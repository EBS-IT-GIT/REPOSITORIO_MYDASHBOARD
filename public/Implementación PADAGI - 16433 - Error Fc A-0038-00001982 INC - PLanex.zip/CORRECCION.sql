UPDATE ra_customer_trx_lines_all rctl
SET    rctl.interface_line_attribute3 = 79604086, last_update_date = sysdate, last_updated_by = 2070
WHERE  rctl.customer_trx_id = 14495209
AND    rctl.interface_line_context = 'ORDER ENTRY';
--1 Registro