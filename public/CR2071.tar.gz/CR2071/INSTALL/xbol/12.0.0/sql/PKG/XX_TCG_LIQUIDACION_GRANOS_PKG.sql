  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_TCG_LIQUIDACION_GRANOS_PKG" AS


  C_PACKAGE_NAME CONSTANT   VARCHAR2(30) := 'XX_TCG_LIQUIDACION_GRANOS_PKG';



/****************************************************************************
 *                                                                          *
 * Name    : Liquidar_1116B                                                 *
 * Purpose : Genera la liquidacion para una Liquidacion de Granos           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Liquidar( p_init_mst_list   IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_commit          IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_liquidacion_id  IN NUMBER
                    , p_procesamiento   IN VARCHAR2 DEFAULT 'INTERFACE'
                    , x_warning        OUT VARCHAR2
                    , x_return_status  OUT VARCHAR2
                    , x_msg_count      OUT NUMBER
                    , x_msg_data       OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Cancelar                                                       *
 * Purpose : Cancela una liquidacion de Granos                              *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Cancelar( p_init_mst_list   IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_commit          IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_liquidacion_id  IN NUMBER
                    , x_warning         OUT VARCHAR2
                    , x_return_status   OUT VARCHAR2
                    , x_msg_count       OUT NUMBER
                    , x_msg_data        OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Borrar_retenciones                                             *
 * Purpose : Borra las retenciones asociadas a una Liquidación de Granos    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_retenciones( p_liquidacion_id IN  NUMBER
                              , p_result         OUT BOOLEAN
                              , p_errmsg         OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Borrar_servicios                                               *
 * Purpose : Borra los servicios asociados a una Liquidación de Granos      *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_servicios( p_liquidacion_id IN  NUMBER
                            , p_result         OUT BOOLEAN
                            , p_errmsg         OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Borrar_CPs_asociadas                                           *
 * Purpose : Borra la asociación de CPs a una Liquidación de Granos         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_CPs_asociadas( p_liquidacion_id IN  NUMBER
                                , p_result         OUT BOOLEAN
                                , p_errmsg         OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Borrar_Certificados_asociados                                  *
 * Purpose : Borra la asociación de Certificados a una Liquidación de       *
 *           Granos                                                         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_Certificados_asociados( p_liquidacion_id IN  NUMBER
                                         , p_result         OUT BOOLEAN
                                         , p_errmsg         OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Borrar_liquidacion                                             *
 * Purpose : Borra las liquidaciones parciales asociadas a una Liquidación  *
 *           de Granos y dicha liquidacion                                  *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_liquidacion( p_liquidacion_id  IN  NUMBER
                              , p_result         OUT BOOLEAN
                              , p_errmsg         OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible                                            *
 * Purpose : Rutina que retorna el peso disponible del 1116B parcial para   *
 *           liquidar, teniendo en cuenta las finales no liquidadas         *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Peso_Disponible( p_liqBParcial_id  IN NUMBER
                              , p_liqBUnica_id    IN NUMBER
                              , p_lock_flag       IN BOOLEAN DEFAULT FALSE)
  RETURN NUMBER;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible_Fijacion                                   *
 * Purpose : Rutina que retorna el peso disponible para liquidar de una     *
 *           linea de fijacion.                                             *
 *           - p_inc_no_liq: en 'Y' incluye liquidaciones no liquidadas     *
 *                           en 'N' no incluye liquidaciones no liq.        *
 *           - p_liquidacion_id: Id de la liquidacion B en la que estoy     *
 *                               parado                                     *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Peso_Disponible_Fijacion( p_fijacion_precio_id IN NUMBER
                                       , p_inc_no_liq         IN VARCHAR2 DEFAULT 'N'
                                       , p_liquidacion_id     IN NUMBER
                                       , p_lock_flag          IN BOOLEAN DEFAULT FALSE)
  RETURN NUMBER;



  /***************************************************************************
  *                                                                          *
  * Name    : Valida_Stock_Disponible                                        *
  * Purpose : Verifica si aun existe stock para bajar en los subinventarios  *
  *           utilizados por la liquidacion de Granos                        *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Valida_Stock_Disponible( p_liquidacion_id IN NUMBER
                                   , p_revertir       IN BOOLEAN
                                   , x_result         OUT BOOLEAN
                                   , x_error_msg      OUT VARCHAR2) ;


  /***************************************************************************
  *                                                                          *
  * Name    : Movimiento_Stock_Liq_Granos                                    *
  * Purpose : Efectua el alta y baja de stock necesarios para el cierre de   *
  *          la liquidacion de Granos                                        *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Movimiento_Stock_Liq_Granos ( p_liquidacion_id  IN NUMBER
                                        , p_revertir        IN BOOLEAN
                                        , x_result          OUT BOOLEAN
                                        , x_error_msg       OUT VARCHAR2);

END XX_TCG_LIQUIDACION_GRANOS_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_TCG_LIQUIDACION_GRANOS_PKG" AS

  --
  -- AP Interface
  --
  C_AP_INVOICE_TYPE_CODE CONSTANT VARCHAR2(30) := 'STANDARD';
  C_AP_INVOICE_TYPE_CODE_NC CONSTANT VARCHAR2(30) := 'CREDIT';
  C_AP_GLOBAL_ATTR_CATEGORY CONSTANT VARCHAR2(30) := 'JL.AR.APXIISIM.INVOICES_FOLDER';
  C_AP_GLOBAL_ATTR_CATEGORY_LN CONSTANT VARCHAR2(30) := 'JL.AR.APXIISIM.LINES_FOLDER';

  ----------------------------------------------
  -- Tipos de registro para liquidacion 1116B
  ----------------------------------------------
  TYPE liq_line_rec_type IS RECORD
  ( description               AP_INVOICE_LINES_INTERFACE.description%TYPE
  , code_combination_id       NUMBER
  , line_type_code            VARCHAR2(30)
  , amount                    NUMBER
  , tax_code                  VARCHAR2(15)
  , legal_trx_category        VARCHAR2(30)
  , tipo_linea                VARCHAR2(10)
  , carta_de_porte            AP_INVOICE_DISTRIBUTIONS_ALL.attribute10%TYPE
  , origen_produccion         AP_INVOICE_DISTRIBUTIONS_ALL.attribute7%TYPE
  , direccion_envio           AP_INVOICE_DISTRIBUTIONS_ALL.global_attribute3%TYPE
  , carta_porte_id            NUMBER
  , line_group_number         NUMBER
  , prorate_across_flag       VARCHAR2(1)
  , tax_classification_code   VARCHAR2(30)
  , tax_rate_id               NUMBER
  , tax_regime_code           VARCHAR2(30)
  , concatenated_segments     VARCHAR2(240)
  );

  TYPE liq_lines_tab_type IS TABLE OF liq_line_rec_type
  INDEX BY BINARY_INTEGER;


  TYPE liquidacion_rec_type IS RECORD
  ( liquidacion_id                 NUMBER
  , organization_id                NUMBER
  , co_code                        VARCHAR2(4)
  , operating_unit                 NUMBER
  , set_of_books_id                NUMBER
  , numero_liquidacion             VARCHAR2(30)
  , tipo_liquidacion               VARCHAR2(30)
  , inventory_item_id              NUMBER
  , lot_number                     NUMBER
  , lineas                         liq_lines_tab_type
  , currency_code                  VARCHAR2(15)
  , numero_contrato                VARCHAR2(15)
  , contrato_id                    NUMBER
  , fecha_liquidacion              DATE
  , term_id                        NUMBER
  , vendor_id                      NUMBER
  , vendor_site_id                 NUMBER
  , metodo_pago                    VARCHAR2(30)
  , unidad_productiva              VARCHAR2(30)
  , empresa_origen_party_id        NUMBER
  , origen_party_site_id           NUMBER
  , depositante_monotributista     VARCHAR2(1)
  , procedencia                    VARCHAR2(30)
  , procedencia_localidad          VARCHAR2(30)
  , empresa_destino_party_id       NUMBER
  , estab_destino_oncca_code       VARCHAR2(30)
  , establecimiento_destino_id     NUMBER
  , provincia_destino_code         VARCHAR2(50)
  , localidad_destino_code         VARCHAR2(50)
  , ship_to_location               NUMBER
  , monto                          NUMBER
  , legal_trx_category_1116        VARCHAR2(30)
  , transaction_letter             VARCHAR2(30)
  , tax_authority_transaction_type VARCHAR2(30)
  , tax_inclusive_flag             VARCHAR2(30)
  , invoice_id                     NUMBER
  , precio_operacion_funcional     NUMBER
  , precio_referencia_funcional    NUMBER
  , peso_neto_liquidado            NUMBER
  , porcentaje_parcial             NUMBER
  , canje_contrato_id              NUMBER
  , fijacion_precio_id             NUMBER
  , tipo_comprobante               VARCHAR2(30)
  , canje_flag                     VARCHAR2(1)
  , liquidado_flag                 VARCHAR2(1)
  , grupo_pago                     VARCHAR2(30)
  , doc_dgi_code                   VARCHAR2(30)
  , doc_dgi_code_nc                VARCHAR2(30)
  , doc_legal_trx_cat              VARCHAR2(30)
  , doc_legal_trx_cat_nc           VARCHAR2(30)
  , doc_trx_letter                 VARCHAR2(30)
  , doc_trx_letter_nc              VARCHAR2(30)
  , vat_code                       VARCHAR2(50)
  , monotributista                 VARCHAR2(1)
  , vendor_type_lookup_code        VARCHAR2(30)
  , acct_id_default_1116b          NUMBER
  , acct_pay_code_combination_id   NUMBER
  , order_number                   VARCHAR2(50)
  , oe_order_type                  VARCHAR2(30)
  , co_code_interco                VARCHAR2(4)
  , customer_bill_address_id       NUMBER
  , customer_ship_address_id       NUMBER
  , ar_term_id                     NUMBER
  , ar_term_name                   VARCHAR2(15)
  , ar_receipt_method_id           NUMBER
  , pto_emision_liq_aju            NUMBER
  , nro_orden_liq_aju              NUMBER
  , fecha_coe_anul                 DATE
  , estado_coe                     VARCHAR2(10)
  , imp_bruto_parcial              NUMBER
  , importe_a_liquidar             NUMBER
  , grado                          NUMBER
  , factor_grado                   NUMBER
  , factor_calidad                 NUMBER
  , factor_resultante              NUMBER
  , fc_a_recibir                   NUMBER
  , peso_diferencia_aju            NUMBER
  , pr_op_diferencia_aju           NUMBER
  , site_use_id                    NUMBER
  , invoice_id_interco             NUMBER
  );


  --
  -- Tipo de registro de atributos
  --
  TYPE attributes_rec_type IS RECORD
  ( attribute1 VARCHAR2(150)
  , attribute2 VARCHAR2(150)
  , attribute3 VARCHAR2(150)
  , attribute4 VARCHAR2(150)
  , attribute5 VARCHAR2(150)
  , attribute6 VARCHAR2(150)
  , attribute7 VARCHAR2(150)
  , attribute8 VARCHAR2(150)
  , attribute9 VARCHAR2(150)
  , attribute10 VARCHAR2(150)
  , attribute11 VARCHAR2(150)
  , attribute12 VARCHAR2(150)
  , attribute13 VARCHAR2(150)
  , attribute14 VARCHAR2(150)
  , attribute15 VARCHAR2(150)
  , attribute16 VARCHAR2(150)
  , attribute17 VARCHAR2(150)
  , attribute18 VARCHAR2(150)
  , attribute19 VARCHAR2(150)
  , attribute20 VARCHAR2(150)
  );


  TYPE p_taxes_liq_rec_tab IS TABLE OF XX_TCG_LIQUIDACION_RETENCIONES%ROWTYPE INDEX BY BINARY_INTEGER;


  TYPE recLOC IS RECORD
    ( locator_id  NUMBER
    , peso        NUMBER);

  TYPE tabLOC IS TABLE OF recLOC INDEX BY BINARY_INTEGER;


  TYPE recCP IS RECORD
    ( carta_porte_id     NUMBER
    , numero_carta_porte VARCHAR2(30)
    , origen             VARCHAR2(5)
    , operating_unit     NUMBER
    , organization_id    NUMBER
    , liquidacion_id     NUMBER
    , peso_a_liquidar    NUMBER
    , lot_number         VARCHAR(10)
    , inventory_item_id  NUMBER
    , owning_org_id      NUMBER
    , subinventario      VARCHAR2(10)
    , locations          tabLOC);

  TYPE tabCPs IS TABLE OF recCP INDEX BY BINARY_INTEGER;


  TYPE rStock IS RECORD
    ( organization_id NUMBER
    , subinv_code     VARCHAR2(10)
    , locator_id      NUMBER
    , quantity        NUMBER
    , owning_org_id   NUMBER);


  TYPE tStock IS TABLE OF rStock INDEX BY BINARY_INTEGER ;

  ---------------------------------------------------
  -- Fin tipos de registro para liquidacion 1116B
  ---------------------------------------------------

/****************************************************************************
 *                     P R I V A T E    R O U T I N E S                     *
 ****************************************************************************/


/****************************************************************************
 *                                                                          *
 * Name    : debug                                                          *
 * Purpose : Debug del paquete.                                             *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE debug ( p_api_name      IN VARCHAR2
                  , p_debug_message IN VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Get_Liquidacion                                                *
 * Purpose : Rutina que retorna la informacion referente al 1116B           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Liquidacion( p_liquidacion_id       IN NUMBER
                           , p_revertir             IN BOOLEAN
                           , p_procesamiento        IN VARCHAR DEFAULT 'INTERFACE'
                           , x_liquidacion_rec     OUT liquidacion_rec_type
                           , x_liquidacion_AR_rec  OUT liquidacion_rec_type
                           , x_result              OUT BOOLEAN
                           , x_errmsg              OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Generar_Linea_Impuesto_AP                                      *
 * Purpose : En funcion de una linea base, genera una linea de impuestos    *
 *           para la factura de AP.                                         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Linea_Impuesto_AP( p_liquidacion_rec     IN OUT NOCOPY liquidacion_rec_type
                                     , p_linea_base          IN NUMBER
                                     , p_tax_code            IN VARCHAR2
                                     , p_legal_trx_category  IN VARCHAR2 DEFAULT NULL
                                     , x_result             OUT BOOLEAN
                                     , x_errmsg             OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Get_Lineas_Factura_Grano                                       *
 * Purpose : Calcula y recupera la lineas de facturacion de granos.         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Lineas_Factura_Grano( p_liquidacion_rec   IN OUT NOCOPY liquidacion_rec_type
                                    , x_result            OUT BOOLEAN
                                    , x_errmsg            OUT VARCHAR2);




/********************************************************************************
 *                                                                              *
 * Name    : Get_Lineas_Factura_Grano_Unica                                     *
 * Purpose : Calcula y recupera la lineas de facturacion de granos(solo unicas) *
 *                                                                              *
 *******************************************************************************/
  PROCEDURE Get_Lineas_Factura_Grano_Unica( p_liquidacion_rec   IN OUT NOCOPY liquidacion_rec_type
                                          , p_flag_cancelado    IN VARCHAR2
                                          , x_result           OUT BOOLEAN
                                          , x_errmsg           OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Get_Linea_Factura_Pend_Final                                   *
 * Purpose : Calcula y recupera la por el pendiente de final de la          *
 *           liquidacion.                                                   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Linea_Factura_Pend_Final( p_liquidacion_rec  IN OUT NOCOPY liquidacion_rec_type
                                        , x_result           OUT BOOLEAN
                                        , x_errmsg           OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Get_Lineas_Factura_Final                                       *
 * Purpose : Calcula las lineas para la liquidacion final                   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Lineas_Factura_Final( p_liquidacion_rec IN OUT NOCOPY liquidacion_rec_type
                                    , x_result          OUT BOOLEAN
                                    , x_errmsg          OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Set_Attribute_Value                                            *
 * Purpose : Setea el valor en el attribute del registro de transaccion.    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Set_Attribute_Value( p_attributes_rec  IN OUT NOCOPY attributes_rec_type
                               , p_column_name     IN VARCHAR2
                               , p_value           IN VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Insertar_Factura_AP                                            *
 * Purpose : Rutina que inserta una factura en la interface de AP           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Insertar_Factura_AP( p_liquidacion_rec   IN OUT NOCOPY liquidacion_rec_type
                               , p_revertir          IN BOOLEAN
                               , p_procesamiento     IN VARCHAR2
                               , x_result           OUT BOOLEAN
                               , x_errmsg           OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Insertar_Lineas_Factura_AP                                     *
 * Purpose : Rutina que inserta las lineas de la factura de AP              *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Insertar_Lineas_Factura_AP( p_liquidacion_rec   IN liquidacion_rec_type
                                      , p_procesamiento     IN VARCHAR2
                                      , x_result           OUT BOOLEAN
                                      , x_errmsg           OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Generar_Transaccion_AR                                         *
 * Purpose : Rutina para la generacion de una Trx Interco en AR a partir de *
 *           la liquidacion de Granos con una empresa Intercompany          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Transaccion_AR( p_liquidacion_rec  IN   OUT NOCOPY liquidacion_rec_type
                                  , p_procesamiento    IN   VARCHAR2
                                  , p_revertir         IN   BOOLEAN
                                  , p_commit           IN   VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                                  , x_result           OUT  BOOLEAN
                                  , x_errmsg           OUT  VARCHAR2
                                  , x_warning          OUT  VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Grabar_retenciones                                             *
 * Purpose : Rutina que crea las retenciones y las graba en la tabla de TCG *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Grabar_retenciones( p_taxes_rec    IN  p_taxes_liq_rec_tab
                              , p_tax_line_num IN  NUMBER
                              , p_result       OUT BOOLEAN
                              , p_errmsg       OUT VARCHAR2) ;



/****************************************************************************
 *                                                                          *
 * Name    : Get_Importe_Retencion                                          *
 * Purpose : Retorna el calculo de la aplicacion de una retencion a un      *
 *           monto.                                                         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Importe_Retencion( p_tax_name   IN VARCHAR2
                                 , p_org_id     IN NUMBER
                                 , p_monto      IN NUMBER
                                 , x_rate      OUT NUMBER
                                 , x_monto     OUT NUMBER
                                 , x_result    OUT BOOLEAN
                                 , x_errmsg    OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AR                                           *
 * Purpose : Rutina para la ejecucion del concurrente de AR                 *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AR( p_org_id              IN NUMBER
                                 , p_batch_source_name   IN VARCHAR2
                                 , p_transaction_number  IN VARCHAR2
                                 , p_customer_class      IN VARCHAR2
                                 , x_result             OUT BOOLEAN
                                 , x_errmsg             OUT VARCHAR2);


/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AP                                           *
 * Purpose : Rutina para la ejecucion del concurrente de Open Interfcae     *
 *          en AP                                                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AP( p_org_id           IN NUMBER
                                 , x_result          OUT BOOLEAN
                                 , x_errmsg          OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Busca_Transacciones_Alta                                       *
 * Purpose : Busca Transacciones con movimientos de Stock de Alta           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Busca_Transacciones_Alta ( p_tabCP        IN OUT tabCPs
                                     , p_index        IN NUMBER
                                     , p_revertir     IN BOOLEAN
                                     , x_result      OUT BOOLEAN
                                     , x_error_msg   OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Busca_Datos_en_CP                                              *
 * Purpose : Busca datos de las Cartas de Porte de r11 para efectuar los    *
 *           movimientos de granos                                          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Busca_Datos_en_CP ( p_tabCP        IN OUT tabCPs
                              , p_index        IN NUMBER
                              , p_revertir     IN BOOLEAN
                              , x_result      OUT BOOLEAN
                              , x_error_msg   OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Get_Cantidad_En_Mano                                           *
 * Purpose : Funcion que devuelve los pesos On Hand de un determinado       *
 *           item, para un locator en particular o para un Subinventario    *
 *         Parametro                                                        *
 *            p_qty_type: Indica que tipo de cantidad se esta buscando      *
 *              Valores posibles                                            *
 *                      QTY_OH     - On Hand Quantity                       *
 *                      QTY_RES_OH - Reservable Quantity On Hand            *
 *                      QTY_RES    - Quantity Reserved                      *
 *                      QTY_SUG    - Quantity Suggested                     *
 *                      QTY_ATT    - Quantity Available To Transact         *
 *                      QTY_ATR    - Quantity Available To Reserve          *
 ****************************************************************************/
  FUNCTION Get_Cantidad_En_Mano ( p_inventory_item_id  IN NUMBER
                                , p_organization_id    IN NUMBER
                                , p_subinventory_code  IN VARCHAR2
                                , p_locator_id         IN NUMBER   DEFAULT NULL
                                , p_lot_number         IN VARCHAR2 DEFAULT NULL
                                , p_qty_type           IN VARCHAR2
                                , x_return_status     OUT VARCHAR2
                                , x_msg_data          OUT VARCHAR2
                                , x_msg_count         OUT NUMBER) RETURN NUMBER;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Cantidad_En_Mano                                           *
 * Purpose : Funcion que devuelve los pesos On Hand de un determinado       *
 *           item, para un locator en particular o para un Subinventario    *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Cantidad_En_Mano ( p_subinventario     IN VARCHAR2
                                , p_locator_id        IN NUMBER DEFAULT NULL
                                , p_owning_org_id     IN NUMBER
                                , p_lot_number        IN VARCHAR2
                                , p_inventory_item_id IN NUMBER
                                , x_result           OUT BOOLEAN
                                , x_error_msg        OUT VARCHAR2) RETURN NUMBER;




/****************************************************************************
 *                                                                          *
 * Name    : Distribuir_Stock_por_Locator                                   *
 * Purpose : Procedimiento que verifica si el movimiento se puede realizar  *
 *           en el locator que especifica la CP o debe usarse stock de otro *
 *          locator dentro del Subinventario                                *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Distribuir_Stock_por_Locator ( p_tabCP        IN OUT tabCPs
                                         , p_tabST        IN OUT tStock
                                         , p_revertir     IN BOOLEAN
                                         , x_result      OUT BOOLEAN
                                         , x_error_msg   OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Determinar_Procesos_a_Realizar                                 *
 * Purpose : Procedimiento que identifica que facturas deben realizarse     *
 *          y si corresponde generar el movimiento de Stock, para el caso   *
 *          en que se este reprocesando el txt recibido por PlanexWare      *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Determinar_Procesos_a_Realizar ( p_liquidacion_id   IN NUMBER
                                           , p_revertir         IN BOOLEAN
                                           , p_factura_AP      OUT BOOLEAN
                                           , p_factura_AR      OUT BOOLEAN
                                           , p_mov_stock       OUT BOOLEAN
                                           , p_result          OUT BOOLEAN
                                           , p_error_msg       OUT VARCHAR2);





/****************************************************************************
 *                     P U B L I C      R O U T I N E S                     *
 ****************************************************************************/





/****************************************************************************
 *                                                                          *
 * Name    : Liquidar                                                       *
 * Purpose : Genera la liquidacion para un 1116B.                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Liquidar( p_init_mst_list    IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_commit           IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_liquidacion_id   IN NUMBER
                    , p_procesamiento    IN VARCHAR2 DEFAULT 'INTERFACE'
                    , x_warning         OUT VARCHAR2
                    , x_return_status   OUT VARCHAR2
                    , x_msg_count       OUT NUMBER
                    , x_msg_data        OUT VARCHAR2) IS


    C_API_NAME                  VARCHAR2(30) := 'Liquidar';
    l_result                    BOOLEAN;
    l_errmsg                    VARCHAR2(3000);
    l_liquidacion_rec           liquidacion_rec_type;
    l_liquidacion_fact_AR_rec   liquidacion_rec_type;
    l_cur_org_id                NUMBER;
    l_cont                      NUMBER;
    l_tipo_almacen              VARCHAR2(50);
    l_ou_chs                    NUMBER;
    l_depositante_chs           NUMBER;
    l_invoice_id                NUMBER;
    l_factura_AP                BOOLEAN := FALSE;
    l_factura_AR                BOOLEAN := FALSE;
    l_mov_stock                 BOOLEAN := FALSE;


  BEGIN


    debug(C_API_NAME, 'Iniciando.');
    debug(C_API_NAME, 'p_liquidacion_id = ' || p_liquidacion_id||' - Procesamiento: '||p_procesamiento);

    -----------------------------------------
    -- Defino un SAVEPOINT antes de procesar
    -----------------------------------------
    IF (p_procesamiento = 'API') THEN
      SAVEPOINT Liquidar_1116B_SVP;
    END IF;

    -----------------------------------
    -- Inicializo el codigo de retorno
    -----------------------------------
    x_return_status := FND_API.G_RET_STS_SUCCESS;

    ----------------------------------
    -- Inicializo la pila de mensajes
    ----------------------------------
    IF (p_init_mst_list = FND_API.G_TRUE) THEN
      debug(C_API_NAME, 'Limpio pila de mensajes.');
      FND_MSG_PUB.Initialize;
    END IF;


    ---------------------------
    -- Recupero la liquidacion
    ---------------------------
    Debug(C_API_NAME, 'Obtengo la liquidacion.');
    Get_Liquidacion ( p_liquidacion_id     => p_liquidacion_id
                    , p_revertir           => FALSE
                    , p_procesamiento      => p_procesamiento
                    , x_liquidacion_rec    => l_liquidacion_rec
                    , x_liquidacion_AR_rec => l_liquidacion_fact_AR_rec
                    , x_result             => l_result
                    , x_errmsg             => l_errmsg);


    IF (NOT l_result) THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos: '||l_errmsg);
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;
    END IF;


    Debug(C_API_NAME, 'Set Policy Context');
    MO_GLOBAL.Set_Policy_Context('S', l_liquidacion_rec.operating_unit);


    ---------------------------------------------------------------------------
    -- Para el caso en que se este reprocesando un txt enviado por PlanexWare
    -- se determina que transaccion falta realizar y/o movimiento de Stock
    ---------------------------------------------------------------------------
    IF (p_procesamiento = 'INTERFACE') THEN

      Determinar_Procesos_a_Realizar ( p_liquidacion_id => p_liquidacion_id
                                     , p_revertir       => FALSE
                                     , p_factura_AP     => l_factura_AP
                                     , p_factura_AR     => l_factura_AR
                                     , p_mov_stock      => l_mov_stock
                                     , p_result         => l_result
                                     , p_error_msg      => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos: '||l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;


    IF (l_liquidacion_rec.tipo_liquidacion IN ('Unica','Ajuste Unico')) AND
      ((p_procesamiento = 'API')
        OR
       (p_procesamiento = 'INTERFACE' AND l_mov_stock)) THEN

      Valida_Stock_Disponible( p_liquidacion_id => p_liquidacion_id
                             , p_revertir       => FALSE
                             , x_result         => l_result
                             , x_error_msg      => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos: '||l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;

    ----------------------------------------------------------------------------
    -- Si es necesario obtener el COE, se llamara a la API para ----------------
    -- insertar momentaneamente en AP y calcular las retenciones,---------------
    -- Si el COE ya fue obtenido, se procesa la factura en AP por Interface ----
    ----------------------------------------------------------------------------


    IF ((p_procesamiento = 'API')
      OR
      (p_procesamiento = 'INTERFACE' AND l_factura_AP)) THEN

      ------------------------------------
      -- Inserto la cabecera de la factura
      ------------------------------------
      Debug(C_API_NAME, 'Insertando cabecera de factura en AP. ');

      Insertar_Factura_AP( p_liquidacion_rec  => l_liquidacion_rec
                         , p_revertir         => FALSE
                         , p_procesamiento    => p_procesamiento
                         , x_result           => l_result
                         , x_errmsg           => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos. No fue posible insertar '
                              ||'la cabecera de la factura: '|| l_errmsg);
        FND_MSG_PUB.add;

        RAISE FND_API.G_EXC_ERROR;
      END IF;

      ---------------------
      -- Inserto las lineas
      ---------------------
      Debug(C_API_NAME, 'Insertando lineas de factura en AP. ');

      Insertar_Lineas_Factura_AP( p_liquidacion_rec  => l_liquidacion_rec
                                , p_procesamiento    => p_procesamiento
                                , x_result           => l_result
                                , x_errmsg           => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos. No fue posible insertar '
                              ||'las lineas de la factura: '|| l_errmsg);
        FND_MSG_PUB.add;

        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;


    ------------------------------
    -- Ejecutar Interfase de AP
    ------------------------------

    IF (p_procesamiento = 'INTERFACE' AND l_factura_AP) THEN

      COMMIT;


      Ejecutar_Interface_AP( p_org_id    => l_liquidacion_rec.operating_unit
                           , x_result    => l_result
                           , x_errmsg    => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos al intentar ejecutar '
                              ||'el programa de Open Interface de AP: '|| l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;

      ELSE

        BEGIN
          SELECT invoice_id
            INTO l_invoice_id
            FROM AP_INVOICES_ALL
           WHERE source                   = 'ACOPIO'
             AND invoice_type_lookup_code = 'STANDARD'
             AND invoice_num              = l_liquidacion_rec.numero_liquidacion;

        EXCEPTION
          WHEN no_data_found THEN
            FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
            FND_MESSAGE.set_token ('MESSAGE', 'No se encuentra la Factura en AP para la liquidacion '
                                  ||l_liquidacion_rec.numero_liquidacion||' con el source = ACOPIO');
            FND_MSG_PUB.add;
            RAISE FND_API.G_EXC_ERROR;
        END;


        XX_TCG_LIQUIDACION_UTIL_PKG.Ejecutar_Validacion_Documento ( p_invoice_id   => l_invoice_id
                                                                  , x_result       => l_result
                                                                  , x_errmsg       => l_errmsg);

        IF (NOT l_result) THEN

          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE', l_errmsg||' - liquidacion '||l_liquidacion_rec.numero_liquidacion
                                ||' con invoice_id '||l_invoice_id);
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;

        ELSE

          XX_TCG_LIQUIDACION_UTIL_PKG.Ejecutar_Liberacion_de_Holds ( p_org_id      => l_liquidacion_rec.operating_unit
                                                                   , p_invoice_id  => l_invoice_id
                                                                   , x_result      => l_result
                                                                   , x_errmsg      => l_errmsg);

          IF (NOT l_result) THEN

            FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
            FND_MESSAGE.set_token ('MESSAGE', l_errmsg||' - liquidacion '||l_liquidacion_rec.numero_liquidacion
                                  ||' con invoice_id '||l_invoice_id);
            FND_MSG_PUB.add;
            RAISE FND_API.G_EXC_ERROR;

          END IF;

        END IF;


      END IF;


    END IF;



    IF (p_procesamiento = 'INTERFACE') AND                                       -- Agregado CR612 Revised Jul 2018
      (l_factura_AP) AND (NOT l_factura_AR) THEN

      Debug(C_API_NAME, 'Update interface_header_attribute5 = l_invoice_id ('||l_invoice_id||')');

      UPDATE RA_CUSTOMER_TRX_ALL
         SET interface_header_attribute5 = l_invoice_id
       WHERE trx_number                  = 'A-'||l_liquidacion_rec.numero_liquidacion
         AND interface_header_context    = 'ACOPIO'
         AND interface_header_attribute2 = 'FC';

    END IF;


    SELECT xtpc.operating_unit
         , aps.party_id
      INTO l_ou_chs
         , l_depositante_chs
      FROM HR_OPERATING_UNITS         hou
         , XX_TCG_PARAMETROS_COMPANIA xtpc
         , AP_SUPPLIERS               aps
     WHERE 1=1
     --AND hou.name            = 'AR CHS UO'  TK1485
     AND xtpc.operating_unit = 1357
     AND hou.organization_id = xtpc.operating_unit
     AND xtpc.vendor_id      = aps.vendor_id
     ;



    -- Genero FC Interco si el proveedor de la liquidacion es INTERCOMPANY.
    IF (l_liquidacion_rec.vendor_type_lookup_code = 'INTERCOMPANY')
      /*AND (l_liquidacion_rec.operating_unit != l_ou_chs)
      AND (l_liquidacion_rec.empresa_origen_party_id != l_depositante_chs ) TK1485*/
      AND (l_liquidacion_rec.tipo_liquidacion = 'Unica')
      AND ((p_procesamiento = 'API')
        OR (p_procesamiento = 'INTERFACE' AND l_factura_AR)) THEN


      --Agregado CR612 Revised Jul 2018
      IF (p_procesamiento = 'INTERFACE') AND (NOT l_factura_AP) THEN

        BEGIN
          SELECT invoice_id
            INTO l_invoice_id
            FROM AP_INVOICES_ALL
           WHERE source                   = 'ACOPIO'
             AND invoice_type_lookup_code = 'STANDARD'
             AND invoice_num              = l_liquidacion_rec.numero_liquidacion;

          l_liquidacion_fact_AR_rec.invoice_id_interco := l_invoice_id;                 --CR612 Revised Jul 2018

        EXCEPTION
          WHEN no_data_found THEN
            FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
            FND_MESSAGE.set_token ('MESSAGE', 'No se encuentra la Factura en AP para la liquidacion '
                                  ||l_liquidacion_rec.numero_liquidacion||' con el source = ACOPIO');
            FND_MSG_PUB.add;
            RAISE FND_API.G_EXC_ERROR;
        END;

      ELSIF (p_procesamiento = 'INTERFACE') AND (l_factura_AP) THEN

        l_liquidacion_fact_AR_rec.invoice_id_interco := l_invoice_id;

      END IF;
      --

      Debug(C_API_NAME, 'l_liquidacion_fact_AR_rec.invoice_id_interco: '||l_liquidacion_fact_AR_rec.invoice_id_interco);

      Debug(C_API_NAME, 'Insertando factura interco en AR. Procesamiento: '||p_procesamiento);

        Generar_Transaccion_AR( p_liquidacion_rec => l_liquidacion_fact_AR_rec
                              , p_procesamiento   => p_procesamiento
                              , p_revertir        => FALSE
                              , p_commit          => p_commit
                              , x_result          => l_result
                              , x_errmsg          => l_errmsg
                              , x_warning         => x_warning);


        IF (NOT l_result) THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE', 'Error generando FC INTERCO en AR: '||l_errmsg);
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;
        END IF;

        MO_GLOBAL.Set_Policy_Context('S', l_liquidacion_rec.operating_unit);

    END IF;



    IF (p_procesamiento = 'INTERFACE')
      AND (l_mov_stock)
      AND (l_liquidacion_rec.tipo_liquidacion IN ('Unica'
                                                ,'Ajuste Unico'))
      AND (l_liquidacion_rec.contrato_id IS NOT NULL) THEN

      -------------------------------------------
      -- Se realiza el movimiento de inventario
      -------------------------------------------
      Movimiento_Stock_Liq_Granos( p_liquidacion_id  => p_liquidacion_id
                                 , p_revertir        => FALSE
                                 , x_result          => l_result
                                 , x_error_msg       => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE',
                               'Error generando el movimiento de Inventario: '|| l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;


      ------------------------------------------------
      -- Efectuo un COMMIT, dependiendo del parametro
      ------------------------------------------------
      IF (FND_API.to_boolean(p_commit)) THEN
        COMMIT;
      END IF;


    ELSIF (p_procesamiento = 'API') THEN

      Debug(C_API_NAME, 'Procesamiento API. Realizando ROLLBACK');


      ROLLBACK TO SAVEPOINT Liquidar_1116B_SVP;

    END IF;

    Debug(C_API_NAME,'Fin');

  EXCEPTION
    WHEN FND_API.G_EXC_ERROR THEN
      IF (p_procesamiento = 'API') THEN
        ROLLBACK TO Liquidar_1116B_SVP;
      END IF;

      x_return_status := FND_API.G_RET_STS_ERROR;

      FND_MSG_PUB.Count_And_Get ( p_count => x_msg_count
                                , p_data  => x_msg_data);

      Debug(C_API_NAME, 'Salgo con error esperado: '|| XX_ACO_UTIL_PK.Get_msg(x_msg_count));

    WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
      IF (p_procesamiento = 'API') THEN
        ROLLBACK TO Liquidar_1116B_SVP;
      END IF;

      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;

      FND_MSG_PUB.Count_And_Get ( p_count => x_msg_count
                                , p_data  => x_msg_data);

      Debug(C_API_NAME, 'Salgo con error inesperado: '|| XX_ACO_UTIL_PK.Get_msg(x_msg_count));

    WHEN others THEN
      IF (p_procesamiento = 'API') THEN
        ROLLBACK TO Liquidar_1116B_SVP;
      END IF;

      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE', 'XX_TCG_Liquidacion_Granos_PKG.Liquidar. '
                             ||'Error inesperado - ' || SQLERRM);
      FND_MSG_PUB.Add;

      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;

      FND_MSG_PUB.Count_And_Get( p_count => x_msg_count
                               , p_data  => x_msg_data);

      Debug(C_API_NAME, 'Salgo con error: '|| XX_ACO_UTIL_PK.Get_msg(x_msg_count));

  END Liquidar;





/****************************************************************************
 *                                                                          *
 * Name    : Cancelar                                                       *
 * Purpose : Cancela una liquidacion de Granos                              *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Cancelar( p_init_mst_list   IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_commit          IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                    , p_liquidacion_id  IN NUMBER
                    , x_warning         OUT VARCHAR2
                    , x_return_status   OUT VARCHAR2
                    , x_msg_count       OUT NUMBER
                    , x_msg_data        OUT VARCHAR2)
  IS

    C_API_NAME                  VARCHAR2(30) := 'Cancelar';
    l_procesamiento             VARCHAR2(30) := 'INTERFACE';
    l_result                    BOOLEAN;
    l_errmsg                    VARCHAR2(3000);
    l_liquidacion_rec           liquidacion_rec_type;
    l_numero_liquidacion        VARCHAR2(30);
    l_liquidacion_fact_AR_rec   liquidacion_rec_type;
    l_tipo_almacen              VARCHAR2(50);
    l_ou_chs                    NUMBER;
    l_depositante_chs           NUMBER;
    l_invoice_id                NUMBER;
    l_factura_AP                BOOLEAN := FALSE;
    l_factura_AR                BOOLEAN := FALSE;
    l_mov_stock                 BOOLEAN := FALSE;



  BEGIN

    Debug(C_API_NAME, 'Iniciando.');
    Debug(C_API_NAME, 'p_liquidacion_id = ' || p_liquidacion_id);

    -----------------------------------------
    -- Defino un SAVEPOINT antes de procesar
    -----------------------------------------
    IF (NOT FND_API.to_boolean(p_commit)) THEN
      SAVEPOINT Cancelar_1116B_SVP;
    END IF;

    -----------------------------------
    -- Inicializo el codigo de retorno
    -----------------------------------
    x_return_status := FND_API.G_RET_STS_SUCCESS;

    ----------------------------------
    -- Inicializo la pila de mensajes
    ----------------------------------
    IF (p_init_mst_list = FND_API.G_TRUE) THEN
      Debug(C_API_NAME, 'Limpio pila de mensajes.');
      FND_MSG_PUB.Initialize;
    END IF;

    ---------------------------
    -- Recupero la liquidacion
    ---------------------------
    Debug(C_API_NAME, 'Obtengo la liquidacion.');

    Get_Liquidacion( p_liquidacion_id     => p_liquidacion_id
                   , p_revertir           => TRUE
                   , p_procesamiento      => l_procesamiento
                   , x_liquidacion_rec    => l_liquidacion_rec
                   , x_liquidacion_AR_rec => l_liquidacion_fact_AR_rec
                   , x_result             => l_result
                   , x_errmsg             => l_errmsg);

    IF (NOT l_result) THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE','Error cancelando liquidacion de Granos: '||l_errmsg);
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;
    END IF;


    ----------------------------------------------
    -- Si es una liquidacion parcial, verifico que
    -- no este en una de Ajuste Unico
    ----------------------------------------------
    IF (UPPER(l_liquidacion_rec.tipo_liquidacion) = 'PARCIAL') THEN

      BEGIN

        SELECT xlb.numero_liquidacion
          INTO l_numero_liquidacion
          FROM (SELECT liquidacion_id
                     , cancelado_flag
                     , numero_liquidacion
                  FROM XX_ACO_LIQUIDACIONES_1116B
                 UNION
                SELECT liquidacion_id
                     , cancelado_flag
                     , numero_liquidacion
                  FROM XX_TCG_LIQUIDACIONES) xlb
             , XX_TCG_LIQUIDACION_LINES      xlbl
         WHERE xlbl.liquidacion_id_parcial = p_liquidacion_id
           AND xlbl.liquidacion_id         = xlb.liquidacion_id
           AND xlb.cancelado_flag          = 'N'
           AND ROWNUM                      = 1;

      EXCEPTION
        WHEN no_data_found THEN
          NULL;
        WHEN others THEN
          FND_MESSAGE.set_Name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_Token ('MESSAGE','Se produjo un error inesperado al intentar validar si '
                                ||'la liquidacion parcial se encuentra referenciada en una liquidacion '
                                ||'de Ajuste Unico: '||SQLERRM);
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;
      END;

      IF (l_numero_liquidacion IS NOT NULL) THEN

        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'No es posible cancelar la liquidacion dado que se encuentra incluida '
                              ||'en la liquidacion final '||l_numero_liquidacion||'.');
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;


    Debug(C_API_NAME, 'Set Policy Context');
    MO_GLOBAL.Set_Policy_Context('S', l_liquidacion_rec.operating_unit);


    IF (FND_API.to_boolean(p_commit)) THEN

      Determinar_Procesos_a_Realizar ( p_liquidacion_id => p_liquidacion_id
                                     , p_revertir       => TRUE
                                     , p_factura_AP     => l_factura_AP
                                     , p_factura_AR     => l_factura_AR
                                     , p_mov_stock      => l_mov_stock
                                     , p_result         => l_result
                                     , p_error_msg      => l_errmsg);


      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error Cancelando liquidacion de Granos: '||l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;

    /* CR612  Revised Jul 2018 -- Se solicita que la validación de Stock se efectúe solamente cuando
      el mismo tiene owner

    IF (l_liquidacion_rec.tipo_liquidacion IN ('Unica','Ajuste Unico'))
      AND ((NOT FND_API.to_boolean(p_commit))
            OR
            (FND_API.to_boolean(p_commit) AND l_mov_stock)) THEN

      Valida_Stock_Disponible( p_liquidacion_id => p_liquidacion_id
                             , p_revertir       => TRUE
                             , x_result         => l_result
                             , x_error_msg      => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error Cancelando liquidacion de Granos: '||l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;
   */

    IF ((NOT FND_API.to_boolean(p_commit))
       OR
       (FND_API.to_boolean(p_commit) AND l_factura_AP)) THEN

      ------------------------------------
      -- Inserto la cabecera de la factura
      ------------------------------------
      debug(C_API_NAME, 'Inserto factura AP.');

      Insertar_Factura_AP( p_liquidacion_rec  => l_liquidacion_rec
                         , p_revertir         => TRUE
                         , p_procesamiento    => l_procesamiento
                         , x_result           => l_result
                         , x_errmsg           => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token('MESSAGE', 'Error cancelando liquidacion de Granos. No fue posible insertar la cabecera '
                              ||'de la factura. '||l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;


      ---------------------
      -- Inserto las lineas
      ---------------------
      debug(C_API_NAME, 'Inserto lineas AP.');

      Insertar_Lineas_Factura_AP( p_liquidacion_rec  => l_liquidacion_rec
                                , p_procesamiento    => l_procesamiento
                                , x_result           => l_result
                                , x_errmsg           => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_Name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_Token ('MESSAGE', 'Error cancelando liquidacion de Granos. No fue posible insertar las lineas '
                              ||'de la factura. '||l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;


    ------------------------------
    -- Ejecutar Interfase de AP
    ------------------------------

    IF (l_procesamiento = 'INTERFACE' AND
      FND_API.to_boolean(p_commit) AND l_factura_AP) THEN

      COMMIT;


      Ejecutar_Interface_AP( p_org_id    => l_liquidacion_rec.operating_unit
                           , x_result    => l_result
                           , x_errmsg    => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion de Granos al intentar ejecutar '
                              ||'el programa de Open Interface de AP: '|| l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;


      ELSE

        BEGIN
          SELECT invoice_id
            INTO l_invoice_id
            FROM AP_INVOICES_ALL
           WHERE source                   = 'ACOPIO'
             AND invoice_type_lookup_code = 'CREDIT'
             AND invoice_num              = l_liquidacion_rec.numero_liquidacion||'*';

        EXCEPTION
          WHEN no_data_found THEN
            FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
            FND_MESSAGE.set_token ('MESSAGE', 'No se encuentra la Factura en AP para la liquidacion '
                                  ||l_liquidacion_rec.numero_liquidacion||'* con el source = ACOPIO');
            FND_MSG_PUB.add;
            RAISE FND_API.G_EXC_ERROR;
        END;


        XX_TCG_LIQUIDACION_UTIL_PKG.Ejecutar_Validacion_Documento ( p_invoice_id   => l_invoice_id
                                                                  , x_result       => l_result
                                                                  , x_errmsg       => l_errmsg);

        IF (NOT l_result) THEN

          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE', l_errmsg||' - liquidacion '||l_liquidacion_rec.numero_liquidacion
                                ||'* con invoice_id '||l_invoice_id);
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;

        ELSE

          XX_TCG_LIQUIDACION_UTIL_PKG.Ejecutar_Liberacion_de_Holds ( p_org_id      => l_liquidacion_rec.operating_unit
                                                                   , p_invoice_id  => l_invoice_id
                                                                   , x_result      => l_result
                                                                   , x_errmsg      => l_errmsg);

          IF (NOT l_result) THEN

            FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
            FND_MESSAGE.set_token ('MESSAGE', l_errmsg||' - liquidacion '||l_liquidacion_rec.numero_liquidacion
                                  ||'* con invoice_id '||l_invoice_id);
            FND_MSG_PUB.add;
            RAISE FND_API.G_EXC_ERROR;

          END IF;

        END IF;

      END IF;


    END IF;


    SELECT xtpc.operating_unit
         , aps.party_id
      INTO l_ou_chs
         , l_depositante_chs
      FROM HR_OPERATING_UNITS         hou
         , XX_TCG_PARAMETROS_COMPANIA xtpc
         , AP_SUPPLIERS               aps
     WHERE 1=1
     --AND hou.name            = 'AR CHS UO'  TK1485
     AND xtpc.operating_unit = 1357
     AND hou.organization_id = xtpc.operating_unit
     AND xtpc.vendor_id      = aps.vendor_id;



    IF (l_liquidacion_rec.vendor_type_lookup_code = 'INTERCOMPANY')
      /*AND (l_liquidacion_rec.operating_unit != l_ou_chs) TK 1485
      AND (l_liquidacion_rec.vendor_id != l_depositante_chs) */
      AND (l_liquidacion_rec.tipo_liquidacion = 'Unica')
      AND ((NOT FND_API.to_boolean(p_commit))
          OR (FND_API.to_boolean(p_commit) AND l_factura_AR)) THEN


      --Agregado CR612 Revised Jul 2018
      IF (FND_API.to_boolean(p_commit)) THEN

        Debug(C_API_NAME, 'Busca invoice_id - l_liquidacion_rec.numero_liquidacion: '||l_liquidacion_rec.numero_liquidacion);

        BEGIN
          SELECT invoice_id
            INTO l_invoice_id
            FROM AP_INVOICES_ALL
           WHERE source                   = 'ACOPIO'
             AND invoice_type_lookup_code = 'CREDIT'
             AND invoice_num              = l_liquidacion_rec.numero_liquidacion||'*';

          l_liquidacion_fact_AR_rec.invoice_id_interco := l_invoice_id;

        EXCEPTION
          WHEN no_data_found THEN
            FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
            FND_MESSAGE.set_token ('MESSAGE', 'No se encuentra la Factura en AP para la liquidacion '
                                  ||l_liquidacion_rec.numero_liquidacion||' con el source = ACOPIO');
            FND_MSG_PUB.add;
            RAISE FND_API.G_EXC_ERROR;
        END;

      END IF;
      --

        Debug(C_API_NAME, 'l_liquidacion_fact_AR_rec.invoice_id_interco: '||l_liquidacion_fact_AR_rec.invoice_id_interco);


        Debug(C_API_NAME, 'Genero NC Interco AR.');

        Generar_Transaccion_AR( p_liquidacion_rec => l_liquidacion_fact_AR_rec
                              , p_procesamiento   => l_procesamiento
                              , p_revertir        => TRUE
                              , p_commit          => p_commit
                              , x_result          => l_result
                              , x_errmsg          => l_errmsg
                              , x_warning         => x_warning);


        IF (NOT l_result) THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE','Error generando NC INTERCO. No fue posible insertar la factura en AR: '
                                || l_errmsg);
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;
        END IF;

        MO_GLOBAL.Set_Policy_Context('S', l_liquidacion_rec.operating_unit);

    END IF;


    IF (l_factura_AP) AND (NOT l_factura_AR) THEN

      UPDATE RA_CUSTOMER_TRX_ALL
         SET interface_header_attribute5 = l_invoice_id
       WHERE trx_number                  = 'A-'||l_liquidacion_rec.numero_liquidacion
         AND interface_header_context    = 'ACOPIO'
         AND interface_header_attribute2 = 'NC';

    END IF;


    IF (l_liquidacion_rec.tipo_liquidacion IN ('Unica'
                                              ,'Ajuste Unico'))
      AND (l_liquidacion_rec.contrato_id IS NOT NULL)
      AND ((NOT FND_API.to_boolean(p_commit))
          OR (FND_API.to_boolean(p_commit) AND l_mov_stock)) THEN

      -------------------------------------------
      -- Se realiza el movimiento de inventario
      -------------------------------------------
      Movimiento_Stock_Liq_Granos( p_liquidacion_id  => p_liquidacion_id
                                 , p_revertir        => TRUE
                                 , x_result          => l_result
                                 , x_error_msg       => l_errmsg);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE',
                               'Error generando el movimiento de Inventario: '|| l_errmsg);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;

    ------------------------------------------------
    -- Efectuo un COMMIT, dependiendo del parametro
    ------------------------------------------------
    IF (FND_API.to_boolean(p_commit)) THEN
      Debug(C_API_NAME, 'Genero Commit.');
      COMMIT;
    ELSE
      Debug(C_API_NAME, 'Genero Rollback');
      ROLLBACK TO Cancelar_1116B_SVP;
    END IF;

    Debug(C_API_NAME, 'Fin.');

  EXCEPTION
    WHEN FND_API.G_EXC_ERROR THEN
      IF (NOT FND_API.to_boolean(p_commit)) THEN
        ROLLBACK TO Cancelar_1116B_SVP;
      END IF;

      x_return_status := FND_API.G_RET_STS_ERROR;

      FND_MSG_PUB.Count_and_get( p_count => x_msg_count, p_data  => x_msg_data);

      Debug(C_API_NAME, 'Salgo con error esperado: '||XX_ACO_UTIL_PK.Get_MSg(x_msg_count));

    WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
      IF (NOT FND_API.to_boolean(p_commit)) THEN
        ROLLBACK TO Cancelar_1116B_SVP;
      END IF;

      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;

      FND_MSG_PUB.Count_and_get( p_count => x_msg_count, p_data  => x_msg_data);

      debug(C_API_NAME, 'Salgo con error inesperado: '||XX_ACO_UTIL_PK.Get_MSg(x_msg_count));

    WHEN others THEN
      IF (NOT FND_API.to_boolean(p_commit)) THEN
        ROLLBACK TO Cancelar_1116B_SVP;
      END IF;

      FND_MESSAGE.set_name('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token('MESSAGE', 'XX_TCG_Liquidacion_Granos_PKG.Cancelar '||SQLERRM);
      FND_MSG_PUB.Add;

      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;

      FND_MSG_PUB.Count_And_Get( p_count => x_msg_count, p_data  => x_msg_data);

      debug(C_API_NAME, 'Salgo con error: '|| XX_ACO_UTIL_PK.Get_MSg(x_msg_count));

  END Cancelar;




/****************************************************************************
 *                                                                          *
 * Name    : debug                                                          *
 * Purpose : Debug del paquete.                                             *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE debug ( p_api_name      IN VARCHAR2
                  , p_debug_message IN VARCHAR2) IS

    l_message VARCHAR2(1000);
    l_user_id NUMBER        := FND_PROFILE.value('USER_ID');
    l_debug   VARCHAR2(1)   := NVL(FND_PROFILE.value('XX_TCG_HABILITA_DEBUG'), 'N');

  BEGIN
xx_debug_aux_pk.debug(p_module => 'CONTROL', p_message =>'p_api_name: '||p_api_name||' - l_user_id: '||l_user_id||' - l_debug: '||l_debug);
    IF (l_user_id = 2070) THEN  --SCHEDULED_REQUESTS
      l_debug := 'Y';
    END IF;

    IF (l_debug = 'Y') THEN

      l_message :=  p_api_name || ': ' || p_debug_message;

      XX_DEBUG_AUX_PK.debug ( p_module => C_PACKAGE_NAME, p_message => l_message);

    END IF;

  END debug;



/****************************************************************************
 *                                                                          *
 * Name    : Borrar_retenciones                                             *
 * Purpose : Borra las retenciones asociadas a una Liquidación de Granos    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_retenciones( p_liquidacion_id IN  NUMBER
                              , p_result         OUT BOOLEAN
                              , p_errmsg         OUT VARCHAR2)
  IS

  BEGIN

    p_result:= TRUE;

    DELETE FROM XX_ACO_LIQ_1116B_RET
     WHERE liquidacion_id = p_liquidacion_id;

    DELETE FROM XX_TCG_LIQUIDACION_RETENCIONES
     WHERE liquidacion_id = p_liquidacion_id;

  EXCEPTION
    WHEN no_data_found THEN
      NULL;

    WHEN others THEN
      p_result:= FALSE;
      p_errmsg:= SQLERRM;

  END Borrar_retenciones;



/****************************************************************************
 *                                                                          *
 * Name    : Borrar_servicios                                               *
 * Purpose : Borra los servicios asociados a una Liquidación de Granos      *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_servicios( p_liquidacion_id IN  NUMBER
                            , p_result         OUT BOOLEAN
                            , p_errmsg         OUT VARCHAR2)
  IS

  BEGIN

    p_result:= TRUE;

    DELETE FROM XX_ACO_LIQ_1116B_SERVICIOS
     WHERE liquidacion_id = p_liquidacion_id;

    DELETE FROM XX_TCG_LIQUIDACION_SERVICIOS
     WHERE liquidacion_id = p_liquidacion_id;


  EXCEPTION
    WHEN no_data_found THEN
      NULL;

    WHEN others THEN
      p_result:= FALSE;
      p_errmsg:= SQLERRM;

  END Borrar_servicios;




/****************************************************************************
 *                                                                          *
 * Name    : Borrar_CPs_asociadas                                           *
 * Purpose : Borra la asociación de CPs a una Liquidación de Granos         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_CPs_asociadas( p_liquidacion_id IN  NUMBER
                                , p_result         OUT BOOLEAN
                                , p_errmsg         OUT VARCHAR2)
  IS

  BEGIN

    p_result:= TRUE;

    DELETE FROM XX_ACO_CARTA_PORTE_LIQ1116B
     WHERE liquidacion_1116B = p_liquidacion_id;

    DELETE FROM XX_TCG_CARTAS_PORTE_LIQUIDADAS
     WHERE liquidacion_id = p_liquidacion_id;


  EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN others THEN
      p_result:= FALSE;
      p_errmsg:= SQLERRM;

  END Borrar_CPs_asociadas;




/****************************************************************************
 *                                                                          *
 * Name    : Borrar_Certificados_asociados                                  *
 * Purpose : Borra la asociación de Certificados a una Liquidación de       *
 *           Granos                                                         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_Certificados_asociados( p_liquidacion_id IN  NUMBER
                                         , p_result         OUT BOOLEAN
                                         , p_errmsg         OUT VARCHAR2)
  IS

  BEGIN

    p_result:= TRUE;

    DELETE FROM XX_ACO_LIQ_1116B_CERTIF
     WHERE liquidacion_1116b_id = p_liquidacion_id;

    DELETE FROM XX_TCG_CERTIFICADOS_LIQUIDADOS
     WHERE liquidacion_id = p_liquidacion_id;


  EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN others THEN
      p_result:= FALSE;
      p_errmsg:= SQLERRM;

  END Borrar_Certificados_asociados;




/****************************************************************************
 *                                                                          *
 * Name    : Borrar_liquidacion                                             *
 * Purpose : Borra las liquidaciones parciales asociadas a una Liquidación  *
 *           de Granos y dicha liquidacion                                  *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Borrar_liquidacion( p_liquidacion_id IN  NUMBER
                              , p_result         OUT BOOLEAN
                              , p_errmsg         OUT VARCHAR2)
  IS

  BEGIN

    p_result:= TRUE;

    BEGIN

      DELETE FROM XX_ACO_LIQ_1116B_LINES
       WHERE liquidacion_id = p_liquidacion_id;

      DELETE FROM XX_TCG_LIQUIDACION_LINES
       WHERE liquidacion_id = p_liquidacion_id;

    EXCEPTION
      WHEN no_data_found THEN
        NULL;
      WHEN others THEN
        p_result:= FALSE;
        p_errmsg:= 'Error al intentar borrar las lineas de la liquidacion: '||SQLERRM;

    END;

    DELETE FROM XX_ACO_LIQUIDACIONES_1116B
     WHERE liquidacion_id = p_liquidacion_id;

    DELETE FROM XX_TCG_LIQUIDACIONES
     WHERE liquidacion_id = p_liquidacion_id;


  EXCEPTION
    WHEN others THEN
      p_result:= FALSE;
      p_errmsg:= SQLERRM;

  END Borrar_liquidacion;





/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible                                            *
 * Purpose : Rutina que retorna el peso disponible del 1116B parcial para   *
 *           liquidar, teniendo en cuenta las finales no liquidadas         *
 *           y las de Ajuste Unico no liquidadas                            *
 ****************************************************************************/
  PROCEDURE Get_Peso_Disponible( p_liqBParcial_id  IN NUMBER
                               , p_liqBUnica_id    IN NUMBER
                               , p_lock_flag       IN BOOLEAN DEFAULT FALSE
                               , x_peso           OUT NUMBER
                               , x_result         OUT BOOLEAN
                               , x_errmsg         OUT VARCHAR2)
  IS

    C_API_NAME         VARCHAR2(30) := 'Get_Peso_Disponible';
    l_peso_liquidado   NUMBER;
    l_peso_subtotal    NUMBER;

  BEGIN

    x_result := TRUE;

    ----------------------------
    -- Obtengo el peso liquidado
    ----------------------------
    BEGIN

      IF (NOT p_lock_flag) THEN
        SELECT peso_neto_liquidado
          INTO l_peso_liquidado
          FROM (SELECT liquidacion_id
                     , peso_neto_liquidado
                  FROM XX_ACO_LIQUIDACIONES_1116B
                 UNION
                SELECT liquidacion_id
                     , peso_neto_liquidado
                  FROM XX_TCG_LIQUIDACIONES)
         WHERE liquidacion_id = p_liqBParcial_id;
      ELSE
        BEGIN
          SELECT peso_neto_liquidado
            INTO l_peso_liquidado
            FROM XX_ACO_LIQUIDACIONES_1116B
           WHERE liquidacion_id = p_liqBParcial_id
             FOR UPDATE NOWAIT;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT peso_neto_liquidado
              INTO l_peso_liquidado
              FROM XX_TCG_LIQUIDACIONES
             WHERE liquidacion_id = p_liqBParcial_id
               FOR UPDATE NOWAIT;
        END;

      END IF;

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo el peso liquidado para la liquidacion id: '|| p_liqBParcial_id
                    ||'. '|| SQLERRM;
        RETURN;
    END;

    ----------------------------------------------
    -- Obtengo la suma de los pesos de las finales
    -- contra la parcial, esten liquidadas o no
    ----------------------------------------------
    BEGIN
      SELECT NVL(SUM(peso_liquidado),0)
        INTO l_peso_subtotal
        FROM (SELECT xlbl.liquidacion_id_parcial
                   , xlb.liquidacion_id
                   , xlb.cancelado_flag
                   , xlb.liquidado_flag
                   , xlbl.peso_liquidado
                FROM XX_ACO_LIQUIDACIONES_1116B xlb
                   , XX_ACO_LIQ_1116B_LINES     xlbl
               WHERE xlbl.liquidacion_id = xlb.liquidacion_id
               UNION
              SELECT xtll.liquidacion_id_parcial
                   , xtl.liquidacion_id
                   , xtl.cancelado_flag
                   , xtl.liquidado_flag
                   , xtll.peso_liquidado
                FROM XX_TCG_LIQUIDACIONES      xtl
                   , XX_TCG_LIQUIDACION_LINES  xtll
               WHERE xtl.liquidacion_id = xtll.liquidacion_id)
       WHERE liquidacion_id_parcial = p_liqBParcial_id
         AND cancelado_flag          = 'N'
         AND ((liquidacion_id <> NVL(p_liqBUnica_id,-1) AND liquidado_flag = 'N')
              OR liquidado_flag = 'Y');
    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo la suma de pesos liquidados para la liquidacion id: '
                    || p_liqBParcial_id ||'. '|| SQLERRM;
        RETURN;
    END;

    x_peso := l_peso_liquidado - l_peso_subtotal;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado obteniendo peso disponible para la liquidacion Parcial id: '
                  || p_liqBParcial_id ||'. '||SQLERRM;

  END Get_Peso_Disponible;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible_1116B_bis                                  *
 * Purpose : Rutina que retorna el peso disponible del 1116B parcial para   *
 *           liquidar, teniendo en cuenta las finales no liquidadas         *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Peso_Disponible( p_liqBParcial_id  IN NUMBER
                              , p_liqBUnica_id    IN NUMBER
                              , p_lock_flag       IN BOOLEAN DEFAULT FALSE)
  RETURN NUMBER IS

    l_peso   NUMBER;
    l_result BOOLEAN;
    l_errmsg VARCHAR2(2000);

  BEGIN

    Get_Peso_Disponible( p_liqBParcial_id  => p_liqBParcial_id
                       , p_liqBUnica_id    => p_liqBUnica_id
                       , p_lock_flag       => p_lock_flag
                       , x_peso            => l_peso
                       , x_result          => l_result
                       , x_errmsg          => l_errmsg);

    RETURN NVL(l_peso,0);


  END Get_Peso_Disponible;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible_Fijacion                                   *
 * Purpose : Rutina que retorna el peso disponible para liquidar de una     *
 *           linea de fijacion.                                             *
 *           - p_inc_no_liq: en 'Y' incluye liquidaciones no liquidadas     *
 *                           en 'N' no incluye liquidaciones no liq.        *
 *           - p_liquidacion_id: Id de la liquidacion B en la que estoy     *
 *                               parada                                     *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Peso_Disponible_Fijacion( p_fijacion_precio_id     IN NUMBER
                                        , p_inc_no_liq             IN VARCHAR2 DEFAULT 'N'
                                        , p_liquidacion_id         IN NUMBER
                                        , p_lock_flag              IN BOOLEAN DEFAULT FALSE
                                        , x_peso                  OUT NUMBER
                                        , x_result                OUT BOOLEAN
                                        , x_errmsg                OUT VARCHAR2)
  IS

    l_peso        NUMBER;
    l_contrato_id NUMBER;
    l_peso_temp   NUMBER;

  BEGIN

    x_result := TRUE;

    ----------------------------
    -- Obtengo el peso fijado
    ----------------------------
    BEGIN
      IF (NOT p_lock_flag) THEN
        SELECT peso
             , contrato_id
          INTO l_peso
             , l_contrato_id
          FROM XX_ACO_FIJACION_PRECIOS
         WHERE fijacion_precio_id = p_fijacion_precio_id;
      ELSE
        SELECT peso
             , contrato_id
          INTO l_peso
             , l_contrato_id
          FROM XX_ACO_FIJACION_PRECIOS
         WHERE fijacion_precio_id = p_fijacion_precio_id
           FOR UPDATE NOWAIT;
      END IF;

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo peso fijado para la linea: '||p_fijacion_precio_id
                    ||'. '||SQLERRM;
    END;

    -----------------------------------------
    -- Resto los pesos liquidados en el 1116B
    -----------------------------------------
    BEGIN

      SELECT NVL(SUM(peso_neto_liquidado),0) as peso_liquidado
        INTO l_peso_temp
        FROM (SELECT liquidacion_id
                   , tipo_liquidacion
                   , contrato_id
                   , fijacion_precio_id
                   , liquidado_flag
                   , cancelado_flag
                   , peso_neto_liquidado
                FROM XX_ACO_LIQUIDACIONES_1116B
               UNION
              SELECT liquidacion_id
                   , tipo_liquidacion
                   , contrato_id
                   , fijacion_precio_id
                   , liquidado_flag
                   , cancelado_flag
                   , peso_neto_liquidado
                FROM XX_TCG_LIQUIDACIONES)
       WHERE tipo_liquidacion IN ('UNICA','PARCIAL')
         AND contrato_id                  = l_contrato_id
         AND fijacion_precio_id           = p_fijacion_precio_id
         AND cancelado_flag               = 'N'
         -- Dependiendo del parametro considera o no las liquidaciones liquidadas
         AND (liquidado_flag = 'Y'
             OR (p_inc_no_liq = 'Y'
                 AND liquidacion_id <> NVL(p_liquidacion_id,-1)
                 AND liquidado_flag = 'N'));
    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo peso liquidado para la linea: '||p_fijacion_precio_id ||
                    ' - Liquidacion: ' || p_liquidacion_id || '. '|| SQLERRM;
        RETURN;
    END;


    x_peso := l_peso - l_peso_temp;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error obteniendo peso disponible para la linea de fijacion: '|| SQLERRM;

  END Get_Peso_Disponible_Fijacion;



/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible_Fijacion                                   *
 * Purpose : Rutina que retorna el peso disponible para liquidar de una     *
 *           linea de fijacion.                                             *
 *           - p_inc_no_liq: en 'Y' incluye liquidaciones no liquidadas     *
 *                           en 'N' no incluye liquidaciones no liq.        *
 *           - p_liquidacion_id: Id de la liquidacion B en la que estoy     *
 *                               parado                                     *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Peso_Disponible_Fijacion( p_fijacion_precio_id IN NUMBER
                                       , p_inc_no_liq         IN VARCHAR2 DEFAULT 'N'
                                       , p_liquidacion_id     IN NUMBER
                                       , p_lock_flag          IN BOOLEAN DEFAULT FALSE)
  RETURN NUMBER IS

    C_API_NAME  VARCHAR2(100) := 'Get_Peso_Disponible_Fijacion';
    l_peso      NUMBER;
    l_result    BOOLEAN;
    l_errmsg    VARCHAR2(2000);

  BEGIN

    Get_Peso_Disponible_Fijacion( p_fijacion_precio_id => p_fijacion_precio_id
                                , p_inc_no_liq         => p_inc_no_liq
                                , p_liquidacion_id     => p_liquidacion_id
                                , p_lock_flag          => p_lock_flag
                                , x_peso               => l_peso
                                , x_result             => l_result
                                , x_errmsg             => l_errmsg);

    IF (l_result) THEN
      RETURN NVL(l_peso,0);
    ELSE
      Debug(C_API_NAME, l_errmsg);
      RETURN 0;
    END IF;


  END Get_Peso_Disponible_Fijacion;


/****************************************************************************
 *                                                                          *
 * Name    : Get_Liquidacion                                                *
 * Purpose : Rutina que retorna la informacion referente al 1116B           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Liquidacion( p_liquidacion_id       IN NUMBER
                           , p_revertir             IN BOOLEAN
                           , p_procesamiento        IN VARCHAR DEFAULT 'INTERFACE'
                           , x_liquidacion_rec     OUT liquidacion_rec_type
                           , x_liquidacion_AR_rec  OUT liquidacion_rec_type
                           , x_result              OUT BOOLEAN
                           , x_errmsg              OUT VARCHAR2) IS

    CURSOR c_liquidacion IS
      SELECT xtl.liquidacion_id
           , xtl.organization_id
           , xtpc.operating_unit
           , xtpc.co_code
           , org_information1 set_of_books_id
           , xtl.numero_liquidacion
           , DECODE(xtl.tipo_liquidacion,'UNICA'       ,'Unica'
                                        ,'PARCIAL'     ,'Parcial'
                                        ,'AJUSTE_UNICO','Ajuste Unico'
                                        ) tipo_liquidacion
           , xtl.tipo_comprobante
           , xtl.inventory_item_id
           , xtl.lot_number
           , xc.numero_contrato
           , xc.contrato_id
           , xtl.fecha_liquidacion
           , xtl.ap_term_id
           , xtl.empresa_origen_party_id
           , aps.vendor_id
           , xtl.metodo_pago
           , xtl.procedencia
           , xtl.procedencia_localidad
           , xtl.empresa_destino_party_id
           , xtl.estab_destino_oncca_code
           , xtl.establecimiento_destino_id
           , xtl.provincia_destino_code
           , xtl.localidad_destino_code
           , NVL(xtl.canje_flag, 'N') canje_flag
           , xtl.peso_neto_liquidado
           , ROUND( xtl.precio_oper_conv
                  , FND_PROFILE.VALUE ('XX_ACO_PRECIO_OPER_DEC')) precio_operacion_funcional
           , ROUND( xtl.precio_ref_conv
                  , FND_PROFILE.VALUE ('XX_ACO_PRECIO_REF_DEC')) precio_referencia_funcional
           , xtl.porcentaje_parcial
           , xtl.fijacion_precio_id
           , xtl.canje_contrato_id
           , xde.location_id
           , xtl.liquidado_flag
           , aps.vendor_type_lookup_code
           , xc.order_number
           , ott.name
           , hcsu_bill_to.cust_acct_site_id   customer_bill_address_id
           , hcsu_ship_to.cust_acct_site_id   customer_ship_address_id
           , xtl.ar_term_id
           , xtl.ar_receipt_method_id
           , rtv.name   ar_term_name
           , xtl.pto_emision_liq_aju
           , xtl.nro_orden_liq_aju
           , xtl.fecha_coe_anul
           , xtl.estado_coe
           , xtl.imp_bruto_parcial
           , xtl.importe_a_liquidar
           , xtl.grado
           , xtl.factor_grado
           , xtl.factor_calidad
           , xtl.fc_a_recibir
           , DECODE(xtl.tipo_liquidacion, 'AJUSTE_UNICO'
                                        , DECODE(xtl.peso_diferencia_aju, 0, NULL
                                                                        , NULL, NULL
                                                                        , xtl.peso_diferencia_aju)
                                        , NULL ) peso_diferencia_aju
           , hcsu_bill_to.site_use_id
           , 'N' tax_inclusive_flag
           , DECODE(aps.global_attribute1, '06', 'Y', 'N') depositante_monotributista
        FROM XX_TCG_LIQUIDACIONES  xtl
           , (SELECT contrato_id
                   , numero_contrato
                   , order_number
                   , oe_transaction_type_id
                FROM XX_ACO_CONTRATOS
               UNION
              SELECT contrato_id
                   , numero_contrato
                   , order_number
                   , oe_transaction_type_id
                FROM XX_TCG_CONTRATOS_COMPRA)  xc
           , OE_TRANSACTION_TYPES_TL      ott
           , HZ_CUST_SITE_USES_ALL        hcsu_bill_to
           , HZ_CUST_SITE_USES_ALL        hcsu_ship_to
           , RA_TERMS                     rtv
           , AP_SUPPLIERS                 aps
           , HR_ORGANIZATION_INFORMATION  hoi
           , XX_TCG_PARAMETROS_COMPANIA   xtpc
           , (SELECT establecimiento_id
                   , location_id
                FROM XX_OPM_ESTABLECIMIENTOS
               UNION
              SELECT party_site_id
                   , location_id
                FROM HZ_PARTY_SITES )     xde
       WHERE xtl.liquidacion_id             = p_liquidacion_id
         AND xtl.contrato_id                = xc.contrato_id
         AND xtl.organization_id            = hoi.organization_id
         AND hoi.org_information_context    = 'Accounting Information'
         AND hoi.org_information3           = xtpc.operating_unit
         AND xc.oe_transaction_type_id      = ott.transaction_type_id(+)
         AND xtl.bill_to_site_use_id        = hcsu_bill_to.site_use_id(+)
         AND xtl.ship_to_site_use_id        = hcsu_ship_to.site_use_id(+)
         AND xtl.ar_term_id                 = rtv.term_id(+)
         AND ott.language(+)                = USERENV('LANG')
         AND xtl.empresa_origen_party_id    = aps.party_id
         AND xtl.establecimiento_destino_id = xde.establecimiento_id(+);


    C_API_NAME          VARCHAR2(200) := 'Get_Liquidacion';
    l_result            BOOLEAN;
    l_errmsg            VARCHAR2(2000);
    l_factor            NUMBER;
    l_factor_grado      NUMBER;
    l_flag_cancelado    VARCHAR2(1):= NULL;
    l_query             VARCHAR2(30);
    l_uo_chs            NUMBER;
    l_juego_mapeo       VARCHAR2(250);
    l_es_estblmto       VARCHAR2(1);
--
l_linea number := 0;
l_linea_error varchar2(2000);

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;


    --------------------------------------------------------
    -- Recupero informacion de la cabecera de la liquidacion
    --------------------------------------------------------
    OPEN  c_liquidacion;
    FETCH c_liquidacion INTO x_liquidacion_rec.liquidacion_id
                           , x_liquidacion_rec.organization_id
                           , x_liquidacion_rec.operating_unit
                           , x_liquidacion_rec.co_code
                           , x_liquidacion_rec.set_of_books_id
                           , x_liquidacion_rec.numero_liquidacion
                           , x_liquidacion_rec.tipo_liquidacion
                           , x_liquidacion_rec.tipo_comprobante
                           , x_liquidacion_rec.inventory_item_id
                           , x_liquidacion_rec.lot_number
                           , x_liquidacion_rec.numero_contrato
                           , x_liquidacion_rec.contrato_id
                           , x_liquidacion_rec.fecha_liquidacion
                           , x_liquidacion_rec.term_id
                           , x_liquidacion_rec.empresa_origen_party_id
                           , x_liquidacion_rec.vendor_id
                           , x_liquidacion_rec.metodo_pago
                           , x_liquidacion_rec.procedencia
                           , x_liquidacion_rec.procedencia_localidad
                           , x_liquidacion_rec.empresa_destino_party_id
                           , x_liquidacion_rec.estab_destino_oncca_code
                           , x_liquidacion_rec.establecimiento_destino_id
                           , x_liquidacion_rec.provincia_destino_code
                           , x_liquidacion_rec.localidad_destino_code
                           , x_liquidacion_rec.canje_flag
                           , x_liquidacion_rec.peso_neto_liquidado
                           , x_liquidacion_rec.precio_operacion_funcional
                           , x_liquidacion_rec.precio_referencia_funcional
                           , x_liquidacion_rec.porcentaje_parcial
                           , x_liquidacion_rec.fijacion_precio_id
                           , x_liquidacion_rec.canje_contrato_id
                           , x_liquidacion_rec.ship_to_location
                           , x_liquidacion_rec.liquidado_flag
                           , x_liquidacion_rec.vendor_type_lookup_code
                           , x_liquidacion_rec.order_number
                           , x_liquidacion_rec.oe_order_type
                           , x_liquidacion_rec.customer_bill_address_id
                           , x_liquidacion_rec.customer_ship_address_id
                           , x_liquidacion_rec.ar_term_id
                           , x_liquidacion_rec.ar_receipt_method_id
                           , x_liquidacion_rec.ar_term_name
                           , x_liquidacion_rec.pto_emision_liq_aju
                           , x_liquidacion_rec.nro_orden_liq_aju
                           , x_liquidacion_rec.fecha_coe_anul
                           , x_liquidacion_rec.estado_coe
                           , x_liquidacion_rec.imp_bruto_parcial
                           , x_liquidacion_rec.importe_a_liquidar
                           , x_liquidacion_rec.grado
                           , x_liquidacion_rec.factor_grado
                           , x_liquidacion_rec.factor_calidad
                           , x_liquidacion_rec.fc_a_recibir
                           , x_liquidacion_rec.peso_diferencia_aju
                           , x_liquidacion_rec.site_use_id
                           , x_liquidacion_rec.tax_inclusive_flag
                           , x_liquidacion_rec.depositante_monotributista
                           ;

    CLOSE c_liquidacion;


    IF (x_liquidacion_rec.liquidacion_id IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No se encontraron registros para la liquidacion id: '||
                  p_liquidacion_id ||'.';
      RETURN;
    END IF;


    -- Recupero el valor de compania correspondiente al proveedor de la liquidacion
    IF (x_liquidacion_rec.vendor_type_lookup_code = 'INTERCOMPANY') THEN

      BEGIN

        SELECT co_code
          INTO x_liquidacion_rec.co_code_interco
          FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
             , AP_SUPPLIERS                aps
         WHERE xtpc.vendor_id = aps.vendor_id
           AND aps.party_id   = x_liquidacion_rec.empresa_origen_party_id;

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniendo el segmento compania para el Depositante: '
                      || x_liquidacion_rec.empresa_origen_party_id ||'. ' || SQLERRM;
        RETURN;
      END;

    END IF;


    ----------------------------------------------------------------
    -- Si es una cancelacion y no esta liquidado, no sigo obteniendo
    -- datos
    ----------------------------------------------------------------
    IF (p_revertir AND x_liquidacion_rec.liquidado_flag = 'N') THEN
      RETURN;
    END IF;


    ----------------------
    -- Valido la compania
    ----------------------
    IF (x_liquidacion_rec.co_code IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No fue posible obtener la compania de la liquidacion: '||
                  x_liquidacion_rec.liquidacion_id;
      RETURN;
    END IF;


    ------------------------------
    -- Valido la unidad operativa
    ------------------------------
    IF (x_liquidacion_rec.operating_unit IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No fue posible obtener la unidad operativa de la '||
                  'liquidacion en funcion de la organizacion: '||
                  x_liquidacion_rec.organization_id;
      RETURN;
    END IF;


    -- Agregado CR612 - Revised Jul 2018
    -------------------------------
    -- Valido el Ship_to_location
    -------------------------------
    --IF (x_liquidacion_rec.tipo_liquidacion != 'Parcial') THEN                 CR1237
l_linea := 1;

      SELECT DECODE(count(*), 0, 'N', 'Y')
        INTO l_es_estblmto
        FROM XX_OPM_ESTABLECIMIENTOS
       WHERE establecimiento_id = x_liquidacion_rec.establecimiento_destino_id;


      --IF (l_es_estblmto = 'N') THEN                                           CR1237
      IF (l_es_estblmto = 'N') AND (x_liquidacion_rec.provincia_destino_code IS NOT NULL) THEN

        BEGIN
       l_linea := 2;

          SELECT hl.location_id
            INTO x_liquidacion_rec.ship_to_location
            FROM HR_LOCATIONS_ALL      hl
               , HR_LOCATIONS_ALL1_DFV hld
           WHERE region_2             = x_liquidacion_rec.provincia_destino_code
             AND hl.rowid             = hld.row_id
             AND hld.context_value    = 'AR'
             AND hld.xx_aco_provincia = 'Y';

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'No fue posible obtener el ship to location '||sqlerrm;
            RETURN;
        END;

      END IF;

    --END IF;


    -------------------------------------------
    -- Obtengo el factor resultante del boletin
    -------------------------------------------
    IF (x_liquidacion_rec.tipo_liquidacion IN ('Ajuste Unico', 'Unica')) THEN

      l_factor       := x_liquidacion_rec.factor_calidad;
      l_factor_grado := x_liquidacion_rec.factor_grado;

    END IF;

    x_liquidacion_rec.factor_resultante := (l_factor / 100) * (l_factor_grado / 100);

    IF (p_revertir) THEN
      x_liquidacion_rec.fecha_liquidacion := x_liquidacion_rec.fecha_coe_anul;
    END IF;

    --------------------------------------------------------
    -- Se obtiene los datos de la Sucursal del Depositante
    --------------------------------------------------------
    BEGIN

       l_linea := 3;

      SELECT apss.party_site_id
           , apss.vendor_site_id
           , apss.accts_pay_code_combination_id
        INTO x_liquidacion_rec.origen_party_site_id
           , x_liquidacion_rec.vendor_site_id
           , x_liquidacion_rec.acct_pay_code_combination_id
        FROM AP_SUPPLIER_SITES_ALL apss
       WHERE vendor_id                      = x_liquidacion_rec.vendor_id
         AND apss.global_attribute_category = 'JL.AR.APXVDMVD.SUPPLIER_SITES'
         AND apss.global_attribute17        = 'Y'
         AND apss.org_id                    = x_liquidacion_rec.operating_unit;


    EXCEPTION
      WHEN too_many_rows THEN
        x_result := FALSE;
        x_errmsg := 'Existe mas de una sucursal de cliente configurada como domicilio fiscal para la '
                    ||'Unidad Operativa: '||x_liquidacion_rec.operating_unit;
        RETURN;
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible obtener los datos de la sucursal de cliente configurada '
                    ||'como domicilio fiscal. '||sqlerrm;
        RETURN;
    END;

    -----------------------
    -- Unidad Productiva
    -----------------------
    BEGIN

       l_linea := 4;

      l_query := 'CHS';

      SELECT organization_id
        INTO l_uo_chs
        FROM HR_OPERATING_UNITS
       WHERE 1=1
       --AND name = 'AR CHS UO'  TK1485
       AND organization_id = 1357
       ;

      l_query := 'Juego Mapeo';

       l_linea := 5;

      SELECT pfm.juego_mapeo
        INTO l_juego_mapeo
        FROM (SELECT lookup_code    codigo
                   , meaning        juego_mapeo
                   , DECODE(INSTR(meaning, 'CHS'), 0, NULL, l_uo_chs) oper_unit
                FROM FND_LOOKUP_VALUES
               WHERE lookup_type  = 'XX_TCG_PROVISION_FLETE_MAPPING'
                 AND language     = 'ESA'
                 AND enabled_flag = 'Y')  pfm
       WHERE pfm.codigo LIKE 'U_PRODUCTIVA%'
         AND ((l_uo_chs = x_liquidacion_rec.operating_unit
               AND pfm.oper_unit = x_liquidacion_rec.operating_unit)
              OR
             (l_uo_chs  != x_liquidacion_rec.operating_unit
               AND pfm.oper_unit IS NULL));

      l_query := 'Unidad Productiva';

       l_linea := 6;

      SELECT value_constant
        INTO x_liquidacion_rec.unidad_productiva
        FROM XLA_MAPPING_SET_VALUES
       WHERE mapping_set_code = l_juego_mapeo
         AND amb_context_code = 'DEFAULT'
         AND input_value_constant = x_liquidacion_rec.organization_id;


    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;

        IF (l_query = 'CHS') THEN
          x_errmsg := 'Error al determinar la Unidad Operativa de CHS. '||SQLERRM;
        ELSIF (l_query = 'Juego Mapeo') THEN
          x_errmsg := 'Error al determinar el Juego de Mapeo correspondiente. '||SQLERRM;
        ELSIF (l_query = 'Unidad Productiva') THEN
          x_errmsg := 'Error al determinar la Unidad Productiva '||SQLERRM;
        END IF;
        RETURN;

    END;

    --------------------
    -- Moneda Funcional
    --------------------
    BEGIN

       l_linea := 7;

      SELECT gl.currency_code
        INTO x_liquidacion_rec.currency_code
        FROM ORG_ORGANIZATION_DEFINITIONS ood
           , GL_LEDGERS                   gl
       WHERE ood.organization_id = x_liquidacion_rec.organization_id
         AND ood.set_of_books_id = gl.ledger_id;

    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;
        x_errmsg := 'Error al obtener la moneda funcional. '||sqlerrm;
        RETURN;
    END;

    ----------------------------------------------------------------------
    --
    -- Obtengo las lineas de la factura en funcion del tipo de liquidacion
    --
    ----------------------------------------------------------------------

    IF (UPPER(x_liquidacion_rec.tipo_liquidacion) = 'UNICA') THEN
        --------------------------------------------
        -- En la factura se debe incluir:
        --       _ La linea de granos liquidados (+)
        --       _ Iva por los granos            (+)
        --------------------------------------------

        ---------------------------------------------
        -- Obtengo la linea por los granos liquidados
        ---------------------------------------------

      IF (p_revertir = TRUE) THEN
        l_flag_cancelado := 'Y';
      ELSE
        l_flag_cancelado := 'N';
      END IF;

       l_linea := 8;

      Get_Lineas_Factura_Grano_Unica ( p_liquidacion_rec  => x_liquidacion_rec
                                     , p_flag_cancelado   => l_flag_cancelado
                                     , x_result           => l_result
                                     , x_errmsg           => l_errmsg);


      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo detalles de la linea del producto: '|| l_errmsg;
        RETURN;
      END IF;

      x_liquidacion_AR_rec.liquidacion_id               := x_liquidacion_rec.liquidacion_id;
      x_liquidacion_AR_rec.organization_id              := x_liquidacion_rec.organization_id;
      x_liquidacion_AR_rec.operating_unit               := x_liquidacion_rec.operating_unit;
      x_liquidacion_AR_rec.co_code                      := x_liquidacion_rec.co_code;
      x_liquidacion_AR_rec.set_of_books_id              := x_liquidacion_rec.set_of_books_id;
      x_liquidacion_AR_rec.numero_liquidacion           := x_liquidacion_rec.numero_liquidacion;
      x_liquidacion_AR_rec.tipo_liquidacion             := x_liquidacion_rec.tipo_liquidacion;
      x_liquidacion_AR_rec.tipo_comprobante             := x_liquidacion_rec.tipo_comprobante;
      x_liquidacion_AR_rec.inventory_item_id            := x_liquidacion_rec.inventory_item_id;
      x_liquidacion_AR_rec.lot_number                   := x_liquidacion_rec.lot_number;
      x_liquidacion_AR_rec.numero_contrato              := x_liquidacion_rec.numero_contrato;
      x_liquidacion_AR_rec.contrato_id                  := x_liquidacion_rec.contrato_id;
      x_liquidacion_AR_rec.fecha_liquidacion            := x_liquidacion_rec.fecha_liquidacion;
      x_liquidacion_AR_rec.term_id                      := x_liquidacion_rec.term_id;
      x_liquidacion_AR_rec.empresa_origen_party_id      := x_liquidacion_rec.empresa_origen_party_id;
      x_liquidacion_AR_rec.vendor_id                    := x_liquidacion_rec.vendor_id;
      x_liquidacion_AR_rec.metodo_pago                  := x_liquidacion_rec.metodo_pago;
      x_liquidacion_AR_rec.procedencia                  := x_liquidacion_rec.procedencia;
      x_liquidacion_AR_rec.procedencia_localidad        := x_liquidacion_rec.procedencia_localidad;
      x_liquidacion_AR_rec.empresa_destino_party_id     := x_liquidacion_rec.empresa_destino_party_id;
      x_liquidacion_AR_rec.estab_destino_oncca_code     := x_liquidacion_rec.estab_destino_oncca_code;
      x_liquidacion_AR_rec.establecimiento_destino_id   := x_liquidacion_rec.establecimiento_destino_id;
      x_liquidacion_AR_rec.provincia_destino_code       := x_liquidacion_rec.provincia_destino_code;
      x_liquidacion_AR_rec.localidad_destino_code       := x_liquidacion_rec.localidad_destino_code;
      x_liquidacion_AR_rec.canje_flag                   := x_liquidacion_rec.canje_flag;
      x_liquidacion_AR_rec.peso_neto_liquidado          := x_liquidacion_rec.peso_neto_liquidado;
      x_liquidacion_AR_rec.precio_operacion_funcional   := x_liquidacion_rec.precio_operacion_funcional;
      x_liquidacion_AR_rec.precio_referencia_funcional  := x_liquidacion_rec.precio_referencia_funcional;
      x_liquidacion_AR_rec.porcentaje_parcial           := x_liquidacion_rec.porcentaje_parcial;
      x_liquidacion_AR_rec.fijacion_precio_id           := x_liquidacion_rec.fijacion_precio_id;
      x_liquidacion_AR_rec.canje_contrato_id            := x_liquidacion_rec.canje_contrato_id;
      x_liquidacion_AR_rec.ship_to_location             := x_liquidacion_rec.ship_to_location;
      x_liquidacion_AR_rec.liquidado_flag               := x_liquidacion_rec.liquidado_flag;
      x_liquidacion_AR_rec.vendor_type_lookup_code      := x_liquidacion_rec.vendor_type_lookup_code;
      x_liquidacion_AR_rec.order_number                 := x_liquidacion_rec.order_number;
      x_liquidacion_AR_rec.oe_order_type                := x_liquidacion_rec.oe_order_type;
      x_liquidacion_AR_rec.customer_bill_address_id     := x_liquidacion_rec.customer_bill_address_id;
      x_liquidacion_AR_rec.customer_ship_address_id     := x_liquidacion_rec.customer_ship_address_id;
      x_liquidacion_AR_rec.ar_term_id                   := x_liquidacion_rec.ar_term_id;
      x_liquidacion_AR_rec.ar_receipt_method_id         := x_liquidacion_rec.ar_receipt_method_id;
      x_liquidacion_AR_rec.ar_term_name                 := x_liquidacion_rec.ar_term_name;
      x_liquidacion_AR_rec.pto_emision_liq_aju          := x_liquidacion_rec.pto_emision_liq_aju;
      x_liquidacion_AR_rec.nro_orden_liq_aju            := x_liquidacion_rec.nro_orden_liq_aju;
      x_liquidacion_AR_rec.fecha_coe_anul               := x_liquidacion_rec.fecha_coe_anul;
      x_liquidacion_AR_rec.estado_coe                   := x_liquidacion_rec.estado_coe;
      x_liquidacion_AR_rec.imp_bruto_parcial            := x_liquidacion_rec.imp_bruto_parcial;
      x_liquidacion_AR_rec.importe_a_liquidar           := x_liquidacion_rec.importe_a_liquidar;
      x_liquidacion_AR_rec.grado                        := x_liquidacion_rec.grado;
      x_liquidacion_AR_rec.factor_grado                 := x_liquidacion_rec.factor_grado;
      x_liquidacion_AR_rec.factor_calidad               := x_liquidacion_rec.factor_calidad;
      x_liquidacion_AR_rec.fc_a_recibir                 := x_liquidacion_rec.fc_a_recibir;
      x_liquidacion_AR_rec.peso_diferencia_aju          := x_liquidacion_rec.peso_diferencia_aju;
      x_liquidacion_AR_rec.site_use_id                  := x_liquidacion_rec.site_use_id;
      x_liquidacion_AR_rec.currency_code                := x_liquidacion_rec.currency_code;
      x_liquidacion_AR_rec.tax_inclusive_flag           := x_liquidacion_rec.tax_inclusive_flag ;
      x_liquidacion_AR_rec.depositante_monotributista   := x_liquidacion_rec.depositante_monotributista;


      Get_Lineas_Factura_Grano( p_liquidacion_rec => x_liquidacion_AR_rec
                              , x_result          => l_result
                              , x_errmsg          => l_errmsg);

       l_linea := 9;


      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo detalles de la linea del producto - AR: '|| l_errmsg;
        RETURN;
      END IF;


    ELSIF (UPPER(x_liquidacion_rec.tipo_liquidacion) = 'PARCIAL') THEN

      --------------------------------------------
      -- En la factura se debe incluir:
      --       _ La linea de granos liquidados (+)
      --       _ Iva por los granos            (+)
      --       _ Pendiente de Liquidacion      (-)
      --------------------------------------------

      ---------------------------------------------
      -- Obtengo la linea por los granos liquidados
      ---------------------------------------------
      Get_Lineas_Factura_Grano( p_liquidacion_rec => x_liquidacion_rec
                              , x_result          => l_result
                              , x_errmsg          => l_errmsg);

      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo detalles de la linea del producto: '|| l_errmsg;
        RETURN;
      END IF;

       l_linea := 10;


      ------------------------------------------
      -- Obtengo la linea por pendiente de final
      ------------------------------------------
      Get_Linea_Factura_Pend_Final( p_liquidacion_rec => x_liquidacion_rec
                                  , x_result          => l_result
                                  , x_errmsg          => l_errmsg);

      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo detalles de las linea por el pendiente '||
                    'de liquidacion: '|| l_errmsg;
        RETURN;
      END IF;

    ELSE
      --------------------------------------------
      -- En la factura se debe incluir:
      --       _ Pendiente de Liquidacion      (+)
      --       _ Descuento por Calidad         (+)
      --       _ Bonificacion por Calidad      (+)
      --------------------------------------------
      Get_Lineas_Factura_Final( p_liquidacion_rec => x_liquidacion_rec
                              , x_result          => l_result
                              , x_errmsg          => l_errmsg);

      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo detalles de las linea por el pendiente '||
                    'de liquidacion: '|| l_errmsg;
        RETURN;
      END IF;

    END IF;


       l_linea := 11;
    --------------------------------------------------------
    -- Recorro las lineas y para obtener el total a liquidar
    --------------------------------------------------------
    x_liquidacion_rec.monto := 0;

    debug(C_API_NAME,'Cantidad de lineas: '|| x_liquidacion_rec.lineas.COUNT||' para liq '||x_liquidacion_rec.liquidacion_id);

    FOR l_index IN 1 .. x_liquidacion_rec.lineas.COUNT LOOP

      ------------------------------------------------------------
      -- Si estoy generando una nota de credito, revierto el signo
      ------------------------------------------------------------
      IF (p_revertir) THEN

        x_liquidacion_rec.lineas(l_index).amount := ROUND(x_liquidacion_rec.lineas(l_index).amount,2) * -1;

      END IF;

      x_liquidacion_rec.monto  := x_liquidacion_rec.monto + ROUND(x_liquidacion_rec.lineas(l_index).amount,2);

      Debug(C_API_NAME, 'Linea: '              ||l_index
                        ||' - ccid: '          ||x_liquidacion_rec.lineas(l_index).code_combination_id
                        ||' - line_type_code: '||x_liquidacion_rec.lineas(l_index).line_type_code
                        ||' - tipo_linea: '    ||x_liquidacion_rec.lineas(l_index).tipo_linea
                        ||' - carta_porte_id: '||x_liquidacion_rec.lineas(l_index).carta_porte_id);
    END LOOP;

    debug(C_API_NAME, 'Cantidad de lineas de AR: '|| x_liquidacion_AR_rec.lineas.COUNT
                      ||' para liq '||x_liquidacion_rec.liquidacion_id);

    x_liquidacion_AR_rec.monto := 0;

    FOR l_index IN 1 .. x_liquidacion_AR_rec.lineas.COUNT LOOP

       l_linea := 12;


      ------------------------------------------------------------
      -- Si estoy generando una nota de credito, revierto el signo
      ------------------------------------------------------------
      IF (p_revertir) THEN
       l_linea := 13;
        x_liquidacion_AR_rec.lineas(l_index).amount := ROUND(x_liquidacion_AR_rec.lineas(l_index).amount,2) * -1;
      END IF;

       l_linea := 14;
      x_liquidacion_AR_rec.monto := x_liquidacion_AR_rec.monto + ROUND(x_liquidacion_AR_rec.lineas(l_index).amount,2);
       l_linea := 141;

  Debug(C_API_NAME,'Linea: '              ||l_index
                      ||' - ccid: '          || x_liquidacion_AR_rec.lineas(l_index).code_combination_id
                       ||' - line_type_code: '||x_liquidacion_AR_rec.lineas(l_index).line_type_code
                       ||' - tipo_linea: '    ||x_liquidacion_AR_rec.lineas(l_index).tipo_linea
                       ||' - carta_porte_id: '||x_liquidacion_AR_rec.lineas(l_index).carta_porte_id);

         l_linea := 142;



    END LOOP;

       l_linea := 15;
    -------------------------------------------
    -- Si no tengo lineas falla la recuperacion
    -------------------------------------------
    IF (x_liquidacion_rec.lineas.COUNT = 0)
      AND (x_liquidacion_AR_rec.lineas.COUNT = 0) THEN

      x_result := FALSE;
      x_errmsg := 'No se encontraron lineas a liquidar.';

    END IF;

       l_linea := 16;

    IF (x_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico')
      AND (x_liquidacion_rec.peso_diferencia_aju IS NOT NULL) THEN

      BEGIN
        SELECT xtl.precio_oper_conv
          INTO x_liquidacion_rec.pr_op_diferencia_aju
          FROM (SELECT liquidacion_id
                     , tipo_liquidacion
                     , precio_oper_conv
                  FROM XX_ACO_LIQUIDACIONES_1116B
                 UNION
                SELECT liquidacion_id
                     , tipo_liquidacion
                     , precio_oper_conv
                  FROM XX_TCG_LIQUIDACIONES) xtl
             , XX_TCG_LIQUIDACION_LINES      xtll
             , XX_TCG_LIQUIDACIONES          xtau
         WHERE xtl.tipo_liquidacion     = 'PARCIAL'
           AND xtl.liquidacion_id       = xtll.liquidacion_id_parcial
           AND xtll.liquidacion_id      = xtau.liquidacion_id
           AND xtll.liquidacion_id      = x_liquidacion_rec.liquidacion_id
           AND xtll.liquidacion_line_id = (SELECT MAX(xtll2.liquidacion_line_id)
                                             FROM XX_TCG_LIQUIDACION_LINES xtll2
                                            WHERE xtll2.liquidacion_id = xtll.liquidacion_id);

      EXCEPTION
        WHEN no_data_found THEN
          x_liquidacion_rec.pr_op_diferencia_aju := NULL;
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error inesperado al buscar el precio de operación de la ultima'||
                      'liquidacion parcial asociada: '|| SQLERRM;
      END;

    END IF;


  EXCEPTION
    WHEN others THEN
      IF (c_liquidacion%ISOPEN) THEN
        CLOSE c_liquidacion;
      END IF;

      x_result := FALSE;
      x_errmsg :=    l_linea||'-'||'Error inesperado obteniendo informacion de la liquidacion: '|| SQLERRM;

  END Get_Liquidacion;



/********************************************************************************
 *                                                                              *
 * Name    : Get_Lineas_Factura_Grano_unica                                     *
 * Purpose : Calcula y recupera la lineas de facturacion de granos(solo unicas) *
 *                                                                              *
 *******************************************************************************/
  PROCEDURE Get_Lineas_Factura_Grano_Unica( p_liquidacion_rec  IN OUT NOCOPY liquidacion_rec_type
                                          , p_flag_cancelado   IN VARCHAR2
                                          , x_result          OUT BOOLEAN
                                          , x_errmsg          OUT VARCHAR2)
  IS

    CURSOR lineas_sin_cancelar IS
      SELECT xtcp.liquidacion_id
           , xtl.inventory_item_id
           , xcp.numero_carta_porte
           , xtcp.cantidad_a_liquidar        peso_neto_liquidado
           , xcp.carta_porte_id
           , xcp.procedencia_origen
           , xcp.pagador_flete_id            --Agregado CR612 Revised Jul 2018
        FROM XX_TCG_LIQUIDACIONES            xtl
           , XX_TCG_CARTAS_PORTE_LIQUIDADAS  xtcp
           , (SELECT carta_porte_id
                   , numero_carta_porte
                   , procedencia_origen
                   , hca.party_id          pagador_flete_id
                FROM XX_ACO_CARTAS_PORTE_B xcpb
                   , HZ_CUST_ACCOUNTS      hca
               WHERE xcpb.pagador_flete_id = hca.cust_account_id
               UNION
              SELECT carta_porte_id
                   , numero_carta_porte
                   , titular_cp_provincia
                   , pagador_flete_id
                FROM XX_TCG_CARTAS_PORTE_ALL )  xcp
        WHERE 1=1
          AND xtl.liquidacion_id             = xtcp.liquidacion_id
          AND xtcp.carta_porte_id            = xcp.carta_porte_id
          AND xtl.liquidacion_id             = p_liquidacion_rec.liquidacion_id
          AND xtcp.cantidad_a_liquidar       <> 0
        ORDER BY xtcp.cantidad_a_liquidar;

    C_API_NAME     VARCHAR2(40) := 'Get_Lineas_Factura_Grano_Unica';
    l_current_line NUMBER;
    l_tax_code     mtl_system_items_b.purchasing_tax_code%TYPE;
    l_result       BOOLEAN;
    l_errmsg       VARCHAR2(2000);

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    -- Empiezo a recorrer las lineas de carta de porte que se van
    -- a insertar en la distribucion de la factura
    FOR cur IN lineas_sin_cancelar LOOP

      x_result := TRUE;

      l_current_line := p_liquidacion_rec.lineas.COUNT + 1;


      -------------------
      -- Tipo de la linea
      -------------------
      p_liquidacion_rec.lineas(l_current_line).line_type_code := 'ITEM';
      p_liquidacion_rec.lineas(l_current_line).tipo_linea     := 'ITEM';

      -- Datos solamente para unicas
      p_liquidacion_rec.lineas(l_current_line).carta_de_porte    := cur.numero_carta_porte;
      p_liquidacion_rec.lineas(l_current_line).carta_porte_id    := cur.carta_porte_id;
      --p_liquidacion_rec.lineas(l_current_line).origen_produccion := cur.procedencia_origen;   Mod CR612 Revised Jul 2018

      -- Agregado CR1727
      IF (cur.pagador_flete_id IS NULL) THEN
        x_result := FALSE;
        x_errmsg := 'La CP '||cur.carta_porte_id||' no tiene configurado el pagador flete. Por favor, revisar.';
        RETURN;
      END IF;
      --fin CR1727

      --IF (cur.pagador_flete_id = p_liquidacion_rec.empresa_destino_party_id) THEN
      IF cur.pagador_flete_id = XX_TCG_FUNCTIONS_PKG.CUIT_Party_ID( XX_TCG_FUNCTIONS_PKG.Operating_Unit_CUIT ( p_liquidacion_rec.operating_unit), 'AR' ) THEN
        p_liquidacion_rec.lineas(l_current_line).origen_produccion := cur.procedencia_origen;
      ELSE
        p_liquidacion_rec.lineas(l_current_line).origen_produccion := p_liquidacion_rec.provincia_destino_code;
      END IF;
      -- Fin CR612 Revised

      --------------------------------------
      -- Obtengo la descripcion del articulo
      --------------------------------------
      BEGIN
        SELECT SUBSTR(description,1,240)
          INTO p_liquidacion_rec.lineas(l_current_line).description
          FROM MTL_SYSTEM_ITEMS_B
         WHERE inventory_item_id = p_liquidacion_rec.inventory_item_id
           AND organization_id   = p_liquidacion_rec.organization_id;
      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniendo descripcion del articulo id: '
                      ||p_liquidacion_rec.inventory_item_id;
          RETURN;
      END;

      -------------------------------
      -- Obtengo el monto de la linea
      -------------------------------
      p_liquidacion_rec.lineas(l_current_line).amount := ROUND(p_liquidacion_rec.precio_operacion_funcional *
                                                               cur.peso_neto_liquidado,   -- es el valor de la cantidad a liquidar de la tabla
                                                               FND_PROFILE.value('XX_ACO_PRECIO_OPER_DEC'));


      ------------------------------------------
      -- Combinacion contable Provisión Factura
      -----------------------------------------
      BEGIN
        SELECT provision_factura_account_id
          INTO p_liquidacion_rec.lineas(l_current_line).code_combination_id
          FROM XX_TCG_PARAMETROS_COMPANIA
         WHERE operating_unit = p_liquidacion_rec.operating_unit;

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniendo la combinacion contable para la linea de '
                      ||'la factura correspondiente a la compra de granos: '
                      ||SQLERRM;
        RETURN;
      END;


      -- Logica que asigna el valor NO RETIENE en el attribute2, para las
      -- transacciones de canje.
      IF NVL(p_liquidacion_rec.canje_flag,'N') = 'Y' THEN
        p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';
      END IF;


      -- Si es una operacion de monotributo el codigo de impuesto se obtiene del DFF
      -- vat_code de la lookup custom 'XX_ACO_DOC_ONCCA' y no se genera linea de impuesto.
      IF (NVL(p_liquidacion_rec.monotributista,'N') = 'N') THEN

        -----------------------------------------------
        --
        -- Genero la linea de impuestos correspondiente
        --
        -----------------------------------------------
        BEGIN
          SELECT purchasing_tax_code
            INTO l_tax_code
            FROM MTL_SYSTEM_ITEMS_B msi
           WHERE msi.inventory_item_id  = p_liquidacion_rec.inventory_item_id
             --AND msi.organization_id     = p_liquidacion_rec.organization_id;
             AND msi.organization_id    = XX_TCG_UTIL_PKG.master_item_org_id;

          IF (l_tax_code IS NULL) THEN
            x_result := FALSE;
            x_errmsg := 'No se encontro codigo de impuesto para el articulo con id: '
                        ||p_liquidacion_rec.inventory_item_id
                        ||' y la organizacion Master: '||XX_TCG_UTIL_PKG.master_item_org_id;
            RETURN;
          END IF;

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Se produjo un error inesperado al intentar obtener el codigo de impuesto '
                        ||'aplicable al articulo con id: '||p_liquidacion_rec.inventory_item_id
                        ||'. '|| SQLERRM;
            RETURN;
        END;

        -------------------------------
        -- Asigno el codigo de impuesto
        -------------------------------
        p_liquidacion_rec.lineas(l_current_line).tax_code                := l_tax_code;
        p_liquidacion_rec.lineas(l_current_line).tax_classification_code := l_tax_code;
        p_liquidacion_rec.lineas(l_current_line).line_group_number       := l_current_line;

        Generar_Linea_Impuesto_AP( p_liquidacion_rec     => p_liquidacion_rec
                                 , p_linea_base          => l_current_line
                                 , p_tax_code            => l_tax_code
                                 , p_legal_trx_category  => NULL
                                 , x_result              => l_result
                                 , x_errmsg              => l_errmsg);


        IF (NOT l_result) THEN
          x_result := FALSE;
          x_errmsg := 'No fue posible generar las lineas por la compra del grano: '|| l_errmsg;
          RETURN;
        END IF;

      ELSE -- monotributo por el no solo genero linea de item.

        -------------------------------
        -- Asigno el codigo de impuesto
        ------------------------------
        p_liquidacion_rec.lineas(l_current_line).tax_code :=p_liquidacion_rec.vat_code;

      END IF; -- monotributo


    END LOOP;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado generando lineas de la factura por la compra de granos '
                 ||'de liquidacion Unica: '|| SQLERRM;

  END Get_Lineas_Factura_Grano_Unica;




 /****************************************************************************
 *                                                                          *
 * Name    : Generar_Linea_Impuesto_AP                                      *
 * Purpose : En funcion de una linea base, genera una linea de impuestos    *
 *           para la factura de AP.                                         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Linea_Impuesto_AP( p_liquidacion_rec     IN OUT NOCOPY liquidacion_rec_type
                                     , p_linea_base          IN NUMBER
                                     , p_tax_code            IN VARCHAR2
                                     , p_legal_trx_category  IN VARCHAR2 DEFAULT NULL
                                     , x_result             OUT BOOLEAN
                                     , x_errmsg             OUT VARCHAR2)
  IS

    C_API_NAME        VARCHAR2(40) := 'Generar_Linea_Impuesto_AP';
    l_description     ZX_RATES_B.tax_rate_code%TYPE;
    l_tax_rate        AR_VAT_TAX_ALL_B.tax_rate%TYPE;
    l_tax_rate_id     NUMBER;
    l_tax_regime_code VARCHAR2(30);
    l_current_line    NUMBER;
    l_conc_segments   VARCHAR2(240);

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    -----------------------------------
    -- Obtengo informacion del impuesto
    -----------------------------------
    BEGIN

      SELECT zrb.tax_rate_code
           , avt.tax_rate
           , zrb.tax_rate_id
           , zrb.tax_regime_code
           , gcc.concatenated_segments
        INTO l_description
           , l_tax_rate
           , l_tax_rate_id
           , l_tax_regime_code
           , l_conc_segments
        FROM AR_VAT_TAX_ALL_B          avt
           , AR_VAT_TAX_ALL_B_DFV      avtd
           , ZX_RATES_B                zrb
           , ZX_RATES_B_DFV            zrbd
           , ZX_PARTY_TAX_PROFILE      zptp
           , ZX_TAXES_B                ztb
           , ZX_ACCOUNTS               za
           , GL_CODE_COMBINATIONS_KFV  gcc
       WHERE 1=1
         AND avt.rowid                    = avtd.row_id
         AND zrb.rowid                    = zrbd.row_id
         AND avtd.xx_cod_imp_nd           = zrbd.xx_cod_imp_nd
         AND zrb.content_owner_id         = zptp.party_tax_profile_id
         AND zrb.tax                      = ztb.tax
         AND zrb.tax_regime_code          = ztb.tax_regime_code
         AND zrb.content_owner_id         = ztb.content_owner_id
         AND zrb.tax_rate_id              = za.tax_account_entity_id
         AND za.internal_organization_id  = zptp.party_id
         AND za.tax_account_ccid          = gcc.code_combination_id
         AND zrb.tax_rate_code            = p_tax_code
         AND set_of_books_id              = p_liquidacion_rec.set_of_books_id
         AND zptp.party_id                = p_liquidacion_rec.operating_unit;

      IF (l_tax_rate IS NULL) THEN

        x_result := FALSE;
        x_errmsg := 'Se esperaba encontrar un rate para el codigo de impuesto: '
                    || p_tax_code || ' cuando se estaba generando una linea de impuesto '
                    ||'para la factura.';
        RETURN;
      END IF;

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Se produjo un error inesperado al intentar obtener informacion del impuesto: '
                    || p_tax_code ||' cuendo se estaba generando una linea de impuesto para la '
                    ||'factura: '|| SQLERRM;
        RETURN;
    END;

    --------------------------------------------
    -- No genero la linea si el impuesto es cero
    --------------------------------------------
    IF (l_tax_rate = 0) THEN
      IF (p_tax_code != 'IVA 0% Exento') THEN
        RETURN;
      ELSE --Agregado CR1237
        l_current_line                                                   := p_liquidacion_rec.lineas.COUNT + 1;
        p_liquidacion_rec.lineas(l_current_line).line_type_code          := 'TAX';
        p_liquidacion_rec.lineas(l_current_line).amount                  := 0;
        p_liquidacion_rec.lineas(l_current_line).description             := 'Imp. al Valor Agregado 0%';
        p_liquidacion_rec.lineas(l_current_line).tax_classification_code := p_tax_code;
        p_liquidacion_rec.lineas(l_current_line).tax_code                := p_tax_code;  -- Agregado CR1423
        p_liquidacion_rec.lineas(l_current_line).tax_rate_id             := l_tax_rate_id ;
        p_liquidacion_rec.lineas(l_current_line).line_group_number       := p_linea_base;
        p_liquidacion_rec.lineas(l_current_line).prorate_across_flag     := 'Y';
        RETURN;
      END IF;
    END IF;

    -----------------------------
    -- Finalmente genero la linea
    -----------------------------
    l_current_line := p_liquidacion_rec.lineas.COUNT + 1;

    p_liquidacion_rec.lineas(l_current_line).line_type_code        := 'TAX';
    p_liquidacion_rec.lineas(l_current_line).description           := SUBSTR(l_description
                                                                      || ' ('
                                                                      ||p_liquidacion_rec.lineas(p_linea_base).description
                                                                      ||')', 1, 240);
    p_liquidacion_rec.lineas(l_current_line).tax_code              := p_tax_code;
    p_liquidacion_rec.lineas(l_current_line).line_group_number     := p_linea_base;
    p_liquidacion_rec.lineas(l_current_line).prorate_across_flag   := 'Y';
    p_liquidacion_rec.lineas(l_current_line).tax_rate_id           := l_tax_rate_id;
--    p_liquidacion_rec.lineas(l_current_line).concatenated_segments := l_conc_segments;
    p_liquidacion_rec.lineas(l_current_line).tax_classification_code := p_tax_code; -- Agregado CR612 Revised jul 2018



    -- Logica que asigna el valor NO RETIENE en el attribute2, para las
    -- transacciones de canje.
    IF (NVL(p_liquidacion_rec.canje_flag,'N') = 'Y') THEN

      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';

    ELSIF (p_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico')  THEN

      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := p_liquidacion_rec.lineas(p_linea_base).legal_trx_category;

    ELSE

      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := p_legal_trx_category;

    END IF;


    IF (UPPER(p_liquidacion_rec.tipo_liquidacion) = 'UNICA') THEN

      p_liquidacion_rec.lineas(l_current_line).carta_de_porte    := p_liquidacion_rec.lineas(p_linea_base).carta_de_porte;
      p_liquidacion_rec.lineas(l_current_line).carta_porte_id    := p_liquidacion_rec.lineas(p_linea_base).carta_porte_id;
      p_liquidacion_rec.lineas(l_current_line).origen_produccion := p_liquidacion_rec.lineas(p_linea_base).origen_produccion;

    END IF;


    p_liquidacion_rec.lineas(l_current_line).amount := ROUND(p_liquidacion_rec.lineas(p_linea_base).amount *
                                                             l_tax_rate / 100,
                                                             FND_PROFILE.value('XX_ACO_PRECIO_OPER_DEC'));

    IF (p_liquidacion_rec.lineas(l_current_line-1).tipo_linea = 'SERVICIOS') THEN
      p_liquidacion_rec.lineas(l_current_line).tipo_linea := 'SERV_TAX';
    END IF;


  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Se produjo un error inesperado al intentar generar una linea de impuesto para factura: '|| SQLERRM;

  END Generar_Linea_Impuesto_AP;



 /****************************************************************************
 *                                                                          *
 * Name    : Get_Lineas_Factura_Grano                                       *
 * Purpose : Calcula y recupera la lineas de facturacion de granos.         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Lineas_Factura_Grano( p_liquidacion_rec   IN OUT NOCOPY liquidacion_rec_type
                                    , x_result            OUT BOOLEAN
                                    , x_errmsg            OUT VARCHAR2)
  IS

    C_API_NAME      VARCHAR2(40) := 'Get_Lineas_Factura_Grano';
    l_current_line  NUMBER;
    l_tax_code      MTL_SYSTEM_ITEMS_B.purchasing_tax_code%TYPE;
    l_result        BOOLEAN;
    l_errmsg        VARCHAR2(2000);

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    l_current_line := p_liquidacion_rec.lineas.COUNT + 1;


    -------------------
    -- Tipo de la linea
    -------------------
    p_liquidacion_rec.lineas(l_current_line).line_type_code := 'ITEM';
    p_liquidacion_rec.lineas(l_current_line).tipo_linea     := 'ITEM';


    --------------------------------------
    -- Obtengo la descripcion del articulo
    --------------------------------------
    BEGIN
      SELECT SUBSTR(description,1,240)
        INTO p_liquidacion_rec.lineas(l_current_line).description
        FROM MTL_SYSTEM_ITEMS_B
       WHERE inventory_item_id = p_liquidacion_rec.inventory_item_id
         AND organization_id   = p_liquidacion_rec.organization_id;
    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo descripcion del articulo id: '||p_liquidacion_rec.inventory_item_id
                    ||'. No fue posible generar la linea de facturacion por los granos liquidados.';
        RETURN;
    END;

    -------------------------------
    -- Obtengo el monto de la linea
    -------------------------------
    IF (p_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico') THEN

      p_liquidacion_rec.lineas(l_current_line).amount := p_liquidacion_rec.fc_a_recibir;

    ELSE

      p_liquidacion_rec.lineas(l_current_line).amount := ROUND( p_liquidacion_rec.precio_operacion_funcional *
                                                                p_liquidacion_rec.peso_neto_liquidado
                                                              , FND_PROFILE.value('XX_ACO_PRECIO_OPER_DEC'));
    END IF;


    ----------------------------------------------------
    -- Combinacion contable de la Provisión de Factura
    ----------------------------------------------------
    BEGIN
      SELECT provision_factura_account_id
        INTO p_liquidacion_rec.lineas(l_current_line).code_combination_id
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_liquidacion_rec.operating_unit;
    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo la combinacion contable para la linea de '
                    ||'la factura correspondiente a la compra de granos: '
                    ||SQLERRM;
      RETURN;
    END;



    -- Logica que asigna el valor NO RETIENE en el attribute2, para las
    -- transacciones de canje.
    IF (NVL(p_liquidacion_rec.canje_flag,'N') = 'Y') THEN

      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';

    ELSIF (p_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico') AND
       (p_liquidacion_rec.lineas(l_current_line).amount <0)     THEN

      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';

    ELSE

      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := NULL;

    END IF;

    -- Agrego logica para monotributo.
    -- Si es una operacion de monotributo el codigo de impuesto se obtiene del DFF
    -- vat_code de la lookup custom 'XX_ACO_DOC_ONCCA' y no se genera linea de impuesto.
    IF (NVL(p_liquidacion_rec.monotributista,'N') = 'N') THEN

      -----------------------------------------------
      --
      -- Genero la linea de impuestos correspondiente
      --
      -----------------------------------------------
      BEGIN
        SELECT purchasing_tax_code
          INTO l_tax_code
          FROM MTL_SYSTEM_ITEMS_B msi
         WHERE msi.inventory_item_id  = p_liquidacion_rec.inventory_item_id
--           AND msi.organization_id     = p_liquidacion_rec.organization_id;
           AND msi.organization_id    = XX_TCG_UTIL_PKG.master_item_org_id;

        IF (l_tax_code IS NULL) THEN
          x_result := FALSE;
          x_errmsg := 'No se encontro codigo de impuesto para el articulo con id: '
                      ||p_liquidacion_rec.inventory_item_id
                      --||' y la organizacion: '||p_liquidacion_rec.organization_id;
                      ||' y la organizacion Master: '||XX_TCG_UTIL_PKG.master_item_org_id;
          RETURN;
        END IF;
      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Se produjo un error inesperado al intentar obtener el codigo de impuesto '
                      ||'aplicable al articulo con id: '||p_liquidacion_rec.inventory_item_id
                      ||'. '|| SQLERRM;
          RETURN;
      END;


      -------------------------------
      -- Asigno el codigo de impuesto
      -------------------------------
      p_liquidacion_rec.lineas(l_current_line).tax_code                := l_tax_code;
      p_liquidacion_rec.lineas(l_current_line).tax_classification_code := l_tax_code;
      p_liquidacion_rec.lineas(l_current_line).line_group_number       := l_current_line; --CR1216


      Generar_Linea_Impuesto_AP( p_liquidacion_rec     => p_liquidacion_rec
                               , p_linea_base          => l_current_line
                               , p_tax_code            => l_tax_code
                               , p_legal_trx_category  => NULL
                               , x_result              => l_result
                               , x_errmsg              => l_errmsg);

      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible generar las lineas por la compra del grano: '|| l_errmsg;
        RETURN;
      END IF;

    ELSE -- monotributo por el no solo genero linea de item.
      -------------------------------
      -- Asigno el codigo de impuesto
      -------------------------------
      p_liquidacion_rec.lineas(l_current_line).tax_code := p_liquidacion_rec.vat_code;

    END IF; -- monotributo


  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado generando lineas de la factura por la compra de granos: '|| SQLERRM;

  END Get_Lineas_Factura_Grano;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Linea_Factura_Pend_Final                                   *
 * Purpose : Calcula y recupera la por el pendiente de final de la          *
 *           liquidacion.                                                   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Linea_Factura_Pend_Final( p_liquidacion_rec IN OUT NOCOPY liquidacion_rec_type
                                        , x_result          OUT BOOLEAN
                                        , x_errmsg          OUT VARCHAR2)
  IS
    C_API_NAME            VARCHAR2(40) := 'Get_Linea_Factura_Pend_Final';
    l_current_line        NUMBER;
    l_memo_line_id        NUMBER;

    CURSOR c_memo_line (p_memo_line_id IN NUMBER) IS
      SELECT SUBSTR(amlv.name,1,240)
           , aml.gl_id_rev
           , amld.xx_aco_tax_code
           , amld.xx_aco_cat_trx_legal
        FROM AR_MEMO_LINES_ALL_B         aml
           , AR_MEMO_LINES_ALL_B_DFV    amld
           , AR_MEMO_LINES_ALL_VL       amlv
       WHERE aml.memo_line_id        = p_memo_line_id
         AND aml.org_id              = p_liquidacion_rec.operating_unit
         AND aml.memo_line_id        = amlv.memo_line_id
         AND aml.org_id              = amlv.org_id
         AND aml.rowid               = amld.row_id;

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    -------------------------------------------------------
    -- Obtengo la memo linea de los parametros por compania
    -------------------------------------------------------
    BEGIN
      SELECT liq_pend_final_memo_line_id
        INTO l_memo_line_id
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_liquidacion_rec.operating_unit;

      IF (l_memo_line_id IS NULL) THEN
        x_result := FALSE;
        x_errmsg := 'No se encuentra definida la memo line para la linea de factura '
                    ||'correspondiente al monto pendiente de liquidacion. Por favor verifique '
                    ||'la configuracion para los parametros de la Unidad Operativa: '|| p_liquidacion_rec.operating_unit;
        RETURN;
      END IF;

    EXCEPTION
      WHEN no_data_found THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible generar la linea sobre el pendiente de liquidacion '
                    ||'dado que no es encontraron parametros definidos para la Unidad Operativa: '
                    || p_liquidacion_rec.operating_unit;
        RETURN;

      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible generar la linea sobre el pendiente de liquidacion dado que '
                    ||'se produjo un error inesperado al consultar los parametros para la Unidad Operativa: '
                    ||p_liquidacion_rec.operating_unit ||'. '|| SQLERRM;
        RETURN;
    END;

    l_current_line := p_liquidacion_rec.lineas.COUNT + 1;

    -------------------------------
    -- Recupero info de la memoline
    -------------------------------
    OPEN  c_memo_line (l_memo_line_id);
    FETCH c_memo_line INTO p_liquidacion_rec.lineas(l_current_line).description
                         , p_liquidacion_rec.lineas(l_current_line).code_combination_id
                         , p_liquidacion_rec.lineas(l_current_line).tax_code
                         , p_liquidacion_rec.lineas(l_current_line).legal_trx_category;
    CLOSE c_memo_line;

    IF (p_liquidacion_rec.lineas(l_current_line).tax_code IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'Error generando linea para el pendiente de final. No se encuentra configurado '
                  ||'el codigo de impuesto para la memo line: '||p_liquidacion_rec.lineas(l_current_line).description
                  ||'. Por favor verificar.';
      RETURN;
    END IF;

    p_liquidacion_rec.lineas(l_current_line).tax_classification_code := p_liquidacion_rec.lineas(l_current_line).tax_code;
    p_liquidacion_rec.lineas(l_current_line).line_group_number       := l_current_line; --CR1216


    p_liquidacion_rec.lineas(l_current_line).line_type_code := 'ITEM';
    p_liquidacion_rec.lineas(l_current_line).amount         := (round(p_liquidacion_rec.imp_bruto_parcial,2)
                                                                -
                                                                round(p_liquidacion_rec.imp_bruto_parcial *
                                                                     (p_liquidacion_rec.porcentaje_parcial / 100),2)
                                                               );

    ---------------------------------------------------------
    -- Si es una liquidacion parcial, el monto va en negativo
    ---------------------------------------------------------
    IF (UPPER(p_liquidacion_rec.tipo_liquidacion) = 'PARCIAL') THEN
      p_liquidacion_rec.lineas(l_current_line).amount := p_liquidacion_rec.lineas(l_current_line).amount * -1;
    END IF;


    -- Si es una operacion de monotributo el codigo de impuesto se obtiene del DFF
    -- vat_code de la lookup custom 'XX_ACO_DOC_ONCCA' y no se genera linea de impuesto.
    IF (NVL(p_liquidacion_rec.monotributista,'N') = 'Y') THEN -- monotributo
      -- Asigno el codigo de impuesto para linea item monotributo
      p_liquidacion_rec.lineas(l_current_line).tax_code := p_liquidacion_rec.vat_code;

    END IF;


  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'No fue posible generar la linea sobre el pendiente de liquidacion '
                  ||'dado que se produjo un error inesperado: '|| SQLERRM;

  END Get_Linea_Factura_Pend_Final;



 /****************************************************************************
 *                                                                          *
 * Name    : Get_Lineas_Factura_Final                                       *
 * Purpose : Calcula las lineas para la liquidacion final                   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Lineas_Factura_Final( p_liquidacion_rec  IN OUT NOCOPY liquidacion_rec_type
                                    , x_result           OUT BOOLEAN
                                    , x_errmsg           OUT VARCHAR2)
  IS

    CURSOR c_lineas IS
      SELECT xtll.peso_liquidado
           , xtl.porcentaje_parcial
           , xtl.peso_neto_liquidado
        FROM XX_TCG_LIQUIDACION_LINES     xtll
           , (SELECT liquidacion_id
                   , porcentaje_parcial
                   , peso_neto_liquidado
                FROM XX_ACO_LIQUIDACIONES_1116B
               UNION
              SELECT liquidacion_id
                   , porcentaje_parcial
                   , peso_neto_liquidado
                FROM XX_TCG_LIQUIDACIONES )    xtl
       WHERE xtll.liquidacion_id         = p_liquidacion_rec.liquidacion_id
         AND xtll.liquidacion_id_parcial = xtl.liquidacion_id;

    CURSOR c_memo_line (p_memo_line_id IN NUMBER) IS
      SELECT amlv.name
           , aml.gl_id_rev
           , amld.xx_aco_tax_code
           , amld.xx_aco_cat_trx_legal
        FROM AR_MEMO_LINES_ALL_B         aml
           , AR_MEMO_LINES_ALL_B_DFV    amld
           , AR_MEMO_LINES_ALL_VL       amlv
       WHERE aml.memo_line_id   = p_memo_line_id
         AND aml.org_id         = p_liquidacion_rec.operating_unit
         AND aml.memo_line_id   = amlv.memo_line_id
         AND aml.org_id         = amlv.org_id
         AND aml.rowid          = amld.row_id;


    CURSOR c_liq_AJU IS
      SELECT acopio_pdte_final
           , importe_a_liquidar
           , bonif_descuento
        FROM XX_TCG_LIQUIDACIONES
       WHERE liquidacion_id = p_liquidacion_rec.liquidacion_id;

    C_API_NAME            VARCHAR2(40) := 'Get_Lineas_Factura_Final';
    l_importe_a_liquidar  NUMBER := 0;
    l_bonif_desc          NUMBER := 0;
    l_monto_pendiente     NUMBER;
    l_monto_liquidar      NUMBER := 0;
    l_memo_line_id        NUMBER;
    l_current_line        NUMBER;
    l_bonif_memo_line_id  NUMBER;
    l_desc_memo_line_id   NUMBER;
    l_memo_line_name      VARCHAR2(50);
    l_gl_id_rev           NUMBER;
    l_tax_code            VARCHAR2(15);
    l_dummy_tax_code      VARCHAR2(15);
    l_cat_trx_legal       VARCHAR2(30);
    l_result              BOOLEAN;
    l_errmsg              VARCHAR2(2000);

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    IF (p_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico') THEN

      OPEN  c_liq_AJU;
      FETCH c_liq_AJU INTO l_monto_pendiente
                         , l_importe_a_liquidar
                         , l_bonif_desc;
      CLOSE c_liq_AJU;

      l_monto_liquidar := l_monto_pendiente; -- Para reutilizar el codigo de generacion de linea mas abajo

    ELSE

      ---------------------------------------------
      -- Recorro las lineas de la liquidacion final
      ---------------------------------------------
      FOR l_reg IN c_lineas LOOP

        --------------------------------------
        -- Calculo la bonificacion o descuento
        --------------------------------------
        l_bonif_desc := l_bonif_desc + ROUND((NVL(l_reg.peso_liquidado,0)
                                     * NVL(p_liquidacion_rec.precio_referencia_funcional,0)
                                     * p_liquidacion_rec.factor_resultante)
                                     - NVL(l_reg.peso_liquidado,0)
                                     * NVL(p_liquidacion_rec.precio_referencia_funcional,0)
                                     , FND_PROFILE.value('XX_ACO_PRECIO_OPER_DEC')
                                            );

        -----------------------------------------------------
        -- 2) Obtengo el monto total de lo que resta liquidar
        -----------------------------------------------------
        l_monto_pendiente := (l_reg.peso_liquidado * (100 - l_reg.porcentaje_parcial) / 100)
                             * p_liquidacion_rec.precio_referencia_funcional;

        ----------------------------------------------------------------
        -- finalmente el monto a liquidar es el porcentaje obtenido en 1
        -- para el monto pendiente
        ----------------------------------------------------------------
        l_monto_liquidar := l_monto_liquidar + ROUND(l_monto_pendiente, FND_PROFILE.value('XX_ACO_PRECIO_OPER_DEC') );

      END LOOP;

    END IF;

    --------------------------------
    -- Genero la linea del pendiente
    --------------------------------

    ------------------------------------
    -- Obtengo parametros de la compania
    ------------------------------------
    BEGIN

      SELECT liq_pend_final_memo_line_id
        INTO l_memo_line_id
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_liquidacion_rec.operating_unit;

    EXCEPTION
      WHEN no_data_found THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible generar la linea sobre el pendiente de liquidacion '
                    ||'dado que no es encontraron parametros definidos para la compania: '
                    || p_liquidacion_rec.co_code;
        RETURN;
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible generar la linea sobre el pendiente de liquidacion '
                    ||'dado que se produjo un error inesperado al consultar los parametros '
                    ||'para la compania: '||p_liquidacion_rec.co_code ||': '|| SQLERRM;
        RETURN;
    END;


    IF (l_memo_line_id IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No se encuentra definida la memo line para la linea de factura '
                  ||'correspondiente al monto pendiente de liquidacion. Por favor verifique '
                  ||'la configuracion para los parametros de la compania: '
                  || p_liquidacion_rec.co_code;
      RETURN;
    END IF;

    l_current_line := p_liquidacion_rec.lineas.COUNT + 1;

    OPEN  c_memo_line (p_memo_line_id => l_memo_line_id);
    FETCH c_memo_line INTO l_memo_line_name
                         , l_gl_id_rev
                         , l_tax_code
                         , l_cat_trx_legal;
    CLOSE c_memo_line;


    IF (l_tax_code IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se encuentra definido el codigo de impuesto para la memo line'
                  ||'que representa la linea de pendiente de la liquidacion: '
                  ||l_memo_line_name ||'. Por favor verifique la configuracion.';
      RETURN;
    END IF;

    p_liquidacion_rec.lineas(l_current_line).line_type_code          := 'ITEM';
    p_liquidacion_rec.lineas(l_current_line).amount                  := l_monto_liquidar;
    p_liquidacion_rec.lineas(l_current_line).tax_code                := l_tax_code;
    p_liquidacion_rec.lineas(l_current_line).tax_classification_code := l_tax_code;
    p_liquidacion_rec.lineas(l_current_line).legal_trx_category      := l_cat_trx_legal;
    p_liquidacion_rec.lineas(l_current_line).description             := SUBSTR(l_memo_line_name,1,240);
    p_liquidacion_rec.lineas(l_current_line).code_combination_id     := l_gl_id_rev;

    p_liquidacion_rec.lineas(l_current_line).line_group_number       := l_current_line;  -- CR1237

    IF (NVL(p_liquidacion_rec.canje_flag,'N') = 'Y') THEN
      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';
    ELSE
      p_liquidacion_rec.lineas(l_current_line).legal_trx_category := l_cat_trx_legal;
    END IF;


    -- Cambiado de lugar CR1237
    IF (p_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico') THEN

      IF (p_liquidacion_rec.fc_a_recibir <> 0)  THEN

        --Para obtener la linea de facturas a recibir
        Get_Lineas_Factura_Grano( p_liquidacion_rec => p_liquidacion_rec
                                , x_result          => l_result
                                , x_errmsg          => l_errmsg);

        IF (NOT l_result) THEN
          x_result := FALSE;
          x_errmsg := 'Error generando la línea de facturas a recibir: '|| l_errmsg;
          RETURN;
        END IF;

      ELSE

        Generar_Linea_Impuesto_AP( p_liquidacion_rec     => p_liquidacion_rec
                                 , p_linea_base          => l_current_line
                                 , p_tax_code            => l_tax_code
                                 , p_legal_trx_category  => NULL
                                 , x_result              => l_result
                                 , x_errmsg              => l_errmsg);

      END IF;

    END IF;

    -------------------------------------------------------------------------------
    -- Del producto saco el tax_code aplicable a la linea de bonificacion/descuento
    -------------------------------------------------------------------------------
    IF (l_bonif_desc != 0) THEN

      BEGIN
        SELECT purchasing_tax_code
          INTO l_tax_code
          FROM MTL_SYSTEM_ITEMS_B msi
         WHERE msi.inventory_item_id   = p_liquidacion_rec.inventory_item_id
--           AND msi.organization_id     = p_liquidacion_rec.organization_id;
           AND msi.organization_id     = XX_TCG_UTIL_PKG.master_item_org_id;

        IF (l_tax_code IS NULL) THEN
          x_result := FALSE;
          x_errmsg := 'No se encontro codigo de impuesto para el articulo con id: '
                      ||p_liquidacion_rec.inventory_item_id
                      --||' y la organizacion: '||p_liquidacion_rec.organization_id;
                      ||' y la organizacion Master: '||XX_TCG_UTIL_PKG.master_item_org_id;
          RETURN;
        END IF;
      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Se produjo un error inesperado al intentar obtener el codigo de impuesto '
                      ||'aplicable al articulo con id: '||p_liquidacion_rec.inventory_item_id
                      ||'. '|| SQLERRM;
          RETURN;
      END;


      BEGIN

        SELECT liq_bonif_memo_line_id
             , liq_desc_memo_line_id
          INTO l_bonif_memo_line_id
             , l_desc_memo_line_id
          FROM XX_TCG_PARAMETROS_COMPANIA
         WHERE tax_code       = l_tax_code
           AND operating_unit = p_liquidacion_rec.operating_unit
         UNION ALL
        SELECT liq_bonif_memo_line2_id
             , liq_desc_memo_line2_id
          FROM XX_TCG_PARAMETROS_COMPANIA
         WHERE tax_code2      = l_tax_code
           AND operating_unit = p_liquidacion_rec.operating_unit;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          x_result := FALSE;
          x_errmsg := 'No se encontró el codigo de impuesto : '||l_tax_code
                      ||' en la compania : '||p_liquidacion_rec.co_code
                      ||'. Por favor ingresarlo. ';
          RETURN;

        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Se produjo un error inesperado al intentar obtener el codigo de impuesto : '
                      ||l_tax_code||' en la compania : '||p_liquidacion_rec.co_code||
                      '. Por favor ingresarlo. ';
          RETURN;
      END;

      IF (l_bonif_memo_line_id IS NULL) THEN

        x_result := FALSE;
        x_errmsg := 'No se encuentra definida la memo line de bonificacion que representa '
                    ||'la bonificacion de la liquidacion. Por favor verifique la configuracion '
                    ||'en los parametros de la compania: '|| p_liquidacion_rec.co_code;
        RETURN;
      END IF;

      IF (l_desc_memo_line_id IS NULL) THEN

        x_result := FALSE;
        x_errmsg := 'No se encuentra definida la memo line de descuento que representa '
                    ||'el descuento de la liquidacion. Por favor verifique la configuracion '
                    ||'en los parametros de la compania: '|| p_liquidacion_rec.co_code;
        RETURN;
      END IF;

    END IF;

    ----------------------------------------------
    -- Genero la linea de bonificacion o descuento
    ----------------------------------------------
    IF (l_bonif_desc > 0) THEN

      IF (l_bonif_memo_line_id IS NULL) THEN

        x_result := FALSE;
        x_errmsg := 'No se encuentra definida al memo line que representa la bonificacion '
                    ||'de la liquidacion. Por favor verifique la configuracion para los '
                    ||'parametros de la compania: '|| p_liquidacion_rec.co_code;
        RETURN;
      END IF;

      OPEN  c_memo_line (p_memo_line_id => l_bonif_memo_line_id);
      FETCH c_memo_line INTO l_memo_line_name
                           , l_gl_id_rev
                           , l_dummy_tax_code
                           , l_cat_trx_legal;
      CLOSE c_memo_line;

      l_current_line                                                   := p_liquidacion_rec.lineas.COUNT + 1;
      p_liquidacion_rec.lineas(l_current_line).amount                  := l_bonif_desc;
      p_liquidacion_rec.lineas(l_current_line).line_type_code          := 'ITEM';
      p_liquidacion_rec.lineas(l_current_line).tax_code                := l_tax_code;
      p_liquidacion_rec.lineas(l_current_line).description             := SUBSTR(l_memo_line_name,1,240);
      p_liquidacion_rec.lineas(l_current_line).legal_trx_category      := l_cat_trx_legal;
      p_liquidacion_rec.lineas(l_current_line).code_combination_id     := l_gl_id_rev;
      --CR1237
      p_liquidacion_rec.lineas(l_current_line).line_group_number       := l_current_line ;
      p_liquidacion_rec.lineas(l_current_line).tax_classification_code := l_dummy_tax_code ;
      -- fin CR1237

      IF NVL(p_liquidacion_rec.canje_flag,'N') = 'Y' THEN
        p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';
      ELSE
        p_liquidacion_rec.lineas(l_current_line).legal_trx_category := l_cat_trx_legal;
      END IF;



      -- Si es una operacion de monotributo el codigo de impuesto se obtiene del DFF
      -- vat_code de la lookup custom 'XX_ACO_DOC_ONCCA' y no se genera linea de impuesto.
      IF (NVL(p_liquidacion_rec.monotributista,'N') = 'N') THEN

        -----------------
        -- Iva por bonif.
        -----------------
        Generar_Linea_Impuesto_AP( p_liquidacion_rec     => p_liquidacion_rec
                                 , p_linea_base          => l_current_line
                                 , p_tax_code            => l_tax_code
                                 , p_legal_trx_category  => FND_PROFILE.value('XX_ACO_AP_LEGAL_TRX_CATEGORY')
                                 , x_result              => l_result
                                 , x_errmsg              => l_errmsg);

        IF (NOT l_result) THEN

          x_result := FALSE;
          x_errmsg := 'Error generado linea de impuestos para linea de bonificacion: '
                      ||l_memo_line_name ||': '|| l_errmsg;
          RETURN;
        END IF;

      ELSE
        -- Asigno codigo de impuesto para monotributo
        p_liquidacion_rec.lineas(l_current_line).tax_code := p_liquidacion_rec.vat_code;

      END IF;


    ELSIF (l_bonif_desc < 0) THEN

      IF (l_desc_memo_line_id IS NULL) THEN

        x_result := FALSE;
        x_errmsg := 'No se encuentra definida al memo line que representa el descuento de la liquidacion. '
                    ||'Por favor verifique la configuracion en los parametros de la compania: '
                    || p_liquidacion_rec.co_code;
        RETURN;
      END IF;

      OPEN  c_memo_line (p_memo_line_id => l_desc_memo_line_id);
      FETCH c_memo_line INTO l_memo_line_name
                           , l_gl_id_rev
                           , l_dummy_tax_code
                           , l_cat_trx_legal;
      CLOSE c_memo_line;

      l_current_line                                               := p_liquidacion_rec.lineas.COUNT + 1;
      p_liquidacion_rec.lineas(l_current_line).amount              := l_bonif_desc;
      p_liquidacion_rec.lineas(l_current_line).line_type_code      := 'ITEM';
      p_liquidacion_rec.lineas(l_current_line).tax_code            := l_tax_code;
      p_liquidacion_rec.lineas(l_current_line).legal_trx_category  := l_cat_trx_legal;
      p_liquidacion_rec.lineas(l_current_line).description         := SUBSTR(l_memo_line_name,1,240);
      p_liquidacion_rec.lineas(l_current_line).code_combination_id := l_gl_id_rev;

      --CR1237
      p_liquidacion_rec.lineas(l_current_line).line_group_number       := l_current_line ;
      p_liquidacion_rec.lineas(l_current_line).tax_classification_code := l_dummy_tax_code ;
      -- fin CR1237

      IF (NVL(p_liquidacion_rec.canje_flag,'N') = 'Y') THEN
        p_liquidacion_rec.lineas(l_current_line).legal_trx_category := 'NO RETIENE';
      ELSE
        p_liquidacion_rec.lineas(l_current_line).legal_trx_category := l_cat_trx_legal;
      END IF;


      -- Si es una operacion de monotributo el codigo de impuesto se obtiene del DFF
      -- vat_code de la lookup custom 'XX_ACO_DOC_ONCCA' y no se genera linea de impuesto.
      IF (NVL(p_liquidacion_rec.monotributista,'N') = 'N') THEN

        -----------------
        -- Iva por desc.
        -----------------
        Generar_Linea_Impuesto_AP( p_liquidacion_rec     => p_liquidacion_rec
                                 , p_linea_base          => l_current_line
                                 , p_tax_code            => l_tax_code
                                 , p_legal_trx_category  => Fnd_Profile.Value('XX_ACO_AP_LEGAL_TRX_CATEGORY')
                                 , x_result              => l_result
                                 , x_errmsg              => l_errmsg);
        IF (NOT l_result) THEN
          x_result := FALSE;
          x_errmsg := 'Error generado linea de impuestos para linea de descuento: '
                      ||l_memo_line_name ||': '|| l_errmsg;
          RETURN;
        END IF;

      ELSE -- monotributo
        -- Asigno codigo de impuesto para monotributo
        p_liquidacion_rec.lineas(l_current_line).tax_code := p_liquidacion_rec.vat_code;

      END IF;


    END IF;


--   Modificado CR1237
--    IF (p_liquidacion_rec.tipo_liquidacion = 'Ajuste Unico')
--      AND (p_liquidacion_rec.fc_a_recibir <> 0)  THEN
--
--      --Para obtener la linea de facturas a recibir
--      Get_Lineas_Factura_Grano( p_liquidacion_rec => p_liquidacion_rec
--                              , x_result          => l_result
--                              , x_errmsg          => l_errmsg);
--
--      IF (NOT l_result) THEN
--
--        x_result := FALSE;
--        x_errmsg := 'Error generando la línea de facturas a recibir: '|| l_errmsg;
--        RETURN;
--      END IF;
--
--    END IF;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Se produjo un error inesperado generando lineas de la liquidacion final: '|| SQLERRM;

  END Get_Lineas_Factura_Final;




/****************************************************************************
 *                                                                          *
 * Name    : Set_Attribute_Value                                            *
 * Purpose : Setea el valor en el attribute del registro de transaccion.    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Set_Attribute_Value( p_attributes_rec  IN OUT NOCOPY attributes_rec_type
                               , p_column_name     IN VARCHAR2
                               , p_value           IN VARCHAR2)
  IS

    l_column_name VARCHAR2(30);

  BEGIN

    IF (SUBSTR(p_column_name,1,7) = 'GLOBAL_') THEN
      l_column_name := SUBSTR(p_column_name,8);
    ELSE
      l_column_name := p_column_name;
    END IF;

    IF (l_column_name = 'ATTRIBUTE1') THEN
      p_attributes_rec.attribute1  := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE2') THEN
      p_attributes_rec.attribute2   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE3') THEN
      p_attributes_rec.attribute3   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE4') THEN
      p_attributes_rec.attribute4   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE5') THEN
      p_attributes_rec.attribute5   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE6') THEN
      p_attributes_rec.attribute6   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE7') THEN
      p_attributes_rec.attribute7   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE8') THEN
      p_attributes_rec.attribute8   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE9') THEN
      p_attributes_rec.attribute9   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE10') THEN
      p_attributes_rec.attribute10   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE11') THEN
      p_attributes_rec.attribute11   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE12') THEN
      p_attributes_rec.attribute12   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE13') THEN
      p_attributes_rec.attribute13   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE14') THEN
      p_attributes_rec.attribute14   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE15') THEN
      p_attributes_rec.attribute15   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE16') THEN
      p_attributes_rec.attribute16   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE17') THEN
      p_attributes_rec.attribute17   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE18') THEN
      p_attributes_rec.attribute18   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE19') THEN
      p_attributes_rec.attribute19   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE20') THEN
      p_attributes_rec.attribute20   := p_value;
    END IF;


  END Set_Attribute_Value;



 /****************************************************************************
  *                                                                          *
  * Name    : Insertar_Factura_AP                                            *
  * Purpose : Rutina que inserta una factura en la interface de AP           *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Insertar_Factura_AP( p_liquidacion_rec   IN OUT NOCOPY liquidacion_rec_type
                               , p_revertir          IN BOOLEAN
                               , p_procesamiento     IN VARCHAR2
                               , x_result           OUT BOOLEAN
                               , x_errmsg           OUT VARCHAR2)
  IS

    C_API_NAME                VARCHAR2(40) := 'Insertar_Factura_AP';
    l_result                  BOOLEAN;
    l_appl_column_name        VARCHAR2(30);
    l_errmsg                  VARCHAR2(2000);
    l_attributes_rec          ATTRIBUTES_REC_TYPE;
    l_gbl_attributes_rec      ATTRIBUTES_REC_TYPE;
    l_invoice_type            VARCHAR2(30);
    l_precio_appl_col_name    VARCHAR2(30);
    l_cant_appl_col_name      VARCHAR2(30);
    l_rowid                   VARCHAR2(50);
    l_liquidacion_num         VARCHAR2(30);
    l_inv_id                  NUMBER;
    l_inv_num                 VARCHAR2(50);
    l_code_comb_id            NUMBER;
    l_numero_coe_orig         VARCHAR2(30);
    l_legal_trx_cat           VARCHAR2(30);
    l_trx_letter              VARCHAR2(1);
    l_dgi_code                VARCHAR2(30);
    l_legal_trx_cat_nc        VARCHAR2(30);
    l_trx_letter_nc           VARCHAR2(1);
    l_dgi_code_nc             VARCHAR2(30);
    l_grupo_pago              VARCHAR2(100);
    l_canje                   VARCHAR2(1);
    l_legal_entity_id         NUMBER;

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    IF (p_liquidacion_rec.monto < 0) THEN
      l_invoice_type := C_AP_INVOICE_TYPE_CODE_NC;
    ELSE
      l_invoice_type := C_AP_INVOICE_TYPE_CODE;
    END IF;

    -- Si se esta liquidando se pasa el numero de COE guardado en numero_liquidacion
    -- Si se cancela la liquidacion, se pasa el numero del COE anulado para
    -- insertar la factura en AP
    IF (p_revertir) THEN

      l_liquidacion_num   := TO_CHAR(p_liquidacion_rec.numero_liquidacion)||'*';
      l_numero_coe_orig   := p_liquidacion_rec.numero_liquidacion;

    ELSE
      l_liquidacion_num   := p_liquidacion_rec.numero_liquidacion;
      l_numero_coe_orig   := NULL;

    END IF;

    -----------------------------------------------
    --
    -- Obtengo la categoria de transacion legal
    --
    -----------------------------------------------
    BEGIN
      SELECT tcp.trx_category        trx_category_ap_pos
           , tcp.trx_letter          trx_letter_ap_pos
           , tcp.dgi_code            trx_type_ap_pos
           , tca.trx_category        anul_category_ap_pos
           , tca.trx_letter          anul_letter_ap_pos
           , tca.dgi_code            anul_type_ap_pos
           , xtpc.grupo_pago
           , NVL(xtpc.canje, 'N')    canje
        INTO l_legal_trx_cat
           , l_trx_letter
           , l_dgi_code
           , l_legal_trx_cat_nc
           , l_trx_letter_nc
           , l_dgi_code_nc
           , l_grupo_pago
           , l_canje
        FROM XX_TCG_PARAMETROS_COMPROBANTE  xtpc
           , JL_AR_AP_TRX_DGI_CODES         tcp
           , MTL_SYSTEM_ITEMS_B      msi
           , MTL_SYSTEM_ITEMS_B_DFV  msid
           , (SELECT flv.lookup_code                    as tipo_comprobante
                   , NVL(flvd.canje, 'N')               as canje
                   , NVL(flvd.monotributista, 'N')      as monotributista
                   , flvd.ap_trx_letter                 as letra
                FROM FND_LOOKUP_VALUES_VL   flv
                   , FND_LOOKUP_VALUES_DFV  flvd
               WHERE flv.rowid       = flvd.row_id
                 AND flv.lookup_type = 'XX_ACO_DOC_ONCCA'
                 AND flvd.context    = 'XX_ACO_DOC_ONCCA'               ) xdo
           , (SELECT lookup_code                        as trx_category
                FROM FND_LOOKUPS
               WHERE lookup_type = 'JLAR_LEGAL_TRX_CATEGORY'            ) xltc
           , (SELECT flv.lookup_code                    as codigo_oncca
                   , UPPER(flvd.xx_aco_especies_oncca)  as especie_oncca
                FROM FND_LOOKUP_VALUES      flv
                   , FND_LOOKUP_VALUES_DFV  flvd
               WHERE flv.rowid       = flvd.row_id
                 AND flv.lookup_type = 'XX_ACO_ESPECIES_ONCCA'
                 AND flv.language    = userenv('LANG')                  )  xeo
           , JL_AR_AP_TRX_DGI_CODES         tca
       WHERE xtpc.codigo_doc            = 'LIQUIDACION'
         AND xtpc.tipo_doc              = 'OFICIAL'
         AND xtpc.operating_unit        = p_liquidacion_rec.operating_unit
         AND xdo.letra                  = tcp.trx_letter
         AND xdo.tipo_comprobante       = p_liquidacion_rec.tipo_comprobante
         AND xdo.canje                  = xtpc.canje
         AND xdo.monotributista         = p_liquidacion_rec.depositante_monotributista
         AND tcp.trx_category_letter_id = xtpc.categ_trx_pos_id
         AND tcp.trx_category           = xltc.trx_category
         AND xtpc.especie_oncca         = xeo.especie_oncca
         AND msid.xx_aco_codigo_oncca   = xeo.codigo_oncca
         AND msi.rowid                  = msid.row_id
         AND tca.trx_category_letter_id = xtpc.categ_anul_pos_id
         AND msi.inventory_item_id      = p_liquidacion_rec.inventory_item_id
         AND msi.organization_id        = p_liquidacion_rec.organization_id
         ;

    EXCEPTION
      WHEN no_data_found THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible obtener la categoria de transaccion legal dado que no se encontraron '
                    ||'parametros definidos para la Unidad Operativa a la que pertenece la liquidacion. ';
        RETURN;
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible obtener la categoria de transaccion legal dado que se produjo un error '
                    ||'inesperado: '|| SQLERRM;
        RETURN;
    END;


    IF (p_liquidacion_rec.monto > 0) THEN
      p_liquidacion_rec.transaction_letter             := l_trx_letter;
      p_liquidacion_rec.legal_trx_category_1116        := l_legal_trx_cat;
      p_liquidacion_rec.tax_authority_transaction_type := l_dgi_code;
    ELSE
      p_liquidacion_rec.transaction_letter             := l_trx_letter_nc;
      p_liquidacion_rec.legal_trx_category_1116        := l_legal_trx_cat_nc;
      p_liquidacion_rec.tax_authority_transaction_type := l_dgi_code_nc;
    END IF;

    IF (p_liquidacion_rec.legal_trx_category_1116 IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se encontro valor definido para la categoria de transaccion legal. '
                  ||'Por favor verifique los parametros configurados para la Unidad Operativa '
                  ||p_liquidacion_rec.operating_unit;
      RETURN;
    END IF;

    IF (p_liquidacion_rec.tax_authority_transaction_type IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se encontro valor definido para Tipo de Transaccion de Autoridad Fiscal. '
                  ||'Por favor verifique los parametros configurados para la Unidad Operativa '
                  ||p_liquidacion_rec.operating_unit;
      RETURN;
    END IF;

    IF (p_liquidacion_rec.transaction_letter IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se encontro valor definido para Letra de Transaccion '
                  ||'. Por favor verifique los parametros configurados para la Unidad Operativa '
                  ||p_liquidacion_rec.operating_unit;
      RETURN;
    END IF;

    --
    -- Atributos
    --

    -- Pasamos en las liquidaciones Parciales y Unicas el Precio Referencia y el peso liquidado
    -- (ambos expresados en TON)
    IF (UPPER(p_liquidacion_rec.tipo_liquidacion) IN ('UNICA','PARCIAL'))
      OR (UPPER(p_liquidacion_rec.tipo_liquidacion) ='AJUSTE UNICO' AND
        p_liquidacion_rec.peso_diferencia_aju IS NOT NULL) THEN

       -- Precio
      l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                           , p_desc_flex_name    => 'AP_INVOICES'
                                           , p_desc_flex_context => 'AR'
                                           , p_desc_flex_column  => 'XX_AP_Precio_Contrato'
                                           , p_appl_column_name  => l_precio_appl_col_name
                                           , p_mesg_error        => l_errmsg);
      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                    ||' "XX_AP_Precio_Contrato" dentro del flexfield "AP_INVOICES": '
                    ||l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

      -- Cantidad
      l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                           , p_desc_flex_name    => 'AP_INVOICES'
                                           , p_desc_flex_context => 'AR'
                                           , p_desc_flex_column  => 'XX_AP_Cantidad_Contrato_Compra'
                                           , p_appl_column_name  => l_cant_appl_col_name
                                           , p_mesg_error        => l_errmsg);
      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                    ||' "XX_AP_Cantidad_Contrato_Compra" dentro del flexfield "AP_INVOICES": '
                    ||l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

    END IF;

    --
    /* BEGIN 20181211 SD 675 */
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICES'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AP_ACTIVIDAD_SISA'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AP_ACTIVIDAD_SISA" dentro dentro del flexfield "AP_INVOICES": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          =>/* TODO: En el SD esta definido un valor fijo, reemplazar por variable */ '01');

    /* END SD 675*/
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICES'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AP_PRODUCTION_UNIT'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AP_PRODUCTION_UNIT" dentro dentro del flexfield "AP_INVOICES": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.unidad_productiva);



    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICES'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_ACOPIO_CONTRATO_DE_COMPRA'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_ACOPIO_CONTRATO_DE_COMPRA" dentro del flexfield "AP_INVOICES": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.contrato_id);


    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICES'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AP_ORIGEN_PROD'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AP_ORIGEN_PROD" dentro del flexfield "AP_INVOICES": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.procedencia);

    -- Agregado CR612 Revised Jul 2018
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICES'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_TCG_DOC_ID_ORIGEN'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_TCG_DOC_ID_ORIGEN" dentro del flexfield "AP_INVOICES": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.liquidacion_id);
    --


    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'JG'
                                         , p_desc_flex_name    => 'JG_AP_INVOICES_INTERFACE'
                                         , p_desc_flex_context => C_AP_GLOBAL_ATTR_CATEGORY
                                         , p_desc_flex_column  => 'LEGAL_TRANSACTION_CATEGORY'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "LEGAL_TRANSACTION_CATEGORY" dentro del flexfield "JG_AP_INVOICES_INTERFACE": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_gbl_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.legal_trx_category_1116);


    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'JG'
                                         , p_desc_flex_name    => 'JG_AP_INVOICES_INTERFACE'
                                         , p_desc_flex_context => C_AP_GLOBAL_ATTR_CATEGORY
                                         , p_desc_flex_column  => 'TRANSACTION_LETTER'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "TRANSACTION_LETTER" dentro del flexfield "JG_AP_INVOICES_INTERFACE": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_gbl_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.transaction_letter);


    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'JG'
                                         , p_desc_flex_name    => 'JG_AP_INVOICES_INTERFACE'
                                         , p_desc_flex_context => C_AP_GLOBAL_ATTR_CATEGORY
                                         , p_desc_flex_column  => 'TAX_AUTHORITY_TRANSACTION_TYPE'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "TAX_AUTHORITY_TRANSACTION_TYPE" dentro del flexfield "JG_AP_INVOICES_INTERFACE": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_gbl_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.tax_authority_transaction_type);


    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'JG'
                                         , p_desc_flex_name    => 'JG_AP_INVOICES_INTERFACE'
                                         , p_desc_flex_context => C_AP_GLOBAL_ATTR_CATEGORY
                                         , p_desc_flex_column  => 'GLOBAL_ATTRIBUTE17'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "GLOBAL_ATTRIBUTE17" dentro del flexfield "JG_AP_INVOICES_INTERFACE": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_gbl_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.tax_inclusive_flag);


    -- Pasamos en las liquidaciones Parciales y Unicas el Precio Referencia y el peso liquidado
    -- (ambos expresados en TON)
    IF UPPER(p_liquidacion_rec.tipo_liquidacion) IN ('UNICA','PARCIAL') THEN

      SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                         , p_column_name    => l_precio_appl_col_name
                         , p_value          => (p_liquidacion_rec.precio_referencia_funcional*1000));


      IF (p_revertir) THEN

        -- Cancelada
        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_cant_appl_col_name
                           , p_value          => (p_liquidacion_rec.peso_neto_liquidado/(-1000)));
      ELSE

        -- Standard
        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_cant_appl_col_name
                           , p_value          => (p_liquidacion_rec.peso_neto_liquidado/1000));

      END IF;


    ELSIF (UPPER(p_liquidacion_rec.tipo_liquidacion) ='AJUSTE UNICO'
      AND p_liquidacion_rec.peso_diferencia_aju IS NOT NULL) THEN

      SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                         , p_column_name    => l_precio_appl_col_name
                         , p_value          => (p_liquidacion_rec.pr_op_diferencia_aju*1000));


      IF (p_revertir) THEN

        -- Cancelada
        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_cant_appl_col_name
                           , p_value          => (p_liquidacion_rec.peso_diferencia_aju/(-1000)));
      ELSE

        -- Standard
        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_cant_appl_col_name
                           , p_value          => (p_liquidacion_rec.peso_diferencia_aju/1000));

      END IF;


    END IF;


    IF (p_procesamiento = 'API') THEN

      BEGIN
        SELECT ap_invoices_s.nextval
          INTO l_inv_id
          FROM DUAL;

        p_liquidacion_rec.invoice_id:= l_inv_id;

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error al asignar el invoice_id. '||SQLERRM;
      END;

      BEGIN
        SELECT hou.default_legal_context_id
          INTO l_legal_entity_id
          FROM HR_OPERATING_UNITS  hou
         WHERE organization_id = p_liquidacion_rec.operating_unit;

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Error al buscar el legal_entity_id para la UO: '||p_liquidacion_rec.operating_unit
                      ||' '||SQLERRM;
      END;

      l_inv_num := LPAD(p_liquidacion_rec.pto_emision_liq_aju,4,'0')||'-'||
                   LPAD(p_liquidacion_rec.liquidacion_id,8,'0');

      Debug(C_API_NAME, 'Invoice_id: '             ||l_inv_id);
      Debug(C_API_NAME, 'p_Last_Updated_By: '      ||FND_GLOBAL.user_id);
      Debug(C_API_NAME, 'p_Invoice_Num: '          ||l_inv_num);
      Debug(C_API_NAME, 'p_Set_Of_Books_Id: '      ||p_liquidacion_rec.set_of_books_id);
      Debug(C_API_NAME, 'p_Invoice_Currency_Code: '||p_liquidacion_rec.currency_code);


      Debug(C_API_NAME, 'Llamada a API_Crear_Cabecera_AP');

      XX_TCG_LIQUIDACION_UTIL_PKG.API_Crear_Cabecera_AP
        ( p_Rowid                               => l_rowid
        , p_Invoice_Id                          => l_inv_id
        , p_Last_Update_Date                    => SYSDATE
        , p_Last_Updated_By                     => FND_GLOBAL.user_id
        , p_Vendor_Id                           => p_liquidacion_rec.vendor_id
        , p_Invoice_Num                         => l_inv_num
        , p_Invoice_Amount                      => p_liquidacion_rec.monto
        , p_Vendor_Site_Id                      => p_liquidacion_rec.vendor_site_id
        , p_Party_Site_Id                       => p_liquidacion_rec.origen_party_site_id
        , p_Amount_Paid                         => NULL
        , p_Discount_Amount_Taken               => NULL
        , p_Invoice_Date                        => TRUNC(SYSDATE)
        , p_Source                              => 'ACOPIO'
        , p_Invoice_Type_Lookup_Code            => l_invoice_type
        , p_Description                         => p_liquidacion_rec.numero_contrato
        , p_Batch_Id                            => NULL
        , p_Amt_Applicable_To_Discount          => NULL
        , p_Tax_Amount                          => NULL
        , p_Terms_Id                            => p_liquidacion_rec.term_id
        , p_Terms_Date                          => NULL
        , p_Payment_Method_Lookup_Code          => p_liquidacion_rec.metodo_pago
        , p_Goods_Received_Date                 => p_liquidacion_rec.fecha_liquidacion
        , p_Invoice_Received_Date               => TRUNC(SYSDATE)
        , p_Voucher_Num                         => NULL
        , p_Approved_Amount                     => NULL
        , p_Approval_Status                     => NULL
        , p_Approval_Description                => NULL
        , p_Pay_Group_Lookup_Code               => l_grupo_pago
        , p_Set_Of_Books_Id                     => p_liquidacion_rec.set_of_books_id
        , p_Accts_Pay_CCId                      => p_liquidacion_rec.acct_pay_code_combination_id
        , p_Recurring_Payment_Id                => NULL
        , p_Invoice_Currency_Code               => p_liquidacion_rec.currency_code
        , p_Payment_Currency_Code               => p_liquidacion_rec.currency_code
        , p_Exchange_Rate                       => NULL
        , p_Invoice_Distribution_Total          => NULL
        , p_Payment_Amount_Total                => NULL
        , p_Payment_Status_Flag                 => NULL
        , p_Posting_Status                      => NULL
        , p_Authorized_By                       => NULL
        , p_Attribute_Category                  => 'AR'
        , p_Attribute1                          => l_attributes_rec.attribute1
        , p_Attribute2                          => l_attributes_rec.attribute2
        , p_Attribute3                          => l_attributes_rec.attribute3
        , p_Attribute4                          => l_attributes_rec.attribute4
        , p_Attribute5                          => l_attributes_rec.attribute5
        , p_Creation_Date                       => SYSDATE
        , p_Created_By                          => FND_GLOBAL.user_id
        , p_Vendor_Prepay_Amount                => NULL
        , p_Prepay_Flag                         => NULL
        , p_Base_Amount                         => NULL
        , p_Exchange_Rate_Type                  => NULL
        , p_Exchange_Date                       => NULL
        , p_Payment_Cross_Rate                  => 1
        , p_Payment_Cross_Rate_Type             => NULL
        , p_Payment_Cross_Rate_Date             => NULL
        , p_Pay_Curr_Invoice_Amount             => p_liquidacion_rec.monto
        , p_Vat_Code                            => NULL
        , p_Last_Update_Login                   => FND_GLOBAL.login_id
        , p_Original_Prepayment_Amount          => NULL
        , p_Earliest_Settlement_Date            => NULL
        , p_Attribute11                         => l_attributes_rec.attribute11
        , p_Attribute12                         => l_attributes_rec.attribute12
        , p_Attribute13                         => l_attributes_rec.attribute13
        , p_Attribute14                         => l_attributes_rec.attribute14
        , p_Attribute6                          => l_attributes_rec.attribute6
        , p_Attribute7                          => l_attributes_rec.attribute7
        , p_Attribute8                          => l_attributes_rec.attribute8
        , p_Attribute9                          => l_attributes_rec.attribute9
        , p_Attribute10                         => l_attributes_rec.attribute10
        , p_Attribute15                         => l_attributes_rec.attribute15
        , p_Cancelled_Date                      => NULL
        , p_Cancelled_By                        => NULL
        , p_Cancelled_Amount                    => NULL
        , p_Temp_Cancelled_Amount               => NULL
        , p_Exclusive_Payment_Flag              => NULL
        , p_Po_Header_Id                        => NULL
        , p_Ussgl_Transaction_Code              => NULL
        , p_Ussgl_Trx_Code_Context              => NULL
        , p_Doc_Sequence_Id                     => NULL
        , p_Doc_Sequence_Value                  => NULL
        , p_Doc_Category_Code                   => NULL
        , p_Freight_Amount                      => NULL
        , p_Expenditure_Item_Date               => NULL
        , p_Expenditure_Organization_Id         => NULL
        , p_Expenditure_Type                    => NULL
        , p_Pa_Default_Dist_Ccid                => NULL
        , p_Pa_Quantity                         => NULL
        , p_Project_Id                          => NULL
        , p_Project_Accounting_Context          => NULL
        , p_Task_Id                             => NULL
        , p_Awt_Flag                            => NULL
        , p_Awt_Group_Id                        => NULL
        , p_Reference_1                         => NULL
        , p_Reference_2                         => NULL
        , p_Auto_Tax_Calc_Flag                  => NULL
        , p_Org_Id                              => p_liquidacion_rec.operating_unit
        , p_global_attribute_category           => 'JL.AR.APXINWKB.INVOICES'
        , p_global_attribute1                   => l_gbl_attributes_rec.attribute1
        , p_global_attribute2                   => l_gbl_attributes_rec.attribute2
        , p_global_attribute3                   => l_gbl_attributes_rec.attribute3
        , p_global_attribute4                   => l_gbl_attributes_rec.attribute4
        , p_global_attribute5                   => l_gbl_attributes_rec.attribute5
        , p_global_attribute6                   => l_gbl_attributes_rec.attribute6
        , p_global_attribute7                   => l_gbl_attributes_rec.attribute7
        , p_global_attribute8                   => l_gbl_attributes_rec.attribute8
        , p_global_attribute9                   => l_gbl_attributes_rec.attribute9
        , p_global_attribute10                  => l_gbl_attributes_rec.attribute10
        , p_global_attribute11                  => l_gbl_attributes_rec.attribute11
        , p_global_attribute12                  => l_gbl_attributes_rec.attribute12
        , p_global_attribute13                  => l_gbl_attributes_rec.attribute13
        , p_global_attribute14                  => l_gbl_attributes_rec.attribute14
        , p_global_attribute15                  => l_gbl_attributes_rec.attribute15
        , p_global_attribute16                  => l_gbl_attributes_rec.attribute16
        , p_global_attribute17                  => l_gbl_attributes_rec.attribute17
        , p_global_attribute18                  => l_gbl_attributes_rec.attribute18
        , p_global_attribute19                  => l_gbl_attributes_rec.attribute19
        , p_global_attribute20                  => l_gbl_attributes_rec.attribute20
        , p_calling_sequence                    => 'Busqueda de COE - liq 1116B: '
                                                    ||p_liquidacion_rec.pto_emision_liq_aju
                                                    ||'-'||p_liquidacion_rec.liquidacion_id||' '
        , p_gl_date                             => TRUNC(SYSDATE)
        , p_Award_Id                            => NULL
        , p_approval_iteration                  => NULL
        , p_approval_ready_flag                 => 'N'
        , p_wfapproval_status                   => 'NOT REQUIRED'
        , p_paid_on_behalf_employee_id          => NULL
        , p_amt_due_employee                    => NULL
        , p_amt_due_ccard_company               => NULL
        , p_requester_id                        => NULL
        , p_legal_entity_id                     => l_legal_entity_id
         );

    ELSIF (p_procesamiento <> 'API') THEN

      INSERT INTO AP_INVOICES_INTERFACE
        ( accts_pay_code_combination_id
        , amount_applicable_to_discount
        , attribute1
        , attribute10
        , attribute11
        , attribute12
        , attribute13
        , attribute14
        , attribute15
        , attribute2
        , attribute3
        , attribute4
        , attribute5
        , attribute6
        , attribute7
        , attribute8
        , attribute9
        , attribute_category
        , awt_group_id
        , awt_group_name
        , created_by
        , creation_date
        , description
        , doc_category_code
        , exchange_date
        , exchange_rate
        , exchange_rate_type
        , exclusive_payment_flag
        , global_attribute1
        , global_attribute10
        , global_attribute11
        , global_attribute12
        , global_attribute13
        , global_attribute14
        , global_attribute15
        , global_attribute16
        , global_attribute17
        , global_attribute18
        , global_attribute19
        , global_attribute2
        , global_attribute20
        , global_attribute3
        , global_attribute4
        , global_attribute5
        , global_attribute6
        , global_attribute7
        , global_attribute8
        , global_attribute9
        , global_attribute_category
        , gl_date
        , goods_received_date
        , group_id
        , invoice_amount
        , invoice_currency_code
        , invoice_date
        , invoice_id
        , invoice_num
        , invoice_received_date
        , invoice_type_lookup_code
        , last_updated_by
        , last_update_date
        , last_update_login
        , org_id
        , party_site_id
        , payment_cross_rate
        , payment_cross_rate_date
        , payment_cross_rate_type
        , payment_currency_code
        , payment_method_lookup_code
        , pay_group_lookup_code
        , po_number
        , prepay_apply_amount
        , prepay_dist_num
        , prepay_gl_date
        , prepay_num
        , request_id
        , source
        , status
        , terms_id
        , terms_name
        , ussgl_transaction_code
        , vendor_id
        , vendor_name
        , vendor_num
        , vendor_site_code
        , vendor_site_id
        , voucher_num
        , workflow_flag
        , legal_entity_id
        )
      VALUES
        ( p_liquidacion_rec.acct_pay_code_combination_id                        --accts_pay_code_combination_id
        , NULL                                                                  --amount_applicable_to_discount
        , l_attributes_rec.attribute1                                           --attribute1
        , l_attributes_rec.attribute10                                          --attribute10
        , l_attributes_rec.attribute11                                          --attribute11
        , l_attributes_rec.attribute12                                          --attribute12
        , l_attributes_rec.attribute13                                          --attribute13
        , l_attributes_rec.attribute14                                          --attribute14
        , l_attributes_rec.attribute15                                          --attribute15
        , l_attributes_rec.attribute2                                           --attribute2
        , l_attributes_rec.attribute3                                           --attribute3
        , l_attributes_rec.attribute4                                           --attribute4
        , l_attributes_rec.attribute5                                           --attribute5
         --v_attributes_rec.attribute6                                          --attribute6
        , l_numero_coe_orig                                                     --attribute6
        , l_attributes_rec.attribute7                                           --attribute7
        , l_attributes_rec.attribute8                                           --attribute8
        , l_attributes_rec.attribute9                                           --attribute9
        , 'AR'                                                                  --attribute_category
        , NULL                                                                  --awt_group_id
        , NULL                                                                  --awt_group_name
        , 2070 --FND_GLOBAL.user_id                                             --created_by
        , SYSDATE                                                               --creation_date
        , p_liquidacion_rec.numero_contrato                                     --description
        , NULL                                                                  --doc_category_code
        , NULL                                                                  --exchange_date
        , NULL                                                                  --exchange_rate
        , NULL                                                                  --exchange_rate_type
        , NULL                                                                  --exclusive_payment_flag
        , l_gbl_attributes_rec.attribute1                                       --global_attribute1
        , l_gbl_attributes_rec.attribute10                                      --global_attribute10
        , l_gbl_attributes_rec.attribute11                                      --global_attribute11
        , l_gbl_attributes_rec.attribute12                                      --global_attribute12
        , l_gbl_attributes_rec.attribute13                                      --global_attribute13
        , l_gbl_attributes_rec.attribute14                                      --global_attribute14
        , l_gbl_attributes_rec.attribute15                                      --global_attribute15
        , l_gbl_attributes_rec.attribute16                                      --global_attribute16
        , l_gbl_attributes_rec.attribute17                                      --global_attribute17
        , l_gbl_attributes_rec.attribute18                                      --global_attribute18
        , SUBSTR(l_liquidacion_num,1,4) ||
          SUBSTR(l_liquidacion_num,6,8)                                         --global_attribute19
        , l_gbl_attributes_rec.attribute2                                       --global_attribute2
        , TO_CHAR(p_liquidacion_rec.fecha_liquidacion, 'YYYY/MM/DD')            --global_attribute20
        , l_gbl_attributes_rec.attribute3                                       --global_attribute3
        , l_gbl_attributes_rec.attribute4                                       --global_attribute4
        , l_gbl_attributes_rec.attribute5                                       --global_attribute5
        , l_gbl_attributes_rec.attribute6                                       --global_attribute6
        , l_gbl_attributes_rec.attribute7                                       --global_attribute7
        , l_gbl_attributes_rec.attribute8                                       --global_attribute8
        , l_gbl_attributes_rec.attribute9                                       --global_attribute9
        , C_AP_GLOBAL_ATTR_CATEGORY                                             --global_attribute_category
        , p_liquidacion_rec.fecha_liquidacion                                   --gl_date
        , p_liquidacion_rec.fecha_liquidacion                                   --goods_received_date
        , NULL                                                                  --group_id
        , round(p_liquidacion_rec.monto, 2)                                     --invoice_amount
        , p_liquidacion_rec.currency_code                                       --invoice_currency_code
        , p_liquidacion_rec.fecha_liquidacion                                   --invoice_date
        , ap_invoices_interface_s.nextval                                       --invoice_id
        , l_liquidacion_num                                                     --invoice_num
        , p_liquidacion_rec.fecha_liquidacion                                   --invoice_received_date
        , l_invoice_type                                                        --invoice_type_lookup_code
        , 2070 --FND_GLOBAL.user_id                                                    --last_updated_by
        , SYSDATE                                                               --last_update_date
        , -1 --FND_GLOBAL.login_id                                                   --last_update_login
        , p_liquidacion_rec.operating_unit                                      --org_id
        , p_liquidacion_rec.origen_party_site_id                                --party_site_id
        , NULL                                                                  --payment_cross_rate
        , NULL                                                                  --payment_cross_rate_date
        , NULL                                                                  --payment_cross_rate_type
        , NULL                                                                  --payment_currency_code
        , p_liquidacion_rec.metodo_pago                                         --payment_method_lookup_code
        , l_grupo_pago                                                          --pay_group_lookup_code
        , NULL                                                                  --po_number
        , NULL                                                                  --prepay_apply_amount
        , NULL                                                                  --prepay_dist_num
        , NULL                                                                  --prepay_gl_date
        , NULL                                                                  --prepay_num
        , NULL                                                                  --request_id
        , 'ACOPIO'                                                              --source
        , NULL                                                                  --status
        , p_liquidacion_rec.term_id                                             --terms_id
        , NULL                                                                  --terms_name
        , NULL                                                                  --ussgl_transaction_code
        , p_liquidacion_rec.vendor_id                                           --vendor_id
        , NULL                                                                  --vendor_name
        , NULL                                                                  --vendor_num
        , NULL                                                                  --vendor_site_code
        , p_liquidacion_rec.vendor_site_id                                      --vendor_site_id
        , NULL                                                                  --voucher_num
        , NULL                                                                  --workflow_flag
        , l_legal_entity_id                                                     --legal_entity_id
        ) RETURNING invoice_id INTO p_liquidacion_rec.invoice_id;


      Debug(C_API_NAME, 'Invoice en interface: '||p_liquidacion_rec.invoice_id);

    END IF;


  END Insertar_Factura_AP;




/****************************************************************************
 *                                                                          *
 * Name    : Insertar_Lineas_Factura_AP                                     *
 * Purpose : Rutina que inserta las lineas de la factura de AP              *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Insertar_Lineas_Factura_AP( p_liquidacion_rec   IN liquidacion_rec_type
                                      , p_procesamiento     IN VARCHAR2
                                      , x_result            OUT BOOLEAN
                                      , x_errmsg            OUT VARCHAR2) IS

    C_API_NAME                VARCHAR2(100) := 'Insertar_Lineas_Factura_AP';
    l_result                  BOOLEAN;
    l_appl_column_name        VARCHAR2(30);
    l_errmsg                  VARCHAR2(2000);
    l_attributes_rec          ATTRIBUTES_REC_TYPE;
    l_gbl_attributes_rec      ATTRIBUTES_REC_TYPE;
    l_ltc_appl_column_name    VARCHAR2(30);
    l_proc_appl_column_name   VARCHAR2(30);
    l_ship_to_location        NUMBER;
    l_cp_appl_column_name     VARCHAR2(30);
    l_combination_id          NUMBER;
    l_rowid                   VARCHAR2(50);
    l_tax_id                  NUMBER;
    l_distrib_lines           NUMBER;
    l_tax_lines               NUMBER;
    l_inv_distr_id            NUMBER;
    l_period_name             VARCHAR2(15);
    l_code_comb_id            NUMBER;
    l_wh_iva                  NUMBER;
    l_wh_gan                  NUMBER;
    l_term_canje              VARCHAR2(30);
    l_ganancias               VARCHAR2(30);
    l_reg_fiscal              VARCHAR2(30);
    l_amount                  NUMBER;
    l_tax_line_rec            p_taxes_liq_rec_tab;
    l_tax_rate_id             NUMBER;

    l_tax_name                VARCHAR2(15);
    l_tax_description         VARCHAR2(240);
    CURSOR c_tax_lines(p_invoice_id IN NUMBER) IS
      SELECT jja.org_id
           , jjd.awt_type_code
           , jjd.description
           , atc.name        as tax_name
           , atc.description as tax_description
           , XX_TCG_LIQUIDACION_UTIL_PKG.bank_round(SUM(aid.amount),2) as monto
        FROM JL_ZZ_AP_INV_DIS_WH_ALL         jja
           , AP_INVOICE_DISTRIBUTIONS_ALL    aid
           , JL_ZZ_AP_SUP_AWT_CD_ALL         jjb
           , JL_ZZ_AP_SUPP_AWT_TYPES         jjc
           , JL_ZZ_AP_AWT_TYPES              jjd
           , AP_TAX_CODES_ALL                atc
           , FND_LOOKUP_VALUES_VL            flv
           , FND_LOOKUP_VALUES_DFV           flvd
       WHERE jja.invoice_id                    = aid.invoice_id
         AND jja.invoice_distribution_id       = aid.invoice_distribution_id
         AND jja.supp_awt_code_id              = jjb.supp_awt_code_id
         AND jjb.tax_id                        = atc.tax_id
         AND jjb.supp_awt_type_id              = jjc.supp_awt_type_id
         AND jjc.awt_type_code                 = jjd.awt_type_code
         AND flv.lookup_type                   = 'JLAR_AP_DGI_TAX_TYPE'
         AND flv.lookup_code                   = jjd.dgi_tax_type_code
         AND flv.row_id                        = flvd.row_id
         AND NVL(flvd.xx_aco_imprime_1116,'N') = 'Y'
         AND jjd.awt_type_code                 NOT LIKE '%SELLOS%'
         AND jja.invoice_id                    = p_invoice_id
       GROUP BY jja.org_id
           , jjd.awt_type_code
           , jjd.description
           , atc.name
           , atc.description;



    CURSOR c_dist ( p_invoice_id NUMBER) IS
      SELECT invoice_distribution_id
        FROM AP_INVOICE_DISTRIBUTIONS
       WHERE invoice_id  = p_invoice_id
       ORDER BY invoice_distribution_id;


  BEGIN

    Debug(C_API_NAME, 'Inicio ');

    x_result := TRUE;

    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICE_DISTRIBUTIONS'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AP_LEGAL_TRANS_CATEGORY'
                                         , p_appl_column_name  => l_ltc_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '
                  ||'"XX_AP_LEGAL_TRANS_CATEGORY" dentro del flexfield "AP_INVOICE_DISTRIBUTIONS": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    -- Se agrega el dato procedencia para informar el dato a nivel
    -- linea distribucion de facturas de AP.
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                         , p_desc_flex_name    => 'AP_INVOICE_DISTRIBUTIONS'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AP_ORIGEN_PROD'
                                         , p_appl_column_name  => l_proc_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AP_ORIGEN_PROD" dentro del flexfield "AP_INVOICE_DISTRIBUTIONS": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    IF (UPPER(p_liquidacion_rec.tipo_liquidacion) = 'UNICA') THEN

      l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'SQLAP'
                                           , p_desc_flex_name    => 'AP_INVOICE_DISTRIBUTIONS'
                                           , p_desc_flex_context => 'AR'
                                           , p_desc_flex_column  => 'XX_ACO_CP_LIQUIDACION'
                                           , p_appl_column_name  => l_cp_appl_column_name
                                           , p_mesg_error        => l_errmsg);
      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '
                    ||' "XX_ACO_CP_LIQUIDACION" dentro del flexfield "AP_INVOICE_DISTRIBUTIONS": '
                    ||l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

    END IF;


    FOR l_index IN 1 .. p_liquidacion_rec.lineas.COUNT LOOP


      SET_ATTRIBUTE_VALUE( p_attributes_rec => l_gbl_attributes_rec
                         , p_column_name    => 'GLOBAL_ATTRIBUTE3' --l_appl_column_name
                         , p_value          => p_liquidacion_rec.ship_to_location);


      SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                         , p_column_name    => l_ltc_appl_column_name
                         , p_value          => p_liquidacion_rec.lineas(l_index).legal_trx_category);

      -- Procedencia
      IF (UPPER(p_liquidacion_rec.tipo_liquidacion) = 'UNICA')
        AND (p_liquidacion_rec.lineas(l_index).carta_porte_id IS NOT NULL) THEN

        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_proc_appl_column_name
                           , p_value          => p_liquidacion_rec.lineas(l_index).origen_produccion );
      ELSE


        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_proc_appl_column_name
                           , p_value          => p_liquidacion_rec.procedencia);

      END IF;



      IF (UPPER(p_liquidacion_rec.tipo_liquidacion) = 'UNICA')
        AND (p_liquidacion_rec.lineas(l_index).carta_porte_id IS NOT NULL) THEN

        SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                           , p_column_name    => l_cp_appl_column_name
                           , p_value          => p_liquidacion_rec.lineas(l_index).carta_de_porte);

      END IF;



      IF (p_procesamiento = 'API')
        AND (NVL( p_liquidacion_rec.lineas(l_index).tipo_linea
                , p_liquidacion_rec.lineas(l_index).line_type_code) NOT IN  ('SERVICIOS','SERV_TAX')) THEN

        -- No deben ingresar lineas de servicios ni sus correspondientes impuestos
        -- Con el filtro de carta de porte id no nulo, se dejaban las liquidaciones parciales afuera
        -- p_liquidacion_rec.lineas(l_index).carta_porte_id IS NOT NULL THEN

        BEGIN

          SELECT period_name
            INTO l_period_name
            FROM GL_PERIODS
           WHERE 1=1
             AND TRUNC(SYSDATE) BETWEEN  TRUNC(start_date) AND TRUNC(end_date)
             AND period_set_name = 'ADECO_CALENDARI'
             AND adjustment_period_flag = 'N';

        EXCEPTION

          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error al obtener el period name '||SQLERRM;
            RETURN;
        END;


        BEGIN

          SELECT tax_rate_id
            INTO l_tax_id
            FROM ZX_RATES_B           zrb
               , ZX_PARTY_TAX_PROFILE zpt
               , HR_OPERATING_UNITS   hou
           WHERE zrb.tax_rate_code    = p_liquidacion_rec.lineas(l_index).tax_code
             AND zrb.tax_regime_code  = 'AR-Tax'
             AND zrb.content_owner_id = party_tax_profile_id
             AND zpt.party_id         = hou.organization_id
             AND hou.set_of_books_id  = p_liquidacion_rec.set_of_books_id;

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error al obtener el tax_id para '|| p_liquidacion_rec.lineas(l_index).tax_code||' - '||SQLERRM;
            RETURN;
        END;



       Debug(C_API_NAME, 'Llamada a API_Crear_Lineas_AP');

        XX_TCG_LIQUIDACION_UTIL_PKG.API_Crear_Lineas_AP
          ( p_ROWID                           => l_rowid
          , p_INVOICE_ID                      => p_liquidacion_rec.invoice_id
          , p_LINE_NUMBER                     => l_index
          , p_LINE_TYPE_LOOKUP_CODE           => p_liquidacion_rec.lineas(l_index).line_type_code
          , p_LINE_GROUP_NUMBER               => p_liquidacion_rec.lineas(l_index).line_group_number
          , p_REQUESTER_ID                    => NULL
          , p_DESCRIPTION                     => NULL
          , p_LINE_SOURCE                     => NULL
          , p_ORG_ID                          => p_liquidacion_rec.operating_unit
          , p_INVENTORY_ITEM_ID               => p_liquidacion_rec.inventory_item_id
          , p_ITEM_DESCRIPTION                => NULL
          , p_SERIAL_NUMBER                   => NULL
          , p_MANUFACTURER                    => NULL
          , p_MODEL_NUMBER                    => NULL
          , p_WARRANTY_NUMBER                 => NULL
          , p_GENERATE_DISTS                  => NULL
          , p_MATCH_TYPE                      => NULL
          , p_DISTRIBUTION_SET_ID             => NULL
          , p_ACCOUNT_SEGMENT                 => NULL
          , p_BALANCING_SEGMENT               => NULL
          , p_COST_CENTER_SEGMENT             => NULL
          , p_OVERLAY_DIST_CODE_CONCAT        => NULL
          , p_DEFAULT_DIST_CCID               => NULL
          , p_PRORATE_ACROSS_ALL_ITEMS        => NULL
          , p_ACCOUNTING_DATE                 => SYSDATE
          , p_PERIOD_NAME                     => l_period_name
          , p_DEFERRED_ACCTG_FLAG             => NULL
          , p_DEF_ACCTG_START_DATE            => NULL
          , p_DEF_ACCTG_END_DATE              => NULL
          , p_DEF_ACCTG_NUMBER_OF_PERIODS     => NULL
          , p_DEF_ACCTG_PERIOD_TYPE           => NULL
          , p_SET_OF_BOOKS_ID                 => p_liquidacion_rec.set_of_books_id
          , p_AMOUNT                          => p_liquidacion_rec.lineas(l_index).amount
          , p_BASE_AMOUNT                     => NULL
          , p_ROUNDING_AMT                    => NULL
          , p_QUANTITY_INVOICED               => NULL
          , p_UNIT_MEAS_LOOKUP_CODE           => NULL
          , p_UNIT_PRICE                      => NULL
          , p_WFAPPROVAL_STATUS               => 'NOT REQUIRED'
          , p_DISCARDED_FLAG                  => NULL
          , p_ORIGINAL_AMOUNT                 => NULL
          , p_ORIGINAL_BASE_AMOUNT            => NULL
          , p_ORIGINAL_ROUNDING_AMT           => NULL
          , p_CANCELLED_FLAG                  => NULL
          , p_INCOME_TAX_REGION               => NULL
          , p_TYPE_1099                       => NULL
          , p_STAT_AMOUNT                     => NULL
          , p_PREPAY_INVOICE_ID               => NULL
          , p_PREPAY_LINE_NUMBER              => NULL
          , p_INVOICE_INCLUDES_PREPAY_FLAG    => NULL
          , p_CORRECTED_INV_ID                => NULL
          , p_CORRECTED_LINE_NUMBER           => NULL
          , p_PO_HEADER_ID                    => NULL
          , p_PO_LINE_ID                      => NULL
          , p_PO_RELEASE_ID                   => NULL
          , p_PO_LINE_LOCATION_ID             => NULL
          , p_PO_DISTRIBUTION_ID              => NULL
          , p_RCV_TRANSACTION_ID              => NULL
          , p_FINAL_MATCH_FLAG                => NULL
          , p_ASSETS_TRACKING_FLAG            => NULL
          , p_ASSET_BOOK_TYPE_CODE            => NULL
          , p_ASSET_CATEGORY_ID               => NULL
          , p_PROJECT_ID                      => NULL
          , p_TASK_ID                         => NULL
          , p_EXPENDITURE_TYPE                => NULL
          , p_EXPENDITURE_ITEM_DATE           => NULL
          , p_EXPENDITURE_ORGANIZATION_ID     => NULL
          , p_PA_QUANTITY                     => NULL
          , p_PA_CC_AR_INVOICE_ID             => NULL
          , p_PA_CC_AR_INVOICE_LINE_NUM       => NULL
          , p_PA_CC_PROCESSED_CODE            => NULL
          , p_AWARD_ID                        => NULL
          , p_AWT_GROUP_ID                    => NULL
          , p_PAY_AWT_GROUP_ID                => NULL
          , p_REFERENCE_1                     => NULL
          , p_REFERENCE_2                     => NULL
          , p_RECEIPT_VERIFIED_FLAG           => NULL
          , p_RECEIPT_REQUIRED_FLAG           => NULL
          , p_RECEIPT_MISSING_FLAG            => NULL
          , p_JUSTIFICATION                   => NULL
          , p_EXPENSE_GROUP                   => NULL
          , p_START_EXPENSE_DATE              => NULL
          , p_END_EXPENSE_DATE                => NULL
          , p_RECEIPT_CURRENCY_CODE           => NULL
          , p_RECEIPT_CONVERSION_RATE         => NULL
          , p_RECEIPT_CURRENCY_AMOUNT         => NULL
          , p_DAILY_AMOUNT                    => NULL
          , p_WEB_PARAMETER_ID                => NULL
          , p_ADJUSTMENT_REASON               => NULL
          , p_MERCHANT_DOCUMENT_NUMBER        => NULL
          , p_MERCHANT_NAME                   => NULL
          , p_MERCHANT_REFERENCE              => NULL
          , p_MERCHANT_TAX_REG_NUMBER         => NULL
          , p_MERCHANT_TAXPAYER_ID            => NULL
          , p_COUNTRY_OF_SUPPLY               => NULL
          , p_CREDIT_CARD_TRX_ID              => NULL
          , p_COMPANY_PREPAID_INVOICE_ID      => NULL
          , p_CC_REVERSAL_FLAG                => NULL
          , p_CREATION_DATE                   => SYSDATE
          , p_CREATED_BY                      => 2070
          , p_LAST_UPDATED_BY                 => 2070
          , p_LAST_UPDATE_DATE                => SYSDATE
          , p_LAST_UPDATE_LOGIN               => -1
          , p_PROGRAM_APPLICATION_ID          => NULL
          , p_PROGRAM_ID                      => NULL
          , p_PROGRAM_UPDATE_DATE             => NULL
          , p_REQUEST_ID                      => NULL
          , p_ATTRIBUTE_CATEGORY              => NULL
          , p_ATTRIBUTE1                      => NULL
          , p_ATTRIBUTE2                      => NULL
          , p_ATTRIBUTE3                      => NULL
          , p_ATTRIBUTE4                      => NULL
          , p_ATTRIBUTE5                      => NULL
          , p_ATTRIBUTE6                      => NULL
          , p_ATTRIBUTE7                      => NULL
          , p_ATTRIBUTE8                      => NULL
          , p_ATTRIBUTE9                      => NULL
          , p_ATTRIBUTE10                     => NULL
          , p_ATTRIBUTE11                     => NULL
          , p_ATTRIBUTE12                     => NULL
          , p_ATTRIBUTE13                     => NULL
          , p_ATTRIBUTE14                     => NULL
          , p_ATTRIBUTE15                     => NULL
          , p_GLOBAL_ATTRIBUTE_CATEGORY       => NULL
          , p_GLOBAL_ATTRIBUTE1               => NULL
          , p_GLOBAL_ATTRIBUTE2               => NULL
          , p_GLOBAL_ATTRIBUTE3               => NULL
          , p_GLOBAL_ATTRIBUTE4               => NULL
          , p_GLOBAL_ATTRIBUTE5               => NULL
          , p_GLOBAL_ATTRIBUTE6               => NULL
          , p_GLOBAL_ATTRIBUTE7               => NULL
          , p_GLOBAL_ATTRIBUTE8               => NULL
          , p_GLOBAL_ATTRIBUTE9               => NULL
          , p_GLOBAL_ATTRIBUTE10              => NULL
          , p_GLOBAL_ATTRIBUTE11              => NULL
          , p_GLOBAL_ATTRIBUTE12              => NULL
          , p_GLOBAL_ATTRIBUTE13              => NULL
          , p_GLOBAL_ATTRIBUTE14              => NULL
          , p_GLOBAL_ATTRIBUTE15              => NULL
          , p_GLOBAL_ATTRIBUTE16              => NULL
          , p_GLOBAL_ATTRIBUTE17              => NULL
          , p_GLOBAL_ATTRIBUTE18              => NULL
          , p_GLOBAL_ATTRIBUTE19              => NULL
          , p_GLOBAL_ATTRIBUTE20              => NULL
          --ETAX: Invwkb
          , p_PRIMARY_INTENDED_USE            => NULL
          , p_SHIP_TO_LOCATION_ID             => NULL
          , p_PRODUCT_FISC_CLASSIFICATION     => NULL
          , p_USER_DEFINED_FISC_CLASS         => NULL
          , p_TRX_BUSINESS_CATEGORY           => NULL
          , p_PRODUCT_TYPE                    => NULL
          , p_PRODUCT_CATEGORY                => NULL
          , p_ASSESSABLE_VALUE                => NULL
          , p_CONTROL_AMOUNT                  => NULL
          , p_TAX_REGIME_CODE                 => NULL
          , p_TAX                             => NULL
          , p_TAX_STATUS_CODE                 => NULL
          , p_TAX_RATE_CODE                   => NULL
          , p_TAX_RATE_ID                     => l_tax_id
          , p_TAX_RATE                        => NULL
          , p_TAX_JURISDICTION_CODE           => NULL
          , p_PURCHASING_CATEGORY_ID          => NULL
          , p_COST_FACTOR_ID                  => NULL
          , p_RETAINED_AMOUNT                 => NULL
          , p_RETAINED_INVOICE_ID             => NULL
          , p_RETAINED_LINE_NUMBER            => NULL
          , p_TAX_CLASSIFICATION_CODE         => NULL
          , p_Calling_Sequence                => 'XX TCG Liquidacion Granos'
          );


        BEGIN

          SELECT AP_INVOICE_DISTRIBUTIONS_S.nextval
            INTO l_inv_distr_id
            FROM DUAL;

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error al obtener el id de distribucion: '||SQLERRM;
            RETURN;
        END;

        -- Se utilizara este código solo para el ccid de impuestos
        IF (p_liquidacion_rec.lineas(l_index).line_type_code='TAX'
          OR p_liquidacion_rec.lineas(l_index).code_combination_id IS NULL) THEN

          l_code_comb_id := p_liquidacion_rec.acct_pay_code_combination_id;
        ELSE
          l_code_comb_id := p_liquidacion_rec.lineas(l_index).code_combination_id;
        END IF;

        Debug(C_API_NAME, 'Llamada a API_Crear_Distribuciones_AP');

        XX_TCG_LIQUIDACION_UTIL_PKG.API_Crear_Distribuciones_AP
          ( p_Rowid                          => l_rowid
          , p_Invoice_Id                     => p_liquidacion_rec.invoice_id
          , p_Invoice_line_number            => l_index
          , p_Invoice_Distribution_Id        => l_inv_distr_id
          , p_Dist_Code_Combination_Id       => l_code_comb_id
          , p_Last_Update_Date               => SYSDATE
          , p_Last_Updated_By                => FND_GLOBAL.user_id
          , p_Accounting_Date                => SYSDATE
          , p_Period_Name                    => l_period_name
          , p_Set_Of_Books_Id                => p_liquidacion_rec.set_of_books_id
          , p_Amount                         => p_liquidacion_rec.lineas(l_index).amount
          , p_Description                    => p_liquidacion_rec.lineas(l_index).description
          , p_Type_1099                      => NULL
          , p_Tax_Code_Id                    => l_tax_id
          , p_Posted_Flag                    => 'N'
          , p_Batch_Id                       => NULL
          , p_Quantity_Invoiced              => NULL
          , p_Unit_Price                     => NULL
          , p_Match_Status_Flag              => NULL
          , p_Attribute_Category             => 'AR'
          , p_Attribute1                     => l_attributes_rec.attribute1
          , p_Attribute2                     => l_attributes_rec.attribute2
          , p_Attribute3                     => l_attributes_rec.attribute3
          , p_Attribute4                     => l_attributes_rec.attribute4
          , p_Attribute5                     => l_attributes_rec.attribute5
          , p_Prepay_Amount_Remaining        => NULL
          , p_Assets_Addition_Flag           => 'U'
          , p_Assets_Tracking_Flag           => 'N'
          , p_Distribution_Line_Number       => l_index
          , p_Line_Type_Lookup_Code          => p_liquidacion_rec.lineas(l_index).line_type_code
          , p_Po_Distribution_Id             => NULL
          , p_Base_Amount                    => NULL
          , p_Exchange_Rate                  => NULL
          , p_Exchange_Rate_Type             => NULL
          , p_Exchange_Date                  => NULL
          , p_Pa_Addition_Flag               => NULL
          , p_Je_Batch_Id                    => NULL
          , p_Posted_Amount                  => NULL
          , p_Posted_Base_Amount             => NULL
          , p_Encumbered_Flag                => NULL
          , p_Accrual_Posted_Flag            => 'N'
          , p_Cash_Posted_Flag               => 'N'
          , p_Last_Update_Login              => FND_GLOBAL.login_id
          , p_Creation_Date                  => SYSDATE
          , p_Created_By                     => FND_GLOBAL.user_id
          , p_Cash_Je_Batch_Id               => NULL
          , p_Stat_Amount                    => NULL
          , p_Attribute11                    => l_attributes_rec.attribute11
          , p_Attribute12                    => l_attributes_rec.attribute12
          , p_Attribute13                    => l_attributes_rec.attribute13
          , p_Attribute14                    => l_attributes_rec.attribute14
          , p_Attribute6                     => l_attributes_rec.attribute6
          , p_Attribute7                     => l_attributes_rec.attribute7
          , p_Attribute8                     => l_attributes_rec.attribute8
          , p_Attribute9                     => l_attributes_rec.attribute9
          , p_Attribute10                    => l_attributes_rec.attribute10
          , p_Attribute15                    => l_attributes_rec.attribute15
          , p_Accts_Pay_Code_Comb_Id         => NULL
          , p_Rate_Var_Code_Combination_Id   => NULL
          , p_Price_Var_Code_Comb_Id         => NULL
          , p_Exchange_Rate_Variance         => NULL
          , p_Invoice_Price_Variance         => NULL
          , p_Base_Invoice_Price_Variance    => NULL
          , p_Reversal_Flag                  => NULL
          , p_Parent_Invoice_Id              => NULL
          , p_Income_Tax_Region              => NULL
          , p_Final_Match_Flag               => NULL
          , p_Ussgl_Transaction_Code         => NULL
          , p_Ussgl_Trx_Code_Context         => NULL
          , p_Expenditure_Item_Date          => NULL
          , p_Expenditure_Organization_Id    => NULL
          , p_Expenditure_Type               => NULL
          , p_Pa_Quantity                    => NULL
          , p_Project_Id                     => NULL
          , p_Task_Id                        => NULL
          , p_Project_Accounting_Context     => NULL
          , p_Quantity_Variance              => NULL
          , p_Base_Quantity_Variance         => NULL
          , p_Packet_Id                      => NULL
          , p_Awt_Flag                       => NULL
          , p_Awt_Group_Id                   => NULL
          , p_Awt_Tax_Rate_Id                => NULL
          , p_Awt_Gross_Amount               => NULL
          , p_Reference_1                    => NULL
          , p_Reference_2                    => NULL
          , p_Org_Id                         => p_liquidacion_rec.operating_unit
          , p_Other_Invoice_Id               => NULL
          , p_Awt_Invoice_Id                 => NULL
          , p_Awt_Origin_Group_Id            => NULL
          , p_Program_Application_Id         => NULL
          , p_Program_Id                     => NULL
          , p_Program_Update_Date            => NULL
          , p_Request_Id                     => NULL
          , p_Amount_Includes_Tax_Flag       => NULL
          , p_Tax_Code_Override_Flag         => 'N'
          , p_Tax_Recovery_Rate              => NULL
          , p_Tax_Recovery_Override_Flag     => 'N'
          , p_Tax_Recoverable_Flag           => NULL
          , p_Award_Id                       => NULL
          , p_Start_Expense_Date             => NULL
          , p_Merchant_Document_Number       => NULL
          , p_Merchant_Name                  => NULL
          , p_Merchant_Tax_Reg_Number        => NULL
          , p_Merchant_Taxpayer_Id           => NULL
          , p_Country_Of_Supply              => NULL
          , p_Merchant_Reference             => NULL
          , p_parent_reversal_id             => NULL
          , p_rcv_transaction_id             => NULL
          , p_matched_uom_lookup_code        => NULL
          , p_amount_variance                => NULL
          , p_base_amount_variance           => NULL
          , p_dist_match_type                => NULL
          , p_global_attribute_category      => 'JL.AR.APXINWKB.DISTRIBUTIONS'
          , p_global_attribute1              => l_gbl_attributes_rec.attribute1
          , p_global_attribute2              => l_gbl_attributes_rec.attribute2
          , p_global_attribute3              => l_gbl_attributes_rec.attribute3
          , p_global_attribute4              => l_gbl_attributes_rec.attribute4
          , p_global_attribute5              => l_gbl_attributes_rec.attribute5
          , p_global_attribute6              => l_gbl_attributes_rec.attribute6
          , p_global_attribute7              => l_gbl_attributes_rec.attribute7
          , p_global_attribute8              => l_gbl_attributes_rec.attribute8
          , p_global_attribute9              => l_gbl_attributes_rec.attribute9
          , p_global_attribute10             => l_gbl_attributes_rec.attribute10
          , p_global_attribute11             => l_gbl_attributes_rec.attribute11
          , p_global_attribute12             => l_gbl_attributes_rec.attribute12
          , p_global_attribute13             => l_gbl_attributes_rec.attribute13
          , p_global_attribute14             => l_gbl_attributes_rec.attribute14
          , p_global_attribute15             => l_gbl_attributes_rec.attribute15
          , p_global_attribute16             => l_gbl_attributes_rec.attribute16
          , p_global_attribute17             => l_gbl_attributes_rec.attribute17
          , p_global_attribute18             => l_gbl_attributes_rec.attribute18
          , p_global_attribute19             => l_gbl_attributes_rec.attribute19
          , p_global_attribute20             => l_gbl_attributes_rec.attribute20
          , p_Calling_Sequence               => 'Busqueda de COE - liq 1116B: '
                                                ||p_liquidacion_rec.pto_emision_liq_aju
                                                ||'-'||p_liquidacion_rec.liquidacion_id
                                                ||' - Distrib line: '||l_index||' '
          , p_Receipt_Verified_Flag          => NULL
          , p_Receipt_Required_flag          => NULL
          , p_Receipt_Missing_flag           => NULL
          , p_Justification                  => NULL
          , p_Expense_Group                  => NULL
          , p_End_Expense_Date               => NULL
          , p_Receipt_Currency_Code          => NULL
          , p_Receipt_Conversion_Rate        => NULL
          , p_Receipt_Currency_Amount        => NULL
          , p_Daily_Amount                   => NULL
          , p_Web_Parameter_Id               => NULL
          , p_Adjustment_Reason              => NULL
          , p_Credit_Card_Trx_Id             => NULL
          , p_Company_Prepaid_Invoice_Id     => NULL
          , p_price_correct_inv_id           => NULL
          , p_price_correct_qty              => NULL
          );

      ELSIF (p_procesamiento <> 'API') THEN



        INSERT INTO AP_INVOICE_LINES_INTERFACE
          ( accounting_date
          , account_segment
          , amount
          , amount_includes_tax_flag
          , assets_tracking_flag
          , attribute1
          , attribute10
          , attribute11
          , attribute12
          , attribute13
          , attribute14
          , attribute15
          , attribute2
          , attribute3
          , attribute4
          , attribute5
          , attribute6
          , attribute7
          , attribute8
          , attribute9
          , attribute_category
          , awt_group_id
          , awt_group_name
          , balancing_segment
          , cost_center_segment
          , created_by
          , creation_date
          , credit_card_trx_id
          , description
          , distribution_set_id
          , distribution_set_name
          , dist_code_combination_id
          , dist_code_concatenated
          , expenditure_item_date
          , expenditure_organization_id
          , expenditure_type
          , final_match_flag
          , global_attribute1
          , global_attribute10
          , global_attribute11
          , global_attribute12
          , global_attribute13
          , global_attribute14
          , global_attribute15
          , global_attribute16
          , global_attribute17
          , global_attribute18
          , global_attribute19
          , global_attribute2
          , global_attribute20
          , global_attribute3
          , global_attribute4
          , global_attribute5
          , global_attribute6
          , global_attribute7
          , global_attribute8
          , global_attribute9
          , global_attribute_category
          , income_tax_region
          , inventory_item_id
          , invoice_id
          , invoice_line_id
          , item_description
          , last_updated_by
          , last_update_date
          , last_update_login
          , line_group_number
          , line_number
          , line_type_lookup_code
          , match_option
          , org_id
          , packing_slip
          , pa_addition_flag
          , pa_cc_ar_invoice_id
          , pa_cc_ar_invoice_line_num
          , pa_cc_processed_code
          , pa_quantity
          , po_distribution_id
          , po_distribution_num
          , po_header_id
          , po_line_id
          , po_line_location_id
          , po_line_number
          , po_number
          , po_release_id
          , po_shipment_num
          , po_unit_of_measure
          , price_correction_flag
          , project_accounting_context
          , project_id
          , prorate_across_flag
          , quantity_invoiced
          , rcv_transaction_id
          , receipt_line_number
          , receipt_number
          , reference_1
          , reference_2
          , release_num
          , ship_to_location_code
          , ship_to_location_id                                                 --Aregado CR612 Revised Jul 2018
          , stat_amount
          , task_id
          , tax_classification_code
          , tax_code
          , tax_code_id
          , tax_code_override_flag
          , tax_rate_id
          , tax_recoverable_flag
          , tax_recovery_override_flag
          , tax_recovery_rate
          , type_1099
          , unit_price
          , ussgl_transaction_code
          )
        VALUES
          ( p_liquidacion_rec.fecha_liquidacion                                 --accounting_date
          , NULL                                                                --account_segment
          , ROUND(p_liquidacion_rec.lineas(l_index).amount, 2)                  --amount
          , NULL                                                                --amount_includes_tax_flag
          , NULL                                                                --assets_tracking_flag
          , l_attributes_rec.attribute1                                         --attribute1
          , l_attributes_rec.attribute10                                        --attribute10
          , l_attributes_rec.attribute11                                        --attribute11
          , l_attributes_rec.attribute12                                        --attribute12
          , l_attributes_rec.attribute13                                        --attribute13
          , l_attributes_rec.attribute14                                        --attribute14
          , l_attributes_rec.attribute15                                        --attribute15
          , l_attributes_rec.attribute2                                         --attribute2
          , l_attributes_rec.attribute3                                         --attribute3
          , l_attributes_rec.attribute4                                         --attribute4
          , l_attributes_rec.attribute5                                         --attribute5
          , l_attributes_rec.attribute6                                         --attribute6
          , l_attributes_rec.attribute7                                         --attribute7
          , l_attributes_rec.attribute8                                         --attribute8
          , l_attributes_rec.attribute9                                         --attribute9
          , 'AR'                                                                --attribute_category
          , NULL                                                                --awt_group_id
          , NULL                                                                --awt_group_name
          , NULL                                                                --balancing_segment
          , NULL                                                                --cost_center_segment
          , 2070 --FND_GLOBAL.user_id                                                  --created_by
          , SYSDATE                                                             --creation_date
          , NULL                                                                --credit_card_trx_id
          , p_liquidacion_rec.lineas(l_index).description                       --description
          , NULL                                                                --distribution_set_id
          , NULL                                                                --distribution_set_name
          , p_liquidacion_rec.lineas(l_index).code_combination_id               --dist_code_combination_id
          , p_liquidacion_rec.lineas(l_index).concatenated_segments             --dist_code_concatenated
          , NULL                                                                --expenditure_item_date
          , NULL                                                                --expenditure_organization_id
          , NULL                                                                --expenditure_type
          , NULL                                                                --final_match_flag
          , l_gbl_attributes_rec.attribute1                                     --global_attribute1
          , l_gbl_attributes_rec.attribute10                                    --global_attribute10
          , l_gbl_attributes_rec.attribute11                                    --global_attribute11
          , l_gbl_attributes_rec.attribute12                                    --global_attribute12
          , l_gbl_attributes_rec.attribute13                                    --global_attribute13
          , l_gbl_attributes_rec.attribute14                                    --global_attribute14
          , l_gbl_attributes_rec.attribute15                                    --global_attribute15
          , l_gbl_attributes_rec.attribute16                                    --global_attribute16
          , l_gbl_attributes_rec.attribute17                                    --global_attribute17
          , l_gbl_attributes_rec.attribute18                                    --global_attribute18
          , l_gbl_attributes_rec.attribute19                                    --global_attribute19
          , l_gbl_attributes_rec.attribute2                                     --global_attribute2
          , l_gbl_attributes_rec.attribute20                                    --global_attribute20
          , l_gbl_attributes_rec.attribute3                                     --Global_attribute3
          , l_gbl_attributes_rec.attribute4                                     --global_attribute4
          , l_gbl_attributes_rec.attribute5                                     --global_attribute5
          , l_gbl_attributes_rec.attribute6                                     --global_attribute6
          , l_gbl_attributes_rec.attribute7                                     --global_attribute7
          , l_gbl_attributes_rec.attribute8                                     --global_attribute8
          , l_gbl_attributes_rec.attribute9                                     --global_attribute9
          , C_AP_GLOBAL_ATTR_CATEGORY_LN                                        --global_attribute_category
          , NULL                                                                --income_tax_region
          , NULL                                                                --inventory_item_id
          , p_liquidacion_rec.invoice_id                                        --invoice_id
          , ap_invoice_lines_interface_s.nextval                                --invoice_line_id
          , NULL                                                                --item_description
          , 2070 --FND_GLOBAL.user_id                                                  --last_updated_by
          , SYSDATE                                                             --last_update_date
          , -1 --FND_GLOBAL.login_id                                                 --last_update_login
          , p_liquidacion_rec.lineas(l_index).line_group_number                 --line_group_number
          , l_index                                                             --line_number
          , p_liquidacion_rec.lineas(l_index).line_type_code                    --line_type_lookup_code
          , NULL                                                                --match_option
          , p_liquidacion_rec.operating_unit                                    --org_id
          , NULL                                                                --packing_slip
          , NULL                                                                --pa_addition_flag
          , NULL                                                                --pa_cc_ar_invoice_id
          , NULL                                                                --pa_cc_ar_invoice_line_num
          , NULL                                                                --pa_cc_processed_code
          , NULL                                                                --pa_quantity
          , NULL                                                                --po_distribution_id
          , NULL                                                                --po_distribution_num
          , NULL                                                                --po_header_id
          , NULL                                                                --po_line_id
          , NULL                                                                --po_line_location_id
          , NULL                                                                --po_line_number
          , NULL                                                                --po_number
          , NULL                                                                --po_release_id
          , NULL                                                                --po_shipment_num
          , NULL                                                                --po_unit_of_measure
          , NULL                                                                --price_correction_flag
          , NULL                                                                --project_accounting_context
          , NULL                                                                --project_id
          , p_liquidacion_rec.lineas(l_index).prorate_across_flag               --prorate_across_flag
          , NULL                                                                --quantity_invoiced
          , NULL                                                                --rcv_transaction_id
          , NULL                                                                --receipt_line_number
          , NULL                                                                --receipt_number
          , NULL                                                                --reference_1
          , NULL                                                                --reference_2
          , NULL                                                                --release_num
          , NULL                                                                --ship_to_location_code
          , p_liquidacion_rec.ship_to_location                                  --ship_to_location_id    CR612 Revised Jul 2018
          , NULL                                                                --stat_amount
          , NULL                                                                --task_id
          , p_liquidacion_rec.lineas(l_index).tax_classification_code           --tax_classification_code
          , NULL                                                                --tax_code
          , NULL                                                                --tax_code_id
          , 'N'                                                                 --tax_code_override_flag
          , p_liquidacion_rec.lineas(l_index).tax_rate_id                       --tax_rate_id
          , NULL                                                                --tax_recoverable_flag
          , 'N'                                                                 --tax_recovery_override_flag
          , NULl                                                                --tax_recovery_rate
          , NULL                                                                --type_1099
          , NULL                                                                --unit_price
          , NULL                                                                --ussgl_transaction_code
          );


--        IF (p_liquidacion_rec.lineas(l_index).line_type_code = 'ITEM')
--          AND (p_liquidacion_rec.lineas(l_index).tax_code = 'IVA 0% Exento') THEN
--
--
--          --Agregado CR1237 - asilva - ago 2018
--          BEGIN
--            SELECT zrb.tax_rate_id
--              INTO l_tax_rate_id
--              FROM ZX_RATES_B                zrb
--                 , ZX_RATES_B_DFV            zrbd
--                 , ZX_PARTY_TAX_PROFILE      zptp
--                 , AR_VAT_TAX_ALL_B          avt
--                 , AR_VAT_TAX_ALL_B_DFV      avtd
--             WHERE zrb.content_owner_id  = zptp.party_tax_profile_id
--               AND avt.rowid             = avtd.row_id
--               AND zrb.rowid             = zrbd.row_id
--               AND avtd.xx_cod_imp_nd    = zrbd.xx_cod_imp_nd
--               AND zrb.tax_rate_code     = p_liquidacion_rec.lineas(l_index).tax_code
--               AND avt.set_of_books_id   = p_liquidacion_rec.set_of_books_id
--               AND zptp.party_id         = p_liquidacion_rec.operating_unit;
--
--          EXCEPTION
--            WHEN others THEN
--              x_result := FALSE;
--              x_errmsg := 'No fue posible encontrar el tax_rate_id para '||p_liquidacion_rec.lineas(l_index).tax_code
--                          ||' con set_of_books_id = '||p_liquidacion_rec.set_of_books_id
--                          ||' y UO = '||p_liquidacion_rec.operating_unit ||'. '|| SQLERRM;
--              RETURN;
--          END;
--          -- fin CR1237
--
--          INSERT INTO AP_INVOICE_LINES_INTERFACE
--            ( invoice_id
--            , invoice_line_id
--            , line_type_lookup_code
--            , amount
--            , accounting_date
--            , description
--            --, tax_code              Modificado  CR1237
--            , tax_classification_code
--            , tax_rate_id
--            , line_group_number
--            , line_number
--            , prorate_across_flag
--            -- fin CR1237
--            , last_updated_by
--            , last_update_date
--            , last_update_login
--            , created_by
--            , creation_date
--            , attribute_category
--            , attribute2
--            , attribute7
--            , global_attribute_category
--            , global_attribute3
--            , org_id
--            , tax_recovery_override_flag
--            , tax_code_override_flag
--            , ship_to_location_id
--            )
--          VALUES
--            ( p_liquidacion_rec.invoice_id
--            , ap_invoice_lines_interface_s.nextval
--            , 'TAX'
--            , 0
--            , p_liquidacion_rec.fecha_liquidacion
--            , 'Imp. al Valor Agregado 0%'
--            , p_liquidacion_rec.lineas(l_index).tax_code
--            -- Agregado CR1237
--            , l_tax_rate_id
--            , l_index
--            , l_index + 1
--            , 'Y'
--            -- fin CR1237
--            , 2070 --FND_GLOBAL.user_id
--            , SYSDATE
--            , -1 --FND_GLOBAL.login_id
--            , 2070 --FND_GLOBAL.user_id
--            , SYSDATE
--            , 'AR'
--            , l_attributes_rec.attribute2
--            , l_attributes_rec.attribute7
--            , C_AP_GLOBAL_ATTR_CATEGORY_LN
--            , l_gbl_attributes_rec.attribute3
--            , p_liquidacion_rec.operating_unit
--            , 'N'
--            , 'N'
--            , p_liquidacion_rec.ship_to_location                                -- CR612 Revised Jul 2018
--            );
--
--        END IF;

      END IF;

    END LOOP;


    BEGIN

      SELECT nvl(max(distribution_line_number),0)
        INTO l_distrib_lines
        FROM AP_INVOICE_DISTRIBUTIONS_ALL
       WHERE invoice_id = p_liquidacion_rec.invoice_id;

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error inesperado al intener calcular la cantidad de lineas '||
                    'de Distribucion en AP_INVOICE_DISTRIBUTIONS_ALL: '|| SQLERRM;
        RETURN;
    END;


    IF (p_procesamiento = 'API') AND (l_distrib_lines>=1) THEN

      DEBUG(C_API_NAME, 'Invoice_id: '||p_liquidacion_rec.invoice_id||' - l_distrib_lines: '||l_distrib_lines);


      FOR reg_dist IN c_dist (p_liquidacion_rec.invoice_id)  LOOP

        DEBUG(C_API_NAME, 'Invoice_distribution_id: '||reg_dist.invoice_distribution_id);

        JL_ZZ_AP_AWT_DEFAULT_PKG.Supp_Wh_Def ( p_invoice_id      => p_liquidacion_rec.invoice_id
                                             , p_inv_line_num    => NULL
                                             , p_inv_dist_id     => reg_dist.invoice_distribution_id
                                             , p_calling_module  => 'XXACOLIQ'
                                             , p_parent_dist_id  => NULL);

      END LOOP;


      l_tax_lines := 0;
      l_wh_iva    := 0;
      l_wh_gan    := 0;


      FOR r_tax_lines IN c_tax_lines(p_liquidacion_rec.invoice_id) LOOP

        l_tax_lines:= l_tax_lines +1;


        l_tax_line_rec(l_tax_lines).liquidacion_id   := p_liquidacion_rec.liquidacion_id;
        l_tax_line_rec(l_tax_lines).org_id           := r_tax_lines.org_id;
        l_tax_line_rec(l_tax_lines).awt_type_code    := r_tax_lines.awt_type_code;
        l_tax_line_rec(l_tax_lines).description      := r_tax_lines.description;
        l_tax_line_rec(l_tax_lines).tax_name         := r_tax_lines.tax_name;
        l_tax_line_rec(l_tax_lines).tax_description  := r_tax_lines.tax_description;
        l_tax_line_rec(l_tax_lines).monto            := r_tax_lines.monto;


        IF r_tax_lines.awt_type_code = 'RIVA' THEN
          l_wh_iva:= l_wh_iva + 1;
        END IF;

        IF r_tax_lines.awt_type_code = 'RGAN' THEN
          l_wh_gan:= l_wh_gan + 1;
        END IF;

      END LOOP;

      BEGIN

        SELECT NVL(attribute1,'N')
          INTO l_term_canje
          FROM AP_TERMS_TL
         WHERE attribute_category = 'AR'
           AND language           = userenv('LANG')
           AND term_id            = p_liquidacion_rec.term_id;


        IF (l_term_canje = 'N') THEN

          IF (l_wh_iva = 0) THEN

            l_tax_lines:= l_tax_lines + 1;

            l_tax_line_rec(l_tax_lines).liquidacion_id   := p_liquidacion_rec.liquidacion_id;
            l_tax_line_rec(l_tax_lines).org_id           := p_liquidacion_rec.operating_unit;
            l_tax_line_rec(l_tax_lines).awt_type_code    := 'RIVA';
            l_tax_line_rec(l_tax_lines).description      := 'Retencion de IVA';
            l_tax_line_rec(l_tax_lines).tax_name         := 'RIVA_0';
            l_tax_line_rec(l_tax_lines).tax_description  := 'IVA RG 2300 0%';
            l_tax_line_rec(l_tax_lines).monto            := 0;

          END IF;

          IF (l_wh_gan = 0) THEN

            BEGIN

              SELECT attribute6 xx_ap_op_granos
                   , attribute8 xx_ap_ganancias
                INTO l_reg_fiscal
                   , l_ganancias
                FROM AP_SUPPLIERS
               WHERE party_id = p_liquidacion_rec.empresa_origen_party_id;


            EXCEPTION
              WHEN no_data_found THEN
                x_result := FALSE;
                x_errmsg := 'No se encuentran datos que informen la situación de Ganancias y '
                            ||'Registro Fiscal del proveedor.';
                RETURN;
              WHEN others THEN
                x_result := FALSE;
                x_errmsg := 'Error inesperado al intener verificar la situación de Ganancias y '
                            ||'Registro Fiscal del proveedor: '|| SQLERRM;
                RETURN;
            END;

            l_tax_lines:= l_tax_lines + 1;

            l_tax_line_rec(l_tax_lines).liquidacion_id   := p_liquidacion_rec.liquidacion_id;
            l_tax_line_rec(l_tax_lines).org_id           := p_liquidacion_rec.operating_unit;
            l_tax_line_rec(l_tax_lines).awt_type_code    := 'RGAN';
            l_tax_line_rec(l_tax_lines).description      := 'Retencion Impuesto a las Ganancias';
            l_tax_line_rec(l_tax_lines).monto            := 0;

            /* 20181204 */
            SELECT
            --flvd.XX_AP_GANANCIAS, flvd.XX_AP_AWT_TAX_CODE, atca.name, atca.description
            NVL (MAX (atca.name),'X')  , NVL( MAX (atca.description) ,'X')
            INTO l_tax_name, l_tax_description
            FROM
            fnd_lookup_values_vl flv, fnd_lookup_values_dfv flvd
            ,
            (
            SELECT
            name , description, tax_id
            FROM
            AP_TAX_CODES_ALL
            WHERE   nvl(inactive_date, sysdate+1) > sysdate
            AND   tax_type = 'AWT'
            --AND   org_id = fnd_global.org_id
            ) atca
            WHERE
             flv.lookup_type = 'XX_AP_ESTADOS_SISA_MAP'
             AND flv.row_id = flvd.row_id
             AND atca.tax_id = to_number (flvd.XX_AP_AWT_TAX_CODE)
             --AND flv.lookup_code = l_reg_fiscal-- ahora es estado SISA (?) '1'
             AND flv.tag = l_reg_fiscal-- ahora es estado SISA (?) '1'
             AND flvd.XX_AP_GANANCIAS = l_ganancias --'INSCRIPTO'
             ;
            IF  l_tax_name = 'X' THEN
            -- si no encuentra anda aplica castigo (?)
              l_tax_line_rec(l_tax_lines).tax_name         := 'RGAN_NI_SISA_CE';
              l_tax_line_rec(l_tax_lines).tax_description  := 'GAN RG4325 Cer NI Gan SISA Activo/Inactivo';
            ELSE

              l_tax_line_rec(l_tax_lines).tax_name         :=l_tax_name;
              l_tax_line_rec(l_tax_lines).tax_description  := l_tax_description;

            END IF;
            /* 20181204 */
            /* 20181204
            IF (l_ganancias = 'INSCRIPTO') AND (l_reg_fiscal = 'INSCRIPTO') THEN

              l_tax_line_rec(l_tax_lines).tax_name         := 'RG2118_CE2';
              l_tax_line_rec(l_tax_lines).tax_description  := 'GAN RG 2118 Cereales I Gan I RFOG';

            ELSIF (l_ganancias = 'INSCRIPTO') AND (l_reg_fiscal = 'NO_INSCRIPTO') THEN

              l_tax_line_rec(l_tax_lines).tax_name         := 'RG2118_CE15';
              l_tax_line_rec(l_tax_lines).tax_description  := 'GAN RG 2118 Cereales I Gan NI RFOG';

            ELSIF (l_ganancias = 'NO_INSCRIPTO') THEN

              l_tax_line_rec(l_tax_lines).tax_name         := 'RG2118_CE28';
              l_tax_line_rec(l_tax_lines).tax_description  := 'GAN RG 2118 Cer NI Gan I RFOG/NI RFOG';

            ELSE

              l_tax_line_rec(l_tax_lines).tax_name         := 'RG_0';
              l_tax_line_rec(l_tax_lines).tax_description  := 'Retencion Ganancias 0%';

            END IF;
            */

          END IF;

        END IF;

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error inesperado al validar si el termino de pago corresponde a canje: '|| SQLERRM;
          RETURN;
      END;


      Grabar_retenciones( p_taxes_rec    =>  l_tax_line_rec
                        , p_tax_line_num =>  l_tax_lines
                        , p_result       =>  x_result
                        , p_errmsg       =>  l_errmsg);

      IF (NOT x_result) THEN
        x_errmsg:= 'Procesamiento API - Error al calcular las retenciones en las lineas de distribucion de AP: '
                   ||p_liquidacion_rec.numero_liquidacion||'. '||l_errmsg;

        RETURN;
      END IF;

    END IF;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Se produjo un error inesperado al intentar insertar una linea de la factura en '
                  ||'AP_INVOICE_LINES_INTERFACE: '|| SQLERRM;

  END Insertar_Lineas_Factura_AP;



/****************************************************************************
 *                                                                          *
 * Name    : Generar_Transaccion_AR                                         *
 * Purpose : Rutina para la generacion de una Trx Interco en AR a partir de *
 *          una liquidacion de Granos con una empresa Intercompany          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Transaccion_AR( p_liquidacion_rec  IN   OUT NOCOPY liquidacion_rec_type
                                  , p_procesamiento    IN   VARCHAR2
                                  , p_revertir         IN   BOOLEAN
                                  , p_commit           IN   VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                                  , x_result           OUT  BOOLEAN
                                  , x_errmsg           OUT  VARCHAR2
                                  , x_warning          OUT  VARCHAR2)
  IS

    C_API_NAME                   VARCHAR2(30) := 'Generar_Transaccion_AR';
    l_tipo_documento             VARCHAR2(30);
    l_batch_source_name_interco  VARCHAR2(50);
    l_result                     BOOLEAN;
    l_errmsg                     VARCHAR2(2000);
    l_ctrx_type_id_interco       NUMBER;
    l_attributes_rec             ATTRIBUTES_REC_TYPE;
    l_appl_column_name           VARCHAR2(30);
    l_org_id_interco             NUMBER;
    l_org_inv_id                 NUMBER;
    l_sob_id_interco             NUMBER;
    l_customer_interco           NUMBER;
    l_co_code_interco            VARCHAR2(10);
    l_memo_line                  VARCHAR2(240);
    l_inv_item_id                NUMBER;
    l_description                VARCHAR2(240);
    l_quantity                   NUMBER;
    l_unit_sell_price            NUMBER;
    l_total_amount               NUMBER;
    l_item_no                    VARCHAR2(30);
    l_item_um                    VARCHAR2(4);
    l_cod_impuesto               VARCHAR2(100);
    l_uom_rate                   NUMBER;
    l_metodo_name                VARCHAR2(30);
    l_grand_total                NUMBER := 0;
    l_warehouse_id               NUMBER;


  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    ----------------------------------------------------------------
    -- Obtengo el batch_source_name de la configuracion por compania
    -- y otros datos de compania.
    ----------------------------------------------------------------
    BEGIN

      Debug(C_API_NAME,'Parametros de UO:' );
      Debug(C_API_NAME,'Empresa Origen Party Id: '||p_liquidacion_rec.empresa_origen_party_id
                        ||' - Tipo Comprobante: ' ||p_liquidacion_rec.tipo_comprobante );
      Debug(C_API_NAME,'Inv Item Id: '            ||p_liquidacion_rec.inventory_item_id
                        ||' - Organization Id: '  ||p_liquidacion_rec.organization_id );

      IF (p_revertir) THEN
        l_tipo_documento := 'NOTA CREDITO';
      ELSE
        l_tipo_documento := 'FACTURA';
      END IF;

      SELECT rbs.name
           , DECODE(l_tipo_documento, 'FACTURA', xtpc.tipo_trx_ar_id
                                    , 'NOTA CREDITO', xtpc.tipo_anul_ar_id)
           , hou.organization_id
           , hou.set_of_books_id
           , acct_id_default_1116b
        INTO l_batch_source_name_interco
           , l_ctrx_type_id_interco
           , l_org_id_interco
           , l_sob_id_interco
           , p_liquidacion_rec.acct_id_default_1116b
        FROM XX_TCG_PARAMETROS_COMPROBANTE  xtpc
           , XX_TCG_PARAMETROS_COMPANIA     xtco
           , JL_AR_AP_TRX_DGI_CODES         tcp
           , MTL_SYSTEM_ITEMS_B      msi
           , MTL_SYSTEM_ITEMS_B_DFV  msid
           , (SELECT flv.lookup_code                    as tipo_comprobante
                   , NVL(flvd.canje, 'N')               as canje
                   , NVL(flvd.monotributista, 'N')      as monotributista
                   , flvd.ap_trx_letter                 as letra
                FROM FND_LOOKUP_VALUES_VL   flv
                   , FND_LOOKUP_VALUES_DFV  flvd
               WHERE flv.rowid       = flvd.row_id
                 AND flv.lookup_type = 'XX_ACO_DOC_ONCCA'
                 AND flvd.context    = 'XX_ACO_DOC_ONCCA'               ) xdo
           , (SELECT lookup_code                        as trx_category
                FROM FND_LOOKUPS
               WHERE lookup_type = 'JLAR_LEGAL_TRX_CATEGORY'            ) xltc
           , (SELECT flv.lookup_code                    as codigo_oncca
                   , UPPER(flvd.xx_aco_especies_oncca)  as especie_oncca
                FROM FND_LOOKUP_VALUES      flv
                   , FND_LOOKUP_VALUES_DFV  flvd
               WHERE flv.rowid       = flvd.row_id
                 AND flv.lookup_type = 'XX_ACO_ESPECIES_ONCCA'
                 AND flv.language    = userenv('LANG')                  )  xeo
           , JL_AR_AP_TRX_DGI_CODES         tca
           , RA_BATCH_SOURCES_ALL           rbs
           , HR_OPERATING_UNITS             hou
           , AP_SUPPLIERS                   aps
       WHERE xtpc.codigo_doc            = 'LIQUIDACION'
         AND xtpc.tipo_doc              = 'OFICIAL'
         AND xtpc.operating_unit        = xtco.operating_unit
         AND xtco.vendor_id             = aps.vendor_id
         AND aps.party_id               = p_liquidacion_rec.empresa_origen_party_id
         AND xdo.letra                  = tcp.trx_letter
         AND xdo.tipo_comprobante       = p_liquidacion_rec.tipo_comprobante
         AND xdo.canje                  = xtpc.canje
         AND xdo.monotributista         = DECODE(aps.global_attribute1, '06', 'Y', 'N')
         AND tcp.trx_category_letter_id = xtpc.categ_trx_pos_id
         AND tcp.trx_category           = xltc.trx_category
         AND xtpc.especie_oncca         = xeo.especie_oncca
         AND msid.xx_aco_codigo_oncca   = xeo.codigo_oncca
         AND msi.rowid                  = msid.row_id
         AND tca.trx_category_letter_id = xtpc.categ_anul_pos_id
         AND rbs.batch_source_id        = DECODE(l_tipo_documento, 'FACTURA', xtpc.origen_trx_ar_id
                                                                 , 'NOTA CREDITO', xtpc.origen_anul_ar_id)
         AND xtco.operating_unit        = hou.organization_id
         AND msi.inventory_item_id      = p_liquidacion_rec.inventory_item_id
         AND msi.organization_id        = p_liquidacion_rec.organization_id;


    EXCEPTION
      WHEN no_data_found THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible obtener los parametros por comprobante para la liquidacion '
                    ||p_liquidacion_rec.liquidacion_id ||' de la Unidad Operativa: '
                    ||p_liquidacion_rec.operating_unit;
        RETURN;
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo los parametros por comprobante para la liquidacion '
                    ||p_liquidacion_rec.liquidacion_id ||' de la Unidad Operativa: '
                    ||p_liquidacion_rec.operating_unit||': ' || SQLERRM;
        RETURN;
    END;


    IF (l_batch_source_name_interco IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No se espefico el nombre del origen de lote para la transaccion de AR '
                  ||'en la Unidad Operativa: '||p_liquidacion_rec.operating_unit;
      RETURN;
    END IF;


    IF (l_ctrx_type_id_interco IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No se espefico el tipo de transaccion de AR en la Unidad Operativa '
                  ||p_liquidacion_rec.operating_unit ;
      RETURN;
    END IF;

    ------------------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar el tipo de pedido de vta
    ------------------------------------------------------------------------
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'AR'
                                         , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AR_TIPO_PEDIDO_OM'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AR_TIPO_PEDIDO_OM" dentro del flexfield "RA_CUSTOMER_TRX": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.oe_order_type);


    ----------------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar el numero de pedido
    ----------------------------------------------------------------------
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'AR'
                                         , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AR_NRO_PEDIDO_OM'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AR_NRO_PEDIDO_OM" dentro del flexfield "RA_CUSTOMER_TRX": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.order_number);


    ----------------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar el tipo de liquidacion
    ----------------------------------------------------------------------
    l_result := XX_UTIL_PK.Dff_get_column( p_appl_short_name   => 'AR'
                                         , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AR_TIPO_LIQUIDACION'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento'
                  ||' "XX_AR_TIPO_LIQUIDACION" dentro del flexfield "RA_CUSTOMER_TRX": '
                  ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    SET_ATTRIBUTE_VALUE( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => p_liquidacion_rec.tipo_liquidacion);


    -----------------------------------------------------------
    -- Obtengo datos del cliente de factura interco
    -----------------------------------------------------------
    BEGIN

      SELECT customer_id
        INTO l_customer_interco
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE co_code = p_liquidacion_rec.co_code;

    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo el cliente asociado para la CIA: '
                    ||p_liquidacion_rec.co_code ||'. '|| SQLERRM;
        RETURN;
    END;



    -- Para que cada los mensaje de error sea m?claro, se separo en 4
    -- Domicilio BILL_TO
    -- Domicilio SHIP_TO
    -- Termino de pago
    -- Metodo de pago
    --

    -- Domicilio BILL_TO
    IF (p_liquidacion_rec.customer_bill_address_id IS NULL) THEN

      x_errmsg := 'Error al obtener la direccion de Facturacion para el cliente '
                  ||'asociado a la CIA. '||p_liquidacion_rec.co_code;
      x_result := FALSE;
      RETURN;
    END IF;

    -- Domicilio SHIP_TO
    IF (p_liquidacion_rec.customer_ship_address_id IS NULL) THEN

      x_errmsg := 'Error al obtener la direccion de Envio para el cliente asociado '
                  ||'a la CIA. '||p_liquidacion_rec.co_code;
      x_result := FALSE;
      RETURN;
    END IF;

    -- Termino de pago
    IF (p_liquidacion_rec.ar_term_name IS NULL) THEN

      x_errmsg := 'Error al obtener el termino de pago de AR para el cliente asociado a la CIA. '
                  ||p_liquidacion_rec.co_code||' Por favor asociar un termino de pago de AR'
                  ||' en el termino de pago de AP.';
      x_result := FALSE;
      RETURN;
    END IF;

    -- Metodo de pago
    BEGIN

      SELECT rm.name
        INTO l_metodo_name
        FROM RA_CUST_RECEIPT_METHODS crm
           , AR_RECEIPT_METHODS      rm
       WHERE rm.receipt_method_id = crm.receipt_method_id
         AND rm.receipt_method_id = p_liquidacion_rec.ar_receipt_method_id
         AND customer_id          = l_customer_interco
         AND crm.end_date         IS NULL
         AND crm.site_use_id      = p_liquidacion_rec.site_use_id;

    EXCEPTION
      WHEN OTHERS THEN
        l_metodo_name := NULL;
    END;


    IF (l_metodo_name IS NULL) THEN

      x_errmsg := 'Error al obtener el metodo de pago de AR para el cliente asociado '
                  ||'a la CIA. '||p_liquidacion_rec.co_code||'. Por favor ingresar el metodo '
                  ||'de pago en la solapa Metodos de pago a nivel de Domicilio del Cliente.';
      x_result := FALSE;
      RETURN;
    END IF;

    -------------------------------------------------------------------
    -- Por cada linea de la liquidacion genero la linea en la interface
    -------------------------------------------------------------------
    FOR l_index IN 1 .. p_liquidacion_rec.lineas.COUNT LOOP

      -- Solo inserto lineas tipo ITEM
      IF (p_liquidacion_rec.lineas(l_index).line_type_code = 'ITEM') THEN

        -- Verifico tipo de linea para setear item_id y memo_line
        IF (p_liquidacion_rec.lineas(l_index).tipo_linea = 'ITEM') THEN

          l_inv_item_id := p_liquidacion_rec.inventory_item_id;
          l_memo_line   := NULL;
          l_description := p_liquidacion_rec.lineas(l_index).description;

          -- La unidad de medida se obtiene a partir de un DFF segun la especie
          -- oncca a la que pertenece el item.
          BEGIN

            SELECT msi.segment1
                 , flvd.unidad_medida_acopio
              INTO l_item_no
                 , l_item_um
              FROM MTL_SYSTEM_ITEMS_B     msi
                 , MTL_SYSTEM_ITEMS_B_DFV msid
                 , FND_LOOKUP_VALUES      flv
                 , FND_LOOKUP_VALUES_DFV  flvd
             WHERE msi.rowid                = msid.row_id
               AND flv.rowid                = flvd.row_id
               AND flv.lookup_type          = 'XX_ACO_ESPECIES_ONCCA'
               AND flv.language             = userenv('LANG')
               AND msid.xx_aco_codigo_oncca = flv.lookup_code
               AND msi.inventory_item_id    = p_liquidacion_rec.inventory_item_id
               AND msi.organization_id      = p_liquidacion_rec.organization_id;

          EXCEPTION
            WHEN OTHERS THEN
              x_result := FALSE;
              x_errmsg := 'Se produjo un error al intentar obtener el item_no e item_um para el item '
                          ||p_liquidacion_rec.inventory_item_id
                          ||': '|| SQLERRM;
              RETURN;
          END;

          -- Se convierte a Toneladas para las especies ONCCA que se comercializan en dicha unidad.
          -- Sino por default es KG.
          IF (l_item_um = 'TON') THEN

            INV_CONVERT.Inv_um_conversion( from_unit    => 'KG'
                                         , to_unit      => l_item_um
                                         , item_id      => NULL
                                         , uom_rate     => l_uom_rate);

            l_quantity        := (p_liquidacion_rec.peso_neto_liquidado * l_uom_rate);
            l_unit_sell_price := (p_liquidacion_rec.precio_operacion_funcional * 1000);
            l_total_amount    := ROUND(l_quantity * l_unit_sell_price,2);

          ELSE

            l_quantity        := p_liquidacion_rec.peso_neto_liquidado;
            l_unit_sell_price := p_liquidacion_rec.precio_operacion_funcional;
            l_total_amount    := ROUND(l_quantity * l_unit_sell_price,2);

          END IF;


          -- Obtengo codigo de impuesto para cada linea de liquidacion
          BEGIN

            SELECT DISTINCT msid.transaction_condition_code
              INTO l_cod_impuesto
              FROM MTL_SYSTEM_ITEMS        msi
                 , MTL_SYSTEM_ITEMS_B4_DFV msid
             WHERE msi.rowid           = msid.rowid
               AND msi.segment1        = l_item_no
               AND msid.transaction_condition_code IS NOT NULL;

            Debug(C_API_NAME,'1.l_cod_impuesto:'||l_cod_impuesto||' para tipo linea '||p_liquidacion_rec.lineas(l_index).tipo_linea );

          EXCEPTION
            WHEN TOO_MANY_ROWS THEN
              BEGIN

                SELECT DISTINCT msid.transaction_condition_code
                  INTO l_cod_impuesto
                  FROM MTL_SYSTEM_ITEMS        msi
                     , MTL_SYSTEM_ITEMS_B4_DFV msid
                 WHERE msi.rowid           = msid.rowid
                   AND msi.segment1        = l_item_no
                   AND msi.organization_id = p_liquidacion_rec.organization_id
                   AND msid.transaction_condition_code IS NOT NULL;

                Debug(C_API_NAME,'1.l_cod_impuesto:'||l_cod_impuesto||' para tipo linea '
                                 ||p_liquidacion_rec.lineas(l_index).tipo_linea );
              EXCEPTION
                WHEN OTHERS THEN
                  x_result := FALSE;
                  x_errmsg := 'Se produjo un error al obtener el codigo de impuesto para el item: '
                              || l_item_no||': '|| SQLERRM;
                  RETURN;
              END;

            WHEN OTHERS THEN
              x_result := FALSE;
              x_errmsg := 'Se produjo un error al obtener el codigo de impuesto para el item: '
                          || l_item_no||': '|| SQLERRM;
              RETURN;
          END;


          IF (p_revertir) THEN
            l_quantity     := ABS(l_quantity) * -1;
            l_total_amount := ABS(l_total_amount) * -1;
          END IF;

        ELSE

          l_inv_item_id     := NULL;
          l_memo_line       := p_liquidacion_rec.lineas(l_index).description;
          l_description     := p_liquidacion_rec.lineas(l_index).description;
          l_quantity        := 1;

          IF(p_revertir) THEN
            l_unit_sell_price := (p_liquidacion_rec.lineas(l_index).amount * -1);
            l_total_amount    := (p_liquidacion_rec.lineas(l_index).amount * -1);
          ELSE
            l_unit_sell_price := p_liquidacion_rec.lineas(l_index).amount;
            l_total_amount    := p_liquidacion_rec.lineas(l_index).amount;
          END IF;

          l_item_no         := NULL;
          l_item_um         := NULL;

          -- Obtengo codigo de impuesto para cada linea de liquidacion
          BEGIN

            SELECT amld.transaction_condition_class
              INTO l_cod_impuesto
              FROM AR_MEMO_LINES_ALL_VL     aml
                 , AR_MEMO_LINES_ALL_B1_DFV amld
             WHERE aml.row_id       = amld.row_id
               AND aml.name         = l_memo_line
               AND aml.org_id       = l_org_id_interco;

            Debug(C_API_NAME,'2.l_cod_impuesto:'||l_cod_impuesto||' para tipo linea '||p_liquidacion_rec.lineas(l_index).tipo_linea );

          EXCEPTION
            WHEN OTHERS THEN
              x_result := FALSE;
              x_errmsg := 'Se produjo un error al obtener el codigo de impuesto para la memoline: '
                          || l_memo_line ||': '|| SQLERRM;
              RETURN;
          END;


          IF (p_revertir) THEN
            l_quantity     := ABS(l_quantity);
            l_total_amount := ABS(l_total_amount);
          END IF;

        END IF;

        -----------------------
        -- Id de Organizacion
        ----------------------
        BEGIN

          SELECT MIN(od.organization_id) warehouse_id
            INTO l_warehouse_id
            FROM FINANCIALS_SYSTEM_PARAMS_ALL   fsp
               , ( SELECT oi.organization_id
                        , ou.name                        organization_name
                        , TO_NUMBER(oi.org_information1) set_of_books_id
                        , TO_NUMBER(oi.org_information3) unit_operation
                     FROM HR_ORGANIZATION_INFORMATION oi
                        , HR_ORGANIZATION_UNITS       ou
                    WHERE 1=1
                      AND ou.organization_id  = oi.organization_id
                      AND oi.org_information_context = 'Accounting Information')  od
          WHERE 1=1
            AND od.set_of_books_id = fsp.set_of_books_id
            AND od.organization_id = fsp.inventory_organization_id
            AND od.unit_operation  = l_org_id_interco;

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error al buscar el warehouse_id. '||SQLERRM;
            RETURN;
        END;


        IF (p_procesamiento = 'API') THEN -- Cuando se ingresa por API para generar la factura ficticia en AP
                                          -- no es necesario crear también la de AR, pero se ingresa a
          GOTO Proxima_Linea;             -- este procedimiento para que se efectúen todas las validaciones
                                          -- necesarias antes de ir a AFIP
        END IF;


        -------------------
        -- Inserto la linea
        -------------------
        BEGIN

          INSERT INTO RA_INTERFACE_LINES_ALL
            ( line_type
            , cust_trx_type_id
            , orig_system_bill_address_id
            , receipt_method_name                                               --receipt_method_id
            , trx_date
            , batch_source_name
            , trx_number
            , quantity
            , currency_code
            , unit_selling_price
            , amount
            , conversion_type
            , conversion_rate
            , conversion_date
            , set_of_books_id
            , memo_line_name
            , memo_line_id
            , line_gdf_attribute2
            , line_gdf_attribute3
            , interface_line_context
            , interface_line_attribute1
            , interface_line_attribute2
            , interface_line_attribute3
            , interface_line_attribute5
            , orig_system_ship_address_id
            , warehouse_id
            , header_gdf_attr_category
            , line_gdf_attr_category
            , orig_system_bill_customer_id
            , orig_system_ship_customer_id
            , orig_system_sold_customer_id
            , term_name                                                         -- term_id
            , description
            , gl_date
            , amount_includes_tax_flag
            , header_attribute_category
            , header_attribute1
            , header_attribute2
            , header_attribute3
            , header_attribute4
            , header_attribute5
            , header_attribute6
            , header_attribute7
            , header_attribute8
            , header_attribute9
            , header_attribute10
            , header_attribute11
            , header_attribute12
            , header_attribute13
            , header_attribute14
            , header_attribute15
            , org_id
            , creation_date
            , created_by
            , last_update_date
            , last_updated_by
            , last_update_login
            , mtl_system_items_seg1                                             -- inventory_item_id
            , uom_code
            , comments
            )
          VALUES
            ( 'LINE'                                                            -- line_type
            , l_ctrx_type_id_interco                                            -- cust_trx_type_id
            , p_liquidacion_rec.customer_bill_address_id                        -- orig_system_bill_address_id
            , l_metodo_name                                                     -- receipt_method_name
              -- por la modificacion del COE se requiere que la factura posea fecha
              -- del dia en que se solicita el mismo
            , p_liquidacion_rec.fecha_liquidacion                               -- trx_date
            , l_batch_source_name_interco                                       -- batch_source_name
            , FND_PROFILE.value('XX_ACO_RA_FC_PREFIX')
              || p_liquidacion_rec.numero_liquidacion                           -- trx_number
            , l_quantity                                                        -- quantity
            , p_liquidacion_rec.currency_code                                   -- currency_code
            , l_unit_sell_price                                                 -- unit_selling_price
            , l_total_amount                                                    -- amount
            , 'User'                                                            -- conversion_type
            , 1                                                                 -- conversion_rate
            , DECODE(l_tipo_documento, 'FACTURA', p_liquidacion_rec.fecha_liquidacion      -- conversion_date
                                     , 'NOTA CREDITO', p_liquidacion_rec.fecha_coe_anul)
            , l_sob_id_interco                                                  -- set_of_books_id
            , l_memo_line                                                       -- memo_line_name
            , NULL                                                              -- memo_line_id
            , 'DEFAULT'                                                         -- line_gdf_attribute2
            , l_cod_impuesto                                                    -- line_gdf_attribute3 -- 'T-GRAVADO'
            , 'ACOPIO'                                                          -- interface_line_context
            , p_liquidacion_rec.numero_liquidacion                              -- interface_line_attribute1
            , DECODE(l_tipo_documento, 'FACTURA', 'FC'                          -- interface_line_attribute2
                                     , 'NOTA CREDITO', 'NC')
            , l_index                                                           -- interface_line_attribute3
            --, p_liquidacion_rec.liquidacion_id                                -- interface_line_attribute5  CR612 Revised Jul 2017
            , p_liquidacion_rec.invoice_id_interco                              -- interface_line_attribute5
            , p_liquidacion_rec.customer_ship_address_id                        -- orig_system_ship_address_id
            , l_warehouse_id                                                    -- warehouse_id
            , 'JL.AR.ARXTWMAI.TGW_HEADER'                                       -- header_gdf_attr_category
            , 'JL.AR.ARXTWMAI.LINES'                                            -- line_gdf_attr_category
            , l_customer_interco                                                -- orig_system_bill_customer_id
            , l_customer_interco                                                -- orig_system_ship_customer_id
            , l_customer_interco                                                -- orig_system_sold_customer_id
            , DECODE(l_tipo_documento, 'FACTURA', p_liquidacion_rec.ar_term_name -- term_name
                                     , 'NOTA CREDITO', NULL)
            , l_description                                                     -- description
            , DECODE(l_tipo_documento, 'FACTURA', p_liquidacion_rec.fecha_liquidacion -- gl_date
                                     , 'NOTA CREDITO', SYSDATE)
            , 'N'                                                               -- amount_includes_tax_flag
            , 'AR'                                                              -- header_attribute_category
            , l_attributes_rec.attribute1                                       -- header_attribute1
            , l_attributes_rec.attribute2                                       -- header_attribute2
            , l_attributes_rec.attribute3                                       -- header_attribute3
            , l_attributes_rec.attribute4                                       -- header_attribute4
            , l_attributes_rec.attribute5                                       -- header_attribute5
            , l_attributes_rec.attribute6                                       -- header_attribute6
            , l_attributes_rec.attribute7                                       -- header_attribute7
            , l_attributes_rec.attribute8                                       -- header_attribute8
            , l_attributes_rec.attribute9                                       -- header_attribute9
            , l_attributes_rec.attribute10                                      -- header_attribute10
            , l_attributes_rec.attribute11                                      -- header_attribute11
            , l_attributes_rec.attribute12                                      -- header_attribute12
            , l_attributes_rec.attribute13                                      -- header_attribute13
            , l_attributes_rec.attribute14                                      -- header_attribute14
            , l_attributes_rec.attribute15                                      -- header_attribute15
            , l_org_id_interco                                                  -- org_id
            , SYSDATE                                                           -- creation_date
            , 2070                                                              -- created_by   --FND_GLOBAL.user_id
            , SYSDATE                                                           -- last_update_date
            , 2070                                                              -- last_updated_by  --FND_GLOBAL.user_id
            , -1                                                                -- last_update_login  --FND_GLOBAL.login_id
            , l_item_no                                                         -- mtl_system_items_seg1
            , l_item_um                                                         -- uom_code
            , DECODE(l_tipo_documento, 'FACTURA', NULL                          -- comments
                                     , 'NOTA CREDITO', 'COE Original: '||p_liquidacion_rec.numero_liquidacion)
            );


        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Se produjo un error al intentar insertar la linea de interface para '
                        ||'la memoline: '||p_liquidacion_rec.lineas(l_index).description
                        ||': '|| SQLERRM;
            RETURN;
        END;


        -----------------------------------
        -- Inserto la linea de distribucion
        -----------------------------------
        BEGIN

          INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL
            ( account_class
            , interface_line_context
            , amount
            , interface_line_attribute1
            , interface_line_attribute2
            , interface_line_attribute3
            , interface_line_attribute5    -- CR612 Revised Jul 2018
            , code_combination_id
            , org_id
            , percent
            , creation_date
            , created_by
            , last_update_date
            , last_updated_by
            , last_update_login
           )
         VALUES
           ( 'REV'
           , 'ACOPIO'
           , p_liquidacion_rec.lineas(l_index).amount
           , p_liquidacion_rec.numero_liquidacion
           , DECODE(l_tipo_documento, 'FACTURA', 'FC'
                                    , 'NOTA CREDITO', 'NC')
           , l_index
           , p_liquidacion_rec.invoice_id_interco
           , p_liquidacion_rec.acct_id_default_1116b
           , l_org_id_interco
           , 100
           , SYSDATE
           , 2070 --FND_GLOBAL.user_id
           , SYSDATE
           , 2070 --FND_GLOBAL.user_id
           , -1 --FND_GLOBAL.login_id
           );

          l_grand_total := l_grand_total + l_total_amount;

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Se produjo un error al intentar insertar la linea de distribucion para '
                        ||'la memoline: '||p_liquidacion_rec.lineas(l_index).description
                        ||': '|| SQLERRM;
            RETURN;
        END;

      END IF;

      <<Proxima_Linea>>
      NULL;

    END LOOP;


    --------------------------
    -- Lanzo la interace de AR
    --------------------------
    Debug(C_API_NAME, 'XX_ACO_EJECUTAR_INTERFACE_AR: '||FND_PROFILE.value('XX_ACO_EJECUTAR_INTERFACE_AR')
                     ||' - p_commit: '||p_commit||' - p_procesamiento: '||p_procesamiento);

    IF (NVL(FND_PROFILE.value('XX_ACO_EJECUTAR_INTERFACE_AR'),'N') = 'Y')
      AND (p_procesamiento = 'INTERFACE')
      AND (FND_API.to_boolean(p_commit)) THEN


      Ejecutar_Interface_AR( p_org_id             => l_org_id_interco
                           , p_batch_source_name  => l_batch_source_name_interco
                           , p_transaction_number => FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') ||
                                                     p_liquidacion_rec.numero_liquidacion
                           , p_customer_class     => NULL
                           , x_result             => l_result
                           , x_errmsg             => l_errmsg);

      IF (NOT l_result) THEN
        x_warning := l_errmsg;
      END IF;

    END IF;


  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado generando '||initcap(l_tipo_documento)
                  ||' Interco en AR. '||SQLERRM;

  END Generar_Transaccion_AR;



/****************************************************************************
 *                                                                          *
 * Name    : Grabar_retenciones                                             *
 * Purpose : Rutina que crea las retenciones y las graba en la tabla de TCG *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Grabar_retenciones( p_taxes_rec    IN  p_taxes_liq_rec_tab
                              , p_tax_line_num IN  NUMBER
                              , p_result       OUT BOOLEAN
                              , p_errmsg       OUT VARCHAR2)
  IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    C_API_NAME     VARCHAR2(40) := 'Grabar_Retenciones';
    l_monto        NUMBER;
    l_monto_ret    NUMBER;
    l_tax_rate     NUMBER;
    l_count        NUMBER:=0;
    l_envia_afip   VARCHAR2(1);
    l_visualizar   VARCHAR2(1);
    l_result       BOOLEAN;
    l_errmsg       VARCHAR2(2000);


  BEGIN

    Debug(C_API_NAME, 'Inicio');

    BEGIN

      SELECT COUNT(*)
        INTO l_count
        FROM XX_TCG_LIQUIDACION_RETENCIONES
       WHERE liquidacion_id = p_taxes_rec(1).liquidacion_id;

    EXCEPTION
      WHEN no_data_found THEN
        NULL;
      WHEN others THEN
        p_result:= FALSE;
        p_errmsg:= SQLERRM;
        RETURN;
    END;

    IF (l_count > 0) THEN

      BEGIN

        DELETE FROM XX_TCG_LIQUIDACION_RETENCIONES
         WHERE liquidacion_id = p_taxes_rec(1).liquidacion_id;

      EXCEPTION
        WHEN others THEN
          p_result:= FALSE;
          p_errmsg:= SQLERRM;
          RETURN;
      END;

    END IF;


    FOR l_index IN 1..p_tax_line_num LOOP

      l_monto    := ROUND(p_taxes_rec(l_index).monto,2);


      BEGIN

        Debug(C_API_NAME, 'l_monto: '||l_monto||' - tax_name: '||p_taxes_rec(l_index).tax_name||
                          ' - org_id: '||p_taxes_rec(l_index).org_id);

        Get_Importe_Retencion( p_tax_name   => p_taxes_rec(l_index).tax_name
                             , p_org_id     => p_taxes_rec(l_index).org_id
                             , p_monto      => l_monto
                             , x_rate       => l_tax_rate
                             , x_monto      => l_monto_ret
                             , x_result     => l_result
                             , x_errmsg     => l_errmsg);

        Debug(C_API_NAME, 'l_tax_rate: '||l_tax_rate||' -  l_monto_ret: '||l_monto_ret);

        IF (l_result) THEN
          l_monto_ret := ROUND(l_monto_ret * (-1), 2);
        ELSE
          p_result := FALSE;
          p_errmsg := l_errmsg;
          RETURN;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          p_result := FALSE;
          p_errmsg := 'Error al obtener el importe de retencion para tax name: '|| p_taxes_rec(l_index).tax_name
                      ||': '||SQLERRM;
          RETURN;
      END;


      IF (p_taxes_rec(l_index).awt_type_code IN ('OP_GRANOS', 'OP_ALGODON')
          OR p_taxes_rec(l_index).tax_description = 'IVA RG 2300 0%') THEN
        l_envia_afip := 'N';
      ELSE
        l_envia_afip := 'Y';
      END IF;

      IF (p_taxes_rec(l_index).tax_description != 'IVA RG 2300 0%') THEN
        l_visualizar := 'Y';
      ELSE
        l_visualizar := 'N';
      END IF;


      INSERT INTO XX_TCG_LIQUIDACION_RETENCIONES
        ( liquidacion_id
        , org_id
        , awt_type_code
        , description
        , tax_name
        , tax_description
        , monto
        , monto_retencion
        , envia_afip
        , visualizar
        )
      VALUES
        ( p_taxes_rec(l_index).liquidacion_id
        , p_taxes_rec(l_index).org_id
        , p_taxes_rec(l_index).awt_type_code
        , p_taxes_rec(l_index).description
        , p_taxes_rec(l_index).tax_name
        , p_taxes_rec(l_index).tax_description
        , l_monto
        , l_monto_ret
        , l_envia_afip
        , l_visualizar
        );

    END LOOP;

    COMMIT;

  EXCEPTION
    WHEN others THEN
      p_result:= FALSE;
      p_errmsg:= SQLERRM;

  END Grabar_retenciones;





/****************************************************************************
 *                                                                          *
 * Name    : Get_Importe_Retencion                                          *
 * Purpose : Retorna el calculo de la aplicacion de una retencion a un      *
 *           monto.                                                         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Importe_Retencion( p_tax_name   IN VARCHAR2
                                 , p_org_id     IN NUMBER
                                 , p_monto      IN NUMBER
                                 , x_rate      OUT NUMBER
                                 , x_monto     OUT NUMBER
                                 , x_result    OUT BOOLEAN
                                 , x_errmsg    OUT VARCHAR2)

  IS

    C_API_NAME                    VARCHAR2(40) := 'Get_Importe_Retencion';
    l_awt_rate_type               ap_tax_codes_all.awt_rate_type%TYPE;
    l_tax_rate                    NUMBER;
    l_minimum_taxable_base_amount NUMBER;

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    x_result := TRUE;

    -----------------------------------------------------
    -- Primero verifico que el impuesto sea por tasa fija
    -- (la linea no contempla otro tipo de calculo)
    -----------------------------------------------------
    SELECT atc.awt_rate_type
         , atcd.minimum_taxable_base_amount
      INTO l_awt_rate_type
         , l_minimum_taxable_base_amount
      FROM AP_TAX_CODES_ALL       atc
         , AP_TAX_CODES_ALL1_DFV atcd
     WHERE atc.org_id = p_org_id
       AND atc.name   = p_tax_name
       AND atc.rowid  = atcd.row_id;


    IF (l_awt_rate_type != 'F') THEN
      x_result := FALSE;
      x_errmsg := 'Tipo de calculo de retencion no contemplada para el impuesto: '|| p_tax_name;
      RETURN;
    END IF;


    BEGIN
      SELECT tax_rate
        INTO l_tax_rate
        FROM AP_AWT_TAX_RATES_ALL
       WHERE tax_name  = p_tax_name
         AND org_id    = p_org_id
         AND rate_type = 'STANDARD'
         AND TRUNC(SYSDATE) BETWEEN NVL(start_date,TRUNC(SYSDATE-1))
                            AND     NVL(end_date,TRUNC(SYSDATE+1));

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo tasa de retencion para el impuesto '||
                     p_tax_name ||': '|| SQLERRM;
        RETURN;
    END;

    IF (l_minimum_taxable_base_amount < p_monto) THEN

      x_monto := ROUND( p_monto * l_tax_rate / 100
                      , XX_ACO_UTIL_PK.Get_Precision(XX_ACO_UTIL_PK.Get_Functional_Currency(p_org_id)));


    ELSE
      x_monto := 0;

    END IF;

    Debug(C_API_NAME, 'x_monto: '||x_monto);

    x_rate := l_tax_rate;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado calculando monto de retencion para el impuesto: '
                  || p_tax_name ||': '||SQLERRM;

  END Get_Importe_Retencion;




/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AR                                           *
 * Purpose : Rutina para la ejecucion del concurrente de AR                 *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AR( p_org_id              IN NUMBER
                                 , p_batch_source_name   IN VARCHAR2
                                 , p_transaction_number  IN VARCHAR2
                                 , p_customer_class      IN VARCHAR2
                                 , x_result             OUT BOOLEAN
                                 , x_errmsg             OUT VARCHAR2)

  IS

    C_API_NAME          VARCHAR2(200) := 'Ejecutar_Interface_AR';
    l_request_id        NUMBER;
    l_batch_source_id   NUMBER;
    l_req_status        BOOLEAN;
    l_phase             VARCHAR2(30);
    l_status            VARCHAR2(30);
    l_dev_phase         VARCHAR2(30);
    l_dev_status        VARCHAR2(30);
    l_message           VARCHAR2(3000);
    l_resp_id           NUMBER;
    l_resp_appl_id      NUMBER;
    l_user_id           NUMBER;
    l_found             BOOLEAN;


    CURSOR c_environment IS
      SELECT fug.responsibility_application_id
           , fug.responsibility_id
           , fu.user_id
        FROM FND_USER_RESP_GROUPS_DIRECT fug
           , FND_USER                    fu
           , FND_RESPONSIBILITY          fr
           , FND_APPLICATION             fa
           , FND_PROFILE_OPTIONS         fpo
           , FND_PROFILE_OPTION_VALUES   fpov
       WHERE fug.user_id               = fu.user_id
         AND fu.user_name              = 'SCHEDULED_REQUESTS'
         AND fug.responsibility_id     = fr.responsibility_id
         AND fug.responsibility_application_id = fr.application_id
         AND fr.application_id         = fa.application_id
         AND fa.application_short_name = 'AR'
         AND fpo.profile_option_id     = fpov.profile_option_id
         AND fpo.profile_option_name   = 'ORG_ID'
         AND fpov.level_id             = 10003
         AND fr.responsibility_id      = fpov.level_value
         AND fpov.profile_option_value = TO_CHAR(p_org_id)
         AND (fr.responsibility_key    LIKE '%SUPERUSER'
             OR
             fr.responsibility_key     LIKE '%SUPER%USUARIO');

--    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    Debug(C_API_NAME, 'Inicio');

    MO_GLOBAL.Set_Policy_Context('S', p_org_id);


    x_result := TRUE;

    debug(C_API_NAME, 'Cursor c_environment.');
    OPEN c_environment;
    FETCH c_environment INTO l_resp_appl_id
                           , l_resp_id
                           , l_user_id;
    l_found := c_environment%FOUND;
    CLOSE c_environment;

    debug(C_API_NAME, 'l_resp_appl_id: '||l_resp_appl_id||' - l_resp_id: '||l_resp_id||' -  l_user_id: '||l_user_id);

    IF (NOT l_found) THEN
      x_result := FALSE;
      x_errmsg := 'No se puede inicializar el ambiente para ejecutar la interface de AR en la Unidad Operativa '||p_org_id;
      RETURN;
    END IF;


    debug(C_API_NAME, 'FND_GLOBAL.apps_initialize ');
    FND_GLOBAL.apps_initialize(resp_appl_id => l_resp_appl_id
                              ,resp_id      => l_resp_id
                              ,user_id      => l_user_id);

    -----------------------------
    -- Obtengo el batch_source_id
    -----------------------------
    BEGIN
      SELECT batch_source_id
        INTO l_batch_source_id
        FROM ra_batch_sources_all
       WHERE org_id = p_org_id
         AND name   = p_batch_source_name;

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo el identificador para el origen del batch: '|| p_batch_source_name;
        RETURN;
    END;



    debug(C_API_NAME, 'Submit Request');
    l_request_id :=  FND_REQUEST.Submit_Request (
                                 'JL'
                               , 'JLARRAIM'
                               , NULL
                               , NULL
                               , FALSE
                               , '1'
                               , p_org_id
                               , l_batch_source_id
                               , p_batch_source_name
                               , FND_DATE.date_to_canonical(TRUNC(SYSDATE))
                               , NULL, NULL, NULL, NULL, NULL
                               , NULL, NULL, NULL, NULL, NULL
                               , p_transaction_number
                               , p_transaction_number
                               , NULL, NULL, NULL, NULL
                               , NULL, NULL, NULL, NULL
                               , 'Y'
                               , NULL
                               );

    COMMIT;

    IF NVL(l_request_id, 0) = 0 THEN
      x_errmsg := 'No fue posible ejecutar el concurrente: Programa Principal Facturación '||
                  'Automática Cuentas a Cobrar de Argentina. '||
                  'Por favor ejecutelo manualmente';
      x_result := FALSE;
    END IF;

    debug(C_API_NAME, 'l_request_id: '||l_request_id);
    IF  (l_request_id>0) THEN

      LOOP

        LOOP

          l_req_status := FND_CONCURRENT.wait_for_request
                                        ( request_id      => l_request_id
                                        , interval        => 30
                                        , max_wait        => 300
                                        -- out arguments
                                        , phase           => l_phase
                                        , status          => l_status
                                        , dev_phase       => l_dev_phase
                                        , dev_status      => l_dev_status
                                        , message         => l_message
                                        );

        EXIT WHEN UPPER (l_phase) IN ('COMPLETED','FINALIZADO')
               OR UPPER (l_status) IN ('CANCELLED', 'ERROR', 'TERMINATED'
                                      ,'CANCELADO', 'FINALIZADO');


        END LOOP;

        IF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'ERROR' THEN
          x_errmsg := 'No fue posible ejecutar el concurrente: Programa Principal '||
                      'de Facturacion Automatica Cuentas a Cobrar de Argentina. '
                      ||l_message;
          x_result := FALSE;

        ELSIF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'NORMAL' THEN
          x_result := TRUE;
          COMMIT;
        END IF;

        IF (x_result) THEN
          BEGIN
            SELECT request_id
              INTO l_request_id
              FROM FND_CONC_REQ_SUMMARY_V
             WHERE parent_request_id = l_request_id;
          EXCEPTION
            WHEN OTHERS THEN
              l_request_id := -1;
          END;
        END IF;

        EXIT WHEN ((l_request_id=-1) OR (NOT x_result));

      END LOOP;

    END IF;

    debug(C_API_NAME, 'Finalizando Ejecutar Interface AR');
  EXCEPTION
    WHEN others THEN
      x_errmsg := 'Se produjo un error inesperado al intentar ejecutar la interface con AR.'||
                  ' Por favor intente manualmente. '|| SQLERRM;
      x_result := FALSE;

  END Ejecutar_Interface_AR;



/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AP                                           *
 * Purpose : Rutina para la ejecucion del concurrente de Open Interfcae     *
 *          en AP                                                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AP( p_org_id              IN NUMBER
                                 , x_result              OUT BOOLEAN
                                 , x_errmsg              OUT VARCHAR2)
  IS

    C_API_NAME          VARCHAR2(300) := 'Ejecutar_Interface_AP';
    l_request_id        NUMBER;
    l_req_status        BOOLEAN;
    l_phase             VARCHAR2(30);
    l_status            VARCHAR2(30);
    l_dev_phase         VARCHAR2(30);
    l_dev_status        VARCHAR2(30);
    l_message           VARCHAR2(3000);
    l_resp_appl_id      NUMBER;
    l_resp_id           NUMBER;
    l_user_id           NUMBER;
    l_found             BOOLEAN;



    CURSOR c_environment IS
      SELECT fug.responsibility_application_id
           , fug.responsibility_id
           , fu.user_id
        FROM FND_USER_RESP_GROUPS_DIRECT fug
           , FND_USER                    fu
           , FND_RESPONSIBILITY          fr
           , FND_APPLICATION             fa
           , FND_PROFILE_OPTIONS         fpo
           , FND_PROFILE_OPTION_VALUES   fpov
       WHERE fug.user_id               = fu.user_id
         AND fu.user_name              = 'SCHEDULED_REQUESTS'
       --  AND NVL(fug.end_date,SYSDATE+1) > SYSDATE
         AND fug.responsibility_id     = fr.responsibility_id
         AND fug.responsibility_application_id = fr.application_id
         AND fr.application_id         = fa.application_id
         AND fa.application_short_name IN ('JL', 'SQLAP')
         AND fpo.profile_option_id     = fpov.profile_option_id
         AND fpo.profile_option_name   = 'ORG_ID'
         AND fpov.level_id             = 10003
         AND fr.responsibility_id      = fpov.level_value
         AND fpov.profile_option_value = TO_CHAR(p_org_id)
         AND (fr.responsibility_key    LIKE '%_AP%SUPERUSER'
             OR
             fr.responsibility_key     LIKE '%SUPER%USUARIO');

    --PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    debug(C_API_NAME, 'Iniciando');

    OPEN c_environment;
    FETCH c_environment INTO l_resp_appl_id
                           , l_resp_id
                           , l_user_id;
    l_found := c_environment%FOUND;
    CLOSE c_environment;

    IF (NOT l_found) THEN
      x_result := FALSE;
      x_errmsg := 'No se puede inicializar el ambiente para ejecutar la interface de AP con org_id '||p_org_id;
      RETURN;
    END IF;

    FND_GLOBAL.apps_initialize(resp_appl_id => l_resp_appl_id
                              ,resp_id      => l_resp_id
                              ,user_id      => l_user_id);



    l_request_id :=  FND_REQUEST.Submit_Request( 'SQLAP'
                                               , 'APXIIMPT'
                                               , 'Importación de Interface Abierta de Cuentas a Pagar'
                                               , NULL
                                               , FALSE
                                               , p_org_id                       -- operating_unit
                                               , 'ACOPIO'                       -- source
                                               , NULL                           -- group
                                               , 'N/D'                          -- batch name
                                               , NULL                           -- hold name
                                               , NULL                           -- hold reason
                                               , NULL                           -- GL date
                                               , 'N'                            -- purge
                                               , 'N'                            -- trace switch
                                               , 'Y'                            -- debug switch
                                               , 'N'                            -- summarize report
                                               , '1000'                         -- commit batch size
                                               , l_user_id                      -- user id
                                               , '1'                            -- login id
                                               );

    COMMIT;

    IF (NVL(l_request_id,0)=0) THEN

      x_result := FALSE;
      x_errmsg := 'No fue posible finalizar correctamente la Importacion de Interface Abierta '
                  ||'de Cuentas a Pagar. Por favor, ejecutelo manualmente';

    ELSE

      Debug(C_API_NAME, 'Request id: '||l_request_id);

      LOOP

        l_req_status := FND_CONCURRENT.wait_for_request
                                   ( request_id      => l_request_id
                                   , interval        => 10
                                   , max_wait        => 60
                                   -- out arguments
                                   , phase           => l_phase
                                   , status          => l_status
                                   , dev_phase       => l_dev_phase
                                   , dev_status      => l_dev_status
                                   , message         => l_message
                                   );

      EXIT WHEN UPPER (l_phase) IN ('COMPLETED','FINALIZADO')
             OR UPPER (l_status) IN ('CANCELLED', 'ERROR', 'TERMINATED'
                                    ,'CANCELADO', 'FINALIZADO');


      END LOOP;

      IF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'ERROR' THEN

        x_errmsg := 'No fue posible ejecutar el concurrente Importacion de Interface Abierta '
                    ||'de Cuentas a Pagar. Detalle: '||l_message;
        x_result := FALSE;

      ELSIF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'NORMAL' THEN

        COMMIT;

        x_result := TRUE;

      END IF;

    END IF;

    Debug(C_API_NAME, 'l_phase: '||l_phase);
    Debug(C_API_NAME, 'l_status: '||l_status);

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Se produjo un error inesperado en la ejecucion de la Importacion de Interface Abierta '
                  ||'de Cuentas a Pagar: '||SQLERRM;

  END Ejecutar_Interface_AP;



  /***************************************************************************
  *                                                                          *
  * Name    : Valida_Stock_Disponible                                        *
  * Purpose : Verifica si aun existe stock para bajar en los subinventarios  *
  *           utilizados por la liquidacion de Granos                        *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Valida_Stock_Disponible( p_liquidacion_id IN NUMBER
                                   , p_revertir        IN BOOLEAN
                                   , x_result         OUT BOOLEAN
                                   , x_error_msg      OUT VARCHAR2)
  IS

    CURSOR cliq IS
      SELECT *
        FROM XX_TCG_LIQUIDACIONES
       WHERE liquidacion_id = p_liquidacion_id;


    CURSOR cCPs IS
      SELECT xtcp.numero_carta_porte
           , xtcp.operating_unit
           , xtcp.origen
           , xcpl.*
        FROM XX_TCG_CARTAS_PORTE_LIQUIDADAS  xcpl
           , (SELECT carta_porte_id
                   , numero_carta_porte
                   , org_id_to     operating_unit
                   , 'ACO' origen
                FROM XX_ACO_CARTAS_PORTE_B
               UNION
              SELECT carta_porte_id
                   , numero_carta_porte
                   , operating_unit
                   , 'TCG'
                FROM XX_TCG_CARTAS_PORTE_ALL)  xtcp
       WHERE xcpl.liquidacion_id      = p_liquidacion_id
         AND xcpl.carta_porte_id      = xtcp.carta_porte_id
         AND xcpl.cantidad_a_liquidar > 0;




    C_API_NAME          VARCHAR2(240) := 'Valida_Stock_Disponible';
    rLiq                XX_TCG_LIQUIDACIONES%ROWTYPE;
    rCPs                XX_TCG_CARTAS_PORTE_LIQUIDADAS%ROWTYPE;
    l_idx               NUMBER := 0;
    l_tabCP             tabCPs;
    l_result            BOOLEAN;
    eInv                EXCEPTION;
    l_subinv_quantity   NUMBER;
    l_locator_qty       NUMBER;
    l_ret_status        VARCHAR2(1);
    l_dummy             NUMBER;
    l_tStock            tStock;
    l_Total_Stock       tStock;
    l_tidx              NUMBER := 0;
    l_data_found        BOOLEAN;
    l_revisar_subinv    BOOLEAN;



  BEGIN

    Debug(C_API_NAME, 'Iniciando');

    x_result := TRUE;

    OPEN cLiq;
    FETCH cLiq INTO rLiq;
    CLOSE cLiq;

    -------------------------------------------------------------------------
    -- Si no es una Liquidacion de Terceros no se debe realizar movimientos
    -------------------------------------------------------------------------
    IF (rLiq.contrato_id IS NULL) THEN
      RETURN;
    END IF;


    ---------------------------------------------------
    --Se obtienen los pesos en los locator de cada CP
    ---------------------------------------------------
    FOR rCPs IN cCPs LOOP

      l_idx := l_idx + 1;

      l_tabCP(l_idx).carta_porte_id     := rCPs.carta_porte_id;
      l_tabCP(l_idx).numero_carta_porte := rCPs.numero_carta_porte;
      l_tabCP(l_idx).peso_a_liquidar    := rCPs.cantidad_a_liquidar;
      l_tabCP(l_idx).liquidacion_id     := rLiq.liquidacion_id;
      l_tabCP(l_idx).operating_unit     := rCPs.operating_unit;
      l_tabCP(l_idx).lot_number         := rLiq.lot_number;
      l_tabCP(l_idx).inventory_item_id  := rLiq.inventory_item_id;
      l_tabCP(l_idx).origen             := rCPs.origen;


      IF (l_tabCP(l_idx).origen = 'TCG') THEN

        Busca_Transacciones_Alta ( p_tabCP        => l_tabCP
                                 , p_index        => l_idx
                                 , p_revertir     => p_revertir
                                 , x_result       => l_result
                                 , x_error_msg    => x_error_msg);

        IF (NOT l_result) THEN
          RAISE eInv;
        END IF;

      ELSIF (l_tabCP(l_idx).origen = 'ACO') THEN

        Busca_Datos_en_CP ( p_tabCP        => l_tabCP
                          , p_index        => l_idx
                          , p_revertir     => p_revertir
                          , x_result       => l_result
                          , x_error_msg    => x_error_msg);

        IF (NOT l_result) THEN
          RAISE eInv;
        END IF;

      END IF;

      l_tStock(l_idx).organization_id := l_tabCP(l_idx).organization_id;
      l_tStock(l_idx).subinv_code     := l_tabCP(l_idx).subinventario;
      l_tStock(l_idx).locator_id      := l_tabCP(l_idx).locations(1).locator_id;
      l_tStock(l_idx).quantity        := l_tabCP(l_idx).locations(1).peso;
      l_tStock(l_idx).owning_org_id   := l_tabCP(l_idx).owning_org_id;

      Debug(C_API_NAME, 'l_idx: '||l_idx||' - Carta de porte: '||l_tabCP(l_idx).carta_porte_id ||
                        ' - Subinventario: '||l_tStock(l_idx).subinv_code||' - locator_id: '||
                        l_tStock(l_idx).locator_id ||' - Peso de la CP tomado: '||l_tStock(l_idx).quantity );

    END LOOP;



    -------------------------------------------
    --Se suman los pesos de cada locator
    -------------------------------------------
    Debug(C_API_NAME, 'Suma de pesos de cada locator');
    Debug(C_API_NAME, 'Inicio: '||l_tStock.FIRST||' - Fin: '||l_tStock.LAST);

    FOR l_idx IN l_tStock.FIRST..l_tStock.LAST LOOP

      IF (l_idx = 1) THEN

        l_tidx                                := 1;
        l_Total_Stock(l_tidx).organization_id := l_tStock(l_idx).organization_id;
        l_Total_Stock(l_tidx).subinv_code     := l_tStock(l_idx).subinv_code;
        l_Total_Stock(l_tidx).locator_id      := l_tStock(l_idx).locator_id;
        l_Total_Stock(l_tidx).quantity        := l_tStock(l_idx).quantity;
        l_Total_Stock(l_tidx).owning_org_id   := l_tStock(l_idx).owning_org_id;

      ELSE

        l_data_found := FALSE;

        FOR l_tidx IN l_Total_Stock.FIRST..l_Total_Stock.LAST LOOP

          IF (l_tStock(l_idx).subinv_code = l_Total_Stock(l_tidx).subinv_code AND
            l_tStock(l_idx).locator_id = l_Total_Stock(l_tidx).locator_id) THEN

            l_Total_Stock(l_tidx).quantity := l_Total_Stock(l_tidx).quantity + l_tStock(l_idx).quantity;
            l_data_found                   := TRUE;

          END IF;

        END LOOP;


        IF (NOT l_data_found) THEN

          l_tidx                                := l_Total_Stock.LAST + 1;
          l_Total_Stock(l_tidx).organization_id := l_tStock(l_idx).organization_id;
          l_Total_Stock(l_tidx).subinv_code     := l_tStock(l_idx).subinv_code;
          l_Total_Stock(l_tidx).locator_id      := l_tStock(l_idx).locator_id;
          l_Total_Stock(l_tidx).quantity        := l_tStock(l_idx).quantity;
          l_Total_Stock(l_tidx).owning_org_id   := l_tStock(l_idx).owning_org_id;  -- CR 1355 ABARACCA 10-07-2019

        END IF;

      END IF;


    END LOOP;



    --Se recorre la tabla con los pesos totales para cada locator y se confirma
    --que exista el stock necesario para descontar
    Debug(C_API_NAME, 'Se crea la tabla plsql con los Stock totales por locator');
    Debug(C_API_NAME, 'Inicio: '||l_Total_Stock.FIRST||' - Fin: '||l_Total_Stock.LAST);

    l_revisar_subinv := FALSE;

    FOR l_tidx IN l_Total_Stock.FIRST..l_Total_Stock.LAST LOOP

      ----------------------
      -- Stock en Locator
      ----------------------
      Debug(C_API_NAME, 'On Hand Subinventario: '||l_Total_Stock(l_tidx).subinv_code||
                        ' - locator id: '||l_Total_Stock(l_tidx).locator_id);

      IF (p_revertir) THEN

        l_locator_qty := Get_Cantidad_En_Mano ( p_inventory_item_id  => rLiq.inventory_item_id
                                              , p_organization_id    => l_Total_Stock(l_tidx).organization_id
                                              , p_subinventory_code  => l_Total_Stock(l_tidx).subinv_code
                                              , p_locator_id         => l_Total_Stock(l_tidx).locator_id
                                              , p_lot_number         => rLiq.lot_number
                                              , p_qty_type           => 'QTY_ATR'
                                              , x_return_status      => l_ret_status
                                              , x_msg_data           => x_error_msg
                                              , x_msg_count          => l_dummy);

        IF (l_ret_status != FND_API.g_ret_sts_success) THEN
          x_error_msg := 'Error al buscar el stock disponible en el subinventario '||l_Total_Stock(l_tidx).subinv_code||
                         ', locator id '||l_Total_Stock(l_tidx).locator_id--||' con owning org id '||  CR612 Revised Jul 2018
                         --l_Total_Stock(l_tidx).owning_org_id
                         ||', lote '||rLiq.lot_number||
                         ' e inv item id '||rLiq.inventory_item_id||' - '||x_error_msg;
          RAISE eInv;
        END IF;

      ELSE

        l_locator_qty := Get_Cantidad_En_Mano ( p_subinventario      => l_Total_Stock(l_tidx).subinv_code
                                              , p_locator_id         => l_Total_Stock(l_tidx).locator_id
                                              , p_owning_org_id      => l_Total_Stock(l_tidx).owning_org_id
                                              , p_lot_number         => rLiq.lot_number
                                              , p_inventory_item_id  => rLiq.inventory_item_id
                                              , x_result             => l_result
                                              , x_error_msg          => x_error_msg);


        IF (NOT l_result) THEN
          x_error_msg := 'Error al buscar el stock disponible en el subinventario '||l_Total_Stock(l_tidx).subinv_code||
                         ', locator id '||l_Total_Stock(l_tidx).locator_id
                         ||' con owning org id '||l_Total_Stock(l_tidx).owning_org_id -- CR612 Revised Jul 2018
                         ||', lote '||rLiq.lot_number||'T'||' e inv item id '||rLiq.inventory_item_id||' - '||x_error_msg;
          RAISE eInv;
        END IF;


      END IF;

      Debug(C_API_NAME,' Cantidad en Locator: '||l_locator_qty);

      IF (l_Total_Stock(l_tidx).quantity > l_locator_qty) THEN
        l_revisar_subinv := TRUE;
      END IF;

    END LOOP;


    -- Si el flag l_revisar_subinv = TRUE, entonces se debe revisar el stock por
    -- subinventario completo para el item y el lote de la CP, no solo por Locator
    IF (l_revisar_subinv) THEN

      l_Total_Stock.DELETE;

      -------------------------------------------
      --Se suman los pesos de cada Subinventario
      -------------------------------------------
      Debug(C_API_NAME, 'Suma de pesos de cada Subinventario');


      FOR l_idx IN l_tStock.FIRST..l_tStock.LAST LOOP

        IF (l_idx = 1) THEN

          l_tidx                                := 1;
          l_Total_Stock(l_tidx).organization_id := l_tStock(l_idx).organization_id;
          l_Total_Stock(l_tidx).subinv_code     := l_tStock(l_idx).subinv_code;
          l_Total_Stock(l_tidx).quantity        := l_tStock(l_idx).quantity;
          l_Total_Stock(l_tidx).owning_org_id   := l_tStock(l_idx).owning_org_id;

        ELSE

          l_data_found := FALSE;

          FOR l_tidx IN l_Total_Stock.FIRST..l_Total_Stock.LAST LOOP

            IF (l_tStock(l_idx).subinv_code = l_Total_Stock(l_tidx).subinv_code) THEN

              l_Total_Stock(l_tidx).quantity := l_Total_Stock(l_tidx).quantity + l_tStock(l_idx).quantity;
              l_data_found                   := TRUE;

            END IF;

          END LOOP;


          IF (NOT l_data_found) THEN

            l_tidx                                := l_Total_Stock.LAST + 1;
            l_Total_Stock(l_tidx).organization_id := l_tStock(l_idx).organization_id;
            l_Total_Stock(l_tidx).subinv_code     := l_tStock(l_idx).subinv_code;
            l_Total_Stock(l_tidx).quantity        := l_tStock(l_idx).quantity;
            l_Total_Stock(l_tidx).owning_org_id   := l_tStock(l_idx).owning_org_id;  -- CR 1355  ABARACCA 10-07-2019

          END IF;

        END IF;

      END LOOP;



      --Se recorre la tabla con los pesos totales para cada Subinventario y se confirma
      --que exista el stock necesario para descontar
      Debug(C_API_NAME, 'Se crea la tabla plsql con los Stock totales por Subinventario');
      Debug(C_API_NAME, 'Inicio: '||l_Total_Stock.FIRST||' - Fin: '||l_Total_Stock.LAST);


      FOR l_tidx IN l_Total_Stock.FIRST..l_Total_Stock.LAST LOOP

        --------------------------
        -- Stock en Subinventario
        -------------------------
        IF (p_revertir) THEN

          l_subinv_quantity := Get_Cantidad_En_Mano ( p_inventory_item_id  => rLiq.inventory_item_id
                                                    , p_organization_id    => l_Total_Stock(l_tidx).organization_id
                                                    , p_subinventory_code  => l_Total_Stock(l_tidx).subinv_code
                                                    , p_lot_number         => rLiq.lot_number
                                                    , p_qty_type           => 'QTY_ATR'
                                                    , x_return_status      => l_ret_status
                                                    , x_msg_data           => x_error_msg
                                                    , x_msg_count          => l_dummy);

          IF (l_ret_status != FND_API.g_ret_sts_success) THEN
            x_error_msg := 'Error al buscar el stock disponible en el subinventario '||l_Total_Stock(l_tidx).subinv_code||
                           --' con owning org id '||l_Total_Stock(l_tidx).owning_org_id||   CR612 Revised
                           ', lote '||rLiq.lot_number||
                           ' e inv item id '||rLiq.inventory_item_id||' - '||x_error_msg;
            RAISE eInv;
          END IF;

        ELSE

          l_subinv_quantity := Get_Cantidad_En_Mano ( p_subinventario      => l_Total_Stock(l_tidx).subinv_code
                                                    , p_owning_org_id      => l_Total_Stock(l_tidx).owning_org_id
                                                    , p_lot_number         => rLiq.lot_number
                                                    , p_inventory_item_id  => rLiq.inventory_item_id
                                                    , x_result             => l_result
                                                    , x_error_msg          => x_error_msg);


          IF (NOT l_result) THEN
            x_error_msg := 'Error al buscar el stock disponible en el subinventario '||l_Total_Stock(l_tidx).subinv_code||
                           ', lote '||rLiq.lot_number||'T, con owning org id '||l_Total_Stock(l_tidx).owning_org_id||
                           'e inv item id '||rLiq.inventory_item_id||' - '||x_error_msg;
            RAISE eInv;
          END IF;


        END IF;



        Debug(C_API_NAME, 'On Hand Subinventario: '||l_Total_Stock(l_tidx).subinv_code||
                            ' - cantidad disponible: '||l_subinv_quantity);


        IF (l_Total_Stock(l_tidx).quantity > l_subinv_quantity) THEN

          x_error_msg := 'No hay stock disponible para bajar en el lote ';

          IF (p_revertir) THEN
            x_error_msg := x_error_msg ||rLiq.lot_number;
          ELSE
            x_error_msg := x_error_msg ||rLiq.lot_number||'T';
          END IF;

          x_error_msg := x_error_msg||', Subinventario: '||l_Total_Stock(l_tidx).subinv_code;

          IF (p_revertir) THEN
            x_error_msg := x_error_msg ||', inventory item id: '||rLiq.inventory_item_id;
          ELSE
            x_error_msg := x_error_msg ||', owning org id: '||l_Total_Stock(l_tidx).owning_org_id||
                         ', inventory item id: '||rLiq.inventory_item_id;
          END IF;


          RAISE eInv;

        END IF;

      END LOOP;

    END IF;


  EXCEPTION
    WHEN eInv THEN
      x_result := FALSE;

    WHEN No_Data_Found THEN
      x_result := FALSE;

      IF (x_error_msg IS NULL) THEN
        x_error_msg := SQLERRM;
      END IF;


    WHEN OTHERS THEN
      x_result    := FALSE;
      x_error_msg := 'Error al validar stock disponible '||SQLERRM;

      IF (cCPs%ISOPEN) THEN
        CLOSE cCPs;
      END IF;

      IF (cLiq%ISOPEN) THEN
        CLOSE cLiq;
      END IF;


  END Valida_Stock_Disponible;



/****************************************************************************
 *                                                                          *
 * Name    : Get_Cantidad_En_Mano                                           *
 * Purpose : Funcion que devuelve los pesos On Hand de un determinado       *
 *           item, para un locator en particular o para un Subinventario    *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Cantidad_En_Mano ( p_subinventario     IN VARCHAR2
                                , p_locator_id        IN NUMBER DEFAULT NULL
                                , p_owning_org_id     IN NUMBER
                                , p_lot_number        IN VARCHAR2
                                , p_inventory_item_id IN NUMBER
                                , x_result           OUT BOOLEAN
                                , x_error_msg        OUT VARCHAR2) RETURN NUMBER

  IS
    C_API_NAME    VARCHAR2(100) := 'Get_Cantidad_En_Mano';
    l_onhand_qty  NUMBER;


  BEGIN

    Debug(C_API_NAME, 'Iniciando');

    x_result := TRUE;


    SELECT SUM(NVL(transaction_quantity,0))
      INTO l_onhand_qty
      FROM MTL_ONHAND_QUANTITIES_DETAIL
     WHERE subinventory_code      = p_subinventario
       AND (p_locator_id IS NULL OR
           (p_locator_id IS NOT NULL AND
              locator_id = p_locator_id))
       AND owning_organization_id = p_owning_org_id
       AND lot_number             = p_lot_number||'T'
       AND inventory_item_id      = p_inventory_item_id;

    Debug(C_API_NAME, 'On Hand Subinventario: '||p_subinventario||' - locator id: '||p_locator_id||
                      ' - Owning org id: '||p_owning_org_id||' - quantity: '||l_onhand_qty);

    RETURN NVL(l_onhand_qty, 0);

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;

      x_error_msg := 'Error al buscar el stock disponible en el subinventario '||p_subinventario||
                     ', locator id '||p_locator_id||' con owning org id '||p_owning_org_id||
                     ', lote '||p_lot_number||'T e inv item id '||p_inventory_item_id||' - '||SQLERRM;
      RETURN 0;

  END;


/****************************************************************************
 *                                                                          *
 * Name    : Get_Cantidad_En_Mano                                           *
 * Purpose : Funcion que devuelve los pesos On Hand de un determinado       *
 *           item, para un locator en particular o para un Subinventario    *
 *          Parametro                                                       *
 *            p_qty_type: Indica que tipo de cantidad se esta buscando      *
 *              Valores posibles                                            *
 *                      QTY_OH     - On Hand Quantity                       *
 *                      QTY_RES_OH - Reservable Quantity On Hand            *
 *                      QTY_RES    - Quantity Reserved                      *
 *                      QTY_SUG    - Quantity Suggested                     *
 *                      QTY_ATT    - Quantity Available To Transact         *
 *                      QTY_ATR    - Quantity Available To Reserve          *
 ****************************************************************************/
  FUNCTION Get_Cantidad_En_Mano ( p_inventory_item_id  IN NUMBER
                                , p_organization_id    IN NUMBER
                                , p_subinventory_code  IN VARCHAR2
                                , p_locator_id         IN NUMBER   DEFAULT NULL
                                , p_lot_number         IN VARCHAR2 DEFAULT NULL
                                , p_qty_type           IN VARCHAR2
                                , x_return_status     OUT VARCHAR2
                                , x_msg_data          OUT VARCHAR2
                                , x_msg_count         OUT NUMBER) RETURN NUMBER
  IS

    C_API_NAME     VARCHAR2(240) := 'Get_Cantidad_En_Mano API';
    l_lot_control  BOOLEAN := FALSE;
    l_quantity     NUMBER;
    l_qty_oh       NUMBER;
    l_qty_res_oh   NUMBER;
    l_qty_res      NUMBER;
    l_qty_sug      NUMBER;
    l_qty_att      NUMBER;
    l_qty_atr      NUMBER;


  BEGIN

    Debug(C_API_NAME, 'Iniciando');

    IF (p_locator_id IS NOT NULL OR
      p_lot_number IS NOT NULL) THEN

      l_lot_control := TRUE;

    END IF;

    INV_QUANTITY_TREE_GRP.clear_quantity_cache;


    INV_QUANTITY_TREE_PUB.QUERY_QUANTITIES
                         ( p_api_version_number  => 1.0,
                           p_init_msg_lst        => FND_API.g_false,
                           x_return_status       => x_return_status,
                           x_msg_count           => x_msg_count,
                           x_msg_data            => x_msg_data,
                           p_organization_id     => p_organization_id,
                           p_inventory_item_id   => p_inventory_item_id,
                           p_tree_mode           => INV_QUANTITY_TREE_PUB.g_transaction_mode,
                           p_onhand_source       => 3,
                           p_is_revision_control => FALSE,
                           p_is_lot_control      => l_lot_control,
                           p_is_serial_control   => FALSE,
                           p_revision            => NULL,
                           p_lot_number          => p_lot_number,
                           p_subinventory_code   => p_subinventory_code,
                           p_locator_id          => p_locator_id,
                           x_qoh                 => l_qty_oh,
                           x_rqoh                => l_qty_res_oh,
                           x_qr                  => l_qty_res,
                           x_qs                  => l_qty_sug,
                           x_att                 => l_qty_att,
                           x_atr                 => l_qty_atr);

    Debug(C_API_NAME, 'x_return_status: '||x_return_status);

    IF (x_return_status = FND_API.g_ret_sts_success) THEN

      IF (p_qty_type = 'QTY_OH') THEN

        l_quantity := l_qty_oh;

      ELSIF (p_qty_type = 'QTY_RES_OH') THEN

        l_quantity := l_qty_res_oh;

      ELSIF (p_qty_type = 'QTY_RES') THEN

        l_quantity := l_qty_res;

      ELSIF (p_qty_type = 'QTY_SUG') THEN

        l_quantity := l_qty_sug;

      ELSIF (p_qty_type = 'QTY_ATT') THEN

        l_quantity := l_qty_att;

      ELSIF (p_qty_type = 'QTY_ATR') THEN

        l_quantity := l_qty_atr;

      END IF;

      RETURN NVL(l_quantity, 0);

    ELSE

      RETURN 0;

    END IF;


  EXCEPTION
    WHEN OTHERS THEN
      x_return_status :=  FND_API.g_ret_sts_unexp_error;
      x_msg_data      := 'Error en Get_Cantidad_En_Mano API: '||SQLERRM;
      RETURN 0;

  END Get_Cantidad_En_Mano;




/****************************************************************************
 *                                                                          *
 * Name    : Busca_Transacciones_Alta                                       *
 * Purpose : Busca Transacciones con movimientos de Stock de Alta           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Busca_Transacciones_Alta ( p_tabCP        IN OUT tabCPs
                                     , p_index        IN NUMBER
                                     , p_revertir     IN BOOLEAN
                                     , x_result      OUT BOOLEAN
                                     , x_error_msg   OUT VARCHAR2)
  IS


    CURSOR cTrxId ( p_doc_id             NUMBER
                  , p_lot_number         VARCHAR2
                  , p_inventory_item_id  NUMBER
                  --, p_reason_code        VARCHAR2
                  , p_source_code        VARCHAR2
                  , p_trx_type_name      VARCHAR2
                  , p_movimiento         VARCHAR2
                  , p_cp_reference       VARCHAR2) IS
      SELECT MAX(mtt.transaction_id)
        FROM MTL_MATERIAL_TRANSACTIONS      mtt
           , MTL_MATERIAL_TRANSACTIONS_DFV  mttd
           --, MTL_TRANSACTION_REASONS        mtr
           , MTL_TRANSACTION_LOT_NUMBERS    mtl
           , MTL_TRANSACTION_TYPES          mtp
       WHERE mtt.rowid                  = mttd.row_id
         --AND mtr.reason_name            = p_reason_code
         --AND mttd.context_value         = TO_CHAR(mtr.reason_id)
         AND mttd.xx_aco_source_id      = p_doc_id
         AND mttd.xx_aco_source_code    = p_source_code
         AND mtt.transaction_id         = mtl.transaction_id
         AND mtl.lot_number             = p_lot_number
         AND mtt.inventory_item_id      = p_inventory_item_id
         AND mtt.transaction_type_id    = mtp.transaction_type_id
         AND mtp.transaction_type_name  = p_trx_type_name
         AND NVL(mtt.attribute4,'NULL') = p_movimiento
         AND (p_cp_reference IS NULL
             OR (mtt.waybill_airbill = p_cp_reference));


    CURSOR cMTLTrx ( p_transaction_id NUMBER) IS
      SELECT mtt.organization_id
           , mtt.subinventory_code
           , mtt.locator_id
           , mtt.owning_organization_id
           , mtt.transaction_quantity
           , mtt.transaction_uom
        FROM MTL_MATERIAL_TRANSACTIONS  mtt
       WHERE mtt.transaction_id = p_transaction_id;



    /*CURSOR cReason( p_oper_unit NUMBER) IS
      SELECT xtpc.inv_trx_alta_reason_code
        FROM XX_TCG_PARAMETROS_COMPANIA   xtpc
       WHERE xtpc.operating_unit = p_oper_unit;*/


    C_API_NAME       VARCHAR2(240) := 'Busca_Transacciones_Alta';
    i                NUMBER;
    l_reason_code    VARCHAR2(10);
    l_doc_id         NUMBER;
    l_lot_number     VARCHAR2(10);
    l_source_code    VARCHAR2(10);
    l_trx_type_name  VARCHAR2(240);
    l_trx_type_nrev  VARCHAR2(240);
    l_cp_reference   VARCHAR2(40);
    l_movimiento     VARCHAR2(10);
    l_trx            NUMBER;
    l_trx_id_rev     NUMBER;
    l_trx_uom        VARCHAR2(10);
    l_trx_id         NUMBER;
    eBuscaTrx        EXCEPTION;
    l_dummy          VARCHAR2(240);



  BEGIN

    Debug(C_API_NAME, 'Iniciando ');

    x_result := TRUE;
    i        := p_index;

    --Julio 2018 -- Se comenta dado que ahora en la cancelacion, el alta se hará con el
    -- codigo BAAC y la baja con el ALAC
    /*OPEN cReason (p_tabCP(i).operating_unit);
    FETCH cReason INTO l_reason_code;
    CLOSE cReason;

    Debug(C_API_NAME, 'l_reason_code: '||l_reason_code||' para organizacion '||p_tabCP(i).operating_unit);
    */

    IF (p_revertir) THEN

      l_doc_id        := p_tabCP(i).liquidacion_id;
      l_lot_number    := p_tabCP(i).lot_number;
      l_source_code   := 'XXTCGLIQ';
      l_trx_type_name := 'TCG Alta Liquidacion';
      l_cp_reference  := p_tabCP(i).numero_carta_porte;
      l_trx_type_nrev := 'TCG Baja Liquidacion';
      l_movimiento    := 'NULL';

    ELSE

      l_doc_id        := p_tabCP(i).carta_porte_id;
      l_lot_number    := p_tabCP(i).lot_number||'T';
      l_source_code   := 'XXTCGCP';
      l_trx_type_name := 'TCG Alta Carta de Porte';
      l_cp_reference  := NULL;
      l_trx_type_nrev := 'TCG Baja Carta de Porte';

    END IF;

    Debug(C_API_NAME, 'inv item id: '||p_tabCP(i).inventory_item_id);
    Debug(C_API_NAME, 'l_lot_number: '||l_lot_number);
    Debug(C_API_NAME, 'l_source_code: '||l_source_code);
    Debug(C_API_NAME, 'l_cp_reference: '||l_cp_reference);


    ----------------------------------------------------------------------------
    -- P_REVERTIR = FALSE: Se verifica que exista una linea de Alta de Inv para
    -- la CP dada con el lote XXXXT, que no haya sido revertida
    -- P_REVERTIR = TRUE: Se verifica que exista una linea de Alta de Inv para
    -- la liquidacion dada con el lote XXXX, que no haya sido revertida
    ----------------------------------------------------------------------------


    IF (l_source_code = 'XXTCGCP') THEN
      l_movimiento := 'R';
    END IF;

    OPEN cTrxId ( l_doc_id, l_lot_number, p_tabCP(i).inventory_item_id--, l_reason_code
                , l_source_code, l_trx_type_name, l_movimiento, l_cp_reference);
    FETCH cTrxId INTO l_trx_id;
    CLOSE cTrxId;


    IF (l_trx_id IS NULL) THEN

      IF (p_revertir) THEN
        x_error_msg := 'No existe un movimiento '||l_trx_type_name||' para la Liquidacion '||l_doc_id;
      ELSE
        x_error_msg := 'No existe un movimiento '||l_trx_type_name||' para la CP '||l_doc_id;
      END IF;

      RAISE eBuscaTrx;

    END IF;



    IF (l_source_code = 'XXTCGCP') THEN
      l_movimiento := 'RR';
    END IF;
    OPEN cTrxId ( l_doc_id, l_lot_number, p_tabCP(i).inventory_item_id--, l_reason_code
                , l_source_code, l_trx_type_nrev, l_movimiento, l_cp_reference);
    FETCH cTrxId INTO l_trx_id_rev;
    CLOSE cTrxId;


    --Se valida si la reversión es posterior al alta
    IF (NVL(l_trx_id_rev, -1) > l_trx_id) THEN

      IF (p_revertir) THEN
        x_error_msg := 'No existe un movimiento '||l_trx_type_name||' no revertido para la Liquidacion '||l_doc_id;
      ELSE
        x_error_msg := 'No existe un movimiento '||l_trx_type_name||' no revertido para la CP '||l_doc_id;
      END IF;

      RAISE eBuscaTrx;

    END IF;


    --Se obtienen los datos de la transaccion
    OPEN cMTLTrx (l_trx_id);
    FETCH cMTLTrx INTO p_tabCP(i).organization_id
                     , p_tabCP(i).subinventario
                     , p_tabCP(i).locations(1).locator_id
                     , p_tabCP(i).owning_org_id
                     , p_tabCP(i).locations(1).peso
                     , l_trx_uom;
    CLOSE cMTLTrx;


    Debug(C_API_NAME, 'Organizacion '||p_tabCP(i).organization_id||
                      ' - Subinventario '||p_tabCP(i).subinventario||
                      ' - Locator '||p_tabCP(i).locations(1).locator_id||
                      ' - Peso del Movimiento: '||p_tabCP(i).locations(1).peso);


    IF (p_tabCP(i).peso_a_liquidar < p_tabCP(i).locations(1).peso ) THEN

      p_tabCP(i).locations(1).peso := p_tabCP(i).peso_a_liquidar;

    END IF;


    Debug(C_API_NAME, 'Peso de la CP considerado: '||p_tabCP(i).locations(1).peso);


    -- Se necesita obtener el owning org id de la CP para el alta en la reversion
    IF (p_revertir) THEN

      l_doc_id        := p_tabCP(i).carta_porte_id;
      l_lot_number    := p_tabCP(i).lot_number||'T';
      l_source_code   := 'XXTCGCP';
      l_trx_type_name := 'TCG Alta Carta de Porte';
      l_cp_reference  := NULL;
      l_movimiento    := 'R';


      OPEN cTrxId ( l_doc_id, l_lot_number, p_tabCP(i).inventory_item_id--, l_reason_code
                  , l_source_code, l_trx_type_name, l_movimiento, l_cp_reference);
      FETCH cTrxId INTO l_trx_id;
      CLOSE cTrxId;


      OPEN cMTLTrx (l_trx_id);
      FETCH cMTLTrx INTO l_dummy
                       , l_dummy
                       , l_dummy
                       , p_tabCP(i).owning_org_id
                       , l_dummy
                       , l_dummy;
      CLOSE cMTLTrx;

    END IF;


  EXCEPTION
    WHEN eBuscaTrx THEN
      x_result := FALSE;

    WHEN OTHERS THEN
      x_result    := FALSE;
      x_error_msg := 'Error en Busca_Transacciones_Alta: '||SQLERRM;

      IF (cMTLTrx%ISOPEN) THEN
        CLOSE cMTLTrx;
      END IF;

  END Busca_Transacciones_Alta;




/****************************************************************************
 *                                                                          *
 * Name    : Busca_Datos_en_CP                                              *
 * Purpose : Busca datos de las Cartas de Porte de r11 para efectuar los    *
 *           movimientos de granos                                          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Busca_Datos_en_CP ( p_tabCP        IN OUT tabCPs
                              , p_index        IN NUMBER
                              , p_revertir     IN BOOLEAN
                              , x_result      OUT BOOLEAN
                              , x_error_msg   OUT VARCHAR2)
  IS

    i  NUMBER;

  BEGIN

    x_result := TRUE;
    i        := p_index;

    SELECT xacp.organization_id
         , xacp.subinventory_code
         , xacp.locator_id
         , pad.vendor_site_id
      INTO p_tabCP(i).organization_id
         , p_tabCP(i).subinventario
         , p_tabCP(i).locations(1).locator_id
         , p_tabCP(i).owning_org_id
      FROM XX_ACO_CARTAS_PORTE_B   xacp
         , XX_TCG_CONTRATOS_COMPRA xtcc
         , PO_ASL_DOCUMENTS_V      pad
         , PO_ASL_ATTRIBUTES       paa
         , AP_SUPPLIERS            aps
     WHERE xacp.contrato_id                 = xtcc.contrato_id
       AND xtcc.productor_id                = aps.party_id
       AND aps.vendor_id                    = pad.vendor_id
       AND pad.asl_id                       = paa.asl_id
       AND xacp.carta_porte_id              = p_tabCP(i).carta_porte_id
       AND pad.org_id                       = p_tabCP(i).operating_unit
       AND pad.item_id                      = xtcc.inventory_item_id
       AND pad.document_status              = 'APPROVED'
       AND paa.consigned_from_supplier_flag = 'Y';


    p_tabCP(i).locations(1).peso := p_tabCP(i).peso_a_liquidar;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      x_error_msg := 'No se encuentran en r11 los datos para la CP '||p_tabCP(i).carta_porte_id||
                     ' con Unidad Operativa: '||p_tabCP(i).operating_unit;
      x_result := FALSE;

    WHEN OTHERS THEN
      x_error_msg := 'Error al buscar los datos para la CP '||p_tabCP(i).carta_porte_id||' en r11';
      x_result := FALSE;

  END Busca_Datos_en_CP;




/****************************************************************************
 *                                                                          *
 * Name    : Distribuir_Stock_por_Locator                                   *
 * Purpose : Procedimiento que verifica si el movimiento se puede realizar  *
 *           en el locator que especifica la CP o debe usarse stock de otro *
 *          locator dentro del Subinventario                                *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Distribuir_Stock_por_Locator ( p_tabCP        IN OUT tabCPs
                                         , p_tabST        IN OUT tStock
                                         , p_revertir     IN BOOLEAN
                                         , x_result      OUT BOOLEAN
                                         , x_error_msg   OUT VARCHAR2)
  IS

    CURSOR cLoc ( p_subinv_code     VARCHAR2
                , p_organization_id NUMBER
                , p_inv_item_id     NUMBER
                , p_excl_loc_id     NUMBER) IS
      SELECT inventory_location_id
        FROM MTL_ITEM_LOCATIONS
       WHERE 1=1
         AND subinventory_code = p_subinv_code
         AND organization_id   = p_organization_id
         AND inventory_item_id = p_inv_item_id
         AND NVL(disable_date, SYSDATE+1) > SYSDATE
         AND UPPER(description) NOT LIKE '%GASOIL%'
         AND inventory_location_id != p_excl_loc_id;


    C_API_NAME     VARCHAR2(240) := 'Distribuir_Stock_por_Locator';
    l_stock_found  BOOLEAN;
    l_pos          NUMBER;
    l_qty_onhand   NUMBER;
    l_qty_resto    NUMBER;
    k              NUMBER;
    l_ret_status   VARCHAR2(1);
    l_dummy        NUMBER;
    l_result       BOOLEAN;



    PROCEDURE Busca_Stock( p_subinventario IN VARCHAR2
                         , p_locator_id    IN NUMBER
                         , p_tabST         IN tStock
                         , x_qty_onhand    IN OUT NUMBER
                         , x_stock_found   OUT BOOLEAN
                         , x_position      OUT NUMBER) IS
    BEGIN

      DEBUG(C_API_NAME, 'Busca Stock: p_tabST.COUNT = '||p_tabST.COUNT||' - p_subinventario = '
                         ||p_subinventario||' - p_locator_id = '||p_locator_id);

      IF (p_tabST.COUNT = 0) THEN
        x_stock_found := FALSE;
        RETURN;
      ELSE
        x_stock_found := FALSE;
      END IF;

      FOR j IN p_tabST.FIRST..p_tabST.LAST LOOP

        DEBUG(C_API_NAME, 'p_tabST('||j||').subinv_code = '||p_tabST(j).subinv_code||
                          ' - p_tabST('||j||').locator_id = '||p_tabST(j).locator_id||
                          ' - p_tabST('||j||').quantity = '||p_tabST(j).quantity);

        IF (p_subinventario = p_tabST(j).subinv_code AND
          p_locator_id = p_tabST(j).locator_id) THEN

          x_qty_onhand  := x_qty_onhand - p_tabST(j).quantity;
          x_stock_found := TRUE;
          x_position    := j;
          DEBUG(C_API_NAME, 'Stock encontrado');
        END IF;

      END LOOP;

    END Busca_Stock;


    PROCEDURE Actualiza_Tabla_Stock( p_subinventario IN VARCHAR2
                                   , p_locator_id    IN NUMBER
                                   , p_quantity      IN NUMBER
                                   , p_tabST         IN OUT tStock
                                   , p_stock_found   IN BOOLEAN
                                   , p_position      IN NUMBER) IS
      j NUMBER;

    BEGIN

      Debug(C_API_NAME, 'Actualiza_Tabla_Stock');

      IF (p_stock_found) THEN

        Debug(C_API_NAME, 'Stock encontrado');
        j := p_position;
        p_tabST(j).quantity := p_tabST(j).quantity + p_quantity;

      ELSE

        j := p_tabST.count + 1;

        p_tabST(j).subinv_code := p_subinventario;
        p_tabST(j).locator_id  := p_locator_id;
        p_tabST(j).quantity    := p_quantity;

        Debug(C_API_NAME, 'Stock no encontrado, se agrega en lugar '||j);
      END IF;

    END;


  BEGIN

    Debug(C_API_NAME, 'Iniciando');

    x_result    := TRUE;
    x_error_msg := NULL;

    FOR i IN p_tabCP.FIRST..p_tabCP.LAST LOOP

      IF (p_tabCP(i).locations(1).peso IS NULL) THEN
        x_result := FALSE;
        x_error_msg := 'La cp '||p_tabCP(i).numero_carta_porte||' no tiene asignado el peso' ;
        RETURN;
      END IF;

      -- Cantidad disponible para el locator en tabla OnHand
      IF (p_revertir) THEN

        l_qty_onhand := Get_Cantidad_En_Mano ( p_inventory_item_id  => p_tabCP(i).inventory_item_id
                                             , p_organization_id    => p_tabCP(i).organization_id
                                             , p_subinventory_code  => p_tabCP(i).subinventario
                                             , p_locator_id         => p_tabCP(i).locations(1).locator_id
                                             , p_lot_number         => p_tabCP(i).lot_number
                                             , p_qty_type           => 'QTY_ATR'
                                             , x_return_status      => l_ret_status
                                             , x_msg_data           => x_error_msg
                                             , x_msg_count          => l_dummy);

        IF (l_ret_status != FND_API.g_ret_sts_success) THEN
          x_result := FALSE;
          RETURN;
        END IF;

      ELSE

        l_qty_onhand := Get_Cantidad_En_Mano ( p_subinventario      => p_tabCP(i).subinventario
                                             , p_locator_id         => p_tabCP(i).locations(1).locator_id
                                             , p_owning_org_id      => p_tabCP(i).owning_org_id
                                             , p_lot_number         => p_tabCP(i).lot_number
                                             , p_inventory_item_id  => p_tabCP(i).inventory_item_id
                                             , x_result             => l_result
                                             , x_error_msg          => x_error_msg);

        IF (NOT l_result) THEN
          x_result := FALSE;
          RETURN;
        END IF;

      END IF;

      Debug(C_API_NAME, 'p_tabCP('||i||').locations(1).locator_id = '||p_tabCP(i).locations(1).locator_id
                          ||' Peso Disponible = '||l_qty_onhand);

      IF (l_qty_onhand > 0) THEN
        --Se verifica si parte de esta cantidad disponible ya fue considerada para otra CP
        --de la liquidacion
        Busca_Stock( p_subinventario => p_tabCP(i).subinventario
                   , p_locator_id    => p_tabCP(i).locations(1).locator_id
                   , p_tabST         => p_tabST
                   , x_qty_onhand    => l_qty_onhand
                   , x_stock_found   => l_stock_found
                   , x_position      => l_pos);
      END IF;


      IF (p_tabCP(i).locations(1).peso <= l_qty_onhand) THEN

        Debug(C_API_NAME, 'Peso <= l_qty_onhand');

        Actualiza_Tabla_Stock( p_subinventario => p_tabCP(i).subinventario
                             , p_locator_id    => p_tabCP(i).locations(1).locator_id
                             , p_quantity      => p_tabCP(i).locations(1).peso
                             , p_tabST         => p_tabST
                             , p_stock_found   => l_stock_found
                             , p_position      => l_pos);


      ELSE  --Cuando el peso a liquidar de la CP es mayor al disponible en el locator

        IF (l_qty_onhand > 0) THEN

          l_qty_resto := p_tabCP(i).locations(1).peso - l_qty_onhand;

          p_tabCP(i).locations(1).peso := l_qty_onhand;

          Debug(C_API_NAME, 'Peso > l_qty_onhand - l_qty_resto: '||l_qty_resto||
                            ' p_tabCP('||i||').locations(1).peso: '||p_tabCP(i).locations(1).peso);

          Actualiza_Tabla_Stock( p_subinventario => p_tabCP(i).subinventario
                               , p_locator_id    => p_tabCP(i).locations(1).locator_id
                               , p_quantity      => p_tabCP(i).locations(1).peso
                               , p_tabST         => p_tabST
                               , p_stock_found   => l_stock_found
                               , p_position      => l_pos);

          --Ahora se debe distribuir el peso restante en otros locators del Subinventario
          k := 1;

        ELSE
          l_qty_resto := p_tabCP(i).locations(1).peso;
          k := 0;

        END IF;

        FOR rLoc IN cLoc ( p_subinv_code     => p_tabCP(i).subinventario
                         , p_organization_id => p_tabCP(i).organization_id
                         , p_inv_item_id     => p_tabCP(i).inventory_item_id
                         , p_excl_loc_id     => p_tabCP(i).locations(1).locator_id) LOOP

          IF (p_revertir) THEN

            l_qty_onhand := Get_Cantidad_En_Mano ( p_inventory_item_id  => p_tabCP(i).inventory_item_id
                                                 , p_organization_id    => p_tabCP(i).organization_id
                                                 , p_subinventory_code  => p_tabCP(i).subinventario
                                                 , p_locator_id         => rLoc.inventory_location_id
                                                 , p_lot_number         => p_tabCP(i).lot_number
                                                 , p_qty_type           => 'QTY_ATR'
                                                 , x_return_status      => l_ret_status
                                                 , x_msg_data           => x_error_msg
                                                 , x_msg_count          => l_dummy);

            IF (l_ret_status != FND_API.g_ret_sts_success) THEN
              x_result := FALSE;
              Debug(C_API_NAME, 'Error en Location_id: '||rLoc.inventory_location_id||' - '||x_error_msg);
              RETURN;
            END IF;

          ELSE

            l_qty_onhand := Get_Cantidad_En_Mano ( p_subinventario      => p_tabCP(i).subinventario
                                                 , p_locator_id         => rLoc.inventory_location_id
                                                 , p_owning_org_id      => p_tabCP(i).owning_org_id
                                                 , p_lot_number         => p_tabCP(i).lot_number
                                                 , p_inventory_item_id  => p_tabCP(i).inventory_item_id
                                                 , x_result             => l_result
                                                 , x_error_msg          => x_error_msg);

            IF (NOT l_result) THEN
              x_result := FALSE;
              Debug(C_API_NAME, 'Error en Location_id: '||rLoc.inventory_location_id||' - '||x_error_msg);
              RETURN;
            END IF;

          END IF;

          Debug(C_API_NAME, 'Location_id: '||rLoc.inventory_location_id||' - l_qty_onhand: '||l_qty_onhand);

          IF (l_qty_onhand > 0 AND l_qty_resto > 0) THEN

            Busca_Stock( p_subinventario => p_tabCP(i).subinventario
                       , p_locator_id    => rLoc.inventory_location_id
                       , p_tabST         => p_tabST
                       , x_qty_onhand    => l_qty_onhand
                       , x_stock_found   => l_stock_found
                       , x_position      => l_pos);


            k := k + 1;
            p_tabCP(i).locations(k).locator_id := rLoc.inventory_location_id;

            Debug(C_API_NAME, 'p_tabCP('||i||').locations('||k||').locator_id: '||p_tabCP(i).locations(k).locator_id);

            IF (l_qty_resto <= l_qty_onhand) THEN

              p_tabCP(i).locations(k).peso := l_qty_resto;

              l_qty_resto := -1;

            ELSE

              l_qty_resto := l_qty_resto - l_qty_onhand;

              p_tabCP(i).locations(k).peso := l_qty_onhand;

            END IF;

            Debug(C_API_NAME, 'l_qty_resto: '||l_qty_resto);

            Actualiza_Tabla_Stock( p_subinventario => p_tabCP(i).subinventario
                                 , p_locator_id    => rLoc.inventory_location_id
                                 , p_quantity      => p_tabCP(i).locations(k).peso
                                 , p_tabST         => p_tabST
                                 , p_stock_found   => l_stock_found
                                 , p_position      => l_pos);

          ELSIF (l_qty_resto < 0) THEN
            EXIT;

          END IF;

        END LOOP;

      END IF;

    END LOOP;

    Debug(C_API_NAME, 'Fin');

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;

      IF (x_error_msg IS NULL) THEN
        x_error_msg := 'Error en Distribuir_Stock_por_Locator '||SQLERRM;
      END IF;

  END Distribuir_Stock_por_Locator;





  PROCEDURE Crear_Lineas_Interfaz ( p_tabCP        IN OUT tabCPs
                                  , p_index        IN NUMBER
                                  , p_movimiento   IN VARCHAR2
                                  , p_revertir     IN BOOLEAN
                                  , x_result      OUT BOOLEAN
                                  , x_error_msg   OUT VARCHAR2)
  IS

    C_API_NAME           VARCHAR2(240) := 'Crear_Lineas_Interfaz';
    rMTI                 MTL_TRANSACTIONS_INTERFACE%ROWTYPE;
    rMTLI                MTL_TRANSACTION_LOTS_INTERFACE%ROWTYPE;
    l_trx_int_id         NUMBER;
    l_idx                NUMBER := p_index;
    l_trx_type_id        NUMBER;
    l_trx_source_type_id NUMBER;
    l_trx_action_id      NUMBER;
    l_reason_id          NUMBER;
    l_distr_acct         NUMBER;
    l_peso               NUMBER;



    CURSOR cTTrx (p_movimiento IN VARCHAR2) IS
      SELECT mtt.transaction_type_id
           , mst.transaction_source_type_id
           , mtt.transaction_action_id
        FROM MTL_TXN_SOURCE_TYPES  mst
           , MTL_TRANSACTION_TYPES mtt
       WHERE 1=1
         AND mtt.transaction_source_type_id          = mst.transaction_source_type_id
         AND mst.transaction_source_type_name        = 'Inventory'
         AND TRUNC(NVL(mtt.disable_date, SYSDATE+1)) > TRUNC(SYSDATE)
         AND (( p_movimiento = 'ALTA' AND
              mtt.transaction_type_name = 'TCG Alta Liquidacion')
              OR (p_movimiento = 'BAJA' AND
              mtt.transaction_type_name = 'TCG Baja Liquidacion'));



    CURSOR cReason ( p_movimiento     VARCHAR2
                   , p_operating_unit NUMBER
                   , p_revertir       VARCHAR2) IS
      SELECT mtr.reason_id
        FROM XX_TCG_PARAMETROS_COMPANIA   xtpc
           , MTL_TRANSACTION_REASONS      mtr
       WHERE xtpc.operating_unit = p_operating_unit
         AND (((p_revertir = 'FALSE')
              AND mtr.reason_name = DECODE(p_movimiento, 'ALTA', xtpc.inv_trx_alta_reason_code
                                                       , 'BAJA', xtpc.inv_trx_baja_reason_code))
             OR
             (p_revertir = 'TRUE'
              AND mtr.reason_name = DECODE(p_movimiento, 'ALTA', xtpc.inv_trx_baja_reason_code
                                                       , 'BAJA', xtpc.inv_trx_alta_reason_code)));



    CURSOR cAcct (p_organization_id NUMBER) IS
      SELECT distribution_account
        FROM MTL_GENERIC_DISPOSITIONS
       WHERE organization_id = p_organization_id;


    l_revertir  VARCHAR2(10) := CASE WHEN p_revertir THEN 'TRUE' ELSE 'FALSE' END;

  BEGIN

    Debug(C_API_NAME, 'Iniciando');

    x_result := TRUE;

    FOR i IN p_tabCP(l_idx).locations.FIRST..p_tabCP(l_idx).locations.LAST LOOP

      Debug(C_API_NAME, 'p_tabCP('||l_idx||').locations('||i||').locator_id: '||p_tabCP(l_idx).locations(i).locator_id);
      Debug(C_API_NAME,'p_tabCP('||l_idx||').locations('||i||').peso: '||p_tabCP(l_idx).locations(i).peso);

      rMTI  := NULL;
      rMTLI := NULL;

      SELECT MTL_MATERIAL_TRANSACTIONS_S.nextval
        INTO l_trx_int_id
        FROM DUAL;


      OPEN cTTrx (p_movimiento);
      FETCH cTTrx INTO l_trx_type_id
                     , l_trx_source_type_id
                     , l_trx_action_id;
      CLOSE cTTrx;


      OPEN cReason ( p_movimiento
                   , p_tabCP(l_idx).operating_unit
                   , l_revertir);
      FETCH cReason INTO l_reason_id;
      CLOSE cReason;


      OPEN cAcct (p_tabCP(l_idx).organization_id);
      FETCH cAcct INTO l_distr_acct;
      CLOSE cAcct;



      --MTL_TRANSACTIONS_INTERFACE
      rMTI.transaction_interface_id   := l_trx_int_id;
      rMTI.source_line_id             := -1;
      rMTI.source_header_id           := -1;
      --
      rMTI.source_code                := 'Inventory';
      rMTI.transaction_source_type_id := l_trx_source_type_id;
      rMTI.transaction_type_id        := l_trx_type_id;
      rMTI.transaction_action_id      := l_trx_action_id;
      rMTI.reason_id                  := l_reason_id;
      rMTI.attribute_category         := l_reason_id;
      rMTI.attribute2                 := p_tabCP(l_idx).liquidacion_id;
      rMTI.attribute3                 := 'XXTCGLIQ';



      rMTI.waybill_airbill            := p_tabCP(l_idx).numero_carta_porte;
      --
      rMTI.transaction_mode           := 3; --Background
      rMTI.lock_flag                  := 2; --NO
      rMTI.process_flag               := 1; --YES
      --
      rMTI.transaction_uom            := 'KG';
      rMTI.transaction_date           := SYSDATE;
      rMTI.inventory_item_id          := p_tabCP(l_idx).inventory_item_id;

      IF (p_movimiento = 'ALTA') THEN
        l_peso := ABS(p_tabCP(l_idx).locations(i).peso);
      ELSIF (p_movimiento = 'BAJA') THEN
        l_peso := ABS(p_tabCP(l_idx).locations(i).peso) * -1;
      END IF;

      rMTI.transaction_quantity       := l_peso;
      --
      --Desde
      rMTI.organization_id            := p_tabCP(l_idx).organization_id;
      rMTI.subinventory_code          := p_tabCP(l_idx).subinventario;
      rMTI.locator_id                 := p_tabCP(l_idx).locations(i).locator_id;
      rMTI.distribution_account_id    := l_distr_acct;


      IF ((p_revertir AND p_movimiento = 'ALTA')
        OR (NOT p_revertir AND p_movimiento = 'BAJA')) THEN

        rMTLI.lot_number                := p_tabCP(l_idx).lot_number||'T';
        rMTI.owning_organization_id     := p_tabCP(l_idx).owning_org_id;
        rMTI.owning_tp_type             := 1;
        rMTI.xfr_owning_organization_id := p_tabCP(l_idx).organization_id;

      ELSE
        rMTI.owning_organization_id     := p_tabCP(l_idx).organization_id;
        rMTLI.lot_number                := p_tabCP(l_idx).lot_number;

      END IF;

      IF (p_revertir) THEN
        DEBUG(C_API_NAME, 'Revertir = TRUE - CP: '||p_tabCP(l_idx).carta_porte_id||' - movimiento: '||p_movimiento||
                          ' - Owning org id: '||rMTI.owning_organization_id||' - Cantidad: '||rMTI.transaction_quantity );
      ELSE
        DEBUG(C_API_NAME, 'Revertir = FALSE - CP: '||p_tabCP(l_idx).carta_porte_id||' - movimiento: '||p_movimiento||
                          ' - Owning org id: '||rMTI.owning_organization_id||' - Cantidad: '||rMTI.transaction_quantity );
      END IF;

      rMTI.created_by                 := FND_GLOBAL.user_id;
      rMTI.creation_date              := SYSDATE;
      rMTI.last_updated_by            := FND_GLOBAL.user_id;
      rMTI.last_update_date           := SYSDATE;


      --MTL_TRANSACTION_LOTS_INTERFACE
      rMTLI.transaction_interface_id  := l_trx_int_id;
      rMTLI.source_line_id            := -1;


      rMTLI.transaction_quantity      := l_peso;

      rMTLI.created_by                := FND_GLOBAL.user_id;
      rMTLI.creation_date             := SYSDATE;
      rMTLI.last_updated_by           := FND_GLOBAL.user_id;
      rMTLI.last_update_date          := SYSDATE;


      INSERT INTO MTL_TRANSACTIONS_INTERFACE VALUES rMTI;

      INSERT INTO MTL_TRANSACTION_LOTS_INTERFACE VALUES rMTLI;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      x_result    := FALSE;
      x_error_msg := 'Error insertando en la interfaz: '||SQLERRM;


  END Crear_Lineas_Interfaz;



 /***************************************************************************
 *                                                                          *
 * Name    : Movimiento_Stock_Liq_Granos                                    *
 * Purpose : Efectua el alta y baja de stock necesarios para el cierre de   *
 *          la liquidacion de Granos                                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Movimiento_Stock_Liq_Granos ( p_liquidacion_id  IN NUMBER
                                        , p_revertir        IN BOOLEAN
                                        , x_result          OUT BOOLEAN
                                        , x_error_msg       OUT VARCHAR2)
  IS

    CURSOR cCPs IS
      SELECT xtl.lot_number
           , xtl.inventory_item_id
           , xtcp.operating_unit
           , xtcp.numero_carta_porte
           , xtcp.origen
           , xcpl.*
        FROM XX_TCG_CARTAS_PORTE_LIQUIDADAS xcpl
           , XX_TCG_LIQUIDACIONES           xtl
           , (SELECT carta_porte_id
                   , numero_carta_porte
                   , org_id_to     operating_unit
                   , 'ACO' origen
                FROM XX_ACO_CARTAS_PORTE_B
               UNION
              SELECT carta_porte_id
                   , numero_carta_porte
                   , operating_unit
                   , 'TCG'
                FROM XX_TCG_CARTAS_PORTE_ALL)   xtcp
       WHERE xtl.liquidacion_id       = p_liquidacion_id
         AND xtl.liquidacion_id       = xcpl.liquidacion_id
         AND xcpl.carta_porte_id      = xtcp.carta_porte_id
         AND xcpl.cantidad_a_liquidar > 0
         ;

    C_API_NAME  VARCHAR2(240) := 'Movimiento_Stock_Liq_Granos';
    l_tabCP     tabCPs;
    l_index     NUMBER := 0;
    l_result    BOOLEAN;
    l_errmsg    VARCHAR2(3000);
    l_peso_trx  NUMBER;
    l_tStock    tStock;



  BEGIN

    Debug(C_API_NAME, 'Iniciando');

    x_result := TRUE;

    SAVEPOINT Mov_Stock_Granos_SVP;

  -- revertir FALSE
  --    TCG Baja Liquidacion   BAAC   Descuenta del lote ####T en todos los location id disponibles y necesarios del Owning de la CP
  --    TCG Alta Liquidacion   ALAC   Suma en el lote ####     en cada location que se bajo -- SUBIR SIN OWNER

  -- revertir TRUE
  --    TCG Baja Liquidacion  BAAC   Descuenta del lote ####  en todos los location id disponibles y necesarios
  --    TCG Alta Liquidacion  ALAC   Suma en el lote ####T   en cada location que se bajo -- determinar el OWNER de la CP
  --
  -- Julio 2018 - Se solicita que en la reversion, la baja se realice con código ALAC y la alta con código BAAC


    -- Agregado CR612 Revised Jul 2018
    IF (NOT p_revertir) THEN
    --
      Valida_Stock_Disponible( p_liquidacion_id => p_liquidacion_id
                             , p_revertir       => p_revertir
                             , x_result         => l_result
                             , x_error_msg      => l_errmsg);

      IF (NOT l_result) THEN
        x_result    := FALSE;
        x_error_msg := l_errmsg;
        RETURN;
      END IF;

    END IF;


    FOR rCPs IN cCPs LOOP

      Debug(C_API_NAME, 'Carta Porte: '||rCPs.numero_carta_porte);

      l_index := l_index + 1;

      l_tabCP(l_index).carta_porte_id     := rCPs.carta_porte_id;
      l_tabCP(l_index).numero_carta_porte := rCPs.numero_carta_porte;
      l_tabCP(l_index).operating_unit     := rCPs.operating_unit;
      l_tabCP(l_index).liquidacion_id     := p_liquidacion_id;
      l_tabCP(l_index).peso_a_liquidar    := rCPs.cantidad_a_liquidar;
      l_tabCP(l_index).lot_number         := rCPs.lot_number;
      l_tabCP(l_index).inventory_item_id  := rCPs.inventory_item_id;
      l_tabCP(l_index).origen             := rCPs.origen;


      IF (l_tabCP(l_index).origen = 'TCG') THEN

        Busca_Transacciones_Alta ( p_tabCP      => l_tabCP
                                 , p_index      => l_index
                                 , p_revertir   => p_revertir
                                 , x_result     => l_result
                                 , x_error_msg  => l_errmsg);

        IF (NOT l_result) THEN
          x_result    := FALSE;
          x_error_msg := l_errmsg;
          RETURN;
        END IF;

      ELSIF (l_tabCP(l_index).origen = 'ACO') THEN

        Busca_Datos_en_CP ( p_tabCP      => l_tabCP
                          , p_index      => l_index
                          , p_revertir   => p_revertir
                          , x_result     => l_result
                          , x_error_msg  => l_errmsg);

        IF (NOT l_result) THEN
          x_result    := FALSE;
          x_error_msg := l_errmsg;
          RETURN;
        END IF;

      END IF;

    END LOOP;


    Distribuir_Stock_por_Locator ( p_tabCP      => l_tabCP
                                 , p_tabST      => l_tStock
                                 , p_revertir   => p_revertir
                                 , x_result     => l_result
                                 , x_error_msg  => l_errmsg);

    IF (NOT l_result) THEN
      x_result    := FALSE;
      x_error_msg := l_errmsg;
      RETURN;
    END IF;


    FOR l_index IN l_tabCP.FIRST..l_tabCP.LAST LOOP


      Crear_Lineas_Interfaz ( p_tabCP      => l_tabCP
                            , p_index      => l_index
                            , p_revertir   => p_revertir
                            , p_movimiento => 'BAJA'
                            , x_result     => l_result
                            , x_error_msg  => l_errmsg);

      IF (NOT l_result) THEN
        x_result    := FALSE;
        x_error_msg := l_errmsg;
        ROLLBACK TO Mov_Stock_Granos_SVP;
        RETURN;
      END IF;



      Crear_Lineas_Interfaz ( p_tabCP      => l_tabCP
                            , p_index      => l_index
                            , p_revertir   => p_revertir
                            , p_movimiento => 'ALTA'
                            , x_result     => l_result
                            , x_error_msg  => l_errmsg);

      IF (NOT l_result) THEN
        x_result    := FALSE;
        x_error_msg := l_errmsg;
        ROLLBACK TO Mov_Stock_Granos_SVP;
        RETURN;
      END IF;

    END LOOP;


    Debug(C_API_NAME, 'Fin Movimiento_Stock_Liq_Granos');

  EXCEPTION
    WHEN OTHERS THEN
      x_result    := FALSE;
      x_error_msg := 'Error al intentar realizar el movimiento de Stock de Granos. '||SQLERRM;
      ROLLBACK TO Mov_Stock_Granos_SVP;

  END Movimiento_Stock_Liq_Granos;




/****************************************************************************
 *                                                                          *
 * Name    : Determinar_Procesos_a_Realizar                                 *
 * Purpose : Procedimiento que identifica que facturas deben realizarse     *
 *          y si corresponde generar el movimiento de Stock, para el caso   *
 *          en que se este reprocesando el txt recibido por PlanexWare      *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Determinar_Procesos_a_Realizar ( p_liquidacion_id  IN NUMBER
                                           , p_revertir        IN BOOLEAN
                                           , p_factura_AP      OUT BOOLEAN
                                           , p_factura_AR      OUT BOOLEAN
                                           , p_mov_stock       OUT BOOLEAN
                                           , p_result          OUT BOOLEAN
                                           , p_error_msg       OUT VARCHAR2
                                           )
  IS

    C_API_NAME     VARCHAR2(240) := 'Determinar_Procesos_a_Realizar';
    rLiq           XX_TCG_LIQUIDACIONES%ROWTYPE;
    l_tipo_trx     VARCHAR2(5);
    l_cant_ap      NUMBER;
    l_cant_int_ap  NUMBER;
    l_invoice_id   NUMBER;
    l_cant_ar      NUMBER;
    l_cant_int_ar  NUMBER;
    l_cust_trx_id  NUMBER;
    l_cant_cp      NUMBER;
    l_cant_baja    NUMBER;
    l_cant_alta    NUMBER;
    l_cant_mov     NUMBER;
    l_lot_alta     VARCHAR2(30);
    l_lot_baja     VARCHAR2(30);



    CURSOR c_liq IS
      SELECT *
        FROM XX_TCG_LIQUIDACIONES
       WHERE liquidacion_id = p_liquidacion_id;


  BEGIN

    Debug(C_API_NAME, 'Inicio');

    p_result := TRUE;


    OPEN c_liq;
    FETCH c_liq INTO rLiq;
    CLOSE c_liq;


    IF (p_revertir) THEN
      rLiq.numero_liquidacion := rLiq.numero_liquidacion||'*';
    END IF;



    --=====================================================
    -- Se valida si ya fue ingresada la factura en AP
    --=====================================================
    Debug(C_API_NAME, 'Validacion de AP');

    SELECT count(*)
      INTO l_cant_ap
      FROM AP_INVOICES_ALL
     WHERE invoice_num  = rLiq.numero_liquidacion
       --AND invoice_date = rLiq.fecha_liquidacion   CR612 Revised Jul 2018
       AND source       = 'ACOPIO';


    IF (l_cant_ap = 0) THEN

      SELECT count(*)
        INTO l_cant_int_ap
        FROM AP_INVOICES_INTERFACE
       WHERE invoice_num       = rLiq.numero_liquidacion
         --AND invoice_date      = rLiq.fecha_liquidacion  CR612 Revised Jul
         AND source            = 'ACOPIO'
         AND NVL(status, '~') != 'PROCESSED';

    END IF;


    IF (l_cant_ap > 0) THEN

      p_factura_AP := FALSE;

    ELSIF (l_cant_ap = 0 AND l_cant_int_ap = 0) THEN

      p_factura_AP := TRUE;

    ELSIF (l_cant_ap = 0 AND l_cant_int_ap > 0) THEN


      SELECT invoice_id
        INTO l_invoice_id
        FROM AP_INVOICES_INTERFACE
       WHERE invoice_num       = rLiq.numero_liquidacion
         --AND invoice_date      = rLiq.fecha_liquidacion
         AND source            = 'ACOPIO'
         AND NVL(status, '~') != 'PROCESSED';


      DELETE FROM AP_INVOICES_INTERFACE
       WHERE invoice_id = l_invoice_id;


      DELETE FROM AP_INVOICE_LINES_INTERFACE
       WHERE invoice_id = l_invoice_id;


      COMMIT;

      p_factura_AP := TRUE;

    END IF;



    --=================================================
    -- Se valida si ya fue ingresada la factura en AR
    --================================================
    Debug(C_API_NAME, 'Validacion de AR');

    IF (p_revertir) THEN
      l_tipo_trx := 'NC';
      rLiq.numero_liquidacion := substr(rLiq.numero_liquidacion, 1, length(rLiq.numero_liquidacion)-1);
    ELSE
      l_tipo_trx := 'FC';
    END IF;


    SELECT count(*)
      INTO l_cant_ar
      FROM RA_CUSTOMER_TRX_ALL
     WHERE trx_number                  = 'A-'||rLiq.numero_liquidacion
       --AND trx_date                    = rLiq.fecha_liquidacion     CR612 Revised Jul 2018
       AND interface_header_context    = 'ACOPIO'
       AND interface_header_attribute1 = rLiq.numero_liquidacion
       AND interface_header_attribute2 = l_tipo_trx;


    IF (l_cant_ar = 0) THEN

      SELECT count(*)
        INTO l_cant_int_ar
        FROM RA_INTERFACE_LINES_ALL
       WHERE trx_number                = 'A-'||rLiq.numero_liquidacion
         --AND trx_date                  = rLiq.fecha_liquidacion
         AND interface_line_context    = 'ACOPIO'
         AND interface_line_attribute1 = rLiq.numero_liquidacion
         AND interface_line_attribute2 = l_tipo_trx;

    END IF;


    IF (l_cant_ar > 0) THEN

      p_factura_AR := FALSE;

    ELSIF (l_cant_ar = 0 AND l_cant_int_ar = 0) THEN

      p_factura_AR := TRUE;

    ELSIF (l_cant_ar = 0 AND l_cant_int_ar > 0) THEN

      DELETE FROM RA_INTERFACE_LINES_ALL
       WHERE trx_number                = 'A-'||rLiq.numero_liquidacion
         --AND trx_date                  = rLiq.fecha_liquidacion
         AND interface_line_context    = 'ACOPIO'
         AND interface_line_attribute1 = rLiq.numero_liquidacion
         AND interface_line_attribute2 = l_tipo_trx;


      DELETE FROM RA_INTERFACE_DISTRIBUTIONS_ALL
       WHERE interface_line_context    = 'ACOPIO'
         AND interface_line_attribute1 = rLiq.numero_liquidacion
         AND interface_line_attribute2 = l_tipo_trx;

      COMMIT;

      p_factura_AR := TRUE;

    END IF;


    IF (rLiq.tipo_liquidacion IN ('UNICA','AJUSTE_UNICO')) THEN

      --========================================================
      -- Se valida si ya fue realizado el Movimiento de Stock
      --========================================================
      Debug(C_API_NAME, 'Validacion de Movimiento de Stock');

      SELECT count(*)
        INTO l_cant_cp
        FROM XX_TCG_CARTAS_PORTE_LIQUIDADAS
       WHERE liquidacion_id = p_liquidacion_id;


      IF (p_revertir) THEN
        l_lot_baja := rLiq.lot_number;
        l_lot_alta := rLiq.lot_number||'T';
      ELSE
        l_lot_baja := rLiq.lot_number||'T';
        l_lot_alta := rLiq.lot_number;
      END IF;


      SELECT count(*)
        INTO l_cant_baja
        FROM (SELECT DISTINCT mmt.waybill_airbill
                FROM MTL_MATERIAL_TRANSACTIONS   mmt
                   , MTL_TRANSACTION_TYPES       mtt
                   , MTL_TRANSACTION_LOT_NUMBERS mtl
               WHERE mmt.attribute2            = TO_CHAR(p_liquidacion_id)
                 AND mmt.attribute3            = 'XXTCGLIQ'
                 AND mmt.transaction_type_id   = mtt.transaction_type_id
                 AND mmt.transaction_id        = mtl.transaction_id
                 AND mtt.transaction_type_name = 'TCG Baja Liquidacion'
                 AND mtl.lot_number            = l_lot_baja);

      SELECT count(*)
        INTO l_cant_alta
        FROM (SELECT DISTINCT mmt.waybill_airbill
                FROM MTL_MATERIAL_TRANSACTIONS   mmt
                   , MTL_TRANSACTION_TYPES       mtt
                   , MTL_TRANSACTION_LOT_NUMBERS mtl
               WHERE mmt.attribute2            = TO_CHAR(p_liquidacion_id)
                 AND mmt.attribute3            = 'XXTCGLIQ'
                 AND mmt.transaction_type_id   = mtt.transaction_type_id
                 AND mmt.transaction_id        = mtl.transaction_id
                 AND mtt.transaction_type_name = 'TCG Alta Liquidacion'
                 AND mtl.lot_number            = l_lot_alta);

      IF (l_cant_cp = l_cant_baja) OR
        (l_cant_cp = l_cant_alta) THEN

        p_mov_stock := FALSE;

      ELSIF (l_cant_baja = 0)
        AND (l_cant_alta = 0) THEN

        p_mov_stock := TRUE;

        SELECT count(*)
          INTO l_cant_mov
          FROM MTL_TRANSACTIONS_INTERFACE mti
         WHERE mti.attribute3    = 'XXTCGLIQ'
           AND mti.attribute2    = TO_CHAR(p_liquidacion_id)
           AND mti.process_flag != 1;


        IF (l_cant_mov > 0) THEN

          DELETE FROM MTL_TRANSACTION_LOTS_INTERFACE
           WHERE transaction_interface_id IN (SELECT transaction_interface_id
                                                FROM MTL_TRANSACTIONS_INTERFACE mti
                                               WHERE mti.attribute3    = 'XXTCGLIQ'
                                                 AND mti.attribute2    = TO_CHAR(p_liquidacion_id)
                                                 AND mti.process_flag != 1);

          DELETE FROM MTL_TRANSACTIONS_INTERFACE mti
           WHERE mti.attribute3    = 'XXTCGLIQ'
             AND mti.attribute2    = TO_CHAR(p_liquidacion_id)
             AND mti.process_flag != 1;


          COMMIT;

        END IF;



        SELECT count(*)
          INTO l_cant_mov
          FROM MTL_TRANSACTIONS_INTERFACE mti
         WHERE mti.attribute3   = 'XXTCGLIQ'
           AND mti.attribute2   = TO_CHAR(p_liquidacion_id)
           AND mti.process_flag = 1;

        IF (l_cant_mov > 0) THEN

          p_mov_stock := FALSE;

        END IF;


      END IF;

    END IF;

    IF (p_factura_AP) THEN
      Debug(C_API_NAME, 'l_factura_AP TRUE');
    ELSE
      Debug(C_API_NAME, 'l_factura_AP FALSE');
    END IF;

    IF (p_factura_AR) THEN
      Debug(C_API_NAME, 'l_factura_AR TRUE');
    ELSE
      Debug(C_API_NAME, 'l_factura_AR FALSE');
    END IF;

    IF (p_mov_stock) THEN
      Debug(C_API_NAME, 'l_mov_stock TRUE');
    ELSE
      Debug(C_API_NAME, 'l_mov_stock FALSE');
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result := FALSE;
      p_error_msg := 'Error al intentar determinar los procesos a realizar. '||SQLERRM;

  END Determinar_Procesos_a_Realizar;





END XX_TCG_LIQUIDACION_GRANOS_PKG;
/

exit
