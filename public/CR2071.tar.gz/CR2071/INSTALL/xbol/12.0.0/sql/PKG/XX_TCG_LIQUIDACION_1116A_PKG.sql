  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_TCG_LIQUIDACION_1116A_PKG" AUTHID CURRENT_USER AS





  TYPE liq_1116a_line_rec_type IS RECORD
    ( liquidacion_line_id  NUMBER
    , memo_line_id         NUMBER
    , memo_line_name       AR_MEMO_LINES_TL.name%TYPE
    , gl_id_rev            NUMBER
    , importe              NUMBER
    , memo_line_interco    AR_MEMO_LINES_TL.name%TYPE
    , codigo_impuesto      AR_VAT_TAX_ALL.tax_code%TYPE
    , clasificacion_fiscal AR_MEMO_LINES_ALL_B.global_attribute1%TYPE
    , condicion_trx        AR_MEMO_LINES_ALL_B.global_attribute2%TYPE
     );


  TYPE liq_1116a_lines_tab_type IS TABLE OF liq_1116a_line_rec_type
  INDEX BY BINARY_INTEGER;


  TYPE liquidacion_1116a_rec_type IS RECORD
    ( liquidacion_id             NUMBER
    , numero_liquidacion         XX_TCG_LIQUIDACIONES_1116A.numero_liquidacion%TYPE
    , inventory_item_id          NUMBER
    , lot_number                 VARCHAR2(20)
    , customer_id                NUMBER
    , customer_bill_address_id   NUMBER
    , customer_ship_address_id   NUMBER
    , lineas                     liq_1116a_lines_tab_type
    , organization_id            NUMBER
    , operating_unit             NUMBER  -- org_id
    , legal_entity_id            NUMBER  -- ex co_code
    , legal_entity_interco       NUMBER  -- ex co_code_interco
    , set_of_books_id            NUMBER
    , ledger_id                  NUMBER
    , ra_term_id                 NUMBER
    , conversion_rate            NUMBER
    , conversion_type            XX_TCG_LIQUIDACIONES_1116A.conversion_type%TYPE
    , currency_code              XX_TCG_LIQUIDACIONES_1116A.currency_code%TYPE
    , numero_contrato            XX_TCG_CONTRATOS_COMPRA.numero_contrato%TYPE
    , fecha_liquidacion          DATE
    , fecha_anulacion            DATE
    , liquidado_flag             VARCHAR2(1)
    , customer_class_code        HZ_CUST_ACCOUNTS.customer_class_code%TYPE
    , acct_id_default_1116a      NUMBER
    , oe_order_type              OE_TRANSACTION_TYPES_TL.name%TYPE
    , oe_order_number            OE_ORDER_HEADERS_ALL.order_number%TYPE
    , boletin_header_id          XX_TCG_LIQUIDACIONES_1116A.boletin_header_id%TYPE
    , liquidado_sin_calidad_flag XX_TCG_LIQUIDACIONES_1116A.liquidado_sin_calidad_flag%TYPE
    , site_use_id                NUMBER
    , es_canje                   VARCHAR2(1)
    , payment_method_interco     VARCHAR2(25)
    , cond_impositiva            VARCHAR2(10)
    );



/****************************************************************************
 *                                                                          *
 * Name    : Get_Liquidacion_1116A                                          *
 * Purpose : Rutina que retorna la informacion referente al 1116A           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Liquidacion_1116A( p_liquidacion_id   IN NUMBER
                                 , x_liquidacion_rec OUT liquidacion_1116a_rec_type
                                 , x_result          OUT BOOLEAN
                                 , x_errmsg          OUT VARCHAR2);




  /****************************************************************************
   *                                                                          *
   * Name    : Liquidar_1116A                                                 *
   * Purpose : Genera la liquidacion para un comprobante 1116A.               *
   *                                                                          *
   ****************************************************************************/
  PROCEDURE Liquidar_1116A ( p_init_mst_list   IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_commit          IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_liquidacion_id  IN NUMBER
                           , p_fc_cust_trx_id  IN NUMBER
                           , x_warning        OUT VARCHAR2
                           , x_return_status  OUT VARCHAR2
                           , x_msg_count      OUT NUMBER
                           , x_msg_data       OUT VARCHAR2);



/****************************************************************************
 *                                                                          *
 * Name    : Cancelar_1116A                                                 *
 * Purpose : Rutina para la cancelacion de un 1116A.                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Cancelar_1116A ( p_init_mst_list      IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_commit             IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_liquidacion_id     IN NUMBER
                           , p_boletin_header_id  IN NUMBER
                           , x_warning           OUT VARCHAR2
                           , x_return_status     OUT VARCHAR2
                           , x_msg_count         OUT NUMBER
                           , x_msg_data          OUT VARCHAR2) ;




 /****************************************************************************
 *                                                                           *
 * Name    : Calcular_Percepciones_AR_1116A                                  *
 * Purpose : Rutina para el calculo de las Percepciones a informar a AFIP    *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Calcular_Percepciones_AR_1116A ( p_liquidacion_id   IN NUMBER
                                           , x_cust_trx_id      OUT NUMBER
                                           , x_resultado        OUT BOOLEAN
                                           , x_error            OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Obtener_Percepciones_AR_1116A                                  *
 * Purpose : Rutina para la obtenciÃ³n de las Percepciones a informar a AFIP *
 *                                                                          *
 ****************************************************************************/
 PROCEDURE Obtener_Percepciones_AR_1116A ( p_liquidacion_id   IN NUMBER
                                         , x_percep_iva       OUT NUMBER
                                         , x_otras_percep     OUT NUMBER
                                         , x_no_gravados      OUT NUMBER
                                         , x_resultado        OUT BOOLEAN
                                         , x_error            OUT VARCHAR2);




 /***************************************************************************
 * Name    : Get_AR_Credit_Interco                                          *
 * Purpose : Verifico si la transaccion NC intercompany ya se genero.       *
 *                                                                          *
 ***************************************************************************/
  FUNCTION Get_AR_Credit_Interco ( p_term_id            NUMBER
                                 , p_customer_id        NUMBER
                                 , p_numero_liquidacion VARCHAR2
                                 )
  RETURN NUMBER;



/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible_1116A                                      *
 * Purpose : Rutina que retorna el peso disponible del 1116A para           *
 *           transferencias o retiros y tiene en cuenta las liquidaciones   *
 *           1116B Liquidadas.                                              *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Peso_Disponible ( p_certificado_id         IN NUMBER
                               , p_liquidacion_id         IN NUMBER DEFAULT NULL
                               , p_lock_flag              IN BOOLEAN DEFAULT FALSE
                               )
  RETURN NUMBER;



 /***************************************************************************
 * Name    : Eliminar_Servicios                                             *
 * Purpose : Elimina las lineas de servicios del Certificado                *
 *                                                                          *
 ***************************************************************************/
  PROCEDURE Eliminar_Servicios ( p_liquidacion_id  IN NUMBER
                               , p_error_msg      OUT VARCHAR2);


END XX_TCG_LIQUIDACION_1116A_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_TCG_LIQUIDACION_1116A_PKG" AS



/****************************************************************************
 *                      C O N S T A N T S  V A L U E S                      *
 ****************************************************************************/



  C_PACKAGE_NAME CONSTANT VARCHAR2(30) := 'XX_TCG_LIQUIDACION_1116A_PKG';

  -----------------
  -- GL Interface
  -----------------
  C_GL_SOURCE_NAME CONSTANT VARCHAR2(30) := 'Acopio';
  C_GL_CATEGORY CONSTANT VARCHAR2(30)    := 'Servicios';
  C_GL_REFERENCE1 CONSTANT VARCHAR2(30)  := 'Liquidacion 1116A';
  C_GL_REFERENCE4 CONSTANT VARCHAR2(30)  := 'Servicios';
  C_GL_REFERENCE10 CONSTANT VARCHAR2(30) := 'Servicios';


  -----------------
  -- AP Interface
  -----------------
  C_AP_INVOICE_TYPE_CODE CONSTANT VARCHAR2(30)       := 'STANDARD';
  C_AP_INVOICE_TYPE_CODE_NC CONSTANT VARCHAR2(30)    := 'CREDIT';
  C_AP_GLOBAL_ATTR_CATEGORY CONSTANT VARCHAR2(30)    := 'JL.AR.APXIISIM.INVOICES_FOLDER';
  C_AP_GLOBAL_ATTR_CATEGORY_LN CONSTANT VARCHAR2(30) := 'JL.AR.APXIISIM.LINES_FOLDER';



/****************************************************************************
 *                              T Y P E S                                   *
 ****************************************************************************/

  ---------------------------------
  -- Tipo de registro de atributos
  ---------------------------------
  TYPE attributes_rec_type IS RECORD
    ( attribute1 VARCHAR2(150)
    , attribute2 VARCHAR2(150)
    , attribute3 VARCHAR2(150)
    , attribute4 VARCHAR2(150)
    , attribute5 VARCHAR2(150)
    , attribute6 VARCHAR2(150)
    , attribute7 VARCHAR2(150)
    , attribute8 VARCHAR2(150)
    , attribute9 VARCHAR2(150)
    , attribute10 VARCHAR2(150)
    , attribute11 VARCHAR2(150)
    , attribute12 VARCHAR2(150)
    , attribute13 VARCHAR2(150)
    , attribute14 VARCHAR2(150)
    , attribute15 VARCHAR2(150)
    , attribute16 VARCHAR2(150)
    , attribute17 VARCHAR2(150)
    , attribute18 VARCHAR2(150)
    , attribute19 VARCHAR2(150)
    , attribute20 VARCHAR2(150)
    );


/****************************************************************************
 *                     P R I V A T E    R O U T I N E S                     *
 ****************************************************************************/


 /****************************************************************************
  *                                                                          *
  * Name    : debug                                                          *
  * Purpose : Debug del paquete.                                             *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Debug ( p_api_name      IN VARCHAR2
                  , p_debug_message IN VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Generar_Factura_1116A                                          *
 * Purpose : Rutina para la generacion de una factura en AR a partir de     *
 *           la liquidacion 1116a.                                          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Factura_1116A( p_liquidacion_rec  IN OUT NOCOPY liquidacion_1116a_rec_type
                                 , x_result              OUT        BOOLEAN
                                 , x_errmsg              OUT        VARCHAR2
                                 , x_warning             OUT        VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Set_Attribute_Value                                            *
 * Purpose : Setea el valor en el attribute del registro de transaccion.    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Set_Attribute_Value( p_attributes_rec  IN OUT NOCOPY attributes_rec_type
                               , p_column_name     IN VARCHAR2
                               , p_value           IN VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Generar_Doc_Trx_Definitivo                                     *
 * Purpose : Rutina que genera el documento de una Transaccion a partir     *
 *          de una documento generado previamente en forma ficticia         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Doc_Trx_Definitivo ( p_liquidacion_rec    IN LIQUIDACION_1116A_REC_TYPE
                                       , p_customer_trx_id    IN NUMBER
                                       , p_cust_trx_type_id   IN NUMBER
                                       , p_batch_source_name  IN VARCHAR2
                                       , p_doc_type           IN VARCHAR2
                                       , p_attributes_rec     IN ATTRIBUTES_REC_TYPE
                                       , x_resultado         OUT BOOLEAN
                                       , x_error             OUT VARCHAR2
                                       );




/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AR_1116A                                     *
 * Purpose : Rutina para la ejecucion del concurrente de AR                 *
 *                                                                          *
 ****************************************************************************/
PROCEDURE Ejecutar_Interface_AR_1116A ( p_org_id              IN NUMBER
                                      , p_batch_source_name   IN VARCHAR2
                                      , p_transaction_number  IN VARCHAR2
                                      , p_customer_class      IN VARCHAR2
                                      , x_result             OUT BOOLEAN
                                      , x_errmsg             OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Crear_Doc_Interco_AP_1116A                                     *
 * Purpose : Rutina que genera la factura o la nota de credito en AP en     *
 *          funcion de una factura o nota de credito en AR (interco)        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Crear_Doc_Interco_AP_1116A ( p_liquidacion_rec   IN LIQUIDACION_1116A_REC_TYPE
                                       , p_cust_trx_id_real  IN NUMBER
                                       , p_categ_trx         IN VARCHAR2
                                       , p_tipo_trx          IN VARCHAR2
                                       , p_grupo_pago        IN VARCHAR2
                                       , x_result           OUT BOOLEAN
                                       , x_errmsg           OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Interface_AP_1116A                                    *
 * Purpose : Rutina para la ejecucion del concurrente de Open Interfcae     *
 *          en AP                                                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AP_1116A ( p_org_id       IN NUMBER
                                        , x_result      OUT BOOLEAN
                                        , x_errmsg      OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Actualizar_refacturado_flag_CP                                 *
 * Purpose : Actualizo los flag de refacturado_flag en Y de las             *
 *           cartas de porte relacionados con la 1116A y que                *
 *           entraron en la refacturaci?n                                   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Actualizar_refacturado_flag_CP ( p_init_mst_list      IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                                           , p_boletin_header_id  IN NUMBER
                                           , x_warning           OUT VARCHAR2
                                           , x_return_status     OUT VARCHAR2
                                           , x_msg_count         OUT NUMBER
                                           , x_msg_data          OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Generar_NC_1116A                                               *
 * Purpose : Rutina para la generacion de una NC en AR a partir de          *
 *           la liquidacion 1116A.                                          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_NC_1116A ( p_liquidacion_rec  IN OUT NOCOPY liquidacion_1116a_rec_type
                             , x_result              OUT BOOLEAN
                             , x_errmsg              OUT VARCHAR2
                             , x_warning             OUT VARCHAR2);




 /* ***************************************************************************
 * Name    : Get_IF_Credit_Interco                                            *
 * Purpose : Verifico si la transaccion NC intercompany esta en la interface  *
 *                                                                            *
 *****************************************************************************/
  FUNCTION Get_IF_Credit_Interco ( p_customer_id        NUMBER
                                 , p_numero_liquidacion VARCHAR2
                                 ) RETURN NUMBER;




/****************************************************************************
 *                                                                          *
 * Name    : Generar_NDInterco_1116A                                        *
 * Purpose : Rutina para la generacion de una ND Interco en AR a partir de  *
 *           la cancelacion de la liquidacion 1116a.                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_NDInterco_1116A ( p_liquidacion_rec  IN OUT NOCOPY liquidacion_1116a_rec_type
                                    , x_result              OUT BOOLEAN
                                    , x_errmsg              OUT VARCHAR2
                                    , x_warning             OUT VARCHAR2);




/****************************************************************************
 *                     P U B L I C    R O U T I N E S                       *
 ****************************************************************************/



 /****************************************************************************
 *                                                                          *
 * Name    : Get_Liquidacion_1116A                                          *
 * Purpose : Rutina que retorna la informacion referente al 1116A           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Liquidacion_1116A ( p_liquidacion_id   IN NUMBER
                                  , x_liquidacion_rec OUT liquidacion_1116a_rec_type
                                  , x_result          OUT BOOLEAN
                                  , x_errmsg          OUT VARCHAR2)
  IS

    CURSOR c_liquidacion IS
      SELECT xtl.liquidacion_id
           , xtl.numero_liquidacion
           , xtc.inventory_item_id
           , xtc.lot_number
           , hca.cust_account_id             customer_id
           , hcsu_bill_to.cust_acct_site_id customer_bill_address_id
           , hcsu_ship_to.cust_acct_site_id customer_ship_address_id
           , xtl.ra_term_id
           , NULL conversion_rate --xtl.conversion_rate
           , NULL conversion_type --xtl.conversion_type
           , 'ARS' currency_code --xtl.currency_code TK986
           , xtl.organization_id
           , (SELECT hoi.org_information3          /*org_id*/
                FROM HR_ORGANIZATION_INFORMATION    hoi
               WHERE hoi.organization_id = xtl.organization_id
                 AND hoi.org_information_context = 'Accounting Information' ) operating_unit
           , (SELECT hou.default_legal_context_id
                FROM HR_ORGANIZATION_INFORMATION  hoi
                   , HR_OPERATING_UNITS           hou
               WHERE hoi.org_information3 = hou.organization_id
                 AND hoi.organization_id  = xtl.organization_id
                 AND hoi.org_information_context = 'Accounting Information')  co_code
           , xtc.numero_contrato
           , xtl.fecha_liquidacion
           , xtl.fecha_anulacion
           , xtl.liquidado_flag
           , hca.customer_class_code
           , ott.name
           , xtc.order_number
           , xtl.boletin_header_id
           , xtl.liquidado_sin_calidad_flag
           , hcsu_bill_to.site_use_id
           , xtl.metodo_pago
           , DECODE(( SELECT count(*)
                        FROM HZ_CUST_ACCT_SITES_ALL hcs
                           , HZ_CUST_SITE_USES_ALL  hcu
                       WHERE hcs.cust_acct_site_id             = hcu.cust_acct_site_id
                         AND hcs.cust_account_id               = hca.cust_account_id
                         AND hcs.status                        = 'A'
                         AND hcu.site_use_code                 IN ('BILL_TO','SHIP_TO')
                         AND hcu.status                        = 'A'
                         AND SUBSTR(hcs.global_attribute8,1,2) = 'MT'
                     ),0,'NO_MT', 'MT')  cond_imp
       FROM XX_TCG_LIQUIDACIONES_1116A xtl
          , XX_TCG_CONTRATOS_COMPRA    xtc
          , HZ_CUST_ACCOUNTS           hca
          , HZ_CUST_SITE_USES_ALL      hcsu_bill_to
          , HZ_CUST_SITE_USES_ALL      hcsu_ship_to
          , OE_TRANSACTION_TYPES_TL    ott
      WHERE xtl.liquidacion_id            = p_liquidacion_id
        AND xtl.contrato_id               = xtc.contrato_id (+)
        AND xtc.productor_id              = hca.party_id (+)
        -- Modificado CR1205 - asilva - ago 2018
        AND (hca.party_id                 IS NULL
             OR hca.status                = 'A')
        --
        AND xtl.bill_to_site_use_id       = hcsu_bill_to.site_use_id(+)
        AND xtl.ship_to_site_use_id       = hcsu_ship_to.site_use_id(+)
        AND xtc.oe_transaction_type_id    = ott.transaction_type_id(+)
        AND ott.language(+)               = USERENV('LANG');



    CURSOR c_lines IS
      SELECT xtll.liquidacion_line_id
           , xtll.memo_line_id
           , aml.name
           , aml.gl_id_rev
           , xtll.importe
           , aml_dfv.xx_memoline_interco
           , aml.global_attribute1
           , aml.global_attribute2
        FROM XX_TCG_LIQUIDACION_1116A_LINES  xtll
           , AR_MEMO_LINES_ALL_VL            aml
           , AR_MEMO_LINES_ALL_B_DFV         aml_dfv
       WHERE xtll.liquidacion_id = p_liquidacion_id
         AND xtll.memo_line_id   = aml.memo_line_id
         AND aml.row_id          = aml_dfv.row_id
         AND xtll.importe        > 0
         ;

    C_API_NAME     VARCHAR2(300) := 'XX_TCG_LIQUIDACION_1116A_PKG.Get_Liquidacion_1116A';
    l_index        NUMBER := 0;
    l_result       BOOLEAN;
    l_errmsg       VARCHAR2(2000);
    l_dummy        VARCHAR2(300);


  BEGIN
    debug(C_API_NAME, 'Iniciando.');
    x_result := TRUE;

    OPEN  c_liquidacion;
    FETCH c_liquidacion INTO x_liquidacion_rec.liquidacion_id
                           , x_liquidacion_rec.numero_liquidacion
                           , x_liquidacion_rec.inventory_item_id
                           , x_liquidacion_rec.lot_number
                           , x_liquidacion_rec.customer_id
                           , x_liquidacion_rec.customer_bill_address_id
                           , x_liquidacion_rec.customer_ship_address_id
                           , x_liquidacion_rec.ra_term_id
                           , x_liquidacion_rec.conversion_rate
                           , x_liquidacion_rec.conversion_type
                           , x_liquidacion_rec.currency_code
                           , x_liquidacion_rec.organization_id
                           , x_liquidacion_rec.operating_unit
                           , x_liquidacion_rec.legal_entity_id
                           , x_liquidacion_rec.numero_contrato
                           , x_liquidacion_rec.fecha_liquidacion
                           , x_liquidacion_rec.fecha_anulacion
                           , x_liquidacion_rec.liquidado_flag
                           , x_liquidacion_rec.customer_class_code
                           , x_liquidacion_rec.oe_order_type
                           , x_liquidacion_rec.oe_order_number
                           , x_liquidacion_rec.boletin_header_id
                           , x_liquidacion_rec.liquidado_sin_calidad_flag
                           , x_liquidacion_rec.site_use_id
                           , x_liquidacion_rec.payment_method_interco
                           , x_liquidacion_rec.cond_impositiva;
    CLOSE c_liquidacion;


    -------------------------------------------------
    -- Verifico que se haya recuperado la liquidacion
    -------------------------------------------------
    IF (x_liquidacion_rec.liquidacion_id IS NULL) THEN
        x_result := FALSE;
        x_errmsg := 'No fue posible recuperar la liquidacion.';
        RETURN;
    END IF;



    ----------------------
    -- Recupero las lineas
    ----------------------
    FOR l_line_rec IN c_lines LOOP
        l_index := l_index + 1;

        x_liquidacion_rec.lineas(l_index).liquidacion_line_id := l_line_rec.liquidacion_line_id;
        x_liquidacion_rec.lineas(l_index).memo_line_id        := l_line_rec.memo_line_id;
        x_liquidacion_rec.lineas(l_index).memo_line_name      := l_line_rec.name;
        x_liquidacion_rec.lineas(l_index).gl_id_rev           := l_line_rec.gl_id_rev;
        x_liquidacion_rec.lineas(l_index).importe             := l_line_rec.importe;
        x_liquidacion_rec.lineas(l_index).memo_line_interco   := l_line_rec.xx_memoline_interco;
        x_liquidacion_rec.lineas(l_index).clasificacion_fiscal:= l_line_rec.global_attribute1;
        x_liquidacion_rec.lineas(l_index).condicion_trx       := l_line_rec.global_attribute2;

    END LOOP;

    ----------------------------------------------------------
    -- Verifico tener un cliente y los domicilios
    ----------------------------------------------------------
    IF (x_liquidacion_rec.numero_contrato IS NOT NULL) THEN

        IF (x_liquidacion_rec.customer_id IS NULL) THEN
            x_result := FALSE;
            x_errmsg := 'No fue posible obtener el cliente origen del contrato '||
                        'a partir del proveedor. Por favor verificar.';
            RETURN;
        END IF;


        IF (x_liquidacion_rec.customer_bill_address_id IS NULL AND x_liquidacion_rec.lineas.count >0 ) THEN
            x_result := FALSE;
            x_errmsg := 'No fue posible obtener el domicilio de facturacion del cliente '||
                        '. Por favor verificar.';
            RETURN;
        END IF;


        IF (x_liquidacion_rec.customer_ship_address_id IS NULL AND x_liquidacion_rec.lineas.count >0) THEN
            x_result := FALSE;
            x_errmsg := 'No fue posible obtener el domicilio de envio del cliente '||
                        '. Por favor verificar.';
            RETURN;
        END IF;


    END IF;


    -------------------------------------------------
    -- Se verifica si el termino de pago es de Canje
    -------------------------------------------------
    BEGIN
      SELECT 'Y'
      INTO x_liquidacion_rec.es_canje
      FROM ra_terms              rt
         , ra_terms_b_dfv  rtfv
      WHERE 1=1
      AND rt.row_id                 = rtfv.row_id
      AND NVL(rtfv.xx_ar_canje,'N') = 'Y'
      AND rt.term_id                = x_liquidacion_rec.ra_term_id;

    EXCEPTION
      WHEN OTHERS THEN
        x_liquidacion_rec.es_canje := 'N';
    END;

    -------------------------------------------------
    -- Se verifica si se trata de una Interco
    -------------------------------------------------
    IF (x_liquidacion_rec.customer_class_code='INTERCOMPANY') THEN
      BEGIN

        SELECT hou.default_legal_context_id
          INTO x_liquidacion_rec.legal_entity_interco
          FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
             , HR_OPERATING_UNITS          hou
         WHERE xtpc.customer_id    = x_liquidacion_rec.customer_id
           AND xtpc.operating_unit = hou.organization_id;

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'No fue posible obtener el company code interco. '||SQLERRM;
          RETURN;
      END;
    END IF;

    -------------------------------------------------
    -- Se obtiene el ledger id
    -------------------------------------------------
    BEGIN
      MO_UTILS.Get_Ledger_Info( p_operating_unit   => x_liquidacion_rec.operating_unit
                              , p_ledger_id        => x_liquidacion_rec.ledger_id
                              , p_ledger_name      => l_dummy
                              );
    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;
        x_errmsg := 'Error al buscar el ledger id: '||SQLERRM;
        RETURN;
    END;

    BEGIN
      SELECT set_of_books_id
        INTO x_liquidacion_rec.set_of_books_id
        FROM FINANCIALS_SYSTEM_PARAMS_ALL
       WHERE org_id = x_liquidacion_rec.operating_unit;
    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;
        x_errmsg := 'Error al buscar el set_of_book_id: '||SQLERRM;
    END;

  EXCEPTION
    WHEN others THEN

      IF (c_liquidacion%ISOPEN) THEN
        CLOSE c_liquidacion;
      END IF;
      x_result := FALSE;
      x_errmsg := 'Error inesperado obteniendo los detalles de la liquidacion. '||
                  'Detalle: '|| SQLERRM;

  END Get_Liquidacion_1116A;



  /****************************************************************************
  *                                                                          *
  * Name    : Liquidar_1116A                                                 *
  * Purpose : Genera la liquidacion para un 1116A.                           *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Liquidar_1116A ( p_init_mst_list   IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_commit          IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_liquidacion_id  IN NUMBER
                           , p_fc_cust_trx_id  IN NUMBER
                           , x_warning        OUT VARCHAR2
                           , x_return_status  OUT VARCHAR2
                           , x_msg_count      OUT NUMBER
                           , x_msg_data       OUT VARCHAR2)
  IS

    C_API_NAME         VARCHAR2(30) := 'LIQUIDAR_1116A';
    l_result           BOOLEAN;
    l_errmsg           VARCHAR2(3000);
    l_liquidacion_rec  liquidacion_1116a_rec_type;

  BEGIN

    debug(C_API_NAME, 'Iniciando.');
    debug(C_API_NAME, 'p_liquidacion_id = ' || p_liquidacion_id);


    -----------------------------------
    -- Inicializo el codigo de retorno
    -----------------------------------
    x_return_status := FND_API.G_RET_STS_SUCCESS;

    ----------------------------------
    -- Inicializo la pila de mensajes
    ----------------------------------
    IF (p_init_mst_list = FND_API.G_TRUE) THEN
      Debug(C_API_NAME, 'Limpio pila de mensajes.');
      FND_MSG_PUB.Initialize;
    END IF;

    ---------------------------
    -- Recupero la liquidacion
    ---------------------------
    Debug(C_API_NAME, 'Obtengo la liquidacion.');

    Get_Liquidacion_1116A( p_liquidacion_id  => p_liquidacion_id
                         , x_liquidacion_rec => l_liquidacion_rec
                         , x_result          => l_result
                         , x_errmsg          => l_errmsg);

    IF (NOT l_result) THEN

      FND_MESSAGE.set_name ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE','Error obteniendo la liquidacion 1116A. Detalle: '||l_errmsg);
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;

    END IF;


    ---------------------------------------------------
    -- Si el origen es de un tercero, genero la factura
    -- en AR.
    ---------------------------------------------------
    IF (l_liquidacion_rec.numero_contrato IS NOT NULL) AND
      -- Si el parametro p_fc_cust_trx_id devuelve -1
      -- entonces habilito para generar la FC de la liquidacion.
      (p_fc_cust_trx_id = -1) THEN


      IF (l_liquidacion_rec.cond_impositiva !='MT' AND
        l_liquidacion_rec.lineas.count > 0) THEN

        debug(C_API_NAME, 'Pre Generar_Factura_1116A para contrato tercero.');

        Generar_Factura_1116A( p_liquidacion_rec => l_liquidacion_rec
                             , x_result          => l_result
                             , x_errmsg          => l_errmsg
                             , x_warning         => x_warning);

      END IF;

    END IF;

    IF (NOT l_result) THEN

      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE', 'Error generando liquidacion 1116A. Detalle: '||
                             l_errmsg);
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;

    END IF;

    --                                Actualizo los flag de refacturado_flag en Y de las
    --                                cartas de porte relacionados con la 1116A y que
    --                                entraron en la refacturaci?n
    IF (l_result) THEN

      Actualizar_refacturado_flag_CP ( p_init_mst_list
                                     , l_liquidacion_rec.boletin_header_id
                                     , x_warning
                                     , x_return_status
                                     , x_msg_count
                                     , x_msg_data);

      IF (NOT l_result) THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE', 'Error al actualizar flag de refacturado en carta de porte '
                              ||x_msg_data);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
      END IF;

    END IF;
    --

    ------------------------------------------------
    -- Efectuo un COMMIT, dependiendo del parametro
    ------------------------------------------------
    IF (FND_API.to_boolean(p_commit)) THEN
        COMMIT;
    END IF;

     debug(C_API_NAME, 'Fin.');

  EXCEPTION
    WHEN FND_API.G_EXC_ERROR THEN

      x_return_status := FND_API.G_RET_STS_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);

      debug(C_API_NAME, 'Salgo con error: '|| XX_TCG_UTIL_PKG.get_msg(x_msg_count));

    WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN

      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);

      debug(C_API_NAME, 'Salgo con error: '||XX_TCG_UTIL_PKG.get_msg(x_msg_count));

    WHEN others THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE', 'XX_TCG_LIQUIDACION_1116A_PKG.Liquidar_1116A. '||
                             'Error inesperado - ' || SQLERRM);
      FND_MSG_PUB.add;
      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
      FND_MSG_PUB.Count_And_Get ( p_count => x_msg_count
                                , p_data  => x_msg_data);

      debug(C_API_NAME, 'Salgo con error: '||XX_TCG_UTIL_PKG.get_msg(x_msg_count));

  END Liquidar_1116A;





/****************************************************************************
 *                                                                          *
 * Name    : Cancelar_1116A                                                 *
 * Purpose : Rutina para la cancelacion de un 1116A.                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Cancelar_1116A ( p_init_mst_list      IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_commit             IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                           , p_liquidacion_id     IN NUMBER
                           , p_boletin_header_id  IN NUMBER
                           , x_warning           OUT VARCHAR2
                           , x_return_status     OUT VARCHAR2
                           , x_msg_count         OUT NUMBER
                           , x_msg_data          OUT VARCHAR2)
  IS


    --------------------------------
    -- Cartas de porte de un boletin
    --------------------------------
    CURSOR c_cartas_porte IS
      SELECT xtcp.carta_porte_id
           , refacturado_flag
        FROM XX_TCG_CARTAS_PORTE_ALL xtcp
           , XX_TCG_BOLETIN_LINES    xtbl
       WHERE xtbl.boletin_header_id = p_boletin_header_id
         AND xtbl.carta_porte_id    = xtcp.carta_porte_id
         AND NVL(xtcp.refacturar_flete_flag,'N') = 'Y'
         AND NVL(xtcp.provisionado_flag,'N')     = 'Y'
         AND NVL(xtcp.refacturado_flag,'N')      = 'Y';


    C_API_NAME               VARCHAR2(30) := 'CANCELAR_1116A';
    l_result                 BOOLEAN;
    l_errmsg                 VARCHAR2(3000);
    l_liquidacion_rec        liquidacion_1116a_rec_type;
    l_numero_liquidacion     VARCHAR2(30);
    l_ou_chs                 NUMBER;
    l_customer_chs           NUMBER;
    l_chr_refacturado_flag   XX_TCG_CARTAS_PORTE_ALL.refacturado_flag%TYPE;
    row_locked               EXCEPTION;
    PRAGMA EXCEPTION_INIT(row_locked,-54);
    l_cust_trx_id_nc         NUMBER;
    l_categ_trx              VARCHAR2(100);
    l_grupo_pago             VARCHAR2(100);
    l_tipo_trx               VARCHAR2(30);



  BEGIN

    debug(C_API_NAME, 'Iniciando.');
    debug(C_API_NAME, 'p_liquidacion_id = ' || p_liquidacion_id);

    -----------------------------------
    -- Inicializo el codigo de retorno
    -----------------------------------
    x_return_status := FND_API.G_RET_STS_SUCCESS;

    ----------------------------------
    -- Inicializo la pila de mensajes
    ----------------------------------
    IF (p_init_mst_list = FND_API.G_TRUE) THEN
      debug(C_API_NAME, 'Limpio pila de mensajes.');
      FND_MSG_PUB.Initialize;
    END IF;


    ---------------------------
    -- Recurpero la liquidacion
    ---------------------------
    debug(C_API_NAME, 'Obtengo la liquidacion.');
    Get_Liquidacion_1116A( p_liquidacion_id  => p_liquidacion_id
                         , x_liquidacion_rec => l_liquidacion_rec
                         , x_result          => l_result
                         , x_errmsg          => l_errmsg);

    IF (NOT l_result) THEN
      FND_MESSAGE.set_name ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE',
                             'Error cancelando liquidacion 1116. Detalle: '||l_errmsg);
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;
    END IF;



    FOR l_rec IN c_cartas_porte LOOP
      -- Para chequear que el registro de carta de porte
      -- no este tomado en la pantalla de carta de porte
      BEGIN

        SELECT refacturado_flag
          INTO l_chr_refacturado_flag
          FROM XX_TCG_CARTAS_PORTE_ALL
         WHERE carta_porte_id = l_rec.carta_porte_id
           FOR UPDATE OF refacturado_flag NOWAIT;

      EXCEPTION
        WHEN row_locked THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE','Error al actualizar cartas de porte por la cancelacion. '||
                                 'Detalle: La carta de porte esta siendo consultada y/o modificada.'||
                                  CHR(10)|| 'ID carta de porte = '||l_rec.carta_porte_id);
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;

      WHEN OTHERS THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE','Error al actualizar cartas de porte por la cancelacion. Detalle: '
                               ||SUBSTR(SQLERRM,1,100));
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;

      END;



      BEGIN

        UPDATE XX_TCG_CARTAS_PORTE_ALL
           SET refacturado_flag = 'N'
         WHERE carta_porte_id   = l_rec.carta_porte_id;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE', 'Error al actualizar cartas de porte por la cancelacion. Detalle: '
                                 ||SUBSTR(SQLERRM,1,100));
          FND_MSG_PUB.add;
          RAISE FND_API.G_EXC_ERROR;

      END;

    END LOOP;


    ------------------------------------
    -- Si no esta liquidada no hago nada
    ------------------------------------
    IF (l_liquidacion_rec.liquidado_flag = 'N') AND
      (l_liquidacion_rec.liquidado_sin_calidad_flag = 'N') THEN
      RETURN;
    END IF;


    -------------------------------------------------
    -- Valido que la liquidacion no este referenciada
    -------------------------------------------------
    BEGIN
      SELECT numero_liquidacion
      INTO l_numero_liquidacion
      FROM xx_aco_liquidaciones_1116rt
      WHERE tipo_liquidacion_relacionada = '1116A'
      AND liquidacion_id_relacionada   = p_liquidacion_id
      AND cancelado_flag               = 'N'
      AND rownum = 1;
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
      WHEN others THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE','Se produjo un error intentando determinar si la liquidación se encontraba '||
                                'en relacionada a una liquidación 1116rt. Detalle: '|| SQLERRM);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
    END;

    IF (l_numero_liquidacion IS NOT NULL) THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE','No es posible cancelar la liquidación dado que se encuentra '||
                             'relacionada a la liquidación 1116rt "'||l_numero_liquidacion ||'". Por favor verificar.');
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;
    END IF;


    BEGIN

      SELECT numero_liquidacion
        INTO l_numero_liquidacion
        FROM XX_TCG_LIQUIDACIONES           xtl
           , XX_TCG_CERTIFICADOS_LIQUIDADOS xtcl
       WHERE xtl.liquidacion_id  = xtcl.liquidacion_id
         AND xtcl.certificado_id = p_liquidacion_id
         AND cancelado_flag      = 'N';

    EXCEPTION
      WHEN no_data_found THEN
        NULL;

      WHEN too_many_rows THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE','No es posible cancelar el certificado dado que se encuentra '||
                              'relacionado a varias liquidaciones de Granos. Por favor verificar.');
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;

      WHEN others THEN
        FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
        FND_MESSAGE.set_token ('MESSAGE','Se produjo un error intentando determinar si el certificado se encontraba '||
                               'relacionado a una liquidación de Granos: '|| SQLERRM);
        FND_MSG_PUB.add;
        RAISE FND_API.G_EXC_ERROR;
    END;

    IF (l_numero_liquidacion IS NOT NULL) THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE','No es posible cancelar el certificado dado que se encuentra '||
                             'relacionado a la liquidacion de Granos '||l_numero_liquidacion||'. Por favor verificar.');
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;
    END IF;


    -----------------------------------------------------------
    -- Si el origen es de un tercero, genero la nota de credito
    -- en AR.
    -----------------------------------------------------------
    IF (l_liquidacion_rec.numero_contrato IS NOT NULL AND
      l_liquidacion_rec.lineas.count > 0) THEN


      IF (l_liquidacion_rec.cond_impositiva != 'MT' ) THEN

        debug(C_API_NAME, 'Genero interface AR para contrato tercero.');
        Generar_NC_1116A ( p_liquidacion_rec => l_liquidacion_rec
                         , x_result          => l_result
                         , x_errmsg          => l_errmsg
                         , x_warning         => x_warning);


        IF (NOT l_result) THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE', 'Error cancelando liquidacion 1116. Detalle: '|| l_errmsg);
          FND_MSG_PUB.Add;
          RAISE FND_API.G_EXC_ERROR;
        END IF;

      END IF;


      SELECT xtpc.operating_unit, xtpc.customer_id
        INTO l_ou_chs, l_customer_chs
        FROM HR_OPERATING_UNITS         hou
           , XX_TCG_PARAMETROS_COMPANIA xtpc
       WHERE 1=1
       --AND hou.name             = 'AR CHS UO' TK1485
       AND xtpc.operating_unit = 1357
       AND hou.organization_id = xtpc.operating_unit;


      BEGIN
        SELECT customer_trx_id
          INTO l_cust_trx_id_nc
          FROM RA_CUSTOMER_TRX_ALL   rct
             , RA_CUST_TRX_TYPES_ALL rctt
         WHERE rct.cust_trx_type_id = rctt.cust_trx_type_id
           AND rct.trx_number       = FND_PROFILE.value('XX_ACO_RA_NC_PREFIX') ||
                                      l_liquidacion_rec.numero_liquidacion
           AND rctt.type            = 'CM';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_cust_trx_id_nc := -1;
      END;

      -- Genero NC Interco si el cliente de la liquidacion es INTERCOMPANY.
      IF  l_liquidacion_rec.customer_class_code = 'INTERCOMPANY' AND
        /*l_liquidacion_rec.operating_unit != l_ou_chs AND TK1485
        l_liquidacion_rec.customer_id != l_customer_chs AND*/
        ( Get_IF_Credit_Interco ( l_liquidacion_rec.customer_id, l_liquidacion_rec.numero_liquidacion ) != -1
          OR Get_AR_Credit_Interco ( l_liquidacion_rec.ra_term_id, l_liquidacion_rec.customer_id, l_liquidacion_rec.numero_liquidacion ) != -1 ) AND
        (l_cust_trx_id_nc = -1)  THEN

        debug(C_API_NAME, 'Genero interface AR para interco.');


        Generar_NDInterco_1116A ( p_liquidacion_rec => l_liquidacion_rec
                                , x_result          => l_result
                                , x_errmsg          => l_errmsg
                                , x_warning         => x_warning);


      ELSIF (l_liquidacion_rec.customer_class_code = 'INTERCOMPANY' AND
        /*l_liquidacion_rec.operating_unit != l_ou_chs AND TK1485
        l_liquidacion_rec.customer_id  != l_customer_chs AND */
        l_cust_trx_id_nc  != -1) THEN

        BEGIN

          SELECT cat.lookup_code
               , NVL(xtpc.grupo_pago, 'IMPUESTOS')
               , xtpc.tipo_factura_anul_pos
            INTO l_categ_trx
               , l_grupo_pago
               , l_tipo_trx
            FROM XX_TCG_PARAMETROS_COMPROBANTE  xtpc
               , JL_AR_AP_TRX_DGI_CODES         dgi
               , FND_LOOKUPS                    cat
           WHERE xtpc.categ_anul_pos_id = dgi.trx_category_letter_id
             AND dgi.trx_category       = cat.lookup_code
             AND cat.lookup_type        = 'JLAR_LEGAL_TRX_CATEGORY'
             AND xtpc.operating_unit    = (SELECT hou.organization_id
                                             FROM HR_OPERATING_UNITS hou
                                            WHERE hou.default_legal_context_id = l_liquidacion_rec.legal_entity_interco)
             AND xtpc.codigo_doc        = 'CERTIFICADO'
             AND xtpc.tipo_doc          = 'OFICIAL'
             AND xtpc.canje             = l_liquidacion_rec.es_canje
           GROUP BY cat.lookup_code
               , xtpc.grupo_pago
               , xtpc.tipo_factura_anul_pos;


        EXCEPTION
          WHEN TOO_MANY_ROWS THEN

            SELECT cat.lookup_code
                 , NVL(xtpc.grupo_pago, 'IMPUESTOS')
                 , xtpc.tipo_factura_anul_pos
              INTO l_categ_trx
                 , l_grupo_pago
                 , l_tipo_trx
              FROM XX_TCG_PARAMETROS_COMPROBANTE  xtpc
                 , JL_AR_AP_TRX_DGI_CODES         dgi
                 , FND_LOOKUPS                    cat
             WHERE xtpc.categ_anul_pos_id     = dgi.trx_category_letter_id
               AND dgi.trx_category           = cat.lookup_code
               AND cat.lookup_type            = 'JLAR_LEGAL_TRX_CATEGORY'
               AND xtpc.operating_unit        = (SELECT hou.organization_id
                                                   FROM HR_OPERATING_UNITS hou
                                                  WHERE hou.default_legal_context_id = l_liquidacion_rec.legal_entity_interco)
               AND xtpc.codigo_doc            = 'CERTIFICADO'
               AND xtpc.tipo_doc              = 'OFICIAL'
               AND xtpc.canje                 = l_liquidacion_rec.es_canje
               AND xtpc.tipo_anul_ar_post_gl  = 'Y'
               AND xtpc.tipo_anul_ar_tax_calc = 'N';

        WHEN OTHERS THEN
          l_errmsg := 'Error al intentar encontrar la categoria de trx para crear la factura en AP. '||SQLERRM;
          l_result := FALSE;

        END;

        IF (l_categ_trx IS NOT NULL AND l_grupo_pago IS NOT NULL ) THEN


          Crear_Doc_Interco_AP_1116A ( p_liquidacion_rec     => l_liquidacion_rec
                                     , p_cust_trx_id_real    => l_cust_trx_id_nc
                                     , p_categ_trx           => l_categ_trx
                                     , p_tipo_trx            => l_tipo_trx
                                     , p_grupo_pago          => l_grupo_pago
                                     , x_result              => l_result
                                     , x_errmsg              => l_errmsg);
        ELSE

          l_errmsg := 'No se puede crear el Doc Interco en AP dado que no se encuentra '
                      ||'configurada la categoria de transacción ó el grupo de pago requerido.';
          l_result := FALSE;

        END IF;

      END IF;


    END IF;

    IF (NOT l_result) THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE','Error cancelando liquidacion 1116A. Detalle: '||l_errmsg);
      FND_MSG_PUB.add;
      RAISE FND_API.G_EXC_ERROR;
    END IF;

    ------------------------------------------------
    -- Efectuo un COMMIT, dependiendo del parametro
    ------------------------------------------------
    IF (FND_API.to_boolean(p_commit)) THEN
      COMMIT;
    END IF;

  EXCEPTION
    WHEN FND_API.G_EXC_ERROR THEN
      x_return_status := FND_API.G_RET_STS_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);
      debug(C_API_NAME, 'Salgo con error: '||XX_TCG_UTIL_PKG.Get_MSg(x_msg_count));

    WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);
      debug(C_API_NAME, 'Salgo con error inesperado: '|| XX_TCG_UTIL_PKG.Get_MSg(x_msg_count));

    WHEN others THEN
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE', 'XX_TCG_LIQUIDACION_1116A_PKG.Cancelar_1116A. Error inesperado - ' || SQLERRM);
      FND_MSG_PUB.add;
      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
      FND_MSG_PUB.Count_And_Get ( p_count => x_msg_count
                                , p_data  => x_msg_data);
      debug(C_API_NAME, 'Salgo con otro error: '|| XX_TCG_UTIL_PKG.Get_MSg(x_msg_count));

  END Cancelar_1116A;





 /****************************************************************************
  *                                                                          *
  * Name    : debug                                                          *
  * Purpose : Debug del paquete.                                             *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Debug ( p_api_name      IN VARCHAR2
                  , p_debug_message IN VARCHAR2)
  IS
    l_message VARCHAR2(1000);
    l_user_id NUMBER        := FND_PROFILE.value('USER_ID');
    l_debug   VARCHAR2(1)   := NVL(FND_PROFILE.value('XX_TCG_HABILITA_DEBUG'), 'N');

  BEGIN

    IF (l_user_id = 2070) THEN  --SCHEDULED_REQUESTS
      l_debug := 'Y';
    END IF;

    IF (l_debug = 'Y') THEN

      l_message :=  p_api_name || ': ' || p_debug_message;

      XX_DEBUG_AUX_PK.debug ( p_module => C_PACKAGE_NAME, p_message => l_message);

    END IF;

  END Debug;




/****************************************************************************
 *                                                                          *
 * Name    : Generar_Factura_1116A                                          *
 * Purpose : Rutina para la generacion de una factura en AR a partir de     *
 *           la liquidacion 1116a.                                          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Factura_1116A(p_liquidacion_rec  IN OUT NOCOPY liquidacion_1116a_rec_type,
                                  x_result              OUT        BOOLEAN,
                                  x_errmsg              OUT        VARCHAR2,
                                  x_warning             OUT        VARCHAR2)
  IS

    C_API_NAME                VARCHAR2(30) := 'Generar_Factura_1116A';
    l_batch_source_name       RA_BATCH_SOURCES_ALL.name%TYPE;
    l_result                  BOOLEAN;
    l_errmsg                  VARCHAR2(2000);
    l_combination_id          NUMBER;
    l_ra_fc_cust_trx_type_id  NUMBER;
    l_attributes_rec          ATTRIBUTES_REC_TYPE;
    l_appl_column_name        VARCHAR2(30);
    l_org_id                  NUMBER;
    l_cod_impuesto            VARCHAR2(100);
    l_ctxid_ficticio          NUMBER;
    l_cust_trx_id_real        NUMBER;
    eCertificar               EXCEPTION;
    l_categ_trx               VARCHAR2(100);
    l_grupo_pago              VARCHAR2(100);
    l_doc_type                VARCHAR2(100);
    l_tipo_trx                VARCHAR2(100);
    l_gr_cert                 VARCHAR2(5);
    l_gr_dep                  VARCHAR2(5);
    l_ej_interfaz_ar          BOOLEAN := FALSE;
    l_warehouse_id            NUMBER;
    l_interface_invoice_id    NUMBER;
    l_dummy                   NUMBER;


    FUNCTION Get_grupo_control(p_legal_entity_id NUMBER) RETURN VARCHAR2 IS
      l_grupo  VARCHAR2(5);
    BEGIN

      SELECT grupo_control
        INTO l_grupo
        FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
           , HR_OPERATING_UNITS          hou
       WHERE xtpc.operating_unit = hou.organization_id
         AND hou.default_legal_context_id = p_legal_entity_id;

      RETURN l_grupo;

    EXCEPTION
      WHEN OTHERS THEN
        RETURN '01';
    END;


  BEGIN

    x_result := TRUE;

    -- Si se ha creado una factura ficticia previo a la llamada a AFIP, se toman
    -- de alli los datos para la creacion de la nueva factura
    BEGIN

      SELECT cust_trx_id_ficticio
        INTO l_ctxid_ficticio
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE liquidacion_id = p_liquidacion_rec.liquidacion_id;


    EXCEPTION
      WHEN no_data_found THEN
        l_ctxid_ficticio := NULL;

      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error al buscar si existe factura ficticia cargada previamente. '||
                    'Detalle: '|| SQLERRM;
        RETURN;
    END;

    --En caso de que el proceso haya fallado al momento de crear la factura en AP
    -- para una Interco, pero se haya creado correctamente la de AR, no vuelvo a generar
    -- esta última si se re-ejecuta todo el proceso
    BEGIN

      SELECT cust_trx_id_real
        INTO l_cust_trx_id_real
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE liquidacion_id = p_liquidacion_rec.liquidacion_id;

    EXCEPTION
      WHEN no_data_found THEN
         -- Ante casos de demora en la ejecución de concurrentes, se valida que la transacción real
         --ya no exista en las tablas finales
         BEGIN

           SELECT customer_trx_id
             INTO l_cust_trx_id_real
             FROM RA_CUSTOMER_TRX_ALL
            WHERE interface_header_context = 'XX_AR_CERTIFICADOS'  --'ACOPIO'
              AND trx_number               = interface_header_attribute1
              AND trx_number               = FND_PROFILE.value('XX_ACO_RA_FC_PREFIX')
                                             || p_liquidacion_rec.numero_liquidacion;

           UPDATE XX_TCG_LIQUIDACIONES_1116A
              SET cust_trx_id_real = l_cust_trx_id_real
            WHERE liquidacion_id   = p_liquidacion_rec.liquidacion_id;

           COMMIT;

         EXCEPTION
           WHEN no_data_found THEN
             l_cust_trx_id_real := NULL;

           WHEN others THEN
             x_result := FALSE;
             x_errmsg := 'Error al confirmar si existe factura real en AR generada previamente. '||
                         'Detalle: '|| SQLERRM;
             RETURN;
         END;

      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error al buscar si existe factura en AR cargada previamente. '||
                    'Detalle: '|| SQLERRM;
        RETURN;
    END;


    IF (l_cust_trx_id_real IS NOT NULL) THEN

      BEGIN

        SELECT customer_trx_id
          INTO l_dummy
          FROM RA_CUSTOMER_TRX_ALL
         WHERE customer_trx_id = l_cust_trx_id_real;

      EXCEPTION
        WHEN no_data_found THEN
          x_result := FALSE;
          x_errmsg := 'La factura de AR informada en el Certificado no existe';
          RETURN;

        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error al buscar la factura de AR informada en el Certificado. '||
                      'Detalle: '||SQLERRM;
          RETURN;

      END;

      BEGIN

        --De haberse generado la transacción de AR correctamente y aún no llegar a realizar la factura en AP
        -- se revisa que no hayan quedado datos en la interfase de AP
        SELECT invoice_id
          INTO l_interface_invoice_id
          FROM AP_INVOICES_INTERFACE
         WHERE invoice_num     = p_liquidacion_rec.numero_liquidacion
           AND source          = 'XX_AP_CERTIFICADOS'
           AND NVL(status,'X') != 'PROCESSED';


        DELETE FROM AP_INVOICE_LINES_INTERFACE
         WHERE invoice_id = l_interface_invoice_id;

        DELETE FROM AP_INVOICES_INTERFACE
         WHERE invoice_id = l_interface_invoice_id;

        COMMIT;

      EXCEPTION
        WHEN no_data_found THEN
          NULL;

        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error al eliminar la información en la interfase de AP. '||
                      'Detalle: '||SQLERRM;
          RETURN;
      END;

    END IF;



    /* CR961 - Se solicita enviar el Organization id en el campo de warehouse_id
    -----------------------
    -- Id de Organizacion
    ----------------------
    BEGIN

      SELECT MIN(od.organization_id) warehouse_id
        INTO l_warehouse_id
        FROM FINANCIALS_SYSTEM_PARAMS_ALL   fsp
           , ( SELECT oi.organization_id
                    , ou.name                        organization_name
                    , TO_NUMBER(oi.org_information1) set_of_books_id
                    , TO_NUMBER(oi.org_information3) unit_operation
                 FROM HR_ORGANIZATION_INFORMATION oi
                    , HR_ORGANIZATION_UNITS       ou
                WHERE 1=1
                  AND ou.organization_id  = oi.organization_id
                  AND oi.org_information_context = 'Accounting Information')  od
       WHERE 1=1
         AND od.set_of_books_id = fsp.set_of_books_id
         AND od.organization_id = fsp.inventory_organization_id
         AND od.unit_operation  = p_liquidacion_rec.operating_unit;

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error al buscar el warehouse_id. '||SQLERRM;
        RETURN;
    END;*/


    IF (l_ctxid_ficticio IS NULL) THEN


      IF (p_liquidacion_rec.es_canje = 'N') THEN

        --------------------------------------------------------------------
        -- Se obtiene el batch_source_name de la configuracion por compania
        --------------------------------------------------------------------
        BEGIN

          SELECT ra_fc_batch_source_name
               , ra_fc_cust_trx_type_id
            INTO l_batch_source_name
               , l_ra_fc_cust_trx_type_id
            FROM XX_TCG_PARAMETROS_COMPANIA
           WHERE operating_unit = p_liquidacion_rec.operating_unit;

        EXCEPTION
          WHEN no_data_found THEN
            x_result := FALSE;
            x_errmsg := 'No fue posible obtener la configuracion de acopio '
                      ||'para la compania: '|| p_liquidacion_rec.operating_unit ||'. '
                      ||'No fue posible obtener el origen de lote para la '
                      ||'generacion de la factura.';
            RETURN;
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error obteniendo la configuracion de acopio '
                      ||'para la compania: '|| p_liquidacion_rec.operating_unit ||'. '
                      ||'No fue posible obtener el origen de lote para la '
                      ||'generacion la factura. Detalle: ' || SQLERRM;
            RETURN;
        END;

      ELSE

        -- Obtengo origen y tipo de transaccion a partir de los parametros de cia
        -- para las operaciones de canje.
        BEGIN

          SELECT xtpc.ra_fccje_batch_source_name
               , rbs.default_inv_trx_type
            INTO l_batch_source_name,
                 l_ra_fc_cust_trx_type_id
            FROM XX_TCG_PARAMETROS_COMPANIA xtpc
               , RA_BATCH_SOURCES_ALL       rbs
           WHERE xtpc.ra_fccje_batch_source_name = rbs.name
             AND rbs.org_id                      = xtpc.operating_unit
             AND xtpc.operating_unit             = p_liquidacion_rec.operating_unit;

        EXCEPTION
          WHEN OTHERS THEN
            x_result := FALSE;
            x_errmsg := 'Error obteniedo la configuracion de acopio '
                      ||'para la compania: '|| p_liquidacion_rec.legal_entity_id ||'. '
                      ||'No fue posible obtener el origen de lote para la '
                      ||'generacion la factura de canje. Detalle: ' || SQLERRM;
            RETURN;
        END;

      END IF;


    ELSE

      BEGIN

          SELECT rbs.name
               , xtpc.tipo_trx_ar_id
               , rct.type
            INTO l_batch_source_name
               , l_ra_fc_cust_trx_type_id
               , l_doc_type
            FROM XX_TCG_PARAMETROS_COMPROBANTE  xtpc
               , RA_BATCH_SOURCES_ALL           rbs
               , RA_CUST_TRX_TYPES_ALL          rct
           WHERE xtpc.origen_trx_ar_id     = rbs.batch_source_id
             AND xtpc.tipo_trx_ar_id       = rct.cust_trx_type_id
             AND xtpc.operating_unit       = p_liquidacion_rec.operating_unit
             AND xtpc.codigo_doc           = 'CERTIFICADO'
             AND xtpc.tipo_doc             = 'OFICIAL'
             AND xtpc.canje                = p_liquidacion_rec.es_canje
             AND xtpc.tipo_trx_ar_post_gl  = 'Y'
             AND xtpc.tipo_trx_ar_tax_calc = 'N';

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniedo la configuracion de acopio para la compania: '
                      || p_liquidacion_rec.operating_unit ||'. No fue posible obtener el origen de lote '
                      ||'ni el tipo de transaccion para la generacion la factura con canje = '
                      ||p_liquidacion_rec.es_canje||'. Detalle: ' || SQLERRM;
          RETURN;
      END;

    END IF;


    IF (l_batch_source_name IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se espefico el nombre del origen de lote para la compania: '||
                  p_liquidacion_rec.operating_unit ||'. '||
                  'No fue posible determinar el origen de lote para la generacion de la factura.';
      RETURN;
    END IF;


    IF (l_ra_fc_cust_trx_type_id IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se espefico el tipo de transaccion de AR para la compania: '||
                   p_liquidacion_rec.operating_unit ||'. Por favor verifique la configuracion de los paramtros. ';
      RETURN;
    END IF;


    IF (p_liquidacion_rec.customer_class_code != 'INTERCOMPANY') THEN


      --------------------------------------------------------------------
      -- Se obtiene el numero de segmento para almacenar el pedido de vta
      --------------------------------------------------------------------
      l_result := XX_UTIL_PK.dff_get_column( p_appl_short_name   => 'AR'
                                           , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                           , p_desc_flex_context => 'AR'
                                           , p_desc_flex_column  => 'XX_AR_NRO_PEDIDO_OM'
                                           , p_appl_column_name  => l_appl_column_name
                                           , p_mesg_error        => l_errmsg );
      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '||
                    ' "XX_AR_NRO_PEDIDO_OM" dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '|| l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

      Set_Attribute_Value( p_attributes_rec => l_attributes_rec
                         , p_column_name    => l_appl_column_name
                         , p_value          => p_liquidacion_rec.oe_order_number);

      ----------------------------------------------------------------------------
      -- Se obtiene el numero de segmento para almacenar el tipo de pedido de vta
      ----------------------------------------------------------------------------
      l_result := XX_UTIL_PK.dff_get_column( p_appl_short_name   => 'AR'
                                           , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                           , p_desc_flex_context => 'AR'
                                           , p_desc_flex_column  => 'XX_AR_TIPO_PEDIDO_OM'
                                           , p_appl_column_name  => l_appl_column_name
                                           , p_mesg_error        => l_errmsg );
      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para '||
                    'almacenar el segmento "XX_AR_TIPO_PEDIDO_OM" dentro '||
                    'dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '||
                    l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

      Set_Attribute_Value( p_attributes_rec => l_attributes_rec
                         , p_column_name    => l_appl_column_name
                         , p_value          => p_liquidacion_rec.oe_order_type);

    END IF;


    /* CR961 - Se solicita no pasar este valor
    ------------------------------------------------------------------------
    -- Se obtiene el numero de segmento para almacenar tipo liquidacion
    ------------------------------------------------------------------------
    l_result := XX_UTIL_PK.dff_get_column( p_appl_short_name   => 'AR'
                                         , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                         , p_desc_flex_context => 'AR'
                                         , p_desc_flex_column  => 'XX_AR_TIPO_LIQUIDACION'
                                         , p_appl_column_name  => l_appl_column_name
                                         , p_mesg_error        => l_errmsg);
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para '
                ||'almacenar el segmento "XX_AR_TIPO_LIQUIDACION" dentro '
                ||'dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '
                ||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    Set_Attribute_Value( p_attributes_rec => l_attributes_rec
                       , p_column_name    => l_appl_column_name
                       , p_value          => 'Unica');
    */

    IF (l_ctxid_ficticio IS NULL) THEN

      -------------------------------------------------------------------
      -- Por cada linea de la liquidacion genero la linea en la interface
      -------------------------------------------------------------------
      FOR l_index IN 1 .. p_liquidacion_rec.lineas.COUNT LOOP

        --Se obtiene codigo de impuesto para cada linea de liquidacion
        BEGIN

          SELECT aml_gldfv.transaction_condition_class
            INTO l_cod_impuesto
            FROM AR_MEMO_LINES_ALL_VL     aml
               , AR_MEMO_LINES_ALL_B1_DFV aml_gldfv
           WHERE aml.row_id       = aml_gldfv.row_id
             AND aml.memo_line_id = p_liquidacion_rec.lineas(l_index).memo_line_id;

        EXCEPTION
          WHEN OTHERS THEN
            x_result := FALSE;
            x_errmsg := 'Error generando Factura. Se produjo un error al obtener el codigo de impuesto '||
                        'para la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_name ||
                       '. Detalle: '|| SQLERRM;
            RETURN;
        END;

        ------------------------
        -- Se inserta la linea
        ------------------------
        BEGIN

          INSERT INTO RA_INTERFACE_LINES_ALL
            ( line_type
            , cust_trx_type_id
            , orig_system_bill_address_id
            , trx_date
            , batch_source_name
            , trx_number
            , quantity
            , currency_code
            , unit_selling_price
            , amount
            , conversion_type
            , conversion_rate
            , conversion_date
            , set_of_books_id
            , memo_line_name
            , memo_line_id
            , line_gdf_attribute2
            , line_gdf_attribute3
            , interface_line_context
            , interface_line_attribute1
            , interface_line_attribute2
            , interface_line_attribute3
            , interface_line_attribute5
            , orig_system_ship_address_id
            , ship_date_actual
            , warehouse_id
            , header_gdf_attr_category
            , line_gdf_attr_category
            , orig_system_bill_customer_id
            , orig_system_ship_customer_id
            , orig_system_sold_customer_id
            , term_id
            , receipt_method_name
            , description
            , gl_date
            , amount_includes_tax_flag
            , header_attribute_category
            , header_attribute1
            , header_attribute2
            , header_attribute3
            , header_attribute4
            , header_attribute5
            , header_attribute6
            , header_attribute7
            , header_attribute8
            , header_attribute9
            , header_attribute10
            , header_attribute11
            , header_attribute12
            , header_attribute13
            , header_attribute14
            , header_attribute15
            , org_id
            , creation_date
            , created_by
            , last_update_date
            , last_updated_by
            , last_update_login
            )
          VALUES
            ( 'LINE'
            , l_ra_fc_cust_trx_type_id
            , p_liquidacion_rec.customer_bill_address_id
            , p_liquidacion_rec.fecha_liquidacion
            , l_batch_source_name
            , FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') || p_liquidacion_rec.numero_liquidacion
            , 1
            , p_liquidacion_rec.currency_code
            , p_liquidacion_rec.lineas(l_index).importe
            , p_liquidacion_rec.lineas(l_index).importe
            , NVL(p_liquidacion_rec.conversion_type,'Corporate')
            , p_liquidacion_rec.conversion_rate
            , p_liquidacion_rec.fecha_liquidacion
            , p_liquidacion_rec.set_of_books_id
            , NULL
            , p_liquidacion_rec.lineas(l_index).memo_line_id
            , 'DEFAULT'
            , l_cod_impuesto
            , 'XX_AR_CERTIFICADOS' --'ACOPIO'
            , FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') || p_liquidacion_rec.numero_liquidacion
            , 'FC'
            , l_index
            , p_liquidacion_rec.liquidacion_id
            , p_liquidacion_rec.customer_ship_address_id
            , p_liquidacion_rec.fecha_liquidacion
            , p_liquidacion_rec.organization_id                                 --, l_warehouse_id CR961
            , 'JL.AR.ARXTWMAI.TGW_HEADER'
            , 'JL.AR.ARXTWMAI.LINES'
            , p_liquidacion_rec.customer_id
            , p_liquidacion_rec.customer_id
            , p_liquidacion_rec.customer_id
            , p_liquidacion_rec.ra_term_id
            , p_liquidacion_rec.payment_method_interco
            , p_liquidacion_rec.lineas(l_index).memo_line_name
            , p_liquidacion_rec.fecha_liquidacion
            , 'N'
            , 'AR'
            , l_attributes_rec.attribute1
            , l_attributes_rec.attribute2
            , l_attributes_rec.attribute3
            , l_attributes_rec.attribute4
            , l_attributes_rec.attribute5
            , l_attributes_rec.attribute6
            , l_attributes_rec.attribute7
            , l_attributes_rec.attribute8
            , l_attributes_rec.attribute9
            , l_attributes_rec.attribute10
            , l_attributes_rec.attribute11
            , l_attributes_rec.attribute12
            , l_attributes_rec.attribute13
            , l_attributes_rec.attribute14
            , l_attributes_rec.attribute15
            , p_liquidacion_rec.operating_unit
            , SYSDATE
            , FND_GLOBAL.user_id
            , SYSDATE
            , FND_GLOBAL.user_id
            , FND_GLOBAL.login_id
            );

        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error generando factura. Se produjo un error al intentar insertar '||
                        'la linea de interface para la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_name ||
                        '. Detalle: '|| SQLERRM;
            RETURN;
        END;


          -----------------------------------
          -- Inserto la linea de distribucion
          -----------------------------------
          BEGIN
            INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL
              ( ACCOUNT_CLASS
              , INTERFACE_LINE_CONTEXT
              , AMOUNT
              , INTERFACE_LINE_ATTRIBUTE1
              , INTERFACE_LINE_ATTRIBUTE2
              , INTERFACE_LINE_ATTRIBUTE3
             -- , CODE_COMBINATION_ID    retorfit r12
              , ORG_ID
              , PERCENT
              , CREATION_DATE
              , CREATED_BY
              , LAST_UPDATE_DATE
              , LAST_UPDATED_BY
              , LAST_UPDATE_LOGIN
              )
            VALUES
              ( 'REV'
              , 'XX_AR_CERTIFICADOS' --'ACOPIO'
              , p_liquidacion_rec.lineas(l_index).importe
              , p_liquidacion_rec.numero_liquidacion
              , 'FC'
              , l_index
             -- , l_combination_id
              , p_liquidacion_rec.operating_unit
              , 100
              , SYSDATE
              , FND_GLOBAL.user_id
              , SYSDATE
              , FND_GLOBAL.user_id
              , FND_GLOBAL.login_id
            );
          EXCEPTION
            WHEN others THEN
              x_result := FALSE;
              x_errmsg := 'Error generando factura. Se produjo un error al intentar '
                          ||'insertar la linea de distribucion para la memoline: '
                          ||p_liquidacion_rec.lineas(l_index).memo_line_name ||'. Detalle: '|| SQLERRM;
              RETURN;
          END;

      END LOOP;


      COMMIT;

      l_ej_interfaz_ar := TRUE;

    ELSIF (l_cust_trx_id_real IS NULL) THEN

      -- Creación de Factura
      Generar_Doc_Trx_Definitivo ( p_liquidacion_rec    => p_liquidacion_rec
                                 , p_customer_trx_id    => l_ctxid_ficticio
                                 , p_cust_trx_type_id   => l_ra_fc_cust_trx_type_id
                                 , p_batch_source_name  => l_batch_source_name
                                 , p_doc_type           => l_doc_type
                                 , p_attributes_rec     => l_attributes_rec
                                 , x_resultado          => l_result
                                 , x_error              => l_errmsg
                                 );

       IF (NOT l_result) THEN
         x_result := FALSE;
         x_errmsg := l_errmsg;
         RETURN;
       ELSE
         l_ej_interfaz_ar := TRUE;
       END IF;

    END IF;


    debug (C_API_NAME,'Se evalua si es necesario lanzar la Interface AR: ');
    --------------------------
    -- Lanzo la interace de AR
    --------------------------
    IF (l_ej_interfaz_ar) THEN

      Ejecutar_Interface_AR_1116A( p_org_id             => p_liquidacion_rec.operating_unit
                                 , p_batch_source_name  => l_batch_source_name
                                 , p_transaction_number => FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') ||
                                                           p_liquidacion_rec.numero_liquidacion
                                 , p_customer_class     => p_liquidacion_rec.customer_class_code
                                 , x_result             => l_result
                                 , x_errmsg             => l_errmsg);

      debug (C_API_NAME,'Fin Interface AR: ');

      IF (NOT l_result) THEN
        x_warning := l_errmsg;
        x_result  := FALSE;
        RETURN;
      ELSE
        debug (C_API_NAME,'Factura a buscar: '||FND_PROFILE.value('XX_ACO_RA_FC_PREFIX')||p_liquidacion_rec.numero_liquidacion);

        BEGIN
          SELECT customer_trx_id
            INTO l_cust_trx_id_real
            FROM RA_CUSTOMER_TRX_ALL
           WHERE interface_header_context    = 'XX_AR_CERTIFICADOS' --'ACOPIO'
             AND interface_header_attribute1 = FND_PROFILE.value('XX_ACO_RA_FC_PREFIX')||
                                               p_liquidacion_rec.numero_liquidacion;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_errmsg := 'No se ha generado la factura en RA_CUSTOMER_TRX.';
            RAISE eCertificar;
        END;

        BEGIN
          UPDATE XX_TCG_LIQUIDACIONES_1116A
             SET cust_trx_id_real     = l_cust_trx_id_real
           WHERE liquidacion_id       = p_liquidacion_rec.liquidacion_id;

          COMMIT;
        EXCEPTION
          WHEN others THEN
            l_errmsg := 'Error al querer actualizar el cust_trx_id real en la tabla de Percepciones de Certificados. '||SQLERRM;
            RAISE eCertificar;
        END;


        -- Agregado CR1334
        BEGIN
          debug (C_API_NAME,'Update de las lineas ZX_LINES');

          UPDATE ZX_LINES zl
             SET (zl.global_attribute_category, zl.global_attribute2, zl.global_attribute3)
                  = (SELECT rctl.global_attribute_category, rctl.global_attribute2, rctl.global_attribute3
                       FROM RA_CUSTOMER_TRX_LINES_ALL rctl
                      WHERE rctl.customer_trx_id = zl.trx_id
                        AND rctl.customer_trx_line_id = zl.trx_line_id)
           WHERE zl.trx_id = l_cust_trx_id_real;

        EXCEPTION
          WHEN others THEN
            l_errmsg := 'Error al querer actualizar los datos globales en la tabla ZX_LINES. '||SQLERRM;
            RAISE eCertificar;
        END;

      END IF;
    END IF;


    IF (p_liquidacion_rec.customer_class_code='INTERCOMPANY') THEN

      BEGIN

        SELECT cat.lookup_code
             , NVL(xpc.grupo_pago, 'IMPUESTOS')
             , xpc.tipo_factura_trx_pos
          INTO l_categ_trx
             , l_grupo_pago
             , l_tipo_trx
          FROM XX_TCG_PARAMETROS_COMPROBANTE  xpc
             , JL_AR_AP_TRX_DGI_CODES         dgi
             , FND_LOOKUPS                    cat
         WHERE xpc.categ_trx_pos_id = dgi.trx_category_letter_id
           AND dgi.trx_category     = cat.lookup_code
           AND cat.lookup_type      = 'JLAR_LEGAL_TRX_CATEGORY'
           AND xpc.operating_unit   = (SELECT hou.organization_id
                                         FROM HR_OPERATING_UNITS hou
                                        WHERE hou.default_legal_context_id = p_liquidacion_rec.legal_entity_interco)
           AND xpc.codigo_doc       = 'CERTIFICADO'
           AND xpc.tipo_doc         = 'OFICIAL'
           AND xpc.canje            = p_liquidacion_rec.es_canje
         GROUP BY cat.lookup_code
             , xpc.grupo_pago
             , xpc.tipo_factura_trx_pos;


      EXCEPTION
        WHEN TOO_MANY_ROWS THEN

          SELECT cat.lookup_code
               , NVL(xpc.grupo_pago, 'IMPUESTOS')
               , xpc.tipo_factura_trx_pos
            INTO l_categ_trx
               , l_grupo_pago
               , l_tipo_trx
            FROM XX_TCG_PARAMETROS_COMPROBANTE  xpc
               , JL_AR_AP_TRX_DGI_CODES         dgi
               , FND_LOOKUPS                    cat
           WHERE xpc.categ_trx_pos_id     = dgi.trx_category_letter_id
             AND dgi.trx_category         = cat.lookup_code
             AND cat.lookup_type          = 'JLAR_LEGAL_TRX_CATEGORY'
             AND xpc.operating_unit       = (SELECT hou.organization_id
                                               FROM HR_OPERATING_UNITS hou
                                              WHERE hou.default_legal_context_id = p_liquidacion_rec.legal_entity_interco)
             AND xpc.codigo_doc           = 'CERTIFICADO'
             AND xpc.tipo_doc             = 'OFICIAL'
             AND xpc.canje                = p_liquidacion_rec.es_canje
             AND xpc.tipo_trx_ar_post_gl  = 'Y'
             AND xpc.tipo_trx_ar_tax_calc = 'N';

        WHEN OTHERS THEN
          l_errmsg := 'Error al intentar encontrar la categoria de trx para crear la factura en AP. '||SQLERRM;
          RAISE eCertificar;

      END;

      -- Se evalua que no sea CHS alguna de las partes
      l_gr_cert := Get_grupo_control(p_liquidacion_rec.legal_entity_id);
      l_gr_dep := Get_grupo_control(p_liquidacion_rec.legal_entity_interco);

       IF (l_categ_trx IS NOT NULL AND l_grupo_pago IS NOT NULL) THEN

         IF ( '02' NOT IN (l_gr_cert, l_gr_dep)) THEN

           Crear_Doc_Interco_AP_1116A ( p_liquidacion_rec     => p_liquidacion_rec
                                      , p_cust_trx_id_real    => l_cust_trx_id_real
                                      , p_categ_trx           => l_categ_trx
                                      , p_tipo_trx            => l_tipo_trx
                                      , p_grupo_pago          => l_grupo_pago
                                      , x_result              => l_result
                                      , x_errmsg              => l_errmsg);
           IF (NOT l_result) THEN
             RAISE eCertificar;
           END IF;
         END IF;

       ELSE
         l_errmsg := 'No se pudo encontrar la categoria de trx ó el grupo de pago'
                     ||' para crear el Doc Interco en AP.';
         RAISE eCertificar;
       END IF;

    END IF;

  EXCEPTION
    WHEN eCertificar THEN
      x_result := FALSE;
      x_errmsg := l_errmsg;

    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado generando factura. Detalle: '||SQLERRM;
  END Generar_Factura_1116A;



 /****************************************************************************
 *                                                                          *
 * Name    : Set_Attribute_Value                                            *
 * Purpose : Setea el valor en el attribute del registro de transaccion.    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Set_Attribute_Value( p_attributes_rec  IN OUT NOCOPY attributes_rec_type
                               , p_column_name     IN VARCHAR2
                               , p_value           IN VARCHAR2)
  IS
    l_column_name VARCHAR2(30);

  BEGIN

    IF (SUBSTR(p_column_name,1,7) = 'GLOBAL_') THEN
        l_column_name := SUBSTR(p_column_name,8);
    ELSE
        l_column_name := p_column_name;
    END IF;

    IF (l_column_name = 'ATTRIBUTE1') THEN
        p_attributes_rec.attribute1  := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE2') THEN
        p_attributes_rec.attribute2   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE3') THEN
        p_attributes_rec.attribute3   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE4') THEN
        p_attributes_rec.attribute4   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE5') THEN
        p_attributes_rec.attribute5   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE6') THEN
        p_attributes_rec.attribute6   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE7') THEN
        p_attributes_rec.attribute7   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE8') THEN
        p_attributes_rec.attribute8   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE9') THEN
        p_attributes_rec.attribute9   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE10') THEN
        p_attributes_rec.attribute10   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE11') THEN
        p_attributes_rec.attribute11   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE12') THEN
        p_attributes_rec.attribute12   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE13') THEN
        p_attributes_rec.attribute13   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE14') THEN
        p_attributes_rec.attribute14   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE15') THEN
        p_attributes_rec.attribute15   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE16') THEN
        p_attributes_rec.attribute16   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE17') THEN
        p_attributes_rec.attribute17   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE18') THEN
        p_attributes_rec.attribute18   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE19') THEN
        p_attributes_rec.attribute19   := p_value;
    ELSIF (l_column_name = 'ATTRIBUTE20') THEN
        p_attributes_rec.attribute20   := p_value;
    END IF;

END Set_Attribute_Value;

  --CR1919
  FUNCTION Anular_percepciones( p_tax            IN VARCHAR2
                              , p_fecha_trx_orig IN VARCHAR2
                              )
  RETURN BOOLEAN IS

    l_void_level  VARCHAR2(10);
    l_void_term   VARCHAR2(10);


  BEGIN

    BEGIN

      SELECT fld.xx_ar_void_level
           , fld.xx_ar_void_term
        INTO l_void_level
           , l_void_term
        FROM FND_LOOKUP_VALUES_VL  flv
           , FND_LOOKUP_VALUES_DFV fld
       WHERE flv.rowid       = fld.row_id
         AND flv.lookup_type = 'XX_AR_CM_TAX_JURISDICTION'
         AND fld.context     = 'XX_AR_CM_TAX_JURISDICTION'
         AND flv.lookup_code = p_tax;


    EXCEPTION
      WHEN OTHERS THEN
        l_void_level := 'T';
        l_void_term  := 'S';
    END;

    IF (l_void_level = 'N') THEN   -- No permite anular percepciones

      RETURN FALSE;

    ELSIF (l_void_level IN ('T', 'P')) THEN  -- T = Totales, P = Totales o Parciales

      IF (l_void_term IS NULL OR l_void_term = 'S') THEN  -- S = Sin plazo

        RETURN TRUE;

      ELSIF(l_void_term = 'E') THEN

        IF (p_fecha_trx_orig = TO_CHAR(SYSDATE, 'MM/YYYY')) THEN  -- La factura se anula dentro del mismo mes de su creacion

          RETURN TRUE;

        ELSE
          RETURN FALSE;

        END IF;

      END IF;

    END IF;

  END Anular_percepciones;


/****************************************************************************
 *                                                                          *
 * Name    : Generar_Doc_Trx_Definitivo                                     *
 * Purpose : Rutina que genera el documento de una Transaccion a partir     *
 *          de una documento generado previamente en forma ficticia         *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_Doc_Trx_Definitivo ( p_liquidacion_rec    IN LIQUIDACION_1116A_REC_TYPE
                                       , p_customer_trx_id    IN NUMBER
                                       , p_cust_trx_type_id   IN NUMBER
                                       , p_batch_source_name  IN VARCHAR2
                                       , p_doc_type           IN VARCHAR2
                                       , p_attributes_rec     IN ATTRIBUTES_REC_TYPE
                                       , x_resultado          OUT BOOLEAN
                                       , x_error              OUT VARCHAR2
                                         )
  IS
    C_API_NAME                    VARCHAR2(300) := 'Generar_Doc_Trx_Definitivo';

    --CONTEXTOS INTERFACE
    l_interface_line_context      RA_INTERFACE_LINES_ALL.interface_line_context%TYPE;
    l_interface_line_attribute1   RA_INTERFACE_LINES_ALL.interface_line_attribute1%TYPE;
    l_interface_line_attribute2   RA_INTERFACE_LINES_ALL.interface_line_attribute2%TYPE;
    l_interface_line_attribute3   RA_INTERFACE_LINES_ALL.interface_line_attribute3%TYPE;
    l_interface_line_attribute4   RA_INTERFACE_LINES_ALL.interface_line_attribute4%TYPE;
    l_interface_line_attribute5   RA_INTERFACE_LINES_ALL.interface_line_attribute5%TYPE;

    --DATOS CABECERA
    l_set_of_books_id              RA_INTERFACE_LINES_ALL.set_of_books_id%TYPE;
    l_cust_trx_type_id             RA_INTERFACE_LINES_ALL.cust_trx_type_id%TYPE;
    l_orig_system_bill_customer_id RA_INTERFACE_LINES_ALL.orig_system_bill_customer_id%TYPE;
    l_orig_system_bill_address_id  RA_INTERFACE_LINES_ALL.orig_system_bill_address_id%TYPE;
    l_orig_system_ship_customer_id RA_INTERFACE_LINES_ALL.orig_system_ship_customer_id%TYPE;
    l_orig_system_ship_address_id  RA_INTERFACE_LINES_ALL.orig_system_ship_address_id%TYPE;
    l_orig_system_sold_customer_id RA_INTERFACE_LINES_ALL.orig_system_sold_customer_id%TYPE;
    l_trx_date                     RA_INTERFACE_LINES_ALL.trx_date%TYPE;
    l_gl_date                      RA_INTERFACE_LINES_ALL.gl_date%TYPE;
    l_org_id                       RA_INTERFACE_LINES_ALL.org_id%TYPE;
    l_bill_to_site_use_id          RA_CUSTOMER_TRX_ALL.bill_to_site_use_id%TYPE;
    l_ship_to_site_use_id          RA_CUSTOMER_TRX_ALL.ship_to_site_use_id%TYPE;
    l_post_to_gl                   RA_CUST_TRX_TYPES_ALL.post_to_gl%TYPE;
    l_currency_code                RA_INTERFACE_LINES_ALL.currency_code%TYPE;
    l_conversion_type              RA_INTERFACE_LINES_ALL.conversion_type%TYPE;
    l_conversion_date              RA_INTERFACE_LINES_ALL.conversion_date%TYPE;
    l_conversion_rate              RA_INTERFACE_LINES_ALL.conversion_rate%TYPE;
    l_tax_code                     RA_INTERFACE_LINES_ALL.tax_code%TYPE;
    l_batch_source_name            RA_INTERFACE_LINES_ALL.batch_source_name%TYPE;
    l_cust_trx_type_name           RA_INTERFACE_LINES_ALL.cust_trx_type_name%TYPE;
    l_receipt_method_id            RA_INTERFACE_LINES_ALL.receipt_method_id%TYPE;
    l_warehouse_id                 RA_INTERFACE_LINES_ALL.warehouse_id%TYPE;
    l_comments                     RA_INTERFACE_LINES_ALL.comments%TYPE;
    l_tax_rate                     RA_INTERFACE_LINES_ALL.tax_rate%TYPE;
    l_tax_account_id               ra_interface_distributions_all.code_combination_id%TYPE;

    l_code_combination_id          ra_interface_distributions_all.code_combination_id%TYPE;
    l_description                  RA_INTERFACE_LINES_ALL.description%TYPE;
    l_description_tax              RA_INTERFACE_LINES_ALL.description%TYPE;
    l_uom_code                     RA_INTERFACE_LINES_ALL.uom_code%TYPE;
    l_global_attribute1            ra_customer_trx_lines_all.global_attribute1%TYPE;
    l_global_attribute2            ra_customer_trx_lines_all.global_attribute2%TYPE;

    l_type                         RA_CUST_TRX_TYPES_ALL.type%TYPE;
    l_term_id_ar                   RA_CUST_TRX_TYPES_ALL.cust_trx_type_id%TYPE;

    l_order_type                   oe_transaction_types_tl.name%TYPE;
    l_order_number                 oe_order_headers_all.order_number%TYPE;

    eInterfaceErrors               EXCEPTION;
    l_errmsg                       VARCHAR2(3000);
    l_user_id                      NUMBER;
    l_creation_date                DATE;
    l_login_id                     NUMBER;
    l_cant_lineas                  NUMBER := 0;

    l_cc_id                        NUMBER;
    l_result                       BOOLEAN;
    l_tax_regime_code              ZX_RATES_B.tax_regime_code%type;
    l_tax                          ZX_RATES_B.tax%type;
    l_tax_status_code              ZX_RATES_B.tax_status_code%type;


    --CR1919
    l_fecha_trx_orig               DATE;
    l_insert_linea                 BOOLEAN := TRUE;
    --


    CURSOR c_datos_linea (c_customer_trx_id RA_CUSTOMER_TRX_LINES_ALL.customer_trx_id%TYPE
                         ,c_trx_number      RA_CUSTOMER_TRX_ALL.trx_number%TYPE
                         ,c_type            RA_CUST_TRX_TYPES_ALL.type%TYPE) IS
       SELECT line_type
            , description
            , DECODE(p_doc_type,'INV', extended_amount
                               ,'CM', extended_amount * -1)     extended_amount
            , quantity_ordered
            , nvl(quantity_invoiced, quantity_credited)         quantity_invoiced
            , DECODE(p_doc_type,'INV',unit_selling_price
                               ,'CM',unit_selling_price * -1)   unit_selling_price
            , DECODE(p_doc_type,'INV', unit_standard_price
                               ,'CM', unit_standard_price * -1) unit_standard_price
            , memo_line_id
            , inventory_item_id
            , uom_code
            , tax_exempt_flag
            , amount_includes_tax_flag
            , global_attribute_category
            , global_attribute2
            , global_attribute3
            , warehouse_id
            , null vat_tax_id
            , customer_trx_line_id
            , line_number
         FROM RA_CUSTOMER_TRX_LINES_ALL rctl
        WHERE line_type = 'LINE'
          AND customer_trx_id = c_customer_trx_id
          --Valida que ya no exista el copiado en la interface
          AND NOT EXISTS (SELECT DISTINCT 'Y'
                            FROM RA_INTERFACE_LINES_ALL
                           WHERE interface_line_context    = 'XX_AR_CERTIFICADOS' --'ACOPIO'
                             AND interface_line_attribute1 = c_trx_number
                             AND interface_line_attribute2 = p_doc_type)
          AND NOT EXISTS (SELECT 'Y'
                            FROM RA_CUSTOMER_TRX_ALL   rct
                               , RA_CUST_TRX_TYPES_ALL rctt
                           WHERE rct.cust_trx_type_id = rctt.cust_trx_type_id
                             AND rct.trx_number = c_trx_number
                             AND rctt.type = c_type);


    CURSOR c_datos_imp(c_customer_trx_id RA_CUSTOMER_TRX_LINES_ALL.customer_trx_id%TYPE) IS
       SELECT rctl.line_type
            , rctl.description
            , DECODE(p_doc_type,'INV', rctl.extended_amount
                               ,'CM', rctl.extended_amount * -1)       extended_amount
            , rctl.quantity_ordered
            , DECODE(p_doc_type,'INV', rctl.unit_selling_price
                               ,'CM', rctl.unit_selling_price * -1)     unit_selling_price
            , DECODE(p_doc_type,'INV', rctl.unit_standard_price
                               ,'CM', rctl.unit_standard_price * -1)   unit_standard_price
            , rctl.memo_line_id
            , rctl.inventory_item_id
            , rctl.uom_code
            , rctl.tax_exempt_flag
            , rctl.amount_includes_tax_flag
            , rctl.global_attribute_category
            , rctl.global_attribute2
            , rctl.global_attribute3
            , rctl.warehouse_id
            , rctl.vat_tax_id
            , rctl.tax_rate
            , rctl.customer_trx_line_id
            , rctl.link_to_cust_trx_line_id
         FROM RA_CUSTOMER_TRX_LINES_ALL rctl
        WHERE rctl.line_type       = 'TAX'
          AND rctl.customer_trx_id = c_customer_trx_id;


    --CURSOR DATOS DISTRIBUCIONES
    CURSOR c_datos_dist (c_customer_trx_line_id RA_CUSTOMER_TRX_LINES_ALL.customer_trx_id%TYPE) IS
       SELECT account_class
            , DECODE(p_doc_type,'INV',amount
                               ,'CM',amount * -1)        amount
            , percent
            , code_combination_id
            , org_id
         FROM RA_CUST_TRX_LINE_GL_DIST_ALL
        WHERE customer_trx_line_id = c_customer_trx_line_id;


  BEGIN

    debug(C_API_NAME, 'Iniciando.');

    SAVEPOINT Generar_Doc_Trx_SVP;

    --------------------------------DATOS INTERFAZ-------------------------------
    debug(C_API_NAME, 'Datos Interfaz.');
    l_interface_line_context    := 'XX_AR_CERTIFICADOS';  -- ACOPIO

    IF (p_doc_type='INV') THEN
      l_interface_line_attribute1 := FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') || p_liquidacion_rec.numero_liquidacion; --trx_number
      l_comments                  := 'Factura de AR para Certificado: '||p_liquidacion_rec.liquidacion_id;
    ELSIF (p_doc_type='CM') THEN
      l_interface_line_attribute1 := FND_PROFILE.value('XX_ACO_RA_NC_PREFIX') || p_liquidacion_rec.numero_liquidacion; --trx_number
      l_comments                  := 'Nota de Crédito de AR para Certificado: '||p_liquidacion_rec.liquidacion_id;
    END IF;

    l_interface_line_attribute2 := p_doc_type;
    l_interface_line_attribute4 := p_customer_trx_id;                           --Customer Trx Id ficticio
    l_interface_line_attribute5 := p_liquidacion_rec.liquidacion_id;


   --------------------------------DATOS CABECERA--------------------------------
   debug(C_API_NAME, 'Datos Cabecera.');
    BEGIN
      SELECT rct.set_of_books_id
           , rct.bill_to_customer_id
           , rct.bill_to_site_use_id
           , rct.ship_to_customer_id
           , rct.ship_to_site_use_id
           , rct.sold_to_customer_id
           , rct.org_id
           , nvl(rct.exchange_rate_type,'User')
           , nvl(rct.exchange_date,sysdate)
           , nvl(rct.exchange_rate,1)
           , rct.invoice_currency_code
           , DECODE(p_doc_type,'INV',rct.trx_date
                              ,'CM',p_liquidacion_rec.fecha_anulacion)
           , rct.receipt_method_id
           , rct_dfv.xx_ar_tipo_pedido_om
           , rct_dfv.xx_ar_nro_pedido_om
           --CR1919
           , rct.trx_date           fecha_trx_original
           --
        INTO l_set_of_books_id
           , l_orig_system_bill_customer_id
           , l_bill_to_site_use_id
           , l_orig_system_ship_customer_id
           , l_ship_to_site_use_id
           , l_orig_system_sold_customer_id
           , l_org_id
           , l_conversion_type
           , l_conversion_date
           , l_conversion_rate
           , l_currency_code
           , l_trx_date
           , l_receipt_method_id
           , l_order_type
           , l_order_number
           , l_fecha_trx_orig
        FROM RA_CUSTOMER_TRX_ALL     rct
           , RA_CUSTOMER_TRX_ALL_DFV rct_dfv
       WHERE rct.rowid           = rct_dfv.row_id
         AND rct.customer_trx_id = p_customer_trx_id;


    EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_errmsg := 'Error: No se encontro la transaccion que se quiere copiar para customer_trx_id: '||p_customer_trx_id;
         RAISE eInterfaceErrors;

      WHEN OTHERS THEN
         l_errmsg:= 'Error general buscando trx para copiar para p_customer_trx_id: '||p_customer_trx_id||' Error Sql: '||sqlerrm;
         RAISE eInterfaceErrors;
    END;

    BEGIN
      debug(C_API_NAME, 'Scheduled Requests.');
      SELECT user_id
           , SYSDATE
           , -1
        INTO l_user_id
           , l_creation_date
           , l_login_id
        FROM FND_USER
       WHERE user_name = 'SCHEDULED_REQUESTS';

    EXCEPTION
      WHEN others THEN
        l_errmsg:= 'Error general buscando el id del usuario Scheduled Requests: Error Sql: '||sqlerrm;
        RAISE eInterfaceErrors;
    END;

    -------------------------Terminos de pago en Nulo para NCs-------------------
    BEGIN
      debug(C_API_NAME, 'Terminos de Pago.');
      SELECT nvl(type,'INV')
        INTO l_type
        FROM RA_CUST_TRX_TYPES_ALL
       WHERE cust_trx_type_id = p_cust_trx_type_id;

      IF l_type = 'CM' THEN
         l_term_id_ar := NULL;
      ELSE
         l_term_id_ar := p_liquidacion_rec.ra_term_id;
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_errmsg := 'Error: No se encontro type para p_cust_trx_type_id: '||p_cust_trx_type_id;
         RAISE eInterfaceErrors;

      WHEN OTHERS THEN
         l_errmsg := 'Error General buscando type para p_cust_trx_type_id: '||p_cust_trx_type_id||' Error: '||SQLERRM;
         RAISE eInterfaceErrors;
    END;


    BEGIN
      debug(C_API_NAME, 'Bill To: Cust_acct_site_id.');
      SELECT cust_acct_site_id
        INTO l_orig_system_bill_address_id
        FROM HZ_CUST_SITE_USES_ALL
       WHERE site_use_id = l_bill_to_site_use_id;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_errmsg := 'Error: No se encontro cust_acct_site_id para: '||l_bill_to_site_use_id;
         RAISE eInterfaceErrors;

      WHEN OTHERS THEN
         l_errmsg := 'Error general buscando cust_acct_site_id para : '||l_bill_to_site_use_id||' Error Sql: '||sqlerrm;
         RAISE eInterfaceErrors;
    END;


    BEGIN
      debug(C_API_NAME, 'Ship To: Cust_acct_site_id.');
      SELECT cust_acct_site_id
        INTO l_orig_system_ship_address_id
        FROM HZ_CUST_SITE_USES_ALL
       WHERE site_use_id = l_ship_to_site_use_id;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
         l_errmsg := 'Error: No se encontro cust_acct_site_id para: '||l_ship_to_site_use_id;
         RAISE eInterfaceErrors;

      WHEN OTHERS THEN
         l_errmsg := 'Error general buscando cust_acct_site_id para : '||l_ship_to_site_use_id||' Error Sql: '||sqlerrm;
         RAISE eInterfaceErrors;
    END;

    ----------------------- Verificar origen -------------------------
    BEGIN
      debug(C_API_NAME, 'Batch source name.');
      SELECT name
        INTO l_batch_source_name
        FROM RA_BATCH_SOURCES_ALL
       WHERE name      = p_batch_source_name
         AND nvl(end_date,sysdate) >= sysdate
         AND org_id                 = l_org_id;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
          l_errmsg := 'Error: No se encontro batch_source_name '||p_batch_source_name||' para org_id '||l_org_id;
          RAISE eInterfaceErrors;

      WHEN OTHERS THEN
          l_errmsg := 'Error general buscando p_batch_source_name '||p_batch_source_name||' para org_id '
                      ||l_org_id||' Error sql:'||sqlerrm;
          RAISE eInterfaceErrors;
    END;

   ----------------------- Verificar tipo de transaccion ------------------------
    BEGIN
      debug(C_API_NAME, 'Tipo de Transaccion.');
      SELECT name
           , nvl(post_to_gl,'N')
        INTO l_cust_trx_type_name
           , l_post_to_gl
        FROM RA_CUST_TRX_TYPES_ALL
       WHERE cust_trx_type_id       = p_cust_trx_type_id
         AND nvl(end_date,sysdate) >= sysdate
         AND org_id                 = l_org_id;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
          l_errmsg := 'Error: No se encontro cust_trx_type_name para: '||p_cust_trx_type_id;
          RAISE eInterfaceErrors;

      WHEN OTHERS THEN
          l_errmsg := 'Error general buscando p_cust_trx_type_name: '||p_cust_trx_type_id||' Error sql:'||sqlerrm;
          RAISE eInterfaceErrors;

    END;



   --Si la transaccion no contabiliza en GL entonces la fecha de GL se debe pasar en blanco
    IF l_post_to_gl = 'N' THEN
      l_gl_date := NULL;

    ELSE
      l_gl_date := l_trx_date;

    END IF;

    debug(C_API_NAME, 'Iniciando For c_line.');
    FOR c_line IN c_datos_linea(p_customer_trx_id, l_interface_line_attribute1, l_type) LOOP

      l_cant_lineas := l_cant_lineas + 1;

      INSERT INTO RA_INTERFACE_LINES_ALL
        ( created_by ,creation_date ,last_updated_by ,last_update_date,last_update_login,interface_line_context,interface_line_attribute1
        , interface_line_attribute2, interface_line_attribute4, interface_line_attribute5, trx_number, batch_source_name, set_of_books_id
        , cust_trx_type_name ,orig_system_bill_customer_id ,orig_system_bill_address_id, orig_system_ship_customer_id
        , orig_system_ship_address_id, orig_system_sold_customer_id ,trx_date ,gl_date ,org_id ,line_type, description
        , currency_code, amount, conversion_type ,conversion_date ,conversion_rate ,quantity ,quantity_ordered ,unit_selling_price
        , unit_standard_price, memo_line_id, inventory_item_id ,uom_code ,tax_exempt_flag
        , amount_includes_tax_flag, line_gdf_attr_category, line_gdf_attribute2, line_gdf_attribute3, warehouse_id
        , vat_tax_id, cust_trx_type_id, term_id, tax_code, interface_line_attribute3, receipt_method_id, comments
        , header_attribute_category, header_attribute1, header_attribute2, header_attribute3, header_attribute4
        , header_attribute5, header_attribute6, header_attribute7, header_attribute8
        , header_attribute9, header_attribute10, header_attribute11, header_attribute12
        , header_attribute13, header_attribute14, header_attribute15)
      VALUES
        ( l_user_id ,l_creation_date ,l_user_id ,l_creation_date ,l_login_id ,l_interface_line_context ,l_interface_line_attribute1
        , l_interface_line_attribute2,l_interface_line_attribute4, l_interface_line_attribute5, l_interface_line_attribute1, l_batch_source_name
        , l_set_of_books_id , l_cust_trx_type_name ,l_orig_system_bill_customer_id ,l_orig_system_bill_address_id, l_orig_system_ship_customer_id
        , l_orig_system_ship_address_id, l_orig_system_sold_customer_id ,l_trx_date ,l_gl_date,l_org_id ,c_line.line_type, c_line.description
        , l_currency_code, c_line.unit_selling_price, l_conversion_type ,l_trx_date ,l_conversion_rate ,1 ,1 ,c_line.unit_selling_price
        , c_line.unit_standard_price, c_line.memo_line_id, c_line.inventory_item_id ,c_line.uom_code ,c_line.tax_exempt_flag
        , c_line.amount_includes_tax_flag,c_line.global_attribute_category, c_line.global_attribute2 ,c_line.global_attribute3, c_line.warehouse_id
        , c_line.vat_tax_id, p_cust_trx_type_id, l_term_id_ar, NULL /*l_tax_code*/, c_line.customer_trx_line_id, l_receipt_method_id ,l_comments
        , 'AR', p_attributes_rec.attribute1, p_attributes_rec.attribute2, p_attributes_rec.attribute3, p_attributes_rec.attribute4
        , p_attributes_rec.attribute5, p_attributes_rec.attribute6, p_attributes_rec.attribute7, p_attributes_rec.attribute8
        , p_attributes_rec.attribute9, p_attributes_rec.attribute10,p_attributes_rec.attribute11, p_attributes_rec.attribute12
        , p_attributes_rec.attribute13, p_attributes_rec.attribute14, p_attributes_rec.attribute15 );


      debug(C_API_NAME, 'Iniciando For c_dist.');
      FOR c_dist IN c_datos_dist(c_line.customer_trx_line_id) LOOP

        l_cc_id := c_dist.code_combination_id;


        INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL
          ( interface_line_context ,interface_line_attribute1 ,interface_line_attribute2 ,account_class ,amount
          , percent, code_combination_id ,created_by ,creation_date ,last_updated_by ,last_update_date ,last_update_login ,org_id
          , interface_line_attribute3 ,interface_line_attribute4, interface_line_attribute5)
        VALUES
          ( l_interface_line_context ,l_interface_line_attribute1 ,l_interface_line_attribute2 ,c_dist.account_class,c_dist.amount
          , c_dist.percent, l_cc_id, l_user_id ,l_creation_date ,l_user_id ,l_creation_date ,l_login_id ,c_dist.org_id
          , c_line.customer_trx_line_id, l_interface_line_attribute4, l_interface_line_attribute5);

      END LOOP;

    END LOOP;

    IF (l_cant_lineas > 0) THEN

      debug(C_API_NAME, 'Iniciando For c_imp.');
      FOR c_imp IN c_datos_imp(p_customer_trx_id) LOOP

        BEGIN
          SELECT tax_code
               , nvl(description,tax_code)
               , tax_regime_code
               , tax
               , tax_status_code
            INTO l_tax_code
               , l_description_tax
               , l_tax_regime_code
               , l_tax
               , l_tax_status_code
            FROM AR_VAT_TAX_ALL_B
           WHERE vat_tax_id = c_imp.vat_tax_id;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_errmsg := 'Error: No se encontro tax_code para: '||c_imp.vat_tax_id;
            RAISE eInterfaceErrors;

        WHEN OTHERS THEN
          l_errmsg := 'Error general buscando tax_code para: '||c_imp.vat_tax_id||' Error sql:'||sqlerrm;
          RAISE eInterfaceErrors;
        END;

        --CR1919
        IF (p_doc_type = 'CM') THEN

          l_insert_linea := Anular_percepciones(l_tax , TO_CHAR(l_fecha_trx_orig,'MM/YYYY'));

        ELSE
          l_insert_linea := TRUE;
        END IF;


        IF (l_insert_linea) THEN
        -- fin CR1919

          INSERT INTO RA_INTERFACE_LINES_ALL
            ( created_by, creation_date, last_updated_by, last_update_date, last_update_login
            , interface_line_context, interface_line_attribute1, interface_line_attribute2, trx_number, batch_source_name
            , set_of_books_id, cust_trx_type_name, orig_system_bill_customer_id, orig_system_bill_address_id, orig_system_ship_customer_id
            , orig_system_ship_address_id, orig_system_sold_customer_id, trx_date, gl_date ,org_id
            , line_type, description, currency_code, amount, conversion_type
            , conversion_date, conversion_rate, quantity, quantity_ordered, unit_selling_price
            , unit_standard_price, memo_line_id, inventory_item_id, uom_code, tax_exempt_flag
            , amount_includes_tax_flag, line_gdf_attr_category, line_gdf_attribute2, line_gdf_attribute3, warehouse_id
            , vat_tax_id, cust_trx_type_id, term_id, tax_code, tax_regime_code
            , tax, tax_status_code, tax_rate_code, interface_line_attribute3, link_to_line_context
            , link_to_line_attribute1, link_to_line_attribute2, link_to_line_attribute3, tax_rate, interface_line_attribute4
            , interface_line_attribute5, receipt_method_id, link_to_line_attribute4, link_to_line_attribute5, header_attribute_category
            , header_attribute1, header_attribute2, header_attribute3, header_attribute4, header_attribute5
            , header_attribute6, header_attribute7, header_attribute8, header_attribute9, header_attribute10
            , header_attribute11, header_attribute12, header_attribute13, header_attribute14, header_attribute15)
          VALUES
            ( l_user_id, l_creation_date, l_user_id, l_creation_date, l_login_id
            , l_interface_line_context, l_interface_line_attribute1, l_interface_line_attribute2, l_interface_line_attribute1, l_batch_source_name
            , l_set_of_books_id, l_cust_trx_type_name, l_orig_system_bill_customer_id, l_orig_system_bill_address_id, l_orig_system_ship_customer_id
            , l_orig_system_ship_address_id, l_orig_system_sold_customer_id, l_trx_date, l_gl_date, l_org_id
            , c_imp.line_type, l_description_tax, l_currency_code, c_imp.extended_amount, l_conversion_type
            , l_conversion_date, l_conversion_rate, c_imp.quantity_ordered, c_imp.quantity_ordered, c_imp.unit_selling_price
            , c_imp.unit_standard_price, c_imp.memo_line_id, c_imp.inventory_item_id, c_imp.uom_code, c_imp.tax_exempt_flag
            , c_imp.amount_includes_tax_flag, c_imp.global_attribute_category, c_imp.global_attribute2, c_imp.global_attribute3, c_imp.warehouse_id
            , c_imp.vat_tax_id, p_cust_trx_type_id, l_term_id_ar, l_tax_code, l_tax_regime_code
            , l_tax, l_tax_status_code, l_tax_code, c_imp.customer_trx_line_id, l_interface_line_context
            , l_interface_line_attribute1, l_interface_line_attribute2, c_imp.link_to_cust_trx_line_id, c_imp.tax_rate, l_interface_line_attribute4
            , l_interface_line_attribute5, l_receipt_method_id, l_interface_line_attribute4, l_interface_line_attribute5, 'AR'
            , p_attributes_rec.attribute1, p_attributes_rec.attribute2, p_attributes_rec.attribute3, p_attributes_rec.attribute4, p_attributes_rec.attribute5
            , p_attributes_rec.attribute6, p_attributes_rec.attribute7, p_attributes_rec.attribute8, p_attributes_rec.attribute9, p_attributes_rec.attribute10
            , p_attributes_rec.attribute11, p_attributes_rec.attribute12, p_attributes_rec.attribute13, p_attributes_rec.attribute14, p_attributes_rec.attribute15
            );

          debug(C_API_NAME, 'Iniciando For c_dist.');
          FOR c_dist IN c_datos_dist(c_imp.customer_trx_line_id) LOOP


            INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL
              ( interface_line_context ,interface_line_attribute1 ,interface_line_attribute2 ,account_class ,amount
              , percent, code_combination_id ,created_by ,creation_date ,last_updated_by ,last_update_date ,last_update_login ,org_id
              , interface_line_attribute3 ,interface_line_attribute4, interface_line_attribute5)
            VALUES
              ( l_interface_line_context ,l_interface_line_attribute1 ,l_interface_line_attribute2 ,c_dist.account_class,c_dist.amount
              , c_dist.percent, c_dist.code_combination_id ,l_user_id ,l_creation_date ,l_user_id, l_creation_date ,l_login_id, c_dist.org_id
              , c_imp.customer_trx_line_id, l_interface_line_attribute4, l_interface_line_attribute5);
          END LOOP;

        END IF;

      END LOOP;

      COMMIT;

    END IF;

    x_resultado := TRUE;

    debug(C_API_NAME, 'Finalizando.');
  EXCEPTION
    WHEN eInterfaceErrors THEN
      ROLLBACK TO Generar_Doc_Trx_SVP;
      x_resultado := FALSE;
      x_error     := 'Error en Generar_Doc_Trx_Definitivo: '||l_errmsg;

    WHEN others THEN
      ROLLBACK TO Generar_Doc_Trx_SVP;
      x_resultado := FALSE;
      x_error     := 'Error en Generar_Doc_Trx_Definitivo: '||SQLERRM;

  END Generar_Doc_Trx_Definitivo;



 /****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AR_1116A                                     *
 * Purpose : Rutina para la ejecucion del concurrente de AR                 *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AR_1116A ( p_org_id              IN NUMBER
                                        , p_batch_source_name   IN VARCHAR2
                                        , p_transaction_number  IN VARCHAR2
                                        , p_customer_class      IN VARCHAR2
                                        , x_result             OUT BOOLEAN
                                        , x_errmsg             OUT VARCHAR2)
  IS
    C_API_NAME          VARCHAR2(300) := 'TCG Ejecutar_Interface_AR_1116A';
    l_request_id        NUMBER;
    l_batch_source_id   NUMBER;
    l_req_status        BOOLEAN;
    l_phase             VARCHAR2(30);
    l_status            VARCHAR2(30);
    l_dev_phase         VARCHAR2(30);
    l_dev_status        VARCHAR2(30);
    l_message           VARCHAR2(3000);
    l_resp_id           NUMBER;
    l_resp_appl_id      NUMBER;
    l_user_id           NUMBER;
    l_found             BOOLEAN;


    CURSOR c_environment IS
      SELECT fug.responsibility_application_id
           , fug.responsibility_id
           , fu.user_id
        FROM FND_USER_RESP_GROUPS_DIRECT fug
           , FND_USER                    fu
           , FND_RESPONSIBILITY          fr
           , FND_APPLICATION             fa
           , FND_PROFILE_OPTIONS         fpo
           , FND_PROFILE_OPTION_VALUES   fpov
       WHERE fug.user_id               = fu.user_id
         AND fu.user_name              = 'SCHEDULED_REQUESTS'
       --   AND NVL(fug.end_date,SYSDATE+1) > SYSDATE
         AND fug.responsibility_id     = fr.responsibility_id
         AND fug.responsibility_application_id = fr.application_id
         AND fr.application_id         = fa.application_id
         AND fa.application_short_name = 'AR'
         AND fpo.profile_option_id     = fpov.profile_option_id
         AND fpo.profile_option_name   = 'ORG_ID'
         AND fpov.level_id             = 10003
         AND fr.responsibility_id      = fpov.level_value
         AND fpov.profile_option_value = TO_CHAR(p_org_id)
         AND (fr.responsibility_key    LIKE '%SUPERUSER'
             OR
             fr.responsibility_key     LIKE '%SUPER%USUARIO');


  BEGIN

    debug(C_API_NAME, 'Iniciando.');

    x_result := TRUE;

    debug(C_API_NAME, 'Cursor c_environment.');
    OPEN c_environment;
    FETCH c_environment INTO l_resp_appl_id
                           , l_resp_id
                           , l_user_id;
    l_found := c_environment%FOUND;
    CLOSE c_environment;

    debug(C_API_NAME, 'l_resp_appl_id: '||l_resp_appl_id||' - l_resp_id: '||l_resp_id||' -  l_user_id: '||l_user_id);
    IF (NOT l_found) THEN
      x_result := FALSE;
      x_errmsg := 'No se puede inicializar el ambiente para ejecutar la interface de AR con el org_id '||p_org_id;
      RETURN;
    END IF;

    debug(C_API_NAME, 'FND_GLOBAL.apps_initialize');
    FND_GLOBAL.apps_initialize(resp_appl_id => l_resp_appl_id
                              ,resp_id      => l_resp_id
                              ,user_id      => l_user_id);

    -----------------------------
    -- Obtengo el batch_source_id
    -----------------------------
    BEGIN

        SELECT batch_source_id
          INTO l_batch_source_id
          FROM ra_batch_sources_all
         WHERE org_id = p_org_id
           AND name   = p_batch_source_name;

      debug(C_API_NAME, 'Batch source id: '||l_batch_source_id);
    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo el identificador para el origen del batch: '|| p_batch_source_name;
        RETURN;
    END;



    debug(C_API_NAME, 'Submit Request');
    l_request_id :=  FND_REQUEST.Submit_Request (
                                 'JL'
                               , 'JLARRAIM'
                               , NULL
                               , NULL
                               , FALSE
                               , '1'
                               , p_org_id
                               , l_batch_source_id
                               , p_batch_source_name
                               , FND_DATE.date_to_canonical(TRUNC(SYSDATE))
                               , NULL, NULL, NULL, NULL, NULL
                               , NULL, NULL, NULL, NULL, NULL
                               , p_transaction_number
                               , p_transaction_number
                               , NULL, NULL, NULL, NULL
                               , NULL, NULL, NULL, NULL
                               , 'Y'
                               , NULL
                               );

    COMMIT;

    IF NVL(l_request_id, 0) = 0 THEN
      x_errmsg := 'No fue posible ejecutar el concurrente: Programa Principal Facturación '||
                  'Automática Cuentas a Cobrar de Argentina. '||
                  'Por favor ejecutelo manualmente';
      x_result := FALSE;
    END IF;

    debug(C_API_NAME, 'l_request_id: '||l_request_id);
    IF  (l_request_id>0) THEN

      LOOP

        LOOP

          l_req_status := FND_CONCURRENT.wait_for_request
                                        ( request_id      => l_request_id
                                        , interval        => 30
                                        , max_wait        => 300
                                        -- out arguments
                                        , phase           => l_phase
                                        , status          => l_status
                                        , dev_phase       => l_dev_phase
                                        , dev_status      => l_dev_status
                                        , message         => l_message
                                        );

        EXIT WHEN UPPER (l_phase) IN ('COMPLETED','FINALIZADO')
               OR UPPER (l_status) IN ('CANCELLED', 'ERROR', 'TERMINATED'
                                      ,'CANCELADO', 'FINALIZADO');


        END LOOP;

        IF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'ERROR' THEN
          x_errmsg := 'No fue posible ejecutar el concurrente: Programa Principal '||
                      'de Facturacion Automatica Cuentas a Cobrar de Argentina. '||
                      'Detalle: '||l_message;
          x_result := FALSE;

        ELSIF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'NORMAL' THEN
          x_result := TRUE;
          COMMIT;
        END IF;

        IF (x_result) THEN
          BEGIN
            SELECT request_id
              INTO l_request_id
              FROM FND_CONC_REQ_SUMMARY_V
             WHERE parent_request_id = l_request_id;
          EXCEPTION
            WHEN OTHERS THEN
              l_request_id := -1;
          END;
        END IF;

        EXIT WHEN ((l_request_id=-1) OR (NOT x_result));

      END LOOP;

    END IF;

    debug(C_API_NAME, 'Finalizando Ejecutar Interface AR');
  EXCEPTION
    WHEN others THEN
      x_errmsg := 'Se produjo un error inesperado al intentar ejecutar la interface con AR.'||
                  ' Por favor intente manualmente. Detalle: '|| SQLERRM;
      x_result := FALSE;
  END Ejecutar_Interface_AR_1116A;




/****************************************************************************
 *                                                                          *
 * Name    : Crear_Doc_Interco_AP_1116A                                     *
 * Purpose : Rutina que genera la factura o la nota de credito en AP en     *
 *          funcion de una factura o nota de credito en AR (interco)        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Crear_Doc_Interco_AP_1116A ( p_liquidacion_rec     IN LIQUIDACION_1116A_REC_TYPE
                                       , p_cust_trx_id_real    IN NUMBER
                                       , p_categ_trx           IN VARCHAR2
                                       , p_tipo_trx            IN VARCHAR2
                                       , p_grupo_pago          IN VARCHAR2
                                       , x_result              OUT BOOLEAN
                                       , x_errmsg              OUT VARCHAR2)
  IS
    C_API_NAME      VARCHAR2(300) := 'TCG Crear_Doc_Interco_AP_1116A';
    l_result        BOOLEAN;
    l_errmsg        VARCHAR2(3000);
    l_ap_term_id    NUMBER;
    l_org_id        NUMBER;
    l_invoice_id    NUMBER;
    eCrearDoc       EXCEPTION;


  BEGIN

    debug(C_API_NAME, 'Iniciando');
    x_result := TRUE;

    SELECT att.term_id
      INTO l_ap_term_id
      FROM AP_TERMS_TL  att
         , AP_TERMS_TL_DFV  attd
     WHERE att.rowid                        = attd.row_id
       AND attd.context                     = 'AR'
       AND att.language                     = userenv('LANG')
       AND TO_NUMBER(xx_ap_termino_pago_ar) = p_liquidacion_rec.ra_term_id;


    IF (NOT XX_AR_AP_INTERCO_PKG.crear_doc_inter ( p_customer_trx_id            => p_cust_trx_id_real
                                                 , p_tipo_trx                   => p_categ_trx
                                                 , p_source                     => 'XX_AP_CERTIFICADOS'
                                                 , p_pay_group                  => p_grupo_pago
                                                 , p_terms_id                   => l_ap_term_id
                                                 , p_payment_method_lookup_code => p_liquidacion_rec.payment_method_interco
                                                 , p_conc_id                    => p_liquidacion_rec.liquidacion_id
                                                 )) THEN

      x_result := FALSE;
      IF (p_tipo_trx='STANDARD') THEN
        x_errmsg := 'Error intentado generar la interfaz de la factura en AP: '||XX_AR_AP_INTERCO_PKG.e_message;
      ELSIF (p_tipo_trx='CREDIT') THEN
        x_errmsg := 'Error intentado generar la interfaz de la Nota de Credito Interco en AP: '||XX_AR_AP_INTERCO_PKG.e_message;
      END IF;

    ELSE

      COMMIT;


      BEGIN
        SELECT org_id
          INTO l_org_id
          FROM AP_INVOICES_INTERFACE
         WHERE source                   = 'XX_AP_CERTIFICADOS'
           AND invoice_type_lookup_code = p_tipo_trx
           AND ((p_tipo_trx   = 'STANDARD' AND
                 invoice_num  = p_liquidacion_rec.numero_liquidacion )
                OR
                (p_tipo_trx = 'CREDIT' AND
                 invoice_num  = p_liquidacion_rec.numero_liquidacion||'*'));
      EXCEPTION
        WHEN no_data_found THEN
          l_errmsg := 'No se puede determinar el org_id Interco para '||p_liquidacion_rec.numero_liquidacion;
          RAISE eCrearDoc;
        WHEN too_many_rows THEN
          l_errmsg := 'Se encuentra más de un documento en la interface de AP con el numero: '||p_liquidacion_rec.numero_liquidacion;
          RAISE eCrearDoc;
      END;

      Ejecutar_Interface_AP_1116A( p_org_id   => l_org_id
                                 , x_result   => l_result
                                 , x_errmsg   => l_errmsg);


      IF (NOT l_result) THEN

        RAISE eCrearDoc;

      ELSE

        BEGIN
          SELECT invoice_id
            INTO l_invoice_id
            FROM AP_INVOICES_ALL
           WHERE source      = 'XX_AP_CERTIFICADOS'
             AND invoice_type_lookup_code = p_tipo_trx
             AND ((p_tipo_trx   = 'STANDARD' AND
                 invoice_num  = p_liquidacion_rec.numero_liquidacion )
                OR
                (p_tipo_trx = 'CREDIT' AND
                 invoice_num  = p_liquidacion_rec.numero_liquidacion||'*' ));
        EXCEPTION
          WHEN no_data_found THEN
            IF (p_tipo_trx='STANDARD') THEN
              l_errmsg := 'No se encuentra la Factura en AP para el certificado '||p_liquidacion_rec.numero_liquidacion||
                          ' con el source = XX_AP_CERTIFICADOS';
            ELSIF (p_tipo_trx='CREDIT') THEN
              l_errmsg := 'No se encuentra la Nota de Credito en AP para el certificado '||p_liquidacion_rec.numero_liquidacion||
                          ' con el source = XX_AP_CERTIFICADOS';
            END IF;
            RAISE eCrearDoc;
        END;


        XX_TCG_LIQUIDACION_UTIL_PKG.Ejecutar_Validacion_Documento ( p_invoice_id   => l_invoice_id
                                                                  , x_result       => l_result
                                                                  , x_errmsg       => l_errmsg);

        IF (NOT l_result) THEN

          RAISE eCrearDoc;

        ELSE

          XX_TCG_LIQUIDACION_UTIL_PKG.Ejecutar_Liberacion_de_Holds ( p_org_id            => l_org_id
                                                                   , p_invoice_id        => l_invoice_id
                                                                   , x_result            => l_result
                                                                   , x_errmsg            => l_errmsg);

          IF (NOT l_result) THEN

            RAISE eCrearDoc;
          END IF;

        END IF;

      END IF;

    END IF;


  EXCEPTION
    WHEN eCrearDoc THEN
      x_result := FALSE;
      x_errmsg := l_errmsg;

    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado en Crear_Doc_Interco_AP: '||SQLERRM;

  END Crear_Doc_Interco_AP_1116A;




/****************************************************************************
 *                                                                          *
 * Name    : Ejecutar_Inteface_AP_1116A                                     *
 * Purpose : Rutina para la ejecucion del concurrente de Open Interfcae     *
 *          en AP                                                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Ejecutar_Interface_AP_1116A ( p_org_id              IN NUMBER
                                        , x_result              OUT BOOLEAN
                                        , x_errmsg              OUT VARCHAR2)
  IS

    C_API_NAME          VARCHAR2(300) := 'TCG Ejecutar_Interface_AP_1116A';
    l_request_id        NUMBER;
    l_req_status        BOOLEAN;
    l_phase             VARCHAR2(30);
    l_status            VARCHAR2(30);
    l_dev_phase         VARCHAR2(30);
    l_dev_status        VARCHAR2(30);
    l_message           VARCHAR2(3000);
    l_resp_appl_id      NUMBER;
    l_resp_id           NUMBER;
    l_user_id           NUMBER;
    l_found             BOOLEAN;



    CURSOR c_environment IS
      SELECT fug.responsibility_application_id
           , fug.responsibility_id
           , fu.user_id
        FROM FND_USER_RESP_GROUPS_DIRECT fug
           , FND_USER                    fu
           , FND_RESPONSIBILITY          fr
           , FND_APPLICATION             fa
           , FND_PROFILE_OPTIONS         fpo
           , FND_PROFILE_OPTION_VALUES   fpov
       WHERE fug.user_id               = fu.user_id
         AND fu.user_name              = 'SCHEDULED_REQUESTS'
       --  AND NVL(fug.end_date,SYSDATE+1) > SYSDATE
         AND fug.responsibility_id     = fr.responsibility_id
         AND fug.responsibility_application_id = fr.application_id
         AND fr.application_id         = fa.application_id
         AND fa.application_short_name IN ('JL', 'SQLAP')
         AND fpo.profile_option_id     = fpov.profile_option_id
         AND fpo.profile_option_name   = 'ORG_ID'
         AND fpov.level_id             = 10003
         AND fr.responsibility_id      = fpov.level_value
         AND fpov.profile_option_value = TO_CHAR(p_org_id)
         AND (fr.responsibility_key    LIKE '%_AP%SUPERUSER'
             OR
             fr.responsibility_key     LIKE '%SUPER%USUARIO');


  BEGIN

       debug(C_API_NAME, 'Iniciando');

       OPEN c_environment;
       FETCH c_environment INTO l_resp_appl_id
                              , l_resp_id
                              , l_user_id;
       l_found := c_environment%FOUND;
       CLOSE c_environment;

       IF (NOT l_found) THEN
         x_result := FALSE;
         x_errmsg := 'No se puede inicializar el ambiente para ejecutar la interface de AP con org_id '||p_org_id;
         RETURN;
       END IF;

       FND_GLOBAL.apps_initialize(resp_appl_id => l_resp_appl_id
                                 ,resp_id      => l_resp_id
                                 ,user_id      => l_user_id);



        l_request_id :=  FND_REQUEST.Submit_Request( 'SQLAP'
                                                   , 'APXIIMPT'
                                                   , 'Importación de Interface Abierta de Cuentas a Pagar'
                                                   , NULL
                                                   , FALSE
                                                   , p_org_id                     -- operating_unit
                                                   , 'XX_AP_CERTIFICADOS'         -- source
                                                   , NULL                         -- group
                                                   , 'N/D'                        -- batch name
                                                   , NULL                         -- hold name
                                                   , NULL                         -- hold reason
                                                   , NULL                         -- GL date
                                                   , 'N'                          -- purge
                                                   , 'N'                          -- trace switch
                                                   , 'Y'                          -- debug switch
                                                   , 'N'                          -- summarize report
                                                   , '1000'                       -- commit batch size
                                                   , l_user_id                    -- user id
                                                   , '1'                          -- login id
                                                   );
        COMMIT;

       IF (NVL(l_request_id,0)=0) THEN

         x_result := FALSE;
         x_errmsg := 'No fue posible finalizar correctamente la Importacion de '||
                     'Interface Abierta de Cuentas a Pagar. '||
                     'Por favor, ejecutelo manualmente';

       ELSE

         debug(C_API_NAME, 'l_request_id: '||l_request_id);

         LOOP

           l_req_status := FND_CONCURRENT.wait_for_request
                                   ( request_id      => l_request_id
                                   , interval        => 10
                                   , max_wait        => 60
                                   -- out arguments
                                   , phase           => l_phase
                                   , status          => l_status
                                   , dev_phase       => l_dev_phase
                                   , dev_status      => l_dev_status
                                   , message         => l_message
                                   );

         EXIT WHEN UPPER (l_phase) IN ('COMPLETED','FINALIZADO')
                 OR UPPER (l_status) IN ('CANCELLED', 'ERROR', 'TERMINATED'
                                        ,'CANCELADO', 'FINALIZADO');


         END LOOP;

         IF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'ERROR' THEN
           x_errmsg := 'No fue posible ejecutar el concurrente Importacion de '||
                       'Interface Abierta de Cuentas a Pagar. Detalle: '||l_message;
           x_result := FALSE;

         ELSIF UPPER(l_phase) IN ('COMPLETED','FINALIZADO') AND UPPER(l_status) = 'NORMAL' THEN
           COMMIT;
           x_result := TRUE;

         END IF;

       END IF;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Se produjo un error inesperado en la ejecucion de la Importacion '||
                  'de Interface Abierta de Cuentas a Pagar: '||SQLERRM;

  END Ejecutar_Interface_AP_1116A;





/****************************************************************************
 *                                                                          *
 * Name    : Actualizar_refacturado_flag_CP                                 *
 * Purpose : Actualizo los flag de refacturado_flag en Y de las             *
 *           cartas de porte relacionados con la 1116A y que                *
 *           entraron en la refacturación                                   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Actualizar_refacturado_flag_CP ( p_init_mst_list      IN VARCHAR2 DEFAULT XX_TCG_UTIL_PKG.G_FALSE
                                           , p_boletin_header_id  IN NUMBER
                                           , x_warning           OUT VARCHAR2
                                           , x_return_status     OUT VARCHAR2
                                           , x_msg_count         OUT NUMBER
                                           , x_msg_data          OUT VARCHAR2)
  IS

    --------------------------------
    -- Cartas de porte de un boletin
    --------------------------------
    CURSOR c_cartas_porte IS
      SELECT xtcp.carta_porte_id
           , xtcp.refacturado_flag
        FROM XX_TCG_CARTAS_PORTE_ALL xtcp
           , XX_TCG_BOLETIN_LINES    xtbl
       WHERE xtbl.boletin_header_id = p_boletin_header_id
         AND xtbl.carta_porte_id    = xtcp.carta_porte_id
         AND NVL(xtcp.provisionado_flag,'N')     = 'Y'
         AND NVL(xtcp.refacturar_flete_flag,'N') = 'Y'
         AND NVL(xtcp.refacturado_flag,'N')      = 'N';



    C_API_NAME               VARCHAR2(30) := 'Actualizar_refacturado_flag';
    l_result                 BOOLEAN;
    l_errmsg                 VARCHAR2(3000);
    l_chr_refacturado_flag   XX_TCG_CARTAS_PORTE_ALL.refacturado_flag%TYPE;
    row_locked               EXCEPTION;
    PRAGMA EXCEPTION_INIT( row_locked,-54);


  BEGIN

    -----------------------------------
    -- Inicializo el codigo de retorno
    -----------------------------------
    x_return_status := FND_API.G_RET_STS_SUCCESS;

    ----------------------------------
    -- Inicializo la pila de mensajes
    ----------------------------------
    IF (p_init_mst_list = FND_API.G_TRUE) THEN
      debug(C_API_NAME, 'Limpio pila de mensajes.');
      FND_MSG_PUB.Initialize;
    END IF;


    FOR l_rec IN c_cartas_porte LOOP

      -- Para chequear que el registro de carta de porte
      --  no este tomado en la pantalla de carta de porte
      BEGIN

        SELECT refacturado_flag
          INTO l_chr_refacturado_flag
          FROM XX_TCG_CARTAS_PORTE_ALL
         WHERE carta_porte_id = l_rec.carta_porte_id
           FOR UPDATE OF refacturado_flag NOWAIT;

      EXCEPTION
        WHEN row_locked THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE','Error al actualizar cartas de porte al liquidar 1116A. '||
                                 'Detalle: La carta de porte esta siendo consultada y/o modificada.'||CHR(10)||
                                 'ID carta de porte = '||l_rec.carta_porte_id);
          FND_MSG_PUB.Add;
          RAISE FND_API.G_EXC_ERROR;
        WHEN OTHERS THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE','Error al actualizar cartas de porte al liquidar 1116A. Detalle: '
                                 ||SUBSTR(SQLERRM,1,100));
          FND_MSG_PUB.Add;
          RAISE FND_API.G_EXC_ERROR;
      END;


      BEGIN

        UPDATE XX_TCG_CARTAS_PORTE_ALL
           SET refacturado_flag = 'Y'
         WHERE carta_porte_id = l_rec.carta_porte_id;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
          FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
          FND_MESSAGE.set_token ('MESSAGE','Error al actualizar cartas de porte al liquidar 1116A. Detalle: '
                                 ||SUBSTR(SQLERRM,1,100));
          FND_MSG_PUB.Add;
          RAISE FND_API.G_EXC_ERROR;
      END;

    END LOOP;


    COMMIT;

  EXCEPTION
    WHEN FND_API.G_EXC_ERROR THEN
      ROLLBACK;
      x_return_status := FND_API.G_RET_STS_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);
        debug(C_API_NAME, 'Salgo con error: '||XX_TCG_UTIL_PKG.Get_MSg(x_msg_count));

    WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
      ROLLBACK;
      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);
      debug(C_API_NAME, 'Salgo con error: '||XX_TCG_UTIL_PKG.Get_MSg(x_msg_count));

    WHEN others THEN
      ROLLBACK;
      FND_MESSAGE.set_name  ('FND', 'CONC-PLACES MESSAGE ON STACK');
      FND_MESSAGE.set_token ('MESSAGE', 'XX_TCG_LIQUIDACION_1116A_PKG.Actualizar_refacturado_flag_CP. '||
                            'Error inesperado - ' || SQLERRM);
      FND_MSG_PUB.Add;
      x_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
      FND_MSG_PUB.count_and_get ( p_count => x_msg_count
                                , p_data  => x_msg_data);
      debug(C_API_NAME, 'Salgo con error: '||XX_TCG_UTIL_PKG.Get_MSg(x_msg_count));

  END Actualizar_refacturado_flag_CP;






/****************************************************************************
 *                                                                           *
 * Name    : Calcular_Percepciones_AR_1116A                                  *
 * Purpose : Rutina para el calculo de las Percepciones a informar a AFIP    *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Calcular_Percepciones_AR_1116A ( p_liquidacion_id   IN NUMBER
                                           , x_cust_trx_id      OUT NUMBER
                                           , x_resultado        OUT BOOLEAN
                                           , x_error            OUT VARCHAR2)
  IS


    C_API_NAME                    CONSTANT      VARCHAR2(100) := 'CALCULAR_PERCEPCIONES_AR_1116A';
    l_trx_system_parameters_rec   AR_INVOICE_DEFAULT_PVT.trx_system_parameters_rec_type;
    l_errmsg                      VARCHAR2(3000);
    l_resultado                   BOOLEAN;
    l_return_status               VARCHAR2(1);
    l_liquidacion_rec             liquidacion_1116a_rec_type;
    l_batch_source_rec            AR_INVOICE_API_PUB.batch_source_rec_type;
    l_trx_header_tbl              AR_INVOICE_API_PUB.trx_header_tbl_type;
    l_trx_lines_tbl               AR_INVOICE_API_PUB.trx_line_tbl_type;
    l_trx_dist_tbl                AR_INVOICE_API_PUB.trx_dist_tbl_type;
    l_trx_salescredits_tbl        AR_INVOICE_API_PUB.trx_salescredits_tbl_type;
    l_trx_type_id                 NUMBER;
    l_header_id                   NUMBER;
    l_trx_line_id                 NUMBER;
    l_trx_line_line_id            NUMBER;
    ePercepErrors                 EXCEPTION;
    l_eMsg                        VARCHAR2(3000);
    l_trx_err                     VARCHAR2(3000);
    l_combination_id              NUMBER;
    l_msg_count                   NUMBER;
    l_errcnt                      NUMBER;
    l_new_trx_id                  NUMBER;
    l_total_amount                NUMBER := 0;
    l_dist_id                     NUMBER;
    l_lines_err                   VARCHAR2(1000);
    l_dist_err                    VARCHAR2(1000);
    l_cust_trx_id                 NUMBER;
    l_concat_segments             VARCHAR2(1000);
    l_failure_count               NUMBER;
    l_commit_user_id              NUMBER;
    l_resp_id                     NUMBER;
    l_resp_appl_id                NUMBER;
    l_warehouse_id                NUMBER;


    CURSOR c_taxes(p_cust_trx_id IN NUMBER) IS
      SELECT avt.vat_tax_id
           , jzatc.tax_category
           , jzcv.description            category_descripcion
           , avt.tax_code
           , avt.description             tax_descripcion
           , rctl.extended_amount        importe_percep
           , rctl.taxable_amount
           , rctl.org_id
           , rctl.tax_rate
        FROM RA_CUSTOMER_TRX_LINES_ALL   rctl
           , AR_VAT_TAX                  avt
           , JL_ZZ_AR_TX_CATEG_ALL       jzatc
           , JL_ZZ_AR_TX_CATEGRY         jzcv
       WHERE rctl.vat_tax_id        = avt.vat_tax_id
         AND avt.tax                = jzatc.tax_category
         AND rctl.customer_trx_id   = p_cust_trx_id
         AND jzatc.org_id           = rctl.org_id
         AND jzatc.tax_category_id  = jzcv.tax_category_id
         AND (jzatc.tax_category    IN ('RFOG','VATPERC')
             OR (jzatc.tax_category LIKE 'TOP%')
             OR (jzatc.tax_category = 'VAT'
                 AND avt.tax_code   IN ('IVA 0% Exento','IVA 0% Exterior') )
             );



  BEGIN

    debug(C_PACKAGE_NAME, C_API_NAME||' Inicio');


    -----------------------------------------------------------------------------
    --Se verifica que no exista una factura ficticia previa para la liquidacion
    --Si existe se elimina
    -----------------------------------------------------------------------------
    BEGIN

      BEGIN

        SELECT cust_trx_id_ficticio
             , commit_user_id
             , resp_id
             , resp_appl_id
          INTO l_cust_trx_id
             , l_commit_user_id
             , l_resp_id
             , l_resp_appl_id
          FROM XX_TCG_LIQUIDACIONES_1116A
         WHERE liquidacion_id = p_liquidacion_id;

      EXCEPTION
        WHEN others THEN
          l_eMsg := 'Error al verificar si la liquidacion tenia generada una factura ficticia previa: '||SQLERRM;
          RAISE ePercepErrors;
      END;


      IF (l_cust_trx_id IS NOT NULL) THEN

        DELETE FROM RA_CUST_TRX_LINE_GL_DIST_ALL   WHERE customer_trx_id = l_cust_trx_id;
        DELETE FROM RA_CUSTOMER_TRX_LINES_ALL      WHERE customer_trx_id = l_cust_trx_id;
        DELETE FROM RA_CUSTOMER_TRX_ALL            WHERE customer_trx_id = l_cust_trx_id;
        DELETE FROM XX_TCG_LIQUIDACION1116A_PERCEP WHERE liquidacion_id  = p_liquidacion_id;

        UPDATE XX_TCG_LIQUIDACIONES_1116A SET cust_trx_id_ficticio = NULL WHERE liquidacion_id = p_liquidacion_id;

        COMMIT;
      END IF;

    EXCEPTION
      WHEN others THEN
        l_eMsg := 'Error al intentar borrar las lineas de Percepciones generadas previamente: '||SQLERRM;
        RAISE ePercepErrors;
    END;



    ---------------------------------------------------------------------------
    -- Se obtiene el certificado a partir del cual se cargara¡ la factura en AR
    ---------------------------------------------------------------------------
    BEGIN

      Get_Liquidacion_1116A( p_liquidacion_id  => p_liquidacion_id
                           , x_liquidacion_rec => l_liquidacion_rec
                           , x_result          => l_resultado
                           , x_errmsg          => l_errmsg);

      IF (NOT l_resultado) THEN

        l_eMsg := l_errmsg;
        RAISE ePercepErrors;
      ELSIF (l_liquidacion_rec.lineas.count=0) THEN
        x_resultado := TRUE;
        x_error := 'No existen lineas de servicios.';
        RETURN;
      END IF;

      MO_GLOBAL.set_policy_context('S',l_liquidacion_rec.operating_unit );

    EXCEPTION
      WHEN others THEN
        IF (l_eMsg IS NULL) THEN
          l_eMsg := 'Error al buscar los datos del certificado '||p_liquidacion_id;
        END IF;
        RAISE ePercepErrors;
    END;


    ------------
    --Origen
    ------------
    BEGIN

      SELECT origen_trx_ar_id
        INTO l_batch_source_rec.batch_source_id
        FROM XX_TCG_PARAMETROS_COMPROBANTE
       WHERE operating_unit       = l_liquidacion_rec.operating_unit
         AND codigo_doc           = 'CERTIFICADO'
         AND tipo_doc             = 'FICTICIO'
         AND canje                = l_liquidacion_rec.es_canje
         AND tipo_trx_ar_post_gl  = 'N'
         AND tipo_trx_ar_tax_calc = 'Y';

    EXCEPTION
      WHEN OTHERS THEN
        l_eMsg := 'Error al buscar el Origen de la factura ficticia: '||SQLERRM;
        RAISE ePercepErrors;
    END;


    -----------------------
    --Tipo de Transaccion
    -----------------------
    BEGIN

      SELECT tipo_trx_ar_id
        INTO l_trx_type_id
        FROM XX_TCG_PARAMETROS_COMPROBANTE
       WHERE operating_unit       = l_liquidacion_rec.operating_unit
         AND codigo_doc           = 'CERTIFICADO'
         AND tipo_doc             = 'FICTICIO'
         AND canje                = l_liquidacion_rec.es_canje
         AND tipo_trx_ar_post_gl  = 'N'
         AND tipo_trx_ar_tax_calc = 'Y';

    EXCEPTION
      WHEN OTHERS THEN
        l_eMsg := 'Error al buscar el Tipo de Transaccion de la factura ficticia: '||SQLERRM;
        RAISE ePercepErrors;
    END;

    /* CR961 - Se solicita enviar el valor de Organization_id para este campo
    -----------------------
    -- Id de Organizacion
    ----------------------
    BEGIN

      SELECT MIN(od.organization_id) warehouse_id
        INTO l_warehouse_id
        FROM FINANCIALS_SYSTEM_PARAMS_ALL   fsp
           , ( SELECT oi.organization_id
                    , ou.name                        organization_name
                    , TO_NUMBER(oi.org_information1) set_of_books_id
                    , TO_NUMBER(oi.org_information3) unit_operation
                 FROM HR_ORGANIZATION_INFORMATION oi
                    , HR_ORGANIZATION_UNITS       ou
                WHERE 1=1
                  AND ou.organization_id  = oi.organization_id
                  AND oi.org_information_context = 'Accounting Information')  od
       WHERE 1=1
         AND od.set_of_books_id = fsp.set_of_books_id
         AND od.organization_id = fsp.inventory_organization_id
         AND od.unit_operation  = l_liquidacion_rec.operating_unit;

    EXCEPTION
      WHEN others THEN
        l_eMsg := 'Error al buscar el warehouse_id. '||SQLERRM;
        RAISE ePercepErrors;
    END;*/

    ------------------------
    -- Armado de Cabecera
    -----------------------
    l_header_id        := l_liquidacion_rec.liquidacion_id;
    l_total_amount     := 0;

    l_trx_header_tbl(1).trx_header_id                := l_header_id;
    l_trx_header_tbl(1).trx_number                   := l_header_id;
    l_trx_header_tbl(1).trx_currency                 := l_liquidacion_rec.currency_code;
    l_trx_header_tbl(1).exchange_rate_type           := l_liquidacion_rec.conversion_type;
    l_trx_header_tbl(1).exchange_rate                := l_liquidacion_rec.conversion_rate;
    IF (l_trx_header_tbl(1).exchange_rate IS NULL) THEN
      l_trx_header_tbl(1).exchange_date              := NULL;
    ELSE
      l_trx_header_tbl(1).exchange_date              := SYSDATE;
    END IF;
    l_trx_header_tbl(1).trx_date                     := SYSDATE;
    l_trx_header_tbl(1).gl_date                      := NULL;
    l_trx_header_tbl(1).bill_to_customer_id          := l_liquidacion_rec.customer_id;
    l_trx_header_tbl(1).bill_to_address_id           := l_liquidacion_rec.customer_bill_address_id;
    l_trx_header_tbl(1).ship_to_customer_id          := l_liquidacion_rec.customer_id;
    l_trx_header_tbl(1).ship_to_address_id           := l_liquidacion_rec.customer_ship_address_id;
    l_trx_header_tbl(1).term_id                      := l_liquidacion_rec.ra_term_id;
    l_trx_header_tbl(1).comments                     := 'Factura ficticia ingresada desde Acopio para obtener Percepciones. Liq: '
                                                        ||l_liquidacion_rec.liquidacion_id;
    l_trx_header_tbl(1).cust_trx_type_id             := l_trx_type_id;
    l_trx_header_tbl(1).global_attribute_category    := 'JL.AR.ARXTWMAI.TGW_HEADER';
    l_trx_header_tbl(1).interface_header_context     := 'XX_AR_CERTIFICADOS'; --'ACOPIO';
    l_trx_header_tbl(1).interface_header_attribute1  := l_header_id;
    l_trx_header_tbl(1).org_id                       := l_liquidacion_rec.operating_unit;


    --------------------------------------
    -- Armado de lineas y distribuciones
    --------------------------------------

    FOR l_row_num IN l_liquidacion_rec.lineas.FIRST .. l_liquidacion_rec.lineas.LAST LOOP

      SELECT RA_CUSTOMER_TRX_LINES_S.nextval
           , RA_CUST_TRX_LINE_GL_DIST_S.nextval
        INTO l_trx_line_id
           , l_trx_line_line_id
        FROM DUAL;

      l_trx_lines_tbl(l_row_num).trx_header_id             := l_header_id;
      l_trx_lines_tbl(l_row_num).trx_line_id               := l_trx_line_id;
      l_trx_lines_tbl(l_row_num).line_number               := l_row_num;
      l_trx_lines_tbl(l_row_num).line_type                 := 'LINE';
      l_trx_lines_tbl(l_row_num).memo_line_id              := l_liquidacion_rec.lineas(l_row_num).memo_line_id;
      l_trx_lines_tbl(l_row_num).quantity_invoiced         := 1;
      l_trx_lines_tbl(l_row_num).unit_selling_price        := l_liquidacion_rec.lineas(l_row_num).importe;
      l_trx_lines_tbl(l_row_num).warehouse_id              := l_liquidacion_rec.organization_id;                   --l_warehouse_id;  CR961
      l_trx_lines_tbl(l_row_num).global_attribute_category := 'JL.AR.ARXTWMAI.LINES';
      l_trx_lines_tbl(l_row_num).global_attribute2         := l_liquidacion_rec.lineas(l_row_num).clasificacion_fiscal;
      l_trx_lines_tbl(l_row_num).global_attribute3         := l_liquidacion_rec.lineas(l_row_num).condicion_trx;



      l_trx_dist_tbl(l_row_num).trx_dist_id          := l_trx_line_line_id;
      l_trx_dist_tbl(l_row_num).trx_header_id        := l_header_id;
      l_trx_dist_tbl(l_row_num).trx_line_id          := l_trx_line_id;
      l_trx_dist_tbl(l_row_num).account_class        := 'REV';
      l_trx_dist_tbl(l_row_num).amount               := l_liquidacion_rec.lineas(l_row_num).importe;
      l_trx_dist_tbl(l_row_num).acctd_amount         := l_liquidacion_rec.lineas(l_row_num).importe;
      l_trx_dist_tbl(l_row_num).percent              := 100;
      --l_trx_dist_tbl(l_row_num).code_combination_id  := l_combination_id;    retrofit r12
      l_trx_dist_tbl(l_row_num).code_combination_id  := l_liquidacion_rec.lineas(l_row_num).gl_id_rev;


      l_total_amount := l_total_amount + l_liquidacion_rec.lineas(l_row_num).importe;
      l_dist_id := l_row_num;


    END LOOP;

    -----------------------------------------------------------
    -- Llamada a la API de AR para crear una factura ficticia
    -----------------------------------------------------------

    debug(C_PACKAGE_NAME, C_API_NAME||' User_id: '||fnd_global.user_id||' - Resp_id: '||fnd_global.resp_id
                         ||' - resp_appl_id: '||fnd_global.resp_appl_id);
    AR_INVOICE_API_PUB.create_single_invoice( p_api_version           => 1.0
                                            , p_init_msg_list         => FND_API.G_TRUE
                                            , p_commit                => FND_API.G_TRUE
                                            , p_batch_source_rec      => l_batch_source_rec
                                            , p_trx_header_tbl        => l_trx_header_tbl
                                            , p_trx_lines_tbl         => l_trx_lines_tbl
                                            , p_trx_dist_tbl          => l_trx_dist_tbl
                                            , p_trx_salescredits_tbl  => l_trx_salescredits_tbl
                                            , x_customer_trx_id       => l_new_trx_id
                                            , x_return_status         => l_return_status
                                            , x_msg_count             => l_msg_count
                                            , x_msg_data              => l_errmsg
                                            );

    debug(C_PACKAGE_NAME, C_API_NAME||' l_return_status: '||l_return_status);
    debug(C_PACKAGE_NAME, C_API_NAME||' l_errmsg: '||l_errmsg);

    IF (l_return_status = FND_API.g_ret_sts_error OR
      l_return_status = FND_API.g_ret_sts_unexp_error) THEN

      l_eMsg :=  XX_TCG_UTIL_PKG.Get_msg(l_msg_count);

      l_eMsg := SUBSTR(l_eMsg||' - '||l_errmsg, 1, 2999);


      RAISE ePercepErrors;

    ELSE

      x_cust_trx_id := l_new_trx_id;

      SELECT count(*)
        INTO l_errcnt
        FROM AR_TRX_ERRORS_GT;


      IF (l_errcnt = 0) THEN

        FOR cTax IN c_taxes(l_new_trx_id) LOOP


          INSERT INTO XX_TCG_LIQUIDACION1116A_PERCEP
            ( LIQUIDACION_ID
            , ORG_ID
            , VAT_TAX_ID
            , TAX_CODE
            , TAX_RATE
            , TAX_DESCRIPCION
            , TAX_CATEGORY
            , CATEGORY_DESCRIPCION
            , MONTO
            , MONTO_PERCEPCION
             )
           VALUES
             ( l_liquidacion_rec.liquidacion_id
             , cTax.org_id
             , cTax.vat_tax_id
             , cTax.tax_code
             , cTax.tax_rate
             , cTax.tax_descripcion
             , cTax.tax_category
             , cTax.category_descripcion
             , cTax.taxable_amount
             , cTax.importe_percep
              );

        END LOOP;


        COMMIT;
        x_resultado := TRUE;

      ELSE

        l_eMsg := 'Transaccion no creada, AR_TRX_ERRORS_GT Errores: ';

        FOR cErr IN (SELECT *
                       FROM AR_TRX_ERRORS_GT) LOOP


          l_trx_err :=  SUBSTR(' // Mensaje: '||cErr.error_message||' - Valor invalido: '||cErr.invalid_value ,1,2999);

          IF (cErr.trx_line_id IS NOT NULL) THEN

            SELECT ' Memo line id: '|| memo_line_id ||' - Vat tax id: '||vat_tax_id
              INTO l_lines_err
              FROM AR_TRX_LINES_GT
             WHERE trx_line_id = cErr.trx_line_id;

            l_trx_err := l_trx_err ||l_lines_err;
          END IF;

          IF (cErr.trx_dist_id IS NOT NULL) THEN

            SELECT ' Code combination id: '|| code_combination_id
              INTO l_dist_err
              FROM AR_TRX_DIST_GT
             WHERE trx_dist_id = cErr.trx_dist_id;

            l_trx_err := l_trx_err ||l_dist_err;
          END IF;

          l_eMsg := SUBSTR(l_eMsg ||l_trx_err,1,3000);

        END LOOP;


        RAISE ePercepErrors;
      END IF;

    END IF;



  EXCEPTION
    WHEN ePercepErrors THEN
      x_error     := 'Error en Calcular_Percepciones_AR_1116A. '||l_eMsg;
      x_resultado := FALSE;
      debug(C_PACKAGE_NAME, C_API_NAME||' x_error: '||x_error);

    WHEN others THEN
      x_error     := 'Error Others en Calcular_Percepciones_AR_1116A. '||SQLERRM;
      x_resultado := FALSE;
      debug(C_PACKAGE_NAME, C_API_NAME||' x_error: '||x_error);


  END Calcular_Percepciones_AR_1116A;



 /****************************************************************************
 *                                                                          *
 * Name    : Obtener_Percepciones_AR_1116A                                  *
 * Purpose : Rutina para el calculo de las Percepciones a informar a AFIP   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Obtener_Percepciones_AR_1116A( p_liquidacion_id   IN NUMBER
                                         , x_percep_iva       OUT NUMBER
                                         , x_otras_percep     OUT NUMBER
                                         , x_no_gravados      OUT NUMBER
                                         , x_resultado        OUT BOOLEAN
                                         , x_error            OUT VARCHAR2
                                         ) IS

    l_percep_iva                  NUMBER := 0;
    l_otras_percep                NUMBER := 0;
    l_no_gravados                 NUMBER := 0;

    CURSOR c_Percep IS
      SELECT *
        FROM XX_TCG_LIQUIDACION1116A_PERCEP
       WHERE liquidacion_id = p_liquidacion_id;


  BEGIN


    FOR rPerc IN c_Percep LOOP

      IF (rPerc.tax_category IN ('RFOG','VATPERC')) THEN

        l_percep_iva := l_percep_iva + rPerc.monto_percepcion;

      ELSIF (rPerc.tax_category LIKE 'TOP%') THEN

        l_otras_percep := l_otras_percep + rPerc.monto_percepcion;

      ELSIF (rPerc.tax_category = 'VAT' AND rPerc.tax_rate = 0) THEN

        l_no_gravados := l_no_gravados + rPerc.monto;

      END IF;


    END LOOP;

    x_percep_iva   := l_percep_iva;
    x_otras_percep := l_otras_percep;
    x_no_gravados  := l_no_gravados;
    x_resultado    := TRUE;


  EXCEPTION
    WHEN others THEN
      x_error     := 'Error Others en Calcular_Percepciones_AR_1116A. '||SQLERRM;
      x_resultado := FALSE;

  END Obtener_Percepciones_AR_1116A;



/****************************************************************************
 *                                                                          *
 * Name    : Generar_NC_1116A                                               *
 * Purpose : Rutina para la generacion de una NC en AR a partir de          *
 *           la liquidacion 1116A.                                          *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_NC_1116A ( p_liquidacion_rec  IN OUT NOCOPY liquidacion_1116a_rec_type
                             , x_result              OUT BOOLEAN
                             , x_errmsg              OUT VARCHAR2
                             , x_warning             OUT VARCHAR2)
  IS

    C_API_NAME               VARCHAR2(30) := 'GENERAR_NC_1116A';
    l_batch_source_name      ra_batch_sources_all.name%TYPE;
    l_result                 BOOLEAN;
    l_errmsg                 VARCHAR2(2000);
    l_combination_id         NUMBER;
    l_ra_fc_cust_trx_type_id NUMBER;
    l_attributes_rec         attributes_rec_type;
    l_appl_column_name       VARCHAR2(30);
    l_org_id                 NUMBER;
    l_cod_impuesto           VARCHAR2(100);
    l_cust_trx_id            NUMBER;
    l_doc_type               VARCHAR2(10);
    l_warehouse_id           NUMBER;
    --CR1334
    l_nc_cust_trx_id         NUMBER;
    --CR1919
    l_status                 VARCHAR(1);
    eNCInterna               EXCEPTION;
    l_batch_source_id_cm     NUMBER;
    l_batch_source_letter    VARCHAR2(1);
    l_memo_line_id_int       NUMBER;
    l_batch_source_id_int    NUMBER;
    l_cust_trx_type_id_int   NUMBER;
    l_cust_trx_id_int        NUMBER;
    l_trx_number_int         VARCHAR2(32);
    l_amount_int             NUMBER;
    --

  BEGIN
    debug(C_API_NAME, 'Iniciando.');
    x_result := TRUE;


    --************************************************************************
    -- Si se generaron las percepciones para enviar a AFIP, al momento de
    -- Cancelar se copiara la factura de AR y se la convertira a NC con los
    -- mismos impuestos
    --************************************************************************
    BEGIN

      SELECT cust_trx_id_real
        INTO l_cust_trx_id
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE liquidacion_id = p_liquidacion_rec.liquidacion_id;

    EXCEPTION
      WHEN others THEN
        l_cust_trx_id := -1;
    END;



    IF (l_cust_trx_id = -1) THEN


      IF (p_liquidacion_rec.es_canje = 'N') THEN

        ----------------------------------------------------------------
        -- Obtengo el batch_source_name de la configuracion por compania
        ----------------------------------------------------------------
        BEGIN

          SELECT xtpc.ra_nc_batch_source_name
               , xtpc.ra_nc_cust_trx_type_id
            INTO l_batch_source_name
               , l_ra_fc_cust_trx_type_id
            FROM XX_TCG_PARAMETROS_COMPANIA xtpc
           WHERE xtpc.operating_unit = p_liquidacion_rec.operating_unit;

        EXCEPTION
          WHEN no_data_found THEN
            x_result := FALSE;
            x_errmsg := 'No fue posible obtener la configuracion de Acopio para la compania: '
                        || p_liquidacion_rec.operating_unit ||'. No fue posible obtener el origen de lote para la '
                        ||'generacion de la nota de credito.';
            RETURN;
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error obteniedo la configuracion de Acopio para la compania: '
                        || p_liquidacion_rec.operating_unit ||'. Fue fue posible obtener el origen de lote para la '
                        ||'generacion la nota de credito. Detalle: ' || SQLERRM;
            RETURN;
        END;

      ELSE

        -- Obtengo origen y tipo de transaccion a partir de los parametros de cia
        -- para las operaciones de canje.
        BEGIN
          SELECT xtpc.ra_nccje_batch_source_name
               , rbs.default_inv_trx_type
            INTO l_batch_source_name
               , l_ra_fc_cust_trx_type_id
            FROM XX_TCG_PARAMETROS_COMPANIA      xtpc
               , RA_BATCH_SOURCES_ALL            rbs
           WHERE xtpc.ra_nccje_batch_source_name = rbs.name
             AND rbs.org_id                      = xtpc.operating_unit
             AND xtpc.operating_unit             = p_liquidacion_rec.operating_unit;

        EXCEPTION
          WHEN OTHERS THEN
            x_result := FALSE;
            x_errmsg := 'Error obteniedo la configuracion de Acopio para la compania: '
                        || p_liquidacion_rec.operating_unit ||'. No fue posible obtener el origen de lote para la '
                        ||'generacion la nota de credito de canje. Detalle: ' || SQLERRM;
            RETURN;
        END;

      END IF;


    ELSE

      BEGIN

        SELECT rbs.name
             , xpc.tipo_anul_ar_id
             , rct.type
          INTO l_batch_source_name
             , l_ra_fc_cust_trx_type_id
             , l_doc_type
          FROM XX_TCG_PARAMETROS_COMPROBANTE  xpc
             , RA_BATCH_SOURCES_ALL           rbs
             , RA_CUST_TRX_TYPES_ALL          rct
         WHERE xpc.origen_anul_ar_id     = rbs.batch_source_id
           AND xpc.tipo_anul_ar_id       = rct.cust_trx_type_id
           AND xpc.codigo_doc            = 'CERTIFICADO'
           AND xpc.tipo_doc              = 'OFICIAL'
           AND xpc.operating_unit        = p_liquidacion_rec.operating_unit
           AND xpc.canje                 = p_liquidacion_rec.es_canje
           AND xpc.tipo_anul_ar_post_gl  = 'Y'
           AND xpc.tipo_anul_ar_tax_calc = 'N';

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniedo la configuracion de acopio para la compania: '
                      || p_liquidacion_rec.operating_unit ||'. No fue posible obtener el origen del lote '
                      ||'y el tipo de transaccion para la generacion la nota de credito '
                      ||'de canje = '||p_liquidacion_rec.es_canje||'. Detalle: ' || SQLERRM;
          RETURN;
      END;

    END IF;

    IF (l_batch_source_name IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se especifico el nombre del origen de lote para la compania: '
                  || p_liquidacion_rec.operating_unit ||'. No fue posible determinar el origen de lote para la '
                  ||'generacion de la nota de credito.';
      RETURN;
    END IF;


    IF (p_liquidacion_rec.customer_class_code != 'INTERCOMPANY') THEN


      ----------------------------------------------------------------
      -- Obtengo el numero de segmento para almacenar el pedido de vta
      ----------------------------------------------------------------
      l_result := XX_UTIL_PK.dff_get_column( p_appl_short_name   => 'AR'
                                           , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                           , p_desc_flex_context => 'AR'
                                           , p_desc_flex_column  => 'XX_AR_NRO_PEDIDO_OM'
                                           , p_appl_column_name  => l_appl_column_name
                                           , p_mesg_error        => l_errmsg
                                           );
      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '||
                    '"XX_AR_NRO_PEDIDO_OM" dentro dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '|| l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

      Set_Attribute_Value ( p_attributes_rec => l_attributes_rec
                          , p_column_name    => l_appl_column_name
                          , p_value          => p_liquidacion_rec.oe_order_number);


      ------------------------------------------------------------------------
      -- Obtengo el numero de segmento para almacenar el tipo de pedido de vta
      ------------------------------------------------------------------------
      l_result := XX_UTIL_PK.dff_get_column ( p_appl_short_name   => 'AR'
                                            ,p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                            ,p_desc_flex_context => 'AR'
                                            ,p_desc_flex_column  => 'XX_AR_TIPO_PEDIDO_OM'
                                            ,p_appl_column_name  => l_appl_column_name
                                            ,p_mesg_error        => l_errmsg
                                            );

      IF (NOT l_result) THEN
        x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '||
                    '"XX_AR_TIPO_PEDIDO_OM" dentro dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '||l_errmsg;
        x_result := FALSE;
        RETURN;
      END IF;

      Set_Attribute_Value ( p_attributes_rec => l_attributes_rec
                          , p_column_name    => l_appl_column_name
                          , p_value          => p_liquidacion_rec.oe_order_type);

    END IF;



    ------------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar tipo liquidacion
    ------------------------------------------------------------------
    l_result := XX_UTIL_PK.dff_get_column ( p_appl_short_name   => 'AR'
                                          , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                          , p_desc_flex_context => 'AR'
                                          , p_desc_flex_column  => 'XX_AR_TIPO_LIQUIDACION'
                                          , p_appl_column_name  => l_appl_column_name
                                          , p_mesg_error        => l_errmsg
                                          );

    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '||
                  '"XX_AR_TIPO_LIQUIDACION" dentro dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    Set_Attribute_Value ( p_attributes_rec => l_attributes_rec
                        , p_column_name    => l_appl_column_name
                        , p_value          => 'Unica');



    IF (l_cust_trx_id = -1) THEN

      /* CR961 - Se solicita enviar el valor de Organization_id en este campo
      -----------------------
      -- Id de Organizacion
      ----------------------
      BEGIN

        SELECT MIN(od.organization_id) warehouse_id
          INTO l_warehouse_id
          FROM FINANCIALS_SYSTEM_PARAMS_ALL   fsp
             , ( SELECT oi.organization_id
                      , ou.name                        organization_name
                      , TO_NUMBER(oi.org_information1) set_of_books_id
                      , TO_NUMBER(oi.org_information3) unit_operation
                   FROM HR_ORGANIZATION_INFORMATION oi
                      , HR_ORGANIZATION_UNITS       ou
                  WHERE 1=1
                    AND ou.organization_id  = oi.organization_id
                    AND oi.org_information_context = 'Accounting Information')  od
         WHERE 1=1
           AND od.set_of_books_id = fsp.set_of_books_id
           AND od.organization_id = fsp.inventory_organization_id
           AND od.unit_operation  = p_liquidacion_rec.operating_unit;

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error al buscar el warehouse_id. '||SQLERRM;
          RETURN;
      END;*/

      -------------------------------------------------------------------
      -- Por cada linea de la liquidacion genero la linea en la interface
      -------------------------------------------------------------------
      FOR l_index IN 1 .. p_liquidacion_rec.lineas.COUNT LOOP

        -- Obtengo codigo de impuesto para cada linea de liquidacion
        BEGIN

          SELECT aml_gldfv.transaction_condition_class
            INTO l_cod_impuesto
            FROM AR_MEMO_LINES_ALL_VL     aml
               , AR_MEMO_LINES_ALL_B1_DFV aml_gldfv
           WHERE aml.row_id        = aml_gldfv.row_id
             AND aml.memo_line_id  = p_liquidacion_rec.lineas(l_index).memo_line_id;

        EXCEPTION
          WHEN OTHERS THEN
            x_result := FALSE;
            x_errmsg := 'Error generando Nota de Credito. Se produjo un error al obtener el codigo '||
                        'de impuesto para la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_name ||
                          '. Detalle: '|| SQLERRM;
            RETURN;
        END;

        -------------------
        -- Inserto la linea
        -------------------
        BEGIN
          INSERT INTO RA_INTERFACE_LINES_ALL
            ( LINE_TYPE
            , CUST_TRX_TYPE_ID
            , ORIG_SYSTEM_BILL_ADDRESS_ID
            , TRX_DATE
            , BATCH_SOURCE_NAME
            , TRX_NUMBER
            , QUANTITY
            , CURRENCY_CODE
            , UNIT_SELLING_PRICE
            , AMOUNT
            , CONVERSION_TYPE
            , CONVERSION_RATE
            , CONVERSION_DATE
            , SET_OF_BOOKS_ID
            , MEMO_LINE_NAME
            , MEMO_LINE_ID
            , LINE_GDF_ATTRIBUTE2
            , LINE_GDF_ATTRIBUTE3
            , INTERFACE_LINE_CONTEXT
            , INTERFACE_LINE_ATTRIBUTE1
            , INTERFACE_LINE_ATTRIBUTE2
            , INTERFACE_LINE_ATTRIBUTE3
            , ORIG_SYSTEM_SHIP_ADDRESS_ID
            , SHIP_DATE_ACTUAL
            , WAREHOUSE_ID
            , HEADER_GDF_ATTR_CATEGORY
            , LINE_GDF_ATTR_CATEGORY
            , ORIG_SYSTEM_BILL_CUSTOMER_ID
            , ORIG_SYSTEM_SHIP_CUSTOMER_ID
            , ORIG_SYSTEM_SOLD_CUSTOMER_ID
            , DESCRIPTION
            , GL_DATE
            , AMOUNT_INCLUDES_TAX_FLAG
            , HEADER_ATTRIBUTE_CATEGORY
            , HEADER_ATTRIBUTE1
            , HEADER_ATTRIBUTE2
            , HEADER_ATTRIBUTE3
            , HEADER_ATTRIBUTE4
            , HEADER_ATTRIBUTE5
            , HEADER_ATTRIBUTE6
            , HEADER_ATTRIBUTE7
            , HEADER_ATTRIBUTE8
            , HEADER_ATTRIBUTE9
            , HEADER_ATTRIBUTE10
            , HEADER_ATTRIBUTE11
            , HEADER_ATTRIBUTE12
            , HEADER_ATTRIBUTE13
            , HEADER_ATTRIBUTE14
            , HEADER_ATTRIBUTE15
            , ORG_ID
            , CREATION_DATE
            , CREATED_BY
            , LAST_UPDATE_DATE
            , LAST_UPDATED_BY
            , LAST_UPDATE_LOGIN
            )
          VALUES
            ( 'LINE'
            , l_ra_fc_cust_trx_type_id
            , p_liquidacion_rec.customer_bill_address_id
            , p_liquidacion_rec.fecha_anulacion
            , l_batch_source_name
            , Fnd_Profile.Value('XX_ACO_RA_NC_PREFIX') || p_liquidacion_rec.numero_liquidacion
            , 1
            , p_liquidacion_rec.currency_code
            , p_liquidacion_rec.lineas(l_index).importe * -1
            , p_liquidacion_rec.lineas(l_index).importe * -1
            , NVL(p_liquidacion_rec.conversion_type,'Corporate')
            , p_liquidacion_rec.conversion_rate
            , p_liquidacion_rec.fecha_liquidacion
            , p_liquidacion_rec.set_of_books_id
            , p_liquidacion_rec.lineas(l_index).memo_line_name
            , p_liquidacion_rec.lineas(l_index).memo_line_id
            , 'DEFAULT'
            , l_cod_impuesto
            , 'XX_AR_CERTIFICADOS' --'ACOPIO'
            , p_liquidacion_rec.numero_liquidacion
            , 'NC'
            , l_index
            , p_liquidacion_rec.customer_ship_address_id
            , p_liquidacion_rec.fecha_anulacion
            , p_liquidacion_rec.organization_id                                 --, l_warehouse_id CR961
            , 'JL.AR.ARXTWMAI.TGW_HEADER'
            , 'JL.AR.ARXTWMAI.LINES'
            , p_liquidacion_rec.customer_id
            , p_liquidacion_rec.customer_id
            , p_liquidacion_rec.customer_id
            , p_liquidacion_rec.lineas(l_index).memo_line_name
            , p_liquidacion_rec.fecha_anulacion
            , 'N'
            , 'AR'
            , l_attributes_rec.attribute1
            , l_attributes_rec.attribute2
            , l_attributes_rec.attribute3
            , l_attributes_rec.attribute4
            , l_attributes_rec.attribute5
            , l_attributes_rec.attribute6
            , l_attributes_rec.attribute7
            , l_attributes_rec.attribute8
            , l_attributes_rec.attribute9
            , l_attributes_rec.attribute10
            , l_attributes_rec.attribute11
            , l_attributes_rec.attribute12
            , l_attributes_rec.attribute13
            , l_attributes_rec.attribute14
            , l_attributes_rec.attribute15
            , p_liquidacion_rec.operating_unit
            , SYSDATE
            , FND_GLOBAL.user_id
            , SYSDATE
            , FND_GLOBAL.user_id
            , FND_GLOBAL.login_id
            );
        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error generando nota de credito. Se produjo un error al intentar insertar '||
                        'la linea de interface para la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_name ||
                          '. Detalle: '|| SQLERRM;
            RETURN;
        END;



        -----------------------------------
        -- Inserto la linea de distribucion
        -----------------------------------
        BEGIN
          INSERT INTO ra_interface_distributions_all
            ( ACCOUNT_CLASS
            , INTERFACE_LINE_CONTEXT
            , AMOUNT
            , INTERFACE_LINE_ATTRIBUTE1
            , INTERFACE_LINE_ATTRIBUTE2
            , INTERFACE_LINE_ATTRIBUTE3
            , CODE_COMBINATION_ID
            , ORG_ID
            , PERCENT
            , CREATION_DATE
            , CREATED_BY
            , LAST_UPDATE_DATE
            , LAST_UPDATED_BY
            , LAST_UPDATE_LOGIN
            )
          VALUES
            ( 'REV'
            , 'XX_AR_CERTIFICADOS' --'ACOPIO'
            , p_liquidacion_rec.lineas(l_index).importe * -1
            , p_liquidacion_rec.numero_liquidacion
            , 'NC'
            , l_index
            , p_liquidacion_rec.lineas(l_index).gl_id_rev
            , p_liquidacion_rec.operating_unit
            , 100
            , SYSDATE
            , FND_GLOBAL.user_id
            , SYSDATE
            , FND_GLOBAL.user_id
            , FND_GLOBAL.login_id
            );
        EXCEPTION
          WHEN others THEN
            x_result := FALSE;
            x_errmsg := 'Error generando nota de credito. Se produjo un error al intentar insertar la linea de distribucion para '
                      ||'la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_name ||'. Detalle: '|| SQLERRM;
            RETURN;
        END;

      END LOOP;

    ELSE

      -- Se genera la Nota de Credito
      Generar_Doc_Trx_Definitivo ( p_liquidacion_rec   =>  p_liquidacion_rec
                                 , p_customer_trx_id   =>  l_cust_trx_id
                                 , p_cust_trx_type_id  =>  l_ra_fc_cust_trx_type_id
                                 , p_batch_source_name =>  l_batch_source_name
                                 , p_doc_type          =>  l_doc_type
                                 , p_attributes_rec    =>  l_attributes_rec
                                 , x_resultado         =>  l_result
                                 , x_error             =>  l_errmsg
                                  );

      IF (NOT l_result) THEN
        debug(C_API_NAME, l_errmsg);
        x_result := FALSE;
        x_errmsg := l_errmsg;
        RETURN;
      END IF;

    END IF;


    --------------------------
    -- Lanzo la interace de AR
    --------------------------
    debug(C_API_NAME, 'Previo a ejecutar interface de AR: ');
    debug(C_API_NAME, 'p_liquidacion_rec.operating_unit: '||p_liquidacion_rec.operating_unit);
    debug(C_API_NAME, 'l_batch_source_name: '||l_batch_source_name);
    debug(C_API_NAME, 'p_liquidacion_rec.customer_class_code: '||p_liquidacion_rec.customer_class_code);
    Ejecutar_Interface_AR_1116A ( p_org_id             => p_liquidacion_rec.operating_unit
                                , p_batch_source_name  => l_batch_source_name
                                , p_transaction_number => FND_PROFILE.value('XX_ACO_RA_NC_PREFIX') ||
                                                          p_liquidacion_rec.numero_liquidacion
                                , p_customer_class     => p_liquidacion_rec.customer_class_code
                                , x_result             => l_result
                                , x_errmsg             => l_errmsg);

    IF (NOT l_result) THEN

      x_warning := l_errmsg;
      x_result := FALSE;
      x_errmsg := l_errmsg;

    ELSE
      -- Agregado CR1334
      BEGIN

        debug(C_API_NAME, 'Update de las lineas ZX_LINES: ');
        SELECT customer_trx_id
             , batch_source_id        --CR1919
          INTO l_nc_cust_trx_id
             , l_batch_source_id_cm
          FROM RA_CUSTOMER_TRX_ALL
         WHERE trx_number = FND_PROFILE.value('XX_ACO_RA_NC_PREFIX') ||p_liquidacion_rec.numero_liquidacion
           AND interface_header_context = 'XX_AR_CERTIFICADOS'
           AND interface_header_attribute2 = 'CM';

        UPDATE ZX_LINES zl
           SET (zl.global_attribute_category, zl.global_attribute2, zl.global_attribute3)
                = (SELECT rctl.global_attribute_category, rctl.global_attribute2, rctl.global_attribute3
                     FROM RA_CUSTOMER_TRX_LINES_ALL rctl
                    WHERE rctl.customer_trx_id = zl.trx_id
                      AND rctl.customer_trx_line_id = zl.trx_line_id)
         WHERE zl.trx_id = l_nc_cust_trx_id;

      EXCEPTION
        WHEN others THEN
          x_errmsg := 'Error al querer actualizar los datos globales en la tabla ZX_LINES. '||SQLERRM;
          x_result := FALSE;
      END;

      /* Finalmente se decide que las NC Internas se realizarán todas por el mismo concurrente: XX AR Generacion NC Internas por Devolucion Impositiva
      --CR1919
      -- Creación de la Nota de Crédito Interna en caso de que no se haya podido compensar todas las percepciones
      -- de la factura original

      BEGIN

        SELECT rbsi.batch_source_id
             , rbdi.document_letter
          INTO l_batch_source_id_int
             , l_batch_source_letter
          FROM RA_BATCH_SOURCES_ALL       rbsi
             , RA_BATCH_SOURCES_ALL1_DFV  rbdi
             , RA_BATCH_SOURCES_ALL       rbsr
             , RA_BATCH_SOURCES_ALL1_DFV  rbdr
             , FND_LOOKUP_VALUES_VL       flv
         WHERE rbsi.rowid           = rbdi.row_id
           AND rbdi.context_value   = 'JL.AR.RAXSUMSC.BATCH_SOURCES'
           AND rbsi.status          = 'A'
           AND UPPER(rbsi.name)     LIKE 'COMPROBANTE%INTERNO%'
           AND TRUNC(SYSDATE)       BETWEEN NVL(rbsi.start_date, TRUNC(SYSDATE))
                                        AND NVL(rbsi.end_date, TRUNC(SYSDATE))
           AND rbsr.rowid           = rbdr.row_id
           AND rbdr.context_value   = 'JL.AR.RAXSUMSC.BATCH_SOURCES'
           AND rbsr.status          = 'A'
           AND rbsr.batch_source_id = l_batch_source_id_cm
           AND TRUNC(SYSDATE)       BETWEEN NVL(rbsr.start_date, TRUNC(SYSDATE))
                                        AND NVL(rbsr.end_date, TRUNC(SYSDATE))
           AND rbdi.document_letter = rbdr.document_letter
           AND flv.lookup_type      = 'XX_AR_TAX_RETURN_SETUP'
           AND flv.lookup_code      = 'INT_BATCH_SOURCE'
           AND TRUNC(SYSDATE)       BETWEEN NVL(TRUNC(flv.start_date_active), TRUNC(SYSDATE))
                                        AND NVL(TRUNC(flv.end_date_active), TRUNC(SYSDATE))
           AND rbdi.four_digit_code = flv.meaning
           AND rbsi.org_id          = p_liquidacion_rec.operating_unit;



      EXCEPTION
        WHEN OTHERS THEN
          x_errmsg := 'Error al obtener ID del Origen para la Nota de Credito Interna. Error: '||SQLERRM;
          RAISE eNCInterna;
      END;

      BEGIN

        SELECT rctt.cust_trx_type_id
          INTO l_cust_trx_type_id_int
          FROM RA_CUST_TRX_TYPES_ALL rctt
             , FND_LOOKUP_VALUES_VL  flv
         WHERE rctt.name       = flv.meaning
           AND flv.lookup_type = 'XX_AR_TAX_RETURN_SETUP'
           AND flv.lookup_code = 'INT_CUST_TRX_TYPE_'||l_batch_source_letter
           AND TRUNC(SYSDATE)  BETWEEN NVL(TRUNC(rctt.start_date),TRUNC(SYSDATE))
                                   AND NVL(TRUNC(rctt.end_date),TRUNC(SYSDATE))
           AND TRUNC(SYSDATE)  BETWEEN NVL(TRUNC(flv.start_date_active),TRUNC(SYSDATE))
                                   AND NVL(TRUNC(flv.end_date_active),TRUNC(SYSDATE))
           AND rctt.org_id     = p_liquidacion_rec.operating_unit;

      EXCEPTION
        WHEN OTHERS THEN
          x_errmsg := 'Error al obtener ID del Tipo de Transaccion de Nota de Credito Interna. Error: '||SQLERRM;
          RAISE eNCInterna;
      END;

      BEGIN

        SELECT aml.memo_line_id
          INTO l_memo_line_id_int
          FROM AR_MEMO_LINES_ALL_B  aml
             , AR_MEMO_LINES_ALL_TL amt
             , FND_LOOKUP_VALUES_VL flv
         WHERE amt.name         = flv.meaning
           AND aml.memo_line_id = amt.memo_line_id
           AND amt.language     = 'ESA'
           AND flv.lookup_type  = 'XX_AR_TAX_RETURN_SETUP'
           AND flv.lookup_code  = 'INT_MEMO_LINE_ID'
           AND TRUNC(SYSDATE)   BETWEEN NVL(TRUNC(aml.start_date),TRUNC(SYSDATE))
                                    AND NVL(TRUNC(aml.end_date),TRUNC(SYSDATE))
           AND TRUNC(SYSDATE)   BETWEEN NVL(TRUNC(flv.start_date_active),TRUNC(SYSDATE))
                                    AND NVL(TRUNC(flv.end_date_active),TRUNC(SYSDATE))
           AND aml.org_id       = p_liquidacion_rec.operating_unit;

      EXCEPTION
        WHEN OTHERS THEN
          x_errmsg := 'Error al obtener ID del Memo Line para Nota de Credito Interna. Error: '||SQLERRM;
          RAISE eNCInterna;
      END;

      BEGIN

        XX_AR_TAX_RETURN_NC_PKG.Gen_trx_int( p_status                => l_status
                                           , p_error_message         => x_errmsg
                                           , p_customer_trx_id       => l_cust_trx_id
                                           , p_batch_source_id_cm    => l_batch_source_id_int
                                           , p_cust_trx_type_id_cm   => l_cust_trx_type_id_int
                                           , p_memo_line_id_int      => l_memo_line_id_int
                                           , p_order_number          => NULL
                                           , p_total_parcial         => 'T'
                                           , p_comments              => 'Devolucion de Factura:'
                                           , p_customer_trx_id_int   => l_cust_trx_id_int
                                           , p_trx_number_int        => l_trx_number_int
                                           , p_amount_int            => l_amount_int);

        IF l_status != 'S' THEN
          RAISE eNCInterna;
        END IF;

        debug(C_API_NAME, 'l_cust_trx_id_int: '||l_cust_trx_id_int);
        debug(C_API_NAME, 'l_trx_number_int: ' ||l_trx_number_int);
        debug(C_API_NAME, 'l_amount_int: '     ||l_amount_int);

      EXCEPTION
        WHEN OTHERS THEN
          x_errmsg := 'Error al intentar realizar la Nota de Crédito Interna. '||SQLERRM;
          x_result := FALSE;
      END;

      */
    END IF;



  EXCEPTION
    WHEN eNCInterna THEN
      x_result := FALSE;

    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado generando nota de credito. Detalle: '||SQLERRM;

  END Generar_NC_1116A;



 /* ***************************************************************************
 * Name    : Get_IF_Credit_Interco                                            *
 * Purpose : Verifico si la transaccion NC intercompany esta en la interface  *
 *                                                                            *
 *****************************************************************************/
  FUNCTION Get_IF_Credit_Interco ( p_customer_id        NUMBER
                                 , p_numero_liquidacion VARCHAR2
                                 )
  RETURN NUMBER IS

    l_flag_exist  NUMBER;

  BEGIN

    SELECT 1
      INTO l_flag_exist
      FROM RA_INTERFACE_LINES_ALL     ril
         , XX_TCG_PARAMETROS_COMPANIA xtpc
     WHERE 1=1
       AND ril.org_id                = xtpc.operating_unit
       AND xtpc.customer_id          = p_customer_id
       AND interface_line_context    = 'XX_AR_CERTIFICADOS' --'ACOPIO'
       AND interface_line_attribute2 = 'NC'
       AND interface_line_attribute1 = p_numero_liquidacion;

    RETURN (l_flag_exist);

  EXCEPTION
    WHEN OTHERS THEN
      RETURN (-1);
  END Get_IF_Credit_Interco;


 /***************************************************************************
 * Name    : Get_AR_Credit_Interco                                          *
 * Purpose : Verifico si la transaccion NC intercompany ya se genero.       *
 *                                                                          *
 ***************************************************************************/
  FUNCTION Get_AR_Credit_Interco ( p_term_id            NUMBER
                                 , p_customer_id        NUMBER
                                 , p_numero_liquidacion VARCHAR2
                                 )
  RETURN NUMBER IS

    l_es_canje                    VARCHAR2(1);
    l_cust_trx_id                 ra_customer_trx_all.customer_trx_id%type;
    l_ra_nc_ctrx_type_id_interco  ra_cust_trx_types_all.cust_trx_type_id%type;

  BEGIN


    -- Agrego logica para obtener tipo de transaccion
    -- a partir del DFF de termino de pago, siempre y cuando sea de canje.
    BEGIN
      SELECT NVL(rtfv.xx_ar_canje,'N') -- 'Y'
      INTO l_es_canje
      FROM RA_TERMS        rt
         , RA_TERMS_B_DFV  rtfv
     WHERE 1=1
       AND rt.row_id  = rtfv.row_id
       AND rt.term_id = p_term_id;

    EXCEPTION
      WHEN OTHERS THEN
        l_es_canje := 'N';
    END;

    IF (l_es_canje = 'N') THEN
      ----------------------------------------------------------------
      -- Si no es canje, busco la factura con el tipo de transaccion
      -- seteado en la pantalla de parametrizacion por cia de acopio
      ----------------------------------------------------------------
      SELECT rct.customer_trx_id
        INTO l_cust_trx_id
        FROM RA_CUSTOMER_TRX_ALL        rct
           , XX_TCG_PARAMETROS_COMPANIA xtpc
           , HZ_CUST_SITE_USES_ALL      hcsu
           , HZ_CUST_ACCT_SITES_ALL     hcas
           , JL_ZZ_AR_TX_ATT_CLS_ALL    cus_tax
           , JL_ZZ_AR_TX_CATEG_ALL      cat
           , JL_AR_AR_DOC_LETTER_ALL    let
       WHERE  1=1
         AND rct.cust_trx_type_id        = xtpc.ra_ncint_cust_trx_type_id
         AND rct.org_id                  = xtpc.operating_unit
         AND rct.ship_to_site_use_id     = hcsu.site_use_id
         AND hcsu.cust_acct_site_id      = hcas.cust_acct_site_id
         AND hcas.global_attribute8      = cus_tax.tax_attr_class_code
         AND cus_tax.tax_attr_class_type = 'CONTRIBUTOR_CLASS'
         AND rct.org_id                  = cus_tax.org_id
         AND cus_tax.tax_attribute_name  = cat.cus_tax_attribute
         AND cat.tax_category            = 'VAT'
         AND cus_tax.org_id              = cat.org_id
         AND cat.tax_category_id         = let.tax_category_id
         AND cat.cus_tax_attribute       = let.con_tax_attribute_name
         AND cus_tax.tax_attribute_value = let.con_tax_attribute_value
         AND cat.org_id                  = let.org_id
         AND rct.trx_number              = let.document_letter||'-'||p_numero_liquidacion;

    ELSE
      -- Obtengo origen y tipo de transaccion a partir de los parametros de cia
      -- para las operaciones de canje.
      BEGIN
        SELECT rbs.default_inv_trx_type
          INTO l_ra_nc_ctrx_type_id_interco
          FROM XX_TCG_PARAMETROS_COMPANIA xtpc
             , RA_BATCH_SOURCES_ALL       rbs
         WHERE 1=1
           AND xtpc.ra_nccje_batch_sce_interco = rbs.name
           AND xtpc.operating_unit             = rbs.org_id
           AND xtpc.customer_id                = p_customer_id;

      EXCEPTION
        WHEN OTHERS THEN
          RETURN (-1);
      END;

      ----------------------------------------------------------------
      -- Si es canje, busco la factura con el tipo de transaccion
      -- default del origen de canje de acopio.
      ----------------------------------------------------------------
      SELECT rct.customer_trx_id
        INTO l_cust_trx_id
        FROM RA_CUSTOMER_TRX_ALL          rct
           , XX_TCG_PARAMETROS_COMPANIA   xtpc
           , HZ_CUST_SITE_USES_ALL        hcsu
           , HZ_CUST_ACCT_SITES_ALL       hcas
           , JL_ZZ_AR_TX_ATT_CLS_ALL      cus_tax
           , JL_ZZ_AR_TX_CATEG_ALL        cat
           , JL_AR_AR_DOC_LETTER_ALL      let
       WHERE 1=1
         AND rct.cust_trx_type_id        = l_ra_nc_ctrx_type_id_interco
         AND rct.org_id                  = xtpc.operating_unit
         AND rct.ship_to_site_use_id     = hcsu.site_use_id
         AND hcsu.cust_acct_site_id      = hcas.cust_acct_site_id
         AND hcas.global_attribute8      = cus_tax.tax_attr_class_code
         AND cus_tax.tax_attr_class_type = 'CONTRIBUTOR_CLASS'
         AND rct.org_id                  = cus_tax.org_id
         AND cus_tax.tax_attribute_name  = cat.cus_tax_attribute
         AND cat.tax_category            = 'VAT'
         AND cus_tax.org_id              = cat.org_id
         AND cat.tax_category_id         = let.tax_category_id
         AND cat.cus_tax_attribute       = let.con_tax_attribute_name
         AND cus_tax.tax_attribute_value = let.con_tax_attribute_value
         AND cat.org_id                  = let.org_id
         AND rct.trx_number              = let.document_letter||'-'||p_numero_liquidacion;


    END IF;

    RETURN (l_cust_trx_id);

  EXCEPTION
    WHEN OTHERS THEN
      RETURN (-1);
  END Get_AR_Credit_Interco;




 /****************************************************************************
 *                                                                          *
 * Name    : Generar_NDInterco_1116A                                        *
 * Purpose : Rutina para la generacion de una ND Interco en AR a partir de  *
 *           la cancelacion de la liquidacion 1116a.                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Generar_NDInterco_1116A ( p_liquidacion_rec  IN OUT NOCOPY liquidacion_1116a_rec_type
                                    , x_result              OUT BOOLEAN
                                    , x_errmsg              OUT VARCHAR2
                                    , x_warning             OUT VARCHAR2)
  IS

    CURSOR csites ( p_customer_id  NUMBER
                  , p_site_use    VARCHAR2
                  , p_org_id      NUMBER) IS
      SELECT hcsu.cust_acct_site_id
        FROM HZ_CUST_ACCT_SITES_ALL    hcas
           , HZ_CUST_SITE_USES_ALL     hcsu
           , HZ_CUST_SITE_USES_ALL_DFV hcsu_dfv
       WHERE hcas.cust_acct_site_id = hcsu.cust_acct_site_id
         AND hcsu.rowid             = hcsu_dfv.rowid
         AND hcsu_dfv.xx_dir_aco_interco = 'Y'
         AND hcsu.site_use_code     = p_site_use
         AND hcsu.org_id            = p_org_id
         AND hcas.cust_account_id   = p_customer_id;

    /* Para levantar las percepciones de la factura (no interco)
        FC +    NC INT -
        NC -    ND INT +
    */
    CURSOR cpercep (p_customer_trx_id NUMBER) IS
      SELECT avt.tax_code
           , rctl.extended_amount
        FROM RA_CUSTOMER_TRX_LINES_ALL rctl
           , AR_VAT_TAX_ALL            avt
           , AR_VAT_TAX_ALL_B1_DFV     avt_gldfv
           , JL_ZZ_AR_TX_CATEG_ALL     categ
       WHERE rctl.vat_tax_id        = avt.vat_tax_id
         AND avt.rowid              = avt_gldfv.rowid
         AND avt_gldfv.tax_category = categ.tax_category_id
         AND rctl.org_id            = categ.org_id
         AND categ.tax_category    != 'VAT'
         AND rctl.extended_amount   <> 0
         AND rctl.line_type         = 'TAX'
         AND rctl.customer_trx_id   = p_customer_trx_id;

    C_API_NAME                          VARCHAR2(30) := 'GENERAR_NDINTERCO_1116A ';
    l_batch_source_name_interco         ra_batch_sources_all.name%TYPE;
    l_result                            BOOLEAN;
    l_errmsg                            VARCHAR2(2000);
    l_combination_id                    NUMBER;
    l_ra_nd_ctrx_type_id_interco        NUMBER;
    l_attributes_rec                    attributes_rec_type;
    l_appl_column_name                  VARCHAR2(30);
    l_es_canje                          VARCHAR2(1):='N';
    l_org_id                            NUMBER;
    l_org_inv_id                        NUMBER;
    l_sob_id                            NUMBER;
    l_customer_interco                  NUMBER;
    l_orig_system_bill_address_id       NUMBER;
    l_orig_system_ship_address_id       NUMBER;
    l_term_name                         ra_terms.name%TYPE;
    l_co_code                           VARCHAR2(3);
    l_cod_impuesto                      VARCHAR2(100);
    l_num_customer_trx_id               NUMBER:=0;
    l_index                             NUMBER;


  BEGIN

    x_result := TRUE;

    -- Agrego logica para obtener origen y tipo de transaccion
    -- a partir del DFF de termino de pago, siempre y cuando sea de canje.
    BEGIN
      SELECT NVL(rtfv.xx_ar_canje,'N')
           , rt.name
        INTO l_es_canje
           , l_term_name
        FROM RA_TERMS        rt
           , RA_TERMS_B_DFV  rtfv
       WHERE  1=1
         AND rt.row_id  = rtfv.row_id
         AND rt.term_id = p_liquidacion_rec.ra_term_id;

    EXCEPTION
      WHEN OTHERS THEN
        l_es_canje := 'N';
    END;


    IF (l_es_canje = 'N') THEN

      ----------------------------------------------------------------
      -- Obtengo el batch_source_name de la configuracion por compania
      -- y otros datos de compania.
      ----------------------------------------------------------------
      BEGIN

        SELECT xtpc.ra_nd_batch_sce_interco
             , xtpc.ra_ndint_cust_trx_type_id
             , hou.set_of_books_id
             , xtpc.operating_unit
--             , org_inv_id
             , hou.default_legal_context_id
             , xtpc.acct_id_default_1116a
          INTO l_batch_source_name_interco
             , l_ra_nd_ctrx_type_id_interco
             , l_sob_id
             , l_org_id
--             , l_org_inv_id
             , l_co_code
             , p_liquidacion_rec.acct_id_default_1116a
          FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
             , HR_OPERATING_UNITS          hou
         WHERE xtpc.operating_unit = hou.organization_id
           AND xtpc.customer_id    = p_liquidacion_rec.customer_id;

      EXCEPTION
        WHEN no_data_found THEN
          x_result := FALSE;
          x_errmsg := 'No fue posible obtener la configuracion de acopio para el cliente: '
                      || p_liquidacion_rec.customer_id ||'. No fue posible obtener el origen de lote para la '||
                      'generacion de la ND INTERCO.';
          RETURN;
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniendo la configuracion de Acopio para el cliente: '|| p_liquidacion_rec.customer_id ||'. '||
                      'No fue posible obtener el origen de lote para la generacion la ND INTERCO. Detalle: ' || SQLERRM;
          RETURN;
      END;

    ELSE

      -- Obtengo origen y tipo de transaccion a partir de los parametros de cia
      -- para las operaciones de canje.
      BEGIN

        SELECT xtpc.ra_ndcje_batch_sce_interco
             , rbs.default_inv_trx_type
             , hou.set_of_books_id
             , xtpc.operating_unit
--             , xtpc.org_inv_id
             , hou.default_legal_context_id
             , xtpc.acct_id_default_1116a
          INTO l_batch_source_name_interco
             , l_ra_nd_ctrx_type_id_interco
             , l_sob_id
             , l_org_id
--             , l_org_inv_id
             , l_co_code
             , p_liquidacion_rec.acct_id_default_1116a
          FROM XX_TCG_PARAMETROS_COMPANIA xtpc
             , RA_BATCH_SOURCES_ALL       rbs
             , HR_OPERATING_UNITS         hou
         WHERE 1=1
           AND xtpc.ra_ndcje_batch_sce_interco = rbs.name
           AND xtpc.operating_unit             = rbs.org_id
           AND xtpc.operating_unit             = hou.organization_id
           AND xtpc.customer_id                = p_liquidacion_rec.customer_id;

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Error obteniedo la configuracion de acopio para el cliente: '|| p_liquidacion_rec.customer_id ||
                      '. No fue posible obtener el origen de lote para la generacion la ND INTERCO de canje. Detalle: ' || SQLERRM;
          RETURN;
      END;

    END IF;


    IF (l_batch_source_name_interco IS NULL) THEN

      x_result := FALSE;
      x_errmsg := 'No se espefico el nombre del origen de lote para el cliente: '|| p_liquidacion_rec.customer_id ||
                  '. No fue posible determinar el origen de lote para la generacion de la ND INTERCO.';
      RETURN;
    END IF;


    IF (l_ra_nd_ctrx_type_id_interco IS NULL) THEN
      x_result := FALSE;
      x_errmsg := 'No se espefico el tipo de transaccion de AR para el cliente: '|| p_liquidacion_rec.customer_id ||
                  '. Por favor verifique la configuracion de los parametros. ';
      RETURN;
    END IF;



    ----------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar el pedido de vta
    ----------------------------------------------------------------
    l_result := XX_UTIL_PK.dff_get_column ( p_appl_short_name   => 'AR'
                                          , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                          , p_desc_flex_context => 'AR'
                                          , p_desc_flex_column  => 'XX_AR_NRO_PEDIDO_OM'
                                          , p_appl_column_name  => l_appl_column_name
                                          , p_mesg_error        => l_errmsg
                                          );
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '||
                  '"XX_AR_NRO_PEDIDO_OM" dentro dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    Set_Attribute_Value ( p_attributes_rec => l_attributes_rec
                        , p_column_name    => l_appl_column_name
                        , p_value          => p_liquidacion_rec.oe_order_number);


    ------------------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar el tipo de pedido de vta
    ------------------------------------------------------------------------
    l_result := XX_UTIL_PK.dff_get_column ( p_appl_short_name   => 'AR'
                                          , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                          , p_desc_flex_context => 'AR'
                                          , p_desc_flex_column  => 'XX_AR_TIPO_PEDIDO_OM'
                                          , p_appl_column_name  => l_appl_column_name
                                          , p_mesg_error        => l_errmsg
                                          );
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento '||
                  '"XX_AR_TIPO_PEDIDO_OM" dentro dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;

    Set_Attribute_Value ( p_attributes_rec => l_attributes_rec
                        , p_column_name    => l_appl_column_name
                        , p_value          => p_liquidacion_rec.oe_order_type);


    ------------------------------------------------------------------------
    -- Obtengo el numero de segmento para almacenar tipo liquidacion
    ------------------------------------------------------------------------
    l_result := XX_UTIL_PK.dff_get_column ( p_appl_short_name   => 'AR'
                                          , p_desc_flex_name    => 'RA_CUSTOMER_TRX'
                                          , p_desc_flex_context => 'AR'
                                          , p_desc_flex_column  => 'XX_AR_TIPO_LIQUIDACION'
                                          , p_appl_column_name  => l_appl_column_name
                                          , p_mesg_error        => l_errmsg
                                          );
    IF (NOT l_result) THEN
      x_errmsg := 'Error al intentar obtener el nombre de la columna para almacenar el segmento "XX_AR_TIPO_LIQUIDACION" dentro '||
                    'dentro del flexfield "RA_CUSTOMER_TRX". Detalle: '||l_errmsg;
      x_result := FALSE;
      RETURN;
    END IF;


    Set_Attribute_Value ( p_attributes_rec => l_attributes_rec
                        , p_column_name    => l_appl_column_name
                        , p_value          => 'Unica');


    -----------------------------------------------------------
    -- Obtengo datos del cliente de nota de debito interco
    -----------------------------------------------------------
    BEGIN
      SELECT customer_id
        INTO l_customer_interco
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_liquidacion_rec.operating_unit;

    EXCEPTION
      WHEN OTHERS THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo el cliente asociado para la CIA: '||
                     p_liquidacion_rec.operating_unit ||'. '|| SQLERRM;
        RETURN;
    END;

    FOR l_cSitesBill IN CSITES( l_customer_interco
                              , 'BILL_TO'
                              , l_org_id) LOOP
        l_orig_system_bill_address_id := l_cSitesBill.cust_acct_site_id;
    END LOOP;

    FOR l_cSitesShip IN CSITES( l_customer_interco
                              , 'SHIP_TO'
                              , l_org_id) LOOP
        l_orig_system_ship_address_id := l_cSitesShip.cust_acct_site_id;
    END LOOP;

    IF (l_orig_system_bill_address_id IS NULL OR
        l_orig_system_ship_address_id IS NULL) THEN
      x_errmsg := 'Error al obtener las direcciones de Envio o Facturacion '||
                   'para el cliente asociado a la CIA. '||p_liquidacion_rec.operating_unit;
      x_result := FALSE;
      RETURN;
    END IF;


    -----------------------------------------------------------------------------
    -- Obtengo lineas de percepciones de la FC y las incluyo al vector de lineas
    -----------------------------------------------------------------------------
    -- Obtengo cantidad de registros del vector de lineas de liquidacion
    l_index := p_liquidacion_rec.lineas.COUNT;

    -- Solo busca el ID si tengo lineas en la factura
    -- ACO - BUG - Certificado de Deposito sin FC exige ID de FC para Cancelacion
    IF l_index <> 0 THEN


      BEGIN

        SELECT customer_trx_id
          INTO l_num_customer_trx_id
          FROM XX_TCG_LIQUIDACIONES_1116A  xla
             , RA_CUSTOMER_TRX_ALL         rct
         WHERE xla.liquidacion_id          = p_liquidacion_rec.liquidacion_id
           AND rct.ct_reference            = xla.numero_liquidacion
           AND rct.org_id                  = p_liquidacion_rec.operating_unit
           AND interface_header_attribute2 = 'FC';

      EXCEPTION
        WHEN OTHERS THEN
          x_errmsg := 'Error al obtener el ID de la factura para la liquidacion : '||
                       p_liquidacion_rec.numero_liquidacion;
          x_result := FALSE;
          RETURN;
      END;


    -- Solo busca el ID si tengo lineas en la factura
    -- ACO - BUG - Certificado de Deposito sin FC exige ID de FC para Cancelacion
    END IF;


    FOR l_cPercep IN CPERCEP(l_num_customer_trx_id) LOOP

      l_index := l_index + 1;

      -- Obtengo memo line asociada al codigo de impuesto percep
      BEGIN

        SELECT aml.name
             , aml.memo_line_id
             , aml.gl_id_rev
             , aml_gldfv.transaction_condition_class
          INTO p_liquidacion_rec.lineas(l_index).memo_line_name
             , p_liquidacion_rec.lineas(l_index).memo_line_id
             , p_liquidacion_rec.lineas(l_index).gl_id_rev
             , p_liquidacion_rec.lineas(l_index).codigo_impuesto
          FROM AR_MEMO_LINES_ALL_VL     aml
             , AR_MEMO_LINES_ALL_B_DFV  aml_dfv
             , AR_MEMO_LINES_ALL_B1_DFV aml_gldfv
          WHERE aml.row_id            = aml_dfv.row_id
            AND aml.row_id            = aml_gldfv.row_id
            AND aml_dfv.xx_tax_code   = l_cPercep.tax_code
            AND aml.org_id            = l_org_id;

          p_liquidacion_rec.lineas(l_index).importe             := l_cPercep.extended_amount;
          p_liquidacion_rec.lineas(l_index).liquidacion_line_id := -1;
          p_liquidacion_rec.lineas(l_index).memo_line_interco   := NULL;

      EXCEPTION
        WHEN OTHERS THEN
          x_result := FALSE;
          x_errmsg := 'Error generando Nota de Debito Interco. Se produjo un error al obtener el memo line'||
                      ' asociada a la percepcion: '||l_cPercep.tax_code ||'. Detalle: '|| SQLERRM;
          RETURN;
      END;

    END LOOP;



    -------------------------------------------------------------------
    -- Por cada linea de la liquidacion genero la linea en la interface
    -------------------------------------------------------------------
    FOR l_index IN 1 .. p_liquidacion_rec.lineas.COUNT LOOP

      IF (p_liquidacion_rec.lineas(l_index).memo_line_interco IS NOT NULL) THEN

        -- Obtengo codigo de impuesto para cada linea de liquidacion
        BEGIN
          SELECT aml_gldfv.transaction_condition_class
            INTO p_liquidacion_rec.lineas(l_index).codigo_impuesto
            FROM AR_MEMO_LINES_ALL_VL     aml
               , AR_MEMO_LINES_ALL_B1_DFV aml_gldfv
           WHERE aml.row_id         = aml_gldfv.row_id
             AND aml.name           = p_liquidacion_rec.lineas(l_index).memo_line_interco
             AND aml.org_id         = l_org_id;

        EXCEPTION
          WHEN OTHERS THEN
            x_result := FALSE;
            x_errmsg := 'Error generando Nota de Debito Interco. Se produjo un error al obtener el codigo '||
                        'de impuesto para la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_interco ||
                        '. Detalle: '|| SQLERRM;
            RETURN;
        END;


      END IF;


      -------------------
      -- Inserto la linea
      -------------------
      BEGIN

        INSERT INTO RA_INTERFACE_LINES_ALL
          ( line_type
          , cust_trx_type_id
          , orig_system_bill_address_id
          , trx_date
          , batch_source_name
          , trx_number
          , quantity
          , currency_code
          , unit_selling_price
          , amount
          , conversion_type
          , conversion_rate
          , conversion_date
          , set_of_books_id
          , memo_line_name
          , memo_line_id
          , line_gdf_attribute2
          , line_gdf_attribute3
          , interface_line_context
          , interface_line_attribute1
          , interface_line_attribute2
          , interface_line_attribute3
          , orig_system_ship_address_id
          , ship_date_actual
--          , warehouse_id
          , header_gdf_attr_category
          , line_gdf_attr_category
          , orig_system_bill_customer_id
          , orig_system_ship_customer_id
          , orig_system_sold_customer_id
          , term_name -- term_id
          , description
          , gl_date
          , amount_includes_tax_flag
          , header_attribute_category
          , header_attribute1
          , header_attribute2
          , header_attribute3
          , header_attribute4
          , header_attribute5
          , header_attribute6
          , header_attribute7
          , header_attribute8
          , header_attribute9
          , header_attribute10
          , header_attribute11
          , header_attribute12
          , header_attribute13
          , header_attribute14
          , header_attribute15
          , org_id
          , creation_date
          , created_by
          , last_update_date
          , last_updated_by
          , last_update_login
          )
        VALUES
         ( 'LINE'
         , l_ra_nd_ctrx_type_id_interco
         , l_orig_system_bill_address_id
         , p_liquidacion_rec.fecha_anulacion
         , l_batch_source_name_interco
         , FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') || p_liquidacion_rec.numero_liquidacion
         , 1
         , p_liquidacion_rec.currency_code
         , p_liquidacion_rec.lineas(l_index).importe
         , p_liquidacion_rec.lineas(l_index).importe
         , 'User'
         , 1
         , p_liquidacion_rec.fecha_liquidacion
         , l_sob_id
         , NVL(p_liquidacion_rec.lineas(l_index).memo_line_interco
         , p_liquidacion_rec.lineas(l_index).memo_line_name)
         , NULL
         , 'DEFAULT'
         , p_liquidacion_rec.lineas(l_index).codigo_impuesto
         , 'XX_AR_CERTIFICADOS' --'ACOPIO'
         , p_liquidacion_rec.numero_liquidacion
         , 'ND'
         , l_index
         , l_orig_system_ship_address_id
         , p_liquidacion_rec.fecha_anulacion
--         , l_org_inv_id
         , 'JL.AR.ARXTWMAI.TGW_HEADER'
         ,'JL.AR.ARXTWMAI.LINES'
         , l_customer_interco
         , l_customer_interco
         , l_customer_interco
         , l_term_name
         , NVL(p_liquidacion_rec.lineas(l_index).memo_line_interco
         , p_liquidacion_rec.lineas(l_index).memo_line_name)
         , p_liquidacion_rec.fecha_anulacion
         , 'N'
         , 'AR'
         , l_attributes_rec.attribute1
         , l_attributes_rec.attribute2
         , l_attributes_rec.attribute3
         , l_attributes_rec.attribute4
         , l_attributes_rec.attribute5
         , l_attributes_rec.attribute6
         , l_attributes_rec.attribute7
         , l_attributes_rec.attribute8
         , l_attributes_rec.attribute9
         , l_attributes_rec.attribute10
         , l_attributes_rec.attribute11
         , l_attributes_rec.attribute12
         , l_attributes_rec.attribute13
         , l_attributes_rec.attribute14
         , l_attributes_rec.attribute15
         , l_org_id
         , SYSDATE
         , FND_GLOBAL.user_id
         , SYSDATE
         , FND_GLOBAL.user_id
         , FND_GLOBAL.login_id
         );

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error generando Nota de Debito Interco. Se produjo un error al intentar insertar '||
                      'la linea de interface para la memoline: '||p_liquidacion_rec.lineas(l_index).memo_line_name ||
                      '. Detalle: '|| SQLERRM;
          RETURN;
      END;


      -- Asigno el segmento compania de la empresa que genero la liquidacion
      -- al campo co_code_interco, para luego usarlo en la asignacion del segmento8
      -- de la distribucion contable.
      p_liquidacion_rec.legal_entity_interco := p_liquidacion_rec.legal_entity_id;


      -- Asigno el segmento compania de la empresa intercompany
      -- al campo co_code del registro
      p_liquidacion_rec.legal_entity_id := l_co_code;




      -----------------------------------
      -- Inserto la linea de distribucion
      -----------------------------------
      BEGIN

        INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL
          ( account_class
          , interface_line_context
          , amount
          , interface_line_attribute1
          , interface_line_attribute2
          , interface_line_attribute3
          , code_combination_id
          , org_id
          , percent
          , creation_date
          , created_by
          , last_update_date
          , last_updated_by
          , last_update_login
          )
        VALUES
          ( 'REV'
          , 'XX_AR_CERTIFICADOS' --'ACOPIO'
          , p_liquidacion_rec.lineas(l_index).importe
          , p_liquidacion_rec.numero_liquidacion
          , 'ND'
          , l_index
          , p_liquidacion_rec.lineas(l_index).gl_id_rev
          , l_org_id
          , 100
          , SYSDATE
          , FND_GLOBAL.user_id
          , SYSDATE
          , FND_GLOBAL.user_id
          , FND_GLOBAL.login_id
           );

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'Error generando Nota de Debito Interco. Se produjo un error al intentar insertar '||
                      'la linea de distribucion para la memoline: '|| p_liquidacion_rec.lineas(l_index).memo_line_name ||
                      '. Detalle: '|| SQLERRM;
          RETURN;
      END;

    END LOOP;


    --------------------------
    -- Lanzo la interace de AR
    --------------------------
    IF (NVL(FND_PROFILE.value('XX_ACO_EJECUTAR_INTERFACE_AR'),'N') = 'Y') THEN

      Ejecutar_Interface_AR_1116A ( p_org_id             => p_liquidacion_rec.operating_unit
                                  , p_batch_source_name  => l_batch_source_name_interco
                                  , p_transaction_number => FND_PROFILE.value('XX_ACO_RA_FC_PREFIX') ||
                                                            p_liquidacion_rec.numero_liquidacion
                                  , p_customer_class     => NULL
                                  , x_result             => l_result
                                  , x_errmsg             => l_errmsg);

      IF (NOT l_result) THEN
        x_warning := l_errmsg;
      END IF;

    END IF;


  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error inesperado generando Nota de Debito Interco. Detalle: '|| SQLERRM;

  END Generar_NDInterco_1116A;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible                                            *
 * Purpose : Rutina que retorna el peso disponible del 1116A para           *
 *           transferencias o retiros y tiene en cuenta las liquidaciones   *
 *           1116B Liquidadas.                                              *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Peso_Disponible ( p_certificado_id         IN NUMBER
                                , p_liquidacion_id         IN NUMBER DEFAULT NULL
                                , p_lock_flag              IN BOOLEAN DEFAULT FALSE
                                , x_peso                  OUT NUMBER
                                , x_result                OUT BOOLEAN
                                , x_errmsg                OUT VARCHAR2)

  IS

    CURSOR c_cartas_porte IS
      SELECT xtbl.carta_porte_id
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , XX_TCG_BOLETIN_LINES        xtbl
       WHERE xtla.liquidacion_id    = p_certificado_id
         AND xtla.boletin_header_id = xtbl.boletin_header_id;



    C_API_NAME              VARCHAR2(300) := 'Get_Peso_Disponible';
    l_certificado_id        NUMBER;
    l_peso_aplicado         NUMBER := 0;
    l_peso_subtotal         NUMBER;
    l_result                BOOLEAN;
    l_errmsg                VARCHAR2(2000);


  BEGIN

    x_result := TRUE;

    debug(C_PACKAGE_NAME, C_API_NAME|| ' Inicio');
    debug(C_PACKAGE_NAME, C_API_NAME|| ' Certificado: '||p_certificado_id);
    debug(C_PACKAGE_NAME, C_API_NAME|| ' Liquidacion: '||p_liquidacion_id);

    ------------------------------------------------
    -- Si p_lock_flag es TRUE, loqueo la liquidacion
    ------------------------------------------------
    IF (p_lock_flag) THEN

      BEGIN
        SELECT liquidacion_id
          INTO l_certificado_id
          FROM XX_TCG_LIQUIDACIONES_1116A
         WHERE liquidacion_id = p_certificado_id
           FOR UPDATE NOWAIT;

      EXCEPTION
        WHEN others THEN
          x_result := FALSE;
          x_errmsg := 'No fue posible reservar el registro del Certificado. Detalle: ' ||SQLERRM ;
          RETURN;
      END;

    END IF;

    debug(C_PACKAGE_NAME, C_API_NAME|| ' Paso el lockeo');

    ---------------------------------------------------------------------
    -- Obtengo el peso total del 1116A, en funcion de las cartas de porte
    -- relacionadas.
    ---------------------------------------------------------------------
    FOR l_carta_porte_rec IN c_cartas_porte LOOP

      XX_TCG_CALIDAD_PKG.Get_Peso_aplicado ( p_carta_porte_id  => l_carta_porte_rec.carta_porte_id
                                           , x_result          => l_result
                                           , x_error_msg       => l_errmsg
                                           , x_peso_aplicado   => l_peso_subtotal);

      IF (NOT l_result) THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo peso aplicado para la carta de porte: '||
                    l_carta_porte_rec.carta_porte_id || '. No fue posible obtener el peso disponible del '||
                    'Certificado. Detalle: '|| l_errmsg;
        RETURN;
      END IF;

      debug(C_PACKAGE_NAME, C_API_NAME|| ' Sumo peso de cp: ' ||l_peso_subtotal);

      l_peso_aplicado := l_peso_aplicado + l_peso_subtotal;

    END LOOP;


    debug(C_PACKAGE_NAME, C_API_NAME|| ' Peso aplicado: ' || l_peso_aplicado);


    -- Calcular Pesos de Transferencia O rETIRO por RT
    SELECT  nvl(SUM(decode(tipo_liquidacion,'TRANSFERENCIA',PESO_TRANSFERIDO,
                                    (SELECT SUM(PESO_RETIRO) FROM xx_tcg_rt_LINES XRTL WHERE XRTL.LIQUIDACION_ID = XRT.LIQUIDACION_ID))),0)
                  INTO l_peso_subtotal
        FROM XX_TCG_RT        XRT
        WHERE liquidacion_id_certificado =     p_certificado_id
        and nvl(cancelado_flag,'N') = 'N'
        and nvl(liquidado_flag,'N') = 'Y';
       l_peso_aplicado := l_peso_aplicado - NVL(l_peso_subtotal,0);

    -------------------------------------------------------
    -- Resto el peso liquidado por Unica y Ajuste Unico
    ------------------------------------------------------
    BEGIN

      l_peso_subtotal := 0;

      SELECT SUM(NVL(xtcl.peso_a_liquidar, 0))
        INTO l_peso_subtotal
        FROM XX_TCG_CERTIFICADOS_LIQUIDADOS  xtcl
           , XX_TCG_LIQUIDACIONES            xtl
       WHERE xtcl.liquidacion_id           = xtl.liquidacion_id
         AND xtcl.certificado_id           = p_certificado_id
         AND xtl.tipo_liquidacion          IN ( 'UNICA'
                                              , 'AJUSTE_UNICO' )
         AND (NVL(xtl.liquidado_flag,'N')   = 'Y'
              OR
              (xtl.liquidacion_id != NVL(p_liquidacion_id, -1)
              AND NVL(xtl.liquidado_flag,'N') = 'N'))
         AND ((NVL(xtl.cancelado_flag,'N') = 'N')
             OR
             (NVL(xtl.cancelado_flag,'N')  = 'Y'
             AND xtl.estado_coe            IN ( 'SOLICITAR'
                                              , 'ESP_RESP' )));

    EXCEPTION
      WHEN others THEN
        x_result := FALSE;
        x_errmsg := 'Error obteniendo el peso liquidado en Unica/Ajuste Unico sobre el certificado: '
                    ||p_certificado_id ||'. Detalle: '||SQLERRM;
        RETURN;
    END;

    debug(C_PACKAGE_NAME, C_API_NAME|| ' Peso liquidado por Unica/Ajuste Unico: ' || NVL(l_peso_subtotal,0));

    x_peso := l_peso_aplicado - NVL(l_peso_subtotal,0);

    debug(C_PACKAGE_NAME, C_API_NAME|| ' Retorno (l_peso_aplicado - l_peso_temp): '||l_peso_aplicado
          ||' - '||NVL(l_peso_subtotal,0) || '='|| x_peso);

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_errmsg := 'Error obteniendo peso disponible para el Certificado '||p_certificado_id
                  ||' - Detalle: '|| SQLERRM;
      debug(C_PACKAGE_NAME, C_API_NAME||' ' || x_errmsg);

  END Get_Peso_Disponible;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Peso_Disponible                                            *
 * Purpose : Rutina que retorna el peso disponible del 1116A para           *
 *           transferencias o retiros y tiene en cuenta las liquidaciones   *
 *           1116B Liquidadas.                                              *
 *                                                                          *
 ****************************************************************************/
  FUNCTION Get_Peso_Disponible ( p_certificado_id         IN NUMBER
                               , p_liquidacion_id         IN NUMBER DEFAULT NULL
                               , p_lock_flag              IN BOOLEAN DEFAULT FALSE
                              )
  RETURN NUMBER
  IS

    C_API_NAME  VARCHAR2(300) := 'Fcion Get_Peso_Disponible';
    l_peso      NUMBER;
    l_result    BOOLEAN;
    l_errmsg    VARCHAR2(3000);


  BEGIN

    Get_Peso_Disponible ( p_certificado_id    => p_certificado_id
                        , p_liquidacion_id    => p_liquidacion_id
                        , x_peso              => l_peso
                        , x_result            => l_result
                        , x_errmsg            => l_errmsg);

    IF (l_result) THEN

     RETURN l_peso;

    ELSE

      debug(C_API_NAME, l_errmsg);
      RETURN NULL;
    END IF;


  EXCEPTION
    WHEN OTHERS THEN
      debug(C_API_NAME, 'Fcion  Get_Peso_Disponible - Error: '||SQLERRM);

  END Get_Peso_Disponible;



 /***************************************************************************
 * Name    : Eliminar_Servicios                                             *
 * Purpose : Elimina las lineas de servicios del Certificado                *
 *                                                                          *
 ***************************************************************************/
  PROCEDURE Eliminar_Servicios ( p_liquidacion_id  IN NUMBER
                               , p_error_msg      OUT VARCHAR2)
  IS

    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DELETE FROM XX_TCG_LIQUIDACION_1116A_LINES
          WHERE liquidacion_id = p_liquidacion_id;

    COMMIT;

  EXCEPTION
    WHEN others THEN
      p_error_msg := 'Error en Eliminar Servicios: '||SQLERRM;

  END Eliminar_servicios;



END XX_TCG_LIQUIDACION_1116A_PKG;
/

exit
