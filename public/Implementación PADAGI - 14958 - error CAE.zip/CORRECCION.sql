UPDATE xxw_fac_tmp 
SET fecha_vto_cae =to_date ('20191219','yyyymmdd')
, CAE = '69512803281900'
, FEX_ERROR_MSG = NULL
, FEX_EV_ERROR_MSG = NULL
, FEX_EV_ERROR_CODE = NULL
, RESULTADO = 'P'
WHERE ID = 13502207;
--1 Registro