  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OM_CREDIT_EXP_REPORT_PKG" AS

PROCEDURE main_process (retcode               OUT NUMBER
                       ,errbuf                OUT VARCHAR2
                       ,p_summary              IN VARCHAR2
                       ,p_customer_prof        IN NUMBER
                       ,p_customer_name_from   IN VARCHAR2
                       ,p_customer_name_to     IN VARCHAR2
                       ,p_customer_number_from IN VARCHAR2
                       ,p_customer_number_to   IN VARCHAR2
                       ,p_customer_canal       IN VARCHAR2
                       ,p_org_id               IN NUMBER);

FUNCTION trae_location (p_address_id  IN hz_cust_acct_sites_all.cust_acct_site_id%type,
                        pc_cust       IN hz_cust_acct_sites_all.cust_account_id%type,
                        pc_org        IN jl_zz_ar_tx_cus_cls_all.org_id%TYPE ) RETURN VARCHAR2;

END; 
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OM_CREDIT_EXP_REPORT_PKG" AS

PROCEDURE print_output (p_message IN VARCHAR2) IS
BEGIN
   fnd_file.put_line(fnd_file.output,p_message);
END;

PROCEDURE print_log (p_message IN VARCHAR2) IS
BEGIN
   fnd_file.put_line(fnd_file.log,p_message);
END;

FUNCTION trae_location ( p_address_id  IN hz_cust_acct_sites_all.cust_acct_site_id%type,
                         pc_cust       IN hz_cust_acct_sites_all.cust_account_id%type,
                         pc_org        IN jl_zz_ar_tx_cus_cls_all.org_id%TYPE ) RETURN VARCHAR2
    IS
    l_retorna   varchar2(200);
  BEGIN
    BEGIN
      SELECT SUBSTR(NVL (arp_addr_pkg.format_address(hl.address_style
           , hl.address1
           , hl.address2
           , hl.address3
           , hl.address4
           , hl.city
           , hl.county
           , hl.state
           , hl.province
           , hl.postal_code
           , ftv.territory_short_name ), 'N/A') ,1,199)
        INTO l_retorna
        FROM hz_locations hl,
             fnd_territories_vl  ftv,
             hz_cust_acct_sites_all hcasa,
             hz_party_sites hps
       WHERE hcasa.cust_acct_site_id  = p_address_id
         AND hl.country               = ftv.territory_code(+)
         AND hps.location_id          = hl.location_id
         AND hcasa.party_site_id      = hps.party_site_id
         AND hcasa.cust_account_id    = pc_cust
         AND hcasa.org_id             = pc_org;
    EXCEPTION
      WHEN OTHERS THEN
        l_retorna :='N/D';
    END;
    RETURN SUBSTR(l_retorna,1,199);
  END;

PROCEDURE show_data (p_status              OUT VARCHAR2
                    ,p_error_message       OUT VARCHAR2
                    ,p_summary              IN VARCHAR2
                    ,p_customer_prof        IN NUMBER
                    ,p_customer_name_from   IN VARCHAR2
                    ,p_customer_name_to     IN VARCHAR2
                    ,p_customer_number_from IN VARCHAR2
                    ,p_customer_number_to   IN VARCHAR2
                    ,p_customer_canal       IN VARCHAR2
                    ,p_org_id               IN NUMBER) IS

e_cust_exception EXCEPTION;

CURSOR c_cust IS
SELECT
  hca.cust_account_id customer_id
 ,XX_UTIL_PK.xml_escape_chars(hp.party_name) Customer
FROM
  hz_customer_profiles hcp
, hz_cust_profile_classes hcpc
, hz_cust_profile_amts hcpa
, hz_cust_accounts hca
, hz_parties hp
, hz_cust_acct_sites_all hcas
, hz_cust_site_uses_all hcsu
, hr_operating_units hou
, fnd_lookup_values_vl flv
WHERE hcp.cust_account_profile_id=hcpa.cust_account_profile_id
  AND hcpc.profile_class_id = hcp.profile_class_id
  AND hcp.site_use_id = hcsu.site_use_id
  AND hcp.cust_account_id=hca.cust_account_id
  and hcas.cust_account_id = hca.cust_account_id
  and hcas.cust_acct_site_id = hcsu.cust_Acct_site_id
  and hcsu.org_id = hou.organization_id
  and hcsu.site_use_code = flv.lookup_code
  and flv.lookup_type = 'SITE_USE_CODE'
  AND hcp.STATUS='A'
  AND hca.status='A'
  and hcp.credit_checking ='Y'
  AND hca.party_id = hp.party_id
  AND hp.party_id= hcp.party_id
  AND XX_JG_ZZ_SHARED_PKG.get_country(hcas.org_id) = 'AR'--Solo compa�ias de Argentina
  AND hcpc.profile_class_id = NVL(p_customer_prof,hcpc.profile_class_id) /*P_CUSTOMER_PROF*/
  AND hp.party_name >= NVL(p_customer_name_from,hp.party_name) /*P_CUSTOMER_NAME_FROM*/
  AND hp.party_name <= NVL(p_customer_name_to,hp.party_name) /*P_CUSTOMER_NAME_TO*/
  and hca.account_number >= NVL(p_customer_number_from,hca.account_number) /*P_CUSTOMER_NUMBER_FROM*/
  and hca.account_number <= NVL(p_customer_number_to,hca.account_number) /*P_CUSTOMER_NUMBER_TO*/
  and NVL(hca.sales_channel_code,'*') = NVL(p_customer_canal,NVL(hca.sales_channel_code,'*')) /*P_CUSTOMER_CANAL*/
  and hcas.org_id = NVL(p_org_id,hcas.org_id) /*P_ORG_ID*/
  GROUP BY hca.cust_account_id,hp.party_name
UNION ALL
SELECT hca.cust_account_id customer_id
,XX_UTIL_PK.xml_escape_chars(hp.party_name) Customer
FROM
  hz_customer_profiles hcp
, hz_cust_profile_classes hcpc
, hz_cust_profile_amts hcpa
, hz_cust_accounts hca
, hz_parties hp
WHERE hcp.cust_account_profile_id=hcpa.cust_account_profile_id
  AND hcpc.profile_class_id = hcp.profile_class_id
  AND hcp.site_use_id IS NULL
  AND hcp.cust_account_id = hca.cust_account_id
  AND hcp.STATUS='A' --14699527
  AND hca.status='A'
  AND hca.party_id = hp.party_id
  AND hp.party_id= hcp.party_id
  AND EXISTS (select 1 
                from hz_cust_acct_sites_all hcas
                where hcas.cust_account_id = hca.cust_account_id
                  AND XX_JG_ZZ_SHARED_PKG.get_country(hcas.org_id) = 'AR')--Tengan domicilio en Argentina 
  AND not exists (select 1 
                    from hz_customer_profiles hcp2 
                   where 1  = 1
                     AND hcp2.cust_account_id = hca.cust_account_id
                     AND hcp2.STATUS='A' --14699527
                     and hcp2.credit_checking ='Y'
                     and hcp2.site_use_id is not null)
  AND hcpc.profile_class_id = NVL(p_customer_prof,hcpc.profile_class_id) /*P_CUSTOMER_PROF*/
  AND hp.party_name >= NVL(p_customer_name_from,hp.party_name) /*P_CUSTOMER_NAME_FROM*/
  AND hp.party_name <= NVL(p_customer_name_to,hp.party_name) /*P_CUSTOMER_NAME_TO*/
  and hca.account_number >= NVL(p_customer_number_from,hca.account_number) /*P_CUSTOMER_NUMBER_FROM*/
  and hca.account_number <= NVL(p_customer_number_to,hca.account_number) /*P_CUSTOMER_NUMBER_TO*/
  and NVL(hca.sales_channel_code,'*') = NVL(p_customer_canal,NVL(hca.sales_channel_code,'*')) /*P_CUSTOMER_CANAL*/
  and ((p_org_id is not null /*P_ORG_ID*/ 
       and exists (select 1 
                     from hz_cust_acct_sites_all hcas 
                    where hca.cust_account_id = hcas.cust_account_id 
                      and hcas.org_id = p_org_id))
      OR p_org_id IS NULL)
  GROUP BY hca.cust_account_id,hp.party_name
order by 1;
                    
CURSOR c_data (p_customer_id NUMBER) IS
SELECT
  hca.cust_account_id customer_id
, hcsu.site_use_id
, hca.account_number customer_number
, XX_UTIL_PK.xml_escape_chars(SUBSTRB(hp.party_name,1,50) ||'('||hca.account_number||')') Customer
, flv.meaning site_use
, XX_OM_CREDIT_EXP_REPORT_PKG.trae_location(hcas.cust_acct_site_id,hca.cust_account_id,hcas.org_id) address
, hou.name org_name
, hcpa.overall_credit_limit party_overall_limit
, NVL((select SUM(acctd_amount_due_remaining)
  from ar_payment_schedules_all aps
      ,ra_customer_trx_all rcta
  where aps.org_id = hcsu.org_id
  and rcta.customer_trx_id = aps.customer_trx_id
  and aps.amount_due_remaining != 0
  and NVL( receipt_confirmed_flag, 'Y' )  =  'Y'
  and aps.customer_id = hca.cust_account_id
  and aps.customer_site_use_id = hcsu.site_use_id),0) Transactions 
, NVL((select SUM(acctd_amount_due_remaining)
  from ar_payment_schedules_all aps
      ,ar_cash_receipts_all acra
  where aps.org_id = hcsu.org_id
  and acra.cash_Receipt_id = aps.cash_receipt_id
  and aps.amount_due_remaining != 0
  and NVL(receipt_confirmed_flag,'Y') =  'Y'
  and aps.customer_id = hca.cust_account_id
  and aps.customer_site_use_id = hcsu.site_use_id),0) Receipts
, NVL((select SUM(((oola.ordered_quantity*oola.unit_selling_price) + tax_value)*NVL(ooha.conversion_rate,1))
  from oe_order_headers_all ooha
  ,oe_order_lines_all oola
  where 1 = 1
  and ooha.sold_to_org_id = hca.cust_account_id
  and ooha.invoice_to_org_id = hcsu.site_use_id
  and ooha.header_id = oola.headeR_id
  and NVL(oola.cancelled_flag,'N') = 'N'
  and NVL(ooha.cancelled_flag,'N') = 'N'
  and NVL(ooha.open_flag,'N') = 'Y'
  and NVL(oola.open_flag,'N') = 'Y'
  and exists (select 1 
                from oe_order_holds_all ooho
               where ooha.header_id = ooho.header_id
                 and hold_release_id is null)),0) Order_holds
, NVL((select SUM(((oola.ordered_quantity*oola.unit_selling_price) + tax_value)*NVL(ooha.conversion_rate,1))
  from oe_order_headers_all ooha
  ,oe_order_lines_all oola
  where 1 = 1
  and ooha.sold_to_org_id = hca.cust_account_id
  and ooha.invoice_to_org_id = hcsu.site_use_id
  and ooha.header_id = oola.headeR_id
  and NVL(oola.cancelled_flag,'N') = 'N'
  and NVL(ooha.cancelled_flag,'N') = 'N'
  and NVL(ooha.open_flag,'N') = 'Y'
  and NVL(oola.open_flag,'N') = 'Y'
  and not exists (select 1 
                from oe_order_holds_all ooho
               where ooha.header_id = ooho.header_id
                 and hold_release_id is null)),0) Order_Rel
FROM
  hz_customer_profiles hcp
, hz_cust_profile_classes hcpc
, hz_cust_profile_amts hcpa
, hz_cust_accounts hca
, hz_parties hp
, hz_cust_acct_sites_all hcas
, hz_cust_site_uses_all hcsu
, hr_operating_units hou
, fnd_lookup_values_vl flv
WHERE hcp.cust_account_profile_id=hcpa.cust_account_profile_id
  AND hcpc.profile_class_id = hcp.profile_class_id
  AND hcp.site_use_id = hcsu.site_use_id
  AND hcp.cust_account_id=hca.cust_account_id
  and hcas.cust_account_id = hca.cust_account_id
  and hcas.cust_acct_site_id = hcsu.cust_Acct_site_id
  and hcsu.org_id = hou.organization_id
  and hcsu.site_use_code = flv.lookup_code
  and flv.lookup_type = 'SITE_USE_CODE'
  AND hcp.STATUS='A' --14699527
  AND hca.status='A'
  and hcp.credit_checking ='Y'
  AND hca.party_id = hp.party_id
  AND hp.party_id= hcp.party_id
  AND hca.cust_account_id = p_customer_id
  and hcas.org_id = NVL(p_org_id,hcas.org_id) /*P_ORG_ID*/
  and NVL(hcpa.overall_credit_limit,0) != 0
UNION ALL
SELECT hca.cust_account_id customer_id
, null
, hca.account_number customer_number
, XX_UTIL_PK.xml_escape_chars(SUBSTRB(hp.party_name,1,50) ||'('||hca.account_number||')') Customer
, null
, NULL
, null
, hcpa.overall_credit_limit party_overall_limit
, NVL((select ROUND(SUM(acctd_amount_due_remaining),2)
  from ar_payment_schedules_all aps
      ,ra_customer_trx_all rcta
  where rcta.customer_trx_id = aps.customer_trx_id
  and amount_due_remaining != 0
  and rcta.bill_to_customer_id = hca.cust_account_id),0) Transactions
, NVL((select ROUND(SUM(acra.amount*NVL(acra.exchange_rate,1)),2)
  from ar_cash_receipts_all acra
  ,ar_cash_Receipt_history_all acrha
  where acra.pay_from_customer = hca.cust_account_id
  and acra.cash_receipt_id = acrha.cash_receipt_id
  and acrha.current_record_flag = 'Y'
  and acrha.status != 'CLEARED'),0) Receipts  
, NVL((select ROUND(SUM(((oola.ordered_quantity*oola.unit_selling_price) + tax_value)*NVL(ooha.conversion_rate,1)),2)
  from oe_order_headers_all ooha
  ,oe_order_lines_all oola
  where 1 = 1
  and ooha.sold_to_org_id = hca.cust_account_id
  and ooha.header_id = oola.headeR_id
  and NVL(oola.cancelled_flag,'N') = 'N'
  and NVL(ooha.cancelled_flag,'N') = 'N'
  and NVL(ooha.open_flag,'N') = 'Y'
  and NVL(oola.open_flag,'N') = 'Y'
  and exists (select 1 
                from oe_order_holds_all ooho
               where ooha.header_id = ooho.header_id
                 and hold_release_id is null)),0) Order_holds
, NVL((select ROUND(SUM(((oola.ordered_quantity*oola.unit_selling_price) + tax_value)*NVL(ooha.conversion_rate,1)),2)
  from oe_order_headers_all ooha
  ,oe_order_lines_all oola
  where 1 = 1
  and ooha.sold_to_org_id = hca.cust_account_id
  and ooha.header_id = oola.headeR_id
  and NVL(oola.cancelled_flag,'N') = 'N'
  and NVL(ooha.cancelled_flag,'N') = 'N'
  and NVL(ooha.open_flag,'N') = 'Y'
  and NVL(oola.open_flag,'N') = 'Y'
  and not exists (select 1 
                from oe_order_holds_all ooho
               where ooha.header_id = ooho.header_id
                 and hold_release_id is null)),0) Order_Released
FROM
  hz_customer_profiles hcp
, hz_cust_profile_classes hcpc
, hz_cust_profile_amts hcpa
, hz_cust_accounts hca
, hz_parties hp
WHERE hcp.cust_account_profile_id=hcpa.cust_account_profile_id
  AND hcpc.profile_class_id = hcp.profile_class_id
  AND hcp.site_use_id IS NULL
  AND hcp.cust_account_id = hca.cust_account_id
  AND hcp.STATUS='A' --14699527
  AND hca.status='A'
  and NVL(hcpa.overall_credit_limit,0) != 0
  AND hca.party_id = hp.party_id
  AND hp.party_id= hcp.party_id
  AND not exists (select 1 
                    from hz_customer_profiles hcp2 
                   where 1  = 1
                     AND hcp2.cust_account_id = hca.cust_account_id
                     AND hcp2.STATUS='A' --14699527
                     and hcp2.credit_checking ='Y'
                     and hcp2.site_use_id is not null)
  AND hca.cust_account_id = p_customer_id
  and ((p_org_id is not null /*P_ORG_ID*/ 
       and exists (select 1 
                     from hz_cust_acct_sites_all hcas 
                    where hca.cust_account_id = hcas.cust_account_id 
                      and hcas.org_id = p_org_id))
      OR p_org_id IS NULL)
order by 4,7,6;

v_expo NUMBER;
v_dif_expo NUMBER;
v_tot_limit NUMBER;
v_tot_transactions NUMBER;
v_tot_receipts NUMBER;
v_tot_order_hold NUMBER;
v_tot_order_rel NUMBER;
v_tot_expo NUMBER;
v_tot_dif_expo NUMBER;

v_gral_tot_limit NUMBER;
v_gral_tot_transactions NUMBER;
v_gral_tot_receipts NUMBER;
v_gral_tot_order_hold NUMBER;
v_gral_tot_order_rel NUMBER;
v_gral_tot_expo NUMBER;
v_gral_tot_dif_expo NUMBER;
         
BEGIN

    print_log('XX_OM_CREDIT_EXP_REPORT_PKG.SHOW_DATA (+)');
    
    print_output( '  <LIST_G_DATA>');
    
    print_log('Seteando Valores Gral en 0');
    
    v_gral_tot_limit := 0;
    v_gral_tot_transactions := 0;
    v_gral_tot_receipts := 0;
    v_gral_tot_order_hold := 0;
    v_gral_tot_order_rel := 0;
    v_gral_tot_expo := 0;
    v_gral_tot_dif_expo := 0;
    
    print_log('Fin Seteando Valores Gral en 0');
    
    FOR r_cust IN c_cust LOOP
    
        print_log('Cliente: '||r_cust.customer);
    
        v_tot_limit := 0;
        v_tot_transactions := 0;
        v_tot_receipts := 0;
        v_tot_order_hold := 0;
        v_tot_order_rel := 0;
        v_tot_expo := 0;
        v_tot_dif_expo := 0;
    
        FOR r_data in c_data (r_cust.customer_id) loop
        
            print_log('Direccion: '||r_data.site_use);
        
            v_expo := 0;
            
            print_log('Sumarizando valores');
            
            v_tot_limit := v_tot_limit + NVL(r_data.party_overall_limit,0);
            v_expo := v_expo + NVL(r_data.transactions,0);
            v_tot_transactions := v_tot_transactions + NVL(r_data.transactions,0);
            v_expo := v_expo + NVL(r_data.receipts,0);
            v_tot_receipts:= v_tot_receipts + NVL(r_data.receipts,0);
            v_expo := v_expo + NVL(r_data.order_holds,0);
            v_tot_order_hold := v_tot_order_hold + NVL(r_data.order_holds,0);
            v_expo := v_expo + NVL(r_data.order_rel,0);
            v_tot_order_rel := v_tot_order_rel + NVL(r_data.order_rel,0);
            v_tot_expo := v_tot_expo + v_expo;
            v_dif_expo := r_data.party_overall_limit - v_expo;
            v_tot_dif_expo := v_tot_dif_expo + v_dif_expo; 
            
            IF p_summary = 'N' THEN 
            
                print_log('Generando Output');
            
                print_output( '    <G_DATA>');
                
                --cliente
                print_output( '      <CUSTOMER_NAME>'||r_data.Customer||'</CUSTOMER_NAME>');
                --proposito de uso
                print_output( '      <SITE_USE>'||r_data.site_use||'</SITE_USE>');
                --direccion
                print_output( '      <ADDRESS>'||r_data.address||'</ADDRESS>');
                --compa�ia
                print_output( '      <ORG_NAME>'||r_data.org_name||'</ORG_NAME>');
                --limite
                print_output( '      <PARTY_OVERALL_LIMIT>'||XX_UTIL_PK.xml_num_display(r_data.party_overall_limit)||'</PARTY_OVERALL_LIMIT>');
                --facturas
                print_output( '      <TRANSACTIONS>'||XX_UTIL_PK.xml_num_display(r_data.transactions)||'</TRANSACTIONS>');
                --recibos_pedientes
                print_output( '      <RECEIPTS>'||XX_UTIL_PK.xml_num_display(r_data.receipts)||'</RECEIPTS>');
                --pedidos_holdeados
                print_output( '      <ORDER_HOLDS>'||XX_UTIL_PK.xml_num_display(r_data.order_holds)||'</ORDER_HOLDS>');
                --pedidos_liberados
                print_output( '      <ORDER_REL>'||XX_UTIL_PK.xml_num_display(r_data.order_rel)||'</ORDER_REL>');
                --total_exposicion
                print_output( '      <EXPO>'||XX_UTIL_PK.xml_num_display(v_expo)||'</EXPO>');
                --disponible
                print_output( '      <DIF_EXPO>'||XX_UTIL_PK.xml_num_display(v_dif_expo)||'</DIF_EXPO>');
                
                print_output( '    </G_DATA>');
            
            END IF;
        
        END LOOP;
        
        print_output( '    <G_TOT_CUST>');
                
        --cliente
        print_output( '      <CUSTOMER_NAME>'||r_cust.Customer||'</CUSTOMER_NAME>');
        --limite
        print_output( '      <PARTY_OVERALL_LIMIT>'||XX_UTIL_PK.xml_num_display(v_tot_limit)||'</PARTY_OVERALL_LIMIT>');
        --facturas
        print_output( '      <TRANSACTIONS>'||XX_UTIL_PK.xml_num_display(v_tot_transactions)||'</TRANSACTIONS>');
        --recibos_pedientes
        print_output( '      <RECEIPTS>'||XX_UTIL_PK.xml_num_display(v_tot_receipts)||'</RECEIPTS>');
        --pedidos_holdeados
        print_output( '      <ORDER_HOLDS>'||XX_UTIL_PK.xml_num_display(v_tot_order_hold)||'</ORDER_HOLDS>');
        --pedidos_liberados
        print_output( '      <ORDER_REL>'||XX_UTIL_PK.xml_num_display(v_tot_order_rel)||'</ORDER_REL>');
        --total_exposicion
        print_output( '      <EXPO>'||XX_UTIL_PK.xml_num_display(v_tot_expo)||'</EXPO>');
        --disponible
        print_output( '      <DIF_EXPO>'||XX_UTIL_PK.xml_num_display(v_tot_dif_expo)||'</DIF_EXPO>');
                
        print_output( '    </G_TOT_CUST>');
        
        v_gral_tot_limit := v_gral_tot_limit + v_tot_limit;
        v_gral_tot_transactions := v_gral_tot_transactions + v_tot_transactions;
        v_gral_tot_receipts := v_gral_tot_receipts + v_tot_receipts;
        v_gral_tot_order_hold := v_gral_tot_order_hold + v_tot_order_hold;
        v_gral_tot_order_rel := v_gral_tot_order_rel + v_tot_order_rel;
        v_gral_tot_expo := v_gral_tot_expo + v_tot_expo;
        v_gral_tot_dif_expo := v_gral_tot_dif_expo + v_tot_dif_expo;
    
    END LOOP;
    
    print_output( '    <G_TOT>');
    --limite
    print_output( '      <PARTY_OVERALL_LIMIT>'||XX_UTIL_PK.xml_num_display(v_gral_tot_limit)||'</PARTY_OVERALL_LIMIT>');
    --facturas
    print_output( '      <TRANSACTIONS>'||XX_UTIL_PK.xml_num_display(v_gral_tot_transactions)||'</TRANSACTIONS>');
    --recibos_pedientes
    print_output( '      <RECEIPTS>'||XX_UTIL_PK.xml_num_display(v_gral_tot_receipts)||'</RECEIPTS>');
    --pedidos_holdeados
    print_output( '      <ORDER_HOLDS>'||XX_UTIL_PK.xml_num_display(v_gral_tot_order_hold)||'</ORDER_HOLDS>');
    --pedidos_liberados
    print_output( '      <ORDER_REL>'||XX_UTIL_PK.xml_num_display(v_gral_tot_order_rel)||'</ORDER_REL>');
    --total_exposicion
    print_output( '      <EXPO>'||XX_UTIL_PK.xml_num_display(v_gral_tot_expo)||'</EXPO>');
    --disponible
    print_output( '      <DIF_EXPO>'||XX_UTIL_PK.xml_num_display(v_gral_tot_dif_expo)||'</DIF_EXPO>');
                
    print_output( '    </G_TOT>');
    
    print_output( '  </LIST_G_DATA>');
    
    print_log('XX_OM_CREDIT_EXP_REPORT_PKG.SHOW_DATA (+)');

EXCEPTION 
 WHEN e_cust_exception THEN
   p_status := 'W';
   print_log('XX_OM_CREDIT_EXP_REPORT_PKG.SHOW_DATA (+)'); 
 WHEN OTHERS THEN 
   p_status := 'W';
   p_error_message := 'Error OTHERS en SHOW_DATA. Error: '||SQLERRM;
   print_log(p_error_message);
   print_log('XX_OM_CREDIT_EXP_REPORT_PKG.SHOW_DATA (+)');
END;

PROCEDURE main_process (retcode               OUT NUMBER
                       ,errbuf                OUT VARCHAR2
                       ,p_summary              IN VARCHAR2
                       ,p_customer_prof        IN NUMBER
                       ,p_customer_name_from   IN VARCHAR2
                       ,p_customer_name_to     IN VARCHAR2
                       ,p_customer_number_from IN VARCHAR2
                       ,p_customer_number_to   IN VARCHAR2
                       ,p_customer_canal       IN VARCHAR2
                       ,p_org_id               IN NUMBER) IS

v_status        VARCHAR2(1);
v_error_message VARCHAR2(2000);
e_cust_exception EXCEPTION;
                       
BEGIN

        print_log('XX_OM_CREDIT_EXP_REPORT_PKG.MAIN_PROCESS (+)');
        
        print_log('Parametros: ');
        print_log('- p_summary: '||p_summary);
        print_log('- p_customer_prof: '||p_customer_prof);
        print_log('- p_customer_name_from: '||p_customer_name_from);
        print_log('- p_customer_name_to: '||p_customer_name_to);
        print_log('- p_customer_number_from: '||p_customer_number_from);
        print_log('- p_customer_number_to: '||p_customer_number_to);
        print_log('- p_customer_canal: '||p_customer_canal);
        print_log('- p_org_id: '||p_org_id);

        print_output('<XXOMCRER>');
        
        show_data (p_status               => v_status
                  ,p_error_message        => v_error_message
                  ,p_summary              => p_summary
                  ,p_customer_prof        => p_customer_prof
                  ,p_customer_name_from   => p_customer_name_from
                  ,p_customer_name_to     => p_customer_name_to
                  ,p_customer_number_from => p_customer_number_from
                  ,p_customer_number_to   => p_customer_number_to
                  ,p_customer_canal       => p_customer_canal
                  ,p_org_id               => p_org_id);
                  
        IF v_status != 'S' THEN 
          RAISE e_cust_exception;
        END IF;
        
        print_output('</XXOMCRER>');
        
        print_log('XX_OM_CREDIT_EXP_REPORT_PKG.MAIN_PROCESS (-)');
    
EXCEPTION
 WHEN e_cust_exception THEN 
   retcode := 1;
   errbuf := v_error_message;
   print_log(errbuf);
   print_log('XX_OM_CREDIT_EXP_REPORT_PKG.MAIN_PROCESS (!)');
   IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
      print_log('Error Seteando Estado De Finalizacion');
   ELSE
      print_log('Estado de finalizacion seteado');
   END IF;
 WHEN OTHERS THEN
   retcode := 2;
   errbuf := 'Error OTHERS en MAIN_PROCESS. Error: '||SQLERRM;
   print_log(errbuf);
   print_log('XX_OM_CREDIT_EXP_REPORT_PKG.MAIN_PROCESS (!)'); 
END;
                       
END; 
/

exit
