  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OPM_PLANILLA_OPER_R12" AS
   PROCEDURE principal( errbuf                     OUT      VARCHAR2
                      , retcode                    OUT      NUMBER
                      , p_org_id                   IN       NUMBER
                      , p_organization_id          IN       NUMBER
                      , p_calendar_code            IN       VARCHAR2
                      , p_project_id               IN       NUMBER
                      , p_top_task                 IN       VARCHAR2
                      , p_top_task_to              IN       VARCHAR2
                      , p_date_from                IN       VARCHAR2
                      , p_date_to                  IN       VARCHAR2
                      , p_flabor_from              IN       VARCHAR2
                      , p_flabor_to                IN       VARCHAR2
                      , p_fcert_from               IN       VARCHAR2
                      , p_fcert_to                 IN       VARCHAR2
                     );

END xx_opm_planilla_oper_r12;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OPM_PLANILLA_OPER_R12" AS
   g_debug   BOOLEAN := TRUE;

   PROCEDURE print_output (p_message  IN VARCHAR2) IS
   BEGIN
      IF fnd_global.conc_request_id = -1
      THEN
         DBMS_OUTPUT.put_line (p_message);
      ELSE
         fnd_file.put_line (fnd_file.output, p_message);
      END IF;
   END print_output;



   PROCEDURE principal ( errbuf                     OUT      VARCHAR2
                       , retcode                    OUT      NUMBER
                       , p_org_id                   IN       NUMBER
                       , p_organization_id          IN       NUMBER
                       , p_calendar_code            IN       VARCHAR2
                       , p_project_id               IN       NUMBER
                       , p_top_task                 IN       VARCHAR2
                       , p_top_task_to              IN       VARCHAR2
                       , p_date_from                IN       VARCHAR2
                       , p_date_to                  IN       VARCHAR2
                       , p_flabor_from              IN       VARCHAR2
                       , p_flabor_to                IN       VARCHAR2
                       , p_fcert_from               IN       VARCHAR2
                       , p_fcert_to                 IN       VARCHAR2
                       ) IS
      g_date_from    DATE := fnd_date.canonical_to_date (p_date_from);
      g_date_to      DATE := fnd_date.canonical_to_date (p_date_to);
      --SD1721
      g_flabor_from  DATE := fnd_date.canonical_to_date (p_flabor_from);
      g_flabor_to    DATE := fnd_date.canonical_to_date (p_flabor_to);
      g_fcert_from   DATE := fnd_date.canonical_to_date (p_fcert_from);
      g_fcert_to     DATE := fnd_date.canonical_to_date (p_fcert_to);

      -----------
      -- Cursores
      -----------
      CURSOR c_data IS
         SELECT   origen
                , ou_name
                , organization_name
                --    ,ship_to_location_id
                --    ,subinventory_code
                --    ,attribute3
                , zona
                , propiedad
                , CASE
                    WHEN tipo_propiedad_pa = 'ALQUILADOS'
                      THEN establecimiento_alquilado
                      ELSE organization_name
                  END establecimiento_alquilado
                , xx_lote
                , cultivo_principal
                , project_type
                --    ,project_id
                , project_number
                , project_name
                , task_number
                --    ,task_name
                , description
                , expenditure_type
                , cuenta_contable
                , item_code
                , item_description
                , fecha_salida
                , xx_opm_superficie
                , dosis
                , um
                , q_total
                , xx_opm_fecha_aplicacion
                , xx_opm_vale_consumo
                , xx_opm_ot
                , xx_opm_oc
                , transaction_id
                , transaction_type_name
                , recepcion
                , nro_proveedor
                , nombre_proveedor
                , factura
                , pagado
                , CASE
                     WHEN origen IN ('INV', 'RCV')
                        THEN costo
                     ELSE NULL
                  END costo
                , CASE
                    WHEN origen IN ('RCV')  AND transaction_type_name IN ('Recepción PO', 'Devolución PO')
                     THEN  ROUND ((costo * q_total), 2) *(-1)

                     WHEN origen IN ('INV', 'RCV')
                        THEN ROUND ((costo * q_total), 2)
                     ELSE costo
                  END costo_total
                , CASE
                     WHEN origen IN ('INV', 'RCV')
                        THEN ROUND (costo * tc, 2)
                     ELSE NULL
                  END costo_usd
                , CASE
                    WHEN origen IN ('RCV')  AND transaction_type_name IN ('Recepción PO', 'Devolución PO')
                        THEN ROUND ((costo * q_total) * tc, 2) * (-1)
                     WHEN origen IN ('INV', 'RCV')
                        THEN ROUND ((costo * q_total) * tc, 2)
                     ELSE ROUND (costo * tc, 2)
                  END costo_total_usd
                , fecha_tc
                , tc tc                                             -- amanukyan 20180129 El TC se redondea al final ...
                , observaciones
                , last_update_date
                , user_name
                , status_pa
                , lote_erogaciones
                , comentario_erogaciones
                , tipo_propiedad_pa
                , zona_pa
                , fecha_labor
                , fecha_certificacion
             FROM (/* Origen: INV */
                   SELECT 'INV' origen
                        , hou.NAME ou_name
                        , ood.organization_name
                        , mmt.ship_to_location_id
                        , mmt.subinventory_code
                        , msei.attribute3
                        , establ.zona_descripcion zona
--                         CASE
--                             WHEN mmt.ship_to_location_id IS NOT NULL
--                                THEN (SELECT zona
--                                        FROM xx_opm_establecimientos
--                                       WHERE location_id = mmt.ship_to_location_id)
--                             ELSE (SELECT zona
--                                     FROM xx_opm_establecimientos
--                                    WHERE establecimiento_id = mseix.xx_tcg_establecimientos)
--                          END zona
                        , DECODE (establ.propio
                                           -- amanukyan 20180130 issue 127 las zonas subzonas y establecimiento saca mal
                                 , 'Y', 'PROPIO'
                                 , 'NO PROPIO'
                                 ) propiedad
                        -- , msei.description establecimiento_alquilado     -- 20180129 amanukyan issue 127
                        , establ.campo establecimiento_alquilado                         -- 20180130 amanukyan issue 127
                        , mmtx.xx_lote
                        , ptt.task_number cultivo_principal
                        , pp.project_type
                        , pp.project_id
                        , pp.segment1 project_number
                        , pp.NAME project_name
                        , pt.task_number
                        , pt.task_name
                        , pt.description
                        , mmt.expenditure_type
                        , gcc.concatenated_segments cuenta_contable
                        , msi.segment1 item_code
                        , msi.description item_description
                        , mmt.transaction_date fecha_salida
                        , mmtx.xx_opm_superficie
                       ---- , (mmt.transaction_quantity / mmtx.xx_opm_superficie) dosis  -- SL, 13/09/18, si la sup es 0 falla
                        , (mmt.transaction_quantity / decode(mmtx.xx_opm_superficie,0,null)) dosis --aca--
                        , mmt.transaction_uom um
                        , mmt.transaction_quantity q_total
                        , mmtx.xx_opm_fecha_aplicacion
                        , mmtx.xx_opm_vale_consumo
                        , mmtx.xx_opm_ot
                        , mmtx.xx_opm_oc
                        , mmt.transaction_id
                        , mtt.transaction_type_name
                        , NULL recepcion
                        , NULL nro_proveedor
                        , NULL nombre_proveedor
                        , NULL factura
                        , NULL pagado
                        , (SELECT SUM (cmpnt_cost) COST
                             FROM cm_cmpt_dtl cc
                                , gmf_period_statuses per
                            WHERE cc.inventory_item_id = mmt.inventory_item_id
                              AND cc.organization_id =        -- Busca el costo en la org de costos asociada, o la misma
                                     NVL ((SELECT cost_organization_id
                                             FROM cm_whse_asc
                                            WHERE organization_id = mmt.organization_id
                                              AND SYSDATE BETWEEN eff_start_date AND eff_end_date
                                              AND delete_mark = 0)
                                        , mmt.organization_id)
                              AND cc.period_id = per.period_id
                              AND per.calendar_code = p_calendar_code
                              AND mmt.transaction_date BETWEEN per.start_date AND per.end_date
                              AND cc.cost_type_id = ply.cost_type_id
                              AND cc.delete_mark = 0) costo
                        , mmt.transaction_reference observaciones
                        , mmt.last_update_date
                        , fu.user_name
                        , NVL ((SELECT DISTINCT meaning
                                           FROM pa_transaction_interface_all pai
                                              , fnd_lookup_values_vl flv
                                          WHERE transaction_source = 'Process Inventory Misc'
                                            AND pai.orig_transaction_reference = mmt.transaction_id
                                            AND flv.lookup_type = 'TRANSACTION STATUS'
                                            AND flv.lookup_code = pai.transaction_status_code)
                             , 'Sin Interfaz') status_pa                                        -- amanukyan 20180117
                        , NULL lote_erogaciones
                        , NULL comentario_erogaciones
                        , mmt.transaction_date fecha_tc
                        , (SELECT gdr.conversion_rate
                             FROM gl_daily_rates gdr
                                , gl_daily_conversion_types ct
                                , hr_operating_units hou
                            WHERE hou.organization_id = p_org_id
                              AND gdr.conversion_type = ct.conversion_type
                              AND ct.user_conversion_type = DECODE (SUBSTR (hou.NAME
                                                                          , 1
                                                                          , 2
                                                                           )
                                                                  , 'UR', 'Promedio CONS URU'
                                                                  , 'AR', 'Promedio CONS ARG'
                                                                   )
                              AND gdr.from_currency = DECODE (SUBSTR (hou.NAME
                                                                    , 1
                                                                    , 2
                                                                     )
                                                            , 'UR', 'UYU'
                                                            , 'AR', 'ARS'
                                                             )
                              AND gdr.to_currency = 'USD'
                              AND conversion_date = TRUNC (LAST_DAY (mmt.transaction_date))) tc
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE project_id = pp.project_id
                              AND class_category = 'TIPO DE PROPIEDAD') tipo_propiedad_pa
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE project_id = pp.project_id
                              AND class_category = 'ZONA DEL PAIS') zona_pa
                        , null fecha_labor -- DECODE(mmt.reason_id, 1910, mmtx.xx_opm_fecha_aplicacion, NULL) fecha_labor --SD1721
                        , NULL fecha_certificacion
                     FROM mtl_material_transactions mmt
                        , mtl_material_transactions_dfv mmtx
                        , mtl_transaction_types mtt
                        , org_organization_definitions ood
                        , mtl_parameters par
                        , hr_operating_units hou
                        , gmf_fiscal_policies ply      -- Las org de EAM no deberian estar aca, pero hace un outer Join)
                        , mtl_secondary_inventories msei
                        , mtl_secondary_inventories_dfv mseix
                        , mtl_system_items msi
                        , gl_code_combinations_kfv gcc
                        , pa_projects_all pp                                                -- ver si hay q dejar la all
                        , pa_tasks pt
                        , pa_tasks ptt
                        , fnd_user fu
                        -- amanukyan 20180130 issue 127 las zonas subzonas y establecimiento saca mal
                        , (SELECT NVL (xzon.zona, address_zones.zona) zona
                                , NVL (xzon.zona_descripcion, address_zones.zona_desc) zona_descripcion
                                , NVL (xzon.subzona, address_zones.subzona) subzona
                                , NVL (xzon.subzona_descripcion, address_zones.subzona_desc) subzona_descripcion
                                , propio
                                , xoe.campo
                                , xoe.establecimiento_id
                                , msi.secondary_inventory_name subinventory_code
                                , msi.organization_id
                             FROM mtl_secondary_inventories msi
                                , mtl_secondary_inventories_dfv msi_df
                                , xx_opm_establecimientos xoe
                                , (SELECT flvz.lookup_code zona
                                        , flvz.meaning zona_descripcion
                                        , flvs.lookup_code subzona
                                        , flvs.meaning subzona_descripcion
                                     FROM fnd_lookup_values_vl flvs
                                        , fnd_lookup_values_dfv flvds
                                        , fnd_lookup_values_vl flvz
                                    WHERE flvs.ROWID = flvds.row_id
                                      AND flvs.lookup_type = 'XX_OPM_SUBZONA'
                                      AND flvds.CONTEXT = 'XX_OPM_SUBZONA'
                                      AND flvs.enabled_flag = 'Y'
                                      AND flvz.enabled_flag = 'Y'
                                      AND flvz.lookup_type = 'XX_OPM_ZONA'
                                      AND flvz.lookup_code = flvds.xx_opm_zona) xzon
                                , (SELECT zona
                                        , zona_desc
                                        , subzona
                                        , subzona_desc
                                        , ood.organization_id
                                        , msei.secondary_inventory_name
                                     FROM mtl_secondary_inventories msei
                                        , hr_organization_units_v ood
                                        , hr_locations hl
                                        , xx_tcg_localidades zonas
                                    WHERE ood.organization_id = msei.organization_id
                                      AND hl.location_id = NVL (msei.location_id, ood.location_id)
                                      AND hl.loc_information16 = zonas.loc_codigo) address_zones
                            WHERE msi.ROWID = msi_df.row_id
                              AND msi_df.xx_tcg_establecimientos = xoe.establecimiento_id(+)
                              AND xoe.subzona = xzon.subzona(+)
                              AND msi.organization_id = address_zones.organization_id(+)
                              AND msi.secondary_inventory_name = address_zones.secondary_inventory_name(+)) establ
                    -- amanukyan 20180130 issue 127 las zonas subzonas y establecimiento saca mal
                   WHERE  mmt.organization_id = ood.organization_id
                      AND mmt.organization_id = par.organization_id
                      AND mmt.ROWID = mmtx.row_id
                      AND mmt.transaction_type_id = mtt.transaction_type_id
                      AND ood.operating_unit = hou.organization_id
                      AND ood.legal_entity = ply.legal_entity_id(+)
                      AND mmt.organization_id = msei.organization_id
                      AND mmt.subinventory_code = msei.secondary_inventory_name
                      AND msei.ROWID = mseix.row_id
                      AND mmt.inventory_item_id = msi.inventory_item_id
                      AND mmt.organization_id = msi.organization_id
                      AND mmt.distribution_account_id = gcc.code_combination_id(+)
                      AND mmt.source_project_id = pp.project_id
                      AND mmt.source_task_id = pt.task_id
                      AND ptt.task_id = pt.top_task_id
                      AND mmt.last_updated_by = fu.user_id(+)
                      AND mmt.organization_id = establ.organization_id
                      -- amanukyan 20180130 issue 127 las zonas subzonas y establecimiento saca mal
                      AND mmt.subinventory_code = establ.subinventory_code
                       -- amanukyan 20180130 issue 127 las zonas subzonas y establecimiento saca mal
                      -- parametros
                      AND ood.organization_id IN (SELECT organization_id
                                                  FROM org_organization_definitions od1
                                                  WHERE operating_unit = p_org_id
                                                  AND EXISTS (SELECT 'X'
                                                              FROM org_access_view oav
                                                              WHERE oav.organization_id = od1.organization_id
                                                              AND oav.responsibility_id = fnd_profile.VALUE ('RESP_ID')
                                                              AND oav.resp_application_id = fnd_profile.VALUE ('RESP_APPL_ID')))
                      AND ood.operating_unit = p_org_id
                      AND (   ood.organization_id = p_organization_id
                           OR p_organization_id IS NULL)
                      AND (   mmt.source_project_id = p_project_id
                           OR p_project_id IS NULL)
                      AND (   ptt.task_number >= p_top_task
                           OR p_top_task IS NULL)
                      AND (   ptt.task_number <= p_top_task_to
                           OR p_top_task_to IS NULL)
                      AND mmt.transaction_date >= g_date_from
                      AND mmt.transaction_date < (  g_date_to + 1)
                      --SD1721
                      AND ( g_flabor_from IS NULL OR
                            TRUNC(DECODE(mmt.reason_id, 1910, mmtx.xx_opm_fecha_aplicacion, NULL)) >= TRUNC(g_flabor_from)
                          )
                      AND ( g_flabor_to IS NULL OR
                            TRUNC(DECODE(mmt.reason_id, 1910, mmtx.xx_opm_fecha_aplicacion, NULL)) <= TRUNC(g_flabor_to)
                          )
                   /* Origen: Recepciones */
                   UNION ALL
                   SELECT /*+ index(RT RCV_TRANSACTIONS_N15) */
                          'RCV' origen
                        , hou.NAME ou_name
                        , ood.organization_name
                        , NULL ship_to_location_id
                        , NULL subinventory_code
                        , NULL attribute3
                        , CASE
                             WHEN pdx.xx_id_establecimiento IS NOT NULL
                                THEN (SELECT zona
                                        FROM xx_opm_establecimientos
                                       WHERE establecimiento_id = pdx.xx_id_establecimiento)
                             ELSE NULL
                          END zona
                        , CASE
                             WHEN pdx.xx_id_establecimiento IS NOT NULL
                                THEN (SELECT DECODE
                                                (propio
                                           -- amanukyan 20180130 issue 127 las zonas subzonas y establecimiento saca mal
                                               , 'Y', 'PROPIO'
                                               , 'NO PROPIO'
                                                ) propiedad
                                        FROM xx_opm_establecimientos
                                       WHERE establecimiento_id = pdx.xx_id_establecimiento)
                             ELSE NULL
                          END propiedad
                        , CASE
                             WHEN pdx.xx_id_establecimiento IS NOT NULL
                                THEN (SELECT campo
                                        FROM xx_opm_establecimientos
                                       WHERE establecimiento_id = pdx.xx_id_establecimiento)
                             ELSE NULL
                          END establecimiento_alquilado
                        , pdx.xx_lote
                        , ptt.task_number cultivo_principal
                        , pp.project_type
                        , pp.project_id
                        , pp.segment1 project_number
                        , pp.NAME project_name
                        , pt.task_number
                        , pt.task_name
                        , pt.description
                        , pd.expenditure_type
                        , gcc.concatenated_segments cuenta_contable
                        , nvl(msi.SEGMENT1, mc.segment1 ) item_code -- 20180326 amanukyan
                        --, pd.expenditure_type item_description   -- 20180326 amanukyan
                        , pl.item_description item_description -- 20180326 amanukyan
                        --, pd.expenditure_item_date fecha_salida   20180129 amanukyan issue 127 piden q salga de rt.transaction_date
                   ,      rt.transaction_date fecha_salida                               -- 20180129 amanukyan issue 127
                        , DECODE (rt.transaction_type
                                , 'RETURN TO VENDOR', rt.quantity * -1
                                , rt.quantity
                                 ) superficie
                        , DECODE (rt.quantity
                                , 0, 0
                                , 1
                                 ) dosis                   -- en el original divide qty/superficie, y muestra 0 si sup=0
                        , rt.unit_of_measure trans_um
                        , DECODE (rt.transaction_type
                                , 'RETURN TO VENDOR', rt.quantity * -1
                                , rt.quantity
                                 ) total_quantity
                        , NULL fecha_aplicacion
                        , NULL vale_consumo                                                -- NULL ok, no aplica para PO
                        , phx.xx_po_numero_ot
                        , ph.segment1 orden_compra
                        , rt.transaction_id
                        --, 'Devolución PO' transaction_type_name  -- 20180129 amanukyan issue 127
                        , DECODE (rt.transaction_type
                                , 'RECEIVE', 'Recepción PO'
                                , 'RETURN TO VENDOR', 'Devolución PO'
                                 ) transaction_type_name                                 -- 20180129 amanukyan issue 127
                        , rsh.receipt_num recepcion
                        , pv.segment1 nro_proveedor
                        , pv.vendor_name nombre_proveedor
                      , (SELECT INVOICE_NUM    -- Ticket 16462 Cambio del select para que vaya por indice
                                                     FROM ap_invoices_all i
                                                     WHERE I.INVOICE_ID = (SELECT MAX(IL.INVOICE_ID)
                                                     FROM ap_invoice_lines_all il
                                                     WHERE  il.rcv_transaction_id = rt.transaction_id)) factura
                      /*  , (SELECT MAX (invoice_num)
                             FROM ap_invoices_all i
                                , ap_invoice_lines_all il
                            WHERE i.invoice_id = il.invoice_id
                              AND il.rcv_transaction_id = rt.transaction_id) factura*/
                        , (SELECT MAX (alc.displayed_field)   -- Ticket 16462 Cambio del select para que vaya por indice
                             FROM ap_invoices_all i
                                    , ap_lookup_codes alc
                            WHERE I.INVOICE_ID = (SELECT MAX(IL.INVOICE_ID)
                                                                FROM ap_invoice_lines_all il
                                                              WHERE  il.rcv_transaction_id = rt.transaction_id)
                               AND i.payment_status_flag = alc.lookup_code
                              AND alc.lookup_type = 'INVOICE PAYMENT STATUS') pagado
                     /*  , (SELECT MAX (alc.displayed_field)
                             FROM ap_invoices_all i
                                , ap_lookup_codes alc
                                , ap_invoice_lines_all il
                            WHERE i.invoice_id = il.invoice_id
                              AND i.payment_status_flag = alc.lookup_code
                              AND alc.lookup_type = 'INVOICE PAYMENT STATUS'
                              AND il.rcv_transaction_id = rt.transaction_id) pagado*/                        
                        , (pl.unit_price * NVL (ph.rate, 1)) costo
                        , ph.comments observaciones
                        , rt.last_update_date
                        , fu.user_name
                        , 'Sin Interfaz' status_pa
                        , NULL lote_erogaciones
                        , NULL comentario_erogaciones
                        , rt.transaction_date fecha_tc
                        , (SELECT gdr.conversion_rate
                             FROM gl_daily_rates gdr
                                , gl_daily_conversion_types ct
                                , hr_operating_units hou
                            WHERE hou.organization_id = p_org_id
                              AND gdr.conversion_type = ct.conversion_type
                              AND ct.user_conversion_type = DECODE (SUBSTR (hou.NAME
                                                                          , 1
                                                                          , 2
                                                                           )
                                                                  , 'UR', 'Promedio CONS URU'
                                                                  , 'AR', 'Promedio CONS ARG'
                                                                   )
                              AND gdr.from_currency = DECODE (SUBSTR (hou.NAME
                                                                    , 1
                                                                    , 2
                                                                     )
                                                            , 'UR', 'UYU'
                                                            , 'AR', 'ARS'
                                                             )
                              AND gdr.to_currency = 'USD'
                              AND conversion_date = TRUNC (LAST_DAY (rt.transaction_date))) tc
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE project_id = pp.project_id
                              AND class_category = 'TIPO DE PROPIEDAD') tipo_propiedad_pa
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE project_id = pp.project_id
                              AND class_category = 'ZONA DEL PAIS') zona_pa
                        --SD1721
                        , pdx.xx_fecha_labor           fecha_labor
                        , pdx.xx_fecha_certificacion   fecha_certificacion
                     FROM rcv_transactions rt
                        , po_distributions_all pd
                        , po_distributions_all_dfv pdx
                        , po_line_locations_all pll
                        , po_lines_all pl
                        , mtl_categories mc
                        , po_headers_all ph
                        , po_headers_all_dfv phx
                        , rcv_shipment_headers rsh
                        , ap_suppliers pv
                        , org_organization_definitions ood
                        , mtl_parameters par
                        , hr_operating_units hou
                        , gl_code_combinations_kfv gcc
                        , fnd_user fu
                        , pa_projects_all pp
                        , pa_tasks pt
                        , pa_tasks ptt
                        , mtl_system_items_kfv msi
                    WHERE rt.po_distribution_id = pd.po_distribution_id
                      AND pd.line_location_id = pll.line_location_id
                      AND pd.ROWID = pdx.row_id
                      AND pll.po_line_id = pl.po_line_id
                      AND pl.category_id = mc.category_id
                      AND pl.po_header_id = ph.po_header_id
                      AND ph.ROWID = phx.row_id
                      AND rt.organization_id = ood.organization_id
                      AND rt.organization_id = par.organization_id
                      AND ood.operating_unit = hou.organization_id
                      AND rsh.shipment_header_id = rt.shipment_header_id
                      AND rt.vendor_id = pv.vendor_id
                      AND pd.code_combination_id = gcc.code_combination_id
                      AND rt.last_updated_by = fu.user_id
                      and pl.item_id = msi.inventory_item_id(+)
                      and ood.ORGANIZATION_ID = msi.ORGANIZATION_ID(+)
                      AND mc.segment1 in ('34','06') -- CR2064 , se incorpora a labores, el 06 de servicios
                      AND (   rt.transaction_type = 'RECEIVE'
                           OR rt.transaction_type = 'RETURN TO VENDOR')
                      AND pd.project_id = pp.project_id
                      AND pd.task_id = pt.task_id
                      AND ptt.task_id = pt.top_task_id
                      -- Parametros
                      -- parametros
                      AND ood.organization_id IN (SELECT organization_id
                                                  FROM org_organization_definitions od1
                                                  WHERE operating_unit = p_org_id
                                                  AND EXISTS (SELECT 'X'
                                                              FROM org_access_view oav
                                                              WHERE oav.organization_id = od1.organization_id
                                                              AND oav.responsibility_id = fnd_profile.VALUE ('RESP_ID')
                                                              AND oav.resp_application_id = fnd_profile.VALUE ('RESP_APPL_ID')))
                      AND ood.operating_unit = p_org_id
                      AND (   ood.organization_id = p_organization_id
                           OR p_organization_id IS NULL)
                      AND (   pp.project_id = p_project_id
                           OR p_project_id IS NULL)
                      AND (   ptt.task_number >= p_top_task
                           OR p_top_task IS NULL)
                      AND (   ptt.task_number <= p_top_task_to
                           OR p_top_task_to IS NULL)
                      AND rt.transaction_date >= g_date_from
                      AND rt.transaction_date < (  g_date_to + 1)
                      --SD1721
--                      AND ( g_flabor_from IS NULL OR
--                            --TRUNC(fnd_date.canonical_to_date(pdx.xx_fecha_labor)) >= TRUNC(g_flabor_from)
--                            TRUNC(pdx.xx_fecha_labor) >= TRUNC(g_flabor_from)
--                          )
--                      AND ( g_flabor_to IS NULL OR
--                            --TRUNC(fnd_date.canonical_to_date(pdx.xx_fecha_labor)) <= TRUNC(g_flabor_to)
--                            TRUNC(pdx.xx_fecha_labor) <= TRUNC(g_flabor_to)
--                          )
--                      AND ( g_fcert_from IS NULL OR
--                            --TRUNC(fnd_date.canonical_to_date(pdx.xx_fecha_certificacion)) >= TRUNC(g_fcert_from)
--                            TRUNC(pdx.xx_fecha_certificacion) >= TRUNC(g_fcert_from)
--                          )
--                      AND ( g_fcert_to IS NULL OR
--                            ---TRUNC(fnd_date.canonical_to_date(pdx.xx_fecha_certificacion)) <= TRUNC(g_fcert_to)
--                            TRUNC(pdx.xx_fecha_certificacion) <= TRUNC(g_fcert_to)
--                          )
                   UNION ALL
                   /* Origen: Erogaciones Manuales */
                   SELECT 'EXP' origen
                        , hou.NAME ou_name
                        , ood.organization_name
                        , NULL
                        , NULL
                        , NULL
                        , NULL zona
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE class_category = 'TIPO DE PROPIEDAD'
                              AND project_id = pei.project_id) propiedad
                        , NULL establecimiento_alquilado                                                       --ok null
                        , NULL lote                                                                            --ok null
                        , ptt.task_number cultivo_principal
                        , pp.project_type
                        , pp.project_id
                        , pp.segment1 project_number
                        , pp.NAME project_name
                        , pt.task_number
                        , pt.task_name
                        , pt.description
                        , pei.expenditure_type
                        , gcc.concatenated_segments
                        , NULL item_code
                        , NULL item_description
                        , pei.expenditure_item_date fecha_salida
                        , pei_dfv.XX_PA_SUPERFICIE  superficie --CR2334 se incorpora ot, superficie y uom de attr
                        , NULL dosis
                        , pei_dfv.XX_PA_MTL_UNITS_OF_MEASURE transaction_uom --CR2334 se incorpora ot, superficie y uom de attr
                        , NULL transaction_quantity
                        , NULL fecha_aplicacion
                        , NULL vale
                        , pei_dfv.XX_PA_OT ot --CR2334 se incorpora ot, superficie y uom de attr
                        , NULL oc
                        , pei.expenditure_id
                        , 'Erogación Manual'
                        , NULL recepcion
                        , pv.segment1 nro_proveedor
                        , pv.vendor_name nombre_proveedor
                        , NULL factura
                        , NULL pagado
                        , (pei.quantity * -1) COST
                        /* , CASE 20181025
                        WHEN NVL (pei.transaction_source, 'X') IN ('Lotes Pre-aprobados por ADI' , 'Lotes Manuales sin Contabilida', 'X')
                        THEN pei.quantity
                        ELSE
                        (pei.quantity * -1)
                        END COST / * 20181025 */
                        , NULL observaciones
                        , pei.last_update_date
                        , fu.user_name
                        , 'Sin Interfaz' status_pa
                        , peg.expenditure_group lote_erogaciones
                        , pec.expenditure_comment comentario_erogaciones
                        --    ,pei.transaction_source
                   ,      pei.expenditure_item_date fecha_tc
                        , (SELECT gdr.conversion_rate
                             FROM gl_daily_rates gdr
                                , gl_daily_conversion_types ct
                                , hr_operating_units hou
                            WHERE hou.organization_id = p_org_id
                              AND gdr.conversion_type = ct.conversion_type
                              AND ct.user_conversion_type = DECODE (SUBSTR (hou.NAME
                                                                          , 1
                                                                          , 2
                                                                           )
                                                                  , 'UR', 'Promedio CONS URU'
                                                                  , 'AR', 'Promedio CONS ARG'
                                                                   )
                              AND gdr.from_currency = DECODE (SUBSTR (hou.NAME
                                                                    , 1
                                                                    , 2
                                                                     )
                                                            , 'UR', 'UYU'
                                                            , 'AR', 'ARS'
                                                             )
                              AND gdr.to_currency = 'USD'
                              AND conversion_date = TRUNC (LAST_DAY (pei.expenditure_item_date))) tc
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE project_id = pp.project_id
                              AND class_category = 'TIPO DE PROPIEDAD') tipo_propiedad_pa
                        , (SELECT class_code
                             FROM pa_project_classes
                            WHERE project_id = pp.project_id
                              AND class_category = 'ZONA DEL PAIS') zona_pa
                        , NULL fecha_labor
                        , NULL fecha_certificacion
                     FROM pa_expenditures_all pe
                        , pa_expenditure_items_all pei
                        , pa_expenditure_comments pec
                        , pa_projects_all pp
                        , pa_tasks pt
                        , pa_tasks ptt
                        , pa_cost_distribution_lines_all pcdl
                        , ap_suppliers pv
                        , gl_code_combinations_kfv gcc
                        , pa_expenditure_groups_all peg
                        , org_organization_definitions ood
                        , mtl_parameters par
                        , hr_operating_units hou
                        , fnd_user fu
                        , pa_expenditure_items_all_dfv pei_dfv --CR2334 se incorpora ot, superficie y uom de attr
                    WHERE pe.incurred_by_organization_id = ood.organization_id
                      AND pe.incurred_by_organization_id = par.organization_id
                      AND ood.operating_unit = hou.organization_id
                      AND pe.expenditure_id = pei.expenditure_id
                      AND pei.expenditure_item_id = pec.expenditure_item_id
                      AND pei.project_id = pp.project_id
                      AND pei.task_id = pt.task_id
                      AND pei.expenditure_item_id = pcdl.expenditure_item_id
                      AND pei.vendor_id = pv.vendor_id(+)
                      AND pei_dfv.row_id = pei.rowid   --CR2334 se incorpora ot, superficie y uom de attr
                      AND pcdl.dr_code_combination_id = gcc.code_combination_id
                      AND pe.expenditure_group = peg.expenditure_group
                      --AND    peg.transaction_source IS NULL   -- eliminado para q traiga lo q viene de ADI
                      AND pei.system_linkage_function = 'PJ'                                -- solo erogaciones manuales
                      AND peg.expenditure_group_status_code = 'RELEASED'
                      AND ptt.task_id = pt.top_task_id
                      AND pei.last_updated_by = fu.user_id(+)
                      -- Parametros
                      AND ood.organization_id IN (SELECT organization_id
                                                  FROM org_organization_definitions od1
                                                  WHERE operating_unit = p_org_id
                                                  AND EXISTS (SELECT 'X'
                                                              FROM org_access_view oav
                                                              WHERE oav.organization_id = od1.organization_id
                                                              AND oav.responsibility_id = fnd_profile.VALUE ('RESP_ID')
                                                              AND oav.resp_application_id = fnd_profile.VALUE ('RESP_APPL_ID')))
                      AND ood.operating_unit = p_org_id
                      AND (   ood.organization_id = p_organization_id
                           OR p_organization_id IS NULL)
                      AND (   pp.project_id = p_project_id
                           OR p_project_id IS NULL)
                      AND (   ptt.task_number >= p_top_task
                           OR p_top_task IS NULL)
                      AND (   ptt.task_number <= p_top_task_to
                           OR p_top_task_to IS NULL)
                      AND pei.expenditure_item_date >= g_date_from
                      AND pei.expenditure_item_date < (  g_date_to
                                                       + 1))
         ORDER BY fecha_salida
                , transaction_id;

      l_ou_name             VARCHAR2 (100);
      l_oi_name             VARCHAR2 (100);
      l_proyecto            VARCHAR2 (100);
      v_flag_conv_rate      NUMBER := 0;
      l_tc                  NUMBER;
                            -- amanukyan 20180322 piden calcular el TC bien exacto sin problemas de redondeo
   BEGIN
      SELECT (SELECT NAME
              FROM hr_organization_units
              WHERE organization_id = p_org_id) ou_name
           , (SELECT organization_name
              FROM org_organization_definitions
              WHERE organization_id = p_organization_id) oi_name
           , (SELECT NAME
              FROM pa_projects_all
              WHERE project_id = p_project_id) l_proyecto
      INTO l_ou_name
         , l_oi_name
         , l_proyecto
      FROM DUAL;

      print_output ('Parámetros Ejecución');
      print_output ('  ');
      print_output (   'Unidad Operativa: '
                    || l_ou_name);
      print_output (   'Org.Inventario:   '
                    || l_oi_name);
      print_output (   'Calendario: '
                    || p_calendar_code);
      print_output (   'Proyecto: '
                    || l_proyecto);
      print_output (   'Cultivo Desde: '
                    || p_top_task);
      print_output (   'Cultivo Hasta: '
                    || p_top_task_to);
      print_output (   'Fecha Desde: '
                    || TO_CHAR (g_date_from));
      print_output (   'Fecha Hasta: '
                    || TO_CHAR (g_date_to));
      print_output (   'Fecha Labor Desde: '
                    || TO_CHAR (g_flabor_from));
      print_output (   'Fecha Labor Hasta: '
                    || TO_CHAR (g_flabor_to));
      print_output (   'Fecha Certificacion Desde: '
                    || TO_CHAR (g_fcert_from));
      print_output (   'Fecha Certificacion Hasta: '
                    || TO_CHAR (g_fcert_to));
      print_output ('  ');
      print_output (   'Origen'
                    || '|'
                    || 'Unidad Operativa'
                    || '|'
                    || 'Org. Inventario'
                    || '|'
                    || 'Zona'
                    || '|'
                    || 'Propiedad'
                    || '|'
                    || 'Establecimiento Alquilado'
                    || '|'
                    || 'Lote'
                    || '|'
                    || 'Cultivo Principal'
                    || '|'
                    || 'Tipo Proyecto'
                    || '|'
                    || 'Proyecto'
                    || '|'
                    || 'Nombre Proyecto'
                    || '|'
                    || 'Tarea'
                    || '|'
                    || 'Nombre Tarea'
                    || '|'
                    || 'Tipo Erogacion'
                    || '|'
                    || 'Cuenta Contable'
                    || '|'
                    || 'Item'
                    || '|'
                    || 'Descr. Item'
                    || '|'
                    || 'Fecha Transacción'
                    || '|'
                    || 'Superficie'
                    || '|'
                    || 'Dosis'
                    || '|'
                    || 'UM'
                    || '|'
                    || 'Total'
                    || '|'
                    || 'Fecha Aplicación'
                    || '|'
                    || 'Vale Consumo'
                    || '|'
                    || 'OT'
                    || '|'
                    || 'OC'
                    || '|'
                    || 'ID Transacción'
                    || '|'
                    || 'Tipo Transacción'
                    || '|'
                    || 'Recepción'
                    || '|'
                    || 'Nro Proveedor'
                    || '|'
                    || 'Nombre Proveedor'
                    || '|'
                    || 'Factura'
                    || '|'
                    || 'Pagado'
                    || '|'
                    || '$ Unidad'
                    || '|'
                    || '$ Total'
                    || '|'
                    || 'U$D Unidad'
                    || '|'
                    || 'U$D Total'
                    || '|'
                    || 'TC'
                    || '|'
                    || 'Observaciones'
                    || '|'
                    || 'Fecha Ultima Mod. '
                    || '|'
                    || 'Usuario Ultima Mod.'
                    || '|'
                    || 'Estado PA'
                    || '|'
                    || 'Lote Erogaciones'
                    || '|'
                    || 'Comentario Erogaciones'
                    || '|'
                    || 'Fecha Labor'
                    || '|'
                    || 'Fecha Certificacion'
                    );

      FOR r_data IN c_data LOOP
         --sl, 14/09/18, se atrapa el costo_total_usd = 0
         BEGIN
          -- amanukyan 20180322 piden calcular el TC bien exacto sin problemas de redondeo
           SELECT DECODE (nvl(r_data.costo_total_usd,0)
                         , 0, 1 / r_data.tc
                         , ROUND (r_data.costo_total / r_data.costo_total_usd, 2)
                         )
           INTO l_tc
           FROM DUAL;
         --exception
         --  when others then
         --    errbuf  := 'Error con r_data.costo_total_usd= '||r_data.costo_total_usd|| ' para '|| r_data.observaciones;
         --    fnd_file.put_line (fnd_file.LOG, errbuf);
         --    retcode := '1';
         --    exit;
         END;


         -- amanukyan 20180322 piden calcular el TC bien exacto sin problemas de redondeo
         print_output (   r_data.origen
                       || '|'
                       || r_data.ou_name
                       || '|'
                       || r_data.organization_name
                       || '|'
                       -- || r_data.zona -- amanukyan 20180323
                       || r_data.zona_pa -- amanukyan 20180323
                       || '|'
                       --|| r_data.propiedad -- amanukyan 20180323
                       || r_data.tipo_propiedad_pa -- amanukyan 20180323
                       || '|'
                       || r_data.establecimiento_alquilado
                       || '|'
                       || r_data.xx_lote
                       || '|'
                       || r_data.cultivo_principal
                       || '|'
                       || r_data.project_type
                       || '|'
                       || r_data.project_number
                       || '|'
                       || r_data.project_name
                       || '|'
                       || r_data.task_number
                       || '|'
                       || r_data.description
                       || '|'
                       || r_data.expenditure_type
                       || '|'
                       || r_data.cuenta_contable
                       || '|'
                       || r_data.item_code
                       || '|'
                       || r_data.item_description
                       || '|'
                       || r_data.fecha_salida
                       || '|'
                       || r_data.xx_opm_superficie
                       || '|'
                       || r_data.dosis
                       || '|'
                       || r_data.um
                       || '|'
                       || r_data.q_total
                       || '|'
                       || r_data.xx_opm_fecha_aplicacion
                       || '|'
                       || r_data.xx_opm_vale_consumo
                       || '|'
                       || r_data.xx_opm_ot
                       || '|'
                       || r_data.xx_opm_oc
                       || '|'
                       || r_data.transaction_id
                       || '|'
                       || r_data.transaction_type_name
                       || '|'
                       || r_data.recepcion
                       || '|'
                       || r_data.nro_proveedor
                       || '|'
                       || r_data.nombre_proveedor
                       || '|'
                       || r_data.factura
                       || '|'
                       || r_data.pagado
                       || '|'
                       || r_data.costo
                       || '|'
                       || r_data.costo_total
                       || '|'
                       || r_data.costo_usd
                       || '|'
                       || r_data.costo_total_usd
                       || '|'
                       --||        r_data.FECHA_TC || '|' ||
                        -- || ROUND (1 / r_data.tc, 2)
                       || l_tc          -- amanukyan 20180322 piden calcular el TC bien exacto sin problemas de redondeo
                       || '|'
                       || r_data.observaciones
                       || '|'
                       || r_data.last_update_date
                       || '|'
                       || r_data.user_name
                       || '|'
                       || r_data.status_pa
                       || '|'
                       || r_data.lote_erogaciones
                       || '|'
                       || r_data.comentario_erogaciones
                       || '|'
                       || r_data.fecha_labor
                       || '|'
                       || r_data.fecha_certificacion
                       );

         IF r_data.tc IS NULL THEN
            v_flag_conv_rate := 1;
         END IF;
      END LOOP;

      IF (v_flag_conv_rate = 1) THEN
         retcode := '1';
         errbuf  := 'La tasa de Conversión de uno de los periodos ejecutados no se encuentra seteada.';
         fnd_file.put_line (fnd_file.LOG, errbuf);
      ELSE
         retcode := '0';
         errbuf  := 'El concurrente finalizo en forma exitosa.';
      END IF;
   END principal;

END xx_opm_planilla_oper_r12;
/

exit
