#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2334_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2334
# |
# | HISTORY
# |   05-MAY-20  Rosas, Ines - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2334_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2334_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2334
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2334" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2334_9350.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2334"
AddAllLogs $CROUT "FND" "CR2334_9350.ldt"
mv CR2334_9350.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OPM_PLANILLA_OPER_R12 " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OPM_PLANILLA_OPER_R12','APPS','$PATCHDIR','CR2334');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_PLANILLA_OPER_R12* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF PO_DISTRIBUTIONS_AR_XXFECHALABOR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt DESC_FLEX APPLICATION_SHORT_NAME="PO" DESCRIPTIVE_FLEXFIELD_NAME="PO_DISTRIBUTIONS" DESCRIPTIVE_FLEX_CONTEXT_CODE="AR" END_USER_COLUMN_NAME="XX_FECHA_LABOR"
AddAllLogs $CROUT "FND" "PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt"
mv PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt DESC_FLEX APPLICATION_SHORT_NAME="PO" DESCRIPTIVE_FLEXFIELD_NAME="PO_DISTRIBUTIONS" DESCRIPTIVE_FLEX_CONTEXT_CODE="AR" END_USER_COLUMN_NAME="XX_FECHA_CERTIFICACION"
AddAllLogs $CROUT "FND" "PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt"
mv PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_OPM_PLANILLA_OPER_R12 " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_PLANILLA_OPER_R12 >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_PLANILLA_OPER_R12.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_PLANILLA_OPER_R12.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_PLANILLA_OPER_R12.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_PLANILLA_OPER_R12.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_PLANILLA_OPER_R12.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF PO_DISTRIBUTIONS_AR_XXFECHALABOR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHALABOR.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/PO_DISTRIBUTIONS_AR_XXFECHACERTIFIC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2334" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2334_9350.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2334_9350.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
