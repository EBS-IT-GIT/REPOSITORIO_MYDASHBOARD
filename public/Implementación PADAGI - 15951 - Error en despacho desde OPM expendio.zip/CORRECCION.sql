UPDATE apps.wsh_new_deliveries wnd
SET    status_code = 'OP'
WHERE  status_code = 'CL'
AND    organization_id != '1031'
AND    exists (SELECT 1 
               FROM   apps.wsh_delivery_details wdd
                    , apps.wsh_delivery_assignments wda
               WHERE  wdd.delivery_detail_id = wda.delivery_detail_id
               AND    wda.delivery_id = wnd.delivery_id
               AND    released_status = 'R');
--9 Registros