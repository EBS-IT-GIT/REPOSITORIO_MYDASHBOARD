UPDATE apps.ap_invoice_distributions_all
SET    attribute2 = 'FC INTERNA', attribute3 = 'Y'
WHERE  attribute4 = '0003-00000137'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'ALEMANY ADRIAN ALBERTO');
--3 Registros