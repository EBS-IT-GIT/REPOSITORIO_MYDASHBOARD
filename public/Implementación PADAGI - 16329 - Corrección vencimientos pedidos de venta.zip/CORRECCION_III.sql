UPDATE apps.oe_order_headers_all ooh
SET    payment_term_id = decode(sold_to_org_id,8382521,1003,8857617,1004,payment_term_id),last_update_date = sysdate, last_updated_by = 2070
WHERE  ooh.org_id = 2235 
AND    ooh.order_number IN (5471,5423,5422,5421,5420,5419,5418,5417,5416,5415,5414,5413,5412,5411,5410,5409,5408,5407,5406,
5405,5404,5403,5402,5401,5400,5399,4972,4971,4969,4968,4965,4964,4963,4961,4954,4951);
--36 Registros