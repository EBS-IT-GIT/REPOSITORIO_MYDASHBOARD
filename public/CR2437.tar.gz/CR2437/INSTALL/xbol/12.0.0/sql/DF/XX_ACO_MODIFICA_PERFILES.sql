  set define off;
SET SERVEROUTPUT ON FORMAT WRAPPED
SET VERIFY OFF
SET FEEDBACK OFF
SET TERMOUT OFF
set serveroutput on size 1000000
/
DBMS_OUTPUT.ENABLE(1000000);
SPOOL XX_ACO_MODIFICA_PERFILES.log

DECLARE

  CURSOR LKV IS
    SELECT lookup_type, lookup_code, language, description
      FROM FND_LOOKUP_VALUES
     WHERE lookup_type = 'XX_ACO_MODIFICA_PERFILES'
       AND (view_application_id = '20003')
       AND (security_group_id = '0')       
     ORDER BY lookup_code;

  l_old_desc   VARCHAR(240);
  l_new_desc   VARCHAR(240);
  l_id         NUMBER;
  l_user_name  VARCHAR(240);
  
BEGIN

  DBMS_OUTPUT.put_line('Inicio');
  
  FOR rlkv IN lkv LOOP
    
    DBMS_OUTPUT.put_line('LOOKUP_CODE='||rlkv.lookup_code||' - LANGUAGE='||rlkv.language);
    l_old_desc := rlkv.description;
    l_new_desc := NULL;
    
    
    WHILE (LENGTH(l_old_desc)>0) LOOP
      
      IF (SUBSTR(l_old_desc, 1, 1)= ',') THEN
        
        l_old_desc := SUBSTR(l_old_desc, 2, length(l_old_desc));
        
      ELSIF (SUBSTR(l_old_desc, 1, 1)= ' ') THEN
        
        l_old_desc := SUBSTR(l_old_desc, 2, length(l_old_desc));
        
      ELSE
        
        IF (INSTR(l_old_desc, ',',1)>0) THEN 
          l_id := SUBSTR(l_old_desc, 1, INSTR(l_old_desc, ',',1)-1);
          l_old_desc := SUBSTR(l_old_desc, INSTR(l_old_desc, ',',1), LENGTH(l_old_desc));
        ELSE
          l_id := l_old_desc;
          l_old_desc := NULL;
        END IF;
        
        
        IF (l_id IS NOT NULL) THEN
          
          SELECT user_name
            INTO l_user_name 
            FROM FND_USER
           WHERE user_id = l_id;
          
          IF (l_new_desc IS NULL) THEN
            l_new_desc := l_user_name||',';
          ELSE
            l_new_desc := l_new_desc||l_user_name||',';
          END IF;  
          
        END IF;
          
        
      END IF;
      
    END LOOP;
    
    
    DBMS_OUTPUT.put_line('Code = '||rlkv.lookup_code||' - Old desc = '||rlkv.description||' - New desc = '||SUBSTR(l_new_desc, 1, LENGTH(l_new_desc)-1));  

    UPDATE FND_LOOKUP_VALUES  
       SET description = SUBSTR(l_new_desc, 1, LENGTH(l_new_desc)-1)
     WHERE lookup_type = rlkv.lookup_type
       AND lookup_code = rlkv.lookup_code
       AND language    = rlkv.language
       AND description = rlkv.description; 
    
  END LOOP;
  
  COMMIT;
  

EXCEPTION
  WHEN others THEN
    DBMS_OUTPUT.put_line('Error: '||SQLERRM);
    
END;
/
SHOW ERRORS

SPOOL OFF

SET TERMOUT ON
SET FEEDBACK ON
SET VERIFY ON;

exit
