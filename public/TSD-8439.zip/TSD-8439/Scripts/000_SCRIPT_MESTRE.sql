@"&DIRETORIO\000_SETUP_SCRIPTS.sql"
--
SPOOL "&DIRETORIO\TSD8439.log";


PROMPT tsd-8439_00.sql
@&DIRETORIO\tsd-8439_00.sql;
PROMPT FIM tsd-8439_00.sql

PROMPT tsd-8439_01.sql
@&DIRETORIO\tsd-8439_01.sql;
PROMPT FIM tsd-8439_01.sql

PROMPT tsd-8439_02.sql
@&DIRETORIO\tsd-8439_02.sql;
PROMPT FIM tsd-8439_02.sql


PROMPT Processo Finalizado! Favor verificar no arquivo de log TSD8439 se O script foi executado com sucesso...
SPOOL OFF;


