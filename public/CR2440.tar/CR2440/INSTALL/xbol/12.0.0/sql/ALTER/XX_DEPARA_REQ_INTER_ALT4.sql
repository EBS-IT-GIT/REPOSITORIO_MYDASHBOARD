  set define off;
ALTER TABLE bolinf.xx_depara_req_inter ADD (last_update_date DATE);

exit
