  set define off;
ALTER TABLE bolinf.xx_depara_req_inter ADD CONSTRAINT xx_depara_req_inter_pk PRIMARY KEY (cod_motivo);

exit
