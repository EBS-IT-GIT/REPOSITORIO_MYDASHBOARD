  set define off;
ALTER TABLE bolinf.xx_gatec_mov_insum ADD (cod_motivo VARCHAR2(6));

exit
