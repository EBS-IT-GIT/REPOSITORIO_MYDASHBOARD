  set define off;
ALTER TABLE bolinf.xx_depara_req_inter ADD (creation_date DATE);

exit
