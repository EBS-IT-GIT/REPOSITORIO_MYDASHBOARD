  set define off;
DROP INDEX XX_DEPARA_REQ_INTER_U1;

exit
