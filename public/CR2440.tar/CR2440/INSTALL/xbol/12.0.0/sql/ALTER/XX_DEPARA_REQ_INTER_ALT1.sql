  set define off;
ALTER TABLE bolinf.xx_depara_req_inter ADD (cod_processo VARCHAR2(10));

exit
