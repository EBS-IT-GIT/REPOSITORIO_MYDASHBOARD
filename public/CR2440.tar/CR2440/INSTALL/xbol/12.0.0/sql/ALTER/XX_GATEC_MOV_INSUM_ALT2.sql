  set define off;
ALTER TABLE bolinf.xx_gatec_mov_insum ADD (cod_processo VARCHAR2(10));

exit
