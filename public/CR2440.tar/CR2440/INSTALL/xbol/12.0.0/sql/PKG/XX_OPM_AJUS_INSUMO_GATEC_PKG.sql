  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OPM_AJUS_INSUMO_GATEC_PKG" AS
--
-- $Header: XX_OPM_AJUS_INSUMO_GATEC_PKG.pks 120.1 06/12/2017 17:00:00  itconvergence ship $
-- +==========================================================================================+ --
-- |                         IT Convergence Brasil, Sao Paulo,SP - 2017                       | --
-- +==========================================================================================+ --
-- | FILENAME                                                                                 | --
-- |   XX_OPM_AJUS_INSUMO_GATECS_PKG.pks                                                      | --
-- |                                                                                          | --
-- | PURPOSE                                                                                  | --
-- |   Oracle Applications Rel 11.5.10.2 --> 12.2.6                                           | --
-- |   Produto.: Oracle                                                                       | --
-- |   Objetivo: Script para criacao da especificacao da package                              | --
-- |                                                                                          | --
-- | DESCRIPTION                                                                              | --
-- |   1. Criar um processo para fazer a transferencia de local                               | --
-- |      (entre depositos) dos itens de Insumos, via API.                                    | --
-- |                                                                                          | --
-- |   2. Criar ajuste imediato para item (Insumo) no estoque do OPM                          | --
-- |      com baixas vindas ao GATEC, via API core.                                           | --
-- |                                                                                          | --
-- |   **********************************************************                             | --
-- |   OBS.: O processo e semelhante a baixa de combustivel                                   | --
-- |   feita pela package APPS.XX_OPM_AJUSTE_GATEC_PKG e utiliza                              | --
-- |   a mesma API.                                                                           | --
-- |   **********************************************************                             | --
-- |                                                                                          | --
-- |   Obs.: Os dados sao enviados para a tabela BOLINF.XX_GATEC_MOV_INSUM pela procedure     | --
-- |         "XX_GATEC_MOV_INSUM_PKG_R12" na base do Gatec DB_INTEGRACAO@ORAGERAL@.           | --
-- |                                                                                          | --
-- | CREATED BY                                                                               | --
-- |   Rafael S. Nunes (Ninecon)    24/01/2017                                                | --
-- |                                                                                          | --
-- | UPDATED BY                                                                               | --
-- |   Luiz Chacon (ITConvergence)  15/06/2017                                                | --
-- |                                Upgrade R12. Atualizadas as tabelas do OPM, para as suas  | --
-- |                                respectivas na R12, removidos APPS do owner das tabelas   | --
-- |                                nos selects.                                              | --
-- |                                                                                          | --
-- |   Rafael S. Nunes (Ninecon)    20/12/2017 - Chamado 487 (R12)                            | --
-- |                                Alterada a procedure BAIXA_INSUMO_P para adequar a R12,   | --
-- |                                agora sera feito pelo INV, na 11i era feito pelo OPM.     | --
-- |                                                                                          | --
-- |                                OBS.: a procedure TRANSF_TRLO_ITEM_P sera descontinuada   | --
-- |                                nesta package, ela foi transferida para a package/proc    | --
-- |                                XX_MOVE_ORDER_GATEC_PKG.TRANSF_ESTOQUE_P.                 | --
-- |                                                                                          | --
-- |   Rafael S. Nunes (Ninecon)    16/05/2019 - Chamado 102600                               | --
-- |                                Exportacao Insumos PCP x Oracle                           | --
-- |                                Correcao no Select para recuperar o numero do Lote, reti- | --
-- |                                rado o ROWNUM e incluido GROUP BY pois estava retornando  | --
-- |                                lote incorreto em alguns casos.                           | --
-- |                                                                                          | --
-- |   Rafael S. Nunes (Ninecon)    09/04/2020 - SD 115062                                    | --
-- |                                Incluido o campo COD_PROCESSO na tabela                   | --
-- |                                BOLINF.XX_DEPARA_REQ_INTER. Neste chamado tambem foi cria-| --
-- |                                do o form XXDEPARACODMOT.fmb para cadastro de De-Para de  | --
-- |                                Codigo de Motivo x Centro de Custo na responsabilidade    | --
-- |                                XXX OPM GE CUSTO BRA_R12 >> XX De-Para Cod. Motivo x C.   | --
-- |                                Custo.                                                    | --
-- |                                                                                          | --
-- +==========================================================================================+ --
--
  -----------------------
  -- Variaveis Globais --
  -----------------------
  l_qty_rec            gmigapi.qty_rec_typ;
  l_ic_jrnl_mst_row    ic_jrnl_mst%ROWTYPE;
  l_ic_adjs_jnl_row1   ic_adjs_jnl%ROWTYPE;
  l_ic_adjs_jnl_row2   ic_adjs_jnl%ROWTYPE;
  l_return_status      VARCHAR2(10);
  l_msg_count          NUMBER := 0;
  l_msg_data           VARCHAR2(1000);
  l_dummy_cnt          NUMBER := 0;
  l_loop_cnt           NUMBER := 0;
  --
  l_vPlanta            mtl_parameters.process_orgn_code    %TYPE;             --apps.ic_whse_mst.orgn_code%TYPE;
  l_vCo_Code           org_organization_definitions.organization_code %TYPE;  --gl_plcy_mst.co_code  %TYPE;
  l_vLegal_entity_id   gmf_fiscal_policies.legal_entity_id %TYPE;
  l_vCod_Motivo        xx_depara_req_inter.cod_motivo      %TYPE;
  l_nCt_Warn           NUMBER := 0;
  l_vLog_Conc          VARCHAR2(32000); -- Armazena todas as msgs de retorno da API para imprimir no final do concurrent
  l_vLog_Reg           VARCHAR2(5000);  -- Armazena as msgs de log de CADA registro que estiver sendo processado
  l_vCod_Empr_Gatec    VARCHAR2(5);
  l_nCt_Reg            NUMBER := 0;
  l_nLot_Ctl           mtl_system_items_b.lot_control_code %TYPE;  --ic_item_mst_b.lot_ctl%TYPE;
  g_vLog_Email         VARCHAR2(32000) := ''; -- Rafael S. Nunes (Ninecon) -- #584# -- Jan/2018
  --
  PROCEDURE inicia_ambiente_p ( p_errbuf    IN OUT VARCHAR2
                               ,p_retcode   IN OUT VARCHAR2
                               ,p_org_id    IN NUMBER
                               ,p_user_name IN VARCHAR2
                               ,p_resp_name IN VARCHAR2 ); -- Ex: BR INV ANGELICA Super Usuario
  --
  PROCEDURE criar_ajuste_p ( p_errbuf    IN OUT VARCHAR2
                            ,p_retcode   IN OUT VARCHAR2
                            ,p_org_id    IN NUMBER
                            ,p_user_name IN VARCHAR2                                          --> Opcional (nÃ?Â£o Ã?Â© ncessÃ?Â¡rio quando executado de dentro da aplicaÃ?Â§Ã?Â£o)
                            ,p_resp_name IN VARCHAR2 ); -- Ex: BR INV ANGELICA Super Usuario --> Opcional (nÃ?Â£o Ã?Â© ncessÃ?Â¡rio quando executado de dentro da aplicaÃ?Â§Ã?Â£o)

  --
  PROCEDURE print_msg_p ( p_msg IN VARCHAR2 );
  --
  PROCEDURE log_email_p ( p_msg IN VARCHAR2 );
  --
  PROCEDURE envia_email_p;
END xx_opm_ajus_insumo_gatec_pkg;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OPM_AJUS_INSUMO_GATEC_PKG" AS
--
-- $Header: XX_OPM_AJUS_INSUMO_GATEC_PKG.pkb 120.1 06/12/2017 17:00:00  itconvergence ship $
-- +==========================================================================================+ --
-- |                         IT Convergence Brasil, Sao Paulo,SP - 2017                       | --
-- +==========================================================================================+ --
-- | FILENAME                                                                                 | --
-- |   XX_OPM_AJUS_INSUMO_GATECB_PKG.pkb                                                      | --
-- |                                                                                          | --
-- | PURPOSE                                                                                  | --
-- |   Oracle Applications Rel 11.5.10.2 --> 12.2.6                                           | --
-- |   Produto.: Oracle                                                                       | --
-- |   Objetivo: Script para criacao do corpo da package                                      | --
-- |                                                                                          | --
-- | DESCRIPTION                                                                              | --
-- |   1. Criar um processo para fazer a transferencia de local                               | --
-- |      (entre depositos) dos itens de Insumos, via API.                                    | --
-- |                                                                                          | --
-- |   2. Criar ajuste imediato para item (Insumo) no estoque do OPM                          | --
-- |      com baixas vindas ao GATEC, via API core.                                           | --
-- |                                                                                          | --
-- |   **********************************************************                             | --
-- |   OBS.: O processo e semelhante a baixa de combustivel                                   | --
-- |   feita pela package APPS.XX_OPM_AJUSTE_GATEC_PKG e utiliza                              | --
-- |   a mesma API.                                                                           | --
-- |   **********************************************************                             | --
-- |                                                                                          | --
-- |   Obs.: Os dados sao enviados para a tabela BOLINF.XX_GATEC_MOV_INSUM pela procedure     | --
-- |         "XX_GATEC_MOV_INSUM_PKG_R12" na base do Gatec DB_INTEGRACAO@ORAGERAL@.           | --
-- |                                                                                          | --
-- | CREATED BY                                                                               | --
-- |   Rafael S. Nunes (Ninecon)    24/01/2017                                                | --
-- |                                                                                          | --
-- | UPDATED BY                                                                               | --
-- |   Luiz Chacon (ITConvergence)  15/06/2017                                                | --
-- |                                Upgrade R12. Atualizadas as tabelas do OPM, para as suas  | --
-- |                                respectivas na R12, removidos APPS do owner das tabelas   | --
-- |                                nos selects.                                              | --
-- |                                                                                          | --
-- |   Rafael S. Nunes (Ninecon)    20/12/2017 - Chamado 487 (R12)                            | --
-- |                                Alterada a procedure BAIXA_INSUMO_P para adequar a R12,   | --
-- |                                agora sera feito pelo INV, na 11i era feito pelo OPM.     | --
-- |                                                                                          | --
-- |                                OBS.: a procedure TRANSF_TRLO_ITEM_P sera descontinuada   | --
-- |                                nesta package, ela foi transferida para a package/proc    | --
-- |                                XX_MOVE_ORDER_GATEC_PKG.TRANSF_ESTOQUE_P.                 | --
-- |                                                                                          | --
-- |   Rafael S. Nunes (Ninecon)    16/05/2019 - Chamado 102600                               | --
-- |                                Exportacao Insumos PCP x Oracle                           | --
-- |                                Correcao no Select para recuperar o numero do Lote, reti- | --
-- |                                rado o ROWNUM e incluido GROUP BY pois estava retornando  | --
-- |                                lote incorreto em alguns casos.                           | --
-- |                                                                                          | --
-- |   Rafael S. Nunes (Ninecon)    09/04/2020 - SD 115062                                    | --
-- |                                Incluido o campo COD_PROCESSO na tabela                   | --
-- |                                BOLINF.XX_DEPARA_REQ_INTER. Neste chamado tambem foi cria-| --
-- |                                do o form XXDEPARACODMOT.fmb para cadastro de De-Para de  | --
-- |                                Codigo de Motivo x Centro de Custo na responsabilidade    | --
-- |                                XXX OPM GE CUSTO BRA_R12 >> XX De-Para Cod. Motivo x C.   | --
-- |                                Custo.                                                    | --
-- |                                                                                          | --
-- +==========================================================================================+ --
  -- ------------------------------------------- --
  -- Rafael S. Nunes (Ninecon) - 487 -- Mar/2018 --
  -- ------------------------------------------- --
  PROCEDURE inicia_ambiente_p ( p_errbuf    IN OUT VARCHAR2
                               ,p_retcode   IN OUT VARCHAR2
                               ,p_org_id    IN NUMBER
                               ,p_user_name IN VARCHAR2
                               ,p_resp_name IN VARCHAR2 ) IS -- Ex: BR INV ANGELICA Super Usuario
    l_user_id        NUMBER := -1;
    l_resp_id        NUMBER := -1;
    l_application_id NUMBER := -1;
  BEGIN
    dbms_output.enable(1000000);
    mo_global.set_policy_context('S', p_org_id);
    mo_global.init('INV'); -- Required for R12 --> Aplicacao do INV
    mo_global.set_org_context(p_org_id, NULL, 'INV');
    fnd_global.set_nls_context('BRAZILIAN PORTUGUESE');
    --
    -- Obter o USER_ID
    BEGIN
      SELECT fu.user_id
        INTO l_user_id
        FROM fnd_user fu
       WHERE fu.user_name = p_user_name;
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'ERRO: Consulta USER_ID em FND_USER para o usuario ' || p_user_name || ' - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20010, p_errbuf);
    END;
    --
    -- Obtem o APPLICATION_ID e RESPONSIBILITY_ID
    BEGIN
      SELECT frv.application_id
            ,frv.responsibility_id
        INTO l_application_id
            ,l_resp_id
        FROM fnd_responsibility_vl frv
       WHERE frv.responsibility_name = p_resp_name;
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'ERRO: Consulta APPLICATION_ID e RESPONSIBILITY_ID da responsabilidade ' || p_resp_name || ' - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20020, p_errbuf);
    END;
    --
    -- Inicia variaveis de ambiente
    FND_GLOBAL.APPS_INITIALIZE(l_user_id, l_resp_id, l_application_id);
    dbms_output.put_line('Initialized applications context:');
    dbms_output.put_line('USER_ID = '|| l_user_id || ' / RESP_ID = ' || l_resp_id || ' / APPLICATION_ID = ' || l_application_id || ' / USER_NAME = ' || p_user_name || CHR(13) || CHR(13));
  END inicia_ambiente_p;
  --
  PROCEDURE criar_ajuste_p ( p_errbuf    IN OUT VARCHAR2
                            ,p_retcode   IN OUT VARCHAR2
                            ,p_org_id    IN NUMBER
                            ,p_user_name IN VARCHAR2                                      --> Opcional (nao e ncessario quando executado de dentro da aplicacao)
                            ,p_resp_name IN VARCHAR2 -- Ex: BR INV ANGELICA Super Usuario --> Opcional (nao e ncessario quando executado de dentro da aplicacao)
                           ) IS
    CURSOR c_1 IS
      SELECT xgmi.chave
            ,xgmi.mov_id
            ,xgmi.num_docum
            ,xgmi.cod_empr
            ,DECODE(xgmi.cod_empr, '10', 110
                                 , '20', 196
                                 , '21', 109
                                 , '23', 196
                                 , '31', 109
                                 , '32', 109
                                 , '34', 109 ) org_id
            ,DECODE(xgmi.cod_empr, '10', 'UMA'
                                 , '20', 'ANG'
                                 , '21', 'LEM'
                                 , '23', 'IVN'
                                 , '31', 'LEM'
                                 , '32', 'LEM'
                                 , '34', 'LEM' ) org_inventario
            ,xgmi.mat_codigo
            ,xgmi.mat_codigo_ga
            ,(xgmi.qtd_material*-1) qtd_material -- Qtde a ser baixada, na Baixa devera, sempre ser um valor negativo
            ,xgmi.dat_movimento
            ,xgmi.cod_centr_custo
            ,xgmi.cod_depos
            ,xgmi.cod_estabel
            ,xgmi.ctb_id
            ,xgmi.cod_ponto
            ,xgmi.ies_integrado
            ,xgmi.dat_export
            ,xgmi.user_export
            ,xgmi.req
            ,xgmi.dev
            ,xgmi.num_os
            ,xgmi.saf_ano_safra
            ,xgmi.cod_empr_erp
            ,xgmi.tipo_resumo
            ,xgmi.ctb_id_old
            ,xgmi.cod_lote
            ,xgmi.lot_qtde
            ,xgmi.status
            ,xgmi.journal_no
            ,xgmi.log
            ,xgmi.created_by
            ,xgmi.creation_date
            ,xgmi.last_update_date
            ,xgmi.last_updated_by
            ,xgmi.last_update_login
            ,xgmi.cod_processo -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020
            ,xgmi.cod_motivo   -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020
            ,rowid
        --FROM xx_gatec_mov_insum xgmi     -- Tabela de baixa de item
        FROM bolinf.xx_gatec_mov_insum xgmi     -- Tabela de baixa de item -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020 -- Retornado o owner original da tabela.
       WHERE NVL(xgmi.status,'X') != 'S'; -- Considerar todos os registros que nao tenham  sido processados(NULL)
                                         -- ou reprocessar os que tenham [E]rro ou erro inesperado [U]nespected,
                                         -- ou qualquer outro status de erro que a API retorne.
         --FOR UPDATE OF xgmi.status; -- -- Rafael S. Nunes (Ninecon) -- 584 -- Mai/2018 -- comentado
    --
    l_nTransaction_type_id      apps.mtl_transaction_types.transaction_type_id%TYPE;
    l_vUDM                      apps.mtl_system_items_b.primary_uom_code%TYPE;
    l_nInventory_item_id        apps.mtl_system_items_b.inventory_item_id%TYPE;
    l_nCt_Rec                   NUMBER := 0; -- Total de registros do cursor
    l_nCt_Intf                  NUMBER := 0; -- Total de registros inseridos na MTL_TRANSACTIONS_INTERFACE
    l_nCt                       NUMBER;
    l_nRetcode                  NUMBER; -- Codigo de retorno da API --> * @return Returns the status with value 0 to indicate successful processing and value -1 to indicate failure processing
    l_return_status             VARCHAR2(50);
    l_msg_count                 NUMBER;
    l_msg_data                  VARCHAR2(5000);
    l_trans_count               NUMBER;
    l_transaction_header_id_ex  NUMBER;
    l_nTransaction_interface_id NUMBER;
    l_nOrganization_id          apps.mtl_system_items_b.organization_id%TYPE;
    l_nReason_id                apps.mtl_transaction_reasons.reason_id%TYPE;
    l_nMaterial_Account         apps.mtl_parameters.material_account%TYPE;
    l_vInventory_location_id    apps.mtl_item_locations.inventory_location_id%TYPE;
    l_nControle_Lote            apps.mtl_system_items_b.lot_control_code%TYPE;
    l_vPrefixo_Inicial          apps.mtl_system_items_b.auto_lot_alpha_prefix%TYPE;
    l_vNumero_Inicial           apps.mtl_system_items_b.start_auto_lot_number%TYPE;
    l_nTot_NOK                  NUMBER := 0; -- Total de Req. com erro
    l_nIntegra                  xx_req_gatec_br.integra%TYPE;
    l_nNum_Req_Ora              xx_req_gatec_br.num_req_ora%TYPE;
    l_vLot_Number               apps.mtl_transaction_lot_val_v.lot_number%TYPE;
    l_vSubinventory_code        apps.mtl_secondary_locators_all_v.subinventory_code%TYPE;
  BEGIN
    -- ------------------------------------------------------------------- --
    -- Inicia variaveis de ambiente apenas se for testar fora da aplicacao --
    -- ------------------------------------------------------------------- --
    IF p_user_name IS NOT NULL AND p_resp_name IS NOT NULL THEN
      inicia_ambiente_p ( p_errbuf    => p_errbuf
                         ,p_retcode   => p_retcode
                         ,p_org_id    => p_org_id
                         ,p_user_name => p_user_name
                         ,p_resp_name => p_resp_name ); -- Ex: BR INV ANGELICA Super Usuario
    END IF;
    -- --------------- --
    -- ID da Transacao --
    -- --------------- --
    BEGIN
      SELECT mtt.transaction_type_id
        INTO l_nTransaction_type_id
        FROM apps.mtl_transaction_types mtt
       WHERE UPPER(mtt.transaction_type_name) = 'RETIRADA PARA CONSUMO GATEC';
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'ERRO.: Erro ao consultar transacao "Retirada para Consumo GATEC" em MTL_TRANSACTION_TYPES - ' || SQLERRM;
        log_email_p (p_errbuf);
        RAISE_APPLICATION_ERROR(-20030, p_errbuf);
    END;
    --
    FOR r_1 IN c_1 LOOP
      -- -------------------------- --
      -- Recupera o ORGANIZATION_ID --
      -- -------------------------- --
      BEGIN
        SELECT msi.organization_id
          INTO l_nOrganization_id
          FROM apps.mtl_system_items_b msi
             , apps.mtl_parameters     mp
         WHERE msi.organization_id    = mp.organization_id
           AND msi.attribute_category = 'BR'
           AND mp.organization_code   = r_1.org_inventario -- ANG, IVN, UMA, etc.
           AND msi.segment1           = r_1.mat_codigo;    -- Cod Item
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_nOrganization_id := NULL;
          p_retcode  := 1; -- Termina concurrent com ADVERTENCIA, mas NAO para o processo.
          p_errbuf   := 'ERRO.: ORGANIZATION_ID nao encontrado para NUM_DOCUM = ' || r_1.num_docum || ', ORG_INVENTARIO = ' || r_1.org_inventario || ' e ITEM = ' || r_1.mat_codigo || ' - ' || SQLERRM;
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop; -- Avanca para o proximo registro
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar ORGANIZATION_ID para NUM_DOCUM = ' || r_1.num_docum || ', ORG_INVENTARIO = ' || r_1.org_inventario || ' e ITEM = ' || r_1.mat_codigo || ' - ' || SQLERRM;
          log_email_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20040, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- ------------- --
      -- Dados do item -- -- > continuar
      -- ------------- --
      BEGIN
        SELECT msi.inventory_item_id
              ,msi.primary_uom_code
              ,msi.lot_control_code      -- Lot control code                  --> Item >> Lote >> Controlar >> Contr. Total = 2
              ,msi.auto_lot_alpha_prefix -- Item-level prefix for lot numbers --> Item >> Lote >> Prefixo Inicial ex: L
              ,msi.start_auto_lot_number -- Next auto assigned lot number     --> Item >> Lote >> NÃ?Âºmero Inicial  ex: 1
          INTO l_nInventory_item_id
              ,l_vUDM
              ,l_nControle_Lote
              ,l_vPrefixo_Inicial
              ,l_vNumero_Inicial
          FROM mtl_system_items_b msi
         WHERE msi.organization_id = l_nOrganization_id
           AND msi.segment1        = r_1.mat_codigo;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_nInventory_item_id := NULL;
          l_vUDM               := NULL;
          l_nControle_Lote     := NULL;
          l_vPrefixo_Inicial   := NULL;
          l_vNumero_Inicial    := NULL;
          p_retcode  := 1;
          p_errbuf   := 'ERRO.: Dados do item nao encontrados, NUM_DOCUM = ' || r_1.num_docum || ', ORGANIZATION_ID = ' || l_nOrganization_id || ' e ITEM = ' || r_1.mat_codigo || ' - ' || SQLERRM;
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consular dados do item, NUM_DOCUM = ' || r_1.num_docum || ', ORGANIZATION_ID = ' || l_nOrganization_id || ' e ITEM = ' || r_1.mat_codigo || ' - ' || SQLERRM;
          log_email_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20050, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- ---------------------------------------------------------------------------- --
      -- Rafael S. Nunes (Ninecon -- #584# -- 25/05/2018                              --
      -- Recupera o Cod_Depos (SUBINVENTORY_CODE) atraves do Cod_Ponto vindo do Gatec --
      -- ---------------------------------------------------------------------------- --
      BEGIN
        SELECT msl.subinventory_code
              --,mil.inventory_location_id
          INTO l_vSubinventory_code
              --,l_vInventory_location_id
          FROM apps.mtl_secondary_locators_all_v msl
              ,apps.mtl_item_locations           mil
         WHERE msl.secondary_locator    = mil.inventory_location_id
           AND msl.organization_id      = mil.organization_id
           AND msl.organization_id      = l_nOrganization_id
           AND msl.inventory_item_id    = l_nInventory_item_id
           AND SUBSTR(mil.segment1,5,4) = TO_CHAR(r_1.cod_ponto) -- 2313 (cod_ponto)
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          p_retcode := 1; -- Advertencia
          p_errbuf  := 'ERRO.: Cod. Deposito (SUBINVENTORY_CODE) nao encontrado: ' ||CHR(13)||
                       --'       COD_REQUISICAO.....: ' || r_l.cod_requisicao    ||CHR(13)||
                       --'       l_nOrganization_id.: ' || l_nOrganization_id    ||CHR(13)||
                       --'       INVENTORY_ITEM_ID..: ' || l_nInventory_item_id  ||CHR(13)||
                       --'       COD_PONTO (Gatec)..: ' || TO_CHAR(r_1.cod_ponto)||CHR(13);
                       '       ORGANIZATION_ID: '   || l_nOrganization_id   ||CHR(13)||
                       '       ITEM: '              || r_1.mat_codigo       ||CHR(13)||
                       '       INVENTORY_ITEM_ID: ' || l_nInventory_item_id ||CHR(13)||
                       '       COD_PONTO (Gatec): ' || r_1.cod_ponto        ||CHR(13)||
                       '       COD_DEPOS (Gatec): ' || r_1.cod_depos        ||CHR(13)||
                       '       NUM_DOCUM: '         || r_1.num_docum        ||CHR(13)||CHR(13);
          print_msg_p(p_errbuf);
          log_email_p(p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := 1; -- Advertencia
          p_errbuf  := 'ERRO.: Ao consultar Cod. Deposito (SUBINVENTORY_CODE): ' ||CHR(13)||
                       '       l_nOrganization_id.: ' || l_nOrganization_id      ||CHR(13)||
                       '       INVENTORY_ITEM_ID..: ' || l_nInventory_item_id    ||CHR(13)||
                       '       COD_PONTO (Gatec)..: ' || TO_CHAR(r_1.cod_ponto)  ||CHR(13)||
                       '       ' || SQLERRM;
          print_msg_p(p_errbuf);
          log_email_p(p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
      END;
      -- ---------------------------------------------------------------------- --
      -- Valida subinventario do item. A API faz essa validacao mas nao retorna --
      -- os detalhes no log, dificultando a identificacao para correcao do erro.--
      -- ---------------------------------------------------------------------- --
      BEGIN
        SELECT COUNT(1)
          INTO l_nCt
          FROM apps.mtl_item_sub_inventories_all_v misv
         WHERE 1=1
           --AND misv.inventory_planning_code  IN (2, 6) -- ???  confirmar se sera necessario!!!
           AND misv.secondary_inventory LIKE r_1.cod_depos||'%'
           AND misv.organization_id     = l_nOrganization_id
           AND misv.inventory_item_id   = l_nInventory_item_id;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          --p_errbuf  := 'ERRO.: Ao validar subinventario/deposito, NUM_DOCUM = ' || r_1.num_docum || ', ITEM = ' || r_1.mat_codigo || ', COD_DEPOS = ' || r_1.cod_depos || ' - ' || SQLERRM;
          p_errbuf  := 'ERRO.: Ao validar subinventario/deposito: ' ||CHR(13)||
                       '       ORGANIZATION_ID: '   || l_nOrganization_id   ||CHR(13)||
                       '       ITEM: '              || r_1.mat_codigo       ||CHR(13)||
                       '       INVENTORY_ITEM_ID: ' || l_nInventory_item_id ||CHR(13)||
                       '       COD_PONTO (Gatec): ' || r_1.cod_ponto        ||CHR(13)||
                       '       COD_DEPOS (Gatec): ' || r_1.cod_depos        ||CHR(13)||
                       '       NUM_DOCUM: '         || r_1.num_docum        ||CHR(13)||
                       '      ' || SQLERRM ||CHR(13)||CHR(13);
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20060, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      --
      IF l_nCt = 0 THEN
        p_retcode := 1; -- Termina concurrent com ADVERTENCIA, mas NAO para o processo.
        --p_errbuf  := 'ERRO.: Subinventario ' || r_1.cod_depos || ' invalido ou nao cadastrado para o item ' || r_1.mat_codigo || ', NUM_DOCUM = ' || r_1.num_docum || CHR(13) || CHR(13);
        p_errbuf  := 'ERRO.: Subinventario ' || r_1.cod_depos || ' invalido ou nao cadastrado para o item: ' ||CHR(13)||
                     '       ORGANIZATION_ID: '   || l_nOrganization_id   ||CHR(13)||
                     '       ITEM: '              || r_1.mat_codigo       ||CHR(13)||
                     '       INVENTORY_ITEM_ID: ' || l_nInventory_item_id ||CHR(13)||
                     '       COD_PONTO (Gatec): ' || r_1.cod_ponto        ||CHR(13)||
                     '       COD_DEPOS (Gatec): ' || r_1.cod_depos        ||CHR(13)||
                     '       NUM_DOCUM: '         || r_1.num_docum        ||CHR(13)||CHR(13);
        print_msg_p (p_errbuf);
        log_email_p (p_errbuf);
        l_nTot_NOK := l_nTot_NOK + 1;
        --GOTO end_loop;
      END IF;
      -- ------------------------------------------------------------------------ --
      -- Para fazer o ajuste, e necessario que tenha  sido criado anteriormente a --
      -- Ordem de Movimentacao de Transferencia (Move Order Transfer), feita pela --
      -- package XX_MOVE_ORDER_GATEC_PKG para atender a baixa que sera feita.     --
      -- Se nao houver Ordem de Movimentacao previa entao exibe mensagem no log e --
      -- avanca para o proximo registro.                                          --
      -- *** Verificar a necessidade desta validacao em seguida                   --
      -- ------------------------------------------------------------------------ --
      /*BEGIN
        SELECT xrgb.integra
              ,xrgb.num_req_ora
          INTO l_nIntegra
              ,l_nNum_Req_Ora
          FROM xx_req_gatec_br xrgb
         WHERE xrgb.cod_empr           = r_1.cod_empr
           AND xrgb.saf_ano_safra      = r_1.saf_ano_safra
           AND xrgb.cod_os             = r_1.num_os
           --AND xrgb.cod_requisicao     = '587822'
           --AND xrgb.req_seq_requisicao = '1'
           AND xrgb.cod_mater          = r_1.mat_codigo
           AND xrgb.req_tipo           = 'T' -- Transferencia TRLO
           AND rownum                  = 1;  -- Limita em apenas uma linha apenas para verificar a existencia da Move Order e evitar a excecao TOO_MANY_ROWS
       \* SELECT COUNT(1)
          FROM apps.mtl_txn_request_headers_v mtrhv
         WHERE mtrhv.organization_id       = l_nOrganization_id
           AND mtrhv.transaction_type_name = 'Move Order Issue' -- Retirada
           -- Funcao para pegar apenas os nÃ?Âºmeros de requisicao que sao gravados no campo "Descricao"
           AND LTRIM(TRANSLATE(mtrhv.description, TRANSLATE(mtrhv.description, '1234567890', ' ') , ' ')) = 587831;*\
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          p_retcode := 1;
          p_errbuf  := 'ERRO.: Nao foi encontrada Ordem de Movimentacao de Transfencia (Move Order Transfer) para atender esta solicitacao!' ||CHR(13)||
                       '       NUM_DOCUM.......: ' || r_1.num_docum  ||CHR(13)||
                       '       COD_EMPR(Gatec).: ' || r_1.cod_empr   ||CHR(13)||
                       '       OS..............: ' || r_1.num_os     ||CHR(13)||
                       --'       ITEM............: ' || r_1.mat_codigo ||CHR(13)|| SQLERRM || CHR(13) || CHR(13) ;
                       '       ITEM............: ' || r_1.mat_codigo ||CHR(13)|| CHR(13);
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop; -- Avanca para o proximo registro
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar Ordem de Movimentacao de Transferencia (Move Order Transfer) para atender esta solicitacao!' ||CHR(13)||
                       '       NUM_DOCUM.......: ' || r_1.num_docum  ||CHR(13)||
                       '       COD_EMPR(Gatec).: ' || r_1.cod_empr   ||CHR(13)||
                       '       OS..............: ' || r_1.num_os     ||CHR(13)||
                       '       ITEM............: ' || r_1.mat_codigo ||CHR(13)|| SQLERRM;
          log_email_p (p_errbuf);
          RAISE_APPLICATION_ERROR(-20070, p_errbuf);
      END;*/
      -- -------------------------------------------------------------------------------------------- --
      -- Se encontrou o registro na tabela XX_REQ_GATEC_BR, mas o flag INTEGRA = 0, e ainda nao foi   --
      -- gerada a Ordem de Movimentacao (NUM_REQ_ORA = NULL) entao o registro ja esta na tabela para  --
      -- ser criada a Move Order mas ainda nao foi processado e nao podera realizar a baixa do item.  --
      -- Etapas:                                                                                      --
      -- 1. Criar a Ordem de Movimentacao de Transferencia TRLO (Move Order Transfer) pelo concurrent --
      --    "XX INV Criar Ordem de Movimentacao (Transf. de Estoque) - TRLO GATEC"                    --
      -- 2. Executar este processo para efetuar a baixa do item no deposito destino (este processo).  --
      -- -------------------------------------------------------------------------------------------- --
      /*IF l_nIntegra < 1 AND l_nNum_Req_Ora IS NULL THEN
        p_retcode := 1;
        p_errbuf  := 'AVISO: A Ordem de Movimentacao de Transfencia (Move Order Transfer) ainda nao foi processada para atender esta solicitacao!' ||CHR(13)||
                     '       Execute o programa "XX INV Criar Ordem de Movimentacao (Transf. de Estoque) - TRLO GATEC"' ||CHR(13)||
                     '       NUM_DOCUM.....: ' || r_1.num_docum     ||CHR(13)||
                     '       SAF_ANO_SAFRA.: ' || r_1.saf_ano_safra ||CHR(13)||
                     '       COD_EMPR......: ' || r_1.cod_empr      ||CHR(13)||
                     '       COD_OS........: ' || r_1.num_os        ||CHR(13)||
                     '       ITEM..........: ' || r_1.mat_codigo    ||CHR(13);
        print_msg_p (p_errbuf);
        log_email_p (p_errbuf);
        l_nTot_NOK := l_nTot_NOK + 1;
        GOTO end_loop; -- Avanca para o proximo registro
      END IF;*/
      -- ---------------------------------- --
      -- Cod. Motivo (pelo Centro de Custo) --
      -- ---------------------------------- --
      BEGIN
        SELECT mtr.reason_id
          INTO l_nReason_id
          --FROM apps.xx_depara_req_inter     dp
          FROM bolinf.xx_depara_req_inter   dp -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020 -- Retornado o owner original da tabela.
              ,apps.mtl_transaction_reasons mtr
         WHERE dp.cod_motivo = mtr.reason_name
           --AND dp.cc         = r_1.cod_centr_custo -- Ex: 3005, 3008, etc
           AND dp.cod_motivo   = r_1.cod_motivo    -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020
           AND dp.cod_processo = r_1.cod_processo; -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020 
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_nReason_id := NULL;
          p_retcode  := 1;
          p_errbuf   := 'ERRO.: Cod. Motivo nao encontrado para o Item:'    ||CHR(13)||
                        '       NUM_DOCUM........: ' || r_1.num_docum       ||CHR(13)||
                        '       ITEM(Mat_Codigo).: ' || r_1.mat_codigo      ||CHR(13)||
                        '       COD_CENTR_CUSTO..: ' || r_1.cod_centr_custo ||CHR(13)|| 
                        '       COD_PROCESSO.....: ' || r_1.cod_processo    ||CHR(13)|| SQLERRM; -- Rafael S. Nunes (Ninecon) -- SD 115062 -- Abr/2020
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar Cod. Motivo para o Item:'      ||CHR(13)||
                       '       NUM_DOCUM........: ' || r_1.num_docum       ||CHR(13)||
                       '       ITEM(Mat_Codigo).: ' || r_1.mat_codigo      ||CHR(13)||
                       '       COD_CENTR_CUSTO..: ' || r_1.cod_centr_custo ||CHR(13)|| SQLERRM || CHR(10);
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20080, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- --------------------- --
      -- Obter ORGANIZATION_ID --
      -- --------------------- --
      /*BEGIN
        SELECT ood.organization_id
          INTO l_nOrganization_id
          FROM apps.org_organization_definitions ood
              ,apps.hr_organization_units        hou
         WHERE hou.organization_id   = ood.operating_unit
           AND ood.operating_unit    = r_1.org_id          -- 110, 196, etc
           AND ood.organization_code = r_1.org_inventario; -- ANG, IVN, etc
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_nOrganization_id := NULL;
          p_retcode  := 1;
          p_errbuf   := 'ERRO.: ORGANIZATION_ID nao encontrado:' ||CHR(13)||
                        '       NUM_DOCUM......: ' || r_1.num_docum       ||CHR(13)||
                        '       ORG_ID.........: ' || r_1.org_id          ||CHR(13)||
                        '       ORG_INVENTARIO.: ' || r_1.org_inventario  ||CHR(13)|| SQLERRM;
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar ORGANIZATION_ID:'   ||CHR(13)||
                       '       NUM_DOCUM......: ' || r_1.num_docum       ||CHR(13)||
                       '       ORG_ID.........: ' || r_1.org_id          ||CHR(13)||
                       '       ORG_INVENTARIO.: ' || r_1.org_inventario  ||CHR(13)|| SQLERRM;
          RAISE_APPLICATION_ERROR(-20090, p_errbuf);
      END;*/
      -- ----------------- --
      -- Conta de Material --
      -- ----------------- --
      BEGIN
        SELECT mp.material_account
          INTO l_nMaterial_Account
          FROM apps.mtl_parameters mp
         WHERE mp.organization_id   = l_nOrganization_id
           AND mp.organization_code = r_1.org_inventario;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_nMaterial_Account := NULL;
          p_retcode  := 1;
          p_errbuf   := 'ERRO.: Conta de Material (MATERIAL_ACCOUNT) nao encontrada:' ||CHR(13)||
                        '       NUM_DOCUM.......: ' || r_1.num_docum      ||CHR(13)||
                        '       ORGANIZATION_ID.: ' || l_nOrganization_id ||CHR(13)||
                        '       ORG_INVENTARIO..: ' || r_1.org_inventario ||CHR(13)|| SQLERRM;
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar Conta de Material (MATERIAL_ACCOUNT):'||CHR(13)||
                       '       NUM_DOCUM.......: ' || r_1.num_docum      ||CHR(13)||
                       '       ORGANIZATION_ID.: ' || l_nOrganization_id ||CHR(13)||
                       '       ORG_INVENTARIO..: ' || r_1.org_inventario ||CHR(13)|| SQLERRM;
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20100, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- ----------------------------------------------------- --
      -- Recupera o codigo do endereco (INVENTORY_LOCATION_ID) --
      -- para atribuir ao campo Endereco (aba Local)           --
      -- ----------------------------------------------------- --
      BEGIN
        SELECT mil.inventory_location_id
          INTO l_vInventory_location_id
          FROM apps.mtl_item_locations mil
         WHERE mil.organization_id = l_nOrganization_id      -- Ex: 1666
           AND SUBSTR(mil.segment1,5,4) = TO_CHAR(r_1.cod_ponto); -- Ex: 2004,2005,2006,2008,2009, etc --> Local -- Gatec envia, ex: "2006", mas no EBS esta cadastrado "ANG-2006", considerar apenas os digitos finais
           --AND mil.segment1        LIKE '%'||r_1.cod_ponto||'%';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_vInventory_location_id := NULL;
          p_retcode := 1;
          p_errbuf  := 'ERRO.: Cod. endereco (INVENTORY_LOCATION_ID) nao encontrado:' ||CHR(13)||
                       --'       NUM_DOCUM...........: ' || r_1.num_docum      ||CHR(13)||
                       --'       ORGANIZATION_ID.....: ' || l_nOrganization_id ||CHR(13)||
                       --'       COD_PONTO(Endereco).: ' || r_1.cod_ponto      ||CHR(13)|| SQLERRM;
                       '       ORGANIZATION_ID: '      || l_nOrganization_id   ||CHR(13)||
                       '       ITEM: '                 || r_1.mat_codigo       ||CHR(13)||
                       '       INVENTORY_ITEM_ID: '    || l_nInventory_item_id ||CHR(13)||
                       '       COD_PONTO (Gatec): '    || r_1.cod_ponto        ||CHR(13)||
                       '       COD_DEPOS (Gatec): '    || r_1.cod_depos        ||CHR(13)||
                       '       NUM_DOCUM: '            || r_1.num_docum        ||CHR(13)||CHR(13);
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar Cod. endereco (INVENTORY_LOCATION_ID):'||CHR(13)||
                       --'       ORGANIZATION_ID.....: ' || l_nOrganization_id       ||CHR(13)||
                       --'       COD_PONTO(Endereco).: ' || r_1.cod_ponto            ||CHR(13)||
                       --'       NUM_DOCUM...........: ' || r_1.num_docum      ||CHR(13)|| SQLERRM;
                       '       ORGANIZATION_ID: '      || l_nOrganization_id   ||CHR(13)||
                       '       ITEM: '                 || r_1.mat_codigo       ||CHR(13)||
                       '       INVENTORY_ITEM_ID: '    || l_nInventory_item_id ||CHR(13)||
                       '       COD_PONTO (Gatec): '    || r_1.cod_ponto        ||CHR(13)||
                       '       COD_DEPOS (Gatec): '    || r_1.cod_depos        ||CHR(13)||
                       '       NUM_DOCUM: '            || r_1.num_docum        ||CHR(13)||
                       '      ' ||SQLERRM||CHR(13)||CHR(13);
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20110, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- ------------------------------------------------------------------------------------------
      -- Valida se o endereco esta associado ao item, se nao estiver, faca o setup abaixo:       --
      -- BR INV XXX Super usuario >> Setup >> Organizacoes >>                                    --
      --   Subinventarios >> botao Item/Subinventario >> selecione o subinventario >> pesquise o --
      --   item e adicione o endereco no bloco "Enderecos para este Subinvent. do Item".         --
      -- ------------------------------------------------------------------------------------------
      BEGIN
        SELECT COUNT(1)
          INTO l_nCt
          FROM apps.mtl_secondary_locators_all_v msl
              ,apps.mtl_item_locations           mil
         WHERE msl.secondary_locator = mil.inventory_location_id
           AND msl.organization_id   = mil.organization_id
           AND msl.organization_id   = l_nOrganization_id -- 1666
           AND msl.subinventory_code LIKE r_1.cod_depos||'%'      -- ANG-DEP18
           AND msl.inventory_item_id = l_nInventory_item_id
           --AND mil.segment1          LIKE '%'||r_1.cod_ponto||'%';  -- 2006
           AND SUBSTR(mil.segment1,5,4) = TO_CHAR(r_1.cod_ponto); -- Ex: 2004,2005,2006,2008,2009, etc --> Local -- Gatec envia, ex: "2006", mas no EBS esta cadastrado "ANG-2006", considerar apenas os digitos finais
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar o "Endereco para este Subinvent. do Item:"' ||CHR(13)||
                       '       NUM_DOCUM...........: ' || r_1.num_docum        ||CHR(13)||
                       '       ORGANIZATION_ID.....: ' || l_nOrganization_id   ||CHR(13)||
                       '       COD_DEPOS (Gatec)...: ' || r_1.cod_depos        ||CHR(13)||
                       '       ITEM................: ' || r_1.mat_codigo       ||CHR(13)||
                       '       INVENTORY_ITEM_ID...: ' || l_nInventory_item_id ||CHR(13)||
                       '       COD_PONTO (Gatec)...: ' || r_1.cod_ponto        ||CHR(13)|| SQLERRM;
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20120, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      --
      IF l_nCt = 0 THEN
        p_retcode := 1; -- Termina concurrent com ADVERTENCIA, mas NAO para o processo.
        p_errbuf  := 'ERRO.: O "Endereco para este Subinvent. do Item" nao esta associado ao item, verifique.' ||CHR(13)||
                     --'       BR INV XXX Super usuario >> Setup >> OrganizacÃ?Âµes >> Subinventarios >> Item/Subinventario >> adicione o endereco no bloco "Enderecos para este Subinvent. do Item". ' ||CHR(13)||
                     --'       ORGANIZATION_ID.....: ' || l_nOrganization_id   ||CHR(13)||
                     '       NUM_DOCUM...........: ' || r_1.num_docum        ||CHR(13)||
                     '       ORGANIZATION_ID.....: ' || l_nOrganization_id   ||CHR(13)||
                     '       COD_DEPOS (Gatec)...: ' || r_1.cod_depos        ||CHR(13)||
                     '       ITEM................: ' || r_1.mat_codigo       ||CHR(13)||
                     '       INVENTORY_ITEM_ID...: ' || l_nInventory_item_id ||CHR(13)||
                     '       COD_PONTO (Gatec)...: ' || r_1.cod_ponto        ||CHR(13)||CHR(13);
        print_msg_p (p_errbuf);
        log_email_p (p_errbuf);
        l_nTot_NOK := l_nTot_NOK + 1;
        GOTO end_loop;
      END IF;
      --
      -- Rafael S. Nunes (Ninecon -- #584# -- 25/05/2018
      -- Recupera o Cod_Depos (SUBINVENTORY_CODE) atraves do Cod_Ponto vindo do Gatec
      /*BEGIN
        SELECT msl.subinventory_code
              --,mil.inventory_location_id
          INTO l_vSubinventory_code
              --,l_vInventory_location_id
          FROM apps.mtl_secondary_locators_all_v msl
              ,apps.mtl_item_locations           mil
         WHERE msl.secondary_locator    = mil.inventory_location_id
           AND msl.organization_id      = mil.organization_id
           AND msl.organization_id      = l_nOrganization_id
           AND msl.inventory_item_id    = l_nInventory_item_id
           AND SUBSTR(mil.segment1,5,4) = TO_CHAR(r_1.cod_ponto) -- 2313 (cod_ponto)
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          p_retcode := 1; -- Advertencia
          p_errbuf  := 'ERRO.: Cod. Deposito (SUBINVENTORY_CODE) nao encontrado: ' ||CHR(13)||
                       --'       COD_REQUISICAO.....: ' || r_l.cod_requisicao    ||CHR(13)||
                       --'       l_nOrganization_id.: ' || l_nOrganization_id    ||CHR(13)||
                       --'       INVENTORY_ITEM_ID..: ' || l_nInventory_item_id  ||CHR(13)||
                       --'       COD_PONTO (Gatec)..: ' || TO_CHAR(r_1.cod_ponto)||CHR(13);
                       '       ORGANIZATION_ID: '   || l_nOrganization_id   ||CHR(13)||
                       '       ITEM: '              || r_1.mat_codigo       ||CHR(13)||
                       '       INVENTORY_ITEM_ID: ' || l_nInventory_item_id ||CHR(13)||
                       '       COD_PONTO (Gatec): ' || r_1.cod_ponto        ||CHR(13)||
                       '       COD_DEPOS (Gatec): ' || r_1.cod_depos        ||CHR(13)||
                       '       NUM_DOCUM: '         || r_1.num_docum        ||CHR(13)||CHR(13);
          print_msg_p(p_errbuf);
          log_email_p(p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
        WHEN OTHERS THEN
          p_retcode := 1; -- Advertencia
          p_errbuf  := 'ERRO.: Ao consultar Cod. Deposito (SUBINVENTORY_CODE): ' ||CHR(13)||
                       '       l_nOrganization_id.: ' || l_nOrganization_id      ||CHR(13)||
                       '       INVENTORY_ITEM_ID..: ' || l_nInventory_item_id    ||CHR(13)||
                       '       COD_PONTO (Gatec)..: ' || TO_CHAR(r_1.cod_ponto)  ||CHR(13)||
                       '       ' || SQLERRM;
          print_msg_p(p_errbuf);
          log_email_p(p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop;
      END;*/
      --
      IF l_nControle_Lote = 2 THEN -- Se o item possuir controle de lote, devera recuperar o nro do lote da transacao de movimentacao
        BEGIN
          SELECT lote.lot_number
            INTO l_vLot_Number
            FROM apps.mtl_material_transactions mmt
                ,apps.mtl_transaction_lot_val_v lote
                ,apps.mtl_transaction_types     mtt
           WHERE mmt.transaction_id        = lote.transaction_id      -- JOIN com lotes
             AND mmt.transaction_type_id   = mtt.transaction_type_id  -- JOIN com tipo de transacao
             AND mmt.inventory_item_id     = l_nInventory_item_id
             AND mmt.organization_id       = l_nOrganization_id
             --AND mmt.subinventory_code     = r_1.cod_depos
             --AND mmt.subinventory_code     LIKE r_1.cod_depos||'%'
             AND mmt.subinventory_code     = l_vSubinventory_code -- Rafael S. Nunes (Ninecon) -- 584 -- Mai/2018
             AND mmt.locator_id            = l_vInventory_location_id
             --AND mtt.transaction_type_name = 'Move Order Transfer' -- Rafael S. Nunes (Ninecon) -- 584 -- Mai/2018 -- comentado
             AND mmt.transaction_quantity  > 0  -- Movimentacao positiva, indica que a transacao de movimentacao e transferencia para o deposito que recebeu o item
             --AND mmt.transaction_date      = (SELECT MAX(mmt2.transaction_date)
             --AND rownum = 1
             AND mmt.creation_date         = (SELECT MAX(mmt2.creation_date)
                                                FROM apps.mtl_material_transactions mmt2
                                                    ,apps.mtl_transaction_types     mtt2
                                               WHERE mmt2.transaction_type_id   = mtt2.transaction_type_id -- JOIN com tipo de transacao
                                                 AND mmt2.inventory_item_id     = l_nInventory_item_id
                                                 AND mmt2.organization_id       = l_nOrganization_id
                                                 --AND mmt2.subinventory_code     LIKE r_1.cod_depos||'%'
                                                 AND mmt2.subinventory_code     = l_vSubinventory_code -- Rafael S. Nunes (Ninecon) -- 584 -- Mai/2018
                                                 AND mmt2.locator_id            = l_vInventory_location_id
                                                 --AND rownum = 1
                                                 --AND mtt2.transaction_type_name = 'Move Order Transfer' -- Rafael S. Nunes (Ninecon) -- 584 -- Mai/2018 -- comentado
                                                 AND mmt2.transaction_quantity  > 0
                                               GROUP BY 1) -- Rafael S. Nunes (Ninecon) -- 102600 -- Mai/2018
           GROUP BY lote.lot_number; -- Rafael S. Nunes (Ninecon) -- 102600 -- Mai/2018
        EXCEPTION
          WHEN no_data_found THEN
            l_vLot_Number := NULL;
            p_retcode := 1;
            p_errbuf  := 'AVISO: Lote da transacao nao encontrado para atender esta solicitacao!' ||CHR(13)||
                         '       Efetue a transacao do material e informe o lote.'               ||CHR(13)||
                         '       NUM_DOCUM.........: ' || r_1.num_docum            ||CHR(13)||
                         '       SAF_ANO_SAFRA.....: ' || r_1.saf_ano_safra        ||CHR(13)||
                         '       COD_EMPR..........: ' || r_1.cod_empr             ||CHR(13)||
                         '       COD_OS............: ' || r_1.num_os               ||CHR(13)||
                         '       ITEM..............: ' || r_1.mat_codigo           ||CHR(13)||
                         '       INVENTORY_ITEM_ID.: ' || l_nInventory_item_id     ||CHR(13)||
                         '       ORGANIZATION_ID...: ' || l_nOrganization_id       ||CHR(13)||
                         '       COD_DEPOS (Gatec).: ' || r_1.cod_depos            ||CHR(13)||
                         '       COD_PONTO (Gatec).: ' || r_1.cod_ponto            ||CHR(13)||
                         '       LOCATOR_ID........: ' || l_vInventory_location_id ||CHR(13)||CHR(13);
          print_msg_p (p_errbuf);
          log_email_p (p_errbuf);
          l_nTot_NOK := l_nTot_NOK + 1;
          GOTO end_loop; -- Avanca para o proximo registro
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Ao consultar o Lote da transacao. '               ||CHR(13)||
                       '       NUM_DOCUM.........: ' || r_1.num_docum            ||CHR(13)||
                       '       SAF_ANO_SAFRA.....: ' || r_1.saf_ano_safra        ||CHR(13)||
                       '       COD_EMPR..........: ' || r_1.cod_empr             ||CHR(13)||
                       '       COD_OS............: ' || r_1.num_os               ||CHR(13)||
                       '       ITEM..............: ' || r_1.mat_codigo           ||CHR(13)||
                       '       INVENTORY_ITEM_ID.: ' || l_nInventory_item_id     ||CHR(13)||
                       '       ORGANIZATION_ID...: ' || l_nOrganization_id       ||CHR(13)||
                       '       COD_DEPOS.........: ' || r_1.cod_depos            ||CHR(13)||
                       '       LOCATOR_ID........: ' || l_vInventory_location_id ||CHR(13)|| SQLERRM;
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20130, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
        END;
      END IF;
      -- -------------------------------------------------- --
      -- Gera id para popular o campo TRANSACTION_INTERFACE_ID
      -- -------------------------------------------------- --
      BEGIN
        SELECT mtl_material_transactions_s.NEXTVAL
          INTO l_nTransaction_interface_id
          FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Erro ao gerar valor para a sequence MTL_MATERIAL_TRANSACTIONS_S - ' || SQLERRM;
          log_email_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20140, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- ---------------------------------------------------------- --
      -- Gera id para popular o campo TRANSACTION_HEADER_ID,        --
      -- este ID sera gerado apenas uma vez para cada processamento --
      -- ---------------------------------------------------------- --
      IF NVL(l_nCt_Rec,0) = 0 THEN
        BEGIN
          SELECT apps.transaction_header_id_s.NEXTVAL
            INTO l_transaction_header_id_ex
            FROM dual;
        EXCEPTION
          WHEN OTHERS THEN
            p_retcode := -2;
            p_errbuf  := 'ERRO.: Erro ao gerar valor para a sequence TRANSACTION_HEADER_ID_S - ' || SQLERRM;
            log_email_p (p_errbuf);
            print_msg_p (p_errbuf);
            --RAISE_APPLICATION_ERROR(-20150, p_errbuf);
            GOTO end_loop; -- Avanca para o proximo registro
        END;
      END IF;
      --
      BEGIN
        INSERT
          INTO mtl_transactions_interface ( transaction_interface_id            -- 1
                                           ,transaction_header_id               -- 2
                                           ,source_code                         -- 3
                                           ,source_line_id                      -- 4
                                           ,source_header_id                    -- 5
                                           ,process_flag                        -- 6
                                           ,validation_required                 -- 7
                                           ,transaction_mode                    -- 8
                                           ,lock_flag                           -- 9
                                           ,last_update_date                    -- 10
                                           ,last_updated_by                     -- 11
                                           ,creation_date                       -- 12
                                           ,created_by                          -- 13
                                           ,inventory_item_id                   -- 14
                                           ,organization_id                     -- 15
                                           ,transaction_quantity                -- 16
                                           ,transaction_uom                     -- 17
                                           ,transaction_date                    -- 18
                                           ,subinventory_code                   -- 19
                                           ,locator_id                          -- 20
                                           ,transaction_type_id                 -- 21
                                           ,flow_schedule                       -- 22
                                           ,scheduled_flag                      -- 23
                                           ,reason_id                           -- 24
                                           ,material_account                    -- 25
                                           ,distribution_account_id             -- 26
                                           ,attribute_category                  -- 27
                                           ,transaction_reference)              -- 28
                                    VALUES( l_nTransaction_interface_id         -- 1 TRANSACTION_INTERFACE_ID
                                           ,l_transaction_header_id_ex          -- 2 TRANSACTION_HEADER_ID
                                           ,'GATEC'                             -- 3 SOURCE_CODE
                                           ,1                                   -- 4 SOURCE_LINE_ID
                                           ,1                                   -- 5 SOURCE_HEADER_ID
                                           ,1                                   -- 6 PROCESS_FLAG     --> Flag indicating whether transaction is ready to be processed by the Transaction Manager or Worker ('1' for ready, '2' for not ready); if the transaction fails for some reason, the Transaction Worker sets the value of PROCESS_FLAG to '3'
                                           ,1                                   -- 7 VALIDATION_REQUIRED
                                           ,3                                   -- 8 TRANSACTION_MODE --> Code that indicates whether the transaction is to be processed in immediate concurrent processing mode (2) or background processing mode (3)
                                           ,2                                   -- 9 LOCK_FLAG        --> Flag indicating whether the transaction is locked by the Transaction Manager or Workers ('1' for locked, '2' or NULL for not locked); this prevents two different Workers from processing the same transaction; You should always specify '2'
                                           ,SYSDATE                             -- 10 LAST_UPDATE_DATE
                                           ,fnd_global.user_id                  -- 11 LAST_UPDATED_BY
                                           ,SYSDATE                             -- 12 CREATION_DATE
                                           ,fnd_global.user_id                  -- 13 CREATED_BY
                                           ,l_nInventory_item_id                -- 14 INVENTORY_ITEM_ID
                                           ,l_nOrganization_id                  -- 15 ORGANIZATION_ID
                                           ,r_1.qtd_material                    -- 16 TRANSACTION_QUANTITY
                                           ,l_vUDM                              -- 17 TRANSACTION_UOM
                                           ,SYSDATE                             -- 18 TRANSACTION_DATE
                                           --,r_1.cod_depos                       -- 19 SUBINVENTORY_CODE
                                           ,l_vSubinventory_code                -- 19 SUBINVENTORY_CODE -- Rafael S. Nunes (Ninecon) -- 584 -- Mai/2018
                                           ,l_vInventory_location_id            -- 20 LOCATOR_ID
                                           ,l_nTransaction_type_id              -- 21 TRANSACTION_TYPE_ID
                                           ,'Y'                                 -- 22 FLOW_SCHEDULE
                                           ,2                                   -- 23 SCHEDULED_FLAG
                                           ,l_nReason_id                        -- 24 REASON_ID
                                           ,l_nMaterial_Account                 -- 25 MATERIAL_ACCOUNT
                                           ,l_nMaterial_Account                 -- 26 DISTRIBUTION_ACCOUNT_ID
                                           ,'BR'                                -- 27 ATTRIBUTE_CATEGORY
                                           ,r_1.num_os);                        -- 28 TRANSACTION_REFERENCE
        l_nCt_Intf := l_nCt_Intf + SQL%ROWCOUNT;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Erro ao inserir registro na tabela MTL_TRANSACTIONS_INTERFACE - ' || SQLERRM;
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20160, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- --------------------------------------------------------------------------------- --
      -- Indica envio para a interface do INV, mas NÃ??O indica que a API processou com      --
      -- sucesso  pois  esta  API  nao  tem  um  retorno exclusivo para cada linha do      --
      -- processamento caso tenha erro, o registro devera ser corrigo na interface do INV. --                                                                         --
      -- --------------------------------------------------------------------------------- --
      BEGIN
        UPDATE xx_gatec_mov_insum
           SET status            = 'S'
              ,last_update_date  = SYSDATE
              ,last_updated_by   = FND_GLOBAL.USER_ID
              ,last_update_login = FND_GLOBAL.LOGIN_ID
         --WHERE CURRENT OF c_1;
         WHERE mov_id = r_1.mov_id;
        --
        COMMIT; -- Manter commit no codigo, caso o concurrent termine dom Advertencia (amarelo) ele nao commita automaticamente!
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO.: Erro ao atualizar o flag STATUS na tabela XX_GATEC_MOV_INSUM - ' || SQLERRM;
          log_email_p (p_errbuf);
          print_msg_p (p_errbuf);
          --RAISE_APPLICATION_ERROR(-20170, p_errbuf);
          GOTO end_loop; -- Avanca para o proximo registro
      END;
      -- ---------------------------------------------------------------------------------------------------- --
      -- There is a connection with transaction_type_id and transaction_source_id. Here is the explaination;  --
      -- TRANSACTION types definitions are stored At MTL_TRANSACTION_TYPES table. At that table               --
      -- TRANSACTION_SOURCE_TYPE_ID is also stored. With this ID go to MTL_TXN_SOURCE_TYPES table.            --
      -- MTL_TXN_SOURCE_TYPES table stores the information about what transaction_source_id means.            --
      -- If transaction source type of transaction is a Work Order TRANSACTION_SOURCE_ID means wip_entity_id, --
      -- if source type is Account then TRANSACTION_SOURCE_ID means a CODE_COMBINATION_ID from                --
      -- GL_CODE_COMBINATIONS_KFV.                                                                            --
      -- Here we insert serial number records if the item to be transaction is serially controlled;           --
      -- ---------------------------------------------------------------------------------------------------- --
      /*INSERT
        INTO mtl_serial_numbers_interface ( transaction_interface_id
                                           ,source_code
                                           ,source_line_id
                                           ,fm_serial_number
                                           ,to_serial_number
                                           ,process_flag
                                           ,created_by
                                           ,creation_date
                                           ,last_updated_by
                                           ,last_update_date)
                                   VALUES ( l_transaction_interface_id_ex
                                           ,'ONHAND TRANSACTIONS ? EXIT'       -- source_code,
                                           ,-111                               -- source_line_id,
                                           ,r_exit_onhand.old_serial_number
                                           ,r_exit_onhand.old_serial_number
                                           ,1                                  -- process_flag,(yes)
                                           ,fnd_global.user_id
                                           ,SYSDATE
                                           ,fnd_global.user_id
                                           ,SYSDATE);*/
      -- ------------------------------------------------------------------------------ --
      -- We have to use same transaction_id for these records to be executed together.  --
      -- Here we insert lot number records if the item to be transaction is lot number  --
      -- controlled;                                                                    --
      -- ------------------------------------------------------------------------------ --
      IF l_nControle_Lote = 2 THEN -- Se o item possuir controle de lote
        BEGIN
          INSERT
            INTO mtl_transaction_lots_interface ( transaction_interface_id      -- 1
                                                 ,source_code                   -- 2
                                                 ,source_line_id                -- 3
                                                 ,lot_number                    -- 4
                                                 ,transaction_quantity          -- 5
                                                 ,process_flag                  -- 6
                                                 ,attribute_category            -- 7
                                                 ,created_by                    -- 8
                                                 ,creation_date                 -- 9
                                                 ,last_updated_by               -- 10
                                                 ,last_update_date)             -- 11
                                         VALUES ( l_nTransaction_interface_id   -- 1   TRANSACTION_INTERFACE_ID
                                                 ,'GATEC'                       -- 2   SOURCE_CODE
                                                 ,1                             -- 3   SOURCE_LINE_ID
                                                 ,l_vLot_Number                 -- 4   LOT_NUMBER
                                                 ,r_1.qtd_material              -- 5   TRANSACTION_QUANTITY
                                                 ,1                             -- 6   PROCESS_FLAG,(YES)
                                                 ,'BR'                          -- 7   ATTRIBUTE_CATEGORY
                                                 ,fnd_global.user_id            -- 8
                                                 ,SYSDATE                       -- 9
                                                 ,fnd_global.user_id            -- 10
                                                 ,SYSDATE);                     -- 11
        EXCEPTION
          WHEN OTHERS THEN
            p_retcode := -2;
            p_errbuf  := 'ERRO.: Erro ao inserir registro na tabela MTL_TRANSACTION_LOTS_INTERFACE - ' || SQLERRM;
            log_email_p (p_errbuf);
            print_msg_p (p_errbuf);
            --RAISE_APPLICATION_ERROR(-20180, p_errbuf);
        END;
      END IF;
      <<end_loop>>
      l_nCt_Rec := l_nCt_Rec + 1; -- Contabiliza os registros do cursor
    END LOOP;
    print_msg_p(CHR(13));
    print_msg_p('Registros lidos (total)...........................: ' || l_nCt_Rec);
    print_msg_p('Registros inseridos em MTL_TRANSACTIONS_INTERFACE.: ' || l_nCt_Intf);
    print_msg_p('------------------------------------------------------------------');
    print_msg_p('Inicio da chamada da API INV_TXN_MANAGER_PUB.process_transactions.');
    p_errbuf := NULL; -- Limpar variavel para nao exibir mensagens duplicadas no log
    --
    -- Faz a chamada da API se tiver sido inserido ao menos 1 registro na interface
    IF NVL(l_nCt_Intf,0) > 0 THEN
      l_nRetcode := INV_TXN_MANAGER_PUB.process_transactions
                      ( p_api_version   => 1.0             -- IN
                       ,p_init_msg_list => fnd_api.g_true  -- IN
                       ,x_return_status => l_return_status -- OUT
                       ,x_msg_count     => l_msg_count     -- OUT
                       ,x_msg_data      => l_msg_data      -- OUT
                       ,x_trans_count   => l_trans_count   -- OUT
                       ,p_header_id     => l_transaction_header_id_ex ); -- IN  --> transaction_header_id that we determined before
    END IF;
    -- ---------------------------------------------------------------------------------- --
    -- Se houver algum registro com erro, envia e-mail para notificar a area responsavel, --
    -- a lista dos e-mails esta cadastrada no conjunto de valores XX_INV_MOVE_ORDER_EMAIL --
    -- ---------------------------------------------------------------------------------- --
    IF l_nTot_NOK > 0 THEN
      IF l_return_status <> 'S' THEN
        log_email_p ('Status API INV_TXN_MANAGER_PUB.process_transactions: ' || l_return_status || CHR(13) ||
                     'l_msg_data: ' || l_msg_data);
      END IF;
      envia_email_p;
    END IF;
    --
    COMMIT; -- Manter commit no codigo para caso o concurrent termine com Advertencia e nesse caso nao comita automaticamente
    --
    print_msg_p('l_transaction_header_id_ex.: ' || l_transaction_header_id_ex);
    print_msg_p('l_return_status............: ' || l_return_status);
    print_msg_p('l_msg_count................: ' || l_msg_count);
    print_msg_p('l_msg_data.................: ' || l_msg_data);
    print_msg_p('l_trans_count..............: ' || l_trans_count);
    print_msg_p('l_nRetcode (API return)....: ' || l_nRetcode);
    print_msg_p('----------------------------');
    print_msg_p('p_retcode (Custom return)..: ' || p_retcode);
    -- -------------------- --
    -- Imprime log de erros --
    -- -------------------- --
    IF l_return_status <> 'S' THEN
      print_msg_p (CHR(13) || CHR(13) || 'Log de erros da interface - Integracoes Gatec: ');
      print_msg_p ( RPAD('ITEM',15,' ')         ||
                    RPAD('ERRO',149, ' ')       ||
                    LPAD('DT TRANSACAO',12,' ') ||
                    LPAD('SUB. INV.',11,' ')    || '  ' ||
                    RPAD('LOCAL',32, ' ')       ||
                    RPAD('UDM',5, ' ')          ||
                    LPAD('QTD TOTAL',17, ' '));
      --
      FOR r_log_erro IN ( SELECT mti.inventory_item_id
                                ,msib.segment1 item
                                ,mti.source_code               origem
                                ,mti.error_code || ': ' || mti.error_explanation erro
                                ,TRUNC(mti.transaction_date)   data_transacao
                                ,mti.subinventory_code         subinventario
                                ,mil.segment1                  local
                                ,mti.transaction_uom           udm
                                ,SUM(mti.transaction_quantity) quantidade
                            FROM apps.mtl_transactions_interface mti
                                ,apps.mtl_system_items_b         msib
                                ,apps.mtl_item_locations         mil
                           WHERE mti.inventory_item_id        = msib.inventory_item_id
                             AND mti.organization_id          = msib.organization_id
                             AND mti.locator_id               = mil.inventory_location_id(+)
                             --AND mti.transaction_header_id    = l_transaction_header_id_ex
                             AND mti.error_code               IS NOT NULL
                             AND mti.source_code              = 'GATEC'
                           GROUP BY msib.segment1
                                   ,mti.error_code
                                   ,mti.error_explanation
                                   ,mti.source_code
                                   ,mti.inventory_item_id
                                   ,TRUNC(mti.transaction_date)
                                   ,mti.subinventory_code
                                   ,mil.segment1
                                   ,mti.transaction_uom
                           ORDER BY msib.segment1
                                   ,TRUNC(mti.transaction_date) ) LOOP
        --
        print_msg_p ( r_log_erro.item                             || '  ' ||
                      RPAD(SUBSTR(r_log_erro.erro,1,150),150,' ') || '  ' ||
                      r_log_erro.data_transacao                   || '  ' ||
                      RPAD(r_log_erro.subinventario,9,' ')        || '  ' ||
                      RPAD(SUBSTR(r_log_erro.local,1,30),30,' ')  || '  ' ||
                      RPAD(r_log_erro.udm,5,' ')                  || '  ' ||
                      LPAD(r_log_erro.quantidade,15,' ' ));
      END LOOP;
    END IF;
  END criar_ajuste_p;
  -- ---------------------------------------------------------------------- --
  -- Procedure para unificar os comandos de mensagens no codigo ao imprimir --
  -- as mensagens no Log do concurrent e no output do PL/SQL.               --
  -- ---------------------------------------------------------------------- --
  PROCEDURE print_msg_p (p_msg IN VARCHAR2) IS
  BEGIN
    --DBMS_OUTPUT.PUT_LINE(p_msg);
    FND_FILE.PUT_LINE(FND_FILE.LOG, p_msg);
  END print_msg_p;
  -- --------------------------------------------------------- --
  -- Armazena mensagens de erro cumulativas na variavel global --
  -- para ser enviada por e-mail para a area responsavel.      --
  -- --------------------------------------------------------- --
  PROCEDURE log_email_p ( p_msg IN VARCHAR2 ) IS
  BEGIN
    g_vLog_Email := SUBSTR((g_vLog_Email || p_msg || ' /// '),1,32000);
  END log_email_p;
  --
  PROCEDURE envia_email_p IS
    l_vDestinatario    VARCHAR2(1000);
    l_vNomeRotina      VARCHAR2(100) := 'LOG_ERRO_BAIXA_INSUMO';
    l_vNomeModulo      VARCHAR2(100) := 'enviarEmail';
    l_vSubject         VARCHAR2(250) := 'ERRO: XX INV OPM Baixa de Itens de Insumo GATEC';
    l_vMsgErro         VARCHAR2(32000);
  BEGIN
    BEGIN
      SELECT LISTAGG(ffv.flex_value, ', ') WITHIN GROUP (ORDER BY ffv.flex_value) email
        INTO l_vDestinatario
        FROM apps.fnd_flex_values_tl  ffvtl
            ,apps.fnd_flex_values     ffv
            ,apps.fnd_flex_value_sets ffvs
       WHERE ffvs.flex_value_set_name = 'XX_INV_LIST_USER_EMAIL'
         AND ffvs.flex_value_set_id   = ffv.flex_value_set_id
         AND ffv.flex_value_id        = ffvtl.flex_value_id
         AND ffv.enabled_flag         = 'Y'
         AND ffvtl.language           = USERENV('LANG')
         AND TRUNC(SYSDATE) BETWEEN TRUNC(NVL(ffv.start_date_active,SYSDATE))
                                AND TRUNC(NVL(ffv.end_date_active,SYSDATE));
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20190, 'Erro ao consultar o e-mail no Conjunto de Valores XX_INV_MOVE_ORDER_EMAIL - ' || SQLERRM);
    END;
    --
    IF l_vDestinatario IS NOT NULL THEN
      xx_pkg_email.setSendEmail( pRotina       => l_vNomeRotina
                                ,pSubRotina    => l_vNomeModulo
                                ,pDestinatario => l_vDestinatario
                                ,pCC           => NULL
                                ,pCCO          => NULL
                                ,pSubject      => l_vSubject-- pSubject = maximo 99 caracteres
                                ,pBody         => g_vLog_Email
                                ,pAttachments  => NULL
                                ,pMsgErro      => l_vMsgErro
                                ,pTipoEnvio    => 'HTML' );
    END IF;
  END envia_email_p;
  -- -------------------------------------- --
  -- Rafael S. Nunes (Ninecon) - 487 -- fim --
  -- -------------------------------------- --
END xx_opm_ajus_insumo_gatec_pkg;
/

exit
