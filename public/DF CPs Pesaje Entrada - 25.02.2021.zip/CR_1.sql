UPDATE apps.XX_TCG_TICKETS_BALANZA xtb
SET xtb.TARA = ( SELECT xcp.TARA_RECEPCION
                                 FROM apps.XX_TCG_CARTAS_PORTE_ALL xcp
                                 WHERE xcp.CARTA_PORTE_ID = xtb.CARTA_PORTE_ID),
                                xtb.BALANZA_TARA_ID =  xtb.BALANZA_PESO_BRUTO_ID,
                                xtb.TARA_USER_ID = xtb.PESO_BRUTO_USER_ID,
                                xtb.TARA_AUT_FLAG = xtb.PESO_BRUTO_AUT_FLAG,
                                xtb.TARA_JUSTIF = xtb.PESO_BRUTO_JUSTIF 
WHERE xtb.TIPO_TICKET = 'ENTRADA' 
AND xtb.cancelado_flag = 'N'          
AND xtb.tara IS NULL
AND xtb.peso_bruto is not null
AND xtb.tara_fecha is null
AND xtb.tara_user_id is null
AND xtb.tara_aut_flag is null
AND xtb.CARTA_PORTE_ID IN (SELECT xcp.CARTA_PORTE_ID
			   FROM apps.XX_TCG_CARTAS_PORTE_ALL xcp
                           WHERE   xcp.tara_recepcion IS NOT NULL
                           AND xcp.pesaje_entrada_flag = 'N'
                           AND xcp.recibido_flag = 'Y'
                           AND xcp.lot_no = '2021'
                           AND xtb.TICKET_ID = xcp.TICKET_RECEPCION_ID
   			   AND xcp.ANULADO_FLAG = 'N')
--5