  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_REPORTES_PKG" AS

  PROCEDURE Listado_Repo_MiPyme ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                , p_errcode     IN OUT NOCOPY VARCHAR2
                                , p_emisor                    NUMBER
                                , p_receptor                  NUMBER
                                , p_fecha_desde               VARCHAR2
                                , p_fecha_hasta               VARCHAR2
                                );

END XX_AP_REPORTES_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_REPORTES_PKG" AS

  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);

  FUNCTION xml_escape_chars ( p_data VARCHAR2 ) RETURN VARCHAR IS
    l_data VARCHAR2(32767);
  BEGIN
    l_data := REPLACE(REPLACE(REPLACE(p_data, '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
    RETURN l_data;
  END xml_escape_chars;

  PROCEDURE Listado_Repo_MiPyme ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                , p_errcode     IN OUT NOCOPY VARCHAR2
                                , p_emisor                    NUMBER
                                , p_receptor                  NUMBER
                                , p_fecha_desde               VARCHAR2
                                , p_fecha_hasta               VARCHAR2
                                ) IS
    CURSOR c1 ( p_cuit_emisor   NUMBER
              , p_cuit_receptor NUMBER
              , p_fecha_desde   DATE
              , p_fecha_hasta   DATE
              ) IS
      SELECT CASE 
               WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c(cbte.cuit_receptor) = 'Y' THEN
                 (SELECT DISTINCT opu.name
                  FROM hr_all_organization_units ou
                     , hr_operating_units        opu
                     , hr_locations              l 
                  WHERE 1=1
                  AND opu.organization_id = ou.organization_id
                  AND l.location_id = ou.location_id
                  AND l.global_attribute11||l.global_attribute12 = cbte.cuit_receptor
                 )
               WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c(cbte.cuit_emisor) = 'Y' THEN
                 (SELECT DISTINCT opu.name
                  FROM hr_all_organization_units ou
                     , hr_operating_units        opu
                     , hr_locations              l 
                  WHERE 1=1
                  AND opu.organization_id = ou.organization_id
                  AND l.location_id = ou.location_id
                  AND l.global_attribute11||l.global_attribute12 = cbte.cuit_emisor
                 )
             END unidad_operativa
           , cbte.cuit_emisor
           , (SELECT DISTINCT s.vendor_name 
              FROM ap_suppliers s 
              WHERE s.num_1099||s.global_attribute12 = cbte.cuit_emisor
              AND ROWNUM=1
             ) razon_social_emisor
           , cbte.cuit_receptor
           , (SELECT DISTINCT s.vendor_name 
              FROM ap_suppliers s 
              WHERE s.num_1099||s.global_attribute12 = cbte.cuit_receptor
              AND ROWNUM=1
             ) razon_social_receptor
           , cbte.codigo_tipo_comprobante
           , (SELECT DISTINCT description
              FROM fnd_lookup_values_vl lv
                 , fnd_lookup_values_dfv lv_dfv
              WHERE 1=1
              AND lv_dfv.row_id = lv.rowid
              AND lv_dfv.context = lv.attribute_category
              AND lookup_type = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
              AND lookup_code = cbte.codigo_tipo_comprobante
              AND UPPER(meaning) LIKE '%MIPYME%'
             ) tipo_comprobante
           , cbte.punto_venta
           , cbte.numero_comprobante
           , cbte.estado
           , cbte.fecha_estado
           , cbte.tipo_aceptacion
           , cbte.fecha_aceptacion
           , cbte.fecha_emision
           , cbte.informado_agente_deposito
           , cbte.fecha_info_agente_deposito
           , cbte.fecha_puesta_disposicion
           , cbte.fecha_vto_pago
           , cbte.fecha_vto_aceptacion
           , (SELECT DISTINCT meaning FROM fnd_lookup_values_vl WHERE lookup_type = 'XX_AR_FC_ELECTRO_MONEDA' AND lookup_code = cbte.codigo_moneda) codigo_moneda    
           , cbte.cotizacion_moneda
           , cbte.importe_total
           , cbte.referencias_comerciales
           , cbte.datos_generales
           , cbte.datos_comerciales
           , cbte.leyenda_comercial
           , cbte.cbu_emisor
           , cbte.cbu_pago
           , cbte.alias_emisor
           , cbte.codigo_cuenta_corriente
           , DECODE(cbte.tipo_codigo_autoriza, 'A', 'CAEA', 'E', 'CAE', cbte.tipo_codigo_autoriza) tipo_codigo_autoriza
           , cbte.codigo_autorizacion
           , cbte.error_message
           , (SELECT DISTINCT invoice_num FROM ap_invoices_all WHERE invoice_id = cbte.invoice_id) comprobante_ap
           , cbte.comentarios
      FROM xx_ap_mipyme_cbtes cbte
      WHERE 1=1 
      AND ( p_cuit_emisor IS NULL OR
            p_cuit_emisor = cbte.cuit_emisor
          )
      AND ( p_cuit_receptor IS NULL OR
            p_cuit_receptor = cbte.cuit_receptor
          )
      AND ( p_fecha_desde IS NULL OR
            TRUNC(cbte.fecha_emision) >= p_fecha_desde
          )
      AND ( p_fecha_hasta IS NULL OR 
            TRUNC(cbte.fecha_emision) <= p_fecha_hasta
          )
      ORDER BY cbte.cuit_emisor , cbte.punto_venta , cbte.numero_comprobante
      ;

    CURSOR cCUIT (p_vendor_id NUMBER) IS
      SELECT s.num_1099||s.global_attribute12, s.vendor_name
      FROM ap_suppliers s 
      WHERE s.vendor_id = p_vendor_id;

    l_emisor_cuit      NUMBER;
    l_emisor_nombre    VARCHAR2(250);
    l_receptor_cuit    NUMBER;
    l_receptor_nombre  VARCHAR2(250);
    l_fecha_desde      DATE;
    l_fecha_hasta      DATE;
  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX Listado de Repositorio Mi Pyme');
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_emisor: '||p_emisor);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_receptor: '||p_receptor);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_desde: '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_hasta: '||p_fecha_hasta);

    OPEN cCUIT (p_emisor);
    FETCH cCUIT INTO l_emisor_cuit, l_emisor_nombre;
    CLOSE cCUIT;

    OPEN cCUIT (p_receptor);
    FETCH cCUIT INTO l_receptor_cuit, l_receptor_nombre;
    CLOSE cCUIT;
    
    l_fecha_desde := TRUNC(TO_DATE(p_fecha_desde, 'YYYY/MM/DD HH24:MI:SS'));
    l_fecha_hasta := TRUNC(TO_DATE(p_fecha_hasta, 'YYYY/MM/DD HH24:MI:SS'));

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXLISREPOMIPYME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX Listado de Repositorio Mi Pyme</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION_REPO>'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION_REPO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMISOR>'||NVL(l_emisor_nombre, 'No Especificado')||'</P_EMISOR>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_RECEPTOR>'||NVL(l_receptor_nombre, 'No Especificado')||'</P_RECEPTOR>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>'||NVL(TO_CHAR(l_fecha_desde,'DD-MM-YYYY'), 'No Especificado')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_HASTA>'||NVL(TO_CHAR(l_fecha_hasta,'DD-MM-YYYY'), 'No Especificado')||'</P_FECHA_HASTA>');

    FOR r1 IN c1 ( l_emisor_cuit
                 , l_receptor_cuit
                 , l_fecha_desde
                 , l_fecha_hasta
                 ) LOOP
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <UNIDAD_OPERATIVA>'||r1.UNIDAD_OPERATIVA||'</UNIDAD_OPERATIVA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CUIT_EMISOR>'||r1.CUIT_EMISOR||'</CUIT_EMISOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <RAZON_SOCIAL_EMISOR>'||XX_UTIL_PK.xml_escape_chars(r1.RAZON_SOCIAL_EMISOR)||'</RAZON_SOCIAL_EMISOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CUIT_RECEPTOR>'||r1.CUIT_RECEPTOR||'</CUIT_RECEPTOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <RAZON_SOCIAL_RECEPTOR>'||XX_UTIL_PK.xml_escape_chars(r1.RAZON_SOCIAL_RECEPTOR)||'</RAZON_SOCIAL_RECEPTOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CODIGO_TIPO_COMPROBANTE>'||r1.CODIGO_TIPO_COMPROBANTE||'</CODIGO_TIPO_COMPROBANTE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <TIPO_COMPROBANTE>'||r1.TIPO_COMPROBANTE||'</TIPO_COMPROBANTE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <PUNTO_VENTA>'||r1.PUNTO_VENTA||'</PUNTO_VENTA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_COMPROBANTE>'||r1.NUMERO_COMPROBANTE||'</NUMERO_COMPROBANTE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <ESTADO>'||r1.ESTADO||'</ESTADO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_ESTADO>'||TO_CHAR(r1.FECHA_ESTADO, 'DD-MM-YYYY')||'</FECHA_ESTADO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <TIPO_ACEPTACION>'||r1.TIPO_ACEPTACION||'</TIPO_ACEPTACION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_ACEPTACION>'||TO_CHAR(r1.FECHA_ACEPTACION, 'DD-MM-YYYY')||'</FECHA_ACEPTACION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_EMISION>'||TO_CHAR(r1.FECHA_EMISION, 'DD-MM-YYYY')||'</FECHA_EMISION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <INFORMADO_AGENTE_DEPOSITO>'||r1.INFORMADO_AGENTE_DEPOSITO||'</INFORMADO_AGENTE_DEPOSITO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_INFO_AGENTE_DEPOSITO>'||r1.FECHA_INFO_AGENTE_DEPOSITO||'</FECHA_INFO_AGENTE_DEPOSITO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_PUESTA_DISPOSICION>'||TO_CHAR(r1.FECHA_PUESTA_DISPOSICION, 'DD-MM-YYYY')||'</FECHA_PUESTA_DISPOSICION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_VTO_PAGO>'||TO_CHAR(r1.FECHA_VTO_PAGO, 'DD-MM-YYYY')||'</FECHA_VTO_PAGO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_VTO_ACEPTACION>'||TO_CHAR(r1.FECHA_VTO_ACEPTACION, 'DD-MM-YYYY')||'</FECHA_VTO_ACEPTACION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CODIGO_MONEDA>'||r1.CODIGO_MONEDA||'</CODIGO_MONEDA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <COTIZACION_MONEDA>'||r1.COTIZACION_MONEDA||'</COTIZACION_MONEDA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <IMPORTE_TOTAL>'||r1.IMPORTE_TOTAL||'</IMPORTE_TOTAL>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <REFERENCIAS_COMERCIALES>'||XX_UTIL_PK.xml_escape_chars(r1.REFERENCIAS_COMERCIALES)||'</REFERENCIAS_COMERCIALES>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <DATOS_GENERALES>'||XX_UTIL_PK.xml_escape_chars(r1.DATOS_GENERALES)||'</DATOS_GENERALES>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <DATOS_COMERCIALES>'||XX_UTIL_PK.xml_escape_chars(r1.DATOS_COMERCIALES)||'</DATOS_COMERCIALES>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <LEYENDA_COMERCIAL>'||XX_UTIL_PK.xml_escape_chars(r1.LEYENDA_COMERCIAL)||'</LEYENDA_COMERCIAL>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CBU_EMISOR>'||r1.CBU_EMISOR||'</CBU_EMISOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CBU_PAGO>'||r1.CBU_PAGO||'</CBU_PAGO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <ALIAS_EMISOR>'||r1.ALIAS_EMISOR||'</ALIAS_EMISOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CODIGO_CUENTA_CORRIENTE>'||r1.CODIGO_CUENTA_CORRIENTE||'</CODIGO_CUENTA_CORRIENTE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <TIPO_CODIGO_AUTORIZA>'||r1.TIPO_CODIGO_AUTORIZA||'</TIPO_CODIGO_AUTORIZA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CODIGO_AUTORIZACION>'||r1.CODIGO_AUTORIZACION||'</CODIGO_AUTORIZACION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <ERROR_MESSAGE>'||r1.ERROR_MESSAGE||'</ERROR_MESSAGE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <COMPROBANTE_AP>'||r1.COMPROBANTE_AP||'</COMPROBANTE_AP>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <COMENTARIOS>'||XX_UTIL_PK.xml_escape_chars(r1.COMENTARIOS)||'</COMENTARIOS>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXLISREPOMIPYME>');

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Listado_Repo_MiPyme;

END XX_AP_REPORTES_PKG;
/

exit
