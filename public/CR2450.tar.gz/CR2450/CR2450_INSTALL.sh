#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2450_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2450
# |
# | HISTORY
# |   30-APR-20  Silva, Alejandra - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2450_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2450_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2450
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT




echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXPAEPRO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPAEPRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'All Projects Programs' 
              ,group_application   => 'PA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPAEPRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'All Projects Programs' 
              ,group_application   => 'PA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPAEPRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'All Projects Programs + Budget' 
              ,group_application   => 'PA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPAEPRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'All Projects Programs + Budget' 
              ,group_application   => 'PA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPAEPRO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXPAEPRO " >> $CROUT; echo "" >> $CROUT

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE DATA_TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXPAEPRO \
-LANGUAGE "00" \
-TERRITORY "00" \
-XDO_FILE_TYPE XML \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.xml \
-CUSTOM_MODE FORCE \
-LOG_FILE XXPAEPRO_xmldt_up.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt"

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.xml &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.xml /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.xml >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.xml /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.xml -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXPAEPRO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXPAEPRO \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXPAEPRO_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPAEPRO_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2450" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2450_13867.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2450_13867.ldt"

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
