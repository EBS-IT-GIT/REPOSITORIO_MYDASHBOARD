UPDATE apps.XX_ACO_CTGS_B x1
   SET x1.DESTINATARIO_ID =
          (SELECT VENDOR_ID
             FROM apps.AP_SUPPLIERS
            WHERE TRIM (CONCAT (NUM_1099, global_attribute12)) =
                     x1.CUIT_DESTINATARIO)
 WHERE x1.DESTINATARIO_ID IS NULL AND x1.CUIT_DESTINATARIO IS NOT NULL
       AND EXISTS
              (SELECT 1
                 FROM apps.AP_SUPPLIERS
                WHERE TRIM (CONCAT (NUM_1099, global_attribute12)) =
                         x1.CUIT_DESTINATARIO)
       AND x1.FECHA_EMISION > TO_DATE ('01-01-2020', 'DD-MM-YYYY')