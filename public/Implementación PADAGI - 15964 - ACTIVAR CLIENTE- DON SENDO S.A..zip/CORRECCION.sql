UPDATE apps.hz_parties
SET    status = 'A'
WHERE  party_name = 'DON SENDO S.A.';
--1 Registro