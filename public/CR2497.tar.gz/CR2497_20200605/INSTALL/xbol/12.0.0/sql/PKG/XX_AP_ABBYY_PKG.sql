  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_ABBYY_PKG" IS

  G_DEBUG_FLAG VARCHAR2(1) := NVL(FND_PROFILE.value('XX_DEBUG_ABBYY_ENABLED'), 'N');

  PROCEDURE Inserta_Cabecera ( p_scan_id               IN NUMBER
                             , p_page_images           IN VARCHAR2
                             , p_csv_file              IN VARCHAR2
                             , p_cuit_empresa          IN VARCHAR2
                             , p_cuit_proveedor        IN VARCHAR2
                             , p_nro_cbte              IN VARCHAR2
                             , p_tipo_cbte             IN VARCHAR2
                             , p_codigo_cbte           IN VARCHAR2
                             , p_letra_cbte            IN VARCHAR2
                             , p_fecha_emision         IN DATE
                             , p_fecha_vto             IN DATE
                             , p_fecha_recepcion       IN DATE
                             , p_termino_pago          IN VARCHAR2
                             , p_grupo_pago            IN VARCHAR2
                             , p_importe               IN NUMBER
                             , p_moneda                IN VARCHAR2
                             , p_cotizacion            IN NUMBER
                             , p_tipo_oc               IN VARCHAR2
                             , p_orden_compra          IN VARCHAR2
                             , p_tipo_anticipo         IN VARCHAR2
                             , p_cant_direcciones      IN VARCHAR2
                             , p_tipo_asoc             IN VARCHAR2
                             , p_campo                 IN VARCHAR2
                             , p_cuenta_nro            IN VARCHAR2
                             , p_unidad_negocio        IN VARCHAR2
                             , p_producto              IN VARCHAR2
                             , p_unidad_productiva     IN VARCHAR2
                             , p_centro_costos         IN VARCHAR2
                             , p_proyecto              IN VARCHAR2
                             , p_sucursal_proveedor    IN VARCHAR2
                             , p_cuenta_bancaria       IN VARCHAR2
                             , p_proceso_id            IN NUMBER
                               );


  PROCEDURE Obtiene_ticket_acceso_WSCDC ( p_cuit_representado  IN VARCHAR2
                                        , x_token             OUT VARCHAR2
                                        , x_sign              OUT VARCHAR2
                                        , x_result            OUT NUMBER
                                        , x_error_msg         OUT VARCHAR2);





END XX_AP_ABBYY_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_ABBYY_PKG" IS

 /***************************************************************************
  *                    P R I V A T E   R O U T I N E S                      *
  ***************************************************************************/

PROCEDURE Debug (p_message IN VARCHAR2)
  IS

    l_module VARCHAR2(15) := 'XX_AP_ABBYY_PKG';

  BEGIN

    IF (G_DEBUG_FLAG = 'Y') THEN

      XX_DEBUG_AUX_PK.debug( p_module  => l_module
                           , p_message => p_message );

    END IF;


  END Debug;


  PROCEDURE Get_datos_Emisor ( p_emisor_cuit              IN NUMBER
                             , x_emisor_vendor_id        OUT NUMBER
                             , x_emisor_party_id         OUT VARCHAR2
                             , x_accts_pay_cc_id         OUT NUMBER
                             , x_estado                  OUT VARCHAR2
                             , x_error                   OUT VARCHAR2
                             )
  IS

  BEGIN

    x_estado := 'E';

    SELECT aps.vendor_id
         , aps.party_id
         , aps.accts_pay_code_combination_id
      INTO x_emisor_vendor_id
         , x_emisor_party_id
         , x_accts_pay_cc_id
      FROM AP_SUPPLIERS aps
     WHERE 1=1
       AND TRUNC(NVL(aps.end_date_active, SYSDATE+1)) > TRUNC(SYSDATE)
       AND aps.num_1099||aps.global_attribute12       = TO_CHAR(p_emisor_cuit);

    x_estado := 'P';

  EXCEPTION
    WHEN no_data_found THEN
      x_error  := 'No se encontraron datos del emisor '||p_emisor_cuit;

    WHEN others THEN
      x_error  := 'Error al buscar los datos del emisor '||p_emisor_cuit||': '||SQLERRM;

  END Get_datos_Emisor;




  PROCEDURE Get_Datos_Receptor ( p_receptor_cuit     IN NUMBER
                               , x_org_id           OUT NUMBER
                               , x_set_of_books_id  OUT NUMBER
                               , x_legal_entity_id  OUT NUMBER
                               , x_estado           OUT VARCHAR2
                               , x_error            OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';

    SELECT hou.organization_id          org_id
         , hou.set_of_books_id
         , hou.default_legal_context_id legal_entity_id
      INTO x_org_id
         , x_set_of_books_id
         , x_legal_entity_id
      FROM HR_OPERATING_UNITS        hou
         , HR_ALL_ORGANIZATION_UNITS haou
         , HR_LOCATIONS_ALL          hl
         , AP_SUPPLIERS              aps
     WHERE 1=1
       AND haou.organization_id                        = hou.organization_id
       AND hl.location_id                              = haou.location_id
       AND aps.num_1099||aps.global_attribute12        = hl.global_attribute11||hl.global_attribute12
       AND TRUNC(NVL(aps.end_date_active, SYSDATE+1)) >= TRUNC(SYSDATE)
       AND aps.num_1099||aps.global_attribute12        = TO_CHAR(p_receptor_cuit);

    x_estado := 'P';

  EXCEPTION
    WHEN no_data_found THEN
      x_error := 'No se encontraron datos del receptor '||p_receptor_cuit;

    WHEN others THEN
      x_error := 'Error al buscar los datos del receptor '||p_receptor_cuit||': '||SQLERRM;

  END Get_Datos_Receptor;




  PROCEDURE Get_Datos_Sucursal ( p_emisor_cuit                  IN NUMBER
                               , p_vendor_id                    IN NUMBER
                               , p_org_id                       IN NUMBER
                               , p_sucursal                     IN VARCHAR2
                               , p_emisor_accts_pay_cc_id       IN NUMBER
                               , x_emisor_vendor_site_id       OUT NUMBER
                               , x_emisor_party_site_id        OUT NUMBER
                               , x_accts_pay_cc_id             OUT NUMBER
                               , x_estado                      OUT VARCHAR2
                               , x_error                       OUT VARCHAR2)
  IS

    ls_accts_pay_cc_id        NUMBER;
    l_inactive_date           DATE;
    l_purchasing_site_flag    VARCHAR2(1);
    l_pay_site_flag           VARCHAR2(1);

  BEGIN

    x_estado := 'E';
    x_error  := NULL;

    SELECT aps.vendor_site_id
         , aps.party_site_id
         , aps.accts_pay_code_combination_id
         , NVL(aps.inactive_date, TRUNC(SYSDATE+1))
         , NVL(aps.purchasing_site_flag, 'N')
         , NVL(aps.pay_site_flag, 'N')
      INTO x_emisor_vendor_site_id
         , x_emisor_party_site_id
         , ls_accts_pay_cc_id
         , l_inactive_date
         , l_purchasing_site_flag
         , l_pay_site_flag
      FROM AP_SUPPLIER_SITES_ALL aps
     WHERE aps.vendor_id        = p_vendor_id
       AND aps.org_id           = p_org_id
       AND aps.vendor_site_code = p_sucursal;


    IF (l_inactive_date < TRUNC(SYSDATE)) THEN
      x_error := 'La sucursal '||p_sucursal||' no se encuentra activa';
    END IF;
    IF (l_purchasing_site_flag = 'N') THEN
      x_error := x_error ||' - La sucursal '||p_sucursal||' no está habilitada para compra.';
    END IF;
    IF (l_pay_site_flag = 'N') THEN
      x_error := x_error ||' - La sucursal '||p_sucursal||' no está habilitada para pago.';
    END IF;

    IF (x_error IS NOT NULL) THEN
      RETURN;
    END IF;

    IF (ls_accts_pay_cc_id IS NOT NULL) THEN
      x_accts_pay_cc_id := ls_accts_pay_cc_id;
    ELSIF (p_emisor_accts_pay_cc_id IS NOT NULL) THEN
      x_accts_pay_cc_id := p_emisor_accts_pay_cc_id;
    END IF;


    x_estado := 'P';

  EXCEPTION
    WHEN no_data_found THEN
      x_error := 'No se encontraron datos a nivel site para el emisor '||p_emisor_cuit||' y nombre de sucursal: '||p_sucursal;

    WHEN too_many_rows THEN
      x_error := 'Se encontraron más de un registro de datos a nivel site para el emisor '||p_emisor_cuit;

    WHEN others THEN
      x_estado := 'E'; -- CR2497                                                    
      x_error  := 'Error al buscar los datos a nivel site para el emisor '||p_emisor_cuit||': '||SQLERRM;

  END Get_Datos_Sucursal;




  PROCEDURE Get_Datos_Conversion ( p_codigo_moneda        IN VARCHAR2
                                 , p_set_of_books_id      IN NUMBER
                                 , p_importe_cbte         IN NUMBER
                                 , p_cotizacion_cbte      IN NUMBER
                                 , p_fecha_emision_cbte   IN DATE
                                 , x_base_amount         OUT NUMBER
                                 , x_exchange_rate       OUT NUMBER
                                 , x_exchange_rate_type  OUT VARCHAR2
                                 , x_exchange_date       OUT DATE
                                 , x_estado              OUT VARCHAR2
                                 , x_error               OUT VARCHAR2)
  IS

    l_curr_code_sob  VARCHAR2(15);
    eImporte         EXCEPTION;
    eCotizacion      EXCEPTION;


  BEGIN

    x_estado := 'E';

    SELECT currency_code
      INTO l_curr_code_sob
      FROM GL_SETS_OF_BOOKS
     WHERE set_of_books_id = p_set_of_books_id;


    IF (p_codigo_moneda != l_curr_code_sob) THEN


      IF (p_importe_cbte IS NULL) THEN
        RAISE eImporte;
      END IF;
      IF (p_cotizacion_cbte IS NULL) THEN
        RAISE eCotizacion;
      END IF;
      x_base_amount        := ROUND(p_importe_cbte * p_cotizacion_cbte, 2);
      x_exchange_rate      := p_cotizacion_cbte;
      x_exchange_rate_type := 'User';
      x_exchange_date      := p_fecha_emision_cbte;

    ELSE
      x_base_amount        := NULL;
      x_exchange_rate      := 1;
      x_exchange_rate_type := NULL;
      x_exchange_date      := NULL;
    END IF;

    x_estado := 'P';

  EXCEPTION
    WHEN eImporte THEN
      x_error := 'No se encontró el valor del importe.';

    WHEN eCotizacion THEN
      x_error := 'No se encontró el valor de la cotizacion.';

    WHEN no_data_found THEN
      x_error := 'No se encontró moneda para el juego de libro.';

    WHEN others THEN
      x_error := 'Error al buscar la moneda para el juego de libro: '||SQLERRM;

  END Get_Datos_Conversion;




  PROCEDURE Get_Usuario_Creador ( x_user_id  OUT NUMBER
                                , x_estado   OUT VARCHAR2
                                , x_error    OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';

    SELECT user_id
      INTO x_user_id
      FROM FND_USER
     WHERE user_name = 'SCHEDULED_REQUESTS';

    x_estado := 'P';

  EXCEPTION
    WHEN others THEN
      x_error := 'Error al buscar el id del usuario creador SCHEDULED_REQUESTS: '||SQLERRM;

  END;




  PROCEDURE Get_Tipo_Comprobante ( p_codigo_cbte   IN VARCHAR2
                                 , p_tipo_anticipo IN VARCHAR2
                                 , x_tipo_cbte    OUT VARCHAR2
                                 , x_estado       OUT VARCHAR2
                                 , x_error        OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';

    IF ( p_tipo_anticipo IS NOT NULL) THEN

      x_tipo_cbte := 'PREPAYMENT';

    ELSE

      SELECT DISTINCT DECODE(flvd.xx_rg3685_nc, NULL, 'STANDARD', 'CREDIT')
        INTO x_tipo_cbte
        FROM FND_LOOKUP_VALUES_VL  flv
           , FND_LOOKUP_VALUES_DFV flvd
       WHERE 1=1
         AND flvd.row_id                = flv.rowid
         AND flvd.context               = flv.attribute_category
         AND flv.lookup_type            = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
         AND TO_NUMBER(flv.lookup_code) = TO_NUMBER(p_codigo_cbte);


    END IF;


    x_estado := 'P';

  EXCEPTION
    WHEN no_data_found THEN
      x_error := 'No fue posible determinar el tipo de comprobante.';

    WHEN others THEN
      x_error := 'Error al determinar el tipo de comprobante: '||SQLERRM;

  END ;




  PROCEDURE Get_Id_Termino_Pago ( p_vendor_id      IN NUMBER
                                , p_vendor_site_id IN NUMBER
                                , p_org_id         IN NUMBER                    --CR2388
                                , x_terms_id       OUT NUMBER
                                , x_estado         OUT VARCHAR2
                                , x_error          OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';

    BEGIN

      SELECT terms_id
        INTO x_terms_id
        FROM AP_SUPPLIER_SITES_ALL apss
           , AP_TERMS_TL           att
       WHERE apss.terms_id       = att.term_id
         AND apss.vendor_site_id = p_vendor_site_id
         AND att.language        = 'ESA'
         AND att.enabled_flag    = 'Y'
         AND terms_id            IS NOT NULL;  -- Agregado CR2367


    EXCEPTION
      WHEN no_data_found THEN

        BEGIN

          SELECT terms_id
            INTO x_terms_id
            FROM AP_SUPPLIERS
           WHERE vendor_id = p_vendor_id
             AND terms_id  IS NOT NULL;    -- Agregado CR2367

        EXCEPTION
          WHEN no_data_found THEN

            SELECT terms_id
              INTO x_terms_id
              --FROM AP_SYSTEM_PARAMETERS     CR2388
              FROM AP_SYSTEM_PARAMETERS_ALL
             WHERE 1=1
               AND org_id   = p_org_id    -- Agregado CR2388
               AND terms_id IS NOT NULL;  -- Agregado CR2367

        END;

    END;

    x_estado := 'P';

  EXCEPTION
    WHEN no_data_found THEN
      x_error := 'No se encuentra el id del termino de pago ';

    WHEN others THEN
      x_error := 'Error al buscar el id del termino de pago: '||SQLERRM;

  END Get_Id_Termino_Pago;




  PROCEDURE Get_Cuenta_Bancaria ( p_org_id               IN NUMBER
                                , p_cbu                  IN VARCHAR2
                                , p_party_id             IN NUMBER
                                , p_party_site_id        IN NUMBER
                                , p_currency_code        IN VARCHAR2
                                , x_ext_bank_account_id OUT NUMBER
                                , x_estado              OUT VARCHAR2
                                , x_error               OUT VARCHAR2)
  IS

    CURSOR c_cta_bco IS
      SELECT asp.vendor_name
           , asp.segment1          vendor_num
           , asa.vendor_site_code
           , payees.payment_function
           , instrument.order_of_preference
           , NVL(instrument.start_date, SYSDATE-1)    start_date
           , NVL(instrument.end_date, SYSDATE+1)      end_date
           , ieb.ext_bank_account_id
           , ieb.bank_account_name
           , ieb.bank_account_num
           , ieb.currency_code
           , ieb.attribute4        cbu
        FROM AP_SUPPLIERS            asp
           , AP_SUPPLIER_SITES_ALL   asa
           , IBY_EXTERNAL_PAYEES_ALL payees
           , IBY_ACCOUNT_OWNERS      owners
           , IBY_PMT_INSTR_USES_ALL  instrument
           , IBY_EXT_BANK_ACCOUNTS   ieb
       WHERE asp.party_id               = p_party_id
         AND asa.vendor_id              = asp.vendor_id
         AND asa.org_id                 = p_org_id
         AND asa.party_site_id          = p_party_site_id
         AND asa.vendor_site_id         = payees.supplier_site_id
         AND payees.payee_party_id      = owners.account_owner_party_id
         AND payees.payment_function    = 'PAYABLES_DISB'
         AND owners.primary_flag        = 'Y'
         AND owners.ext_bank_account_id = instrument.instrument_id
         AND payees.ext_payee_id        = instrument.ext_pmt_party_id
         AND instrument.instrument_type = 'BANKACCOUNT'
         AND owners.ext_bank_account_id = ieb.ext_bank_account_id
         AND ieb.currency_code          = p_currency_code;


    l_order_pref           NUMBER := 999999;
    l_ext_bank_account_id  NUMBER := NULL;
    l_encuentra_CBU        BOOLEAN:= FALSE;
    eCtaBcoNoAsignada      EXCEPTION;
    eCtaBcoNoDataFound     EXCEPTION;


  BEGIN

    x_estado := 'E';

/*
    SELECT ieba.ext_bank_account_id
         , MIN(ipiu.order_of_preference)
      INTO x_ext_bank_account_id
         , l_dummy
      FROM IBY_ACCOUNT_OWNERS    iao
         , IBY_EXT_BANK_ACCOUNTS ieba
         , IBY_PMT_INSTR_USES_ALL ipiu
     WHERE 1=1
       AND iao.ext_bank_account_id    = ieba.ext_bank_account_id
       AND ieba.attribute4            = p_cbu
       AND iao.account_owner_party_id = p_party_id
       AND ieba.currency_code         = p_currency_code
       AND SYSDATE                    BETWEEN NVL(ipiu.start_date, SYSDATE-1)
                                          AND NVL(ipiu.end_date-1, SYSDATE+1)
     GROUP BY ieba.ext_bank_account_id;
*/

    FOR rcb IN c_cta_bco LOOP

      IF (rcb.cbu = p_cbu) THEN

        l_encuentra_CBU := TRUE;

        IF (TRUNC(SYSDATE) BETWEEN rcb.start_date AND rcb.end_date) THEN

          IF (rcb.order_of_preference < l_order_pref) THEN
            l_order_pref          := rcb.order_of_preference;
            l_ext_bank_account_id := rcb.ext_bank_account_id;
          END IF;

        END IF;

      END IF;

    END LOOP;

    IF (l_encuentra_CBU AND l_ext_bank_account_id IS NULL) THEN
      RAISE eCtaBcoNoAsignada;
    ELSIF (NOT l_encuentra_CBU) THEN
      RAISE eCtaBcoNoDataFound;
    END IF;

    x_ext_bank_account_id := l_ext_bank_account_id;
    x_estado              := 'P';

  EXCEPTION
    WHEN eCtaBcoNoAsignada THEN
      x_error := 'La cuenta bancaria con CBU = '||p_cbu||' está desasignada. Organización id = '||p_org_id;

    WHEN eCtaBcoNoDataFound THEN
      x_error := 'No se pudo encontrar la cuenta bancaria con CBU = '||p_cbu||' para la organización = '||p_org_id;

    WHEN others THEN
      x_error := 'Error al buscar el id de cuenta bancaria del Emisor: '||SQLERRM;

  END Get_Cuenta_Bancaria;



  PROCEDURE Get_Datos_OC ( p_tipo_anticipo           IN VARCHAR2
                         , p_orden_compra        IN OUT NUMBER
                         , x_primera_fecha_pago     OUT DATE
                         , x_estado                 OUT VARCHAR2
                         , x_error                  OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';

    IF (p_tipo_anticipo IS NULL) THEN

      p_orden_compra       := NULL;
      x_primera_fecha_pago := NULL;

    ELSE

      IF (UPPER(p_tipo_anticipo) = 'TEMPORARIO') THEN
        x_primera_fecha_pago := TRUNC(SYSDATE);
      ELSIF (UPPER(p_tipo_anticipo) = 'PERMANENTE') THEN
        x_primera_fecha_pago := NULL;
      END IF;

    END IF;

    x_estado := 'P';

  END Get_Datos_OC;



  PROCEDURE Verifica_Fact_Cred_Electronica ( p_codigo_cbte   IN VARCHAR2
                                           , x_es_fce        OUT BOOLEAN
                                           , x_estado        OUT VARCHAR2
                                           , x_error         OUT VARCHAR2)
  IS

    l_dummy VARCHAR2(1);

  BEGIN

    x_es_fce := FALSE;

    SELECT 'Y'
      INTO l_dummy
      FROM FND_LOOKUP_VALUES_VL  flv
         , FND_LOOKUP_VALUES_DFV flvd
     WHERE 1=1
       AND flvd.row_id                = flv.rowid
       AND flvd.context               = flv.attribute_category
       AND flv.lookup_type            = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
       AND TO_NUMBER(flv.lookup_code) = TO_NUMBER(p_codigo_cbte)
       AND flv.meaning                LIKE '%(FCE)%';


    x_es_fce := TRUE;
    x_estado := 'P';


  EXCEPTION
    WHEN no_data_found THEN
      x_estado := 'P';

    WHEN others THEN
      x_estado := 'E';
      x_error  := 'Error al verificar si el comprobante es de tipo Factura de Crédito Electrónica: '||SQLERRM;

  END;




  PROCEDURE Valida_Datos_Capturados ( p_emisor_cuit             IN NUMBER
                                    , p_receptor_cuit           IN NUMBER
                                    , p_codigo_moneda           IN VARCHAR2
                                    , p_importe_cbte            IN NUMBER
                                    , p_cotizacion_cbte         IN NUMBER
                                    , p_fecha_emision_cbte      IN DATE
                                    , p_tipo_anticipo           IN VARCHAR2
                                    , p_orden_compra        IN OUT NUMBER
                                    , p_codigo_cbte             IN VARCHAR2
                                    , p_sucursal_proveedor      IN VARCHAR2
                                    , p_cbu                     IN VARCHAR2
                                    , x_emisor_vendor_id       OUT NUMBER
                                    , x_emisor_party_id        OUT NUMBER
                                    , x_emisor_vendor_site_id  OUT NUMBER
                                    , x_emisor_party_site_id   OUT NUMBER
                                    , x_accts_pay_cc_id        OUT NUMBER
                                    , x_org_id                 OUT NUMBER
                                    , x_set_of_books_id        OUT NUMBER
                                    , x_legal_entity_id        OUT NUMBER
                                    , x_base_amount            OUT NUMBER
                                    , x_exchange_rate          OUT NUMBER
                                    , x_exchange_rate_type     OUT VARCHAR2
                                    , x_exchange_date          OUT DATE
                                    , x_created_by             OUT NUMBER
                                    , x_tipo_cbte              OUT VARCHAR2
                                    , x_terms_id               OUT NUMBER
                                    , x_ext_bank_account_id    OUT NUMBER
                                    , x_primera_fecha_pago     OUT DATE
                                    , x_es_fce                 OUT BOOLEAN
                                    , x_error                  OUT VARCHAR2
                                    , x_estado                 OUT VARCHAR2
                                    ) IS

    le_accts_pay_cc_id        NUMBER;

  BEGIN

    x_estado := NULL;
    x_error  := NULL;

    Get_datos_Emisor ( p_emisor_cuit            => p_emisor_cuit
                     , x_emisor_vendor_id       => x_emisor_vendor_id
                     , x_emisor_party_id        => x_emisor_party_id
                     , x_accts_pay_cc_id        => le_accts_pay_cc_id
                     , x_estado                 => x_estado
                     , x_error                  => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;


    Get_Datos_Receptor ( p_receptor_cuit    => p_receptor_cuit
                       , x_org_id           => x_org_id
                       , x_set_of_books_id  => x_set_of_books_id
                       , x_legal_entity_id  => x_legal_entity_id
                       , x_estado           => x_estado
                       , x_error            => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;




    Get_Datos_Sucursal ( p_emisor_cuit                 => p_emisor_cuit
                       , p_vendor_id                   => x_emisor_vendor_id
                       , p_sucursal                    => p_sucursal_proveedor
                       , p_org_id                      => x_org_id
                       , p_emisor_accts_pay_cc_id      => le_accts_pay_cc_id
                       , x_emisor_vendor_site_id       => x_emisor_vendor_site_id
                       , x_emisor_party_site_id        => x_emisor_party_site_id
                       , x_accts_pay_cc_id             => x_accts_pay_cc_id
                       , x_estado                      => x_estado
                       , x_error                       => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;


    Get_Datos_Conversion ( p_codigo_moneda        => p_codigo_moneda
                         , p_set_of_books_id      => x_set_of_books_id
                         , p_importe_cbte         => p_importe_cbte
                         , p_cotizacion_cbte      => p_cotizacion_cbte
                         , p_fecha_emision_cbte   => p_fecha_emision_cbte
                         , x_base_amount          => x_base_amount
                         , x_exchange_rate        => x_exchange_rate
                         , x_exchange_rate_type   => x_exchange_rate_type
                         , x_exchange_date        => x_exchange_date
                         , x_estado               => x_estado
                         , x_error                => x_error);


    IF (x_estado = 'E') THEN
      RETURN;
    END IF;



    Get_Usuario_Creador ( x_user_id => x_created_by
                        , x_estado  => x_estado
                        , x_error   => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;


    Get_Tipo_Comprobante ( p_codigo_cbte   => p_codigo_cbte
                         , p_tipo_anticipo => p_tipo_anticipo
                         , x_tipo_cbte     => x_tipo_cbte
                         , x_estado        => x_estado
                         , x_error         => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;


    Get_Id_Termino_Pago ( p_vendor_id      => x_emisor_vendor_id
                        , p_vendor_site_id => x_emisor_vendor_site_id
                        , p_org_id         => x_org_id                          --CR2388
                        , x_terms_id       => x_terms_id
                        , x_estado         => x_estado
                        , x_error          => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;


    Get_Cuenta_Bancaria ( p_org_id               => x_org_id
                        , p_cbu                  => p_cbu
                        , p_party_id             => x_emisor_party_id
                        , p_party_site_id        => x_emisor_party_site_id
                        , p_currency_code        => p_codigo_moneda
                        , x_ext_bank_account_id  => x_ext_bank_account_id
                        , x_estado               => x_estado
                        , x_error                => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;



    Get_Datos_OC ( p_tipo_anticipo      => p_tipo_anticipo
                 , p_orden_compra       => p_orden_compra
                 , x_primera_fecha_pago => x_primera_fecha_pago
                 , x_estado             => x_estado
                 , x_error              => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;


    Verifica_Fact_Cred_Electronica ( p_codigo_cbte   => p_codigo_cbte
                                   , x_es_fce        => x_es_fce
                                   , x_estado        => x_estado
                                   , x_error         => x_error);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;



    x_estado := 'P';


  END Valida_Datos_Capturados;



  PROCEDURE Busca_Cbte_en_Repositorio ( p_cuit_emisor     IN VARCHAR2
                                      , p_cuit_receptor   IN VARCHAR2
                                      , p_codigo_cbte     IN VARCHAR2
                                      , p_invoice_num     IN VARCHAR2
                                      , x_rowid          OUT ROWID
                                      , x_estado_cbte    OUT VARCHAR2
                                      , x_error          OUT VARCHAR2
                                      , x_estado         OUT VARCHAR2 )
  IS

    l_invoice_id  NUMBER;

  BEGIN

    x_estado := 'E';

    SELECT rowid
         , invoice_id
         , UPPER(estado)
      INTO x_rowid
         , l_invoice_id
         , x_estado_cbte
      FROM XX_AP_MIPYME_CBTES
     WHERE cuit_emisor             = p_cuit_emisor
       AND cuit_receptor           = p_cuit_receptor
       AND codigo_tipo_comprobante = TO_NUMBER(p_codigo_cbte)
       AND punto_venta             = TO_NUMBER(SUBSTR(p_invoice_num, 1, 4))
       AND numero_comprobante      = TO_NUMBER(SUBSTR(p_invoice_num, 6, 12))
       FOR UPDATE NOWAIT;

    IF (l_invoice_id IS NULL) THEN

      x_estado  := 'P';
    ELSE

      x_error   := 'La factura de crédito electrónica ya se encuentra asociada a otro comprobante en el repositorio. ';
    END IF;

  EXCEPTION
    WHEN no_data_found THEN
      x_error   := 'No se encuentra importada la factura de crédito electrónica en el repositorio. ';

    WHEN others THEN
      x_error   := 'Error al buscar la factura de crédito electrónica en el repositorio: '||SQLERRM;

  END Busca_Cbte_en_Repositorio;



  PROCEDURE Actualiza_repositorio ( p_rowid        IN ROWID
                                  , p_invoice_id   IN NUMBER
                                  , x_error        OUT VARCHAR2
                                  , x_estado       OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';

    UPDATE XX_AP_MIPYME_CBTES
       SET invoice_id = p_invoice_id
     WHERE rowid      = p_rowid;

    COMMIT;

    x_estado := 'P';

  EXCEPTION
    WHEN OTHERS THEN
      x_error := 'Error al actualizar la factura de crédito electrónica en el repositorio: '||SQLERRM;
      ROLLBACK;
  END;


  /* CR2497 */
  PROCEDURE Check_Unique ( p_invoice_num        IN VARCHAR2
                         , p_vendor_id          IN NUMBER
                         , p_org_id             IN NUMBER
                         , p_party_site_id      IN NUMBER
                         , p_tax_auth_trx_type  IN NUMBER
                         , p_invoice_date       IN DATE
                         , p_invoice_currency   IN VARCHAR2
                         , p_invoice_amt        IN NUMBER
                         , x_error             OUT VARCHAR2
                         , x_estado            OUT VARCHAR2
                         )
  IS
  
    l_cant  NUMBER;
    
  BEGIN
    
    x_estado := 'E';
    
    SELECT count(*)
      INTO l_cant
      FROM AP_INVOICES_ALL       ai
         , AP_INVOICES_ALL2_DFV  aid
     WHERE ai.rowid                 = aid.row_id
       AND ai.cancelled_date        IS NULL
       AND ai.invoice_num           = p_invoice_num
       AND ai.vendor_id             = p_vendor_id
       AND ai.org_id                = p_org_id 
       AND ai.invoice_date          = p_invoice_date
       AND ai.invoice_currency_code = p_invoice_currency
       AND ai.invoice_amount        = p_invoice_amt
       AND (ai.party_site_id = p_party_site_id 
          OR 
           (ai.party_site_id IS NULL AND p_party_site_id IS NULL)) 
       AND aid.context_value        = 'JL.AR.APXINWKB.INVOICES'
       AND aid.tax_authority_transaction_type = p_tax_auth_trx_type
       ;
       
    IF (l_cant > 0) THEN
      x_error := 'Este comprobante ya existe. Por favor, reingresar.';
      RETURN;
    END IF;

    
    SELECT count(*)
      INTO l_cant
      FROM AP_INVOICES_ALL   ai
     WHERE ai.invoice_num    = p_invoice_num
       AND ai.vendor_id      = p_vendor_id
       AND ai.org_id         = p_org_id;
        
    IF (l_cant = 0) THEN
      x_estado := 'P';
    ELSE  
      x_error := 'Este valor ya existe. Por favor, reingresar.';
    END IF;

         
  EXCEPTION
    WHEN OTHERS THEN
      x_error := 'Error al verificar si el comprobante ya existe en AP: '||SQLERRM;
        
  END Check_Unique;                         
  /* CR2497 */
  
  
  PROCEDURE Crea_Cabecera_AP ( p_created_by                    IN NUMBER
                             , p_vendor_id                     IN NUMBER
                             , p_invoice_num                   IN VARCHAR2
                             , p_invoice_amt                   IN NUMBER
                             , p_vendor_site_id                IN NUMBER
                             , p_invoice_date                  IN DATE
                             , p_invoice_type                  IN VARCHAR2
                             , p_terms_id                      IN NUMBER
                             , p_terms_date                    IN DATE
                             , p_inv_received_date             IN DATE
                             , p_set_of_books_id               IN NUMBER
                             , p_accts_pay_ccid                IN NUMBER
                             , p_pay_group_code                IN VARCHAR2
                             , p_invoice_currency              IN VARCHAR2
                             , p_exchange_rate                 IN NUMBER
                             , p_base_amount                   IN NUMBER
                             , p_exchange_rate_type            IN VARCHAR2
                             , p_exchange_date                 IN DATE
                             , p_org_id                        IN NUMBER
                             , p_tax_inv_rec_date              IN DATE
                             , p_legal_entity_id               IN NUMBER
                             , p_external_bank_account_id      IN NUMBER
                             , p_party_id                      IN NUMBER
                             , p_party_site_id                 IN NUMBER
                             , p_po_header_id                  IN NUMBER
                             , p_primera_fecha_pago            IN DATE
                             , p_cuit_emisor                   IN NUMBER
                             , p_cuit_receptor                 IN NUMBER
                             , p_codigo_cbte                   IN VARCHAR2
                             , p_es_FCE                        IN BOOLEAN
                             , p_cust_registration_number      IN VARCHAR2
                             , p_letra_de_transaccion          IN VARCHAR2
                             , p_tipo_trx_aut_fiscal           IN VARCHAR2
                             , x_invoice_id                IN OUT NUMBER
                             , x_error                        OUT VARCHAR2
                             , x_estado                       OUT VARCHAR2
                             ) IS

      
  BEGIN

    Debug('+ Check_Unique');
    Check_Unique ( p_invoice_num        => p_invoice_num
                 , p_vendor_id          => p_vendor_id
                 , p_org_id             => p_org_id
                 , p_party_site_id      => p_party_site_id
                 , p_tax_auth_trx_type  => p_tipo_trx_aut_fiscal
                 , p_invoice_date       => p_invoice_date
                 , p_invoice_currency   => p_invoice_currency
                 , p_invoice_amt        => p_invoice_amt
                 , x_error              => x_error
                 , x_estado             => x_estado
                 );
    Debug('- Check_Unique'); 
                
    IF (x_estado = 'E') THEN
      RETURN;
    END IF;             
       

    SELECT AP_INVOICES_S.nextval 
      INTO x_invoice_id
      FROM DUAL;
      
      
    Debug('+ Insert');
    INSERT INTO ap.AP_INVOICES_ALL
      ( INVOICE_ID
      , LAST_UPDATE_DATE                   
      , LAST_UPDATED_BY                    
      , VENDOR_ID                          
      , INVOICE_NUM                        
      , INVOICE_AMOUNT                     
      , VENDOR_SITE_ID                     
      , INVOICE_DATE                       
      , SOURCE                             
      , INVOICE_TYPE_LOOKUP_CODE           
      , AMOUNT_APPLICABLE_TO_DISCOUNT         
      , TERMS_ID                           
      , TERMS_DATE                         
      , INVOICE_RECEIVED_DATE              
      , APPROVED_AMOUNT                    
      , PAY_GROUP_LOOKUP_CODE              
      , SET_OF_BOOKS_ID                    
      , ACCTS_PAY_CODE_COMBINATION_ID                     
      , INVOICE_CURRENCY_CODE              
      , PAYMENT_CURRENCY_CODE              
      , EXCHANGE_RATE                      
      , PAYMENT_STATUS_FLAG                
      , ATTRIBUTE_CATEGORY                 
      , CREATION_DATE                      
      , CREATED_BY                         
      , BASE_AMOUNT                        
      , EXCHANGE_RATE_TYPE                 
      , EXCHANGE_DATE                      
      , PAYMENT_CROSS_RATE                 
      , PAYMENT_CROSS_RATE_DATE            
      , PAY_CURR_INVOICE_AMOUNT            
      , LAST_UPDATE_LOGIN                  
      , EARLIEST_SETTLEMENT_DATE           
      , EXCLUSIVE_PAYMENT_FLAG             
      , PO_HEADER_ID                       
      , ORG_ID                             
      , GLOBAL_ATTRIBUTE_CATEGORY          
      , GLOBAL_ATTRIBUTE12                 
      , GLOBAL_ATTRIBUTE13                 
      , GLOBAL_ATTRIBUTE17                                    
      , GL_DATE                            
      , APPROVAL_ITERATION                 
      , APPROVAL_READY_FLAG                
      , WFAPPROVAL_STATUS                  
      , QUICK_CREDIT                       
      , FORCE_REVALIDATION_FLAG            
      , TAXATION_COUNTRY                   
      , TAX_INVOICE_RECORDING_DATE         
      , LEGAL_ENTITY_ID                    
      , PAYMENT_METHOD_CODE                
      , EXTERNAL_BANK_ACCOUNT_ID           
      , PARTY_ID                           
      , PARTY_SITE_ID                      
      , EXCLUDE_FREIGHT_FROM_DISCOUNT          
      , CUST_REGISTRATION_NUMBER           
      )
      VALUES
      ( x_invoice_id                                                            --INVOICE_ID
      , SYSDATE                                                                 --LAST_UPDATE_DATE                   
      , p_created_by                                                            --LAST_UPDATED_BY                    
      , p_vendor_id                                                             --VENDOR_ID                          
      , p_invoice_num                                                           --INVOICE_NUM                        
      , p_invoice_amt                                                           --INVOICE_AMOUNT                     
      , p_vendor_site_id                                                        --VENDOR_SITE_ID                     
      , p_invoice_date                                                          --INVOICE_DATE                       
      , 'XX_AP_ABBYY'                                                           --SOURCE                             
      , p_invoice_type                                                          --INVOICE_TYPE_LOOKUP_CODE           
      , p_invoice_amt                                                           --AMOUNT_APPLICABLE_TO_DISCOUNT         
      , p_terms_id                                                              --TERMS_ID                           
      , p_terms_date                                                            --TERMS_DATE                         
      , p_inv_received_date                                                     --INVOICE_RECEIVED_DATE              
      , p_invoice_amt                                                           --APPROVED_AMOUNT                    
      , p_pay_group_code                                                        --PAY_GROUP_LOOKUP_CODE              
      , p_set_of_books_id                                                       --SET_OF_BOOKS_ID                    
      , p_accts_pay_ccid                                                        --ACCTS_PAY_CODE_COMBINATION_ID                     
      , p_invoice_currency                                                      --INVOICE_CURRENCY_CODE              
      , p_invoice_currency                                                      --PAYMENT_CURRENCY_CODE              
      , p_exchange_rate                                                         --EXCHANGE_RATE                      
      , 'N'                                                                     --PAYMENT_STATUS_FLAG                
      , 'AR'                                                                    --ATTRIBUTE_CATEGORY                 
      , SYSDATE                                                                 --CREATION_DATE                      
      , p_created_by                                                            --CREATED_BY                         
      , p_base_amount                                                           --BASE_AMOUNT                        
      , p_exchange_rate_type                                                    --EXCHANGE_RATE_TYPE                 
      , p_exchange_date                                                         --EXCHANGE_DATE                      
      , 1                                                                       --PAYMENT_CROSS_RATE                 
      , p_invoice_date                                                          --PAYMENT_CROSS_RATE_DATE            
      , p_invoice_amt                                                           --PAY_CURR_INVOICE_AMOUNT            
      , -1                                                                      --LAST_UPDATE_LOGIN                  
      , p_primera_fecha_pago                                                    --EARLIEST_SETTLEMENT_DATE           
      , 'N'                                                                     --EXCLUSIVE_PAYMENT_FLAG             
      , p_po_header_id                                                          --PO_HEADER_ID                       
      , p_org_id                                                                --ORG_ID                             
      , 'JL.AR.APXINWKB.INVOICES'                                               --GLOBAL_ATTRIBUTE_CATEGORY          
      , p_letra_de_transaccion                                                  --GLOBAL_ATTRIBUTE12                 
      , p_tipo_trx_aut_fiscal                                                   --GLOBAL_ATTRIBUTE13                 
      , 'N'                                                                     --GLOBAL_ATTRIBUTE17                                    
      , SYSDATE                                                                 --GL_DATE                            
      , 0                                                                       --APPROVAL_ITERATION                 
      , 'Y'                                                                     --APPROVAL_READY_FLAG                
      , 'REQUIRED'                                                              --WFAPPROVAL_STATUS                  
      , 'N'                                                                     --QUICK_CREDIT                       
      , 'Y'                                                                     --FORCE_REVALIDATION_FLAG            
      , 'AR'                                                                    --TAXATION_COUNTRY                   
      , p_tax_inv_rec_date                                                      --TAX_INVOICE_RECORDING_DATE         
      , p_legal_entity_id                                                       --LEGAL_ENTITY_ID                    
      , 'EFT'                                                                   --PAYMENT_METHOD_CODE                
      , p_external_bank_account_id                                              --EXTERNAL_BANK_ACCOUNT_ID           
      , p_party_id                                                              --PARTY_ID                           
      , p_party_site_id                                                         --PARTY_SITE_ID                      
      , 'N'                                                                     --EXCLUDE_FREIGHT_FROM_DISCOUNT          
      , p_cust_registration_number                                              --CUST_REGISTRATION_NUMBER                  
      );
      
    COMMIT;
      
    Debug('- Insert');                       
    Debug(' invoice_id '||x_invoice_id);
    
    x_estado := 'P';



  EXCEPTION
    WHEN OTHERS THEN
      x_estado := 'E';         -- CR2497
      x_error  := 'Error insertando la cabecera para el comprobante '||p_invoice_num||' (org_id: '||p_org_id||') - '||SQLERRM;


  END Crea_Cabecera_AP;



  PROCEDURE Crea_Hold ( p_invoice_id  IN NUMBER
                      , x_error      OUT VARCHAR2
                      , x_estado     OUT VARCHAR2)
  IS

    l_hold_type  VARCHAR2(25);
    l_hold_desc  VARCHAR2(240);

  BEGIN

    x_estado := 'E';

    SELECT hold_type
         , description
      INTO l_hold_type
         , l_hold_desc
      FROM AP_HOLD_CODES_V
     WHERE hold_lookup_code = 'Hold ABBYY';


    AP_HOLDS_PKG.Insert_Single_Hold( x_invoice_id       => p_invoice_id
                                   , x_hold_lookup_code => 'Hold ABBYY'
                                   , x_hold_type        => l_hold_type
                                   , x_hold_reason      => l_hold_desc
                                   , x_held_by          => 5 );

    x_estado := 'P';

  EXCEPTION
    WHEN OTHERS THEN
      x_error  := 'Error al intentar crear el hold: '||SQLERRM;

  END;



  PROCEDURE Crea_Calendario_Pago ( p_invoice_id  IN NUMBER
                                 , p_hold_flag   IN VARCHAR2
                                 , x_error      OUT VARCHAR2
                                 , x_estado     OUT VARCHAR2)
  IS

  BEGIN

    x_estado := 'E';


    INSERT INTO AP_PAYMENT_SCHEDULES
      ( invoice_id
      , last_updated_by
      , last_update_date
      , payment_cross_rate
      , payment_num
      , amount_remaining
      , created_by
      , creation_date
      , due_date
      , gross_amount
      , hold_flag
      , last_update_login
      , payment_priority
      , payment_status_flag
      , discount_amount_remaining
      , org_id
      , external_bank_account_id
      , inv_curr_gross_amount
      , dbi_events_complete_flag
      , iby_hold_reason
      , payment_method_code)
    SELECT invoice_id                                                           -- invoice_id
         , last_updated_by                                                      -- last_updated_by
         , SYSDATE                                                              -- last_update_date
         , 1                                                                    -- payment_cross_rate
         , 1                                                                    -- payment_num
         , invoice_amount                                                       -- amount_remaining
         , created_by                                                           -- created_by
         , SYSDATE                                                              -- creation_date
         , tax_invoice_recording_date                                           -- due_date
         , invoice_amount                                                       -- gross_amount
         , p_hold_flag                                                          -- hold_flag
         , -1                                                                   -- last_update_login
         , 99                                                                   -- payment_priority
         , 'N'                                                                  -- payment_status_flag
         , 0                                                                    -- discount_amount_remaining
         , org_id                                                               -- org_id
         , external_bank_account_id                                             -- external_bank_account_id
         , invoice_amount                                                       -- inv_curr_gross_amount
         , 'N'                                                                  -- dbi_events_complete_flag
         , DECODE(p_hold_flag, 'Y', 'Factura de Crédito Electrónica Rechazada') --iby_hold_reason
         , payment_method_code                                                  -- payment_method_code
      FROM AP_INVOICES
     WHERE invoice_id = p_invoice_id;

    COMMIT;

    x_estado := 'P';

  EXCEPTION
    WHEN OTHERS THEN
      x_error := 'Error al insertar la línea de calendario de pago: '||SQLERRM;

  END Crea_Calendario_Pago;


  PROCEDURE Elimina_archivo ( p_archivo         IN VARCHAR2
                            , x_error          OUT VARCHAR2
                            , x_estado         OUT VARCHAR2)
  IS

    l_filepath  VARCHAR2(240) := 'ABBYY_REPOSITORY';
    l_dir_path  VARCHAR2(4000);
    l_fexists   BOOLEAN;
    l_flen      NUMBER;
    l_bsize     BINARY_INTEGER;


  BEGIN
    
    debug('Archivo a borrar: '||p_archivo);
    x_estado := 'E';

    BEGIN
      SELECT directory_path
        INTO l_dir_path
        FROM ALL_DIRECTORIES
       WHERE directory_name = l_filepath;
     debug('Path: '||l_dir_path);
    EXCEPTION
      WHEN OTHERS THEN
        x_error := 'Error al determinar la ruta para el directorio ABBYY: '||SQLERRM;
        RETURN;
    END;

    --Se le cambian los permisos al archivo para poder eliminarlo
    debug('+ host_command');
    host_command (p_command =>  '/usr/bin/chmod 777 '||l_dir_path||'/'||p_archivo||';');
    debug('- host_command');


    debug('+ UTL_FILE.fgetattr');
    UTL_FILE.fgetattr(l_filepath, p_archivo, l_fexists, l_flen, l_bsize);
    debug('- UTL_FILE.fgetattr');
    
    IF (l_fexists) THEN
      debug('+ UTL_FILE.fremove ');
      UTL_FILE.fremove(l_filepath, p_archivo);
      debug('- UTL_FILE.fremove ');
    ELSE
      x_error := 'No existe el archivo a borrar: '||p_archivo;
      RETURN;
    END IF;

    x_estado := 'P';

  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN
      x_error := 'File location is invalid. '||SQLERRM;

    WHEN UTL_FILE.INVALID_FILEHANDLE THEN
      x_error := 'File handle is invalid. '||SQLERRM;

    WHEN UTL_FILE.INVALID_OPERATION THEN
      x_error := 'File could not be opened or operated on as requested. '||SQLERRM;

    WHEN UTL_FILE.INTERNAL_ERROR THEN
      x_error := 'Unspecified PL/SQL error. '||SQLERRM;

    WHEN UTL_FILE.INVALID_FILENAME THEN
      x_error := 'The filename parameter is invalid. '||SQLERRM;

    WHEN UTL_FILE.ACCESS_DENIED THEN
      x_error := 'Permission to access to the file location is denied. '||SQLERRM;

    WHEN UTL_FILE.DELETE_FAILED THEN
      x_error := 'The requested file delete operation failed. '||SQLERRM;

    WHEN OTHERS THEN
      x_error := 'Error en Elimina Archivo: '||SQLERRM;

  END Elimina_archivo;



  PROCEDURE Adjunta_archivo ( p_archivo         IN VARCHAR2
                            , p_user            IN NUMBER
                            , p_set_of_books_id IN NUMBER
                            , p_invoice_id      IN NUMBER
                            , x_error          OUT VARCHAR2
                            , x_estado         OUT VARCHAR2)
  IS

    l_fhandle              UTL_FILE.file_type;
    l_filepath             VARCHAR2(4000);
    l_filename             VARCHAR2(256);
    l_extension            VARCHAR2(3);
    l_content_type         VARCHAR2(100);
    l_description          VARCHAR2(255);
    l_file_path            VARCHAR2(240) := 'ABBYY_REPOSITORY';
    l_attached_document_id NUMBER;
    l_document_id          NUMBER;
    l_media_id             NUMBER;
    l_fils                 BFILE;
    l_blob_length          INTEGER;
    x_blob                 BLOB;
    l_short_datatype_id    NUMBER;
    l_category_id          NUMBER;
    l_rowid                ROWID;
    l_seq_num              NUMBER;
    l_entity_name          VARCHAR2(100) := 'AP_INVOICES';
    l_oracle_charset       VARCHAR2(30);
    l_file_format          VARCHAR2(10);
    eAdjuntoError          EXCEPTION;
    eSelectError           EXCEPTION;

  BEGIN

    x_estado := 'E';


    BEGIN
      SELECT p_archivo
           , SUBSTR(p_archivo, INSTR(p_archivo, '.', -1)+1)
        INTO l_filename
           , l_extension
        FROM DUAL;
      debug('filename: '||l_filename||' - extension: '||l_extension);
    EXCEPTION
      WHEN OTHERS THEN
        x_error := 'Error al determinar la extensión del archivo: '||SQLERRM;
        RAISE eSelectError;
    END;

    BEGIN
      SELECT directory_path
        INTO l_filepath
        FROM ALL_DIRECTORIES
     WHERE directory_name = 'ABBYY_REPOSITORY';
     debug('path: '||l_filepath);
    EXCEPTION
      WHEN OTHERS THEN
        x_error := 'Error al determinar la ruta para el directorio ABBYY: '||SQLERRM;
        RAISE eSelectError;
    END;

    --Se le cambian los permisos al archivo para poder adjuntarlo y luego eliminarlo
    debug('+ host_command');
    host_command (p_command =>  '/usr/bin/chmod 777 '||l_filepath||'/'||l_filename||';');
    debug('- host_command');

    IF (UPPER(l_extension) = 'PDF') THEN

      l_content_type   := 'application/pdf';
      l_description    := 'Imagen';
      l_oracle_charset := 'WE8MSWIN1252';
      l_file_format    := 'binary';

    ELSIF (UPPER(l_extension) = 'TIF') THEN

      l_content_type   := 'image/tiff';
      l_description    := 'Imagen';
      l_oracle_charset := 'WE8MSWIN1252';
      l_file_format    := 'binary';

    ELSIF (UPPER(l_extension) IN ('TXT', 'CSV')) THEN

      l_content_type   := 'text/plain';
      l_description    := 'Información de Sello';
      l_oracle_charset := 'UTF8';
      l_file_format    := 'text';

    ELSE
      RAISE eAdjuntoError;

    END IF;

    BEGIN
      -- Se obtienen los ids necesarios
      SELECT FND_DOCUMENTS_S.nextval
           , FND_ATTACHED_DOCUMENTS_S.nextval
           , FND_LOBS_S.nextval
        INTO l_document_id
           , l_attached_document_id
           , l_media_id
        FROM DUAL;

      debug('document_id: '||l_document_id);
      debug('attached_document_id: '||l_attached_document_id);
      debug('media_id: '||l_media_id);
    EXCEPTION
      WHEN OTHERS THEN
        x_error := 'Error al determinar los ids: '||SQLERRM;
        RAISE eSelectError;
    END;

    -- Crea el archivo BLOB
    debug('+ Creacion de archivo BLOB');
    l_fils := BFILENAME (l_file_path, l_filename);

    DBMS_LOB.fileopen (l_fils, DBMS_LOB.file_readonly);

    l_blob_length := DBMS_LOB.getlength (l_fils);

    DBMS_LOB.fileclose (l_fils);
    debug('- Creacion de archivo BLOB');

    BEGIN
      -- Inserta un nuevo registro en la tabla conteniendo el archivo especificado
      -- y un LOB LOCATOR
      -- Devuelve el LOB LOCATOR y se lo asigna a x_blob.
      debug('+ Insert FND_LOBS');
      INSERT INTO FND_LOBS
        ( file_id, file_name, file_content_type, upload_date, expiration_date
        , program_name, program_tag, file_data, LANGUAGE, oracle_charset, file_format)
      VALUES
        ( l_media_id, l_filename, l_content_type, SYSDATE, NULL
        , 'FNDATTCH', NULL, EMPTY_BLOB (), 'ESA', l_oracle_charset, l_file_format)
      RETURNING file_data
           INTO x_blob;
      debug('- Insert FND_LOBS');
    EXCEPTION
      WHEN OTHERS THEN
        x_error := 'Error al insertar el registro en FND_LOBS: '||SQLERRM;
        RAISE eSelectError;
    END;


    -- Carga el archivo en la base de datos como un BLOB
    debug('+ Ingreso del archivo BLOB en la base de datos');
    DBMS_LOB.OPEN (l_fils, DBMS_LOB.lob_readonly);

    DBMS_LOB.OPEN (x_blob, DBMS_LOB.lob_readwrite);

    DBMS_LOB.loadfromfile (x_blob, l_fils, l_blob_length);

    DBMS_LOB.CLOSE (x_blob);

    DBMS_LOB.CLOSE (l_fils);

    COMMIT;
    debug('- Ingreso del archivo BLOB en la base de datos');
    
    BEGIN
      -- Asocia el archivo a un documento
      SELECT datatype_id
        INTO l_short_datatype_id
        FROM FND_DOCUMENT_DATATYPES
       WHERE name     = 'FILE'
         AND language = 'ESA';
      debug('short_datatype_id: '||l_short_datatype_id);
    EXCEPTION
      WHEN OTHERS THEN
        l_short_datatype_id := 6;
    END;

    BEGIN
      SELECT category_id
        INTO l_category_id
        FROM FND_DOCUMENT_CATEGORIES_VL
       WHERE user_name IN ( 'Para Cuentas a Pagar'
                          , 'Para Contas a Pagar'
                          , 'To Payables');
      debug('category_id: '||l_category_id);
    EXCEPTION
      WHEN OTHERS THEN
        l_category_id := 37;
    END;


    debug('+ FND_DOCUMENTS.insert_row');
    FND_DOCUMENTS_PKG.insert_row ( x_rowid             => l_rowid
                                 , x_document_id       => l_document_id
                                 , x_creation_date     => SYSDATE
                                 , x_created_by        => p_user
                                 , x_last_update_date  => SYSDATE
                                 , x_last_updated_by   => p_user
                                 , x_last_update_login => -1
                                 , x_datatype_id       => l_short_datatype_id
                                 , x_security_id       => p_set_of_books_id
                                 , x_publish_flag      => 'Y'
                                 , x_category_id       => l_category_id
                                 , x_security_type     => 2
                                 , x_usage_type        => 'S'
                                 , x_language          => 'ESA'
                                 , x_description       => l_description
                                 , x_file_name         => l_filename
                                 , x_media_id          => l_media_id );

    COMMIT;
    debug('- FND_DOCUMENTS.insert_row');

    -- Información según idioma
    debug('+ FND_DOCUMENTS_TL.insert_tl_row');
    FND_DOCUMENTS_PKG.insert_tl_row ( x_document_id       => l_document_id
                                    , x_creation_date     => SYSDATE
                                    , x_created_by        => p_user
                                    , x_last_update_date  => SYSDATE
                                    , x_last_updated_by   => p_user
                                    , x_last_update_login => -1
                                    , x_language          => 'ESA'
                                    , x_description       => l_description );
    COMMIT;
    debug('- FND_DOCUMENTS_TL.insert_tl_row');

    BEGIN
      -- Asocia archivo ya en base de datos, a la linea del documento

      SELECT NVL(MAX (seq_num), 0) + 10
        INTO l_seq_num
        FROM FND_ATTACHED_DOCUMENTS
       WHERE pk1_value   = p_invoice_id
         AND entity_name = l_entity_name;
      debug('seq_num: '||l_seq_num);
    EXCEPTION
      WHEN OTHERS THEN
        x_error := 'Error al buscar el numero de secuencia: '||SQLERRM;
        RAISE eSelectError;
    END;
    
    debug('+ FND_ATTACHED_DOCUMENTS_PKG.insert_row');
    FND_ATTACHED_DOCUMENTS_PKG.insert_row ( x_rowid                    => l_rowid
                                          , x_attached_document_id     => l_attached_document_id
                                          , x_document_id              => l_document_id
                                          , x_creation_date            => SYSDATE
                                          , x_created_by               => p_user
                                          , x_last_update_date         => SYSDATE
                                          , x_last_updated_by          => p_user
                                          , x_last_update_login        => -1
                                          , x_seq_num                  => l_seq_num
                                          , x_entity_name              => l_entity_name
                                          , x_column1                  => NULL
                                          , x_pk1_value                => p_invoice_id
                                          , x_pk2_value                => NULL
                                          , x_pk3_value                => NULL
                                          , x_pk4_value                => NULL
                                          , x_pk5_value                => NULL
                                          , x_automatically_added_flag => 'Y'
                                          , x_datatype_id              => l_short_datatype_id
                                          , x_category_id              => l_category_id
                                          , x_security_type            => 2
                                          , x_security_id              => p_set_of_books_id
                                          , x_publish_flag             => 'Y'
                                          , x_language                 => 'ESA'
                                          , x_description              => l_description
                                          , x_file_name                => l_filename
                                          , x_media_id                 => l_media_id );
    COMMIT;
    debug('- FND_ATTACHED_DOCUMENTS_PKG.insert_row');

    debug('+ Elimina_archivo');
    Elimina_archivo ( p_archivo => l_filename
                    , x_error   => x_error
                    , x_estado  => x_estado);

    IF (x_estado = 'E') THEN
      RETURN;
    END IF;
    debug('- Elimina_archivo');
    
    x_estado := 'P';

  EXCEPTION
    WHEN DBMS_LOB.ACCESS_ERROR THEN
      x_error := 'You are trying to write too much data to the LOB: LOB size is limited to 4 gigabytes. '||SQLERRM;

    WHEN DBMS_LOB.CONTENTTYPE_TOOLONG THEN
      x_error := 'The length of the contenttype string exceeds the defined maximum. Modify the length of the contenttype string and retry the operation. '||SQLERRM;

    WHEN DBMS_LOB.CONTENTTYPEBUF_WRONG THEN
      x_error := 'The length of the contenttype buffer is less than defined constant. Modify the length of the contenttype buffer and retry the operation. '||SQLERRM;

    WHEN DBMS_LOB.INVALID_ARGVAL THEN
      x_error := 'The argument is expecting a non-NULL, valid value but the argument value passed in is NULL, invalid, or out of range. '||SQLERRM;

    WHEN DBMS_LOB.INVALID_DIRECTORY THEN
      x_error := 'The directory used for the current operation is not valid if being accessed for the first time, or if it has been modified by the DBA since the last access. '||SQLERRM;

    WHEN DBMS_LOB.NOEXIST_DIRECTORY THEN
      x_error := 'The directory leading to the file does not exist. '||SQLERRM;

    WHEN DBMS_LOB.NOPRIV_DIRECTORY THEN
      x_error := 'The user does not have the necessary access privileges on the directory or the file for the operation. '||SQLERRM;

    WHEN DBMS_LOB.OPEN_TOOMANY THEN
      x_error := 'The number of open files has reached the maximum limit. '||SQLERRM;

    WHEN DBMS_LOB.OPERATION_FAILED THEN
      x_error := 'The operation attempted on the file failed. '||SQLERRM;

    WHEN DBMS_LOB.SECUREFILE_BADLOB THEN
      x_error := 'A non-SECUREFILE LOB type was used in a SECUREFILE only call. '||SQLERRM;

    WHEN DBMS_LOB.SECUREFILE_BADPARAM THEN
      x_error := 'An invalid argument was passed to a SECUREFILE subprogram '||SQLERRM;

    WHEN DBMS_LOB.SECUREFILE_MARKERASED THEN
      x_error := 'The mark provided to a FRAGMENT_* operation has been deleted. '||SQLERRM;

    WHEN DBMS_LOB.SECUREFILE_OUTOFBOUNDS THEN
      x_error := 'Attempted to perform a FRAGMENT_* operation past the LOB end. '||SQLERRM;

    WHEN DBMS_LOB.UNOPENED_FILE THEN
      x_error := 'The file is not open for the required operation to be performed. '||SQLERRM;

    WHEN eSelectError THEN
      x_error := 'Error en Adjunta Archivo: '||x_error;

    WHEN eAdjuntoError THEN
      x_error := 'No se puede identificar el tipo de archivo a adjuntar. '||SQLERRM;

    WHEN OTHERS THEN
      x_error := 'Error al adjuntar archivo '||l_filepath||'/'||l_filename||': '||SQLERRM;

  END Adjunta_archivo;



  PROCEDURE Inserta_Resultado ( p_scan_id    IN NUMBER
                              , p_proceso_id IN NUMBER
                              , p_estado     IN VARCHAR2
                              , p_error_msg  IN VARCHAR2
                              ) IS

  BEGIN


    INSERT INTO XX_AP_ABBYY_RESPUESTAS
      ( SCAN_ID
      , PROCESO_ID
      , ESTADO
      , MENSAJE
      , FECHA_CREACION)
    VALUES
      ( p_scan_id
      , p_proceso_id
      , p_estado
      , p_error_msg
      , SYSDATE);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      G_DEBUG_FLAG := 'Y';
      Debug('Error al insertar el registro de resultado para p_scan_id: '||p_scan_id||' - '||SQLERRM);
      G_DEBUG_FLAG := 'N';

  END Inserta_Resultado;



  /***************************************************************************
  *                      P U B L I C    R O U T I N E S                      *
  ****************************************************************************/


  PROCEDURE Inserta_Cabecera ( p_scan_id               IN NUMBER
                             , p_page_images           IN VARCHAR2
                             , p_csv_file              IN VARCHAR2
                             , p_cuit_empresa          IN VARCHAR2   --         Receptor
                             , p_cuit_proveedor        IN VARCHAR2   --         Emisor
                             , p_nro_cbte              IN VARCHAR2
                             , p_tipo_cbte             IN VARCHAR2
                             , p_codigo_cbte           IN VARCHAR2
                             , p_letra_cbte            IN VARCHAR2
                             , p_fecha_emision         IN DATE
                             , p_fecha_vto             IN DATE
                             , p_fecha_recepcion       IN DATE
                             , p_termino_pago          IN VARCHAR2
                             , p_grupo_pago            IN VARCHAR2
                             , p_importe               IN NUMBER
                             , p_moneda                IN VARCHAR2
                             , p_cotizacion            IN NUMBER
                             , p_tipo_oc               IN VARCHAR2
                             , p_orden_compra          IN VARCHAR2
                             , p_tipo_anticipo         IN VARCHAR2
                             , p_cant_direcciones      IN VARCHAR2
                             , p_tipo_asoc             IN VARCHAR2
                             , p_campo                 IN VARCHAR2
                             , p_cuenta_nro            IN VARCHAR2
                             , p_unidad_negocio        IN VARCHAR2
                             , p_producto              IN VARCHAR2
                             , p_unidad_productiva     IN VARCHAR2
                             , p_centro_costos         IN VARCHAR2
                             , p_proyecto              IN VARCHAR2
                             , p_sucursal_proveedor    IN VARCHAR2
                             , p_cuenta_bancaria       IN VARCHAR2  -- CBU
                             , p_proceso_id            IN NUMBER
                             ) IS

    l_emisor_vendor_id      NUMBER;
    l_emisor_party_id       NUMBER;
    l_emisor_party_site_id  NUMBER;
    l_emisor_vendor_site_id NUMBER;
    l_accts_pay_cc_id       NUMBER;
    l_org_id                NUMBER;
    l_set_of_books_id       NUMBER;
    l_legal_entity_id       NUMBER;
    l_base_amount           NUMBER;
    l_exchange_rate         NUMBER;
    l_exchange_rate_type    VARCHAR2(30);
    l_exchange_date         DATE;
    l_created_by            NUMBER;
    l_tipo_cbte             VARCHAR2(150);
    l_terms_id              NUMBER;
    l_ext_bank_account_id   NUMBER;
    l_po_header_id          NUMBER := p_orden_compra;
    l_invoice_id            NUMBER;
    l_primera_fecha_pago    DATE;
    l_es_FCE                BOOLEAN;
    l_filepath              VARCHAR2(240) := 'ABBYY_REPOSITORY';
    eInsertError            EXCEPTION;
    x_estado                VARCHAR2(1);
    x_error_msg             VARCHAR2(4000);
    x_error_e1              VARCHAR2(240);
    x_error_e2              VARCHAR2(240);
    l_hold_flag             VARCHAR2(1);
    /*  CR2497  */
    l_estado_cbte           VARCHAR2(50);  
    l_rowid_FCE             ROWID;
    /*  CR2497  */
    

  BEGIN
    Debug(' Inicio: '||TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
    Debug(' p_scan_id: '||p_scan_id);
    Debug(' p_page_images: '||p_page_images);
    Debug(' p_csv_file : '||p_csv_file );
    Debug(' p_cuit_empresa: '||p_cuit_empresa);
    Debug(' p_cuit_proveedor: '||p_cuit_proveedor);
    Debug(' p_nro_cbte : '||p_nro_cbte);
    Debug(' p_tipo_cbte: '||p_tipo_cbte);
    Debug(' p_codigo_cbte: '||p_codigo_cbte);
    Debug(' p_letra_cbte : '||p_letra_cbte );
    Debug(' p_fecha_emision: '||p_fecha_emision);
    Debug(' p_fecha_vto: '||p_fecha_vto);
    Debug(' p_fecha_recepcion: '||p_fecha_recepcion);
    Debug(' p_termino_pago: '||p_termino_pago);
    Debug(' p_grupo_pago: '||p_grupo_pago);
    Debug(' p_importe: '||p_importe);
    Debug(' p_moneda: '||p_moneda);
    Debug(' p_cotizacion: '||p_cotizacion);
    Debug(' p_tipo_oc: '||p_tipo_oc);
    Debug(' p_orden_compra: '||p_orden_compra);
    Debug(' p_tipo_anticipo: '||p_tipo_anticipo);
    Debug(' p_cant_direcciones: '||p_cant_direcciones);
    Debug(' p_tipo_asoc: '||p_tipo_asoc);
    Debug(' p_campo: '||p_campo);
    Debug(' p_cuenta_nro: '||p_cuenta_nro);
    Debug(' p_unidad_negocio: '||p_unidad_negocio);
    Debug(' p_producto: '||p_producto);
    Debug(' p_unidad_productiva: '||p_unidad_productiva);
    Debug(' p_centro_costos: '||p_centro_costos);
    Debug(' p_proyecto: '||p_proyecto);
    Debug(' p_sucursal_proveedor: '||p_sucursal_proveedor);
    Debug(' p_cuenta_bancaria: '||p_cuenta_bancaria);

    --==================================================================================
    --
    -- Con los datos leídos por ABBYY se obtienen los necesarios para crear la cabecera
    --
    --==================================================================================
    Debug('+ Valida_Datos_Capturados');
    Valida_Datos_Capturados ( p_emisor_cuit            => p_cuit_proveedor
                            , p_receptor_cuit          => p_cuit_empresa
                            , p_codigo_moneda          => p_moneda
                            , p_importe_cbte           => p_importe
                            , p_cotizacion_cbte        => p_cotizacion
                            , p_fecha_emision_cbte     => p_fecha_emision
                            , p_tipo_anticipo          => p_tipo_anticipo
                            , p_orden_compra           => l_po_header_id
                            , p_codigo_cbte            => p_codigo_cbte
                            , p_sucursal_proveedor     => p_sucursal_proveedor
                            , p_cbu                    => p_cuenta_bancaria
                            , x_emisor_vendor_id       => l_emisor_vendor_id
                            , x_emisor_party_id        => l_emisor_party_id
                            , x_emisor_vendor_site_id  => l_emisor_vendor_site_id
                            , x_emisor_party_site_id   => l_emisor_party_site_id
                            , x_accts_pay_cc_id        => l_accts_pay_cc_id
                            , x_org_id                 => l_org_id
                            , x_set_of_books_id        => l_set_of_books_id
                            , x_legal_entity_id        => l_legal_entity_id
                            , x_base_amount            => l_base_amount
                            , x_exchange_rate          => l_exchange_rate
                            , x_exchange_rate_type     => l_exchange_rate_type
                            , x_exchange_date          => l_exchange_date
                            , x_created_by             => l_created_by
                            , x_tipo_cbte              => l_tipo_cbte
                            , x_terms_id               => l_terms_id
                            , x_ext_bank_account_id    => l_ext_bank_account_id
                            , x_primera_fecha_pago     => l_primera_fecha_pago
                            , x_es_fce                 => l_es_FCE
                            , x_error                  => x_error_msg
                            , x_estado                 => x_estado
                            );

    Debug('- Valida_Datos_Capturados');
    
    IF (x_estado = 'E') THEN
      Debug(x_error_msg);
      RAISE eInsertError;
    END IF;


    --========================================================================
    --
    -- Seteo de unidad operativa
    --
    --========================================================================

    IF (l_org_id IS NULL OR l_created_by IS NULL) THEN
      RETURN;
    END IF;
    MO_GLOBAL.set_policy_context ('S', l_org_id);


    /*  CR2497 Se trae la busqueda de cbtes en Repositorio del procedimiento Crea_Cabecera_AP */
    l_hold_flag := 'N';

    IF ( l_es_FCE ) THEN

      Debug('+ Busca_Cbte_en_Repositorio');
      Busca_Cbte_en_Repositorio ( p_cuit_emisor    => p_cuit_proveedor
                                , p_cuit_receptor  => p_cuit_empresa
                                , p_codigo_cbte    => p_codigo_cbte
                                , p_invoice_num    => p_nro_cbte
                                , x_rowid          => l_rowid_FCE
                                , x_estado_cbte    => l_estado_cbte
                                , x_error          => x_error_msg
                                , x_estado         => x_estado );
      Debug('- Busca_Cbte_en_Repositorio');
      
      IF ( x_estado = 'E' ) THEN
        Debug(x_error_msg);
        RAISE eInsertError;
      END IF;

      IF (l_estado_cbte = 'RECHAZADO') THEN
        l_hold_flag := 'Y';
      END IF;

    END IF;
    /*  CR2497  */
    
    
    --=========================================================================
    --
    -- Creación de cabecera en AP_INVOICES_ALL
    --
    --=========================================================================
    Debug('+ Crea_Cabecera_AP');
    Crea_Cabecera_AP ( p_created_by                => l_created_by
                     , p_vendor_id                 => l_emisor_vendor_id
                     , p_invoice_num               => p_nro_cbte
                     , p_invoice_amt               => p_importe
                     , p_vendor_site_id            => l_emisor_vendor_site_id
                     , p_invoice_date              => p_fecha_emision
                     , p_invoice_type              => l_tipo_cbte
                     , p_terms_id                  => l_terms_id
                     , p_terms_date                => p_fecha_recepcion
                     , p_inv_received_date         => p_fecha_recepcion
                     , p_set_of_books_id           => l_set_of_books_id
                     , p_accts_pay_ccid            => l_accts_pay_cc_id
                     , p_pay_group_code            => p_grupo_pago
                     , p_invoice_currency          => p_moneda
                     , p_exchange_rate             => l_exchange_rate
                     , p_base_amount               => l_base_amount
                     , p_exchange_rate_type        => l_exchange_rate_type
                     , p_exchange_date             => l_exchange_date
                     , p_org_id                    => l_org_id
                     , p_tax_inv_rec_date          => p_fecha_vto
                     , p_legal_entity_id           => l_legal_entity_id
                     , p_external_bank_account_id  => l_ext_bank_account_id
                     , p_party_id                  => l_emisor_party_id
                     , p_party_site_id             => l_emisor_party_site_id
                     , p_po_header_id              => l_po_header_id
                     , p_primera_fecha_pago        => l_primera_fecha_pago
                     , p_cuit_emisor               => p_cuit_proveedor
                     , p_cuit_receptor             => p_cuit_empresa
                     , p_codigo_cbte               => p_codigo_cbte
                     , p_es_fce                    => l_es_FCE
                     , p_cust_registration_number  => p_cuit_empresa
                     , p_letra_de_transaccion      => p_letra_cbte
                     , p_tipo_trx_aut_fiscal       => p_codigo_cbte
                     , x_invoice_id                => l_invoice_id
                     --, x_hold_flag                 => l_hold_flag            CR2497
                     , x_error                     => x_error_msg
                     , x_estado                    => x_estado
                     );

    Debug('- Crea_Cabecera');
    
    IF (x_estado = 'E') THEN
      Debug(x_error_msg);
      RAISE eInsertError;
    /*ELSIF (l_invoice_id IS NULL) THEN                                         CR2497 Se dejó de usar la API por lo tanto 
                                                                               si no hay insert se termina en error

      BEGIN
        SELECT invoice_id
          INTO l_invoice_id
          FROM AP_INVOICES
         WHERE invoice_num          = p_nro_cbte
           AND created_by           = l_created_by
           AND org_id               = l_org_id;

      EXCEPTION
        WHEN no_data_found THEN
          x_error_msg := 'No se obtuvo invoice_id para el comprobante '||p_nro_cbte;
          Debug(x_error_msg);
          RAISE eInsertError;

        WHEN others THEN
          x_error_msg := 'Error al intentar encontrar el invoice_id para el comprobante '||SQLERRM;
          Debug(x_error_msg);
          RAISE eInsertError;
      END;*/

    END IF;

    
    /* CR2497 Se trae la actualización del repositorio FCE desde el procedure Crea_cabecera_AP */
    IF ( l_es_FCE ) THEN

      Debug('+ Actualiza_repositorio ');
      Actualiza_repositorio ( p_rowid          => l_rowid_FCE
                            , p_invoice_id     => l_invoice_id
                            , x_error          => x_error_msg
                            , x_estado         => x_estado );
      Debug('- Actualiza_repositorio ');
      
      IF ( x_estado = 'E' ) THEN
        Debug(x_error_msg);
        RAISE eInsertError;
      END IF;


    END IF;
    /* CR2497  */
   

    --=========================================================================
    --
    -- Crea el hold para identificar las facturas leídas por ABBYY
    --
    --=========================================================================
    Debug('+ Crea_Hold ');
    Crea_Hold ( p_invoice_id  => l_invoice_id
              , x_error       => x_error_msg
              , x_estado      => x_estado);
    
    Debug('- Crea_Hold ');
    
    IF (x_estado = 'E') THEN
      Debug(x_error_msg);
      RAISE eInsertError;
    END IF;


    --=========================================================================
    --
    -- Inserta linea en la tabla AP_PAYMENT_SCHEDULES
    --
    --=========================================================================
    Debug('+ Crea_Calendario_Pago ');
    Crea_Calendario_Pago ( p_invoice_id  => l_invoice_id
                         , p_hold_flag   => l_hold_flag
                         , x_error       => x_error_msg
                         , x_estado      => x_estado);

    Debug('- Crea_Calendario_Pago ');
    
    IF (x_estado = 'E') THEN
      Debug(x_error_msg);
      RAISE eInsertError;
    END IF;



    --=========================================================================
    --
    -- Adjunta imagen escaneada a pdf
    --
    --=========================================================================
    Debug('+ Adjunta_archivo Imagen ');
    Adjunta_archivo ( p_archivo         => p_page_images
                    , p_user            => l_created_by
                    , p_set_of_books_id => l_set_of_books_id
                    , p_invoice_id      => l_invoice_id
                    , x_error           => x_error_msg
                    , x_estado          => x_estado);

    Debug('- Adjunta_archivo Imagen ');
    
    IF (x_estado = 'E') THEN
      Debug(x_error_msg);
      RAISE eInsertError;
    END IF;


    --=========================================================================
    --
    -- Adjunta informacion de sellos en archivo CSV
    --
    --=========================================================================
    Debug('+ Adjunta_archivo Texto ');
    Adjunta_archivo ( p_archivo         => p_csv_file
                    , p_user            => l_created_by
                    , p_set_of_books_id => l_set_of_books_id
                    , p_invoice_id      => l_invoice_id
                    , x_error           => x_error_msg
                    , x_estado          => x_estado);

    Debug('- Adjunta_archivo Texto ');
    
    IF (x_estado = 'E') THEN
      Debug(x_error_msg);
      RAISE eInsertError;
    END IF;

    Debug('+ Inserta_Resultado ');
    Inserta_Resultado (p_scan_id, p_proceso_id, 'P', NULL);
    Debug('- Inserta_Resultado ');

  EXCEPTION
    WHEN eInsertError THEN
      Debug(x_error_msg);

      Elimina_archivo ( p_archivo  => p_page_images
                      , x_error    => x_error_e1
                      , x_estado   => x_estado);

      IF (x_estado = 'E') THEN
        Debug(x_error_e1);
        x_error_msg := x_error_msg ||' - '||x_error_e1;
      END IF;


      Elimina_archivo ( p_archivo  => p_csv_file
                      , x_error    => x_error_e2
                      , x_estado   => x_estado);

      IF (x_estado = 'E') THEN
        Debug(x_error_e2);
        x_error_msg := x_error_msg ||' - '||x_error_e2;
      END IF;

      Inserta_Resultado (p_scan_id, p_proceso_id, 'E', x_error_msg);

    WHEN OTHERS THEN
      x_error_msg := 'Error insertando cabecera de comprobante '||p_nro_cbte||': '||SQLERRM;
      Debug(x_error_msg);

      Elimina_archivo ( p_archivo  => p_page_images
                      , x_error    => x_error_e1
                      , x_estado   => x_estado);

      IF (x_estado = 'E') THEN
        Debug(x_error_e1);
        x_error_msg := x_error_msg ||' - '||x_error_e1;
      END IF;


      Elimina_archivo ( p_archivo  => p_csv_file
                      , x_error    => x_error_e2
                      , x_estado   => x_estado);

      IF (x_estado = 'E') THEN
        Debug(x_error_e2);
        x_error_msg := x_error_msg ||' - '||x_error_e2;
      END IF;

      Inserta_Resultado (p_scan_id, p_proceso_id, 'E', x_error_msg);

  END Inserta_Cabecera;


  PROCEDURE Obtiene_ticket_acceso_WSCDC ( p_cuit_representado  IN VARCHAR2
                                        , x_token             OUT VARCHAR2
                                        , x_sign              OUT VARCHAR2
                                        , x_result            OUT NUMBER
                                        , x_error_msg         OUT VARCHAR2)

  IS

    l_user_id      NUMBER;
    l_resp_id      NUMBER;
    l_resp_appl_id NUMBER;
    l_result       BOOLEAN;
    eWSCDCError    EXCEPTION;
    l_ta_cdc       XX_WS_AFIP_TICKET;
    l_request_id   NUMBER;

    CURSOR cEnv IS
      SELECT fu.user_id
           , fr.responsibility_id
           , fr.application_id
        FROM FND_RESPONSIBILITY_VL fr
           , FND_USER              fu
       WHERE fr.responsibility_name = 'ADE AR Super User ARG'
         AND fu.user_name           = 'SCHEDULED_REQUESTS';

  BEGIN


    --debug('Inicio Ticket Acceso');

    x_result    := 1;                                                           -- 1: Termina OK // 0: Termina con error
    x_error_msg := NULL;



    ------------------------------
    -- Seteo variables de entorno
    ------------------------------
    OPEN cEnv;
    FETCH cEnv INTO l_user_id
                  , l_resp_id
                  , l_resp_appl_id;
    CLOSE cEnv;


    FND_GLOBAL.apps_initialize (l_user_id, l_resp_id, l_resp_appl_id);

    -----------------
    -- Inicializo WS
    -----------------
    IF NOT XX_WS_AFIP_WSAA_PK.Set_WebService THEN
      x_result    := 0;
      x_error_msg := 'No fue posible configurar los parametros de sistema.';
      RETURN;
    END IF;


    --------------------------------
    -- Obtengo el ticket de acceso
    --------------------------------
    XX_WS_AFIP_WSAA_PK.Obtener_Ticket_Acceso( p_cuit_representado  => p_cuit_representado
                                            , p_servicio           => 'wscdc'
                                            , p_instance           => 'PRODUCCION'
                                            , x_auth_object        => l_ta_cdc
                                            , x_result             => l_result
                                            , x_error_message      => x_error_msg
                                            );

    IF (l_result) THEN
      x_token := l_ta_cdc.token;
      x_sign  := l_ta_cdc.sign;

      IF (x_token IS NULL OR x_sign IS NULL) THEN

        x_result := 0;

        BEGIN

          SELECT max(request_id)
            INTO l_request_id
            FROM FND_CONC_REQ_SUMMARY_V
           WHERE status_code         = 'E'
             AND requested_by        = l_user_id
             AND program_short_name  = 'XXWSAFIPWSAA'
             AND argument_text       LIKE '%wscdc%'
             AND trunc(request_date) = TRUNC(SYSDATE);

          x_error_msg := 'No se ha podido obtener token. El concurrente '||l_request_id||' ha finalizado con error.';

        EXCEPTION
          WHEN NO_DATA_FOUND THEN

            SELECT max(request_id)
            INTO l_request_id
            FROM FND_CONC_REQ_SUMMARY_V
           WHERE requested_by        = l_user_id
             AND program_short_name  = 'XXWSAFIPWSAA'
             AND argument_text       LIKE '%wscdc%'
             AND trunc(request_date) = TRUNC(SYSDATE);

            x_error_msg := 'No se ha podido obtener token. Por favor, revisar el concurrente '||l_request_id;

        END;

      END IF;
    ELSE
      x_token := NULL;
      x_sign  := NULL;
      x_result:= 0;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      x_result    := 0;
      x_error_msg := 'Error al intentar obtener el ticket de acceso de AFIP: '||SQLERRM;

  END Obtiene_ticket_acceso_WSCDC;

END XX_AP_ABBYY_PKG;
/

  CREATE OR REPLACE EDITIONABLE SYNONYM "ABBY"."XX_AP_ABBYY_PKG" FOR "APPS"."XX_AP_ABBYY_PKG";

exit
