  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_RI_NF_FISCAL_ENTRADAS_PKG" AS
  PROCEDURE XX_RI_REL_NF_FISCAL_ENTRADAS (ERRBUF         OUT VARCHAR2,
                                           RETCODE        OUT NUMBER,
                                           P_COMPANY      IN VARCHAR2,
                                           P_DEPOSITO_INI IN VARCHAR2,
                                           P_DEPOSITO_FIM IN VARCHAR2,
                                           P_DT_INI       IN VARCHAR2,
                                           P_DT_FIM       IN VARCHAR2);

End XX_RI_NF_FISCAL_ENTRADAS_PKG;



/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_RI_NF_FISCAL_ENTRADAS_PKG" AS
  PROCEDURE XX_RI_REL_NF_FISCAL_ENTRADAS(ERRBUF         OUT VARCHAR2,
                                           RETCODE        OUT NUMBER,
                                           P_COMPANY      IN VARCHAR2,
                                           P_DEPOSITO_INI IN VARCHAR2,
                                           P_DEPOSITO_FIM IN VARCHAR2,
                                           P_DT_INI       IN VARCHAR2,
                                           P_DT_FIM       IN VARCHAR2) AS
/*
+=============================================================================================+ --
|                     Copyright (c) 2020 Adecoagro , Sao Paulo , Brasil                       | --
|                                      All rights reserved.                                   | --
+=============================================================================================+ --
|                                                                                             | --
| FILENAME                                                                                    | --
|   XX_RI_NF_FISCAL_ENTRADAS_PKG                                                              | --                                                                       | --
|   Objetivo: XX RI Relatório Fiscal de Notas de Entrada                                      | --
|                                                                                             | --
|                                                                                             | --
| NOTES                                                                                       | --
|   Creation Date (DD/MM/YYYY): 14/11/2019                                                    | --
|   Created BY - Adecoagro - Arnaldo Souza - SD 95262                                         | --
|   Last Update 18/03/2020                                                                    | --
|                                                                                             | --
|   Update Date  Update BY       Description                                                  | --
|   14/04/2020 - Arnaldo Souza   Ajustes nos campos de ICMS - Datafix                         | --
+=============================================================================================+ --
|                                Adecoagro - Sao Paulo,SP - 2020                              | --
+=============================================================================================+ --
|                                                                                             | --
+=============================================================================================+ --
*/
--- Variaveis:
    v_linha               varchar2(2000);
    l_flag                varchar2(1);
    l_operation           number;
    l_organization_id     number;
    l_item_id             number;
   l_count_lines         number;
   l_deposito_fim       VARCHAR2(4);
   l_deposito_ini       VARCHAR2(4);

    cursor c_0 is
       SELECT a.invoice_id,
       a.registro,
       a.STATUS_REVERSAO,
      -- '' CST_IPI, -- já tem lá embaixo -- OK
    --   a.invoice_id, -- coloquei no distinct
       a.invoice_line_id,
    ----   a.unid_operacional,      --a.empresa,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
       a.operating_unit, -- PARAMETRO COMPANIA UNIDADE OPERACIONAL
       a.organization_code,     --a.planta,   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
       a.org_id,
       a.cod_org,
       a.status_ri, --  ADASSA       Alt. 1980 - Novo campo Status RI
       a.doc_fiscal,
       a.num_ri,
       a.num_nf_ri,
       to_char(a.data_nf, 'dd/mm/yyyy') data_nf,
       to_char(a.data_gl, 'dd/mm/yyyy') data_gl,
       a.fornecedor,
       a.cnpj_cpf,
       a.uf,
       a.pais,
       a.tipo,
       a.valortotal,
       a.icms_base, 
       /*case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.icms_base
      END icms_base, */-- 06/03/2020 - Novos Campos ICMS
       case
       when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
       ELSE a.item
       end item,
       a.item_id,
       case
       when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
       ELSE a.descricao
       end descricao,
       case
       when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
       ELSE a.udm
       END udm,
       case
       when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
       ELSE a.classif
       END classif,
       a.cfo,
       a.funrural_base,
       a.funrural_tax,
       a.funrural_valor,
       a.aliq_icms, 
       /*case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.aliq_icms
      END aliq_icms,*/
      a.vr_icms,
      /*case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.vr_icms
      END vr_icms,*/
       a.base_ir,
       a.aliq,
       a.valor_ir,
       to_char(a.data_condicao, 'dd/mm/yyyy') data_condicao,
       a.condicao,
       to_char(a.data_vencto, 'dd/mm/yyyy') data_vencto,
       a.vr_tot,
       a.inss_base,
       a.inss_amount,
       a.sest_senat_base,
       a.sest_senat_amount,
       a.ir_base,
       a.ir_amount,
       a.irrf_base_date,
       a.ir_categ,
       a.iss_base,
       a.iss_tax,
       a.iss_amount,
       a.icms_type,
       a.icms_tax,
       a.icms_amount,
       a.icms_st_base,
       a.icms_st_amount,
       case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
        ELSE a.quantity
      END quantity,
       case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.precoitem
      END precoitem,
       case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
          ELSE a.precototal
      END precototal,
       a.diff_icms_tax,
       a.vr_icms_item,
       a.vr_diferencial_icms,
       a.vr_dif_icms_recup,
       a.vr_recuperacao_icms,
       a.vr_recuperavel_icms_st,
       a.bc_icms_st_da_linha,
       a.vr_icms_st_linha,
       a.cod_sit_tributaria,
        case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.aliq_ipi
      END aliq_ipi,
       case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.vr_ipi
      END vr_ipi,
       case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
         ELSE a.vr_recuperacao_ipi
      END vr_recuperacao_ipi,
       case
      when a.TIPO_FRETE = 'FOB' AND a.doc_fiscal = 'CT-e' then NULL
        ELSE a.indicador_tributacao_ipi
      END indicador_tributacao_ipi,
       a.location_code,
       a.criador,
       a.aprovador,
       a.series,
       a.indicador_icms,
       a.icms_base_item, -- novo campo para a linha item
       a.base_calculo_porcent_reduzida, -- ICMS_BASE_REDUC_PERC -- 06-03-2020 Novos Campos ICMS
       a.conta_contabil,
       a.name,
       a.estado,
       a.eletronic_invoice_key chave_nfe,
       decode(a.cst_ipi, 0, null, cst_ipi) cst_ipi,
       decode(a.cst_pis, 0, null, cst_pis) cst_pis,
       decode(a.cst_cofins, 0, null, cst_cofins) cst_cofins,
       a.cofins_recup_frt,
       a.cofins_recup_nff,
       a.icms_recup_frt,
       a.icms_recup_nff,
       a.ipi_recup,
       a.pis_recup_frt,
       a.pis_recup_nff,
       a.marca_homologada,
       a.entrada_fisica
FROM ( SELECT DISTINCT 'OPERACAO_FISCAL' REGISTRO,
                      ri.invoice_id,
                      ril.invoice_line_id,
                      NVL(DECODE(REO.reversion_flag, 'S', 'REVERSAO', 'R', 'REVERTIDA', REO.reversion_flag), 'NORMAL')  STATUS_REVERSAO,
                      ril.db_code_combination_id,
                      haou_ou.name                    unid_operacional , --b.co_code empresa,   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                      mp.organization_code ,                  --a.orgn_code planta,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                      ri.organization_id              org_id,
                      ood.operating_unit              operating_unit,
                      mp.organization_code            cod_org,
                      reo.status                      status_ri, --  ADASSA       Alt. 1980 - Novo campo Status RI
                      haou.name                       organizacao,
                      ri.invoice_num                  nf,
                      ri.invoice_date                 data_nf,
                      flv.meaning                     doc_fiscal, -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
                      ri.operation_id                 num_ri,
                      ri.invoice_id                   inv_id,
                      trunc(reo.gl_date)              data_gl,
                      pv.vENDor_name                  fornecedor,
                      pv.vENDor_type_lookup_code      tipo_fornecedor,
                      pvsa.cpf                        cnpj_cpf,
                      pvsa.address_line4              uf,
                      pvsa.country                    pais,       -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                      rit.invoice_type_code           tipo,
                      ri.invoice_num                  num_nf_ri,
                      ri.invoice_amount               valortotal,
                      ri.icms_base                  icms_base, -- 06/03/2020 - Novos Campos ICMS
                      msib.segment1                   item,
                      ril.item_id,
                      msib.description                descricao,
                      msib.primary_uom_code           udm,
                      msib.global_attribute1          classif,
                      rcu.description                 cfo,
                      ri.funrural_base                funrural_base,
                      ri.funrural_tax                 funrural_tax,
                      ri.funrural_amount              funrural_valor,
                      ri.icms_tax                     aliq_icms, --nf
                      ri.icms_amount                  vr_icms, --nf
                      ri.ir_base                      base_ir,
                      ri.ir_tax                       aliq,
                      ri.ir_amount                    valor_ir,
                      ri.terms_date                   data_condicao,
                      ats.name                        condicao,
                      ri.first_payment_date           data_vencto,
                      ri.invoice_amount               vr_tot,
                      ri.inss_base,
                      ri.inss_amount,
                      ri.sest_senat_base,
                      ri.sest_senat_amount,
                      ri.ir_base,
                      ri.ir_amount,
                      ri.irrf_base_date,
                      ri.ir_categ,
                      ri.iss_base,
                      ri.iss_tax,
                      ri.iss_amount,
                      ri.icms_type,
                     -- ril.icms_base, -- tá lá embaixo esse por item
                      ril.icms_tax,
                      ril.icms_amount,
                      ril.icms_st_base,
                      ril.icms_st_amount,
                      ril.quantity,
                      ril.unit_price                  precoitem,
                      ril.total_amount                precototal,
                      ril.diff_icms_tax,
                      ril.icms_amount                 vr_icms_item,
                      ril.diff_icms_amount            vr_diferencial_icms,
                      ril.diff_icms_amount_recover    vr_dif_icms_recup,
                      ril.icms_amount_recover         vr_recuperacao_icms,
                      ril.icms_st_amount_recover      vr_recuperavel_icms_st,
                      ril.icms_st_base                bc_icms_st_da_linha,
                      ril.icms_st_amount              vr_icms_st_linha,
                      ril.importation_pis_amount      vr_pis_importacao,
                      ril.pis_unit_amount             vr_unit_pis,
                      ril.pis_amount                  vr_pis,
                      ril.importation_cofins_amount   vr_cofins_importacao,
                      ril.cofins_amount               vr_cofins,
                      ril.cofins_unit_amount          vr_unit_cofins,
                      ril.tributary_status_code       cod_sit_tributaria,
                      hla.location_code,
                      fu1.user_name                  Criador, -- SD 91590 - Arnaldo - 03/05/2019
                      fu.user_name                   Aprovador, -- SD 91590 - Arnaldo - 03/05/2019
                      ri.series,
                      ril.ipi_tax                     aliq_ipi,
                      ril.ipi_amount                  vr_ipi,
                      ril.ipi_amount_recover          vr_recuperacao_ipi,
                      ril.ipi_tax_code                indicador_tributacao_ipi,
                      decode(ril.icms_tax_code,
                             '1',
                             '1 - NORMAL',
                             '2',
                             '2 - ISENTO',
                             '3',
                             '3 - OUTROS') indicador_icms,
                     ril.icms_base        icms_base_item, -- novo campo base item icms 18-03-2020 - Arnaldo Souza
                     ril.icms_base_reduc_perc       base_calculo_porcent_reduzida, -- 06-03-2020 Novos Campos ICMS
                     NVL(gcc.Concatenated_Segments,(SELECT gcc1.Concatenated_Segments
                               FROM gl_code_combinations_kfv  gcc1,
                                    po_line_locations_all      plla1,
                                    po_distributions_all      pda1
                               WHERE gcc1.code_combination_id = pda1.code_combination_id
                               AND pda1.line_location_id = plla1.line_location_id
                               AND ril.line_location_id = plla1.line_location_id
                               AND ROWNUM = 1)) conta_contabil, -- SD 91590 - Arnaldo - 30/04/2019 -- tania alves - 28/09/2010 - hd 12257
                      ------ novo SELECT withholding tax group 28/03/2011- arnaldo souza
                      (SELECT aag.name
                         FROM ap_awt_groups aag
                        WHERE aag.group_id = ril.awt_group_id
                          AND rownum = 1) name,
                      -- SELECT do fornecedor e seus ENDere?os
                      (SELECT site.state estado
                         FROM ap_suppliers vend
                            , ap_supplier_sites_all site
                        WHERE vend.vendor_id = pvsa.vendor_id -- fornecedor
                          AND vendor_site_id = pvsa.vendor_site_id
                          AND rownum = 1) estado, -- END
                      to_char(ri.eletronic_invoice_key)       eletronic_invoice_key, -- coluna chave nfe- 02/05/2011
                      ril.ipi_tributary_code cst_ipi,
                      ril.pis_tributary_code cst_pis,
                      ril.cofins_tributary_code cst_cofins,
                      --------------- cofins_recup_frt - cham 13132- arnaldo souza- 13/05/2011
                      (SELECT rid.functional_dr || rid.functional_cr cofins_recup_frt
                         FROM cll_f189_invoice_dist rid
                        WHERE reference = 'COFINS RECUP FRT'
                          AND rid.vendor_site_id = pvsa.vendor_site_id
                          AND ri.operation_id = rid.operation_id
                          AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND rownum = 1) COFINS_RECUP_FRT,
                      --------------- COFINS_RECUP_NFF  - cham 13132- Arnaldo Souza- 13/05/2011
                      ril.COFINS_AMOUNT_RECOVER    COFINS_RECUP_NFF,     -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                      ---------------  ICMS_RECUP_FRT  - cham 13132- Arnaldo Souza- 13/05/2011
                      (SELECT rid.functional_dr || rid.functional_cr ICMS_RECUP_FRT
                         FROM cll_f189_invoice_dist rid
                        WHERE reference = 'ICMS RECUP FRT'
                          AND rid.vendor_site_id = pvsa.vendor_site_id
                          AND ri.operation_id = rid.operation_id
                          AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND rownum = 1) ICMS_RECUP_FRT,
                      --------------- ICMS_RECUP_NFF  - cham 13132- Arnaldo Souza- 13/05/2011
                      ril.ICMS_AMOUNT_RECOVER     ICMS_RECUP_NFF,   -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                      --------------- IPI_RECUP  - cham 13132- Arnaldo Souza- 13/05/2011
                      (SELECT rid.functional_dr || rid.functional_cr IPI_RECUP
                         FROM cll_f189_invoice_dist rid
                        WHERE reference = 'IPI RECUP'
                          AND rid.vendor_site_id = pvsa.vendor_site_id
                          AND ri.operation_id = rid.operation_id
                          AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND rownum = 1) IPI_RECUP,
                      --------------- PIS_RECUP_FRT  - cham 13132- Arnaldo Souza- 13/05/2011
                      (SELECT rid.functional_dr || rid.functional_cr PIS_RECUP_FRT
                         FROM cll_f189_invoice_dist rid
                        WHERE reference = 'PIS RECUP FRT'
                          AND rid.vendor_site_id = pvsa.vendor_site_id
                          AND ri.operation_id = rid.operation_id
                          AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ??Ã?Â§Ã??Ã?Â£o campos RECUP
                          AND rownum = 1) PIS_RECUP_FRT,
                      --------------- PIS_RECUP_NFF  - cham 13132- Arnaldo Souza- 13/05/2011
                      ril.PIS_AMOUNT_RECOVER   PIS_RECUP_NFF,    -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                      -- Marca homologada - sd alt 24 - Arnaldo Souza - 06/10/2011
                      (SELECT msi_2.attribute5
                         FROM mtl_system_items_b msi_2
                       WHERE msib.inventory_item_id = msi_2.inventory_item_id   --iim_2.ITEM_NO = msi_2.segment1
                          AND msib.organization_id   = msi_2.organization_id
                          AND rownum = 1
                      ) MARCA_HOMOLOGADA,    --Upgrade R12 - Luiz Chacon - 18.OUT.2017
                      ri.attribute11 ENTRADA_FISICA,
                      decode(reo.freight_flag,
                            'C',
                            'CIF',
                            'F',
                            'FOB',
                            'N',
                            'Sem FRETE') TIPO_FRETE
                FROM  cll_f189_invoice_dist          rid, --- cofins recup - 02/05/2011
                      cll_f189_invoices              ri,
                      cll_f189_invoice_lines         ril,
                      cll_f189_distributions         rd,
                      gl_code_combinations_kfv       gcc, -- SD 91590 - Arnaldo - 30/04/2019
                      mtl_system_items_b             msib,
                      cll_f189_invoice_types         rit,
                      hr_all_organization_units      haou,
                      org_organization_definitions   ood,    --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                      hr_all_organization_units      haou_ou,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                      hr_locations_all               hla,
                      mtl_parameters                 mp,
                      --ic_whse_mst a,   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                      --sy_orgn_mst b,   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                      cll_f189_fiscal_entities_all   rfea,
                      cll_f189_entry_operations      reo,
                      ap_suppliers                   pv,
                      (SELECT DISTINCT pvsa.vendor_id,
                                       pvsa.vendor_site_id,
                                       pvsa.address_line4,
                              pvsa.country,    -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                                       DECODE(pvsa.global_attribute9,
                                              '1',
                                              pvsa.global_attribute10 || '-' ||
                                              pvsa.global_attribute12,
                                              '2',
                                              pvsa.global_attribute10 || '/' ||
                                              pvsa.global_attribute11 || '-' ||
                                              pvsa.global_attribute12) cpf
                         FROM ap_supplier_sites_all pvsa)  pvsa,
                      cll_f189_cfo_utilizations            rcu,
                      fnd_user        fu, -- SD 91590 - Arnaldo - 03/05/2019
                      fnd_user        fu1, -- SD 91590 - Arnaldo - 03/05/2019
                      ap_terms        ats,
                 fnd_lookup_values    flv    -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
               WHERE ri.invoice_id              = ril.invoice_id
                 AND ril.invoice_line_id        = rd.invoice_line_id (+)
                 AND ril.db_code_combination_id = gcc.code_combination_id (+) -- Tania Alves - 28/09/2010 - HD 12257
                 AND ril.item_id                = msib.inventory_item_id (+)
                 AND ril.organization_id        = msib.organization_id (+)
                 AND ri.invoice_type_id         = rit.invoice_type_id (+)
                 AND ri.organization_id         = haou.organization_id (+)
                 AND ri.location_id             = hla.location_id (+)
                 AND haou.organization_id       = mp.organization_id (+)
                 AND ri.organization_id         = reo.organization_id (+)
                 AND ri.operation_id            = reo.operation_id (+)
                 AND ri.entity_id               = rfea.entity_id
                 AND rfea.vendor_site_id        = pvsa.vendor_site_id (+)
                 AND pvsa.vendor_id             = pv.vendor_id (+)
                 AND ril.cfo_id                 = rcu.cfo_id (+)
                 AND ril.utilization_id         = rcu.utilization_id (+)
                 AND ri.last_updated_BY         = fu.user_id (+) -- para o Ã?Âºltimo aprovador  -- SD 91590 - Arnaldo - 03/05/2019
                 AND ri.created_BY              = fu1.user_id (+) -- para o Criador RI -- SD 91590 - Arnaldo - 03/05/2019
                 AND ri.terms_id                = ats.term_id (+)
                 AND haou.organization_id       = ood.organization_id       --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 AND ood.operating_unit         = haou_ou.organization_id   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 --AND a.orgn_code = b.orgn_code           --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 --AND b.orgn_code = mp.process_orgn_code  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 --AND mp.organization_code = a.whse_code  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 AND ri.operation_id            = rid.operation_id (+) -- Linhas sem OC -- Alt 137 - Arnaldo Souza -- 11/10/2011
             and ri.ORGANIZATION_id         = rid.organization_id (+)                 -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                 and ril.invoice_line_id        = rid.invoice_line_id (+)                 -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                 and ri.fiscal_document_model   = flv.lookup_code                    -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
             and flv.lookup_type            = 'CLL_F189_FISCAL_DOCUMENT_MODEL'   -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
             and flv.language               = USERENV ('LANG')               -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
              --
              UNION
              --
            SELECT DISTINCT 'CONHECIMENTO_FRETE' registro, -- ctrc
                     rfi.invoice_id,
                     NULL                         invoice_line_id, -- SD 91590 - Arnaldo - 03/05/2019
                     NVL(DECODE(REO.reversion_flag, 'S', 'REVERSAO', 'R', 'REVERTIDA', REO.reversion_flag), 'NORMAL')  STATUS_REVERSAO,
                     NULL                         db_code_combination_id, -- SD 91590 - Arnaldo - 03/05/2019
                     haou_ou.name                 unid_operacional , --b.co_code empresa,   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                     mp.organization_code ,            --a.orgn_code planta,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                     ri.organization_id            org_id,
                     ood.operating_unit              operating_unit,
                     mp.organization_code          cod_org,
                     reo.status                    status_ri, --  ADASSA       Alt. 1980 - Novo campo Status RI
                     haou.name                     organizacao,
                     rfi.invoice_num               nf,
                     rfi.invoice_date              data_nf,
                     flv.meaning                   doc_fiscal, -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
                     rfi.operation_id              num_ri,
                     rfi.invoice_id                inv_id,
                     trunc(reo.gl_date)            data_gl,
                     pv.vendor_name                fornecedor,
                     pv.vendor_type_lookup_code    tipo_fornecedor,
                     pvsa.cpf                      cnpj_cpf,
                     pvsa.address_line4            uf,
                     pvsa.country                  pais,       -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                     rit.invoice_type_code         tipo,
                     rfi.invoice_num               num_nf_ri,
                     rfi.invoice_amount            valortotal,
                     rfi.ICMS_BASE                 icms_base, -- 06/03/2020 - Novos Campos ICMS
                     NULL                          item, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          item_id, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          descricao, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          udm, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          classif, -- SD 91590 - Arnaldo - 03/05/2019
                     fop.cfo_code                  cfo, -- rcu.description cfo SD 91590 - Arnaldo - 03/05/2019
                     0 funrural_base, --ri.funrural_base
                     0 funrural_tax, --ri.funrural_tax
                     0 funrural_valor, --ri.funrural_amount
                 --    rfi.icms_base                 base_icms, --ctrc
                     rfi.icms_tax                  aliq_icms, -- ctrc
                     rfi.icms_amount               vr_icms, -- ctrc
                     ri.ir_base                    base_ir,
                     rfi.ir_tax,
                     rfi.ir_amount                 valor_ir,
                     rfi.terms_date                data_condicao,
                     ats.name                      condicao,
                     rfi.first_payment_date        data_vencto,
                     rfi.invoice_amount,
                     ri.inss_base,
                     ri.inss_amount,
                     ri.sest_senat_base,
                     ri.sest_senat_amount,
                     ri.ir_base,
                     rfi.ir_amount,
                     rfi.irrf_base_date,
                     rfi.ir_categ,
                     ri.iss_base,
                     ri.iss_tax,
                     ri.iss_amount,
                     rfi.icms_type,
                   --  rfi.icms_base                 icms_base,
                     rfi.icms_tax,
                     rfi.icms_amount,
                     NULL                          icms_st_base, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          icms_st_amount, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          quantity, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          precoitem, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                          precototal, -- SD 91590 - Arnaldo - 03/05/2019
                     rfi.diff_icms_tax,
                     rfi.icms_amount vr_icms_item,
                     rfi.diff_icms_amount vr_diferencial_icms,
                     rfi.diff_icms_amount_recover vr_diferencial_icms_recup,
                      (Select rds.functional_dr from apps.cll_f189_distributions rds
                      where rds.operation_id = rd.operation_id
                      and rds.organization_id = rd.organization_id
                      and reference = 'ICMS RECOVER FRT'
                      and rownum =1 )  vr_recuperacao_icms, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_recuperavel_icms_st, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           bc_icms_st_da_linha, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_icms_st_linha, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_pis_importacao, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_unit_pis, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_pis, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_cofins_importacao, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_cofins, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_unit_cofins, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           cod_sit_tributaria, -- SD 91590 - Arnaldo - 03/05/2019
                     hla.location_code,
                     fu1.user_name                  Criador,
                     fu.user_name                   Aprovador,
                     rfi.series,
                     NULL                           aliq_ipi, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_ipi, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           vr_recuperacao_ipi, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           indicador_tributacao_ipi, -- SD 91590 - Arnaldo - 03/05/2019
                     decode(rfi.ICMS_TAX_CODE,
                             '1',
                             '1 - NORMAL',
                             '2',
                             '2 - ISENTO',
                             '3',
                             '3 - OUTROS')                           INDICADOR_ICMS, -- SD 91590 - Arnaldo - 03/05/2019
                     null                  icms_base_item, -- novo campo icms linha item
                     NULL                           base_calculo_porcent_reduzida, -- 06-03-2020 Novos Campos ICMS
                     NVL(gcc.Concatenated_Segments,(SELECT gcc1.Concatenated_Segments
                     FROM gl_code_combinations_kfv  gcc1,
                          po_line_locations_all      plla1,
                          po_distributions_all      pda1
                     WHERE gcc1.code_combination_id = pda1.code_combination_id
                     AND pda1.line_location_id = plla1.line_location_id
                     AND ril.line_location_id = plla1.line_location_id
                     AND ROWNUM = 1)) conta_contabil, -- SD 91590 - Arnaldo - 30/04/2019
                     ------ novo SELECT withholding tax group 28/03/2011- arnaldo souza
                     (SELECT aag.name
                        FROM apps.ap_awt_groups aag
                       WHERE aag.group_id = ril.awt_group_id) name,
                     -- SELECT do Fornecedor e seus Enderecos
                     (SELECT site.state estado
                        FROM apps.ap_suppliers vend
                           , apps.ap_supplier_sites_all site
                       WHERE vend.vendor_id = pvsa.vendor_id -- fornecedor
                         AND vendor_site_id = pvsa.vendor_site_id) estado, -- END
                     to_char(rfi.eletronic_invoice_key)            eletronic_invoice_key, -- coluna chave nfe- 02/05/2010- arnaldo souza- hd 13132
                     ----- csts ipi, pis e cofins - arnaldo souza- hd 16442- 13/05/2011
                     NULL                              cst_ipi, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                              cst_pis, -- SD 91590 - Arnaldo - 03/05/2019
                     NULL                           cst_cofins, -- SD 91590 - Arnaldo - 03/05/2019
                     --------------- cofins_recup_frt - cham 13132- arnaldo souza- 13/05/2011
                     (SELECT rid.functional_dr || rid.functional_cr cofins_recup_frt
                        FROM apps.cll_f189_invoice_dist rid
                       WHERE reference = 'COFINS RECUP FRT'
                         AND rid.vendor_site_id = pvsa.vendor_site_id
                         AND ri.operation_id = rid.operation_id
                         AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ?Â§Ã?Â£o campos RECUP
                         AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ?Â§Ã?Â£o campos RECUP
                      ) COFINS_RECUP_FRT,
                     NULL                              COFINS_RECUP_NFF,     -- SD 91590 - Arnaldo - 03/05/2019
                     ---------------  ICMS_RECUP_FRT  - cham 13132- Arnaldo Souza- 13/05/2011
                     (SELECT rid.functional_dr || rid.functional_cr ICMS_RECUP_FRT
                        FROM apps.cll_f189_invoice_dist rid
                       WHERE reference = 'ICMS RECUP FRT'
                         AND rid.vendor_site_id = pvsa.vendor_site_id
                         AND ri.operation_id = rid.operation_id
                         AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ?Â§Ã?Â£o campos RECUP
                         AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ?Â§Ã?Â£o campos RECUP
                      ) ICMS_RECUP_FRT,
                     NULL                               ICMS_RECUP_NFF,    -- SD 91590 - Arnaldo - 03/05/2019
                     --------------- IPI_RECUP  - cham 13132- Arnaldo Souza- 13/05/2011
                     (SELECT rid.functional_dr || rid.functional_cr IPI_RECUP
                        FROM apps.cll_f189_invoice_dist rid
                       WHERE reference = 'IPI RECUP'
                         AND rid.vendor_site_id = pvsa.vendor_site_id
                         AND ri.operation_id = rid.operation_id
                         AND rid.organization_id = ri.organization_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ?Â§Ã?Â£o campos RECUP
                         AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  Alt 440- Arnaldo Souza- CorreÃ?Â§Ã?Â£o campos RECUP
                      ) IPI_RECUP,
                     --------------- PIS_RECUP_FRT  - cham 13132- Arnaldo Souza- 13/05/2011
                     (SELECT rid.functional_dr || rid.functional_cr PIS_RECUP_FRT
                        FROM apps.cll_f189_invoice_dist rid
                       WHERE reference = 'PIS RECUP FRT'
                         AND rid.vendor_site_id = pvsa.vendor_site_id
                         AND ri.operation_id = rid.operation_id
                         AND rid.organization_id = ri.organization_id -- 02/02/2012  alt 440- arnaldo souza- CorreÃ?Â§Ã?Â£o campos recup
                         AND ri.invoice_type_id = rid.invoice_type_id -- 02/02/2012  alt 440- arnaldo souza- CorreÃ?Â§Ã?Â£o campos recup
                      ) pis_recup_frt,
                     NULL                          PIS_RECUP_NFF,  -- SD 91590 - Arnaldo - 03/05/2019
                     -- Marca homologada - sd alt 24 - Arnaldo Souza - 06/10/2011
                     NULL                              MARCA_HOMOLOGADA,  -- SD 91590 - Arnaldo - 03/05/2019
                     ri.attribute11,
                     decode(reo.freight_flag,
                            'C',
                            'CIF',
                            'F',
                            'FOB',
                            'N',
                            'Sem FRETE') TIPO_FRETE
                FROM apps.cll_f189_invoice_dist rid, -- cofins/ipi/pis - arnaldo souza- 02/05/2011- hd 16442
                     apps.cll_f189_invoices ri,
                     apps.cll_f189_invoice_lines ril,
                     apps.cll_f189_freight_invoices rfi, -- ctrc
                     apps.hr_all_organization_units haou,
                     apps.org_organization_definitions  ood,    --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                     apps.hr_all_organization_units   haou_ou,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                     apps.hr_locations_all hla,
                     apps.mtl_parameters mp,
                     --ic_whse_mst a,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                     --sy_orgn_mst b,  --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                     apps.cll_f189_entry_operations reo,
                     apps.cll_f189_fiscal_entities_all rfea,
                     apps.cll_f189_invoice_types rit,
                     apps.mtl_system_items_b msib,
                     apps.ap_suppliers pv,
                     apps.cll_f189_distributions rd,
                     apps.gl_code_combinations_kfv gcc,
                     (SELECT DISTINCT pvsa.vendor_id,
                                      pvsa.vendor_site_id,
                                      pvsa.address_line4,
                                      pvsa.country,    -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                                      DECODE(pvsa.global_attribute9,
                                             '1',
                                             pvsa.global_attribute10 || '-' ||
                                             pvsa.global_attribute12,
                                             '2',
                                             pvsa.global_attribute10 || '/' ||
                                             pvsa.global_attribute11 || '-' ||
                                             pvsa.global_attribute12) cpf
                        FROM apps.ap_supplier_sites_all pvsa) pvsa,
                      apps.cll_f189_fiscal_operations fop, -- SD 91590 -- para coluna CFOP apps.cll_f189_cfo_utilizations rcu
                      apps.fnd_user fu, -- last_updated_by -- SD 91590 - Arnaldo - 03/05/2019
                      apps.fnd_user fu1,-- created_by -- SD 91590 - Arnaldo - 03/05/2019
                      apps.ap_terms ats,
                      apps.fnd_lookup_values    flv    -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
               WHERE ri.invoice_id              = ril.invoice_id
                 AND ril.invoice_line_id        = rd.invoice_line_id (+)
                 AND ril.db_code_combination_id = gcc.code_combination_id (+) -- Tania Alves - 28/09/2010 - HD 12257
                 AND ri.operation_id            = rfi.operation_id (+)
                 AND ri.organization_id         = rfi.organization_id (+)
                 AND ri.location_id             = rfi.location_id (+)
                 AND ril.item_id                = msib.inventory_item_id (+)
                 AND ril.organization_id        = msib.organization_id (+)
                 AND rfi.invoice_type_id        = rit.invoice_type_id (+)
                 AND ri.organization_id         = haou.organization_id (+)
                 AND ri.location_id             = hla.location_id (+)
                 AND haou.organization_id       = mp.organization_id (+)
                 AND rfi.organization_id        = reo.organization_id (+)
                 AND rfi.operation_id           = reo.operation_id (+)
                 AND rfi.entity_id              = rfea.entity_id
                 AND rfea.vendor_site_id        = pvsa.vendor_site_id (+)
                 AND pvsa.vendor_id             = pv.vendor_id (+)
            --     AND ril.cfo_id                 = rcu.CFO_ID (+) -- liga com NF tela NFF - Arnaldo - SD 91590
            --     AND ril.utilization_id         = rcu.utilization_id (+) -- liga com NF tela NFF - Arnaldo - SD 91590
                 AND rfi.cfo_id                 = fop.CFO_ID (+) -- liga com CTE tela Conhecimento de Transporte - Arnaldo - SD 91590
                 AND ri.last_updated_BY         = fu.user_id (+) -- para o Ã?Âºltimo aprovador  -- SD 91590 - Arnaldo - 03/05/2019
                 AND ri.created_BY              = fu1.user_id (+) -- para o Criador RI -- SD 91590 - Arnaldo - 03/05/2019
                 AND rfi.terms_id               = ats.term_id (+)
                 AND haou.organization_id       = ood.organization_id       --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 AND ood.operating_unit         = haou_ou.organization_id   --Upgrade R12 - Luiz Chacon - 17.OUT.2017
                 AND ri.operation_id            = rid.operation_id (+) -- Linhas sem OC -- Alt 137 - Arnaldo Souza -- 11/10/2011
                 AND ri.organization_id         = rid.organization_id (+)             -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                 AND ril.invoice_line_id        = rid.invoice_line_id (+)             -- Upgrade R12 - ITC | Weslley Rodrigues | 22-03-2018
                 AND rfi.fiscal_document_model   = flv.lookup_code                            --Upgrade R12 - Luiz Chacon - 24.MAI.2018
                 AND flv.lookup_type            = 'CLL_F189_FISCAL_DOCUMENT_MODEL'            -- Upgrade R12 - ITC | Weslley Rodrigues | 23-03-2018
                 AND flv.language               = USERENV ('LANG')
                 ) A
       WHERE 1=1
         AND to_char(a.data_gl, 'yyyymmdd') >= to_char(to_date(P_DT_INI, 'dd/mm/yyyy'), 'yyyymmdd')
         AND to_char(a.data_gl, 'yyyymmdd') <= to_char(to_date(P_DT_FIM, 'dd/mm/yyyy'), 'yyyymmdd')
         AND a.org_id IN (SELECT DISTINCT organization_id
                          FROM org_organization_definitions OOD
                          WHERE 1=1
                          AND operating_unit IN ('1446','1544','196','110','109')
                          AND operating_unit = P_COMPANY
                          AND disable_date IS NULL)
       AND (P_DEPOSITO_INI IS NULL OR a.organization_code >= P_DEPOSITO_INI)
       AND (P_DEPOSITO_FIM IS NULL OR a.organization_code <= P_DEPOSITO_FIM )
       ORDER BY a.cod_org, to_date(a.data_gl, 'dd/mm/yyyy'), a.num_nf_ri;
   -- Fim Select Principal

   -- Cursor da OC
      cursor r_0 (L_invoice_line_id NUMBER) IS
      (SELECT distinct pap2.full_name  solicitante,                   -- Upgrade R12 - ITC | Weslley Rodrigues | 26-02-2018 (novo cursor adicionado)
                      pap1.full_name                requisitante,
                      prla.justification            justificativa,
                      pha.segment1                  numero_ordem_compra,
                      pha.approved_date             data_aprov_oc,
                      prha.segment1                 numero_requisicao,
                      prha.approved_date            data_aprov_req,
                      (SELECT pra.approved_date     data_aprov_liberacao
                         FROM po_releases_all pra
                        WHERE pra.po_header_id    = pda.po_header_id
                          AND pra.po_release_id   = pda.po_release_id
                          AND prha.org_id         = pra.org_id
                          AND ROWNUM = 1)   data_aprov_liberacao,
                      round(reo.gl_date -  prha.approved_date) LEAD_TIME
                from po_requisition_headers_all prha,
             po_requisition_lines_all   prla,
             po_req_distributions_all   prda,
             po_distributions_all       pda,
             po_headers_all             pha,
             po_lines_all               pla,
             mtl_system_items_b         msib,
             po_line_locations_all      plla,
             cll_f189_invoice_lines     ril,
             cll_f189_invoices          ri,
             cll_f189_entry_operations  reo,
             --apps.po_releases_all       pra,
             per_all_people_f           pap1,
             per_all_people_f           pap2
       WHERE 1 = 1
         and prha.requisition_header_id = prla.requisition_header_id
         and prla.requisition_line_id   = prda.requisition_line_id
         and prda.distribution_id       = pda.req_distribution_id
         and pda.po_header_id           = pla.po_header_id
         and pda.po_header_id           = pha.po_header_id
         and pla.item_id                = msib.inventory_item_id
         and pla.item_id                = prla.item_id
         and pla.item_id                = ril.item_id
         and msib.inventory_item_id     = prla.item_id
         and msib.inventory_item_id     = ril.item_id
         and plla.line_location_id      = pda.line_location_id
         and plla.line_location_id      = ril.line_location_id
         and pda.line_location_id       = ril.line_location_id
         and pda.po_header_id           = plla.po_header_id
         and pda.po_header_id           = pha.po_header_id
         --and pda.po_header_id           = pra.po_header_id
         and pha.po_header_id           = plla.po_header_id
         --and pha.po_header_id           = pra.po_header_id
         --and plla.po_header_id          = pra.po_header_id
         and pda.po_line_id             = plla.po_line_id
         and prha.org_id                = prla.org_id
         and prha.org_id                = pha.org_id
         and prha.org_id                = prda.org_id
         --and prha.org_id                = pra.org_id
         and prla.org_id                = pha.org_id
         and prla.org_id                = prda.org_id
         --and prla.org_id                = pra.org_id
         and prda.org_id                = pha.org_id
         --and pha.org_id                 = pra.org_id
         and ri.organization_id         = ril.organization_id
         and ri.organization_id         = reo.organization_id
         and ril.organization_id        = reo.organization_id
         and ri.operation_id            = reo.operation_id
         and ri.invoice_id              = ril.invoice_id
         --and pda.po_release_id          = pra.po_release_id
         and pap1.person_id             = prha.preparer_id
         and pap2.person_id             = prla.to_person_id
         AND ril.invoice_line_id        = L_invoice_line_id);

  BEGIN

    BEGIN
       SELECT ORGANIZATION_CODE
        INTO L_DEPOSITO_INI
        FROM ORG_ORGANIZATION_DEFINITIONS
        WHERE ORGANIZATION_CODE = P_DEPOSITO_INI;
      ---- WHERE ORGANIZATION_ID = P_DEPOSITO_INI; -- Por ID, modificado para Code
    END;

     BEGIN
       SELECT ORGANIZATION_CODE
        INTO L_DEPOSITO_FIM
        FROM ORG_ORGANIZATION_DEFINITIONS
        WHERE ORGANIZATION_CODE = P_DEPOSITO_FIM;
      ---- WHERE ORGANIZATION_ID = P_DEPOSITO_FIM; -- Por ID, modificado para Code
    END;


    BEGIN
      -- Abre o Aquivo para GravaÃ§Ã£o
      DBMS_OUTPUT.ENABLE(9000000000);
      fnd_file.put_line(fnd_file.log,
                        '========================================================================================');
      fnd_file.put_line(fnd_file.log,
                        'Abre Arquivo para Gravacao ' ||
                        to_char(sysdate, 'dd-mon-yy HH:mi:ss'));
      fnd_file.put_line(fnd_file.log, 'Valores dos parametros inseridos: ');
      fnd_file.put_line(fnd_file.log, 'Companhia = ' || to_char(P_COMPANY));
      fnd_file.put_line(fnd_file.log,
                        'Deposito Inicial = ' || to_char(L_DEPOSITO_INI) ||
                        ' Final = ' || to_char(L_DEPOSITO_FIM)); -- Douglas Sousa 24/08/2010
      fnd_file.put_line(fnd_file.log,
                        'Data Inicial = ' || to_char(P_DT_INI) ||
                        ' Data Final = ' || to_char(P_DT_FIM));
      fnd_file.put_line(fnd_file.log,
                        '                                                                                       ');
      fnd_file.put_line(fnd_file.log,
                        '========================================================================================');
    Exception
      When Others Then
        raise_application_error(-20080,
                                sqlerrm ||
                                ' Problemas na abertura do arquivo ');
    END;

    -- Titulo do Relatorio
    v_linha := '' || '|' || '' || '|' || '' || '|' || '' || '|' ||
               '                                         XX RI Relatorio Fiscal de Notas de Entrada' || '|' || '' || '|' || '';

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;

    ------------------------------------------------------------------------------------------
   v_linha := 'COMPANHIA: ' ||'|' || P_COMPANY;

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    ------------------------------------------------------------------------------------------
    v_linha := 'PLANTA/ DEPOSITO INICIAL: ' || '|' || L_DEPOSITO_INI || '|' ||
               'PLANTA/ DEPOSITO FINAL: ' || '|' || L_DEPOSITO_FIM;

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    --------------------------------------------------------------------------------------------
    v_linha := 'DATA INICIAL:     ' || '|' || P_DT_INI || '|' ||
               'DATA FINAL:     ' || '|' || P_DT_FIM;

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    -------------------------------------------------------------------------------------------------------
    v_linha := '                                                                              ';

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    -------------------------------------------------------------------------------------------------------

    v_linha := 'PLANTA' || '|' ||
               'STATUS_RI' || '|' ||
               'DOC_FISCAL' || '|' ||
               'NUM_RI' || '|' ||
               'NUM_NF_RI' || '|' ||
               'SERIES' || '|' ||
               'STATUS_REVERSAO' || '|' ||
               'DATA_NF' || '|' ||
               'DATA_GL' || '|' ||
               'DATA_FISICA' || '|' ||
               'FORNECEDOR' || '|' ||
               'CNPJ_CPF' || '|' ||
               'ESTADO' || '|' ||
               'PAIS' || '|' ||
               'TIPO' || '|' ||
               'VALOR_TOTAL' || '|' ||
               'ICMS_BASE' || '|' ||
               'ITEM' || '|' ||
               'DESCRIÃ?Ã?O' || '|' ||
               'UDM' || '|' ||
               'CLASSIF' || '|' ||
               'CFO' || '|' ||
               'VALOR_IR' || '|' ||
               'INDICADOR_ICMS' || '|' ||
               'ICMS_BASE_ITEM' || '|' ||
               'BASE_CALCULO_ICMS_%_REDUZIDA' || '|' ||
               'ICMS_TAX' || '|' ||
               'ICMS_AMOUNT' || '|' ||
               'ICMS_ST_BASE' || '|' ||
               'ICMS_ST_AMOUNT' || '|' ||
               'QUANTITY' || '|' ||
               'PRECO_ITEM' || '|' ||
               'PRECO_TOTAL' || '|' ||
               'DIFF_ICMS_TAX' || '|' ||
               'VR_ICMS_ITEM' || '|' ||
               'VR_DIFERENCIAL_ICMS' || '|' ||
               'VR_DIF_ICMS_RECUP' || '|' ||
               'VR_RECUPERACAO_ICMS' || '|' ||
               'VR_RECUPERAVEL_ICMS_ST' || '|' ||
               'BC_ICMS_ST_DA_LINHA' || '|' ||
               'VR_ICMS_ST_LINHA' || '|' ||
               'COD_SIT_TRIBUTARIA' || '|' ||
               'ALIQ_IPI' || '|' ||
               'VR_IPI' || '|' ||
               'VR_RECUP_IPI' || '|' ||
               'IND_TRIBUT_IPI' || '|' ||
               'CST_IPI' || '|' ||
               'CRIADOR_RI' || '|' ||
               'APROVADOR_RI' || '|' ||
               'CONTA_CONTABIL' || '|' ||
               'CHAVE_NFE' || '|' ||
               'JUSTIFICATIVA'|| '|' ||
               'ORDEM_COMPRA';

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;

    --- Processa os registros do cursor ---

    For v_0 in c_0 Loop

      Exit When c_0%NotFound;

     IF v_0.REGISTRO = 'OPERACAO_FISCAL' THEN
        --
        BEGIN
          --
          FOR A IN (SELECT ric.operation_id ri_complementar,
                           ric.invoice_num  nf_complementar
                      FROM cll_f189_invoices        ri,
                           cll_f189_invoices        ric,
                           cll_f189_invoice_parents recp
                     WHERE ri.invoice_id = v_0.invoice_id
                       AND ri.invoice_id = recp.invoice_id
                       AND ric.invoice_id = recp.invoice_parent_id) LOOP
            --
            iF l_flag = 0 THEN
              --
              l_flag            := 1;

            END IF;
            --
          END LOOP;
          --
        END;
        --
      END IF;
      l_flag := 0;

    l_count_lines := 0;
   --
   FOR v2_0 IN r_0 (v_0.invoice_line_id)
      LOOP

     l_count_lines := l_count_lines + 1;
     --
      v_linha := v_0.COD_ORG || '|' ||
                 v_0.STATUS_RI || '|' ||
                 v_0.DOC_FISCAL || '|' ||
                 v_0.NUM_RI || '|' ||
                 v_0.NUM_NF_RI || '|' ||
                 v_0.SERIES || '|' ||
                 v_0.STATUS_REVERSAO || '|' ||
                v_0.DATA_NF || '|' ||
                 v_0.DATA_GL || '|' ||
                 v_0.ENTRADA_FISICA || '|' ||
                 v_0.FORNECEDOR || '|' ||
                 v_0.CNPJ_CPF || '|' ||
                 V_0.ESTADO || '|' ||
                 v_0.PAIS || '|' ||
                 v_0.TIPO || '|' ||
                 v_0.VALORTOTAL || '|' ||
                 v_0.ICMS_BASE  || '|' ||
                 v_0.ITEM || '|' ||
                 v_0.DESCRICAO || '|' ||
                 v_0.UDM || '|' ||
                 v_0.CLASSIF || '|' ||
                 v_0.CFO || '|' ||
                 v_0.VALOR_IR || '|' ||
                 v_0.INDICADOR_ICMS || '|' ||
                 v_0.ICMS_BASE_ITEM || '|' ||
                 v_0.base_calculo_porcent_reduzida || '|' ||
                 v_0.ICMS_TAX || '|' ||
                 v_0.ICMS_AMOUNT || '|' ||
                 v_0.ICMS_ST_BASE || '|' ||
                 v_0.ICMS_ST_AMOUNT || '|' ||
                 v_0.QUANTITY || '|' ||
                 v_0.PRECOITEM || '|' ||
                 v_0.PRECOTOTAL || '|' ||
                 v_0.DIFF_ICMS_TAX || '|' ||
                 v_0.VR_ICMS_ITEM || '|' ||
                 v_0.VR_DIFERENCIAL_ICMS || '|' ||
                 v_0.VR_DIF_ICMS_RECUP || '|' ||
                 v_0.VR_RECUPERACAO_ICMS || '|' ||
                 v_0.VR_RECUPERAVEL_ICMS_ST || '|' ||
                 v_0.BC_ICMS_ST_DA_LINHA || '|' ||
                 v_0.VR_ICMS_ST_LINHA || '|' ||
                 v_0.COD_SIT_TRIBUTARIA || '|' ||
                 v_0.ALIQ_IPI || '|' ||
                 v_0.VR_IPI || '|' ||
                 v_0.VR_RECUPERACAO_IPI || '|' ||
                 v_0.INDICADOR_TRIBUTACAO_IPI || '|' ||
                 v_0.CST_IPI || '|' ||
                 v_0.CRIADOR || '|' ||
                 v_0.APROVADOR || '|' ||
                 v_0.CONTA_CONTABIL || '|' ||
                 to_char(v_0.CHAVE_NFE) || '|' ||
                 v2_0.JUSTIFICATIVA || '|' ||
                 v2_0.NUMERO_ORDEM_COMPRA ; 
      --- Grava o registro
        BEGIN
          Fnd_File.Put_Line(Fnd_File.Output, v_linha);
        Exception
          When Others Then
            fnd_file.put_line(fnd_file.output,
                              'Problemas na gravacao do arquivo');
            raise_application_error(-20030,
                                    sqlerrm ||
                                    ' Problemas na gravacao do arquivo ');
        END;
     --
     END LOOP;
      --
     IF l_count_lines = 0 THEN
       --
      v_linha := v_0.COD_ORG || '|' ||
                 v_0.STATUS_RI || '|' ||
                 v_0.DOC_FISCAL || '|' ||
                 v_0.NUM_RI || '|' ||
                 v_0.NUM_NF_RI || '|' ||
                 v_0.SERIES  || '|' ||
                 v_0.STATUS_REVERSAO || '|' ||
                 v_0.DATA_NF || '|' ||
                 v_0.DATA_GL || '|' ||
                 v_0.ENTRADA_FISICA || '|' ||
                 v_0.FORNECEDOR || '|' ||
                 v_0.CNPJ_CPF || '|' ||
                 V_0.ESTADO || '|' ||
                 v_0.PAIS || '|' ||
                 v_0.TIPO || '|' ||
                 v_0.VALORTOTAL || '|' ||
                 v_0.ICMS_BASE || '|' ||
                 v_0.ITEM || '|' ||
                 v_0.DESCRICAO || '|' ||
                 v_0.UDM || '|' ||
                 v_0.CLASSIF || '|' ||
                 v_0.CFO || '|' ||
                 v_0.VALOR_IR || '|' ||
                 v_0.INDICADOR_ICMS || '|' ||
                 v_0.ICMS_BASE_ITEM || '|' ||
                 v_0.base_calculo_porcent_reduzida || '|' ||
                 v_0.ICMS_TAX || '|' ||
                 v_0.ICMS_AMOUNT || '|' ||
                 v_0.ICMS_ST_BASE || '|' ||
                 v_0.ICMS_ST_AMOUNT || '|' ||
                 v_0.QUANTITY || '|' ||
                 v_0.PRECOITEM || '|' ||
                 v_0.PRECOTOTAL || '|' ||
                 v_0.DIFF_ICMS_TAX || '|' ||
                 v_0.VR_ICMS_ITEM || '|' ||
                 v_0.VR_DIFERENCIAL_ICMS || '|' ||
                 v_0.VR_DIF_ICMS_RECUP || '|' ||
                 v_0.VR_RECUPERACAO_ICMS || '|' ||
                 v_0.VR_RECUPERAVEL_ICMS_ST || '|' ||
                 v_0.BC_ICMS_ST_DA_LINHA || '|' ||
                 v_0.VR_ICMS_ST_LINHA || '|' ||
                 v_0.COD_SIT_TRIBUTARIA || '|' ||
                 v_0.ALIQ_IPI || '|' ||
                 v_0.VR_IPI || '|' ||
                 v_0.VR_RECUPERACAO_IPI || '|' ||
                 v_0.INDICADOR_TRIBUTACAO_IPI || '|' ||
                 v_0.CST_IPI || '|' ||
                 v_0.CRIADOR || '|' || 
                 v_0.APROVADOR || '|' ||
                 v_0.CONTA_CONTABIL || '|' ||
                 to_char(v_0.CHAVE_NFE) || '|' ||
                 ''  || '|' ||       
                 ''  || '|' ||       
                 ''  ;               
      --- Grava o registro
            BEGIN
              Fnd_File.Put_Line(Fnd_File.Output, v_linha);
            Exception
              When Others Then
                fnd_file.put_line(fnd_file.output,
                                  'Problemas na gravacao do arquivo');
                raise_application_error(-20030,
                                        sqlerrm ||
                                   ' Problemas na gravacao do arquivo ');
            END;
         --
     END IF;
     --
    END Loop;
    --- Fecha o Loop
  END XX_RI_REL_NF_FISCAL_ENTRADAS;
END XX_RI_NF_FISCAL_ENTRADAS_PKG;
/

exit
