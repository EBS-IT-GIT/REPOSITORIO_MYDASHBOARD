UPDATE  apps.ar_payment_schedules_all aps
SET    trx_number = 'A-0001-00002465', last_update_date = sysdate, last_updated_by = 2070
WHERE  customer_trx_id = 15390433;
--1 Registro