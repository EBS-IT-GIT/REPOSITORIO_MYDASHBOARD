UPDATE apps.ap_invoice_distributions_all
SET    attribute11 = (SELECT cash_receipt_id
                      FROM   apps.ar_cash_receipts_all
                      WHERE  receipt_number = '50'
                      AND    amount         = 57458.28)
WHERE  line_type_lookup_code  = 'ITEM'
AND    invoice_id = (SELECT invoice_id
                     FROM   apps.ap_invoices_all
                     WHERE  invoice_num = '00000-20102020 099'
                     AND    vendor_id = (SELECT vendor_id 
                                         FROM   apps.ap_suppliers asup
                                         WHERE  vendor_name = 'ABS ARGENTINA S.A.'));
--1 Registro