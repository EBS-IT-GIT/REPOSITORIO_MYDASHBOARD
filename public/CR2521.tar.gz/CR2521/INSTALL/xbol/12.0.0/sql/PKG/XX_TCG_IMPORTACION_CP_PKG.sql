  set define off;

  CREATE OR REPLACE EDITIONABLE PACKAGE "APPS"."XX_TCG_IMPORTACION_CP_PKG" AS
  CTG_REC                XX_ACO_CTG_DTL := XX_ACO_CTG_DTL();

  g_comments            VARCHAR2(250);
  g_operating_unit      NUMBER;
  g_grupo_control       VARCHAR2(20);
  g_cuit_imp            NUMBER;
  g_batch_id            NUMBER;
  gLog                  BOOLEAN := FALSE;
  gLogLevel             NUMBER;

  PROCEDURE Cargar_CP ( p_operating_unit    IN  NUMBER
                      , p_directorio        IN  VARCHAR2
                      , p_nombre_archivo    IN  VARCHAR2
                      , p_fuente            IN  VARCHAR2
                      , x_batch_id          OUT NUMBER
                      , x_error_msg         OUT VARCHAR
                      );

  PROCEDURE setDebugON ( p_active BOOLEAN );

  PROCEDURE setDebugLevel ( p_level NUMBER );
END;
/


  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "APPS"."XX_TCG_IMPORTACION_CP_PKG" AS
  PROCEDURE myDebug (message VARCHAR2, p_level NUMBER ) IS
  BEGIN
    IF gLog AND
       p_level <= gLogLevel THEN
      DBMS_OUTPUT.PUT_LINE(message);
    END IF;
  END;


  PROCEDURE concatComment( IMP_CP_REC  IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                         , p_comment          VARCHAR2
                         ) IS
  BEGIN
    IF IMP_CP_REC.COMENTARIOS IS NULL THEN
      IMP_CP_REC.COMENTARIOS := p_comment;
    ELSE
      IMP_CP_REC.COMENTARIOS := IMP_CP_REC.COMENTARIOS||' -- '||p_comment;
    END IF;
  END;


  FUNCTION getCompanyCodeOrgID ( p_cuit              IN     VARCHAR2
                               , ENTREGADORES_REC    IN OUT XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                               ) RETURN BOOLEAN IS
  BEGIN
    SELECT operating_unit
    INTO ENTREGADORES_REC.OPERATING_UNIT
    FROM xx_tcg_parametros_compania
    WHERE 1=1
    AND operating_unit_cuit = p_cuit;

    RETURN TRUE;
  EXCEPTION
    WHEN Others THEN
      myDebug('getCompanyCodeOrgID '||p_cuit||' - '||SQLERRM,1);
      RETURN FALSE;
  END;


  PROCEDURE insertHeader ( p_row_count             NUMBER
                         , p_nombre_archivo        VARCHAR2
                         , p_fuente                VARCHAR2
                         , x_error_msg      IN OUT VARCHAR2
                         ) IS
    l_exists NUMBER;
  BEGIN
    SELECT COUNT(1)
    INTO l_exists
    FROM XX_TCG_IMPORTACION_CP_HDR
    WHERE batch_id = g_batch_id
    ;

    IF l_exists > 0 THEN RETURN; END IF;

    INSERT INTO XX_TCG_IMPORTACION_CP_HDR
    ( BATCH_ID
    , BATCH_DATE
    , BATCH_SOURCE
    , FILE_NAME
    , LOAD_MESSAGE
    , IMPORTED_QTY
    , PROCESSED_QTY
    , CANCELLED_QTY
    , PENDINGS_QTY
    , OPERATING_UNIT
    , CREATED_BY
    , CREATION_DATE
    , LAST_UPDATED_BY
    , LAST_UPDATE_DATE
    , LAST_UPDATE_LOGIN
    ) VALUES
    ( g_batch_id
    , TRUNC(SYSDATE)
    , p_fuente
    , p_nombre_archivo
    , NULL
    , p_row_count
    , 0
    , 0
    , 0
    , g_operating_unit
    , FND_GLOBAL.User_ID
    , SYSDATE
    , FND_GLOBAL.USER_ID
    , SYSDATE
    , FND_GLOBAL.Login_ID
    );
  EXCEPTION
    WHEN Others THEN
      x_error_msg := 'No fue posible insertar la cabecera.'||chr(10)||SQLERRM;
  END insertHeader;


  PROCEDURE updateHeader ( x_error_msg IN OUT VARCHAR2
                         , p_cant_ou          NUMBER
                         ) IS
    CURSOR cMultiCompanies IS
      SELECT DISTINCT REPLACE(REPLACE(ou.name, 'AR ', ''), ' UO', '') ou_name
      FROM xx_tcg_archivo_entregadores ae
         , hr_operating_units          ou
      WHERE 1=1
      AND ou.organization_id = ae.operating_unit
      AND ae.operating_unit != g_operating_unit;

    l_total           NUMBER;
    l_cancelados      NUMBER;
    l_pendientes      NUMBER;
    l_first           BOOLEAN := TRUE;
    l_muti_ou_msg     VARCHAR2(2000);
  BEGIN
    SELECT COUNT(*) total, COUNT(DECODE(cancelado_flag, 'Y', 1, NULL)) cancelados, COUNT(*)  - COUNT(DECODE(cancelado_flag, 'Y', 1, NULL)) pendientes
    INTO l_total, l_cancelados, l_pendientes
    FROM XX_TCG_IMPORTACION_CP_DTL
    WHERE batch_id = g_batch_id;

    IF p_cant_ou > 1 THEN
      FOR r IN cMultiCompanies LOOP
        IF l_first THEN
          l_muti_ou_msg := 'Se crearon registros en: '||r.ou_name;
          l_first       := FALSE;
        ELSE
          l_muti_ou_msg := l_muti_ou_msg||', '||r.ou_name;
        END IF;
      END LOOP;
    END IF;

    UPDATE XX_TCG_IMPORTACION_CP_HDR
    SET imported_qty  = l_total
      , processed_qty = 0
      , cancelled_qty = l_cancelados
      , pendings_qty  = l_pendientes
      , load_message  = l_muti_ou_msg
    WHERE batch_id = g_batch_id;
  EXCEPTION
    WHEN Others THEN
      x_error_msg := 'Error actualizando totales: '||SUBSTR(SQLERRM,1,100);
  END updateHeader;


  FUNCTION insertLines ( IMP_CP_REC  IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                       , x_error_msg IN OUT VARCHAR2
                       ) RETURN BOOLEAN IS
    l_num_dummy  NUMBER;
  BEGIN
    SELECT COUNT(1)
    INTO l_num_dummy
    FROM XX_TCG_IMPORTACION_CP_DTL
    WHERE 1=1
    AND batch_id           = IMP_CP_REC.BATCH_ID
    AND numero_carta_porte = IMP_CP_REC.NUMERO_CARTA_PORTE;

    IF l_num_dummy > 0 THEN
      x_error_msg := 'Carta de Porte '||IMP_CP_REC.NUMERO_CARTA_PORTE||' duplicada.';
      concatComment(IMP_CP_REC, x_error_msg);
      myDebug(x_error_msg, 2);
      x_error_msg := NULL;

      IMP_CP_REC.CANCELADO_FLAG  := 'Y';
      IMP_CP_REC.IMP_CP_STATUS   := 'Duplicado';
    END IF;

    INSERT INTO XX_TCG_IMPORTACION_CP_DTL
    ( BATCH_ID
      --
    , CARTA_PORTE_ID
    , ORG_ID
    , OPERATING_UNIT
    , NUMERO_CARTA_PORTE
    , CARTA_PORTE_RELACIONADA
    , ITEM_ID
    , ITEM_ONCCA_CODE
    , LOT_NO
    , TIPO_GRANO
    , OBSERVACIONES
    , PESAJE_ENTRADA_FLAG
    , PESAJE_SALIDA_FLAG
    , TRANSFERIDO_FLAG
    , RECIBIDO_FLAG
    , ANULADO_FLAG
    , CANCELADO_FLAG
    , TITULAR_CP_ID
    , TITULAR_CP
    , TITULAR_CP_CUIT
    , TITULAR_CP_TIPO
    , TITULAR_CP_ESTAB_ID
    , TITULAR_CP_UBICACION
    , TITULAR_CP_PROVINCIA
    , TITULAR_CP_LOCALIDAD
    , TITULAR_CP_DIRECCION
    , TITULAR_CP_CONTRATO_ID
    , INTERMEDIARIO_ID
    , INTERMEDIARIO
    , INTERMEDIARIO_CUIT
    , INTERMEDIARIO_TIPO
    , INTERMEDIARIO_RETIRO
    , INTERMEDIARIO_CONTRATO_ID
    , RTTE_COMERCIAL_ID
    , RTTE_COMERCIAL
    , RTTE_COMERCIAL_CUIT
    , RTTE_COMERCIAL_TIPO
    , RTTE_COMERCIAL_RETIRO
    , RTTE_COMERCIAL_CONTRATO_ID
    , CORREDOR_ID
    , CORREDOR
    , CORREDOR_CUIT
    , MERCADO_TERMINO_ID
    , MERCADO_TERMINO
    , MERCADO_TERMINO_CUIT
    , CORREDOR_VENDEDOR_ID
    , CORREDOR_VENDEDOR
    , CORREDOR_VENDEDOR_CUIT
    , REPRESENTANTE_ID
    , REPRESENTANTE
    , REPRESENTANTE_CUIT
    , DESTINATARIO_ID
    , DESTINATARIO
    , DESTINATARIO_CUIT
    , DESTINATARIO_CONTRATO_ID
    , DESTINO_ID
    , DESTINO
    , DESTINO_CUIT
    , DESTINO_ESTAB_ID
    , DESTINO_UBICACION
    , DESTINO_PROVINCIA
    , DESTINO_LOCALIDAD
    , DESTINO_DIRECCION
    , DESTINO_CONTRATO_ID
    , CEE_NUMERO
    , CEE_FECHA_VENCIMIENTO
    , COT_NUMERO
    , RENSPA
    , CTG_NUMERO
    , TURNO
    , MOTIVO_RECHAZO
    , CARRIER_SERVICE_ID
    , TRANSPORTISTA_NOMBRE
    , TRANSPORTISTA_CUIT
    , CHOFER
    , CHOFER_CUIT
    , PATENTE_CAMION
    , PATENTE_ACOPLADO
    , INTERMEDIARIO_FLETE_ID
    , INTERMEDIARIO_FLETE
    , INTERMEDIARIO_FLETE_CUIT
    , PROCEDENCIA_ENGANCHADA
    , DISTANCIA_ID
    , TARIFA_NEGOCIACION_ID
    , FECHA_CALC_DISTANCIA
    , DISTANCIA_ESTIMADA
    , TARIFA_REF_FLETE_XTON
    , COSTO_FLETE_XTON
    , COSTO_FLETE
    , COSTO_FLETE_CURRENCY_CODE
    , TARIFA_CP_XTON
    , PROVISIONAR_FLETE_FLAG
    , PROVISIONADO_FLAG
    , REFACTURAR_FLETE_FLAG
    , REFACTURADO_FLAG
    , PAGADOR_FLETE_ID
    , PROVISIONADO_POR
    , FECHA_DISPONIBLE_TRANSPORTE
    , FIN_CARGA_TRANSPORTE
    , TOTAL_UNIDADES_TRANSPORTE
    , NUMERO_PEDIDO_TRANSPORTE
    , NUMERO_OPERATIVO_TRANSPORTE
    , NUMERO_GUIA_TRANSPORTE
    , ESTACION_TRANSPORTE
    , OBSERVACION_TRANSPORTE
    , ID_FACTURA_AP
    , TICKET_ENVIO_ID
    , FECHA_ENVIO
    , FECHA_CARGA
    , CANTIDAD_HORAS
    , TARA_ENVIO
    , PESO_BRUTO_ENVIO
    , PESO_ESTIMADO
    , PESO_TRANSFERIDO
    , LOTE
    , VARIEDAD
    , PCTAJE_HUMEDAD_ESTIMADA
    , PCTAJE_MERMA_HUMEDAD_ENVIO
    , PCTAJE_MATERIA_EXTRANIA_ENVIO
    , TIPO_CALIDAD_ENVIO
    , TICKET_RECEPCION_ID
    , FECHA_RECEPCION
    , PESO_BRUTO_RECEPCION
    , TARA_RECEPCION
    , INSECTOS_VIVOS_FLAG
    , PCTAJE_HUMEDAD_RECEP
    , PCTAJE_MERMA_HUMEDAD_RECEP
    , PCTAJE_ZARANDA_RECEP
    , PCTAJE_VOLATIL_RECEP
    , PCTAJE_OTROS_RECEP
    , PCTAJE_MATERIA_EXTRANIA_RECEP
    , PCTAJE_HUMEDAD_COMPRA
    , PCTAJE_MERMA_HUMEDAD_COMPRA
    , PCTAJE_ZARANDA_COMPRA
    , PCTAJE_VOLATIL_COMPRA
    , PCTAJE_OTROS_COMPRA
    , PROVISION_REQUEST_ID
    , UO_CERTIFICA
    , UO_BOLETIN
    , MERMA_HEADER_ID
    , GASTOS_ACOND_CALCULADOS_FLAG
    , FECHA_IMPRESION
      --
    , IMP_CP_STATUS
    , IMPORTADO_FLAG
    , TRANSFERIDO_IMP_FLAG
    , RECIBIDO_IMP_FLAG
    , ANULADO_IMP_FLAG
    , CP_ACOPIO_FLAG
    , CP_ACOPIO_MODIFICADA_FLAG
    , CTG_VALIDADO_FLAG
    , INCONSISTENCIA_CTG_FLAG
    , PESO_CTG
    , OTROS_DESCUENTOS_KILOS
    , COMENTARIOS
    , LINEA_IMPORTADA
      --
    , ATTRIBUTE_CATEGORY
    , ATTRIBUTE1
    , ATTRIBUTE2
    , ATTRIBUTE3
    , ATTRIBUTE4
    , ATTRIBUTE5
    , ATTRIBUTE6
    , ATTRIBUTE7
    , ATTRIBUTE8
    , ATTRIBUTE9
    , ATTRIBUTE10
    , ATTRIBUTE11
    , ATTRIBUTE12
    , ATTRIBUTE13
    , ATTRIBUTE14
    , ATTRIBUTE15
    , CREATED_BY
    , CREATION_DATE
    , LAST_UPDATED_BY
    , LAST_UPDATE_LOGIN
    , LAST_UPDATE_DATE
    ) VALUES
    ( IMP_CP_REC.BATCH_ID
      --
    , IMP_CP_REC.CARTA_PORTE_ID
    , IMP_CP_REC.ORG_ID
    , IMP_CP_REC.OPERATING_UNIT
    , IMP_CP_REC.NUMERO_CARTA_PORTE
    , IMP_CP_REC.CARTA_PORTE_RELACIONADA
    , IMP_CP_REC.ITEM_ID
    , IMP_CP_REC.ITEM_ONCCA_CODE
    , IMP_CP_REC.LOT_NO
    , IMP_CP_REC.TIPO_GRANO
    , IMP_CP_REC.OBSERVACIONES
    , IMP_CP_REC.PESAJE_ENTRADA_FLAG
    , IMP_CP_REC.PESAJE_SALIDA_FLAG
    , IMP_CP_REC.TRANSFERIDO_FLAG
    , IMP_CP_REC.RECIBIDO_FLAG
    , IMP_CP_REC.ANULADO_FLAG
    , IMP_CP_REC.CANCELADO_FLAG
    , IMP_CP_REC.TITULAR_CP_ID
    , IMP_CP_REC.TITULAR_CP
    , IMP_CP_REC.TITULAR_CP_CUIT
    , IMP_CP_REC.TITULAR_CP_TIPO
    , IMP_CP_REC.TITULAR_CP_ESTAB_ID
    , IMP_CP_REC.TITULAR_CP_UBICACION
    , IMP_CP_REC.TITULAR_CP_PROVINCIA
    , IMP_CP_REC.TITULAR_CP_LOCALIDAD
    , IMP_CP_REC.TITULAR_CP_DIRECCION
    , IMP_CP_REC.TITULAR_CP_CONTRATO_ID
    , IMP_CP_REC.INTERMEDIARIO_ID
    , IMP_CP_REC.INTERMEDIARIO
    , IMP_CP_REC.INTERMEDIARIO_CUIT
    , IMP_CP_REC.INTERMEDIARIO_TIPO
    , IMP_CP_REC.INTERMEDIARIO_RETIRO
    , IMP_CP_REC.INTERMEDIARIO_CONTRATO_ID
    , IMP_CP_REC.RTTE_COMERCIAL_ID
    , IMP_CP_REC.RTTE_COMERCIAL
    , IMP_CP_REC.RTTE_COMERCIAL_CUIT
    , IMP_CP_REC.RTTE_COMERCIAL_TIPO
    , IMP_CP_REC.RTTE_COMERCIAL_RETIRO
    , IMP_CP_REC.RTTE_COMERCIAL_CONTRATO_ID
    , IMP_CP_REC.CORREDOR_ID
    , IMP_CP_REC.CORREDOR
    , IMP_CP_REC.CORREDOR_CUIT
    , IMP_CP_REC.MERCADO_TERMINO_ID
    , IMP_CP_REC.MERCADO_TERMINO
    , IMP_CP_REC.MERCADO_TERMINO_CUIT
    , IMP_CP_REC.CORREDOR_VENDEDOR_ID
    , IMP_CP_REC.CORREDOR_VENDEDOR
    , IMP_CP_REC.CORREDOR_VENDEDOR_CUIT
    , IMP_CP_REC.REPRESENTANTE_ID
    , IMP_CP_REC.REPRESENTANTE
    , IMP_CP_REC.REPRESENTANTE_CUIT
    , IMP_CP_REC.DESTINATARIO_ID
    , IMP_CP_REC.DESTINATARIO
    , IMP_CP_REC.DESTINATARIO_CUIT
    , IMP_CP_REC.DESTINATARIO_CONTRATO_ID
    , IMP_CP_REC.DESTINO_ID
    , IMP_CP_REC.DESTINO
    , IMP_CP_REC.DESTINO_CUIT
    , IMP_CP_REC.DESTINO_ESTAB_ID
    , IMP_CP_REC.DESTINO_UBICACION
    , IMP_CP_REC.DESTINO_PROVINCIA
    , IMP_CP_REC.DESTINO_LOCALIDAD
    , IMP_CP_REC.DESTINO_DIRECCION
    , IMP_CP_REC.DESTINO_CONTRATO_ID
    , IMP_CP_REC.CEE_NUMERO
    , IMP_CP_REC.CEE_FECHA_VENCIMIENTO
    , IMP_CP_REC.COT_NUMERO
    , IMP_CP_REC.RENSPA
    , IMP_CP_REC.CTG_NUMERO
    , IMP_CP_REC.TURNO
    , IMP_CP_REC.MOTIVO_RECHAZO
    , IMP_CP_REC.CARRIER_SERVICE_ID
    , IMP_CP_REC.TRANSPORTISTA_NOMBRE
    , IMP_CP_REC.TRANSPORTISTA_CUIT
    , IMP_CP_REC.CHOFER
    , IMP_CP_REC.CHOFER_CUIT
    , IMP_CP_REC.PATENTE_CAMION
    , IMP_CP_REC.PATENTE_ACOPLADO
    , IMP_CP_REC.INTERMEDIARIO_FLETE_ID
    , IMP_CP_REC.INTERMEDIARIO_FLETE
    , IMP_CP_REC.INTERMEDIARIO_FLETE_CUIT
    , IMP_CP_REC.PROCEDENCIA_ENGANCHADA
    , IMP_CP_REC.DISTANCIA_ID
    , IMP_CP_REC.TARIFA_NEGOCIACION_ID
    , IMP_CP_REC.FECHA_CALC_DISTANCIA
    , IMP_CP_REC.DISTANCIA_ESTIMADA
    , IMP_CP_REC.TARIFA_REF_FLETE_XTON
    , IMP_CP_REC.COSTO_FLETE_XTON
    , IMP_CP_REC.COSTO_FLETE
    , IMP_CP_REC.COSTO_FLETE_CURRENCY_CODE
    , IMP_CP_REC.TARIFA_CP_XTON
    , IMP_CP_REC.PROVISIONAR_FLETE_FLAG
    , IMP_CP_REC.PROVISIONADO_FLAG
    , IMP_CP_REC.REFACTURAR_FLETE_FLAG
    , IMP_CP_REC.REFACTURADO_FLAG
    , IMP_CP_REC.PAGADOR_FLETE_ID
    , IMP_CP_REC.PROVISIONADO_POR
    , IMP_CP_REC.FECHA_DISPONIBLE_TRANSPORTE
    , IMP_CP_REC.FIN_CARGA_TRANSPORTE
    , IMP_CP_REC.TOTAL_UNIDADES_TRANSPORTE
    , IMP_CP_REC.NUMERO_PEDIDO_TRANSPORTE
    , IMP_CP_REC.NUMERO_OPERATIVO_TRANSPORTE
    , IMP_CP_REC.NUMERO_GUIA_TRANSPORTE
    , IMP_CP_REC.ESTACION_TRANSPORTE
    , IMP_CP_REC.OBSERVACION_TRANSPORTE
    , IMP_CP_REC.ID_FACTURA_AP
    , IMP_CP_REC.TICKET_ENVIO_ID
    , IMP_CP_REC.FECHA_ENVIO
    , IMP_CP_REC.FECHA_CARGA
    , IMP_CP_REC.CANTIDAD_HORAS
    , IMP_CP_REC.TARA_ENVIO
    , IMP_CP_REC.PESO_BRUTO_ENVIO
    , IMP_CP_REC.PESO_ESTIMADO
    , IMP_CP_REC.PESO_TRANSFERIDO
    , IMP_CP_REC.LOTE
    , IMP_CP_REC.VARIEDAD
    , IMP_CP_REC.PCTAJE_HUMEDAD_ESTIMADA
    , IMP_CP_REC.PCTAJE_MERMA_HUMEDAD_ENVIO
    , IMP_CP_REC.PCTAJE_MATERIA_EXTRANIA_ENVIO
    , IMP_CP_REC.TIPO_CALIDAD_ENVIO
    , IMP_CP_REC.TICKET_RECEPCION_ID
    , IMP_CP_REC.FECHA_RECEPCION
    , IMP_CP_REC.PESO_BRUTO_RECEPCION
    , IMP_CP_REC.TARA_RECEPCION
    , IMP_CP_REC.INSECTOS_VIVOS_FLAG
    , IMP_CP_REC.PCTAJE_HUMEDAD_RECEP
    , IMP_CP_REC.PCTAJE_MERMA_HUMEDAD_RECEP
    , IMP_CP_REC.PCTAJE_ZARANDA_RECEP
    , IMP_CP_REC.PCTAJE_VOLATIL_RECEP
    , IMP_CP_REC.PCTAJE_OTROS_RECEP
    , IMP_CP_REC.PCTAJE_MATERIA_EXTRANIA_RECEP
    , IMP_CP_REC.PCTAJE_HUMEDAD_COMPRA
    , IMP_CP_REC.PCTAJE_MERMA_HUMEDAD_COMPRA
    , IMP_CP_REC.PCTAJE_ZARANDA_COMPRA
    , IMP_CP_REC.PCTAJE_VOLATIL_COMPRA
    , IMP_CP_REC.PCTAJE_OTROS_COMPRA
    , IMP_CP_REC.PROVISION_REQUEST_ID
    , IMP_CP_REC.UO_CERTIFICA
    , IMP_CP_REC.UO_BOLETIN
    , IMP_CP_REC.MERMA_HEADER_ID
    , IMP_CP_REC.GASTOS_ACOND_CALCULADOS_FLAG
    , IMP_CP_REC.FECHA_IMPRESION
      --
    , IMP_CP_REC.IMP_CP_STATUS
    , IMP_CP_REC.IMPORTADO_FLAG
    , IMP_CP_REC.TRANSFERIDO_IMP_FLAG
    , IMP_CP_REC.RECIBIDO_IMP_FLAG
    , IMP_CP_REC.ANULADO_IMP_FLAG
    , IMP_CP_REC.CP_ACOPIO_FLAG
    , IMP_CP_REC.CP_ACOPIO_MODIFICADA_FLAG
    , IMP_CP_REC.CTG_VALIDADO_FLAG
    , IMP_CP_REC.INCONSISTENCIA_CTG_FLAG
    , IMP_CP_REC.PESO_CTG
    , IMP_CP_REC.OTROS_DESCUENTOS_KILOS
    , IMP_CP_REC.COMENTARIOS
    , IMP_CP_REC.LINEA_IMPORTADA
      --
    , IMP_CP_REC.ATTRIBUTE_CATEGORY
    , IMP_CP_REC.ATTRIBUTE1
    , IMP_CP_REC.ATTRIBUTE2
    , IMP_CP_REC.ATTRIBUTE3
    , IMP_CP_REC.ATTRIBUTE4
    , IMP_CP_REC.ATTRIBUTE5
    , IMP_CP_REC.ATTRIBUTE6
    , IMP_CP_REC.ATTRIBUTE7
    , IMP_CP_REC.ATTRIBUTE8
    , IMP_CP_REC.ATTRIBUTE9
    , IMP_CP_REC.ATTRIBUTE10
    , IMP_CP_REC.ATTRIBUTE11
    , IMP_CP_REC.ATTRIBUTE12
    , IMP_CP_REC.ATTRIBUTE13
    , IMP_CP_REC.ATTRIBUTE14
    , IMP_CP_REC.ATTRIBUTE15
    , IMP_CP_REC.CREATED_BY
    , IMP_CP_REC.CREATION_DATE
    , IMP_CP_REC.LAST_UPDATED_BY
    , IMP_CP_REC.LAST_UPDATE_LOGIN
    , IMP_CP_REC.LAST_UPDATE_DATE
    );

    RETURN TRUE;
  EXCEPTION
    WHEN Others THEN
      x_error_msg := SQLERRM;
      RETURN FALSE;
  END insertlines;


  PROCEDURE getCTG (IMP_CP_REC  IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE) IS
    l_cuit_representado VARCHAR2(50) := g_cuit_imp;
    l_nro_cp            NUMBER       := REPLACE(IMP_CP_REC.NUMERO_CARTA_PORTE,'-','');
    l_response_b        XX_ACO_CTG_CONSULTA_RESP;
    l_response_d        XX_ACO_CTG_DETALLE_RESP;
    l_ctgs_b_rec        XX_ACO_CTGS_B%ROWTYPE;
    l_result            BOOLEAN;
    l_error_msg         VARCHAR2(2000);
    l_index             NUMBER;
    l_org_id            NUMBER;
    l_party_id          NUMBER;
    l_party_name        VARCHAR2(250);
    l_tipo_operacion    VARCHAR2(10);
    eCTGError           EXCEPTION;
    eSinCTG             EXCEPTION;
    eCTGAnulado         EXCEPTION;
  BEGIN
    CTG_REC := XX_ACO_CTG_DTL();

    BEGIN
      SELECT lv.tag
      INTO l_org_id
      FROM fnd_lookup_values_vl  lv
         , fnd_lookup_values_dfv lv_dfv
      WHERE 1=1
      AND lv_dfv.row_id  = lv.row_id
      AND lv_dfv.context = lv.attribute_category
      AND lv.lookup_type = 'XX_WSAFIP_WSAA_CERTIFICATES'
      AND lv_dfv.services LIKE '%wsctg%'
      AND lv.lookup_code = g_cuit_imp;
    EXCEPTION
      WHEN No_Data_Found THEN
        myDebug('CUIT '||g_cuit_imp||'no configurado para obtener CTG.', 2);
        RETURN;
    END;

    BEGIN
      SELECT *
      INTO l_ctgs_b_rec
      FROM xx_aco_ctgs_b
      WHERE 1=1
      AND estado IS NOT NULL
      AND item_oncca_cod  IS NOT NULL
      AND nro_carta_porte = IMP_CP_REC.NUMERO_CARTA_PORTE;

      CTG_REC.NUMERO_CARTA_PORTE  := l_ctgs_b_rec.nro_carta_porte;
      CTG_REC.CTG                 := l_ctgs_b_rec.nro_ctg;

      IF IMP_CP_REC.CTG_NUMERO IS NOT NULL AND
         IMP_CP_REC.CTG_NUMERO != CTG_REC.CTG THEN
        l_error_msg := 'El CTG Entregador es distinto CTG AFIP.'||chr(10)
                     ||'CTG AFIP: '||CTG_REC.CTG||' - '
                     ||'CTG Entregador: '||IMP_CP_REC.CTG_NUMERO;
        RAISE eCTGError;
      END IF;

      IF UPPER(l_ctgs_b_rec.estado) = 'ANULADO' THEN
        l_error_msg := 'El CTG se encuentra Anulado.';
        RAISE eCTGError;
      END IF;

      CTG_REC.ITEM_ONCCA           := l_ctgs_b_rec.item_oncca_cod;
      CTG_REC.COSECHA              := l_ctgs_b_rec.lot_no_ctg;
      CTG_REC.ESTADO               := l_ctgs_b_rec.estado;
      CTG_REC.DETALLE              := l_ctgs_b_rec.detalle;
      CTG_REC.FECHA_EMISION        := l_ctgs_b_rec.fecha_emision;
      CTG_REC.TURNO                := l_ctgs_b_rec.turno;
      CTG_REC.FECHA_VIGENCIA_DESDE := l_ctgs_b_rec.fecha_vigencia_desde;
      CTG_REC.FECHA_VIGENCIA_HASTA := l_ctgs_b_rec.fecha_vigencia_hasta;
      CTG_REC.CUIT_CANJEADOR       := l_ctgs_b_rec.cuit_canjeador;
      CTG_REC.CUIT_RTTE_COMERCIAL  := l_ctgs_b_rec.cuit_remitente_comercial;
      CTG_REC.RTTE_COMERCIAL_PROD  := l_ctgs_b_rec.rtte_comercial_productor;
      CTG_REC.CANJEA_RTTE_COMERCIAL := l_ctgs_b_rec.canjeador_rtte_comercial;
      CTG_REC.CUIT_DESTINO         := l_ctgs_b_rec.cuit_destino;
      CTG_REC.CUIT_DESTINATARIO    := l_ctgs_b_rec.cuit_destinatario;
      CTG_REC.ESTABLECIMIENTO      := l_ctgs_b_rec.establecimiento;
      CTG_REC.LOC_ONCCA_CODE_ORIG  := l_ctgs_b_rec.loc_origen_oncca_code;
      CTG_REC.PROV_ONCCA_CODE_ORIG := l_ctgs_b_rec.prov_origen_code;
      CTG_REC.LOC_ONCCA_CODE_DEST  := l_ctgs_b_rec.loc_destino_oncca_code;
      CTG_REC.PROV_ONCCA_CODE_DEST := l_ctgs_b_rec.prov_destino_code;
      CTG_REC.CUIT_TRANSPORTISTA   := l_ctgs_b_rec.cuit_transportista;
      CTG_REC.CANT_HORAS           := l_ctgs_b_rec.cant_horas;
      CTG_REC.PATENTE              := l_ctgs_b_rec.patente;
      CTG_REC.PESO_NETO            := NVL(l_ctgs_b_rec.peso_neto_confirmado, l_ctgs_b_rec.peso_neto);
      CTG_REC.DISTANCIA            := l_ctgs_b_rec.distancia;
      CTG_REC.TARIFA_REF           := l_ctgs_b_rec.tarifa_referencia;
      IMP_CP_REC.CTG_VALIDADO_FLAG := 'Y';

      IF CTG_REC.CUIT_DESTINO IS NOT NULL THEN
        XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (CTG_REC.CUIT_DESTINO, 'AR', l_party_id, l_party_name);
        IF l_party_id IS NULL THEN
          RAISE NO_DATA_FOUND;
        END IF;
      ELSIF CTG_REC.CUIT_DESTINATARIO IS NOT NULL THEN
        XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (CTG_REC.CUIT_DESTINATARIO, 'AR', l_party_id, l_party_name);
        IF l_party_id IS NULL THEN
          RAISE NO_DATA_FOUND;
        END IF;
      END IF;

    --
    EXCEPTION
      WHEN No_Data_Found THEN
        XX_ACO_WSCTG_PUB.Consultar_CTG
                        ( p_cuit_representado  => l_cuit_representado
                        , p_carta_porte        => l_nro_cp
                        , p_femision_desde     => TRUNC(sysdate-365) --p_femision_desde -- Obligatorio
                        , p_femision_hasta     => TRUNC(sysdate) --p_femision_desde -- Obligatorio
                        --
                        , x_response_object    => l_response_b
                        , x_result             => l_result
                        , x_error_message      => l_error_msg
                        );

        IF NOT l_result THEN
          RAISE eCTGError;
        END IF;

        IF (l_response_b.errores IS NOT NULL AND l_response_b.errores.COUNT > 0) THEN
          FOR l_index IN 1 .. l_response_b.errores.COUNT LOOP
            l_error_msg := l_error_msg ||' #' || l_index ||' - ' || l_response_b.errores(l_index);
          END LOOP;

          IF INSTR(l_error_msg, 'No se encontraron solicitudes que correspondan con el criterio') > 0 THEN
            IF g_cuit_imp = IMP_CP_REC.TITULAR_CP_CUIT AND
               IMP_CP_REC.DESTINO_CUIT IS NOT NULL AND
               XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (IMP_CP_REC.DESTINO_CUIT) THEN
              l_cuit_representado := IMP_CP_REC.DESTINO_CUIT;
              l_error_msg := NULL;
            ELSIF g_cuit_imp != IMP_CP_REC.TITULAR_CP_CUIT AND
                  IMP_CP_REC.TITULAR_CP_CUIT IS NOT NULL AND
                  XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(IMP_CP_REC.TITULAR_CP_CUIT) THEN
              l_cuit_representado := IMP_CP_REC.TITULAR_CP_CUIT;
              l_error_msg := NULL;
            ELSE
              RAISE eCTGError;
            END IF;

            BEGIN
              SELECT lv.tag
              INTO l_org_id
              FROM fnd_lookup_values_vl  lv
                 , fnd_lookup_values_dfv lv_dfv
              WHERE 1=1
              AND lv_dfv.row_id  = lv.row_id
              AND lv_dfv.context = lv.attribute_category
              AND lv.lookup_type = 'XX_WSAFIP_WSAA_CERTIFICATES'
              AND lv_dfv.services LIKE '%wsctg%'
              AND lv.lookup_code = l_cuit_representado;
            EXCEPTION
              WHEN No_Data_Found THEN
                myDebug('CUIT '||l_cuit_representado||'no configurado para obtener CTG.', 2);
                RETURN;
            END;

            XX_ACO_WSCTG_PUB.Consultar_CTG
                            ( p_cuit_representado  => l_cuit_representado
                            , p_carta_porte        => l_nro_cp
                            , p_femision_desde     => TRUNC(sysdate-365) --p_femision_desde -- Obligatorio
                            , p_femision_hasta     => TRUNC(sysdate) --p_femision_desde -- Obligatorio
                            --
                            , x_response_object    => l_response_b
                            , x_result             => l_result
                            , x_error_message      => l_error_msg
                            );

            IF NOT l_result THEN
              RAISE eCTGError;
            END IF;

            IF (l_response_b.errores IS NOT NULL AND l_response_b.errores.COUNT > 0) THEN
              FOR l_index IN 1 .. l_response_b.errores.COUNT LOOP
                l_error_msg := l_error_msg ||' #' || l_index ||' - ' || l_response_b.errores(l_index) ;
              END LOOP;

              RAISE eCTGError;
            END IF;
          ELSE
            RAISE eCTGError;
          END IF;
        END IF;

        IF NOT (l_response_b.arrayDatosConsultarCTG IS NOT NULL AND l_response_b.arrayDatosConsultarCTG.COUNT > 0) THEN
          IF IMP_CP_REC.CTG_NUMERO IS NULL THEN
            RAISE eSinCTG;
          ELSE
            l_error_msg := 'No se encontraron datos para la CP "'||l_nro_cp||'".';
            RAISE eCTGError;
          END IF;
        END IF;

        IF IMP_CP_REC.CTG_NUMERO IS NOT NULL AND
           IMP_CP_REC.CTG_NUMERO != REPLACE(l_response_b.arrayDatosConsultarCTG(1).ctg,'.','') THEN
          l_error_msg := 'El CTG Entregador es distinto CTG AFIP.'||chr(10)
                       ||'CTG AFIP: '||REPLACE(l_response_b.arrayDatosConsultarCTG(1).ctg,'.','')||' - '
                       ||'CTG Entregador: '||IMP_CP_REC.CTG_NUMERO;
          RAISE eCTGError;
        END IF;

        XX_ACO_WSCTG_PUB.Consultar_Detalle_CTG
                        ( p_cuit_representado  => l_cuit_representado
                        , p_ctg                => REPLACE(l_response_b.arrayDatosConsultarCTG(1).ctg,'.','')
                        --
                        , x_response_object    => l_response_d
                        , x_result             => l_result
                        , x_error_message      => l_error_msg
                        );

        IF NOT l_result THEN
          RAISE eCTGError;
        END IF;

        IF (l_response_d.errores IS NOT NULL AND l_response_d.errores.COUNT > 0) THEN
          FOR l_index IN 1 .. l_response_d.errores.COUNT LOOP
            l_error_msg := l_error_msg ||' #' || l_index ||' - ' || l_response_d.errores(l_index) || chr(10);
          END LOOP;

          RAISE eCTGError;
        END IF;

        IF UPPER(l_response_d.detalle.estado) = 'ANULADO' THEN
          l_error_msg := 'El CTG se encuentra Anulado.';
          RAISE eCTGAnulado;
        END IF;

        CTG_REC.NUMERO_CARTA_PORTE   := SUBSTR(LPAD(l_response_d.detalle.cartaPorte, 12, 0),1,4)||'-'||SUBSTR(LPAD(l_response_d.detalle.cartaPorte, 12, 0),5,8);
        CTG_REC.CTG                  := l_response_d.detalle.ctg;

        BEGIN
          SELECT lookup_code
          INTO CTG_REC.ITEM_ONCCA
          FROM fnd_lookup_values_vl
          WHERE 1=1
          AND lookup_type = 'XX_ACO_ESPECIES_ONCCA'
          AND description = UPPER(l_response_d.detalle.especie);
        EXCEPTION
          WHEN Others THEN
            CTG_REC.ITEM_ONCCA := NULL;
            myDebug('No fue posible obtener COD ONCCA CTG. '||UPPER(l_response_d.detalle.especie), 2);
        END;

        IF UPPER(l_response_d.detalle.estado) = 'ANULADO' THEN
          l_error_msg := 'El CTG se encuentra Anulado.';
          RAISE eCTGError;
        END IF;

        CTG_REC.COSECHA              := REPLACE(l_response_d.detalle.cosecha,'-','');
        CTG_REC.ESTADO               := l_response_d.detalle.estado;
        CTG_REC.DETALLE              := l_response_d.detalle.detalle;
        CTG_REC.FECHA_EMISION        := TRUNC(TO_DATE(l_response_d.detalle.fechaEmision, 'DD/MM/YYYY HH24:MI:SS'));
        CTG_REC.TURNO                := l_response_d.detalle.turno;
        CTG_REC.FECHA_VIGENCIA_DESDE := TO_DATE(l_response_d.detalle.fechaVigenciaDesde, 'DD/MM/YYYY');
        CTG_REC.FECHA_VIGENCIA_HASTA := TO_DATE(l_response_d.detalle.fechaVigenciaHasta, 'DD/MM/YYYY');

        CTG_REC.CUIT_CANJEADOR       := SUBSTR(l_response_d.detalle.cuitCanjeador,1,INSTR(l_response_d.detalle.cuitCanjeador,'(')-1);

        IF NVL(UPPER(l_response_d.detalle.canjeadorRteComercial),'NO') = 'NO' THEN
          CTG_REC.CUIT_RTTE_COMERCIAL := CTG_REC.CUIT_CANJEADOR;
          CTG_REC.RTTE_COMERCIAL_PROD := l_response_d.detalle.rtecomercialproductor;
          CTG_REC.CUIT_CANJEADOR      := NULL;
        ELSE
          CTG_REC.CUIT_RTTE_COMERCIAL := NULL;
        END IF;

        CTG_REC.CANJEA_RTTE_COMERCIAL := l_response_d.detalle.canjeadorRteComercial;
        CTG_REC.CUIT_DESTINO         := SUBSTR(l_response_d.detalle.cuitDestino,1,INSTR(l_response_d.detalle.cuitDestino,'(')-1);
        CTG_REC.CUIT_DESTINATARIO    := SUBSTR(l_response_d.detalle.cuitDestinatario,1,INSTR(l_response_d.detalle.cuitDestinatario,'(')-1);

        IF CTG_REC.CUIT_DESTINO IS NOT NULL THEN
          XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (CTG_REC.CUIT_DESTINO, 'AR', l_party_id, l_party_name);
          IF l_party_id IS NULL THEN
            IMP_CP_REC.DESTINO := REPLACE(REPLACE(SUBSTR(l_response_d.detalle.cuitDestino,INSTR(l_response_d.detalle.cuitDestino,'('), 200),'(', ''), ')', '');
          END IF;
        END IF;

        IF CTG_REC.CUIT_DESTINATARIO IS NOT NULL THEN
          XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (CTG_REC.CUIT_DESTINATARIO, 'AR', l_party_id, l_party_name);
          IF l_party_id IS NULL THEN
            IMP_CP_REC.DESTINATARIO := REPLACE(REPLACE(SUBSTR(l_response_d.detalle.cuitDestinatario,INSTR(l_response_d.detalle.cuitDestinatario,'('), 200),'(', ''), ')', '');
          END IF;
        END IF;

        CTG_REC.ESTABLECIMIENTO      := l_response_d.detalle.establecimiento;

        BEGIN
          SELECT lv_loc.meaning     loc_oncca_code
               --, lv_loc.description loc_oncca_description
               , prov.province_code prov_code
               --, prov.province_name prov_desc
          INTO CTG_REC.LOC_ONCCA_CODE_ORIG, CTG_REC.PROV_ONCCA_CODE_ORIG
          FROM fnd_lookup_values_vl lv_loc
             , fnd_lookup_values_vl lv_par
             , jl_ar_ap_provinces   prov
          WHERE 1=1
          AND lv_par.meaning     = lv_loc.attribute1
          AND prov.province_code = lv_par.attribute1
          --
          AND lv_loc.lookup_type = 'XX_ACO_LOCALIDADES_ONCCA'
          AND lv_loc.attribute_category = 'XX_ACO_LOCALIDADES_ONCCA'
          AND lv_par.lookup_type = 'XX_ACO_PARTIDOS_ONCCA'
          --
          AND lv_loc.description = SUBSTR(l_response_d.detalle.localidadOrigen,1,INSTR(l_response_d.detalle.localidadOrigen,'(')-2)
          AND UPPER(prov.province_name) = REPLACE(SUBSTR(l_response_d.detalle.localidadOrigen,INSTR(l_response_d.detalle.localidadOrigen,'(')+1, 50),')','');
          --myDebug('Procedencia CTG: '||CTG_REC.LOC_ONCCA_CODE_ORIG, 2);
        EXCEPTION
          WHEN Others THEN
            CTG_REC.LOC_ONCCA_CODE_ORIG  := NULL;
            CTG_REC.PROV_ONCCA_CODE_ORIG := NULL;
        END;

        BEGIN
          SELECT lv_loc.meaning     loc_oncca_code
                 --lv_loc.description loc_oncca_description
               , prov.province_code prov_code
               --, prov.province_name prov_desc
          INTO CTG_REC.LOC_ONCCA_CODE_DEST, CTG_REC.PROV_ONCCA_CODE_DEST
          FROM fnd_lookup_values_vl lv_loc
             , fnd_lookup_values_vl lv_par
             , jl_ar_ap_provinces   prov
          WHERE 1=1
          AND lv_par.meaning     = lv_loc.attribute1
          AND prov.province_code = lv_par.attribute1
          --
          AND lv_loc.lookup_type = 'XX_ACO_LOCALIDADES_ONCCA'
          AND lv_loc.attribute_category = 'XX_ACO_LOCALIDADES_ONCCA'
          AND lv_par.lookup_type = 'XX_ACO_PARTIDOS_ONCCA'
          --
          AND lv_loc.description = SUBSTR(l_response_d.detalle.localidadDestino,1,INSTR(l_response_d.detalle.localidadDestino,'(')-2)
          AND UPPER(prov.province_name) = REPLACE(SUBSTR(l_response_d.detalle.localidadDestino,INSTR(l_response_d.detalle.localidadDestino,'(')+1, 50),')','');
        EXCEPTION
          WHEN Others THEN
            CTG_REC.LOC_ONCCA_CODE_DEST  := NULL;
            CTG_REC.PROV_ONCCA_CODE_DEST := NULL;
        END;

        CTG_REC.CUIT_TRANSPORTISTA    := SUBSTR(l_response_d.detalle.cuitTransportista,1,INSTR(l_response_d.detalle.cuitTransportista,'(')-1);
        CTG_REC.CANT_HORAS            := l_response_d.detalle.cantHoras;
        CTG_REC.PATENTE               := l_response_d.detalle.patente;
        IF --l_tipo_operacion = 'ENTRADA' AND
           UPPER(l_ctgs_b_rec.estado) != 'CONFIRMACION DEFINITIVA' THEN
          CTG_REC.PESO_NETO           := NULL;
        ELSE
          CTG_REC.PESO_NETO           := l_response_d.detalle.pesoNeto;
        END IF;
        CTG_REC.DISTANCIA             := l_response_d.detalle.kmARecorrer;
        CTG_REC.TARIFA_REF            := l_response_d.detalle.tarifaReferencia;
        IMP_CP_REC.CTG_VALIDADO_FLAG  := 'Y';
    END;
  EXCEPTION
    WHEN eSinCTG THEN
      concatComment(IMP_CP_REC, 'Aun no se gestionó CTG.');
      myDebug('Aun no se gestionó CTG.', 2);
    --
    WHEN eCTGError THEN
      --IMP_CP_REC.CANCELADO_FLAG := 'Y';
      --IMP_CP_REC.INCONSISTENCIA_CTG_FLAG := 'Y';
      concatComment(IMP_CP_REC, 'No fue posible obtener CTG. '||l_error_msg);
      myDebug('No fue posible obtener CTG. '||l_error_msg, 2);
    WHEN eCTGAnulado THEN
      --IMP_CP_REC.CANCELADO_FLAG := 'Y';
      --IMP_CP_REC.INCONSISTENCIA_CTG_FLAG := 'Y';
      concatComment(IMP_CP_REC, 'CTG ANULADO.');
      myDebug('CTG ANULADO.', 2);

  END getCTG;


  FUNCTION existeCP ( p_numero_cp  VARCHAR2 ) RETURN BOOLEAN IS
    l_cps   NUMBER;
  BEGIN
    SELECT COUNT(carta_porte_id)
    INTO l_cps
    FROM xx_tcg_cartas_porte
    WHERE numero_carta_porte = p_numero_cp;

    IF l_cps > 0 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN No_Data_Found THEN
      RETURN FALSE;
  END existeCP;


  PROCEDURE getHeader ( IMP_CP_REC        IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                      , ENTREGADORES_REC  IN     XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                      , CTG_REC           IN     XX_ACO_CTG_DTL
                      ) IS
    l_dummy_num  NUMBER;
  BEGIN
    -- CTG
    IF IMP_CP_REC.CTG_NUMERO IS NULL AND
       CTG_REC.CTG IS NOT NULL THEN
      IMP_CP_REC.CTG_NUMERO := CTG_REC.CTG;
    END IF;


    --TURNO
    IF IMP_CP_REC.TURNO IS NULL AND
       CTG_REC.TURNO IS NOT NULL THEN
      IMP_CP_REC.TURNO := CTG_REC.TURNO;
    END IF;

    -- ITEM
    IF CTG_REC.ITEM_ONCCA IS NOT NULL THEN
      IMP_CP_REC.ITEM_ONCCA_CODE := CTG_REC.ITEM_ONCCA;
    END IF;


    IF IMP_CP_REC.ITEM_ID IS NULL THEN
      BEGIN
        SELECT msi.inventory_item_id item_id
        INTO IMP_CP_REC.ITEM_ID
        FROM mtl_system_items       msi
           , mtl_system_items_b_dfv msi_dfv
        WHERE 1=1
        AND msi_dfv.row_id  = msi.rowid
        AND msi.organization_id = XX_TCG_FUNCTIONS_PKG.getmasterorg
        AND msi.enabled_flag = 'Y'
        AND msi_dfv.xx_aco_codigo_oncca = IMP_CP_REC.ITEM_ONCCA_CODE;

      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            SELECT occ.inventory_item_id
            INTO IMP_CP_REC.ITEM_ID
            FROM xx_tcg_cartas_porte_interface cpi
               , xx_tcg_orden_carga_cupos      occ
            WHERE 1=1
            AND occ.cupo_id             = cpi.cupo_id
            AND cpi.numero_carta_porte  = IMP_CP_REC.NUMERO_CARTA_PORTE
            AND occ.item_oncca_code     = IMP_CP_REC.ITEM_ONCCA_CODE
            ;

          EXCEPTION
            WHEN OTHERS THEN
              BEGIN
                SELECT msi.inventory_item_id item_id
                INTO IMP_CP_REC.ITEM_ID
                FROM mtl_system_items       msi
                   , mtl_system_items_b_dfv msi_dfv
                WHERE 1=1
                AND msi_dfv.row_id  = msi.rowid
                AND msi.organization_id = XX_TCG_FUNCTIONS_PKG.getmasterorg
                AND msi.enabled_flag = 'Y'
                AND msi_dfv.xx_aco_codigo_oncca = IMP_CP_REC.ITEM_ONCCA_CODE
                AND IMP_CP_REC.ITEM_ONCCA_CODE  = '019'
                AND msi.segment1    = '020100000746'
                ;
              EXCEPTION
                WHEN Others THEN
                  IMP_CP_REC.ITEM_ID := NULL;
                  concatComment(IMP_CP_REC, 'No fue posible determinar el producto ONCCA.');
                  myDebug('No fue posible determinar el producto ONCCA. '||IMP_CP_REC.ITEM_ONCCA_CODE||' Campaña: '||IMP_CP_REC.LOT_NO||'. '||SQLERRM, 2);
              END;
          END;
      END;
    --
    ELSIF IMP_CP_REC.ITEM_ONCCA_CODE != NVL(CTG_REC.ITEM_ONCCA, IMP_CP_REC.ITEM_ONCCA_CODE) THEN
      IMP_CP_REC.CANCELADO_FLAG := 'Y';
      IMP_CP_REC.IMP_CP_STATUS := 'Cancelado';
      IMP_CP_REC.INCONSISTENCIA_CTG_FLAG := 'Y';
      IMP_CP_REC.COMENTARIOS := 'Inconsistencia CTG: Producto ONCCA.'||' -- '||IMP_CP_REC.COMENTARIOS;
      RETURN;
    END IF;


    -- CAMPAÑA
    IF CTG_REC.COSECHA IS NOT NULL THEN
      IMP_CP_REC.LOT_NO := CTG_REC.COSECHA;
    END IF;

    IF IMP_CP_REC.LOT_NO IS NOT NULL AND
       IMP_CP_REC.LOT_NO != NVL(CTG_REC.COSECHA, IMP_CP_REC.LOT_NO) AND
       IMP_CP_REC.CARTA_PORTE_ID IS NOT NULL THEN
      IMP_CP_REC.CANCELADO_FLAG := 'Y';
      IMP_CP_REC.IMP_CP_STATUS := 'Cancelado';
      IMP_CP_REC.INCONSISTENCIA_CTG_FLAG := 'Y';
      IMP_CP_REC.COMENTARIOS := 'Inconsistencia CTG: Campaña.'||' -- '||IMP_CP_REC.COMENTARIOS;
      RETURN;
    END IF;


    /* TIPO GRANO */
    BEGIN
      SELECT lookup_code
      INTO IMP_CP_REC.TIPO_GRANO
      FROM fnd_lookup_values_vl
      WHERE 1=1
      AND lookup_type = 'XX_ACO_TIPOS_GRANO'
      AND (end_date_active IS NULL OR end_date_active > sysdate)
      AND lookup_code = ENTREGADORES_REC.TIPO_GRANO;
    EXCEPTION
      WHEN Others THEN
        IMP_CP_REC.TIPO_GRANO := 0;
    END;
  --
  EXCEPTION
    WHEN Others THEN
      myDebug('Error derivando Cabecera. '||SQLERRM, 2);
  END getHeader;


  PROCEDURE getDatosFiscales ( IMP_CP_REC  IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                             , CTG_REC     IN     XX_ACO_CTG_DTL
                             ) IS
    l_party_id         NUMBER;
    l_party_name       VARCHAR2(250);
  BEGIN
    -- TITULAR
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.TITULAR_CP_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.TITULAR_CP_ID := l_party_id;
      IMP_CP_REC.TITULAR_CP    := l_party_name;
    END IF;

    -- INTERMEDIARIO
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.INTERMEDIARIO_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.INTERMEDIARIO_ID := l_party_id;
      IMP_CP_REC.INTERMEDIARIO    := l_party_name;
    END IF;

    -- RTTE_COMERCIAL
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.RTTE_COMERCIAL_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.RTTE_COMERCIAL_ID := l_party_id;
      IMP_CP_REC.RTTE_COMERCIAL    := l_party_name;

      IF UPPER(CTG_REC.RTTE_COMERCIAL_PROD) = 'SI' THEN
        IF IMP_CP_REC.INTERMEDIARIO_ID IS NOT NULL THEN
          IMP_CP_REC.INTERMEDIARIO_TIPO := 'PRODUCTOR';
          IMP_CP_REC.INTERMEDIARIO_RETIRO := 'Y';
        ELSE
          IMP_CP_REC.RTTE_COMERCIAL_TIPO := 'PRODUCTOR';
          IMP_CP_REC.RTTE_COMERCIAL_RETIRO := 'Y';
        END IF;
      END IF;
    END IF;

    -- CORREDOR
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.CORREDOR_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.CORREDOR_ID := l_party_id;
      IMP_CP_REC.CORREDOR    := l_party_name;
    END IF;

    -- MERCADO_TERMINO
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.MERCADO_TERMINO_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.MERCADO_TERMINO_ID := l_party_id;
      IMP_CP_REC.MERCADO_TERMINO    := l_party_name;
    END IF;

    -- CORREDOR_VENDEDOR
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.CORREDOR_VENDEDOR_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.CORREDOR_VENDEDOR_ID := l_party_id;
      IMP_CP_REC.CORREDOR_VENDEDOR    := l_party_name;
    END IF;

    ---REPRESENTANTE
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.REPRESENTANTE_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.REPRESENTANTE_ID := l_party_id;
      IMP_CP_REC.REPRESENTANTE    := l_party_name;
    END IF;

    ---DESTINATARIO
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.DESTINATARIO_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.DESTINATARIO_ID := l_party_id;
      IMP_CP_REC.DESTINATARIO    := l_party_name;
    END IF;

    ---DESTINO
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.DESTINO_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.DESTINO_ID := l_party_id;
      IMP_CP_REC.DESTINO    := l_party_name;
    END IF;

    ---INTERMEDIARIO_FLETE
    XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB ( p_cuit       => IMP_CP_REC.INTERMEDIARIO_FLETE_CUIT
                                          , p_country    => 'AR'
                                          , x_party_id   => l_party_id
                                          , x_party_name => l_party_name
                                          );

    IF l_party_id IS NOT NULL THEN
      IMP_CP_REC.INTERMEDIARIO_FLETE_ID := l_party_id;
      IMP_CP_REC.INTERMEDIARIO_FLETE    := l_party_name;
    END IF;


  END getDatosFiscales;


  PROCEDURE getOrigenDestino ( IMP_CP_REC        IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                             , ENTREGADORES_REC  IN     XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                             , CTG_REC           IN     XX_ACO_CTG_DTL
                             ) IS
    CURSOR cProvLoc ( p_localidad VARCHAR2 ) IS
      SELECT lv_pro.lookup_code provincia, lv_loc.lookup_code localidad
      FROM fnd_lookup_values_vl lv_loc
         , fnd_lookup_values_vl lv_par
         , fnd_lookup_values_vl lv_pro
      WHERE 1=1
      AND lv_par.lookup_code = lv_loc.attribute1
      AND lv_pro.lookup_code = lv_par.attribute1
      AND lv_loc.lookup_type = 'XX_ACO_LOCALIDADES_ONCCA'
      AND lv_par.lookup_type = 'XX_ACO_PARTIDOS_ONCCA'
      AND lv_pro.lookup_type = 'JLZZ_STATE_PROVINCE'
      AND lv_loc.lookup_code = p_localidad;


    TYPE mainCurTyp    IS REF CURSOR;
    l_main_cursor      mainCurTyp;
    l_rec              XX_TCG_FUNCTIONS_PKG.trOrgInfo;
    rProvLoc           cProvLoc%ROWTYPE;
    l_main_cursor_stmt VARCHAR2(4000);
    l_party_id         NUMBER;
    l_party_name       VARCHAR2(250);
    l_org_id           NUMBER;
    l_subinv           VARCHAR2(50);
    l_location_id      NUMBER;
    l_estab_id         NUMBER;
    l_estab_tipo       VARCHAR2(50);
    l_provincia        VARCHAR2(150);
    l_localidad        VARCHAR2(150);
    l_direccion        VARCHAR2(250);

  BEGIN
    IF CTG_REC.PROV_ONCCA_CODE_ORIG IS NOT NULL THEN
      IMP_CP_REC.TITULAR_CP_PROVINCIA := CTG_REC.PROV_ONCCA_CODE_ORIG;
      IMP_CP_REC.TITULAR_CP_LOCALIDAD := CTG_REC.LOC_ONCCA_CODE_ORIG;
    ELSE
      OPEN cProvLoc (IMP_CP_REC.TITULAR_CP_LOCALIDAD);
      FETCH cProvLoc INTO rProvLoc;
      IMP_CP_REC.TITULAR_CP_PROVINCIA := rProvLoc.provincia;
      IMP_CP_REC.TITULAR_CP_LOCALIDAD := rProvLoc.localidad;
      CLOSE cProvLoc;
    END IF;

    IF CTG_REC.PROV_ONCCA_CODE_DEST IS NOT NULL THEN
      IMP_CP_REC.DESTINO_PROVINCIA := CTG_REC.PROV_ONCCA_CODE_DEST;
      IMP_CP_REC.DESTINO_LOCALIDAD := CTG_REC.LOC_ONCCA_CODE_DEST;
    ELSE
      OPEN cProvLoc (IMP_CP_REC.DESTINO_LOCALIDAD);
      FETCH cProvLoc INTO rProvLoc;
      IMP_CP_REC.DESTINO_PROVINCIA := rProvLoc.provincia;
      IMP_CP_REC.DESTINO_LOCALIDAD := rProvLoc.localidad;
      CLOSE cProvLoc;
    END IF;

    IF ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO IS NOT NULL AND
       XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo ( IMP_CP_REC.TITULAR_CP_CUIT ) THEN
      BEGIN
        SELECT establecimiento_id
        INTO IMP_CP_REC.TITULAR_CP_ESTAB_ID
        FROM (
          SELECT est.establecimiento_id
          FROM xx_tcg_estab_oncca est
          WHERE 1=1
          AND establecimiento_oncca_code = ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO
          UNION
          SELECT establecimiento_id
          FROM xx_opm_establecimientos
          WHERE 1=1
          AND campo = ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO
                )
                ;
      EXCEPTION
        WHEN TOO_MANY_ROWS THEN
          BEGIN
            SELECT est.establecimiento_id
            INTO IMP_CP_REC.TITULAR_CP_ESTAB_ID
            FROM xx_tcg_estab_oncca est
            WHERE 1=1
            AND establecimiento_oncca_code = ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO
            AND item_oncca_code = IMP_CP_REC.ITEM_ONCCA_CODE;
          EXCEPTION
            WHEN TOO_MANY_ROWS THEN
              BEGIN
                SELECT est.establecimiento_id
                INTO IMP_CP_REC.TITULAR_CP_ESTAB_ID
                FROM xx_tcg_estab_oncca est
                WHERE 1=1
                AND establecimiento_oncca_code = ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO
                AND item_oncca_code = IMP_CP_REC.ITEM_ONCCA_CODE
                AND item_id = IMP_CP_REC.ITEM_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  IMP_CP_REC.TITULAR_CP_ESTAB_ID := NULL;
              END;

            WHEN OTHERS THEN
              IMP_CP_REC.TITULAR_CP_ESTAB_ID := NULL;
          END;

        WHEN OTHERS THEN
          IMP_CP_REC.TITULAR_CP_ESTAB_ID := NULL;
      END;
    END IF;

    -- Completar --estab/sucursal / provincia / localidad / direccion
    IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo ( IMP_CP_REC.TITULAR_CP_CUIT ) THEN
      BEGIN
        SELECT od.organization_id
             , est.location_id
             , est.establecimiento_id
             , msi_dfv.xx_tcg_tipos tipo_establecimiento
             , msi.secondary_inventory_name
        INTO l_org_id, l_location_id, l_estab_id, l_estab_tipo, l_subinv
        FROM xx_opm_establecimientos est
           , hr_locations l
           , mtl_secondary_inventories      msi
           , mtl_secondary_inventories_dfv  msi_dfv
           , org_organization_definitions   od
           , xx_tcg_parametros_compania     pc
        WHERE 1=1
        AND l.location_id = est.location_id
        AND msi_dfv.source_type(+) = msi.attribute_category
        AND msi_dfv.row_id(+)      = msi.rowid
        AND est.establecimiento_id(+) = msi_dfv.xx_tcg_establecimientos
        AND msi.organization_id = od.organization_id
        AND pc.operating_unit(+) = od.operating_unit
        AND ( IMP_CP_REC.TITULAR_CP_ESTAB_ID IS NULL OR
              IMP_CP_REC.TITULAR_CP_ESTAB_ID = est.establecimiento_id
            )
        AND pc.operating_unit_cuit = IMP_CP_REC.TITULAR_CP_CUIT
        AND l.loc_information16    = ''||IMP_CP_REC.TITULAR_CP_LOCALIDAD||''
        AND msi_dfv.xx_tcg_tipos  != 'ACOPIO';
      EXCEPTION
        WHEN OTHERS THEN
          l_org_id := NULL;
          l_location_id := NULL;
          l_estab_id := NULL;
      END;

      IF IMP_CP_REC.TITULAR_CP_ESTAB_ID IS NULL THEN
        IMP_CP_REC.TITULAR_CP_ESTAB_ID := l_estab_id;
      END IF;

      IF l_estab_tipo = 'CAMPO' THEN
        IMP_CP_REC.TITULAR_CP_TIPO := 'PRODUCTOR';
      ELSE
        IMP_CP_REC.TITULAR_CP_TIPO := 'OPERADOR';
      END IF;

      IF l_location_id IS NOT NULL THEN
        BEGIN
          SELECT l.region_2, l.loc_information16
               , l.address_line_1
               ||DECODE(NVL(l.address_line_2,'<<NULL>>'),'<<NULL>>',NULL,', '||l.address_line_2)
               ||DECODE(NVL(l.address_line_3,'<<NULL>>'),'<<NULL>>',NULL,', '||l.address_line_3)
               ||DECODE(NVL(l.postal_code,'<<NULL>>'),'<<NULL>>',NULL,', CP '||l.postal_code) direccion
          INTO l_provincia, l_localidad, l_direccion
          FROM hr_locations l
          WHERE 1=1
          AND l.location_id = l_location_id;

          IMP_CP_REC.TITULAR_CP_PROVINCIA := l_provincia;
          IMP_CP_REC.TITULAR_CP_LOCALIDAD := l_localidad;
          IMP_CP_REC.TITULAR_CP_DIRECCION := l_direccion;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;

      IF ENTREGADORES_REC.SILO_ORIGEN = 'S' THEN
        BEGIN
          SELECT inventory_location_id
          INTO IMP_CP_REC.TITULAR_CP_UBICACION
          FROM mtl_item_locations
          WHERE 1=1
          AND organization_id = l_org_id
          AND subinventory_code = l_subinv
          AND segment1 = 'BOLSA';
        EXCEPTION
          WHEN OTHERS THEN
            IMP_CP_REC.TITULAR_CP_UBICACION := NULL;
        END;
      ELSE
        BEGIN
          SELECT inventory_location_id
          INTO IMP_CP_REC.TITULAR_CP_UBICACION
          FROM mtl_item_locations
          WHERE 1=1
          AND organization_id = l_org_id
          AND subinventory_code = l_subinv
          AND attribute1 = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            IMP_CP_REC.TITULAR_CP_UBICACION := NULL;
        END;
      END IF;

    ELSE
      IMP_CP_REC.TITULAR_CP_TIPO := 'OPERADOR';

      BEGIN
        SELECT ps.party_site_id
             , l.province, l.city
             , ARH_ADDR_PKG.Format_Address
               ( l.address_style
               , l.address1, l.address2, l.address3, l.address4
               , l.city, l.county, l.state , l.province, l.postal_code , null) direccion
        INTO l_estab_id
           , l_provincia
           , l_localidad
           , l_direccion
        FROM hz_party_sites ps
           , hz_locations   l
        WHERE 1=1
        AND l.location_id = ps.location_id
        AND ps.party_id   = IMP_CP_REC.TITULAR_CP_ID
        AND l.city        = IMP_CP_REC.TITULAR_CP_LOCALIDAD;


        IMP_CP_REC.TITULAR_CP_ESTAB_ID  := l_estab_id;
        IMP_CP_REC.TITULAR_CP_PROVINCIA := l_provincia;
        IMP_CP_REC.TITULAR_CP_LOCALIDAD := l_localidad;
        IMP_CP_REC.TITULAR_CP_DIRECCION := l_direccion;
      EXCEPTION
        WHEN Others THEN
          NULL;
      END;
    END IF;


    --DESTINO
    -- Completar --estab/sucursal / provincia / localidad / direccion
    BEGIN
      SELECT occ.destino_estab_id, occ.destino_provincia, occ.destino_localidad, occ.destino_direccion
      INTO IMP_CP_REC.DESTINO_ESTAB_ID, IMP_CP_REC.DESTINO_PROVINCIA, IMP_CP_REC.DESTINO_LOCALIDAD, IMP_CP_REC.DESTINO_DIRECCION
      FROM xx_tcg_cartas_porte_interface cpi
         , xx_tcg_orden_carga_cupos      occ
      WHERE 1=1
      AND occ.cupo_id             = cpi.cupo_id
      AND cpi.numero_carta_porte  = IMP_CP_REC.NUMERO_CARTA_PORTE
      AND occ.cancelado_flag      = 'N';
    EXCEPTION
      WHEN OTHERS THEN

        IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo ( IMP_CP_REC.DESTINO_CUIT ) THEN
          BEGIN
            SELECT od.organization_id
                 , est.location_id
                 , est.establecimiento_id
            INTO l_org_id, l_location_id, l_estab_id
            FROM xx_opm_establecimientos est
               , hr_locations l
               , mtl_secondary_inventories      msi
               , mtl_secondary_inventories_dfv  msi_dfv
               , org_organization_definitions   od
            WHERE 1=1
            AND l.location_id = est.location_id
            AND msi_dfv.source_type(+) = msi.attribute_category
            AND msi_dfv.row_id(+)      = msi.rowid
            AND est.establecimiento_id(+) = msi_dfv.xx_tcg_establecimientos
            AND msi.organization_id = od.organization_id
            AND l.loc_information16    = ''||IMP_CP_REC.DESTINO_LOCALIDAD||''
            AND msi_dfv.xx_tcg_tipos  != 'CAMPO';
          EXCEPTION
            WHEN OTHERS THEN
              l_org_id := NULL;
              l_location_id := NULL;
              l_estab_id := NULL;
          END;

          IMP_CP_REC.DESTINO_ESTAB_ID := l_estab_id;

          IF l_location_id IS NOT NULL THEN
            BEGIN
              SELECT l.region_2, l.loc_information16
                   , l.address_line_1
                   ||DECODE(NVL(l.address_line_2,'<<NULL>>'),'<<NULL>>',NULL,', '||l.address_line_2)
                   ||DECODE(NVL(l.address_line_3,'<<NULL>>'),'<<NULL>>',NULL,', '||l.address_line_3)
                   ||DECODE(NVL(l.postal_code,'<<NULL>>'),'<<NULL>>',NULL,', CP '||l.postal_code) direccion
              INTO l_provincia, l_localidad, l_direccion
              FROM hr_locations l
              WHERE 1=1
              AND l.location_id = l_location_id;

              IMP_CP_REC.DESTINO_PROVINCIA := l_provincia;
              IMP_CP_REC.DESTINO_LOCALIDAD := l_localidad;
              IMP_CP_REC.DESTINO_DIRECCION := l_direccion;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;

        ELSE
          BEGIN
            SELECT ps.party_site_id
                 , l.province, l.city
                 , ARH_ADDR_PKG.Format_Address
                   ( l.address_style
                   , l.address1, l.address2, l.address3, l.address4
                   , l.city, l.county, l.state , l.province, l.postal_code , null) direccion
            INTO l_estab_id
               , l_provincia
               , l_localidad
               , l_direccion
            FROM hz_party_sites ps
               , hz_locations   l
            WHERE 1=1
            AND l.location_id = ps.location_id
            AND ps.party_id   = IMP_CP_REC.DESTINO_ID
            AND l.city        = IMP_CP_REC.DESTINO_LOCALIDAD;

            IMP_CP_REC.DESTINO_ESTAB_ID  := l_estab_id;
            IMP_CP_REC.DESTINO_PROVINCIA := l_provincia;
            IMP_CP_REC.DESTINO_LOCALIDAD := l_localidad;
            IMP_CP_REC.DESTINO_DIRECCION := l_direccion;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
    END;
  END getOrigenDestino;


  PROCEDURE getTransportista ( IMP_CP_REC        IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                             , ENTREGADORES_REC  IN     XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                             , CTG_REC           IN     XX_ACO_CTG_DTL
                             ) IS
    CURSOR cTranspo ( p_transportista_cuit  VARCHAR2
                    , p_chofer_cuit         VARCHAR2
                    , p_patente_camion      VARCHAR2
                    , p_patente_acoplado    VARCHAR2
                    ) IS
      SELECT  wcs.carrier_service_id
           , wcsd.xx_wsh_patente_camion   patente_camion
           , wcsd.xx_wsh_patente_acoplado patente_acoplado
           , (SELECT hp.party_id
              FROM hz_parties hp, hz_party_usg_assignments hpa
              WHERE  hpa.party_id = hp.party_id
              AND hp.party_id   = s.party_id
              AND hpa.party_usage_code = 'SUPPLIER'
              AND hp.status    = 'A'
             ) transportista_id
           , s.vendor_name  transportista_nombre
           , s.num_1099 || s.global_attribute12 transportista_cuit
           , NVL(qpv.empleado_nombre, wcsd.xx_wsh_nombre_conductor) chofer
           , REPLACE(wcsd.xx_wsh_cuil_conductor,'-','')   chofer_cuit
      FROM wsh_carrier_services_v      wcs
         , wsh_carrier_services_dfv    wcsd
         , xx_opm_qr_proveedores_cp_v  qpv
         , ap_suppliers                s
      WHERE 1=1
      AND wcsd.row_id = wcs.row_id
      AND qpv.carrier_service_id = wcs.carrier_service_id
      AND s.vendor_id(+) = TO_NUMBER(wcsd.xx_aco_proveedor)
      AND wcsd.context_value = 'AR_Automotor'
      AND NVL(wcs.enabled_flag,'Y') = 'Y'
      --
      AND s.num_1099 || s.global_attribute12 = p_transportista_cuit
      AND ( p_chofer_cuit IS NULL OR
            p_chofer_cuit = REPLACE(wcsd.xx_wsh_cuil_conductor,'-','')
          )
      AND ( p_patente_camion IS NULL OR
            p_patente_camion = wcsd.xx_wsh_patente_camion
          )
      AND ( p_patente_acoplado IS NULL OR
            p_patente_acoplado = wcsd.xx_wsh_patente_acoplado
          )
      ;

    rTranspo       cTranspo%ROWTYPE;
  BEGIN
    IF CTG_REC.CUIT_TRANSPORTISTA IS NOT NULL THEN
      IMP_CP_REC.TRANSPORTISTA_CUIT := CTG_REC.CUIT_TRANSPORTISTA;
      IMP_CP_REC.PATENTE_CAMION     := CTG_REC.PATENTE;
      IMP_CP_REC.DISTANCIA_ESTIMADA := CTG_REC.DISTANCIA;
      IMP_CP_REC.TARIFA_REF_FLETE_XTON := CTG_REC.TARIFA_REF;
    END IF;


    OPEN cTranspo ( IMP_CP_REC.TRANSPORTISTA_CUIT
                  , IMP_CP_REC.CHOFER_CUIT
                  , IMP_CP_REC.PATENTE_CAMION
                  , IMP_CP_REC.PATENTE_ACOPLADO
                  );
    FETCH cTranspo INTO rTranspo;
    CLOSE cTranspo;

    IF rTranspo.carrier_service_id IS NOT NULL THEN
      IMP_CP_REC.CARRIER_SERVICE_ID := rTranspo.carrier_service_id;
      IMP_CP_REC.TRANSPORTISTA_NOMBRE := rTranspo.transportista_nombre;
      IMP_CP_REC.CHOFER           := rTranspo.chofer;
      IMP_CP_REC.CHOFER_CUIT      := rTranspo.chofer_cuit;
      IMP_CP_REC.PATENTE_CAMION   := rTranspo.patente_camion;
      IMP_CP_REC.PATENTE_ACOPLADO := rTranspo.patente_acoplado;
    ELSE
      OPEN cTranspo ( IMP_CP_REC.TRANSPORTISTA_CUIT
                    , IMP_CP_REC.CHOFER_CUIT
                    , NULL
                    , NULL
                    );
      FETCH cTranspo INTO rTranspo;
      CLOSE cTranspo;

      IF rTranspo.chofer IS NOT NULL THEN
        IMP_CP_REC.TRANSPORTISTA_NOMBRE := rTranspo.transportista_nombre;
        IMP_CP_REC.CHOFER       := rTranspo.chofer;
        IMP_CP_REC.CHOFER_CUIT  := rTranspo.chofer_cuit;
      END IF;
    END IF;
  END getTransportista;


  PROCEDURE cargarCPAcopio ( IMP_CP_REC        IN OUT XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE
                           , ENTREGADORES_REC  IN     XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                           , CTG_REC           IN     XX_ACO_CTG_DTL
                           ) IS

    l_dummy_num  NUMBER;
    l_dummy_chr  VARCHAR2(250);
    l_result     BOOLEAN;

    ORACP_REC    XX_TCG_CARTAS_PORTE_ALL%ROWTYPE;
    l_stmt_sql   VARCHAR2(4000);
  BEGIN
    myDebug('---cargaCPAcopio+: '||ENTREGADORES_REC.NUMERO_CARTA_PORTE, 2);
    SELECT *
    INTO oracp_rec
    FROM xx_tcg_cartas_porte_all
    WHERE numero_carta_porte = IMP_CP_REC.NUMERO_CARTA_PORTE;

    /* Header */
    IMP_CP_REC.CARTA_PORTE_ID      := ORACP_REC.CARTA_PORTE_ID;
    IMP_CP_REC.PESAJE_ENTRADA_FLAG := ORACP_REC.PESAJE_ENTRADA_FLAG;
    IMP_CP_REC.PESAJE_SALIDA_FLAG  := ORACP_REC.PESAJE_SALIDA_FLAG;
    IMP_CP_REC.TRANSFERIDO_FLAG    := ORACP_REC.TRANSFERIDO_FLAG;
    IMP_CP_REC.RECIBIDO_FLAG       := ORACP_REC.RECIBIDO_FLAG;
    IMP_CP_REC.ANULADO_FLAG        := ORACP_REC.ANULADO_FLAG;
    IMP_CP_REC.ITEM_ID             := ORACP_REC.ITEM_ID;
    IMP_CP_REC.LOT_NO              := ORACP_REC.LOT_NO;
    IMP_CP_REC.TIPO_GRANO          := ORACP_REC.TIPO_GRANO;
    IMP_CP_REC.OBSERVACIONES       := ORACP_REC.OBSERVACIONES;


    /* Datos Fiscales */
    /* Titular CP Validar con los chicos*/
    IMP_CP_REC.TITULAR_CP_TIPO        := ORACP_REC.TITULAR_CP_TIPO;
    IMP_CP_REC.TITULAR_CP_ID          := ORACP_REC.TITULAR_CP_ID;
    IMP_CP_REC.TITULAR_CP             := ORACP_REC.TITULAR_CP;
    IMP_CP_REC.TITULAR_CP_CUIT        := ORACP_REC.TITULAR_CP_CUIT;
    IMP_CP_REC.TITULAR_CP_ESTAB_ID    := ORACP_REC.TITULAR_CP_ESTAB_ID;
    IMP_CP_REC.TITULAR_CP_ESTAB_ONCCA_CODE   := ORACP_REC.TITULAR_CP_ESTAB_ONCCA_CODE;
    IMP_CP_REC.TITULAR_CP_UBICACION   := ORACP_REC.TITULAR_CP_UBICACION;
    IMP_CP_REC.TITULAR_CP_PROVINCIA   := ORACP_REC.TITULAR_CP_PROVINCIA;
    IMP_CP_REC.TITULAR_CP_LOCALIDAD   := ORACP_REC.TITULAR_CP_LOCALIDAD;
    IMP_CP_REC.TITULAR_CP_DIRECCION   := ORACP_REC.TITULAR_CP_DIRECCION;
    IMP_CP_REC.TITULAR_CP_CONTRATO_ID := ORACP_REC.TITULAR_CP_CONTRATO_ID;

    /* Intermediario */
    IMP_CP_REC.INTERMEDIARIO_TIPO     := ORACP_REC.INTERMEDIARIO_TIPO;
    IMP_CP_REC.INTERMEDIARIO_ID       := ORACP_REC.INTERMEDIARIO_ID;
    IMP_CP_REC.INTERMEDIARIO          := ORACP_REC.INTERMEDIARIO;
    IMP_CP_REC.INTERMEDIARIO_CUIT     := ORACP_REC.INTERMEDIARIO_CUIT;
    IMP_CP_REC.INTERMEDIARIO_RETIRO   := ORACP_REC.INTERMEDIARIO_RETIRO;
    IMP_CP_REC.INTERMEDIARIO_CONTRATO_ID := ORACP_REC.INTERMEDIARIO_CONTRATO_ID;

    /* Remitente Comercial */
    IMP_CP_REC.RTTE_COMERCIAL_TIPO    := ORACP_REC.RTTE_COMERCIAL_TIPO;
    IMP_CP_REC.RTTE_COMERCIAL_ID      := ORACP_REC.RTTE_COMERCIAL_ID;
    IMP_CP_REC.RTTE_COMERCIAL         := ORACP_REC.RTTE_COMERCIAL;
    IMP_CP_REC.RTTE_COMERCIAL_CUIT    := ORACP_REC.RTTE_COMERCIAL_CUIT;
    IMP_CP_REC.RTTE_COMERCIAL_RETIRO  := ORACP_REC.RTTE_COMERCIAL_RETIRO;
    IMP_CP_REC.RTTE_COMERCIAL_CONTRATO_ID := ORACP_REC.RTTE_COMERCIAL_CONTRATO_ID;

    /* Corredor */
    IMP_CP_REC.CORREDOR_ID            := ORACP_REC.CORREDOR_ID;
    IMP_CP_REC.CORREDOR               := ORACP_REC.CORREDOR;
    IMP_CP_REC.CORREDOR_CUIT          := ORACP_REC.CORREDOR_CUIT;

    /* Mercado a Termino */
    IMP_CP_REC.MERCADO_TERMINO_ID     := ORACP_REC.MERCADO_TERMINO_ID;
    IMP_CP_REC.MERCADO_TERMINO        := ORACP_REC.MERCADO_TERMINO;
    IMP_CP_REC.MERCADO_TERMINO_CUIT   := ORACP_REC.MERCADO_TERMINO_CUIT;

    /* Corredor Vendedor */
    IMP_CP_REC.CORREDOR_VENDEDOR_ID   := ORACP_REC.CORREDOR_VENDEDOR_ID;
    IMP_CP_REC.CORREDOR_VENDEDOR      := ORACP_REC.CORREDOR_VENDEDOR;
    IMP_CP_REC.CORREDOR_VENDEDOR_CUIT := ORACP_REC.CORREDOR_VENDEDOR_CUIT;

    /* Representante/Entregador */
    IMP_CP_REC.REPRESENTANTE_ID       := ORACP_REC.REPRESENTANTE_ID;
    IMP_CP_REC.REPRESENTANTE          := ORACP_REC.REPRESENTANTE;
    IMP_CP_REC.REPRESENTANTE_CUIT     := ORACP_REC.REPRESENTANTE_CUIT;

    /* Destinatario */
    IMP_CP_REC.DESTINATARIO_ID        := ORACP_REC.DESTINATARIO_ID;
    IMP_CP_REC.DESTINATARIO           := ORACP_REC.DESTINATARIO;
    IMP_CP_REC.DESTINATARIO_CUIT      := ORACP_REC.DESTINATARIO_CUIT;
    IMP_CP_REC.DESTINATARIO_CONTRATO_ID := ORACP_REC.DESTINATARIO_CONTRATO_ID;

    /* Destino */
    IMP_CP_REC.DESTINO_ID             := ORACP_REC.DESTINO_ID;
    IMP_CP_REC.DESTINO                := ORACP_REC.DESTINO;
    IMP_CP_REC.DESTINO_CUIT           := ORACP_REC.DESTINO_CUIT;
    IMP_CP_REC.DESTINO_ESTAB_ID       := ORACP_REC.DESTINO_ESTAB_ID;
    IMP_CP_REC.DESTINO_ESTAB_ONCCA_CODE := ORACP_REC.DESTINO_ESTAB_ONCCA_CODE;
    IMP_CP_REC.DESTINO_UBICACION      := ORACP_REC.DESTINO_UBICACION;
    IMP_CP_REC.DESTINO_PROVINCIA      := ORACP_REC.DESTINO_PROVINCIA;
    IMP_CP_REC.DESTINO_LOCALIDAD      := ORACP_REC.DESTINO_LOCALIDAD;
    IMP_CP_REC.DESTINO_DIRECCION      := ORACP_REC.DESTINO_DIRECCION;
    IMP_CP_REC.DESTINO_CONTRATO_ID    := ORACP_REC.DESTINO_CONTRATO_ID;

    /* Datos Talonario y CTG */
    IF ORACP_REC.CEE_NUMERO IS NOT NULL THEN
      IMP_CP_REC.CEE_NUMERO:= ORACP_REC.CEE_NUMERO;
    END IF;

    IF ORACP_REC.CEE_FECHA_VENCIMIENTO IS NOT NULL THEN
      IMP_CP_REC.CEE_FECHA_VENCIMIENTO := ORACP_REC.CEE_FECHA_VENCIMIENTO;
    END IF;

    IMP_CP_REC.CTG_NUMERO         := ORACP_REC.CTG_NUMERO;

    /* Transporte */
    IMP_CP_REC.CARRIER_SERVICE_ID  := ORACP_REC.CARRIER_SERVICE_ID;
    IMP_CP_REC.TRANSPORTISTA_NOMBRE := ORACP_REC.TRANSPORTISTA_NOMBRE;
    IMP_CP_REC.TRANSPORTISTA_CUIT  := ORACP_REC.TRANSPORTISTA_CUIT;
    IMP_CP_REC.PATENTE_CAMION      := ORACP_REC.PATENTE_CAMION;
    IMP_CP_REC.PATENTE_ACOPLADO    := ORACP_REC.PATENTE_ACOPLADO;
    IMP_CP_REC.CHOFER              := ORACP_REC.CHOFER;
    IMP_CP_REC.CHOFER_CUIT         := ORACP_REC.CHOFER_CUIT;
    IMP_CP_REC.INTERMEDIARIO_FLETE_ID     := ORACP_REC.INTERMEDIARIO_FLETE_ID;
    IMP_CP_REC.INTERMEDIARIO_FLETE        := ORACP_REC.INTERMEDIARIO_FLETE;
    IMP_CP_REC.INTERMEDIARIO_FLETE_CUIT   := ORACP_REC.INTERMEDIARIO_FLETE_CUIT;

    IF IMP_CP_REC.TRANSPORTISTA_CUIT != IMP_CP_REC.TRANSPORTISTA_CUIT THEN
      concatComment(IMP_CP_REC, 'Inconsistencia CTG: CUIT Transportista.');
    END IF;

    IMP_CP_REC.PROCEDENCIA_ENGANCHADA     := ORACP_REC.PROCEDENCIA_ENGANCHADA;
    IMP_CP_REC.DISTANCIA_ID               := ORACP_REC.DISTANCIA_ID;
    IMP_CP_REC.TARIFA_NEGOCIACION_ID      := ORACP_REC.TARIFA_NEGOCIACION_ID;
    IMP_CP_REC.FECHA_CALC_DISTANCIA       := ORACP_REC.FECHA_CALC_DISTANCIA;
    IMP_CP_REC.DISTANCIA_ESTIMADA         := ORACP_REC.DISTANCIA_ESTIMADA;
    IMP_CP_REC.TARIFA_REF_FLETE_XTON      := ORACP_REC.TARIFA_REF_FLETE_XTON;
    IMP_CP_REC.COSTO_FLETE_XTON           := ORACP_REC.COSTO_FLETE_XTON;
    IMP_CP_REC.COSTO_FLETE                := ORACP_REC.COSTO_FLETE;
    IMP_CP_REC.COSTO_FLETE_CURRENCY_CODE  := ORACP_REC.COSTO_FLETE_CURRENCY_CODE;
    IMP_CP_REC.TARIFA_CP_XTON             := ORACP_REC.TARIFA_CP_XTON;
    IMP_CP_REC.PROVISIONAR_FLETE_FLAG     := ORACP_REC.PROVISIONAR_FLETE_FLAG;
    IMP_CP_REC.PROVISIONADO_FLAG          := ORACP_REC.PROVISIONADO_FLAG;
    IMP_CP_REC.REFACTURAR_FLETE_FLAG      := ORACP_REC.REFACTURAR_FLETE_FLAG;
    IMP_CP_REC.REFACTURADO_FLAG           := ORACP_REC.REFACTURADO_FLAG;
    IMP_CP_REC.PAGADOR_FLETE_ID           := ORACP_REC.PAGADOR_FLETE_ID;
    IMP_CP_REC.PROVISIONADO_POR           := ORACP_REC.PROVISIONADO_POR;
    IMP_CP_REC.ID_FACTURA_AP              := ORACP_REC.ID_FACTURA_AP;

    -- Envio
    IF ORACP_REC.TRANSFERIDO_FLAG = 'N' AND
       ( ORACP_REC.PESO_ESTIMADO IS NULL AND
         ORACP_REC.TARA_ENVIO IS NULL
       ) AND
       ( ENTREGADORES_REC.PESO_BRUTO_ENVIO - ENTREGADORES_REC.PESO_TARA_ENVIO IS NOT NULL OR
         ENTREGADORES_REC.PESO_ESTIMADO IS NOT NULL
       )THEN
      IMP_CP_REC.FECHA_ENVIO     := ENTREGADORES_REC.FECHA_CARGA;
      IMP_CP_REC.FECHA_CARGA     := ENTREGADORES_REC.FECHA_CARGA;
      IF ENTREGADORES_REC.PESO_BRUTO_ENVIO - ENTREGADORES_REC.PESO_TARA_ENVIO IS NOT NULL THEN
        IMP_CP_REC.TARA_ENVIO       := ENTREGADORES_REC.PESO_TARA_ENVIO;
        IMP_CP_REC.PESO_BRUTO_ENVIO := ENTREGADORES_REC.PESO_BRUTO_ENVIO;
      ELSE
        IMP_CP_REC.PESO_ESTIMADO := ENTREGADORES_REC.PESO_ESTIMADO;
      END IF;
      IMP_CP_REC.PCTAJE_HUMEDAD_ESTIMADA  := ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA;
      IMP_CP_REC.PESO_CTG := CTG_REC.PESO_NETO;

    ELSIF ( ORACP_REC.PESO_ESTIMADO IS NOT NULL OR
            ORACP_REC.TARA_ENVIO IS NOT NULL
          ) /*AND
          ( ENTREGADORES_REC.PESO_BRUTO - ENTREGADORES_REC.PESO_TARA IS NULL AND
            ENTREGADORES_REC.KILOS_ESTIMADOS IS NULL
          )*/ THEN
      IMP_CP_REC.FECHA_ENVIO             := ORACP_REC.FECHA_ENVIO;
      IMP_CP_REC.FECHA_CARGA             := ORACP_REC.FECHA_CARGA;
      IMP_CP_REC.TICKET_ENVIO_ID         := ORACP_REC.TICKET_ENVIO_ID;
      IMP_CP_REC.TARA_ENVIO              := ORACP_REC.TARA_ENVIO;
      IMP_CP_REC.PESO_BRUTO_ENVIO        := ORACP_REC.PESO_BRUTO_ENVIO;
      IMP_CP_REC.PESO_ESTIMADO           := ORACP_REC.PESO_ESTIMADO;
      IMP_CP_REC.PCTAJE_HUMEDAD_ESTIMADA := ORACP_REC.PCTAJE_HUMEDAD_ESTIMADA;
      IMP_CP_REC.TIPO_CALIDAD_ENVIO      := ORACP_REC.TIPO_CALIDAD_ENVIO;

      IMP_CP_REC.LOTE                    := ORACP_REC.LOTE;
      IMP_CP_REC.VARIEDAD                := ORACP_REC.VARIEDAD;
      IMP_CP_REC.PROYECTO_ID             := ORACP_REC.PROYECTO_ID;
      IMP_CP_REC.TAREA_ID                := ORACP_REC.TAREA_ID;
      IMP_CP_REC.TIPO_EROGACION          := ORACP_REC.TIPO_EROGACION;
    END IF;

    -- Recepcion
    IF ORACP_REC.RECIBIDO_FLAG = 'N' AND
       ORACP_REC.PESO_BRUTO_RECEPCION IS NULL AND
       ENTREGADORES_REC.PESO_BRUTO_RECEPCION IS NOT NULL THEN
      IMP_CP_REC.FECHA_RECEPCION           := ENTREGADORES_REC.FECHA_RECEPCION;
      IMP_CP_REC.PESO_BRUTO_RECEPCION      := ENTREGADORES_REC.PESO_BRUTO_RECEPCION;
      IMP_CP_REC.TARA_RECEPCION            := ENTREGADORES_REC.PESO_TARA_RECEPCION;
      IMP_CP_REC.INSECTOS_VIVOS_FLAG       := 'N';
      IMP_CP_REC.PCTAJE_HUMEDAD_RECEP      := ENTREGADORES_REC.HUMEDAD_PCTAJE;

      SELECT grupo_control
      INTO l_dummy_chr
      FROM xx_tcg_parametros_compania
      WHERE operating_unit = ENTREGADORES_REC.OPERATING_UNIT;

      BEGIN
        XX_TCG_CALIDAD_PKG.Get_Peso_Merma_Humedad
                          ( p_peso                => IMP_CP_REC.PESO_BRUTO_RECEPCION - IMP_CP_REC.TARA_RECEPCION
                          , p_porcentaje_humedad  => IMP_CP_REC.PCTAJE_HUMEDAD_RECEP
                          , p_item_oncca_code     => IMP_CP_REC.ITEM_ONCCA_CODE
                          , p_item_id             => IMP_CP_REC.ITEM_ID
                          , p_party_id            => IMP_CP_REC.DESTINO_ID
                          , p_party_site_id       => IMP_CP_REC.DESTINO_ESTAB_ID
                          , p_grupo_control       => l_dummy_chr
                          , x_merma_header_id     => IMP_CP_REC.MERMA_HEADER_ID
                          , x_porcentaje_merma    => IMP_CP_REC.PCTAJE_MERMA_HUMEDAD_RECEP
                          , x_peso                => l_dummy_num
                          , x_result              => l_result
                          , x_errmsg              => l_dummy_chr
                          );
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      IMP_CP_REC.PCTAJE_ZARANDA_RECEP      := ENTREGADORES_REC.ZARANDA_PCTAJE;
      IMP_CP_REC.PCTAJE_VOLATIL_RECEP      := ENTREGADORES_REC.VOLATIL_PCTAJE;

    ELSIF ORACP_REC.TARA_RECEPCION IS NOT NULL /*AND
          ENTREGADORES_REC.TARA_RECEPCION IS NULL*/ THEN
      IMP_CP_REC.FECHA_RECEPCION         := ORACP_REC.FECHA_RECEPCION;
      IMP_CP_REC.TICKET_RECEPCION_ID     := ORACP_REC.TICKET_RECEPCION_ID;
      IMP_CP_REC.PESO_BRUTO_RECEPCION    := ORACP_REC.PESO_BRUTO_RECEPCION;
      IMP_CP_REC.TARA_RECEPCION          := ORACP_REC.TARA_RECEPCION;
      IMP_CP_REC.INSECTOS_VIVOS_FLAG     := ORACP_REC.INSECTOS_VIVOS_FLAG;
      IMP_CP_REC.PCTAJE_HUMEDAD_RECEP    := ORACP_REC.PCTAJE_HUMEDAD_RECEP;
      IMP_CP_REC.PCTAJE_MERMA_HUMEDAD_RECEP := ORACP_REC.PCTAJE_MERMA_HUMEDAD_RECEP;
      IMP_CP_REC.PCTAJE_ZARANDA_RECEP    := ORACP_REC.PCTAJE_ZARANDA_RECEP;
      IMP_CP_REC.PCTAJE_VOLATIL_RECEP    := ORACP_REC.PCTAJE_VOLATIL_RECEP;
    --
    END IF;



    IF IMP_CP_REC.TITULAR_CP_CUIT       != ENTREGADORES_REC.TITULAR_CP_CUIT     OR
       IMP_CP_REC.INTERMEDIARIO_CUIT    != ENTREGADORES_REC.INTERMEDIARIO_CUIT  OR
       IMP_CP_REC.RTTE_COMERCIAL_TIPO   != ENTREGADORES_REC.RTTE_COMERCIAL_TIPO OR
       IMP_CP_REC.RTTE_COMERCIAL_CUIT   != ENTREGADORES_REC.RTTE_COMERCIAL_CUIT OR
       IMP_CP_REC.CORREDOR_CUIT         != ENTREGADORES_REC.CORREDOR_CUIT       OR
       IMP_CP_REC.REPRESENTANTE_CUIT    != ENTREGADORES_REC.REPRESENTANTE_CUIT  OR
       IMP_CP_REC.DESTINATARIO_CUIT     != ENTREGADORES_REC.DESTINATARIO_CUIT   OR
       IMP_CP_REC.DESTINO_CUIT          != ENTREGADORES_REC.DESTINO_CUIT  THEN
      concatComment(IMP_CP_REC, 'Inconsistencia CTG: Datos Fiscales.');
      myDebug('Inconsistencia CTG: Datos Fiscales.', 2);
    END IF;


    IF IMP_CP_REC.ANULADO_FLAG = 'Y' THEN
      RETURN;
    END IF;


    IF ( ORACP_REC.TRANSFERIDO_FLAG = 'Y' AND
         ORACP_REC.RECIBIDO_FLAG = 'Y'
       ) OR
       ( ( ORACP_REC.PESO_ESTIMADO IS NOT NULL OR
           ORACP_REC.TARA_ENVIO IS NOT NULL
         ) AND --tengo envio cp
         ( ENTREGADORES_REC.PESO_BRUTO_ENVIO - ENTREGADORES_REC.PESO_TARA_ENVIO IS NOT NULL OR
           ENTREGADORES_REC.PESO_ESTIMADO IS NOT NULL
         ) AND --tengo envio entregador
         ORACP_REC.PESO_BRUTO_RECEPCION IS NOT NULL AND -- tengo recep cp
         ENTREGADORES_REC.PESO_BRUTO_RECEPCION IS NOT NULL --tengo recep entregador
       ) OR
       ( ( ORACP_REC.PESO_ESTIMADO IS NOT NULL OR
           ORACP_REC.TARA_ENVIO IS NOT NULL
         ) AND --tengo envio cp
         ( ENTREGADORES_REC.PESO_BRUTO_ENVIO - ENTREGADORES_REC.PESO_TARA_ENVIO IS NOT NULL OR
           ENTREGADORES_REC.PESO_ESTIMADO IS NOT NULL
         ) AND --tengo envio entregador
         ORACP_REC.PESO_BRUTO_RECEPCION IS NULL AND -- tengo recep cp
         ENTREGADORES_REC.PESO_BRUTO_RECEPCION IS NULL --tengo recep entregador
       ) OR
       ( ORACP_REC.PESO_ESTIMADO IS NULL AND
         ORACP_REC.TARA_ENVIO IS NULL AND -- no tengo envio cp
         ENTREGADORES_REC.PESO_BRUTO_ENVIO - ENTREGADORES_REC.PESO_TARA_ENVIO IS NULL AND
         ENTREGADORES_REC.PESO_ESTIMADO IS NULL AND --tengo envio entregador
         ORACP_REC.PESO_BRUTO_RECEPCION IS NOT NULL AND -- tengo recep cp
         ENTREGADORES_REC.PESO_BRUTO_RECEPCION IS NOT NULL --tengo recep entregador
       ) THEN
      IMP_CP_REC.CP_ACOPIO_FLAG := 'Y';
      IMP_CP_REC.CANCELADO_FLAG := 'Y';
      IMP_CP_REC.IMP_CP_STATUS := 'Existente';
      concatComment(IMP_CP_REC, 'Operación existente.');
      myDebug('Operación existente en ACOPIO', 2);
    END IF;

    IF IMP_CP_REC.ITEM_ONCCA_CODE != NVL(CTG_REC.ITEM_ONCCA, IMP_CP_REC.ITEM_ONCCA_CODE) THEN
      IMP_CP_REC.CANCELADO_FLAG := 'Y';
      IMP_CP_REC.IMP_CP_STATUS := 'Cancelado';
      IMP_CP_REC.INCONSISTENCIA_CTG_FLAG := 'Y';
      IMP_CP_REC.COMENTARIOS := 'Inconsistencia CTG: Producto ONCCA.'||' -- '||IMP_CP_REC.COMENTARIOS;
      myDebug('Inconsistencia CTG: Producto ONCCA.', 2);
      RETURN;
    END IF;

    myDebug('---cargaCPAcopio-: '||ENTREGADORES_REC.NUMERO_CARTA_PORTE, 2);

  EXCEPTION
    WHEN Others THEN
      concatComment(IMP_CP_REC, 'No fue posible obtener los datos desde Acopio.');
      myDebug('No fue posible obtener los datos desde Acopio.'||SQLERRM, 2);
  END cargarCPAcopio;



  PROCEDURE insertLines ( ENTREGADORES_REC      XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                        , x_error_msg       OUT VARCHAR2
                        ) IS

    IMP_CP_REC      XX_TCG_IMP_CP_DTL_TEMP%ROWTYPE;
    l_dummy_num     NUMBER;
    l_dummy_chr     VARCHAR2(2000);
    l_ou            NUMBER;
    l_result        BOOLEAN;
    e_InsertLine    EXCEPTION;
  BEGIN
    myDebug('---Inicio CP: '||ENTREGADORES_REC.NUMERO_CARTA_PORTE, 2);
    -- Item Defaults
    IMP_CP_REC.BATCH_ID                    := g_batch_id;
    IMP_CP_REC.OPERATING_UNIT              := g_operating_unit;
    IMP_CP_REC.NUMERO_CARTA_PORTE          := ENTREGADORES_REC.NUMERO_CARTA_PORTE;
    IMP_CP_REC.ITEM_ONCCA_CODE             := LPAD(ENTREGADORES_REC.GRANO_CODIGO_ONCCA,3,0);
    IMP_CP_REC.IMP_CP_STATUS               := 'Pendiente';
    --
    IMP_CP_REC.PESAJE_ENTRADA_FLAG         := 'N';
    IMP_CP_REC.PESAJE_SALIDA_FLAG          := 'N';
    IMP_CP_REC.TRANSFERIDO_FLAG            := 'N';
    IMP_CP_REC.RECIBIDO_FLAG               := 'N';
    IMP_CP_REC.ANULADO_FLAG                := 'N';
    --
    IMP_CP_REC.IMPORTADO_FLAG              := 'N';
    IMP_CP_REC.CANCELADO_FLAG              := 'N';
    IMP_CP_REC.CP_ACOPIO_FLAG              := 'N';
    IMP_CP_REC.CP_ACOPIO_MODIFICADA_FLAG   := 'N';
    IMP_CP_REC.INCONSISTENCIA_CTG_FLAG     := 'N';
    IMP_CP_REC.TRANSFERIDO_IMP_FLAG        := 'N';
    IMP_CP_REC.RECIBIDO_IMP_FLAG           := 'N';
    IMP_CP_REC.ANULADO_IMP_FLAG            := 'N';
    --

    -- Datos Fiscales
    IMP_CP_REC.TITULAR_CP_CUIT             := ENTREGADORES_REC.TITULAR_CP_CUIT;
    IMP_CP_REC.DESTINO_CUIT                := ENTREGADORES_REC.DESTINO_CUIT;

    IMP_CP_REC.CEE_NUMERO                  := ENTREGADORES_REC.CEE_NUMERO;
    IMP_CP_REC.CEE_FECHA_VENCIMIENTO       := TRUNC(ENTREGADORES_REC.FECHA_VENCIMIENTO);
    IMP_CP_REC.CTG_NUMERO                  := ENTREGADORES_REC.CTG_NUMERO;
    IMP_CP_REC.TURNO                       := ENTREGADORES_REC.TURNO;

    -- Transporte
    IMP_CP_REC.COSTO_FLETE_CURRENCY_CODE   := 'ARS';
    IMP_CP_REC.PROVISIONAR_FLETE_FLAG      := 'N';
    IMP_CP_REC.PROVISIONADO_FLAG           := 'N';
    IMP_CP_REC.REFACTURAR_FLETE_FLAG       := 'N';
    IMP_CP_REC.REFACTURADO_FLAG            := 'N';

    -- Envío
    IMP_CP_REC.TIPO_CALIDAD_ENVIO          := 'CONFORME';

    --* Desvio
--    IMP_CP_REC.DESVIO_DESTINO_CUIT         := ENTREGADORES_REC.CUIT_DESTINO_DESVIO;
--    IMP_CP_REC.DESVIO_DESTINATARIO_CUIT    := ENTREGADORES_REC.CUIT_DESTINA_DESVIO;
--    IMP_CP_REC.DESVIO_DOMICILIO            := ENTREGADORES_REC.DOMICILIO_DESVIO;
--    IMP_CP_REC.DESVIO_LOCALIDAD            := ENTREGADORES_REC.LOCALIDAD_DESVIO;

    /* Atributos */
    IMP_CP_REC.ATTRIBUTE1                  := ENTREGADORES_REC.ATTRIBUTE1;
    IMP_CP_REC.ATTRIBUTE2                  := ENTREGADORES_REC.ATTRIBUTE2;
    IMP_CP_REC.ATTRIBUTE3                  := ENTREGADORES_REC.ATTRIBUTE3;
    IMP_CP_REC.ATTRIBUTE4                  := ENTREGADORES_REC.ATTRIBUTE4;
    IMP_CP_REC.ATTRIBUTE5                  := ENTREGADORES_REC.ATTRIBUTE5;
    IMP_CP_REC.ATTRIBUTE6                  := ENTREGADORES_REC.ATTRIBUTE6;
    IMP_CP_REC.ATTRIBUTE7                  := ENTREGADORES_REC.ATTRIBUTE7;
    IMP_CP_REC.ATTRIBUTE8                  := ENTREGADORES_REC.ATTRIBUTE8;
    IMP_CP_REC.ATTRIBUTE9                  := ENTREGADORES_REC.ATTRIBUTE9;
    IMP_CP_REC.ATTRIBUTE10                 := ENTREGADORES_REC.ATTRIBUTE10;
    IMP_CP_REC.ATTRIBUTE11                 := ENTREGADORES_REC.ATTRIBUTE11;
    IMP_CP_REC.ATTRIBUTE12                 := ENTREGADORES_REC.ATTRIBUTE12;
    IMP_CP_REC.COMENTARIOS                 := NULL;
    IMP_CP_REC.CTG_VALIDADO_FLAG           := 'N';
    IMP_CP_REC.LINEA_IMPORTADA             := ENTREGADORES_REC.LINEA_IMPORTADA;

    /* WHO COLUMNS */
    IMP_CP_REC.CREATED_BY                  := FND_GLOBAL.User_ID;
    IMP_CP_REC.CREATION_DATE               := SYSDATE;
    IMP_CP_REC.LAST_UPDATED_BY             := FND_GLOBAL.User_ID;
    IMP_CP_REC.LAST_UPDATE_DATE            := SYSDATE;
    IMP_CP_REC.LAST_UPDATE_LOGIN           := FND_GLOBAL.Login_ID;

    IF NOT ( g_operating_unit = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit (ENTREGADORES_REC.TITULAR_CP_CUIT) OR
             g_operating_unit = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit (ENTREGADORES_REC.INTERMEDIARIO_CUIT) OR
             g_operating_unit = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit (ENTREGADORES_REC.RTTE_COMERCIAL_CUIT) OR
             g_operating_unit = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit (ENTREGADORES_REC.DESTINATARIO_CUIT) OR
             g_operating_unit = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit (ENTREGADORES_REC.DESTINO_CUIT)
           ) THEN
      IMP_CP_REC.CANCELADO_FLAG := 'Y';
      IMP_CP_REC.IMP_CP_STATUS  := 'Cancelado';
      x_error_msg := 'La unidad operativa no participa como interviniente.';
    END IF;

    -- Obtengo datos de CTG
    IF NVL(IMP_CP_REC.CANCELADO_FLAG,'N') = 'N' THEN
      getCTG(IMP_CP_REC);
    END IF;

    IF NVL(IMP_CP_REC.CANCELADO_FLAG,'N') = 'N' THEN
      -- Busco CP en Acopio
      IF existeCP(IMP_CP_REC.NUMERO_CARTA_PORTE) THEN
        cargarCPAcopio(IMP_CP_REC, ENTREGADORES_REC, CTG_REC);
      --
      ELSE
        -- CABECERA
        IMP_CP_REC.LOT_NO                     := ENTREGADORES_REC.CAMPANIA;
        IMP_CP_REC.OBSERVACIONES              := ENTREGADORES_REC.OBSERVACIONES;
        getHeader(IMP_CP_REC, ENTREGADORES_REC, CTG_REC);

        -- DATOS FISCALES
        IMP_CP_REC.INTERMEDIARIO              := ENTREGADORES_REC.INTERMEDIARIO;
        IMP_CP_REC.INTERMEDIARIO_CUIT         := ENTREGADORES_REC.INTERMEDIARIO_CUIT;
        IMP_CP_REC.INTERMEDIARIO_RETIRO       := 'N';
        IMP_CP_REC.RTTE_COMERCIAL             := ENTREGADORES_REC.RTTE_COMERCIAL;
        IMP_CP_REC.RTTE_COMERCIAL_TIPO        := ENTREGADORES_REC.RTTE_COMERCIAL_TIPO;
        IMP_CP_REC.RTTE_COMERCIAL_CUIT        := ENTREGADORES_REC.RTTE_COMERCIAL_CUIT;
        IMP_CP_REC.RTTE_COMERCIAL_RETIRO      := 'N';
        IMP_CP_REC.CORREDOR                   := ENTREGADORES_REC.CORREDOR_COMPRADOR;
        IMP_CP_REC.CORREDOR_CUIT              := ENTREGADORES_REC.CORREDOR_CUIT;
        IMP_CP_REC.MERCADO_TERMINO            := ENTREGADORES_REC.MERCADO_TERMINO;
        IMP_CP_REC.MERCADO_TERMINO_CUIT       := ENTREGADORES_REC.MERCADO_TERMINO_CUIT;
        IMP_CP_REC.CORREDOR_VENDEDOR          := ENTREGADORES_REC.CORREDOR_VENDEDOR;
        IMP_CP_REC.CORREDOR_VENDEDOR_CUIT     := ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT;
        IMP_CP_REC.REPRESENTANTE              := ENTREGADORES_REC.REPRESENTANTE;
        IMP_CP_REC.REPRESENTANTE_CUIT         := ENTREGADORES_REC.REPRESENTANTE_CUIT;
        IMP_CP_REC.DESTINATARIO               := ENTREGADORES_REC.DESTINATARIO;
        IMP_CP_REC.DESTINATARIO_CUIT          := ENTREGADORES_REC.DESTINATARIO_CUIT;
        IMP_CP_REC.DESTINO                    := ENTREGADORES_REC.DESTINO;
        IMP_CP_REC.DESTINO_CUIT               := ENTREGADORES_REC.DESTINO_CUIT;
        IMP_CP_REC.INTERMEDIARIO_FLETE        := ENTREGADORES_REC.INTERMEDIARIO_FLETE;
        IMP_CP_REC.INTERMEDIARIO_FLETE_CUIT   := ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT;
        getDatosFiscales(IMP_CP_REC, CTG_REC);

        -- ORIGEN / DESTINO
        IMP_CP_REC.TITULAR_CP_LOCALIDAD       := LPAD(ENTREGADORES_REC.TITULAR_CP_LOCALIDAD,5,0);
        IMP_CP_REC.TITULAR_CP_DIRECCION       := ENTREGADORES_REC.TITULAR_CP_DIRECCION;
        IMP_CP_REC.DESTINO_LOCALIDAD          := LPAD(ENTREGADORES_REC.DESTINO_LOCALIDAD,5,0);
        IMP_CP_REC.DESTINO_DIRECCION          := ENTREGADORES_REC.DESTINO_DIRECCION;
        --IMP_CP_REC.FECHA_CREACION             := NVL(ENTREGADORES_REC.FECHA,TRUNC(SYSDATE)); ??????
        getOrigenDestino(IMP_CP_REC, ENTREGADORES_REC, CTG_REC);

        -- TRANSPORTE
        IMP_CP_REC.TRANSPORTISTA_NOMBRE       := ENTREGADORES_REC.TRANSPORTISTA;
        IMP_CP_REC.TRANSPORTISTA_CUIT         := ENTREGADORES_REC.TRANSPORTISTA_CUIT;
        IMP_CP_REC.CHOFER                     := ENTREGADORES_REC.CHOFER;
        IMP_CP_REC.CHOFER_CUIT                := ENTREGADORES_REC.CHOFER_CUIT;
        IMP_CP_REC.PATENTE_CAMION             := ENTREGADORES_REC.PATENTE_CAMION;
        IMP_CP_REC.PATENTE_ACOPLADO           := ENTREGADORES_REC.PATENTE_ACOPLADO;
        IMP_CP_REC.DISTANCIA_ESTIMADA         := ENTREGADORES_REC.KM_RECORRER;
        IMP_CP_REC.TARIFA_CP_XTON             := ENTREGADORES_REC.TARIFA_IMPRESION; --impresion
        IMP_CP_REC.TARIFA_REF_FLETE_XTON      := ENTREGADORES_REC.TARIFA_REF_AFIP; --afip
        IF ENTREGADORES_REC.PAGADOR_FLETE IS NOT NULL THEN
          BEGIN
            SELECT s.party_id
            INTO IMP_CP_REC.PAGADOR_FLETE_ID
            FROM ap_suppliers s
            WHERE s.vendor_name = ENTREGADORES_REC.PAGADOR_FLETE;
          EXCEPTION
            WHEN OTHERS THEN
              IMP_CP_REC.PAGADOR_FLETE_ID := NULL;
          END;
        END IF;
        getTransportista(IMP_CP_REC, ENTREGADORES_REC, CTG_REC);

        IF CTG_REC.DISTANCIA IS NOT NULL THEN
          IMP_CP_REC.DISTANCIA_ESTIMADA := CTG_REC.DISTANCIA;
        END IF;

        IF CTG_REC.TARIFA_REF IS NOT NULL THEN
          IMP_CP_REC.TARIFA_REF_FLETE_XTON := CTG_REC.TARIFA_REF;
        END IF;

        --ENVIO
        IMP_CP_REC.FECHA_ENVIO               := ENTREGADORES_REC.FECHA_CARGA;
        IMP_CP_REC.FECHA_CARGA               := ENTREGADORES_REC.FECHA_CARGA;
        IF (ENTREGADORES_REC.PESO_BRUTO_ENVIO - ENTREGADORES_REC.PESO_TARA_ENVIO) != 0 THEN
          IMP_CP_REC.TARA_ENVIO              := ENTREGADORES_REC.PESO_TARA_ENVIO;
          IMP_CP_REC.PESO_BRUTO_ENVIO        := ENTREGADORES_REC.PESO_BRUTO_ENVIO;
        ELSE
          IMP_CP_REC.PESO_ESTIMADO           := ENTREGADORES_REC.PESO_ESTIMADO;
        END IF;
        IMP_CP_REC.PCTAJE_HUMEDAD_ESTIMADA   := ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA;
        IMP_CP_REC.PESO_CTG := CTG_REC.PESO_NETO;

        --RECEPCION
        IMP_CP_REC.FECHA_RECEPCION           := ENTREGADORES_REC.FECHA_RECEPCION;
        IMP_CP_REC.PESO_BRUTO_RECEPCION      := ENTREGADORES_REC.PESO_BRUTO_RECEPCION;
        IMP_CP_REC.TARA_RECEPCION            := ENTREGADORES_REC.PESO_TARA_RECEPCION;
        IMP_CP_REC.INSECTOS_VIVOS_FLAG       := 'N';
        IF NVL(ENTREGADORES_REC.HUMEDAD_PCTAJE,0) BETWEEN 0 AND 100 THEN
          IMP_CP_REC.PCTAJE_HUMEDAD_RECEP      := ENTREGADORES_REC.HUMEDAD_PCTAJE;

          SELECT grupo_control
          INTO l_dummy_chr
          FROM xx_tcg_parametros_compania
          WHERE operating_unit = ENTREGADORES_REC.OPERATING_UNIT;

          BEGIN
            XX_TCG_CALIDAD_PKG.Get_Peso_Merma_Humedad
                              ( p_peso                => IMP_CP_REC.PESO_BRUTO_RECEPCION - IMP_CP_REC.TARA_RECEPCION
                              , p_porcentaje_humedad  => IMP_CP_REC.PCTAJE_HUMEDAD_RECEP
                              , p_item_oncca_code     => IMP_CP_REC.ITEM_ONCCA_CODE
                              , p_item_id             => IMP_CP_REC.ITEM_ID
                              , p_party_id            => IMP_CP_REC.DESTINO_ID
                              , p_party_site_id       => IMP_CP_REC.DESTINO_ESTAB_ID
                              , p_grupo_control       => l_dummy_chr
                              , x_merma_header_id     => IMP_CP_REC.MERMA_HEADER_ID
                              , x_porcentaje_merma    => IMP_CP_REC.PCTAJE_MERMA_HUMEDAD_RECEP
                              , x_peso                => l_dummy_num
                              , x_result              => l_result
                              , x_errmsg              => l_dummy_chr
                              );
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        ELSE
          IMP_CP_REC.CANCELADO_FLAG := 'Y';
          IMP_CP_REC.IMP_CP_STATUS  := 'Cancelado';
          concatComment(IMP_CP_REC, 'El % Humedad está fuera del rango ('||ENTREGADORES_REC.HUMEDAD_PCTAJE||').');
        END IF;

        IF NVL(ENTREGADORES_REC.ZARANDA_PCTAJE,0) BETWEEN 0 AND 100 THEN
          IMP_CP_REC.PCTAJE_ZARANDA_RECEP      := ENTREGADORES_REC.ZARANDA_PCTAJE;
        ELSE
          IMP_CP_REC.CANCELADO_FLAG := 'Y';
          IMP_CP_REC.IMP_CP_STATUS  := 'Cancelado';
          concatComment(IMP_CP_REC, 'El % Zaranda está fuera del rango ('||ENTREGADORES_REC.ZARANDA_PCTAJE||').');
        END IF;

        IF NVL(ENTREGADORES_REC.VOLATIL_PCTAJE,0) BETWEEN 0 AND 100 THEN
          IMP_CP_REC.PCTAJE_VOLATIL_RECEP      := ENTREGADORES_REC.VOLATIL_PCTAJE;
        ELSE
          IMP_CP_REC.CANCELADO_FLAG := 'Y';
          IMP_CP_REC.IMP_CP_STATUS  := 'Cancelado';
          concatComment(IMP_CP_REC, 'El % Volátil está fuera del rango ('||ENTREGADORES_REC.VOLATIL_PCTAJE||').');
        END IF;
        -- Otros ??????

      END IF;

    --
    ELSE
      myDebug('CANCELADO en rutina getCTG', 3);
    END IF;

    IF CTG_REC.ESTADO = 'ANULADO' THEN
      IMP_CP_REC.CANCELADO_FLAG := 'Y';
      IMP_CP_REC.IMP_CP_STATUS  := 'Cancelado';
      IMP_CP_REC.INCONSISTENCIA_CTG_FLAG := 'Y';
    END IF;

    IF NOT insertLines(IMP_CP_REC, x_error_msg) THEN
      RAISE e_InsertLine;
    END IF;
    myDebug('---Fin CP: '||ENTREGADORES_REC.NUMERO_CARTA_PORTE, 2);
  --
  EXCEPTION
    WHEN e_InsertLine THEN
      x_error_msg := 'No fue posible insertar todas las líneas.'||chr(10)||x_error_msg;
      RETURN;
    WHEN Others THEN
      x_error_msg := 'Error derivando campos insertLines.'||chr(10)||SQLERRM;
      myDebug('Error derivando campos insertLines.'||chr(10)||SQLERRM, 2);
      RETURN;
  END insertLines;


  PROCEDURE populateEntregadoresRec (p_field_num      IN     NUMBER
                                    ,p_field_value    IN     VARCHAR2
                                    ,ENTREGADORES_REC IN OUT XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE
                                    ,x_error_msg      OUT    VARCHAR2) IS
    l_num_cp           VARCHAR2(20);
    l_field_value      VARCHAR2(500) := p_field_value;
  BEGIN
    IF NVL(FND_PROFILE.Value('ICX_NUMERIC_CHARACTERS'),'.,') = '.,' AND
       p_field_num IN (3, 4, 22, 23, 24, 34, 35, 36, 40, 41, 42, 43, 44, 45, 46, 47, 48, 60, 63) THEN -- se deben remplazar los separadores de miles
      l_field_value := REPLACE(l_field_value,',','.');
    END IF;

    IF p_field_num IN (7, 8, 9, 10, 11, 12, 13, 14, 15, 16) AND
       l_field_value = '11111111111' THEN
      l_field_value := NULL;
    END IF;

    CASE p_field_num
      WHEN 1 THEN
        ENTREGADORES_REC.TIPO_CP            := l_field_value;
        myDebug('ENTREGADORES_REC.TIPO_CP :'||ENTREGADORES_REC.TIPO_CP, 3);
      WHEN 2 THEN
        ENTREGADORES_REC.NUMERO_CARTA_PORTE := SUBSTR(LPAD(l_field_value,12,0),1,4)||'-'||SUBSTR(LPAD(l_field_value,12,0),5,8);
        myDebug('ENTREGADORES_REC.NUMERO_CARTA_PORTE :'||ENTREGADORES_REC.NUMERO_CARTA_PORTE, 3);
      WHEN 3 THEN
        ENTREGADORES_REC.CEE_NUMERO         := l_field_value;
        myDebug('ENTREGADORES_REC.CEE_NUMERO :'||ENTREGADORES_REC.CEE_NUMERO, 3);
      WHEN 4 THEN
        ENTREGADORES_REC.CTG_NUMERO         := l_field_value;
        myDebug('ENTREGADORES_REC.CTG_NUMERO :'||ENTREGADORES_REC.CTG_NUMERO, 3);
      WHEN 5 THEN
        IF l_field_value IS NULL OR
           ( l_field_value IS NOT NULL AND
             TO_DATE(l_field_value, 'DD/MM/RRRR') = TO_DATE('01011900', 'DD/MM/RRRR') ) THEN
          ENTREGADORES_REC.FECHA_CARGA      := NULL;
        ELSE
          ENTREGADORES_REC.FECHA_CARGA      := TO_DATE(l_field_value, 'DD/MM/RRRR');
        END IF;
        myDebug('ENTREGADORES_REC.FECHA_CARGA :'||ENTREGADORES_REC.FECHA_CARGA, 3);
      WHEN 6 THEN
        IF l_field_value IS NULL OR
           ( l_field_value IS NOT NULL AND
             TO_DATE(l_field_value, 'DD/MM/RRRR') = TO_DATE('01011900', 'DD/MM/RRRR') ) THEN
          ENTREGADORES_REC.FECHA_VENCIMIENTO := NULL;
        ELSE
          ENTREGADORES_REC.FECHA_VENCIMIENTO := TO_DATE(l_field_value, 'DD/MM/RRRR');
        END IF;
        myDebug('ENTREGADORES_REC.FECHA_VENCIMIENTO :'||ENTREGADORES_REC.FECHA_VENCIMIENTO, 3);
      WHEN 7 THEN
        ENTREGADORES_REC.TITULAR_CP_CUIT     := l_field_value;
        myDebug('ENTREGADORES_REC.TITULAR_CP_CUIT :'||ENTREGADORES_REC.TITULAR_CP_CUIT, 3);
      WHEN 8 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.INTERMEDIARIO_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.INTERMEDIARIO_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.INTERMEDIARIO_CUIT :'||ENTREGADORES_REC.INTERMEDIARIO_CUIT, 3);
      WHEN 9 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.RTTE_COMERCIAL_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.RTTE_COMERCIAL_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.RTTE_COMERCIAL_CUIT :'||ENTREGADORES_REC.RTTE_COMERCIAL_CUIT, 3);
      WHEN 10 THEN
        ENTREGADORES_REC.RTTE_COMERCIAL_TIPO  := l_field_value;
        myDebug('ENTREGADORES_REC.RTTE_COMERCIAL_TIPO :'||ENTREGADORES_REC.RTTE_COMERCIAL_TIPO, 3);
      WHEN 11 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.CORREDOR_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.CORREDOR_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.CORREDOR_CUIT :'||ENTREGADORES_REC.CORREDOR_CUIT, 3);
      WHEN 12 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.REPRESENTANTE_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.REPRESENTANTE_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.REPRESENTANTE_CUIT :'||ENTREGADORES_REC.REPRESENTANTE_CUIT, 3);
      WHEN 13 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.DESTINATARIO_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.DESTINATARIO_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.DESTINATARIO_CUIT :'||ENTREGADORES_REC.DESTINATARIO_CUIT, 3);
      WHEN 14 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.DESTINO_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.DESTINO_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.DESTINO_CUIT :'||ENTREGADORES_REC.DESTINO_CUIT, 3);
      WHEN 15 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.TRANSPORTISTA_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.TRANSPORTISTA_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.TRANSPORTISTA_CUIT :'||ENTREGADORES_REC.TRANSPORTISTA_CUIT, 3);
      WHEN 16 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.CHOFER_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.CHOFER_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.CHOFER_CUIT :'||ENTREGADORES_REC.CHOFER_CUIT, 3);
      WHEN 17 THEN
        ENTREGADORES_REC.GRANO_ESPECIE      := l_field_value;
        myDebug('ENTREGADORES_REC.GRANO_ESPECIE :'||ENTREGADORES_REC.GRANO_ESPECIE, 3);
      WHEN 18 THEN
        ENTREGADORES_REC.GRANO_CODIGO_ONCCA := LPAD(l_field_value,3,0);
        myDebug('ENTREGADORES_REC.GRANO_CODIGO_ONCCA :'||ENTREGADORES_REC.GRANO_CODIGO_ONCCA, 3);
      WHEN 19 THEN
        ENTREGADORES_REC.TIPO_GRANO         := l_field_value;
        myDebug('ENTREGADORES_REC.TIPO_GRANO :'||ENTREGADORES_REC.TIPO_GRANO, 3);
      WHEN 20 THEN
        IF l_field_value = '0000' THEN
          ENTREGADORES_REC.CAMPANIA          := NULL;
        ELSE
          ENTREGADORES_REC.CAMPANIA          := REPLACE(l_field_value,'-','');
        END IF;
        myDebug('ENTREGADORES_REC.CAMPANIA :'||ENTREGADORES_REC.CAMPANIA, 3);
      WHEN 21 THEN
        ENTREGADORES_REC.CONTRATO_NUMERO       := l_field_value;
        myDebug('ENTREGADORES_REC.CONTRATO_NUMERO :'||ENTREGADORES_REC.CONTRATO_NUMERO, 3);
      WHEN 22 THEN
        IF ENTREGADORES_REC.FECHA_CARGA IS NOT NULL AND
           NVL(l_field_value, 0) != 0 THEN
          ENTREGADORES_REC.PESO_ESTIMADO    := l_field_value;
        ELSE
          ENTREGADORES_REC.PESO_ESTIMADO    := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.KILOS_ESTIMADOS :'||ENTREGADORES_REC.PESO_ESTIMADO, 3);
      WHEN 23 THEN
        IF NVL(l_field_value, 0) != 0 THEN
          ENTREGADORES_REC.PESO_BRUTO_ENVIO := l_field_value;
        ELSE
          ENTREGADORES_REC.PESO_BRUTO_ENVIO := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.PESO_BRUTO :'||ENTREGADORES_REC.PESO_BRUTO_ENVIO, 3);
      WHEN 24 THEN
        IF NVL(l_field_value, 0) != 0 THEN
          ENTREGADORES_REC.PESO_TARA_ENVIO  := l_field_value;
        ELSE
          ENTREGADORES_REC.PESO_TARA_ENVIO  := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.PESO_TARA :'||ENTREGADORES_REC.PESO_TARA_ENVIO, 3);
      WHEN 25 THEN
        ENTREGADORES_REC.OBSERVACIONES      := l_field_value;
        myDebug('ENTREGADORES_REC.OBSERVACIONES :'||ENTREGADORES_REC.OBSERVACIONES, 3);
      WHEN 26 THEN
        ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO  := l_field_value;
        myDebug('ENTREGADORES_REC.PROCEDENCIA_ESTAB :'||ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO, 3);
      WHEN 27 THEN
        ENTREGADORES_REC.TITULAR_CP_DIRECCION := l_field_value;
        myDebug('ENTREGADORES_REC.PROCEDENCIA_DIRECCION :'||ENTREGADORES_REC.TITULAR_CP_DIRECCION, 3);
      WHEN 28 THEN
        ENTREGADORES_REC.TITULAR_CP_LOCALIDAD  := l_field_value;
        myDebug('ENTREGADORES_REC.PROCEDENCIA_LOCALIDAD :'||ENTREGADORES_REC.TITULAR_CP_LOCALIDAD, 3);
      WHEN 29 THEN
        ENTREGADORES_REC.DESTINO_DIRECCION  := l_field_value;
        myDebug('ENTREGADORES_REC.DESTINO_DIRECCION :'||ENTREGADORES_REC.DESTINO_DIRECCION, 3);
      WHEN 30 THEN
        ENTREGADORES_REC.DESTINO_LOCALIDAD  := l_field_value;
        myDebug('ENTREGADORES_REC.DESTINO_LOCALIDAD :'||ENTREGADORES_REC.DESTINO_LOCALIDAD, 3);
      WHEN 31 THEN
        ENTREGADORES_REC.PAGADOR_FLETE      := l_field_value;
        myDebug('ENTREGADORES_REC.PAGADOR_FLETE :'||ENTREGADORES_REC.PAGADOR_FLETE, 3);
      WHEN 32 THEN
        ENTREGADORES_REC.PATENTE_CAMION     := l_field_value;
        myDebug('ENTREGADORES_REC.PATENTE_CAMION :'||ENTREGADORES_REC.PATENTE_CAMION, 3);
      WHEN 33 THEN
        ENTREGADORES_REC.PATENTE_ACOPLADO   := l_field_value;
        myDebug('ENTREGADORES_REC.PATENTE_ACOPLADO :'||ENTREGADORES_REC.PATENTE_ACOPLADO, 3);
      WHEN 34 THEN
        ENTREGADORES_REC.KM_RECORRER        := l_field_value;
        myDebug('ENTREGADORES_REC.KM_RECORRER :'||ENTREGADORES_REC.KM_RECORRER, 3);
      WHEN 35 THEN
        ENTREGADORES_REC.TARIFA_REF_AFIP    := l_field_value;
        myDebug('ENTREGADORES_REC.TARIFA_REF_FLETE_XTON :'||ENTREGADORES_REC.TARIFA_REF_AFIP, 3);
      WHEN 36 THEN
        ENTREGADORES_REC.TARIFA_IMPRESION   := l_field_value;
        myDebug('ENTREGADORES_REC.TARIFA_IMPRESION :'||ENTREGADORES_REC.TARIFA_IMPRESION, 3);
      WHEN 37 THEN
        ENTREGADORES_REC.FLETE_PAGADO       := l_field_value;
        myDebug('ENTREGADORES_REC.FLETE_PAGADO :'||ENTREGADORES_REC.FLETE_PAGADO, 3);
      WHEN 38 THEN
        ENTREGADORES_REC.FLETE_A_PAGAR      := l_field_value;
        myDebug('ENTREGADORES_REC.FLETE_A_PAGAR :'||ENTREGADORES_REC.FLETE_A_PAGAR, 3);
      WHEN 39 THEN
        IF l_field_value IS NULL OR
           ( l_field_value IS NOT NULL AND
             TO_DATE(l_field_value, 'DD/MM/RRRR') = TO_DATE('01011900', 'DD/MM/RRRR') ) THEN
          ENTREGADORES_REC.FECHA_RECEPCION := NULL;
        ELSE
          ENTREGADORES_REC.FECHA_RECEPCION := TO_DATE(l_field_value, 'DD/MM/RRRR');
        END IF;
        myDebug('ENTREGADORES_REC.FECHA_RECEPCION :'||ENTREGADORES_REC.FECHA_RECEPCION, 3);
      WHEN 40 THEN
        IF NVL(l_field_value, 0) != 0 THEN
          ENTREGADORES_REC.PESO_BRUTO_RECEPCION    := l_field_value;
        ELSE
          ENTREGADORES_REC.PESO_BRUTO_RECEPCION    := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.BRUTO_RECEPCION :'||ENTREGADORES_REC.PESO_BRUTO_RECEPCION, 3);
      WHEN 41 THEN
        IF NVL(l_field_value, 0) != 0 THEN
          ENTREGADORES_REC.PESO_TARA_RECEPCION    := l_field_value;
        ELSE
          ENTREGADORES_REC.PESO_TARA_RECEPCION    := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.TARA_RECEPCION :'||ENTREGADORES_REC.PESO_TARA_RECEPCION, 3);
      WHEN 42 THEN
        ENTREGADORES_REC.HUMEDAD_PCTAJE   := NVL(l_field_value,0);
        myDebug('ENTREGADORES_REC.PCTAJE_HUMEDAD :'||ENTREGADORES_REC.HUMEDAD_PCTAJE, 3);
      WHEN 43 THEN
        ENTREGADORES_REC.HUMEDAD_PCTAJE_MERMA := NVL(l_field_value,0);
        myDebug('ENTREGADORES_REC.PCTAJE_MERMA_HUMEDAD :'||ENTREGADORES_REC.HUMEDAD_PCTAJE_MERMA, 3);
      WHEN 44 THEN
        ENTREGADORES_REC.HUMEDAD_KILOS      := l_field_value;
        myDebug('ENTREGADORES_REC.HUMEDAD_KILOS :'||ENTREGADORES_REC.HUMEDAD_KILOS, 3);
      WHEN 45 THEN
        ENTREGADORES_REC.VOLATIL_PCTAJE       := NVL(l_field_value,0);
        myDebug('ENTREGADORES_REC.PCTAJE_VOLATIL :'||ENTREGADORES_REC.VOLATIL_PCTAJE, 3);
      WHEN 46 THEN
        ENTREGADORES_REC.VOLATIL_KILOS      := l_field_value;
        myDebug('ENTREGADORES_REC.VOLATIL_KILOS :'||ENTREGADORES_REC.VOLATIL_KILOS, 3);
      WHEN 47 THEN
        ENTREGADORES_REC.ZARANDA_PCTAJE       := NVL(l_field_value,0);
        myDebug('ENTREGADORES_REC.PCTAJE_ZARANDA :'||ENTREGADORES_REC.ZARANDA_PCTAJE, 3);
      WHEN 48 THEN
        ENTREGADORES_REC.ZARANDA_KILOS      := l_field_value;
        myDebug('ENTREGADORES_REC.ZARANDA_KILOS :'||ENTREGADORES_REC.ZARANDA_KILOS, 3);
      WHEN 49 THEN
        ENTREGADORES_REC.DESTINO_DESVIO_CUIT := l_field_value;
        myDebug('ENTREGADORES_REC.DESTINO_CUIT_DESVIO :'||ENTREGADORES_REC.DESTINO_DESVIO_CUIT, 3);
      WHEN 50 THEN
        ENTREGADORES_REC.DESTINATARIO_DESVIO_CUIT := l_field_value;
        myDebug('ENTREGADORES_REC.DESTINATARIO_CUIT_DESVIO :'||ENTREGADORES_REC.DESTINATARIO_DESVIO_CUIT, 3);
      WHEN 51 THEN
        ENTREGADORES_REC.DIRECCION_DESVIO   := l_field_value;
        myDebug('ENTREGADORES_REC.DOMICILIO_DESVIO :'||ENTREGADORES_REC.DIRECCION_DESVIO, 3);
      WHEN 52 THEN
        ENTREGADORES_REC.LOCALIDAD_DESVIO   := l_field_value;
        myDebug('ENTREGADORES_REC.LOCALIDAD_DESVIO :'||ENTREGADORES_REC.LOCALIDAD_DESVIO, 3);
      WHEN 53 THEN
        ENTREGADORES_REC.PLANTA_DESVIO      := l_field_value;
        myDebug('ENTREGADORES_REC.PLANTA_DESVIO :'||ENTREGADORES_REC.PLANTA_DESVIO, 3);
      WHEN 54 THEN
        IF l_field_value IS NULL OR
           ( l_field_value IS NOT NULL AND
             TO_DATE(l_field_value, 'DD/MM/RRRR') = TO_DATE('01011900', 'DD/MM/RRRR') ) THEN
          ENTREGADORES_REC.FECHA_DESVIO := NULL;
        ELSE
          ENTREGADORES_REC.FECHA_DESVIO := TO_DATE(l_field_value, 'DD/MM/RRRR');
        END IF;
        myDebug('ENTREGADORES_REC.FECHA :'||ENTREGADORES_REC.FECHA_DESVIO, 3);
      WHEN 55 THEN
        ENTREGADORES_REC.TRASLADO_ORDENADO_POR := l_field_value;
        myDebug('ENTREGADORES_REC.TRASLADO_ORDENADO_POR :'||ENTREGADORES_REC.TRASLADO_ORDENADO_POR, 3);
      WHEN 56 THEN
        ENTREGADORES_REC.DECLARACION_CALIDAD := l_field_value;
        myDebug('ENTREGADORES_REC.DECLARACION_CALIDAD :'||ENTREGADORES_REC.DECLARACION_CALIDAD, 3);
      WHEN 57 THEN
        ENTREGADORES_REC.VARIEDAD_HIBRIDO    := l_field_value;
        myDebug('ENTREGADORES_REC.VARIEDAD_HIBRIDO :'||ENTREGADORES_REC.VARIEDAD_HIBRIDO, 3);
      WHEN 58 THEN
        ENTREGADORES_REC.LOTE                := l_field_value;
        myDebug('ENTREGADORES_REC.LOTE :'||ENTREGADORES_REC.LOTE, 3);
      WHEN 59 THEN
        ENTREGADORES_REC.SILO_ORIGEN         := l_field_value;
        myDebug('ENTREGADORES_REC.SILO_ORIGEN :'||ENTREGADORES_REC.SILO_ORIGEN, 3);
      WHEN 60 THEN
        ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA := l_field_value;
        myDebug('ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA :'||ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA, 3);
      WHEN 61 THEN
        ENTREGADORES_REC.CONTRATO_COMPRA     := l_field_value;
        myDebug('ENTREGADORES_REC.CONTRATO_COMPRA :'||ENTREGADORES_REC.CONTRATO_COMPRA, 3);
      WHEN 62 THEN
        ENTREGADORES_REC.CONTRATO_VENTA      := l_field_value;
        myDebug('ENTREGADORES_REC.CONTRATO_VENTA :'||ENTREGADORES_REC.CONTRATO_VENTA, 3);
      WHEN 63 THEN
        ENTREGADORES_REC.OTROS_DESCUENTOS_KILOS := NVL(l_field_value,0);
        myDebug('ENTREGADORES_REC.OTROS_DESCUENTOS_KILOS :'||ENTREGADORES_REC.OTROS_DESCUENTOS_KILOS, 3);
      WHEN 64 THEN
        ENTREGADORES_REC.PROCESO_GENERACION     := l_field_value;
        myDebug('ENTREGADORES_REC.PROCESO_GENERACION :'||ENTREGADORES_REC.PROCESO_GENERACION, 3);
      WHEN 65 THEN
        ENTREGADORES_REC.CARTA_PORTE_REEMPLAZADA := SUBSTR(LPAD(l_field_value,12,0),1,4)||'-'||SUBSTR(LPAD(l_field_value,12,0),5,8);
        myDebug('ENTREGADORES_REC.CARTA_PORTE_REEMPLAZADA :'||ENTREGADORES_REC.CARTA_PORTE_REEMPLAZADA, 3);
      WHEN 66 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.MERCADO_TERMINO_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.MERCADO_TERMINO_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.MERCADO_TERMINO_CUIT :'||ENTREGADORES_REC.MERCADO_TERMINO_CUIT, 3);
      WHEN 67 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT :'||ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT, 3);
      WHEN 68 THEN
        IF l_field_value != 0 THEN
          ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT := l_field_value;
        ELSE
          ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT := NULL;
        END IF;
        myDebug('ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT :'||ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT, 3);
      WHEN 69 THEN
        ENTREGADORES_REC.RENSPA             := l_field_value;
        myDebug('ENTREGADORES_REC.RENSPA :'||ENTREGADORES_REC.RENSPA, 3);
      WHEN 70 THEN
        ENTREGADORES_REC.INTERMEDIARIO     := l_field_value;
        myDebug('ENTREGADORES_REC.INTERMEDIARIO :'||ENTREGADORES_REC.INTERMEDIARIO, 3);
      WHEN 71 THEN
        ENTREGADORES_REC.RTTE_COMERCIAL    := l_field_value;
        myDebug('ENTREGADORES_REC.RTTE_COMERCIAL :'||ENTREGADORES_REC.RTTE_COMERCIAL, 3);
      WHEN 72 THEN
        ENTREGADORES_REC.CORREDOR_COMPRADOR := l_field_value;
        myDebug('ENTREGADORES_REC.CORREDOR :'||ENTREGADORES_REC.CORREDOR_COMPRADOR, 3);
      WHEN 73 THEN
        ENTREGADORES_REC.MERCADO_TERMINO   := l_field_value;
        myDebug('ENTREGADORES_REC.MERCADO_TERMINO :'||ENTREGADORES_REC.MERCADO_TERMINO, 3);
      WHEN 74 THEN
        ENTREGADORES_REC.CORREDOR_VENDEDOR  := l_field_value;
        myDebug('ENTREGADORES_REC.CORREDOR_VENDEDOR :'||ENTREGADORES_REC.CORREDOR_VENDEDOR, 3);
      WHEN 75 THEN
        ENTREGADORES_REC.REPRESENTANTE     := l_field_value;
        myDebug('ENTREGADORES_REC.REPRESENTANTE :'||ENTREGADORES_REC.REPRESENTANTE, 3);
      WHEN 76 THEN
        ENTREGADORES_REC.DESTINATARIO      := l_field_value;
        myDebug('ENTREGADORES_REC.DESTINATARIO :'||ENTREGADORES_REC.DESTINATARIO, 3);
      WHEN 77 THEN
        ENTREGADORES_REC.DESTINO           := l_field_value;
        myDebug('ENTREGADORES_REC.DESTINO :'||ENTREGADORES_REC.DESTINO, 3);
      WHEN 78 THEN
        ENTREGADORES_REC.INTERMEDIARIO_FLETE := l_field_value;
        myDebug('ENTREGADORES_REC.INTERMEDIARIO_FLETE :'||ENTREGADORES_REC.INTERMEDIARIO_FLETE, 3);
      WHEN 79 THEN
        ENTREGADORES_REC.TRANSPORTISTA     := l_field_value;
        myDebug('ENTREGADORES_REC.TRANSPORTISTA :'||ENTREGADORES_REC.TRANSPORTISTA, 3);
      WHEN 80 THEN
        ENTREGADORES_REC.CHOFER            := l_field_value;
        myDebug('ENTREGADORES_REC.CHOFER :'||ENTREGADORES_REC.CHOFER, 3);
      WHEN 81 THEN
        ENTREGADORES_REC.COT_NUMERO       := l_field_value;
        myDebug('ENTREGADORES_REC.COT_NUMERO :'||ENTREGADORES_REC.COT_NUMERO, 3);
      WHEN 82 THEN
        ENTREGADORES_REC.ATTRIBUTE1         := l_field_value;
      WHEN 83 THEN
        ENTREGADORES_REC.ATTRIBUTE2         := l_field_value;
      WHEN 84 THEN
        ENTREGADORES_REC.ATTRIBUTE3         := l_field_value;
      WHEN 85 THEN
        ENTREGADORES_REC.ATTRIBUTE4         := l_field_value;
      WHEN 86 THEN
        ENTREGADORES_REC.ATTRIBUTE5         := l_field_value;
      WHEN 87 THEN
        ENTREGADORES_REC.ATTRIBUTE6         := l_field_value;
      WHEN 88 THEN
        ENTREGADORES_REC.ATTRIBUTE7         := l_field_value;
      WHEN 89 THEN
        ENTREGADORES_REC.ATTRIBUTE8         := l_field_value;
      WHEN 90 THEN
        ENTREGADORES_REC.ATTRIBUTE9         := l_field_value;
      WHEN 91 THEN
        ENTREGADORES_REC.TURNO              := l_field_value;
      ELSE
        NULL;
    END CASE;

  --
  EXCEPTION
    WHEN Others THEN
      x_error_msg := 'No fue posible cargar el registro Entregadores.'||chr(10)||SQLERRM;
  END populateEntregadoresRec;


  PROCEDURE parseLineWS ( p_row_count OUT VARCHAR2
                        , x_error_msg OUT VARCHAR2
                        ) IS
    CURSOR c1 IS
      SELECT *
      FROM xx_tcg_cartas_porte_interface
      WHERE 1=1
      AND importado_flag = 'N'
      AND orden_carga_id = g_batch_id
      ;

    l_get_ou           BOOLEAN;
    l_nro_cupo         VARCHAR2(150);
    ENTREGADORES_REC   XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE;
  BEGIN
    myDebug('-------------- Comienzo Info Entregador --------------', 3);
    p_row_count := 0;
    FOR r1 IN c1 LOOP
      ENTREGADORES_REC := NULL;

      ENTREGADORES_REC.NUMERO_CARTA_PORTE   := r1.NUMERO_CARTA_PORTE;
      myDebug('ENTREGADORES_REC.NUMERO_CARTA_PORTE :'||ENTREGADORES_REC.NUMERO_CARTA_PORTE, 3);

      ENTREGADORES_REC.CEE_NUMERO           := r1.CEE_NUMERO;
      myDebug('ENTREGADORES_REC.CEE_NUMERO :'||ENTREGADORES_REC.CEE_NUMERO, 3);

      ENTREGADORES_REC.CTG_NUMERO           := r1.CTG_NUMERO;
      myDebug('ENTREGADORES_REC.CTG_NUMERO :'||ENTREGADORES_REC.CTG_NUMERO, 3);

      ENTREGADORES_REC.FECHA_CARGA          := r1.FECHA_CARGA;
      myDebug('ENTREGADORES_REC.FECHA_CARGA :'||ENTREGADORES_REC.FECHA_CARGA, 3);

      ENTREGADORES_REC.FECHA_VENCIMIENTO    := r1.FECHA_VENCIMIENTO;
      myDebug('ENTREGADORES_REC.FECHA_VENCIMIENTO :'||ENTREGADORES_REC.FECHA_VENCIMIENTO, 3);

      ENTREGADORES_REC.TITULAR_CP_CUIT      := r1.TITULAR_CP_CUIT;
      myDebug('ENTREGADORES_REC.TITULAR_CP_CUIT :'||ENTREGADORES_REC.TITULAR_CP_CUIT, 3);

      ENTREGADORES_REC.INTERMEDIARIO_CUIT   := r1.INTERMEDIARIO_CUIT;
      myDebug('ENTREGADORES_REC.INTERMEDIARIO_CUIT :'||ENTREGADORES_REC.INTERMEDIARIO_CUIT, 3);

      ENTREGADORES_REC.RTTE_COMERCIAL_CUIT  := r1.RTTE_COMERCIAL_CUIT;
      myDebug('ENTREGADORES_REC.RTTE_COMERCIAL_CUIT :'||ENTREGADORES_REC.RTTE_COMERCIAL_CUIT, 3);

      ENTREGADORES_REC.RTTE_COMERCIAL_TIPO  := r1.RTTE_COMERCIAL_TIPO;
      myDebug('ENTREGADORES_REC.RTTE_COMERCIAL_TIPO :'||ENTREGADORES_REC.RTTE_COMERCIAL_TIPO, 3);

      ENTREGADORES_REC.CORREDOR_CUIT        := r1.CORREDOR_CUIT;
      myDebug('ENTREGADORES_REC.CORREDOR_CUIT :'||ENTREGADORES_REC.CORREDOR_CUIT, 3);

      ENTREGADORES_REC.REPRESENTANTE_CUIT   := r1.REPRESENTANTE_CUIT;
      myDebug('ENTREGADORES_REC.REPRESENTANTE_CUIT :'||ENTREGADORES_REC.REPRESENTANTE_CUIT, 3);

      ENTREGADORES_REC.DESTINATARIO_CUIT    := r1.DESTINATARIO_CUIT;
      myDebug('ENTREGADORES_REC.DESTINATARIO_CUIT :'||ENTREGADORES_REC.DESTINATARIO_CUIT, 3);

      ENTREGADORES_REC.DESTINO_CUIT         := r1.DESTINO_CUIT;
      myDebug('ENTREGADORES_REC.DESTINO_CUIT :'||ENTREGADORES_REC.DESTINO_CUIT, 3);

      ENTREGADORES_REC.TRANSPORTISTA_CUIT   := r1.TRANSPORTISTA_CUIT;
      myDebug('ENTREGADORES_REC.TRANSPORTISTA_CUIT :'||ENTREGADORES_REC.TRANSPORTISTA_CUIT, 3);

      ENTREGADORES_REC.CHOFER_CUIT          := r1.CHOFER_CUIT;
      myDebug('ENTREGADORES_REC.CHOFER_CUIT :'||ENTREGADORES_REC.CHOFER_CUIT, 3);

      ENTREGADORES_REC.GRANO_ESPECIE        := r1.GRANO_ESPECIE;
      myDebug('ENTREGADORES_REC.GRANO_ESPECIE :'||ENTREGADORES_REC.GRANO_ESPECIE, 3);

      ENTREGADORES_REC.GRANO_CODIGO_ONCCA   := r1.GRANO_CODIGO_ONCCA;
      myDebug('ENTREGADORES_REC.GRANO_CODIGO_ONCCA :'||ENTREGADORES_REC.GRANO_CODIGO_ONCCA, 3);

      ENTREGADORES_REC.TIPO_GRANO           := r1.TIPO_GRANO;
      myDebug('ENTREGADORES_REC.TIPO_GRANO :'||ENTREGADORES_REC.TIPO_GRANO, 3);

      ENTREGADORES_REC.CAMPANIA             := r1.CAMPANIA;
      myDebug('ENTREGADORES_REC.CAMPANIA :'||ENTREGADORES_REC.CAMPANIA, 3);

      ENTREGADORES_REC.CONTRATO_NUMERO      := r1.CONTRATO_NUMERO;
      myDebug('ENTREGADORES_REC.CONTRATO_NUMERO :'||ENTREGADORES_REC.CONTRATO_NUMERO, 3);

      ENTREGADORES_REC.PESO_ESTIMADO        := r1.PESO_ESTIMADO;
      myDebug('ENTREGADORES_REC.KILOS_ESTIMADOS :'||ENTREGADORES_REC.PESO_ESTIMADO, 3);

      ENTREGADORES_REC.PESO_BRUTO_ENVIO     := r1.PESO_BRUTO_ENVIO;
      myDebug('ENTREGADORES_REC.PESO_BRUTO :'||ENTREGADORES_REC.PESO_BRUTO_ENVIO, 3);

      ENTREGADORES_REC.PESO_TARA_ENVIO      := r1.PESO_TARA_ENVIO;
      myDebug('ENTREGADORES_REC.PESO_TARA :'||ENTREGADORES_REC.PESO_TARA_ENVIO, 3);

      ENTREGADORES_REC.OBSERVACIONES        := r1.OBSERVACIONES;
      myDebug('ENTREGADORES_REC.OBSERVACIONES :'||ENTREGADORES_REC.OBSERVACIONES, 3);

      ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO  := r1.TITULAR_CP_ESTABLECIMIENTO;
      myDebug('ENTREGADORES_REC.PROCEDENCIA_ESTAB :'||ENTREGADORES_REC.TITULAR_CP_ESTABLECIMIENTO, 3);

      ENTREGADORES_REC.TITULAR_CP_DIRECCION := r1.TITULAR_CP_DIRECCION;
      myDebug('ENTREGADORES_REC.PROCEDENCIA_DIRECCION :'||ENTREGADORES_REC.TITULAR_CP_DIRECCION, 3);

      ENTREGADORES_REC.TITULAR_CP_LOCALIDAD := r1.TITULAR_CP_LOCALIDAD;
      myDebug('ENTREGADORES_REC.PROCEDENCIA_LOCALIDAD :'||ENTREGADORES_REC.TITULAR_CP_LOCALIDAD, 3);

      ENTREGADORES_REC.DESTINO_DIRECCION    := r1.DESTINO_DIRECCION;
      myDebug('ENTREGADORES_REC.DESTINO_DIRECCION :'||ENTREGADORES_REC.DESTINO_DIRECCION, 3);

      ENTREGADORES_REC.DESTINO_LOCALIDAD    := r1.DESTINO_LOCALIDAD;
      myDebug('ENTREGADORES_REC.DESTINO_LOCALIDAD :'||ENTREGADORES_REC.DESTINO_LOCALIDAD, 3);

      ENTREGADORES_REC.PAGADOR_FLETE        := r1.PAGADOR_FLETE;
      myDebug('ENTREGADORES_REC.PAGADOR_FLETE :'||ENTREGADORES_REC.PAGADOR_FLETE, 3);

      ENTREGADORES_REC.PATENTE_CAMION       := r1.PATENTE_CAMION;
      myDebug('ENTREGADORES_REC.PATENTE_CAMION :'||ENTREGADORES_REC.PATENTE_CAMION, 3);

      ENTREGADORES_REC.PATENTE_ACOPLADO     := r1.PATENTE_ACOPLADO;
      myDebug('ENTREGADORES_REC.PATENTE_ACOPLADO :'||ENTREGADORES_REC.PATENTE_ACOPLADO, 3);

      ENTREGADORES_REC.KM_RECORRER          := r1.KM_RECORRER;
      myDebug('ENTREGADORES_REC.KM_RECORRER :'||ENTREGADORES_REC.KM_RECORRER, 3);

      ENTREGADORES_REC.TARIFA_REF_AFIP      := r1.TARIFA_REF_AFIP;
      myDebug('ENTREGADORES_REC.TARIFA_REF_FLETE_XTON :'||ENTREGADORES_REC.TARIFA_REF_AFIP, 3);

      ENTREGADORES_REC.TARIFA_IMPRESION     := r1.TARIFA_IMPRESION;
      myDebug('ENTREGADORES_REC.TARIFA_IMPRESION :'||ENTREGADORES_REC.TARIFA_IMPRESION, 3);

      ENTREGADORES_REC.FLETE_PAGADO         := r1.FLETE_PAGADO;
      myDebug('ENTREGADORES_REC.FLETE_PAGADO :'||ENTREGADORES_REC.FLETE_PAGADO, 3);

      ENTREGADORES_REC.FLETE_A_PAGAR        := r1.FLETE_A_PAGAR;
      myDebug('ENTREGADORES_REC.FLETE_A_PAGAR :'||ENTREGADORES_REC.FLETE_A_PAGAR, 3);

      ENTREGADORES_REC.FECHA_RECEPCION      := r1.FECHA_RECEPCION;
      myDebug('ENTREGADORES_REC.FECHA_RECEPCION :'||ENTREGADORES_REC.FECHA_RECEPCION, 3);

      ENTREGADORES_REC.PESO_BRUTO_RECEPCION := r1.PESO_BRUTO_RECEPCION;
      myDebug('ENTREGADORES_REC.BRUTO_RECEPCION :'||ENTREGADORES_REC.PESO_BRUTO_RECEPCION, 3);

      ENTREGADORES_REC.PESO_TARA_RECEPCION  := r1.PESO_TARA_RECEPCION;
      myDebug('ENTREGADORES_REC.TARA_RECEPCION :'||ENTREGADORES_REC.PESO_TARA_RECEPCION, 3);

      ENTREGADORES_REC.HUMEDAD_PCTAJE       := r1.HUMEDAD_PCTAJE;
      myDebug('ENTREGADORES_REC.PCTAJE_HUMEDAD :'||ENTREGADORES_REC.HUMEDAD_PCTAJE, 3);

      ENTREGADORES_REC.HUMEDAD_PCTAJE_MERMA := r1.HUMEDAD_PCTAJE_MERMA;
      myDebug('ENTREGADORES_REC.PCTAJE_MERMA_HUMEDAD :'||ENTREGADORES_REC.HUMEDAD_PCTAJE_MERMA, 3);

      ENTREGADORES_REC.HUMEDAD_KILOS        := r1.HUMEDAD_KILOS;
      myDebug('ENTREGADORES_REC.HUMEDAD_KILOS :'||ENTREGADORES_REC.HUMEDAD_KILOS, 3);

      ENTREGADORES_REC.VOLATIL_PCTAJE       := r1.VOLATIL_PCTAJE;
      myDebug('ENTREGADORES_REC.PCTAJE_VOLATIL :'||ENTREGADORES_REC.VOLATIL_PCTAJE, 3);

      ENTREGADORES_REC.VOLATIL_KILOS        := r1.VOLATIL_KILOS;
      myDebug('ENTREGADORES_REC.VOLATIL_KILOS :'||ENTREGADORES_REC.VOLATIL_KILOS, 3);

      ENTREGADORES_REC.ZARANDA_PCTAJE       := r1.ZARANDA_PCTAJE;
      myDebug('ENTREGADORES_REC.PCTAJE_ZARANDA :'||ENTREGADORES_REC.ZARANDA_PCTAJE, 3);

      ENTREGADORES_REC.ZARANDA_KILOS        := r1.ZARANDA_KILOS;
      myDebug('ENTREGADORES_REC.ZARANDA_KILOS :'||ENTREGADORES_REC.ZARANDA_KILOS, 3);

      ENTREGADORES_REC.DESTINO_DESVIO_CUIT  := r1.DESTINO_DESVIO_CUIT;
      myDebug('ENTREGADORES_REC.DESTINO_CUIT_DESVIO :'||ENTREGADORES_REC.DESTINO_DESVIO_CUIT, 3);

      ENTREGADORES_REC.DESTINATARIO_DESVIO_CUIT := r1.DESTINATARIO_DESVIO_CUIT;
      myDebug('ENTREGADORES_REC.DESTINATARIO_CUIT_DESVIO :'||ENTREGADORES_REC.DESTINATARIO_DESVIO_CUIT, 3);

      ENTREGADORES_REC.DIRECCION_DESVIO     := r1.DIRECCION_DESVIO;
      myDebug('ENTREGADORES_REC.DOMICILIO_DESVIO :'||ENTREGADORES_REC.DIRECCION_DESVIO, 3);

      ENTREGADORES_REC.LOCALIDAD_DESVIO     := r1.LOCALIDAD_DESVIO;
      myDebug('ENTREGADORES_REC.LOCALIDAD_DESVIO :'||ENTREGADORES_REC.LOCALIDAD_DESVIO, 3);

      ENTREGADORES_REC.PLANTA_DESVIO        := r1.PLANTA_DESVIO;
      myDebug('ENTREGADORES_REC.PLANTA_DESVIO :'||ENTREGADORES_REC.PLANTA_DESVIO, 3);

      ENTREGADORES_REC.FECHA_DESVIO         := r1.FECHA_DESVIO;
      myDebug('ENTREGADORES_REC.FECHA :'||ENTREGADORES_REC.FECHA_DESVIO, 3);

      ENTREGADORES_REC.TRASLADO_ORDENADO_POR := r1.TRASLADO_ORDENADO_POR;
      myDebug('ENTREGADORES_REC.TRASLADO_ORDENADO_POR :'||ENTREGADORES_REC.TRASLADO_ORDENADO_POR, 3);

      ENTREGADORES_REC.DECLARACION_CALIDAD  := r1.DECLARACION_CALIDAD;
      myDebug('ENTREGADORES_REC.DECLARACION_CALIDAD :'||ENTREGADORES_REC.DECLARACION_CALIDAD, 3);

      ENTREGADORES_REC.VARIEDAD_HIBRIDO     := r1.VARIEDAD_HIBRIDO;
      myDebug('ENTREGADORES_REC.VARIEDAD_HIBRIDO :'||ENTREGADORES_REC.VARIEDAD_HIBRIDO, 3);

      ENTREGADORES_REC.LOTE                 := r1.LOTE;
      myDebug('ENTREGADORES_REC.LOTE :'||ENTREGADORES_REC.LOTE, 3);

      ENTREGADORES_REC.SILO_ORIGEN          := r1.SILO_ORIGEN;
      myDebug('ENTREGADORES_REC.SILO_ORIGEN :'||ENTREGADORES_REC.SILO_ORIGEN, 3);

      ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA := r1.PCTAJE_HUMEDAD_SALIDA;
      myDebug('ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA :'||ENTREGADORES_REC.PCTAJE_HUMEDAD_SALIDA, 3);

      ENTREGADORES_REC.CONTRATO_COMPRA      := r1.CONTRATO_COMPRA;
      myDebug('ENTREGADORES_REC.CONTRATO_COMPRA :'||ENTREGADORES_REC.CONTRATO_COMPRA, 3);

      ENTREGADORES_REC.CONTRATO_VENTA       := r1.CONTRATO_VENTA;
      myDebug('ENTREGADORES_REC.CONTRATO_VENTA :'||ENTREGADORES_REC.CONTRATO_VENTA, 3);

      ENTREGADORES_REC.OTROS_DESCUENTOS_KILOS := r1.OTROS_DESCUENTOS_KILOS;
      myDebug('ENTREGADORES_REC.OTROS_DESCUENTOS_KILOS :'||ENTREGADORES_REC.OTROS_DESCUENTOS_KILOS, 3);

      ENTREGADORES_REC.PROCESO_GENERACION   := r1.PROCESO_GENERACION;
      myDebug('ENTREGADORES_REC.PROCESO_GENERACION :'||ENTREGADORES_REC.PROCESO_GENERACION, 3);

      ENTREGADORES_REC.CARTA_PORTE_REEMPLAZADA := r1.CARTA_PORTE_REEMPLAZADA;
      myDebug('ENTREGADORES_REC.CARTA_PORTE_REEMPLAZADA :'||ENTREGADORES_REC.CARTA_PORTE_REEMPLAZADA, 3);

      ENTREGADORES_REC.MERCADO_TERMINO_CUIT := r1.MERCADO_TERMINO_CUIT;
      myDebug('ENTREGADORES_REC.MERCADO_TERMINO_CUIT :'||ENTREGADORES_REC.MERCADO_TERMINO_CUIT, 3);

      ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT := r1.CORREDOR_VENDEDOR_CUIT;
      myDebug('ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT :'||ENTREGADORES_REC.CORREDOR_VENDEDOR_CUIT, 3);

      ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT := r1.INTERMEDIARIO_FLETE_CUIT;
      myDebug('ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT :'||ENTREGADORES_REC.INTERMEDIARIO_FLETE_CUIT, 3);

      ENTREGADORES_REC.RENSPA               := r1.RENSPA;
      myDebug('ENTREGADORES_REC.RENSPA :'||ENTREGADORES_REC.RENSPA, 3);

      ENTREGADORES_REC.INTERMEDIARIO        := r1.INTERMEDIARIO;
      myDebug('ENTREGADORES_REC.INTERMEDIARIO :'||ENTREGADORES_REC.INTERMEDIARIO, 3);

      ENTREGADORES_REC.RTTE_COMERCIAL       := r1.RTTE_COMERCIAL;
      myDebug('ENTREGADORES_REC.RTTE_COMERCIAL :'||ENTREGADORES_REC.RTTE_COMERCIAL, 3);

      ENTREGADORES_REC.CORREDOR_COMPRADOR   := r1.CORREDOR_COMPRADOR;
      myDebug('ENTREGADORES_REC.CORREDOR :'||ENTREGADORES_REC.CORREDOR_COMPRADOR, 3);

      ENTREGADORES_REC.MERCADO_TERMINO      := r1.MERCADO_TERMINO;
      myDebug('ENTREGADORES_REC.MERCADO_TERMINO :'||ENTREGADORES_REC.MERCADO_TERMINO, 3);

      ENTREGADORES_REC.CORREDOR_VENDEDOR    := r1.CORREDOR_VENDEDOR;
      myDebug('ENTREGADORES_REC.CORREDOR_VENDEDOR :'||ENTREGADORES_REC.CORREDOR_VENDEDOR, 3);

      ENTREGADORES_REC.REPRESENTANTE        := r1.REPRESENTANTE;
      myDebug('ENTREGADORES_REC.REPRESENTANTE :'||ENTREGADORES_REC.REPRESENTANTE, 3);

      ENTREGADORES_REC.DESTINATARIO         := r1.DESTINATARIO;
      myDebug('ENTREGADORES_REC.DESTINATARIO :'||ENTREGADORES_REC.DESTINATARIO, 3);

      ENTREGADORES_REC.DESTINO              := r1.DESTINO;
      myDebug('ENTREGADORES_REC.DESTINO :'||ENTREGADORES_REC.DESTINO, 3);

      ENTREGADORES_REC.INTERMEDIARIO_FLETE  := r1.INTERMEDIARIO_FLETE;
      myDebug('ENTREGADORES_REC.INTERMEDIARIO_FLETE :'||ENTREGADORES_REC.INTERMEDIARIO_FLETE, 3);

      ENTREGADORES_REC.TRANSPORTISTA        := r1.TRANSPORTISTA;
      myDebug('ENTREGADORES_REC.TRANSPORTISTA :'||ENTREGADORES_REC.TRANSPORTISTA, 3);

      ENTREGADORES_REC.CHOFER               := r1.CHOFER;
      myDebug('ENTREGADORES_REC.CHOFER :'||ENTREGADORES_REC.CHOFER, 3);

      ENTREGADORES_REC.COT_NUMERO           := r1.COT_NUMERO;
      myDebug('ENTREGADORES_REC.COT_NUMERO :'||ENTREGADORES_REC.COT_NUMERO, 3);

      BEGIN
        SELECT DISTINCT cupo_numero
        INTO ENTREGADORES_REC.TURNO
        FROM xx_tcg_cupos
        WHERE cupo_id = r1.cupo_id;
      EXCEPTION
        WHEN OTHERS THEN
          ENTREGADORES_REC.TURNO := NULL;
      END;

      /* Obtengo operating_unit */
      IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.TITULAR_CP_CUIT) THEN
        l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.TITULAR_CP_CUIT, ENTREGADORES_REC);
      ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.INTERMEDIARIO_CUIT) THEN
        l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.INTERMEDIARIO_CUIT, ENTREGADORES_REC);
      ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.RTTE_COMERCIAL_CUIT) THEN
        l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.RTTE_COMERCIAL_CUIT, ENTREGADORES_REC);
      ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.DESTINATARIO_CUIT) THEN
        l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.DESTINATARIO_CUIT, ENTREGADORES_REC);
      ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.DESTINO_CUIT) THEN
        l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.DESTINO_CUIT, ENTREGADORES_REC);
      END IF;


      IF NOT l_get_ou OR
         ENTREGADORES_REC.OPERATING_UNIT IS NULL THEN
        x_error_msg := 'No fue posible determinar unidad operativa.';
        RETURN;
      END IF;


      INSERT INTO XX_TCG_ARCHIVO_ENTREGADORES VALUES ENTREGADORES_REC;

      UPDATE xx_tcg_cartas_porte_interface cpi
      SET cpi.importado_flag = 'Y'
      WHERE 1=1
      AND cpi.orden_carga_id = g_batch_id
      AND cpi.numero_carta_porte = r1.numero_carta_porte;

      p_row_count := p_row_count + 1;
    --
    END LOOP;

    myDebug('-------------- Fin Info Entregador --------------', 3);
  EXCEPTION
    WHEN Others THEN
      x_error_msg := 'No fue posible parsear la linea.'||chr(10)||SQLERRM;
  END parseLineWS;


  PROCEDURE parseLine ( p_line          VARCHAR2
                      , x_error_msg OUT VARCHAR2) IS
    l_line             VARCHAR2(2000) := p_line;
    l_field            VARCHAR2(500);
    l_field_num        NUMBER := 1;
    l_get_ou           BOOLEAN;
    ENTREGADORES_REC   XX_TCG_ARCHIVO_ENTREGADORES%ROWTYPE;
  BEGIN
    myDebug('-------------- Comienzo Info Entregador --------------', 3);
    WHILE INSTR(l_line, '|') > 0 LOOP
      l_field := SUBSTR(l_line,1,INSTR(l_line, '|')-1);
      /*IF l_field IS NULL THEN
        --myDebug('NULL');
      ELSE
        myDebug(l_field);
      END IF;*/

      populateEntregadoresRec (l_field_num, l_field, ENTREGADORES_REC, x_error_msg);

      l_line := SUBSTR(l_line,INSTR(l_line,'|')+1,LENGTH(l_line));
      l_field_num := l_field_num + 1;
    --
    END LOOP;

    IF x_error_msg IS NOT NULL THEN
      RETURN;
    END IF;

    /* Obtengo operating_unit */
    IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.TITULAR_CP_CUIT) THEN
      l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.TITULAR_CP_CUIT, ENTREGADORES_REC);
    ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.INTERMEDIARIO_CUIT) THEN
      l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.INTERMEDIARIO_CUIT, ENTREGADORES_REC);
    ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.RTTE_COMERCIAL_CUIT) THEN
      l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.RTTE_COMERCIAL_CUIT, ENTREGADORES_REC);
    ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.DESTINATARIO_CUIT) THEN
      l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.DESTINATARIO_CUIT, ENTREGADORES_REC);
    ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(ENTREGADORES_REC.DESTINO_CUIT) THEN
      l_get_ou := getCompanyCodeOrgID( ENTREGADORES_REC.DESTINO_CUIT, ENTREGADORES_REC);
    END IF;


    IF NOT l_get_ou OR
       ENTREGADORES_REC.OPERATING_UNIT IS NULL THEN
      x_error_msg := 'No fue posible determinar unidad operativa.';
      RETURN;
    END IF;

    ENTREGADORES_REC.LINEA_IMPORTADA := p_line;

    INSERT INTO XX_TCG_ARCHIVO_ENTREGADORES VALUES ENTREGADORES_REC;

    myDebug('-------------- Fin Info Entregador --------------', 3);
  EXCEPTION
    WHEN Others THEN
      x_error_msg := 'No fue posible parsear la linea.'||chr(10)||SQLERRM;
  END parseLine;


  PROCEDURE Cargar_CP ( p_operating_unit    IN  NUMBER
                      , p_directorio        IN  VARCHAR2
                      , p_nombre_archivo    IN  VARCHAR2
                      , p_fuente            IN  VARCHAR2
                      , x_batch_id          OUT NUMBER
                      , x_error_msg         OUT VARCHAR
                      ) IS
    p_cuit_imp          VARCHAR2(50);
    l_in                UTL_FILE.file_type;
    l_line              VARCHAR2(2000);
    l_fuente            VARCHAR2(250);
    --
    l_row_count         NUMBER := 0;
    l_curr_ou           NUMBER;
    l_total_ou          NUMBER;
    e_NoFile            EXCEPTION;
    e_EmptyFile         EXCEPTION;
    e_NoRecords         EXCEPTION;
    e_MyExit            EXCEPTION;
  BEGIN
    x_error_msg := NULL;

    -- Populo las globales
    SELECT operating_unit_cuit, grupo_control
    INTO p_cuit_imp, g_grupo_control
    FROM xx_tcg_parametros_compania
    WHERE 1=1
    AND operating_unit = p_operating_unit;

    g_operating_unit := p_operating_unit;
    g_cuit_imp := p_cuit_imp;

    BEGIN
      SELECT UPPER(meaning)
      INTO l_fuente
      FROM FND_LOOKUP_VALUES_VL
      WHERE lookup_type = 'XX_ACO_ENTREGADORES'
      AND lookup_code   = p_fuente;
    EXCEPTION
      WHEN OTHERS THEN
        l_fuente := 'OTROS';
    END;

    myDebug('Comenzando con el proceso de importación de CPs...'||chr(10)
          ||'Parámetros: '||chr(10)
          ||'Unidad Operativa: '||p_operating_unit||chr(10)
          ||'CUIT: '||p_cuit_imp||chr(10)
          ||'Directorio: '||p_directorio||chr(10)
          ||'Nombre Archivo: '||p_nombre_archivo||chr(10)
          ||'Fuente: '||l_fuente||chr(10)
          ||'----------------------------------------------------------'
           , 1);

    IF l_fuente = 'CPPRO WS' THEN
      g_batch_id := NVL(SUBSTR(p_nombre_archivo,1,INSTR(p_nombre_archivo,' ')), p_nombre_archivo);
      parseLineWS (l_row_count, x_error_msg);

      IF l_row_count = 0 THEN
        RAISE e_EmptyFile;
      END IF;
    ELSE
      --Obtener el directorio del perfil o bien pasar como parametro
      BEGIN
        l_in := UTL_FILE.FOpen_NChar (p_directorio, p_nombre_archivo, 'R', 32767);
      EXCEPTION
        WHEN Others THEN
          RAISE e_NoFile;
      END;

      BEGIN
        LOOP
          UTL_FILE.Get_Line_NChar (l_in, l_line);

          IF NVL(LENGTH(TRIM(REPLACE(l_line,chr(9),' '))),0) > 0 THEN
            parseLine (l_line, x_error_msg);

            l_row_count := l_row_count + 1;

            IF x_error_msg IS NOT NULL THEN
              x_error_msg := 'Error en linea '||l_row_count||'. '||x_error_msg;
              RAISE e_MyExit;
            END IF;

          END IF;
        END LOOP;
      EXCEPTION
        WHEN No_Data_Found THEN
          UTL_FILE.FClose(l_in);
      END;

      UTL_FILE.FClose(l_in);

      IF l_row_count = 0 THEN
        RAISE e_EmptyFile;
      END IF;

    END IF;

    SELECT COUNT(DECODE(operating_unit, p_operating_unit, 1, NULL)), COUNT(DISTINCT operating_unit)
    INTO l_curr_ou, l_total_ou
    FROM XX_TCG_ARCHIVO_ENTREGADORES;

    IF l_curr_ou = 0 THEN
      RAISE e_NoRecords;
    END IF;

    /* Importo los datos de la compañia donde estoy parado */
    IF l_fuente != 'CPPRO WS' THEN
      SELECT XX_ACO_IMP_CP.nextval
      INTO g_batch_id
      FROM DUAL;
    END IF;

    l_row_count := 0;

    FOR rec IN ( SELECT * FROM XX_TCG_ARCHIVO_ENTREGADORES ) LOOP
      insertLines (rec, x_error_msg);

      IF x_error_msg IS NOT NULL THEN
        RAISE e_MyExit;
      END IF;

      --myDebug(chr(10),1);

      l_row_count := l_row_count + 1;
    END LOOP;

    insertHeader(l_row_count, p_nombre_archivo, p_fuente, x_error_msg);

    IF x_error_msg IS NOT NULL THEN
      RAISE e_MyExit;
    END IF;

    updateHeader(x_error_msg, l_total_ou);

    IF x_error_msg IS NOT NULL THEN
      RAISE e_MyExit;
    END IF;

    x_batch_id := g_batch_id;

    myDebug('Se importaron '||l_row_count||' registros para la unidad operativa '||p_operating_unit||'. Se creó el batch '||g_batch_id||'.'||chr(10)
          ||'----------------------------------------------------------'
           , 1);

    DELETE XX_TCG_ARCHIVO_ENTREGADORES;

    COMMIT;
  --
  EXCEPTION
    WHEN e_NoFile THEN
      x_error_msg := 'No fue posible abrir el archivo: '||p_nombre_archivo||' en el directorio: '||p_directorio||'.';
      myDebug(x_error_msg,1);
    WHEN e_EmptyFile THEN
      x_error_msg := 'El archivo: '||p_nombre_archivo||' en el directorio: '||p_directorio||' se encuentra vacio.';
      myDebug(x_error_msg,1);
    WHEN e_NoRecords THEN
      x_error_msg := 'El archivo: '||p_nombre_archivo||' no cuenta con registros para la compañia actual.';
      myDebug(x_error_msg,1);
    WHEN e_MyExit THEN
      UTL_FILE.FClose(l_in);
      x_batch_id := NULL;
      myDebug(x_error_msg,1);
      ROLLBACK;
  END Cargar_CP;


  PROCEDURE setDebugON ( p_active BOOLEAN ) IS
  BEGIN
    gLog := p_active;
  END;



  PROCEDURE setDebugLevel ( p_level NUMBER ) IS
  BEGIN
    /* Level 1: Básico
      Level 2: Detalle
      Level 3: Detalle + entregador
    */
    gLogLevel := p_level;
  END;


END;
/

exit
