  set define off;

  CREATE OR REPLACE EDITIONABLE PACKAGE "APPS"."XX_TCG_REPORTES_PKG" AS

  FUNCTION Obtiene_tipo_cliente (p_empresa in number,
                                          p_titular_cp_cuit in number,
                                          p_INTERMEDIARIO_CUIT in number,
                                          p_RTTE_COMERCIAL_CUIT in number,
                                          p_DESTINATARIO_CUIT in number,
                                          p_RTTE_COMERCIAL_RETIRO in varchar2,
                                          p_INTERMEDIARIO_RETIRO in varchar2)
                                          RETURN VARCHAR2;


  FUNCTION Get_Item_Desc ( p_item_id NUMBER ) RETURN VARCHAR2;


  FUNCTION Get_Party_Name ( p_party_id NUMBER ) RETURN VARCHAR2 ;


  PROCEDURE Listado_CP_PV ( p_errbuf      IN OUT NOCOPY VARCHAR2
                          , p_errcode     IN OUT NOCOPY VARCHAR2
                          , p_empresa                   NUMBER
                          , p_cliente                   NUMBER
                          , p_pedido_venta              VARCHAR2
                          , p_fecha_envio_desde         VARCHAR2
                          , p_fecha_envio_hasta         VARCHAR2
                          , p_fecha_recep_desde         VARCHAR2
                          , p_fecha_recep_hasta         VARCHAR2
                          , p_especie_oncca             VARCHAR2
                          , p_codigo_oncca              VARCHAR2
                          , p_producto                  VARCHAR2
                          , p_campana                   VARCHAR2
                          , p_cmv                       VARCHAR2
                          ); --CR1181


  PROCEDURE Listado_Tickets_Balanza ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                    , p_errcode     IN OUT NOCOPY VARCHAR2
                                    , p_emisor                    NUMBER
                                    , p_establecimiento           NUMBER
                                    , p_cliente                   NUMBER
                                    , p_fecha_desde               VARCHAR2
                                    , p_fecha_hasta               VARCHAR2
                                    , p_codigo_oncca              VARCHAR2
                                    , p_tipo                      VARCHAR2
                                    ); --CR1191


  PROCEDURE Listado_Boletines_Calidad ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                      , p_errcode     IN OUT NOCOPY VARCHAR2
                                      , p_uo                        NUMBER
                                      , p_empresa_origen            NUMBER
                                      , p_estab_origen              NUMBER
                                      , p_provincia_origen          VARCHAR2
                                      , p_localidad_origen          VARCHAR2
                                      , p_empresa_destino           NUMBER
                                      , p_estab_destino             NUMBER
                                      , p_provincia_destino         VARCHAR2
                                      , p_localidad_destino         VARCHAR2
                                      , p_numero_boletin            VARCHAR2
                                      , p_fecha_desde               VARCHAR2
                                      , p_fecha_hasta               VARCHAR2
                                      , p_especie_oncca             VARCHAR2
                                      , p_codigo_oncca              VARCHAR2
                                      , p_producto                  VARCHAR2
                                      , p_campana                   VARCHAR2
                                      , p_mostrar_cp                VARCHAR2
                                      );


  PROCEDURE Actualiza_Cert_ACO ( p_errbuf      IN OUT NOCOPY VARCHAR2
                               , p_errcode     IN OUT NOCOPY VARCHAR2
                               --
                               , p_contrato_compra      IN NUMBER
                               , p_carta_porte          IN NUMBER
                               , p_certificado          IN NUMBER
                               , p_destino_empresa      IN NUMBER
                               , p_destino_empresa_enbl IN VARCHAR2
                               , p_establecimiento      IN NUMBER
                               , p_localidad_destino    IN VARCHAR2
                               , p_organizacion         IN NUMBER
                               , p_subinventario        IN VARCHAR2
                               , p_localizador          IN NUMBER
                               );


  PROCEDURE Gasto_Acondicionamiento ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                    , p_errcode     IN OUT NOCOPY VARCHAR2
                                    , p_uo                        NUMBER
                                    , p_empresa_origen            NUMBER
                                    , p_estab_origen              NUMBER
                                    , p_empresa_destino           NUMBER
                                    , p_estab_destino             NUMBER
                                    , p_fecha_recep_desde         VARCHAR2
                                    , p_fecha_recep_hasta         VARCHAR2
                                    , p_especie_oncca             VARCHAR2
                                    );


  PROCEDURE Imprime_Turno ( p_errbuf      IN OUT NOCOPY VARCHAR2
                          , p_errcode     IN OUT NOCOPY VARCHAR2
                          , p_carta_porte_id            NUMBER
                          );


  PROCEDURE Lista_Cupos ( p_errbuf         IN OUT NOCOPY VARCHAR2
                        , p_errcode        IN OUT NOCOPY VARCHAR2
                        , p_fentrega_desde IN VARCHAR2
                        , p_fentrega_hasta IN VARCHAR2
                        , p_grano          IN VARCHAR2
                        , p_cupo_dueno     IN NUMBER
                        );

  PROCEDURE Lista_Orden_Carga ( p_errbuf           IN OUT NOCOPY VARCHAR2
                              , p_errcode          IN OUT NOCOPY VARCHAR2
                              , p_orden_carga      IN NUMBER
                              , p_empresa          IN VARCHAR2
                              , p_establecimiento  IN NUMBER
                              , p_fcarga_desde     IN VARCHAR2
                              , p_fcarga_hasta     IN VARCHAR2
                              );

  PROCEDURE Lista_Demanda_Camiones ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                   , p_errcode        IN OUT NOCOPY VARCHAR2
                                   , p_empresa        IN NUMBER
                                   , p_estab_id       IN NUMBER
                                   , p_fcarga_desde   IN VARCHAR2
                                   , p_fcarga_hasta   IN VARCHAR2
                                   );


  PROCEDURE QR_Interme_Incompatible ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                    , p_errcode        IN OUT NOCOPY VARCHAR2
                                    , p_adm_vendor_id  IN NUMBER
                                    );


  PROCEDURE Lista_CP_Sin_OCarga ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                , p_errcode        IN OUT NOCOPY VARCHAR2
                                , p_fcarga_desde   IN VARCHAR2
                                , p_fcarga_hasta   IN VARCHAR2
                                );


  PROCEDURE Lista_CP_Interv_Modif_OC ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                     , p_errcode        IN OUT NOCOPY VARCHAR2
                                     , p_fcarga_desde   IN VARCHAR2
                                     , p_fcarga_hasta   IN VARCHAR2
                                     );


  PROCEDURE Lista_CP_Trans_Prov_OC ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                   , p_errcode        IN OUT NOCOPY VARCHAR2
                                   , p_fcarga_desde   IN VARCHAR2
                                   , p_fcarga_hasta   IN VARCHAR2
                                   );


  PROCEDURE Lista_Interface_CP ( p_errbuf         IN OUT NOCOPY VARCHAR2
                               , p_errcode        IN OUT NOCOPY VARCHAR2
                               , p_fcarga_desde   IN VARCHAR2
                               , p_fcarga_hasta   IN VARCHAR2
                               , p_importado      IN VARCHAR2
                               , p_modifpostimp   IN VARCHAR2
                               );

END;
/


  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "APPS"."XX_TCG_REPORTES_PKG" AS
  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);

  FUNCTION xml_escape_chars ( p_data VARCHAR2 ) RETURN VARCHAR IS
    l_data VARCHAR2(32767);
  BEGIN
    l_data := REPLACE(REPLACE(REPLACE(p_data, '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
    RETURN l_data;
  END xml_escape_chars;


  FUNCTION Get_Party_Name ( p_party_id NUMBER ) RETURN VARCHAR2 IS
  BEGIN
    g_param_desc := NULL;

    SELECT party_name
    INTO g_param_desc
    FROM hz_parties
    WHERE party_id = p_party_id;

    RETURN g_param_desc;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_Party_Name;


  FUNCTION Get_Item_Desc ( p_item_id NUMBER ) RETURN VARCHAR2 IS
  BEGIN
    g_param_desc := NULL;

    SELECT segment1||' - '||description
    INTO g_param_desc
    FROM mtl_system_items
    WHERE inventory_item_id = p_item_id
    AND organization_id     = XX_TCG_FUNCTIONS_PKG.GetMasterOrg;

    RETURN g_param_desc;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_Item_Desc;


  FUNCTION Get_YesNo ( p_code VARCHAR2 ) RETURN VARCHAR2 IS
  BEGIN
    g_param_desc := NULL;

    SELECT meaning
    INTO g_param_desc
    FROM fnd_lookup_values_vl
    WHERE lookup_type = 'YES_NO'
    AND view_application_id = 0
    AND lookup_code = p_code;

    RETURN g_param_desc;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_YesNo;


  FUNCTION Get_Provincia ( p_provincia_code VARCHAR2 ) RETURN VARCHAR2 IS
  BEGIN

    SELECT province_name
    INTO g_param_desc
    FROM jl_ar_ap_provinces
    WHERE province_code = p_provincia_code;

    RETURN g_param_desc;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_Provincia;


  FUNCTION Get_Localidad ( p_localidad_code VARCHAR2 ) RETURN VARCHAR2 IS
  BEGIN
    SELECT description
    INTO g_param_desc
    FROM fnd_lookup_values_vl
    WHERE 1=1
    AND lookup_type = 'XX_ACO_LOCALIDADES_ONCCA'
    AND lookup_code = p_localidad_code;

    RETURN g_param_desc;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_Localidad;

  FUNCTION Obtiene_tipo_cliente ( p_empresa in number,
                                  p_titular_cp_cuit in number,
                                  p_INTERMEDIARIO_CUIT in number,
                                  p_RTTE_COMERCIAL_CUIT in number,
                                  p_DESTINATARIO_CUIT in number,
                                  p_RTTE_COMERCIAL_RETIRO in varchar2,
                                  p_INTERMEDIARIO_RETIRO in varchar2)
                                  RETURN varchar2 IS



    l_cuit_empresa  NUMBER :=XX_TCG_FUNCTIONS_PKG.Operating_Unit_CUIT(p_empresa );
    l_tipo          varchar2(5);

  begin

     case
       when l_cuit_empresa=  P_titular_cp_cuit then
                IF  P_INTERMEDIARIO_CUIT IS NULL and
                     P_RTTE_COMERCIAL_CUIT is not null and
                     l_cuit_empresa <> P_RTTE_COMERCIAL_CUIT then
                                              IF NVL(p_RTTE_COMERCIAL_RETIRO,'N') = 'N' then
                                                  l_tipo := 'RTTE';
                                              else
                                                  l_tipo := 'NA';
                                              end if;
                 ELSIF P_INTERMEDIARIO_CUIT is not null and
                          l_cuit_empresa <> P_INTERMEDIARIO_CUIT then
                                     IF NVL(P_INTERMEDIARIO_RETIRO,'N') = 'N' then
                                        l_tipo := 'INTE';
                                      else
                                         l_tipo := 'NA';
                                     end if;
                 ELSIF  P_DESTINATARIO_CUIT is not null and
                            l_cuit_empresa <> P_DESTINATARIO_CUIT THEN
                            l_tipo := 'DEST';
                 ELSIF  P_INTERMEDIARIO_CUIT IS NULL and
                           P_RTTE_COMERCIAL_CUIT is  not null and
                           P_RTTE_COMERCIAL_CUIT =   l_cuit_empresa and
                           P_DESTINATARIO_CUIT is not null and
                           l_cuit_empresa <> P_DESTINATARIO_CUIT then
                                l_tipo := 'DEST';
                  ELSE
                                     l_tipo := 'NA';
                   END IF;
     WHEN P_INTERMEDIARIO_CUIT is not null and
              l_cuit_empresa =  P_INTERMEDIARIO_CUIT then
                IF  P_RTTE_COMERCIAL_CUIT IS NOT NULL AND
                    l_cuit_empresa<> P_RTTE_COMERCIAL_CUIT then
                         l_tipo := 'RTTE';
              ELSIF P_RTTE_COMERCIAL_CUIT IS NOT NULL AND
                     l_cuit_empresa =  P_RTTE_COMERCIAL_CUIT AND
                      P_DESTINATARIO_CUIT is not null and
                      l_cuit_empresa <> P_DESTINATARIO_CUIT THEN
                        l_tipo := 'DEST';
              ELSE
                      l_tipo := 'NA';
              end if;
     WHEN P_RTTE_COMERCIAL_CUIT IS NOT NULL AND
              l_cuit_empresa =  P_RTTE_COMERCIAL_CUIT AND
              P_DESTINATARIO_CUIT is not null and
              l_cuit_empresa<> P_DESTINATARIO_CUIT THEN
               l_tipo := 'DEST';
      ELSE
            l_tipo := 'NA';
      END CASE;

    return l_tipo;
  END;


  PROCEDURE Listado_CP_PV ( p_errbuf      IN OUT NOCOPY VARCHAR2
                          , p_errcode     IN OUT NOCOPY VARCHAR2
                          , p_empresa                   NUMBER
                          , p_cliente                   NUMBER
                          , p_pedido_venta              VARCHAR2
                          , p_fecha_envio_desde         VARCHAR2
                          , p_fecha_envio_hasta         VARCHAR2
                          , p_fecha_recep_desde         VARCHAR2
                          , p_fecha_recep_hasta         VARCHAR2
                          , p_especie_oncca             VARCHAR2
                          , p_codigo_oncca              VARCHAR2
                          , p_producto                  VARCHAR2
                          , p_campana                   VARCHAR2
                          , p_cmv                       VARCHAR2
                          ) IS

    CURSOR c1 IS

      SELECT cp.numero_carta_porte
           , lv_dfv.xx_aco_especies_oncca item_oncca_especie
           , lv.description               item_tipo_grano
           , si_dfv.xx_aco_codigo_oncca   item_oncca_code
           , si.segment1                  item_no
           , si.description               item_desc
           , cp.lot_no
           , cp.titular_cp
           , cp.titular_cp_cuit
           , cp.intermediario
           , cp.intermediario_cuit
           , cp.rtte_comercial
           , cp.rtte_comercial_cuit
           , cp.destinatario
           , cp.destinatario_cuit
           , cp.destino
           , cp.destino_cuit
           , cp.fecha_envio
           , cp.fecha_recepcion
           , XX_TCG_CALIDAD_PKG.Get_Peso_Aplicado(cp.carta_porte_id) peso_aplicado
           , oh.order_number
           , apv.asociado_flag aplicado
           , apv.peso_asociado peso_cmv
      FROM xx_tcg_asocia_pedido_venta apv
         , xx_tcg_cartas_porte_all    cp
         , oe_order_headers_all       oh
         , mtl_system_items           si
         , mtl_system_items_b_dfv     si_dfv
         , fnd_lookup_values_vl       lv
         , fnd_lookup_values_dfv      lv_dfv
      WHERE 1=1
      AND cp.carta_porte_id = apv.carta_porte_id
      AND oh.header_id      = apv.oe_order_header_id
      AND si.inventory_item_id = cp.item_id
      AND si.organization_id   = XX_TCG_FUNCTIONS_PKG.GetMasterOrg
      AND si_dfv.row_id     = si.rowid
      AND lv.lookup_code    = si_dfv.xx_aco_codigo_oncca
      AND lv.lookup_type    = 'XX_ACO_ESPECIES_ONCCA'
      AND lv_dfv.row_id     = lv.row_id
      AND lv_dfv.context    = lv.attribute_category
      --PARAMS--
      AND ( p_empresa IS NULL OR
            XX_TCG_FUNCTIONS_PKG.CUIT_Party_ID( XX_TCG_FUNCTIONS_PKG.Operating_Unit_CUIT( p_empresa )) = apv.party_id_empresa
          )
      AND ( p_cliente IS NULL OR
            p_cliente = apv.party_id_cliente
          )
      AND ( p_pedido_venta IS NULL OR
            p_pedido_venta = apv.oe_order_header_id
          )
      AND ( p_fecha_envio_desde IS NULL OR
            TRUNC(cp.fecha_envio) >= TRUNC(TO_DATE(p_fecha_envio_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_envio_hasta IS NULL OR
            TRUNC(cp.fecha_envio) <= TRUNC(TO_DATE(p_fecha_envio_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_recep_desde IS NULL OR
            TRUNC(cp.fecha_recepcion) >= TRUNC(TO_DATE(p_fecha_recep_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_recep_hasta IS NULL OR
            TRUNC(cp.fecha_recepcion) <= TRUNC(TO_DATE(p_fecha_recep_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_especie_oncca IS NULL OR
            p_especie_oncca = lv_dfv.xx_aco_especies_oncca
          )
      AND ( p_codigo_oncca IS NULL OR
            p_codigo_oncca = si_dfv.xx_aco_codigo_oncca
          )
      AND ( p_producto IS NULL OR
            p_producto = cp.item_id
          )
      AND ( p_campana IS NULL OR
            p_campana = cp.lot_no
          )
      AND ( p_cmv IS NULL OR
            p_cmv = apv.asociado_flag
          )
      ;

    l_pedido_venta  VARCHAR2(15);
  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '-------------------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Carta Portes Asociadas a Pedido Venta');
    FND_FILE.Put_Line(FND_FILE.Log, '-------------------------------------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa: '||p_empresa);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_cliente: '||p_cliente);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_pedido_venta: '||p_pedido_venta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_envio_desde: '||p_fecha_envio_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_envio_hasta: '||p_fecha_envio_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_recep_desde: '||p_fecha_recep_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_recep_hasta: '||p_fecha_recep_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_especie_oncca: '||p_especie_oncca);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_codigo_oncca: '||p_codigo_oncca);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_producto: '||p_producto);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_campana: '||p_campana);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_cmv: '||p_cmv);

    --Significado Params--
    BEGIN
      SELECT order_number
      INTO l_pedido_venta
      FROM oe_order_headers_all
      WHERE header_id = p_pedido_venta;
    EXCEPTION
      WHEN OTHERS THEN
        l_pedido_venta := 'No Especificado';
    END;

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXTCGLISTCPPV>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX TCG Listado de Carta Portes Asociadas a Pedido Venta</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>Fecha Emisión|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <PARAMS>Parámetros</PARAMS>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA>Empresa|'||NVL(XX_TCG_FUNCTIONS_PKG.OU_Party_Name(p_empresa), 'No Especificado')||'</P_EMPRESA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CLIENTE>Cliente|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Party_Name(p_cliente))), 'No Especificado')||'</P_CLIENTE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PEDIDO_VENTA>Pedido Venta|'||l_pedido_venta||'</P_PEDIDO_VENTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_ENVIO_DESDE>Fecha Envío Desde|'||NVL(SUBSTR(p_fecha_envio_desde,1,10), 'No Especificado')||'</P_FECHA_ENVIO_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_ENVIO_HASTA>Fecha Envío Hasta|'||NVL(SUBSTR(p_fecha_envio_hasta,1,10), 'No Especificado')||'</P_FECHA_ENVIO_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_RECEP_DESDE>Fecha Recep Desde|'||NVL(SUBSTR(p_fecha_recep_desde,1,10), 'No Especificado')||'</P_FECHA_RECEP_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_RECEP_HASTA>Fecha Recep Hasta|'||NVL(SUBSTR(p_fecha_recep_hasta,1,10), 'No Especificado')||'</P_FECHA_RECEP_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESPECIE_ONCCA>Especie ONNCA|'||NVL(p_especie_oncca, 'No Especificado')||'</P_ESPECIE_ONCCA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CODIGO_ONCCA>Código ONNCA|'||NVL(p_codigo_oncca, 'No Especificado')||'</P_CODIGO_ONCCA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PRODUCTO>Producto|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Item_Desc(p_producto))), 'No Especificado')||'</P_PRODUCTO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CAMPANA>Campaña|'||NVL(p_campana, 'No Especificado')||'</P_CAMPANA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CMV>Tipo Ticket|'||NVL(Get_YesNo(p_cmv), 'No Especificado')||'</P_CMV>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <TITULOS>Número Carta Porte|Especie|Código ONCCA|Producto|Producto Desc|Campaña|Titular|Titular CUIT|Intermediario|Intermediario CUIT|Rtte Comercial|Rtte Comercial CUIT|Destinatario|Destinatario CUIT|Destino|Destino CUIT|Fecha Envío|Fecha Recepción|Peso Aplicado|Pedido de Venta|Aplicado|Peso CMV</TITULOS>');
    FOR r1 IN c1 LOOP
      g_data := r1.numero_carta_porte||'|'
              ||r1.item_oncca_especie||'|'
              ||r1.item_tipo_grano||'|'
              ||r1.item_no||'|'
              ||r1.item_desc||'|'
              ||r1.lot_no||'|'
              ||r1.titular_cp||'|'
              ||r1.titular_cp_cuit||'|'
              ||r1.intermediario||'|'
              ||r1.intermediario_cuit||'|'
              ||r1.rtte_comercial||'|'
              ||r1.rtte_comercial_cuit||'|'
              ||r1.destinatario||'|'
              ||r1.destinatario_cuit||'|'
              ||r1.destino||'|'
              ||r1.destino_cuit||'|'
              ||r1.fecha_envio||'|'
              ||r1.fecha_recepcion||'|'
              ||r1.peso_aplicado||'|'
              ||r1.order_number||'|'
              ||r1.aplicado||'|'
              ||r1.peso_cmv||'|'
              ;
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DATA>'||xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(g_data))||'</DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXTCGLISTCPPV>');

  END Listado_CP_PV;



  PROCEDURE Listado_Tickets_Balanza ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                    , p_errcode     IN OUT NOCOPY VARCHAR2
                                    , p_emisor                    NUMBER
                                    , p_establecimiento           NUMBER
                                    , p_cliente                   NUMBER
                                    , p_fecha_desde               VARCHAR2
                                    , p_fecha_hasta               VARCHAR2
                                    , p_codigo_oncca              VARCHAR2
                                    , p_tipo                      VARCHAR2
                                    ) IS

    CURSOR c1 IS

      SELECT DISTINCT
             tb.operating_unit
           , (SELECT grupo_control FROM xx_tcg_parametros_compania WHERE operating_unit = tb.operating_unit) grupo_control
           , tb.ticket_id
           , tb.ticket_numero
           , DECODE(tb.cancelado_flag, 'N', 'No', 'Y', 'Si') cancelado
           , DECODE(tb.asignado_flag, 'N', 'No', 'Y', 'Si') asignado
           , tb.tipo_ticket
           , TO_CHAR(tb.fecha, 'DD-MM-YYYY HH24:MI:SS')    fecha
           , (SELECT campo FROM xx_opm_establecimientos WHERE establecimiento_id = tb.establecimiento_id) establecimiento
           , (SELECT party_name FROM hz_parties WHERE party_id = tb.emisor) emisor
           , (SELECT numero_carta_porte FROM xx_tcg_cartas_porte WHERE carta_porte_id = tb.carta_porte_id) numero_carta_porte
           , tb.remito
           , tb.item_id
           , itm_dfv.xx_aco_codigo_oncca item_oncca_code
           , itm.segment1      item_no
           , itm.description   item_desc
           , tb.lot_no
           , tb.observaciones
           --Origen
           , (SELECT party_name FROM hz_parties WHERE party_id = tb.origen_id) origen
           , suc_origen.address1   sucursal_origen
           , estab_origen.campo    establecimiento_origen
           , (SELECT secondary_inventory_name||' - '||description FROM mtl_secondary_inventories WHERE attribute3 = tb.origen_estab_id AND secondary_inventory_name = tb.origen_subinventario) subinv_origen
           , (SELECT segment1||' - '||description FROM mtl_item_locations WHERE inventory_location_id = tb.origen_localizador_id) localizador_origen
           , tb.lote
           , NVL(suc_origen.concatenated_address, estab_origen.direccion) direccion_origen
           , TO_CHAR(tb.fecha_envio, 'DD-MM-YYYY')    fecha_envio
           --Destino
           , tb.destino_id
           , tb.destino_estab_id
           , (SELECT party_name FROM hz_parties WHERE party_id = tb.destino_id) destino
           , suc_destino.address1   sucursal_destino
           , estab_destino.campo    establecimiento_destino
           , (SELECT secondary_inventory_name||' - '||description FROM mtl_secondary_inventories WHERE attribute3 = tb.destino_estab_id AND secondary_inventory_name = tb.destino_subinventario) subinv_destino
           , (SELECT segment1||' - '||description FROM mtl_item_locations WHERE inventory_location_id = tb.destino_localizador_id) localizador_destino
           , NVL(suc_destino.concatenated_address, estab_destino.direccion) direccion_destino
           --Transporte
           , cs.metodo_envio
           , cs.transportista
           , cs.transportista_nombre
           , cs.transportista_cuit
           , cs.conductor
           , cs.conductor_cuit
           , cs.patente_camion
           , cs.patente_acoplado
           , tb.ata_cuit
           , tb.contenedor_numero
           --Pesaje
           , (SELECT balance_name FROM xx_oe_balances WHERE balance_id = tb.balanza_tara_id) balanza_tara
           , tb.tara
           , user_det.tara_detalle
           , tb.tara_justif
           , (SELECT balance_name FROM xx_oe_balances WHERE balance_id = tb.balanza_peso_bruto_id) balanza_peso_bruto
           , tb.peso_bruto
           , user_det.peso_bruto_detalle
           , tb.peso_bruto_justif
           --Calidad
           , tb.porcentaje_humedad
           , tb.porcentaje_merma_humedad
           , tb.porcentaje_zaranda
           , tb.porcentaje_volatil
      FROM xx_tcg_tickets_balanza tb
         , mtl_system_items       itm
         , mtl_system_items_b_dfv itm_dfv
         , (SELECT est.establecimiento_id, est.campo
                 , l.address_line_1||' '||l.address_line_2||' '||l.address_line_3||', '||lv_prov.description||', '||lv_loc.description||', '||l.postal_code direccion
            FROM xx_opm_establecimientos est
               , hr_locations            l
               , fnd_lookup_values_vl    lv_prov
               , fnd_lookup_values_vl    lv_loc
            WHERE 1=1
            AND l.location_id       = est.location_id
            AND lv_prov.lookup_code = l.region_2
            AND lv_loc.lookup_code  = l.loc_information16
            AND lv_loc.lookup_type  = 'XX_ACO_LOCALIDADES_ONCCA'
            AND lv_prov.lookup_type = 'JLZZ_STATE_PROVINCE'
           ) estab_origen
         , (SELECT est.establecimiento_id, est.campo
                 , l.address_line_1||' '||l.address_line_2||' '||l.address_line_3||', '||lv_prov.description||', '||lv_loc.description||', '||l.postal_code direccion
            FROM xx_opm_establecimientos est
               , hr_locations            l
               , fnd_lookup_values_vl    lv_prov
               , fnd_lookup_values_vl    lv_loc
            WHERE 1=1
            AND l.location_id       = est.location_id
            AND lv_prov.lookup_code = l.region_2
            AND lv_loc.lookup_code  = l.loc_information16
            AND lv_loc.lookup_type  = 'XX_ACO_LOCALIDADES_ONCCA'
            AND lv_prov.lookup_type = 'JLZZ_STATE_PROVINCE'
           ) estab_destino
         , (SELECT ps.party_site_id, l.address1
                 , arh_addr_pkg.format_address( l.address_style
                                              , l.address1, l.address2, l.address3, l.address4
                                              , l.city
                                              , l.county
                                              , l.state
                                              , l.province
                                              , l.postal_code
                                              , null) concatenated_address
            FROM hz_party_sites  ps
               , hz_locations    l
            WHERE 1=1
            AND l.location_id = ps.location_id
           )  suc_origen
         , (SELECT ps.party_site_id, l.address1
                 , arh_addr_pkg.format_address( l.address_style
                                              , l.address1, l.address2, l.address3, l.address4
                                              , l.city
                                              , l.county
                                              , l.state
                                              , l.province
                                              , l.postal_code
                                              , null) concatenated_address
            FROM hz_party_sites  ps
               , hz_locations    l
            WHERE 1=1
            AND l.location_id = ps.location_id
           )  suc_destino
         , (SELECT wcs.carrier_service_id
                 , wcs.ship_method_meaning      metodo_envio
                 , wcsd.xx_wsh_patente_camion   patente_camion
                 , wcsd.xx_wsh_patente_acoplado patente_acoplado
                 , NVL(qpv.empleado_nombre, wcsd.xx_wsh_nombre_conductor) conductor
                 , wcsd.xx_wsh_cuil_conductor   conductor_cuit
                 , NULL                         responsable_fc
                 , NULL                         cuil_ferrocarril
                 , s.segment1       transportista
                 , s.vendor_name    transportista_nombre
                 , s.num_1099 || s.global_attribute12 transportista_cuit
            FROM wsh_carrier_services_v      wcs
               , wsh_carrier_services_dfv    wcsd
               , xx_opm_qr_proveedores_cp_v  qpv
               , ap_suppliers                s
            WHERE 1=1
            AND wcsd.row_id = wcs.row_id
            AND qpv.carrier_service_id = wcs.carrier_service_id
            AND s.vendor_id(+) = TO_NUMBER(wcsd.xx_aco_proveedor)
           )   cs
         , (SELECT xtb.ticket_id
                 , DECODE( xtb.tara
                         , NULL, NULL
                         , DECODE( xtb.tara_aut_flag
                                 , 'Y', 'A - '||user_tara.user_name||' - '||TO_CHAR(xtb.tara_fecha, 'DD-MM-YYYY HH24:MI:SS')
                                 , 'M - '||user_tara.user_name||' - '||TO_CHAR(xtb.tara_fecha, 'DD-MM-YYYY HH24:MI:SS')
                                 )
                         ) tara_detalle
                 , DECODE( xtb.peso_bruto
                         , NULL, NULL
                         , DECODE( xtb.peso_bruto_aut_flag
                                 , 'Y', 'A - '||user_bruto.user_name||' - '||TO_CHAR(xtb.peso_bruto_fecha, 'DD-MM-YYYY HH24:MI:SS')
                                 , 'M - '||user_bruto.user_name||' - '||TO_CHAR(xtb.peso_bruto_fecha, 'DD-MM-YYYY HH24:MI:SS')
                                 )
                         ) peso_bruto_detalle
            FROM xx_tcg_tickets_balanza xtb
               , ( SELECT DECODE(fu.user_name, NULL, ppf.full_name, fu.user_name) user_name, user_id
                   FROM fnd_user fu, per_people_f ppf
                   WHERE ppf.party_id(+) = fu.user_id ) user_tara
               , ( SELECT DECODE(fu.user_name, NULL, ppf.full_name, fu.user_name) user_name, user_id
                   FROM fnd_user fu, per_people_f ppf
                   WHERE ppf.party_id(+) = fu.user_id ) user_bruto
            WHERE 1=1
            AND user_tara.user_id(+)  = xtb.tara_user_id
            AND user_bruto.user_id(+) = xtb.peso_bruto_user_id
           ) user_det
      WHERE 1=1
      AND itm.inventory_item_id(+) = tb.item_id
      AND itm.organization_id(+)   = XX_TCG_FUNCTIONS_PKG.GetMasterOrg
      AND itm_dfv.row_id(+)        = itm.rowid
      AND estab_origen.establecimiento_id(+)  = tb.origen_estab_id
      AND estab_destino.establecimiento_id(+) = tb.destino_estab_id
      AND suc_origen.party_site_id(+)  = tb.origen_sucursal_id
      AND suc_destino.party_site_id(+) = tb.destino_sucursal_id
      AND cs.carrier_service_id(+)     = tb.carrier_service_id
      AND user_det.ticket_id       = tb.ticket_id
      --PARAMS--
      AND ( p_emisor IS NULL OR
            p_emisor = tb.emisor
          )
      AND ( p_establecimiento IS NULL OR
            p_establecimiento = tb.establecimiento_id
          )
      AND ( p_cliente IS NULL OR
            p_cliente = tb.destino_id
          )
      AND ( p_fecha_desde IS NULL OR
            TRUNC(tb.fecha) >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(tb.fecha) <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_codigo_oncca IS NULL OR
            p_codigo_oncca = itm_dfv.xx_aco_codigo_oncca
          )
      AND ( p_tipo IS NULL OR
            p_tipo = tb.tipo_ticket
          )
      ;

    l_dummy_num1       NUMBER;
    l_dummy_num2       NUMBER;
    l_dummy_num3       NUMBER;
    l_peso_humedad     NUMBER;
    l_peso_zaranda       NUMBER;
    l_peso_volatil          NUMBER;
    l_peso_neto            NUMBER;
    l_result                   BOOLEAN;
    l_error_msg            VARCHAR2(2000);

  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Tickets de Balanza');
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_emisor: '||p_emisor);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_establecimiento: '||p_establecimiento);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_cliente: '||p_cliente);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_desde: '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_hasta: '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_codigo_oncca: '||p_codigo_oncca);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_tipo: '||p_tipo);

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXTCGLISTTB>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX TCG Listado de Tickets de Balanza</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>Fecha Emisión|'||TO_CHAR(SYSDATE, 'dd-mm-yy HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <PARAMS>Parámetros</PARAMS>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMISOR>Emisor|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Party_Name(p_emisor))), 'No Especificado')||'</P_EMISOR>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESTABLECIMIENTO>Establecimiento|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(XX_TCG_FUNCTIONS_PKG.getEstabName(p_establecimiento))), 'No Especificado')||'</P_ESTABLECIMIENTO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CLIENTE>Cliente|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Party_Name(p_cliente))), 'No Especificado')||'</P_CLIENTE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>Fecha Desde|'||NVL(SUBSTR(p_fecha_desde,1,10), 'No Especificado')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_HASTA>Fecha Hasta|'||NVL(SUBSTR(p_fecha_hasta,1,10), 'No Especificado')||'</P_FECHA_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CODIGO_ONCCA>Código ONNCA|'||NVL(p_codigo_oncca, 'No Especificado')||'</P_CODIGO_ONCCA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_TIPO>Tipo Ticket|'||NVL(INITCAP(p_tipo), 'No Especificado')||'</P_TIPO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <TITULOS>TICKET NUMERO|CANCELADO|ASIGNADO|TIPO TICKET|FECHA|ESTABLECIMIENTO|EMISOR|NUMERO CARTA PORTE|REMITO|PRODUCTO|PRODUCTO DESC|CAMPAÑA|OBSERVACIONES|ORIGEN|SUCURSAL ORIGEN|ESTABLECIMIENTO ORIGEN|SUBINV ORIGEN|LOCALIZADOR ORIGEN|LOTE|DIRECCION ORIGEN|FECHA ENVIO|DESTINO|SUCURSAL DESTINO|ESTABLECIMIENTO DESTINO|SUBINV DESTINO|LOCALIZADOR DESTINO|DIRECCION DESTINO|METODO ENVIO|TRANSPORTISTA|TRANSPORTISTA NOMBRE|TRANSPORTISTA CUIT|CONDUCTOR|CONDUCTOR CUIT|PATENTE CAMION|PATENTE ACOPLADO|ATA CUIT|CONTENEDOR NUMERO|BALANZA TARA|TARA|TARA DETALLE|TARA JUSTIF|BALANZA PESO BRUTO|PESO BRUTO|PESO BRUTO DETALLE|PESO BRUTO JUSTIF|PESO NETO|PORCENTAJE HUMEDAD|PORCENTAJE MERMA HUMEDAD|PESO MERMA HUMEDAD|PORCENTAJE ZARANDA|PESO MERMA ZARANDA|PORCENTAJE VOLATIL|PESO MERMA VOLATIL|</TITULOS>');
    FOR r1 IN c1 LOOP
      --PORCENTAJE_HUMEDAD
      IF r1.tipo_ticket = 'ENTRADA' THEN
        XX_TCG_CALIDAD_PKG.Get_Peso_Merma_Humedad
                          ( p_peso               => (NVL(r1.peso_bruto,0) - NVL(r1.tara,0))
                          , p_porcentaje_humedad => r1.porcentaje_humedad
                          , p_item_oncca_code    => r1.item_oncca_code
                          , p_item_id            => r1.item_id
                          , p_party_id           => r1.destino_id
                          , p_party_site_id      => r1.destino_estab_id
                          , p_grupo_control      => r1.grupo_control
                          , x_merma_header_id    => l_dummy_num1
                          , x_porcentaje_merma   => l_dummy_num2
                          , x_peso               => l_dummy_num3
                          , x_result             => l_result
                          , x_errmsg             => l_error_msg
                        );

        IF l_result THEN
          l_peso_humedad := l_dummy_num3;
        END IF;

        --PORCENTAJE_ZARANDA
        l_peso_zaranda := XX_TCG_CALIDAD_PKG.Get_Peso_Merma_Zaranda
                                            ( p_peso_neto          => (NVL(r1.peso_bruto,0) - NVL(r1.tara,0))
                                            , p_item_oncca_code    => r1.item_oncca_code
                                            , p_merma_humedad      => l_peso_humedad
                                            , p_merma_volatil      => r1.porcentaje_volatil
                                            , p_porcentaje_zaranda => r1.porcentaje_zaranda
                                            , p_country            => 'AR'
                                            );

        --PORCENTAJE_VOLATIL
        l_peso_volatil := XX_TCG_CALIDAD_PKG.Get_Peso_Merma_Volatil
                                            ( p_peso_neto          => (NVL(r1.peso_bruto,0) - NVL(r1.tara,0))
                                            , p_item_oncca_code    => r1.item_oncca_code
                                            , p_merma_humedad      => l_peso_humedad
                                            , p_merma_zaranda      => l_peso_zaranda
                                            , p_porcentaje_volatil => r1.porcentaje_volatil
                                            , p_country            => 'AR'
                                            );

      END IF;

      l_peso_neto := NVL(r1.peso_bruto,0)-NVL(r1.tara,0);

      g_data := r1.ticket_numero||'|'
              ||r1.cancelado||'|'
              ||r1.asignado||'|'
              ||r1.tipo_ticket||'|'
              ||r1.fecha||'|'
              ||r1.establecimiento||'|'
              ||r1.emisor||'|'
              ||r1.numero_carta_porte||'|'
              ||r1.remito||'|'
              ||r1.item_no||'|'
              ||r1.item_desc||'|'
              ||r1.lot_no||'|'
              ||r1.observaciones||'|'
              ||r1.origen||'|'
              ||r1.sucursal_origen||'|'
              ||r1.establecimiento_origen||'|'
              ||r1.subinv_origen||'|'
              ||r1.localizador_origen||'|'
              ||r1.lote||'|'
              ||r1.direccion_origen||'|'
              ||r1.fecha_envio||'|'
              ||r1.destino||'|'
              ||r1.sucursal_destino||'|'
              ||r1.establecimiento_destino||'|'
              ||r1.subinv_destino||'|'
              ||r1.localizador_destino||'|'
              ||r1.direccion_destino||'|'
              ||r1.metodo_envio||'|'
              ||r1.transportista||'|'
              ||r1.transportista_nombre||'|'
              ||r1.transportista_cuit||'|'
              ||r1.conductor||'|'
              ||r1.conductor_cuit||'|'
              ||r1.patente_camion||'|'
              ||r1.patente_acoplado||'|'
              ||r1.ata_cuit||'|'
              ||r1.contenedor_numero||'|'
              ||r1.balanza_tara||'|'
              ||r1.tara||'|'
              ||r1.tara_detalle||'|'
              ||r1.tara_justif||'|'
              ||r1.balanza_peso_bruto||'|'
              ||r1.peso_bruto||'|'
              ||r1.peso_bruto_detalle||'|'
              ||r1.peso_bruto_justif||'|'
              ||l_peso_neto||'|'
              ||r1.porcentaje_humedad||'|'
              ||r1.porcentaje_merma_humedad||'|'
              ||l_peso_humedad||'|'
              ||r1.porcentaje_zaranda||'|'
              ||l_peso_zaranda||'|'
              ||r1.porcentaje_volatil||'|'
              ||l_peso_volatil||'|'
              ;
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DATA>'||xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(g_data))||'</DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXTCGLISTTB>');

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Listado_Tickets_Balanza;


  PROCEDURE Listado_Boletines_Calidad ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                      , p_errcode     IN OUT NOCOPY VARCHAR2
                                      , p_uo                        NUMBER
                                      , p_empresa_origen            NUMBER
                                      , p_estab_origen              NUMBER
                                      , p_provincia_origen          VARCHAR2
                                      , p_localidad_origen          VARCHAR2
                                      , p_empresa_destino           NUMBER
                                      , p_estab_destino             NUMBER
                                      , p_provincia_destino         VARCHAR2
                                      , p_localidad_destino         VARCHAR2
                                      , p_numero_boletin            VARCHAR2
                                      , p_fecha_desde               VARCHAR2
                                      , p_fecha_hasta               VARCHAR2
                                      , p_especie_oncca             VARCHAR2
                                      , p_codigo_oncca              VARCHAR2
                                      , p_producto                  VARCHAR2
                                      , p_campana                   VARCHAR2
                                      , p_mostrar_cp                VARCHAR2
                                      ) IS

    CURSOR c1 IS

      SELECT bh.boletin_header_id
           , bh.numero_boletin
           , INITCAP(bh.estado)       estado
           , TO_CHAR(bh.fecha_analisis, 'DD-MM-YYYY') fecha_analisis
           , INITCAP(bh.entidad_code) entidad
           , (SELECT description
              FROM fnd_lookup_values_vl
              WHERE 1=1
              AND lookup_type = 'XX_ACO_LABORATORIOS_ANALISIS'
              AND lookup_code = bh.entidad_code
             ) entidad_desc
           , bh.tabla_analisis_id
           , ta.codigo                    tabla_analisis_codigo
           , ta.descripcion               tabla_analisis_desc
           , item.segment1                item_no
           , item.description             item_desc
           , item_dfv.xx_aco_codigo_oncca item_oncca_code
           , bh.lot_number                campana
           , (SELECT numero_contrato
              FROM xx_tcg_contratos_compra
              WHERE contrato_id = bh.contrato_id
             ) numero_contrato
           , ( SELECT party_name
               FROM hz_parties
               WHERE party_id = bh.empresa_origen_party_id
             ) empresa_origen
           , bh.empresa_origen_cuit
           , CASE
               WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c( XX_TCG_FUNCTIONS_PKG.Obtener_CUIT (bh.empresa_origen_party_id)) = 'Y' THEN
                 ( SELECT campo FROM xx_opm_establecimientos WHERE establecimiento_id = bh.establecimiento_origen_id )
               ELSE
                 ( SELECT l.address1
                   FROM hz_party_sites  ps
                      , hz_locations    l
                   WHERE 1=1
                   AND l.location_id = ps.location_id
                   AND ps.party_site_id = bh.establecimiento_origen_id )
               END establecimiento_origen
           , bh.est_origen_oncca_code
           , ( SELECT pr_dpto_nombre
               FROM xx_tcg_localidades
               WHERE pais_codigo = 'AR'
               AND pr_dpto_codigo = bh.provincia_origen_code
               AND loc_codigo = bh.localidad_origen_code
             ) provincia_origen
           , ( SELECT loc_nombre
               FROM xx_tcg_localidades
               WHERE pais_codigo = 'AR'
               AND pr_dpto_codigo = bh.provincia_origen_code
               AND loc_codigo = bh.localidad_origen_code
             ) localidad_origen
           , ( SELECT party_name
               FROM hz_parties
               WHERE party_id = bh.empresa_destino_party_id
             ) empresa_destino
           , bh.empresa_destino_cuit
           , CASE
               WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c( XX_TCG_FUNCTIONS_PKG.Obtener_CUIT (bh.empresa_destino_party_id)) = 'Y' THEN
                 ( SELECT campo FROM xx_opm_establecimientos WHERE establecimiento_id = bh.establecimiento_destino_id )
               ELSE
                 ( SELECT l.address1
                   FROM hz_party_sites  ps
                      , hz_locations    l
                   WHERE 1=1
                   AND l.location_id = ps.location_id
                   AND ps.party_site_id = bh.establecimiento_destino_id )
               END establecimiento_destino
           , bh.est_destino_oncca_code
           , ( SELECT pr_dpto_nombre
               FROM xx_tcg_localidades
               WHERE pais_codigo = 'AR'
               AND pr_dpto_codigo = bh.provincia_destino_code
               AND loc_codigo = bh.localidad_destino_code
             ) provincia_destino
           , ( SELECT loc_nombre
               FROM xx_tcg_localidades
               WHERE pais_codigo = 'AR'
               AND pr_dpto_codigo = bh.provincia_destino_code
               AND loc_codigo = bh.localidad_destino_code
             ) localidad_destino
           , bh.factor
           , bh.grado_resultante       grado
           , cert.numero_liquidacion   numero_certif
           , TO_CHAR(cert.fecha_liquidacion, 'DD-MM-YYYY')    fecha_certif
      FROM org_organization_definitions od
         , xx_tcg_boletin_headers bh
         , xx_aco_tablas_analisis ta
         , mtl_system_items       item
         , mtl_system_items_b_dfv item_dfv
         , fnd_lookup_values_vl   lv
         , fnd_lookup_values_dfv  lv_dfv
         , xx_tcg_liquidaciones_1116a cert
      WHERE 1=1
      AND bh.organization_id      = od.organization_id
      AND ta.tabla_analisis_id(+) = bh.tabla_analisis_id
      AND item.inventory_item_id  = bh.inventory_item_id
      AND item.organization_id    = XX_TCG_FUNCTIONS_PKG.GetMasterOrg
      AND item_dfv.row_id         = item.rowid
      AND lv.lookup_code          = item_dfv.xx_aco_codigo_oncca
      AND lv.lookup_type          = 'XX_ACO_ESPECIES_ONCCA'
      AND lv_dfv.row_id           = lv.row_id
      AND lv_dfv.context          = lv.attribute_category
      AND cert.boletin_header_id(+) = bh.boletin_header_id
      AND XX_TCG_FUNCTIONS_PKG.Valida_Acceso_Org_c(FND_GLOBAL.User_ID, bh.organization_id) = 'Y'
      --Parametros--
      AND ( p_uo IS NULL OR
            p_uo = od.operating_unit
          )
      AND ( p_empresa_origen IS NULL OR
            p_empresa_origen = bh.empresa_origen_party_id
          )
      AND ( p_estab_origen IS NULL OR
            p_estab_origen = bh.establecimiento_origen_id
          )
      AND ( p_provincia_origen IS NULL OR
            p_provincia_origen = bh.provincia_origen_code
          )
      AND ( p_localidad_origen IS NULL OR
            p_localidad_origen = bh.localidad_origen_code
          )
      AND ( p_empresa_destino IS NULL OR
            p_empresa_destino = bh.empresa_destino_party_id
          )
      AND ( p_estab_destino IS NULL OR
            p_estab_destino = bh.establecimiento_destino_id
          )
      AND ( p_provincia_destino IS NULL OR
            p_provincia_destino = bh.provincia_destino_code
          )
      AND ( p_localidad_destino IS NULL OR
            p_localidad_destino = bh.localidad_destino_code
          )
      AND ( p_numero_boletin IS NULL OR
            p_numero_boletin = bh.boletin_header_id
          )
      AND ( p_fecha_desde IS NULL OR
            TRUNC(bh.fecha_analisis)  >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(bh.fecha_analisis)  <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_especie_oncca IS NULL OR
            p_especie_oncca = lv_dfv.xx_aco_especies_oncca
          )
      AND ( p_codigo_oncca IS NULL OR
            p_codigo_oncca = item_dfv.xx_aco_codigo_oncca
          )
      AND ( p_producto IS NULL OR
            p_producto = bh.inventory_item_id
          )
      AND ( p_campana IS NULL OR
            p_campana = bh.lot_number
          )
      ;

    CURSOR c2 IS

      SELECT DISTINCT
             bh.boletin_header_id
           , bh.tabla_analisis_id
           , cm.concepto_lookup_code concepto_calidad
           , flv.description         concepto_calidad_desc
           , vm.valor
           , vm.porcentaje_descuento
           , vm.porcentaje_bonificacion
      FROM org_organization_definitions od
         , xx_tcg_boletin_headers bh
         , xx_aco_tablas_analisis ta
         , mtl_system_items       item
         , mtl_system_items_b_dfv item_dfv
         , fnd_lookup_values_vl   lv
         , fnd_lookup_values_dfv  lv_dfv
         , xx_aco_ta_conceptos_muestra cm
         , xx_aco_valores_muestra vm
         , fnd_lookup_values_vl   flv
      WHERE 1=1
      AND bh.organization_id      = od.organization_id
      AND ta.tabla_analisis_id(+) = bh.tabla_analisis_id
      AND item.inventory_item_id  = bh.inventory_item_id
      AND item.organization_id    = XX_TCG_FUNCTIONS_PKG.GetMasterOrg
      AND item_dfv.row_id         = item.rowid
      AND lv.lookup_code          = item_dfv.xx_aco_codigo_oncca
      AND lv.lookup_type          = 'XX_ACO_ESPECIES_ONCCA'
      AND lv_dfv.row_id           = lv.row_id
      AND lv_dfv.context          = lv.attribute_category
      AND cm.tabla_analisis_id    = bh.tabla_analisis_id
      AND vm.boletin_header_id    = bh.boletin_header_id
      AND cm.concepto_lookup_code = vm.codigo_concepto
      AND cm.concepto_lookup_code = flv.lookup_code
      AND flv.lookup_type         = 'XX_ACO_CONCEPTOS_MUESTRA'
      AND XX_TCG_FUNCTIONS_PKG.Valida_Acceso_Org_c(FND_GLOBAL.User_ID, bh.organization_id) = 'Y'
      --Parametros--
      AND ( p_uo IS NULL OR
            p_uo = od.operating_unit
          )
      AND ( p_empresa_origen IS NULL OR
            p_empresa_origen = bh.empresa_origen_party_id
          )
      AND ( p_estab_origen IS NULL OR
            p_estab_origen = bh.establecimiento_origen_id
          )
      AND ( p_provincia_origen IS NULL OR
            p_provincia_origen = bh.provincia_origen_code
          )
      AND ( p_localidad_origen IS NULL OR
            p_localidad_origen = bh.localidad_origen_code
          )
      AND ( p_empresa_destino IS NULL OR
            p_empresa_destino = bh.empresa_destino_party_id
          )
      AND ( p_estab_destino IS NULL OR
            p_estab_destino = bh.establecimiento_destino_id
          )
      AND ( p_provincia_destino IS NULL OR
            p_provincia_destino = bh.provincia_destino_code
          )
      AND ( p_localidad_destino IS NULL OR
            p_localidad_destino = bh.localidad_destino_code
          )
      AND ( p_numero_boletin IS NULL OR
            p_numero_boletin = bh.boletin_header_id
          )
      AND ( p_fecha_desde IS NULL OR
            TRUNC(bh.fecha_analisis)  >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(bh.fecha_analisis)  <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_especie_oncca IS NULL OR
            p_especie_oncca = lv_dfv.xx_aco_especies_oncca
          )
      AND ( p_codigo_oncca IS NULL OR
            p_codigo_oncca = item_dfv.xx_aco_codigo_oncca
          )
      AND ( p_producto IS NULL OR
            p_producto = bh.inventory_item_id
          )
      AND ( p_campana IS NULL OR
            p_campana = bh.lot_number
          )
      ORDER BY cm.concepto_lookup_code
      ;

    CURSOR c3 ( p_request_id         NUMBER
              ) IS

      SELECT DISTINCT cc.codigo_concepto concepto_calidad
      FROM xx_aco_rep_calidad_tmp cc
         , fnd_lookup_values_vl   lv
      WHERE 1=1
      AND lv.lookup_code  = cc.codigo_concepto
      AND lv.lookup_type  = 'XX_ACO_CONCEPTOS_MUESTRA'
      AND ( p_request_id IS NULL OR
            p_request_id = cc.request_id
          )
      ORDER BY cc.codigo_concepto
      ;

    CURSOR c4 ( p_request_id         NUMBER
              , p_boletin_header_id  NUMBER
              , p_tabla_analisis_id  NUMBER
              ) IS

      SELECT cc.codigo_concepto concepto_calidad
           , lv.description     concepto_calidad_desc
           , cc.valor
           , cc.porcentaje_descuento
           , cc.porcentaje_bonificacion
      FROM xx_aco_rep_calidad_tmp cc
         , fnd_lookup_values_vl   lv
      WHERE 1=1
      AND lv.lookup_code  = cc.codigo_concepto
      AND lv.lookup_type  = 'XX_ACO_CONCEPTOS_MUESTRA'
      AND ( p_request_id IS NULL OR
            p_request_id = cc.request_id
          )
      AND ( p_boletin_header_id IS NULL OR
            p_boletin_header_id = cc.boletin_header_id
          )
      AND ( p_tabla_analisis_id IS NULL OR
            p_tabla_analisis_id = cc.tabla_analisis_id
          )
      ORDER BY cc.codigo_concepto
      ;

    CURSOR c5 IS

      SELECT bh.numero_boletin
           , TO_CHAR(bh.fecha_analisis,'DD/MM/YYYY') fecha_analisis
           , cp.numero_carta_porte
           , ( SELECT party_name
               FROM hz_parties
               WHERE party_id = bh.empresa_origen_party_id
             ) productor
           , CASE
               WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c( XX_TCG_FUNCTIONS_PKG.Obtener_CUIT (bh.empresa_origen_party_id)) = 'Y' THEN
                 ( SELECT campo FROM xx_opm_establecimientos WHERE establecimiento_id = bh.establecimiento_origen_id )
               ELSE
                 ( SELECT l.address1
                   FROM hz_party_sites  ps
                      , hz_locations    l
                   WHERE 1=1
                   AND l.location_id = ps.location_id
                   AND ps.party_site_id = bh.establecimiento_origen_id )
               END productor_sucursal
           , cp.lote
           , ( SELECT party_name
               FROM hz_parties
               WHERE party_id = bh.empresa_destino_party_id
             ) destino
           , CASE
               WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c( XX_TCG_FUNCTIONS_PKG.Obtener_CUIT (bh.empresa_destino_party_id)) = 'Y' THEN
                 ( SELECT campo FROM xx_opm_establecimientos WHERE establecimiento_id = bh.establecimiento_destino_id )
               ELSE
                 ( SELECT l.address1
                   FROM hz_party_sites  ps
                      , hz_locations    l
                   WHERE 1=1
                   AND l.location_id = ps.location_id
                   AND ps.party_site_id = bh.establecimiento_destino_id )
               END destino_sucursal
           , cp.pctaje_humedad_recep      pctaje_humedad
           , cp.peso_merma_humedad_recep  peso_humedad
           , cp.pctaje_volatil_recep      pctaje_volatil
           , cp.peso_merma_volatil_recep  peso_volatil
           , cp.pctaje_zaranda_recep      pctaje_zaranda
           , cp.peso_merma_zaranda_recep  peso_zaranda
           , cp.peso_aplicado_recep       peso_aplicado
      FROM org_organization_definitions od
         , xx_tcg_boletin_headers  bh
         , xx_tcg_boletin_lines    bl
         , xx_tcg_cartas_porte_v   cp
         , xx_aco_tablas_analisis  ta
         , mtl_system_items        item
         , mtl_system_items_b_dfv  item_dfv
         , fnd_lookup_values_vl    lv
         , fnd_lookup_values_dfv   lv_dfv
      WHERE 1=1
      AND bh.organization_id      = od.organization_id
      AND bl.boletin_header_id    = bh.boletin_header_id
      AND cp.carta_porte_id       = bl.carta_porte_id
      AND ta.tabla_analisis_id(+) = bh.tabla_analisis_id
      AND item.inventory_item_id  = bh.inventory_item_id
      AND item.organization_id    = XX_TCG_FUNCTIONS_PKG.GetMasterOrg
      AND item_dfv.row_id         = item.rowid
      AND lv.lookup_code          = item_dfv.xx_aco_codigo_oncca
      AND lv.lookup_type          = 'XX_ACO_ESPECIES_ONCCA'
      AND lv_dfv.row_id           = lv.row_id
      AND lv_dfv.context          = lv.attribute_category
      AND XX_TCG_FUNCTIONS_PKG.Valida_Acceso_Org_c(FND_GLOBAL.User_ID, bh.organization_id) = 'Y'
      --Parametros--
      AND ( p_uo IS NULL OR
            p_uo = od.operating_unit
          )
      AND ( p_empresa_origen IS NULL OR
            p_empresa_origen = bh.empresa_origen_party_id
          )
      AND ( p_estab_origen IS NULL OR
            p_estab_origen = bh.establecimiento_origen_id
          )
      AND ( p_provincia_origen IS NULL OR
            p_provincia_origen = bh.provincia_origen_code
          )
      AND ( p_localidad_origen IS NULL OR
            p_localidad_origen = bh.localidad_origen_code
          )
      AND ( p_empresa_destino IS NULL OR
            p_empresa_destino = bh.empresa_destino_party_id
          )
      AND ( p_estab_destino IS NULL OR
            p_estab_destino = bh.establecimiento_destino_id
          )
      AND ( p_provincia_destino IS NULL OR
            p_provincia_destino = bh.provincia_destino_code
          )
      AND ( p_localidad_destino IS NULL OR
            p_localidad_destino = bh.localidad_destino_code
          )
      AND ( p_numero_boletin IS NULL OR
            p_numero_boletin = bh.boletin_header_id
          )
      AND ( p_fecha_desde IS NULL OR
            TRUNC(bh.fecha_analisis)  >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(bh.fecha_analisis)  <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_especie_oncca IS NULL OR
            p_especie_oncca = lv_dfv.xx_aco_especies_oncca
          )
      AND ( p_codigo_oncca IS NULL OR
            p_codigo_oncca = item_dfv.xx_aco_codigo_oncca
          )
      AND ( p_producto IS NULL OR
            p_producto = bh.inventory_item_id
          )
      AND ( p_campana IS NULL OR
            p_campana = bh.lot_number
          )
      ;

    l_dummy_char1   VARCHAR2(250);

  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Boletines');
    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_uo: '||p_uo);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa_origen: '||p_empresa_origen);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_estab_origen: '||p_estab_origen);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_provincia_origen: '||p_provincia_origen);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_localidad_origen: '||p_localidad_origen);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa_destino: '||p_empresa_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_estab_destino: '||p_estab_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_provincia_destino: '||p_provincia_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_localidad_destino: '||p_localidad_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_numero_boletin: '||p_numero_boletin);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_desde: '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_hasta: '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_especie_oncca: '||p_especie_oncca);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_codigo_oncca: '||p_codigo_oncca);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_producto: '||p_producto);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_campana: '||p_campana);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_mostrar_cp: '||p_mostrar_cp);

    --Significado Params--

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXTCGLISTBOLCAL>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX TCG Listado de Boletines</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>Fecha Emisión|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <PARAMS>Parámetros</PARAMS>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_UO>Unidad Operativa|'||NVL(XX_TCG_FUNCTIONS_PKG.OU_Party_Name(p_uo), 'No Especificado')||'</P_UO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA_ORIGEN>Empresa Origen|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Party_Name(p_empresa_origen))), 'No Especificado')||'</P_EMPRESA_ORIGEN>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESTAB_ORIGEN>Establecimiento Origen|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(XX_TCG_FUNCTIONS_PKG.getEstabName(p_estab_origen))), 'No Especificado')||'</P_ESTAB_ORIGEN>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PROVINCIA_ORIGEN>Provincia Origen|'||NVL(Get_Provincia(p_provincia_origen), 'No Especificado')||'</P_PROVINCIA_ORIGEN>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_LOCALIDAD_ORIGEN>Localidad Origen|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Localidad(p_localidad_origen))), 'No Especificado')||'</P_LOCALIDAD_ORIGEN>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA_DESTINO>Empresa Desino|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Party_Name(p_empresa_destino))), 'No Especificado')||'</P_EMPRESA_DESTINO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESTAB_DESTINO>Establecimiento Destino|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(XX_TCG_FUNCTIONS_PKG.getEstabName(p_estab_destino))), 'No Especificado')||'</P_ESTAB_DESTINO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PROVINCIA_DESTINO>Provincia Destino|'||NVL(Get_Provincia(p_provincia_destino), 'No Especificado')||'</P_PROVINCIA_DESTINO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_LOCALIDAD_DESTINO>Localidad Destino|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Localidad(p_localidad_destino))), 'No Especificado')||'</P_LOCALIDAD_DESTINO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>Fecha Desde|'||NVL(SUBSTR(p_fecha_desde,1,10), 'No Especificado')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_HASTA>Fecha Hasta|'||NVL(SUBSTR(p_fecha_hasta,1,10), 'No Especificado')||'</P_FECHA_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESPECIE_ONCCA>Especie ONNCA|'||NVL(p_especie_oncca, 'No Especificado')||'</P_ESPECIE_ONCCA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CODIGO_ONCCA>Código ONNCA|'||NVL(p_codigo_oncca, 'No Especificado')||'</P_CODIGO_ONCCA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PRODUCTO>Producto|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Item_Desc(p_producto))), 'No Especificado')||'</P_PRODUCTO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CAMPANA>Campaña|'||NVL(p_campana, 'No Especificado')||'</P_CAMPANA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_MOSTRAR_CP>Tipo Ticket|'||NVL(Get_YesNo(p_mostrar_cp), 'No Especificado')||'</P_MOSTRAR_CP>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_MOSTRAR_CP2>'||p_mostrar_cp||'</P_MOSTRAR_CP2>');

    g_data := 'Numero Boletin|'
            ||'Estado|'
            ||'Fecha Analisis|'
            ||'Entidad|'
            ||'Entidad Descripción|'
            ||'Tabla Analisis|'
            ||'Tabla Analisis Descripción|'
            ||'Producto|'
            ||'Producto Descripción|'
            ||'Código ONCCA|'
            ||'Campaña|'
            ||'Número Contrato|'
            ||'Empresa Origen|'
            ||'Empresa Origen CUIT|'
            ||'Establecimiento Origen|'
            ||'Estab Origen ONCCA|'
            ||'Provincia Origen|'
            ||'Localidad Origen|'
            ||'Empresa Destino|'
            ||'Empresa Destino CUIT|'
            ||'Etablecimiento Destino|'
            ||'Estab Destino ONCCA|'
            ||'Provincia Destino|'
            ||'Localidad Destino|'
            ||'Factor|'
            ||'Grado |'
            ||'Número Certificado|'
            ||'Fecha Certificado|';

    --Completa tabla de valores de calidad
    DELETE xx_aco_rep_calidad_tmp WHERE request_id != FND_GLOBAL.conc_request_id;

    FOR r2 IN c2 LOOP
      INSERT INTO bolinf.xx_aco_rep_calidad_tmp
      ( request_id
      , boletin_header_id
      , tabla_analisis_id
      , codigo_concepto
      , valor
      , porcentaje_descuento
      , porcentaje_bonificacion
      ) VALUES
      ( FND_GLOBAL.conc_request_id
      , r2.boletin_header_id
      , r2.tabla_analisis_id
      , r2.concepto_calidad
      , r2.valor
      , r2.porcentaje_descuento
      , r2.porcentaje_bonificacion
      );
    END LOOP;

    FOR r3 IN c3 ( p_request_id => FND_GLOBAL.conc_request_id ) LOOP
      IF NVL(l_dummy_char1,'x') != r3.concepto_calidad THEN
        l_dummy_char1 := r3.concepto_calidad;
        g_data := g_data ||'Concepto Calidad|Valor|Porcentaje Descuento|Porcentaje Bonificación|';
      END IF;
    END LOOP;


    FND_FILE.Put_Line(FND_FILE.Output, '  <TITULOS>'||g_data||'</TITULOS>');

    FOR r1 IN c1 LOOP
      g_data := r1.numero_boletin||'|'
              ||r1.estado||'|'
              ||r1.fecha_analisis||'|'
              ||r1.entidad||'|'
              ||r1.entidad_desc||'|'
              ||r1.tabla_analisis_codigo||'|'
              ||r1.tabla_analisis_desc||'|'
              ||r1.item_no||'|'
              ||r1.item_desc||'|'
              ||r1.item_oncca_code||'|'
              ||r1.campana||'|'
              ||r1.numero_contrato||'|'
              ||r1.empresa_origen||'|'
              ||r1.empresa_origen_cuit||'|'
              ||r1.establecimiento_origen||'|'
              ||r1.est_origen_oncca_code||'|'
              ||r1.provincia_origen||'|'
              ||r1.localidad_origen||'|'
              ||r1.empresa_destino||'|'
              ||r1.empresa_destino_cuit||'|'
              ||r1.establecimiento_destino||'|'
              ||r1.est_destino_oncca_code||'|'
              ||r1.provincia_destino||'|'
              ||r1.localidad_destino||'|'
              ||r1.factor||'|'
              ||r1.grado||'|'
              ||r1.numero_certif||'|'
              ||r1.fecha_certif||'|'
              ;

      FOR r3 IN c3 ( p_request_id => FND_GLOBAL.conc_request_id ) LOOP

        FOR r4 IN c4 ( p_request_id        => FND_GLOBAL.conc_request_id
                     , p_tabla_analisis_id => r1.tabla_analisis_id
                     , p_boletin_header_id => r1.boletin_header_id
                     ) LOOP
          IF c3%ROWCOUNT = c4%ROWCOUNT THEN
            IF r3.concepto_calidad = r4.concepto_calidad THEN
              g_data := g_data || r4.concepto_calidad_desc||'|'||r4.valor||'|'||r4.porcentaje_descuento||'|'||r4.porcentaje_bonificacion||'|';
            ELSE
              g_data := g_data || '||||';
            END IF;

            EXIT;
          END IF;
        END LOOP;

      END LOOP;


      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DATA>'||xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(g_data))||'</DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;

    IF p_mostrar_cp = 'Y' THEN
      g_data := 'Número Boletín|'
              ||'Fecha Analisis|'
              ||'Número Carta Porte|'
              ||'Productor|'
              ||'Productor Sucursal|'
              ||'Lote|'
              ||'Destino|'
              ||'Destino Sucursal|'
              ||'Pctaje Humedad|'
              ||'Peso Humedad|'
              ||'Pctaje Volatil|'
              ||'Peso Volatil|'
              ||'Pctaje Zaranda|'
              ||'Peso Zaranda|'
              ||'Peso Aplicado|'
              ;
      FND_FILE.Put_Line(FND_FILE.Output, '  <TITULOS2>'||g_data||'</TITULOS2>');

      FOR r5 IN c5 LOOP
        g_data := r5.numero_boletin||'|'
                ||r5.fecha_analisis||'|'
                ||r5.numero_carta_porte||'|'
                ||r5.productor||'|'
                ||r5.productor_sucursal||'|'
                ||r5.lote||'|'
                ||r5.destino||'|'
                ||r5.destino_sucursal||'|'
                ||r5.pctaje_humedad||'|'
                ||r5.peso_humedad||'|'
                ||r5.pctaje_volatil||'|'
                ||r5.peso_volatil||'|'
                ||r5.pctaje_zaranda||'|'
                ||r5.peso_zaranda||'|'
                ||r5.peso_aplicado||'|'
                ;

        FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA2>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <DATA2>'||xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(g_data))||'</DATA2>');
        FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA2>');
      END LOOP;
    END IF;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXTCGLISTBOLCAL>');

    DELETE xx_aco_rep_calidad_tmp;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Listado_Boletines_Calidad;



  PROCEDURE Actualiza_Cert_ACO ( p_errbuf      IN OUT NOCOPY VARCHAR2
                               , p_errcode     IN OUT NOCOPY VARCHAR2
                               --
                               , p_contrato_compra      IN NUMBER
                               , p_carta_porte          IN NUMBER
                               , p_certificado          IN NUMBER
                               , p_destino_empresa      IN NUMBER
                               , p_destino_empresa_enbl IN VARCHAR2
                               , p_establecimiento      IN NUMBER
                               , p_localidad_destino    IN VARCHAR2
                               , p_organizacion         IN NUMBER
                               , p_subinventario        IN VARCHAR2
                               , p_localizador          IN NUMBER
                               ) IS
    l_sql_stmt VARCHAR2(20000);
  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Actualiza Certificados ACO');
    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_contrato_compra: '||p_contrato_compra);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_carta_porte: '||p_carta_porte);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_certificado: '||p_certificado);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_destino_empresa: '||p_destino_empresa);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_establecimiento: '||p_establecimiento);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_localidad_destino: '||p_localidad_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_organizacion: '||p_organizacion);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_subinventario: '||p_subinventario);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_localizador: '||p_localizador);


    l_sql_stmt := 'UPDATE xx_aco_liquidaciones_1116a ';
    IF p_destino_empresa IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'SET empresa_destino_party_id = '||p_destino_empresa||' ';

      IF p_establecimiento IS NOT NULL THEN
        l_sql_stmt := l_sql_stmt ||'  , establecimiento_destino_id = '||p_establecimiento||' ';
      END IF;

      IF p_localidad_destino IS NOT NULL THEN
        l_sql_stmt := l_sql_stmt ||'  , localidad_destino_code = '''||p_localidad_destino||''' ';
      END IF;

    ELSIF p_establecimiento IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'SET establecimiento_destino_id = '||p_establecimiento||' ';

      IF p_localidad_destino IS NOT NULL THEN
        l_sql_stmt := l_sql_stmt ||'  , localidad_destino_code = '''||p_localidad_destino||''' ';
      END IF;

    ELSIF p_localidad_destino IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'SET localidad_destino_code = '''||p_localidad_destino||''' ';

    END IF;

    l_sql_stmt := l_sql_stmt ||'WHERE contrato_id = '||p_contrato_compra||' ';
    IF p_certificado IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'AND liquidacion_id = '||p_certificado;
    END IF;

    IF p_destino_empresa IS NOT NULL OR
       p_establecimiento IS NOT NULL OR
       p_localidad_destino IS NOT NULL THEN
      EXECUTE IMMEDIATE l_sql_stmt;
      FND_FILE.Put_Line(FND_FILE.Output, 'Se actualizaron '||SQL%ROWCOUNT||' registros en Liquidaciones.');
    END IF;

    l_sql_stmt := 'UPDATE apps.xx_aco_cartas_porte_b ';

    IF p_organizacion IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt || 'SET organization_id = '||p_organizacion||' ';

      IF p_subinventario IS NOT NULL THEN
        l_sql_stmt := l_sql_stmt ||'  , subinventory_code = '''||p_subinventario||''' ';
      END IF;

      IF p_localizador IS NOT NULL THEN
        l_sql_stmt := l_sql_stmt ||'  , locator_id = '||p_localizador||' ';
      END IF;

    ELSIF p_subinventario IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'SET subinventory_code = '''||p_subinventario||''' ';

      IF p_localizador IS NOT NULL THEN
        l_sql_stmt := l_sql_stmt ||'  , locator_id = '||p_localizador||' ';
      END IF;

    ELSIF p_localizador IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'SET locator_id = '||p_localizador||' ';

    END IF;

    l_sql_stmt := l_sql_stmt ||'WHERE contrato_id = '||p_contrato_compra||' ';
    IF p_carta_porte IS NOT NULL THEN
      l_sql_stmt := l_sql_stmt ||'AND carta_porte_id = '||p_carta_porte;
    END IF;

    IF p_organizacion IS NOT NULL OR
       p_subinventario IS NOT NULL OR
       p_localizador IS NOT NULL THEN
      EXECUTE IMMEDIATE l_sql_stmt;
      FND_FILE.Put_Line(FND_FILE.Output, 'Se actualizaron '||SQL%ROWCOUNT||' registros en CP.');
    END IF;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      FND_FILE.Put_Line(FND_FILE.Output, 'Error gral '||SQLERRM);
      ROLLBACK;
  END Actualiza_Cert_ACO;


  PROCEDURE Gasto_Acondicionamiento ( p_errbuf      IN OUT NOCOPY VARCHAR2
                                    , p_errcode     IN OUT NOCOPY VARCHAR2
                                    , p_uo                        NUMBER
                                    , p_empresa_origen            NUMBER
                                    , p_estab_origen              NUMBER
                                    , p_empresa_destino           NUMBER
                                    , p_estab_destino             NUMBER
                                    , p_fecha_recep_desde         VARCHAR2
                                    , p_fecha_recep_hasta         VARCHAR2
                                    , p_especie_oncca             VARCHAR2
                                    ) IS

    CURSOR c1 IS
      SELECT cp.numero_carta_porte
      ||'|'||cp.item_no
      ||'|'||cp.item_desc
      ||'|'||cp.lot_no
      ||'|'||cp.item_oncca_especie
      ||'|'||cp.transferido_flag
      ||'|'||cp.recibido_flag
      ||'|'||cp.anulado_flag
      ||'|'||cp.titular_cp_tipo
      ||'|'||cp.titular_cp
      ||'|'||cp.titular_cp_estab_desc
      ||'|'||cp.titular_cp_ubicacion_desc
      ||'|'||cp.titular_cp_provincia_desc
      ||'|'||cp.titular_cp_localidad_desc
      ||'|'||cp.titular_cp_direccion
      ||'|'||cp.intermediario      -- CR 1888    ABARACCA
      ||'|'||cp.rtte_comercial    -- CR 1888    ABARACCA
      ||'|'||cp.destinatario
      ||'|'||cp.destino
      ||'|'||cp.destino_estab_desc
      ||'|'||cp.destino_ubicacion_desc
      ||'|'||cp.destino_provincia_desc
      ||'|'||cp.destino_localidad_desc
      ||'|'||cp.destino_direccion
      ||'|'||cp.fecha_envio
      ||'|'||cp.fecha_carga
      ||'|'||cp.tara_envio
      ||'|'||cp.peso_bruto_envio
      ||'|'||cp.peso_neto_envio
      ||'|'||cp.peso_estimado
      ||'|'||cp.lote
      ||'|'||cp.variedad
      ||'|'||cp.fecha_recepcion
      ||'|'||cp.peso_bruto_recepcion
      ||'|'||cp.tara_recepcion
      ||'|'||cp.peso_neto_recepcion
      ||'|'||cp.pctaje_humedad_recep
      ||'|'||cp.pctaje_merma_humedad_recep
      ||'|'||cp.peso_merma_humedad_recep
      ||'|'||cp.pctaje_zaranda_recep
      ||'|'||cp.peso_merma_zaranda_recep
      ||'|'||cp.pctaje_volatil_recep
      ||'|'||cp.peso_merma_volatil_recep
      ||'|'||cp.pctaje_otros_recep
      ||'|'||cp.peso_merma_otros_recep
      ||'|'||cp.pctaje_materia_extrania_recep
      ||'|'||cp.peso_merma_materia_ext_recep
      ||'|'||cp.peso_aplicado_recep
      ||'|'||ca.moneda                 -- CR 1888    ABARACCA
      ||'|'||ga.paritaria_tarifa
      ||'|'||ga.paritaria_importe
      ||'|'||ga.secada_tarifa
      ||'|'||ga.secada_importe
      ||'|'||ga.fumigada_tarifa
      ||'|'||ga.fumigada_importe
      ||'|'||ga.zaranda_tarifa
      ||'|'||ga.zaranda_importe
      ||'|'||cer.liquidacion_id
      ||'|'||cer.numero_liquidacion
      ||'|'||cer.fecha_liquidacion
      ||'|'||ga.acond_id  data_out
      FROM xx_tcg_cartas_porte_v2         cp
         , xx_tcg_gasto_acondicionamiento ga
         , xx_tcg_liquidaciones_1116a        cer
         , xx_tcg_acondicionamiento          ca      -- CR 1888   ABARACCA
      WHERE 1=1
      AND ga.carta_porte_id      = cp.carta_porte_id
      AND ga.acond_id              = ca.acond_id
      AND cer.liquidacion_id (+) = ga.certificado_id
      --Params
      AND ( p_uo IS NULL OR
            XX_TCG_FUNCTIONS_PKG.Interviene_CP ( cp.carta_porte_id, p_uo ) = 1
          )
      AND ( p_empresa_origen IS NULL OR
            p_empresa_origen = cp.titular_cp_id
          )
      AND ( p_estab_origen IS NULL OR
            p_estab_origen = cp.titular_cp_estab_id
          )
      AND ( p_empresa_destino IS NULL OR
            p_empresa_destino = cp.destino_id
          )
      AND ( p_estab_destino IS NULL OR
            p_estab_destino = cp.destino_estab_id
          )
      AND ( p_fecha_recep_desde IS NULL OR
            cp.fecha_recepcion >= TRUNC(TO_DATE(p_fecha_recep_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_recep_hasta IS NULL OR
            cp.fecha_recepcion <= TRUNC(TO_DATE(p_fecha_recep_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_especie_oncca IS NULL OR
            p_especie_oncca = cp.item_oncca_especie
          )
      ;

  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Gastos de Acondicionamiento');
    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_uo: '||p_uo);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa_origen: '||p_empresa_origen);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_estab_origen: '||p_estab_origen);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa_destino: '||p_empresa_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_estab_destino: '||p_estab_destino);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_recep_desde: '||p_fecha_recep_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_recep_hasta: '||p_fecha_recep_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_especie_oncca: '||p_especie_oncca);

    --Significado Params--

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXTCGLISTGACOND>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX TCG Listado de Gastos de Acondicionamiento</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>Fecha Emisión|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <PARAMS>Parámetros</PARAMS>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_UO>Unidad Operativa|'||NVL(XX_TCG_FUNCTIONS_PKG.OU_Party_Name(p_uo), 'No Especificado')||'</P_UO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA_ORIGEN>Empresa Origen|'||NVL(Get_Party_Name(p_empresa_origen), 'No Especificado')||'</P_EMPRESA_ORIGEN>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESTAB_ORIGEN>Establecimiento Origen|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(XX_TCG_FUNCTIONS_PKG.getEstabName(p_estab_origen))), 'No Especificado')||'</P_ESTAB_ORIGEN>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA_DESTINO>Empresa Destino|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(Get_Party_Name(p_empresa_destino))), 'No Especificado')||'</P_EMPRESA_DESTINO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESTAB_DESTINO>Establecimiento Destino|'||NVL(xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(XX_TCG_FUNCTIONS_PKG.getEstabName(p_estab_destino))), 'No Especificado')||'</P_ESTAB_DESTINO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>Fecha Recepción Desde|'||NVL(SUBSTR(p_fecha_recep_desde,1,10), 'No Especificado')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_HASTA>Fecha Recepción Hasta|'||NVL(SUBSTR(p_fecha_recep_hasta,1,10), 'No Especificado')||'</P_FECHA_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ESPECIE_ONCCA>Especie ONNCA|'||NVL(p_especie_oncca, 'No Especificado')||'</P_ESPECIE_ONCCA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <TITULOS>Nro Carta Porte|Articulo Cod.|Articulo Des.|Campaña|ONCCA Art|Transf.|Recib.|Anul.|Titular Tipo|Titular|Titular Estab.|Titular Ubic.|Titular Provincia|Titular Localidad|Titular Dirección|Intermediario|Rtte Comercial|Destinatario|Destino|Destino Estab.|Destino Ubic.|Destino Provincia|Destino Localidad|Destino Dirección|Fecha Envío|Fecha Carga|Tara Envío|Bruto Envío|Neto Envío|Estimado Envío|Lote|Variedad|Fecha Rec.|Bruto Rec.|Tara Rec.|Neto Rec.|% Humedad|Por.Hum.Rec.|Mer.Hum.Rec.|% Zar.Rec.|Mer.Zar.Rec.|% Vol.Rec.|Mer.Vol.Rec.|% Otros Cptos|Mer.Otros Cptos|% Mat.Ext.Rec.|Mer.Mat.Ext.Rec.|Peso Aplicado Rec.|Moneda|Paritaria Tarifa|Paritaria Importe|Secada Tarifa|Secada Importe|Fumigada Tarifa|Fumigada Importe|Zaranda Tarifa|Zaranda Importe|ID Certificado|Nro. Certificado|Fecha Certificado|ID Costo Acond.|</TITULOS>');


    FOR r1 IN c1 LOOP
      g_data := r1.data_out;
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DATA>'||xx_util_pk.xml_accepted_chars(xx_util_pk.xml_escape_chars(g_data))||'</DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXTCGLISTGACOND>');

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Gasto_Acondicionamiento;


  PROCEDURE Imprime_Turno ( p_errbuf      IN OUT NOCOPY VARCHAR2
                          , p_errcode     IN OUT NOCOPY VARCHAR2
                          , p_carta_porte_id            NUMBER
                          ) IS

    CURSOR c1 IS

      SELECT cp.carta_porte_id
           , cp.numero_carta_porte
           , XX_UTIL_PK.xml_escape_chars(cp.item_desc)      item_desc
           , cp.lot_no
           , XX_UTIL_PK.xml_escape_chars(cp.titular_cp)     titular_cp
           , XX_UTIL_PK.xml_escape_chars(cp.intermediario)  intermediario
           , XX_UTIL_PK.xml_escape_chars(cp.rtte_comercial) rtte_comercial
           , XX_UTIL_PK.xml_escape_chars(cp.destinatario)   destinatario
           , XX_UTIL_PK.xml_escape_chars(cp.destino)        destino
           , XX_UTIL_PK.xml_escape_chars(cp.transportista_nombre) transportista_nombre
           , cp.transportista_cuit
           , XX_UTIL_PK.xml_escape_chars(cp.chofer)         chofer
           , cp.cuil
           , cp.patente_camion
           , cp.patente_acoplado
           , cp.distancia_estimada
           , cp.costo_flete_xton
           , cp.costo_flete
           , XX_UTIL_PK.xml_escape_chars(cp.observacion_transporte) observacion_transporte
      FROM xx_tcg_cartas_porte_v cp
      WHERE cp.carta_porte_id = p_carta_porte_id;


  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '--------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Imprime Turno');
    FND_FILE.Put_Line(FND_FILE.Log, '--------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_carta_porte_id: '||p_carta_porte_id);

    --Significado Params--

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXTCGIMPTURNO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX TCG Imprime Turno</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>Fecha Emisión|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');

    FOR r1 IN c1 LOOP
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CARTA_PORTE_ID>'||r1.carta_porte_id||'</CARTA_PORTE_ID>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_CARTA_PORTE>'||r1.numero_carta_porte||'</NUMERO_CARTA_PORTE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ITEM_DESC>'||r1.item_desc||'</ITEM_DESC>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LOT_NO>'||r1.lot_no||'</LOT_NO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TITULAR_CP>'||r1.titular_cp||'</TITULAR_CP>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <INTERMEDIARIO>'||r1.intermediario||'</INTERMEDIARIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <RTTE_COMERCIAL>'||r1.rtte_comercial||'</RTTE_COMERCIAL>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DESTINATARIO>'||r1.destinatario||'</DESTINATARIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DESTINO>'||r1.destino||'</DESTINO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSPORTISTA_NOMBRE>'||r1.transportista_nombre||'</TRANSPORTISTA_NOMBRE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSPORTISTA_CUIT>'||r1.transportista_cuit||'</TRANSPORTISTA_CUIT>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CHOFER>'||r1.chofer||'</CHOFER>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CUIL>'||r1.cuil||'</CUIL>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PATENTE_CAMION>'||r1.patente_camion||'</PATENTE_CAMION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PATENTE_ACOPLADO>'||r1.patente_acoplado||'</PATENTE_ACOPLADO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DISTANCIA_ESTIMADA>'||r1.distancia_estimada||'</DISTANCIA_ESTIMADA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <COSTO_FLETE_XTON>'||r1.costo_flete_xton||'</COSTO_FLETE_XTON>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <COSTO_FLETE>'||r1.costo_flete||'</COSTO_FLETE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <OBSERVACION_TRANSPORTE>'||r1.observacion_transporte||'</OBSERVACION_TRANSPORTE>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXTCGIMPTURNO>');

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Imprime_Turno;


  PROCEDURE Lista_Cupos ( p_errbuf         IN OUT NOCOPY VARCHAR2
                        , p_errcode        IN OUT NOCOPY VARCHAR2
                        , p_fentrega_desde IN VARCHAR2
                        , p_fentrega_hasta IN VARCHAR2
                        , p_grano          IN VARCHAR2
                        , p_cupo_dueno     IN NUMBER
                        ) IS


    CURSOR cCupos IS
      SELECT  cu.cupo_tipo
            , cu.cupo_numero
            , cu.fecha_creacion
            , cu.fecha_entrega
            , cu.estado
            , cu.item_oncca_code
            , cu.inventory_item_id
            , cu.lot_no
            , cu.condicion
            , cu.cupo_dueno
            , cu.cupo_dueno_cuit
            , cu.titular_cp_tipo
            , cu.titular_cp
            , cu.titular_cp_cuit
            , cu.intermediario_tipo
            , cu.intermediario
            , cu.intermediario_cuit
            , cu.rtte_comercial_tipo
            , cu.rtte_comercial_id
            , cu.rtte_comercial
            , cu.rtte_comercial_cuit
            , cu.rtte_comercial_estab_id
            , cu.corredor
            , cu.corredor_cuit
            , cu.mercado_termino
            , cu.mercado_termino_cuit
            , cu.corredor_vendedor
            , cu.corredor_vendedor_cuit
            , cu.representante
            , cu.representante_cuit
            , cu.destinatario
            , cu.destinatario_cuit
            , cu.destino_id
            , cu.destino
            , cu.destino_cuit
            , cu.destino_estab_id
            , loc.pr_dpto_nombre  destino_provincia
            , loc.loc_nombre      destino_localidad
            , cu.destino_direccion
            , cu.pagador_flete
            , cu.pagador_flete_cuit
            , cu.pedido_venta_id
            , cu.observaciones
            , ( SELECT oc.demanda_camiones_id
                FROM xx_tcg_orden_carga        oc
                   , xx_tcg_orden_carga_cupos  occ
                WHERE 1=1
                AND occ.orden_carga_id  = oc.orden_carga_id
                AND NVL(oc.cancelado_flag,'N')  = 'N'
                AND NVL(occ.cancelado_flag,'N') = 'N'
                AND occ.cupo_numero     = cu.cupo_numero
              ) orden_carga
            , ( SELECT ctg.nro_carta_porte carta_porte
                FROM xx_aco_ctgs_b ctg
                WHERE 1=1
                AND ctg.turno  = cu.cupo_numero
                AND ctg.estado NOT IN ( 'ANULADO', 'RECHAZADO' )
              ) numero_carta_porte
            , cu.cupo_id
      FROM xx_tcg_cupos  cu
         , xx_tcg_localidades2 loc
      WHERE 1=1
      AND loc.pais_codigo = 'AR'
      AND loc.pr_dpto_codigo = cu.destino_provincia
      AND loc.loc_codigo  = cu.destino_localidad
      AND cu.fecha_entrega BETWEEN TRUNC(NVL(TO_DATE(p_fentrega_desde, 'RRRR-MM-DD HH24:MI:SS'), cu.fecha_entrega)) AND TRUNC(NVL(TO_DATE(p_fentrega_hasta, 'RRRR-MM-DD HH24:MI:SS'), cu.fecha_entrega))
      AND cu.item_oncca_code = NVL(p_grano, cu.item_oncca_code)
      AND cu.cupo_dueno_id   = NVL(p_cupo_dueno, cu.cupo_dueno_id)
      ORDER BY fecha_entrega, cupo_numero
      ;

    CURSOR cItems ( p_item_id NUMBER ) IS
      SELECT msi.segment1          item_no
           , msi.description       item_description
           , msi_dfv.xx_aco_codigo_oncca  item_oncca_code
           , lv.description               item_oncca_desc
           , lv_dfv.xx_aco_especies_oncca item_oncca_especie
      FROM mtl_system_items       msi
         , mtl_system_items_b_dfv msi_dfv
         , fnd_lookup_values_vl   lv
         , fnd_lookup_values_dfv  lv_dfv
      WHERE 1=1
      AND msi_dfv.row_id = msi.rowid
      AND lv.lookup_code  = msi_dfv.xx_aco_codigo_oncca
      AND lv.lookup_type  = 'XX_ACO_ESPECIES_ONCCA'
      AND lv_dfv.row_id   = lv.row_id
      AND lv_dfv.context  = lv.attribute_category
      AND msi.inventory_item_id = p_item_id;

    CURSOR cEstab ( p_estab_id NUMBER ) IS
      SELECT est.campo
           , msi_type.xx_tcg_tipos tipo_establecimiento
           , est_oncca.establecimiento_oncca_code
      FROM xx_opm_establecimientos est
         , xx_tcg_estab_oncca      est_oncca
         , ( SELECT msi_dfv.xx_tcg_establecimientos, msi_dfv.xx_tcg_tipos
             FROM mtl_secondary_inventories_dfv msi_dfv
                , mtl_secondary_inventories     msi
             WHERE msi.rowid = msi_dfv.row_id
             AND msi_dfv.xx_tcg_tipos IS NOT NULl
           ) msi_type
      WHERE 1=1
      AND est_oncca.establecimiento_id(+) = est.establecimiento_id
      AND msi_type.xx_tcg_establecimientos(+) = est.establecimiento_id
      AND est.establecimiento_id = p_estab_id;

    CURSOR cLocation ( p_party_id    NUMBER
                     , p_location_id NUMBER
                     ) IS
      SELECT NVL(ps.party_site_name, l.address1) address1
           , l.address1||', '||l.address2||', CP '||l.postal_code concatenated_address
      FROM hz_party_sites  ps
         , hz_locations    l
      WHERE 1=1
      AND l.location_id = ps.location_id
      AND ps.party_id = p_party_id
      AND ps.party_site_id = p_location_id;


    rItems                     cItems%ROWTYPE;
    rEstab                     cEstab%ROWTYPE;
    rLocation                  cLocation%ROWTYPE;
    l_item_oncca               VARCHAR2(500);
    l_item_desc                VARCHAR2(500);
    l_destino_sucursal         VARCHAR2(2000);
    l_rtte_comercial_sucursal  VARCHAR2(2000);
    l_dueno                    VARCHAR2(500);
    l_carta_porte              VARCHAR2(50);
  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '-----------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Cupos');
    FND_FILE.Put_Line(FND_FILE.Log, '-----------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fentrega_desde: '||p_fentrega_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fentrega_hasta: '||p_fentrega_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_grano: '||p_grano);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_cupo_dueno: '||p_cupo_dueno);

    BEGIN
      SELECT lookup_code||' - '||description
      INTO l_item_oncca
      FROM fnd_lookup_values_vl
      WHERE 1=1
      AND lookup_type = 'XX_ACO_ESPECIES_ONCCA'
      AND lookup_code = p_grano
      ;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    BEGIN
      SELECT vendor_name
      INTO l_dueno
      FROM ap_suppliers
      WHERE party_id = p_cupo_dueno
      ;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado de Cupos');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Entrega Desde:|'||TO_CHAR(TO_DATE(p_fentrega_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Entrega Hasta:|'||TO_CHAR(TO_DATE(p_fentrega_hasta, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Grano:|'||l_item_oncca);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Proveedor Cupo:|'||l_dueno);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    --TITULOS
    FND_FILE.Put_Line(FND_FILE.OUTPUT,
                     'CUPO_TIPO|'
                   ||'CUPO_NUMERO|'
                   ||'FECHA_CREACION|'
                   ||'FECHA_ENTREGA|'
                   ||'ESTADO|'
                   ||'GRANO|'
                   ||'ARTICULO|'
                   ||'CAMPAÑA|'
                   ||'CONDICION|'
                   ||'PROVEEDOR CUPO|'
                   ||'PROVEEDOR CUPO CUIT|'
                   ||'TITULAR CP TIPO|'
                   ||'TITULAR CP|'
                   ||'TITULAR CP CUIT|'
                   ||'INTERMEDIARIO TIPO|'
                   ||'INTERMEDIARIO|'
                   ||'INTERMEDIARIO CUIT|'
                   ||'RTTE COMERCIAL TIPO|'
                   ||'RTTE COMERCIAL|'
                   ||'RTTE COMERCIAL CUIT|'
                   ||'RTTE COMERCIAL SUCURSAL|'
                   ||'CORREDOR|'
                   ||'CORREDOR CUIT|'
                   ||'MERCADO TERMINO|'
                   ||'MERCADO TERMINO CUIT|'
                   ||'CORREDOR VENDEDOR|'
                   ||'CORREDOR VENDEDOR CUIT|'
                   ||'REPRESENTANTE|'
                   ||'REPRESENTANTE CUIT|'
                   ||'DESTINATARIO|'
                   ||'DESTINATARIO CUIT|'
                   ||'DESTINO|'
                   ||'DESTINO CUIT|'
                   ||'DESTINO SUCURSAL|'
                   ||'DESTINO PROVINCIA|'
                   ||'DESTINO LOCALIDAD|'
                   ||'DESTINO DIRECCION|'
                   ||'PAGADOR FLETE|'
                   ||'PAGADOR FLETE CUIT|'
                   ||'PEDIDO VENTA|'
                   ||'OBSERVACIONES|'
                   ||'ORDEN CARGA|'
                   ||'NUMERO CARTA PORTE'
                     );
    FOR rCupos IN cCupos LOOP
      -- Items
      l_item_oncca := NULL;
      OPEN cItems (rCupos.inventory_item_id);
      FETCH cItems INTO rItems;
      l_item_oncca := rItems.item_oncca_desc;
      l_item_desc  := rItems.item_description;
      CLOSE cItems;


      l_destino_sucursal := NULL;
      IF rCupos.destino_estab_id IS NOT NULL THEN
        IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rCupos.destino_cuit) THEN
          rEstab := NULL;
          OPEN cEstab (rCupos.destino_estab_id);
          FETCH cEstab INTO rEstab;
          l_destino_sucursal := rEstab.campo;
          CLOSE cEstab;

        ELSIF XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (rCupos.destino_cuit) THEN
          rLocation := NULL;
          OPEN cLocation ( rCupos.destino_id
                         , rCupos.destino_estab_id
                         );
          FETCH cLocation INTO rLocation;
          l_destino_sucursal := rLocation.address1;
          CLOSE cLocation;

        END IF;
      END IF;

      l_rtte_comercial_sucursal := NULL;
      IF rCupos.rtte_comercial_estab_id IS NOT NULL THEN
        IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rCupos.rtte_comercial_cuit) THEN
          rEstab := NULL;
          OPEN cEstab (rCupos.rtte_comercial_estab_id);
          FETCH cEstab INTO rEstab;
          l_rtte_comercial_sucursal := rEstab.campo;
          CLOSE cEstab;

        ELSIF XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (rCupos.rtte_comercial_cuit) THEN
          rLocation := NULL;
          OPEN cLocation ( rCupos.rtte_comercial_id
                         , rCupos.rtte_comercial_estab_id
                         );
          FETCH cLocation INTO rLocation;
          l_rtte_comercial_sucursal := rLocation.address1;
          CLOSE cLocation;

        END IF;
      END IF;

      l_carta_porte := rCupos.numero_carta_porte;
      IF l_carta_porte IS NULL THEN
        BEGIN
          SELECT SUBSTR(cpi.numero_carta_porte,1,4)||'-'||SUBSTR(cpi.numero_carta_porte,5,8)
          INTO l_carta_porte
          FROM xx_tcg_cartas_porte_interface cpi
          WHERE 1=1
          AND cpi.cupo_id = rCupos.cupo_id
          AND NOT EXISTS ( SELECT 1
                           FROM xx_aco_ctgs_b ctg
                           WHERE 1=1
                           AND REPLACE(ctg.nro_carta_porte,'-','') = cpi.numero_carta_porte
                           AND ctg.estado IN ('ANULADO', 'RECHAZADO')
                         );
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;

      FND_FILE.Put_Line(FND_FILE.OUTPUT, rCupos.cupo_tipo
                                  ||'|'||rCupos.cupo_numero
                                  ||'|'||TO_CHAR(rCupos.fecha_creacion, 'RRRR-MM-DD')
                                  ||'|'||TO_CHAR(rCupos.fecha_entrega, 'RRRR-MM-DD')
                                  ||'|'||rCupos.estado
                                  ||'|'||l_item_oncca
                                  ||'|'||l_item_desc
                                  ||'|'||rCupos.lot_no
                                  ||'|'||rCupos.condicion
                                  ||'|'||rCupos.cupo_dueno
                                  ||'|'||rCupos.cupo_dueno_cuit
                                  ||'|'||rCupos.titular_cp_tipo
                                  ||'|'||rCupos.titular_cp
                                  ||'|'||rCupos.titular_cp_cuit
                                  ||'|'||rCupos.intermediario_tipo
                                  ||'|'||rCupos.intermediario
                                  ||'|'||rCupos.intermediario_cuit
                                  ||'|'||rCupos.rtte_comercial_tipo
                                  ||'|'||rCupos.rtte_comercial
                                  ||'|'||rCupos.rtte_comercial_cuit
                                  ||'|'||l_rtte_comercial_sucursal
                                  ||'|'||rCupos.corredor
                                  ||'|'||rCupos.corredor_cuit
                                  ||'|'||rCupos.mercado_termino
                                  ||'|'||rCupos.mercado_termino_cuit
                                  ||'|'||rCupos.corredor_vendedor
                                  ||'|'||rCupos.corredor_vendedor_cuit
                                  ||'|'||rCupos.representante
                                  ||'|'||rCupos.representante_cuit
                                  ||'|'||rCupos.destinatario
                                  ||'|'||rCupos.destinatario_cuit
                                  ||'|'||rCupos.destino
                                  ||'|'||rCupos.destino_cuit
                                  ||'|'||l_destino_sucursal
                                  ||'|'||rCupos.destino_provincia
                                  ||'|'||rCupos.destino_localidad
                                  ||'|'||rCupos.destino_direccion
                                  ||'|'||rCupos.pagador_flete
                                  ||'|'||rCupos.pagador_flete_cuit
                                  ||'|'||NULL --Pedido Venta
                                  ||'|'||rCupos.observaciones
                                  ||'|'||rCupos.orden_carga
                                  ||'|'||l_carta_porte
                                  );
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_Cupos;


  PROCEDURE Lista_Orden_Carga ( p_errbuf           IN OUT NOCOPY VARCHAR2
                              , p_errcode          IN OUT NOCOPY VARCHAR2
                              , p_orden_carga      IN NUMBER
                              , p_empresa          IN VARCHAR2
                              , p_establecimiento  IN NUMBER
                              , p_fcarga_desde     IN VARCHAR2
                              , p_fcarga_hasta     IN VARCHAR2
                              ) IS

    CURSOR cOC IS
      SELECT oc.empresa
           , oc.empresa_cuit
           , CASE WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_C (oc.empresa_cuit) = 'Y' THEN
                    (SELECT est.campo
                     FROM xx_opm_establecimientos est
                     WHERE establecimiento_id = oc.empresa_estab_id)
                  ELSE
                    (SELECT l.address1
                     FROM hz_party_sites ps, hz_locations l
                     WHERE 1=1
                     AND l.location_id = ps.location_id
                     AND ps.party_id   = oc.empresa_id
                     AND ps.party_site_id = oc.empresa_estab_id)
             END empresa_estab
           , oc.fecha_carga
           , oc.demanda_camiones_id ref_interna
           , lv.description         item_oncca
           , oc.lot_no
           , oc.fecha_creacion
           , oc.cantidad_solicitada
           , oc.observaciones
           , oc.cancelado_flag
           , oc.orden_carga_id
      FROM xx_tcg_orden_carga      oc
         , fnd_lookup_values_vl    lv
      WHERE 1=1
      AND lv.lookup_code = oc.item_oncca_code
      AND lookup_type    = 'XX_ACO_ESPECIES_ONCCA'
      -- Parametros
      AND ( p_orden_carga IS NULL OR
            p_orden_carga = oc.orden_carga_id
          )
      AND ( p_empresa IS NULL OR
            p_empresa = oc.empresa_id
          )
      AND ( p_establecimiento IS NULL OR
            p_establecimiento = oc.empresa_estab_id
          )
      AND ( p_fcarga_desde IS NULL OR
            oc.fecha_carga >= FND_DATE.CANONICAL_TO_DATE(p_fcarga_desde)
          )
      AND ( p_fcarga_hasta IS NULL OR
            oc.fecha_carga <= FND_DATE.CANONICAL_TO_DATE(p_fcarga_hasta)
          )
      ;

    CURSOR cCupos ( p_oc_id NUMBER ) IS
      SELECT  cu.cupo_tipo
            , cu.cupo_numero
            , cu.fecha_creacion
            , cu.fecha_entrega
            , cu.estado
            , cu.item_oncca_code
            , cu.inventory_item_id
            , cu.lot_no
            , cu.condicion
            , cu.cupo_dueno
            , cu.cupo_dueno_cuit
            , cu.titular_cp_tipo
            , cu.titular_cp
            , cu.titular_cp_cuit
            , cu.intermediario_tipo
            , cu.intermediario
            , cu.intermediario_cuit
            , cu.rtte_comercial_tipo
            , cu.rtte_comercial_id
            , cu.rtte_comercial
            , cu.rtte_comercial_cuit
            , cu.rtte_comercial_estab_id
            , cu.corredor
            , cu.corredor_cuit
            , cu.mercado_termino
            , cu.mercado_termino_cuit
            , cu.corredor_vendedor
            , cu.corredor_vendedor_cuit
            , cu.representante
            , cu.representante_cuit
            , cu.destinatario
            , cu.destinatario_cuit
            , cu.destino_id
            , cu.destino
            , cu.destino_cuit
            , cu.destino_estab_id
            , loc.pr_dpto_nombre  destino_provincia
            , loc.loc_nombre      destino_localidad
            , cu.destino_direccion
            , cu.pagador_flete
            , cu.pagador_flete_cuit
            , cu.distancia_estimada
            , cu.tarifa_impresion
            , cu.pedido_venta_id
            , cu.observaciones
            , ( SELECT oc.demanda_camiones_id
                FROM xx_tcg_orden_carga        oc
                   , xx_tcg_orden_carga_cupos  occ
                WHERE 1=1
                AND occ.orden_carga_id  = oc.orden_carga_id
                AND NVL(oc.cancelado_flag,'N')  = 'N'
                AND NVL(occ.cancelado_flag,'N') = 'N'
                AND occ.cupo_numero     = cu.cupo_numero
              ) orden_carga
            , ( SELECT ctg.nro_carta_porte carta_porte
                FROM xx_aco_ctgs_b ctg
                WHERE 1=1
                AND ctg.turno  = cu.cupo_numero
                AND ctg.estado NOT IN ( 'ANULADO', 'RECHAZADO' )
              ) numero_carta_porte
            , cu.cancelado_flag
            , cu.cupo_id
      FROM xx_tcg_orden_carga_cupos  cu
         , xx_tcg_localidades2       loc
      WHERE 1=1
      AND loc.pais_codigo = 'AR'
      AND loc.pr_dpto_codigo = cu.destino_provincia
      AND loc.loc_codigo  = cu.destino_localidad
      AND cu.orden_carga_id = p_oc_id
      ORDER BY cu.cupo_id
      ;

    CURSOR cOCT ( p_oc_id NUMBER ) IS
      SELECT oct.carrier_service_id
           , wcs.ship_method_meaning
           , oct.transportista
           , oct.transportista_cuit
           , oct.chofer
           , oct.chofer_cuit
           , oct.patente_camion
           , oct.patente_acoplado
           , oct.intermediario_flete
           , oct.intermediario_flete_cuit
           , loc.loc_nombre localidad_destino
           , oct.observaciones
      FROM xx_tcg_orden_carga_trans oct
         , wsh_carrier_services_v   wcs
         , xx_tcg_localidades2      loc
      WHERE 1=1
      AND wcs.carrier_service_id(+) = oct.carrier_service_id
      AND loc.loc_codigo(+)         = oct.localidad_destino
      AND loc.pais_codigo(+)        = 'AR'
      AND oct.orden_carga_id        = p_oc_id
      ORDER BY oct.carrier_service_id
      ;

    CURSOR cItems ( p_item_id NUMBER ) IS
      SELECT msi.segment1          item_no
           , msi.description       item_description
           , msi_dfv.xx_aco_codigo_oncca  item_oncca_code
           , lv.description               item_oncca_desc
           , lv_dfv.xx_aco_especies_oncca item_oncca_especie
      FROM mtl_system_items       msi
         , mtl_system_items_b_dfv msi_dfv
         , fnd_lookup_values_vl   lv
         , fnd_lookup_values_dfv  lv_dfv
      WHERE 1=1
      AND msi_dfv.row_id = msi.rowid
      AND lv.lookup_code  = msi_dfv.xx_aco_codigo_oncca
      AND lv.lookup_type  = 'XX_ACO_ESPECIES_ONCCA'
      AND lv_dfv.row_id   = lv.row_id
      AND lv_dfv.context  = lv.attribute_category
      AND msi.inventory_item_id = p_item_id;

    CURSOR cEstab ( p_estab_id NUMBER ) IS
      SELECT est.campo
           , msi_type.xx_tcg_tipos tipo_establecimiento
           , est_oncca.establecimiento_oncca_code
      FROM xx_opm_establecimientos est
         , xx_tcg_estab_oncca      est_oncca
         , ( SELECT msi_dfv.xx_tcg_establecimientos, msi_dfv.xx_tcg_tipos
             FROM mtl_secondary_inventories_dfv msi_dfv
                , mtl_secondary_inventories     msi
             WHERE msi.rowid = msi_dfv.row_id
             AND msi_dfv.xx_tcg_tipos IS NOT NULl
           ) msi_type
      WHERE 1=1
      AND est_oncca.establecimiento_id(+) = est.establecimiento_id
      AND msi_type.xx_tcg_establecimientos(+) = est.establecimiento_id
      AND est.establecimiento_id = p_estab_id;

    CURSOR cLocation ( p_party_id    NUMBER
                     , p_location_id NUMBER
                     ) IS
      SELECT l.address1
           , l.address1||', '||l.address2||', CP '||l.postal_code concatenated_address
      FROM hz_party_sites  ps
         , hz_locations    l
      WHERE 1=1
      AND l.location_id = ps.location_id
      AND ps.party_id = p_party_id
      AND ps.party_site_id = p_location_id;


    rItems                     cItems%ROWTYPE;
    rEstab                     cEstab%ROWTYPE;
    rLocation                  cLocation%ROWTYPE;
    l_item_oncca               VARCHAR2(500);
    l_item_desc                VARCHAR2(500);
    l_destino_sucursal         VARCHAR2(2000);
    l_rtte_comercial_sucursal  VARCHAR2(2000);
    l_empresa                  VARCHAR2(500);
    l_establecimiento          VARCHAR2(500);
    l_carta_porte              VARCHAR2(50);
  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '----------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Ordenes de Carga');
    FND_FILE.Put_Line(FND_FILE.Log, '----------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa: '||p_empresa);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_establecimiento: '||p_establecimiento);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_desde: '||p_fcarga_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_hasta: '||p_fcarga_hasta);

    BEGIN
      SELECT vendor_name
      INTO l_empresa
      FROM ap_suppliers
      WHERE party_id = p_empresa
      ;
    EXCEPTION
      WHEN OTHERS THEN
        l_empresa := 'No Especificado';
    END;

    BEGIN
      SELECT campo
      INTO l_establecimiento
      FROM xx_opm_establecimientos
      WHERE establecimiento_id = p_establecimiento
      ;
    EXCEPTION
      WHEN OTHERS THEN
        l_establecimiento := 'No Especificado';
    END;

    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado de Ordenes de Carga');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Empresa:|'||l_empresa);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Establecimiento:|'||l_establecimiento);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Entrega Desde:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Entrega Hasta:|'||TO_CHAR(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');


    FOR rOC IN cOC LOOP
      FND_FILE.Put_Line(FND_FILE.OUTPUT, 'ORDEN DE CARGA '||rOC.ref_interna);
      --TITULOS OC
      FND_FILE.Put_Line(FND_FILE.OUTPUT,
                       'EMPRESA|'
                     ||'EMPRESA CUIT|'
                     ||'ESTABLECIMIENTO|'
                     ||'FECHA CARGA|'
                     ||'REF INTERNA|'
                     ||'GRANO|'
                     ||'CAMPAÑA|'
                     ||'FECHA CREACION|'
                     ||'CANT SOLICITADA|'
                     ||'OBSERVACIONES|'
                     ||'CANCELADO|'
                       );

      FND_FILE.Put_Line(FND_FILE.OUTPUT, rOC.empresa
                                  ||'|'||rOC.empresa_cuit
                                  ||'|'||rOC.empresa_estab
                                  ||'|'||TO_CHAR(rOC.fecha_carga, 'RRRR-MM-DD')
                                  ||'|'||rOC.ref_interna
                                  ||'|'||rOC.item_oncca
                                  ||'|'||rOC.lot_no
                                  ||'|'||TO_CHAR(rOC.fecha_creacion, 'RRRR-MM-DD')
                                  ||'|'||rOC.cantidad_solicitada
                                  ||'|'||rOC.observaciones
                                  ||'|'||rOC.cancelado_flag
                                      );

      FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
      FND_FILE.Put_Line(FND_FILE.OUTPUT, 'CUPOS');

      --TITULOS CUPOS
      FND_FILE.Put_Line(FND_FILE.OUTPUT,
                       'CUPO_TIPO|'
                     ||'CUPO_NUMERO|'
                     ||'FECHA_CREACION|'
                     ||'FECHA_ENTREGA|'
                     ||'ESTADO|'
                     ||'GRANO|'
                     ||'ARTICULO|'
                     ||'CAMPAÑA|'
                     ||'CONDICION|'
                     ||'PROVEEDOR CUPO|'
                     ||'PROVEEDOR CUPO CUIT|'
                     ||'TITULAR CP TIPO|'
                     ||'TITULAR CP|'
                     ||'TITULAR CP CUIT|'
                     ||'INTERMEDIARIO TIPO|'
                     ||'INTERMEDIARIO|'
                     ||'INTERMEDIARIO CUIT|'
                     ||'RTTE COMERCIAL TIPO|'
                     ||'RTTE COMERCIAL|'
                     ||'RTTE COMERCIAL CUIT|'
                     ||'RTTE COMERCIAL SUCURSAL|'
                     ||'CORREDOR|'
                     ||'CORREDOR CUIT|'
                     ||'MERCADO TERMINO|'
                     ||'MERCADO TERMINO CUIT|'
                     ||'CORREDOR VENDEDOR|'
                     ||'CORREDOR VENDEDOR CUIT|'
                     ||'REPRESENTANTE|'
                     ||'REPRESENTANTE CUIT|'
                     ||'DESTINATARIO|'
                     ||'DESTINATARIO CUIT|'
                     ||'DESTINO|'
                     ||'DESTINO CUIT|'
                     ||'DESTINO SUCURSAL|'
                     ||'DESTINO PROVINCIA|'
                     ||'DESTINO LOCALIDAD|'
                     ||'DESTINO DIRECCION|'
                     ||'PAGADOR FLETE|'
                     ||'PAGADOR FLETE CUIT|'
                     ||'KM RECORRER|'
                     ||'TARIFA IMPRESION|'
                     ||'PEDIDO VENTA|'
                     ||'OBSERVACIONES|'
                     ||'ORDEN CARGA|'
                     ||'NUMERO CARTA PORTE|'
                     ||'CANCELADO'
                       );
      FOR rCupos IN cCupos (rOC.orden_carga_id) LOOP
        -- Items
        l_item_oncca := NULL;
        OPEN cItems (rCupos.inventory_item_id);
        FETCH cItems INTO rItems;
        l_item_oncca := rItems.item_oncca_desc;
        l_item_desc  := rItems.item_description;
        CLOSE cItems;


        IF rCupos.destino_estab_id IS NOT NULL THEN
          IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rCupos.destino_cuit) THEN
            rEstab := NULL;
            OPEN cEstab (rCupos.destino_estab_id);
            FETCH cEstab INTO rEstab;
            l_destino_sucursal := rEstab.campo;
            CLOSE cEstab;

          ELSIF XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (rCupos.destino_cuit) THEN
            rLocation := NULL;
            OPEN cLocation ( rCupos.destino_id
                           , rCupos.destino_estab_id
                           );
            FETCH cLocation INTO rLocation;
            l_destino_sucursal := rLocation.address1;
            CLOSE cLocation;

          END IF;
        END IF;


        IF rCupos.rtte_comercial_estab_id IS NOT NULL THEN
          IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rCupos.rtte_comercial_cuit) THEN
            rEstab := NULL;
            OPEN cEstab (rCupos.rtte_comercial_estab_id);
            FETCH cEstab INTO rEstab;
            l_rtte_comercial_sucursal := rEstab.campo;
            CLOSE cEstab;

          ELSIF XX_TCG_FUNCTIONS_PKG.Valida_CUIT_DDBB (rCupos.rtte_comercial_cuit) THEN
            rLocation := NULL;
            OPEN cLocation ( rCupos.rtte_comercial_id
                           , rCupos.rtte_comercial_estab_id
                           );
            FETCH cLocation INTO rLocation;
            l_rtte_comercial_sucursal := rLocation.address1;
            CLOSE cLocation;

          END IF;
        END IF;

        l_carta_porte := rCupos.numero_carta_porte;
        IF l_carta_porte IS NULL THEN
          BEGIN
            SELECT SUBSTR(cpi.numero_carta_porte,1,4)||'-'||SUBSTR(cpi.numero_carta_porte,5,8)
            INTO l_carta_porte
            FROM xx_tcg_cartas_porte_interface cpi
            WHERE 1=1
            AND cpi.cupo_id = rCupos.cupo_id
            AND NOT EXISTS ( SELECT 1
                             FROM xx_aco_ctgs_b ctg
                             WHERE 1=1
                             AND REPLACE(ctg.nro_carta_porte,'-','') = cpi.numero_carta_porte
                             AND ctg.estado IN ('ANULADO', 'RECHAZADO')
                           );
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;

        FND_FILE.Put_Line(FND_FILE.OUTPUT, rCupos.cupo_tipo
                                    ||'|'||rCupos.cupo_numero
                                    ||'|'||TO_CHAR(rCupos.fecha_creacion, 'RRRR-MM-DD')
                                    ||'|'||TO_CHAR(rCupos.fecha_entrega, 'RRRR-MM-DD')
                                    ||'|'||rCupos.estado
                                    ||'|'||l_item_oncca
                                    ||'|'||l_item_desc
                                    ||'|'||rCupos.lot_no
                                    ||'|'||rCupos.condicion
                                    ||'|'||rCupos.cupo_dueno
                                    ||'|'||rCupos.cupo_dueno_cuit
                                    ||'|'||rCupos.titular_cp_tipo
                                    ||'|'||rCupos.titular_cp
                                    ||'|'||rCupos.titular_cp_cuit
                                    ||'|'||rCupos.intermediario_tipo
                                    ||'|'||rCupos.intermediario
                                    ||'|'||rCupos.intermediario_cuit
                                    ||'|'||rCupos.rtte_comercial_tipo
                                    ||'|'||rCupos.rtte_comercial
                                    ||'|'||rCupos.rtte_comercial_cuit
                                    ||'|'||l_rtte_comercial_sucursal
                                    ||'|'||rCupos.corredor
                                    ||'|'||rCupos.corredor_cuit
                                    ||'|'||rCupos.mercado_termino
                                    ||'|'||rCupos.mercado_termino_cuit
                                    ||'|'||rCupos.corredor_vendedor
                                    ||'|'||rCupos.corredor_vendedor_cuit
                                    ||'|'||rCupos.representante
                                    ||'|'||rCupos.representante_cuit
                                    ||'|'||rCupos.destinatario
                                    ||'|'||rCupos.destinatario_cuit
                                    ||'|'||rCupos.destino
                                    ||'|'||rCupos.destino_cuit
                                    ||'|'||l_destino_sucursal
                                    ||'|'||rCupos.destino_provincia
                                    ||'|'||rCupos.destino_localidad
                                    ||'|'||rCupos.destino_direccion
                                    ||'|'||rCupos.pagador_flete
                                    ||'|'||rCupos.pagador_flete_cuit
                                    ||'|'||rCupos.distancia_estimada
                                    ||'|'||rCupos.tarifa_impresion
                                    ||'|'||NULL --Pedido Venta
                                    ||'|'||rCupos.observaciones
                                    ||'|'||rCupos.orden_carga --Orden de Carga
                                    ||'|'||l_carta_porte
                                    ||'|'||rCupos.cancelado_flag
                                    );
      END LOOP; -- Loop Cupos

      FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
      FND_FILE.Put_Line(FND_FILE.OUTPUT, 'CAMIONES');
      --TITULOS OC Transporte
      FND_FILE.Put_Line(FND_FILE.OUTPUT,
                       'METODO SERVICIO|'
                     ||'TRANSPORTISTA|'
                     ||'TRANSPORTISTA CUIT|'
                     ||'CHOFER|'
                     ||'CHOFER CUIT|'
                     ||'PATENTE CAMION|'
                     ||'PATENTE ACOPLADO|'
                     ||'INTERMEDIARIO FLETE|'
                     ||'INTERMEDIARIO FLETE CUIT|'
                     ||'LOCALIDAD DESTINO|'
                     ||'OBSERVACIONES|'
                       );

      FOR rOCT IN cOCT (rOC.orden_carga_id) LOOP
        FND_FILE.Put_Line(FND_FILE.OUTPUT, rOCT.ship_method_meaning
                                    ||'|'||rOCT.transportista
                                    ||'|'||rOCT.transportista_cuit
                                    ||'|'||rOCT.chofer
                                    ||'|'||rOCT.chofer_cuit
                                    ||'|'||rOCT.patente_camion
                                    ||'|'||rOCT.patente_acoplado
                                    ||'|'||rOCT.intermediario_flete
                                    ||'|'||rOCT.intermediario_flete_cuit
                                    ||'|'||rOCT.localidad_destino
                                    ||'|'||rOCT.observaciones
                                        );
      END LOOP; -- Loop Transpo

      FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
      FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    END LOOP; --Loop OC

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_Orden_Carga;


  PROCEDURE Lista_Demanda_Camiones ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                   , p_errcode        IN OUT NOCOPY VARCHAR2
                                   , p_empresa        IN NUMBER
                                   , p_estab_id       IN NUMBER
                                   , p_fcarga_desde   IN VARCHAR2
                                   , p_fcarga_hasta   IN VARCHAR2
                                   ) IS
    CURSOR cDeca IS
      SELECT dc.empresa
           , dc.empresa_cuit
           , CASE WHEN XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_C (dc.empresa_cuit) = 'Y' THEN
                    (SELECT est.campo
                     FROM xx_opm_establecimientos est
                     WHERE establecimiento_id = dc.empresa_estab_id)
                  ELSE
                    (SELECT NVL(ps.party_site_name, l.address1) address1
                     FROM hz_party_sites ps, hz_locations l
                     WHERE 1=1
                     AND l.location_id = ps.location_id
                     AND ps.party_id   = dc.empresa_id
                     AND ps.party_site_id = dc.empresa_estab_id)
             END empresa_estab
           , TO_CHAR(dc.fecha_creacion, 'RRRR-MM-DD') fecha_creacion
           , dc.item_oncca_code
           , lv.description    grano
           , msi.segment1      item_no
           , msi.description   item_desc
           , dc.lot_no         campana
           , TO_CHAR(dc.fecha_carga, 'RRRR-MM-DD') fecha_carga
           , NVL(dc.cantidad_solicitada, 0) cantidad_solicitada
           , lvc.description   condicion
           , (SELECT COUNT(1)
              FROM xx_tcg_orden_carga       oc
                 , xx_tcg_orden_carga_cupos occ
              WHERE 1=1
              AND occ.orden_carga_id = oc.orden_carga_id
              AND NVL(occ.cancelado_flag,'N') = 'N'
              AND oc.demanda_camiones_id = dc.demanda_camiones_id
             ) cupos_asignados
           , 0 cupos_pendientes
           , (SELECT COUNT(1)
              FROM xx_tcg_orden_carga       oc
                 , xx_tcg_orden_carga_trans oct
              WHERE 1=1
              AND oct.orden_carga_id = oc.orden_carga_id
              AND NVL(oc.cancelado_flag,'N') = 'N'
              AND oc.demanda_camiones_id = dc.demanda_camiones_id
             ) camiones_asignados
           , (SELECT COUNT(1)
              FROM xx_tcg_orden_carga       oc
                 , xx_tcg_orden_carga_cupos occ
              WHERE 1=1
              AND occ.orden_carga_id = oc.orden_carga_id
              AND NVL(occ.cancelado_flag,'N') = 'N'
              AND ( EXISTS (SELECT 1 FROM xx_aco_ctgs_b repo WHERE repo.turno = occ.cupo_numero AND repo.estado NOT IN ('ANULADO', 'RECHAZADO') ) OR
                    EXISTS (SELECT 1 FROM xx_tcg_cartas_porte_interface cpi WHERE cpi.cupo_id = occ.cupo_id)
                  )
              AND oc.demanda_camiones_id = dc.demanda_camiones_id
             ) camiones_despachados
           , 0 camiones_pendientes
      FROM xx_tcg_demanda_camiones dc
         , mtl_system_items        msi
         , fnd_lookup_values_vl    lv
         , fnd_lookup_values_vl    lvc
      WHERE 1=1
      AND msi.organization_id(+)   = XX_TCG_FUNCTIONS_PKG.getMasterOrg
      AND msi.inventory_item_id(+) = dc.inventory_item_id
      AND lv.lookup_code(+)      = dc.item_oncca_code
      AND lvc.lookup_code(+)     = dc.condicion
      AND lv.lookup_type(+)      = 'XX_ACO_ESPECIES_ONCCA'
      AND lvc.lookup_type(+)     = 'XX_TCG_CONDICION_CUPOS'
      AND dc.fecha_carga BETWEEN TRUNC(NVL(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), dc.fecha_carga)) AND TRUNC(NVL(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), dc.fecha_carga))
      AND dc.empresa_id          = NVL(p_empresa, dc.empresa_id)
      AND dc.empresa_estab_id    = NVL(p_estab_id, dc.empresa_estab_id)
      ORDER BY dc.fecha_carga, 3
      ;


    rDeca                  cDeca%ROWTYPE;
    l_empresa              VARCHAR2(250);
    l_empresa_cuit         VARCHAR2(50);
    l_establecimiento      VARCHAR2(500);

  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '-------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado de Demanda de Camiones');
    FND_FILE.Put_Line(FND_FILE.Log, '-------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_empresa: '||p_empresa);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_estab_id: '||p_estab_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_desde: '||p_fcarga_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_hasta: '||p_fcarga_hasta);

    BEGIN
      SELECT vendor_name, num_1099||global_attribute12
      INTO l_empresa, l_empresa_cuit
      FROM ap_suppliers
      WHERE party_id = p_empresa
      ;
    EXCEPTION
      WHEN OTHERS THEN
        l_empresa := 'No Especificado';
    END;

    BEGIN
      IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_C (l_empresa_cuit) = 'Y' THEN
        SELECT est.campo
        INTO l_establecimiento
        FROM xx_opm_establecimientos est
        WHERE establecimiento_id = p_estab_id;
      ELSE
        SELECT l.address1
        INTO l_establecimiento
        FROM hz_party_sites ps, hz_locations l
        WHERE 1=1
        AND l.location_id = ps.location_id
        AND ps.party_id   = p_empresa
        AND ps.party_site_id = p_estab_id;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        l_establecimiento := 'No Especificado';
    END;

    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado de Demanda de Camiones');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Empresa:|'||l_empresa);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Establecimiento:|'||l_establecimiento);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Entrega Desde:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Entrega Hasta:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    --TITULOS
    FND_FILE.Put_Line(FND_FILE.OUTPUT,
                     'EMPRESA|'
                   ||'EMPRESA CUIT|'
                   ||'EMPRESA ESTABLECIMIENTO|'
                   ||'FECHA CREACION|'
                   ||'GRANO|'
                   ||'PRODUCTO|'
                   ||'PRODUCTO DESCRIPCION|'
                   ||'CAMPAÑA|'
                   ||'FECHA CARGA|'
                   ||'CANTIDAD SOLICITADA|'
                   ||'CONDICION|'
                   ||'CUPOS ASIGNADOS|'
                   ||'CUPOS PENDIENTES|'
                   ||'CAMIONES ASIGNADOS|'
                   ||'CAMIONES DESPACHADOS|'
                   ||'CAMIONES PENDIENTES|'
                     );
    FOR rDeca IN cDeca LOOP
      FND_FILE.Put_Line(FND_FILE.OUTPUT, rDeca.empresa
                                  ||'|'||rDeca.empresa_cuit
                                  ||'|'||rDeca.empresa_estab
                                  ||'|'||rDeca.fecha_creacion
                                  ||'|'||rDeca.grano
                                  ||'|'||rDeca.item_no
                                  ||'|'||rDeca.item_desc
                                  ||'|'||rDeca.campana
                                  ||'|'||rDeca.fecha_carga
                                  ||'|'||rDeca.cantidad_solicitada
                                  ||'|'||rDeca.condicion
                                  ||'|'||rDeca.cupos_asignados
                                  ||'|'||(rDeca.cantidad_solicitada - rDeca.cupos_asignados) --cupos_pendientes
                                  ||'|'||rDeca.camiones_asignados
                                  ||'|'||rDeca.camiones_despachados
                                  ||'|'||(rDeca.cantidad_solicitada - rDeca.camiones_asignados) --camiones_pendientes
                                  );

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_Demanda_Camiones;


  PROCEDURE QR_Interme_Incompatible ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                    , p_errcode        IN OUT NOCOPY VARCHAR2
                                    , p_adm_vendor_id  IN NUMBER
                                    ) IS
    CURSOR cMain IS
      SELECT ap.adm_vendor_id, s.vendor_name, ap.intermediario_flag
      FROM xx_opm_admin_proveedores ap
         , ap_suppliers             s
      WHERE 1=1
      AND s.vendor_id = ap.vendor_id
      AND ap.status   = 'ACTIVO'
      AND ap.intermediario_flag = 'Y'
      AND ap.adm_vendor_id      = NVL(p_adm_vendor_id, ap.adm_vendor_id)
      ;

    CURSOR cQR (p_adm_vendor_id NUMBER) IS
      SELECT qrp.*
      FROM xx_opm_qr_proveedores_v    qrp
      WHERE 1=1
      AND adm_vendor_id = p_adm_vendor_id
      AND status        = 'ACTIVO'
      ;

    CURSOR cDup ( p_qr_id          NUMBER
                , p_patente_v      VARCHAR2
                , p_patente_a      VARCHAR2
                , p_empleado_cuil  VARCHAR2
                ) IS
      SELECT qrp.*
      FROM xx_opm_qr_proveedores_v    qrp
      WHERE 1=1
      AND qr_id           != p_qr_id
      AND patente_veh_maq  = p_patente_v
      AND patente_acoplado = p_patente_a
      AND empleado_cuil    = p_empleado_cuil
      AND status           = 'ACTIVO'
      ;

  l_empresa VARCHAR2(500);
BEGIN
  FND_FILE.Put_Line(FND_FILE.Log, '--------------------------------------');
  FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG QR Intermediarios Incompatibles');
  FND_FILE.Put_Line(FND_FILE.Log, '--------------------------------------'||chr(10));
  FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
  FND_FILE.Put_Line(FND_FILE.Log, 'p_adm_vendor_id: '||p_adm_vendor_id);

  BEGIN
    SELECT s.vendor_name
    INTO l_empresa
    FROM xx_opm_admin_proveedores ap
       , ap_suppliers             s
    WHERE 1=1
    AND s.vendor_id = ap.vendor_id
    ;
  EXCEPTION
    WHEN OTHERS THEN
      l_empresa := 'No Especificado.';
  END;

  --Significado Params--
  FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
  FND_FILE.Put_Line(FND_FILE.Output, '<XXTCGQRINTINC>');
  FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX TCG QR Intermediarios Incompatibles</REPORT_NAME>');
  FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
  FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA>'||l_empresa||'</P_EMPRESA>');

  FOR rMain IN cMain LOOP
    FOR rQR IN cQR (rMain.adm_vendor_id) LOOP
      FOR rDup IN cDup (rQR.qr_id, rQR.patente_veh_maq, rQR.patente_acoplado, rQR.empleado_cuil) LOOP
        --DBMS_OUTPUT.PUT_LINE('Incompatibilidad: Empresa:'||rQR.vendor_name||' QR:'||rQR.qr_id||' con Empresa:'||rDup.vendor_name||' QR:'||rDup.qr_id||' '||rDup.patente_veh_maq||' '||rDup.patente_acoplado);
        FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <QR>'||rQR.qr_id||'</QR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <EMPRESA>'||rQR.vendor_name||'</EMPRESA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <EMPRESA_CUIT>'||rQR.vendor_cuit||'</EMPRESA_CUIT>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <QR_INCO>'||rDup.qr_id||'</QR_INCO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <EMPRESA_INCO>'||rDup.vendor_name||'</EMPRESA_INCO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <EMPRESA_CUIT_INCO>'||rDup.vendor_cuit||'</EMPRESA_CUIT_INCO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <PATENTE_VEH_MAQ>'||rDup.patente_veh_maq||'</PATENTE_VEH_MAQ>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <PATENTE_ACOPLADO>'||rDup.patente_acoplado||'</PATENTE_ACOPLADO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <EMPLEADO>'||rDup.empleado_nombre||'</EMPLEADO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <EMPLEADO_CUIL>'||REPLACE(rDup.empleado_cuil,'-','')||'</EMPLEADO_CUIL>');
        FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
      END LOOP;
    END LOOP;
  END LOOP;
  FND_FILE.Put_Line(FND_FILE.Output, '</XXTCGQRINTINC>');

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END QR_Interme_Incompatible;


  PROCEDURE Lista_CP_Sin_OCarga ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                , p_errcode        IN OUT NOCOPY VARCHAR2
                                , p_fcarga_desde   IN VARCHAR2
                                , p_fcarga_hasta   IN VARCHAR2
                                ) IS
    CURSOR cCP IS
      SELECT cp.numero_carta_porte
           , cp.item_oncca_code codigo_oncca
           , lv.description     descripcion_oncca
           , cp.lot_no
           , TO_CHAR(cp.fecha_carga, 'RRRR-MM-DD') fecha_carga
           , cp.titular_cp_cuit
           , cp.titular_cp
           , estab.campo titular_cp_estab
           , cp.intermediario_cuit
           , cp.intermediario
           , cp.rtte_comercial_cuit
           , cp.rtte_comercial
           , cp.corredor_cuit
           , cp.corredor
           , cp.mercado_termino_cuit
           , cp.mercado_termino
           , cp.corredor_vendedor_cuit
           , cp.corredor_vendedor
           , cp.representante_cuit
           , cp.representante
           , cp.destinatario_cuit
           , cp.destinatario
           , cp.destino_cuit
           , cp.destino
           , NVL(cp.peso_estimado, (cp.peso_bruto_envio - cp.tara_envio )) PESO
           , cp.transportista_cuit
           , cp.transportista_nombre
           , cp.intermediario_flete_cuit
           , cp.intermediario_flete
           , cp.chofer_cuit
           , cp.patente_camion
           , cp.patente_acoplado
           , cp.distancia_estimada km_recorrer
           , cp.tarifa_ref_flete_xton tarifa_ref_afip
           , cp.tarifa_cp_xton tarifa_impresion
           , s.vendor_name pagador_flete
           , cp.turno
           , cp.creation_date
           , cp.last_update_date
      FROM xx_tcg_cartas_porte  cp
         , fnd_lookup_values_vl lv
         , ap_suppliers         s
         , xx_opm_establecimientos estab
         , xx_tcg_cartas_porte_interface cpi
      WHERE 1=1
      AND estab.establecimiento_id = cp.titular_cp_estab_id
      AND lv.lookup_code           = cp.item_oncca_code
      AND lv.lookup_type           = 'XX_ACO_ESPECIES_ONCCA'
      AND s.party_id(+)            = cp.pagador_flete_id
      AND cp.numero_carta_porte    = cpi.numero_carta_porte
      AND cpi.cupo_id              = 0
      AND cp.fecha_carga BETWEEN TRUNC(NVL(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), cp.fecha_carga)) AND TRUNC(NVL(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), cp.fecha_carga))
      ORDER BY cp.fecha_carga, cp.numero_carta_porte
      ;

  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado CP sin Orden de Carga');
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_desde: '||p_fcarga_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_hasta: '||p_fcarga_hasta);


    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado CP sin Orden de Carga');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Desde:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Hasta:|'||TO_CHAR(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    --TITULOS
    FND_FILE.Put_Line(FND_FILE.OUTPUT,
                     'NUMERO_CARTA_PORTE|'
                   ||'CODIGO_ONCCA|'
                   ||'DESCRIPCION_ONCCA|'
                   ||'LOT_NO|'
                   ||'FECHA_CARGA|'
                   ||'TITULAR_CP_CUIT|'
                   ||'TITULAR_CP|'
                   ||'TITULAR_CP_ESTAB|'
                   ||'INTERMEDIARIO_CUIT|'
                   ||'INTERMEDIARIO|'
                   ||'RTTE_COMERCIAL_CUIT|'
                   ||'RTTE_COMERCIAL|'
                   ||'CORREDOR_CUIT|'
                   ||'CORREDOR|'
                   ||'MERCADO_TERMINO_CUIT|'
                   ||'MERCADO_TERMINO|'
                   ||'CORREDOR_VENDEDOR_CUIT|'
                   ||'CORREDOR_VENDEDOR|'
                   ||'REPRESENTANTE_CUIT|'
                   ||'REPRESENTANTE|'
                   ||'DESTINATARIO_CUIT|'
                   ||'DESTINATARIO|'
                   ||'DESTINO_CUIT|'
                   ||'DESTINO|'
                   ||'PESO|'
                   ||'TRANSPORTISTA_CUIT|'
                   ||'TRANSPORTISTA_NOMBRE|'
                   ||'INTERMEDIARIO_FLETE_CUIT|'
                   ||'INTERMEDIARIO_FLETE|'
                   ||'CHOFER_CUIT|'
                   ||'PATENTE_CAMION|'
                   ||'PATENTE_ACOPLADO|'
                   ||'KM_RECORRER|'
                   ||'TARIFA_REF_AFIP|'
                   ||'TARIFA_IMPRESION|'
                   ||'PAGADOR_FLETE|'
                    );
    FOR rCP IN cCP LOOP
      FND_FILE.Put_Line(FND_FILE.OUTPUT, rCP.NUMERO_CARTA_PORTE
                                  ||'|'||rCP.CODIGO_ONCCA
                                  ||'|'||rCP.DESCRIPCION_ONCCA
                                  ||'|'||rCP.LOT_NO
                                  ||'|'||rCP.FECHA_CARGA
                                  ||'|'||rCP.TITULAR_CP_CUIT
                                  ||'|'||rCP.TITULAR_CP
                                  ||'|'||rCP.TITULAR_CP_ESTAB
                                  ||'|'||rCP.INTERMEDIARIO_CUIT
                                  ||'|'||rCP.INTERMEDIARIO
                                  ||'|'||rCP.RTTE_COMERCIAL_CUIT
                                  ||'|'||rCP.RTTE_COMERCIAL
                                  ||'|'||rCP.CORREDOR_CUIT
                                  ||'|'||rCP.CORREDOR
                                  ||'|'||rCP.MERCADO_TERMINO_CUIT
                                  ||'|'||rCP.MERCADO_TERMINO
                                  ||'|'||rCP.CORREDOR_VENDEDOR_CUIT
                                  ||'|'||rCP.CORREDOR_VENDEDOR
                                  ||'|'||rCP.REPRESENTANTE_CUIT
                                  ||'|'||rCP.REPRESENTANTE
                                  ||'|'||rCP.DESTINATARIO_CUIT
                                  ||'|'||rCP.DESTINATARIO
                                  ||'|'||rCP.DESTINO_CUIT
                                  ||'|'||rCP.DESTINO
                                  ||'|'||rCP.PESO
                                  ||'|'||rCP.TRANSPORTISTA_CUIT
                                  ||'|'||rCP.TRANSPORTISTA_NOMBRE
                                  ||'|'||rCP.INTERMEDIARIO_FLETE_CUIT
                                  ||'|'||rCP.INTERMEDIARIO_FLETE
                                  ||'|'||rCP.CHOFER_CUIT
                                  ||'|'||rCP.PATENTE_CAMION
                                  ||'|'||rCP.PATENTE_ACOPLADO
                                  ||'|'||rCP.KM_RECORRER
                                  ||'|'||rCP.TARIFA_REF_AFIP
                                  ||'|'||rCP.TARIFA_IMPRESION
                                  ||'|'||rCP.PAGADOR_FLETE
                                  );

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_CP_Sin_OCarga;


  PROCEDURE Lista_CP_Interv_Modif_OC ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                     , p_errcode        IN OUT NOCOPY VARCHAR2
                                     , p_fcarga_desde   IN VARCHAR2
                                     , p_fcarga_hasta   IN VARCHAR2
                                     ) IS
    CURSOR cCP IS
      SELECT cpi.numero_carta_porte,
             cpi.grano_codigo_oncca codigo_oncca,
             lv.description         descripcion_oncca,
             cpi.campania,
             TO_CHAR(cpi.fecha_carga, 'RRRR-MM-DD') fecha_carga,
             cpi.titular_cp_cuit,
             s.vendor_name          titular_cp,
             cpi.titular_cp_establecimiento,
             cpi.intermediario_cuit,
             cpi.intermediario,
             cpi.rtte_comercial_cuit,
             cpi.rtte_comercial,
             cpi.corredor_cuit,
             cpi.corredor_comprador,
             cpi.mercado_termino_cuit,
             cpi.mercado_termino,
             cpi.corredor_vendedor_cuit,
             cpi.corredor_vendedor,
             cpi.representante_cuit,
             cpi.representante,
             cpi.destinatario_cuit,
             cpi.destinatario,
             cpi.destino_cuit,
             cpi.destino,
             NVL(cpi.peso_estimado, (cpi.peso_bruto_envio - cpi.peso_tara_envio )) peso,
             cpi.transportista_cuit,
             cpi.transportista,
             cpi.intermediario_flete_cuit,
             cpi.intermediario_flete,
             cpi.chofer_cuit,
             cpi.patente_camion,
             cpi.patente_acoplado,
             cpi.km_recorrer,
             cpi.tarifa_ref_afip,
             cpi.tarifa_impresion,
             cpi.pagador_flete
      FROM xx_tcg_cartas_porte_interface cpi,
           xx_tcg_orden_carga_cupos      occ,
           fnd_lookup_values_vl          lv,
           ap_suppliers                  s
      WHERE 1=1
      AND cpi.cupo_id       = occ.cupo_id
      AND lv.lookup_code(+) = cpi.grano_codigo_oncca
      AND lv.lookup_type(+) = 'XX_ACO_ESPECIES_ONCCA'
      AND s.num_1099||s.global_attribute12 = TO_CHAR(cpi.titular_cp_cuit)
      AND (NVL(cpi.titular_cp_cuit, '99')        <> NVL(occ.titular_cp_cuit, '99')        OR
           NVL(cpi.intermediario_cuit, '99')     <> NVL(occ.intermediario_cuit, '99')     OR
           NVL(cpi.rtte_comercial_cuit, '99')    <> NVL(occ.rtte_comercial_cuit, '99')    OR
           NVL(cpi.corredor_cuit, '99')          <> NVL(occ.corredor_cuit, '99')          OR
           NVL(cpi.mercado_termino_cuit, '99')   <> NVL(occ.mercado_termino_cuit, '99')   OR
           NVL(cpi.corredor_vendedor_cuit, '99') <> NVL(occ.corredor_vendedor_cuit, '99') OR
           NVL(cpi.representante_cuit, '99')     <> NVL(occ.representante_cuit, '99')     OR
           NVL(cpi.destinatario_cuit, '99')      <> NVL(occ.destinatario_cuit, '99')      OR
           NVL(cpi.destino_cuit, '99')           <> NVL(occ.destino_cuit, '99') )
      AND cpi.fecha_carga BETWEEN TRUNC(NVL(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga)) AND TRUNC(NVL(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga))
      ORDER BY cpi.fecha_carga, cpi.numero_carta_porte
      ;

  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado CP Intervinientes Modificados Orden de Carga');
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_desde: '||p_fcarga_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_hasta: '||p_fcarga_hasta);


    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado CP Intervinientes Modificados Orden de Carga');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Desde:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Hasta:|'||TO_CHAR(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    --TITULOS
    FND_FILE.Put_Line(FND_FILE.OUTPUT,
                     'NUMERO_CARTA_PORTE|'
                   ||'CODIGO_ONCCA|'
                   ||'DESCRIPCION_ONCCA|'
                   ||'CAMPANIA|'
                   ||'FECHA_CARGA|'
                   ||'TITULAR_CP_CUIT|'
                   ||'TITULAR_CP|'
                   ||'TITULAR_CP_ESTABLECIMIENTO|'
                   ||'INTERMEDIARIO_CUIT|'
                   ||'INTERMEDIARIO|'
                   ||'RTTE_COMERCIAL_CUIT|'
                   ||'RTTE_COMERCIAL|'
                   ||'CORREDOR_CUIT|'
                   ||'CORREDOR_COMPRADOR|'
                   ||'MERCADO_TERMINO_CUIT|'
                   ||'MERCADO_TERMINO|'
                   ||'CORREDOR_VENDEDOR_CUIT|'
                   ||'CORREDOR_VENDEDOR|'
                   ||'REPRESENTANTE_CUIT|'
                   ||'REPRESENTANTE|'
                   ||'DESTINATARIO_CUIT|'
                   ||'DESTINATARIO|'
                   ||'DESTINO_CUIT|'
                   ||'DESTINO|'
                   ||'NVL(CPI.PESO_ESTIMADO,(CPI.PESO_BRUTO_ENVIO-CPI.PESO_TARA_ENVIO))|'
                   ||'TRANSPORTISTA_CUIT|'
                   ||'TRANSPORTISTA|'
                   ||'INTERMEDIARIO_FLETE_CUIT|'
                   ||'INTERMEDIARIO_FLETE|'
                   ||'CHOFER_CUIT|'
                   ||'PATENTE_CAMION|'
                   ||'PATENTE_ACOPLADO|'
                   ||'KM_RECORRER|'
                   ||'TARIFA_REF_AFIP|'
                   ||'TARIFA_IMPRESION|'
                   ||'PAGADOR_FLETE|'
                   );
    FOR rCP IN cCP LOOP
      FND_FILE.Put_Line(FND_FILE.OUTPUT, rCP.NUMERO_CARTA_PORTE
                                  ||'|'||rCP.CODIGO_ONCCA
                                  ||'|'||rCP.DESCRIPCION_ONCCA
                                  ||'|'||rCP.CAMPANIA
                                  ||'|'||rCP.FECHA_CARGA
                                  ||'|'||rCP.TITULAR_CP_CUIT
                                  ||'|'||rCP.TITULAR_CP
                                  ||'|'||rCP.TITULAR_CP_ESTABLECIMIENTO
                                  ||'|'||rCP.INTERMEDIARIO_CUIT
                                  ||'|'||rCP.INTERMEDIARIO
                                  ||'|'||rCP.RTTE_COMERCIAL_CUIT
                                  ||'|'||rCP.RTTE_COMERCIAL
                                  ||'|'||rCP.CORREDOR_CUIT
                                  ||'|'||rCP.CORREDOR_COMPRADOR
                                  ||'|'||rCP.MERCADO_TERMINO_CUIT
                                  ||'|'||rCP.MERCADO_TERMINO
                                  ||'|'||rCP.CORREDOR_VENDEDOR_CUIT
                                  ||'|'||rCP.CORREDOR_VENDEDOR
                                  ||'|'||rCP.REPRESENTANTE_CUIT
                                  ||'|'||rCP.REPRESENTANTE
                                  ||'|'||rCP.DESTINATARIO_CUIT
                                  ||'|'||rCP.DESTINATARIO
                                  ||'|'||rCP.DESTINO_CUIT
                                  ||'|'||rCP.DESTINO
                                  ||'|'||rCP.PESO
                                  ||'|'||rCP.TRANSPORTISTA_CUIT
                                  ||'|'||rCP.TRANSPORTISTA
                                  ||'|'||rCP.INTERMEDIARIO_FLETE_CUIT
                                  ||'|'||rCP.INTERMEDIARIO_FLETE
                                  ||'|'||rCP.CHOFER_CUIT
                                  ||'|'||rCP.PATENTE_CAMION
                                  ||'|'||rCP.PATENTE_ACOPLADO
                                  ||'|'||rCP.KM_RECORRER
                                  ||'|'||rCP.TARIFA_REF_AFIP
                                  ||'|'||rCP.TARIFA_IMPRESION
                                  ||'|'||rCP.PAGADOR_FLETE
                                  );

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_CP_Interv_Modif_OC;


  PROCEDURE Lista_CP_Trans_Prov_OC ( p_errbuf         IN OUT NOCOPY VARCHAR2
                                   , p_errcode        IN OUT NOCOPY VARCHAR2
                                   , p_fcarga_desde   IN VARCHAR2
                                   , p_fcarga_hasta   IN VARCHAR2
                                   ) IS
    CURSOR cCP IS
      SELECT *
        FROM
             (
              SELECT 'Provisorio' Tipo,
                     cpi.numero_carta_porte,
                     cpi.grano_codigo_oncca codigo_oncca,
                     lv.description         descripcion_oncca,
                     cpi.campania,
                     TO_CHAR(cpi.fecha_carga, 'RRRR-MM-DD') fecha_carga,
                     cpi.titular_cp_cuit,
                     s.vendor_name          titular_cp,
                     cpi.titular_cp_establecimiento,
                     cpi.intermediario_cuit,
                     cpi.intermediario,
                     cpi.rtte_comercial_cuit,
                     cpi.rtte_comercial,
                     cpi.corredor_cuit,
                     cpi.corredor_comprador,
                     cpi.mercado_termino_cuit,
                     cpi.mercado_termino,
                     cpi.corredor_vendedor_cuit,
                     cpi.corredor_vendedor,
                     cpi.representante_cuit,
                     cpi.representante,
                     cpi.destinatario_cuit,
                     cpi.destinatario,
                     cpi.destino_cuit,
                     cpi.destino,
                     NVL(cpi.peso_estimado, (cpi.peso_bruto_envio - cpi.peso_tara_envio )) peso,
                     cpi.transportista_cuit,
                     cpi.transportista,
                     cpi.intermediario_flete_cuit,
                     cpi.intermediario_flete,
                     cpi.chofer_cuit,
                     cpi.patente_camion,
                     cpi.patente_acoplado,
                     cpi.km_recorrer,
                     cpi.tarifa_ref_afip,
                     cpi.tarifa_impresion,
                     cpi.pagador_flete
              FROM xx_tcg_cartas_porte_interface cpi,
                   fnd_lookup_values_vl          lv,
                   ap_suppliers                  s,
                   ( SELECT s.num_1099||s.global_attribute12 transportista_cuit
                     FROM ap_suppliers s
                     WHERE 1=1
                     AND s.vendor_type_lookup_code = 'TRANSPORTADOR'
                     AND NOT EXISTS (SELECT 1 FROM ap_supplier_sites_all vs WHERE vs.vendor_id = s.vendor_id)
                   ) st
              WHERE 1=1
              AND lv.lookup_code = cpi.grano_codigo_oncca
              AND lv.lookup_type = 'XX_ACO_ESPECIES_ONCCA'
              AND s.num_1099||s.global_attribute12 = TO_CHAR(cpi.titular_cp_cuit)
              AND st.transportista_cuit            = NVL(TO_CHAR(cpi.intermediario_flete_cuit),TO_CHAR(cpi.transportista_cuit))
              AND cpi.fecha_carga BETWEEN TRUNC(NVL(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga)) AND TRUNC(NVL(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga))
              --
              UNION ALL
              --
              SELECT 'NoExiste' Tipo,
                     cpi.numero_carta_porte,
                     cpi.grano_codigo_oncca codigo_oncca,
                     lv.description         descripcion_oncca,
                     cpi.campania,
                     TO_CHAR(cpi.fecha_carga, 'RRRR-MM-DD') fecha_carga,
                     cpi.titular_cp_cuit,
                     s.vendor_name          titular_cp,
                     cpi.titular_cp_establecimiento,
                     cpi.intermediario_cuit,
                     cpi.intermediario,
                     cpi.rtte_comercial_cuit,
                     cpi.rtte_comercial,
                     cpi.corredor_cuit,
                     cpi.corredor_comprador,
                     cpi.mercado_termino_cuit,
                     cpi.mercado_termino,
                     cpi.corredor_vendedor_cuit,
                     cpi.corredor_vendedor,
                     cpi.representante_cuit,
                     cpi.representante,
                     cpi.destinatario_cuit,
                     cpi.destinatario,
                     cpi.destino_cuit,
                     cpi.destino,
                     NVL(cpi.peso_estimado, (cpi.peso_bruto_envio - cpi.peso_tara_envio )) peso,
                     cpi.transportista_cuit,
                     cpi.transportista,
                     cpi.intermediario_flete_cuit,
                     cpi.intermediario_flete,
                     cpi.chofer_cuit,
                     cpi.patente_camion,
                     cpi.patente_acoplado,
                     cpi.km_recorrer,
                     cpi.tarifa_ref_afip,
                     cpi.tarifa_impresion,
                     cpi.pagador_flete
              FROM xx_tcg_cartas_porte_interface cpi,
                   fnd_lookup_values_vl          lv,
                   ap_suppliers                  s
              WHERE 1=1
              AND lv.lookup_code = cpi.grano_codigo_oncca
              AND lv.lookup_type = 'XX_ACO_ESPECIES_ONCCA'
              AND s.num_1099||s.global_attribute12 = TO_CHAR(cpi.titular_cp_cuit)
              AND NOT EXISTS ( SELECT 1
                                 FROM ap_suppliers st
                                WHERE 1=1
                                  AND st.vendor_type_lookup_code = 'TRANSPORTADOR'
                                  AND st.num_1099||st.global_attribute12 =  NVL(TO_CHAR(cpi.intermediario_flete_cuit),TO_CHAR(cpi.transportista_cuit))
                              )
              AND cpi.fecha_carga BETWEEN TRUNC(NVL(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga)) AND TRUNC(NVL(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga))
             )
      ORDER BY fecha_carga, numero_carta_porte
      ;

  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado CP con OC Transportista Provisorio');
    FND_FILE.Put_Line(FND_FILE.Log, '------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_desde: '||p_fcarga_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_hasta: '||p_fcarga_hasta);


    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado CP con OC Transportista Provisorio');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Desde:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Hasta:|'||TO_CHAR(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    --TITULOS
    FND_FILE.Put_Line(FND_FILE.OUTPUT,
                     'TIPO|'
                   ||'NUMERO_CARTA_PORTE|'
                   ||'CODIGO_ONCCA|'
                   ||'DESCRIPCION_ONCCA|'
                   ||'CAMPANIA|'
                   ||'FECHA_CARGA|'
                   ||'TITULAR_CP_CUIT|'
                   ||'TITULAR_CP|'
                   ||'TITULAR_CP_ESTABLECIMIENTO|'
                   ||'INTERMEDIARIO_CUIT|'
                   ||'INTERMEDIARIO|'
                   ||'RTTE_COMERCIAL_CUIT|'
                   ||'RTTE_COMERCIAL|'
                   ||'CORREDOR_CUIT|'
                   ||'CORREDOR_COMPRADOR|'
                   ||'MERCADO_TERMINO_CUIT|'
                   ||'MERCADO_TERMINO|'
                   ||'CORREDOR_VENDEDOR_CUIT|'
                   ||'CORREDOR_VENDEDOR|'
                   ||'REPRESENTANTE_CUIT|'
                   ||'REPRESENTANTE|'
                   ||'DESTINATARIO_CUIT|'
                   ||'DESTINATARIO|'
                   ||'DESTINO_CUIT|'
                   ||'DESTINO|'
                   ||'NVL(CPI.PESO_ESTIMADO,(CPI.PESO_BRUTO_ENVIO-CPI.PESO_TARA_ENVIO))|'
                   ||'TRANSPORTISTA_CUIT|'
                   ||'TRANSPORTISTA|'
                   ||'INTERMEDIARIO_FLETE_CUIT|'
                   ||'INTERMEDIARIO_FLETE|'
                   ||'CHOFER_CUIT|'
                   ||'PATENTE_CAMION|'
                   ||'PATENTE_ACOPLADO|'
                   ||'KM_RECORRER|'
                   ||'TARIFA_REF_AFIP|'
                   ||'TARIFA_IMPRESION|'
                   ||'PAGADOR_FLETE|'
                   );
    FOR rCP IN cCP LOOP
      FND_FILE.Put_Line(FND_FILE.OUTPUT, rcp.TIPO
                                  ||'|'||rCP.NUMERO_CARTA_PORTE
                                  ||'|'||rCP.CODIGO_ONCCA
                                  ||'|'||rCP.DESCRIPCION_ONCCA
                                  ||'|'||rCP.CAMPANIA
                                  ||'|'||rCP.FECHA_CARGA
                                  ||'|'||rCP.TITULAR_CP_CUIT
                                  ||'|'||rCP.TITULAR_CP
                                  ||'|'||rCP.TITULAR_CP_ESTABLECIMIENTO
                                  ||'|'||rCP.INTERMEDIARIO_CUIT
                                  ||'|'||rCP.INTERMEDIARIO
                                  ||'|'||rCP.RTTE_COMERCIAL_CUIT
                                  ||'|'||rCP.RTTE_COMERCIAL
                                  ||'|'||rCP.CORREDOR_CUIT
                                  ||'|'||rCP.CORREDOR_COMPRADOR
                                  ||'|'||rCP.MERCADO_TERMINO_CUIT
                                  ||'|'||rCP.MERCADO_TERMINO
                                  ||'|'||rCP.CORREDOR_VENDEDOR_CUIT
                                  ||'|'||rCP.CORREDOR_VENDEDOR
                                  ||'|'||rCP.REPRESENTANTE_CUIT
                                  ||'|'||rCP.REPRESENTANTE
                                  ||'|'||rCP.DESTINATARIO_CUIT
                                  ||'|'||rCP.DESTINATARIO
                                  ||'|'||rCP.DESTINO_CUIT
                                  ||'|'||rCP.DESTINO
                                  ||'|'||rCP.PESO
                                  ||'|'||rCP.TRANSPORTISTA_CUIT
                                  ||'|'||rCP.TRANSPORTISTA
                                  ||'|'||rCP.INTERMEDIARIO_FLETE_CUIT
                                  ||'|'||rCP.INTERMEDIARIO_FLETE
                                  ||'|'||rCP.CHOFER_CUIT
                                  ||'|'||rCP.PATENTE_CAMION
                                  ||'|'||rCP.PATENTE_ACOPLADO
                                  ||'|'||rCP.KM_RECORRER
                                  ||'|'||rCP.TARIFA_REF_AFIP
                                  ||'|'||rCP.TARIFA_IMPRESION
                                  ||'|'||rCP.PAGADOR_FLETE
                                  );

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_CP_Trans_Prov_OC;



  PROCEDURE Lista_Interface_CP ( p_errbuf         IN OUT NOCOPY VARCHAR2
                               , p_errcode        IN OUT NOCOPY VARCHAR2
                               , p_fcarga_desde   IN VARCHAR2
                               , p_fcarga_hasta   IN VARCHAR2
                               , p_importado      IN VARCHAR2
                               , p_modifpostimp   IN VARCHAR2
                               ) IS

    CURSOR cCP IS
      SELECT cpi.numero_carta_porte,
             cpi.grano_codigo_oncca codigo_oncca,
             lv.description         descripcion_oncca,
             cpi.campania,
             TO_CHAR(cpi.fecha_carga, 'RRRR-MM-DD') fecha_carga,
             cpi.titular_cp_cuit,
             s.vendor_name          titular_cp,
             cpi.titular_cp_establecimiento,
             cpi.intermediario_cuit,
             cpi.intermediario,
             cpi.rtte_comercial_cuit,
             cpi.rtte_comercial,
             cpi.corredor_cuit,
             cpi.corredor_comprador,
             cpi.mercado_termino_cuit,
             cpi.mercado_termino,
             cpi.corredor_vendedor_cuit,
             cpi.corredor_vendedor,
             cpi.representante_cuit,
             cpi.representante,
             cpi.destinatario_cuit,
             cpi.destinatario,
             cpi.destino_cuit,
             cpi.destino,
             NVL(cpi.peso_estimado, (cpi.peso_bruto_envio - cpi.peso_tara_envio )) peso,
             cpi.transportista_cuit,
             cpi.transportista,
             cpi.intermediario_flete_cuit,
             cpi.intermediario_flete,
             cpi.chofer_cuit,
             cpi.patente_camion,
             cpi.patente_acoplado,
             cpi.km_recorrer,
             cpi.tarifa_ref_afip,
             cpi.tarifa_impresion,
             cpi.pagador_flete,
             cpi.importado_flag,
             cpi.modifpostimp_flag,
             cpi.orden_carga_id,
             cup.cupo_numero
      FROM xx_tcg_cartas_porte_interface cpi,
           fnd_lookup_values_vl          lv,
           ap_suppliers                  s,
           xx_tcg_cupos                  cup
      WHERE 1=1
      AND lv.lookup_code = cpi.grano_codigo_oncca
      AND lv.lookup_type = 'XX_ACO_ESPECIES_ONCCA'
      AND cpi.cupo_id    = cup.cupo_id (+)
      AND s.num_1099||s.global_attribute12 = TO_CHAR(cpi.titular_cp_cuit)
      AND cpi.fecha_carga BETWEEN TRUNC(NVL(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga)) AND TRUNC(NVL(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), cpi.fecha_carga))
      AND (p_importado IS NULL OR
           cpi.importado_flag = p_importado
           )
      AND (p_modifpostimp IS NULL OR
           cpi.modifpostimp_flag = p_modifpostimp
           )
      ORDER BY cpi.fecha_carga, cpi.numero_carta_porte
      ;

  BEGIN

    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX TCG Listado Interface Carta de Porte');
    FND_FILE.Put_Line(FND_FILE.Log, '---------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_desde: '||p_fcarga_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fcarga_hasta: '||p_fcarga_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_importado: '||p_importado);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_modifpostimp: '||p_modifpostimp);


    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'XX TCG Listado Interface Carta de Porte');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Emisión:|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Desde:|'||TO_CHAR(TO_DATE(p_fcarga_desde, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Fecha Carga Hasta:|'||TO_CHAR(TO_DATE(p_fcarga_hasta, 'RRRR-MM-DD HH24:MI:SS'), 'RRRR-MM-DD'));
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Importado:|'||p_importado);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Modif.Luego Importado:|'|| p_modifpostimp);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    --TITULOS
    FND_FILE.Put_Line(FND_FILE.OUTPUT,
                     'NUMERO_CARTA_PORTE|'
                   ||'CODIGO_ONCCA|'
                   ||'DESCRIPCION_ONCCA|'
                   ||'CAMPANIA|'
                   ||'FECHA_CARGA|'
                   ||'TITULAR_CP_CUIT|'
                   ||'TITULAR_CP|'
                   ||'TITULAR_CP_ESTABLECIMIENTO|'
                   ||'INTERMEDIARIO_CUIT|'
                   ||'INTERMEDIARIO|'
                   ||'RTTE_COMERCIAL_CUIT|'
                   ||'RTTE_COMERCIAL|'
                   ||'CORREDOR_CUIT|'
                   ||'CORREDOR_COMPRADOR|'
                   ||'MERCADO_TERMINO_CUIT|'
                   ||'MERCADO_TERMINO|'
                   ||'CORREDOR_VENDEDOR_CUIT|'
                   ||'CORREDOR_VENDEDOR|'
                   ||'REPRESENTANTE_CUIT|'
                   ||'REPRESENTANTE|'
                   ||'DESTINATARIO_CUIT|'
                   ||'DESTINATARIO|'
                   ||'DESTINO_CUIT|'
                   ||'DESTINO|'
                   ||'NVL(CPI.PESO_ESTIMADO,(CPI.PESO_BRUTO_ENVIO-CPI.PESO_TARA_ENVIO))|'
                   ||'TRANSPORTISTA_CUIT|'
                   ||'TRANSPORTISTA|'
                   ||'INTERMEDIARIO_FLETE_CUIT|'
                   ||'INTERMEDIARIO_FLETE|'
                   ||'CHOFER_CUIT|'
                   ||'PATENTE_CAMION|'
                   ||'PATENTE_ACOPLADO|'
                   ||'KM_RECORRER|'
                   ||'TARIFA_REF_AFIP|'
                   ||'TARIFA_IMPRESION|'
                   ||'PAGADOR_FLETE|'
                   ||'IMPORTADO|'
                   ||'MODIF_LUEGO_IMPORTADO|'
                   ||'ORDEN_CARGA_ID|'
                   ||'CUPO_NUMERO|'
                   );

    FOR rCP IN cCP LOOP
      FND_FILE.Put_Line(FND_FILE.OUTPUT, rCP.NUMERO_CARTA_PORTE
                                  ||'|'||rCP.CODIGO_ONCCA
                                  ||'|'||rCP.DESCRIPCION_ONCCA
                                  ||'|'||rCP.CAMPANIA
                                  ||'|'||rCP.FECHA_CARGA
                                  ||'|'||rCP.TITULAR_CP_CUIT
                                  ||'|'||rCP.TITULAR_CP
                                  ||'|'||rCP.TITULAR_CP_ESTABLECIMIENTO
                                  ||'|'||rCP.INTERMEDIARIO_CUIT
                                  ||'|'||rCP.INTERMEDIARIO
                                  ||'|'||rCP.RTTE_COMERCIAL_CUIT
                                  ||'|'||rCP.RTTE_COMERCIAL
                                  ||'|'||rCP.CORREDOR_CUIT
                                  ||'|'||rCP.CORREDOR_COMPRADOR
                                  ||'|'||rCP.MERCADO_TERMINO_CUIT
                                  ||'|'||rCP.MERCADO_TERMINO
                                  ||'|'||rCP.CORREDOR_VENDEDOR_CUIT
                                  ||'|'||rCP.CORREDOR_VENDEDOR
                                  ||'|'||rCP.REPRESENTANTE_CUIT
                                  ||'|'||rCP.REPRESENTANTE
                                  ||'|'||rCP.DESTINATARIO_CUIT
                                  ||'|'||rCP.DESTINATARIO
                                  ||'|'||rCP.DESTINO_CUIT
                                  ||'|'||rCP.DESTINO
                                  ||'|'||rCP.PESO
                                  ||'|'||rCP.TRANSPORTISTA_CUIT
                                  ||'|'||rCP.TRANSPORTISTA
                                  ||'|'||rCP.INTERMEDIARIO_FLETE_CUIT
                                  ||'|'||rCP.INTERMEDIARIO_FLETE
                                  ||'|'||rCP.CHOFER_CUIT
                                  ||'|'||rCP.PATENTE_CAMION
                                  ||'|'||rCP.PATENTE_ACOPLADO
                                  ||'|'||rCP.KM_RECORRER
                                  ||'|'||rCP.TARIFA_REF_AFIP
                                  ||'|'||rCP.TARIFA_IMPRESION
                                  ||'|'||rCP.PAGADOR_FLETE
                                  ||'|'||rCP.IMPORTADO_FLAG
                                  ||'|'||rCP.MODIFPOSTIMP_FLAG
                                  ||'|'||rCP.ORDEN_CARGA_ID
                                  ||'|'||rCP.CUPO_NUMERO
                                  );

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Lista_Interface_CP;



END;
/

exit
