#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2521_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2521
# |
# | HISTORY
# |   28-JUL-20  Petrocelli, Ariel Alejandro
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2521_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2521_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2521
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/RESPO
mkdir -p au/12.0.0/forms/US/
mkdir -p au/12.0.0/resource/
mkdir -p xbol/12.0.0/sql/ALTER
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2521" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2521_9582.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2521"
AddAllLogs $CROUT "FND" "CR2521_9582.ldt"
mv CR2521_9582.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_TCG_ORDEN_CARGA " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_TCG_ORDEN_CARGA','BOLINF','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_ORDEN_CARGA* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_TCG_ORDEN_CARGA_CUPOS " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_TCG_ORDEN_CARGA_CUPOS','BOLINF','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_ORDEN_CARGA_CUPOS* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_TCG_ORDEN_CARGA_TRANS " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_TCG_ORDEN_CARGA_TRANS','BOLINF','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_ORDEN_CARGA_TRANS* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_TCG_CUPOS " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_TCG_CUPOS','BOLINF','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_CUPOS* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_TCG_ORDEN_CARGA_CUPOS_TMP " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_TCG_ORDEN_CARGA_CUPOS_TMP','BOLINF','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_ORDEN_CARGA_CUPOS_TMP* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-ALTER DROP_TABLE " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('ALTER','DROP_TABLE','','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv DROP_TABLE* $DOWNDBDIR/xbol/12.0.0/sql/ALTER

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_TCG_ORDEN_CARGA_S " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_TCG_ORDEN_CARGA_S','APPS','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_ORDEN_CARGA_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF SYN_BOL " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','SYN_BOL','','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv SYN_BOL* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF SYN_STG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','SYN_STG','','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv SYN_STG* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_TCG_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_TCG_REPORTES_PKG','APPS','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_REPORTES_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_TCG_IMPORTACION_CP_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_TCG_IMPORTACION_CP_PKG','APPS','$PATCHDIR','CR2521');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_TCG_IMPORTACION_CP_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXTCGOCARGA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXTCGOCARGA.ldt FUNCTION FUNCTION_NAME="XXTCGOCARGA"
AddAllLogs $CROUT "FND" "XXTCGOCARGA.ldt"
mv XXTCGOCARGA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXTCGOCARGA_Q " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXTCGOCARGA_Q.ldt FUNCTION FUNCTION_NAME="XXTCGOCARGA_Q"
AddAllLogs $CROUT "FND" "XXTCGOCARGA_Q.ldt"
mv XXTCGOCARGA_Q.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_ACO_CONFIGURADOR_FLETE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_ACO_CONFIGURADOR_FLETE.ldt MENU MENU_NAME="XX_ACO_CONFIGURADOR_FLETE"
AddAllLogs $CROUT "FND" "XX_ACO_CONFIGURADOR_FLETE.ldt"
mv XX_ACO_CONFIGURADOR_FLETE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-RESPO XX_OPM_ADMIN_TRANSPORTISTA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscursp.lct XX_OPM_ADMIN_TRANSPORTISTA.ldt FND_RESPONSIBILITY RESP_KEY="XX_OPM_ADMIN_TRANSPORTISTA"
AddAllLogs $CROUT "FND" "XX_OPM_ADMIN_TRANSPORTISTA.ldt"
mv XX_OPM_ADMIN_TRANSPORTISTA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/RESPO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXTCGLISTOCARGA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXTCGLISTOCARGA.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXTCGLISTOCARGA"
AddAllLogs $CROUT "FND" "XXTCGLISTOCARGA.ldt"
mv XXTCGLISTOCARGA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXTCGCPINTMODOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXTCGCPINTMODOC.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXTCGCPINTMODOC"
AddAllLogs $CROUT "FND" "XXTCGCPINTMODOC.ldt"
mv XXTCGCPINTMODOC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXTCGCPSOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXTCGCPSOC.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXTCGCPSOC"
AddAllLogs $CROUT "FND" "XXTCGCPSOC.ldt"
mv XXTCGCPSOC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXTCGTRANSPROVOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXTCGTRANSPROVOC.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXTCGTRANSPROVOC"
AddAllLogs $CROUT "FND" "XXTCGTRANSPROVOC.ldt"
mv XXTCGTRANSPROVOC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXTCGIOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXTCGIOC.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXTCGIOC"
AddAllLogs $CROUT "FND" "XXTCGIOC.ldt"
mv XXTCGIOC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXTCGINTCP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXTCGINTCP.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXTCGINTCP"
AddAllLogs $CROUT "FND" "XXTCGINTCP.ldt"
mv XXTCGINTCP.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt DESC_FLEX APPLICATION_SHORT_NAME="XBOL" DESCRIPTIVE_FLEXFIELD_NAME="XX_OPM_ESTABLECIMIENTOS" DESCRIPTIVE_FLEX_CONTEXT_CODE="AR" END_USER_COLUMN_NAME="XX_TCG_ZONA_DESTINO"
AddAllLogs $CROUT "FND" "XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt"
mv XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXTCGDECA " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXTCGDECA.fmb ]; then
  cp $AU_TOP/forms/US/XXTCGDECA.fmb XXTCGDECA.fmb
  echo `ls -lh XXTCGDECA.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXTCGDECA.fmb no existe" >> $CROUT
fi
mv XXTCGDECA* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXTCGCUPOS " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXTCGCUPOS.fmb ]; then
  cp $AU_TOP/forms/US/XXTCGCUPOS.fmb XXTCGCUPOS.fmb
  echo `ls -lh XXTCGCUPOS.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXTCGCUPOS.fmb no existe" >> $CROUT
fi
mv XXTCGCUPOS* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXTCGOCARGA " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXTCGOCARGA.fmb ]; then
  cp $AU_TOP/forms/US/XXTCGOCARGA.fmb XXTCGOCARGA.fmb
  echo `ls -lh XXTCGOCARGA.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXTCGOCARGA.fmb no existe" >> $CROUT
fi
mv XXTCGOCARGA* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXTCGIMPCP " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXTCGIMPCP.fmb ]; then
  cp $AU_TOP/forms/US/XXTCGIMPCP.fmb XXTCGIMPCP.fmb
  echo `ls -lh XXTCGIMPCP.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXTCGIMPCP.fmb no existe" >> $CROUT
fi
mv XXTCGIMPCP* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto PLL- XXTCGCP.pll " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/resource/XXTCGCP.pll ]; then
  cp $AU_TOP/resource/XXTCGCP.pll XXTCGCP.pll
  echo `ls -lh XXTCGCP.pll` >> $CROUT
else
 echo " El archivo $AU_TOP/resource/XXTCGCP.pll no existe" >> $CROUT
fi
mv XXTCGCP.pll* $DOWNDBDIR/au/12.0.0/resource/


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-ALTER DROP_TABLE " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/ALTER/DROP_TABLE >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/ALTER/DROP_TABLE.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/ALTER/DROP_TABLE.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/ALTER >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/ALTER/DROP_TABLE.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/ALTER/DROP_TABLE.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/ALTER >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/ALTER/DROP_TABLE.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_TCG_ORDEN_CARGA " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_TCG_ORDEN_CARGA_CUPOS " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_TCG_ORDEN_CARGA_TRANS " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_TRANS >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_TRANS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_TRANS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_TRANS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_TRANS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_TRANS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_TCG_CUPOS " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_CUPOS >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_CUPOS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_CUPOS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_CUPOS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_CUPOS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_CUPOS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_TCG_ORDEN_CARGA_CUPOS_TMP " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS_TMP >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS_TMP.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS_TMP.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS_TMP.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS_TMP.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_TCG_ORDEN_CARGA_CUPOS_TMP.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-SEQ XX_TCG_ORDEN_CARGA_S " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/SEQ/XX_TCG_ORDEN_CARGA_S >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/XX_TCG_ORDEN_CARGA_S.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/SEQ/XX_TCG_ORDEN_CARGA_S.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/XX_TCG_ORDEN_CARGA_S.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/SEQ/XX_TCG_ORDEN_CARGA_S.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/XX_TCG_ORDEN_CARGA_S.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF SYN_BOL " >> $CROUT; echo "" >> $CROUT
sqlplus -s bolinf/$BOLINF_PWD @$INSTDIR/xbol/12.0.0/sql/DF/SYN_BOL >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYN_BOL.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/SYN_BOL.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYN_BOL.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/SYN_BOL.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYN_BOL.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF SYN_STG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/SYN_STG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYN_STG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/SYN_STG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYN_STG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/SYN_STG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYN_STG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_TCG_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_TCG_REPORTES_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_TCG_REPORTES_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_TCG_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_TCG_REPORTES_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_TCG_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_TCG_REPORTES_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_TCG_IMPORTACION_CP_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_TCG_IMPORTACION_CP_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_TCG_IMPORTACION_CP_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_TCG_IMPORTACION_CP_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_TCG_IMPORTACION_CP_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_TCG_IMPORTACION_CP_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_TCG_IMPORTACION_CP_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-FUNC XXTCGOCARGA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-FUNC XXTCGOCARGA_Q " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXTCGOCARGA_Q.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-MENU XX_ACO_CONFIGURADOR_FLETE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_ACO_CONFIGURADOR_FLETE.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-RESPO XX_OPM_ADMIN_TRANSPORTISTA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscursp.lct $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_OPM_ADMIN_TRANSPORTISTA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXTCGLISTOCARGA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGLISTOCARGA' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGLISTOCARGA' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGLISTOCARGA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXTCGCPINTMODOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGCPINTMODOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGCPINTMODOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGCPINTMODOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGCPINTMODOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGCPINTMODOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGCPINTMODOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPINTMODOC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXTCGCPSOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGCPSOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGCPSOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGCPSOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGCPSOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGCPSOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGCPSOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGCPSOC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXTCGTRANSPROVOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGTRANSPROVOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGTRANSPROVOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGTRANSPROVOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGTRANSPROVOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGTRANSPROVOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGTRANSPROVOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGTRANSPROVOC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXTCGIOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGIOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGIOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGIOC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXTCGINTCP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGINTCP' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGINTCP' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO Consulta' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXTCGINTCP' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXTCGINTCP' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX ACO All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXTCGINTCP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/XX_OPM_ESTABLECIMIEN_AR_XXTCGZONADESTIN.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGDECA " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXTCGDECA.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXTCGDECA.fmb`" >> $CROUT
mv XXTCGDECA.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXTCGDECA.fmx` >> $CROUT
cd $CURDIR
if ! ls /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGDECA.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGDECA.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGDECA.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGDECA.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGDECA.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGCUPOS " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXTCGCUPOS.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXTCGCUPOS.fmb`" >> $CROUT
mv XXTCGCUPOS.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXTCGCUPOS.fmx` >> $CROUT
cd $CURDIR
if ! ls /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGCUPOS.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGCUPOS.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGCUPOS.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGCUPOS.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGCUPOS.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGOCARGA " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXTCGOCARGA.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXTCGOCARGA.fmb`" >> $CROUT
mv XXTCGOCARGA.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXTCGOCARGA.fmx` >> $CROUT
cd $CURDIR
if ! ls /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGOCARGA.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGOCARGA.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGOCARGA.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGOCARGA.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGOCARGA.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGIMPCP " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXTCGIMPCP.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXTCGIMPCP.fmb`" >> $CROUT
mv XXTCGIMPCP.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXTCGIMPCP.fmx` >> $CROUT
cd $CURDIR
if ! ls /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGIMPCP.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGIMPCP.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGIMPCP.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXTCGIMPCP.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXTCGIMPCP.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto PLL- XXTCGCP.pll " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
`cp $INSTDIR/au/12.0.0/resource/XXTCGCP.pll $AU_TOP/resource`
cd $AU_TOP/resource/
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXTCGCP.pll module_type=LIBRARY compile_all=YES`" >> $CROUT
echo `ls -lh $AU_TOP/resource/XXTCGCP.plx` >> $CROUT
cd $CURDIR
if ! ls /crp3/svn/XXADECUSTOMS/au/12.0.0/resource/XXTCGCP.pll &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/resource/XXTCGCP.pll /crp3/svn/XXADECUSTOMS/au/12.0.0/resource/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/au/12.0.0/resource/XXTCGCP.pll >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/resource/XXTCGCP.pll /crp3/svn/XXADECUSTOMS/au/12.0.0/resource/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/au/12.0.0/resource/XXTCGCP.pll -m $CRNUM  >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch











echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGDECA " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXTCGDECA.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXTCGDECA.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGCUPOS " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXTCGCUPOS.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXTCGCUPOS.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGOCARGA " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXTCGOCARGA.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXTCGOCARGA.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXTCGIMPCP " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXTCGIMPCP.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXTCGIMPCP.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto PLL- XXTCGCP.pll " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/resource/XXTCGCP.pll $AU_TOP/resource
CPFROM=$AU_TOP/resource/XXTCGCP.plx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $AU_TOP/resource/

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2521" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2521_9582.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2521_9582.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
