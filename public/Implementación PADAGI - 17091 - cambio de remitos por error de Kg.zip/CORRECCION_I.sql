UPDATE apps.xx_inv_remitos_impresos
SET    waybill_airbill = decode(waybill_airbill,'0146-00001036', '0146-00001042','0146-00001042','0146-00001036')
      ,last_update_date = sysdate
      ,last_updated_by  = 2070
WHERE  waybill_airbill IN ('0146-00001036', '0146-00001042');
--2 Registros 