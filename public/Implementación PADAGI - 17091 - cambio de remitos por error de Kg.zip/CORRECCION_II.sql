UPDATE apps.wsh_new_deliveries wnd
SET    waybill = decode(waybill,'0146-00001036', '0146-00001042','0146-00001042','0146-00001036')
      ,last_update_date = sysdate
      ,last_updated_by  = 2070
WHERE  waybill IN ('0146-00001036', '0146-00001042');
--2 Registros
