---------------------------------------------------------------------------------- 
-- +==========================================================================+ -- 
-- |                     ENERGIA SUSTENTAVEL DO BRASIL                        | --
-- |                         All rights reserved.                             | --
-- +==========================================================================+ -- 
-- |  # Nro GAP:         120_ESBR_TSD8824_01  	                              | -- 
-- |  # Descrição:       Incluir mensagem tela de aprovacao PO                | --  
-- |  # Versão:          1.0                                                  | -- 
-- |  # Data:            03/03/2021	                                          | -- 
-- |  # Autor:           Mariana Andrade                                      | --
-- +==========================================================================+ --

---------------------------------------------------------------------------------- 
###### 1. Pré-Instalação:                                     		        ###### 
----------------------------------------------------------------------------------
 1.1) Readme para aplicação do seguinte patch
 		
 		- 120_ESBR_TSD8824_01

----------------------------------------------------------------------------------
###### 2. Instalação:                                                       ###### 
----------------------------------------------------------------------------------
  2.1) Execute os comandos abaixo no UNIX
    	 
	# Copie o arquivo 120_ESBR_TSD8824_01.zip para a pasta $APPL_TOP/patches.  
  
	# Execute o comando abaixo para descompactar a pasta.
		$ cd $APPL_TOP/patches
		$ unzip 120_ESBR_TSD8824_01.zip   
		$ cd 120_ESBR_TSD8824_01  

  2.2) O patch pode ser aplicado manualmente.

     	2.2.2) Manualmente
     	
				# Verifique se as pastas estão criadas. Caso não haja alguma, favor criar.
				   
				   mkdir -p $ESBR_TOP/admin/sql
				   mkdir -p $JAVA_TOP//esbr/oracle/apps/po/notifications/webui
				   mkdir -p $JAVA_TOP/esbr/oracle/apps/po/notifications/webui/customizations/site/0

     		
				# Copia dos arquivos customizados
				   
				   cp -f esbr/admin/sql/GET_PO_MESSAGE_P.sql                                                        $ESBR_TOP/admin/sql/GET_PO_MESSAGE_P.sql


                # SQL - Substituir $apps_pwd pelas respectivas informacoes
				
				  sqlplus apps/$apps_pwd      @$ESBR_TOP/admin/sql/GET_PO_MESSAGE_P.sql    >    $ESBR_TOP/admin/sql/GET_PO_MESSAGE_P.log;
				
				# Fazer backup dos arquivos OAF
				
				   cd $JAVA_TOP
				   zip custom.zip -r esbr
				
				# Copiar arquivos OAF para o diretorio $JAVA_TOP
				
 		           cd $APPL_TOP/patches/120_ESBR_TSD8824_01
				   cp -f esbr/misc/esbr/oracle/apps/po/notifications/webui/esbrPOApprvNotifCO.class                 $JAVA_TOP/esbr/oracle/apps/po/notifications/webui/esbrPOApprvNotifCO.class
				   cp -f esbr/misc/esbr/oracle/apps/po/notifications/webui/customizations/site/0/POApprvNotifRN.xml $JAVA_TOP/esbr/oracle/apps/po/notifications/webui/customizations/site/0/POApprvNotifRN.xml
 		        
 		        # Rode os comandos abaixo
				
 		           cd $JAVA_TOP
                   mv customall.jar customall.jar.old
                   zip esbr.zip -r esbr
                   adjava oracle.apps.ad.jri.adjmx -areas esbr.zip -outputFile customall.jar
                   chmod 775 customall.jar
                   chmod 775 esbr.*	

                # Importar aquivos XML - Substituir <PASS_APPS>, <HOST>, <PORT> e <SID> pelas respectivas informacoes

                  java oracle.jrad.tools.xml.importer.XMLImporter $JAVA_TOP/esbr/oracle/apps/po/notifications/webui/customizations/site/0/POApprvNotifRN.xml -rootdir $JAVA_TOP/esbr/ -username apps -password <PASS_APPS> -dbconnection '(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=<HOST>)(PORT=<PORT>))(CONNECT_DATA=(SERVICE_NAME=<SID>)(INSTANCE_NAME=<SID>)))'			  


---------------------------------------------------------------------------
###### 3. Pós-Instalação                                             ######
---------------------------------------------------------------------------

  3.1) Execute os comandos abaixo para realizar o BOUNCE:
  	
  	Para fazer o STOP
  		admanagedsrvctl.sh stop oacore_server1
  	
  	Para fazer o START
        admanagedsrvctl.sh start oacore_server1
  
  
  
# *** Fim da Aplicação ***