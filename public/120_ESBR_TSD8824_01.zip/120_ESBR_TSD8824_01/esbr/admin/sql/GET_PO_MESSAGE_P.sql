CREATE OR REPLACE PROCEDURE get_po_message_p(p_po_header_id IN VARCHAR2
                                            ,x_msg          OUT VARCHAR2) AS

    lv_msg         VARCHAR2(2000);
    lv_attribute10 po_headers_all.attribute10%TYPE;

  BEGIN

    BEGIN
      SELECT attribute10
        INTO lv_attribute10
        FROM po_headers_all
       WHERE po_header_id = p_po_header_id
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        lv_attribute10 := NULL;
    END;

    IF lv_attribute10 IS NOT NULL THEN
      lv_msg := 'Utilizando contrato jur�dico j� existente. Contrato ' || lv_attribute10;
      --lv_msg := '';
    END IF;

    x_msg := NVL(lv_msg, '');

  EXCEPTION
    WHEN OTHERS THEN
      x_msg := 'Erro: ' || SQLERRM;
  END get_po_message_p;
/
EXIT;
