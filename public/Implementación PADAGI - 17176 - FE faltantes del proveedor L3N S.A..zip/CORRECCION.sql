UPDATE apps.oe_order_headers_all ooh
SET    cust_po_number = '507057', last_update_date = sysdate, last_updated_by = 2070
WHERE  order_number = '6213'
AND    org_id = 2235;
--1 Registros