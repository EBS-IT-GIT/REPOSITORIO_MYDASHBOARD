UPDATE apps.ap_invoice_distributions_all
SET    attribute2 = 'FC INTERNA'
WHERE  attribute4 = '0002-00000103'
AND    invoice_id = (SELECT invoice_id
                     FROM   apps.ap_invoices_all ai
                           ,apps.ap_suppliers asup
                     WHERE  ai.vendor_id = asup.vendor_id
                     AND    asup.vendor_name = 'FONDO FIJO SAN JOAQUIN'
                     AND    ai.invoice_num = '0001-00000002');
--3 Registros