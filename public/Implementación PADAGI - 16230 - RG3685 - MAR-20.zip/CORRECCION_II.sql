UPDATE apps.ap_invoice_distributions_all
SET    attribute2 = 'FC INTERNA'
WHERE  attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'FF GANADERIA EL ORDEN')
AND    invoice_id IN(SELECT invoice_id
                     FROM   apps.ap_invoices_all ai
                           ,apps.ap_suppliers asup
                     WHERE  ai.vendor_id = asup.vendor_id
                     AND    asup.vendor_name = 'FONDO FIJO GANADERÍA'
                     AND    ai.invoice_num IN ('0001-00000182','0001-00000184'));
--6 Registros