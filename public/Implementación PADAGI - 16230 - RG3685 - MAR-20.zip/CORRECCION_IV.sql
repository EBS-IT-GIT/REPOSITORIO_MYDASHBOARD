UPDATE apps.ap_invoice_distributions_all
SET    attribute3 = 'A'
WHERE  attribute4 ='0002-00000228'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'BRANGERI GLADYS LIDIA');
--3 Registros