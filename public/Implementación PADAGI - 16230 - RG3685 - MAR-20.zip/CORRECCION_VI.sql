UPDATE apps.ap_invoice_distributions_all aid
SET    attribute2 =(SELECT distinct attribute2 
        FROM   apps.ap_invoice_distributions_all aid2
        WHERE  aid.invoice_id = aid2.invoice_id
        AND    aid2.line_type_lookup_code = 'REC_TAX'
        AND    aid2.charge_applicable_to_dist_id = aid.invoice_distribution_id)
     , attribute3 = (SELECT distinct attribute3 
        FROM   apps.ap_invoice_distributions_all aid2
        WHERE  aid.invoice_id = aid2.invoice_id
        AND    aid2.line_type_lookup_code = 'REC_TAX'
        AND    aid2.charge_applicable_to_dist_id = aid.invoice_distribution_id)
     , attribute4 = (SELECT distinct attribute4 
        FROM   apps.ap_invoice_distributions_all aid2
        WHERE  aid.invoice_id = aid2.invoice_id
        AND    aid2.line_type_lookup_code = 'REC_TAX'
        AND    aid2.charge_applicable_to_dist_id = aid.invoice_distribution_id)
     , attribute5 = (SELECT distinct attribute5 
        FROM   apps.ap_invoice_distributions_all aid2
        WHERE  aid.invoice_id = aid2.invoice_id
        AND    aid2.line_type_lookup_code = 'REC_TAX'
        AND    aid2.charge_applicable_to_dist_id = aid.invoice_distribution_id)
     , attribute6 =(SELECT distinct attribute6 
        FROM   apps.ap_invoice_distributions_all aid2
        WHERE  aid.invoice_id = aid2.invoice_id
        AND    aid2.line_type_lookup_code = 'REC_TAX'
        AND    aid2.charge_applicable_to_dist_id = aid.invoice_distribution_id)
WHERE  invoice_id = (SELECT invoice_id
                     FROM   apps.ap_invoices_all
                     WHERE  invoice_num = '0923-00000565')
AND line_type_lookup_code = 'ITEM';
--42 Registros