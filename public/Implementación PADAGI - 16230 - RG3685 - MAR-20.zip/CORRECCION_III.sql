UPDATE apps.ap_invoices_all aid
SET    global_attribute12 = 'A', global_attribute13 = '01'
WHERE  invoice_num IN ('0003-00043297','0003-00000032','0003-00000033')
AND    vendor_id IN (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name IN ('TORNERIA ROSSI SOCIEDAD ANONIMA','PATRUCCO SEBASTIAN'));
--3 Registros