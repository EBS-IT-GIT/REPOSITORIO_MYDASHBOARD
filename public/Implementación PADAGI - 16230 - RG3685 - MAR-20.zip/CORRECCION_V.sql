UPDATE  apps.ap_invoice_distributions_all
SET    attribute2 = 'FC INTERNA'
WHERE  attribute4= '0005-00003461'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'ZARZA CARLOS ALFREDO');
--3 Registros
