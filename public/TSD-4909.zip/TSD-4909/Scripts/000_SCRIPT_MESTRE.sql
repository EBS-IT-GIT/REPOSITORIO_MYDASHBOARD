@"&DIRETORIO\000_SETUP_SCRIPTS.sql"
--
SPOOL "&DIRETORIO\TSD4909_01.log";


PROMPT P_TSD4909_01.sql
@&DIRETORIO\P_TSD4909_01.sql;
PROMPT FIM P_TSD4909_01.sql

PROMPT Processo Finalizado! Favor verificar no arquivo de log TSD4909_01 se O script foi executado com sucesso...
SPOOL OFF;


