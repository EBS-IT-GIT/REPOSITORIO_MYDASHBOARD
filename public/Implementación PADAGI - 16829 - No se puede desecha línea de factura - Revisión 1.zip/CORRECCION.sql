UPDATE apps.ap_invoice_distributions_all
SET    description = 'JUNTA TERMICA 6-99035344 PARA HOMOGENIZADOR TKA'
WHERE  invoice_id = 6291783
AND    invoice_line_number = 1;
--2 Registros