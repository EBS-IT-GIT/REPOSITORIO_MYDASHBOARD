  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_ADE_TIMECARDS_V_MON" ("FECHA"
                                                                         , "ID_CONCEPTO"
                                                                         , "DESCRIPTION"
                                                                         , "OBSERVACIONES") AS 
  SELECT fecha,
          id_concepto,
          description,
          observaciones
     FROM xx_ade_timecards a, fnd_user b
    WHERE a.user_id = b.user_id
          AND TO_CHAR (fecha, 'RRRRMM') = TO_CHAR (SYSDATE, 'RRRRMM');


exit
