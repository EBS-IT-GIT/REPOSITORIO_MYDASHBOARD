  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_PROFORMA_PKG" IS
FUNCTION xx_Run_API ( p_int_header_id         in   NUMBER
                   , p_operating_unit          in  NUMBER
                   , p_commit                  in  VARCHAR2
                   , p_buyer                    in number
                   , x_error_msg         IN OUT VARCHAR2
                   ) RETURN BOOLEAN;
FUNCTION Alta_lineas_oc ( p_po_header_id         in   NUMBER
                   , x_error_msg         IN OUT VARCHAR2
                  , x_header_interface in out number
                   )  RETURN BOOLEAN;
function alta_lineas_busqueda  ( p_po_header_id         in   NUMBER
                , P_PROVISION_ACCOUNT_ID IN NUMBER
                , P_VENDOR_ID  IN NUMBER
                , p_tipo_erogacion in varchar2
                , p_inventory_item_id in number
                , p_DOCUMENTO in varchar2
                , p_producto in varchar2
                ,P_FECHA_DESDE IN DATE
                ,P_FECHA_HASTA IN DATE
                , x_cant_filas  in out number
                , x_error_msg         IN OUT VARCHAR2
                   )  RETURN BOOLEAN    ;
END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_PROFORMA_PKG" IS
FUNCTION xx_Run_API ( p_int_header_id         in   NUMBER
                   , p_operating_unit          in  NUMBER
                   , p_commit                  in  VARCHAR2
                   , p_buyer                    in number
                   , x_error_msg         IN OUT VARCHAR2
                   ) RETURN BOOLEAN IS

    CURSOR cIError IS
      SELECT error_message
      FROM po_interface_errors
      WHERE interface_header_id = p_int_header_id;

    d_pkg_name CONSTANT VARCHAR2(255) := 'po.plsql.PO_PDOI_Concurrent.';
    d_api_name CONSTANT VARCHAR2(255) :=  'POXPDOI';
    d_position                  NUMBER;

    l_sourcing_inv_org_id       HR_ALL_ORGANIZATION_UNITS.organization_id%type;

    --Bug 13343886
    l_batch_size                NUMBER;
    l_gather_stats              VARCHAR2(1);
    --Bug 13343886

    l_return_status             VARCHAR2(1);
    l_msg                       VARCHAR2(2000);
    --CLM PDOI Integration
    l_clm_flag                  VARCHAR2(1) := 'N';

      x_po_header_id      NUMBER;

  BEGIN
   -- FND_GLOBAL.apps_initialize(FND_GLOBAL.User_ID, FND_GLOBAL.Resp_ID, FND_GLOBAL.Resp_appl_ID);
  --  FND_CLIENT_INFO.set_org_context(p_operating_unit);
    d_position := 0;


    d_position := 20;

    SELECT max(organization_id)    INTO l_sourcing_inv_org_id
    FROM org_organization_definitions
    WHERE organization_code = '1MI';
    --Bug 13343886
    PO_PDOI_CONSTANTS.g_DEF_BATCH_SIZE := 5000;
    PO_PDOI_CONSTANTS.g_GATHER_STATS   := 'N';
    --Bug 13343886

    d_position := 30;
    PO_PDOI_GRP.start_process
               ( p_api_version          => 1.0
               , p_init_msg_list        => FND_API.G_TRUE
               , p_validation_level     => FND_API.G_VALID_LEVEL_FULL
               , p_commit               => FND_API.G_FALSE
               , x_return_status        => l_return_status
               , p_gather_intf_tbl_stat => FND_API.G_FALSE
               , p_calling_module       => PO_PDOI_CONSTANTS.g_CALL_MOD_CONCURRENT_PRGM
               , p_selected_batch_id    => NULL
               , p_batch_size           => PO_PDOI_CONSTANTS.g_DEF_BATCH_SIZE
               , p_buyer_id             => p_buyer ---29286
               , p_document_type        => 'STANDARD'
               , p_document_subtype     => NULL
               , p_create_items         =>  'N'
               , p_create_sourcing_rules_flag => 'Y'
               , p_rel_gen_method       => NULL
               , p_sourcing_level       => 'Y'
               , p_sourcing_inv_org_id  => l_sourcing_inv_org_id
               , p_approved_status      =>  'APPROVED'
               , p_process_code         => PO_PDOI_CONSTANTS.g_process_code_PENDING
               , p_interface_header_id  => p_int_header_id -- Interface Header ID generado previamente
               , p_org_id               => p_operating_unit
               , p_ga_flag              => 'Y'
               , p_clm_flag             => 'N'
               );

    IF l_return_status != FND_API.G_RET_STS_SUCCESS THEN
      RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
    END IF;


   BEGIN
      SELECT ph.po_header_id
      INTO x_po_header_id
      FROM po_headers_interface hi
         , po_headers_all       ph
      WHERE 1=1
      AND ph.po_header_id = hi.po_header_id
      AND hi.interface_header_id = p_int_header_id
      and nvl(hi.process_code,'X') =  'ACCEPTED';

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        FOR r IN cIError LOOP
          x_error_msg := x_error_msg||' '||r.error_message;
        END LOOP;

        RETURN FALSE;
    END;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      PO_MESSAGE_S.add_exc_msg
      ( p_pkg_name => d_pkg_name,
        p_procedure_name => d_api_name || '.' || d_position
      );

      FOR i IN 1..FND_MSG_PUB.COUNT_MSG LOOP
        l_msg := FND_MSG_PUB.get
                 ( p_msg_index => i,
                   p_encoded => FND_API.G_FALSE
                 );

        --DBMS_OUTPUT.PUT_LINE('Error: '||l_msg);
        x_error_msg := x_error_msg || l_msg ||' ';
      END LOOP;
      RETURN FALSE;
  END xx_Run_API;

FUNCTION Alta_lineas_oc  ( p_po_header_id         in   NUMBER
                   , x_error_msg         IN OUT VARCHAR2
                   , x_header_interface in out number
                   )  RETURN BOOLEAN IS

        l_org_id number;
        l_segment1 varchar2(20);
        l_agent_id numbeR;

        l_num_linea NUMBER;
        l_header_interface number;
        l_lines_interface number;
begin

         select org_id, segment1, agent_id
            into l_org_id, l_segment1, l_agent_id
            from po_headers_all
            where po_header_id = p_po_header_id;

          select apps.po_headers_interface_s.NEXTVAL into l_header_interface from dual;
            -- Alta cabecera de la interface
                INSERT INTO po.po_headers_interface
                        (interface_header_id
                        ,process_code
                        ,action
                        ,org_id
                        ,document_type_code
                        ,DOCUMENT_NUM
                        ,po_header_id
                        ,CREATION_DATE
                        ,CREATED_BY
                        ,ATTRIBUTE_CATEGORY )
                VALUES
                        (l_header_interface
                        ,'PENDING'
                        ,'UPDATE'
                        ,l_org_id
                        ,'STANDARD'
                        ,l_segment1
                        ,p_po_header_id
                        ,SYSDATE
                        ,FND_GLOBAL.user_id
                        ,'AR');

                select MAX(LINE_NUM) INTO L_NUM_LINEA
                from PO.po_lines_all
                where po_header_id = p_po_header_id ;

                FOR C_InsReg IN (select  tipo_erogacion
                                                ,     TIPO_DOCUMENTO
                                                ,  CLAVE_NRO
                                                ,(select NVL(lv_dfv.xx_PO_cATEG_PROFORMA,0)
                                                            from fnd_lookup_values_vl      lv ,
                                                                  fnd_lookup_values_dfv     lv_dfv
                                                           where lv_dfv.rowid(+)   = lv.rowid
                                                          and NVL(lv_dfv.xx_PO_circuito_PROFORMA,'N') = 'Y'
                                                          and lv.lookup_type    = 'XX_AP_TIPOS_EROGACION'
                                                          AND LV.LOOKUP_CODE = xpar.tipo_erogacion) categoria
                                                , decode(TIPO_DOCUMENTO,'TCG', 'Carta Porte : ' || Clave_nro, 'OM','Viaje : ' || CLAVE_BUSQUEDA, 'Remito : ' || CLAVE_NRO)  descripcion
                                                , DESTINO_PCIA_FINAL
                                                 , (select location_id
                                                                from hr_locations hl,
                                                                       xx_tcg_provincias_arg tpa
                                                                where hl.attribute5 = 'Y'
                                                                and  tpa.geography_code = hl.region_2
                                                                and  upper(tpa.GEOGRAPHY_NAME) = upper(xpar.destino_pcia_final)) ship_to_location_id
                                                  , (select organization_id  from org_organization_definitions ood where organization_id =  xpar.organization_id) SHIP_TO_ORGANIZATION_ID
                                                  , costo_unitario --total
                                              , (select geography_CODE from HZ_GEOGRAPHIES where upper(geography_name) =upper( ORIGEN_PCIA) and geography_type = 'PROVINCE'
                                                            and geography_use = 'MASTER_REF'
                                                        and country_code = 'AR' and end_date > sysdate)  ORIGEN_PCIA_LDV
                                              , CC_GASTO_ID
                                              , UDM
                                              ,CANTIDAD
                                        from XX_PO_ASOCIA_REM_GT xpar
                                        where insert_flag = 'Y') LOOP

-- agregar MTL_UNITS_OF_MEASURE
                                L_NUM_LINEA := NVL(L_NUM_LINEA,0) + 1;
                               select  apps.po_lines_interface_s.nextval into  l_lines_interface from dual;

                                        INSERT INTO PO.PO_LINES_INTERFACE
                                        ( INTERFACE_LINE_ID
                                        , INTERFACE_HEADER_ID
                                        , ACTION
                                        , LINE_NUM
                                        , LINE_TYPE_id
                                        , ITEM_DESCRIPTION
                                        , category_id
                                        , UOM_CODE
                                        ,quantity
                                        , UNIT_PRICE
                                        , CREATION_DATE
                                        , po_header_id
                                        ,PROMISED_DATE
                                        ,ship_to_location_id
                                        ,SHIP_TO_ORGANIZATION_ID
                                       , line_attribute_category_lines
                                       , RECEIPT_REQUIRED_FLAG --> N
                                       , inspection_required_flag --> 'N'
                                       ,LINE_attribute2  --   XX_GL_UNIDAD_NEGOCIOS
                                       ,LINE_attribute6  --   XX_ORIGEN_REMITO
                                      , LINE_attribute7  -- XX_NRO_REMITO

                                        ) VALUES
                                        (l_lines_interface
                                        , l_header_interface
                                        , 'ADD'
                                        , l_num_linea
                                        , 1020              --> servicios
                                        ,  substr(C_InsReg.tipo_erogacion || ' ' || C_InsReg.descripcion,1,239)
                                        , C_InsReg.CATEGORIA
                                        , C_InsReg.UDM -- ANTES 'UN'
                                         ,C_InsReg.cantidad -- antes 1
                                        ,C_InsReg.costo_unitario
                                        , SYSDATE
                                      , p_po_header_id
                                      , TRUNC(SYSDATE)
                                      ,C_InsReg.ship_to_location_id
                                      ,C_InsReg.SHIP_TO_ORGANIZATION_ID
                                       ,'AR'
                                       ,'N'
                                       ,'N'
                                       ,'00'
                                   , C_InsReg.tipo_erogacion || '|' || C_InsReg.TIPO_DOCUMENTO
                                   , C_InsReg.CLAVE_NRO
                                        );



                             INSERT INTO PO_DISTRIBUTIONS_INTERFACE
                                ( interface_header_id
                                    ,interface_line_id
                                    ,interface_distribution_id
                                    ,distribution_num
                                    ,org_id
                                    ,quantity_ordered
                                    ,destination_type_code
                                    ,charge_account_id
                                   ,attribute_category
                                     --,MATCH_OPTION --> P
                                    , attribute7  -- XX_AP_ORIGEN_PROD
                                     , attribute10  -- XX_ACO_CARTA_PORTE

                                )
                                VALUES
                                (
                                    l_header_interface
                                    , l_lines_interface
                                    ,apps.po_distributions_interface_s.NEXTVAL
                                    ,1
                                   , l_org_id
                                    ,C_InsReg.cantidad -- antes 1
                                    ,'EXPENSE'
                                    ,C_InsReg.CC_GASTO_ID
                                   , 'AR'
                                -- ,'P'
                                    ,C_InsReg.ORIGEN_PCIA_LDV
                                   , decode(C_InsReg.TIPO_DOCUMENTO,'TCG',C_InsReg.CLAVE_NRO,null)
                            );

             end loop;

        IF NOT xx_Run_API ( p_int_header_id     => l_header_interface
                           , p_operating_unit    => l_org_id
                           , p_commit            => FND_API.G_TRUE
                           , p_buyer            => l_agent_id
                           , x_error_msg         => x_error_msg
                           ) THEN
                           x_header_interface := null;
                    return false;

        else
                x_header_interface := l_header_interface;
                -- Actualiza match_option -- opcion de asoc. de factura a OC ('p')
                update PO_LINE_LOCATIONS_ALL set match_option = 'P'  WHERE po_header_id = p_po_header_id and match_option <> 'P';
                    return true;
        END IF;
-- falta guardar detalle en nueva tabla, para tener informacion del detalle de cada remito

end Alta_lineas_oc;
---------------------------------------------------------------------------------------------
-- Busca las lineas en la tabla del reporte según criterio ingresado en pantalla
---------------------------------------------------------------------------------------------
function alta_lineas_busqueda ( p_po_header_id         in   NUMBER
                , P_PROVISION_ACCOUNT_ID IN NUMBER
                , P_VENDOR_ID  IN NUMBER
                , p_tipo_erogacion in varchar2
                , p_inventory_item_id in number
                , p_DOCUMENTO in varchar2
                , p_producto in varchar2
                ,P_FECHA_DESDE IN DATE
                ,P_FECHA_HASTA IN DATE
                , x_cant_filas  in out number
                , x_error_msg         IN OUT VARCHAR2
                   )  RETURN BOOLEAN IS
L_UDM VARCHAR2(10);
  begin
execute immediate 'truncate  table bolinf.XX_PO_ASOCIA_REM_SEL_GT';
-- COMENTO la busqueda de udm, porque trae la de pantalla y el resto debe ser informada
--SELECT  lv_dfv.XX_PO_UOM_PROFORMA INTO L_UDM
--  FROM fnd_lookup_values_vl  lv
--           , fnd_lookup_values_dfv lv_dfv
 --       WHERE 1=1
 --       AND lv_dfv.rowid(+)   = lv.rowid
 --       AND lv_dfv.context(+) = 'XX_AP_TIPOS_EROGACION'
  --      AND lv.lookup_type    = 'XX_AP_TIPOS_EROGACION'
  --      AND lv.lookup_code    = P_TIPO_EROGACION ;
            INSERT INTO XX_PO_ASOCIA_REM_SEL_GT (TIPO_DOCUMENTO,
                                     CLAVE_NRO,
                                     CLAVE_BUSQUEDA,
                                     INF_ADICIONAL_OC,
                                     DOMINIO,
                                     TITULAR_DESC,
                                     ORIGEN_PCIA,
                                     ORIGEN_ORG_CODE,
                                     DESTINATARIO_DESC,
                                     DESTINO_DESC,
                                     DESTINO_ESTAB_SUC,
                                     DESTINO_PCIA,
                                     FECHA_ENVIO,
                                     CANTIDAD,
                                     UDM,
                                     COSTO_UNITARIO,
                                     COSTO_TOTAL,
                                     INFO_ITEMS,
                                     OPERATING_UNIT,
                                     CLAVE_ID,
                                     ORGANIZATION_ID,
                                     INVENTORY_ITEM_ID,
                                     CANT_ITEMS,
                                     CC_GASTO_ID,
                                     VENDOR_ID,
                                     TIPO_EROGACION,
                                     PO_HEADER_ID)
                                   SELECT TIPO_DOCUMENTO
                                         , CLAVE_NRO
                                         , CLAVE_BUSQUEDA
                                         ,INF_ADICIONAL_OC
                                         , DOMINIO
                                         , TITULAR_DESC
                                         , ORIGEN_PCIA
                                         , ORIGEN_ORG_CODE
                                         , DESTINATARIO_DESC
                                         , DESTINO_DESC
                                         , DESTINO_ESTAB_SUC
                                         , DESTINO_PCIA
                                         , FECHA_ENVIO
                                         , CANTIDAD
                                         , udm              -- recupera la udm de la tabla del reporte
                                         , COSTO_UNITARIO
                                         , COSTO_TOTAL
                                         , INFO_ITEMS
                                         , OPERATING_UNIT
                                         , CLAVE_ID
                                         , ORGANIZATION_ID
                                         , INVENTORY_ITEM_ID
                                         , CANT_ITEMS
                                         , CASE  WHEN TIPO_DOCUMENTO = 'TCG'  AND P_TIPO_EROGACION = 'FLETE' THEN
                                                 P_PROVISION_ACCOUNT_ID
                                          ELSE NULL END                 CC_GASTO_ID
                                        , P_VENDOR_ID
                                        , P_TIPO_EROGACION
                                        , P_PO_HEADER_ID
                                from
                                (SELECT      TIPO_DOCUMENTO
                                       ,CLAVE_NRO
                                       ,clave_busqueda
                                       ,INF_ADICIONAL_OC
                                       ,DOMINIO
                                       ,titular_desc
                                       ,origen_pcia
                                       ,origen_org_code
                                       ,NVL (destinatario_desc, destino_desc) destinatario_desc
                                       ,destino_desc
                                       ,destino_estab_suc
                                       ,destino_pcia
                                       ,fecha_envio
                                       ,CASE  when P_TIPO_EROGACION = 'FLETE'
                                             and tipo_documento = 'TCG' THEN
                                             CANTIDAD  ELSE NULL END CANTIDAD
                                       ,CASE  when P_TIPO_EROGACION = 'FLETE'
                                             and tipo_documento = 'TCG' THEN
                                             COSTO_UNITARIO ELSE NULL END COSTO_UNITARIO
                                       ,CASE  when P_TIPO_EROGACION = 'FLETE'
                                             and tipo_documento = 'TCG' THEN
                                             COSTO_TOTAL ELSE NULL END COSTO_TOTAL
                                       , INFO_ITEMS
                                       ,OPERATING_UNIT
                                       ,  CLAVE_ID
                                       , ORGANIZATION_ID
                                       , INVENTORY_ITEM_ID
                                       , CANT_ITEMS
                                       , udm
                                  FROM bolinf.XX_PO_FLEPASIG_GT
                                where trip_id is NULL
                                   and (p_documento is null or clave_busqueda like '%' || p_documento || '%')
                                   and (p_producto is null or info_items like '%' || p_producto || '%')
                                   and (p_inventory_item_id is null or inventory_item_id is null or  p_inventory_item_id = inventory_item_id)
                                   and trunc(fecha_envio) between nvl(trunc(p_fecha_desde),trunc(fecha_envio)) and nvl(trunc(p_fecha_hasta),trunc(sysdate))
                                union
                                SELECT  TIPO_DOCUMENTO
                                        ,TO_CHAR(TRIP_ID) CLAVE_NRO
                                       ,MAX(clave_busqueda)
                                       ,max(INF_ADICIONAL_OC)
                                       ,MAX(DOMINIO)
                                       ,MAX(titular_desc)
                                       ,MAX(origen_pcia)
                                       ,MAX(origen_org_code)
                                       ,MAX(NVL (destinatario_desc, destino_desc)) destinatario_desc
                                       ,MAX(destino_desc)
                                       ,MAX(destino_estab_suc)
                                       ,MAX(destino_pcia_final)
                                       ,MAX(fecha_envio)
                                       , NULL CANTIDAD
                                       ,NULL COSTO_UNITARIO
                                       ,NULL COSTO_TOTAL
                                      , MAX(info_items) info_items
                                      ,MAX(OPERATING_UNIT)
                                       ,  MAX(TRIP_ID) CLAVE_ID
                                       , MAX(ORGANIZATION_ID)
                                       , NULL INVENTORY_ITEM_ID
                                       , SUM(CANT_ITEMS)
                                       , MAX(UDM) UDM
                                  FROM bolinf.XX_PO_FLEPASIG_GT
                                where trip_id is NOT NULL
                                   and (p_documento is null or clave_busqueda like '%' || p_documento || '%')
                                   and (p_producto is null or info_items like '%' || p_producto || '%')
                                   and (p_inventory_item_id is null or inventory_item_id is null or  p_inventory_item_id = inventory_item_id)
                                   and trunc(fecha_envio) between nvl(trunc(p_fecha_desde),trunc(fecha_envio)) and nvl(trunc(p_fecha_hasta),trunc(sysdate))
                                group by tipo_documento, TO_CHAR(TRIP_ID)) tfle
                                where ( NOT EXISTS -- No exista en la asociación
                                            (SELECT 1
                                             FROM XX_po_ASOCIA_remitos xpar
                                             WHERE 1=1
                                             AND tipo_erogacion =  P_TIPO_EROGACION
                                             AND xpar.po_header_id    != P_po_header_id
                                             and tfle.tipo_documento = xpar.tipo_documento
                                             AND tfle.clave_nro = xpar.clave_nro)
                                            OR EXISTS -- Existe en la asociación para otra oc, pero la oc esta cancelada totalmente o la aprobación  fue rechazada                              
                                            ( SELECT 1
                                                from    po_headers_all poh,   
                                                         XX_po_ASOCIA_remitos xpar
                                             WHERE  tipo_erogacion =  P_TIPO_EROGACION
                                             AND xpar.po_header_id    != P_po_header_id
                                             and tfle.tipo_documento = xpar.tipo_documento
                                             AND tfle.clave_nro = xpar.clave_nro
                                             AND  (nvl(poh.authorization_status,'INCOMPLETE')  IN ('CANCELED','CANCELLED','REJECTED') or nvl(poh.cancel_flag,'N') = 'Y')
                                            and    poh.po_header_id =xpar.po_header_id 
                                             )       
                                         )   
                                AND NOT EXISTS
                                (SELECT 1
                                 FROM xx_po_asocia_rem_gt xpart
                                 WHERE 1=1
                                 AND xpart.tipo_erogacion =  P_TIPO_EROGACION
                                 AND xpart.clave_nro = tfle.clave_nro
                                  and tfle.tipo_documento = xpart.tipo_documento
                                 AND xpart.delete_flag   != 'Y'
                                );
x_cant_filas := sql%rowcount;

return true;
exception
    WHEN OTHERS THEN
        x_error_msg := sqlerrm;
      RETURN FALSE ;
end alta_lineas_busqueda;

END;
/

exit
