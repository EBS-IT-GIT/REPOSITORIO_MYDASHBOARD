UPDATE zx.zx_taxes_b
SET    live_for_processing_flag = 'Y'
     , primary_recovery_type_code = null
     , primary_rec_rate_det_rule_flag = null
     , sec_rec_rate_det_rule_flag = null
     , recovery_rate_override_flag = null
     , allow_dup_regn_num_flag = 'N'
     , last_updated_by = 2070
     , last_update_date = sysdate
WHERE  tax = 'TOPSA';
--1 Registro
