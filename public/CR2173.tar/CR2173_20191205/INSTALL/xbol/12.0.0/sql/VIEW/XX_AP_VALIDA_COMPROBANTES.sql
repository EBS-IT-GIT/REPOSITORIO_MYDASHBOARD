  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_AP_VALIDA_COMPROBANTES" ("CUIT_EMPRESA"
                                                                         , "CUIT_PROVEEDOR"
                                                                         , "TIPO_COMPROBANTE"
                                                                         , "NUMERO_COMPROBANTE") AS 
  SELECT ld.primary_id_number || ld.primary_id_valid_digit__ar_ CUIT_Empresa,
         s.num_1099 || pv.taxpayer_id_validation_digit CUIT_Proveedor,
         idfv.tax_authority_transaction_type Tipo_Comprobante,
         i.invoice_num Numero_Comprobante
    FROM ap_suppliers s,
         po_vendors1_dfv pv,
         ap_supplier_sites_all ss,
         hr_operating_units ou,
         hr_organization_units orgu,
         hr_locations_all l,
         hr_locations_all2_dfv ld,
         ap_invoices_all i,
         ap_invoices_all2_dfv idfv
   WHERE 1 = 1
     -- Proveedor Activo
     AND SYSDATE BETWEEN NVL(s.start_date_active,SYSDATE - 1) AND NVL(s.end_date_active,SYSDATE + 1)
     -- Solo proveedores con CUIT
     AND s.num_1099 || pv.taxpayer_id_validation_digit IS NOT NULL
     --
     AND s.rowid = pv.row_id
     AND s.vendor_id = ss.vendor_id
     -- Sucursal Activa
     AND ss.inactive_date IS NULL
     --
     AND ss.org_id = ou.organization_id
     AND ou.organization_id = orgu.organization_id
     AND orgu.location_id = l.location_id
     AND l.rowid = ld.row_id
     -- Solo de empresas con CUIT
     AND ld.primary_id_number || ld.primary_id_valid_digit__ar_ IS NOT NULL
     --
     AND ss.vendor_id = i.vendor_id
     AND ss.vendor_site_id = i.vendor_site_id
     AND i.rowid = idfv.row_id;


exit
