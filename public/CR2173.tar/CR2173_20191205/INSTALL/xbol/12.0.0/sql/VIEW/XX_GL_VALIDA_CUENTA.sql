  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_GL_VALIDA_CUENTA" ("FLEX_VALUE"
                                                                         , "DESCRIPTION") AS 
  SELECT flex_value, description
FROM   fnd_flex_values_vl f
WHERE  flex_value_set_id = 1010641
AND    enabled_flag = 'Y'
AND    summary_flag = 'N'
AND    sysdate BETWEEN nvl(start_date_active, sysdate) AND nvl(end_date_active, sysdate)
ORDER BY flex_value;


exit
