  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_AP_VALIDA_PROVEEDORES" ("CUIT_EMPRESA"
                                                                         , "CUIT_PROVEEDOR"
                                                                         , "NOMBRE_PROVEEDOR"
                                                                         , "ESTRUCTURA_LEGAL"
                                                                         , "ORIGEN") AS 
  SELECT ld.primary_id_number || ld.primary_id_valid_digit__ar_              CUIT_Empresa
          , s.num_1099 || pv.taxpayer_id_validation_digit                       CUIT_Proveedor
          , s.vendor_name                                                       Nombre_Proveedor
          , hop.legal_status                                                    Estructura_Legal
          , DECODE(s.global_attribute9, 'DOMESTIC_ORIGIN', 'Nacional'
                                      , 'FOREIGN_ORIGIN', 'Extranjero')         Origen
       FROM AP_SUPPLIERS             s
          , PO_VENDORS1_DFV          pv
          , AP_SUPPLIER_SITES_ALL    ss
          , HR_OPERATING_UNITS       ou
          , HR_ORGANIZATION_UNITS    orgu
          , HR_LOCATIONS_ALL         l 
          , HR_LOCATIONS_ALL2_DFV    ld
          , HZ_ORGANIZATION_PROFILES hop
      WHERE 1 = 1
        -- Proveedor Activo
        AND SYSDATE BETWEEN NVL (s.start_date_active, SYSDATE - 1)
                        AND NVL (s.end_date_active, SYSDATE + 1)
        -- Solo proveedores con CUIT
        AND s.num_1099 || pv.taxpayer_id_validation_digit IS NOT NULL
        --
        AND s.ROWID = pv.row_id
        AND s.vendor_id = ss.vendor_id
        -- Sucursal Activa
        AND ss.inactive_date IS NULL
        AND ss.org_id = ou.organization_id
        AND ou.organization_id = orgu.organization_id
        AND orgu.location_id = l.location_id
        AND l.ROWID = ld.row_id
        -- Solo de empresas con CUIT
        AND ld.primary_id_number || ld.primary_id_valid_digit__ar_ IS NOT NULL
        --
        AND s.party_id   = hop.party_id (+) 
        AND hop.effective_end_date IS NULL
      GROUP BY ld.primary_id_number || ld.primary_id_valid_digit__ar_
          , s.num_1099 || pv.taxpayer_id_validation_digit
          , s.vendor_name
          , hop.legal_status
          , s.global_attribute9;


exit
