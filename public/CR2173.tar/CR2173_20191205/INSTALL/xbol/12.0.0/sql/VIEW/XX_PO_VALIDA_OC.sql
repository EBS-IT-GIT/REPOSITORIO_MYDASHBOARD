  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_PO_VALIDA_OC" ("CUIT_EMPRESA"
                                                                         , "CUIT_PROVEEDOR"
                                                                         , "ORDEN_COMPRA"
                                                                         , "MONEDA_ORDEN_COMPRA"
                                                                         , "MONTO_TOTAL"
                                                                         , "TERMINO_PAGO"
                                                                         , "NOMBRE_SUCURSAL") AS 
  SELECT DISTINCT
          ld.primary_id_number || ld.primary_id_valid_digit__ar_ CUIT_Empresa,
          s.num_1099 || pv.taxpayer_id_validation_digit CUIT_Proveedor,
          ph.segment1 Orden_Compra,
          ph.currency_code Moneda_Orden_Compra,
          COALESCE (amount_limit,
                    (SELECT SUM (unit_price * quantity)
                       FROM po_lines_all pl
                      WHERE pl.po_header_id = ph.po_header_id),
                    0)
             monto_total,
          at.name,
          ss.vendor_site_code   nombre_sucursal
     FROM ap_suppliers s,
          po_vendors1_dfv pv,
          hr_locations_all2_dfv ld,
          po_headers_all ph,
          hr_organization_units orgu,
          hr_locations_all l,
          hr_operating_units ou,
          ap_terms at, 
          ap.ap_supplier_sites_all ss
    WHERE 1 = 1 AND ph.terms_id = at.term_id(+)
          -- Proveedor Activo
          AND SYSDATE BETWEEN NVL (s.start_date_active, SYSDATE - 1)
                          AND NVL (s.end_date_active, SYSDATE + 1)
          -- Solo proveedores con CUIT
          AND s.num_1099 || pv.taxpayer_id_validation_digit IS NOT NULL
          --
          AND ph.vendor_id = s.vendor_id
          AND s.ROWID = pv.row_id
          AND ph.org_id = ou.organization_id
          AND ou.organization_id = orgu.organization_id
          AND orgu.location_id = l.location_id
          AND l.ROWID = ld.row_id
          AND s.vendor_id = ss.vendor_id
          AND ph.vendor_site_id = ss.vendor_site_id
          -- Solo de empresas con CUIT
          AND ld.primary_id_number || ld.primary_id_valid_digit__ar_
                 IS NOT NULL
          --
          AND NVL (ph.authorization_status, 'INCOMPLETE') = 'APPROVED'
          -- Solo Ocs sin fecha de cierre
          AND NVL (ph.closed_date, SYSDATE) >= SYSDATE;


exit
