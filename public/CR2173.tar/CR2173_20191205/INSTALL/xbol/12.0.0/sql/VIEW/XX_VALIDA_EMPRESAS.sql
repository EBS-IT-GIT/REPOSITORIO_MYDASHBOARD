  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_VALIDA_EMPRESAS" ("CUIT_EMPRESA"
                                                                         , "NOMBRE_EMPRESA") AS 
  SELECT ld.primary_id_number || ld.primary_id_valid_digit__ar_ CUIT_Empresa,
         ld.company_name Nombre_Empresa
    FROM hr_operating_units ou,
         hr_organization_units orgu,
         hr_locations_all l,
         hr_locations_all2_dfv ld
   WHERE ou.organization_id = orgu.organization_id
     AND orgu.location_id = l.location_id
     AND l.rowid = ld.row_id
     -- Solo empresas con CUIT
     AND ld.primary_id_number || ld.primary_id_valid_digit__ar_ IS NOT NULL
GROUP BY ld.primary_id_number || ld.primary_id_valid_digit__ar_,
         ld.company_name;


exit
