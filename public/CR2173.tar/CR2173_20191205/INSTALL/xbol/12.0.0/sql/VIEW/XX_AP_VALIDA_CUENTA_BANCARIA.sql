  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_AP_VALIDA_CUENTA_BANCARIA" ("CUIT_EMPRESA"
                                                                         , "CUIT_PROVEEDOR"
                                                                         , "NOMBRE_PROVEEDOR"
                                                                         , "NOMBRE_SUCURSAL"
                                                                         , "DOMICILIO_LEGAL"
                                                                         , "CBU_CUENTA_BANCARIA"
                                                                         , "MONEDA_SUCURSAL_BANCARIA"
                                                                         , "PRIORIDAD") AS 
  SELECT ld.primary_id_number || ld.primary_id_valid_digit__ar_              CUIT_Empresa,
            s.num_1099 || pv.taxpayer_id_validation_digit                       CUIT_Proveedor,
            s.vendor_name                                                       Nombre_Proveedor,
            ss.vendor_site_code                                                 Nombre_Sucursal,
            NVL(ss.global_attribute17, 'N')                                     Domicilio_Legal,
            ba.attribute4                                                       CBU_Cuenta_Bancaria,
            ba.currency_code                                                    Moneda_Sucursal_Bancaria,
            ba.order_of_preference                                              Prioridad 
       FROM ap_suppliers s,
            po_vendors1_dfv pv,
            ap_supplier_sites_all ss,
            hr_operating_units ou,
            hr_organization_units orgu,
            hr_locations_all l,
            hr_locations_all2_dfv ld,
            -- Datos cuenta bancaria
            (  SELECT ep.supplier_site_id, ieb.currency_code, ieb.attribute4, ins.order_of_preference 
                 FROM iby_external_payees_all ep,
                      iby_ext_bank_accounts ieb,
                      iby_pmt_instr_uses_all ins,
                      iby_account_owners ow
                WHERE     ow.primary_flag = 'Y'
                      AND ow.ext_bank_account_id = ieb.ext_bank_account_id
                      AND ow.ext_bank_account_id = ins.instrument_id
                      AND ep.ext_payee_id = ins.ext_pmt_party_id
                      AND ep.payee_party_id = ow.account_owner_party_id
                      --AND NVL (ieb.end_date, SYSDATE + 1) > SYSDATE
                      AND TRUNC (SYSDATE) BETWEEN NVL (ins.start_date,
                                                       SYSDATE - 1)
                                              AND NVL (ins.end_date, SYSDATE + 1)
             GROUP BY ep.supplier_site_id, ieb.currency_code, ieb.attribute4, ins.order_of_preference) ba
      WHERE 1 = 1
            -- Proveedor Activo
            AND SYSDATE BETWEEN NVL (s.start_date_active, SYSDATE - 1)
                            AND NVL (s.end_date_active, SYSDATE + 1)
            -- Solo proveedores con CUIT
            AND s.num_1099 || pv.taxpayer_id_validation_digit IS NOT NULL
            --
            AND s.ROWID = pv.row_id
            AND s.vendor_id = ss.vendor_id
            -- Sucursal Activa
            AND ss.inactive_date IS NULL
            AND ss.org_id = ou.organization_id
            AND ou.organization_id = orgu.organization_id
            AND orgu.location_id = l.location_id
            AND l.ROWID = ld.row_id
            -- Solo de empresas con CUIT
            AND ld.primary_id_number || ld.primary_id_valid_digit__ar_
                   IS NOT NULL
            --
            AND ss.vendor_site_id = ba.supplier_site_id(+)
   GROUP BY ld.primary_id_number || ld.primary_id_valid_digit__ar_,
            s.num_1099 || pv.taxpayer_id_validation_digit,
            s.vendor_name,
            ss.vendor_site_code,
            ss.global_attribute17, 
            ba.attribute4,
            ba.currency_code,
            ba.order_of_preference;


exit
