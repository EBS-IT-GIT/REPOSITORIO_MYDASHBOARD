  set define off;
GRANT EXECUTE ON XX_AP_ABBYY_PKG TO ABBY;

exit
