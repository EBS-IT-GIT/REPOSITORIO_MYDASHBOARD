  set define off;
CREATE OR REPLACE DIRECTORY ABBYY_REPOSITORY AS '/ua1001/fs_ne/ADECO/interface/incoming/ABBYY';

/* Modificar permisos carpeta */

exit
