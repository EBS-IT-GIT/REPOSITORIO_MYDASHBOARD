  set define off;
 INSERT INTO FND_DOC_CATEGORY_USAGES
   (DOC_CATEGORY_USAGE_ID, CATEGORY_ID, ATTACHMENT_FUNCTION_ID, ENABLED_FLAG, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY)
 SELECT FND_DOC_CATEGORY_USAGES_S.nextval
      , fdc.category_id
      , (SELECT attachment_function_id 
           FROM FND_ATTACHMENT_FUNCTIONS
          WHERE function_name = 'AP_APXINWKB_SUMMARY_VIEW')
      , 'Y'
      , SYSDATE
      , 2070
      , SYSDATE
      , 2070
   FROM FND_DOC_CATEGORY_USAGES    fdcu
      , FND_ATTACHMENT_FUNCTIONS   faf
      , FND_DOCUMENT_CATEGORIES_TL fdc
  WHERE fdcu.attachment_function_id = faf.attachment_function_id
    AND faf.function_name           = 'APXINWKB'
    AND fdcu.category_id            = fdc.category_id
    AND fdc.language                ='ESA' 
    AND fdc.user_name               = 'Para Cuentas a Pagar' ; 

COMMIT;

exit
