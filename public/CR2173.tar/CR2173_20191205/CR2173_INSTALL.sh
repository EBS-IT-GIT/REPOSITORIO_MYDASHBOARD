#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2173_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2173
# |
# | HISTORY
# |   05-DEC-19  Silva, Alejandra - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2173_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2173_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2173
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/ALR
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/PROF
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/sql/VIEW
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT



echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_AP_WSFECRED_PUB " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_AP_WSFECRED_PUB','APPS','$PATCHDIR','CR2173');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AP_WSFECRED_PUB* $DOWNDBDIR/xbol/12.0.0/sql/PKG


echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_AP_SETUP_PAGOS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_AP_SETUP_PAGOS.ldt MENU MENU_NAME="XX_AP_SETUP_PAGOS"
AddAllLogs $CROUT "FND" "XX_AP_SETUP_PAGOS.ldt"
mv XX_AP_SETUP_PAGOS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU


echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXREPOFECRED " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXREPOFECRED.fmb ]; then
  cp $AU_TOP/forms/US/XXREPOFECRED.fmb XXREPOFECRED.fmb
  echo `ls -lh XXREPOFECRED.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXREPOFECRED.fmb no existe" >> $CROUT
fi
mv XXREPOFECRED* $DOWNDBDIR/au/12.0.0/forms/US/


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_AP_ABBYY_RESPUESTAS " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_AP_ABBYY_RESPUESTAS >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AP_ABBYY_RESPUESTAS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AP_ABBYY_RESPUESTAS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AP_ABBYY_RESPUESTAS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AP_ABBYY_RESPUESTAS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AP_ABBYY_RESPUESTAS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_AP_MIPYME_CBTES_ASOC " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_AP_MIPYME_CBTES_ASOC >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AP_MIPYME_CBTES_ASOC.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AP_MIPYME_CBTES_ASOC.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AP_MIPYME_CBTES_ASOC.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AP_MIPYME_CBTES_ASOC.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AP_MIPYME_CBTES_ASOC.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_GL_VALIDA_CUENTA " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_GL_VALIDA_CUENTA >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_GL_VALIDA_CUENTA.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_GL_VALIDA_CUENTA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_GL_VALIDA_CUENTA.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_GL_VALIDA_CUENTA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_GL_VALIDA_CUENTA.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_AP_VALIDA_COMPROBANTES " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_COMPROBANTES >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_COMPROBANTES.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_COMPROBANTES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_COMPROBANTES.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_COMPROBANTES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_COMPROBANTES.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_AP_VALIDA_PROVEEDORES " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_PO_VALIDA_OC " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_VALIDA_EMPRESAS " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_VALIDA_EMPRESAS >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_VALIDA_EMPRESAS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_VALIDA_EMPRESAS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_VALIDA_EMPRESAS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_VALIDA_EMPRESAS.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_VALIDA_EMPRESAS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_AP_VALIDA_CUENTA_BANCARIA " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF CREATE_HOLD " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/CREATE_HOLD >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_HOLD.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_HOLD.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_HOLD.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_HOLD.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_HOLD.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF CREATE_USAGE " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/CREATE_USAGE >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_USAGE.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_USAGE.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_USAGE.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_USAGE.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_USAGE.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF CREATE_DIRECTORY " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/CREATE_DIRECTORY >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_AP_ABBYY_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_AP_ABBYY_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AP_ABBYY_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_AP_ABBYY_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AP_ABBYY_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_AP_ABBYY_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AP_ABBYY_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_AP_WSFECRED_PUB " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_AP_WSFECRED_PUB >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AP_WSFECRED_PUB.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_AP_WSFECRED_PUB.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AP_WSFECRED_PUB.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_AP_WSFECRED_PUB.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AP_WSFECRED_PUB.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF GRANT_ABBYY " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/GRANT_ABBYY >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/GRANT_ABBYY.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/GRANT_ABBYY.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/GRANT_ABBYY.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/GRANT_ABBYY.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/GRANT_ABBYY.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-MENU XX_AP_SETUP_PAGOS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_AP_SETUP_PAGOS.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF XX_DEBUG_ABBYY_ENABLED " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XX_DEBUG_ABBYY_ENABLED.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-LOOKUP XX_AP_MAIL_PAYGROUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/aflvmlu.lct $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XX_AP_MAIL_PAYGROUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-ALR XXAPWSFECREDDocumentosAsociadosaFC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $ALR_TOP/patch/115/import/xxalr.lct $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosAsociadosaFC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-ALR XXAPWSFECREDDocumentosRechazadosporClientes " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $ALR_TOP/patch/115/import/xxalr.lct $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosRechazadosporClientes.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-ALR XXAPWSFECREDDocumentosavencer " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $ALR_TOP/patch/115/import/xxalr.lct $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XXAPWSFECREDDocumentosavencer.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXREPOFECRED " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXREPOFECRED.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXREPOFECRED.fmb`" >> $CROUT
mv XXREPOFECRED.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXREPOFECRED.fmx` >> $CROUT
cd $CURDIR
if ! ls /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXREPOFECRED.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXREPOFECRED.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXREPOFECRED.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXREPOFECRED.fmb /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /crp3/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXREPOFECRED.fmb -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch






echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXREPOFECRED " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXREPOFECRED.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXREPOFECRED.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2173" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2173_9274.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2173_9274.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
