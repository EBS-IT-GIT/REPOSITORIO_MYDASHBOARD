#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2458_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2458
# |
# | HISTORY
# |   29-APR-20  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2458_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2458_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2458
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/PROF
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/reports/US/
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2458" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2458_13881.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2458"
AddAllLogs $CROUT "FND" "CR2458_13881.ldt"
mv CR2458_13881.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF ACTUA_REMITOS " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','ACTUA_REMITOS','','$PATCHDIR','CR2458');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv ACTUA_REMITOS* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt PROFILE PROFILE_NAME="XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION" APPLICATION_SHORT_NAME="XBOL" LEV="" LEV_NAME=""
AddAllLogs $CROUT "FND" "XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt"
mv XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXINVREM " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXINVREM.fmb ]; then
  cp $AU_TOP/forms/US/XXINVREM.fmb XXINVREM.fmb
  echo `ls -lh XXINVREM.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXINVREM.fmb no existe" >> $CROUT
fi
mv XXINVREM* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto REPORTS- XXINVRTO " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/reports/US/XXINVRTO.rdf XXINVRTO.rdf
echo `ls -lh XXINVRTO.rdf` >> $CROUT

mv XXINVRTO* $DOWNDBDIR/xbol/12.0.0/reports/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXINVRTO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXINVRTO.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXINVRTO"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXINVRTO \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXINVRTO_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXINVRTO.ldt"
mv XXINVRTO* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF ACTUA_REMITOS " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/ACTUA_REMITOS >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/ACTUA_REMITOS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/ACTUA_REMITOS.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/ACTUA_REMITOS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/ACTUA_REMITOS.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/ACTUA_REMITOS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XX_INV_REMITOS_DIAS_ANTELACION_REIMPRESION.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXINVREM " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXINVREM.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXINVREM.fmb`" >> $CROUT
mv XXINVREM.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXINVREM.fmx` >> $CROUT
cd $CURDIR
if ! ls /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXINVREM.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXINVREM.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXINVREM.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXINVREM.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXINVREM.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto REPORTS- XXINVRTO " >> $CROUT; echo "" >> $CROUT
`cp $INSTDIR/xbol/12.0.0/reports/US/XXINVRTO.rdf $XBOL_TOP/reports/US`
echo `ls -lh $XBOL_TOP/reports/US/XXINVRTO.rdf` >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/XXINVRTO.rdf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/reports/US/XXINVRTO.rdf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/XXINVRTO.rdf  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/reports/US/XXINVRTO.rdf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/XXINVRTO.rdf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXINVRTO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXINVRTO \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXINVRTO_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVRTO_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXINVREM " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXINVREM.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXINVREM.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto REPORTS- XXINVRTO " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/xbol/12.0.0/reports/US/XXINVRTO.rdf $XBOL_TOP/reports/US

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2458" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2458_13881.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2458_13881.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
