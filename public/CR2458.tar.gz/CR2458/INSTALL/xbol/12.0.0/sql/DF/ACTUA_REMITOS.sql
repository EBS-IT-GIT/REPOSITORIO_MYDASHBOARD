  set define off;
update wsh_carrier_services set enabled_FLAG = 'N' 
where carrier_id = 22045 
and attribute2 is null 
and enabled_flag = 'Y' 
and upper(SHIP_METHOD_MEANING) not like  'PUESTO%' ;

UPDATE xx_inv_remitos_impresos
   SET copies = 1, print_date = last_update_date
 WHERE     TO_CHAR (creation_date, 'YYYY') = '2020'
       AND status = 'PRINTED'
       AND copies IS NULL;

COMMIT;

exit
