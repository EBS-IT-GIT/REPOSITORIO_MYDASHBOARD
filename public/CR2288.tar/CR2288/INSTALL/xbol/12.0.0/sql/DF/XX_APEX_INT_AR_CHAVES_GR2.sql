  set define off;
GRANT all ON  apps.XX_APEX_INT_AR_CHAVES  to BOLLINK;

exit
