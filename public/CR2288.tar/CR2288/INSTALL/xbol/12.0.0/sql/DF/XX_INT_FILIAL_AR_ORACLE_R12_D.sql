  set define off;
ORA-01422: exact fetch returns more than requested number of rows

exit
