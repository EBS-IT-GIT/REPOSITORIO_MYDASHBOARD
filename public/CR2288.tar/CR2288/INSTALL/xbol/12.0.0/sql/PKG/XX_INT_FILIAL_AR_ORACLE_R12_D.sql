  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_INT_FILIAL_AR_ORACLE_R12_D" AS

PROCEDURE log_p( p_name   IN VARCHAR2
                   ,p_msg    IN VARCHAR2 ) ;


PROCEDURE output_p ( p_type             IN VARCHAR2
                       ,p_header_id IN VARCHAR2 DEFAULT NULL
                       ,p_status           IN VARCHAR2 DEFAULT NULL
                       ,p_total            IN NUMBER   DEFAULT NULL
                       ,p_success          IN NUMBER   DEFAULT NULL
                       ,p_error            IN NUMBER   DEFAULT NULL ) ;


PROCEDURE main_p ( errbuf         OUT VARCHAR2
                     ,retcode        OUT NUMBER
                     ,p_origem       IN VARCHAR2 DEFAULT NULL
                  ) ;

End XX_INT_FILIAL_AR_ORACLE_R12_D;

/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_INT_FILIAL_AR_ORACLE_R12_D" IS
--
-- +===================================================================+
-- |         Copyright (c) 2017 Adecoagro, Sao Paulo , Brasil          |
-- |                         All rights reserved.                      |
-- +===================================================================+
-- |                                                                   |
-- | Name       : XX_INT_FILIAL_AR_ORACLE_R12_D                        |
-- |                                                                   |
-- |  Oracle Applications Rel 12.2.6                                   |
-- |   Produto.: Oracle                                                |
-- |  ### Chamado 95324 ###                                            |
-- |  Objetivo: CRIAR NOTAS NO AR PELO APEX :                          |
-- |      Emissor de Notas Fiscais de Formação de Lote - Filiais       |
-- |      http://192.168.14.202:8282/apex/f?p=106:1                    |
-- | History:                                                          |
-- | ==========                                                        |
-- | Version  Date          Author           Description               |
-- | =======  ============  ==============   ========================= |
-- | 1.0      30/08/2019    Douglas Sousa    Initial Version           |
-- |                                                                   |
-- +===================================================================+
--
   --

   PROCEDURE log_p( p_name   IN VARCHAR2
                   ,p_msg    IN VARCHAR2) IS
      --
      l_log_msg fnd_log_messages.message_text%TYPE;

      --
   BEGIN
      --
      l_log_msg := ' -> XX_INT_FILIAL_AR_ORACLE_R12_D.' || p_name || ' = ' || p_msg;
      --
         --
         dbms_output.put_line(l_log_msg);
         --
   END;
   --
   PROCEDURE output_p ( p_type             IN VARCHAR2
                       ,p_header_id        IN VARCHAR2 DEFAULT NULL
                       ,p_status           IN VARCHAR2 DEFAULT NULL
                       ,p_total            IN NUMBER   DEFAULT NULL
                       ,p_success          IN NUMBER   DEFAULT NULL
                       ,p_error            IN NUMBER   DEFAULT NULL) IS
      --
      l_trx_number  NUMBER;
      --
   BEGIN
      --
      IF p_type = 'HEADER' THEN
         --
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '|                          Integracao APEX com Módulo AR Oracle EBS                                              |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Sem Parâmetros na Concurrent                                                                                  |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Processado(s)                                                                                             |');
         fnd_file.put_line(fnd_file.OUTPUT, '| ------------------                                                                                             |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         --
      ELSIF p_type = 'ROW_HEADER' THEN
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|  Nro do Header PIMS: ' || RPAD(p_header_id,80, ' ')                                        || ' |');
   ----      fnd_file.put_line(fnd_file.OUTPUT, '|  Nro da nota Oracle: ' || RPAD(p_num_nota,80, ' ')                                        || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Nota Fiscal ' || RPAD(p_status,80, ' ')                                                 || ' |');
     --    fnd_file.put_line(fnd_file.OUTPUT, '|     Nro da NF: ' || RPAD(nvl(p_trx_number_dev,' '),95, ' ')                                               || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         --
      ELSIF p_type = 'SUM' THEN
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|           Total Registros: ' || RPAD(p_total,83, ' ')                                                     || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '| Total Registros (Sucesso): ' || RPAD(p_success,83, ' ')                                                   || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|    Total Registros (Erro): ' || RPAD(p_error,83, ' ')                                                     || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
         --
      END IF;
      --
   END;

   --

   PROCEDURE main_p ( errbuf         OUT VARCHAR2
                     ,retcode        OUT NUMBER
                     ,p_origem       IN VARCHAR2 DEFAULT NULL) IS
      --
      l_count_header             NUMBER;
      l_count_success           NUMBER;
      l_count_error             NUMBER;
      l_user_id                 NUMBER;
      l_ref_approved_sefaz      NUMBER;
      l_entry_cust_trx_type_id  NUMBER;
      l_count_lines             NUMBER;
      l_rma_trx_id              NUMBER;
      l_msg_count               NUMBER  := 0;
      l_customer_trx_id         NUMBER;
      l_resp_id                 NUMBER;
      l_resp_appl_id            NUMBER;
      l_total_gr_weight         NUMBER;
      l_total_nt_weight         NUMBER;
      l_org_id                  NUMBER;
      --
      l_name                    VARCHAR2(100);
      l_new_trx_number          VARCHAR2(100);
      l_return_status           VARCHAR2(1);
      l_msg_data                VARCHAR2(2000);
      l_msg_data_out            VARCHAR2(2000);
      l_peso_liquido            number(10,3);  --> DOUGLAS SOUSA 26/11/2019
      l_peso_bruto              number(10,3);  --> DOUGLAS SOUSA 26/11/2019
  --    l_volume_quantity         VARCHAR2(100);
      l_volume_type             VARCHAR2(100);
  --    l_volume_number           VARCHAR2(100);
   --   l_additional_info         VARCHAR2(2000);
--      l_nop                     VARCHAR2(100);
      l_country_code            VARCHAR2(30);

      --
      l_ref_exchange_date       DATE;
      --
      l_error                   BOOLEAN := FALSE;
      --
      l_batch_source_rec        ar_invoice_api_pub.batch_source_rec_type;
      l_trx_header_tbl          ar_invoice_api_pub.trx_header_tbl_type;
      l_trx_lines_tbl           ar_invoice_api_pub.trx_line_tbl_type;
      l_trx_dist_tbl            ar_invoice_api_pub.trx_dist_tbl_type;
      l_trx_salescredits_tbl    ar_invoice_api_pub.trx_salescredits_tbl_type;
      ln_msg_index_out          NUMBER;
      lv_sqlerrm                VARCHAR2(4000) := NULL;
      --


      CURSOR c_header /*( pc_org_id     IN NUMBER
                       ,pc_rma_number IN NUMBER) */ IS

      SELECT DISTINCT xhpa.FILIAL,
       xhpa.header_id, hcsua_bill.LOCATION
      ,'' order_number
      ,'' customer_trx_id
      ,'' trx_number
   --   ,rctta.name cust_trx_type_name
      , rctta.cust_trx_type_id  cust_trx_type_id
      ,'BRL' invoice_currency_code
      ,hcasa.cust_account_id bill_to_customer_id
      ,hcsua_bill.cust_acct_site_id bill_cust_acct_site_id
      ,hcasa.cust_account_id ship_to_customer_id
      ,hcsua_ship.cust_acct_site_id ship_cust_acct_site_id
      ,'' exchange_rate_type
      ,'' exchange_date
      ,'' exchange_rate
 ---    ,'SEM MOVIMENTACAO FISICA' ship_via
     ,'ALL'  ship_via   ---> DOUGLAS SOUSA 26/11/2019 - TRANSPORTADORA FIXA  aqui e o NOME ABREVIADO da transportadora 'RUMO MALHA SUL S.A' = ALL   
 ----     ,'ADECOAGRO VALE DO IVINHEMA S.A.'  ship_via   ---> DOUGLAS SOUSA - TESTE   da erro de muito grande to small       
      ,rctta.org_id
      ---- ,nvl(hcsua_ship.fob_point,1) fob_point --> DOUGLAS SOUSA 26/11/2019
      ,1 fob_point --> DOUGLAS SOUSA 26/11/2019 - FRETE FOB
      ,DECODE(rctta.org_id,196,100007051,110,100021041) primary_salesrep_id
      ,'' default_tax_exempt_flag
      ,'JL.BR.ARXTWMAI.Additional Info' global_attribute_category
     ---- ,rctta.default_term term_id
      , 1052 term_id
       ,rbsa.name batch_source_name
    --  ,(select nvl(global_attribute1,rbsa.batch_source_id)
    --     from apps.ra_batch_sources_all rbsa
    --    where rbsa.name = 'MAR-SERIE05 MANUAL' /*xhpa.batch_source_name*/) batch_source_id
      , DECODE(xhpa.FILIAL, 'MAR', 9844, 9846 /*8844*/) batch_source_id   --> DOUGLAS SOUSA 11/11/2019
      ,'' name
    --  ,(select address_id
    --      from apps.ar_remit_to_addresses_v ar
    --      where ar.org_id = rctta.org_id
    --        and rownum = 1 ) remit_to_address_id -- Douglas
      , 9761 remit_to_address_id
  --    ,xhpa.trx_date
  ----    ,'' chave_nfe
      ,xhpa.CHAVE_ACESSO_PRINCIPAL chave_nfe
      ,xhpa.COMMENTS
  --    ,xhpa.ADDITIONAL_INFO
 --     ,xhpa.USUARIO -- DOUGLAS SOUSA 30/01/2019
 ---     ,xhpa.INSTANCIA -- Douglas 13/02/2019
     --- ,xhpa.customer_trx_id
  FROM /*apps.xx_header_pims_ar*/ apps.XX_APEX_INT_AR_HEADER          xhpa
      ,apps.ra_cust_trx_types_all      rctta
      ,apps.hz_cust_site_uses_all      hcsua_bill
      ,apps.hz_cust_site_uses_all      hcsua_ship
      ,apps.hz_cust_acct_sites_all     hcasa
      ,apps.ra_batch_sources_all       rbsa
 where xhpa.TRANSACAO = rctta.name
---  and /*xhpa.local_bill_to*/'001687' = hcsua_bill.LOCATION
 AND DECODE(xhpa.FILIAL, 'MAR', '001687', 'APR', '001504') = hcsua_bill.LOCATION
  AND hcasa.cust_acct_site_id = hcsua_bill.cust_acct_site_id
  AND hcasa.cust_acct_site_id = hcsua_ship.cust_acct_site_id
  AND xhpa.ORIGEM = rbsa.name
  AND xhpa.customer_trx_id IS NULL; --Douglas Sousa 30/01/2019
----  and header_id = 98;



CURSOR c_lines ( pc_header_id NUMBER) IS

        SELECT     xlpa.header_id,
                xlpa.line_id,
                10919  inventory_item_id,
                xlpa.QTDE_TONELADA,
                xlpa.VLR_UNITARIO,
  ------              round((xlpa.quantity * xlpa.unit_selling_price),2) amount,   -- DOUGLAS SOUSA
                'TON' uom_code,
         ----   1166 organization_id, -- DOUGLAS SOUSA 14/11/2019 - PEGA ORGANIZAÇÃO PARA MUDAR CNPJ DO EMITENTE
                DECODE(xlpa.DEPOSITO, '2H8',1098, '2Q8', 1166, 505 ) organization_id, -- DOUGLAS SOUSA 14/11/2019 - PEGA ORGANIZAÇÃO PARA MUDAR CNPJ DO EMITENTE
                '0' global_attribute4,
                '04' Global_Attribute5,
                '00' global_attribute6,
                '000'  global_attribute7
                ---xlpa.instancia -- Douglas 13/02/2019
           FROM apps.XX_APEX_INT_AR_LINES              xlpa
          WHERE  xlpa.header_id         = pc_header_id;  --  31

     /*SELECT     xlpa.header_id,
                xlpa.line_id,
                msi.inventory_item_id,
                xlpa.quantity,
                xlpa.unit_selling_price,
  ------              round((xlpa.quantity * xlpa.unit_selling_price),2) amount,   -- DOUGLAS SOUSA
                miuv.uom_code, --Douglas
                ood.organization_id,
                msi.global_attribute3 global_attribute4, --Douglas
                msi.global_attribute4 Global_Attribute5, --Douglas
                msi.global_attribute5 global_attribute6, --Douglas
                msi.global_attribute6 global_attribute7, --Douglas
                xlpa.instancia -- Douglas 13/02/2019
           FROM apps.xx_lines_pims_ar              xlpa
               ,apps.org_organization_definitions  ood
               ,apps.hr_organization_units_v       hou
               ,apps.mtl_system_items_b            msi
               ,apps.mtl_item_uoms_view            miuv
          WHERE ood.operating_unit     =  hou.organization_id
            and ood.organization_id    = msi.organization_id
            and xlpa.instancia         = pc_INSTANCIA  --Douglas 13/02/2019
            and xlpa.header_id         = pc_header_id -- Douglas
            AND substr(warehouse_name, 1,3) = SUBSTR(V_batch_source_name,1,3)  -- DOUGLAS SOUSA 30/01/2019
            and xlpa.cod_item          = msi.segment1
            and unit_of_measure        = msi.unit_of_issue
            and miuv.inventory_item_id = msi.inventory_item_id
            AND miuv.organization_id   = msi.organization_id
            and ood.organization_name  = xlpa.warehouse_name;*/

      CURSOR c_chave ( pc_header_id NUMBER) IS

      SELECT X.VALUE
            FROM (SELECT Chave_acesso1 VALUE
                  FROM XX_APEX_INT_AR_CHAVES
                  WHERE  header_id   = pc_header_id
            UNION ALL
                SELECT Chave_acesso2 VALUE
                FROM XX_APEX_INT_AR_CHAVES
                  WHERE  header_id   = pc_header_id
            UNION ALL
                SELECT Chave_acesso3 VALUE
                FROM XX_APEX_INT_AR_CHAVES
                  WHERE  header_id   = pc_header_id
            UNION ALL
                SELECT Chave_acesso4 VALUE
                FROM XX_APEX_INT_AR_CHAVES
                  WHERE  header_id   = pc_header_id
            UNION ALL
                SELECT Chave_acesso5 VALUE
                FROM XX_APEX_INT_AR_CHAVES
                  WHERE  header_id   = pc_header_id
            UNION ALL
                SELECT Chave_acesso6 VALUE
                FROM XX_APEX_INT_AR_CHAVES
                  WHERE  header_id   = pc_header_id ) X
            WHERE  X.VALUE IS NOT NULL ;


      --
   BEGIN
      --
      dbms_output.enable(1000000);
      l_name := 'MAIN_P';
      --
  --    log_p(l_name,' ');
  --    log_p(l_name,'Iniciando a Leitura para Alimentar a API');
  --    log_p(l_name,' ');
     -- log_p(l_name,'Parametros do Concurrent');
   --   log_p(l_name,'    Org Id: ' || p_org_id);
    --  log_p(l_name,'Numero RMA: ' || p_rma_number);
   --   log_p(l_name,' ');
      --
  --    output_p( p_type              => 'HEADER'
     --          ,p_org_id            => p_org_id
            --   ,p_rma_number_param  => p_rma_number
   --         );
      --
      --
--Variavel


      log_p(l_name,'Inicializando as variaveis');
      --
      log_p(l_name,'********************************');
      --
      l_count_success := 0;
      l_count_error   := 0;
      l_count_header  := 0;
      --
      log_p(l_name,'Abrindo o cursor c_header');
      --
      FOR r_header IN c_header /*( pc_org_id      => p_org_id
                                ,pc_rma_number  => p_rma_number
                                )*/  LOOP -- LOOP r_header

         --
         l_count_header   := l_count_header + 1;
         l_volume_type := NULL;
         --

         ---> inicio
              BEGIN
            SELECT fu.user_id,
                   fr.responsibility_id,
                   (select fpov.profile_option_value
                      from apps.fnd_profile_option_values fpov,
                           apps.fnd_profile_options       fpo,
                           apps.fnd_responsibility_vl     fr
                     where fpo.profile_option_id   = fpov.profile_option_id
                       and fr.responsibility_id = fpov.level_value
                       and fr.responsibility_id = furg.responsibility_id
                       and fpov.level_id = 10003
                       and fpo.profile_option_name = 'ORG_ID') org_id

             into l_user_id,
                  l_resp_id,
                  l_org_id

             FROM apps.fnd_user fu,
                  apps.fnd_user_resp_groups_direct furg,
                  apps.fnd_responsibility_vl fr
            WHERE fu.user_id = furg.user_id
              AND furg.responsibility_application_id = 222
              AND furg.responsibility_id = fr.responsibility_id
              AND furg.end_date IS NULL
              AND fu.user_name = /*r_header.USUARIO --*/'AMSILVA' --PARAMETRO  (AMSILVA - AVI, NBARBOSA - UMA)  -- r_header.USUARIO   -- DOUGLAS SOUSA 31/01/2019
              AND exists (select fpov.profile_option_value,fr.responsibility_name
                            from apps.fnd_profile_option_values fpov,
                                 apps.fnd_profile_options       fpo,
                                 apps.fnd_responsibility_vl     fr
                          where fpo.profile_option_id   = fpov.profile_option_id
                            and fr.responsibility_id = fpov.level_value
                            and fr.responsibility_id = furg.responsibility_id
                            and fpov.profile_option_value in ('110','196')
                            and fr.responsibility_name LIKE '%OM FATURAMENTO BRA'
                            and fpov.level_id = 10003
                            and fpo.profile_option_name = 'ORG_ID')
              AND ROWNUM = 1;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          log_p (l_name, '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
          log_p (l_name, 'ERRO: Dados nao encontrados ao consultar USER_ID e RESPONSIBILITY_ID - ' || SQLERRM);
          log_p (l_name, '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
          retcode := 2;
          errbuf  := 'ERRO: Dados nao encontrados ao consultar USER_ID e RESPONSIBILITY_ID - ' || SQLERRM;
          RAISE_APPLICATION_ERROR (-20001, 'ERRO: Dados nao encontrados ao consultar USER_ID e RESPONSIBILITY_ID - '||SQLERRM);
      END;


      fnd_global.apps_initialize ( user_id      => l_user_id
                                  ,resp_id      => l_resp_id
                                  ,resp_appl_id => 222);  --l_resp_appl_id);   -- DOUGLAS SOUSA

      mo_global.set_policy_context('S', l_org_id);  -- DOUGLAS SOUSA
      --
         --> fim

               BEGIN
                  --
                  --
                  l_batch_source_rec.batch_source_id                  := r_header.batch_source_id; -- r_header.batch_source_id;
                  --
                  log_p(l_name,'Populando as informacoes do cabecalho da Nota Fiscal');
                  --
                  l_trx_header_tbl(1).trx_header_id                     := r_header.header_id; --1;
--                  l_trx_header_tbl(1).trx_number                        := '53163';
                  l_trx_header_tbl(1).trx_currency                      := r_header.invoice_currency_code;  -- OK
                  l_trx_header_tbl(1).cust_trx_type_id                  := r_header.cust_trx_type_id;  -- OK
                  l_trx_header_tbl(1).trx_date                          := SYSDATE; -- r_header.trx_date; -- OK
                  l_trx_header_tbl(1).term_id                           := r_header.term_id; -- OK
                  l_trx_header_tbl(1).bill_to_customer_id               := r_header.bill_to_customer_id; -- OK
                  l_trx_header_tbl(1).bill_to_address_id                := r_header.bill_cust_acct_site_id; -- OK
                  l_trx_header_tbl(1).ship_to_customer_id               := r_header.ship_to_customer_id; -- OK
                  l_trx_header_tbl(1).ship_to_address_id                := r_header.ship_cust_acct_site_id; -- OK
                  l_trx_header_tbl(1).sold_to_customer_id               := r_header.bill_to_customer_id; -- OK
                  l_trx_header_tbl(1).remit_to_address_id               := r_header.remit_to_address_id; -- OK
                  l_trx_header_tbl(1).exchange_rate_type                := r_header.exchange_rate_type; -- está Nulo
                  l_trx_header_tbl(1).exchange_date                     := r_header.exchange_date;-- está Nulo
                  l_trx_header_tbl(1).exchange_rate                     := r_header.exchange_rate;-- está Nulo
                  l_trx_header_tbl(1).ship_date_actual                  := SYSDATE;
                  l_trx_header_tbl(1).ship_via                          := r_header.ship_via;  -- OK
                  l_trx_header_tbl(1).fob_point                         := r_header.fob_point; --Douglas
                  l_trx_header_tbl(1).primary_salesrep_id               := r_header.primary_salesrep_id; -- OK
                  l_trx_header_tbl(1).default_tax_exempt_flag           := r_header.default_tax_exempt_flag; -- está Nulo
                  l_trx_header_tbl(1).org_id                            := r_header.org_id; -- OK
                  l_trx_header_tbl(1).global_attribute_category         := r_header.global_attribute_category;
     --             l_trx_header_tbl(1).interface_header_context          := 'TRANSACAO PIMS'; -- Vai criar no EBS
     --             l_trx_header_tbl(1).interface_header_attribute1       := r_header.header_id;
     --             l_trx_header_tbl(1).interface_header_attribute2       := 'FILIAL'; --r_header.INSTANCIA; --Douglas 13/02/2019
     --             l_trx_header_tbl(1).interface_header_attribute3       := ''; --r_header.trx_number;
     ----             l_trx_header_tbl(1).attribute_category                := 'BR'; --DOUGLAS
                  l_trx_header_tbl(1).attribute6                        := r_header.chave_nfe;  ---  '32154678945612313231321321321312546897545421'; -- r_header.chave_nfe --DOUGLAS
                  l_trx_header_tbl(1).attribute2                        := ''; --r_header.trx_number;
                  l_trx_header_tbl(1).attribute14                       := ''; --r_header.chave_nfe;
                  l_trx_header_tbl(1).attribute13                       := ''; --to_char(r_header.trx_date, 'RRRR/MM/DD HH24:MI:SS');
                  l_trx_header_tbl(1).global_attribute_category         := 'JL.BR.ARXTWMAI.Additional Info';
                  l_trx_header_tbl(1).global_attribute13                := ''; --l_volume_quantity;
                  --l_trx_header_tbl(1).global_attribute14                := l_volume_type; --Douglas
                  l_trx_header_tbl(1).global_attribute15                := ''; --l_volume_number;
                  --l_trx_header_tbl(1).global_attribute16                := l_total_gr_weight; --Douglas
                  --l_trx_header_tbl(1).global_attribute17                := l_total_nt_weight; --Douglas
                  l_trx_header_tbl(1).comments                          := r_header.COMMENTS;   ---  'TESTE INF ADIC';--r_header.ADDITIONAL_INFO;
                  --
               END;
               --
               log_p(l_name,'Abrindo o cursor c_lines');
               --
               l_count_lines := 0;
               --

               -- COMENTADO LINES INICIO...
               FOR r_lines IN c_lines ( pc_header_id => r_header.header_id ) --> DOUGLAS SOUSA
               --FOR r_lines IN c_lines
                                      LOOP -- r_lines
                  --
                  BEGIN
                      --> Douglas 05/10/2018 - INCIO.....
                           IF NOT l_error THEN -- IF NOT l_error
                                 --
                                 log_p(l_name,'Recuperando os dados de volume');
                                 --
                                BEGIN

                                  select -- sum(xlpa.quantity) total_gr_weight,
                                       apps.xx_om_int_adeco_prest_pkg.canonical_to_number_f(sum(xlpa.quantity)) total_gr_weight,
                                  ---       sum(xlpa.quantity) total_nt_weight
                                       apps.xx_om_int_adeco_prest_pkg.canonical_to_number_f(sum(xlpa.quantity)) total_nt_weight
                                         INTO l_total_gr_weight
                                             ,l_total_nt_weight
                                     from apps.xx_lines_pims_ar xlpa,
                                         apps.mtl_system_items_b msi
                                   where xlpa.header_id = r_header.header_id
                                     and xlpa.cod_item  = msi.segment1
                                     and msi.organization_id = r_lines.organization_id;
                                 EXCEPTION
                                    /*WHEN too_many_rows THEN
                                      l_total_gr_weight := 0;
                                      l_total_nt_weight := 0;
                                      l_volume_type     := 0;*/

                                    WHEN OTHERS THEN
                                      --
                                      l_total_gr_weight  := 0;
                                      l_total_nt_weight  := 0;
                                      log_p(l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                                      log_p(l_name,'WARNING: Erro ao encontrar os dados de volume - ' || SQLERRM);
                                      log_p(l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                                      --
                                 END;

--
                           BEGIN

                                  if l_volume_type is null then
                                      select msi.unit_of_issue volume_type
                                        INTO l_volume_type
                                        from apps.mtl_system_items_b msi
                                       where msi.inventory_item_id = r_lines.inventory_item_id
                                         and msi.organization_id = r_lines.organization_id;
                                 end if;

                                 EXCEPTION
                                    /*WHEN too_many_rows THEN
                                      l_total_gr_weight := 0;
                                      l_total_nt_weight := 0;
                                      l_volume_type     := 0;*/

                                    WHEN OTHERS THEN

                                      --
                                      l_volume_type      := 0;
                                      log_p(l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                                      log_p(l_name,'WARNING: Erro ao encontrar os dados de volume - ' || SQLERRM);
                                      log_p(l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                                      --
                                 END;

                              end if;



                     --> Douglas 05/10/2018 - FIM.....

                     --
                     l_count_lines := l_count_lines + 1;
                     --
--                     l_trx_header_tbl(1).interface_header_attribute4                := r_lines.line_id; --Douglas 13/02/2019
                     --
                     log_p(l_name,'Populando as informacoes da linha da Nota Fiscal');
                     --
                     l_trx_lines_tbl(l_count_lines).trx_header_id                    := r_header.header_id; -- era 1;
                     l_trx_lines_tbl(l_count_lines).trx_line_id                      := r_lines.line_id;-- to_number('1' || l_count_lines);
                     l_trx_lines_tbl(l_count_lines).line_number                      := l_count_lines;
                    /* l_trx_lines_tbl(l_count_lines).interface_line_context           := 'TRANSACAO PIMS';
                     l_trx_lines_tbl(l_count_lines).interface_line_attribute1        := r_header.header_id;
                     l_trx_lines_tbl(l_count_lines).interface_line_attribute2        := r_lines.line_id;
                     l_trx_lines_tbl(l_count_lines).interface_line_attribute3        := 20; --r_lines.instancia; --Douglas 13/02/2019
*/                     l_trx_lines_tbl(l_count_lines).line_type                        := 'LINE';
                     l_trx_lines_tbl(l_count_lines).description                      := ''; --r_lines.description;
 ----                    l_trx_lines_tbl(l_count_lines).amount                           := r_lines.amount;  -- Douglas Sousa 12/03/2019
                     l_trx_lines_tbl(l_count_lines).quantity_invoiced                := r_lines.QTDE_TONELADA;
                     l_trx_lines_tbl(l_count_lines).quantity_ordered                 := r_lines.QTDE_TONELADA;
                     l_trx_lines_tbl(l_count_lines).unit_selling_price               := r_lines.VLR_UNITARIO;
                     l_trx_lines_tbl(l_count_lines).unit_standard_price              := r_lines.VLR_UNITARIO;
                     l_trx_lines_tbl(l_count_lines).inventory_item_id                := r_lines.inventory_item_id;
                     l_trx_lines_tbl(l_count_lines).uom_code                         := r_lines.uom_code; --Douglas
                     l_trx_lines_tbl(l_count_lines).global_attribute_category        := 'JL.BR.ARXTWMAI.Additional Info';--r_lines.global_attribute_category;
                     l_trx_lines_tbl(l_count_lines).global_attribute2                := ''; --r_lines.line_gdf_attribute2;
                     l_trx_lines_tbl(l_count_lines).global_attribute3                := ''; --r_lines.line_gdf_attribute3;
                     l_trx_lines_tbl(l_count_lines).global_attribute4                := r_lines.global_attribute4; --Douglas
                     l_trx_lines_tbl(l_count_lines).global_attribute5                := r_lines.Global_Attribute5; --Douglas
                     l_trx_lines_tbl(l_count_lines).global_attribute6                := r_lines.global_attribute6; --Douglas
                     l_trx_lines_tbl(l_count_lines).global_attribute7                := r_lines.global_attribute7; --Douglas
                     l_trx_lines_tbl(l_count_lines).warehouse_id                     := r_lines.organization_id;
                     l_trx_lines_tbl(l_count_lines).attribute3                       := ''; --r_lines.attribute3;
                     l_trx_lines_tbl(l_count_lines).attribute2                       := ''; --r_lines.attribute2;
                     l_trx_lines_tbl(l_count_lines).attribute8                       := ''; --r_lines.attribute8;
                     --

                     log_p(l_name,'Interface line 1 = '||r_header.order_number);
                     log_p(l_name,'Interface line 2 = '||r_header.name);
                     log_p(l_name,'Interface line 3 = '||r_header.trx_number);
                     log_p(l_name,'Interface line 4 = '||r_lines.line_id);
                     log_p(l_name,'Batch Source = '||r_header.batch_source_name);

                     log_p(l_name,'Populando as informacoes de salescredit da Nota Fisca do AR');
                     --
     --                l_trx_salescredits_tbl(l_count_lines).trx_line_id               := to_number('1' || l_count_lines);    -- DOUGLAS SOUSA 04/10/2018
     ----                l_trx_salescredits_tbl(l_count_lines).salesrep_id               := r_header.primary_salesrep_id;     -- DOUGLAS SOUSA 04/10/2018
     --                l_trx_salescredits_tbl(l_count_lines).sales_credit_type_id      := 1;                                  -- DOUGLAS SOUSA 04/10/2018
     --                l_trx_salescredits_tbl(l_count_lines).salescredit_percent_split := 100;                                -- DOUGLAS SOUSA 04/10/2018
                     --
                     log_p(l_name,'Inserindo o registro na tabela XX_APEX_INT_AR_HEADER');
                     --
                  END;
                  --
                   l_peso_liquido := r_lines.QTDE_TONELADA;  -- DOUGLAS SOUSA 26/11/2019
                   l_peso_bruto := r_lines.QTDE_TONELADA;  -- DOUGLAS SOUSA 26/11/2019
                  --
               END LOOP; -- LOOP r_lines
               --
               -- Douglas --
               -- As variaveis abaixo sao populadas dentro do cursor 'c_lines' !!!
               --
               l_trx_header_tbl(1).global_attribute14 := l_volume_type;
              --- l_trx_header_tbl(1).global_attribute16 := l_total_gr_weight;   --- r_lines.QTDE_TONELADA
              --- l_trx_header_tbl(1).global_attribute16 := REPLACE(20000/*l_total_gr_weight*/,',','.');  -- DOUGLAS SOUSA 06/02/2019
               l_trx_header_tbl(1).global_attribute16 := REPLACE(l_peso_liquido,',','.');  -- DOUGLAS SOUSA 26/11/2019
             ---  l_trx_header_tbl(1).global_attribute17 := l_total_nt_weight;
             ----  l_trx_header_tbl(1).global_attribute17 := REPLACE(45000/*l_total_nt_weight*/,',','.');  -- DOUGLAS SOUSA 06/02/2019
               l_trx_header_tbl(1).global_attribute17 := REPLACE(l_peso_bruto,',','.');  -- DOUGLAS SOUSA 26/11/2019
               -- Douglas -- fim


               -- COMENTADO LINES ... fim
               --
           ----   IF NOT l_error THEN -- IF NOT l_error
                  --
                  BEGIN
                     --
                     log_p(l_name,'Chamando a API para criar a Nota Fiscal no AR');
                     --
                     BEGIN
                        --
                    ----    fnd_profile.get('JGZZ_COUNTRY_CODE', l_country_code);
                     ----   log_p(l_name,l_country_code);
                        --
                        ar_invoice_api_pub.create_single_invoice( p_api_version          => 1.0                      -- IN
                                                                 ,p_init_msg_list        => FND_API.G_TRUE           -- IN
                                                                 ,p_commit               => FND_API.G_FALSE          -- IN
                                                                 ,p_batch_source_rec     => l_batch_source_rec       -- IN
                                                                 ,p_trx_header_tbl       => l_trx_header_tbl         -- IN
                                                                 ,p_trx_lines_tbl        => l_trx_lines_tbl          -- IN
                                                                 ,p_trx_dist_tbl         => l_trx_dist_tbl           -- IN
                                                                 ,p_trx_salescredits_tbl => l_trx_salescredits_tbl   -- IN
                                                                 ,x_customer_trx_id      => l_customer_trx_id        -- OUT
                                                                 ,x_return_status        => l_return_status          -- OUT
                                                                 ,x_msg_count            => l_msg_count              -- OUT
                                                                 ,x_msg_data             => l_msg_data               -- OUT
                                                                );

--Douglas 13/02/2019 log
                      dbms_output.put_line('l_return_status: '||l_return_status);
                      FND_FILE.PUT_LINE(FND_FILE.LOG, 'l_return_status: '||l_return_status);
                      --
                      IF l_return_status = fnd_api.g_ret_sts_error OR l_return_status = fnd_api.g_ret_sts_unexp_error THEN
                        dbms_output.put_line('FND_MSG_PUB.Count_Msg ');
                        dbms_output.put_line(l_return_status||': '||SQLERRM);
                        FND_FILE.PUT_LINE(FND_FILE.LOG, 'FND_MSG_PUB.Count_Msg ');
                        FND_FILE.PUT_LINE(FND_FILE.LOG, l_return_status||': '||SQLERRM);
                        --
                        FOR l_msg_count IN 1..FND_MSG_PUB.Count_Msg LOOP
                          FND_MSG_PUB.Get (p_msg_index     => l_msg_count
                                          ,p_encoded       => 'F'
                                          ,p_data          => l_msg_data
                                          ,p_msg_index_OUT => ln_msg_index_out);
                          --
                          lv_sqlerrm := SUBSTR(lv_sqlerrm||REPLACE(l_msg_data,CHR(10),''),1,3998);
                          dbms_output.put_line(l_return_status||': '||lv_sqlerrm);
                          FND_FILE.PUT_LINE(FND_FILE.LOG, l_return_status||': '||lv_sqlerrm);
                        END LOOP;
                        --
                        FND_MSG_PUB.Delete_Msg;
                      ELSE
                        dbms_output.put_line('FND_MSG_PUB.Count_Msg else: '||FND_MSG_PUB.Count_Msg);
                        FND_FILE.PUT_LINE(FND_FILE.LOG, 'FND_MSG_PUB.Count_Msg else: '||FND_MSG_PUB.Count_Msg);
                      END IF;

--Douglas 13/02/2019 log

                     EXCEPTION
                        WHEN OTHERS THEN
                           --
                           log_p (l_name, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           log_p (l_name, 'ERRO: Chamando a API para criar a Nota Fiscal no AR - ' || SQLERRM);
                           log_p (l_name, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           l_new_trx_number := 'ERRO Chamando a API para criar a Nota Fiscal no AR - '|| SUBSTR(SQLERRM, 1,30);
                           --
                       ----    l_error := TRUE;
                           --
                     END;
                     --
                     IF l_return_status != FND_API.G_RET_STS_SUCCESS THEN
                        l_count_error:= l_count_error + 1;
                     ELSE
                         l_count_success := l_count_success + 1;
                     END IF;
                     --
                     FOR i IN (SELECT error_message
                                 FROM ar_trx_errors_gt) LOOP -- FOR i IN (SELECT error_message FROM ar_trx_errors_gt)
                       --
                       log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++');
                       log_p (l_name,'ERRO: API ' || i.error_message);
                       log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++');
                       --
                   ----------    l_new_trx_number := 'ERRO: API ' || i.error_message;  -- estou de variavel
                       --
                     END LOOP; -- FOR i IN (SELECT error_message FROM ar_trx_errors_gt)
                     --

                        BEGIN
                           --
                           SELECT rcta.trx_number
                             INTO l_new_trx_number
                             FROM apps.ra_customer_trx_all rcta
                            WHERE rcta.customer_trx_id = l_customer_trx_id;
                           --
                        EXCEPTION
                           WHEN OTHERS THEN
                              l_new_trx_number := 9999;   ---'ERRO: Ao processar a Transação do APEX no Oracle';
                              --
                              log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                              log_p (l_name,'ERRO: Ao processar a Transação do APEX no Oracle');
                              log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                              --
                           ----   l_error := TRUE;
                              --
                        END;
                        --
                        log_p(l_name,'Nota Fiscal criada com successo');
                        log_p(l_name,'Nro da NF: '       || l_new_trx_number);
                        log_p(l_name,'Customer Trx Id: ' || l_customer_trx_id);
                        log_p(l_name,'Nro de Linhas: '   || l_count_lines);
                        --
                            --> DOUGLAS SOUSA 05/09/2019
                            IF l_customer_trx_id IS NOT NULL THEN
                              FOR r_chave IN c_chave ( pc_header_id => r_header.header_id ) LOOP
                                   BEGIN
                                     INSERT INTO apps.xx_br_chaves_acesso_referencia
                                                   (
                                                    CHAVE_ACESSO,
                                                    CUSTOMER_TRX_ID
                                                   )
                                                 VALUES
                                                   (
                                                    r_chave.VALUE,
                                                    l_customer_trx_id
                                                    );
                                  EXCEPTION
                                   WHEN OTHERS THEN
                                      log_p(l_name,'ERRO AO INSERIR CHAVE NA TABELA');
                                  END;

                               END LOOP;

                            END IF;
                            ---

                            BEGIN
                             UPDATE XX_APEX_INT_AR_HEADER
                              SET  customer_trx_id = l_customer_trx_id,
                                   STATUS = NVL(l_new_trx_number, 'INTEGRADO')
                              WHERE header_id = r_header.header_id

                              ;

                                COMMIT;

                             EXCEPTION

                              WHEN OTHERS THEN
                                 --
                                 log_p (l_name, '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                                 log_p (l_name, 'ERRO: Erro ao atualizar campos na tabela XX_APEX_INT_AR_HEADER  - ' || SQLERRM);
                                 log_p (l_name, '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                                 --
                           END;
                  END;
                  --

                /*  output_p( p_type            => 'ROW_HEADER'
                     ---      ,p_num_nota        => 'ERRO NA API'   -- DOUGLAS SOUSA - NUMERO DA NOTA CRIADA NO ORACLE
                           ,p_header_id_pims => r_header.header_id
                        ---   ,p_trx_number_dev  => l_new_trx_number
                           ,p_status          => 'ERRO');*/

                  --
                  COMMIT;
                  --
            ---      l_count_success := l_count_success + 1;
                  --
                  output_p( p_type            => 'ROW_HEADER'
                    ---       ,p_num_nota      => l_new_trx_number   -- DOUGLAS SOUSA - NUMERO DA NOTA CRIADA NO ORACLE
                           ,p_header_id => r_header.header_id
                        --   ,p_trx_number_dev  => l_new_trx_number
                           ,p_status          => ' Integrada com Sucesso');
                  --
         --
      END LOOP; -- LOOP r_header
      --
      log_p(l_name,'-----------------------------------');
      log_p(l_name,'          Total Registros: ' || l_count_header);
      log_p(l_name,'Total Registros (Sucesso): ' || l_count_success);
      log_p(l_name,'   Total Registros (Erro): ' || l_count_error);
      log_p(l_name,'-----------------------------------');
      --
      output_p( p_type    => 'SUM'
               ,p_total   => l_count_header
               ,p_success => l_count_success
               ,p_error   => l_count_error);
      --
      IF l_count_header = l_count_success THEN -- IF l_count_total = l_count_success
         --
         retcode := 0;
         errbuf  := 'Integracao APEX x Ar realizada com sucesso';
         --
      ELSIF l_count_header = l_count_error THEN -- IF l_count_total = l_count_success
         --
         retcode := 1; -- Termina concurrent com ADVERTENCIA, mas NAO para o processo.
       ---  retcode := 2;
         errbuf  := 'Integracao APEX x Ar realizada com ERRO';
         --
      ELSE -- IF l_count_total = l_count_success
         --
         retcode := 1;
         errbuf  := 'Integracao APEX x Ar realizada com ALERTAS, verificar';
         --
      END IF; -- IF l_count_total = l_count_success
      --
   END;
END XX_INT_FILIAL_AR_ORACLE_R12_D;
/

exit
