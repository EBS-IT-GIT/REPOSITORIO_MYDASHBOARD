WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE apps.XXSTN_GL_COSIF_REL_MAPEAMENTO IS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_GL_COSIF_REL_MAPEAMENTO_PS.sql                            |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Stone - Relat�rio Regras de Mapeamento de Plano de Contas     |
-- |                                                                 |
-- | CREATED BY   Rogerio Farto - Ninecon - 08/06/2020               |
-- |              SR#518849 - NSD320097                              |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;

  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_mapeamento     IN NUMBER);

END XXSTN_GL_COSIF_REL_MAPEAMENTO;
/

EXIT; 