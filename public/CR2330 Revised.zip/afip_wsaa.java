package afip.wsaa;

import java.io.Reader;
import java.io.StringReader;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;

public class afip_wsaa {

  public static void main(String [] args ) {
/*
    String db_conn_stmt = "jdbc:oracle:thin:APPS/ADECOAPPS1980@ad-ar-cat-db-05.adeco.net.ar:10010:DADAGI";//args[0];
    String secureDir = "C:\\Users\\apetrocelli\\Documents\\MyReqs\\Req262 - CR2134\\Pasaje a PADAGI\\secure"; //args[1];
    //String secureDir = "/dadagi/applmgr/11510/xbol/11.5.0/bin/WebServices/secure"; //args[1];
    String service   = "wsctg"; //args[2];
    String company   = "30506898591"; //args[3];
    String genTime   = "2015-08-24T12:00:00.000-03:00"; //args[4];
    String expTime   = "2015-08-24T23:00:00.000-03:00"; //args[5];
    String oraUserID = "23077"; //args[6];
    String oraLoginID = "70004185"; //args[7];
    String LoginTicketResponse = null;
*/

/*
    System.out.println("Default Charset=" + Charset.defaultCharset());
    System.out.println("file.encoding=" + System.getProperty("file.encoding"));
    Field charset = null;   
    System.setProperty("file.encoding", "UTF-8");
    try {
      charset = Charset.class.getDeclaredField("defaultCharset");
    } catch (NoSuchFieldException ex) {
      Logger.getLogger(afip_wsaa.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SecurityException ex) {
      Logger.getLogger(afip_wsaa.class.getName()).log(Level.SEVERE, null, ex);
    }
    charset.setAccessible(true);
    try {
      charset.set(null,null);
    } catch (IllegalArgumentException ex) {
      Logger.getLogger(afip_wsaa.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(afip_wsaa.class.getName()).log(Level.SEVERE, null, ex);
    }
    System.out.println("file.encoding=" + System.getProperty("file.encoding"));
    System.out.println("Default Charset=" + Charset.defaultCharset());
*/
    String db_conn_stmt = args[0];
    String secureDir = args[1];
    String service   = args[2];
    String company   = args[3];
    String genTime   = args[4];
    String expTime   = args[5];
    String oraUserID = args[6];
    String oraLoginID = args[7];
    //String prodFlag  = args[8];
    String LoginTicketResponse = null;

    System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");

    // Get wsaa properties
    OraConnection oraConn = new OraConnection();
    afip_wsaa_client wsaaClient = new afip_wsaa_client();
    
    //if (oraConn.getParameters(db_conn_stmt, secureDir, company, prodFlag)) {
    if (oraConn.getParameters(db_conn_stmt, secureDir, company)) {
      try {
        String endpoint = oraConn.getEndPoint();
        String dstDN = oraConn.getDestination();

        String p12file = oraConn.getKeyStore();
        String signer = oraConn.getKeySigner();
        String p12pass = oraConn.getKeyStore_pass();

        // Set proxy system vars
        //System.setProperty("http.proxyHost", config.getProperty("http_proxy",""));
        //System.setProperty("http.proxyPort", config.getProperty("http_proxy_port",""));
        //System.setProperty("http.proxyUser", config.getProperty("http_proxy_user",""));
        //System.setProperty("http.proxyPassword", config.getProperty("http_proxy_password",""));

        // Set the keystore used by SSL
        System.setProperty("javax.net.ssl.trustStore", oraConn.getTrustStore());
        System.setProperty("javax.net.ssl.trustStorePassword", oraConn.getTrustStore_pass()); 
        
        // Disable timezone
        System.setProperty("oracle.jdbc.timezoneAsRegion", "false"); 

        // Create LoginTicketRequest_xml_cms
        byte [] LoginTicketRequest_xml_cms = wsaaClient.create_cms(p12file, p12pass, signer, dstDN, service, genTime, expTime);

        // Invoke AFIP wsaa and get LoginTicketResponse
        if (null!=LoginTicketRequest_xml_cms){
          LoginTicketResponse = wsaaClient.invoke_wsaa ( LoginTicketRequest_xml_cms, endpoint );
        }

        // Get token & sign from LoginTicketResponse
        if (null!=LoginTicketResponse) {
          try {
            Reader tokenReader = new StringReader(LoginTicketResponse);
            Document tokenDoc = new SAXReader(false).read(tokenReader);

            String uniqueID    = tokenDoc.valueOf("/loginTicketResponse/header/uniqueId");
            String genTimeAfip = tokenDoc.valueOf("/loginTicketResponse/header/generationTime");
            String expTimeAfip = tokenDoc.valueOf("/loginTicketResponse/header/expirationTime");
            String token       = tokenDoc.valueOf("/loginTicketResponse/credentials/token");
            String sign        = tokenDoc.valueOf("/loginTicketResponse/credentials/sign");

            System.out.println("Request OUT:");
            System.out.println("UniqueID: " + uniqueID);
            System.out.println("GenTime:  " + genTimeAfip);
            System.out.println("ExpTime:  " + expTimeAfip);
            System.out.println("TOKEN:    " + token);
            System.out.println("SIGN:     " + sign + "\n");
          
            if (oraConn.insertAfipResponse(db_conn_stmt, wsaaClient.getUniqueId(), uniqueID, genTimeAfip, expTimeAfip, token, sign, service, oraUserID, oraLoginID)){
              System.out.println("Token guardado satisfactoriamente.");
            } else {
              System.out.println("Error guardando token.");
              System.exit(2);
            }
          } catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(1);
          }		
        }
      } catch(Exception e){
        System.out.println(e.getMessage());
        System.exit(1);
      }
    } else {
      System.exit(1);
    }
  }
}
