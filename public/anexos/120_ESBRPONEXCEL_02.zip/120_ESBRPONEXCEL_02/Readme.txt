----------------------------------------------------------------------------------
-- +==========================================================================+ --
-- |                            Supero TI                                     | --
-- |                    Todos os direitos reservados.                         | --
-- +==========================================================================+ --
-- |  # Nro GAP:         120_ESBRPONEXCEL_02  	                              | --
-- |  # Descrição:       120_ESBRPONEXCEL_02 - iSourcing Analisar por Planilha| --
-- |  # Versão:          1.0                                                  | --
-- |  # Data:            08/08/2016	                                          | --
-- |  # Autor:           Guilherme Marques                                    | --
-- +==========================================================================+ --

----------------------------------------------------------------------------------
###### 1. Pré-Instalação:                                     		        ######
----------------------------------------------------------------------------------
 1.1) Readme para aplicação do seguinte patch

 		- 120_ESBRPONEXCEL_02

 1.2) Para mais detalhes:

 		- 120_ESBRPONEXCEL_02/doc/ESBR_MD070_-_ESBRPONEXCEL_-_iSourcing_Analisar_por_Planilha_v1.0.doc

----------------------------------------------------------------------------------
###### 2. Instalação:                                                       ######
----------------------------------------------------------------------------------
  2.1) Execute os comandos abaixo no UNIX

	# Copie o arquivo 120_ESBRPONEXCEL_02.zip para a pasta $APPL_TOP/patches.

	# Execute o comando abaixo para descompactar a pasta.
		$ cd $APPL_TOP/patches
		$ unzip 120_ESBRPONEXCEL_02.zip
		$ cd 120_ESBRPONEXCEL_02

  2.2) O patch pode ser aplicado manualmente.

     	2.2.2) Manualmente

     		Execute os comandos no UNIX

				# Copia dos arquivos customizados

                   mv $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVO.xml          $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVO.xml_bkp11042019
                   mv $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVOImpl.class    $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVOImpl.class_bkp11042019
                   mv $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVORowImpl.class $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVORowImpl.class_bkp11042019

                   cp -f esbr/patch/115/publisher/templates/esbrMapaCotacao.rtf $ESBR_TOP/patch/115/publisher/templates/esbrMapaCotacao.rtf
                   cp -f esbr/misc/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVO.xml          $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVO.xml
                   cp -f esbr/misc/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVOImpl.class    $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVOImpl.class
                   cp -f esbr/misc/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVORowImpl.class $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/server/esbrMapaCotacaoVORowImpl.class
                   cp -f esbr/misc/esbr/oracle/apps/pon/negotiation/inquiry/webui/esbrConsolePageLayoutCO.class   $JAVA_TOP/esbr/oracle/apps/pon/negotiation/inquiry/webui/esbrConsolePageLayoutCO.class

                # FNDLOAD

                   export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"

 				           java oracle.apps.xdo.oa.util.XDOLoader UPLOAD -DB_USERNAME apps -DB_PASSWORD $apps_pwd -JDBC_CONNECTION $jdbc_connection -LOB_TYPE TEMPLATE -LOB_CODE ESBR_PON_MAPA_COTACAO -XDO_FILE_TYPE RTF -FILE_NAME $ESBR_TOP/patch/115/publisher/templates/esbrMapaCotacao.rtf -APPS_SHORT_NAME ESBR -NLS_LANG pt -LANGUAGE pt -TERRITORY 00 -CUSTOM_MODE FORCE

 		           # Rode o comando abaixo

 		               adcgnjar


---------------------------------------------------------------------------
###### 3. Pós-Instalação                                             ######
---------------------------------------------------------------------------

  3.1) Execute os comandos abaixo para realizar o BOUNCE:

  	Para fazer o STOP
  		admanagedsrvctl.sh stop oacore_server1

  	Para fazer o START
        admanagedsrvctl.sh start oacore_server1

  3.2) Após o BOUNCE, seguir o passo-a-passo para aplicação da personalização (O mesmo se encontra no MD070 -> Installation Requirements -> Item 2):



# *** Fim da Aplicação ***
