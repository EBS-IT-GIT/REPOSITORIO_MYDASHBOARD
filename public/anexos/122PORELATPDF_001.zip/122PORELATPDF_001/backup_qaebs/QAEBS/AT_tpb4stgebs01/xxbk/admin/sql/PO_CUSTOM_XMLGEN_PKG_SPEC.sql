CREATE OR REPLACE PACKAGE PO_CUSTOM_XMLGEN_PKG AUTHID CURRENT_USER AS
/* $Header: PO_CUSTOM_XMLGEN_PKG.pls 120.1.12020000.2 2013/02/11 13:18:40 vegajula noship $ */
------------------------------------------------------------------------------
   -- Declare public procedures.
------------------------------------------------------------------------------

--Custom hook to generate XML fragment in PO Output for Communication
PROCEDURE generate_xml_fragment
(p_document_id IN NUMBER
, p_revision_num IN NUMBER
, p_document_type IN VARCHAR2
, p_document_subtype IN VARCHAR2
, x_custom_xml OUT NOCOPY CLOB);

END PO_CUSTOM_XMLGEN_PKG;
--Indicativo de Final de Arquivo. Não deve ser removido.
/

show errors package apps.PO_CUSTOM_XMLGEN_PKG 

EXIT
/