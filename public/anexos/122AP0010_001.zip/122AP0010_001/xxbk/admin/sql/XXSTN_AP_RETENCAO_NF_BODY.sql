CREATE OR REPLACE PACKAGE BODY XXSTN_AP_RETENCAO_NF_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_AP_RETENCAO_NF_PKG.pls                                    |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   AP - Retencao de titulos em aberto com adiantamento pendente  |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S               (17/10/2018)     |
-- |                                                                 |
-- | UPDATED BY   Fernando Pavao - 3S    11/03/2019                  |
-- |    Implementacao da logica do processo Regularizacao bandeiras  |
-- | e cartao de credito                                             |
-- |                                                                 |
-- +=================================================================+
 --> Variaveis Globais:
 g_bShow_log          BOOLEAN := TRUE; -- FALSE;
 g_bGen_XML           BOOLEAN := FALSE;-- TRUE;

 PROCEDURE RETENCAO_NF_P(ERRBUF OUT VARCHAR2
                        ,RETCODE OUT NUMBER
                        ) IS

 CURSOR C_NOTAS_PREPAYMENT IS
  SELECT  distinct aia.org_id
         ,aia.vendor_id
         ,aia.invoice_currency_code
    FROM ap_invoices_all aia
        ,ap_suppliers asup
   WHERE aia.vendor_id = asup.vendor_id
     AND aia.invoice_type_lookup_code = 'PREPAYMENT'
     AND aia.payment_status_flag = 'Y'
     AND (((SELECT SUM(nvl(x.prepay_amount_remaining, x.amount))
              FROM apps.ap_invoice_distributions_all x
             WHERE x.invoice_id = aia.invoice_id) <> 0))
     AND aia.cancelled_date IS NULL;

 CURSOR C_NOTAS_HOLD(PC_VENDOR_ID ap_invoices_all.vendor_id%TYPE
                    ,PC_ORG_ID ap_invoices_all.org_id%TYPE
                    ,PC_CURRENCY ap_invoices_all.invoice_currency_code%TYPE
                    )
  IS
  SELECT aia.invoice_id
        ,aia.invoice_num
    FROM ap_invoices_all aia
        ,ap_suppliers asup
   WHERE aia.vendor_id = asup.vendor_id
     AND aia.invoice_type_lookup_code IN('STANDARD','EXPENSE REPORT')
     AND aia.cancelled_date IS NULL
     AND EXISTS (SELECT 'X'
                   FROM ap_payment_schedules_all apsa
                  WHERE apsa.org_id = aia.org_id
                    AND apsa.invoice_id = aia.invoice_id
                    AND apsa.payment_status_flag IN('N','P'))
     and aia.vendor_id = PC_VENDOR_ID
     and aia.org_id = PC_ORG_ID
     and aia.invoice_currency_code = PC_CURRENCY;

 --fpavao 11/03/2019 begin
 CURSOR c_regular_bandeira IS
  SELECT aia.invoice_id
        --,aia.vendor_site_id
    FROM ap_invoices_all aia
   WHERE aia.source in('Manual Invoice Entry','CLL F189 INTEGRATED RCV')
     AND aia.payment_status_flag = 'N'
     AND aia.pay_group_lookup_code <> 'REGULARIZAR BANDEIRAS'
     AND EXISTS (SELECT 'X'                                                                                                        
                   FROM fnd_lookup_values
                  WHERE lookup_type = 'STN_AP_VENDOR_REG_BANDEIRAS'
                    AND language = userenv('LANG')
                    AND lookup_code IN(select vendor_site_id                                                                       
                                         from po_headers_all                                                                    
                                        where po_header_id in(select quick_po_header_id                                         
                                                                from ap_invoices_all                                            
                                                              where invoice_id = aia.invoice_id)                                 
                                        UNION                                                                                  
                                        select vendor_site_id                                                                   
                                          from po_headers_all                                                                  
                                         where po_header_id in(select po_header_id                                             
                                                                 from po_distributions_all                                     
                                                                where po_distribution_id in(select po_distribution_id          
                                                                                              from ap_invoice_distributions_all
                                                                                             where invoice_id = aia.invoice_id))));

 CURSOR c_cartao_credito IS
  SELECT aia.invoice_id
        ,aia.vendor_site_id
    FROM ap_invoices_all aia
   WHERE aia.source in('Manual Invoice Entry','CLL F189 INTEGRATED RCV')
     AND aia.payment_status_flag = 'N'
     AND aia.payment_method_code <> 'STN CARTAO DE CREDITO'
     AND EXISTS (SELECT 'X'
                   FROM po_headers_all
                  WHERE po_header_id IN(SELECT quick_po_header_id
                                          FROM ap_invoices_all
                                         WHERE invoice_id = aia.invoice_id)
                    AND attribute7 = 'Y'
                 UNION
                 SELECT 'X'
                   FROM po_headers_all
                  WHERE po_header_id IN(SELECT po_header_id
                                          FROM po_distributions_all
                                         WHERE po_distribution_id in(SELECT po_distribution_id
                                                                       FROM ap_invoice_distributions_all
                                                                      WHERE invoice_id = aia.invoice_id))
                    AND attribute7 = 'Y'
                 );
 --fpavao 11/03/2019 end

 l_invoice_id       ap_invoices_all.invoice_id%type;
 l_hold_lookup_code VARCHAR2(200);
 l_hold_type        VARCHAR2(200);
 l_hold_reason      VARCHAR2(200);
 l_held_by          NUMBER;
 l_calling_sequence VARCHAR2(200);
 l_check_flag       VARCHAR2(1);
 l_count_retencao   NUMBER;
 l_term_id          ap_terms.term_id%type;
 l_attribute8       po_headers_all.attribute8%type;
 l_attribute9       po_headers_all.attribute9%type;
 l_vendor_site_id   po_headers_all.vendor_site_id%type;

 BEGIN

  mo_global.init('SQLAP');

  l_count_retencao := 0;

  FOR R_NOTAS_PREPAYMENT IN C_NOTAS_PREPAYMENT LOOP

   FOR R_NOTAS_HOLD IN C_NOTAS_HOLD(R_NOTAS_PREPAYMENT.vendor_id
                                   ,R_NOTAS_PREPAYMENT.org_id
                                   ,R_NOTAS_PREPAYMENT.invoice_currency_code) LOOP

    l_count_retencao := 1;

    l_invoice_id := R_NOTAS_HOLD.invoice_id;
    l_hold_lookup_code := 'Stone - Adiantamentos Pen';
    l_hold_type := 'INVOICE HOLD REASON';
    l_hold_reason := 'Stone - Adiantamentos Pendentes de Aplicacao';
    l_held_by := FND_GLOBAL.USER_ID;
    l_calling_sequence := NULL;

    BEGIN

     AP_HOLDS_PKG.INSERT_SINGLE_HOLD(x_invoice_id            => l_invoice_id,
                                     x_hold_lookup_code      => l_hold_lookup_code,
                                     x_hold_type             => l_hold_type,
                                     x_hold_reason           => l_hold_reason,
                                     x_held_by               => l_held_by,
                                     x_calling_sequence      => l_calling_sequence
                                     );

     EXCEPTION
      WHEN OTHERS THEN
       FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro ao chamar o processo AP_HOLDS_PKG.INSERT_SINGLE_HOLD: '||SQLERRM);
       RETCODE := 2;

    END;

    COMMIT;

/*    BEGIN

     SELECT 'Y'
       INTO l_check_flag
       FROM ap_holds_all
      WHERE invoice_id = l_invoice_id
        AND hold_lookup_code = 'Motivo da Retencao NFF';

     EXCEPTION
      WHEN NO_DATA_FOUND THEN
       l_check_flag := 'N';
      WHEN OTHERS THEN
       l_check_flag := 'N';

    END;

    IF l_check_flag = 'Y' THEN

     FND_FILE.PUT_LINE(FND_FILE.LOG,'Nota: '||R_NOTAS_HOLD.invoice_num||' retida com sucesso');

    ELSE

     FND_FILE.PUT_LINE(FND_FILE.LOG,'Nota: '||R_NOTAS_HOLD.invoice_num||' nao retida favor verificar');

    END IF;*/

   END LOOP; --FOR R_NOTAS_HOLD IN C_NOTAS_HOLD

  END LOOP; --FOR R_NOTAS_PREPAYMENT IN C_NOTAS_PREPAYMENT LOOP

  IF l_count_retencao = 0 THEN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'Nenhum titulo encontrado para retencao !');
   RETCODE := 1;

  END IF;

  --fpavao 12/03/2019 begin
  FOR r_regular_bandeira IN c_regular_bandeira LOOP
  
   BEGIN                                                                                                  
	                                                                                                      
     select vendor_site_id                                                                                 
       into l_vendor_site_id                                                                               
       from po_headers_all                                                                                 
      where po_header_id in(select quick_po_header_id                                                      
                               from ap_invoices_all                                                         
                             where invoice_id = r_regular_bandeira.invoice_id);                                             
                                                                                                           
    EXCEPTION                                                                                              
      WHEN NO_DATA_FOUND THEN                                                                               
      BEGIN                                                                                                
    	                                                                                                      
        select vendor_site_id                                                                               
          into l_vendor_site_id                                                                             
          from po_headers_all                                                                               
         where po_header_id in(select po_header_id                                                          
                                 from po_distributions_all                                                  
                                where po_distribution_id in(select po_distribution_id                       
                                                              from ap_invoice_distributions_all             
                                                             where invoice_id = r_regular_bandeira.invoice_id));             
                                                                                                           
       EXCEPTION                                                                                           
        WHEN OTHERS THEN                                                                                   
         l_vendor_site_id := '';                                                                           
                                                                                                           
       END;                                                                                                 
                                                                                                           
       WHEN OTHERS THEN                                                                                     
        l_vendor_site_id := '';                                                                             
                                                                                                           
   END;                                                                                                   

   BEGIN

     update ap_invoices_all
        set vendor_site_id = l_vendor_site_id
           ,pay_group_lookup_code = 'REGULARIZAR BANDEIRAS'
           ,payment_method_code = 'BAIXA AUT BANDEIRAS'
           ,last_update_date = SYSDATE          
           ,last_updated_by = FND_GLOBAL.USER_ID           
      where invoice_id = r_regular_bandeira.invoice_id;

    EXCEPTION
     WHEN OTHERS THEN
      NULL;

   END;

   BEGIN

     update ap_payment_schedules_all
        set payment_priority = 28
           ,payment_method_code = 'BAIXA AUT BANDEIRAS'
           ,last_update_date = SYSDATE          
           ,last_updated_by = FND_GLOBAL.USER_ID
      where invoice_id = r_regular_bandeira.invoice_id;

    EXCEPTION
     WHEN OTHERS THEN
      NULL;

   END;

  END LOOP;

  FOR r_cartao_credito IN c_cartao_credito LOOP

   l_term_id := '';
   BEGIN

    select term_id
      into l_term_id
      from ap_terms
     where name = 'Cartão de Crédito';

   EXCEPTION
    WHEN OTHERS THEN
     l_term_id := '';

   END;

   BEGIN

     select attribute8
           ,attribute9
       into l_attribute8
           ,l_attribute9
       from po_headers_all
      where po_header_id in(select quick_po_header_id
                               from ap_invoices_all
                             where invoice_id = r_cartao_credito.invoice_id);

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
     BEGIN

       select attribute8
             ,attribute9
         into l_attribute8
             ,l_attribute9
         from po_headers_all
        where po_header_id in(select po_header_id
                                from po_distributions_all
                               where po_distribution_id in(select po_distribution_id
                                                             from ap_invoice_distributions_all
                                                            where invoice_id = r_cartao_credito.invoice_id));

      EXCEPTION
       WHEN OTHERS THEN
        l_attribute8 := '';
        l_attribute9 := '';

      END;

      WHEN OTHERS THEN
       l_attribute8 := '';
       l_attribute9 := '';

   END;

   BEGIN

    update ap_invoices_all
       set terms_id = l_term_id
          ,payment_method_code = 'STN CARTAO DE CREDITO'
          ,attribute2 = 'CARTAO'
          ,attribute3 = l_attribute8
          ,attribute4 = l_attribute9
          ,last_update_date = SYSDATE          
          ,last_updated_by = FND_GLOBAL.USER_ID
     where invoice_id = r_cartao_credito.invoice_id;

   EXCEPTION
    WHEN OTHERS THEN
     NULL;

   END;

   BEGIN

    update ap_payment_schedules_all
       set payment_priority = 29
          ,payment_method_code = 'STN CARTAO DE CREDITO'
          ,last_update_date = SYSDATE          
          ,last_updated_by = FND_GLOBAL.USER_ID
     where invoice_id = r_cartao_credito.invoice_id;

   EXCEPTION
    WHEN OTHERS THEN
     NULL;

   END;

  END LOOP;
  --fpavao 12/03/2019 end

  EXCEPTION
   WHEN OTHERS THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro inesperado no processo RETENCAO_NF_P: '||SQLERRM);

 END RETENCAO_NF_P;

 PROCEDURE RETENCAO_TELA_NF_P(P_VENDOR_ID IN NUMBER
                             ,P_ORG_ID IN NUMBER
                             ,P_CURRENCY IN VARCHAR2
                             ,P_INVOICE_ID IN NUMBER
                             ) IS

 CURSOR C_NOTAS_PREPAYMENT IS
  SELECT  distinct aia.org_id
         ,aia.vendor_id
         ,aia.invoice_currency_code
    FROM ap_invoices_all aia
        ,ap_suppliers asup
   WHERE aia.vendor_id = asup.vendor_id
     AND aia.invoice_type_lookup_code = 'PREPAYMENT'
     AND aia.payment_status_flag = 'Y'
     AND (((SELECT SUM(nvl(x.prepay_amount_remaining, x.amount))
              FROM apps.ap_invoice_distributions_all x
             WHERE x.invoice_id = aia.invoice_id) <> 0))
     AND aia.cancelled_date IS NULL
     and aia.vendor_id = P_VENDOR_ID
     and aia.org_id = P_ORG_ID
     and aia.invoice_currency_code = P_CURRENCY;


 CURSOR C_NOTAS_HOLD(PC_VENDOR_ID ap_invoices_all.vendor_id%TYPE
                    ,PC_ORG_ID ap_invoices_all.org_id%TYPE
                    ,PC_CURRENCY ap_invoices_all.invoice_currency_code%TYPE
                    )
  IS
  SELECT aia.invoice_id
        ,aia.invoice_num
    FROM ap_invoices_all aia
        ,ap_suppliers asup
   WHERE aia.vendor_id = asup.vendor_id
     AND aia.invoice_type_lookup_code IN('STANDARD','EXPENSE REPORT')
     AND aia.cancelled_date IS NULL
     AND EXISTS (SELECT 'X'
                   FROM ap_payment_schedules_all apsa
                  WHERE apsa.org_id = aia.org_id
                    AND apsa.invoice_id = aia.invoice_id
                    AND apsa.payment_status_flag IN('N','P'))
     and aia.vendor_id = PC_VENDOR_ID
     and aia.org_id = PC_ORG_ID
     and aia.invoice_currency_code = PC_CURRENCY
     and aia.invoice_id = P_INVOICE_ID;

 l_invoice_id       ap_invoices_all.invoice_id%type;
 l_hold_lookup_code VARCHAR2(200);
 l_hold_type        VARCHAR2(200);
 l_hold_reason      VARCHAR2(200);
 l_held_by          NUMBER;
 l_calling_sequence VARCHAR2(200);
 l_check_flag       VARCHAR2(1);
 l_count_retencao   NUMBER;

 BEGIN

  mo_global.init('SQLAP');

  l_count_retencao := 0;

  FOR R_NOTAS_PREPAYMENT IN C_NOTAS_PREPAYMENT LOOP

   FOR R_NOTAS_HOLD IN C_NOTAS_HOLD(R_NOTAS_PREPAYMENT.vendor_id
                                   ,R_NOTAS_PREPAYMENT.org_id
                                   ,R_NOTAS_PREPAYMENT.invoice_currency_code) LOOP

    l_count_retencao := 1;

    l_invoice_id := R_NOTAS_HOLD.invoice_id;
    l_hold_lookup_code := 'Stone - Adiantamentos Pen';
    l_hold_type := 'INVOICE HOLD REASON';
    l_hold_reason := 'Stone - Adiantamentos Pendentes de Aplicacao';
    l_held_by := FND_GLOBAL.USER_ID;
    l_calling_sequence := NULL;

    BEGIN

     AP_HOLDS_PKG.INSERT_SINGLE_HOLD(x_invoice_id            => l_invoice_id,
                                     x_hold_lookup_code      => l_hold_lookup_code,
                                     x_hold_type             => l_hold_type,
                                     x_hold_reason           => l_hold_reason,
                                     x_held_by               => l_held_by,
                                     x_calling_sequence      => l_calling_sequence
                                     );

     EXCEPTION
      WHEN OTHERS THEN
       FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro ao chamar o processo AP_HOLDS_PKG.INSERT_SINGLE_HOLD: '||SQLERRM);
       --RETCODE := 2;

    END;

    COMMIT;

/*    BEGIN

     SELECT 'Y'
       INTO l_check_flag
       FROM ap_holds_all
      WHERE invoice_id = l_invoice_id
        AND hold_lookup_code = 'Motivo da Retencao NFF';

     EXCEPTION
      WHEN NO_DATA_FOUND THEN
       l_check_flag := 'N';
      WHEN OTHERS THEN
       l_check_flag := 'N';

    END;

    IF l_check_flag = 'Y' THEN

     FND_FILE.PUT_LINE(FND_FILE.LOG,'Nota: '||R_NOTAS_HOLD.invoice_num||' retida com sucesso');

    ELSE

     FND_FILE.PUT_LINE(FND_FILE.LOG,'Nota: '||R_NOTAS_HOLD.invoice_num||' nao retida favor verificar');

    END IF;*/

   END LOOP; --FOR R_NOTAS_HOLD IN C_NOTAS_HOLD

  END LOOP; --FOR R_NOTAS_PREPAYMENT IN C_NOTAS_PREPAYMENT LOOP

  IF l_count_retencao = 0 THEN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'Nenhum titulo encontrado para retencao !');
   --RETCODE := 1;

  END IF;

  COMMIT;

  EXCEPTION
   WHEN OTHERS THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro inesperado no processo RETENCAO_TELA_NF_P: '||SQLERRM);

 END RETENCAO_TELA_NF_P;

 PROCEDURE gen_relat_retenc_nff_p (errbuf OUT VARCHAR2
                                  ,retcode OUT NUMBER
                                  ,p_organization_id IN NUMBER
                                  ,p_invoice_date IN VARCHAR2
                                  ) IS

 CURSOR c_retenc_nff IS
  select distinct
                 f.name                                                             Empresa
                ,decode(a.invoice_type_lookup_code,'PREPAYMENT','Pagto Antecipado') Tipo_NF
                 ,c.vendor_name                                                     Fornecedor
                 ,d.vendor_site_code                                                Local
                 ,to_date(a.invoice_date,'dd/mm/rrrr')                              Data_Adto
                 ,a.invoice_num                                                     Nr_Adto
                 ,a.invoice_amount                                                  Vl_Adto
                 ,decode(a.payment_status_flag,'Y','Sim','N','NÃ£o','P','Parcial')   Adto_Pago
                 ,a.amount_paid                                                     Vl_Pago_Adto
                 ,(select sum (nvl(x.prepay_amount_remaining, x.amount))
                   from apps.ap_invoice_distributions_all x
                   where x.invoice_id = b.invoice_id)                               Vl_Adto_Em_Aberto
                 ,a.invoice_currency_code                                           Moeda_Adto
                 ,e.name                                                            Livro
                 ,e.currency_code                                                   Moeda_Livro
                 ,a.source                                                          Origem
                 ,a.description                                                     Desc_Adiantamento
                 ,(select distinct x.full_name
                  from apps.per_all_people_f x
                  where x.person_id = a.requester_id
                  and to_char(trunc(x.effective_end_date),'DD/MM/RRRR') = '31/12/4712')                   Solicitante
                 ,trunc(b.accounting_date)                                          Data_Contabil
                 ,(select sum(b.amount)
                   from apps.ap_invoice_distributions_all b
                   where a.invoice_id = b.invoice_id)                               Vl_Contabil
                 ,b.period_name                                                     Periodo
                 ,b.line_type_lookup_code                                           Tipo_Linha
                 ,g.segment1||'.'||
                  g.segment2||'.'||
                  g.segment3||'.'||
                  g.segment4||'.'||
                  g.segment5||'.'||
                  g.segment6||'.'||
                  g.segment7||'.'||
                  g.segment8                                                        Debito
                 ,i.description                                                     Desc_Conta_Debito
                 ,h.segment1||'.'||
                  h.segment2||'.'||
                  h.segment3||'.'||
                  h.segment4||'.'||
                  h.segment6||'.'||
                  h.segment7||'.'||
                  h.segment8                                                        Credito
                 ,k.description                                                     Desc_Conta_Credito
  from apps.ap_invoices_all              a
      ,apps.ap_invoice_distributions_all b
      ,apps.ap_suppliers                 c
      ,apps.ap_supplier_sites_all        d
      ,apps.gl_sets_of_books             e
      ,apps.hr_all_organization_units    f
      ,apps.gl_code_combinations         g
      ,apps.gl_code_combinations         h
      ,apps.fnd_flex_values_vl           i
      ,apps.fnd_flex_value_sets          j
      ,apps.fnd_flex_values_vl           k
      ,apps.fnd_flex_value_sets          l
      ,apps.per_all_people_f             x
  where a.invoice_id                     = b.invoice_id
  and   a.vendor_id                      = c.vendor_id
  and   a.vendor_site_id                 = d.vendor_site_id
  and   b.set_of_books_id                = e.set_of_books_id
  and   a.org_id                         = f.organization_id
  and   b.dist_code_combination_id       = g.code_combination_id (+)
  and   a.accts_pay_code_combination_id  = h.code_combination_id
  and   a.requester_id                   = x.person_id (+)
  and   a.invoice_type_lookup_code       = 'PREPAYMENT'
  and   g.segment4                       = i.flex_value
  and   i.flex_value_set_id              = j.flex_value_set_id (+)
  and   j.flex_value_set_id              = 1017355
  and   h.segment4                       = k.flex_value
  and   k.flex_value_set_id              = l.flex_value_set_id
  and   l.flex_value_set_id              = 1017355
  and (((select sum (nvl(x.prepay_amount_remaining, x.amount))
                   from apps.ap_invoice_distributions_all x
                   where x.invoice_id = b.invoice_id)!= 0))
  and   a.invoice_date between to_date ('01/01/1951 00:00:00' , 'dd/mm/yyyy hh24:mi:ss' ) ---> Fixo - Data De
                           and to_date(to_date(p_invoice_date,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR') ---> ParÃ¢metro Data Fim
  and   a.cancelled_date is null
  and   f.organization_id = nvl(p_organization_id,f.organization_id)
  --AND ROWNUM < 3
  order by f.name,c.vendor_name,trunc(b.accounting_date);

  l_exist_number VARCHAR2(1);
  l_local_number NUMBER;

 BEGIN

  --> Ativa ou desativa o log de erros de acordo com o parametro
    /*IF p_show_log = 'Y' THEN
    g_bShow_log := TRUE;
  END IF;*/

  show_error_log_p(p_message => 'Inicio do relatorio gen_relat_retenc_nff_p');

  --gen_xml_p('<?xml version="1.0" encoding="UTF-8"?>');
  gen_xml_p('<?xml version="1.0" encoding="ISO-8859-1"?>');
  gen_xml_p('<HEADERS>');

  gen_xml_p(' <HEADER>');

  -- Recupera dados para o relatÃ³rio de razao
  FOR r_retenc_nff IN c_retenc_nff LOOP

   l_exist_number := NULL;
   BEGIN

    SELECT 'X'
      INTO l_exist_number
      FROM DUAL
     WHERE REGEXP_LIKE(r_retenc_nff.LOCAL, '^[[:digit:]]+$');

    EXCEPTION
     WHEN OTHERS THEN
       l_exist_number := null;

   END;

   gen_xml_p('   <LINES_RETENC>');

    gen_xml_p('    <EMPRESA>'  || conv_spc_chr(r_retenc_nff.EMPRESA) ||'</EMPRESA>');
    gen_xml_p('    <TIPO_NF>'  || conv_spc_chr(r_retenc_nff.TIPO_NF) ||'</TIPO_NF>');
    gen_xml_p('    <FORNECEDOR>'  || conv_spc_chr(r_retenc_nff.FORNECEDOR) ||'</FORNECEDOR>');

    --IF l_exist_number = 'X' THEN

     --l_local_number := TO_NUMBER(r_retenc_nff.LOCAL);

     --gen_xml_p('    <LOCAL>'  || l_local_number ||'</LOCAL>');

    --ELSE

    gen_xml_p('    <LOCAL>'  || conv_spc_chr(r_retenc_nff.LOCAL) ||'</LOCAL>');

    --END IF;

    gen_xml_p('    <DATA_ADTO>'  || TO_CHAR(r_retenc_nff.DATA_ADTO,'DD/MM/RRRR') ||'</DATA_ADTO>');
    gen_xml_p('    <NR_ADTO>'  || conv_spc_chr(r_retenc_nff.NR_ADTO) ||'</NR_ADTO>');
    gen_xml_p('    <VL_ADTO>'  || LTRIM(TO_CHAR(conv_spc_chr(r_retenc_nff.VL_ADTO),'999G999G990D00')) ||'</VL_ADTO>');
    gen_xml_p('    <ADTO_PAGO>'  || conv_spc_chr(r_retenc_nff.ADTO_PAGO) ||'</ADTO_PAGO>');
    gen_xml_p('    <VL_PAGO_ADTO>'  || LTRIM(TO_CHAR(conv_spc_chr(r_retenc_nff.VL_PAGO_ADTO),'999G999G990D00')) ||'</VL_PAGO_ADTO>');
    gen_xml_p('    <VL_ADTO_EM_ABERTO>'  || LTRIM(TO_CHAR(conv_spc_chr(r_retenc_nff.VL_ADTO_EM_ABERTO),'999G999G990D00')) ||'</VL_ADTO_EM_ABERTO>');
    gen_xml_p('    <MOEDA_ADTO>'  || conv_spc_chr(r_retenc_nff.MOEDA_ADTO) ||'</MOEDA_ADTO>');
    gen_xml_p('    <LIVRO>'  || conv_spc_chr(r_retenc_nff.LIVRO) ||'</LIVRO>');
    gen_xml_p('    <MOEDA_LIVRO>'  || conv_spc_chr(r_retenc_nff.MOEDA_LIVRO) ||'</MOEDA_LIVRO>');
    gen_xml_p('    <ORIGEM>'  || conv_spc_chr(r_retenc_nff.ORIGEM) ||'</ORIGEM>');
    gen_xml_p('    <DESC_ADIANTAMENTO>'  || conv_spc_chr(r_retenc_nff.DESC_ADIANTAMENTO) ||'</DESC_ADIANTAMENTO>');
    gen_xml_p('    <SOLICITANTE>'  || conv_spc_chr(r_retenc_nff.SOLICITANTE) ||'</SOLICITANTE>');
    gen_xml_p('    <DATA_CONTABIL>'  || TO_CHAR(r_retenc_nff.DATA_CONTABIL,'DD/MM/RRRR') ||'</DATA_CONTABIL>');
    gen_xml_p('    <VL_CONTABIL>'  || LTRIM(TO_CHAR(conv_spc_chr(r_retenc_nff.VL_CONTABIL),'999G999G990D00')) ||'</VL_CONTABIL>');
    gen_xml_p('    <PERIODO>'  || conv_spc_chr(r_retenc_nff.PERIODO) ||'</PERIODO>');
    gen_xml_p('    <TIPO_LINHA>'  || conv_spc_chr(r_retenc_nff.TIPO_LINHA) ||'</TIPO_LINHA>');
    gen_xml_p('    <DEBITO>'  || conv_spc_chr(r_retenc_nff.DEBITO) ||'</DEBITO>');
    gen_xml_p('    <DESC_CONTA_DEBITO>'  || conv_spc_chr(r_retenc_nff.DESC_CONTA_DEBITO) ||'</DESC_CONTA_DEBITO>');
    gen_xml_p('    <CREDITO>'  || conv_spc_chr(r_retenc_nff.CREDITO) ||'</CREDITO>');
    gen_xml_p('    <DESC_CONTA_CREDITO>'  || conv_spc_chr(r_retenc_nff.DESC_CONTA_CREDITO) ||'</DESC_CONTA_CREDITO>');

   gen_xml_p('   </LINES_RETENC>');

  END LOOP;

  gen_xml_p(' </HEADER>');

  gen_xml_p('</HEADERS>');

 END gen_relat_retenc_nff_p;

 PROCEDURE show_error_log_p(p_message IN VARCHAR2) IS
 BEGIN
  IF g_bShow_log THEN
    fnd_file.put_line(fnd_file.log, p_message);
  END IF;
 END show_error_log_p;

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER IS

  l_vDecimal_char VARCHAR2(1);

 BEGIN
  --> Recupera o character decimal
  l_vDecimal_char := substr(ltrim(to_char(.3, '0D0')), 2, 1);

  --> Transforma o varchar para um nÃºmero com um decimal vÃ¡lido
  IF l_vDecimal_char = ',' THEN
    RETURN round(to_number(translate(p_value, '.', l_vDecimal_char)), 20);
  ELSE
    RETURN round(to_number(translate(p_value, ',', l_vDecimal_char)), 20);
  END IF;

 END canonical_to_number_f;
 --

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2 IS

  l_vReturn      VARCHAR2(20);
  l_nDecimal_qty NUMBER;
  l_nMask_qty    NUMBER;
  l_vMask        VARCHAR2(100);

 BEGIN

  l_vMask := p_mask;
  l_nMask_qty := length(substr(l_vMask, instr(l_vMask, '.') + 1));

  --> Verifica se deve criar uma mÃ¡scara com mais de 3 decimais- INICIO
  IF l_nMask_qty > 3 THEN

    --> Verifica se hÃ¡ decimais no valor - INICIO
    IF instr(to_char(translate(p_value, ',', '.')), '.') = 0 THEN
      l_nDecimal_qty := 0;
    ELSE
      --> Armazena a quantidade de digitos de decimais
      l_nDecimal_qty := length(substr(to_char(translate(p_value, ',', '.')), instr(to_char(translate(p_value, ',', '.')), '.') + 1));
    END IF;

    --> Verifica se a mascara retornou menos que 2
    IF l_nDecimal_qty <= 2 THEN
      l_nDecimal_qty := 2;
    END IF;

    --> Gera uma novas mÃ¡scara com a quantidade de decimais necessÃ¡rias
    l_vMask := substr(l_vMask, 1,  instr(l_vMask, '.')) || rpad('0', l_nDecimal_qty, '0');

  END IF;

  l_vReturn := lpad(to_char(p_value, l_vMask), 20, ' ');
  l_vReturn := REPLACE( l_vReturn, ',', '@' );
  l_vReturn := REPLACE( l_vReturn, '.', ',' );
  l_vReturn := REPLACE( l_vReturn, '@', '.' );

  RETURN(trim(l_vReturn));

 END format_br_mask_f;
 --

 -- FunÃ§Ã£o que retorna valor por extenso:
 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2 IS

  valor_string VARCHAR2(256);
  valor_conv   VARCHAR2(25);
  tres_digitos VARCHAR2(3);
  texto_string VARCHAR2(256);
  ind          NUMBER;

 BEGIN
  valor_conv := to_char(trunc((abs(valor) * 100)
                             ,0)
                       ,'0999999999999999999');
  valor_conv := substr(valor_conv
                      ,1
                      ,18) || '0' || substr(valor_conv
                                           ,19
                                           ,2);
  IF to_number(valor_conv) = 0 THEN
    RETURN('Zero ');
  END IF;

  FOR ind IN 1 .. 7 LOOP
    tres_digitos := substr(valor_conv
                          ,(((ind - 1) * 3) + 1)
                          ,3);
    texto_string := '';

    -- Extenso para Centena
    IF substr(tres_digitos
             ,1
             ,1) = '2' THEN
      texto_string := texto_string || 'Duzentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '3' THEN
      texto_string := texto_string || 'Trezentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '4' THEN
      texto_string := texto_string || 'Quatrocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '5' THEN
      texto_string := texto_string || 'Quinhentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '6' THEN
      texto_string := texto_string || 'Seiscentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '7' THEN
      texto_string := texto_string || 'Setecentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '9' THEN
      texto_string := texto_string || 'Novecentos ';
    END IF;

    IF substr(tres_digitos
             ,1
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,2
               ,2) = '00' THEN
        texto_string := texto_string || 'Cem ';
      ELSE
        texto_string := texto_string || 'Cento ';
      END IF;

    END IF;
    -- Extenso para Dezena
    IF substr(tres_digitos
             ,2
             ,1) <> '0'
       AND texto_string IS NOT NULL THEN
      texto_string := texto_string || 'e ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '2' THEN
      texto_string := texto_string || 'Vinte ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '3' THEN
      texto_string := texto_string || 'Trinta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '4' THEN
      texto_string := texto_string || 'Quarenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '5' THEN
      texto_string := texto_string || 'Cinquenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '6' THEN
      texto_string := texto_string || 'Sessenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '7' THEN
      texto_string := texto_string || 'Setenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '9' THEN
      texto_string := texto_string || 'Noventa ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,3
               ,1) <> '0' THEN

        IF substr(tres_digitos
                 ,3
                 ,1) = '1' THEN
          texto_string := texto_string || 'Onze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '2' THEN
          texto_string := texto_string || 'Doze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '3' THEN
          texto_string := texto_string || 'Treze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '4' THEN
          texto_string := texto_string || 'Quatorze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '5' THEN
          texto_string := texto_string || 'Quinze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '6' THEN
          texto_string := texto_string || 'Dezesseis ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '7' THEN
          texto_string := texto_string || 'Dezessete ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '8' THEN
          texto_string := texto_string || 'Dezoito ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '9' THEN
          texto_string := texto_string || 'Dezenove ';
        END IF;

      ELSE
        texto_string := texto_string || 'Dez ';
      END IF;

    ELSE

      -- Extenso para Unidade
      IF substr(tres_digitos
               ,3
               ,1) <> '0'
         AND texto_string IS NOT NULL THEN
        texto_string := texto_string || 'e ';
      END IF;

      IF substr(tres_digitos
               ,3
               ,1) = '1' THEN
        texto_string := texto_string || 'Um ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '2' THEN
        texto_string := texto_string || 'Dois ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '3' THEN
        texto_string := texto_string || 'Tres ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '4' THEN
        texto_string := texto_string || 'Quatro ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '5' THEN
        texto_string := texto_string || 'Cinco ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '6' THEN
        texto_string := texto_string || 'Seis ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '7' THEN
        texto_string := texto_string || 'Sete ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '8' THEN
        texto_string := texto_string || 'Oito ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '9' THEN
        texto_string := texto_string || 'Nove ';
      END IF;

    END IF;

    IF to_number(tres_digitos) > 0 THEN
      IF to_number(tres_digitos) = 1 THEN
        IF ind = 1 THEN
          texto_string := texto_string || 'QuatrilhÃ£o ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'TrilhÃ£o ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'BilhÃ£o ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'MilhÃ£o ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      ELSE
        IF ind = 1 THEN
          texto_string := texto_string || 'QuatrilhÃµes ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'TrilhÃµes ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'BilhÃµes ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'MilhÃµes ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      END IF;
    END IF;
    valor_string := valor_string || texto_string;
    -- Escrita da Moeda Corrente
    IF ind = 5 THEN
      IF to_number(substr(valor_conv
                         ,16
                         ,3)) > 0
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    ELSE
      IF ind < 5
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    END IF;
    IF ind = 6 THEN
      IF to_number(substr(valor_conv
                         ,1
                         ,18)) > 1 THEN
        valor_string := valor_string || 'Reais ';
      ELSIF to_number(substr(valor_conv
                            ,1
                            ,18)) = 1 THEN
        valor_string := valor_string || 'Real ';
      END IF;

      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 0
         AND length(valor_string) > 0 THEN
        valor_string := valor_string || 'e ';
      END IF;
    END IF;
    -- Escrita para Centavos
    IF ind = 7 THEN
      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 1 THEN
        valor_string := valor_string || 'Centavos ';
      ELSIF to_number(substr(valor_conv
                            ,20
                            ,2)) = 1 THEN
        valor_string := valor_string || 'Centavo ';
      END IF;
    END IF;
  END LOOP;
  RETURN(rtrim(valor_string));
 EXCEPTION
  WHEN OTHERS THEN
    RETURN('*** VALOR INVALIDO ***');
 END;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2 IS

  l_vChar VARCHAR2(4000) := p_char;

 BEGIN
  l_vChar := REPLACE(l_vChar, '&', ';');
  l_vChar := REPLACE(l_vChar, '<', ';');
  l_vChar := REPLACE(l_vChar, '>', ';');
  l_vChar := REPLACE(l_vChar, '"', ';');
  l_vChar := REPLACE(l_vChar, '''', ';');
  l_vChar := REPLACE(l_vChar, 'Âº', 'o');
  l_vChar := REPLACE(l_vChar, 'Ã¿', 'C');
  l_vChar := REPLACE(l_vChar, 'Ã§', 'c');
  l_vChar := REPLACE(l_vChar, 'Ã§', 'c');
  l_vChar := REPLACE(l_vChar, 'Ã£', 'a');
  l_vChar := REPLACE(l_vChar, 'Ã¿', 'A');
  l_vChar := REPLACE(l_vChar, 'Ã©', 'e');
  l_vChar := REPLACE(l_vChar, 'Ã¿', 'E');
  l_vChar := REPLACE(l_vChar, 'Ã­', 'i');
  l_vChar := REPLACE(l_vChar, 'Ã', 'I');
  l_vChar := REPLACE(l_vChar, 'Ã³', 'o');
  l_vChar := REPLACE(l_vChar, 'Ã¿', 'O');
  l_vChar := REPLACE(l_vChar, 'Ãº', 'u');
  l_vChar := REPLACE(l_vChar, 'Ã¿', 'U');

  RETURN(l_vChar);
 END conv_spc_chr;
 --

 PROCEDURE gen_xml_p(p_message IN VARCHAR2) IS
 BEGIN
   IF g_bGen_XML THEN
     -- Gera Log de execuÃ§Ã£o
     dbms_output.put_line(p_message);
   ELSE
     -- Grava saÃ­da do concurrent:
     fnd_file.put_line(fnd_file.output,p_message);
   END IF;

 END gen_xml_p;
 --

END XXSTN_AP_RETENCAO_NF_PKG;
/

show errors package body apps.XXSTN_AP_RETENCAO_NF_PKG 

EXIT
/
