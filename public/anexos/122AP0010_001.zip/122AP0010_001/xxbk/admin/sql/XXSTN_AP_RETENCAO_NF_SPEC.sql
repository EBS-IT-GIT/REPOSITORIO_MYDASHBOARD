CREATE OR REPLACE PACKAGE XXSTN_AP_RETENCAO_NF_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_AP_RETENCAO_NF_PKG.pls                                    |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   AP - Retencao de titulos em aberto com adiantamento pendente  |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S               (17/10/2018)     |
-- |                                                                 |
-- | UPDATED BY   Fernando Pavao - 3S    11/03/2019                  |
-- |    Implementacao da logica do processo Regularizacao bandeiras  |
-- | e cartao de credito                                             |
-- |                                                                 |
-- +=================================================================+

 PROCEDURE RETENCAO_NF_P(ERRBUF OUT VARCHAR2
                        ,RETCODE OUT NUMBER
                        );
 PROCEDURE RETENCAO_TELA_NF_P(P_VENDOR_ID IN NUMBER
                             ,P_ORG_ID IN NUMBER
                             ,P_CURRENCY IN VARCHAR2
                             ,P_INVOICE_ID IN NUMBER
                             );

 PROCEDURE gen_relat_retenc_nff_p (errbuf OUT VARCHAR2
                                  ,retcode OUT NUMBER
                                  ,p_organization_id IN NUMBER
                                  ,p_invoice_date IN VARCHAR2
                                  );

 PROCEDURE show_error_log_p(p_message IN VARCHAR2);

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER;

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2;

 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2;

 PROCEDURE gen_xml_p(p_message IN VARCHAR2);

END XXSTN_AP_RETENCAO_NF_PKG;
/

show errors package apps.XXSTN_AP_RETENCAO_NF_PKG 

EXIT
/