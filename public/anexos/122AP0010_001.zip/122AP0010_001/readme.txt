********************************************************************************
* 122AP0010_001
********************************************************************************
* This patch contains
* =================
* 
* Gap 122AP0010_001
* 
* 
* PRE-REQS:  
* ==============
* N/A 
* 
* POST-PATCH:
* ====================
1. Copiar o arquivo CUSTOM.pll  para o diretório /fs1/EBSapps/appl/au/12.0.0/resource que se encontra na seguinte pasta do patch:122AP0010_001\au\resource

2. Dentro da pasta /fs1/EBSapps/appl/au/12.0.0/resource Compilar o arquivo CUSTOM.pll conforme comando abaixo passando a senha do user apps substituindo o @password:

frmcmp_batch module=CUSTOM.pll userid=apps/@password output_file=$AU_TOP/resource/CUSTOM.plx compile_all=yes module_type=LIBRARY
********************************************************************************  

################################################################################
###                        Installation procedures                           ###
################################################################################

1) Apply unified driver

	