set define off;
CREATE OR REPLACE PACKAGE BODY XXSTN_PO_RELAT_FACILIT_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PO_RELAT_FACILIT_PKG.pls                                  |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   PO - Relatorio de Compras Facilities                          |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S               (30/11/2018)     |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

 --> Variaveis Globais:
 g_bShow_log          BOOLEAN := TRUE; -- FALSE;
 g_bGen_XML           BOOLEAN := FALSE;-- TRUE;

 PROCEDURE gen_relat_po_facilit_p (errbuf OUT VARCHAR2
                                  ,retcode OUT NUMBER
                                  ,P_UNID_OPER IN VARCHAR2
                                  ,P_DATA_DE IN VARCHAR2
                                  ,P_DATA_ATE IN VARCHAR2
                                  --,P_STATUS_APROV IN VARCHAR2
                                  ,P_DATA_VALID_BLANK IN VARCHAR2
                                  ,P_CENTRO_CUSTO IN VARCHAR2
                                  ) IS

 CURSOR c_po_facilit IS
  select distinct hr.name                                                                    Unidade_Operacional
                 ,pv.vendor_name                                                             Fornecedor
                 ,pvs.vendor_site_code                                                       Local_Fornecedor
                 ,(select case
                  when global_attribute9 = '2' then
                       global_attribute10 || '/' || global_attribute11 || '-' || global_attribute12
                  when global_attribute9 = '3' then
                       lpad(party_site_id,9,'0') || '/' || global_attribute11 || '-' || global_attribute12
                  else
                       global_attribute10  || '-' || global_attribute12
                  end cnpj from apps.ap_supplier_sites_all x
                  where x.vendor_site_id = pvs.vendor_site_id)                               CNPJ_CPF

                  ,decode(ph.type_lookup_code,'STANDARD','Ordem de Compra-Padr�o'
                                             ,'BLANKET' ,'Acordo de Compra em Aberto'
                                             ,'PLANNED' ,'Ordem Compra Planejada'
                                             ,'CONTRACT','Acordo de Compra do Contrato')     Tipo_PO
       ,papf.first_name || ' ' || papf.last_name                                             Comprador

       ,decode(ph.authorization_status,'IN PROCESS','Em Andamento'
                                      ,'APPROVED'  ,'Aprovado'
                                      ,'INCOMPLETE','Incompleto'
                                      ,'REJECTED'  ,'Rejeitado'
                                      ,'REQUIRES REAPPROVAL','Exige Reaprova��o'
                                      ,'','Incompleto')            Status_PO

       ,ph.segment1                                                                          Nr_PO
       ,pr.release_num                                                                       Nr_Release

       ,ph.creation_date                                                                     Data_Criacao_PO
       ,ph.approved_date                                                                     Data_Aprovacao_PO

       ,papf1.first_name || ' ' || papf1.last_name                                           Requisitante
       ,prh.segment1                                                                         Nr_Requisicao
       ,prh.creation_date                                                                    Data_Criacao_Req
       ,prh.approved_date                                                                    Data_Aprovacao_Req

       ,decode(ph.attribute2,'Y','PO Global','N','PO Spot',null,'N�o se Aplica')             Global

       ,nvl(ph.blanket_total_amount,0)                                                       Total_Acordo

       ,ph.start_date                                                                        Data_Inicio
       ,ph.end_date                                                                          Data_Fim
       ,ph.currency_code                                                                     Moeda
       ,apt.name                                                                             Cond_Pagto

       ,pl.line_num                                                                          Nr_Linha
       ,plt.line_type                                                                        Tipo_Linha
       ,mc.segment1                                                                          Nome_Categoria

       , msi.segment1                                                                        Nr_Item
       , msi.description                                                                     Descricao_Item
       , msi.inventory_item_status_code                                                      Status_Item

       , pd.distribution_num                                                                 Nr_Distribuicao_Contabil

       ,gcccc.segment5                                                                       Centro_Custo

       ,ffvcc.description                                                                    Descricao_Centro_Custo

       , gcc.segment7                                                                        Unidade_Negocio

       , ffv.description                                                                     Descricao_Unidade_Negocio

       ,pl.unit_price                                                                        Preco
       ,pl.quantity                                                                          Quantidade

       , pd.quantity_ordered                                                                 Quantidade_Solicitada
       , nvl(pd.amount_billed,0)                                                             Quantia_Faturada

       , mp.organization_code||'-'||hl.location_code                                         OI_Entrega
       ,pd.REQ_DISTRIBUTION_ID

  from apps.hr_all_organization_units    hr
     , apps.hr_locations                 hl
     , apps.org_organization_definitions mp
     , apps.ap_suppliers                 pv
     , apps.ap_supplier_sites_all        pvs
     , apps.po_headers_all               ph
     , apps.po_lines_all                 pl
     , apps.po_line_locations_all        pll
     , apps.po_distributions_all         pd
     , apps.po_releases_all              pr
     , apps.po_line_types                plt
     , apps.ap_terms                     apt
     , apps.mtl_system_items             msi
     , apps.mtl_categories               mc
     , apps.po_agents                    pa
     , apps.per_all_people_f             papf
     , apps.per_all_people_f             papf1
     , apps.po_requisition_headers_all   prh
     , apps.po_requisition_lines_all     prl
     , apps.po_req_distributions_all     prd
     , apps.gl_code_combinations         gcc
     , apps.fnd_flex_value_sets          ffvs
     , apps.fnd_flex_values_vl           ffv
     , apps.gl_code_combinations         gcccc
     , apps.fnd_flex_value_sets          ffvscc
     , apps.fnd_flex_values_vl           ffvcc
  where ph.org_id             = hr.organization_id
    and ph.po_header_id       = pl.po_header_id
    and ph.po_header_id       = pll.po_header_id
    and ph.po_header_id       = pd.po_header_id
    and pr.po_header_id(+)    = ph.po_header_id
    and pl.po_line_id         = pll.po_line_id
    and pl.po_line_id         = pd.po_line_id
    and pll.line_location_id  = pd.line_location_id
    and ph.vendor_id          = pv.vendor_id
    and ph.vendor_site_id     = pvs.vendor_site_id
    and pvs.vendor_id         = pv.vendor_id
    and ph.terms_id           = apt.term_id
    and pl.line_type_id       = plt.line_type_id
    and pl.item_id            = msi.inventory_item_id
    and pl.category_id        = mc.category_id
    and pa.agent_id           = ph.agent_id
    and pa.agent_id           = papf.person_id
    and prh.preparer_id       = papf1.person_id
    and hl.location_id        = ph.ship_to_location_id
    and msi.organization_id   = pll.ship_to_organization_id
    and mp.organization_id    = msi.organization_id
    and pd.code_combination_id    = gcc.code_combination_id
    and ffv.flex_value_set_id     = ffvs.flex_value_set_id
    and gcc.segment7              = ffv.flex_value
    and ffvs.flex_value_set_id    = 1017448                    ------> Unidade Negocio

    and pd.code_combination_id      = gcccc.code_combination_id
    and ffvcc.flex_value_set_id     = ffvscc.flex_value_set_id
    and gcccc.segment5              = ffvcc.flex_value
    and ffvscc.flex_value_set_id    = 1017450
    --and ffvscc.flex_value_set_id    = NVL(P_CENTRO_CUSTO,ffvscc.flex_value_set_id)                  ------> Centro Custo
    --and trunc(ffvcc.flex_value)   = NVL(P_CENTRO_CUSTO,trunc(ffvcc.flex_value))                  ------> Centro Custo
    and trunc(gcccc.segment5)   = NVL(P_CENTRO_CUSTO,trunc(gcccc.segment5))                  ------> Centro Custo
    and nvl(pll.po_release_id,1)  = nvl (pr.po_release_id, 1)
    and prh.requisition_header_id = prl.requisition_header_id
    and prl.requisition_line_id   = prd.requisition_line_id
    and prd.distribution_id       = pd.req_distribution_id(+)
    and nvl(ph.cancel_flag,'N')   = 'N'
    and nvl(ph.closed_code,'OPEN')!= 'FINALLY CLOSED'
    and (pv.pay_group_lookup_code = 'POLO' or pvs.pay_group_lookup_code = 'POLO')
    and hr.name = NVL(P_UNID_OPER,hr.name)
    and ph.creation_date between NVL(to_date(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'),ph.creation_date)  ---> Opcional
                             and to_date(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')  ---> Obrigatorio
    --and ph.authorization_status = NVL(P_STATUS_APROV,ph.authorization_status)
    --and trunc(ph.end_date) = NVL(to_date(to_date(P_DATA_VALID_BLANK,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'),ph.end_date)
    and decode(P_DATA_VALID_BLANK,'',sysdate,trunc(ph.end_date)) = decode(P_DATA_VALID_BLANK,'',sysdate,to_date(to_date(P_DATA_VALID_BLANK,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'))
  --order by hr.name,ph.segment1, pr.release_num, pd.distribution_num;
  UNION
  select distinct hr.name                                                                    Unidade_Operacional
                 ,pv.vendor_name                                                             Fornecedor
                 ,pvs.vendor_site_code                                                       Local_Fornecedor
                 ,(select case
                  when global_attribute9 = '2' then
                       global_attribute10 || '/' || global_attribute11 || '-' || global_attribute12
                  when global_attribute9 = '3' then
                       lpad(party_site_id,9,'0') || '/' || global_attribute11 || '-' || global_attribute12
                  else
                       global_attribute10  || '-' || global_attribute12
                  end cnpj from apps.ap_supplier_sites_all x
                  where x.vendor_site_id = pvs.vendor_site_id)                               CNPJ_CPF

                  ,decode(ph.type_lookup_code,'STANDARD','Ordem de Compra-Padr�o'
                                             ,'BLANKET' ,'Acordo de Compra em Aberto'
                                             ,'PLANNED' ,'Ordem Compra Planejada'
                                             ,'CONTRACT','Acordo de Compra do Contrato')     Tipo_PO
       ,papf.first_name || ' ' || papf.last_name                                             Comprador

       ,decode(ph.authorization_status,'IN PROCESS','Em Andamento'
                                      ,'APPROVED'  ,'Aprovado'
                                      ,'INCOMPLETE','Incompleto'
                                      ,'REJECTED'  ,'Rejeitado'
                                      ,'REQUIRES REAPPROVAL','Exige Reaprova��o'
                                      ,'','Incompleto')            Status_PO

       ,ph.segment1                                                                          Nr_PO
       ,pr.release_num                                                                       Nr_Release

       ,ph.creation_date                                                                     Data_Criacao_PO
       ,ph.approved_date                                                                     Data_Aprovacao_PO

       ,''                                           Requisitante
       ,''                                                                         Nr_Requisicao
       ,ph.creation_date                                                                 Data_Criacao_Req
       ,ph.creation_date                                                                 Data_Aprovacao_Req

       ,decode(ph.attribute2,'Y','PO Global','N','PO Spot',null,'N�o se Aplica')             Global

       ,nvl(ph.blanket_total_amount,0)                                                       Total_Acordo

       ,ph.start_date                                                                        Data_Inicio
       ,ph.end_date                                                                          Data_Fim
       ,ph.currency_code                                                                     Moeda
       ,apt.name                                                                             Cond_Pagto

       ,pl.line_num                                                                          Nr_Linha
       ,plt.line_type                                                                        Tipo_Linha
       ,mc.segment1                                                                          Nome_Categoria

       , msi.segment1                                                                        Nr_Item
       , msi.description                                                                     Descricao_Item
       , msi.inventory_item_status_code                                                      Status_Item

       , pd.distribution_num                                                                 Nr_Distribuicao_Contabil

       ,gcccc.segment5                                                                       Centro_Custo

       ,ffvcc.description                                                                    Descricao_Centro_Custo

       , gcc.segment7                                                                        Unidade_Negocio

       , ffv.description                                                                     Descricao_Unidade_Negocio

       ,pl.unit_price                                                                        Preco
       ,pl.quantity                                                                          Quantidade

       , pd.quantity_ordered                                                                 Quantidade_Solicitada
       , nvl(pd.amount_billed,0)                                                             Quantia_Faturada

       , mp.organization_code||'-'||hl.location_code                                         OI_Entrega
       ,pd.REQ_DISTRIBUTION_ID

  from apps.hr_all_organization_units    hr
     , apps.hr_locations                 hl
     , apps.org_organization_definitions mp
     , apps.ap_suppliers                 pv
     , apps.ap_supplier_sites_all        pvs
     , apps.po_headers_all               ph
     , apps.po_lines_all                 pl
     , apps.po_line_locations_all        pll
     , apps.po_distributions_all         pd
     , apps.po_releases_all              pr
     , apps.po_line_types                plt
     , apps.ap_terms                     apt
     , apps.mtl_system_items             msi
     , apps.mtl_categories               mc
     , apps.po_agents                    pa
     , apps.per_all_people_f             papf
     , apps.per_all_people_f             papf1
     , apps.gl_code_combinations         gcc
     , apps.fnd_flex_value_sets          ffvs
     , apps.fnd_flex_values_vl           ffv
     , apps.gl_code_combinations         gcccc
     , apps.fnd_flex_value_sets          ffvscc
     , apps.fnd_flex_values_vl           ffvcc
  where ph.org_id             = hr.organization_id
    and ph.po_header_id       = pl.po_header_id
    and ph.po_header_id       = pll.po_header_id
    and ph.po_header_id       = pd.po_header_id
    and pr.po_header_id(+)    = ph.po_header_id
    and pl.po_line_id         = pll.po_line_id
    and pl.po_line_id         = pd.po_line_id
    and pll.line_location_id  = pd.line_location_id
    and ph.vendor_id          = pv.vendor_id
    and ph.vendor_site_id     = pvs.vendor_site_id
    and pvs.vendor_id         = pv.vendor_id
    and ph.terms_id           = apt.term_id
    and pl.line_type_id       = plt.line_type_id
    and pl.item_id            = msi.inventory_item_id
    and pl.category_id        = mc.category_id
    and pa.agent_id           = ph.agent_id
    and pa.agent_id           = papf.person_id
    and hl.location_id        = ph.ship_to_location_id
    and msi.organization_id   = pll.ship_to_organization_id
    and mp.organization_id    = msi.organization_id
    and pd.code_combination_id    = gcc.code_combination_id
    and ffv.flex_value_set_id     = ffvs.flex_value_set_id
    and gcc.segment7              = ffv.flex_value
    and ffvs.flex_value_set_id    = 1017448                    ------> Unidade Negocio

    and pd.code_combination_id      = gcccc.code_combination_id
    and ffvcc.flex_value_set_id     = ffvscc.flex_value_set_id
    and gcccc.segment5              = ffvcc.flex_value
    and ffvscc.flex_value_set_id    = 1017450
    --and ffvscc.flex_value_set_id    = NVL(P_CENTRO_CUSTO,ffvscc.flex_value_set_id)                  ------> Centro Custo
    --and trunc(ffvcc.flex_value)   = NVL(P_CENTRO_CUSTO,trunc(ffvcc.flex_value))                  ------> Centro Custo
    and trunc(gcccc.segment5)   = NVL(P_CENTRO_CUSTO,trunc(gcccc.segment5))                  ------> Centro Custo
    and nvl(pll.po_release_id,1)  = nvl (pr.po_release_id, 1)
    and nvl(ph.cancel_flag,'N')   = 'N'
    and nvl(ph.closed_code,'OPEN')!= 'FINALLY CLOSED'
    and (pv.pay_group_lookup_code = 'POLO' or pvs.pay_group_lookup_code = 'POLO')
    and hr.name = NVL(P_UNID_OPER,hr.name)
    and ph.creation_date between NVL(to_date(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'),ph.creation_date)  ---> Opcional
                             and to_date(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')  ---> Obrigatorio
    --and ph.authorization_status = NVL(P_STATUS_APROV,ph.authorization_status)
    --and trunc(ph.end_date) = NVL(to_date(to_date(P_DATA_VALID_BLANK,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'),ph.end_date)
    and decode(P_DATA_VALID_BLANK,'',sysdate,trunc(ph.end_date)) = decode(P_DATA_VALID_BLANK,'',sysdate,to_date(to_date(P_DATA_VALID_BLANK,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'))
   AND pd.REQ_DISTRIBUTION_ID IS NULL
  order by 1,8,9,28;

  l_exist_number VARCHAR2(1);
  l_local_number NUMBER;
  l_exec varchar2(500);
  l_data_criacao_req date;
  l_data_aprovacao_req date;

 BEGIN

  --> Ativa ou desativa o log de erros de acordo com o parametro
    /*IF p_show_log = 'Y' THEN
    g_bShow_log := TRUE;
  END IF;*/
  
  l_exec := 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS='',.''';

  execute immediate l_exec;  

  show_error_log_p(p_message => 'Inicio do relatorio gen_relat_po_facilit_p');

  --gen_xml_p('<?xml version="1.0" encoding="UTF-8"?>');
  --gen_xml_p('<?xml version="1.0" encoding="UTF-16"?>');
  gen_xml_p('<?xml version="1.0" encoding="ISO-8859-1"?>');
  gen_xml_p('<HEADERS>');

  gen_xml_p(' <HEADER>');

  gen_xml_p('    <EMPRESA>'  || P_UNID_OPER ||'</EMPRESA>');
  gen_xml_p('    <DATA_DE>'  || to_char(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR') ||'</DATA_DE>');
  gen_xml_p('    <DATA_ATE>'  || to_char(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')  ||'</DATA_ATE>');
  --gen_xml_p('    <STATUS_APROV>'  || P_STATUS_APROV ||'</STATUS_APROV>');
  gen_xml_p('    <DATA_VAL_BLANK>'  || to_char(to_date(P_DATA_VALID_BLANK,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR') ||'</DATA_VAL_BLANK>');
  gen_xml_p('    <CENTRO_DE_CUSTO>'  || P_CENTRO_CUSTO ||'</CENTRO_DE_CUSTO>');

  FOR r_po_facilit IN c_po_facilit LOOP

   gen_xml_p('   <LINES_FACILIT>');
   
    IF r_po_facilit.REQ_DISTRIBUTION_ID IS NULL THEN
    
     l_data_criacao_req := '';
     l_data_aprovacao_req := '';
     
    ELSE
    
     l_data_criacao_req := r_po_facilit.Data_Criacao_Req; 
     l_data_aprovacao_req := r_po_facilit.Data_Aprovacao_Req;
    
    END IF;

    gen_xml_p('    <UNIDADE_OPERACIONAL>'  || conv_spc_chr(r_po_facilit.UNIDADE_OPERACIONAL) ||'</UNIDADE_OPERACIONAL>');
    gen_xml_p('    <FORNECEDOR>'  || conv_spc_chr(r_po_facilit.FORNECEDOR) ||'</FORNECEDOR>');
    --gen_xml_p('    <FORNECEDOR>'  || r_po_facilit.FORNECEDOR ||'</FORNECEDOR>');
    gen_xml_p('    <LOCAL_FORNECEDOR>'  || conv_spc_chr(r_po_facilit.LOCAL_FORNECEDOR) ||'</LOCAL_FORNECEDOR>');
    gen_xml_p('    <CNPJ_CPF>'  || conv_spc_chr(r_po_facilit.CNPJ_CPF) ||'</CNPJ_CPF>');
    gen_xml_p('    <TIPO_PO>'  || conv_spc_chr(r_po_facilit.TIPO_PO) ||'</TIPO_PO>');
    gen_xml_p('    <COMPRADOR>'  || conv_spc_chr(r_po_facilit.COMPRADOR) ||'</COMPRADOR>');
    gen_xml_p('    <STATUS_PO>'  || conv_spc_chr(r_po_facilit.STATUS_PO) ||'</STATUS_PO>');
    gen_xml_p('    <NR_PO>'  || conv_spc_chr(r_po_facilit.NR_PO) ||'</NR_PO>');
    gen_xml_p('    <NR_RELEASE>'  || conv_spc_chr(r_po_facilit.NR_RELEASE) ||'</NR_RELEASE>');
    gen_xml_p('    <DATA_CRIACAO_PO>'  || TO_CHAR(r_po_facilit.DATA_CRIACAO_PO,'DD/MM/RRRR') ||'</DATA_CRIACAO_PO>');
    gen_xml_p('    <DATA_APROVACAO_PO>'  || TO_CHAR(r_po_facilit.DATA_APROVACAO_PO,'DD/MM/RRRR') ||'</DATA_APROVACAO_PO>');
    gen_xml_p('    <REQUISITANTE>'  || conv_spc_chr(r_po_facilit.REQUISITANTE) ||'</REQUISITANTE>');
    gen_xml_p('    <NR_REQUISICAO>'  || conv_spc_chr(r_po_facilit.NR_REQUISICAO) ||'</NR_REQUISICAO>');
    gen_xml_p('    <DATA_CRIACAO_REQ>'  || TO_CHAR(l_data_criacao_req,'DD/MM/RRRR') ||'</DATA_CRIACAO_REQ>');
    gen_xml_p('    <DATA_APROVACAO_REQ>'  || TO_CHAR(l_data_aprovacao_req,'DD/MM/RRRR') ||'</DATA_APROVACAO_REQ>');
    gen_xml_p('    <GLOBAL>'  || conv_spc_chr(r_po_facilit.GLOBAL) ||'</GLOBAL>');
    gen_xml_p('    <TOTAL_ACORDO>'  || LTRIM(TO_CHAR(conv_spc_chr(r_po_facilit.TOTAL_ACORDO),'999G999G990D00')) ||'</TOTAL_ACORDO>');
    --gen_xml_p('    <TOTAL_ACORDO>'  || TO_CHAR(r_po_facilit.TOTAL_ACORDO,'999G999G999D99') ||'</TOTAL_ACORDO>');
    gen_xml_p('    <DATA_INICIO>'  || TO_CHAR(r_po_facilit.DATA_INICIO,'DD/MM/RRRR') ||'</DATA_INICIO>');
    gen_xml_p('    <DATA_FIM>'  || TO_CHAR(r_po_facilit.DATA_FIM,'DD/MM/RRRR') ||'</DATA_FIM>');
    gen_xml_p('    <MOEDA>'  || conv_spc_chr(r_po_facilit.MOEDA) ||'</MOEDA>');
    gen_xml_p('    <COND_PAGTO>'  || conv_spc_chr(r_po_facilit.COND_PAGTO) ||'</COND_PAGTO>');
    gen_xml_p('    <NR_LINHA>'  || conv_spc_chr(r_po_facilit.NR_LINHA) ||'</NR_LINHA>');
    gen_xml_p('    <TIPO_LINHA>'  || conv_spc_chr(r_po_facilit.TIPO_LINHA) ||'</TIPO_LINHA>');
    gen_xml_p('    <NOME_CATEGORIA>'  || conv_spc_chr(r_po_facilit.NOME_CATEGORIA) ||'</NOME_CATEGORIA>');
    gen_xml_p('    <NR_ITEM>'  || conv_spc_chr(r_po_facilit.NR_ITEM) ||'</NR_ITEM>');
    gen_xml_p('    <DESCRICAO_ITEM>'  || conv_spc_chr(r_po_facilit.DESCRICAO_ITEM) ||'</DESCRICAO_ITEM>');
    gen_xml_p('    <STATUS_ITEM>'  || conv_spc_chr(r_po_facilit.STATUS_ITEM) ||'</STATUS_ITEM>');
    gen_xml_p('    <NR_DISTRIBUICAO_CONTABIL>'  || conv_spc_chr(r_po_facilit.NR_DISTRIBUICAO_CONTABIL) ||'</NR_DISTRIBUICAO_CONTABIL>');
    gen_xml_p('    <CENTRO_CUSTO>'  || conv_spc_chr(r_po_facilit.CENTRO_CUSTO) ||'</CENTRO_CUSTO>');
    gen_xml_p('    <DESCRICAO_CENTRO_CUSTO>'  || conv_spc_chr(r_po_facilit.DESCRICAO_CENTRO_CUSTO) ||'</DESCRICAO_CENTRO_CUSTO>');
    gen_xml_p('    <UNIDADE_NEGOCIO>'  || conv_spc_chr(r_po_facilit.UNIDADE_NEGOCIO) ||'</UNIDADE_NEGOCIO>');
    gen_xml_p('    <DESCRICAO_UNIDADE_NEGOCIO>'  || conv_spc_chr(r_po_facilit.DESCRICAO_UNIDADE_NEGOCIO) ||'</DESCRICAO_UNIDADE_NEGOCIO>');
    gen_xml_p('    <PRECO>'  || LTRIM(TO_CHAR(conv_spc_chr(r_po_facilit.PRECO),'999G999G990D00')) ||'</PRECO>');
    gen_xml_p('    <QUANTIDADE>'  || conv_spc_chr(r_po_facilit.QUANTIDADE) ||'</QUANTIDADE>');
    gen_xml_p('    <QUANTIDADE_SOLICITADA>'  || LTRIM(TO_CHAR(conv_spc_chr(r_po_facilit.QUANTIDADE_SOLICITADA),'999G999G990D00')) ||'</QUANTIDADE_SOLICITADA>');
    gen_xml_p('    <QUANTIA_FATURADA>'  || LTRIM(TO_CHAR(conv_spc_chr(r_po_facilit.QUANTIA_FATURADA),'999G999G990D00')) ||'</QUANTIA_FATURADA>');
    gen_xml_p('    <OI_ENTREGA>'  || conv_spc_chr(r_po_facilit.OI_ENTREGA) ||'</OI_ENTREGA>');

   gen_xml_p('   </LINES_FACILIT>');

  END LOOP;

  gen_xml_p(' </HEADER>');

  gen_xml_p('</HEADERS>');

 END gen_relat_po_facilit_p;

 PROCEDURE show_error_log_p(p_message IN VARCHAR2) IS
 BEGIN
  IF g_bShow_log THEN
    fnd_file.put_line(fnd_file.log, p_message);
  END IF;
 END show_error_log_p;

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER IS

  l_vDecimal_char VARCHAR2(1);

 BEGIN
  --> Recupera o character decimal
  l_vDecimal_char := substr(ltrim(to_char(.3, '0D0')), 2, 1);

  --> Transforma o varchar para um número com um decimal válido
  IF l_vDecimal_char = ',' THEN
    RETURN round(to_number(translate(p_value, '.', l_vDecimal_char)), 20);
  ELSE
    RETURN round(to_number(translate(p_value, ',', l_vDecimal_char)), 20);
  END IF;

 END canonical_to_number_f;
 --

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2 IS

  l_vReturn      VARCHAR2(20);
  l_nDecimal_qty NUMBER;
  l_nMask_qty    NUMBER;
  l_vMask        VARCHAR2(100);

 BEGIN

  l_vMask := p_mask;
  l_nMask_qty := length(substr(l_vMask, instr(l_vMask, '.') + 1));

  --> Verifica se deve criar uma máscara com mais de 3 decimais- INICIO
  IF l_nMask_qty > 3 THEN

    --> Verifica se há decimais no valor - INICIO
    IF instr(to_char(translate(p_value, ',', '.')), '.') = 0 THEN
      l_nDecimal_qty := 0;
    ELSE
      --> Armazena a quantidade de digitos de decimais
      l_nDecimal_qty := length(substr(to_char(translate(p_value, ',', '.')), instr(to_char(translate(p_value, ',', '.')), '.') + 1));
    END IF;

    --> Verifica se a mascara retornou menos que 2
    IF l_nDecimal_qty <= 2 THEN
      l_nDecimal_qty := 2;
    END IF;

    --> Gera uma novas máscara com a quantidade de decimais necessárias
    l_vMask := substr(l_vMask, 1,  instr(l_vMask, '.')) || rpad('0', l_nDecimal_qty, '0');

  END IF;

  l_vReturn := lpad(to_char(p_value, l_vMask), 20, ' ');
  l_vReturn := REPLACE( l_vReturn, ',', '@' );
  l_vReturn := REPLACE( l_vReturn, '.', ',' );
  l_vReturn := REPLACE( l_vReturn, '@', '.' );

  RETURN(trim(l_vReturn));

 END format_br_mask_f;
 --

 -- Função que retorna valor por extenso:
 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2 IS

  valor_string VARCHAR2(256);
  valor_conv   VARCHAR2(25);
  tres_digitos VARCHAR2(3);
  texto_string VARCHAR2(256);
  ind          NUMBER;

 BEGIN
  valor_conv := to_char(trunc((abs(valor) * 100)
                             ,0)
                       ,'0999999999999999999');
  valor_conv := substr(valor_conv
                      ,1
                      ,18) || '0' || substr(valor_conv
                                           ,19
                                           ,2);
  IF to_number(valor_conv) = 0 THEN
    RETURN('Zero ');
  END IF;

  FOR ind IN 1 .. 7 LOOP
    tres_digitos := substr(valor_conv
                          ,(((ind - 1) * 3) + 1)
                          ,3);
    texto_string := '';

    -- Extenso para Centena
    IF substr(tres_digitos
             ,1
             ,1) = '2' THEN
      texto_string := texto_string || 'Duzentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '3' THEN
      texto_string := texto_string || 'Trezentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '4' THEN
      texto_string := texto_string || 'Quatrocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '5' THEN
      texto_string := texto_string || 'Quinhentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '6' THEN
      texto_string := texto_string || 'Seiscentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '7' THEN
      texto_string := texto_string || 'Setecentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '9' THEN
      texto_string := texto_string || 'Novecentos ';
    END IF;

    IF substr(tres_digitos
             ,1
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,2
               ,2) = '00' THEN
        texto_string := texto_string || 'Cem ';
      ELSE
        texto_string := texto_string || 'Cento ';
      END IF;

    END IF;
    -- Extenso para Dezena
    IF substr(tres_digitos
             ,2
             ,1) <> '0'
       AND texto_string IS NOT NULL THEN
      texto_string := texto_string || 'e ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '2' THEN
      texto_string := texto_string || 'Vinte ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '3' THEN
      texto_string := texto_string || 'Trinta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '4' THEN
      texto_string := texto_string || 'Quarenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '5' THEN
      texto_string := texto_string || 'Cinquenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '6' THEN
      texto_string := texto_string || 'Sessenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '7' THEN
      texto_string := texto_string || 'Setenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '9' THEN
      texto_string := texto_string || 'Noventa ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,3
               ,1) <> '0' THEN

        IF substr(tres_digitos
                 ,3
                 ,1) = '1' THEN
          texto_string := texto_string || 'Onze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '2' THEN
          texto_string := texto_string || 'Doze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '3' THEN
          texto_string := texto_string || 'Treze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '4' THEN
          texto_string := texto_string || 'Quatorze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '5' THEN
          texto_string := texto_string || 'Quinze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '6' THEN
          texto_string := texto_string || 'Dezesseis ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '7' THEN
          texto_string := texto_string || 'Dezessete ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '8' THEN
          texto_string := texto_string || 'Dezoito ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '9' THEN
          texto_string := texto_string || 'Dezenove ';
        END IF;

      ELSE
        texto_string := texto_string || 'Dez ';
      END IF;

    ELSE

      -- Extenso para Unidade
      IF substr(tres_digitos
               ,3
               ,1) <> '0'
         AND texto_string IS NOT NULL THEN
        texto_string := texto_string || 'e ';
      END IF;

      IF substr(tres_digitos
               ,3
               ,1) = '1' THEN
        texto_string := texto_string || 'Um ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '2' THEN
        texto_string := texto_string || 'Dois ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '3' THEN
        texto_string := texto_string || 'Tres ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '4' THEN
        texto_string := texto_string || 'Quatro ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '5' THEN
        texto_string := texto_string || 'Cinco ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '6' THEN
        texto_string := texto_string || 'Seis ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '7' THEN
        texto_string := texto_string || 'Sete ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '8' THEN
        texto_string := texto_string || 'Oito ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '9' THEN
        texto_string := texto_string || 'Nove ';
      END IF;

    END IF;

    IF to_number(tres_digitos) > 0 THEN
      IF to_number(tres_digitos) = 1 THEN
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhão ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhão ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhão ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhão ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      ELSE
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhões ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhões ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhões ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhões ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      END IF;
    END IF;
    valor_string := valor_string || texto_string;
    -- Escrita da Moeda Corrente
    IF ind = 5 THEN
      IF to_number(substr(valor_conv
                         ,16
                         ,3)) > 0
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    ELSE
      IF ind < 5
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    END IF;
    IF ind = 6 THEN
      IF to_number(substr(valor_conv
                         ,1
                         ,18)) > 1 THEN
        valor_string := valor_string || 'Reais ';
      ELSIF to_number(substr(valor_conv
                            ,1
                            ,18)) = 1 THEN
        valor_string := valor_string || 'Real ';
      END IF;

      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 0
         AND length(valor_string) > 0 THEN
        valor_string := valor_string || 'e ';
      END IF;
    END IF;
    -- Escrita para Centavos
    IF ind = 7 THEN
      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 1 THEN
        valor_string := valor_string || 'Centavos ';
      ELSIF to_number(substr(valor_conv
                            ,20
                            ,2)) = 1 THEN
        valor_string := valor_string || 'Centavo ';
      END IF;
    END IF;
  END LOOP;
  RETURN(rtrim(valor_string));
 EXCEPTION
  WHEN OTHERS THEN
    RETURN('*** VALOR INVALIDO ***');
 END;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2 IS

  l_vChar VARCHAR2(4000) := p_char;

 BEGIN
  l_vChar := REPLACE(l_vChar, '&', '&amp;');
  l_vChar := REPLACE(l_vChar, '<', ';');
  l_vChar := REPLACE(l_vChar, '>', ';');
  l_vChar := REPLACE(l_vChar, '"', ';');
  l_vChar := REPLACE(l_vChar, '''', ';');
  l_vChar := REPLACE(l_vChar, 'º', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'C');
  l_vChar := REPLACE(l_vChar, 'ç', 'c');
  l_vChar := REPLACE(l_vChar, 'ç', 'c');
  l_vChar := REPLACE(l_vChar, 'ã', 'a');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'A');
  l_vChar := REPLACE(l_vChar, 'é', 'e');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'E');
  l_vChar := REPLACE(l_vChar, 'í', 'i');
  l_vChar := REPLACE(l_vChar, 'Í', 'I');
  l_vChar := REPLACE(l_vChar, 'ó', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'O');
  l_vChar := REPLACE(l_vChar, 'ú', 'u');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'U');

  RETURN(l_vChar);
 END conv_spc_chr;
 --

 PROCEDURE gen_xml_p(p_message IN VARCHAR2) IS
 BEGIN
   IF g_bGen_XML THEN
     -- Gera Log de execucao
     dbms_output.put_line(p_message);
   ELSE
     -- Grava saida do concurrent:
     fnd_file.put_line(fnd_file.output,p_message);
   END IF;

 END gen_xml_p;
 --

END XXSTN_PO_RELAT_FACILIT_PKG;
--Indicativo de Final de Arquivo. N�o deve ser removido.
/

show errors package body apps.XXSTN_PO_RELAT_FACILIT_PKG 

EXIT
/

