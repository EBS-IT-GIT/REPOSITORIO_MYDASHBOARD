CREATE OR REPLACE PACKAGE BODY PO_CUSTOM_XMLGEN_PKG AS
/* $Header: PO_CUSTOM_XMLGEN_PKG.plb 120.1.12020000.2 2013/02/11 13:22:53 vegajula noship $ */

--========================================================================
-- PROCEDURE : generate_xml_fragment       PUBLIC
-- PARAMETERS: p_document_id         document id
--           : p_revision_num        revision num of the document
--           : p_document_type       document type of the document
--           : p_document_subtype    document subtype of the document
--           : x_custom_xml          output of xml
-- COMMENT   : Custom hook to generate XML fragment for document,
--             called by PO Output for Communication
-- PRE-COND  : NONE
-- EXCEPTIONS: NONE
-- EXAMPLE CODES: Here is an example of how to program custom code.
/**
PROCEDURE generate_xml_fragment
(p_document_id IN NUMBER
, p_revision_num IN NUMBER
, p_document_type IN VARCHAR2
, p_document_subtype IN VARCHAR2
, x_custom_xml OUT NOCOPY CLOB)
IS
  --1). Declare context
  context DBMS_XMLGEN.ctxHandle;
BEGIN

  --2). Init context with custom query sql statement
  context := dbms_xmlgen.newContext('select 1,2,3 from dual');

  --3). Set XML tag of the XML fragment for the result set
  dbms_xmlgen.setRowsetTag(context,'CUSTOM_RESULT');

  --4). Set XML tag for each row of the result set
  dbms_xmlgen.setRowTag(context,NULL);

  dbms_xmlgen.setConvertSpecialChars (context, TRUE);

  --5). Call dbms_xmlgen to get XML and assign it to output CLOB
  x_custom_xml := dbms_xmlgen.getXML(context,DBMS_XMLGEN.NONE);

  dbms_xmlgen.closeContext(context);
EXCEPTION
  WHEN OTHERS THEN
  --6). Capture any exceptions and handle them properly
    NULL;
END;
*/
--========================================================================
PROCEDURE generate_xml_fragment
(p_document_id IN NUMBER
, p_revision_num IN NUMBER
, p_document_type IN VARCHAR2
, p_document_subtype IN VARCHAR2
, x_custom_xml OUT NOCOPY CLOB)
IS
  l_custom_query VARCHAR2(32000);
  -- 1). Declare context
  l_context     DBMS_XMLGEN.ctxHandle;
  l_xml       VARCHAR2(32000);

BEGIN
  -- 

  l_custom_query := 'SELECT DISTINCT
    hou.short_code org_code,
    decode(hou.short_code,''OU_STONE'',''STONE'',''OU_BUY4'',''BUY4'',''OU_BUY4LLC'',''BUY4 LLC'',''OU_B4_LLC'',''BUY4 LLC'',''OU_DLP'',''DLP'',''OU_DLPPAR'',''DLPPAR'',''OU_ELAVON'',''ELAVON'',
    ''OU_EQUALS'',''EQUALS'',''OU_MUNDIPA'',''MUNDIPA'',''OU_PAGARME'',''PAGARME'',''OU_CAPPTA'',''CAPPTA'',''STONE'')   unid_oper, /* Fernando Pavao 17/10/2018 */
    pha.po_header_id,
    NVL2(pra.release_num,'' - ''||pra.release_num,pra.release_num) release_num,
    pha.segment1 po_number,
    '|| CHR(10) ||
    CASE
    When p_document_type = 'RELEASE' then
    ' TO_CHAR(pra.creation_date,''DD/MM/YYYY HH24:MI:SS'') '|| chr(10)
    when p_document_type != 'RELEASE' then
    ' TO_CHAR(pha.creation_date,''DD/MM/YYYY HH24:MI:SS'') '||chr(10)
    end ||' po_creation_date,
    pha.bill_to_location_id,
    (SELECT hla.location_code
       FROM hr_locations_all hla
      WHERE hla.location_id = pha.bill_to_location_id) location_code,
    pha.vendor_id,
    pha.vendor_site_id,
    aps.vendor_name,
    aps.segment1 vendor_number,
    ( apss.address_line1 || '' '' ||
      apss.address_line2 || '' '' ||
      apss.address_line3 ) vendor_address,
    apss.address_line4 vendor_bairro, /*fpavao alt 21/03/2019 - ajusta para buscar o bairro do address_line4*/
    apss.city vendor_city,
    apss.state vendor_state,
    REGEXP_REPLACE(REGEXP_REPLACE(apss.zip,''[^0-9]'',''''),''([0-9]{5})'',''\1-'') vendor_zip,
    apss.phone vendor_phone,
    apss.email_address vendor_email,
    NVL(apss.payment_method_lookup_code,
    (SELECT ieppm.payment_method_code
       FROM ap_supplier_sites_all assa,
            ap_suppliers sup,
            iby_external_payees_all iepa,
            iby_ext_party_pmt_mthds ieppm
      WHERE sup.vendor_id = assa.vendor_id
        AND assa.pay_site_flag = ''Y''
        AND assa.vendor_site_id = iepa.supplier_site_id
        AND iepa.ext_payee_id = ieppm.ext_pmt_party_id
        AND ((ieppm.inactive_date IS NULL) OR (ieppm.inactive_date > SYSDATE))
        AND assa.vendor_site_id = pha.vendor_site_id
        AND ieppm.primary_flag = ''Y''
        AND ROWNUM = 1)) vendor_pay_method,
     decode(apss.global_attribute9,''2'',substr(apss.global_attribute10, 2, 9) || ''/'' || apss.global_attribute11 || ''-'' ||apss.global_attribute12
                              ,''3'',lpad(apss.party_site_id, 9, ''0'') || ''/'' || apss.global_attribute11 || ''-'' ||apss.global_attribute12
                              ,apss.global_attribute10 || ''-'' || apss.global_attribute12) vendor_cnpj, /*fpavao alt 21/03/2019 - alteracao formato cnpj*/
    ( SELECT rfea.ie
        FROM cll_f189_fiscal_entities_all rfea
        WHERE rfea.vendor_site_id (+) = pha.vendor_site_id /* Fernando Pavao 17/10/2018 */) vendor_ie,
    pb.per_name po_buyer_name,
    pb.email_address po_buyer_email,
    pb.phone_number po_buyer_phone,
    pda.deliver_to_person_id,
    pr.per_name po_requestor_name,
    pr.email_address po_requestor_email,
    NVL(pr.phone_number, '' '') po_requestor_phone,
    apt.name term_name,
    TO_CHAR(plla.promised_date,''DD/MM/YYYY'') promised_date,
    ( ship_inf.address_line_1 || '' '' ||
      ship_inf.address_line_2 || '' '' ||
      ship_inf.address_line_3 ) ship_address,
    /* Fernando Pavao 07/11/2018 - inclusao para trazer a razao social */
    ship_inf.razao_social ship_razao_social,
    ship_inf.bairro ship_bairro,
    ship_inf.city ship_city,
    ship_inf.state ship_state,
    ship_inf.postal_code ship_zip,
    ship_inf.document_number ship_cnpj,
    /* Fernando Pavao 12/11/2018 - inclusao para trazer informacoes do endereco de faturamento - begin */
    ( bill_inf.address_line_1 || '' '' ||
      bill_inf.address_line_2 || '' '' ||
      bill_inf.address_line_3 ) bill_address,
    bill_inf.razao_social bill_razao_social,
    bill_inf.bairro bill_bairro,
    bill_inf.city bill_city,
    bill_inf.state bill_state,
    bill_inf.postal_code bill_zip,
    bill_inf.document_number bill_cnpj,
    /* Fernando Pavao 12/11/2018 - inclusao para trazer informacoes do endereco de faturamento - end */
    ( SELECT need_by_date
        FROM PO_LINE_LOCATIONS_ALL
        WHERE need_by_date IS NOT NULL
         AND po_header_id = pha.po_header_id
         AND ROWNUM = 1) prazo_entrega_oc, /* Fernando Pavao 12/11/2018 */
    ( SELECT note_to_receiver
        FROM PO_LINE_LOCATIONS_ALL
       WHERE note_to_receiver IS NOT NULL
         AND po_header_id = pha.po_header_id
         AND ROWNUM = 1) note_to_receiver,
    ( SELECT note_to_vendor
        FROM PO_LINES_ALL
        WHERE note_to_vendor IS NOT NULL
          AND po_header_id = pha.po_header_id
          AND ROWNUM = 1) note_to_vendor,
    ( /* LCARMO - 23/09/2019 */
SELECT TO_CHAR(SUM(unit_price * quantity), ''999G999G999G990D00'') total_amount /* FPAVAO 03/04/2019 */
FROM (
SELECT pla.unit_price, pla.quantity
FROM po_headers_all pha1,
    po_lines_all pla,
    po_line_locations_all plla,
    mtl_system_items_b msi
WHERE pha1.po_header_id = pha.po_header_id
  AND pha1.type_lookup_code = ''STANDARD''
  AND pla.po_header_id = pha1.po_header_id
  AND plla.po_header_id = pla.po_header_id
  AND plla.po_line_id = pla.po_line_id
  AND msi.inventory_item_id = pla.item_id
  AND msi.organization_id = plla.ship_to_organization_id
UNION ALL
SELECT
     pla.unit_price, plla.quantity
FROM po_headers_all pha1,
    po_releases_all pra1,
    po_lines_all pla,
    po_line_locations_all plla,
    mtl_system_items_b msi
WHERE pha1.po_header_id = pha.po_header_id
  AND pra1.release_num = pra.release_num
  AND pha1.type_lookup_code = ''BLANKET''
  AND pla.po_header_id = pha1.po_header_id
  AND pra1.po_header_id = pha1.po_header_id 
  AND plla.po_release_id = pra1.po_release_id
  AND plla.po_header_id = pla.po_header_id
  AND plla.po_line_id = pla.po_line_id
  AND msi.inventory_item_id = pla.item_id
  AND msi.organization_id = plla.ship_to_organization_id) ) valor_total,
    CURSOR ( SELECT /* lcarmo - 29/03/2019 */
    pla.po_line_id,
    pla.item_id,
    pla.org_id,
    pla.line_num,
    msi.segment1 item_code,
    msi.description item_description,
    TO_CHAR(plla.need_by_date,''DD/MM/YYYY'') need_by_date,
    pha1.currency_code,
    pla.quantity,
    TO_CHAR(pla.unit_price, ''999G999G999G990D00'') unit_price, /* FPAVAO 03/04/2019 */
    TO_CHAR((pla.unit_price * pla.quantity), ''999G999G999G990D00'') line_total_amount /* FPAVAO 03/04/2019 */
FROM po_headers_all pha1,
    po_lines_all pla,
    po_line_locations_all plla,
    mtl_system_items_b msi
WHERE 1 = 1
  AND pha1.type_lookup_code = ''STANDARD''
  AND pha1.po_header_id = pha.po_header_id
  AND pla.po_header_id = pha1.po_header_id
  AND plla.po_header_id = pla.po_header_id
  AND plla.po_line_id = pla.po_line_id
  AND msi.inventory_item_id = pla.item_id
  AND msi.organization_id = plla.ship_to_organization_id
UNION ALL
SELECT
    pla.po_line_id,
    pla.item_id,
    pla.org_id,
    pla.line_num,
    msi.segment1 item_code,
    msi.description item_description,
    TO_CHAR(plla.need_by_date,''DD/MM/YYYY'') need_by_date,
    pha1.currency_code,
    plla.quantity,
    TO_CHAR(pla.unit_price, ''999G999G999G990D00'') unit_price, /* FPAVAO 03/04/2019 */
    TO_CHAR((pla.unit_price * plla.quantity ), ''999G999G999G990D00'') line_total_amount /* FPAVAO 03/04/2019 */
FROM po_headers_all pha1,
    po_releases_all pra1,
    po_lines_all pla,
    po_line_locations_all plla,
    mtl_system_items_b msi
WHERE 1 = 1
  AND pha1.type_lookup_code = ''BLANKET''
  AND pha1.po_header_id = pha.po_header_id
  AND pra1.release_num = pra.release_num
  AND pra1.po_header_id = pha1.po_header_id
  and pra1.po_release_id = plla.po_release_id
  AND pla.po_header_id = pha1.po_header_id
  AND plla.po_header_id = pla.po_header_id
  AND plla.po_line_id = pla.po_line_id
  AND msi.inventory_item_id = pla.item_id
  AND msi.organization_id = plla.ship_to_organization_id ) xx_po_lines
FROM
    po_headers_all             pha,
    po_releases_all            pra,
    po_distributions_all       pda,
    po_req_distributions_all   prda,
    po_requisition_lines_all   prla,
    po_requisition_headers_all prha,
    ap_suppliers               aps,
    ap_supplier_sites_all      apss,
    ( SELECT papf.person_id,
             ( papf.first_name || '' '' || papf.last_name ) per_name,
             papf.email_address,
             pp.phone_number
        FROM per_all_people_f papf,
             per_all_assignments_f paaf,
             per_phones pp
        WHERE 1 = 1
          AND pp.parent_table (+) = ''PER_ALL_PEOPLE_F''
          AND pp.parent_id (+) = papf.person_id
          AND pp.phone_type (+) = ''M''
          AND papf.person_id = paaf.person_id
          AND papf.business_group_id = paaf.business_group_id
          AND trunc(SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date
          AND trunc(SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date ) pb,
    (SELECT papf.person_id,
            ( papf.first_name || '' '' || papf.last_name ) per_name,
            papf.email_address,
            pp.phone_number
       FROM per_all_people_f papf,
            per_all_assignments_f paaf,
            per_phones pp
      WHERE 1 = 1
        AND pp.parent_table (+) = ''PER_ALL_PEOPLE_F''
        AND pp.parent_id (+) = papf.person_id
        AND pp.phone_type (+) = ''M''
        AND papf.person_id = paaf.person_id
        AND papf.business_group_id = paaf.business_group_id
        AND trunc(SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date
        AND trunc(SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date ) pr,
    /* Fernando Pavao 12/11/2018 inclusao das informacoes do endereco de faturamento - begin */
    (SELECT hl.location_id,
            hl.address_line_1,
            hl.address_line_2,
            hl.address_line_3,
            hl.inventory_organization_id,
            decode(hl.style,''BR'',hl.region_1,'''') bairro, /* Fernando Pavao 18/10/2018 */
            hl.town_or_city city,
            nvl(hl.region_2,hl.region_1) state, /* Fernando Pavao 17/10/2018 */
            REGEXP_REPLACE(REGEXP_REPLACE(hl.postal_code,''[^0-9]'',''''),''([0-9]{5})'',''\1-'') postal_code,
            REGEXP_REPLACE(cffe.document_number,''([0-9]{2})([0-9]{3})([0-9]{3})([0-9]{4})'',''\1.\2.\3/\4-'') document_number,
            cffe.ie,
            NVL((select xep.name
              from xle_entity_profiles xep
                  ,xle_registrations xr
             where xr.source_id = xep.legal_entity_id
               and xr.source_table = ''XLE_ENTITY_PROFILES''
               and xr.location_id = hl.location_id
               and rownum = 1),(select xep.name
                                  from xle_entity_profiles xep
                                      ,org_organization_definitions ood
                                 where xep.legal_entity_id = ood.legal_entity
                                   and ood.organization_id = hl.inventory_organization_id
                                   and rownum = 1
                                )) razao_social
       FROM hr_locations hl,
            cll_f189_fiscal_entities_all cffe
      WHERE 1 = 1
        AND cffe.location_id (+) = hl.location_id
        AND cffe.entity_type_lookup_code (+) = ''LOCATION''
        AND cffe.document_type (+) = ''CNPJ'') bill_inf,
    /* Fernando Pavao 12/11/2018 inclusao das informacoes do endereco de faturamento - end */
    (SELECT hl.location_id,
            hl.address_line_1,
            hl.address_line_2,
            hl.address_line_3,
            decode(hl.style,''BR'',hl.region_1,'''') bairro, /* Fernando Pavao 18/10/2018 */
            hl.town_or_city city,
            nvl(hl.region_2,hl.region_1) state, /* Fernando Pavao 17/10/2018 */
            REGEXP_REPLACE(REGEXP_REPLACE(hl.postal_code,''[^0-9]'',''''),''([0-9]{5})'',''\1-'') postal_code,
            REGEXP_REPLACE(cffe.document_number,''([0-9]{2})([0-9]{3})([0-9]{3})([0-9]{4})'',''\1.\2.\3/\4-'') document_number,
            cffe.ie,
            /* Fernando Pavao 07/11/2018 - inclusao para trazer a razao social */
            (select xep.name
              from xle_entity_profiles xep
                  ,xle_registrations xr
             where xr.source_id = xep.legal_entity_id
               and xr.source_table = ''XLE_ENTITY_PROFILES''
               and xr.location_id = hl.location_id
               and rownum = 1) razao_social
       FROM hr_locations hl,
            cll_f189_fiscal_entities_all cffe
      WHERE 1 = 1
        AND cffe.location_id (+) = hl.location_id /* Fernando Pavao 17/10/2018 */
        AND cffe.entity_type_lookup_code (+) = ''LOCATION'' /* Fernando Pavao 17/10/2018 */
        AND cffe.document_type (+) = ''CNPJ''  ) ship_inf, /* Fernando Pavao 17/10/2018 */
    ap_terms apt,
    po_line_locations_all plla,
    hr_operating_units hou
WHERE pha.po_header_id = pda.po_header_id
  AND pda.req_distribution_id = prda.distribution_id(+)           /* Paulo Ribas */
  AND prda.requisition_line_id = prla.requisition_line_id(+)       /* Paulo Ribas */
  AND prla.requisition_header_id = prha.requisition_header_id(+)   /* Paulo Ribas */
  AND hou.organization_id = pha.org_id '|| CHR(10) ||
  CASE
    When p_document_type = 'RELEASE' then
  ' AND pra.po_RELEASE_id = '|| p_document_id ||chr(10)
    when p_document_type != 'RELEASE' then
  ' AND pha.po_header_id = '|| p_document_id ||chr(10)
  end
||' AND pha.type_lookup_code IN ( ''STANDARD'', ''BLANKET'', ''CONTRACT'' )
  AND aps.vendor_id = pha.vendor_id
  AND apss.vendor_id = pha.vendor_id
  AND apss.vendor_site_id = pha.vendor_site_id
  AND pb.person_id (+) = pha.agent_id
  AND pr.person_id (+) = pda.deliver_to_person_id
  AND apt.term_id = pha.terms_id
  AND plla.po_header_id = pha.po_header_id
  AND plla.PO_RELEASE_ID = pra.PO_RELEASE_ID(+)  /* Paulo Ribas */
  AND pda.PO_RELEASE_ID  = pra.PO_RELEASE_ID(+)  /* Paulo Ribas */
  AND pha.po_header_id   = pra.po_header_id(+)   /* Paulo Ribas */
  AND ship_inf.location_id(+) = pha.ship_to_location_id /* Fernando Pavao */
  AND bill_inf.location_id(+) = pha.bill_to_location_id /* 12/11/2018 Fernando Pavao */
  AND pda.line_location_id = plla.line_location_id /* Fernando Pavao 08/11/2018 */
  AND pda.po_distribution_id in(select max(po_distribution_id)
                                  from po_distributions_all
                                 where po_header_id = pha.po_header_id)';

 -- fnd_file.put_line(fnd_file.log,'******** QUERY ******** ');
 -- fnd_file.put_line(fnd_file.log, l_custom_query );

  -- 2). Init context with custom query sql statement
  l_context := dbms_xmlgen.newContext( l_custom_query );
--DBMS_OUTPUT.PUT_LINE(l_context);

  -- 3). Set XML tag of the XML fragment for the result set
  dbms_xmlgen.setRowsetTag(l_context,'CUSTOM_RESULT');

  -- 4). Set XML tag for each row of the result set
  dbms_xmlgen.setRowTag(l_context, 'CUSTOM_TEST');
  dbms_xmlgen.setConvertSpecialChars (l_context, TRUE);

  -- 5). Call dbms_xmlgen to get XML and assign it to output CLOB
  x_custom_xml := dbms_xmlgen.getXML(l_context,DBMS_XMLGEN.NONE);
  l_xml := CAST(x_custom_xml AS VARCHAR2);
--DBMS_OUTPUT.PUT_LINE(l_xml);
fnd_file.put_line(fnd_file.log,l_xml);

  dbms_xmlgen.closeContext(l_context);
EXCEPTION
  WHEN OTHERS THEN
  --6). Capture any exceptions and handle them properly
    fnd_file.put_line(fnd_file.log,'General Error: ' || sqlerrm);
    DBMS_OUTPUT.PUT_LINE('General Error: ' || sqlerrm);
END;

END PO_CUSTOM_XMLGEN_PKG;
/

show errors package body apps.PO_CUSTOM_XMLGEN_PKG 

EXIT
/
