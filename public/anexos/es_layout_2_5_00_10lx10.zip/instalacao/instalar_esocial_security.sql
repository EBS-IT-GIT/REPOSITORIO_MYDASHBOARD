/*
 _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
|           TM                                                        |
|RHEVOLUTION                                                          |
|COPYRIGHT � 1996 TECHWARE SYSTEMS                                    |
|---------------------------------------------------------------------|
|AVISO:                                                               |
|ESTE PROGRAMA DE COMPUTADOR E PROTEGIDO PELA LEI DE DIREITO AUTORAL E|
|TRATADOS INTERNACIONAIS E TODOS OS DIREITOS AUTORAIS SOBRE O CODIGO  |
|FONTE DESTE PROGRAMA SAO PROPRIEDADE DA TECHWARE SYSTEMS COMERCIO E  |
|SERVICOS LTDA.  NENHUMA OUTRA PARTE TEM QUALQUER DIREITO, TITULO OU  |
|INTERESSE NO REFERIDO CODIGO FONTE. A REPRODUCAO NAO AUTORIZADA DESTE|
|PROGRAMA OU DE QUALQUER PARTE DELE OU DE SUA DOCUMENTACAO, RESULTARA |
|NA IMPOSICAO DE RIGOROSAS PENAS CIVIS E CRIMINAIS E SERA OBJETO DE   |
|ACAO JUDICIAL PROMOVIDA NA MAXIMA EXTENSAO POSSIVEL, NOS TERMOS DA   |
|LEI.                                                                 |
|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|

|                       Documentacao Script                           |

Modulo instalar_esocial_security.sql
Patch  


Objetivo
  Instalacao no Security de objetos da Base de Dados do Rhevolution.

*/

PROMPT 
PROMPT [ Parametrizando execucao do instalador ]
PROMPT

ACCEPT LocalScripts       PROMPT 'Diretorio para execucao scripts : '
ACCEPT LSpool             PROMPT 'Diretorio para geracao dos logs : '

PROMPT 
PROMPT [ Informacoes relativas ao ambiente a ser instalado ]
PROMPT
PROMPT

ACCEPT NomeBD           CHAR PROMPT 'Informe o nome do banco de dados      : '
ACCEPT PropRHevolution  CHAR PROMPT 'Informe o proprietario do RHevolution : '
ACCEPT SenhaRHevolution CHAR PROMPT 'Informe sua senha                     : ' hide


DEFINE DiretorioScript=&LocalScripts;
DEFINE LocalSpool=&LSpool;

spool &LocalSpool\instalar_esocial_security.log
set verify off
set array 1
set serveroutput on size 99999;

PROMPT *********************************************************************
PROMPT * Conectando com o usuario &PropRHevolution
PROMPT *********************************************************************
connect &PropRHevolution/&SenhaRHevolution@&NomeBD

prompt 
 
PROMPT 1.  script:   21678.sec              
@&DiretorioScript\21678.sec

PROMPT 2.  script:   22819.sec              
@&DiretorioScript\22819.sec

PROMPT 3.  script:   22979.sec               
@&DiretorioScript\22979.sec

SET SERVEROUTPUT ON SIZE 999999
EXEC RSL_INSERE_OBJETOS;



PROMPT ***
PROMPT *********** Total de scripts executados = 3 *******************
	
PROMPT *********************************************************************
PROMPT * TERMINO                                                           *
PROMPT * VERIFIQUE LOG DE EXECUCAO                                         *
PROMPT * *******************************************************************
spool 
spool off
disconnect 
set verify on
