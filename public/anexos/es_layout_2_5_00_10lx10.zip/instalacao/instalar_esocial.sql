
/*	
 _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
|RHEVOLUTION                                                          |
|COPYRIGHT � 1996 TECHWARE SYSTEMS                                    |
|---------------------------------------------------------------------|
|AVISO:                                                               |
|ESTE PROGRAMA DE COMPUTADOR E PROTEGIDO PELA LEI DE DIREITO AUTORAL E|
|TRATADOS INTERNACIONAIS E TODOS OS DIREITOS AUTORAIS SOBRE O CODIGO  |
|FONTE DESTE PROGRAMA SAO PROPRIEDADE DA TECHWARE SYSTEMS COMERCIO E  |
|SERVICOS LTDA.  NENHUMA OUTRA PARTE TEM QUALQUER DIREITO, TITULO OU  |
|INTERESSE NO REFERIDO CODIGO FONTE. A REPRODUCAO NAO AUTORIZADA DESTE|
|PROGRAMA OU DE QUALQUER PARTE DELE OU DE SUA DOCUMENTACAO, RESULTARA |
|NA IMPOSICAO DE RIGOROSAS PENAS CIVIS E CRIMINAIS E SERA OBJETO DE   |
|ACAO JUDICIAL PROMOVIDA NA MAXIMA EXTENSAO POSSIVEL, NOS TERMOS DA   |
|LEI.                                                                 |
|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|

|                       Documentacao Script                           |

Modulo instalar_esocial.sql 
 

Objetivo
  Instalar alteracoes na base de dados do Rhevolution, tais como
  criacao ou alteracao de tabelas,constraints de integridade, indices, 
  setups do sistema, procedures e alteracoes no menu de transacoes.
*/

PROMPT 
PROMPT [ Parametrizando execucao do instalador ]
PROMPT

ACCEPT LocalScripts      	PROMPT 'Diretorio para execucao scripts SQL : '
ACCEPT LSpool            	PROMPT 'Diretorio para geracao dos logs : '

PROMPT 
PROMPT [ Informacoes relativas ao ambiente a ser instalado ]
PROMPT
PROMPT

ACCEPT NomeBD                CHAR PROMPT 'Informe o nome do banco de dados       : '
ACCEPT PropRHevolution       CHAR PROMPT 'Informe o proprietario do RHevolution  : '
ACCEPT SenhaRHevolution      CHAR PROMPT 'Informe sua senha                      : ' hide
ACCEPT NomeTablespaceDefault CHAR PROMPT 'Informe o nome da tablespace default   : '
ACCEPT NomeTablespaceIndex   CHAR PROMPT 'Informe o nome da tablespace p/ Index  : '
ACCEPT perfilinstalacao      CHAR PROMPT 'Informe o perfil,em letras mai�sculas, para inclusao transacoes menu : '


DEFINE DiretorioScript=&LocalScripts;
DEFINE LocalSpool=&LSpool;
DEFINE tablespaceRHevolution=&NomeTablespaceDefault
DEFINE tablespaceRHevolutionIndex=&NomeTablespaceIndex
DEFINE perfil=&perfilinstalacao

spool &LocalSpool\instalar_esocial.log
set verify off
set serveroutput on size 99999;

PROMPT *******************************************************************
PROMPT * Conectando com o usuario &PropRHevolution
PROMPT *******************************************************************
connect &PropRHevolution/&SenhaRHevolution@&NomeBD

PROMPT 
 
PROMPT ***********************************************************************
PROMPT  IP 22819
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  22819.tab
@&DiretorioScript\22819.tab

PROMPT 1.2  script:  rhes9002.tg
@&DiretorioScript\rhes9002.tg

PROMPT 1.3  script:  rhfp5146.ger
@&DiretorioScript\rhfp5146.ger

PROMPT 1.4  script:  rhfp5146.vie
@&DiretorioScript\rhfp5146.vie

PROMPT ***********************************************************************
PROMPT  IP 22832
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************

PROMPT 1.1  script:  rhctr001.plb
@&DiretorioScript\rhctr001.plb
 
PROMPT 1.2  script:  22408.tab
@&DiretorioScript\22408.tab

PROMPT 1.3  script:  rhad075.plb
@&DiretorioScript\rhad075.plb

PROMPT ***********************************************************************
PROMPT  IP 22904
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes2240c.tg
@&DiretorioScript\rhes2240c.tg

PROMPT 1.2  script:  rhes2240s.tg
@&DiretorioScript\rhes2240s.tg

PROMPT 1.3  script:  rhes2240u.tg
@&DiretorioScript\rhes2240u.tg

PROMPT ***********************************************************************
PROMPT  IP 22953
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes1270.plb
@&DiretorioScript\rhes1270.plb

PROMPT 1.2  script:  rhes1270p.plb
@&DiretorioScript\rhes1270p.plb

PROMPT ***********************************************************************
PROMPT  IP 22963
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  22963.mod
@&DiretorioScript\22963.mod

PROMPT 1.2  script:  22963.per
@&DiretorioScript\22963.per

PROMPT 1.3  script:  22963.set
@&DiretorioScript\22963.set

PROMPT 1.4  script:  rhes045.plb
@&DiretorioScript\rhes045.plb

PROMPT ***********************************************************************
PROMPT  IP 22970
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes2800t.tg
@&DiretorioScript\rhes2800t.tg

PROMPT ***********************************************************************
PROMPT  IP 21678
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  21678.mod
@&DiretorioScript\21678.mod
 
PROMPT 1.2  script:  21678.per
@&DiretorioScript\21678.per
 
PROMPT 1.3  script:  21678.tab
@&DiretorioScript\21678.tab
 
PROMPT 1.4  script:  21678.set
@&DiretorioScript\21678.set
 
PROMPT 1.5  script:  rhcaprhev.plb
@&DiretorioScript\rhcaprhev.plb
 
PROMPT 1.6  script:  rhset001.tg
@&DiretorioScript\rhset001.tg
 
PROMPT 1.7  script:  rhset001p.idi
@&DiretorioScript\rhset001p.idi
 
PROMPT 1.8  script:  rhset001p.plb
@&DiretorioScript\rhset001p.plb
 
PROMPT 1.9  script:  rhset001p.rot
@&DiretorioScript\rhset001p.rot

PROMPT ***********************************************************************
PROMPT  IP 22979
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhgp011p.plb
@&DiretorioScript\rhgp011p.plb
 
PROMPT 1.2  script:  rhgp010fp.plb
@&DiretorioScript\rhgp010fp.plb
 
PROMPT 1.3  script:  rhgp010fp.rot
@&DiretorioScript\rhgp010fp.rot
 
PROMPT 1.4  script:  rhset002.plb
@&DiretorioScript\rhset002.plb

PROMPT ***********************************************************************
PROMPT  IP 22984
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes2200.plb
@&DiretorioScript\rhes2200.plb

PROMPT ***********************************************************************

PROMPT  IP 23010
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes001t.tg
@&DiretorioScript\rhes001t.tg

PROMPT ***********************************************************************
PROMPT  IP 23020
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes2220.plb
@&DiretorioScript\rhes2220.plb

PROMPT 1.2  script:  rhes2220t.tg
@&DiretorioScript\rhes2220t.tg

PROMPT ***********************************************************************
PROMPT  IP 23029
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  23029.sql
@&DiretorioScript\23029.sql

PROMPT 1.2  script:  23029.tab
@&DiretorioScript\23029.tab

PROMPT 1.3  script:  rhes037p.plb
@&DiretorioScript\rhes037p.plb

PROMPT 1.4  script: rhes037p.rot
@&DiretorioScript\rhes037p.rot

PROMPT 1.5  script:  rhes1200.plb
@&DiretorioScript\rhes1200.plb

PROMPT 1.6  script:  rhes1250.plb
@&DiretorioScript\rhes1250.plb

PROMPT 1.7  script:  rhes1250p.plb
@&DiretorioScript\rhes1250p.plb

PROMPT 1.8  script:  rhes1250p.rot
@&DiretorioScript\rhes1250p.rot

PROMPT 1.9  script:  rhes1400.plb
@&DiretorioScript\rhes1400.plb

PROMPT 1.10  script:  rhes2200t.tg
@&DiretorioScript\rhes2200t.tg

PROMPT 1.11  script:  rhes2399.plb
@&DiretorioScript\rhes2399.plb

PROMPT 1.12  script:  rhes2600.plb
@&DiretorioScript\rhes2600.plb

PROMPT 1.13  script:  rhes2600t.tg
@&DiretorioScript\rhes2600t.tg

PROMPT 1.14  script:  rhes2620.plb
@&DiretorioScript\rhes2620.plb

PROMPT 1.15  script:  rhes2800.plb
@&DiretorioScript\rhes2800.plb

PROMPT 1.16  script:  rhgp010p.plb
@&DiretorioScript\rhgp010p.plb

PROMPT 1.17  script:  rhgp010p.rot
@&DiretorioScript\rhgp010p.rot

PROMPT ***********************************************************************
PROMPT  IP 23050
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes2320x.tg
@&DiretorioScript\rhes2320x.tg

PROMPT ***********************************************************************
PROMPT  IP 23055
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhfp5102.ger
@&DiretorioScript\rhfp5102.ger

PROMPT ***********************************************************************
PROMPT  IP 23084
PROMPT ***********************************************************************

PROMPT ***********************************************************************
PROMPT 1. SQL
PROMPT ***********************************************************************
 
PROMPT 1.1  script:  rhes2200m.tg
@&DiretorioScript\rhes2200m.tg

PROMPT ***
PROMPT *********** Total de scripts executados = 54 *******************
 

PROMPT ====================================================================
PROMPT = Validando objetos invalidados durante a instalacao do Patch 
PROMPT ====================================================================
SET HEAD OFF
SET PAGES 0
SET TERM OFF
SET FEED OFF
SET LINES 300

SPOOL &LocalSpool\tmpValidaObjeto.do




select objetos.processo1
 from 
(select 'PROMPT Compilando  ----------------------------------------'||object_name||';' processo1 ,object_name processo2 ,1 processo3
from  user_objects a
where status      = 'INVALID'
union
select 'alter '||DECODE( object_type,'PACKAGE BODY','PACKAGE', object_type ) || ' ' || object_name||' compile ;' processo1 ,object_name processo2 ,2 processo3
from  user_objects a
where status      = 'INVALID'
union
select  'show err;' processo1 ,object_name processo2 ,3 processo3
from  user_objects a
where status      = 'INVALID'
union
select  'PROMPT Fim compila��o  ' || object_name || '------------------------;' processo1 ,object_name processo2 ,4 processo3
from  user_objects a
where status      = 'INVALID') objetos
order by objetos.processo2,objetos.processo3
/


SPOOL OFF
SET HEAD ON
SET TERM ON
SET FEED ON
SET LINES 80
SET PAGES 14

PROMPT =====================================================================
PROMPT = Validando objetos invalidos                                       =
PROMPT =====================================================================


SPOOL &LocalSpool\tmpValidaObjeto.log



@&LocalSpool\tmpValidaObjeto.do

PROMPT =====================================================================
PROMPT = Objetos com error                                                 =

set serveroutput on size 999999;

declare

  v_objeto varchar2(4000);
  cursor c is
    select f.name nome_objeto, f.type
      from user_errors f
     where f.name in
           (select x.object_name
              from all_objects x
             where x.owner in
                   (select z.usuario_default from parametros_rhevolution z))
     group by f.name, f.type;

  cursor erro is
    select ' - ' || text texto_erro
      from user_errors f
     where f.name in
           (select x.object_name
              from all_objects x
             where x.owner in
                   (select z.usuario_default from parametros_rhevolution z))
       and name = v_objeto
     order by f.sequence;

begin
  for c1 in c loop
    exit when c%notfound;
    v_objeto := c1.nome_objeto;
    dbms_output.put_line('Objeto Invalido - ' || c1.type || ' - ' ||
                         v_objeto);
    for erro1 in erro loop
      exit when erro%notfound;
      dbms_output.put_line('                             '||erro1.texto_erro);
    
    end loop;
  
  end loop;
end;
/

 
prompt 
PROMPT *******************************************************************
PROMPT * TERMINO                                                         *
PROMPT * VERIFIQUE LOG DE EXECUCAO                                       *
PROMPT *******************************************************************
spool 
spool off
disconnect 
set verify on

