Prompt Script 23029.sql

Prompt Atualizando ES_LISTA_VALORES_DET ESLVAL_LISTA_VALORES_COD= 'indMV' eslvd_valor = 1
update ES_LISTA_VALORES_DET d
set d.eslvd_descricao = '1 - O declarante aplica a al�quota de desconto do segurado sobre a remunera��o por ele informada (o percentual da al�quota ser� obtido considerando a remunera��o total do trabalhador);'
where D.ESLVAL_LISTA_VALORES_COD= 'indMV' 
and   d.eslvd_valor = 1;

Prompt Atualizando ES_LISTA_VALORES_DET ESLVAL_LISTA_VALORES_COD= 'indMV' eslvd_valor = 2
update ES_LISTA_VALORES_DET d
set d.eslvd_descricao = '2 - O declarante aplica a al�quota de desconto do segurado sobre a diferen�a entre o limite m�ximo do sal�rio de contribui��o e a remunera��o de outra(s) empresa(s) para as quais o trabalhador informou que houve o desconto;'
where D.ESLVAL_LISTA_VALORES_COD= 'indMV' 
and   d.eslvd_valor = 2;

Prompt Atualizando ES_LISTA_VALORES_DET ESLVAL_LISTA_VALORES_COD= 'indMV' eslvd_valor = 3
update ES_LISTA_VALORES_DET d
set d.eslvd_descricao = '3 - O declarante n�o realiza desconto do segurado, uma vez que houve desconto sobre o limite m�ximo de sal�rio de contribui��o em outra(s) empresa(s).'
where D.ESLVAL_LISTA_VALORES_COD= 'indMV' 
and   d.eslvd_valor = 3;

Prompt Incluindo es_lista_valores_det eslval_lista_valores_cod = 'tpInsc' eslvd_valor=5
insert into es_lista_valores_det
(eslval_lista_valores_cod,eslvd_valor,eslvd_descricao,eslvd_data_registro,eslvd_usuario_registro) values
('tpInsc',5,'CGC',sysdate,user);

Prompt Incluindo es_lista_valores_det eslval_lista_valores_cod = 'MOTIVO_DESLIGAMENTO' eslvd_valor=35
insert into es_lista_valores_det
(eslval_lista_valores_cod,eslvd_valor,eslvd_descricao,eslvd_data_registro,eslvd_usuario_registro) values
('MOTIVO_DESLIGAMENTO',35,'Extin��o do contrato de trabalho intermitente',sysdate,user);

Prompt Incluindo es_lista_valores_det eslval_lista_valores_cod = 'MOTIVO_DESLIGAMENTO' eslvd_valor=36
insert into es_lista_valores_det
(eslval_lista_valores_cod,eslvd_valor,eslvd_descricao,eslvd_data_registro,eslvd_usuario_registro) values
('MOTIVO_DESLIGAMENTO',36,'Mudan�a de CPF',sysdate,user);

Prompt Incluindo es_lista_valores_det eslval_lista_valores_cod = 'MOTIVO_DESLIGAMENTO' eslvd_valor=15
update ES_LISTA_VALORES_DET d
set d.eslvd_descricao = 'Rescis�o do contrato de aprendizagem por desempenho insuficiente, inadapta��o ou aus�ncia injustificada do aprendiz � escola que implique perda do ano letivo.'
where D.ESLVAL_LISTA_VALORES_COD= 'MOTIVO_DESLIGAMENTO' 
and   d.eslvd_valor = 15;

Prompt Atualizando vers�o do layout para 02_05_00 tabela ES_LAYOUT_VERSOES 
UPDATE ES_LAYOUT_VERSOES V SET V.ESLV_DATA_INICIO = TO_DATE('21/01/2019','dd/mm/yyyy'), V.ESLV_VERSAO_LAYOUT = '02_05_00', v.eslv_usuario_alteracao=sysdate;

commit;
