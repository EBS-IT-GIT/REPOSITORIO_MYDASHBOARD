SET DEFINE OFF
--
SET VERIFY OFF
--
WHENEVER SQLERROR CONTINUE
--
WHENEVER OSERROR EXIT FAILURE ROLLBACK
--
PROMPT Creating PACKAGE XXCUST_AP0003_PKGA...
--
CREATE OR REPLACE PACKAGE XXCUST_AP0003_PKGA AUTHID CURRENT_USER IS
--------------------------------------------------------------------------------
  --
  -- $Header.............: XXCUST_AP0003_PKGA.sql
  --
  -- Copyright (c) 2018, by Stone Inc., All Rights Reserved
  --
  -- Author..............: pontes, paulo, Brazil IT
  -- Component Id........: XXAP0003
  -- Script Location.....: $XXBK_TOP/sql
  -- Description.........:
  -- Package Usage.......: This package will be called from Concurrent manager
  -- Name                  Type         Purpose
  -- --------------------  -----------  ---------------------------------------------------------------------------------------------
  --
  -- Notes...............: Need to login into the APPS schema
  -- History:
  -- Name          Date                   Version     Description
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------
  -- pontes, paulo    24-09-2018              1.0      Original Creation
  -------------------------------------------------------------------------------------------------------------------
 --
 CURSOR c_inv (pc_invoice_id NUMBER)IS
        SELECT DISTINCT aia.invoice_id, aid.dist_code_combination_id dist_ccid, aia.invoice_num
          FROM ap_invoices_all              aia
             , ap_invoice_lines_all         ail
             , ap_invoice_distributions_all aid
         WHERE aia.creation_date > SYSDATE - 2
           AND aia.attribute5        IS NULL
           AND aia.cancelled_date    IS NULL
           AND aia.invoice_type_lookup_code = 'INTEREST'
           AND aia.invoice_id = NVL(pc_invoice_id,aia.invoice_id)
           AND aia.invoice_id = ail.invoice_id
           AND ail.invoice_id = aid.invoice_id
           AND ail.line_number = aid.invoice_line_number
     ORDER BY aia.invoice_id;

  TYPE t_inv IS TABLE OF c_inv%ROWTYPE;

  ap_inv   t_inv;

 CURSOR c_inv_ri (pc_invoice_id NUMBER ) IS
                SELECT DISTINCT 
                       aia.set_of_books_id
                     , aida.invoice_distribution_id
                     , aia.invoice_num
                     , aia.invoice_id
                     , aia.invoice_amount  vlr_juros
                     , aia1.invoice_amount vlr_NFF
                     , aida.amount         vlr_dist_AP
                     , (ROUND((aida.amount/aia1.invoice_amount),4)/**100*/) perc
                     , ROUND((ROUND((aida.amount/aia1.invoice_amount),4)*aia.invoice_amount),2)   vlr_final_juros
                     , aia.description
                     , aia1.reference_key1
                     , aida.org_id
                     , aida.line_type_lookup_code
                     , aida.period_name
                     , aila.line_number
                     , aida.distribution_line_number
                     --, cfd.code_combination_id
                     , aida.dist_code_combination_id dist_ccid
                     , cfd.code_combination_id   db_ccid
                     , cfd.functional_dr   functional_dr
                     , aida.amount
                     , aida.invoice_line_number
                     , aida.created_by
                     , aida.accts_pay_code_combination_id
                     , (select MAX(accounting_event_id)
                          from ap_invoice_payments_all
                          where invoice_id = aia1.invoice_id
                            and reversal_flag = 'N') accounting_event_id
                     , aia1.invoice_id  invoice_id_orig
                  FROM ap_invoices_all              aia
                     , ap_invoices_all              aia1
                     , ap_invoice_lines_all         aila
                     , ap_invoice_distributions_all aida
                     , cll_f189_invoices            cfi
                     , cll_f189_invoice_lines       cfil
                     , cll_f189_distributions       cfd
                     , ap_invoice_relationships     air
                 WHERE 1 = 1
                   AND aia.invoice_type_lookup_code IN ('INTEREST')
                   AND aia1.invoice_id       = aila.invoice_id
                   AND aila.invoice_id       = aida.invoice_id
                   AND aila.line_number      = aida.invoice_line_number
                   AND aia1.reference_key1   = cfi.invoice_id
                   AND cfi.invoice_id        = cfil.invoice_id
                   AND cfi.organization_id   = cfil.organization_id
                   AND cfil.invoice_line_id  = cfd.invoice_line_id
                   AND cfil.organization_id  = cfd.organization_id
                   AND aida.po_distribution_id = cfd.po_distribution_id
                   AND aia.invoice_id        = air.related_invoice_id
                   AND aia1.invoice_id       = air.original_invoice_id
                   AND aia.cancelled_date    IS NULL
                   AND aia.attribute5        IS NULL
                   AND cfd.REFERENCE         = 'ITEM'
                   AND aila.amount > 0
                   AND aia.invoice_id        = pc_invoice_id
                   ORDER BY aia.invoice_id
                          , aila.line_number
                          , aida.distribution_line_number;

  --
  CURSOR c_inv_ap (pc_invoice_id NUMBER ) IS
-- SEM RI
                SELECT DISTINCT 
                       aia.set_of_books_id
                     , aida.invoice_distribution_id
                     , aia.invoice_num
                     , aia.invoice_id
                     , aia.invoice_amount  vlr_juros
                     , aia1.invoice_amount vlr_NFF
                     , aida.amount         vlr_dist_AP
                     , (ROUND((aida.amount/aia1.invoice_amount),4)/**100*/) perc
                     , ROUND((ROUND((aida.amount/aia1.invoice_amount),4)*aia.invoice_amount),2)   vlr_final_juros
                     , aia.description
                     , aia1.reference_key1
                     , aida.org_id
                     , aida.line_type_lookup_code
                     , aida.period_name
                     , aila.line_number
                     , aida.distribution_line_number
                     , aida.dist_code_combination_id dist_ccid
                     , NULL   db_ccid
                     , NULL   functional_dr
                     , aida.amount
                     , aida.invoice_line_number
                     , aida.created_by
                     , aida.accts_pay_code_combination_id
                     , (select MAX(accounting_event_id)
                          from ap_invoice_payments_all
                          where invoice_id = aia1.invoice_id
                            and reversal_flag = 'N') accounting_event_id
                     , aia1.invoice_id  invoice_id_orig
  FROM ap_invoices_all              aia
     , ap_invoice_relationships     air
     , ap_invoices_all              aia1
     , ap_invoice_lines_all         aila
     , ap_invoice_distributions_all aida
 WHERE 1 = 1
   AND aia.invoice_type_lookup_code IN ('INTEREST')
   AND aia.invoice_id        = air.related_invoice_id
   AND aia1.invoice_id       = air.original_invoice_id
   AND aia1.invoice_id       = aila.invoice_id
   AND aila.invoice_id       = aida.invoice_id
   AND aila.line_number      = aida.invoice_line_number
   AND aia.cancelled_date    IS NULL
   AND aia.attribute5        IS NULL
   AND aida.line_type_lookup_code = 'ITEM'
   AND aila.amount > 0
   AND aia.invoice_id        = pc_invoice_id
   ORDER BY aia.invoice_id
          , aila.line_number
          , aida.distribution_line_number;

  TYPE t_inv_ap IS TABLE OF c_inv_ap%ROWTYPE;

  ap_rec   t_inv_ap;

  x_api_version       NUMBER := 1.0;
  x_init_msg_list     VARCHAR2(100) := fnd_api.g_true;
  x_application_id    INTEGER := 707;
  x_ledger_id         INTEGER := 2022;
  x_gl_date           DATE := SYSDATE;
  x_description       VARCHAR2(100) := 'Gain/Loss on sale';
  x_je_category_name  VARCHAR2(100) := 'Other';
  x_balance_type_code VARCHAR2(100) := 'A';
  xx_return_status    VARCHAR2(100);
  xx_msg_count        NUMBER;
  xx_msg_data         VARCHAR2(2000);
  xx_ae_header_id     INTEGER;
  xx_event_id         INTEGER;
  --line
  x_ae_header_id               INTEGER;
  x_displayed_line_number_1    INTEGER := 1;
  x_displayed_line_number_2    INTEGER := 2;
  x_code_combination_id_1      INTEGER := 7276364;
  x_code_combination_id_2      INTEGER := 7276374;
  x_gl_transfer_mode           VARCHAR2(100) := 'S';
  x_accounting_class_code_rev  VARCHAR2(100) := 'COST_OF_GOODS_SOLD';
  x_accounting_class_code_gain VARCHAR2(100) := 'GAIN';
  x_entered_dr                 NUMBER := 699;
  x_entered_cr                 NUMBER := 699;
  xx_ae_line_num               INTEGER;
  x_completion_option          VARCHAR2(100) := 'P';
  xx_completion_retcode        VARCHAR2(100);

  -- Public function and procedure declarations
  FUNCTION check_amount_f(p_invoice_id IN NUMBER
                        , p_invoice_line_number IN NUMBER) RETURN NUMBER;
  --
  FUNCTION get_ccid_f (p_ccid_in  IN  NUMBER
                     , p_segment4 IN VARCHAR2
                     , p_ccid_out OUT NUMBER) RETURN BOOLEAN;
  --
  FUNCTION get_ccid_oneline_f (p_invoice_id IN  NUMBER
                             , p_origem     IN VARCHAR2) RETURN NUMBER;
  --
  FUNCTION check_lines_ccid_f (p_invoice_id IN  NUMBER
                             , p_origem     OUT VARCHAR2) RETURN NUMBER;
  --
  --FUNCTION split_sla_interest_f (p_invoice_id IN NUMBER) RETURN BOOLEAN;
  --
  PROCEDURE split_ap_interest_f (p_errbuf     OUT VARCHAR2
                               , p_retcode    OUT VARCHAR2
                               , p_invoice_id IN NUMBER
                               , p_dist_ccid  IN NUMBER
                               , p_origem     IN VARCHAR2);
  --
END XXCUST_AP0003_PKGA;
/
--
SHOW ERRORS
--
PROMPT Package XXCUST_AP0003_PKGA created
--
PROMPT Creating Package Body XXCUST_AP0003_PKGA...
--
CREATE OR REPLACE PACKAGE BODY XXCUST_AP0003_PKGA IS
--------------------------------------------------------------------------------
  --
  -- $Header.............: XXCUST_AP0003_PKGA.sql
  --
  -- Copyright (c) 2018, by Stone Inc., All Rights Reserved
  --
  -- Author..............: pontes, paulo, Brazil IT
  -- Component Id........: XXAP0003
  -- Script Location.....: $XXBK_TOP/sql
  -- Description.........:
  -- Package Usage.......: This package will be called from Concurrent manager
  -- Name                  Type         Purpose
  -- --------------------  -----------  ---------------------------------------------------------------------------------------------
  --
  -- Notes...............: Need to login into the APPS schema
  -- History:
  -- Name          Date                   Version     Description
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------
  -- pontes, paulo    24-09-2018              1.0      Original Creation
  -------------------------------------------------------------------------------------------------------------------
  --
  FUNCTION get_qte_ditr_lines (p_invoice_id   IN NUMBER
                             , p_invoice_line IN NUMBER) RETURN NUMBER IS
    --
    l_qte_distr_line  NUMBER := 0;
    --
  BEGIN
    --
    SELECT MAX(aid.distribution_line_number)
      INTO l_qte_distr_line
      FROM ap_invoice_distributions_all aid
     WHERE aid.invoice_id          = p_invoice_id
       AND aid.invoice_line_number = p_invoice_line;
    --
    RETURN(l_qte_distr_line);
    --
  END get_qte_ditr_lines;

  FUNCTION check_amount_f(p_invoice_id IN NUMBER
                        , p_invoice_line_number IN NUMBER) RETURN NUMBER IS
  --
  CURSOR c_inv IS
        SELECT line_number
              ,SUM(  ail.amount)  amount_lin
          FROM ap_invoices_all aia
             , ap_invoice_lines_all ail
         WHERE 1 = 1
           AND aia.invoice_type_lookup_code IN ('INTEREST')
           AND aia.invoice_id = ail.invoice_id
           AND aia.invoice_id = p_invoice_id
         GROUP BY line_number;
  --
  l_amount_dif  NUMBER;
  l_amount_lin  NUMBER;
  l_amount_inv  NUMBER;
  --
  BEGIN
    --
    BEGIN
      --
      FOR r_inv IN c_inv LOOP
        --
        -- Check Amount in Distribution
        --
        SELECT SUM(TRUNC(aid.AMOUNT,2)) AMOUNT
          INTO l_amount_lin
          FROM ap_invoice_distributions_all aid
         WHERE 1 = 1
           AND aid.invoice_id          = p_invoice_id
           AND aid.invoice_line_number = r_inv.line_number;
        --
        --
        l_amount_dif := r_inv.amount_lin - l_amount_lin;
        --
        IF l_amount_dif != 0 THEN
          --
          UPDATE ap_invoice_distributions_all
             SET amount = amount + l_amount_dif
           WHERE 1 = 1
             AND invoice_id          = p_invoice_id
             AND invoice_distribution_id =  (SELECT MAX(invoice_distribution_id)
                                               FROM ap_invoice_distributions_all
                                              WHERE invoice_id          = p_invoice_id
                                                AND invoice_line_number = r_inv.line_number);
          --
        END IF;

      END LOOP;
      --
      -- Check Amount in Lines
      --
      SELECT SUM(  ail.amount)                amount_lin
            ,SUM(DISTINCT aia.invoice_amount) amount_inv
        INTO l_amount_lin
            ,l_amount_inv
        FROM ap_invoices_all aia
           , ap_invoice_lines_all ail
       WHERE 1 = 1
         AND aia.invoice_type_lookup_code IN ('INTEREST')
         AND aia.invoice_id = ail.invoice_id
         AND aia.invoice_id = p_invoice_id;
      --
      l_amount_dif := l_amount_inv - l_amount_lin;
      --
      IF l_amount_dif != 0 THEN
        --
        UPDATE ap_invoice_lines_all
           SET amount = amount + l_amount_dif
         WHERE invoice_id  = p_invoice_id
           AND line_number = (SELECT MAX(line_number)
                               FROM ap_invoice_lines_all
                              WHERE invoice_id = p_invoice_id);
        --
      END IF;
      --
      RETURN(l_amount_dif);
    END;
    --
  END check_amount_f;
  --
  --
  PROCEDURE Insert_Row  (
            p_Rowid                        IN OUT NOCOPY VARCHAR2,
            p_Invoice_Id                          NUMBER,
            p_Invoice_Line_Number                 NUMBER,
            p_Distribution_Class                  VARCHAR2,
            p_Invoice_Distribution_Id      IN OUT NOCOPY NUMBER,
            p_Dist_Code_Combination_Id            NUMBER,
            p_Last_Update_Date                    DATE,
            p_Last_Updated_By                     NUMBER,
            p_Accounting_Date                     DATE,
            p_Period_Name                         VARCHAR2,
            p_Set_Of_Books_Id                     NUMBER,
            p_Amount                              NUMBER,
            p_Description                         VARCHAR2,
            p_Type_1099                           VARCHAR2,
            p_Posted_Flag                         VARCHAR2,
            p_Batch_Id                            NUMBER,
            p_Quantity_Invoiced                   NUMBER,
            p_Unit_Price                          NUMBER,
            p_Match_Status_Flag                   VARCHAR2,
            p_Attribute_Category                  VARCHAR2,
            p_Attribute1                          VARCHAR2,
            p_Attribute2                          VARCHAR2,
            p_Attribute3                          VARCHAR2,
            p_Attribute4                          VARCHAR2,
            p_Attribute5                          VARCHAR2,
            p_Prepay_Amount_Remaining             NUMBER,
            p_Assets_Addition_Flag                VARCHAR2,
            p_Assets_Tracking_Flag                VARCHAR2,
            p_Distribution_Line_Number            NUMBER,
            p_Line_Type_Lookup_Code               VARCHAR2,
            p_Po_Distribution_Id                  NUMBER,
            p_Base_Amount                         NUMBER,
            p_Pa_Addition_Flag                    VARCHAR2,
            p_Posted_Amount                       NUMBER,
            p_Posted_Base_Amount                  NUMBER,
            p_Encumbered_Flag                     VARCHAR2,
            p_Accrual_Posted_Flag                 VARCHAR2,
            p_Cash_Posted_Flag                    VARCHAR2,
            p_Last_Update_Login                   NUMBER,
            p_Creation_Date                       DATE,
            p_Created_By                          NUMBER,
            p_Stat_Amount                         NUMBER,
            p_Attribute11                         VARCHAR2,
            p_Attribute12                         VARCHAR2,
            p_Attribute13                         VARCHAR2,
            p_Attribute14                         VARCHAR2,
            p_Attribute6                          VARCHAR2,
            p_Attribute7                          VARCHAR2,
            p_Attribute8                          VARCHAR2,
            p_Attribute9                          VARCHAR2,
            p_Attribute10                         VARCHAR2,
            p_Attribute15                         VARCHAR2,
            p_Accts_Pay_Code_Comb_Id              NUMBER,
            p_Reversal_Flag                       VARCHAR2,
            p_Parent_Invoice_Id                   NUMBER,
            p_Income_Tax_Region                   VARCHAR2,
            p_Final_Match_Flag                    VARCHAR2,
         -- Removed for bug 4277744
         -- p_Ussgl_Transaction_Code              VARCHAR2,
         -- p_Ussgl_Trx_Code_Context              VARCHAR2,
            p_Expenditure_Item_Date               DATE,
            p_Expenditure_Organization_Id         NUMBER,
            p_Expenditure_Type                    VARCHAR2,
            p_Pa_Quantity                         NUMBER,
            p_Project_Id                          NUMBER,
            p_Task_Id                             NUMBER,
            p_Quantity_Variance                   NUMBER,
            p_Base_Quantity_Variance              NUMBER,
            p_Packet_Id                           NUMBER,
            p_Awt_Flag                            VARCHAR2,
            p_Awt_Group_Id                        NUMBER,
            p_Pay_Awt_Group_Id                    NUMBER,--bug6639866
            p_Awt_Tax_Rate_Id                     NUMBER,
            p_Awt_Gross_Amount                    NUMBER,
            p_Reference_1                         VARCHAR2,
            p_Reference_2                         VARCHAR2,
            p_Org_Id                              NUMBER,
            p_Other_Invoice_Id                    NUMBER,
            p_Awt_Invoice_Id                      NUMBER,
            p_Awt_Origin_Group_Id                 NUMBER,
            p_Program_Application_Id              NUMBER,
            p_Program_Id                          NUMBER,
            p_Program_Update_Date                 DATE,
            p_Request_Id                          NUMBER,
            p_Tax_Recoverable_Flag                VARCHAR2,
            p_Award_Id                            NUMBER,
            p_Start_Expense_Date                  DATE,
            p_Merchant_Document_Number            VARCHAR2,
            p_Merchant_Name                       VARCHAR2,
            p_Merchant_Tax_Reg_Number             VARCHAR2,
            p_Merchant_Taxpayer_Id                VARCHAR2,
            p_Country_Of_Supply                   VARCHAR2,
            p_Merchant_Reference                  VARCHAR2,
            p_parent_reversal_id                  NUMBER,
            p_rcv_transaction_id                  NUMBER,
            p_matched_uom_lookup_code             VARCHAR2,
            p_global_attribute_category           VARCHAR2 DEFAULT NULL,
            p_global_attribute1                   VARCHAR2 DEFAULT NULL,
            p_global_attribute2                   VARCHAR2 DEFAULT NULL,
            p_global_attribute3                   VARCHAR2 DEFAULT NULL,
            p_global_attribute4                   VARCHAR2 DEFAULT NULL,
            p_global_attribute5                   VARCHAR2 DEFAULT NULL,
            p_global_attribute6                   VARCHAR2 DEFAULT NULL,
            p_global_attribute7                   VARCHAR2 DEFAULT NULL,
            p_global_attribute8                   VARCHAR2 DEFAULT NULL,
            p_global_attribute9                   VARCHAR2 DEFAULT NULL,
            p_global_attribute10                  VARCHAR2 DEFAULT NULL,
            p_global_attribute11                  VARCHAR2 DEFAULT NULL,
            p_global_attribute12                  VARCHAR2 DEFAULT NULL,
            p_global_attribute13                  VARCHAR2 DEFAULT NULL,
            p_global_attribute14                  VARCHAR2 DEFAULT NULL,
            p_global_attribute15                  VARCHAR2 DEFAULT NULL,
            p_global_attribute16                  VARCHAR2 DEFAULT NULL,
            p_global_attribute17                  VARCHAR2 DEFAULT NULL,
            p_global_attribute18                  VARCHAR2 DEFAULT NULL,
            p_global_attribute19                  VARCHAR2 DEFAULT NULL,
            p_global_attribute20                  VARCHAR2 DEFAULT NULL,
            p_Calling_Sequence                    VARCHAR2,
            p_Receipt_Verified_Flag               VARCHAR2 DEFAULT NULL,
            p_Receipt_Required_flag               VARCHAR2 DEFAULT NULL,
            p_Receipt_Missing_flag                VARCHAR2 DEFAULT NULL,
            p_Justification                       VARCHAR2 DEFAULT NULL,
            p_Expense_Group                       VARCHAR2 DEFAULT NULL,
            p_End_Expense_Date                    DATE DEFAULT NULL,
            p_Receipt_Currency_Code               VARCHAR2 DEFAULT NULL,
            p_Receipt_Conversion_Rate             VARCHAR2 DEFAULT NULL,
            p_Receipt_Currency_Amount             NUMBER DEFAULT NULL,
            p_Daily_Amount                        NUMBER DEFAULT NULL,
            p_Web_Parameter_Id                    NUMBER DEFAULT NULL,
            p_Adjustment_Reason                   VARCHAR2 DEFAULT NULL,
            p_Credit_Card_Trx_Id                  NUMBER DEFAULT NULL,
            p_Company_Prepaid_Invoice_Id          NUMBER DEFAULT NULL,
            -- Invoice Lines Project Stage 1
            p_Rounding_Amt                        NUMBER DEFAULT NULL,
            p_Charge_Applicable_To_Dist_ID        NUMBER DEFAULT NULL,
            p_Corrected_Invoice_Dist_ID           NUMBER DEFAULT NULL,
            p_Related_ID                          NUMBER DEFAULT NULL,
            p_Asset_Book_Type_Code                VARCHAR2 DEFAULT NULL,
            p_Asset_Category_ID                   NUMBER DEFAULT NULL,
      --ETAX: Invwkb
      p_Intended_Use                        VARCHAR2 DEFAULT NULL,
      --Freight and Special Charges
      p_rcv_charge_addition_flag    VARCHAR2 DEFAULT 'N',
     p_accts_pay_code_combination            NUMBER DEFAULT NULL,       --TRAMOS
     p_accounting_event_id                      NUMBER DEFAULT NULL --TRAMOS
     )   IS

    current_calling_sequence VARCHAR2(2000);
    debug_info               VARCHAR2(100);
    l_dist_match_type        VARCHAR2(25);


  BEGIN

    -- Update the calling sequence

    current_calling_sequence := 'AP_AID_TABLE_HANDLER_PKG.Insert_Row<-'
                                ||p_Calling_Sequence;


    -- Figure out NOCOPY the dist_match_type (not passed from invoice w/b)

    /*IF (p_rcv_transaction_id IS NOT NULL AND                       --TRAMOS BEGIN
        p_po_distribution_id IS NOT NULL) THEN
          l_dist_match_type := 'ITEM_TO_RECEIPT';
    ELSIF (p_rcv_transaction_id IS NOT NULL AND
           p_po_distribution_id IS NULL)     THEN
          l_dist_match_type := 'OTHER_TO_RECEIPT';
    ELSIF (p_rcv_transaction_id IS NULL AND
          p_po_distribution_id IS NOT NULL) THEN
          l_dist_match_type := 'ITEM_TO_PO';
    ELSE
          --l_dist_match_type := NULL;
          l_dist_match_type := 'NOT_MATCHED'; /* Bug 17309867 */

    --END IF;
    l_dist_match_type   :=  'PERMANENT';                             --TRAMOS END

    INSERT INTO AP_INVOICE_DISTRIBUTIONS_ALL(
                invoice_id,
                -- Invoice Lines Project Stage 1
                invoice_line_number,
                distribution_class,
                dist_code_combination_id,
                invoice_distribution_id,
                last_update_date,
                last_updated_by,
                accounting_date,
                period_name,
                set_of_books_id,
                amount,
                description,
                type_1099,
                posted_flag,
                batch_id,
                quantity_invoiced,
                unit_price,
                match_status_flag,
                attribute_category,
                attribute1,
                attribute2,
                attribute3,
                attribute4,
                attribute5,
                prepay_amount_remaining,
                assets_addition_flag,
                assets_tracking_flag,
                distribution_line_number,
                line_type_lookup_code,
                po_distribution_id,
                base_amount,
                pa_addition_flag,
                posted_amount,
                posted_base_amount,
                encumbered_flag,
                accrual_posted_flag,
                cash_posted_flag,
                last_update_login,
                creation_date,
                created_by,
                stat_amount,
                attribute11,
                attribute12,
                attribute13,
                attribute14,
                attribute6,
                attribute7,
                attribute8,
                attribute9,
                attribute10,
                attribute15,
                accts_pay_code_combination_id,
                reversal_flag,
                parent_invoice_id,
                income_tax_region,
                final_match_flag,
             -- Removed for bug 4277744
             -- ussgl_transaction_code,
             -- ussgl_trx_code_context,
                expenditure_item_date,
                expenditure_organization_id,
                expenditure_type,
                pa_quantity,
                project_id,
                task_id,
                quantity_variance,
                base_quantity_variance,
                packet_id,
                awt_flag,
                awt_group_id,
                pay_awt_group_id,--bug6639866
                awt_tax_rate_id,
                awt_gross_amount,
                reference_1,
                reference_2,
                other_invoice_id,
                awt_invoice_id,
                awt_origin_group_id,
                program_application_id,
                program_id,
                program_update_date,
                request_id,
                tax_recoverable_flag,
                award_id,
                start_expense_date,
                merchant_document_number,
                merchant_name,
                merchant_tax_reg_number,
                merchant_taxpayer_id,
                country_of_supply,
                merchant_reference,
                parent_reversal_id,
                rcv_transaction_id,
                dist_match_type,
                matched_uom_lookup_code,
                global_attribute_category,
                global_attribute1,
                global_attribute2,
                global_attribute3,
                global_attribute4,
                global_attribute5,
                global_attribute6,
                global_attribute7,
                global_attribute8,
                global_attribute9,
                global_attribute10,
                global_attribute11,
                global_attribute12,
                global_attribute13,
                global_attribute14,
                global_attribute15,
                global_attribute16,
                global_attribute17,
                global_attribute18,
                global_attribute19,
                global_attribute20,
                receipt_verified_flag,
                receipt_required_flag,
                receipt_missing_flag,
                justification,
                expense_Group,
                end_Expense_Date,
                receipt_Currency_Code,
                receipt_Conversion_Rate,
                receipt_Currency_Amount,
                daily_Amount,
                web_Parameter_Id,
                adjustment_Reason,
                credit_Card_Trx_Id,
                company_Prepaid_Invoice_Id,
                org_id, --MOAC project
                -- Invoice Lines Project Stage 1
                rounding_amt,
                charge_applicable_to_dist_id,
                corrected_invoice_dist_id,
                related_id,
                asset_book_type_code,
                asset_category_id,
          --ETAX: Invwkb
          intended_use,
          --Freight and Special Charges
          rcv_charge_addition_flag,
          inventory_transfer_status,  /*Bug#11067286 */
           accounting_event_id         --TRAMOS
               ) VALUES (
                p_Invoice_Id,
                -- Invoice Lines Project Stage 1
                p_Invoice_Line_Number,
                p_Distribution_Class,
                p_Dist_Code_Combination_Id,
                p_Invoice_Distribution_Id,
                --add for new column 'Invoice_Distribution_Id'
                p_Last_Update_Date,
                p_Last_Updated_By,
                p_Accounting_Date,
                p_Period_Name,
                p_Set_Of_Books_Id,
                p_Amount,
                p_Description,
                p_Type_1099,
                p_Posted_Flag,
                p_Batch_Id,
                p_Quantity_Invoiced,
                p_Unit_Price,
                p_Match_Status_Flag,
                p_Attribute_Category,
                p_Attribute1,
                p_Attribute2,
                p_Attribute3,
                p_Attribute4,
                p_Attribute5,
                p_Prepay_Amount_Remaining,
                p_Assets_Addition_Flag,
                p_Assets_Tracking_Flag,
                p_Distribution_Line_Number,
                p_Line_Type_Lookup_Code,
                p_Po_Distribution_Id,
                p_Base_Amount,
                p_Pa_Addition_Flag,
                p_Posted_Amount,
                p_Posted_Base_Amount,
                p_Encumbered_Flag,
                p_Accrual_Posted_Flag,
                p_Cash_Posted_Flag,
                p_Last_Update_Login,
                p_Creation_Date,
                p_Created_By,
                p_Stat_Amount,
                p_Attribute11,
                p_Attribute12,
                p_Attribute13,
                p_Attribute14,
                p_Attribute6,
                p_Attribute7,
                p_Attribute8,
                p_Attribute9,
                p_Attribute10,
                p_Attribute15,
                p_Accts_Pay_Code_Comb_Id,
                p_Reversal_Flag,
                p_Parent_Invoice_Id,
                p_Income_Tax_Region,
                p_Final_Match_Flag,
             -- Removed for bug 4277744
             -- p_Ussgl_Transaction_Code,
             -- p_Ussgl_Trx_Code_Context,
                p_Expenditure_Item_Date,
                p_Expenditure_Organization_Id,
                p_Expenditure_Type,
                p_Pa_Quantity,
                p_Project_Id,
                p_Task_Id,
                p_Quantity_Variance,
                p_Base_Quantity_Variance,
                p_Packet_Id,
                p_Awt_Flag,
                p_Awt_Group_Id,
                p_Pay_Awt_Group_Id,--bug6639866
                p_Awt_Tax_Rate_Id,
                p_Awt_Gross_Amount,
                p_Reference_1,
                p_Reference_2,
                p_Other_Invoice_Id,
                p_Awt_Invoice_Id,
                p_Awt_Origin_Group_Id,
                p_Program_Application_Id,
                p_Program_Id,
                p_Program_Update_Date,
                p_Request_Id,
                p_Tax_Recoverable_Flag,
                p_Award_Id,
                p_Start_Expense_Date,
                p_Merchant_Document_Number,
                p_Merchant_Name,
                p_Merchant_Tax_Reg_Number,
                p_Merchant_Taxpayer_Id,
                p_Country_Of_Supply,
                p_Merchant_Reference,
                p_Parent_Reversal_Id,
                p_rcv_transaction_id,
                l_dist_match_type,
                p_matched_uom_lookup_code,
                p_global_attribute_category,
                p_global_attribute1,
                p_global_attribute2,
                p_global_attribute3,
                p_global_attribute4,
                p_global_attribute5,
                p_global_attribute6,
                p_global_attribute7,
                p_global_attribute8,
                p_global_attribute9,
                p_global_attribute10,
                p_global_attribute11,
                p_global_attribute12,
                p_global_attribute13,
                p_global_attribute14,
                p_global_attribute15,
                p_global_attribute16,
                p_global_attribute17,
                p_global_attribute18,
                p_global_attribute19,
                p_global_attribute20,
                p_Receipt_Verified_Flag,
                p_Receipt_Required_flag,
                p_Receipt_Missing_flag,
                p_Justification,
                p_Expense_Group,
                p_End_Expense_Date,
                p_Receipt_Currency_Code,
                p_Receipt_Conversion_Rate,
                p_Receipt_Currency_Amount,
                p_Daily_Amount,
                p_Web_Parameter_Id,
                p_Adjustment_Reason,
                p_Credit_Card_Trx_Id,
                p_Company_Prepaid_Invoice_Id,
                p_org_id,  --MOAC project
                -- Invoice Lines Project Stage 1
                p_rounding_amt,
                p_charge_applicable_to_dist_id,
                p_corrected_invoice_dist_id,
                p_related_id,
                p_asset_book_type_code,
                p_asset_category_id,
          --ETAX: Invwkb
          p_intended_use,
          p_rcv_charge_addition_flag,
 --'N' /*Bug#11067286*/            --TRAMOS
          NULL,                              --TRAMOS
                p_accounting_event_id         --TRAMOS
               );



  EXCEPTION
    WHEN OTHERS THEN
      IF (SQLCODE <> -20001) THEN
        FND_MESSAGE.SET_NAME('SQLAP', 'AP_DEBUG');
        FND_MESSAGE.SET_TOKEN('ERROR', SQLERRM);
        FND_MESSAGE.SET_TOKEN('CALLING_SEQUENCE', current_calling_sequence);
        FND_MESSAGE.SET_TOKEN('DEBUG_INFO', debug_info);
      END IF;
      DBMS_OUTPUT.PUT_LINE('Erro na Insert Row distributions  end ');
      APP_EXCEPTION.RAISE_EXCEPTION;

  END Insert_Row;
  --
  --
  FUNCTION get_amount_f(p_invoice_id IN NUMBER) RETURN NUMBER IS
    --
    l_amount               NUMBER;
    l_vlr_tot_dist         NUMBER;
    l_qtde_lines           NUMBER;
    l_vlr_NFF              NUMBER;
    ---
  BEGIN
    --
    BEGIN
      --
      SELECT SUM( aida.amount)    vlr_dist_AP
           , count(1)             qtde_lines
           , SUM(aia1.invoice_amount)/count(1) vlr_NFF
        INTO l_vlr_tot_dist
           , l_qtde_lines
           , l_vlr_NFF
        FROM ap_invoices_all              aia
           , ap_invoice_relationships     air
           , ap_invoices_all              aia1
           , ap_invoice_lines_all         aila
           , ap_invoice_distributions_all aida
       WHERE 1 = 1
         AND aia.invoice_type_lookup_code IN ('INTEREST')
         AND aia.invoice_id        = air.related_invoice_id
         AND aia1.invoice_id       = air.original_invoice_id
         AND aia1.invoice_id       = aila.invoice_id
         AND aila.invoice_id       = aida.invoice_id
         AND aila.line_number      = aida.invoice_line_number
         AND aia.cancelled_date    IS NULL
         AND aida.line_type_lookup_code = 'ITEM'
         AND aia.invoice_id        = p_invoice_id;
    EXCEPTION
      WHEN OTHERS THEN
        --
        l_vlr_tot_dist    := NULL;
        l_qtde_lines      := NULL;
        l_vlr_NFF         := NULL;
        --
    END;
    --
    IF l_vlr_tot_dist > l_vlr_NFF THEN
      --
      l_amount := l_vlr_tot_dist/l_qtde_lines;
      --
    END IF;
    --
    RETURN(l_amount);
    --

  END get_amount_f;
  --
  --
  FUNCTION get_ccid_oneline_f (p_invoice_id IN  NUMBER
                             , p_origem     IN VARCHAR2) RETURN NUMBER IS
  --
  l_segment5              VARCHAR2(20);
  lv_code_combination_id  NUMBER;
  l_code_combination_id   NUMBER;
  --PRAGMA AUTONOMOUS_TRANSACTION;
  --
  BEGIN
    --
    IF p_origem = 'RI' THEN
      --
      OPEN c_inv_ri(p_invoice_id);
      FETCH c_inv_ri BULK COLLECT INTO ap_rec;
      CLOSE c_inv_ri;
      --
    ELSIF p_origem = 'AP' THEN
      --
      OPEN c_inv_ap(p_invoice_id);
      FETCH c_inv_ap BULK COLLECT INTO ap_rec;
      CLOSE c_inv_ap;
      --
    END IF;
    --
    IF ap_rec.count > 0 THEN
      --
      FOR i IN ap_rec.first..ap_rec.last LOOP
        --
        l_segment5             := NULL;
        lv_code_combination_id := NULL;
        --
        IF ap_rec(i).db_ccid IS NOT NULL THEN
          --
          lv_code_combination_id := ap_rec(i).db_ccid;
          --
        ELSE
          --
          lv_code_combination_id := ap_rec(i).dist_ccid;
          --
        END IF;
        --
        BEGIN
          --
          SELECT segment5
            INTO l_segment5
            FROM gl_code_combinations
           WHERE code_combination_id = lv_code_combination_id;
        EXCEPTION
          WHEN OTHERS THEN
            null;
        END;

        IF get_ccid_f(lv_code_combination_id
                    , l_segment5
                    , l_code_combination_id) THEN
          --
          RETURN(l_code_combination_id);
          --
        END IF;
        --
      END LOOP;
      --
    END IF;


  END get_ccid_oneline_f;

  --
  --
  FUNCTION check_lines_ccid_f (p_invoice_id IN NUMBER
                             , p_origem     OUT VARCHAR2) RETURN NUMBER IS
  --
  l_count   NUMBER := 0;
  --PRAGMA AUTONOMOUS_TRANSACTION;
  --
  BEGIN
    --
    DBMS_OUTPUT.PUT_LINE('check_lines_ccid_f --> '||p_invoice_id);
    FOR r_check IN c_inv_ri(p_invoice_id) LOOP
      --
      l_count := r_check.line_number;   --l_count + 1;
      --
    END LOOP;
    --
--DBMS_OUTPUT.PUT_LINE('check_lines_ccid_f no IF --> '||p_invoice_id);
    IF l_count > 0 THEN
      --
      p_origem := 'RI';
      RETURN(l_count);
      --
    ELSE
      --
--DBMS_OUTPUT.PUT_LINE('check_lines_ccid_f no ELSE --> '||p_invoice_id);
      l_count := 0;
      --
      FOR r_check IN c_inv_ap(p_invoice_id) LOOP
        --
        l_count := r_check.line_number;   --l_count + 1;
        --
      END LOOP;
      --
      IF l_count > 0 THEN
        --
DBMS_OUTPUT.PUT_LINE('check_lines_ccid_f Origem AP TRUE');
        p_origem := 'AP';
        RETURN(l_count);
        --
      ELSE
        --
DBMS_OUTPUT.PUT_LINE('check_lines_ccid_f Origem AP FALSE');
        RETURN(l_count);
        --
      END IF;
      --
    END IF;
    --
  EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erro check_lines_ccid_f -->  '||sqlerrm);
  END check_lines_ccid_f;
  --
  --
  FUNCTION get_ccid_f (p_ccid_in  IN  NUMBER
                     , p_segment4 IN VARCHAR2
                     , p_ccid_out OUT NUMBER) RETURN BOOLEAN IS
  --
  l_segments   gl_code_combinations_kfv.concatenated_segments%TYPE;
  l_ccid       NUMBER;
  l_coa_id     NUMBER;
  l_status     VARCHAR2(1) ;
  --
  BEGIN
    --
    BEGIN
      --
      SELECT segment1||'.'||
             segment2||'.'||
             segment3||'.'||
             p_segment4||'.'||
             segment5||'.'||
             segment6||'.'||
             segment7||'.'||
             segment8
           , chart_of_accounts_id
          -- , enabled_flag
        INTO l_segments
           , l_coa_id
           --, l_status
        FROM gl_code_combinations gcc
       WHERE gcc.code_combination_id = p_ccid_in;
      --
      --DBMS_OUTPUT.put_line('  Combinacao  --> '||l_segments||'  Status --> '||l_status);
    EXCEPTION
      WHEN OTHERS THEN
        --
        l_ccid := FND_FLEX_EXT.GET_CCID('SQLGL'
                                       ,'GL#'
                                       ,l_coa_id
                                       ,TO_CHAR(SYSDATE, fnd_flex_ext.date_format)
                                       ,l_segments);
        --
        IF l_ccid = 0 THEN
          --
          FND_FILE.PUT_LINE(FND_FILE.LOG,' Erro na Criacao do CCID para a Combinacao --> '||l_segments);
          RETURN(FALSE);
          --
        ELSE
          --
          p_ccid_out := l_ccid;
          --
          RETURN(TRUE);
          --
        END IF;
        --
    END;
    --
    IF l_ccid IS NULL THEN
      --
        --DBMS_OUTPUT.put_line('  Pegando CCID --> '||l_segments);
        BEGIN
          --
          SELECT code_combination_id
               , enabled_flag
            INTO l_ccid
               , l_status
            FROM gl_code_combinations_kfv gcck
           WHERE gcck.concatenated_segments = l_segments;
--             AND enabled_flag = 'Y';

           IF l_status = 'Y' THEN
             --
             p_ccid_out := l_ccid;
             RETURN(TRUE);
             --
           ELSE
            --
            FND_FILE.PUT_LINE(FND_FILE.LOG,'  Combinacao Desabilitada --> '||l_segments);
            DBMS_OUTPUT.put_line('  Combinacao Desabilitada --> '||l_segments);
            RETURN(FALSE);
            --
           END IF;

        EXCEPTION
          WHEN OTHERS THEN
            --
            l_ccid := FND_FLEX_EXT.GET_CCID('SQLGL'
                                           ,'GL#'
                                           ,l_coa_id
                                           ,TO_CHAR(SYSDATE, fnd_flex_ext.date_format)
                                           ,l_segments);
            --
            IF l_ccid = 0 THEN
              --
              FND_FILE.PUT_LINE(FND_FILE.LOG,' Erro na Criacao do CCID para a Combinacao --> '||l_segments);
              RETURN(FALSE);
              --
            ELSE
              --
              p_ccid_out := l_ccid;
              --
              RETURN(TRUE);
              --
            END IF;
            --
        END;
      --
    END IF;
    --
  EXCEPTION
    --
    WHEN OTHERS THEN
      --
      DBMS_OUTPUT.put_line('Erro no Get CCID --> '|| sqlerrm);
        FND_FILE.PUT_LINE(FND_FILE.LOG,'  Erro no Get CCID --> '||l_segments);
        DBMS_OUTPUT.put_line('  Erro no Get CCID --> '||l_segments);
      RETURN(FALSE);
      --
  END get_ccid_f;
  --
  --
  PROCEDURE split_ap_interest_f (p_errbuf     OUT VARCHAR2
                               , p_retcode    OUT VARCHAR2
                               , p_invoice_id IN NUMBER
                               , p_dist_ccid  IN NUMBER
                               , p_origem     IN VARCHAR2)  IS
  --
  lv_ap_invoice_dis_id   NUMBER;
  lv_dis_line_number     NUMBER := 1;
  l_user_id              NUMBER := FND_PROFILE.value('USER_ID');
  l_amount               NUMBER;
  lv_code_combination_id NUMBER;
  l_code_combination_id  NUMBER;
  l_row_id               VARCHAR2(2000);
  l_dist_row_id          VARCHAR2(2000);
  l_segment4             VARCHAR2(20);
  l_vlr_juros            NUMBER;
  l_invoice_id_ctrl      NUMBER;
  l_origem               VARCHAR2(20);
  l_dif_amount           NUMBER;
  l_line_inv             NUMBER;
  l_qte_lines            NUMBER;
  l_vlr_line             NUMBER;
  l_qte_distr            NUMBER;
  l_vlr_distr            NUMBER;
  --PRAGMA AUTONOMOUS_TRANSACTION;
  --
  BEGIN
    --
    OPEN c_inv(p_invoice_id);
    FETCH c_inv BULK COLLECT INTO ap_inv;
    CLOSE c_inv;
    --
    IF ap_inv.count > 0 THEN
      --
      FOR x IN ap_inv.first..ap_inv.last LOOP
        --
        FND_FILE.PUT_LINE(FND_FILE.LOG,'Processando Invoice......'||ap_inv(x).invoice_num);
        DBMS_OUTPUT.PUT_LINE('Processando Invoice......'||ap_inv(x).invoice_num);
        --
        l_qte_lines := check_lines_ccid_f (p_invoice_id => ap_inv(x).invoice_id
                                         , p_origem     => l_origem);
        IF l_qte_lines > 0 THEN
          --
        --DBMS_OUTPUT.PUT_LINE('Origem --> '||l_origem);
        --

          IF l_origem = 'RI' THEN
            --
            OPEN c_inv_ri(ap_inv(x).invoice_id);
            FETCH c_inv_ri BULK COLLECT INTO ap_rec;
            CLOSE c_inv_ri;
            --
          ELSIF l_origem = 'AP' THEN
            --
            OPEN c_inv_ap(ap_inv(x).invoice_id);
            FETCH c_inv_ap BULK COLLECT INTO ap_rec;
            CLOSE c_inv_ap;
            --
          END IF;
          --
        --ELSE
                  --DBMS_OUTPUT.PUT_LINE('Else da ap_inv '||l_origem);

        --ELSE
        --
        IF ap_rec.count > 0 THEN
          --
          BEGIN
            --
            SELECT segment4
              INTO l_segment4
              FROM gl_code_combinations
             WHERE code_combination_id = ap_inv(x).dist_ccid;
          EXCEPTION
            WHEN OTHERS THEN
              null;
          END;
          --
          FOR i IN ap_rec.first..ap_rec.last LOOP
            --
--DBMS_OUTPUT.PUT_LINE('Cursor ap_rec  --> Line '||ap_rec(i).line_number);
            IF ap_rec(i).db_ccid IS NOT NULL THEN
              --
              lv_code_combination_id := ap_rec(i).db_ccid;
              --
            ELSE
              --
              lv_code_combination_id := ap_rec(i).dist_ccid;
              --
            END IF;
            --
            --
            IF get_ccid_f(lv_code_combination_id
                        , l_segment4
                        , l_code_combination_id) THEN
              --
              IF ap_rec(i).line_number = 1 AND  ap_rec(i).distribution_line_number = 1
                AND (l_invoice_id_ctrl IS NULL OR l_invoice_id_ctrl != ap_rec(i).invoice_id) THEN
                --
                SELECT MAX(line_number)
                   INTO l_qte_lines
                   FROM ap_invoice_lines_all
                  WHERE invoice_id = ap_rec(i).invoice_id_orig
                    AND line_type_lookup_code = 'ITEM';   -- Paulo Ribas 26-Mar-2019
                  
                FND_FILE.PUT_LINE(FND_FILE.LOG,'IF Line -> '||ap_rec(i).line_number);
                FND_FILE.PUT_LINE(FND_FILE.LOG,'Distri -> '||ap_rec(i).distribution_line_number);

                --
                l_amount    := get_amount_f(p_invoice_id => ap_rec(i).invoice_id);
                l_vlr_juros := NVL(l_amount,ap_rec(i).vlr_final_juros);
                l_vlr_line  := ap_rec(i).vlr_juros / l_qte_lines;
                l_qte_distr := get_qte_ditr_lines(ap_rec(i).invoice_id_orig, ap_rec(i).line_number);
                l_vlr_distr := TRUNC((l_vlr_line / l_qte_distr),2);

                dbms_output.put_line('Inv Id Orig -> '||ap_rec(i).invoice_id_orig);
                dbms_output.put_line('Qtde Line -> '||l_qte_lines);
                dbms_output.put_line('Vlr Line -> '||l_vlr_line);
                dbms_output.put_line('Vlr Distri -> '||l_vlr_distr);
                --
                UPDATE AP_INVOICE_LINES_ALL
                   SET AMOUNT      = l_vlr_line
                     , BASE_AMOUNT = l_vlr_line
                  WHERE invoice_id  = ap_rec(i).invoice_id
                    AND line_number = ap_rec(i).line_number;
                --
                UPDATE AP_INVOICE_DISTRIBUTIONS_ALL
                   SET AMOUNT      = l_vlr_distr
                     , BASE_AMOUNT = l_vlr_distr
                     , dist_code_combination_id = l_code_combination_id
                  WHERE invoice_id  = ap_rec(i).invoice_id
                    AND invoice_line_number = ap_rec(i).line_number;
                --
                UPDATE AP_INVOICES_ALL
                   SET Attribute5 = 'Y'
                  WHERE invoice_id  = ap_rec(i).invoice_id;
                --

              ELSIF ap_rec(i).line_number = l_line_inv AND  ap_rec(i).distribution_line_number > 1 THEN
                -- Create Distribution
                  SELECT AP_INVOICE_DISTRIBUTIONS_S.NEXTVAL
                    INTO lv_ap_invoice_dis_id
                    FROM DUAL;
                  --
                FND_FILE.PUT_LINE(FND_FILE.LOG,'ELSE Line -> '||ap_rec(i).line_number);
                FND_FILE.PUT_LINE(FND_FILE.LOG,'Distri -> '||ap_rec(i).distribution_line_number);

                  lv_dis_line_number := ap_rec(i).distribution_line_number;--lv_dis_line_number + 1;
                  --

                 INSERT_ROW(P_ROWID                       => l_dist_row_id,
                            P_INVOICE_ID                  => ap_rec(i).invoice_id,
                            P_INVOICE_LINE_NUMBER         => ap_rec(i).line_number,
                            --P_DISTRIBUTION_CLASS          => 'PERMANENT',               --TRAMOS
                            P_DISTRIBUTION_CLASS          => NULL,
                            P_INVOICE_DISTRIBUTION_ID     => lv_ap_invoice_dis_id,
                            P_DIST_CODE_COMBINATION_ID    => l_code_combination_id,
                            P_LAST_UPDATE_DATE            => SYSDATE,
                            P_LAST_UPDATED_BY             => NVL(l_user_id,-1),
                            P_ACCOUNTING_DATE             => SYSDATE,
                            P_PERIOD_NAME                 => ap_rec(i).period_name,
                            P_SET_OF_BOOKS_ID             => ap_rec(i).set_of_books_id,
                            P_AMOUNT                      => l_vlr_distr, --NVL(l_amount,ap_rec(i).vlr_final_juros),
                            --P_DESCRIPTION                 => NULL,    --TRAMOS
                            P_DESCRIPTION                 => ap_rec(i).description,     --TRAMOS
                            P_TYPE_1099                   => NULL,
                            P_POSTED_FLAG                 => 'N',
                            P_BATCH_ID                    => NULL,
                            P_QUANTITY_INVOICED           => NULL,
                            P_UNIT_PRICE                  => NULL,
                            --P_MATCH_STATUS_FLAG           => NULL,    --TRAMOS
                            P_MATCH_STATUS_FLAG           => 'A',
                            P_ATTRIBUTE_CATEGORY          => NULL,
                            P_ATTRIBUTE1                  => NULL,
                            P_ATTRIBUTE2                  => NULL,
                            P_ATTRIBUTE3                  => NULL,
                            P_ATTRIBUTE4                  => NULL,
                            P_ATTRIBUTE5                  => NULL,
                            P_PREPAY_AMOUNT_REMAINING     => NULL,
                            --P_ASSETS_ADDITION_FLAG        => 'N',     --TRAMOS
                            P_ASSETS_ADDITION_FLAG        => 'U',       --TRAMOS
                            --P_ASSETS_TRACKING_FLAG        => 'Y',     --TRAMOS
                            P_ASSETS_TRACKING_FLAG        => 'N',       --TRAMOS
                            P_DISTRIBUTION_LINE_NUMBER    => ap_rec(i).distribution_line_number, --lv_dis_line_number,
                            P_LINE_TYPE_LOOKUP_CODE       => ap_rec(i).line_type_lookup_code,
                            P_PO_DISTRIBUTION_ID          => NULL,
                            P_BASE_AMOUNT                 => l_vlr_distr, --NVL(l_amount,ap_rec(i).vlr_final_juros),
                            --P_PA_ADDITION_FLAG            => NULL,    --TRAMOS
                            P_PA_ADDITION_FLAG            => 'E',       --TRAMOS
                            P_POSTED_AMOUNT               => NULL,
                            P_POSTED_BASE_AMOUNT          => NULL,
                            --P_ENCUMBERED_FLAG             => NULL,    --TRAMOS
                            P_ENCUMBERED_FLAG             => 'N',
                            --P_ACCRUAL_POSTED_FLAG         => NULL,    --TRAMOS
                            P_ACCRUAL_POSTED_FLAG         => 'N',       --TRAMOS
                            --P_CASH_POSTED_FLAG            => NULL,    --TRAMOS
                            P_CASH_POSTED_FLAG            => 'N',       --TRAMOS
                            P_LAST_UPDATE_LOGIN           => NULL,
                            P_CREATION_DATE               => SYSDATE,
                            P_CREATED_BY                  => NVL(l_user_id,-1),
                            P_STAT_AMOUNT                 => NULL,
                            P_ATTRIBUTE11                 => NULL,
                            P_ATTRIBUTE12                 => NULL,
                            P_ATTRIBUTE13                 => NULL,
                            P_ATTRIBUTE14                 => NULL,
                            P_ATTRIBUTE6                  => NULL,
                            P_ATTRIBUTE7                  => NULL,
                            P_ATTRIBUTE8                  => NULL,
                            P_ATTRIBUTE9                  => NULL,
                            P_ATTRIBUTE10                 => NULL,
                            P_ATTRIBUTE15                 => NULL,
                            --P_ACCTS_PAY_CODE_COMB_ID      => NULL,    --TRAMOS
                            P_ACCTS_PAY_CODE_COMB_ID      => ap_rec(i).accts_pay_code_combination_id,      --TRAMOS
                            P_REVERSAL_FLAG               => NULL,
                            P_PARENT_INVOICE_ID           => NULL,
                            P_INCOME_TAX_REGION           => NULL,
                            P_FINAL_MATCH_FLAG            => NULL,
                            P_EXPENDITURE_ITEM_DATE       => NULL,
                            P_EXPENDITURE_ORGANIZATION_ID => NULL,
                            P_EXPENDITURE_TYPE            => NULL,
                            P_PA_QUANTITY                 => NULL,
                            P_PROJECT_ID                  => NULL,
                            P_TASK_ID                     => NULL,
                            P_QUANTITY_VARIANCE           => NULL,
                            P_BASE_QUANTITY_VARIANCE      => NULL,
                            P_PACKET_ID                   => NULL,
                            P_AWT_FLAG                    => NULL,
                            P_AWT_GROUP_ID                => NULL,
                            P_PAY_AWT_GROUP_ID            => NULL,
                            P_AWT_TAX_RATE_ID             => NULL,
                            P_AWT_GROSS_AMOUNT            => NULL,
                            P_REFERENCE_1                 => NULL,
                            P_REFERENCE_2                 => NULL,
                            P_ORG_ID                      => ap_rec(i).org_id,
                            P_OTHER_INVOICE_ID            => NULL,
                            P_AWT_INVOICE_ID              => NULL,
                            P_AWT_ORIGIN_GROUP_ID         => NULL,
                            P_PROGRAM_APPLICATION_ID      => NULL,
                            P_PROGRAM_ID                  => NULL,
                            P_PROGRAM_UPDATE_DATE         => NULL,
                            P_REQUEST_ID                  => NULL,
                            P_TAX_RECOVERABLE_FLAG        => NULL,
                            P_AWARD_ID                    => NULL,
                            P_START_EXPENSE_DATE          => NULL,
                            P_MERCHANT_DOCUMENT_NUMBER    => NULL,
                            P_MERCHANT_NAME               => NULL,
                            P_MERCHANT_TAX_REG_NUMBER     => NULL,
                            P_MERCHANT_TAXPAYER_ID        => NULL,
                            P_COUNTRY_OF_SUPPLY           => NULL,
                            P_MERCHANT_REFERENCE          => NULL,
                            P_PARENT_REVERSAL_ID          => NULL,
                            P_RCV_TRANSACTION_ID          => NULL,
                            P_MATCHED_UOM_LOOKUP_CODE     => NULL,
                            P_CALLING_SEQUENCE            => '1',
                            --P_RCV_CHARGE_ADDITION_FLAG    => NULL  --TRAMOS
                            P_RCV_CHARGE_ADDITION_FLAG    => 'N',
                            P_ACCOUNTING_EVENT_ID           => ap_rec(i).accounting_event_id                 --TRAMOS
                            );

              ELSIF ap_rec(i).line_number != l_line_inv AND  ap_rec(i).distribution_line_number = 1 THEN
                --
                dbms_output.put_line('Line -> '||ap_rec(i).line_number);
                dbms_output.put_line('Distri -> '||ap_rec(i).distribution_line_number);
                --l_vlr_line  := ap_rec(i).vlr_final_juros / l_qte_lines;
                l_qte_distr := get_qte_ditr_lines(ap_rec(i).invoice_id_orig, ap_rec(i).line_number);
                l_vlr_distr := TRUNC((l_vlr_line / l_qte_distr),2);
                dbms_output.put_line('Valor -> '||l_vlr_distr);
                  --
                  SELECT AP_INVOICE_DISTRIBUTIONS_S.NEXTVAL
                    INTO lv_ap_invoice_dis_id
                    FROM DUAL;
                  --
                  lv_dis_line_number := ap_rec(i).distribution_line_number;--lv_dis_line_number + 1;
                  --
              AP_AIL_TABLE_HANDLER_PKG.INSERT_ROW(
                             P_ROWID                             =>l_row_id
                            ,P_INVOICE_ID                        =>ap_rec(i).invoice_id
                            ,P_LINE_NUMBER                       =>ap_rec(i).LINE_NUMBER
                            ,P_LINE_TYPE_LOOKUP_CODE             =>ap_rec(i).line_type_lookup_code
                            ,P_LINE_GROUP_NUMBER                 =>NULL
                            ,P_REQUESTER_ID                      =>NULL
                            ,P_DESCRIPTION                       =>NULL
                            ,P_LINE_SOURCE                       =>'AUTO INVOICE CREATION'
                            ,P_ORG_ID                            =>ap_rec(i).org_id
                            ,P_INVENTORY_ITEM_ID                 =>NULL
                            ,P_ITEM_DESCRIPTION                  =>NULL
                            ,P_SERIAL_NUMBER                     =>NULL
                            ,P_MANUFACTURER                      =>NULL
                            ,P_MODEL_NUMBER                      =>NULL
                            ,P_WARRANTY_NUMBER                   =>NULL
                            ,P_GENERATE_DISTS                    =>'D'
                            ,P_MATCH_TYPE                        =>NULL
                            ,P_DISTRIBUTION_SET_ID               =>NULL
                            ,P_ACCOUNT_SEGMENT                   =>NULL
                            ,P_BALANCING_SEGMENT                 =>NULL
                            ,P_COST_CENTER_SEGMENT               =>NULL
                            ,P_OVERLAY_DIST_CODE_CONCAT          =>NULL
                            ,P_DEFAULT_DIST_CCID                 =>l_code_combination_id
                            ,P_PRORATE_ACROSS_ALL_ITEMS          =>NULL
                            ,P_ACCOUNTING_DATE                   =>SYSDATE
                            ,P_PERIOD_NAME                       =>ap_rec(i).period_name
                            ,P_DEFERRED_ACCTG_FLAG               =>'N'
                            ,P_DEF_ACCTG_START_DATE              =>NULL
                            ,P_DEF_ACCTG_END_DATE                =>NULL
                            ,P_DEF_ACCTG_NUMBER_OF_PERIODS       =>NULL
                            ,P_DEF_ACCTG_PERIOD_TYPE             =>NULL
                            ,P_SET_OF_BOOKS_ID                   =>ap_rec(i).set_of_books_id
                            ,P_AMOUNT                            =>l_vlr_line  --NVL(l_amount,ap_rec(i).vlr_final_juros)
                            ,P_BASE_AMOUNT                       =>l_vlr_line --NVL(l_amount,ap_rec(i).vlr_final_juros)
                            ,P_ROUNDING_AMT                      =>NULL
                            ,P_QUANTITY_INVOICED                 =>NULL
                            ,P_UNIT_MEAS_LOOKUP_CODE             =>NULL
                            ,P_UNIT_PRICE                        =>NULL
                            ,P_WFAPPROVAL_STATUS                 =>'NOT REQUIRED'
                            ,P_DISCARDED_FLAG                    =>NULL
                            ,P_ORIGINAL_AMOUNT                   =>NULL
                            ,P_ORIGINAL_BASE_AMOUNT              =>NULL
                            ,P_ORIGINAL_ROUNDING_AMT             =>NULL
                            ,P_CANCELLED_FLAG                    =>NULL
                            ,P_INCOME_TAX_REGION                 =>NULL
                            ,P_TYPE_1099                         =>NULL
                            ,P_STAT_AMOUNT                       =>NULL
                            ,P_PREPAY_INVOICE_ID                 =>NULL
                            ,P_PREPAY_LINE_NUMBER                =>NULL
                            ,P_INVOICE_INCLUDES_PREPAY_FLAG      =>NULL
                            ,P_CORRECTED_INV_ID                  =>NULL
                            ,P_CORRECTED_LINE_NUMBER             =>NULL
                            ,P_PO_HEADER_ID                      =>NULL
                            ,P_PO_RELEASE_ID                     =>NULL
                            ,P_PO_LINE_LOCATION_ID               =>NULL
                            ,P_PO_DISTRIBUTION_ID                =>NULL
                            ,P_PO_LINE_ID                        =>NULL
                            ,P_RCV_TRANSACTION_ID                =>NULL
                            ,P_FINAL_MATCH_FLAG                  =>NULL
                            ,P_ASSETS_TRACKING_FLAG              =>'Y'
                            ,P_ASSET_BOOK_TYPE_CODE              =>NULL
                            ,P_ASSET_CATEGORY_ID                 =>NULL
                            ,P_PROJECT_ID                        =>NULL
                            ,P_TASK_ID                           =>NULL
                            ,P_EXPENDITURE_TYPE                  =>NULL
                            ,P_EXPENDITURE_ITEM_DATE             =>NULL
                            ,P_EXPENDITURE_ORGANIZATION_ID       =>NULL
                            ,P_PA_QUANTITY                       =>1
                            ,P_PA_CC_AR_INVOICE_ID               =>NULL
                            ,P_PA_CC_AR_INVOICE_LINE_NUM         =>NULL
                            ,P_PA_CC_PROCESSED_CODE              =>NULL
                            ,P_AWARD_ID                          =>NULL
                            ,P_AWT_GROUP_ID                      =>NULL
                            ,P_PAY_AWT_GROUP_ID                  =>NULL
                            ,P_REFERENCE_1                       =>NULL
                            ,P_REFERENCE_2                       =>NULL
                            ,P_RECEIPT_VERIFIED_FLAG             =>NULL
                            ,P_RECEIPT_REQUIRED_FLAG             =>NULL
                            ,P_RECEIPT_MISSING_FLAG              =>NULL
                            ,P_JUSTIFICATION                     =>NULL
                            ,P_EXPENSE_GROUP                     =>NULL
                            ,P_START_EXPENSE_DATE                =>NULL
                            ,P_END_EXPENSE_DATE                  =>NULL
                            ,P_RECEIPT_CURRENCY_CODE             =>NULL
                            ,P_RECEIPT_CONVERSION_RATE           =>NULL
                            ,P_RECEIPT_CURRENCY_AMOUNT           =>NULL
                            ,P_DAILY_AMOUNT                      =>NULL
                            ,P_WEB_PARAMETER_ID                  =>NULL
                            ,P_ADJUSTMENT_REASON                 =>NULL
                            ,P_MERCHANT_DOCUMENT_NUMBER          =>NULL
                            ,P_MERCHANT_NAME                     =>NULL
                            ,P_MERCHANT_REFERENCE                =>NULL
                            ,P_MERCHANT_TAX_REG_NUMBER           =>NULL
                            ,P_MERCHANT_TAXPAYER_ID              =>NULL
                            ,P_COUNTRY_OF_SUPPLY                 =>NULL
                            ,P_CREDIT_CARD_TRX_ID                =>NULL
                            ,P_COMPANY_PREPAID_INVOICE_ID        =>NULL
                            ,P_CC_REVERSAL_FLAG                  =>NULL
                            ,P_CREATION_DATE                     =>SYSDATE
                            ,P_CREATED_BY                        =>NVL(l_user_id,-1)
                            ,P_LAST_UPDATED_BY                   =>NVL(l_user_id,-1)
                            ,P_LAST_UPDATE_DATE                  =>SYSDATE
                            ,P_LAST_UPDATE_LOGIN                 =>NULL
                            ,P_PROGRAM_APPLICATION_ID            =>NULL
                            ,P_PROGRAM_ID                        =>NULL
                            ,P_PROGRAM_UPDATE_DATE               =>NULL
                            ,P_REQUEST_ID                        =>NULL
                            ,P_ATTRIBUTE_CATEGORY                =>NULL
                            ,P_ATTRIBUTE1                        =>NULL
                            ,P_ATTRIBUTE2                        =>NULL
                            ,P_ATTRIBUTE3                        =>NULL
                            ,P_ATTRIBUTE4                        =>NULL
                            ,P_ATTRIBUTE5                        =>NULL
                            ,P_CALLING_SEQUENCE                  =>'1'
                            ,P_PRODUCT_TYPE                      =>NULL
                            ,P_SHIP_TO_LOCATION_ID               =>NULL);


                 INSERT_ROW(P_ROWID                       => l_dist_row_id,
                            P_INVOICE_ID                  => ap_rec(i).invoice_id,
                            P_INVOICE_LINE_NUMBER         => ap_rec(i).line_number,
                            --P_DISTRIBUTION_CLASS          => 'PERMANENT',               --TRAMOS
                            P_DISTRIBUTION_CLASS          => NULL,
                            P_INVOICE_DISTRIBUTION_ID     => lv_ap_invoice_dis_id,
                            P_DIST_CODE_COMBINATION_ID    => l_code_combination_id,
                            P_LAST_UPDATE_DATE            => SYSDATE,
                            P_LAST_UPDATED_BY             => NVL(l_user_id,-1),
                            P_ACCOUNTING_DATE             => SYSDATE,
                            P_PERIOD_NAME                 => ap_rec(i).period_name,
                            P_SET_OF_BOOKS_ID             => ap_rec(i).set_of_books_id,
                            P_AMOUNT                      => l_vlr_distr, --NVL(l_amount,ap_rec(i).vlr_final_juros),
                            --P_DESCRIPTION                 => NULL,    --TRAMOS
                            P_DESCRIPTION                 => ap_rec(i).description,     --TRAMOS
                            P_TYPE_1099                   => NULL,
                            P_POSTED_FLAG                 => 'N',
                            P_BATCH_ID                    => NULL,
                            P_QUANTITY_INVOICED           => NULL,
                            P_UNIT_PRICE                  => NULL,
                            --P_MATCH_STATUS_FLAG           => NULL,    --TRAMOS
                            P_MATCH_STATUS_FLAG           => 'A',
                            P_ATTRIBUTE_CATEGORY          => NULL,
                            P_ATTRIBUTE1                  => NULL,
                            P_ATTRIBUTE2                  => NULL,
                            P_ATTRIBUTE3                  => NULL,
                            P_ATTRIBUTE4                  => NULL,
                            P_ATTRIBUTE5                  => NULL,
                            P_PREPAY_AMOUNT_REMAINING     => NULL,
                            --P_ASSETS_ADDITION_FLAG        => 'N',     --TRAMOS
                            P_ASSETS_ADDITION_FLAG        => 'U',       --TRAMOS
                            --P_ASSETS_TRACKING_FLAG        => 'Y',     --TRAMOS
                            P_ASSETS_TRACKING_FLAG        => 'N',       --TRAMOS
                            P_DISTRIBUTION_LINE_NUMBER    => ap_rec(i).distribution_line_number, --lv_dis_line_number,
                            P_LINE_TYPE_LOOKUP_CODE       => ap_rec(i).line_type_lookup_code,
                            P_PO_DISTRIBUTION_ID          => NULL,
                            P_BASE_AMOUNT                 => l_vlr_distr, --NVL(l_amount,ap_rec(i).vlr_final_juros),
                            --P_PA_ADDITION_FLAG            => NULL,    --TRAMOS
                            P_PA_ADDITION_FLAG            => 'E',       --TRAMOS
                            P_POSTED_AMOUNT               => NULL,
                            P_POSTED_BASE_AMOUNT          => NULL,
                            --P_ENCUMBERED_FLAG             => NULL,    --TRAMOS
                            P_ENCUMBERED_FLAG             => 'N',
                            --P_ACCRUAL_POSTED_FLAG         => NULL,    --TRAMOS
                            P_ACCRUAL_POSTED_FLAG         => 'N',       --TRAMOS
                            --P_CASH_POSTED_FLAG            => NULL,    --TRAMOS
                            P_CASH_POSTED_FLAG            => 'N',       --TRAMOS
                            P_LAST_UPDATE_LOGIN           => NULL,
                            P_CREATION_DATE               => SYSDATE,
                            P_CREATED_BY                  => NVL(l_user_id,-1),
                            P_STAT_AMOUNT                 => NULL,
                            P_ATTRIBUTE11                 => NULL,
                            P_ATTRIBUTE12                 => NULL,
                            P_ATTRIBUTE13                 => NULL,
                            P_ATTRIBUTE14                 => NULL,
                            P_ATTRIBUTE6                  => NULL,
                            P_ATTRIBUTE7                  => NULL,
                            P_ATTRIBUTE8                  => NULL,
                            P_ATTRIBUTE9                  => NULL,
                            P_ATTRIBUTE10                 => NULL,
                            P_ATTRIBUTE15                 => NULL,
                            --P_ACCTS_PAY_CODE_COMB_ID      => NULL,    --TRAMOS
                            P_ACCTS_PAY_CODE_COMB_ID      => ap_rec(i).accts_pay_code_combination_id,      --TRAMOS
                            P_REVERSAL_FLAG               => NULL,
                            P_PARENT_INVOICE_ID           => NULL,
                            P_INCOME_TAX_REGION           => NULL,
                            P_FINAL_MATCH_FLAG            => NULL,
                            P_EXPENDITURE_ITEM_DATE       => NULL,
                            P_EXPENDITURE_ORGANIZATION_ID => NULL,
                            P_EXPENDITURE_TYPE            => NULL,
                            P_PA_QUANTITY                 => NULL,
                            P_PROJECT_ID                  => NULL,
                            P_TASK_ID                     => NULL,
                            P_QUANTITY_VARIANCE           => NULL,
                            P_BASE_QUANTITY_VARIANCE      => NULL,
                            P_PACKET_ID                   => NULL,
                            P_AWT_FLAG                    => NULL,
                            P_AWT_GROUP_ID                => NULL,
                            P_PAY_AWT_GROUP_ID            => NULL,
                            P_AWT_TAX_RATE_ID             => NULL,
                            P_AWT_GROSS_AMOUNT            => NULL,
                            P_REFERENCE_1                 => NULL,
                            P_REFERENCE_2                 => NULL,
                            P_ORG_ID                      => ap_rec(i).org_id,
                            P_OTHER_INVOICE_ID            => NULL,
                            P_AWT_INVOICE_ID              => NULL,
                            P_AWT_ORIGIN_GROUP_ID         => NULL,
                            P_PROGRAM_APPLICATION_ID      => NULL,
                            P_PROGRAM_ID                  => NULL,
                            P_PROGRAM_UPDATE_DATE         => NULL,
                            P_REQUEST_ID                  => NULL,
                            P_TAX_RECOVERABLE_FLAG        => NULL,
                            P_AWARD_ID                    => NULL,
                            P_START_EXPENSE_DATE          => NULL,
                            P_MERCHANT_DOCUMENT_NUMBER    => NULL,
                            P_MERCHANT_NAME               => NULL,
                            P_MERCHANT_TAX_REG_NUMBER     => NULL,
                            P_MERCHANT_TAXPAYER_ID        => NULL,
                            P_COUNTRY_OF_SUPPLY           => NULL,
                            P_MERCHANT_REFERENCE          => NULL,
                            P_PARENT_REVERSAL_ID          => NULL,
                            P_RCV_TRANSACTION_ID          => NULL,
                            P_MATCHED_UOM_LOOKUP_CODE     => NULL,
                            P_CALLING_SEQUENCE            => '1',
                            --P_RCV_CHARGE_ADDITION_FLAG    => NULL  --TRAMOS
                            P_RCV_CHARGE_ADDITION_FLAG    => 'N',
                            P_ACCOUNTING_EVENT_ID           => ap_rec(i).accounting_event_id                 --TRAMOS
                            );


                  --
              END IF;
              --
            ELSE
              ROLLBACK;
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro na Invoice Nr. ==> '||ap_rec(i).invoice_num||' Linha --> '||ap_rec(i).line_number);
              EXIT;
            END IF;
            --
            l_invoice_id_ctrl := ap_rec(i).invoice_id;
            l_line_inv        := ap_rec(i).line_number;
            --
          END LOOP;
          --
          l_dif_amount := check_amount_f(p_invoice_id => ap_inv(x).invoice_id
                                         ,p_invoice_line_number => NULL);
          --
          --
        END IF;
        --

        COMMIT;
        --
      END IF;
      --
      END LOOP;
      --
    END IF;
    --
    COMMIT;
    --
    EXCEPTION
    --
    WHEN OTHERS THEN
      --------------------------------------------------------------------
      --> Rollback All Data
      --------------------------------------------------------------------
      ROLLBACK;
      --------------------------------------------------------------------
      FND_FILE.PUT_LINE(FND_FILE.LOG,' Erro na API '||sqlerrm);
      --
  END split_ap_interest_f;
  --
  --
BEGIN
  -- INITIALIZATION
  NULL;
END XXCUST_AP0003_PKGA;
/
--
SHOW ERRORS
--
PROMPT Package Body XXCUST_AP0003_PKGA created
--
