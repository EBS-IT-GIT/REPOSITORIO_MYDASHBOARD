set define off;
CREATE OR REPLACE PACKAGE BODY XXSTN_GL0002_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_GL0002_PKG.pls                                            |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   GL - Relatorio Status Aprovacao e Contabilizacao              |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S               (28/01/2019)     |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

 --> Variaveis Globais:
 g_bShow_log          BOOLEAN := TRUE; -- FALSE;
 g_bGen_XML           BOOLEAN := FALSE;-- TRUE;

 PROCEDURE gen_relat_gl_status_p (errbuf OUT VARCHAR2
                                  ,retcode OUT NUMBER
                                  ,P_LIVRO IN VARCHAR2
                                  ,P_DATA_DE IN VARCHAR2
                                  ,P_DATA_ATE IN VARCHAR2
                                  ,P_TIPO_RELAT IN VARCHAR2
                                  ) IS

 CURSOR c_aprovacao IS
  select distinct led.name Livro_Contabil,
                  gb.name Nome_Lote,
                  gh.currency_code Moeda_Lote,
                  decode(gb.actual_flag,
                         'A',
                         'Real',
                         'E',
                         'Encumbrances',
                         'B',
                         'Budgets') Tipo_Saldo,
                  gb.default_period_name Periodo,
                  gb.default_effective_date Data_Efetiva_Lote,
                  decode(gb.status,
                         'I',
                         'Em Andamento',
                         'U',
                         'N�o Contabilizado',
                         'P',
                         'Contabilizado',
                         'S',
                         'Selecionado',
                         'O',
                         'Erro') Status_Contabilizacao,
                  gb.running_total_cr Total_Credito,
                  decode(gb.approval_status_code,
                         'R',
                         'Obrigatorio',
                         'Z',
                         'Nao se Aplica',
                         'I',
                         'Iniciado',
                         'A',
                         'Aprovado',
                         'J',
                         'Rejeitado') Status_Aprovacao,
                  trunc(gb.date_created) Data_Criacao_Lote,
                  fnd.user_name Usuario_Criador_Lote
  
    from apps.gl_je_batches gb,
         apps.gl_je_headers gh,
         apps.gl_ledgers    led,
         apps.fnd_user      fnd,
         apps.gl_je_sources gs
  
   where gb.je_batch_id = gh.je_batch_id
     and gh.je_source = gs.je_source_name
     and gs.journal_approval_flag = 'Y'
     and gs.language = userenv('lang')
     and trunc(gb.date_created) between to_date(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')
         and to_date(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')
     and led.name = nvl(P_LIVRO,led.name)     
     and gh.ledger_id = led.ledger_id
     and led.ledger_category_code = 'PRIMARY'
     and gb.approval_status_code <> 'A'
     and gb.created_by = fnd.user_id
   order by led.name, gb.default_effective_date, trunc(gb.date_created);
 
  CURSOR c_contab IS
   select distinct led.name                       Livro_Contabil
                  ,gb.name                        Nome_Lote
                  ,gh.currency_code               Moeda_Lote
                  ,decode(gb.actual_flag,'A','Real'
                                        ,'E','Encumbrances'
                                        ,'B','Budgets')             Tipo_Saldo
                  ,gb.default_period_name                           Periodo
                  ,gb.default_effective_date                        Data_Efetiva_Lote
              
                  ,decode(gb.status,'I','Em Andamento'
                                   ,'U','N�o Contabilizado'
                                   ,'P','Contabilizado'
                                   ,'S','Selecionado'
                                   ,'O','Erro')                     Status_Contabilizacao
                  ,gb.posted_date                                   Data_Postagem_GL
                  ,fnd2.user_name                                   Usuario_Postagem_GL
                  ,gb.running_total_cr                              Total_Credito
                  ,decode(gb.approval_status_code,'R','Obrigatorio'
                                                 ,'Z','Nao se Aplica'
                                                 ,'I','Iniciado'
                                                 ,'A','Aprovado'
                                                 ,'J','Rejeitado')  Status_Aprovacao
                  ,trunc(gwf.action_date)                           Data_Aprovacao
                  ,fnd1.user_name                                   Usuario_Aprovador
                  
                  ,trunc(gb.date_created)                           Data_Criacao_Lote                  
                  ,fnd.user_name                                    Usuario_Criador_Lote               
   from gl_je_batches        gb
       ,gl_je_headers        gh
       ,gl_wf_action_history gwf
       ,gl_ledgers           led
       ,gl_je_sources        gs   
       ,fnd_user             fnd
       ,fnd_user             fnd1
       ,fnd_user             fnd2 
   where gb.je_batch_id          = gh.je_batch_id
   and   gb.approver_employee_id = fnd1.employee_id (+)  --aprovador
   and   gb.created_by           = fnd.user_id       --criador
   and   fnd2.user_id            = gb.posted_by      --postagem
   and   gb.je_batch_id          = gwf.object_id (+)
   and   gwf.action_code         = 'APPROVE'
   --and   gh.je_source in ('Manual','Planilha','Spreadsheet')
   and   gh.je_source             = gs.je_source_name
   and   gs.journal_approval_flag = 'Y'
   and   gs.language              = userenv('lang')
   and   trunc(gb.date_created) between to_date(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')
         and to_date(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')
   and   gh.ledger_id             = led.ledger_id
   and   led.name = nvl(P_LIVRO,led.name)   
   and   led.ledger_category_code = 'PRIMARY'
   and   gb.approval_status_code  = 'A'
   order by led.name,gb.default_effective_date,trunc(gb.date_created);

  l_exec varchar2(500);

 BEGIN

  --> Ativa ou desativa o log de erros de acordo com o parametro
    /*IF p_show_log = 'Y' THEN
    g_bShow_log := TRUE;
  END IF;*/

  l_exec := 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS='',.''';

  execute immediate l_exec;

  show_error_log_p(p_message => 'Inicio do relatorio gen_relat_gl_status_p');

  --gen_xml_p('<?xml version="1.0" encoding="UTF-8"?>');
  --gen_xml_p('<?xml version="1.0" encoding="UTF-16"?>');
  gen_xml_p('<?xml version="1.0" encoding="ISO-8859-1"?>');
  gen_xml_p('<HEADERS>');

  gen_xml_p(' <HEADER>');

  gen_xml_p('    <LIVRO>'  || P_LIVRO ||'</LIVRO>');
  gen_xml_p('    <DATA_DE>'  || to_char(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR') ||'</DATA_DE>');
  gen_xml_p('    <DATA_ATE>'  || to_char(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')  ||'</DATA_ATE>');
  gen_xml_p('    <P_TIPO_RELAT>'  || P_TIPO_RELAT ||'</P_TIPO_RELAT>');
  
  IF P_TIPO_RELAT = 'APROVACAO' THEN   
  
   --gen_xml_p('    <TOTAL_CREDITO_LABEL_APPRV>'  || 'Total Credito' ||'</TOTAL_CREDITO_LABEL_APPRV>');
   --gen_xml_p('    <STATUS_APROVACAO_LABEL_APPRV>'  || 'Status Aprovacao' ||'</STATUS_APROVACAO_LABEL_APPRV>');
   --gen_xml_p('    <DATA_CRIACAO_LOTE_LABEL_APPRV>'  || 'Data Criacao Lote' ||'</DATA_CRIACAO_LOTE_LABEL_APPRV>');
   --gen_xml_p('    <USUARIO_CRIADOR_LOTE_LABEL_APPRV>'  || 'Usuario Criador Lote' ||'</USUARIO_CRIADOR_LOTE_LABEL_APPRV>'); 

   FOR r_aprovacao IN c_aprovacao LOOP

    gen_xml_p('   <LINES_RELAT>');

     gen_xml_p('    <LIVRO_CONTABIL_APPRV>'  || conv_spc_chr(r_aprovacao.livro_contabil) ||'</LIVRO_CONTABIL_APPRV>');
     gen_xml_p('    <NOME_LOTE_APPRV>'  || conv_spc_chr(r_aprovacao.Nome_Lote) ||'</NOME_LOTE_APPRV>');
     gen_xml_p('    <MOEDA_LOTE_APPRV>'  || conv_spc_chr(r_aprovacao.Moeda_Lote) ||'</MOEDA_LOTE_APPRV>');
     gen_xml_p('    <TIPO_SALDO_APPRV>'  || conv_spc_chr(r_aprovacao.Tipo_Saldo) ||'</TIPO_SALDO_APPRV>');
     gen_xml_p('    <PERIODO_APPRV>'  || conv_spc_chr(r_aprovacao.Periodo) ||'</PERIODO_APPRV>');
     gen_xml_p('    <DATA_EFETIVA_LOTE_APPRV>'  || TO_CHAR(r_aprovacao.Data_Efetiva_Lote,'DD/MM/RRRR') ||'</DATA_EFETIVA_LOTE_APPRV>');
     gen_xml_p('    <STATUS_CONTABILIZACAO_APPRV>'  || conv_spc_chr(r_aprovacao.Status_Contabilizacao) ||'</STATUS_CONTABILIZACAO_APPRV>');
     gen_xml_p('    <TOTAL_CREDITO_APPRV>'  || LTRIM(TO_CHAR(conv_spc_chr(r_aprovacao.TOTAL_CREDITO),'999G999G990D00')) ||'</TOTAL_CREDITO_APPRV>');
     gen_xml_p('    <STATUS_APROVACAO_APPRV>'  || conv_spc_chr(r_aprovacao.STATUS_APROVACAO) ||'</STATUS_APROVACAO_APPRV>');
     gen_xml_p('    <DATA_CRIACAO_LOTE_APPRV>'  || TO_CHAR(r_aprovacao.DATA_CRIACAO_LOTE,'DD/MM/RRRR') ||'</DATA_CRIACAO_LOTE_APPRV>');
     gen_xml_p('    <USUARIO_CRIADOR_LOTE_APPRV>'  || conv_spc_chr(r_aprovacao.USUARIO_CRIADOR_LOTE) ||'</USUARIO_CRIADOR_LOTE_APPRV>');

    gen_xml_p('   </LINES_RELAT>');

   END LOOP; --FOR R_aprovacao IN c_aprovacao LOOP
   
  ELSIF P_TIPO_RELAT = 'CONTABILIZACAO' THEN  
  
   /*gen_xml_p('    <DATA_POSTAGEM_GL_LABEL_CONTAB>'  || 'Data Postagem GL' ||'</DATA_POSTAGEM_GL_LABEL_CONTAB>');
   gen_xml_p('    <USUARIO_POSTAGEM_GL_LABEL_CONTAB>'  || 'Usuario Postagem GL' ||'</USUARIO_POSTAGEM_GL_LABEL_CONTAB>');
   gen_xml_p('    <TOTAL_CREDITO_LABEL_CONTAB>'  || 'Total Credito' ||'</TOTAL_CREDITO_LABEL_CONTAB>');
   gen_xml_p('    <STATUS_APROVACAO_LABEL_CONTAB>'  || 'Status Aprovacao' ||'</STATUS_APROVACAO_LABEL_CONTAB>');
   gen_xml_p('    <DATA_APROVACAO_LABEL_CONTAB>'  || 'Data Aprovacao' ||'</DATA_APROVACAO_LABEL_CONTAB>');
   gen_xml_p('    <USUARIO_APROVADOR_LABEL_CONTAB>'  || 'Usuario Aprovador' ||'</USUARIO_APROVADOR_LABEL_CONTAB>');
   gen_xml_p('    <DATA_CRIACAO_LOTE_LABEL_CONTAB>'  || 'Data Criacao Lote' ||'</DATA_CRIACAO_LOTE_LABEL_CONTAB>');
   gen_xml_p('    <USUARIO_CRIADOR_LOTE_LABEL_CONTAB>'  || 'Usuario Criador Lote' ||'</USUARIO_CRIADOR_LOTE_LABEL_CONTAB>');*/

   FOR r_contab IN c_contab LOOP
   
    gen_xml_p('   <LINES_RELAT>');
   
     gen_xml_p('    <LIVRO_CONTABIL_CONTAB>'  || conv_spc_chr(r_contab.livro_contabil) ||'</LIVRO_CONTABIL_CONTAB>');
     gen_xml_p('    <NOME_LOTE_CONTAB>'  || conv_spc_chr(r_contab.Nome_Lote) ||'</NOME_LOTE_CONTAB>');
     gen_xml_p('    <MOEDA_LOTE_CONTAB>'  || conv_spc_chr(r_contab.Moeda_Lote) ||'</MOEDA_LOTE_CONTAB>');
     gen_xml_p('    <TIPO_SALDO_CONTAB>'  || conv_spc_chr(r_contab.Tipo_Saldo) ||'</TIPO_SALDO_CONTAB>');
     gen_xml_p('    <PERIODO_CONTAB>'  || conv_spc_chr(r_contab.Periodo) ||'</PERIODO_CONTAB>');
     gen_xml_p('    <DATA_EFETIVA_LOTE_CONTAB>'  || TO_CHAR(r_contab.Data_Efetiva_Lote,'DD/MM/RRRR') ||'</DATA_EFETIVA_LOTE_CONTAB>');
     gen_xml_p('    <STATUS_CONTABILIZACAO_CONTAB>'  || conv_spc_chr(r_contab.Status_Contabilizacao) ||'</STATUS_CONTABILIZACAO_CONTAB>');
     gen_xml_p('    <DATA_POSTAGEM_GL_CONTAB>'  || TO_CHAR(r_contab.Data_Postagem_GL,'DD/MM/RRRR') ||'</DATA_POSTAGEM_GL_CONTAB>');
     gen_xml_p('    <USUARIO_POSTAGEM_GL_CONTAB>'  || conv_spc_chr(r_contab.Usuario_Postagem_GL) ||'</USUARIO_POSTAGEM_GL_CONTAB>');
     gen_xml_p('    <TOTAL_CREDITO_CONTAB>'  || LTRIM(TO_CHAR(conv_spc_chr(r_contab.Total_Credito),'999G999G990D00')) ||'</TOTAL_CREDITO_CONTAB>');
     gen_xml_p('    <STATUS_APROVACAO_CONTAB>'  || conv_spc_chr(r_contab.STATUS_APROVACAO) ||'</STATUS_APROVACAO_CONTAB>');
     gen_xml_p('    <DATA_APROVACAO_CONTAB>'  || TO_CHAR(r_contab.Data_Aprovacao,'DD/MM/RRRR') ||'</DATA_APROVACAO_CONTAB>');
     gen_xml_p('    <USUARIO_APROVADOR_CONTAB>'  || conv_spc_chr(r_contab.Usuario_Aprovador) ||'</USUARIO_APROVADOR_CONTAB>');
     gen_xml_p('    <DATA_CRIACAO_LOTE_CONTAB>'  || TO_CHAR(r_contab.DATA_CRIACAO_LOTE,'DD/MM/RRRR') ||'</DATA_CRIACAO_LOTE_CONTAB>');
     gen_xml_p('    <USUARIO_CRIADOR_LOTE_CONTAB>'  || conv_spc_chr(r_contab.Usuario_Criador_Lote) ||'</USUARIO_CRIADOR_LOTE_CONTAB>');

    gen_xml_p('   </LINES_RELAT>');
   
   END LOOP; --FOR r_contab IN c_contab LOOP

  END IF; -- IF P_TIPO_RELAT = 'Aprovacao' THEN 

  gen_xml_p(' </HEADER>');

  gen_xml_p('</HEADERS>');

 END gen_relat_gl_status_p;

 PROCEDURE show_error_log_p(p_message IN VARCHAR2) IS
 BEGIN
  IF g_bShow_log THEN
    fnd_file.put_line(fnd_file.log, p_message);
  END IF;
 END show_error_log_p;

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER IS

  l_vDecimal_char VARCHAR2(1);

 BEGIN
  --> Recupera o character decimal
  l_vDecimal_char := substr(ltrim(to_char(.3, '0D0')), 2, 1);

  --> Transforma o varchar para um número com um decimal válido
  IF l_vDecimal_char = ',' THEN
    RETURN round(to_number(translate(p_value, '.', l_vDecimal_char)), 20);
  ELSE
    RETURN round(to_number(translate(p_value, ',', l_vDecimal_char)), 20);
  END IF;

 END canonical_to_number_f;
 --

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2 IS

  l_vReturn      VARCHAR2(20);
  l_nDecimal_qty NUMBER;
  l_nMask_qty    NUMBER;
  l_vMask        VARCHAR2(100);

 BEGIN

  l_vMask := p_mask;
  l_nMask_qty := length(substr(l_vMask, instr(l_vMask, '.') + 1));

  --> Verifica se deve criar uma máscara com mais de 3 decimais- INICIO
  IF l_nMask_qty > 3 THEN

    --> Verifica se há decimais no valor - INICIO
    IF instr(to_char(translate(p_value, ',', '.')), '.') = 0 THEN
      l_nDecimal_qty := 0;
    ELSE
      --> Armazena a quantidade de digitos de decimais
      l_nDecimal_qty := length(substr(to_char(translate(p_value, ',', '.')), instr(to_char(translate(p_value, ',', '.')), '.') + 1));
    END IF;

    --> Verifica se a mascara retornou menos que 2
    IF l_nDecimal_qty <= 2 THEN
      l_nDecimal_qty := 2;
    END IF;

    --> Gera uma novas máscara com a quantidade de decimais necessárias
    l_vMask := substr(l_vMask, 1,  instr(l_vMask, '.')) || rpad('0', l_nDecimal_qty, '0');

  END IF;

  l_vReturn := lpad(to_char(p_value, l_vMask), 20, ' ');
  l_vReturn := REPLACE( l_vReturn, ',', '@' );
  l_vReturn := REPLACE( l_vReturn, '.', ',' );
  l_vReturn := REPLACE( l_vReturn, '@', '.' );

  RETURN(trim(l_vReturn));

 END format_br_mask_f;
 --

 -- Função que retorna valor por extenso:
 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2 IS

  valor_string VARCHAR2(256);
  valor_conv   VARCHAR2(25);
  tres_digitos VARCHAR2(3);
  texto_string VARCHAR2(256);
  ind          NUMBER;

 BEGIN
  valor_conv := to_char(trunc((abs(valor) * 100)
                             ,0)
                       ,'0999999999999999999');
  valor_conv := substr(valor_conv
                      ,1
                      ,18) || '0' || substr(valor_conv
                                           ,19
                                           ,2);
  IF to_number(valor_conv) = 0 THEN
    RETURN('Zero ');
  END IF;

  FOR ind IN 1 .. 7 LOOP
    tres_digitos := substr(valor_conv
                          ,(((ind - 1) * 3) + 1)
                          ,3);
    texto_string := '';

    -- Extenso para Centena
    IF substr(tres_digitos
             ,1
             ,1) = '2' THEN
      texto_string := texto_string || 'Duzentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '3' THEN
      texto_string := texto_string || 'Trezentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '4' THEN
      texto_string := texto_string || 'Quatrocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '5' THEN
      texto_string := texto_string || 'Quinhentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '6' THEN
      texto_string := texto_string || 'Seiscentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '7' THEN
      texto_string := texto_string || 'Setecentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '9' THEN
      texto_string := texto_string || 'Novecentos ';
    END IF;

    IF substr(tres_digitos
             ,1
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,2
               ,2) = '00' THEN
        texto_string := texto_string || 'Cem ';
      ELSE
        texto_string := texto_string || 'Cento ';
      END IF;

    END IF;
    -- Extenso para Dezena
    IF substr(tres_digitos
             ,2
             ,1) <> '0'
       AND texto_string IS NOT NULL THEN
      texto_string := texto_string || 'e ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '2' THEN
      texto_string := texto_string || 'Vinte ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '3' THEN
      texto_string := texto_string || 'Trinta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '4' THEN
      texto_string := texto_string || 'Quarenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '5' THEN
      texto_string := texto_string || 'Cinquenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '6' THEN
      texto_string := texto_string || 'Sessenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '7' THEN
      texto_string := texto_string || 'Setenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '9' THEN
      texto_string := texto_string || 'Noventa ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,3
               ,1) <> '0' THEN

        IF substr(tres_digitos
                 ,3
                 ,1) = '1' THEN
          texto_string := texto_string || 'Onze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '2' THEN
          texto_string := texto_string || 'Doze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '3' THEN
          texto_string := texto_string || 'Treze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '4' THEN
          texto_string := texto_string || 'Quatorze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '5' THEN
          texto_string := texto_string || 'Quinze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '6' THEN
          texto_string := texto_string || 'Dezesseis ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '7' THEN
          texto_string := texto_string || 'Dezessete ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '8' THEN
          texto_string := texto_string || 'Dezoito ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '9' THEN
          texto_string := texto_string || 'Dezenove ';
        END IF;

      ELSE
        texto_string := texto_string || 'Dez ';
      END IF;

    ELSE

      -- Extenso para Unidade
      IF substr(tres_digitos
               ,3
               ,1) <> '0'
         AND texto_string IS NOT NULL THEN
        texto_string := texto_string || 'e ';
      END IF;

      IF substr(tres_digitos
               ,3
               ,1) = '1' THEN
        texto_string := texto_string || 'Um ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '2' THEN
        texto_string := texto_string || 'Dois ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '3' THEN
        texto_string := texto_string || 'Tres ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '4' THEN
        texto_string := texto_string || 'Quatro ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '5' THEN
        texto_string := texto_string || 'Cinco ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '6' THEN
        texto_string := texto_string || 'Seis ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '7' THEN
        texto_string := texto_string || 'Sete ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '8' THEN
        texto_string := texto_string || 'Oito ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '9' THEN
        texto_string := texto_string || 'Nove ';
      END IF;

    END IF;

    IF to_number(tres_digitos) > 0 THEN
      IF to_number(tres_digitos) = 1 THEN
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhão ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhão ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhão ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhão ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      ELSE
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhões ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhões ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhões ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhões ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      END IF;
    END IF;
    valor_string := valor_string || texto_string;
    -- Escrita da Moeda Corrente
    IF ind = 5 THEN
      IF to_number(substr(valor_conv
                         ,16
                         ,3)) > 0
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    ELSE
      IF ind < 5
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    END IF;
    IF ind = 6 THEN
      IF to_number(substr(valor_conv
                         ,1
                         ,18)) > 1 THEN
        valor_string := valor_string || 'Reais ';
      ELSIF to_number(substr(valor_conv
                            ,1
                            ,18)) = 1 THEN
        valor_string := valor_string || 'Real ';
      END IF;

      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 0
         AND length(valor_string) > 0 THEN
        valor_string := valor_string || 'e ';
      END IF;
    END IF;
    -- Escrita para Centavos
    IF ind = 7 THEN
      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 1 THEN
        valor_string := valor_string || 'Centavos ';
      ELSIF to_number(substr(valor_conv
                            ,20
                            ,2)) = 1 THEN
        valor_string := valor_string || 'Centavo ';
      END IF;
    END IF;
  END LOOP;
  RETURN(rtrim(valor_string));
 EXCEPTION
  WHEN OTHERS THEN
    RETURN('*** VALOR INVALIDO ***');
 END;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2 IS

  l_vChar VARCHAR2(4000) := p_char;

 BEGIN
  l_vChar := REPLACE(l_vChar, '&', '&amp;');
  l_vChar := REPLACE(l_vChar, '<', ';');
  l_vChar := REPLACE(l_vChar, '>', ';');
  l_vChar := REPLACE(l_vChar, '"', ';');
  l_vChar := REPLACE(l_vChar, '''', ';');
  l_vChar := REPLACE(l_vChar, 'º', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'C');
  l_vChar := REPLACE(l_vChar, 'ç', 'c');
  l_vChar := REPLACE(l_vChar, 'ç', 'c');
  l_vChar := REPLACE(l_vChar, 'ã', 'a');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'A');
  l_vChar := REPLACE(l_vChar, 'é', 'e');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'E');
  l_vChar := REPLACE(l_vChar, 'í', 'i');
  l_vChar := REPLACE(l_vChar, 'Í', 'I');
  l_vChar := REPLACE(l_vChar, 'ó', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'O');
  l_vChar := REPLACE(l_vChar, 'ú', 'u');
  l_vChar := REPLACE(l_vChar, 'ÿ', 'U');

  RETURN(l_vChar);
 END conv_spc_chr;
 --

 PROCEDURE gen_xml_p(p_message IN VARCHAR2) IS
 BEGIN
   IF g_bGen_XML THEN
     -- Gera Log de execucao
     dbms_output.put_line(p_message);
   ELSE
     -- Grava saida do concurrent:
     fnd_file.put_line(fnd_file.output,p_message);
   END IF;

 END gen_xml_p;
 --

END XXSTN_GL0002_PKG;
--Indicativo de Final de Arquivo. N�o deve ser removido.
/

show errors package body apps.XXSTN_GL0002_PKG 

EXIT
/

