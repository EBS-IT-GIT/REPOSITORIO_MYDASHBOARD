==============================================================================
CUSICX044_002: Novo Metodo de Rateio de Contas do Iproc
==============================================================================

Atualiza��o - CUSICX044_002
Produto     - XX Customizaciones
Data        - 15/04/2019 14:24:08
HotPatch    - S
Forncedor   - HQS Plus

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSICX044_002

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N�o h� tarefas nesta se��o.

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N�o h� pr�-requisitos para este patch.

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: PORCUSTB.pls
