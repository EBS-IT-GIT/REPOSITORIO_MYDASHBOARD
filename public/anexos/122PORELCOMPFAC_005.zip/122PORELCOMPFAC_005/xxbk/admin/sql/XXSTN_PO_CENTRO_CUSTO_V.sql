CREATE OR REPLACE VIEW XXSTN_PO_CENTRO_CUSTO_V AS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PO_CENTRO_CUSTO_V.sql                                     |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   PO - view para recuperar centros de custos                    |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S               (30/11/2018)     |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+
select distinct ffvcc.flex_value
       ,ffvcc.description 
from fnd_flex_value_sets ffvscc
    ,po_distributions_all pd
    ,gl_code_combinations gcccc
    ,fnd_flex_values_vl ffvcc
where pd.code_combination_id = gcccc.code_combination_id
and ffvcc.flex_value_set_id = ffvscc.flex_value_set_id
and gcccc.segment5 = ffvcc.flex_value
and ffvscc.flex_value_set_id = 1017450
--Indicativo de Final de Arquivo. Não deve ser removido.
/
EXIT
/
