set define off;
CREATE OR REPLACE PACKAGE XXSTN_PO_RELAT_FACILIT_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PO_RELAT_FACILIT_PKG.pls                                  |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   PO - Relatorio de Compras Facilities                          |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S               (30/11/2018)     |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

 PROCEDURE gen_relat_po_facilit_p (errbuf OUT VARCHAR2
                                  ,retcode OUT NUMBER
                                  ,P_UNID_OPER IN VARCHAR2
                                  ,P_DATA_DE IN VARCHAR2
                                  ,P_DATA_ATE IN VARCHAR2
                                  --,P_STATUS_APROV IN VARCHAR2
                                  ,P_DATA_VALID_BLANK IN VARCHAR2
                                  ,P_CENTRO_CUSTO IN VARCHAR2
                                  );

 PROCEDURE show_error_log_p(p_message IN VARCHAR2);

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER;

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2;

 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2;

 PROCEDURE gen_xml_p(p_message IN VARCHAR2);

END XXSTN_PO_RELAT_FACILIT_PKG;
--Indicativo de Final de Arquivo. N�o deve ser removido.
/

show errors package apps.XXSTN_PO_RELAT_FACILIT_PKG 

EXIT
/