  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_CORRIG_CARR_ETANOL_PKG" IS
  PROCEDURE XX_AUTO_CORR_CARR_COMP (p_errbuf  IN OUT VARCHAR2   -- Parametros obrigatorios quando for objeto do oracle EBS
                                ,p_retcode IN OUT VARCHAR2   -- Parametros obrigatorios quando for objeto do oracle EBS
                                -- damais parametros aqui
                                );
END;
--

/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_CORRIG_CARR_ETANOL_PKG" IS
-- Corpo da Package (body)
--
  PROCEDURE XX_AUTO_CORR_CARR_COMP (p_errbuf  IN OUT VARCHAR2   -- Parametros obrigatorios quando for objeto do oracle EBS
                                ,p_retcode IN OUT VARCHAR2   -- Parametros obrigatorios quando for objeto do oracle EBS

                                -- damais parametros aqui

                                ) IS
   ---------------
  -- VARIAVEIS --
  ---------------
  nCOUNT_UPDATE number := 0;
  nCOUNT_INSERT number := 0;
  V_EXIST       NUMBER;
  v_DATA_INI    VARCHAR2(30);
  SqlErro            VARCHAR2(240);
 
  /*  +=================================================================+
      |    Copyright (c) 2020 Adecoagro , Sao Paulo , Brasil            |
      |                         All rights reserved.                    |
      +=================================================================+
      |                                                                 |
      | FILENAME                                                        |
      |   XX_CORRIG_ENTREGA_COMP_ETANOL                                 |
      |                                                                 |
      | PURPOSE                                                         |
      |   Oracle                                                        |
      |   Produto : Oracle                                              |
      |   Objetivo: Procedure que Corrige Erros de Procedimento e entr  |
      |   do carregamento composto                                      |                                                  |
      |   Creation Date (DD/MM/YYYY): 07/02/2020                        |
      |   Created by - Adecoagro - Daniel Marques                       |
      |   Analista Funcional Oracle                                     |
      |   Update Date  Update By       Description                      |
      |                                                                 |
      +=================================================================+
-- Premissas
 --- 1 Esta Procedure corrige apenas carregamentos que eventualmente ficaram com seu valor de entrega
 -- maior que o valor de origem da linha, cuja tenha uma linha do mesmo percurso sobrando valor
 -- e que a soma total do percurso esteja identica ao do ticket, de forma a evitar erros e inconsistencias
 -- funcionais e operacionais. Caso o usuario atribua um valor errado, desatribua do percurso a mesma nao funciona
 -- adicionalmente so funciona para carregamentos de Etanol e compostos.
 -- Esta Concurrent NAO CORRIGE linhas que foram Interfaceadas com o Inventário
  */

  cursor c_0 is

   --> Cursorselect ooha.order_number    NUMERO_ORDEM
    select ooha.order_number    NUMERO_ORDEM
      ,xotb.TICKET_NUMERO   NUMERO_TICKET  
      ,oola.line_id         ID_LINHA
      ,oola.LINE_NUMBER     LINHA_DA_OV
      ,wdd.delivery_detail_id  ID_DETALHE_LINHA
      ,wdd.SPLIT_FROM_DELIVERY_DETAIL_ID DIV_LINHA_ID
      ,wdd.source_line_number NUMERO_DE_LINHA
      ,(select xbo2.PORCENTAJE_MERMA_HUMEDAD 
      from apps.XX_OM_TICKETS_BAL_BR xbo2 
      where NUM_DISTRIBUICAO = wt.trip_id) PESO_TICKET 
      ,(select sum(oola1.ordered_quantity) from 
       apps.oe_order_lines_all oola1 where oola1.line_id  = oola.line_id) SOMA_LINHA_ORDEM
      ,oola.PRICING_QUANTITY QNT_PRECIFC 
      ,(select sum(wdd1.REQUESTED_QUANTITY)
       from apps.wsh_delivery_details    wdd1
      ,apps.wsh_delivery_assignments wda1
      ,apps.wsh_new_deliveries       wnd1
      ,apps.wsh_trips                wt1
      ,apps.wsh_trip_stops           wts1
      ,apps.wsh_delivery_legs        wdl1
where  wnd1.delivery_id            =  wda1.delivery_id 
   and wda1.delivery_detail_id    =  wdd1.delivery_detail_id (+)
   and wt1.trip_id            =  wts1.trip_id 
   and wts1.stop_id           =  wdl1.drop_off_stop_id 
   and wdl1.delivery_id       =  wda1.delivery_id 
   and wdd1.SOURCE_LINE_ID = wdd.source_line_id) SOMA_ENT_LINHA
      ,(select sum(wdd1.REQUESTED_QUANTITY)
       from apps.wsh_delivery_details    wdd1
      ,apps.wsh_delivery_assignments wda1
      ,apps.wsh_new_deliveries       wnd1
      ,apps.wsh_trips                wt1
      ,apps.wsh_trip_stops           wts1
      ,apps.wsh_delivery_legs        wdl1
where  wnd1.delivery_id            =  wda1.delivery_id 
   and wda1.delivery_detail_id    =  wdd1.delivery_detail_id (+)
   and wt1.trip_id            =  wts1.trip_id 
   and wts1.stop_id           =  wdl1.drop_off_stop_id 
   and wdl1.delivery_id       =  wda1.delivery_id 
   and wt1.trip_id = wt.trip_id) SOMA_QNT_PERCURSO 
    ,wdd.SRC_REQUESTED_QUANTITY QUANT_ORIGEM_DISTR 
    ,wdd.REQUESTED_QUANTITY QNT_REQUISITADA  
    ,wda.delivery_id      NUMERO_DISTRIBUIÇAO
    ,wt.name              NUMERO_PERCURSO
    ,wt.trip_id            PERCURSO_ID
    ,wdd.DELIVERY_DETAIL_ID DELIVERY_LINE_ID
    ,oola.ORDERED_QUANTITY QNT_LINHA_OV
    ,xotb.QTDE_CARREGADA QNT_CARREGADA
    ,oola.inventory_item_id xaf_ITEM_ID
    ,wdd.SRC_REQUESTED_QUANTITY_UOM UNID_MED
    ,wdd.REQUESTED_QUANTITY2 QUANTID_2
    ,wdd.REQUESTED_QUANTITY_UOM QUANTID_UOM
    ,wdd.RELEASED_STATUS STATUS_LIBERACAO
    ,ooha.org_id xaf_org_id
    ,wdd.INV_INTERFACED_FLAG INTERFACE_INVENTARIO
    ,(select A.trx_number
      from APPS.RA_CUSTOMER_TRX_ALL       A,
      APPS.RA_CUSTOMER_TRX_LINES_ALL X
      where a.customer_trx_id = x.customer_trx_id
      and x.line_type = 'LINE'
      and ooha.org_id = a.org_id
      and to_char (wda.delivery_id) = X.INTERFACE_LINE_ATTRIBUTE3
      and to_char (ooha.order_number) = A.INTERFACE_HEADER_ATTRIBUTE1
      and rownum = 1) NF,
      oola.FLOW_STATUS_CODE NF_STATUS          
      from apps.oe_order_lines_all       oola
      ,apps.oe_order_headers_all     ooha
      ,apps.wsh_delivery_details    wdd
      ,apps.wsh_delivery_assignments wda
      ,apps.wsh_new_deliveries       wnd
      ,apps.wsh_trips                wt
      ,apps.wsh_trip_stops           wts
      ,apps.wsh_delivery_legs        wdl
      ,apps.XX_OM_TICKETS_BAL_BR     xotb
 where ooha.header_id           =  oola.header_id -- AMARRA O CABECALHO DA ORDEM A LINHA
   and wnd.delivery_id       =  wda.delivery_id  -- AMARRA O DETALHE DA ENTREGA A ENTREGA
   and wda.delivery_detail_id    =  wdd.delivery_detail_id (+) -- AMARRA O DETALHE DA ENTREGA A ENTREGA
   and wdd.source_line_id      =  oola.line_id (+) -- AMRRA A LINHA DA ORDEM A ENTRRGA DA ORDEM
   and wdd.source_header_id     =  ooha.header_id (+) -- AMARRA O CABECALHO A DETALHE DA ENTREGA
   and wt.trip_id            =  wts.trip_id  -- AMARRA A ENTREGA A PARADA DE PERCURSO
   and wts.stop_id           =  wdl.drop_off_stop_id  -- AMARRA A ENTREGA A PARADA DE PERCURSI
   and wdl.delivery_id       =  wda.delivery_id  -- AMARRA A PARADA DE PERCURSO A ENTRETA
   and xotb.NUM_DISTRIBUICAO =   wt.trip_id -- AMARRA O TICKET AO PERCURSO DO ORACLE
   and wdd.SRC_REQUESTED_QUANTITY_UOM = 'M3' -- SOMENTE ORDENS DE ALCOOL
   and wdd.INV_INTERFACED_FLAG <> 'Y' -- SOMENTE O QUE NAO FOI PARA O INVENTARIO
   and TO_NUMBER(wt.trip_id) in (select TO_NUMBER(NUM_DISTRIBUICAO) from apps.XX_OM_TICKETS_BAL_BR where CREATION_DATE > sysdate -7)
   -- Percursos vinculados nos TIckets e Tickets Criados há 7 dias.                                                    
   --------------------------------------------------
   and ooha.order_number in --ABAIXO E PARA PEGAR SOMENTE ORDENS DO QUAIS ESTAO COM A SOMA DA QUANTIDADE REQUISITRADA MAIOR QUE A LINHA APOS RETORNO DO MINIMODULO.
                             (select ooha.order_number        
                             from apps.oe_order_lines_all       oola
                             ,apps.oe_order_headers_all     ooha
                             ,apps.wsh_delivery_details    wdd
                             ,apps.wsh_delivery_assignments wda
                             ,apps.wsh_new_deliveries       wnd
                             ,apps.wsh_trips                wt
                             ,apps.wsh_trip_stops           wts
                             ,apps.wsh_delivery_legs        wdl
                             ,apps.XX_OM_TICKETS_BAL_BR     xotb
                             where ooha.header_id           =  oola.header_id
                             and wnd.delivery_id       =  wda.delivery_id 
                             and wda.delivery_detail_id    =  wdd.delivery_detail_id (+)
                             and wdd.source_line_id      =  oola.line_id (+)
                             and wdd.source_header_id     =  ooha.header_id (+)
                             and wt.trip_id            =  wts.trip_id 
                             and wts.stop_id           =  wdl.drop_off_stop_id 
                             and wdl.delivery_id       =  wda.delivery_id 
                             and xotb.NUM_DISTRIBUICAO =   wt.trip_id
                             -- Percursos vinculados nos TIckets e Tickets Criados há 7 dias.  
                             and TO_NUMBER(wt.trip_id) in (select TO_NUMBER(NUM_DISTRIBUICAO) from apps.XX_OM_TICKETS_BAL_BR where CREATION_DATE > sysdate -7)
                             and wdd.SRC_REQUESTED_QUANTITY_UOM = 'M3'
                             and wdd.INV_INTERFACED_FLAG <> 'Y' -- DESCOMENTAR DEPOIS
                             and (select sum(wdd1.REQUESTED_QUANTITY)
       from apps.wsh_delivery_details    wdd1
      ,apps.wsh_delivery_assignments wda1
      ,apps.wsh_new_deliveries       wnd1
      ,apps.wsh_trips                wt1
      ,apps.wsh_trip_stops           wts1
      ,apps.wsh_delivery_legs        wdl1
where  wnd1.delivery_id            =  wda1.delivery_id 
   and wda1.delivery_detail_id    =  wdd1.delivery_detail_id (+)
   and wt1.trip_id            =  wts1.trip_id 
   and wts1.stop_id           =  wdl1.drop_off_stop_id 
   and wdl1.delivery_id       =  wda1.delivery_id 
   and wdd1.SOURCE_LINE_ID = wdd.source_line_id) > (select sum(oola1.ordered_quantity) from 
       apps.oe_order_lines_all oola1 where oola1.line_id  = oola.line_id))  ;
  BEGIN
   For v_0 in c_0 Loop
     Exit When c_0%NotFound;
     
                     -----------------------
                     -- Altera os valores da Linha da Ordem a ficarem condizente 
                     -- com o valor da entrega e a linha precidicada de forma igual
                     
        
                    BEGIN
                        Update apps.oe_order_lines_all
                         set ordered_quantity = v_0.SOMA_ENT_LINHA,
                             PRICING_QUANTITY = v_0.SOMA_ENT_LINHA
                       where line_id = v_0.id_linha;
                    
                      --------------------------------------------------
                      --------------------------------------------------
                      
                      -- Atualiza a Linha da quantidade requisitada de forma a ficar igual
                      -- ao valor provindo do select.
                      update apps.wsh_delivery_details wdd
                         set SRC_REQUESTED_QUANTITY = v_0.SOMA_ENT_LINHA
                       where wdd.delivery_detail_id = v_0.ID_DETALHE_LINHA;
                    
                      nCOUNT_INSERT := nCOUNT_INSERT + 1;
                    
                      COMMIT;
                    
                    EXCEPTION
                      WHEN OTHERS THEN
                        sqlErro := SubStr(SqlErrm, 1, 240);
                    END;
                    
  End Loop; END;
END;
/

exit
