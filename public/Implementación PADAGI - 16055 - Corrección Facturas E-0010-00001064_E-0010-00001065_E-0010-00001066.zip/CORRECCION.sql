UPDATE apps.ra_customer_trx_all rct
SET    ship_to_site_use_id = DECODE(trx_number
             ,'E-0010-00001064',2718746
             ,'E-0010-00001065',2592746
             ,'E-0010-00001066', 206368
             ,trx_number)
WHERE  trx_number IN ('E-0010-00001064','E-0010-00001065','E-0010-00001066');
--3 Registros
