UPDATE apps.ap_invoice_distributions_all
SET     attribute5 = to_char((SELECT vendor_id 
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'GNP S.R.L.')), last_update_date = sysdate, last_updated_by = 2070
WHERE  org_id  = 102
AND    accounting_date BETWEEN '01-06-2020' AND '30-06-2020'
AND    attribute5 = to_char((SELECT vendor_id 
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'G.N.P.S.R.L.'));
--9 Registros   