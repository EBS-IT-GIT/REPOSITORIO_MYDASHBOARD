UPDATE apps.ap_invoice_distributions_all aid
SET    attribute2 = 'FC INTERNA', attribute3 = 'Y', last_update_date = sysdate, last_updated_by = 2070
WHERE  attribute4 = '0005-00036949'
AND    attribute5 = (SELECT vendor_id 
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name ='RUGGERO VACCARI Y ASOCIADOS S.A');
--6 Registros