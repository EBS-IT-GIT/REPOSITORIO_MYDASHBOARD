WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
CREATE OR REPLACE PACKAGE XXSTN_AR_CUSTOM_NEW AUTHID CURRENT_USER AS
  -- $HEADER: XXSTN_AR_CUSTOM_NEW_PKS.sql 120.0 00:00 15/05/2020 ninecon $
  -- +=================================================================+
  -- |               Copyright (c) 2017 STONE Pagamentos               |
  -- |                   All rights reserved.                          |
  -- +=================================================================+
  -- | FILENAME                                                        |
  -- | XXSTN_AR_CUSTOM_NEW_PKS.sql                                     |
  -- |                                                                 |
  -- | PURPOSE                                                         |
  -- |   Procedimentos criados para processamento da interface de      |
  -- | clientes e transacoes                                           |
  -- | utilizadas como proposito de chave estrangeira na carga clientes|
  -- | e transacoes dentro do AR, sincronizando as tabelas             |
  -- |                                                                 |
  -- | CREATED BY                                                      |
  -- |   Edgar Oliveira - Somma-it                        (21/06/2017) |
  -- |                                                                 |
  -- | ALTERED BY                                                      |
  -- |   Fernando Pavao - 3S               (26/07/2018)                |
  -- |     Melhorias no log do processo AR_TEXT_FILE_INVOICE_LOAD      |
  -- |e adequacao do programa de acordo com novo layout do arquivo     |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (01/10/2018)                |
  -- |     Alteracao na busca da nota para operacao de cancelamento    |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (27/11/2018)                |
  -- |    Criacao de novas incosistencias na carga do arquivo de       |
  -- | de clientes e melhorias no processo de atualizacao dos cadastros|
  -- | do cliente                                                      |
  -- |                                                                 |
  -- |   Emerson Vitiello - 3S             (02/01/2019)                |
  -- |    Regra para email do tipo Faturamento                         |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (23/01/2019)                |
  -- |    alteracao na logica do orig_sys_ref e batch_source           |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (14/05/2019)                |
  -- |    alteracao na regra do tamanho do logradouro                  |
  -- |                                                                 |
  -- |   Marcos Fumio - Ninecon            (15/05/2020)                |
  -- |    #SR-381687 - Ticket 319239                                   |
  -- |    Inclusao de novos campos na interface de clientes e notas.   |
  -- |                                                                 |
  -- +=================================================================+
  --
FUNCTION validy_cnpj(
    p_documento IN VARCHAR)
  RETURN BOOLEAN;
FUNCTION validy_cpf(
    p_documento IN VARCHAR)
  RETURN BOOLEAN;
PROCEDURE CUST_INTERF_LOAD_FILE(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2
   --, p_source         IN VARCHAR2
    ,
    p_file_name IN VARCHAR2);
  --
PROCEDURE CUST_INTERF_LOAD(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
    p_file_name IN VARCHAR2 );
  --
  /**
  * Processo pos interface de Clientes que cadastra o email
  * para envio da fatura ao cliente
  * caso tenha sido informado
  */
PROCEDURE SYNC_CUSTOMER_EMAIL_INVOICE(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
-- Emerson Vitiello 15/01/2019 - Atualização Email Faturamento
    p_file_name IN VARCHAR2);
-- Emerson Vitiello 15/01/2019 - Atualização Email Faturamento
  --
PROCEDURE PROCESSA_ITF_AR(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
    p_file_name IN VARCHAR2 --alt fpavao 23/01/2019
    );
  --
PROCEDURE AR_TEXT_FILE_INVOICE_LOAD(
    Errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
    P_FILE_NAME IN VARCHAR);
PROCEDURE ATUALIZA_CFOP(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2);
    
END XXSTN_AR_CUSTOM_NEW;
/

