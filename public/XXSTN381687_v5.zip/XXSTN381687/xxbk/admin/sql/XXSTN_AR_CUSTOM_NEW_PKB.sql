WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
CREATE OR REPLACE PACKAGE BODY XXSTN_AR_CUSTOM_NEW AS
  -- $HEADER: XXSTN_AR_CUSTOM_NEW.pls 120.1 00:00 15/05/2020 ninecon $
  -- +=================================================================+
  -- |               Copyright (c) 2017 STONE Pagamentos               |
  -- |                   All rights reserved.                          |
  -- +=================================================================+
  -- | FILENAME                                                        |
  -- | XXSTN_AR_CUSTOM_NEW.pls                                         |
  -- |                                                                 |
  -- | PURPOSE                                                         |
  -- |   Procedimentos criados para processamento da interface de      |
  -- | clientes e transacoes                                           |
  -- | utilizadas como proposito de chave estrangeira na carga clientes|
  -- | e transacoes dentro do AR, sincronizando as tabelas             |
  -- |                                                                 |
  -- | CREATED BY                                                      |
  -- |   Edgar Oliveira - Somma-it                        (21/06/2017) |
  -- |                                                                 |
  -- | ALTERED BY                                                      |
  -- |   Fernando Pavao - 3S               (26/07/2018)                |
  -- |     Melhorias no log do processo AR_TEXT_FILE_INVOICE_LOAD      |
  -- |e adequacao do programa de acordo com novo layout do arquivo     |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (01/10/2018)                |
  -- |     Alteracao na busca da nota para operacao de cancelamento    |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (27/11/2018)                |
  -- |    Criacao de novas incosistencias na carga do arquivo de       |
  -- | de clientes e melhorias no processo de atualizacao dos cadastros|
  -- | do cliente                                                      |
  -- |                                                                 |
  -- |   Emerson Vitiello - 3S             (02/01/2019)                |
  -- |    Regra para email do tipo Faturamento                         |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (23/01/2019)                |
  -- |    alteracao na logica do orig_sys_ref e batch_source           |
  -- |                                                                 |
  -- |   Fernando Pavao - 3S               (14/05/2019)                |
  -- |    alteracao na regra do tamanho do logradouro                  |
  -- |                                                                 |
  -- |   Marcos Fumio - Ninecon            (07/01/2020)                |
  -- |    #SR-433445 - Ticket 311637                                   |
  -- |    Alteracao na tratativa do nome, endereco, numero do endereco |
  -- |    e distrito.                                                  |
  -- |                                                                 |
  -- |   Marcos Fumio - Ninecon            (15/05/2020)                |
  -- |    #SR-381687 - Ticket 319239                                   |
  -- |    Inclusao de novos campos na interface de clientes e notas.   |
  -- |                                                                 |
  -- +=================================================================+
  --
  g_delim                   VARCHAR2(1)   := ';';
  G_ST_CUST_SUCCESS         VARCHAR2(200) := 'SUCCESS';
  G_ST_CUST_ERRO            VARCHAR2(200) := 'ERRO';
  G_MSG_CUST_INV_MAIL_OK    VARCHAR2(200) := 'Email Faturamento cadastrado';
  G_MSG_CUST_INV_MAIL_EXIST VARCHAR2(200) := 'Email Faturamento ja existente';
  G_MSG_CUST_INV_MAIL_ERRO  VARCHAR2(200) := 'Erro Email Faturamento';
  --
  G_MSG_CUST_ERR_TCA VARCHAR2(200) := 'COMBINACAO PAIS/ESTADO/CIDADE NAO CADASTRADA NO TCA';
  G_MSG_CUST_ERR_ORG VARCHAR2(200) := 'EMPRESA(ORG_CODE) NAO EXISTENTE';
  g_user_id          NUMBER        := FND_GLOBAL.USER_ID;
  g_login_id         NUMBER        := FND_GLOBAL.LOGIN_ID;
  g_org_id           NUMBER        := fnd_profile.value('ORG_ID');
  --
  --
  PROCEDURE OUT_L(
      P_TEXTO IN VARCHAR)
  IS
  BEGIN
    FND_FILE.PUT_LINE(FND_FILE.LOG, P_TEXTO);
  END OUT_l;
--
  PROCEDURE OUT_P(
      P_TEXTO IN VARCHAR)
  IS
  BEGIN
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, REPLACE(P_TEXTO,CHR(10), ''));
  END OUT_P;
--
  PROCEDURE INIT_AUDIT
  IS
  BEGIN
    g_user_id  := FND_GLOBAL.USER_ID;
    g_login_id := FND_GLOBAL.LOGIN_ID;
    g_org_id   := fnd_profile.value('ORG_ID');
  END INIT_AUDIT;
--
  PROCEDURE validy_org(
      x_org_id   IN OUT NUMBER,
      x_org_name IN OUT VARCHAR,
      x_ret_status OUT BOOLEAN)
  IS
  BEGIN
    XXSTN_AR_CUSTOM_UTIL_PK.validy_org(x_org_id, x_org_name, x_ret_status);
  END validy_org;
--
/*
*
* FUNGCO QUE VALIDA O DIGITO VERIFICADOR DO CNPJ, RETORNA TRUE OU FALSE
*/
  FUNCTION validy_cnpj(
      p_documento IN VARCHAR)
    RETURN BOOLEAN
  IS
    v_cnpj VARCHAR(20) := p_documento;
    v_d01  NUMBER      := 0;
    v_d02  NUMBER      := 0;
    --
  BEGIN
    IF LENGTH(v_cnpj) < 13 THEN
      RETURN false;
    END IF;
    v_cnpj := LPAD(v_cnpj, 14, '0');
    --
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 1, 1)) * 5;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 2, 1)) * 4;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 3, 1)) * 3;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 4, 1)) * 2;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 5, 1)) * 9;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 6, 1)) * 8;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 7, 1)) * 7;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 8, 1)) * 6;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 9, 1)) * 5;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 10, 1)) * 4;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 11, 1)) * 3;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cnpj, 12, 1)) * 2;
    --
    v_d01   := MOD(v_d01, 11);
    IF v_d01 < 2 THEN
      v_d01 := 0;
    ELSE
      V_D01 := 11 - V_D01;
    END IF;
    --
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 1, 1)) * 6);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 2, 1)) * 5);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 3, 1)) * 4);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 4, 1)) * 3);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 5, 1)) * 2);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 6, 1)) * 9);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 7, 1)) * 8);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 8, 1)) * 7);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 9, 1)) * 6);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 10, 1)) * 5);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 11, 1)) * 4);
    v_d02 := v_d02 + (TO_NUMBER(SUBSTR(v_cnpj, 12, 1)) * 3);
    v_d02 := v_d02 + (v_d01
    /*to_number( substr(v_cnpj,13,1) )*/
    * 2);
    --
    v_d02   := MOD(v_d02, 11);
    IF v_d02 < 2 THEN
      v_d02 := 0;
    ELSE
      v_d02 := 11 - v_d02;
    END IF;
    --
    IF TO_CHAR(v_d01) || TO_CHAR(v_d02) = SUBSTR(v_cnpj, 13, 2) THEN
      RETURN TRUE;
    ELSE
      --dbms_output.put_line('cnpj invC!lido');
      RETURN FALSE;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;
  END validy_cnpj;
--
/*
* FUNGCO QUE VALIDA O DIGITO VERIFICADOR DO CPF, RETORNA TRUE OU FALSE
*/
  FUNCTION validy_cpf(
      p_documento IN VARCHAR)
    RETURN BOOLEAN
  IS
    v_cpf VARCHAR(20) := p_documento;
    v_d01 NUMBER      := 0;
    v_d02 NUMBER      := 0;
    --
  BEGIN
    IF LENGTH(v_cpf) < 11 THEN
      RETURN false;
    END IF;
    --dbms_output.put_Line( 'CPF: ' || lpad(v_cpf,11,'0') );
    --v_cpf := lpad(v_cpf,11,'0');
    --
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 1, 1)) * 10;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 2, 1)) * 9;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 3, 1)) * 8;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 4, 1)) * 7;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 5, 1)) * 6;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 6, 1)) * 5;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 7, 1)) * 4;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 8, 1)) * 3;
    v_d01 := v_d01 + TO_NUMBER(SUBSTR(v_cpf, 9, 1)) * 2;
    --
    v_d01 := MOD(v_d01, 11);
    --
    IF v_d01 < 2 THEN
      v_d01 := 0;
    ELSE
      v_d01 := 11 - v_d01;
    END IF;
    --
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 1, 1)) * 11;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 2, 1)) * 10;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 3, 1)) * 9;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 4, 1)) * 8;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 5, 1)) * 7;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 6, 1)) * 6;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 7, 1)) * 5;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 8, 1)) * 4;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 9, 1)) * 3;
    v_d02 := v_d02 + TO_NUMBER(SUBSTR(v_cpf, 10, 1)) * 2;
    --
    v_d02   := MOD(v_d02, 11);
    IF v_d02 < 2 THEN
      v_d02 := 0;
    ELSE
      v_d02 := 11 - v_d02;
    END IF;
    --
    IF TO_CHAR(v_d01) || TO_CHAR(v_d02) = SUBSTR(v_cpf, 10, 2) THEN
      --dbms_output.put_line('cnpj valido');
      RETURN TRUE;
    ELSE
      --dbms_output.put_line('cnpj invC!lido');
      RETURN FALSE;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;
  END validy_cpf;
--
--
/*
*
* PROCEDIMENTO QUE CONCATENA A MENSAGEM AO TEXTO E RETORNA
*
*/
  PROCEDURE concat_message(
      p_message IN OUT VARCHAR,
      p_texto   IN VARCHAR)
  IS
  BEGIN
    IF LENGTH(p_message) = 0 THEN
      p_message         := p_texto;
    ELSE
      p_message := p_message || ', ' || p_texto;
    END IF;
  END concat_message;
--
/*
*FUNCAO AUXILIAR PARA RECUPERAR OS PARAMETROS PARA A INTERFACE DE CLIENTES
*
*/
  FUNCTION get_custint_lookup(
      p_org_name       IN VARCHAR,
      p_lookup_meaning IN VARCHAR)
    RETURN VARCHAR
  IS
    l_description apps.fnd_lookup_values.description%type;
  BEGIN
    SELECT DESCRIPTION
    INTO l_description
    FROM apps.fnd_lookup_values_vl
    WHERE lookup_type = 'STN_CUSTINT_'
      || p_org_name
    AND meaning = p_lookup_meaning;
    --
    RETURN l_description;
    --
  EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
  END get_custint_lookup;
--
  --
  FUNCTION get_custint_lookup_tag(
      p_org_name       IN VARCHAR,
      p_lookup_meaning IN VARCHAR)
    RETURN VARCHAR
  IS
    l_description apps.fnd_lookup_values.description%type;
  BEGIN
    SELECT TAG
      INTO l_description
      FROM apps.fnd_lookup_values_vl
     WHERE lookup_type = 'STN_CUSTINT_'
        || p_org_name
       AND meaning = p_lookup_meaning;
    --
    RETURN l_description;
    --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_custint_lookup_tag;

  --
/*
* FUNCAO AUXILIZAR PARA RECUPERAR OS PARAMETROS PARA A INTERFACE DE TRANSACOES
*/
  FUNCTION get_artrx_lookup(
      p_org_name       IN VARCHAR,
      p_lookup_meaning IN VARCHAR,
      p_cod_item       IN VARCHAR)
    RETURN VARCHAR
  IS
    l_description_org apps.fnd_lookup_values.description%type;
    l_description_item apps.fnd_lookup_values.description%type;
  BEGIN
    BEGIN
      --
      SELECT DESCRIPTION
      INTO l_description_org
      FROM apps.fnd_lookup_values_vl
      WHERE lookup_type LIKE 'STN_ARTRX_'
        || p_org_name
      AND meaning = p_lookup_meaning;
      --
    EXCEPTION
    WHEN OTHERS THEN
      l_description_org := '';
    END;
    --
    BEGIN
      --
      SELECT DESCRIPTION
      INTO l_description_item
      FROM apps.fnd_lookup_values_vl
      WHERE lookup_type LIKE 'STN_ARTRX_'
        || p_org_name
        || '%'
        || p_cod_item
      AND meaning = p_lookup_meaning;
      --
    EXCEPTION
    WHEN OTHERS THEN
      l_description_item := '';
    END;
    RETURN NVL(l_description_item, l_description_org);
    --
  EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
  END get_artrx_lookup;
  FUNCTION exists_artrx_lookup(
      p_org_name IN VARCHAR,
      p_cod_item IN VARCHAR)
    RETURN NUMBER
  IS
    l_count NUMBER := 0;
  BEGIN
    BEGIN
      SELECT COUNT(1)
      INTO l_count
      FROM apps.fnd_lookup_values_vl
      WHERE lookup_type LIKE 'STN_ARTRX_'
        || p_org_name
        || '%'
        || p_cod_item;
    EXCEPTION
    WHEN OTHERS THEN
      l_count := 0;
    END;
    RETURN l_count;
    --
  EXCEPTION
  WHEN OTHERS THEN
    RETURN l_count;
  END exists_artrx_lookup;
--
/*
Function get_artrx_lookup(
p_org_name       in varchar
, p_lookup_meaning in varchar
) return varchar is
Begin
return get_artrx_lookup(p_org_name, p_lookup_meaning,null );
End get_artrx_lookup;
*/
--
/*
* FUNCAO AUXILIAR PARA RECUPERAR O ORG_NAME DE ACORDO COM O ORG_ID INFORMADO
*/
  FUNCTION get_org_name(
      P_org_id IN NUMBER)
    RETURN VARCHAR
  IS
    l_retorno hr_operating_units.name%type;
  BEGIN
    SELECT name
    INTO l_retorno
    FROM apps.hr_operating_units
    WHERE organization_id = p_org_Id;
    --
    RETURN l_retorno;
  END get_org_name;
--
/*
* FUNCAO AUXILIAR PARA RECUPERAR O ORG_ID DE ACORDO COM O ORG_NAME INFORMADO
*/
  FUNCTION get_org_id(
      P_org_code IN VARCHAR)
    RETURN VARCHAR
  IS
    l_retorno hr_operating_units.organization_id%type;
  BEGIN
    SELECT organization_id
    INTO l_retorno
    FROM apps.hr_operating_units
    WHERE name = p_org_code;
    --
    RETURN l_retorno;
  END get_org_id;
/*
* PROCEDIMENTO CONCORRENTE QUE LE O REGISTRO NA INTERFACE CUSTOMIZADA
* E ESCREVE E PROCESSA PARA A INTERFACE DO AR.
*/
--
  PROCEDURE CUST_INTERF_LOAD(
      errbuf OUT VARCHAR2,
      retcode OUT VARCHAR2,
      p_file_name IN VARCHAR2 )
  IS
    CURSOR c_pend
    IS
      SELECT eci.*,
        eci.rowid AS xid
      FROM xxstn_customer_interface eci
      WHERE status = 'PEND'
        --and XXSTN_AR_CUSTOM_NEW_util_pk.IS_valid_org(eci.org_id) = 'Y'
      AND NVL(file_name, 'x') = NVL(p_file_name, 'x')
      AND ROWNUM             <= 500000;
    l_insert_update VARCHAR(1); --alt 3S 27/11/2018
    l_pend c_pend%rowtype;
    l_status BOOLEAN := true;
    l_create VARCHAR(1);
    l_party_name hz_parties.party_name%type;
    l_party_id                  NUMBER;
    l_location_id               NUMBER;
    l_rowid_hzp                 VARCHAR2(100);
    l_rowid_hzl                 VARCHAR2(100);
    l_hzp_object_version_number NUMBER;
    l_hzl_object_version_number NUMBER;
    l_cust_acct_site_id         NUMBER;
    -- Emerson Vitiello 15/01/2019 - Site_Use_ID do Metodo de Pagamento
    l_site_use_id NUMBER;
    -- Emerson Vitiello 15/01/2019 - Site_Use_ID do Metodo de Pagamento
    l_exist_interface         NUMBER;
    l_orig_system_address_ref VARCHAR(200);
    l_cust_account_id         NUMBER;
    l_orig_system fnd_lookup_values.description%type;
    l_payment_method_name    ra_cust_pay_method_int_all.payment_method_name%TYPE;

    l_rowid_prof rowid;
    l_count NUMBER := 0;
    r_cust_itf ra_customers_interface_all%rowtype;
    r_cust_prof_itf ra_customer_profiles_int_all%rowtype;
    r_cust_pmet_itf ra_cust_pay_method_int_all%rowtype;
    -- Emerson Vitiello 15/01/2019 - Tratamento do Metodo de Recebimento
    l_rPayMethod_Rec hz_payment_method_pub.payment_method_rec_type;
    l_ncust_rcpt_mthd_id ra_cust_receipt_methods.cust_receipt_method_id%TYPE;
    l_verror              VARCHAR2(2000);
    l_vstatus             VARCHAR2(20);
    l_nmsg_count          NUMBER;
    l_vmsg_data           VARCHAR2(2000);
    l_px_last_update_date DATE;
    l_last_update_date    DATE;
    -- Emerson Vitiello 15/01/2019 - Tratamento do Metodo de Recebimento
    --
    -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
    l_contributor_class       VARCHAR2(30);
    l_valid                   NUMBER;
    l_payment_method_name_sec ra_cust_pay_method_int_all.payment_method_name%TYPE;
    -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239

    PROCEDURE upd_st(
        p_status IN VARCHAR)
    IS
    BEGIN
      --
      UPDATE XXSTN_customer_interface
      SET status         = p_status,
        org_id           = l_pend.org_id,
        org_name         = l_pend.org_name,
        MESSAGE          = l_pend.message,
        last_update_date = sysdate,
        last_updated_by  = g_user_Id
      WHERE rowid        = l_pend.xid;
      --
    END upd_st;
  /**
  * Insere ou Atualiza o Contato no Local do Cliente.
  *
  */
  PROCEDURE set_contact_itf(
      P_CUSTOMER_REF IN VARCHAR,
      P_ADDRESS_REF  IN VARCHAR,
      P_CONTACT_REF  IN VARCHAR,
      P_ACTION       IN VARCHAR -- I OU U
      ,
      p_CONTACT_TYPE IN VARCHAR,
      P_CONTACT_NAME IN VARCHAR
      --,P_LAST_NAME     in varchar
      ,
      P_ORG_ID       IN NUMBER,
      P_EMAIL        IN VARCHAR,
      P_PHONE_NUMBER IN VARCHAR,
      P_AREA_CODE    IN VARCHAR)
  IS
    r_cust_cpia ra_contact_phones_int_all%rowtype;
    l_first_name VARCHAR2(1000);
    l_last_name  VARCHAR2(1000);
    l_pos        NUMBER;
  BEGIN
    l_pos := instr(P_CONTACT_NAME, ' ', 1);
    --
    IF l_pos        > 0 THEN
      l_first_name := trim(SUBSTR(P_CONTACT_NAME, 0, l_pos));
      l_last_name  := trim(SUBSTR(P_CONTACT_NAME, l_pos, LENGTH(P_CONTACT_NAME)));
    ELSE
      l_first_name := trim(p_contact_name);
      -- Emerson Vitiello 14/01/2019 - Corre��o Last Name n�o pode ser nulo
      -- l_last_name  := '';
      l_last_name := '';
      -- Emerson Vitiello 14/01/2019 - Corre��o Last Name n�o pode ser nulo
    END IF;
    r_cust_cpia                          := NULL;
    r_cust_cpia.ORIG_SYSTEM_CUSTOMER_REF := P_CUSTOMER_REF;
    r_cust_cpia.ORIG_SYSTEM_ADDRESS_REF  := P_ADDRESS_REF;
    r_cust_cpia.ORIG_SYSTEM_CONTACT_REF  := P_CONTACT_REF;
    r_cust_cpia.INSERT_UPDATE_FLAG       := P_ACTION;
    r_cust_cpia.CONTACT_FIRST_NAME       := l_first_name;
    r_cust_cpia.CONTACT_LAST_NAME        := l_last_name;
    r_cust_cpia.ORG_ID                   := P_ORG_ID;
    r_cust_cpia.last_update_date         := sysdate;
    r_cust_cpia.last_updated_by          := g_user_Id;
    r_cust_cpia.creation_date            := sysdate;
    r_cust_cpia.Created_by               := g_user_Id;
    --
    IF p_CONTACT_TYPE                        = 'PHONE' THEN
      r_cust_cpia.ORIG_SYSTEM_TELEPHONE_REF := P_CONTACT_REF || 'T';
      r_cust_cpia.TELEPHONE                 := P_PHONE_NUMBER;
      r_cust_cpia.TELEPHONE_AREA_CODE       := P_AREA_CODE;
      r_cust_cpia.TELEPHONE_TYPE            := 'GEN';
      r_cust_cpia.CONTACT_POINT_TYPE        := 'PHONE';
    END IF;
    ---
    IF p_CONTACT_TYPE                        = 'EMAIL' THEN
      r_cust_cpia.ORIG_SYSTEM_TELEPHONE_REF := P_CONTACT_REF || 'E';
      r_cust_cpia.email_address             := P_EMAIL;
      r_cust_cpia.CONTACT_POINT_TYPE        := 'EMAIL';
    END IF;
    --
    INSERT INTO ra_contact_phones_int_all VALUES r_cust_cpia;
    --
  END set_contact_itf;
--
/**
* Atualiza o Customer, Perfil e location
*/
  PROCEDURE update_customer_prof_loc
    (
      x_rowid_prof          IN OUT rowid,
      x_rowid_hzp           IN OUT rowid,
      x_rowid_hzl           IN OUT rowid,
      p_party_id            IN NUMBER,
      p_location_Id         IN NUMBER,
      p_obj_version_num_hzp IN NUMBER,
      p_obj_version_num_hzl IN NUMBER,
      p_customer_name       IN VARCHAR,
      p_address1            IN VARCHAR,
      p_address2            IN VARCHAR,
      p_address3            IN VARCHAR,
      p_address4            IN VARCHAR,
      p_city                IN VARCHAR,
      p_state               IN VARCHAR,
      p_postal_code         IN VARCHAR,
      p_country             IN VARCHAR
    )
  IS
  BEGIN
    apps.hz_organization_profiles_pkg.update_row(x_rowid => x_rowid_prof, x_organization_profile_id => NULL, x_party_id => NULL, x_organization_name => p_customer_name, x_attribute_category => NULL, x_attribute1 => NULL, x_attribute2 => NULL, x_attribute3 => NULL, x_attribute4 => NULL, x_attribute5 => NULL, x_attribute6 => NULL, x_attribute7 => NULL, x_attribute8 => NULL, x_attribute9 => NULL, x_attribute10 => NULL, x_attribute11 => NULL, x_attribute12 => NULL, x_attribute13 => NULL, x_attribute14 => NULL, x_attribute15 => NULL, x_attribute16 => NULL, x_attribute17 => NULL, x_attribute18 => NULL, x_attribute19 => NULL, x_attribute20 => NULL, x_enquiry_duns => NULL, x_ceo_name => NULL, x_ceo_title => NULL, x_principal_name => NULL, x_principal_title => NULL, x_legal_status => NULL, x_control_yr => NULL, x_employees_total => NULL, x_hq_branch_ind => NULL, x_branch_flag => NULL, x_oob_ind => NULL, x_line_of_business => NULL, x_cong_dist_code => NULL, x_sic_code => NULL, x_import_ind =>
    NULL, x_export_ind => NULL, x_labor_surplus_ind => NULL, x_debarment_ind => NULL, x_minority_owned_ind => NULL, x_minority_owned_type => NULL, x_woman_owned_ind => NULL, x_disadv_8a_ind => NULL, x_small_bus_ind => NULL, x_rent_own_ind => NULL, x_debarments_count => NULL, x_debarments_date => NULL, x_failure_score => NULL, x_failure_score_override_code => NULL, x_failure_score_commentary => NULL, x_global_failure_score => NULL, x_db_rating => NULL, x_credit_score => NULL, x_credit_score_commentary => NULL, x_paydex_score => NULL, x_paydex_three_months_ago => NULL, x_paydex_norm => NULL, x_best_time_contact_begin => NULL, x_best_time_contact_end => NULL, x_organization_name_phonetic => NULL, x_tax_reference => NULL, x_gsa_indicator_flag => NULL, x_jgzz_fiscal_code => NULL, x_analysis_fy => NULL, x_fiscal_yearend_month => NULL, x_curr_fy_potential_revenue => NULL, x_next_fy_potential_revenue => NULL, x_year_established => NULL, x_mission_statement => NULL, x_organization_type =>
    NULL, x_business_scope => NULL, x_corporation_class => NULL, x_known_as => NULL, x_local_bus_iden_type => NULL, x_local_bus_identifier => NULL, x_pref_functional_currency => NULL, x_registration_type => NULL, x_total_employees_text => NULL, x_total_employees_ind => NULL, x_total_emp_est_ind => NULL, x_total_emp_min_ind => NULL, x_parent_sub_ind => NULL, x_incorp_year => NULL, x_content_source_type => NULL, x_content_source_number => NULL, x_effective_start_date => NULL, x_effective_end_date => NULL, x_sic_code_type => NULL, x_public_private_ownership => NULL, x_local_activity_code_type => NULL, x_local_activity_code => NULL, x_emp_at_primary_adr => NULL, x_emp_at_primary_adr_text => NULL, x_emp_at_primary_adr_est_ind => NULL, x_emp_at_primary_adr_min_ind => NULL, x_internal_flag => NULL, x_high_credit => NULL, x_avg_high_credit => NULL, x_total_payments => NULL, x_known_as2 => NULL, x_known_as3 => NULL, x_known_as4 => NULL, x_known_as5 => NULL, x_credit_score_class => NULL,
    x_credit_score_natl_percentile => NULL, x_credit_score_incd_default => NULL, x_credit_score_age => NULL, x_credit_score_date => NULL, x_failure_score_class => NULL, x_failure_score_incd_default => NULL, x_failure_score_age => NULL, x_failure_score_date => NULL, x_failure_score_commentary2 => NULL, x_failure_score_commentary3 => NULL, x_failure_score_commentary4 => NULL, x_failure_score_commentary5 => NULL, x_failure_score_commentary6 => NULL, x_failure_score_commentary7 => NULL, x_failure_score_commentary8 => NULL, x_failure_score_commentary9 => NULL, x_failure_score_commentary10 => NULL, x_credit_score_commentary2 => NULL, x_credit_score_commentary3 => NULL, x_credit_score_commentary4 => NULL, x_credit_score_commentary5 => NULL, x_credit_score_commentary6 => NULL, x_credit_score_commentary7 => NULL, x_credit_score_commentary8 => NULL, x_credit_score_commentary9 => NULL, x_credit_score_commentary10 => NULL, x_maximum_credit_recomm => NULL, x_maximum_credit_currency_code => NULL,
    x_displayed_duns_party_id => NULL, x_failure_score_natnl_perc => NULL, x_duns_number_c => NULL, x_bank_or_branch_number => NULL, x_bank_code => NULL, x_branch_code => NULL, x_object_version_number => NULL, x_created_by_module => NULL, x_application_id => NULL, x_do_not_confuse_with => NULL, x_actual_content_source => NULL, x_version_number => NULL, x_home_country => NULL);
    --
    apps.HZ_PARTIES_PKG.Update_Row(X_Rowid => x_rowid_hzp, X_PARTY_ID => p_party_id, X_PARTY_NUMBER => NULL, X_PARTY_NAME => p_customer_name, X_PARTY_TYPE => NULL, X_VALIDATED_FLAG => NULL, X_ATTRIBUTE_CATEGORY => NULL, X_ATTRIBUTE1 => NULL, X_ATTRIBUTE2 => NULL, X_ATTRIBUTE3 => NULL, X_ATTRIBUTE4 => NULL, X_ATTRIBUTE5 => NULL, X_ATTRIBUTE6 => NULL, X_ATTRIBUTE7 => NULL, X_ATTRIBUTE8 => NULL, X_ATTRIBUTE9 => NULL, X_ATTRIBUTE10 => NULL, X_ATTRIBUTE11 => NULL, X_ATTRIBUTE12 => NULL, X_ATTRIBUTE13 => NULL, X_ATTRIBUTE14 => NULL, X_ATTRIBUTE15 => NULL, X_ATTRIBUTE16 => NULL, X_ATTRIBUTE17 => NULL, X_ATTRIBUTE18 => NULL, X_ATTRIBUTE19 => NULL, X_ATTRIBUTE20 => NULL, X_ATTRIBUTE21 => NULL, X_ATTRIBUTE22 => NULL, X_ATTRIBUTE23 => NULL, X_ATTRIBUTE24 => NULL, X_ORIG_SYSTEM_REFERENCE => NULL, X_SIC_CODE => NULL, X_HQ_BRANCH_IND => NULL, X_CUSTOMER_KEY => NULL, X_TAX_REFERENCE => NULL, X_JGZZ_FISCAL_CODE => NULL, X_PERSON_PRE_NAME_ADJUNCT => NULL, X_PERSON_FIRST_NAME => NULL,
    X_PERSON_MIDDLE_NAME => NULL, X_PERSON_LAST_NAME => NULL, X_PERSON_NAME_SUFFIX => NULL, X_PERSON_TITLE => NULL, X_PERSON_ACADEMIC_TITLE => NULL, X_PERSON_PREVIOUS_LAST_NAME => NULL, X_KNOWN_AS => NULL, X_PERSON_IDEN_TYPE => NULL, X_PERSON_IDENTIFIER => NULL, X_GROUP_TYPE => NULL, X_COUNTRY => p_country, X_ADDRESS1 => p_address1 --l_tag_lougradouro
    , X_ADDRESS2 => p_address2                                                                                                                                                                                                                                                                                                                --l_tag_numero
    , X_ADDRESS3 => p_address3                                                                                                                                                                                                                                                                                                                --l_tag_complemento
    , X_ADDRESS4 => p_address4                                                                                                                                                                                                                                                                                                                --l_tag_bairro
    , X_CITY => p_city                                                                                                                                                                                                                                                                                                                        --l_tag_cidade
    , X_POSTAL_CODE => p_postal_code                                                                                                                                                                                                                                                                                                          --l_tag_cep
    , X_STATE => p_state                                                                                                                                                                                                                                                                                                                      --l_tag_estado
    , X_PROVINCE => NULL, X_STATUS => NULL, X_COUNTY => p_country, X_SIC_CODE_TYPE => NULL, X_URL => NULL, X_EMAIL_ADDRESS => NULL, X_ANALYSIS_FY => NULL, X_FISCAL_YEAREND_MONTH => NULL, X_EMPLOYEES_TOTAL => NULL, X_CURR_FY_POTENTIAL_REVENUE => NULL, X_NEXT_FY_POTENTIAL_REVENUE => NULL, X_YEAR_ESTABLISHED => NULL, X_GSA_INDICATOR_FLAG => NULL, X_MISSION_STATEMENT => NULL, X_ORGANIZATION_NAME_PHONETIC => NULL, X_PERSON_FIRST_NAME_PHONETIC => NULL, X_PERSON_LAST_NAME_PHONETIC => NULL, X_LANGUAGE_NAME => NULL, X_CATEGORY_CODE => NULL, X_SALUTATION => NULL, X_KNOWN_AS2 => NULL, X_KNOWN_AS3 => NULL, X_KNOWN_AS4 => NULL, X_KNOWN_AS5 => NULL, X_OBJECT_VERSION_NUMBER => p_obj_version_num_hzp, X_DUNS_NUMBER_C => NULL, X_CREATED_BY_MODULE => NULL, X_APPLICATION_ID => NULL);
    --
    apps.hz_locations_pkg.update_row(x_rowid => x_rowid_hzl, x_location_id => p_location_Id, x_attribute_category => NULL, x_attribute1 => NULL, x_attribute2 => NULL, x_attribute3 => NULL, x_attribute4 => NULL, x_attribute5 => NULL, x_attribute6 => NULL, x_attribute7 => NULL, x_attribute8 => NULL, x_attribute9 => NULL, x_attribute10 => NULL, x_attribute11 => NULL, x_attribute12 => NULL, x_attribute13 => NULL, x_attribute14 => NULL, x_attribute15 => NULL, x_attribute16 => NULL, x_attribute17 => NULL, x_attribute18 => NULL, x_attribute19 => NULL, x_attribute20 => NULL, x_orig_system_reference => NULL, x_country => p_country, x_address1 => p_address1 --l_tag_lougradouro
    , x_address2 => p_address2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  --l_tag_numero
    , x_address3 => p_address3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  --l_tag_complemento
    , x_address4 => p_address4                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  --
    , x_city => p_city                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          --l_tag_cidade
    , x_postal_code => p_postal_code                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            --l_tag_cep
    , x_state => p_state                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        --l_tag_estado
    , x_province => NULL, x_county => p_country, x_address_key => NULL, x_address_style => NULL, x_validated_flag => NULL, x_address_lines_phonetic => NULL, x_po_box_number => NULL, x_house_number => NULL, x_street_suffix => NULL, x_street => NULL, x_street_number => NULL, x_floor => NULL, x_suite => NULL, x_postal_plus4_code => NULL, x_position => NULL, x_location_directions => NULL, x_address_effective_date => NULL, x_address_expiration_date => NULL, x_clli_code => NULL, x_language => NULL, x_short_description => NULL, x_description => NULL, x_content_source_type => NULL, x_loc_hierarchy_id => NULL, x_sales_tax_geocode => NULL, x_sales_tax_inside_city_limits => NULL, x_fa_location_id => NULL, x_geometry => NULL, x_object_version_number => p_obj_version_num_hzl, x_timezone_id => NULL, x_created_by_module => NULL, x_application_id => NULL, x_actual_content_source => NULL, x_geometry_status_code => NULL, x_delivery_point_code => NULL);
    NULL;
  END update_customer_prof_loc;
--
-- Check if exist rows in a interface with erros
  PROCEDURE CHECK_AND_CLEAN_CUST_INTF
    (
      P_ORG_ID   IN NUMBER,
      P_CNPJ_CPF IN VARCHAR,
      P_USE      IN VARCHAR
    )
  IS
    l_exist_interface NUMBER;
  BEGIN
    --
    IF P_USE = 'PAY_METHOD' THEN
      --
      SELECT COUNT(1)
      INTO l_exist_interface
      FROM ra_cust_pay_method_int_all
      WHERE org_id                 = P_org_id
      AND orig_system_customer_ref = P_cnpj_cpf;
      --
      IF l_exist_interface > 0 THEN
        DELETE ra_cust_pay_method_int_all
        WHERE org_id                 = P_org_Id
        AND orig_system_customer_ref = P_cnpj_cpf;
      END IF;
    ELSE
      --
      SELECT COUNT(1)
      INTO l_exist_interface
      FROM ra_customers_interface_all
      WHERE org_id                 = P_org_id
      AND orig_system_customer_ref = P_cnpj_cpf
      AND interface_status        IS NOT NULL
      AND site_use_code            = P_USE;
      --
      IF l_exist_interface > 0 THEN
        DELETE ra_customers_interface_all
        WHERE org_id                 = p_org_id
        AND orig_system_customer_ref = P_cnpj_cpf
        AND interface_status        IS NOT NULL
        AND site_use_code            = P_USE;
      END IF;
    END IF;
  END;
--
/**
* Checa se o Contato Existe para o cliente
* campo nome do contato utilizado como chave
* altera o Email/Telefone caso tenha sido alterado
* inclui um novo contato caso o nome nao exista cadastrado
*/
  PROCEDURE Check_and_Set_Contact(
      p_cust_account_id         IN NUMBER,
      p_cust_acct_site_id       IN NUMBER,
      p_cnpj_cpf                IN VARCHAR,
      p_orig_system_address_ref IN VARCHAR,
      p_contact_Name            IN VARCHAR,
      p_phone_number            IN VARCHAR,
      p_area_code               IN VARCHAR,
      p_email_address           IN VARCHAR,
      p_org_id                  IN NUMBER)
  IS
  BEGIN
    IF NVL(p_contact_Name, 'X') <> 'X' THEN
      DECLARE
        l_exist         BOOLEAN := false;
        l_count_contact NUMBER  := 0;
        l_first_name    VARCHAR2(1000);
        l_last_name     VARCHAR2(1000);
        l_pos           NUMBER;
        l_existe        NUMBER := 0;
      BEGIN
        -- Emerson Vitiello 14/01/2019 - Deixar no mesmo formato o contato
        l_pos := instr(P_CONTACT_NAME, ' ', 1);
        --
        IF l_pos        > 0 THEN
          l_first_name := trim(SUBSTR(P_CONTACT_NAME, 0, l_pos));
          l_last_name  := trim(SUBSTR(P_CONTACT_NAME, l_pos, LENGTH(P_CONTACT_NAME)));
        ELSE
          l_first_name := trim(p_contact_name);
          l_last_name  := '';
        END IF;
        -- Emerson Vitiello 14/01/2019 - Deixar no mesmo formato o contato
        FOR X IN
        (SELECT hcar.cust_account_role_id AS cari,
          hcar.party_id,
          hcar.cust_account_id,
          hcar.current_role_state,
          hcar.cust_acct_site_id,
          hcar.primary_flag,
          hcar.role_type,
          hcar.source_code,
          hcar.orig_system_reference,
          hcar.status,
          hpsub.party_name AS hpsub_party_name,
          hpsub.person_first_name,
          hpsub.person_last_name,
          hps.location_id,
          hprel.primary_phone_country_code,
          hprel.primary_phone_area_code,
          hprel.primary_phone_number,
          hprel.primary_phone_extension,
          hprel.primary_phone_line_type,
          hprel.email_address,
          hoc.job_title,
          hps.mailstop,
          ftv.territory_short_name  AS country,
          hps.orig_system_reference AS ps_reference,
          hpsub.party_id            AS sub_party_id,
          hpsub.party_type,
          hprel.party_id AS rel_party_id,
          hr.relationship_id
          --lookups.meaning job_title_code,
          ,
          hoc.contact_number,
          hr.status    AS rel_status,
          hpsub.status AS sub_status,
          hpobj.status AS obj_status
        FROM hz_cust_account_roles hcar,
          hz_parties hpsub,
          hz_parties hprel,
          hz_parties hpobj,
          hz_org_contacts hoc,
          hz_relationships hr,
          hz_party_sites hps,
          fnd_territories_vl ftv,
          hz_cust_accounts act
        WHERE hcar.role_type                         = 'CONTACT'
        AND hcar.party_id                            = hr.party_id
        AND hr.party_id                              = hprel.party_id
        AND hr.subject_id                            = hpsub.party_id
        AND hr.object_id                             = hpobj.party_id
        AND hoc.party_relationship_id                = hr.relationship_id
        AND hcar.cust_account_id                     = act.cust_account_id
        AND act.party_id                             = hr.object_id
        AND hps.party_id(+)                          = hprel.party_id
        AND NVL(hps.identifying_address_flag(+),'Y') = 'Y'
        AND NVL(hps.status(+), 'A')                  = 'A'
        AND hprel.country                            = ftv.territory_code(+)
        AND hcar.cust_account_id                     = p_cust_account_id   --5382
        AND NVL(hcar.cust_acct_site_id, 1)           = p_cust_acct_site_id --24047
          -- Emerson Vitiello 14/01/2019 - Corre��o Last Name
          --AND UPPER(hpsub.person_first_name)           = upper(p_contact_name)
        AND UPPER(hpsub.person_first_name) = upper(l_first_name)
        AND UPPER(hpsub.person_last_name)  = upper(NVL(l_last_name,' '))
          -- Emerson Vitiello 14/01/2019 - Corre��o Last Name
        AND hcar.status = 'A'
        )
        LOOP
          l_exist := true;
          OUT_P('       Contato Existente : ' || p_contact_name);
          OUT_P('       Email    : ' || x.EMAIL_ADDRESS);
          OUT_P('       Telefone : ' || x.primary_phone_number);
          IF NVL(x.primary_phone_number, 'X') <> NVL(p_phone_number, 'X') THEN
            -- atualizar telefone
            --
            OUT_P('       Telefone alterado : ' || x.primary_phone_number);
            set_contact_itf(P_CUSTOMER_REF => p_cnpj_cpf, P_ADDRESS_REF => p_orig_system_address_ref, P_CONTACT_REF => x.orig_system_reference, P_ACTION => 'U' -- I OU U
            , p_CONTACT_TYPE => 'PHONE', P_Contact_Name => p_contact_name, P_ORG_ID => p_org_Id, P_EMAIL => NULL, P_PHONE_NUMBER => p_phone_number, P_AREA_CODE => p_area_code);
          ELSE
            OUT_P('       Nao existe alteracao de telefone.');
          END IF;
          --
          IF NVL(x.email_address, 'X') <> NVL(p_email_address, 'X') THEN
            -- atualizar email
            --
            OUT_P('       Email alterado : ' || p_EMAIL_ADDRESS);
            set_contact_itf(P_CUSTOMER_REF => p_cnpj_cpf, P_ADDRESS_REF => p_orig_system_address_ref, P_CONTACT_REF => X.ORIG_SYSTEM_REFERENCE, P_ACTION => 'U' -- I OU U
            , p_CONTACT_TYPE => 'EMAIL', p_contact_name => p_contact_name, P_ORG_ID => p_org_Id, P_EMAIL => p_EMAIL_ADDRESS, P_PHONE_NUMBER => NULL, P_AREA_CODE => NULL);
            --
          ELSE
            OUT_P('       Nao existe alteracao de Email.');
          END IF;
        END LOOP;
        IF l_exist = false THEN
          -- CRIAR NOVO CONTATO NO LOCAL DO FORNECEDOR -- PRATICAMENTE IGUAL AO INSERT ANTERIOR ????
          IF NVL(p_contact_name, 'X') <> 'X' AND (NVL(p_phone_number, 'X') <> 'X' OR NVL(p_EMAIL_ADDRESS, 'X') <> 'X') THEN
            OUT_P('       Adicionando novo contato : ' || p_contact_name);
            OUT_P('       Email    : ' || p_EMAIL_ADDRESS);
            OUT_P('       Telefone : ' || p_phone_number);
            --
            SELECT COUNT(hcar.party_id)
            INTO l_count_contact
            FROM hz_cust_account_roles hcar,
              hz_parties hpsub,
              hz_parties hprel,
              hz_parties hpobj,
              hz_org_contacts hoc,
              hz_relationships hr,
              hz_party_sites hps,
              fnd_territories_vl ftv,
              hz_cust_accounts act
            WHERE hcar.role_type                          = 'CONTACT'
            AND hcar.party_id                             = hr.party_id
            AND hr.party_id                               = hprel.party_id
            AND hr.subject_id                             = hpsub.party_id
            AND hr.object_id                              = hpobj.party_id
            AND hoc.party_relationship_id                 = hr.relationship_id
            AND hcar.cust_account_id                      = act.cust_account_id
            AND act.party_id                              = hr.object_id
            AND hps.party_id(+)                           = hprel.party_id
            AND NVL(hps.identifying_address_flag(+), 'Y') = 'Y'
            AND hprel.country                             = ftv.territory_code(+)
            AND hcar.cust_account_id                      = p_cust_account_id   --5382
            AND NVL(hcar.cust_acct_site_id, 1)            = p_cust_acct_site_id --24047
              ;
            --
            l_count_contact := l_count_contact + 1;
            -- Insere o Telefone na Interface
            IF NVL(p_phone_number, 'X') <> 'X' THEN
              set_contact_itf(P_CUSTOMER_REF => p_cnpj_cpf, P_ADDRESS_REF => p_orig_system_address_ref, P_CONTACT_REF => p_orig_system_address_ref || '.' || l_count_contact, P_ACTION => 'I' -- I OU U
              , p_CONTACT_TYPE => 'PHONE', p_contact_name => p_contact_name, P_ORG_ID => p_org_Id, P_EMAIL => NULL, P_PHONE_NUMBER => p_phone_number, P_AREA_CODE => p_area_code);
            END IF;
            IF NVL(p_EMAIL_ADDRESS, 'X') <> 'X' THEN
              -- Insere Email na Interface
              set_contact_itf(P_CUSTOMER_REF => p_cnpj_cpf, P_ADDRESS_REF => p_orig_system_address_ref, P_CONTACT_REF => p_orig_system_address_ref || '.' || l_count_contact, P_ACTION => 'I' -- I OU U
              , p_CONTACT_TYPE => 'EMAIL', p_contact_name => p_contact_name, P_ORG_ID => p_org_Id, P_EMAIL => p_EMAIL_ADDRESS, P_PHONE_NUMBER => NULL, P_AREA_CODE => NULL);
            END IF;
          END IF;
        END IF;
      END;
    END IF;
  END Check_and_Set_Contact;
BEGIN
  INIT_AUDIT;
  out_p('Carga de Clientes - Inicio : ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
  --
  out_p(rpad('Codigo', 18, ' ') || ' ' || rpad('Cliente', 35, ' ') || ' ' || rpad('Empresa', 20, ' '));
  --
  out_p(rpad('-', 18, '-') || ' ' || rpad('-', 35, '-') || ' ' || rpad('-', 20, '-'));
  OPEN c_pend;
  LOOP
    FETCH c_pend INTO l_pend;
    EXIT
  WHEN c_pend%notfound;
    l_status := true;
    --
    validy_org(x_org_id => l_pend.org_id, x_org_name => l_pend.org_name, x_ret_status => l_status);
    --
    out_p(rpad(l_pend.cnpj_cpf, 18, ' ') || ' ' || rpad(l_pend.customer_name, 35, ' ') || ' ' || rpad(l_pend.org_name, 20, ' '));
    -- verifica se cliente ja existe
    --if l_status = true then --alt 3S 27/11/2018
    BEGIN
      SELECT 'N',
        hz_p.party_name,
        hz_p.party_id,
        hz_loc.location_id,
        hz_p.rowid,
        hz_loc.rowid,
        hz_p.object_version_number,
        hz_loc.object_version_number,
        hz_casa.CUST_ACCT_SITE_ID,
        hz_ca.cust_account_id,
        hz_casa.orig_system_reference,
        -- Emerson Vitiello 15/01/2019 - Obter Site_Use_ID para atualiza��o do Metodo de Pagamento
        hz_csua.site_use_id
        -- Emerson Vitiello 15/01/2019 - Obter Site_Use_ID para atualiza��o do Metodo de Pagamento
      INTO l_create,
        l_party_name,
        l_party_id,
        l_location_id,
        l_rowid_hzp,
        l_rowid_hzl,
        l_hzp_object_version_number,
        l_hzl_object_version_number,
        l_cust_acct_site_id,
        l_cust_account_id,
        l_orig_system_address_ref,
        -- Emerson Vitiello 15/01/2019 - Obter Site_Use_ID para atualiza��o do Metodo de Pagamento
        l_site_use_id
        -- Emerson Vitiello 15/01/2019 - Obter Site_Use_ID para atualiza��o do Metodo de Pagamento
      FROM hz_party_sites hz_ps,
        hz_cust_acct_sites_all hz_casa,
        hz_parties hz_p,
        hz_cust_accounts hz_ca,
        hz_cust_site_uses_all hz_csua,
        hz_locations hz_loc
      WHERE hz_casa.party_site_id   = hz_ps.party_site_id
      AND hz_ps.status              = 'A'
      AND hz_casa.cust_account_id   = hz_ca.cust_account_id
      AND hz_casa.org_id            = l_pend.org_id
      AND hz_casa.status            = 'A'
      AND hz_p.party_id             = hz_ps.party_id
      AND hz_p.status               = 'A'
      AND hz_csua.site_use_code     = 'BILL_TO'
      AND hz_ca.party_id            = hz_p.party_id
      AND hz_ca.STATUS              = 'A'
      AND hz_ps.location_id         = hz_loc.location_id
      AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
      AND hz_casa.status            = 'A'
      AND hz_ca.account_number      = l_pend.cnpj_cpf;
    EXCEPTION
    WHEN no_data_found THEN
      -- Se o Cliente ja existe na interface
      -- apaga para inserir o registro mais atual
      --
      DELETE ra_customers_interface_all
      WHERE org_id                 = l_pend.org_id
      AND orig_system_customer_ref = l_pend.cnpj_cpf;
      -- Check if exist rows in a interface with erros
      CHECK_AND_CLEAN_CUST_INTF(l_pend.org_Id, l_pend.cnpj_cpf, 'BILL_TO');
      CHECK_AND_CLEAN_CUST_INTF(l_pend.org_Id, l_pend.cnpj_cpf, 'SHIP_TO');
      CHECK_AND_CLEAN_CUST_INTF(l_pend.org_Id, l_pend.cnpj_cpf, 'PAY_METHOD');
      --
      l_create := 'Y';
    WHEN TOO_MANY_ROWS THEN
      l_create := 'N';
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001, 'Error to find Customer [' || l_pend.cnpj_cpf || ']-' || SQLERRM);
    END;
    --
    l_pend.customer_name := SUBSTR(l_pend.customer_name, 1, 250); --- 120.17 -- 04/Set/2015
    l_pend.city          := SUBSTR(l_pend.city, 1, 60);           --- 120.17 -- 04/Set/2015
    --
    IF l_create = 'Y' THEN --alt 3S 27/11/2018
      -- null;
      OUT_P('Acao : Cadastrar como Cliente.');
      l_pend.message        := 'CREATE';
      --
      -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
      --l_payment_method_name := get_custint_lookup(l_pend.org_name, 'METODO DE RECEBIMENTO'); --fnd_profile.value('XXSTN_AR_CUST_RECEIPT_MET');
      l_payment_method_name     := NULL;
      l_payment_method_name_sec := NULL;
      l_contributor_class       := NULL;
      IF l_pend.receipt_method_name IS NOT NULL THEN
        BEGIN
          SELECT NAME
            INTO l_payment_method_name
            FROM ar_receipt_methods
           WHERE NAME = l_pend.receipt_method_name;
        EXCEPTION
          WHEN OTHERS THEN
            l_payment_method_name     := get_custint_lookup(l_pend.org_name, 'METODO DE RECEBIMENTO');
            l_payment_method_name_sec := get_custint_lookup_tag(l_pend.org_name, 'METODO DE RECEBIMENTO');
        END;
      ELSE
        l_payment_method_name     := get_custint_lookup(l_pend.org_name, 'METODO DE RECEBIMENTO');
        l_payment_method_name_sec := get_custint_lookup_tag(l_pend.org_name, 'METODO DE RECEBIMENTO');
      END IF;
      --
      -- CLASSE DE CONTRIBUINTE
      IF l_pend.contributor_class IS NOT NULL THEN
        --
        SELECT COUNT(1)
          INTO l_valid
          FROM apps.jl_zz_ar_tx_att_val_v
        WHERE  org_id             = l_pend.org_id
          AND tax_attribute_type  = 'CONTRIBUTOR_ATTRIBUTE'
          AND tax_attribute_name  = 'CONTRIBUTOR_TYPE'
          AND tax_attribute_value = l_pend.contributor_class;
        --
        IF l_valid > 0 THEN
          l_contributor_class := l_pend.contributor_class;
        ELSE
          l_contributor_class := 'NAO CONTRIBUINTE';
        END IF;
      ELSE
        l_contributor_class := 'NAO CONTRIBUINTE';
      END IF;
      --
      -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
      --
      l_orig_system         := get_custint_lookup(l_pend.org_name, 'SIGLA DE ORIGEM');
      OUT_L('Org Name: ' || l_pend.org_name);
      OUT_L('METODO DE RECEBIMENTO: ' || l_payment_method_name);
      OUT_L('Sigla Origem         : ' || l_orig_system);
      --
      BEGIN
        SELECT XXSTN_AR_BR_ADD_S.NEXTVAL INTO l_orig_system_address_ref FROM dual;
      EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20010, 'Error selecting into XXAR_ELA_BR_ADD_S sequence - ' || SQLERRM);
      END;
      --
      -- verifica se ja existe na interface o metodo de recebimento
      --
      CHECK_AND_CLEAN_CUST_INTF(l_pend.org_Id, l_pend.cnpj_cpf, 'PAY_METHOD');
      --
      --IF l_tag_lougradouro IS NOT NULL THEN
      BEGIN
        r_cust_pmet_itf                          := NULL;
        r_cust_pmet_itf.orig_system_customer_ref := l_pend.cnpj_cpf;
        r_cust_pmet_itf.payment_method_name      := l_payment_method_name;
        r_cust_pmet_itf.primary_flag             := 'Y';
        r_cust_pmet_itf.orig_system_address_ref  := l_orig_system || '_' || l_orig_system_address_ref;
        r_cust_pmet_itf.start_date               := SYSDATE - 60;
        r_cust_pmet_itf.last_update_date         := SYSDATE;
        r_cust_pmet_itf.last_updated_by          := g_user_id;
        r_cust_pmet_itf.created_by               := g_user_id;
        r_cust_pmet_itf.creation_date            := SYSDATE;
        r_cust_pmet_itf.org_id                   := l_pend.org_id;
        --

        --
        INSERT INTO  ra_cust_pay_method_int_all VALUES r_cust_pmet_itf;
        --
        -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
        IF l_payment_method_name_sec IS NOT NULL THEN
          r_cust_pmet_itf                          := NULL;
          r_cust_pmet_itf.orig_system_customer_ref := l_pend.cnpj_cpf;
          r_cust_pmet_itf.payment_method_name      := l_payment_method_name_sec;
          r_cust_pmet_itf.primary_flag             := 'N';
          r_cust_pmet_itf.orig_system_address_ref  := l_orig_system || '_' || l_orig_system_address_ref;
          r_cust_pmet_itf.start_date               := SYSDATE - 60;
          r_cust_pmet_itf.last_update_date         := SYSDATE;
          r_cust_pmet_itf.last_updated_by          := g_user_id;
          r_cust_pmet_itf.created_by               := g_user_id;
          r_cust_pmet_itf.creation_date            := SYSDATE;
          r_cust_pmet_itf.org_id                   := l_pend.org_id;
          --
          INSERT INTO  ra_cust_pay_method_int_all VALUES r_cust_pmet_itf;
        END IF;
        -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
        --
      EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20010, 'Error : inserting into  table to the Customer Name ' || l_pend.customer_name || ' - ' || SQLERRM);
      END;
      --
      -- Check if exist rows in a interface with erros
      CHECK_AND_CLEAN_CUST_INTF(l_pend.org_Id, l_pend.cnpj_cpf, 'BILL_TO');
      --
      -- Check if the customer should be exists in interface table
      BEGIN
        SELECT COUNT(1)
        INTO l_exist_interface
        FROM ra_customers_interface_all
        WHERE orig_system_customer_ref = l_pend.cnpj_cpf; --decode(i.customer_type,'1',substrb(i.cnpj_cpf,1,8), substr(i.cnpj_cpf,1,length(i.cnpj_cpf)-2));
      END;
      --
      r_cust_itf := NULL;
      -- BILL_TO
      r_cust_itf.orig_system_customer_ref := l_pend.cnpj_cpf;
      r_cust_itf.site_use_code            := 'BILL_TO';
      r_cust_itf.orig_system_address_ref  := l_orig_system || '_' || l_orig_system_address_ref;
      r_cust_itf.insert_update_flag       := 'I';
      r_cust_itf.validated_flag           := 'Y';
      r_cust_itf.customer_name            := l_pend.customer_name; --l_tag_razao_social;
      r_cust_itf.customer_number          := l_pend.cnpj_cpf;
      r_cust_itf.customer_status          := 'A';
      r_cust_itf.customer_type            := 'R';
      --
      SELECT DECODE(l_exist_interface, 0, 'Y', 'N')
      INTO r_cust_itf.primary_site_use_flag
      FROM dual;
      --
      r_cust_itf.address1               := l_pend.address;                    --l_tag_lougradouro                                                            -- ;
      r_cust_itf.address2               := l_pend.address_number;             --l_tag_numero                                                                 --
      r_cust_itf.address3               := l_pend.additional_information;     --l_tag_complemento                                                            --
      r_cust_itf.address4               := l_pend.district;                   --l_tag_bairro - rbs 2018/01/02
      r_cust_itf.city                   := l_pend.city;                       --l_tag_cidade
      r_cust_itf.state                  := l_pend.state;                      --l_tag_estado
      r_cust_itf.postal_code            := REPLACE(l_pend.zip_code, '-', ''); --l_tag_cep
      r_cust_itf.country                := l_pend.country;                    --'BR';
      r_cust_itf.county                 := l_Pend.country;
      r_cust_itf.customer_category_code := 'CUSTOMER';
      r_cust_itf.last_updated_by        := g_user_id;
      r_cust_itf.last_update_date       := SYSDATE;
      r_cust_itf.created_by             := g_user_id;
      r_cust_itf.creation_date          := SYSDATE;
      r_cust_itf.last_update_login      := g_login_id;
      r_cust_itf.org_id                 := l_pend.org_Id;
      r_cust_itf.customer_prospect_code := 'CUSTOMER';
      r_cust_itf.gdf_address_attr_cat   := 'JL.BR.ARXCUDCI.Additional';
      r_cust_itf.gdf_address_attribute1 := NULL;
      --
      --if length(l_pend.cnpj_cpf) = 14 then -- CNPJ
      IF validy_cnpj(l_pend.cnpj_cpf)      = true THEN
        r_cust_itf.gdf_address_attribute2 := '2';
        r_cust_itf.gdf_address_attribute3 := '0' || SUBSTR(lpad(l_pend.cnpj_cpf, 14, '0'), 0, 8);
        r_cust_itf.gdf_address_attribute4 := SUBSTR(lpad(l_pend.cnpj_cpf, 14, '0'), 9, 4);
        r_cust_itf.gdf_address_attribute5 := SUBSTR(lpad(l_pend.cnpj_cpf, 14, '0'), 13, 2);
      elsif r_cust_itf.city                = 'EX' AND r_cust_itf.state = 'EX' THEN
        -- OUTROS - INTERNACIONAL
        r_cust_itf.gdf_address_attribute2 := '3';
        r_cust_itf.gdf_address_attribute3 := '000000000';
        r_cust_itf.gdf_address_attribute4 := '0000';
        r_cust_itf.gdf_address_attribute5 := '00';
      elsif validy_cpf(l_pend.cnpj_cpf)    = true THEN
        r_cust_itf.gdf_address_attribute2 := '1';
        r_cust_itf.gdf_address_attribute3 := SUBSTR(l_pend.cnpj_cpf, 0, 9);
        r_cust_itf.gdf_address_attribute4 := '0000';
        r_cust_itf.gdf_address_attribute5 := SUBSTR(l_pend.cnpj_cpf, 10, 2);
      ELSE
        -- OUTROS - INTERNACIONAL
        r_cust_itf.gdf_address_attribute2 := '3';
        r_cust_itf.gdf_address_attribute3 := '000000000';
        r_cust_itf.gdf_address_attribute4 := '0000';
        r_cust_itf.gdf_address_attribute5 := '00';
      END IF;
      --
      -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
      -- r_cust_itf.gdf_address_attribute8 := 'NAO CONTRIBUINTE';
      r_cust_itf.gdf_address_attribute8 := l_contributor_class;
      -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239

      --
      INSERT INTO ra_customers_interface_all VALUES r_cust_itf;
      --
      -- SHIP_TO
      r_cust_itf.orig_system_customer_ref := l_pend.cnpj_cpf;
      r_cust_itf.site_use_code            := 'SHIP_TO';
      r_cust_itf.orig_system_address_ref  := l_orig_system || '_' || l_orig_system_address_ref;
      r_cust_itf.insert_update_flag       := 'I';
      r_cust_itf.validated_flag           := 'Y';
      r_cust_itf.customer_name            := l_pend.customer_name; --l_tag_razao_social;
      r_cust_itf.customer_number          := l_pend.cnpj_cpf;
      r_cust_itf.customer_status          := 'A';
      r_cust_itf.customer_type            := 'R';
      r_cust_itf.primary_site_use_flag    := 'N';
      r_cust_itf.address1                 := l_pend.address;                --l_tag_lougradouro                                                            -- ;
      r_cust_itf.address2                 := l_pend.address_number;         --l_tag_numero                                                                 --
      r_cust_itf.address3                 := l_pend.additional_information; --l_tag_complemento                                                            --
      r_cust_itf.address4                 := l_pend.district;               --l_tag_bairro
      r_cust_itf.city                     := l_pend.city;                   --l_tag_cidade
      r_cust_itf.state                    := l_pend.state;                  --l_tag_estado
      r_cust_itf.postal_code              := l_pend.zip_code;               --l_tag_cep
      r_cust_itf.country                  := l_pend.country;
      r_cust_itf.county                   := l_pend.country;
      r_cust_itf.customer_category_code   := 'CUSTOMER';
      r_cust_itf.last_updated_by          := g_user_id;
      r_cust_itf.last_update_date         := SYSDATE;
      r_cust_itf.created_by               := g_user_id;
      r_cust_itf.creation_date            := SYSDATE;
      r_cust_itf.last_update_login        := g_login_id;
      r_cust_itf.org_id                   := l_pend.org_Id;
      r_cust_itf.customer_prospect_code   := 'CUSTOMER';
      r_cust_itf.gdf_address_attr_cat     := 'JL.BR.ARXCUDCI.Additional';
      r_cust_itf.gdf_address_attribute1   := NULL;
      --
      -- Check if exist rows in a interface with erros
      CHECK_AND_CLEAN_CUST_INTF(l_pend.org_Id, l_pend.cnpj_cpf, 'SHIP_TO');
      --
      INSERT INTO ra_customers_interface_all VALUES r_cust_itf;
      --
      l_count := l_count + 1;
      --
      BEGIN
        --
        -- Check if exist rows in a interface with erros
        SELECT COUNT(1)
        INTO l_exist_interface
        FROM ra_customer_profiles_int_all
        WHERE org_id                 = l_pend.org_id
        AND orig_system_customer_ref = l_pend.cnpj_cpf
        AND interface_status        IS NOT NULL;
        --
        IF l_exist_interface > 0 THEN
          DELETE ra_customer_profiles_int_all
          WHERE org_id                 = l_pend.org_id
          AND orig_system_customer_ref = l_pend.cnpj_cpf
          AND interface_status        IS NOT NULL;
        END IF;
        --
        SELECT COUNT(1)
        INTO l_exist_interface
        FROM ra_customer_profiles_int_all
        WHERE org_id                 = l_pend.org_id
        AND orig_system_customer_ref = l_pend.cnpj_cpf;
        --rbs               WHERE orig_system_customer_ref = l_pend.cnpj_cpf;
        --
        IF l_exist_interface = 0 THEN
          --
          r_cust_prof_itf                             := NULL;
          r_cust_prof_itf.insert_update_flag          := 'I';
          r_cust_prof_itf.orig_system_customer_ref    := l_pend.cnpj_cpf;
          r_cust_prof_itf.orig_system_address_ref     := NULL;
          r_cust_prof_itf.customer_profile_class_name := 'DEFAULT';
          r_cust_prof_itf.org_id                      := l_pend.org_id;
          r_cust_prof_itf.credit_hold                 := 'N';
          r_cust_prof_itf.created_by                  := g_user_id;
          r_cust_prof_itf.creation_date               := sysdate;
          r_cust_prof_itf.last_updated_by             := g_user_id;
          r_cust_prof_itf.last_update_date            := sysdate;
          r_cust_prof_itf.last_update_login           := g_login_id;
          --
          INSERT INTO ra_customer_profiles_int_all VALUES r_cust_prof_itf;
          --
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        out_l(SQLERRM);
        RAISE_APPLICATION_ERROR(-20010, 'Error : inserting into RA_CUSTOMER_PROFILES_INT_ALL table to the Customer Name ' || l_pend.customer_name || ' - ' || SQLERRM);
      END;
      -- Emerson Vitiello 08/01/2019 - Obter Classe de Perfil da Lookup de Interface no Nivel de Site
      -- Caso n�o exista n�o gera registro
      BEGIN
        --
        r_cust_prof_itf                             := NULL;
        r_cust_prof_itf.customer_profile_class_name := get_custint_lookup(l_pend.org_name, 'CLASSE PERFIL');
        --
      EXCEPTION
      WHEN OTHERS THEN
        out_l(SQLERRM);
        RAISE_APPLICATION_ERROR(-20010, 'Error : OBTER CLASSE DE PERFIL ' || r_cust_prof_itf.customer_profile_class_name ||' - '|| SQLERRM);
      END;
      --
      IF r_cust_prof_itf.customer_profile_class_name IS NOT NULL THEN
        --
        BEGIN
          --
          DELETE ra_customer_profiles_int_all
          WHERE org_id                 = l_pend.org_id
          AND orig_system_customer_ref = l_pend.cnpj_cpf
          AND orig_system_address_ref  = l_orig_system
            || '_'
            || l_orig_system_address_ref;
          --
        EXCEPTION
        WHEN OTHERS THEN
          out_l(SQLERRM);
          RAISE_APPLICATION_ERROR(-20010, 'Error : DELETE RA_CUSTOMER_PROFILES_INT_ALL table to the Customer Name / Site ' || l_pend.customer_name || ' - ' || l_orig_system || '_' || l_orig_system_address_ref ||' - '|| SQLERRM);
        END;
        --
        BEGIN
          --
          BEGIN
            --
            SELECT c.global_attribute_category,
              c.global_attribute1,
              c.global_attribute2,
              c.global_attribute3,
              c.global_attribute4,
              c.global_attribute5,
              c.global_attribute6,
              c.global_attribute7,
              c.global_attribute8,
              c.global_attribute9,
              c.global_attribute10,
              c.global_attribute11,
              c.global_attribute12,
              c.global_attribute13,
              c.global_attribute14,
              c.global_attribute15,
              c.global_attribute16,
              c.global_attribute17,
              c.global_attribute18,
              c.global_attribute19,
              c.global_attribute20
            INTO r_cust_prof_itf.gdf_cust_prof_attr_cat,
              r_cust_prof_itf.gdf_cust_prof_attribute1,
              r_cust_prof_itf.gdf_cust_prof_attribute2,
              r_cust_prof_itf.gdf_cust_prof_attribute3,
              r_cust_prof_itf.gdf_cust_prof_attribute4,
              r_cust_prof_itf.gdf_cust_prof_attribute5,
              r_cust_prof_itf.gdf_cust_prof_attribute6,
              r_cust_prof_itf.gdf_cust_prof_attribute7,
              r_cust_prof_itf.gdf_cust_prof_attribute8,
              r_cust_prof_itf.gdf_cust_prof_attribute9,
              r_cust_prof_itf.gdf_cust_prof_attribute10,
              r_cust_prof_itf.gdf_cust_prof_attribute11,
              r_cust_prof_itf.gdf_cust_prof_attribute12,
              r_cust_prof_itf.gdf_cust_prof_attribute13,
              r_cust_prof_itf.gdf_cust_prof_attribute14,
              r_cust_prof_itf.gdf_cust_prof_attribute15,
              r_cust_prof_itf.gdf_cust_prof_attribute16,
              r_cust_prof_itf.gdf_cust_prof_attribute17,
              r_cust_prof_itf.gdf_cust_prof_attribute18,
              r_cust_prof_itf.gdf_cust_prof_attribute19,
              r_cust_prof_itf.gdf_cust_prof_attribute20
            FROM apps.hz_cust_site_uses a,
              apps.hz_customer_profiles b,
              apps.hz_cust_profile_classes c
            WHERE a.orig_system_reference = l_orig_system
              || '_'
              || l_orig_system_address_ref
            AND a.site_use_code    = 'BILL_TO'
            AND a.status           = 'A'
            AND b.profile_class_id = c.profile_class_id
            AND a.site_use_id      = b.site_use_id;
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_exist_interface := 0;
          WHEN OTHERS THEN
            out_l(SQLERRM);
            RAISE_APPLICATION_ERROR(-20010, 'Error : ERROR getting the Customer Profile Class Site level ' || l_pend.customer_name || ' - ' || l_orig_system || '_' || l_orig_system_address_ref ||' - '|| SQLERRM);
          END;
          --
          IF l_exist_interface                  = 0 THEN
            r_cust_prof_itf.insert_update_flag := 'I';
          ELSE
            r_cust_prof_itf.insert_update_flag := 'U';
          END IF;
          --
          r_cust_prof_itf.orig_system_customer_ref := l_pend.cnpj_cpf;
          r_cust_prof_itf.orig_system_address_ref  := l_orig_system || '_' || l_orig_system_address_ref;
          r_cust_prof_itf.org_id                   := l_pend.org_id;
          r_cust_prof_itf.credit_hold              := 'N';
          r_cust_prof_itf.created_by               := g_user_id;
          r_cust_prof_itf.creation_date            := sysdate;
          r_cust_prof_itf.last_updated_by          := g_user_id;
          r_cust_prof_itf.last_update_date         := sysdate;
          r_cust_prof_itf.last_update_login        := g_login_id;
          --
          INSERT INTO ra_customer_profiles_int_all VALUES r_cust_prof_itf;
          --
        EXCEPTION
        WHEN OTHERS THEN
          out_l(SQLERRM);
          RAISE_APPLICATION_ERROR(-20010, 'Error : INSERT RA_CUSTOMER_PROFILES_INT_ALL table to the Customer Name / Site ' || l_pend.customer_name || ' - ' || l_orig_system || '_' || l_orig_system_address_ref ||' - '|| SQLERRM);
        END;
        --
      END IF;
      -- Emerson Vitiello 08/01/2019 - Obter Classe de Perfil da Lookup de Interface no Nivel de Site
      DECLARE
        r_cust_cpia ra_contact_phones_int_all%rowtype;
      BEGIN
        -- PARA INTEGRAR UM CONTATO, DEVE SER INFORMADO AO MENOS O NOME DO CONTATO
        -- SE INFORMADO :
        --  * TELEFONE - DEVE CADASTRAR COMO TELEFONE DESTE CONTATO
        --  * EMAIL    - DEVE CADASTRAR COMO EMAIL DESTE CONTATO
        --
        IF NVL(l_pend.contact_name, 'X')         <> 'X' THEN
          IF NVL(trim(l_pend.phone_number), 'X') <> 'X' THEN
            set_contact_itf(P_CUSTOMER_REF => l_pend.cnpj_cpf, P_ADDRESS_REF => r_cust_itf.orig_system_address_ref, P_CONTACT_REF => '01', P_ACTION => 'I' -- I OU U
            , p_CONTACT_TYPE => 'PHONE', p_contact_name => TRIM(l_pend.contact_name), P_ORG_ID => l_pend.org_Id, P_EMAIL => NULL, P_PHONE_NUMBER => l_pend.phone_number, P_AREA_CODE => l_pend.area_code);
          END IF;
          --
          IF NVL(L_PEND.EMAIL_ADDRESS, 'X') <> 'X' THEN
            set_contact_itf(P_CUSTOMER_REF => l_pend.cnpj_cpf, P_ADDRESS_REF => r_cust_itf.orig_system_address_ref, P_CONTACT_REF => '01', P_ACTION => 'I'               -- I OU U
            , p_CONTACT_TYPE => 'EMAIL', p_contact_name => TRIM(l_pend.contact_name), P_ORG_ID => l_pend.org_Id, P_EMAIL => l_pend.EMAIL_ADDRESS, P_PHONE_NUMBER => NULL --l_pend.phone_number
            , P_AREA_CODE => NULL                                                                                                                                        --l_pend.area_code
            );
          END IF;
        END IF;
      END;
      --
      upd_st('SUCCESS');
    ELSE
      --
      -- Atualizar
      OUT_P('Acao : Atualizacao Cadastral.');
      l_pend.message := 'UPDATE';
      BEGIN
        SELECT hop.rowid
        INTO l_rowid_prof
        FROM hz_organization_profiles hop
        WHERE hop.party_id          = l_party_id
        AND hop.effective_end_date IS NULL;
        --
        /**
        * Atualiza o Customer, Perfil e location
        */
        update_customer_prof_loc(x_rowid_prof => l_rowid_prof, x_rowid_hzp => l_rowid_hzp, x_rowid_hzl => l_rowid_hzl, p_party_id => l_party_id, p_location_Id => l_location_id, p_obj_version_num_hzp => l_hzp_object_version_number, p_obj_version_num_hzl => l_hzl_object_version_number, p_customer_name => l_pend.customer_name, p_address1 => l_pend.address, p_address2 => l_pend.address_number, p_address3 => l_pend.additional_information, p_address4 => l_pend.district, p_city => l_pend.city, p_state => l_pend.state, p_postal_code => l_pend.zip_code, p_country => l_pend.country);
      EXCEPTION
      WHEN OTHERS THEN
        NULL;
      END;
      --
      -- Atualizacao de """"CONTATOS""""
      /**
      * Checa se o Contato Existe para o cliente
      * campo nome do contato utilizado como chave
      * altera o Email/Telefone caso tenha sido alterado
      * inclui um novo contato caso o nome nao exista cadastrado
      */
      Check_and_Set_Contact(p_cust_account_id => l_cust_account_id, p_cust_acct_site_id => l_cust_acct_site_id, p_cnpj_cpf => l_pend.cnpj_cpf
      --,p_orig_system_reference   in varchar
      , p_orig_system_address_ref => l_orig_system_address_ref, p_contact_Name => l_pend.contact_name, p_phone_number => l_pend.phone_number, p_area_code => l_pend.area_code, p_email_address => l_pend.email_address, p_org_id => l_pend.org_Id);
      --
      -- Emerson Vitiello 08/01/2019 - Obter Classe de Perfil da Lookup de Interface no Nivel de Site
      -- Caso n�o exista n�o gera registro
      BEGIN
        --
        r_cust_prof_itf                             := NULL;
        r_cust_prof_itf.customer_profile_class_name := get_custint_lookup(l_pend.org_name, 'CLASSE PERFIL');
        --
      EXCEPTION
      WHEN OTHERS THEN
        out_l(SQLERRM);
        RAISE_APPLICATION_ERROR(-20010, 'Error : OBTER CLASSE DE PERFIL ' || r_cust_prof_itf.customer_profile_class_name ||' - '|| SQLERRM);
      END;
      --
      IF r_cust_prof_itf.customer_profile_class_name IS NOT NULL THEN
        --
        BEGIN
          --
          DELETE ra_customer_profiles_int_all
          WHERE org_id                 = l_pend.org_id
          AND orig_system_customer_ref = l_pend.cnpj_cpf
          AND orig_system_address_ref  = l_orig_system_address_ref;
          --
        EXCEPTION
        WHEN OTHERS THEN
          out_l(SQLERRM);
          RAISE_APPLICATION_ERROR(-20010, 'Error : DELETE RA_CUSTOMER_PROFILES_INT_ALL table to the Customer Name / Site ' || l_pend.customer_name || ' - ' || l_orig_system || '_' || l_orig_system_address_ref ||' - '|| SQLERRM);
        END;
        --
        BEGIN
          --
          BEGIN
            --
            SELECT c.global_attribute_category,
              c.global_attribute1,
              c.global_attribute2,
              c.global_attribute3,
              c.global_attribute4,
              c.global_attribute5,
              c.global_attribute6,
              c.global_attribute7,
              c.global_attribute8,
              c.global_attribute9,
              c.global_attribute10,
              c.global_attribute11,
              c.global_attribute12,
              c.global_attribute13,
              c.global_attribute14,
              c.global_attribute15,
              c.global_attribute16,
              c.global_attribute17,
              c.global_attribute18,
              c.global_attribute19,
              c.global_attribute20
            INTO r_cust_prof_itf.gdf_cust_prof_attr_cat,
              r_cust_prof_itf.gdf_cust_prof_attribute1,
              r_cust_prof_itf.gdf_cust_prof_attribute2,
              r_cust_prof_itf.gdf_cust_prof_attribute3,
              r_cust_prof_itf.gdf_cust_prof_attribute4,
              r_cust_prof_itf.gdf_cust_prof_attribute5,
              r_cust_prof_itf.gdf_cust_prof_attribute6,
              r_cust_prof_itf.gdf_cust_prof_attribute7,
              r_cust_prof_itf.gdf_cust_prof_attribute8,
              r_cust_prof_itf.gdf_cust_prof_attribute9,
              r_cust_prof_itf.gdf_cust_prof_attribute10,
              r_cust_prof_itf.gdf_cust_prof_attribute11,
              r_cust_prof_itf.gdf_cust_prof_attribute12,
              r_cust_prof_itf.gdf_cust_prof_attribute13,
              r_cust_prof_itf.gdf_cust_prof_attribute14,
              r_cust_prof_itf.gdf_cust_prof_attribute15,
              r_cust_prof_itf.gdf_cust_prof_attribute16,
              r_cust_prof_itf.gdf_cust_prof_attribute17,
              r_cust_prof_itf.gdf_cust_prof_attribute18,
              r_cust_prof_itf.gdf_cust_prof_attribute19,
              r_cust_prof_itf.gdf_cust_prof_attribute20
            FROM apps.hz_cust_site_uses a,
              apps.hz_customer_profiles b,
              apps.hz_cust_profile_classes c
            WHERE a.orig_system_reference = l_orig_system_address_ref
            AND a.site_use_code           = 'BILL_TO'
            AND a.status                  = 'A'
            AND b.profile_class_id        = c.profile_class_id
            AND a.site_use_id             = b.site_use_id;
            --
            l_exist_interface := 1;
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_exist_interface := 0;
          WHEN OTHERS THEN
            out_l(SQLERRM);
            RAISE_APPLICATION_ERROR(-20010, 'Error : ERROR getting the Customer Profile Class Site level ' || l_pend.customer_name || ' - ' || l_orig_system || '_' || l_orig_system_address_ref ||' - '|| SQLERRM);
          END;
          --
          IF l_exist_interface                  = 0 THEN
            r_cust_prof_itf.insert_update_flag := 'I';
          ELSE
            r_cust_prof_itf.insert_update_flag := 'U';
          END IF;
          --
          r_cust_prof_itf.orig_system_customer_ref := l_pend.cnpj_cpf;
          r_cust_prof_itf.orig_system_address_ref  := l_orig_system_address_ref;
          r_cust_prof_itf.org_id                   := l_pend.org_id;
          r_cust_prof_itf.credit_hold              := 'N';
          r_cust_prof_itf.created_by               := g_user_id;
          r_cust_prof_itf.creation_date            := sysdate;
          r_cust_prof_itf.last_updated_by          := g_user_id;
          r_cust_prof_itf.last_update_date         := sysdate;
          r_cust_prof_itf.last_update_login        := g_login_id;
          --
          INSERT INTO ra_customer_profiles_int_all VALUES r_cust_prof_itf;
          --
        EXCEPTION
        WHEN OTHERS THEN
          out_l(SQLERRM);
          RAISE_APPLICATION_ERROR(-20010, 'Error : INSERT RA_CUSTOMER_PROFILES_INT_ALL table to the Customer Name / Site ' || l_pend.customer_name || ' - ' || l_orig_system || '_' || l_orig_system_address_ref ||' - '|| SQLERRM);
        END;
        --
      END IF;
      -- Emerson Vitiello 08/01/2019 - Obter Classe de Perfil da Lookup de Interface no Nivel de Site
      --
      -- Emerson Vitiello 14/01/2019 - Atualiza��o do Metodo de Pagamento
      BEGIN
        --
        l_rPayMethod_Rec     := NULL;
        l_ncust_rcpt_mthd_id := NULL;
        l_last_update_date   := NULL;
        --
        --
        -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
        --l_payment_method_name := get_custint_lookup(l_pend.org_name, 'METODO DE RECEBIMENTO'); --fnd_profile.value('XXSTN_AR_CUST_RECEIPT_MET');
        l_payment_method_name     := NULL;
        l_contributor_class       := NULL;
        IF l_pend.receipt_method_name IS NOT NULL THEN
          BEGIN
            SELECT NAME
              INTO l_payment_method_name
              FROM ar_receipt_methods
             WHERE NAME = l_pend.receipt_method_name;
          EXCEPTION
            WHEN OTHERS THEN
              --l_payment_method_name     := get_custint_lookup(l_pend.org_name, 'METODO DE RECEBIMENTO');
              l_payment_method_name     := NULL;
              fnd_file.put_line(fnd_file.log,'Receipt method name invalid:' || l_pend.receipt_method_name||' CPF/CNPJ:'||l_pend.cnpj_cpf);
              retcode := 1;
          END;
        --ELSE
        --  l_payment_method_name     := get_custint_lookup(l_pend.org_name, 'METODO DE RECEBIMENTO');
        END IF;
        --
        -- CLASSE DE CONTRIBUINTE
        IF l_pend.contributor_class IS NOT NULL THEN
          --
          SELECT COUNT(1)
            INTO l_valid
            FROM apps.jl_zz_ar_tx_att_val_v
          WHERE  org_id             = l_pend.org_id
            AND tax_attribute_type  = 'CONTRIBUTOR_ATTRIBUTE'
            AND tax_attribute_name  = 'CONTRIBUTOR_TYPE'
            AND tax_attribute_value = l_pend.contributor_class;
          --
          IF l_valid > 0 THEN
            l_contributor_class := l_pend.contributor_class;
          ELSE
            --l_contributor_class := 'NAO CONTRIBUINTE';
            l_contributor_class := NULL;
            fnd_file.put_line(fnd_file.log,'Contributor Class invalid:' || l_pend.contributor_class||' CPF/CNPJ:'||l_pend.cnpj_cpf);
            retcode := 1;
          END IF;
        ELSE
          --l_contributor_class := 'NAO CONTRIBUINTE';
          l_contributor_class := NULL;
        END IF;
        -- end -- 15/05/2020 -- #SR-381687 - Ticket 319239
        --
        -- Verifica se existe metodo de pagamento associado anterior ao da carga, se sim, atualiza o campo PRIMARY_FLAG para N
        IF l_payment_method_name IS NOT NULL THEN 
          BEGIN
            --
            SELECT /*+ USE_INVISIBLE_INDEXES */ b.customer_id, -- INDEX Ronaldo Silva 03/04/2020
              b.cust_receipt_method_id,
              b.receipt_method_id,
              b.site_use_id,
              b.start_date,
              b.primary_flag,
              b.last_update_date
            INTO l_rPayMethod_Rec.cust_account_id,
              l_ncust_rcpt_mthd_id,
              l_rPayMethod_Rec.receipt_method_id,
              l_rPayMethod_Rec.site_use_id,
              l_rPayMethod_Rec.start_date,
              l_rPayMethod_Rec.primary_flag,
              l_last_update_date
            FROM apps.ra_cust_receipt_methods b,
              apps.hz_cust_site_uses a,
              apps.ar_receipt_methods c
            WHERE a.orig_system_reference = l_orig_system_address_ref
            AND a.site_use_code           = 'BILL_TO'
            AND a.status                  = 'A'
            AND b.receipt_method_id       = c.receipt_method_id
            AND c.name                   != l_payment_method_name
            AND NVL(b.end_date,SYSDATE)  >= TRUNC(sysdate)
            AND a.site_use_id             = b.site_use_id
            AND b.primary_flag            = 'Y';
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_rPayMethod_Rec     := NULL;
            l_ncust_rcpt_mthd_id := NULL;
          WHEN OTHERS THEN
            out_l(SQLERRM);
            RAISE_APPLICATION_ERROR(-20010, 'Error : Getting Old Payment Method ' || l_orig_system_address_ref ||' - '|| SQLERRM);
          END;
          --
          IF l_ncust_rcpt_mthd_id IS NOT NULL THEN
            -- Atualiza Flag Primario Para ""N""
            l_rPayMethod_Rec.cust_receipt_method_id := l_ncust_rcpt_mthd_id;
            l_px_last_update_date := l_last_update_date;
            l_rPayMethod_Rec.primary_flag := 'N';
            --
            hz_payment_method_pub.update_payment_method ( p_init_msg_list => fnd_api.g_true , p_payment_method_rec => l_rPayMethod_Rec , px_last_update_date => l_px_last_update_date , x_return_status => l_vstatus , x_msg_count => l_nmsg_count , x_msg_data => l_vmsg_data );
            --
            IF l_vstatus != fnd_api.g_ret_sts_success THEN
              --
              out_l(l_vstatus);
              RAISE_APPLICATION_ERROR(-20010, 'Error : Update Payment Method Primary Flag ' || l_orig_system_address_ref ||' - '|| l_vmsg_data);
              --
            END IF;
          END IF;
          --
          -- Verifica se o M�todo informado j� existe, se n�o, insere como primario
          BEGIN
            --
            l_ncust_rcpt_mthd_id := NULL;
            --
            SELECT /*+ USE_INVISIBLE_INDEXES */ b.customer_id, -- INDEX Ronaldo Silva 03/04/2020
              b.cust_receipt_method_id,
              b.receipt_method_id,
              b.site_use_id,
              b.start_date,
              b.primary_flag,
              b.last_update_date
            INTO l_rPayMethod_Rec.cust_account_id,
              l_ncust_rcpt_mthd_id,
              l_rPayMethod_Rec.receipt_method_id,
              l_rPayMethod_Rec.site_use_id,
              l_rPayMethod_Rec.start_date,
              l_rPayMethod_Rec.primary_flag,
              l_last_update_date
            FROM apps.ra_cust_receipt_methods b,
              apps.hz_cust_site_uses a,
              apps.ar_receipt_methods c
            WHERE a.orig_system_reference = l_orig_system_address_ref
            AND a.site_use_code           = 'BILL_TO'
            AND a.status                  = 'A'
            AND b.receipt_method_id       = c.receipt_method_id
            AND c.name                    = l_payment_method_name
            AND NVL(b.end_date,SYSDATE)  >= TRUNC(sysdate)
            AND a.site_use_id             = b.site_use_id;
            --
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_rPayMethod_Rec     := NULL;
            l_ncust_rcpt_mthd_id := NULL;
            l_last_update_date := NULL;
          WHEN OTHERS THEN
            out_l(SQLERRM);
            RAISE_APPLICATION_ERROR(-20010, 'Error : Getting New Payment Method ' || ' - ' || l_orig_system_address_ref ||' - '|| SQLERRM);
          END;
          --
          IF l_ncust_rcpt_mthd_id IS NULL THEN
            -- Insere metodo como primario
            l_rPayMethod_Rec.cust_account_id := l_cust_account_id;
            l_rPayMethod_Rec.site_use_id     := l_site_use_id;
            l_rPayMethod_Rec.start_date      := TRUNC(SYSDATE)-60;
            l_rPayMethod_Rec.primary_flag    := 'Y';
            -- Obtem Metodo de Pagamento
            BEGIN
              --
              SELECT receipt_method_id
              INTO l_rPayMethod_Rec.receipt_method_id
              FROM apps.ar_receipt_methods
              WHERE UPPER(TRIM(NAME)) = UPPER(TRIM(l_payment_method_name))
              AND SYSDATE BETWEEN (NVL(start_date,SYSDATE - 1)) AND (NVL(end_date,SYSDATE + 1));
              --
            EXCEPTION
            WHEN OTHERS THEN
              --
              out_l(SQLERRM);
              RAISE_APPLICATION_ERROR(-20010, 'Error : Getting Payment Method Name ' || l_payment_method_name || ' - ' || l_orig_system_address_ref ||' - '|| SQLERRM);
              --
            END;
            --
            hz_payment_method_pub.create_payment_method ( p_init_msg_list => fnd_api.g_true , p_payment_method_rec => l_rPayMethod_Rec , x_cust_receipt_method_id => l_ncust_rcpt_mthd_id , x_return_status => l_vstatus , x_msg_count => l_nmsg_count , x_msg_data => l_vmsg_data );
            --
            IF l_vstatus != fnd_api.g_ret_sts_success THEN
              --
              out_l(l_vstatus);
              RAISE_APPLICATION_ERROR(-20010, 'Error : Create New Payment Method Primary Flag ' || l_pend.customer_name || ' - ' || l_orig_system_address_ref ||' - '|| l_vmsg_data);
              --
            END IF;
            --
          ELSE
            -- Atualiza metodo como primario
            l_rPayMethod_Rec.primary_flag           := 'Y';
            l_rPayMethod_Rec.cust_receipt_method_id := l_ncust_rcpt_mthd_id;
            l_px_last_update_date := l_last_update_date;
            --
            hz_payment_method_pub.update_payment_method ( p_init_msg_list => fnd_api.g_true , p_payment_method_rec => l_rPayMethod_Rec , px_last_update_date => l_px_last_update_date , x_return_status => l_vstatus , x_msg_count => l_nmsg_count , x_msg_data => l_vmsg_data );
            --
            IF l_vstatus != fnd_api.g_ret_sts_success THEN
              --
              out_l(l_vstatus);
              RAISE_APPLICATION_ERROR(-20010, 'Error : Update New Payment Method Primary Flag ' || l_orig_system_address_ref ||' - '|| l_vmsg_data);
              --
            END IF;
            --
          END IF;
        END IF; -- IF l_payment_method_name IS NOT NULL THEN
      EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20010, 'Error : Creating Payment Method ' || l_payment_method_name || l_pend.cnpj_cpf || ' - ' || SQLERRM);
      END;
      --
      -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
      -- Alterar Class de Contribuinte
      IF l_contributor_class IS NOT NULL THEN 
        BEGIN
          UPDATE apps.hz_cust_acct_sites_all
             SET global_attribute8 = l_contributor_class
           WHERE cust_acct_site_id = l_cust_acct_site_id
             AND cust_account_id   = l_rPayMethod_Rec.cust_account_id;
        EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Error : Update Contributor Class:' || l_contributor_class||' CPF/CNPJ:'||l_pend.cnpj_cpf);
            retcode := 1;
        END;
      END IF;
      -- end -- 15/05/2020 -- #SR-381687 - Ticket 319239
      --
      -- Emerson Vitiello 14/01/2019 - Atualiza��o do Metodo de Pagamento
      upd_st('SUCCESS');
      --
      --end if; --alt 3S 27/11/2018
    END IF; --if l_create = 'Y' then --alt 3S 27/11/2018
    --
    --
  END LOOP;
CLOSE c_pend;
out_p('Clientes inserido na interface do AR: ' || l_count);
out_p('Carga de Clientes - Final : ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
END CUST_INTERF_LOAD;
--
PROCEDURE ADD_CONTACT_POINT(
    P_contact_point_type    IN VARCHAR DEFAULT 'EMAIL',
    p_owner_table_name      IN VARCHAR DEFAULT 'HZ_PARTY_SITES',
    p_owner_table_id        IN NUMBER,
    p_primary_flag          IN VARCHAR DEFAULT 'Y',
    p_orig_system_reference IN VARCHAR,
    p_email_format          IN VARCHAR,
    p_email                 IN VARCHAR,
    -- Emerson Vitiello 02/01/2019 - Inserir Proposito de negocio NFE para email de Faturamento
    p_contact_point_pur IN VARCHAR DEFAULT NULL,
    -- Emerson Vitiello 02/01/2019 - Inserir Proposito de negocio NFE para email de Faturamento
    r_status OUT BOOLEAN,
    r_message OUT VARCHAR2 )
IS
  --
  V_CONTACT_POINT_REC HZ_CONTACT_POINT_V2PUB.CONTACT_POINT_REC_TYPE;
  v_email_rec HZ_CONTACT_POINT_V2PUB.email_rec_type;
  v_phone_rec HZ_CONTACT_POINT_V2PUB.phone_rec_type;
  --
  V_CONTACT_POINT_PARTY_ID NUMBER;
  --
  v_object_version_number NUMBER;
  v_status                VARCHAR(500);
  V_MSG_COUNT             NUMBER;
  V_MSG_DATA              VARCHAR2(32767);
  V_RETORNO               BOOLEAN;
  v_msg_index_OUT         NUMBER;
  --
BEGIN
  BEGIN
    -- Create Contact Point and Phone Record
    v_contact_point_rec.contact_point_type := P_contact_point_type;
    v_contact_point_rec.status             := 'A';
    -- Emerson Vitiello 02/01/2019 - Inserir Proposito de negocio NFE para email de Faturamento
    v_contact_point_rec.contact_point_purpose := p_contact_point_pur;
    -- Emerson Vitiello 02/01/2019 - Inserir Proposito de negocio NFE para email de Faturamento
    v_contact_point_rec.owner_table_name      := p_owner_table_name; --'HZ_PARTY_SITES';
    v_contact_point_rec.owner_table_id        := p_owner_table_id;   -- PARTY_SITE_ID --V_PARTY_iD  ; --V_PARTY_SITE_ID;
    v_contact_point_rec.primary_flag          := p_primary_flag;
    V_CONTACT_POINT_REC.ORIG_SYSTEM_REFERENCE := p_orig_system_reference; -- PARTY_SITE_ID V_PARTY_iD; --V_PARTY_SITE_ID; --rec_phones.orig_system_reference;
    V_CONTACT_POINT_REC.CREATED_BY_MODULE     := 'TCA_V2_API';            -- SELECT DISTINCT LOOKUP_CODE FROM FND_LOOKUP_VALUES WHERE LOOKUP_TYPE = 'HZ_CREATED_BY_MODULES'
    -- PREENCHE VARS EMAIL
    V_EMAIL_REC.EMAIL_FORMAT  := p_email_format;
    V_EMAIL_REC.EMAIL_ADDRESS := p_email;
    --
    -- PREENCHE VARS PHONE
    v_phone_rec.phone_calling_calendar := NULL;
    v_phone_rec.last_contact_dt_time   := NULL;
    v_phone_rec.timezone_id            := NULL;
    v_phone_rec.phone_area_code        := NULL;
    v_phone_rec.phone_country_code     := NULL;
    v_phone_rec.phone_number           := NULL;
    v_phone_rec.phone_extension        := NULL;
    --
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
  END;
  --
  HZ_CONTACT_POINT_V2PUB.CREATE_CONTACT_POINT(p_init_msg_list => FND_API.G_TRUE, P_CONTACT_POINT_REC => V_CONTACT_POINT_REC, p_email_rec => v_email_rec, X_CONTACT_POINT_ID => V_CONTACT_POINT_PARTY_ID, X_RETURN_STATUS => V_STATUS, X_MSG_COUNT => V_MSG_COUNT, x_msg_data => v_msg_data);
  --
  IF NVL(V_STATUS, 'X') NOT IN ('S', 'Y') THEN
    r_status  := false;
    r_message := v_msg_data;
  ELSE
    r_status  := true;
    r_message := 'Contato Cadastrado';
  END IF;
  --
END ADD_CONTACT_POINT;
/*
* PROCESSO CONCORRENTE QUE
* TRATA A INFORMAGCO DE EMAIL PARA FATURAMENTO
* DE INVOICES, ASSOCIADO AO CADASTRO DE CLIENTES.
*/
PROCEDURE SYNC_CUSTOMER_EMAIL_INVOICE(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
-- Emerson Vitiello 15/01/2019 - Atualiza��o Email Faturamento
    p_file_name IN VARCHAR2)
-- Emerson Vitiello 15/01/2019 - Atualiza��o Email Faturamento
IS
  --
  CURSOR c_pend
  IS
    SELECT hcas.party_site_id,
      hca.cust_account_id,
      hca.party_id,
      hcsua.org_id,
      xci.email_invoice,
      xci.cnpj_cpf,
      xci.message,
      xci.customer_name,
      xci.org_name,
      xci.rowid AS xid
    FROM xxstn_customer_interface xci,
      HZ_CUST_ACCOUNTS hca,
      Hz_cust_acct_sites_all hcas,
      HZ_CUST_SITE_USES_ALL hcsua
    WHERE xci.status                          = 'SUCCESS'
    AND xci.cnpj_cpf                          = hca.account_number
    AND hca.cust_account_id                   = hcas.cust_account_id
    AND hcas.cust_acct_site_id                = hcsua.cust_acct_site_id
    AND hcsua.site_use_code                   = 'BILL_TO'
    AND hcsua.org_id                          = xci.org_id
    AND xci.email_invoice                    IS NOT NULL
    AND NVL(xci.STATUS_EMAIL_INVOICE, 'PEND') = 'PEND'
-- Emerson Vitiello 15/01/2019 - Atualiza��o Email Faturamento
    AND xci.file_name = p_file_name;
-- Emerson Vitiello 15/01/2019 - Atualiza��o Email Faturamento
  --
  l_pend c_pend%ROWTYPE;
  --
  l_exist NUMBER;
  r_email XXSTN_AR_CUSTOM_UTIL_PK.ARRAY_CSV; -- rbs 2017/12/14
  g_delim VARCHAR2(1) := '|';
  l_ok    VARCHAR2(10);
  PROCEDURE upd_st(
      p_status IN VARCHAR)
  IS
  BEGIN
    --
    UPDATE XXSTN_customer_interface
    SET STATUS_EMAIL_INVOICE = p_status,
      org_id                 = l_pend.org_id,
      MESSAGE                = l_pend.message,
      last_update_date       = sysdate,
      last_updated_by        = g_user_Id
    WHERE rowid              = l_pend.xid;
    --
  END upd_st;
BEGIN
  INIT_AUDIT;
  OUT_P('Carga Cliente - Email de Faturamento - inicio ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
  out_p(rpad('Empresa', 25, ' ') || ' ' || rpad('Codigo', 18, ' ') || ' ' || rpad('Cliente', 35, ' ') || ' ' || rpad('Email', 40, ' '));
  --
  out_p(rpad('-', 25, '-') || ' ' || rpad('-', 18, '-') || ' ' || rpad('-', 35, '-') || ' ' || rpad('-', 40, '-'));
  --
  OPEN c_pend;
  LOOP
    FETCH c_pend INTO l_pend;
    EXIT
  WHEN c_pend%notfound;
    --
    out_p(rpad(l_pend.org_name, 25, '-') || ' ' || rpad(l_pend.cnpj_cpf, 18, '-') || ' ' || rpad(l_pend.customer_name, 35, '-') || ' ' || l_pend.email_invoice);
    --
    l_ok    := NULL;
    r_email := NULL;
    XXSTN_AR_CUSTOM_UTIL_PK.SPLIT_L_CSV(l_pend.email_invoice, g_delim, r_email);
    FOR x IN 1 .. r_email.count
    LOOP
      IF r_email(x) IS NOT NULL THEN
        --
        SELECT COUNT(1)
        INTO l_exist
        FROM HZ_CONTACT_POINTS
        WHERE OWNER_TABLE_NAME = 'HZ_PARTY_SITES' --<> 'HZ_PARTIES'
        AND contact_point_type = 'EMAIL'
        AND email_address      = r_email(x) --l_pend.email_invoice
        AND owner_table_id     = l_pend.party_site_id
          --- tipo de negscio - Email Faturamento ????
          -- Emerson Vitiello 02/01/2019 - Inserir Proposito de negocio NFE para email de Faturamento
        AND contact_point_purpose = 'NFE'
          -- Emerson Vitiello 02/01/2019 - Inserir Proposito de negocio NFE para email de Faturamento
        AND status = 'A';
        IF l_exist = 0 THEN
          DECLARE
            x_status  BOOLEAN;
            x_message VARCHAR2(4000);
          BEGIN
            ADD_CONTACT_POINT(P_contact_point_type => 'EMAIL', p_owner_table_name => 'HZ_PARTY_SITES', p_owner_table_id => l_pend.party_site_id, p_primary_flag => 'Y', p_orig_system_reference => l_Pend.cnpj_cpf, p_email_format => 'MAILHTML', p_email => r_email(x) --l_pend.email_invoice
            , p_contact_point_pur => 'NFE', r_status => x_status, r_message => x_message);
            --
            IF x_status = true THEN
              l_ok     := 'OK';
            ELSE
              concat_message(l_pend.message, G_MSG_CUST_INV_MAIL_ERRO || ': ' || x_message);
              upd_st(G_ST_CUST_ERRO);
            END IF;
          END;
        END IF;
      END IF;
    END LOOP;
    IF l_ok = 'OK' THEN
      concat_message(l_pend.message, G_MSG_CUST_INV_MAIL_OK);
      upd_st(G_ST_CUST_SUCCESS);
    ELSE
      concat_message(l_pend.message, G_MSG_CUST_INV_MAIL_EXIST);
      upd_st(G_ST_CUST_SUCCESS);
    END IF;
    --
  END LOOP;
  CLOSE c_pend;
  --
  OUT_P('Carga Cliente - Email de Faturamento - final ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
END SYNC_CUSTOMER_EMAIL_INVOICE;
--
--
/*
* PROCESSO CONCORRENTE QUE
* LE ARQUIVOS .CSV E INSERE NA TABELA DE INTERFACE DE CLIENTES.
*/
PROCEDURE CUST_INTERF_LOAD_FILE(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2
    --, p_source         IN VARCHAR2
    ,
    p_file_name IN VARCHAR2)
IS
  --
  g_delim     VARCHAR(1) := ';';
  l_qtde_sele NUMBER     := 0;
  l_qtde_inse NUMBER     := 0;
  l_qtde_erro NUMBER     := 0;
  l_arqdir UTL_FILE.FILE_TYPE;
  l_dir           VARCHAR2(255);
  l_arq           VARCHAR2(100) := P_FILE_NAME;
  l_linha         VARCHAR2(32000);
  l_linha_out_p   VARCHAR2(32000);
  l_num_linha     NUMBER := 1;
  l_file_name     VARCHAR2(100);
  l_creation_date DATE;
  -- ************* --
  R_RET XXSTN_AR_CUSTOM_UTIL_PK.ARRAY_CSV;
  l_num_col                   NUMBER := 0;
  e_invalid_cnpj_cpf          EXCEPTION;
  e_invalid_org               EXCEPTION;
  e_no_delimiter_found        EXCEPTION;
  e_state_city                EXCEPTION;
  e_doc_type_is_null          EXCEPTION;
  e_doc_type_invalid          EXCEPTION;
  l_doc_type_1                NUMBER := 0;
  l_doc_type_2                NUMBER := 0;
  l_doc_type_3                NUMBER := 0;
  l_qtd_erro_cpf              NUMBER := 0;
  l_qtd_erro_org              NUMBER := 0;
  e_cpf_tamanho_invalido      EXCEPTION;
  e_cnpj_tamanho_invalido     EXCEPTION;
  e_state_city_invalid        EXCEPTION;
  l_qtd_erro_cnpj             NUMBER := 0;
  e_cust_name_is_null         EXCEPTION;
  l_exist_minuscula           VARCHAR2(2000);
  l_qtd_erro_cust_name        NUMBER := 0;
  e_cust_name_letra_minuscula EXCEPTION;
  l_exist_acento              VARCHAR2(1);
  e_cust_name_letra_acento    EXCEPTION;
  e_address_is_null           EXCEPTION;
  l_qtd_erro_address          NUMBER := 0;
  e_address_letra_minuscula   EXCEPTION;
  e_address_letra_acento      EXCEPTION;
  e_add_info_is_null          EXCEPTION;
  l_qtd_erro_add_info         NUMBER := 0;
  e_add_info_letra_minuscula  EXCEPTION;
  e_add_info_letra_acento     EXCEPTION;
  e_district_is_null          EXCEPTION;
  l_qtd_erro_district         NUMBER := 0;
  e_district_letra_minuscula  EXCEPTION;
  e_district_letra_acento     EXCEPTION;
  l_qtd_erro_doc_type         NUMBER := 0;
  e_city_is_null              EXCEPTION;
  l_qtd_erro_city             NUMBER := 0;
  e_city_letra_minuscula      EXCEPTION;
  e_city_letra_acento         EXCEPTION;
  l_geography_name hz_geographies.geography_name%type;
  l_geography_name_state hz_geographies.geography_name%type;
  l_meaning_city FND_LOOKUP_VALUES.meaning%type;
  e_city_not_found               EXCEPTION;
  e_state_is_null                EXCEPTION;
  e_state_invalid                EXCEPTION;
  e_state_tamanho_erro           EXCEPTION;
  l_qtd_erro_state               NUMBER := 0;
  e_state_letra_minuscula        EXCEPTION;
  l_exist_numero                 VARCHAR2(1);
  e_state_letra_numero           EXCEPTION;
  e_zip_code_is_null             EXCEPTION;
  e_zip_code_tamanho_erro        EXCEPTION;
  l_exist_letra_carac_esp        VARCHAR2(1);
  l_qtd_erro_zip_code            NUMBER := 0;
  e_zip_code_letra_carac_esp     EXCEPTION;
  l_qtd_erro_email_address       NUMBER := 0;
  e_email_addr_letra_minuscula   EXCEPTION;
  e_email_address_letra_acento   EXCEPTION;
  l_qtd_erro_contact_name        NUMBER := 0;
  e_contact_name_letra_minuscula EXCEPTION;
  e_contact_name_letra_acento    EXCEPTION;
  l_qtd_erro_email_invoice       NUMBER := 0;
  e_email_inv_letra_minuscula    EXCEPTION;
  e_email_invoice_letra_acento   EXCEPTION;
  l_qtd_reg_rec_ibge             NUMBER := 0;
  l_qtd_erro_tca                 NUMBER := 0;
  l_qtd_erro_org_code            NUMBER := 0;
  e_cpf_invalido                 EXCEPTION;
  e_cnpj_invalido                EXCEPTION;
  --e_address_menor_tres           EXCEPTION; --alt fpavao 14/05/2019
  --e_district_menor_tres          EXCEPTION; --alt fpavao 14/05/2019
  e_address_menor_quatro         EXCEPTION; --alt fpavao 14/05/2019
  e_district_menor_quatro        EXCEPTION; --alt fpavao 14/05/2019
  e_address_number_is_null       EXCEPTION; --alt 3S 27/11/2018
  -- ************* --
  reg XXSTN.XXSTN_CUSTOMER_INTERFACE%ROWTYPE;
  --
  FUNCTION GET_COL(
      P_NUMERO_COLUNA IN NUMBER)
    RETURN VARCHAR
  IS
  BEGIN
    RETURN trim(R_RET(P_NUMERO_COLUNA));
  EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
  END GET_COL;
--
  FUNCTION GET_NEXT_COL
    RETURN VARCHAR
  IS
    l_retorno VARCHAR2(4000);
  BEGIN
    l_retorno := get_col(l_num_col);
    l_num_col := l_num_col + 1;
    RETURN l_retorno;
  END GET_NEXT_COL;
--
BEGIN
  --
  out_l('Carga de Clientes - Inicio: ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
  --
  l_dir := fnd_profile.value('XXSTN_AR_CUST_DIR_IN');
  --
  BEGIN
    SELECT file_name,
      MAX(creation_date)
    INTO l_file_name,
      l_creation_date
    FROM XXSTN_customer_interface
    WHERE file_name = P_FILE_NAME
    AND status NOT IN ('PENDING', 'ERROR')
    GROUP BY file_name;
  EXCEPTION
  WHEN OTHERS THEN
    l_file_name := NULL;
  END;
  --
  IF l_file_name IS NOT NULL THEN
    retcode      := 1;
    OUT_l('The ' || P_File_Name || ' file was already processed before with Success in ' || TO_CHAR(l_creation_date, 'DD/MM/RRRR HH24:MI:MM') || '. Rename the file to processs it again');
    RETURN;
  END IF;
  --
  out_l('Directory..................: ' || l_dir);
  out_l('File Name..................: ' || l_arq);
  --
  BEGIN
    L_ARQDIR    := UTL_FILE.FOPEN(L_DIR, L_ARQ, 'R', 32000);
    l_qtde_sele := 0;
  EXCEPTION
  WHEN UTL_FILE.INVALID_PATH THEN
    RAISE_APPLICATION_ERROR(-20003, 'Invalid file name or directory ' || l_dir);
  WHEN UTL_FILE.INVALID_MODE THEN
    RAISE_APPLICATION_ERROR(-20004, 'Invalid parameter mode in FSOPEN');
  WHEN UTL_FILE.INVALID_FILEHANDLE THEN
    RAISE_APPLICATION_ERROR(-20005, 'The handle of the file is invalid');
  WHEN UTL_FILE.INVALID_OPERATION THEN
    RAISE_APPLICATION_ERROR(-20006, 'The file can not be opened');
  WHEN UTL_FILE.READ_ERROR THEN
    RAISE_APPLICATION_ERROR(-20007, 'Operating system error during reading');
  WHEN UTL_FILE.WRITE_ERROR THEN
    RAISE_APPLICATION_ERROR(-20008, 'Operating system error during recording');
  WHEN UTL_FILE.INTERNAL_ERROR THEN
    RAISE_APPLICATION_ERROR(-20009, 'An error occurred unidentified');
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20011, 'Error opening the file - ' || SQLERRM);
  END;
  --
  l_linha_out_p := REPLACE('ORG_NAME;DOC_TYPE;DOC_NUMBER;CUSTOMER_NAME;ADDRESS;ADDRESS_NUMBER;ADDITIONAL_INFORMATION;DISTRICT;CITY;STATE;ZIP_CODE;EMAIL_ADDRESS;CONTACT_NAME;AREA_CODE;PHONE_NUMBER;EMAIL_INVOICE',CHR(10), '');
  out_p(l_linha_out_p);
  LOOP
    BEGIN
      UTL_FILE.GET_LINE(L_ARQDIR, L_LINHA, 32000);
      l_qtde_sele                 := l_qtde_sele + 1;
      IF l_qtde_sele               = 1 THEN
        IF Instr(L_LINHA, g_delim) = 0 THEN
          raise e_no_delimiter_found;
        END IF;
      END IF;
    EXCEPTION
    WHEN e_no_delimiter_found THEN
      RAISE_APPLICATION_ERROR(-20010, 'I necessario usar PONTO e VIRGULA entre os campos');
    WHEN NO_DATA_FOUND THEN
      EXIT;
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20011, 'Error select the file row - ' || SQLERRM);
    END;
    --
    IF l_qtde_sele > 1 AND LENGTH(TRIM(l_linha)) > 0 THEN
      DECLARE
        l_campo     VARCHAR2(50);
        l_campo_aux VARCHAR2(2000);
        l_ibge_code XXSTN_TCA_GEOGRAPHY.CITY_IBGE_CODE%type;
        --
      BEGIN
        reg       := NULL;
        l_num_col := 1;
        XXSTN_AR_CUSTOM_UTIL_PK.SPLIT_L_CSV(l_linha, g_delim, R_RET);
        --
        reg.file_name := p_file_name;
        --
        l_campo         := 'ORG_NAME';
        REG.ORG_NAME    := GET_NEXT_COL;
        REG.ORG_ID      := get_org_id(REG.ORG_NAME);
        l_campo         := 'DOC_TYPE';
        REG.DOC_TYPE    := get_next_col;
        IF REG.DOC_TYPE IS NULL THEN
          raise e_doc_type_is_null;
        ELSIF REG.DOC_TYPE NOT IN(1,2,3) THEN
          raise e_doc_type_invalid;
        END IF;
        l_campo                   := 'DOC_NUMBER';
        REG.CNPJ_CPF              := get_next_col;
        IF REG.DOC_TYPE            = 1 THEN
          IF LENGTH(REG.CNPJ_CPF) <> 11 THEN
            l_qtd_erro_cpf        := l_qtd_erro_cpf + 1;
            raise e_cpf_tamanho_invalido;
          END IF;
          IF validy_cpf(REG.CNPJ_CPF) THEN
            NULL;
          ELSE
            l_qtd_erro_cpf := l_qtd_erro_cpf + 1;
            raise e_cpf_invalido;
          END IF;
        END IF;
        IF REG.DOC_TYPE            = 2 THEN
          IF LENGTH(REG.CNPJ_CPF) <> 14 THEN
            l_qtd_erro_cnpj       := l_qtd_erro_cnpj + 1;
            raise e_cnpj_tamanho_invalido;
          END IF;
          IF validy_cnpj(REG.CNPJ_CPF) THEN
            NULL;
          ELSE
            l_qtd_erro_cnpj := l_qtd_erro_cnpj + 1;
            raise e_cnpj_invalido;
          END IF;
        END IF;
        /*if REG.CNPJ_CPF like '%E+%' then
        l_campo := l_campo || ' ' || REG.CNPJ_CPF;
        IF REG.DOC_TYPE = 1 THEN
        l_qtd_erro_cpf := l_qtd_erro_cpf + 1;
        END IF;
        IF REG.DOC_TYPE = 2 THEN
        l_qtd_erro_cnpj := l_qtd_erro_cnpj + 1;
        END IF;
        raise e_invalid_cnpj_cpf;
        end if;*/
        --
        -- Campo Obrigatsrio
        IF reg.org_id    IS NULL THEN
          l_qtd_erro_org := l_qtd_erro_org + 1;
          raise e_invalid_org;
        END IF;
        l_campo                := 'CUSTOMER_NAME';
        REG.CUSTOMER_NAME      := GET_NEXT_COL;
        IF REG.CUSTOMER_NAME   IS NULL THEN
          l_qtd_erro_cust_name := l_qtd_erro_cust_name + 1;
          raise e_cust_name_is_null;
        END IF;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.CUSTOMER_NAME, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula   IS NOT NULL THEN
          l_qtd_erro_cust_name := l_qtd_erro_cust_name + 1;
          raise e_cust_name_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.CUSTOMER_NAME,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento      IS NOT NULL THEN
          l_qtd_erro_cust_name := l_qtd_erro_cust_name + 1;
          raise e_cust_name_letra_acento;
        END IF;
        --
        -- begin #SR-433445 - Ticket 311637 -- 07/01/2020
        REG.CUSTOMER_NAME := translate(REG.CUSTOMER_NAME,'!@#$%&*()_+=[]{}/\?:<>|',
                                                         '                       ');
        -- end #SR-433445 - Ticket 311637 -- 07/01/2020
        --
        l_campo     := 'ADDRESS';
        REG.ADDRESS := GET_NEXT_COL;
        --alt fpavao 14/05/2019 begin
        IF LENGTH(REG.ADDRESS) < 4 THEN
          l_qtd_erro_address  := l_qtd_erro_address + 1;
          raise e_address_menor_quatro;
        END IF;
        --alt fpavao 14/05/2019 end
        IF REG.ADDRESS       IS NULL THEN
          l_qtd_erro_address := l_qtd_erro_address + 1;
          raise e_address_is_null;
        END IF;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.ADDRESS, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula IS NOT NULL THEN
          l_qtd_erro_address := l_qtd_erro_address + 1;
          raise e_address_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.ADDRESS,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento    IS NOT NULL THEN
          l_qtd_erro_address := l_qtd_erro_address + 1;
          raise e_address_letra_acento;
        END IF;
        --
        -- begin #SR-433445 - Ticket 311637 -- 07/01/2020
        REG.ADDRESS := translate(REG.ADDRESS,'!@#$%&*()_+=[]{}/\?:<>|',
                                             '                       ');
        --
        REG.ADDRESS := SUBSTR(REG.ADDRESS,1,30);
        -- end #SR-433445 - Ticket 311637 -- 07/01/2020
        --
        l_campo            := 'ADDRESS_NUMBER';
        REG.ADDRESS_NUMBER := GET_NEXT_COL;
        --alt 3S 27/11/2018 begin
        IF REG.ADDRESS_NUMBER IS NULL THEN
          l_qtd_erro_address  := l_qtd_erro_address + 1;
          raise e_address_number_is_null;
        END IF;
        --alt 3S 27/11/2018 end
        l_campo                    := 'ADDITIONAL_INFORMATION';
        REG.ADDITIONAL_INFORMATION := GET_NEXT_COL;
        --IF REG.ADDITIONAL_INFORMATION IS NULL THEN
        --l_qtd_erro_add_info := l_qtd_erro_add_info + 1;
        --raise e_add_info_is_null;
        --END IF;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.ADDITIONAL_INFORMATION, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula  IS NOT NULL THEN
          l_qtd_erro_add_info := l_qtd_erro_add_info + 1;
          raise e_add_info_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.ADDITIONAL_INFORMATION,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento     IS NOT NULL THEN
          l_qtd_erro_add_info := l_qtd_erro_add_info + 1;
          raise e_add_info_letra_acento;
        END IF;
        l_campo      := 'DISTRICT';
        REG.DISTRICT := GET_NEXT_COL;
        --alt fpavao 14/05/2019 begin
        IF LENGTH(REG.DISTRICT) < 4 THEN
          l_qtd_erro_district  := l_qtd_erro_district + 1;
          raise e_district_menor_quatro;
        END IF;
        --alt fpavao 14/05/2019 end
        IF REG.DISTRICT       IS NULL THEN
          l_qtd_erro_district := l_qtd_erro_district + 1;
          raise e_district_is_null;
        END IF;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.DISTRICT, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula  IS NOT NULL THEN
          l_qtd_erro_district := l_qtd_erro_district + 1;
          raise e_district_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.DISTRICT,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento     IS NOT NULL THEN
          l_qtd_erro_district := l_qtd_erro_district + 1;
          raise e_district_letra_acento;
        END IF;
        --
        -- begin #SR-433445 - Ticket 311637 -- 07/01/2020
        REG.DISTRICT := translate(REG.DISTRICT,'!@#$%&*()_+=[]{}/\?:<>|',
                                             '                       ');
        --
        REG.DISTRICT := SUBSTR(REG.DISTRICT,1,30);
        -- end #SR-433445 - Ticket 311637 -- 07/01/2020
        --
        l_campo           := 'CITY';
        REG.CITY          := GET_NEXT_COL;
        IF REG.CITY       IS NULL THEN
          l_qtd_erro_city := l_qtd_erro_city + 1;
          raise e_city_is_null;
        END IF;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.CITY, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula IS NOT NULL THEN
          l_qtd_erro_city    := l_qtd_erro_city + 1;
          raise e_city_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.CITY,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento IS NOT NULL THEN
          l_qtd_erro_city := l_qtd_erro_city + 1;
          raise e_city_letra_acento;
        END IF;
        l_campo            := 'STATE';
        REG.STATE          := GET_NEXT_COL;
        IF REG.STATE       IS NULL THEN
          l_qtd_erro_state := l_qtd_erro_state + 1;
          raise e_state_is_null;
        END IF;
        IF LENGTH(REG.STATE) <> 2 THEN
          l_qtd_erro_state   := l_qtd_erro_state + 1;
          raise e_state_tamanho_erro;
        END IF;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.STATE, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula IS NOT NULL THEN
          l_qtd_erro_state   := l_qtd_erro_state + 1;
          raise e_state_letra_minuscula;
        END IF;
        l_exist_numero := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_numero
          FROM DUAL
          WHERE regexp_like(REG.STATE,'[0123456789]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_numero := NULL;
        END;
        IF l_exist_numero  IS NOT NULL THEN
          l_qtd_erro_state := l_qtd_erro_state + 1;
          raise e_state_letra_numero;
        END IF;
        --verifica estado TCA
        l_geography_name_state := NULL;
        BEGIN
          SELECT geography_name
          INTO l_geography_name_state
          FROM hz_geographies
          WHERE geography_type = 'STATE'
          AND country_code     = 'BR'
          AND geography_name   = REG.STATE;
        EXCEPTION
        WHEN OTHERS THEN
          l_geography_name_state := NULL;
        END;
        IF l_geography_name_state IS NULL THEN
          l_qtd_erro_state        := l_qtd_erro_state + 1;
          raise e_state_invalid;
        END IF;
        --verifica cidade TCA
        l_geography_name := NULL;
        BEGIN
          SELECT geography_name
          INTO l_geography_name
          FROM hz_geographies
          WHERE geography_type   = 'CITY'
          AND country_code       = 'BR'
          AND geography_name     = REG.CITY
          AND geography_element2 = REG.STATE;
        EXCEPTION
        WHEN OTHERS THEN
          l_geography_name := NULL;
        END;
        l_meaning_city      := NULL;
        IF l_geography_name IS NULL THEN
          BEGIN
            SELECT MEANING
            INTO l_meaning_city
            FROM FND_LOOKUP_VALUES
            WHERE LOOKUP_TYPE = 'STN_CUSTINT_IBGE_RECEITA'
            AND LANGUAGE      = 'PTB'
            AND DESCRIPTION   = REG.CITY;
          EXCEPTION
          WHEN OTHERS THEN
            l_meaning_city := NULL;
          END;
          IF l_meaning_city IS NULL THEN
            l_qtd_erro_city := l_qtd_erro_city + 1;
            raise e_city_not_found;
          ELSE
            REG.CITY           := l_meaning_city;
            l_qtd_reg_rec_ibge := l_qtd_reg_rec_ibge + 1;
          END IF;
        ELSE
          REG.CITY := l_geography_name;
        END IF;
        --verifica cidade x estado
        l_geography_name_state := NULL;
        BEGIN
          SELECT geography_name
          INTO l_geography_name_state
          FROM hz_geographies
          WHERE geography_type   = 'CITY'
          AND country_code       = 'BR'
          AND geography_name     = REG.CITY
          AND geography_element2 = REG.STATE;
        EXCEPTION
        WHEN OTHERS THEN
          l_geography_name_state := NULL;
        END;
        IF l_geography_name_state IS NULL THEN
          l_qtd_erro_state        := l_qtd_erro_state + 1;
          raise e_state_city_invalid;
        END IF;
        l_campo               := 'ZIP_CODE';
        REG.ZIP_CODE          := GET_NEXT_COL;
        IF REG.ZIP_CODE       IS NULL THEN
          l_qtd_erro_zip_code := l_qtd_erro_zip_code + 1;
          raise e_zip_code_is_null;
        END IF;
        IF LENGTH(REG.ZIP_CODE) <> 8 THEN
          l_qtd_erro_zip_code   := l_qtd_erro_zip_code + 1;
          raise e_zip_code_tamanho_erro;
        END IF;
        l_exist_letra_carac_esp := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_letra_carac_esp
          FROM DUAL
          WHERE regexp_like(REG.ZIP_CODE,'[ABCDEFGHIJKLMNOPQRSTUVXZabcdefghijklmnopqrstuvxz-/.*+""""!@#$%�&()_=]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_letra_carac_esp := NULL;
        END;
        IF l_exist_letra_carac_esp IS NOT NULL THEN
          l_qtd_erro_zip_code      := l_qtd_erro_zip_code + 1;
          raise e_zip_code_letra_carac_esp;
        END IF;
        l_campo           := 'EMAIL_ADDRESS';
        REG.EMAIL_ADDRESS := GET_NEXT_COL;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.EMAIL_ADDRESS, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula       IS NOT NULL THEN
          l_qtd_erro_email_address := l_qtd_erro_email_address + 1;
          raise e_email_addr_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.EMAIL_ADDRESS,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento          IS NOT NULL THEN
          l_qtd_erro_email_address := l_qtd_erro_email_address + 1;
          raise e_email_address_letra_acento;
        END IF;
        l_campo           := 'CONTACT_NAME';
        REG.CONTACT_NAME  := GET_NEXT_COL;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.CONTACT_NAME, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula      IS NOT NULL THEN
          l_qtd_erro_contact_name := l_qtd_erro_contact_name + 1;
          raise e_contact_name_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.CONTACT_NAME,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento         IS NOT NULL THEN
          l_qtd_erro_contact_name := l_qtd_erro_contact_name + 1;
          raise e_contact_name_letra_acento;
        END IF;
        l_campo           := 'AREA_CODE';
        REG.AREA_CODE     := GET_NEXT_COL;
        l_campo           := 'PHONE_NUMBER';
        REG.PHONE_NUMBER  := GET_NEXT_COL;
        l_campo           := 'EMAIL_INVOICE';
        REG.EMAIL_INVOICE := GET_NEXT_COL;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(REG.EMAIL_INVOICE, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula       IS NOT NULL THEN
          l_qtd_erro_email_invoice := l_qtd_erro_email_invoice + 1;
          raise e_email_inv_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(REG.EMAIL_INVOICE,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento          IS NOT NULL THEN
          l_qtd_erro_email_invoice := l_qtd_erro_email_invoice + 1;
          raise e_email_invoice_letra_acento;
        END IF;
        --
        l_campo := 'STATE= ' || reg.state || ' CITY= ' ||reg.city;
        --out_p('city:'|| reg.city || ', state:' || reg.state );
        --
        BEGIN
          SELECT CITY_IBGE_CODE,
            COUNTRY
          INTO l_ibge_code,
            REG.COUNTRY
          FROM XXSTN.XXSTN_TCA_GEOGRAPHY
          WHERE CITY = reg.city
          AND STATE  = reg.state;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          raise e_state_city;
        WHEN OTHERS THEN
          raise;
        END;
        --
        -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
        l_campo           := 'RECEIPT_METHOD';
        REG.RECEIPT_METHOD_NAME := GET_NEXT_COL;
        REG.RECEIPT_METHOD_NAME := regexp_replace(REG.RECEIPT_METHOD_NAME,'[����������������������������������������]');
        REG.RECEIPT_METHOD_NAME := upper(REG.RECEIPT_METHOD_NAME);
        --
        l_campo           := 'CONTRIBUTOR_CLASS';
        REG.CONTRIBUTOR_CLASS := GET_NEXT_COL;
        REG.CONTRIBUTOR_CLASS := regexp_replace(REG.CONTRIBUTOR_CLASS,'[����������������������������������������]');
        REG.CONTRIBUTOR_CLASS := replace(replace(upper(REG.CONTRIBUTOR_CLASS),chr(10),NULL),chr(13),NULL);
        -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
        --
        reg.created_by       := g_user_id;
        reg.last_updated_by  := g_user_id;
        reg.last_update_date := sysdate;
        reg.creation_date    := sysdate;
        reg.Status           := 'PEND';
        --
        reg.last_update_login := g_login_id;
        --
        l_campo := 'insert';
        --
        INSERT INTO XXSTN.XXSTN_CUSTOMER_INTERFACE VALUES REG;
        l_qtde_inse    := l_qtde_inse + 1;
        IF REG.DOC_TYPE = 1 THEN
          l_doc_type_1 := l_doc_type_1 + 1;
        END IF;
        IF REG.DOC_TYPE = 2 THEN
          l_doc_type_2 := l_doc_type_2 + 1;
        END IF;
        IF REG.DOC_TYPE = 3 THEN
          l_doc_type_3 := l_doc_type_3 + 1;
        END IF;
        --
      EXCEPTION
      WHEN e_doc_type_is_null THEN
        retcode             := 1;
        l_qtd_erro_doc_type := l_qtd_erro_doc_type + 1;
        l_qtde_erro         := l_qtde_erro         + 1;
        l_linha_out_p       := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DOC_TYPE nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_doc_type_invalid THEN
        retcode             := 1;
        l_qtd_erro_doc_type := l_qtd_erro_doc_type + 1;
        l_qtde_erro         := l_qtde_erro         + 1;
        l_linha_out_p       := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DOC_TYPE diferente de 1, 2 ou 3',CHR(13), '');
        out_p(l_linha_out_p);
        /*WHEN e_invalid_cnpj_cpf THEN
        l_qtde_erro := l_qtde_erro + 1;
        out_p(l_linha||';'||l_qtde_sele||';'||'CPNJ/CPF invalido - campo ' || l_campo); */
      WHEN e_cpf_tamanho_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Tamanho campo CPF invalido - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cnpj_tamanho_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Tamanho campo CNPJ invalido - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cust_name_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Nome do cliente nao pode ser nulo - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cust_name_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CUSTOMER_NAME nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cust_name_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CUSTOMER_NAME nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_address_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ENDERECO nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
        --alt fpavao 14/05/2019 begin
      WHEN e_address_menor_quatro THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Quantidade de caracteres do campo ADDRESS tem que ser maior ou igual a 4 posicoes',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_district_menor_quatro THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Quantidade de caracteres do campo DISTRICT tem que ser maior ou igual a 4 posicoes',CHR(13), '');
        out_p(l_linha_out_p);
        --alt fpavao 14/05/2019 end
        --alt 3S 27/11/2018 begin
      WHEN e_address_number_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ADDRESS_NUMBER nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
        --alt 3S 27/11/2018 end
      WHEN e_address_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ENDERECO nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_address_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ENDERECO nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_add_info_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ADDITIONAL_INFORMATION nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_add_info_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ADDITIONAL_INFORMATION nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_add_info_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ADDITIONAL_INFORMATION nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_district_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DISTRICT nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_district_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DISTRICT nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_district_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DISTRICT nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_city_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CITY nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_city_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CITY nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_city_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CITY nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_city_not_found THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CITY nao encontrado cadastrado',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_state_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo STATE nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_state_tamanho_erro THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo STATE com tamanho de caracteres invalido',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_state_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo STATE nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_state_letra_numero THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo STATE nao pode conter numeros',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_state_invalid THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo STATE com nome invalido',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_state_city_invalid THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Combinacao de cidade x estado invalida',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_zip_code_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ZIP_CODE nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_zip_code_tamanho_erro THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ZIP_CODE tamanho invalido do campo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_zip_code_letra_carac_esp THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ZIP_CODE nao pode conter letras ou caracteres especiais',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_email_addr_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo EMAIL_ADDRESS nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_email_address_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo EMAIL_ADDRESS nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_contact_name_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CONTACT_NAME nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_contact_name_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo CONTACT_NAME nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_email_inv_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo EMAIL_INVOICE nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_email_invoice_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo EMAIL_INVOICE nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
        --rbs 2017/dec/28
      WHEN e_invalid_cnpj_cpf THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CPNJ/CPF invalido',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cpf_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CPF invalido ',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cnpj_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CNPJ invalido ',CHR(13), '');
        out_p(l_linha_out_p);
        /*WHEN e_state_city THEN
        retcode := 1;
        l_qtde_erro := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Nao encontrado Estado - Cidade: '|| l_campo,CHR(13), '');
        out_p(l_linha_out_p);*/
      WHEN OTHERS THEN
        retcode         := 1;
        l_qtde_erro     := l_qtde_erro + 1;
        IF l_campo       = 'insert' THEN
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao Processar a Linha - Erro ao tentar Inserir no Banco de Dados - '||' Verifique a mensagem de erro' || ' : '||
          CASE
          WHEN SQLERRM LIKE '%XXSTN_CUSTOMER_INTF_FK1%' THEN
            G_MSG_CUST_ERR_TCA
          WHEN SQLERRM LIKE '%XXSTN_CUSTOMER_INTF_FK2%' THEN
            G_MSG_CUST_ERR_ORG
          ELSE
            SQLERRM
          END,CHR(13), '');
          out_p(l_linha_out_p);
          IF SQLERRM LIKE '%XXSTN_CUSTOMER_INTF_FK1%' THEN
            l_qtd_erro_tca := l_qtd_erro_tca + 1;
          ELSIF SQLERRM LIKE '%XXSTN_CUSTOMER_INTF_FK2%' THEN
            l_qtd_erro_org_code := l_qtd_erro_org_code + 1;
          END IF;
        ELSE
          l_qtde_erro   := l_qtde_erro + 1;
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'...Erro ao Processar a Linha - '||'- Campo :' || l_campo||' - '||sqlerrm,CHR(13), '');
          out_p(l_linha_out_p);
        END IF;
        --OUT_P('...Texto da Linha: ' || l_linha);
      END;
    END IF;
  END LOOP;
  --
  UTL_FILE.FCLOSE(L_ARQDIR);
  --
  --
  out_l('Total Records selected ......................................: ' || l_qtde_sele);
  out_l('Total Records inserted ......................................: ' || l_qtde_inse);
  out_l('total Records with errors ...................................: ' || l_qtde_erro||CHR(10));
  --
  out_l('Total Records DOC_TYPE 1 CPF ................................: ' || l_doc_type_1);
  out_l('Total Records DOC_TYPE 2 CNPJ ...............................: ' || l_doc_type_2);
  out_l('Total Records DOC_TYPE 3 Others .............................: ' || l_doc_type_3||CHR(10));
  out_l('Total Records CITY RECEITA / IBGE ...........................: ' || l_qtd_reg_rec_ibge||CHR(10));
  out_l('Total Inconsistencias encontradas ...........................: ' || l_qtde_erro||CHR(10));
  out_l('Total Records customers with wrong DOC_TYPE .................: ' || l_qtd_erro_doc_type);
  out_l('Total Records customers with wrong DOC_NUMBER 1 CPF .........: ' || l_qtd_erro_cpf);
  out_l('Total Records customers with wrong DOC_NUMBER 2 CNPJ ........: ' || l_qtd_erro_cnpj);
  out_l('Total Records customers with wrong EMPRESA ORG_CODE .........: ' || l_qtd_erro_org_code);
  out_l('Total Records customers with wrong TCA ......................: ' || l_qtd_erro_tca);
  --out_l('Total Records customers with wrong DOC_NUMBER 3 Others ......: ' || l_doc_type_2);
  out_l('Total Records customers with wrong CUSTOMER_NAME ............: ' || l_qtd_erro_cust_name);
  out_l('Total Records customers with wrong ADDRESS ..................: ' || l_qtd_erro_address);
  --out_l('Total Records customers with wrong ADDRESS_NUMBER ...........: ' || l_doc_type_2);
  out_l('Total Records customers with wrong ADDITIONAL_INFORMATION ...: ' || l_qtd_erro_add_info);
  out_l('Total Records customers with wrong DISTRICT .................: ' || l_qtd_erro_district);
  out_l('Total Records customers with wrong CITY .....................: ' || l_qtd_erro_city);
  out_l('Total Records customers with wrong STATE ....................: ' || l_qtd_erro_state);
  out_l('Total Records customers with wrong ZIP_CODE .................: ' || l_qtd_erro_zip_code);
  out_l('Total Records customers with wrong EMAIL_ADDRESS ............: ' || l_qtd_erro_email_address);
  out_l('Total Records customers with wrong CONTACT_NAME .............: ' || l_qtd_erro_contact_name);
  out_l('Total Records customers with wrong ORGANIZACAO .............: ' || l_qtd_erro_org);
  --out_l('Total Records customers with wrong PHONE_NUMBER .............: ' || l_doc_type_2);
  out_l('Total Records customers with wrong EMAIL_INVOICE ............: ' || l_qtd_erro_email_invoice||CHR(10));
  out_l('Carga de Clientes- Termino: ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
  --
END CUST_INTERF_LOAD_FILE;
--
/*
* PROCESSO CONCORRENTE QUE LE
* AS INFORMACOES DO ARQUIVO CSV DE CARGA
* MANUAL E INSERE AS INFORMAGUES NA TABELA
* CUSTOMIZADA DE CARGA
*/
--
PROCEDURE AR_TEXT_FILE_INVOICE_LOAD
  (
    Errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
    P_FILE_NAME IN VARCHAR
  )
IS
  --
  g_delim         VARCHAR(1)   := ';';
  g_dt_format     VARCHAR2(20) := 'DD/MM/YYYY';--'DD-MM-YYYY';
  l_currency_code VARCHAR2(03) := 'BRL';
  l_number_mask   VARCHAR2(30) := '999999999999D99';
  l_number_nls    VARCHAR2(30) := 'NLS_NUMERIC_CHARACTERS=''.,'''; -- formato americano
  --
  l_qtde_sele NUMBER := 0;
  l_qtde_inse NUMBER := 0;
  l_qtde_updt NUMBER := 0;
  l_qtde_erro NUMBER := 0;
  l_arqdir UTL_FILE.FILE_TYPE;
  l_dir           VARCHAR2(255);
  l_arq           VARCHAR2(100) := P_FILE_NAME;
  l_linha         VARCHAR2(32000);
  l_linha_out_p   VARCHAR2(32000);
  l_instance_name VARCHAR2(30);
  l_num_linha     NUMBER := 1;
  l_file_name     VARCHAR2(100);
  l_creation_date DATE;
  l_exists        NUMBER;
  l_sqlerrm       VARCHAR2(32000);
  -- ************* --
  R_RET XXSTN_AR_CUSTOM_UTIL_PK.ARRAY_CSV;
  l_num_col              NUMBER;
  e_invalid_cnpj_cpf     EXCEPTION;
  e_invalid_org          EXCEPTION;
  e_invalid_lookup_setup EXCEPTION;
  e_no_delimiter_found   EXCEPTION;
  -- ************* --
  reg xxstn.xxstn_electronic_inv_interf%rowtype;
  l_orig_sys_ref xxstn.xxstn_electronic_inv_interf.orig_sys_ref%type;
  e_orig_sys_ref_is_null    EXCEPTION;
  e_doc_type_is_null        EXCEPTION;
  e_doc_type_invalid        EXCEPTION;
  l_doc_type_1              NUMBER := 0;
  l_doc_type_2              NUMBER := 0;
  l_doc_type_3              NUMBER := 0;
  l_tot_elavon              NUMBER := 0;
  l_tot_stone               NUMBER := 0;
  l_total_error_city        NUMBER := 0;
  l_unid_oper_erro          NUMBER := 0;
  e_cpf_tamanho_invalido    EXCEPTION;
  e_cpf_invalido            EXCEPTION;
  e_cnpj_tamanho_invalido   EXCEPTION;
  e_cnpj_invalido           EXCEPTION;
  e_item_is_null            EXCEPTION;
  e_item_no_data_found      EXCEPTION;
  e_item_error_found        EXCEPTION;
  e_amount_menor_zero       EXCEPTION;
  e_operacao_is_null        EXCEPTION;
  e_operacao_is_invalid     EXCEPTION;
  e_trans_data_is_null      EXCEPTION;
  e_trans_data_error        EXCEPTION;
  l_exist_minuscula         VARCHAR2(2000);
  e_comment_letra_minuscula EXCEPTION;
  e_comment_letra_acento    EXCEPTION;
  e_city_found_error        EXCEPTION;
  l_city hz_locations.city%type;
  e_error_city_item_emp EXCEPTION;
  l_cidade hz_locations.city%type;
  l_item    VARCHAR2(100);
  l_empresa VARCHAR2(100);
  l_lookup_city FND_LOOKUP_VALUES.LOOKUP_TYPE%TYPE;
  e_found_city_lookup     EXCEPTION;
  l_qtd_erro_orig_sys_ref NUMBER := 0;
  l_qtd_erro_doc_type     NUMBER := 0;
  l_qtd_erro_cpf          NUMBER := 0;
  l_qtd_erro_cnpj         NUMBER := 0;
  l_qtd_erro_item         NUMBER := 0;
  l_qtd_erro_amount       NUMBER := 0;
  l_qtd_erro_operacao     NUMBER := 0;
  l_qtd_erro_trans_date   NUMBER := 0;
  l_qtd_erro_comments     NUMBER := 0;
  l_qtd_erro_elavon_fora  NUMBER := 0;
  l_qtd_erro_stone_fora   NUMBER := 0;
  l_qtd_doc_number_nulo   NUMBER := 0;
  l_exist_acento          VARCHAR2(1);
  e_doc_number_is_null    EXCEPTION;
  l_empresa_inser         VARCHAR2(100);
  l_comments_verif        VARCHAR2(2000);
  --
  -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
  l_qtd_erro_terms        NUMBER := 0;
  e_terms_no_data_found   EXCEPTION;
  e_terms_error_found     EXCEPTION;
  -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
  --
  FUNCTION get_col
    (
      P_NUMERO_COLUNA IN NUMBER
    )
    RETURN VARCHAR
  IS
  BEGIN
    RETURN trim(R_RET(P_NUMERO_COLUNA));
  EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
  END get_col;
--
  FUNCTION get_next_col
    RETURN VARCHAR
  IS
    l_retorno VARCHAR2(4000);
  BEGIN
    l_retorno := get_col(l_num_col);
    l_num_col := l_num_col + 1;
    RETURN l_retorno;
  END get_next_col;
--
BEGIN
  out_l('Carga de Transacoes- Inicio: ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
  --
  l_dir := fnd_profile.value('XXSTN_AR_INVOICES_DIR_IN'); --'XXSTN_AR_STN_IN'
  --
  -- rbs 2017/nov/28 - limpar stage para transacoes com status de processado
  BEGIN
    DELETE
    FROM xxstn_electronic_inv_interf
    WHERE file_name = P_FILE_NAME
    AND status      = 'P'
    AND creation_date <= SYSDATE - 14; --alt fpavao 23/01/2019
    --AND status <> 'PEND';
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
  END;
  --
  BEGIN
    SELECT file_name,
      MAX(creation_date)
    INTO l_file_name,
      l_creation_date
    FROM xxstn_electronic_inv_interf
    WHERE file_name = P_FILE_NAME
    AND status      = 'SUCCESS'
    GROUP BY file_name;
  EXCEPTION
  WHEN OTHERS THEN
    l_file_name := NULL;
  END;
  --
  IF l_file_name IS NOT NULL THEN
    retcode      := 1;
    OUT_l('The ' || P_File_Name || ' file was already processed before with Success in ' || TO_CHAR(l_creation_date, 'DD/MM/RRRR HH24:MI:MM') || '. Rename the file to processs it again');
    RETURN;
  END IF;
  --
  out_l('Directory..................: ' || l_dir);
  out_l('File Name..................: ' || l_arq);
  --
  BEGIN
    L_ARQDIR    := UTL_FILE.FOPEN(L_DIR, L_ARQ, 'R', 32000);
    l_qtde_sele := 0;
  EXCEPTION
  WHEN UTL_FILE.INVALID_PATH THEN
    RAISE_APPLICATION_ERROR(-20003, 'Invalid file name or directory ' || l_dir);
  WHEN UTL_FILE.INVALID_MODE THEN
    RAISE_APPLICATION_ERROR(-20004, 'Invalid parameter mode in FSOPEN');
  WHEN UTL_FILE.INVALID_FILEHANDLE THEN
    RAISE_APPLICATION_ERROR(-20005, 'The handle of the file is invalid');
  WHEN UTL_FILE.INVALID_OPERATION THEN
    RAISE_APPLICATION_ERROR(-20006, 'The file can not be opened');
  WHEN UTL_FILE.READ_ERROR THEN
    RAISE_APPLICATION_ERROR(-20007, 'Operating system error during reading');
  WHEN UTL_FILE.WRITE_ERROR THEN
    RAISE_APPLICATION_ERROR(-20008, 'Operating system error during recording');
  WHEN UTL_FILE.INTERNAL_ERROR THEN
    RAISE_APPLICATION_ERROR(-20009, 'An error occurred unidentified');
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20011, 'Error opening the file - ' || SQLERRM);
  END;
  --
  l_linha_out_p := REPLACE('ORG_CODE;ORIG_SYS_REF;DOC_TYPE;DOC_NUMBER;ITEM;AMOUNT;OPERACAO;TRANSACTION_DATE;COMMENTS',CHR(10), '');
  out_p(l_linha_out_p);
  LOOP
    BEGIN
      UTL_FILE.GET_LINE(L_ARQDIR, L_LINHA, 32000);
      l_qtde_sele   := l_qtde_sele + 1;
      IF l_qtde_sele = 1 THEN
        --l_qtde_sele := 0;
        IF Instr(L_LINHA, g_delim) = 0 THEN
          raise e_no_delimiter_found;
        END IF;
      END IF;
    EXCEPTION
    WHEN e_no_delimiter_found THEN
      RAISE_APPLICATION_ERROR(-20010, 'I necessario usar PONTO e VIRGULA entre os campos');
    WHEN NO_DATA_FOUND THEN
      EXIT;
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20011, 'Error select the file row - ' || SQLERRM);
    END;
    --
    IF l_qtde_sele > 1 AND LENGTH(TRIM(l_linha)) > 0 THEN
      DECLARE
        l_campo     VARCHAR2(50);
        l_campo_aux VARCHAR2(2000);
        --
      BEGIN
        reg       := NULL;
        l_num_col := 1;
        XXSTN_AR_CUSTOM_UTIL_PK.SPLIT_L_CSV(l_linha, g_delim, R_RET);
        --
        reg.file_name := p_file_name;
        --
        l_campo      := 'ORG_CODE';
        REG.ORG_CODE := get_next_col;
        REG.ORG_ID   := get_org_id(REG.ORG_CODE);
        --
        -- Campo Obrigatsrio
        IF reg.org_id IS NULL THEN
          raise e_invalid_org;
        END IF;
        --
        -- ***
        l_campo          := 'ORIG_SYS_REF';
        REG.ORIG_SYS_REF := get_next_col;
        l_orig_sys_ref   := REG.ORIG_SYS_REF;
        --            REG.ORIG_SYS_REF := '9'||get_next_col; -- carga retroativa da stone
        l_campo      := 'DOC_TYPE';
        REG.DOC_TYPE := get_next_col;
        l_campo      := 'DOC_NUMBER';
        REG.CNPJ_CPF := get_next_col;
        l_campo      := 'ITEM';
        REG.ITEM     := get_next_col;
        l_campo      := 'AMOUNT';
        l_campo_aux  := get_next_col;
        l_campo      := 'OPERACAO';
        --
        DECLARE
          l_aux VARCHAR2(4000) := '';
        BEGIN
          l_aux                 := upper(get_next_col); -- rbs 2017/12/07 upper
          IF l_aux              IS NULL THEN
            l_qtd_erro_operacao := l_qtd_erro_operacao + 1;
            raise e_operacao_is_null;
          END IF;
          IF l_aux NOT                                IN('I','C') THEN
            l_qtd_erro_operacao := l_qtd_erro_operacao + 1;
            raise e_operacao_is_invalid;
          END IF;
          --
          IF l_aux         = 'I' THEN
            reg.operation := 1;
          ELSIF L_AUX      = 'C' THEN
            reg.operation := 2;
          ELSE
            reg.operation := NULL;
          END IF;
          --
        END;
        IF reg.operation IN(1) THEN --inclusao
          IF REG.CNPJ_CPF         IS NULL THEN
            l_qtd_doc_number_nulo := l_qtd_doc_number_nulo + 1;
            raise e_doc_number_is_null;
          END IF;
          --alt fpavao 23/01/2019 begin
          --REG.ORIG_SYS_REF      := '';
          --alt fpavao 23/01/2019 end
          IF REG.DOC_TYPE       IS NULL THEN
            l_qtd_erro_doc_type := l_qtd_erro_doc_type + 1;
            raise e_doc_type_is_null;
          ELSIF REG.DOC_TYPE NOT                      IN(1,2,3) THEN
            l_qtd_erro_doc_type := l_qtd_erro_doc_type + 1;
            raise e_doc_type_invalid;
          END IF;
          IF REG.DOC_TYPE            = 1 THEN
            IF LENGTH(REG.CNPJ_CPF) <> 11 THEN
              l_qtd_erro_cpf        := l_qtd_erro_cpf + 1;
              --l_doc_type_1 := l_doc_type_1 - 1;
              raise e_cpf_tamanho_invalido;
            END IF;
            IF validy_cpf(REG.CNPJ_CPF) THEN
              NULL;
            ELSE
              l_qtd_erro_cpf := l_qtd_erro_cpf + 1;
              raise e_cpf_invalido;
            END IF;
          END IF;
          IF REG.DOC_TYPE            = 2 THEN
            IF LENGTH(REG.CNPJ_CPF) <> 14 THEN
              l_qtd_erro_cnpj       := l_qtd_erro_cnpj + 1;
              raise e_cnpj_tamanho_invalido;
            END IF;
            IF validy_cnpj(REG.CNPJ_CPF) THEN
              NULL;
            ELSE
              l_qtd_erro_cnpj := l_qtd_erro_cnpj + 1;
              raise e_cnpj_invalido;
            END IF;
          END IF;
          /*if REG.CNPJ_CPF like '%E+%' then
          l_campo := l_campo || ' ' || REG.CNPJ_CPF;
          IF REG.DOC_TYPE = 1 THEN
          l_qtd_erro_cpf := l_qtd_erro_cpf + 1;
          END IF;
          IF REG.DOC_TYPE = 2 THEN
          l_qtd_erro_cnpj := l_qtd_erro_cnpj + 1;
          END IF;
          raise e_invalid_cnpj_cpf;
          end if;*/
        ELSIF reg.operation IN(2) THEN --cancelamento
          IF REG.ORIG_SYS_REF       IS NULL THEN
            l_qtd_erro_orig_sys_ref := l_qtd_erro_orig_sys_ref + 1;
            raise e_orig_sys_ref_is_null;
          END IF;
        END IF;
        IF REG.ITEM       IS NULL THEN
          l_qtd_erro_item := l_qtd_erro_item + 1;
          raise e_item_is_null;
        END IF;
        l_cidade        := NULL;
        l_city          := NULL;
        l_empresa_inser := NULL;
        IF REG.ITEM      = '90002' THEN
          --verifica cidade do cliente
          BEGIN
            SELECT hz_loc.CITY
            INTO l_city
            FROM hz_party_sites hz_ps,
              hz_locations hz_loc,
              hz_cust_acct_sites_all hz_casa,
              hz_parties hz_p,
              hz_cust_accounts hz_ca,
              hz_cust_site_uses_all hz_csua
            WHERE hz_casa.party_site_id   = hz_ps.party_site_id
            AND hz_ps.status              = 'A'
            AND hz_loc.location_id        = hz_ps.location_id
            AND hz_casa.cust_account_id   = hz_ca.cust_account_id
            AND hz_casa.org_id            = REG.ORG_ID
            AND hz_casa.status            = 'A'
            AND hz_ca.status              = 'A'
            AND hz_csua.status            = 'A'
            AND hz_p.party_id             = hz_ps.party_id
            AND hz_p.status               = 'A'
            AND hz_csua.site_use_code     = 'SHIP_TO'
            AND hz_ca.party_id            = hz_p.party_id
            AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
            AND hz_casa.org_id            = REG.ORG_ID
            AND hz_casa.status            = 'A'
            AND hz_csua.primary_flag      = 'Y'
            AND ((hz_ca.account_number    = REG.CNPJ_CPF)
            OR (hz_ca.account_number      = TO_CHAR(TO_NUMBER(REG.CNPJ_CPF)))
            OR (hz_casa.GLOBAL_ATTRIBUTE2 = '2'
            AND hz_casa.GLOBAL_ATTRIBUTE3
              || hz_casa.GLOBAL_ATTRIBUTE4
              || hz_casa.GLOBAL_ATTRIBUTE5 = lpad(REG.CNPJ_CPF, 15, '0')));
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT hz_loc.CITY
              INTO l_city
              FROM hz_party_sites hz_ps,
                hz_locations hz_loc,
                hz_cust_acct_sites_all hz_casa,
                hz_parties hz_p,
                hz_cust_accounts hz_ca,
                hz_cust_site_uses_all hz_csua
              WHERE hz_casa.party_site_id   = hz_ps.party_site_id
              AND hz_ps.status              = 'A'
              AND hz_loc.location_id        = hz_ps.location_id
              AND hz_casa.cust_account_id   = hz_ca.cust_account_id
              AND hz_casa.org_id            = REG.ORG_ID
              AND hz_casa.status            = 'A'
              AND hz_ca.status              = 'A'
              AND hz_csua.status            = 'A'
              AND hz_p.party_id             = hz_ps.party_id
              AND hz_p.status               = 'A'
              AND hz_csua.site_use_code     = 'SHIP_TO'
              AND hz_ca.party_id            = hz_p.party_id
              AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
              AND hz_casa.org_id            = REG.ORG_ID
              AND hz_casa.status            = 'A'
              AND hz_csua.primary_flag      = 'Y'
              AND hz_ca.cust_account_id    IN
                (SELECT rct.ship_to_customer_id
                FROM ra_customer_trx_all rct ,
                  ra_cust_trx_types_all rctt
                WHERE rct.cust_trx_type_id = rctt.cust_trx_type_id
                AND rctt.type              = 'INV'
                  --ALT 3S 27/09/2018
                  --AND rct.trx_number = reg.orig_sys_ref
                AND CUSTOMER_TRX_ID IN
                  (SELECT MAX(CUSTOMER_TRX_ID)
                  FROM RA_CUSTOMER_TRX_ALL
                  WHERE TRX_NUMBER = TO_CHAR(reg.orig_sys_ref)
                  AND ORG_ID       = FND_GLOBAL.ORG_ID
                  )
                AND rct.org_id = FND_GLOBAL.ORG_ID
                );
            EXCEPTION
            WHEN OTHERS THEN
              l_city := NULL;
              --l_sqlerrm := SQLERRM;
              --l_total_error_city := l_total_error_city + 1;
              --raise e_city_found_error;
            END;
          WHEN OTHERS THEN
            l_city := NULL;
            --l_sqlerrm := SQLERRM;
            --l_total_error_city := l_total_error_city + 1;
            --raise e_city_found_error;
          END;
          l_item    := NULL;
          l_empresa := NULL;
          BEGIN
            SELECT DESCRIPTION
            INTO l_cidade
            FROM FND_LOOKUP_VALUES
            WHERE LOOKUP_TYPE = 'STN_ARTRX_'
              ||REG.ORG_CODE
              ||'_'
              ||REG.ITEM
            AND LANGUAGE    = 'PTB'
            AND LOOKUP_CODE = 'CIDADE';
          EXCEPTION
          WHEN OTHERS THEN
            --l_sqlerrm := SQLERRM;
            l_cidade      := NULL;
            l_lookup_city := 'STN_ARTRX_'||REG.ORG_CODE||'_'||REG.ITEM;
            --l_total_error_city := l_total_error_city + 1;
            --raise e_found_city_lookup;
          END;
          --inicio ALT 3S 01/11/2018
          IF l_cidade                                                        IS NOT NULL THEN
            IF REG.ORG_CODE IN('OU_STONE','OU_ELAVON') AND NVL(l_city,'CITY') = NVL(l_cidade,'CIDADE') AND REG.ITEM = '90002' THEN
              IF REG.ORG_CODE                                                 = 'OU_STONE' THEN
                l_empresa_inser                                              := 'OU_STONE';
                --l_tot_stone := l_tot_stone + 1;
              END IF;
              IF REG.ORG_CODE    = 'OU_ELAVON' THEN
                l_empresa_inser := 'OU_ELAVON';
                --l_tot_elavon := l_tot_elavon + 1;
              END IF;
            ELSIF REG.ORG_CODE IN('OU_STONE','OU_ELAVON') THEN
              l_item                   := REG.ITEM;
              l_empresa                := REPLACE(REG.ORG_CODE,'OU_');
              IF REG.ORG_CODE           = 'OU_ELAVON' THEN
                l_qtd_erro_elavon_fora := l_qtd_erro_elavon_fora + 1;
              END IF;
              IF REG.ORG_CODE          = 'OU_STONE' THEN
                l_qtd_erro_stone_fora := l_qtd_erro_stone_fora + 1;
              END IF;
              --l_total_error_city := l_total_error_city + 1;
              raise e_error_city_item_emp;
            ELSE
              NULL;
            END IF;
          END IF; --IF l_cidade IS NOT NULL THEN --fim ALT 3S 01/11/2018
        END IF;   --IF REG.ITEM = '90002' THEN
        --inicio ALT 3S 01/11/2018
        IF REG.ORG_CODE    = 'OU_STONE' THEN
          l_empresa_inser := 'OU_STONE';
          --l_tot_stone := l_tot_stone + 1;
        END IF;
        IF REG.ORG_CODE    = 'OU_ELAVON' THEN
          l_empresa_inser := 'OU_ELAVON';
          --l_tot_elavon := l_tot_elavon + 1;
        END IF;
        --fim ALT 3S 01/11/2018
        --
        BEGIN
          SELECT INVENTORY_ITEM_ID
          INTO REG.ITEM_ID
          FROM APPS.XXSTN_MTL_SYSTEM_ITEMS
          WHERE ORG_ID              = REG.ORG_ID
          AND CONCATENATED_SEGMENTS = REG.ITEM;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_qtd_erro_item := l_qtd_erro_item + 1;
          raise e_item_no_data_found;
        WHEN OTHERS THEN
          l_qtd_erro_item := l_qtd_erro_item + 1;
          l_sqlerrm       := SQLERRM;
          raise e_item_error_found;
        END;
        --
        --rbs 2017/nov/28
        IF exists_artrx_lookup(REG.ORG_CODE, REG.item) = 0 THEN
          raise e_invalid_lookup_setup;
        END IF;
        REG.AMOUNT          := to_number(l_campo_aux, l_number_mask, l_number_nls);
        IF REG.AMOUNT       <= 0 THEN
          l_qtd_erro_amount := l_qtd_erro_amount + 1;
          raise e_amount_menor_zero;
        END IF;
        --
        --l_campo           := 'CURRENCY_CODE';
        --REG.CURRENCY_CODE := NVL(get_next_col, l_currency_code);
        REG.CURRENCY_CODE := 'BRL';
        --
        l_campo_aux := NULL;
        l_campo     := 'TRANSACTION_DATE';
        l_campo_aux := get_next_col;
        IF reg.operation IN(1) THEN
          IF l_campo_aux          IS NULL THEN
            l_qtd_erro_trans_date := l_qtd_erro_trans_date + 1;
            raise e_trans_data_is_null;
          END IF;
        END IF;
        --
        BEGIN
          IF l_campo_aux         IS NOT NULL THEN
            REG.TRANSACTION_DATE := to_date(l_campo_aux, g_dt_format);
          ELSE
            REG.TRANSACTION_DATE := TRUNC(SYSDATE);
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          l_qtd_erro_trans_date := l_qtd_erro_trans_date + 1;
          l_sqlerrm             := sqlerrm;
          raise e_trans_data_error;
        END;
        --
        l_campo           := 'COMMENTS';
        l_campo_aux       := SUBSTR(get_next_col, 1, 2000);
        l_comments_verif  := l_campo_aux;
        l_exist_minuscula := NULL;
        BEGIN
          SELECT regexp_replace(l_comments_verif, '[^[:lower:]]')
          INTO l_exist_minuscula
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_minuscula := NULL;
        END;
        IF l_exist_minuscula  IS NOT NULL THEN
          l_qtd_erro_comments := l_qtd_erro_comments + 1;
          raise e_comment_letra_minuscula;
        END IF;
        l_exist_acento := NULL;
        BEGIN
          SELECT 'X'
          INTO l_exist_acento
          FROM DUAL
          WHERE regexp_like(l_comments_verif,'[����������������������������������������]');
        EXCEPTION
        WHEN OTHERS THEN
          l_exist_acento := NULL;
        END;
        IF l_exist_acento     IS NOT NULL THEN
          l_qtd_erro_comments := l_qtd_erro_comments + 1;
          raise e_comment_letra_acento;
        END IF;
        IF LENGTH(l_comments_verif) > 240 THEN
          REG.INTERNAL_NOTES       := SUBSTR(l_comments_verif,241,240);
          REG.COMMENTS             := SUBSTR(l_comments_verif,1,240);
        ELSE
          REG.INTERNAL_NOTES := '';
          REG.COMMENTS       := SUBSTR(l_comments_verif,1,240);
        END IF;
        REG.DESCRIPTION := '.';

        -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
        l_campo_aux := NULL;
        l_campo     := 'TERM_NAME';
        l_campo_aux := ltrim(rtrim(get_next_col));
        IF l_campo_aux is NULL THEN
          l_qtd_erro_terms := l_qtd_erro_terms + 1;
          raise e_terms_no_data_found;
        END IF;
        --
        BEGIN
          SELECT NAME
          INTO reg.term_name
          FROM apps.ra_terms_vl
          WHERE NAME = l_campo_aux;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_qtd_erro_terms := l_qtd_erro_terms + 1;
            raise e_terms_no_data_found;
          WHEN OTHERS THEN
            l_qtd_erro_terms := l_qtd_erro_terms + 1;
            l_sqlerrm       := SQLERRM;
            raise e_terms_error_found;
        END;
        --
        l_campo_aux := NULL;
        l_campo     := 'RECEIPT_METHOD_NAME';
        l_campo_aux := ltrim(rtrim(get_next_col));
        reg.receipt_method_name :=  REPLACE(replace(ltrim(rtrim(l_campo_aux)),chr(10),NULL),chr(13),NULL);
        -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
        --
        --
        --l_campo           := 'ELETRONIC_NUM';
        --REG.ELETRONIC_NUM := get_next_col;
        --
        --l_campo                   := 'ELETRONIC_VERIFY_CODE';
        --REG.ELETRONIC_VERIFY_CODE := get_next_col;
        --
        reg.creation_date    := SYSDATE;
        reg.created_by       := g_user_id;
        reg.last_updated_by  := g_user_id;
        reg.last_update_date := sysdate;
        reg.last_update_date := sysdate;
        reg.Status           := 'PEND';
        --
        reg.last_update_login := g_login_id;
        --
        -- rbs 2017/nov/29 - update quando registro ainda nao foi processado
        /*BEGIN
        SELECT count(1)
        INTO l_exists
        FROM XXSTN.xxstn_electronic_inv_interf
        WHERE ORG_ID = reg.ORG_ID
        AND ORIG_SYS_REF = reg.ORIG_SYS_REF
        AND OPERATION = reg.OPERATION
        AND STATUS <> 'PEND';
        EXCEPTION
        WHEN others THEN
        l_exists := 0;
        END;
        IF l_exists > 0 THEN
        l_campo := 'update';
        UPDATE XXSTN.xxstn_electronic_inv_interf
        SET FILE_NAME             = reg.file_name,
        CNPJ_CPF              = reg.cnpj_cpf,
        AMOUNT                = reg.amount,
        CREATION_DATE         = reg.creation_date,
        CREATED_BY            = reg.created_by,
        LAST_UPDATE_DATE      = reg.last_update_date,
        LAST_UPDATED_BY       = reg.last_updated_by,
        LAST_UPDATE_LOGIN     = reg.last_update_login,
        STATUS                = reg.status,
        ERROR_MESSAGE         = reg.error_message,
        CURRENCY_CODE         = reg.currency_code,
        IBGE_CODE             = reg.ibge_code,
        ITEM                  = reg.item,
        ELETRONIC_NUM         = reg.eletronic_num,
        ELETRONIC_VERIFY_CODE = reg.eletronic_verify_code,
        DESCRIPTION           = reg.description,
        TRANSACTION_DATE      = reg.transaction_date,
        CITY                  = reg.city,
        STATE                 = reg.state,
        ITEM_ID               = reg.item_id,
        ORG_CODE              = reg.org_code,
        COMMENTS              = reg.comments
        --                  ,ID = reg.id
        WHERE ORG_ID = reg.ORG_ID
        AND ORIG_SYS_REF = reg.ORIG_SYS_REF
        AND OPERATION = reg.OPERATION;
        l_qtde_updt := l_qtde_updt + 1;*/
        --ELSE

        --alt fpavao 23/01/2019 begin
        BEGIN
          SELECT XXSTN_AR_INTERF_LINE_ATTRIB1_S.nextval
          INTO reg.interface_line_attribute1
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;
        --alt fpavao 23/01/2019 end

        l_campo := 'insert';
        INSERT INTO XXSTN.xxstn_electronic_inv_interf VALUES reg;
        l_qtde_inse    := l_qtde_inse + 1;
        IF REG.DOC_TYPE = 1 THEN
          l_doc_type_1 := l_doc_type_1 + 1;
        END IF;
        IF REG.DOC_TYPE = 2 THEN
          l_doc_type_2 := l_doc_type_2 + 1;
        END IF;
        IF REG.DOC_TYPE = 3 THEN
          l_doc_type_3 := l_doc_type_3 + 1;
        END IF;
        IF NVL(l_empresa_inser,'NULO')    = 'OU_STONE' THEN
          l_tot_stone                    := l_tot_stone + 1;
        ELSIF NVL(l_empresa_inser,'NULO') = 'OU_ELAVON' THEN
          l_tot_elavon                   := l_tot_elavon + 1;
        END IF;
        --END IF;
        -- end rbs 2017/nov/29
        --
      EXCEPTION
      WHEN e_found_city_lookup THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao tentar encontrar cidade na lookup: '||l_lookup_city||' - '||l_sqlerrm,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_error_city_item_emp THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Cliente fora da cidade de '||l_cidade||' para item '||l_item||' e empresa '||l_empresa,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_city_found_error THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao tentar encontrar cidade do cliente: '||l_sqlerrm,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_comment_letra_minuscula THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo COMMENT nao pode conter letra minuscula',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_comment_letra_acento THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo COMMENT nao pode conter acentuacao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_doc_number_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DOC_NUMBER nao pode ser nulo para tipo operacao Inclusao',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_trans_data_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo TRANSACTION_DATE nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_trans_data_error THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro Campo TRANSACTION_DATE: '||l_sqlerrm,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_operacao_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo OPERATION nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_operacao_is_invalid THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Valor para campo OPERATION invalido',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_amount_menor_zero THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo AMOUNT tem que ser positivo e maior que 0',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_item_is_null THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ITEM nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_item_error_found THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao encontrar ITEM: '||l_sqlerrm,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_item_no_data_found THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Nao encontrado ITEM cadastrado',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_doc_type_is_null THEN
        retcode := 1;
        --l_qtd_erro_doc_type := l_qtd_erro_doc_type + 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DOC_TYPE nao pode ser nulo',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_doc_type_invalid THEN
        retcode := 1;
        --l_qtd_erro_doc_type := l_qtd_erro_doc_type + 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo DOC_TYPE diferente de 1, 2 ou 3',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_orig_sys_ref_is_null THEN
        retcode := 1;
        --l_qtd_erro_orig_sys_ref := l_qtd_erro_orig_sys_ref + 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Campo ORIG_SYS_REF nao pode ser nulo para operacao cancelamento',CHR(13), '');
        out_p(l_linha_out_p);
        --rbs 2017/dec/28
      WHEN e_invalid_cnpj_cpf THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CPNJ/CPF invalido - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cpf_tamanho_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Tamanho campo CPF invalido - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cnpj_tamanho_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Tamanho campo CNPJ invalido - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cpf_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CPF invalido ',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_cnpj_invalido THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CNPJ invalido ',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_invalid_org THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Organizacao invalida - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
        --rbs 2017/nov/28
      WHEN e_invalid_lookup_setup THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Nao existe setup para este item ' ||REG.ORG_CODE || ' ' || REG.item||' - campo ' || l_campo,CHR(13), '');
        out_p(l_linha_out_p);
        --rbs 2017/nov/28
      --
      --
      WHEN e_terms_no_data_found THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Nao encontrado Condicao Pagamento cadastrado.',CHR(13), '');
        out_p(l_linha_out_p);
      WHEN e_terms_error_found THEN
        retcode       := 1;
        l_qtde_erro   := l_qtde_erro + 1;
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao encontrar Condicao Pagamento: '||l_sqlerrm,CHR(13), '');
        out_p(l_linha_out_p);
      --
      --
      WHEN OTHERS THEN
        retcode     := 1;
        l_qtde_erro := l_qtde_erro + 1;
        l_sqlerrm   := SQLERRM;
        /*IF l_sqlerrm like '%XXSTN_ELECTRONIC_INV_INTF_U01%' THEN
        l_sqlerrm := 'Nota ref ' || reg.ORIG_SYS_REF ||
        ' ja cadastrada na tabela temporaria';
        out_p(l_linha||';'||l_qtde_sele||';'||'Nota ref ' || reg.ORIG_SYS_REF ||
        ' ja cadastrada na tabela temporaria');
        ELS*/
        IF l_sqlerrm LIKE '%XXSTN_ELECTRONIC_INV_INTF_FK1%' THEN
          l_sqlerrm     := 'Operating Unit ' || reg.org_id || ' nao cadastrada';
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Operating Unit ' || reg.org_id ||' nao cadastrada',CHR(13), '');
          out_p(l_linha_out_p);
          l_unid_oper_erro := l_unid_oper_erro + 1;
        ELSIF l_sqlerrm LIKE '%XXSTN_ELECTRONIC_INV_INTF_FK2%' THEN
          l_sqlerrm     := 'Item ' || reg.item || ' nao cadastrado';
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Item ' || reg.item ||' nao cadastrado',CHR(10), '');
          out_p(l_linha_out_p);
          l_qtd_erro_item := l_qtd_erro_item + 1;
        ELSIF l_sqlerrm LIKE '%XXSTN_ELECTRONIC_INV_INTF_FK3%' THEN
          l_sqlerrm     := 'Operacao nao ' || reg.operation || ' cadastrada';
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Operacao nao ' || reg.operation ||' cadastrada',CHR(13), '');
          out_p(l_linha_out_p);
          l_qtd_erro_operacao := l_qtd_erro_operacao + 1;
        ELSIF l_sqlerrm LIKE '%XXSTN_ELECTRONIC_INV_INTF_FK4%' THEN
          l_sqlerrm     := 'CNPJ/CPF ' || reg.cnpj_cpf ||' nao cadastrado';
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'CNPJ/CPF ' || reg.cnpj_cpf ||' nao cadastrado',CHR(13), '');
          out_p(l_linha_out_p);
          IF REG.DOC_TYPE   = 1 THEN
            l_qtd_erro_cpf := l_qtd_erro_cpf + 1;
          END IF;
          IF REG.DOC_TYPE    = 2 THEN
            l_qtd_erro_cnpj := l_doc_type_2 + 1;
          END IF;
        ELSE
          l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao Processar a Linha - '||l_sqlerrm||' - campo ' || l_campo||' - campo aux '||l_campo_aux,CHR(13), '');
          out_p(l_linha_out_p);
          IF REG.DOC_TYPE   = 1 THEN
            l_qtd_erro_cpf := l_qtd_erro_cpf + 1;
          END IF;
          IF REG.DOC_TYPE    = 2 THEN
            l_qtd_erro_cnpj := l_doc_type_2 + 1;
          END IF;
        END IF;
        /*                        l_qtde_erro := l_qtde_erro + 1;
        if l_campo in ('insert', 'update') then
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||l_sqlerrm,CHR(13), '');
        out_p(l_linha_out_p);
        else
        l_linha_out_p := REPLACE(l_linha||';'||l_qtde_sele||';'||'Erro ao Processar a Linha - '||l_sqlerrm||' - campo ' || l_campo||' - campo aux '||l_campo_aux,CHR(13), '');
        out_p(l_linha_out_p);
        end if;*/
        --OUT_l('...Texto: ' || l_linha);
      END;
    END IF;
  END LOOP;
  --
  UTL_FILE.FCLOSE(L_ARQDIR);
  --
  out_l('Total Records selected ...................................: ' || l_qtde_sele);
  out_l('Total Records inserted ...................................: ' || l_qtde_inse);
  --out_l('Total Records updated ....................................: ' || l_qtde_updt);
  out_l('total Records with errors ................................: ' || l_qtde_erro||CHR(10));
  out_l('Total Records DOC_TYPE 1 CPF .............................: ' || l_doc_type_1);
  out_l('Total Records DOC_TYPE 2 CNPJ ............................: ' || l_doc_type_2);
  out_l('Total Records DOC_TYPE 3 Others ..........................: ' || l_doc_type_3||CHR(10));
  out_l('Total Records ELAVON SAO PAULO 90002 .....................: ' || l_tot_elavon);
  out_l('Total Records STONE SAO PAULO 90002 ......................: ' || l_tot_stone||CHR(10)||CHR(10));
  out_l('Total Inconsistencias encontradas ........................: ' || l_qtde_erro||CHR(10)||CHR(10));
  out_l('Total Records invoices with wrong ORIG_SYS_REF ...........: ' ||l_qtd_erro_orig_sys_ref);
  out_l('Total Records invoices with wrong DOC_TYPE ...............: ' ||l_qtd_erro_doc_type);
  out_l('Total Records invoices with wrong DOC_NUMBER 1 CPF .......: ' ||l_qtd_erro_cpf);
  out_l('Total Records invoices with wrong DOC_NUMBER 2 CNPJ ......: ' ||l_qtd_erro_cnpj);
  out_l('Total Records invoices with wrong DOC_NUMBER nulo ........: ' ||l_qtd_doc_number_nulo);
  --out_l('Total Records invoices with wrong CITY ...................: ' ||l_total_error_city);
  --out_l('Total Records invoices with wrong DOC_NUMBER 3 Others ....: ' ||);
  out_l('Total Records invoices with wrong ITEM ...................: ' ||l_qtd_erro_item);
  out_l('Total Records invoices with wrong AMOUNT .................: ' ||l_qtd_erro_amount);
  out_l('Total Records invoices with wrong OPERACAO ...............: ' ||l_qtd_erro_operacao);
  out_l('Total Records invoices with wrong TRANSACTION_DATE .......: ' ||l_qtd_erro_trans_date);
  out_l('Total Records invoices with wrong COMMENTS ...............: ' ||l_qtd_erro_comments);
  out_l('Total Records invoices with wrong UNIDADE OPERACIONAL ....: ' ||l_unid_oper_erro);
  out_l('Total Records ELAVON FORA SAO PAULO 90002 ................: ' ||l_qtd_erro_elavon_fora);
  out_l('Total Records STONE FORA SAO PAULO 90002 .................: ' ||l_qtd_erro_stone_fora);
  --
  out_l('Carga de Transacoes- Termino: ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
END AR_TEXT_FILE_INVOICE_LOAD;
/**
* PROCESSO CONCORRENTE QUE LE AS INFORMACOES PENDENTES
* NA TABELA CUSTOMIZADA, E INSERE NAS TABELAS DE OPEN INTERFA DO AR
*/
PROCEDURE PROCESSA_ITF_AR
  (
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2,
    p_file_name IN VARCHAR2 --alt fpavao 23/01/2019
  )
IS
  CURSOR c_pend
  IS
    SELECT x.FILE_NAME,
      x.CNPJ_CPF,
      x.AMOUNT,
      x.STATUS,
      x.ERROR_MESSAGE,
      x.COMMENTS,
      x.ORG_ID,
      x.ORIG_SYS_REF,
      x.CURRENCY_CODE,
      x.OPERATION,
      x.IBGE_CODE,
      x.ITEM,
      x.ELETRONIC_NUM,
      x.ELETRONIC_VERIFY_CODE,
      x.DESCRIPTION,
      x.TRANSACTION_DATE,
      x.CITY,
      x.STATE,
      x.ITEM_ID,
      x.ORG_CODE,
      x.INTERNAL_NOTES,
      x.interface_line_attribute1, --alt fpavao 23/01/2019
      --
      -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
      x.term_name,
      x.receipt_method_name,
      -- End -- 15/05/2020  -- #SR-381687 - Ticket 319239
      --
      x.rowid AS xid
    FROM XXSTN.XXSTN_ELECTRONIC_INV_INTERF x
    WHERE STATUS                                      IN ('PEND', 'E') -- rbs 2017/nov/29
    AND XXSTN_AR_CUSTOM_UTIL_PK.IS_valid_org(x.org_id) = 'Y'
    AND FILE_NAME = p_file_name; ----alt fpavao 23/01/2019
  l_pend c_pend%rowtype;
  reg ra_interface_lines_all%rowtype;
  --
  l_orig_system_reference_site apps.hz_cust_accounts.orig_system_reference%type;
  l_orig_system_reference_loc apps.hz_cust_acct_sites_all.orig_system_reference%type;
  l_orig_system_reference_ship apps.hz_cust_acct_sites_all.orig_system_reference%type;
  l_orig_sys_ref_ship_state VARCHAR2(40);
  l_state_inv_org           VARCHAR2(40);
  -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
  l_customer_id          hz_cust_accounts_all.cust_account_id%TYPE;
  l_site_use_id          hz_cust_site_uses_all.site_use_id%TYPE;
  -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
  l_ret_status           BOOLEAN;
  l_ret_mensagem         VARCHAR2(4000);
  l_orig_trx_type        VARCHAR2(4000);
  l_orig_trx_type_canc   VARCHAR2(4000); -- rbs 2017/12/07
  l_orig_trx_type_ISENTO VARCHAR2(4000);
  l_aux                  VARCHAR2(500);
  l_campo                VARCHAR2(500);
  l_warehouse_id         NUMBER;
  l_ref_line_id          NUMBER; -- rbs 2017/12/07
  l_ref_customer_trx_id  NUMBER; -- rbs 2017/12/07
  --  l_description                  ar.ra_interface_lines_all.description%TYPE;
  l_receipt_method_name ra_interface_lines_all.receipt_method_name%TYPE;
  l_term_name ra_interface_lines_all.term_name%TYPE;
  l_batch_source_name ra_interface_lines_all.batch_source_name%TYPE;
  l_cust_trx_type_name ra_interface_lines_all.cust_trx_type_name%TYPE;
  l_cust_trx_type_name_isento ra_interface_lines_all.cust_trx_type_name%TYPE;
  --
  l_line_gdf_attribute3 VARCHAR2(100);
  l_line_gdf_attribute4 VARCHAR2(100);
  l_line_gdf_attribute5 VARCHAR2(100);
  l_line_gdf_attribute6 VARCHAR2(100);
  l_line_gdf_attribute7 VARCHAR2(100);
  l_line_attribute15    VARCHAR2(100); --rbs
  l_uom_code            VARCHAR2(20);
  l_cfop                VARCHAR2(100);
  l_tax_code            VARCHAR2(100);
  l_aliq_irrf           NUMBER := 0;
  l_qtde_sele           NUMBER := 0;
  l_qtde_inse           NUMBER := 0;
  l_qtde_erro           NUMBER := 0;
  l_qtde_sele_reg       NUMBER := 0;
  l_qtde_inse_reg       NUMBER := 0;
  l_qtde_erro_reg       NUMBER := 0;
  l_cont_operation_1    NUMBER;
  e_nf_nota_found       EXCEPTION;
  --
  -- Processo Auxiliar que busca o Estado da organizacaoo de inventario
  --
  PROCEDURE GET_ESTADO_INV_ORG(
      p_organization_id IN NUMBER,
      p_state OUT VARCHAR2)
  IS
  BEGIN
    SELECT region_2
    INTO p_state
    FROM hr_locations_v
    WHERE inventory_organization_id = p_organization_id;
  EXCEPTION
  WHEN OTHERS THEN
    p_state := NULL;
  END;
--
  PROCEDURE GET_DERIV_CFOP(
      p_customer_state     IN VARCHAR2,
      p_inv_org_state      IN VARCHAR2,
      p_cust_trx_type_name IN VARCHAR2,
      p_org_id             IN NUMBER,
      p_cfop OUT VARCHAR2)
  IS
    V_OPERATION_DEST VARCHAR2(100);
  BEGIN
    OUT_L('p_customer_state:      ' || p_customer_state);
    OUT_L('p_inv_org_state:       ' || p_inv_org_state);
    OUT_L('p_cust_trx_type_name:  ' || p_cust_trx_type_name);
    OUT_L('p_org_id:              ' || p_org_id);
    IF p_customer_state = p_inv_org_state THEN
      V_OPERATION_DEST := 'INTRASTATE';
    ELSE
      V_OPERATION_DEST := 'INTERSTATE';
    END IF;
    --
    OUT_L('V_OPERATION_DEST:      ' || V_OPERATION_DEST);
    SELECT CFOP_CODE
    INTO p_cfop
    FROM JL_BR_CFOP_DERIV_LINES l,
      JL_BR_CFOP_DERIV_HDR_ALL h,
      RA_CUST_TRX_TYPES_ALL RCTTA
    WHERE h.org_id         = p_org_id
    AND OPERATION_TYPE     = 'EXIT'
    AND OPERATION_DEST     = V_OPERATION_DEST
    AND H.CFOP_HEADER_ID   = L.CFOP_HEADER_ID
    AND RCTTA.NAME         = p_cust_trx_type_name
    AND RCTTA.ORG_ID       = p_org_id
    AND L.CUST_TRX_TYPE_ID = RCTTA.CUST_TRX_TYPE_ID;
    OUT_L('p_cfop:                ' || p_cfop);
  EXCEPTION
  WHEN OTHERS THEN
    p_cfop := NULL;
  END;
--
/**
* Procedimento Auxiliar que recupera
* os dados de referencia do cliente para utilizacao
* na interface
*/
  PROCEDURE GET_CUSTOMER(
      P_CNPJ_CPF   IN VARCHAR,
      P_ORG_ID     IN NUMBER,
      P_TRX_NUMBER IN VARCHAR
      --
      ,
      -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
      r_customer_id OUT NUMBER,
      r_site_use_id OUT NUMBER,
      -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
      r_orig_system_reference_site OUT VARCHAR,
      r_orig_system_reference_loc OUT VARCHAR,
      r_orig_system_reference_ship OUT VARCHAR,
      r_orig_sys_ref_ship_state OUT VARCHAR,
      r_ret_status OUT BOOLEAN,
      r_ret_mensagem OUT VARCHAR)
  IS
  BEGIN
    r_ret_status := true;
    --
    SELECT hz_ca.orig_system_reference,
           hz_casa.orig_system_reference orig_system_reference_loc,
           -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
           hz_ca.cust_account_id,
           hz_csua.site_use_id
           -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
    INTO r_orig_system_reference_site,
         r_orig_system_reference_loc,
         -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
         r_customer_id,
         r_site_use_id
         -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
    FROM hz_party_sites hz_ps,
      hz_locations hz_loc,
      hz_cust_acct_sites_all hz_casa,
      hz_parties hz_p,
      hz_cust_accounts hz_ca,
      hz_cust_site_uses_all hz_csua
    WHERE hz_casa.party_site_id   = hz_ps.party_site_id
    AND hz_ps.status              = 'A'
    AND hz_loc.location_id        = hz_ps.location_id
    AND hz_casa.cust_account_id   = hz_ca.cust_account_id
    AND hz_casa.org_id            = P_ORG_ID
    AND hz_casa.status            = 'A'
    AND hz_ca.status              = 'A'
    AND hz_csua.status            = 'A'
    AND hz_p.party_id             = hz_ps.party_id
    AND hz_p.status               = 'A'
    AND hz_csua.site_use_code     = 'BILL_TO'
    AND hz_ca.party_id            = hz_p.party_id
    AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
    AND hz_casa.org_id            = P_ORG_ID
    AND hz_casa.status            = 'A'
    AND hz_csua.primary_flag      = 'Y'
    AND ((hz_ca.account_number    = p_cnpj_cpf)
    OR (hz_ca.account_number      = TO_CHAR(TO_NUMBER(p_cnpj_cpf)))
    OR (hz_casa.GLOBAL_ATTRIBUTE2 = '2'
    AND hz_casa.GLOBAL_ATTRIBUTE3
      || hz_casa.GLOBAL_ATTRIBUTE4
      || hz_casa.GLOBAL_ATTRIBUTE5 = lpad(p_cnpj_cpf, 15, '0')));
    SELECT hz_casa.orig_system_reference orig_system_reference_loc,
      hz_loc.state orig_sys_ref_ship_state
    INTO R_orig_system_reference_ship,
      r_orig_sys_ref_ship_state
    FROM hz_party_sites hz_ps,
      hz_locations hz_loc,
      hz_cust_acct_sites_all hz_casa,
      hz_parties hz_p,
      hz_cust_accounts hz_ca,
      hz_cust_site_uses_all hz_csua
    WHERE hz_casa.party_site_id   = hz_ps.party_site_id
    AND hz_ps.status              = 'A'
    AND hz_loc.location_id        = hz_ps.location_id
    AND hz_casa.cust_account_id   = hz_ca.cust_account_id
    AND hz_casa.org_id            = p_org_id
    AND hz_casa.status            = 'A'
    AND hz_ca.status              = 'A'
    AND hz_csua.status            = 'A'
    AND hz_p.party_id             = hz_ps.party_id
    AND hz_p.status               = 'A'
    AND hz_csua.site_use_code     = 'SHIP_TO'
    AND hz_ca.party_id            = hz_p.party_id
    AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
    AND hz_casa.org_id            = p_org_id
    AND hz_casa.status            = 'A'
    AND hz_csua.primary_flag      = 'Y'
    AND ((hz_ca.account_number    = p_cnpj_cpf)
    OR (hz_ca.account_number      = TO_CHAR(TO_NUMBER(p_cnpj_cpf)))
    OR (hz_casa.GLOBAL_ATTRIBUTE2 = '2'
    AND hz_casa.GLOBAL_ATTRIBUTE3
      || hz_casa.GLOBAL_ATTRIBUTE4
      || hz_casa.GLOBAL_ATTRIBUTE5 = lpad(p_cnpj_cpf, 15, '0')));
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    BEGIN
      SELECT hz_ca.orig_system_reference,
        hz_casa.orig_system_reference orig_system_reference_loc
      INTO r_orig_system_reference_site,
        r_orig_system_reference_loc
      FROM hz_party_sites hz_ps,
        hz_locations hz_loc,
        hz_cust_acct_sites_all hz_casa,
        hz_parties hz_p,
        hz_cust_accounts hz_ca,
        hz_cust_site_uses_all hz_csua
      WHERE hz_casa.party_site_id   = hz_ps.party_site_id
      AND hz_ps.status              = 'A'
      AND hz_loc.location_id        = hz_ps.location_id
      AND hz_casa.cust_account_id   = hz_ca.cust_account_id
      AND hz_casa.org_id            = P_ORG_ID
      AND hz_casa.status            = 'A'
      AND hz_ca.status              = 'A'
      AND hz_csua.status            = 'A'
      AND hz_p.party_id             = hz_ps.party_id
      AND hz_p.status               = 'A'
      AND hz_csua.site_use_code     = 'BILL_TO'
      AND hz_ca.party_id            = hz_p.party_id
      AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
      AND hz_casa.org_id            = P_ORG_ID
      AND hz_casa.status            = 'A'
      AND hz_csua.primary_flag      = 'Y'
      AND hz_ca.cust_account_id    IN
        (SELECT rct.ship_to_customer_id
        FROM ra_customer_trx_all rct ,
          ra_cust_trx_types_all rctt
        WHERE rct.cust_trx_type_id = rctt.cust_trx_type_id
        AND rctt.type              = 'INV'
          --ALT 3S 27/09/2018
          --AND rct.trx_number = P_TRX_NUMBER
        AND CUSTOMER_TRX_ID IN
          (SELECT MAX(CUSTOMER_TRX_ID)
          FROM RA_CUSTOMER_TRX_ALL
          WHERE TRX_NUMBER = TO_CHAR(P_TRX_NUMBER)
          AND ORG_ID       = P_ORG_ID
          )
        AND rct.org_id = FND_GLOBAL.ORG_ID
        );
      SELECT hz_casa.orig_system_reference orig_system_reference_loc,
        hz_loc.state orig_sys_ref_ship_state
      INTO R_orig_system_reference_ship,
        r_orig_sys_ref_ship_state
      FROM hz_party_sites hz_ps,
        hz_locations hz_loc,
        hz_cust_acct_sites_all hz_casa,
        hz_parties hz_p,
        hz_cust_accounts hz_ca,
        hz_cust_site_uses_all hz_csua
      WHERE hz_casa.party_site_id   = hz_ps.party_site_id
      AND hz_ps.status              = 'A'
      AND hz_loc.location_id        = hz_ps.location_id
      AND hz_casa.cust_account_id   = hz_ca.cust_account_id
      AND hz_casa.org_id            = p_org_id
      AND hz_casa.status            = 'A'
      AND hz_ca.status              = 'A'
      AND hz_csua.status            = 'A'
      AND hz_p.party_id             = hz_ps.party_id
      AND hz_p.status               = 'A'
      AND hz_csua.site_use_code     = 'SHIP_TO'
      AND hz_ca.party_id            = hz_p.party_id
      AND hz_casa.cust_acct_site_id = hz_csua.cust_acct_site_id
      AND hz_casa.org_id            = p_org_id
      AND hz_casa.status            = 'A'
      AND hz_csua.primary_flag      = 'Y'
      AND hz_ca.cust_account_id    IN
        (SELECT rct.ship_to_customer_id
        FROM ra_customer_trx_all rct ,
          ra_cust_trx_types_all rctt
        WHERE rct.cust_trx_type_id = rctt.cust_trx_type_id
        AND rctt.type              = 'INV'
          --ALT 3S 27/09/2018
          --AND rct.trx_number = P_TRX_NUMBER
        AND CUSTOMER_TRX_ID IN
          (SELECT MAX(CUSTOMER_TRX_ID)
          FROM RA_CUSTOMER_TRX_ALL
          WHERE TRX_NUMBER = TO_CHAR(P_TRX_NUMBER)
          AND ORG_ID       = P_ORG_ID
          )
        AND rct.org_id = FND_GLOBAL.ORG_ID
        );
    EXCEPTION
    WHEN OTHERS THEN
      r_ret_mensagem := 'Erro ao recuperar Cliente: ' || p_cnpj_cpf || ' ' || SQLERRM;
      r_ret_status   := false;
    END;
    --r_ret_mensagem := 'Erro: Cliente Nao Encontrado: ' ||
    --                  p_cnpj_cpf || ' - Org ' || p_org_id;
    --r_ret_status   := false;
  WHEN OTHERS THEN
    r_ret_mensagem := 'Erro ao recuperar Cliente: ' || p_cnpj_cpf || ' ' || SQLERRM;
    r_ret_status   := false;
  END GET_CUSTOMER;
/*
* Procedimento Auxiliar para preenchimento do campo corrente que esta sendo processado.
*/
  PROCEDURE CAMPO(
      P_VALOR IN VARCHAR)
  IS
  BEGIN
    L_CAMPO := p_valor;
  END campo;
/*
* Procedimento Auxiliar que atualiza o Status
* e faz incremento dos contadores do processamento atual
*/
  PROCEDURE UPDATE_ST(
      P_STATUS IN VARCHAR)
  IS
  BEGIN
    --
    IF P_STATUS    = 'PEND' THEN
      l_qtde_inse := l_qtde_inse + 1;
    ELSIF P_STATUS = 'E' THEN
      l_qtde_erro := l_qtde_erro + 1;
    ELSIF P_STATUS = 'R' THEN
      l_qtde_sele := l_qtde_sele + 1;
    END IF;
    --
    l_pend.STATUS := p_Status;
    --
    BEGIN
      UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
      SET STATUS         = P_STATUS,
        ERROR_MESSAGE    = L_PEND.ERROR_MESSAGE,
        ORG_CODE         = l_pend.ORG_CODE,
        ITEM             = l_pend.item,
        LAST_UPDATED_BY  = g_user_id,
        last_update_date = sysdate
        --,last_update_login = l_login_id
      WHERE rowid = l_pend.xid;
    EXCEPTION
    WHEN OTHERS THEN
      OUT_L('Erro ao buscar o CFOP - '||SQLERRM);
    END;
  END UPDATE_ST;
--
BEGIN
  init_audit;
  --
  out_p('Carga de Transacoes- Inicio: ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
  out_p('');
  --
  OPEN c_pend;
  LOOP
    FETCH c_pend INTO l_pend;
    EXIT
  WHEN c_pend%notFound;
    l_qtde_sele_reg := l_qtde_sele_reg + 1;
    --
    BEGIN
      --
      reg := NULL;
      UPDATE_ST('R');
      CAMPO('EMPRESA');
      l_pend.ORG_CODE := get_org_name(l_pend.org_id);
      --
      CAMPO('ITEM');
      l_campo := 'ITEM';
      SELECT CONCATENATED_SEGMENTS
      INTO l_Pend.item
      FROM APPS.XXSTN_MTL_SYSTEM_ITEMS
      WHERE ORG_ID          = l_pend.org_id
      AND inventory_item_Id = l_pend.item_id;
      --
      l_campo := 'CLIENTE';
      CAMPO('CLIENTE');
      GET_CUSTOMER(P_CNPJ_CPF => l_pend.cnpj_cpf
                 , P_ORG_ID => l_pend.org_id
                 , P_TRX_NUMBER => l_pend.orig_sys_ref
                 -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
                 , r_customer_id => l_customer_id
                 , r_site_use_id => l_site_use_id
                 -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239
                 , r_orig_system_reference_site => l_orig_system_reference_site
                 , r_orig_system_reference_loc => l_orig_system_reference_loc
                 , r_orig_system_reference_ship => l_orig_system_reference_ship
                 , r_orig_sys_ref_ship_state => l_orig_sys_ref_ship_state
                 , r_ret_status => l_ret_status
                 , r_ret_mensagem => l_ret_mensagem);
      --
      IF l_ret_status         = false THEN
        l_pend.ERROR_MESSAGE := l_ret_mensagem;
        UPDATE_ST('E');
      END IF;
      --
      -- Criar NF
      IF l_pend.operation = 1 THEN --insert
        CAMPO('OPERACAO');
        --
        l_orig_trx_type        := 'TIPO TRANSACAO';
        l_orig_trx_type_ISENTO := 'TIPO TRANSACAO ISENTO';
        --
        l_campo := 'DEPOSITO';
        CAMPO('DEPOSITO');
        BEGIN
          L_AUX := GET_ARTRX_LOOKUP(L_PEND.ORG_CODE, 'DEPOSITO', L_PEND.ITEM);
          --
          SELECT ORGANIZATION_ID
          INTO L_WAREHOUSE_ID
          FROM APPS.ORG_ORGANIZATION_DEFINITIONS
          WHERE ORGANIZATION_NAME = L_AUX; --FND_PROFILE.VALUE('XXSTN_AR_INVOICES_WAREHOUSE');
        END;
        --
        l_campo := 'METODO PAGAMENTO';
        CAMPO('METODO PAGAMENTO');
        l_receipt_method_name := replace(replace(ltrim(rtrim(l_pend.receipt_method_name)),chr(13),NULL),chr(10)); 
        -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
        
        BEGIN
          l_aux := REPLACE(replace(ltrim(rtrim(l_pend.receipt_method_name)),chr(13),NULL),chr(10));          --
          fnd_file.put_line(fnd_file.log,'metodo='||l_customer_id||'-'||l_site_use_id||'-'||l_aux||'%');
          IF l_aux IS NOT NULL THEN 
            SELECT a.name
              INTO l_receipt_method_name
              FROM apps.ar_receipt_methods      a,
                   apps.ra_cust_receipt_methods b
             WHERE b.customer_id                   = l_customer_id
               AND b.site_use_id                   = l_site_use_id
               AND b.receipt_method_id             = a. receipt_method_id
               AND a.name                          = l_aux
               AND b.start_date                   <= sysdate
               AND nvl(b.end_date,trunc(sysdate)) >= trunc(sysdate);
               fnd_file.put_line(fnd_file.log,'depois select metodo');
          END IF;
        END;
        -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239

        l_campo               := 'CONDICAO PAGAMENTO';
        CAMPO('CONDICAO PAGAMENTO');
        -- Begin -- 15/05/2020 -- #SR-381687 - Ticket 319239
        --l_term_name := get_artrx_lookup(l_pend.ORG_CODE, 'CONDICAO PAGAMENTO', l_pend.item);
        l_term_name := l_pend.term_name;
        -- End -- 15/05/2020 -- #SR-381687 - Ticket 319239

        l_campo     := 'ORIGEM TRANSACAO';
        CAMPO('ORIGEM TRANSACAO');
        --alt 23/01/2019 fpavao begin
        IF L_PEND.ORIG_SYS_REF IS NULL THEN

         l_batch_source_name := get_artrx_lookup(l_pend.ORG_CODE, 'ORIGEM TRANSACAO', l_pend.item);

        ELSE

         l_batch_source_name := get_artrx_lookup(l_pend.ORG_CODE, 'ORIGEM TRANSACAO RPS', l_pend.item);

        END IF;
        --alt 23/01/2019 fpavao end
        --
        l_campo := 'TIPO TRANSACAO';
        CAMPO('TIPO TRANSACAO');
        l_cust_trx_type_name := get_artrx_lookup(l_pend.ORG_CODE, l_orig_trx_type, l_pend.item);
        --
        l_campo := 'TIPO TRANSACAO ISENTO';
        CAMPO('TIPO TRANSACAO ISENTO');
        l_cust_trx_type_name_isento := get_artrx_lookup(l_pend.ORG_CODE, l_orig_trx_type_ISENTO, l_pend.item);
        --
        -- Busca Flexfields do Item
        --
        l_campo := 'ITEM/UOM CODE';
        CAMPO('ITEM/UOM CODE');
        --
        SELECT MSI.PRIMARY_UOM_CODE,
          MSI.GLOBAL_ATTRIBUTE2,
          MSI.GLOBAL_ATTRIBUTE3,
          MSI.GLOBAL_ATTRIBUTE4,
          MSI.GLOBAL_ATTRIBUTE5,
          MSI.GLOBAL_ATTRIBUTE6
        INTO L_UOM_CODE,
          L_LINE_GDF_ATTRIBUTE3,
          L_LINE_GDF_ATTRIBUTE4,
          L_LINE_GDF_ATTRIBUTE5,
          L_LINE_GDF_ATTRIBUTE6,
          L_LINE_GDF_ATTRIBUTE7
        FROM INV.MTL_SYSTEM_ITEMS_B MSI
        WHERE MSI.INVENTORY_ITEM_ID = L_PEND.ITEM_ID
        AND MSI.ORGANIZATION_ID    IN
          (SELECT MASTER_ORGANIZATION_ID
          FROM MTL_PARAMETERS MP
          WHERE MP.ORGANIZATION_ID = L_WAREHOUSE_ID
          );
        --
        l_campo := 'CFOP/TAX CODE';
        CAMPO('CFOP/TAX CODE : ' || l_cust_trx_type_name);
        --
        SELECT RCTTA.GLOBAL_ATTRIBUTE3,
          RCTTA.GLOBAL_ATTRIBUTE4
        INTO L_CFOP,
          L_TAX_CODE
        FROM RA_CUST_TRX_TYPES_ALL RCTTA
        WHERE RCTTA.NAME = L_CUST_TRX_TYPE_NAME
        AND RCTTA.ORG_ID = L_PEND.ORG_ID;
        --
        l_campo := 'ALIQUOTA IRRF';
        CAMPO('ALIQUOTA IRRF');
        l_aliq_irrf := get_artrx_lookup(l_pend.ORG_CODE, 'ALIQUOTA IRRF', l_pend.item);
        -- rbs
        l_campo := 'NOP CONTEXTO';
        CAMPO('NOP CONTEXTO');
        --reg.interface_line_context  := get_artrx_lookup(l_pend.ORG_CODE,'NOP CONTEXTO',l_pend.item);
        reg.header_attribute_category := get_artrx_lookup(l_pend.ORG_CODE, 'NOP CONTEXTO', l_pend.item);
        l_campo                       := 'NOP';
        CAMPO('NOP');
        l_line_attribute15 := get_artrx_lookup(l_pend.ORG_CODE, 'NOP', l_pend.item);
        --    out_p('nop = '||l_line_attribute15);
        --
        -- Insert Open Interface
        reg.org_id                 := l_pend.org_id;
        reg.interface_line_context := 'NFSE';
        --IF l_pend.operation = 1 THEN
        --alt fpavao 3S 23/01/2019 begin
        /*BEGIN
          SELECT XXSTN_AR_INTERF_LINE_ATTRIB1_S.nextval
          INTO l_cont_operation_1
          FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
          l_cont_operation_1 := NULL;
        END;*/
        reg.interface_line_attribute1 := l_pend.interface_line_attribute1;--l_cont_operation_1;
        --alt fpavao 3S 23/01/2019 end
        --ELSE
        --reg.interface_line_attribute1 := l_pend.ORIG_SYS_REF;
        --END IF;
        reg.interface_line_attribute2 := 'NFSE';
        reg.interface_line_attribute3 := 1;
        reg.interface_line_attribute4 := l_pend.transaction_date;
        reg.batch_source_name         := l_batch_source_name;
        reg.cust_trx_type_name        := l_cust_trx_type_name;
        reg.currency_code             := l_pend.currency_code;
        reg.amount                    := l_pend.amount;
        reg.quantity                  := 1;
        reg.unit_selling_price        := l_pend.amount;
        reg.description               := l_pend.description;
        -- carga rbs
        reg.gl_date := NULL; --to_date('31122017','DDMMRRRR');--NULL; -- rbs 20180105
        --           reg.gl_date                       := to_date('31012018','DDMMRRRR');--NULL; -- rbs 20180105
        -- fix rbs 2018/fev/14 - somente para retroativa das OU_STONE/OU_ELAVON/OU_PAGARME
        -- fix rbs 2018/mar/01 - valida ou's na lookup STN_AR_DATA_RETROATIVA
        FOR c_trx IN
        (SELECT hou.organization_id,
          hou.name
        FROM hr_operating_units hou,
          fnd_lookup_values_vl flv
        WHERE flv.lookup_type = 'STN_AR_DATA_RETROATIVA'
        AND flv.enabled_flag  = 'Y'
        AND sysdate BETWEEN NVL(flv.start_date_active, sysdate) AND NVL(flv.end_date_active, sysdate)
        AND flv.lookup_code     = hou.name
        AND hou.organization_id = l_pend.org_id
        )
        LOOP
          reg.trx_number := l_pend.ORIG_SYS_REF;
        END LOOP;
        reg.orig_system_bill_customer_ref := l_orig_system_reference_site;
        reg.orig_system_ship_customer_ref := l_orig_system_reference_site;
        reg.orig_system_bill_address_ref  := l_orig_system_reference_loc;
        reg.orig_system_ship_address_ref  := l_orig_system_reference_ship;
        reg.orig_system_sold_customer_ref := l_orig_system_reference_site;
        reg.receipt_method_name           := l_receipt_method_name;
        reg.trx_date                      := l_pend.transaction_date;
        reg.conversion_type               := 'Corporate';
        reg.conversion_rate               := NULL;
        reg.conversion_date               := NULL;
        reg.line_type                     := 'LINE';
        reg.reference_line_context        := NULL;
        reg.header_gdf_attr_category      := 'JL.BR.ARXTWMAI.Additional Info';
        reg.line_gdf_attr_category        := 'JL.BR.ARXTWMAI.Additional Info';
        reg.line_gdf_attribute1           := l_cfop;
        reg.line_gdf_attribute2           := NULL;
        reg.line_gdf_attribute3           := l_line_gdf_attribute3;
        reg.line_gdf_attribute4           := l_line_gdf_attribute4;
        reg.line_gdf_attribute5           := l_line_gdf_attribute5;
        reg.line_gdf_attribute6           := l_line_gdf_attribute6;
        reg.line_gdf_attribute7           := l_line_gdf_attribute7;
        reg.warehouse_id                  := l_warehouse_id;
        reg.created_by                    := g_user_id;
        reg.creation_date                 := SYSDATE;
        reg.last_updated_by               := g_user_id;
        reg.last_update_date              := SYSDATE;
        reg.last_update_login             := g_login_id;
        reg.memo_line_name                := NULL;
        /*l_memo_line*/
        reg.tax_code := NULL;
        /*l_tax_code*/
        --           reg.header_attribute_category := 'NFSE';
        reg.mtl_system_items_seg1 := l_pend.item;
        reg.uom_code              := l_uom_code;
        reg.COMMENTS              := l_pend.comments;
        reg.internal_notes        := l_pend.internal_notes;
        --
        reg.term_name := l_term_name;
        --
        -- rbs
        reg.header_attribute4 := l_pend.eletronic_num;
        -- rbs
        reg.interface_line_attribute15 := l_line_attribute15;
        --
        -- DERIVAR cfop
        --
        GET_ESTADO_INV_ORG(p_organization_id => l_warehouse_id, p_state => l_state_inv_org);
        --
        GET_DERIV_CFOP(p_customer_state => l_orig_sys_ref_ship_state, p_inv_org_state => l_state_inv_org, p_cust_trx_type_name => L_CUST_TRX_TYPE_NAME, p_org_id => REG.ORG_ID, p_cfop => L_CFOP);
        --
        reg.line_gdf_attribute1 := L_CFOP;
        --
        IF l_pend.status = 'R' THEN
          BEGIN
            INSERT INTO RA_INTERFACE_LINES_ALL VALUES REG;
            --UPDATE_ST('PEND');
            l_qtde_inse_reg := l_qtde_inse_reg + 1;
            BEGIN
              UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
              SET STATUS         = 'P',
                ORG_CODE         = l_pend.ORG_CODE,
                ITEM             = l_pend.item,
                LAST_UPDATED_BY  = g_user_id,
                last_update_date = sysdate
              WHERE rowid        = l_pend.xid;
            EXCEPTION
            WHEN OTHERS THEN
              OUT_L('Erro ao atualizar tabela XXSTN_ELECTRONIC_INV_INTERF - '||SQLERRM);
            END;
            --
          EXCEPTION
          WHEN OTHERS THEN
            l_pend.ERROR_MESSAGE := 'Erro ao Inserir na Open Interface :' || SQLERRM;
            out_l(l_pend.ERROR_MESSAGE);
            l_qtde_erro_reg := l_qtde_erro_reg + 1;
            --UPDATE_ST('E');
            BEGIN
              UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
              SET STATUS         = 'E',
                ERROR_MESSAGE    = L_PEND.ERROR_MESSAGE,
                ORG_CODE         = l_pend.ORG_CODE,
                ITEM             = l_pend.item,
                LAST_UPDATED_BY  = g_user_id,
                last_update_date = sysdate
              WHERE rowid        = l_pend.xid;
            EXCEPTION
            WHEN OTHERS THEN
              OUT_L('Erro ao atualizar tabela XXSTN_ELECTRONIC_INV_INTERF - '||SQLERRM);
            END;
          END;
        END IF;
        --
      elsif l_pend.operation = 2 THEN --cancelamento
        CAMPO('OPERACAO');
        --
        l_orig_trx_type := 'TIPO TRANSACAO';
        --             l_orig_trx_type_ISENTO := 'TIPO TRANSACAO ISENTO';
        --             l_orig_trx_type_canc   := 'TIPO TRANSACAO CANC'; -- rbs 2017/12/07
        --
        l_campo := 'DEPOSITO';
        CAMPO('DEPOSITO');
        BEGIN
          L_AUX := GET_ARTRX_LOOKUP(L_PEND.ORG_CODE, 'DEPOSITO', L_PEND.ITEM);
          --
          SELECT ORGANIZATION_ID
          INTO L_WAREHOUSE_ID
          FROM APPS.ORG_ORGANIZATION_DEFINITIONS
          WHERE ORGANIZATION_NAME = L_AUX; --FND_PROFILE.VALUE('XXSTN_AR_INVOICES_WAREHOUSE');
        END;
        --
        l_campo := 'METODO PAGAMENTO';
        CAMPO('METODO PAGAMENTO');
        l_receipt_method_name := get_artrx_lookup(l_pend.ORG_CODE, 'METODO PAGAMENTO', l_pend.item);
        l_campo               := 'CONDICAO PAGAMENTO';
        CAMPO('CONDICAO PAGAMENTO');
        l_term_name := get_artrx_lookup(l_pend.ORG_CODE, 'CONDICAO PAGAMENTO', l_pend.item);
        l_campo     := 'ORIGEM TRANSACAO';
        CAMPO('ORIGEM TRANSACAO');
        --             l_batch_source_name := get_artrx_lookup(l_pend.ORG_CODE,'ORIGEM TRANSACAO',l_pend.item);
        --
        l_campo := 'TIPO TRANSACAO';
        CAMPO('TIPO TRANSACAO');
        --             l_cust_trx_type_name := get_artrx_lookup(l_pend.ORG_CODE,l_orig_trx_type_canc,l_pend.item);
        l_campo := 'Localizando NF';
        CAMPO('Localizando NF: ' || TO_CHAR(l_pend.ORIG_SYS_REF) || ' ' || l_pend.ORG_CODE);
        --Alt 3S 01/10/2018 inicio
        BEGIN
          SELECT R1.NAME,
            RBSA1.NAME,
            RCTLA.CUSTOMER_TRX_LINE_ID,
            TRX.CUSTOMER_TRX_ID
          INTO l_cust_trx_type_name,
            l_batch_source_name,
            l_ref_line_id,
            l_ref_customer_trx_id
          FROM RA_CUST_TRX_TYPES_ALL R1,
            RA_CUST_TRX_TYPES_aLL R2,
            RA_CUSTOMER_TRX_ALL TRX,
            RA_BATCH_SOURCES_ALL RBSA2,
            RA_BATCH_SOURCES_ALL RBSA1,
            RA_CUSTOMER_TRX_LINES_ALL RCTLA
          WHERE R1.ORG_ID           = l_pend.org_id
          AND R1.ORG_ID             = R2.ORG_ID
          AND R1.CUST_TRX_TYPE_ID   = R2.CREDIT_MEMO_TYPE_ID
          AND R2.CUST_TRX_TYPE_ID   = TRX.CUST_TRX_TYPE_ID
          AND RBSA1.BATCH_SOURCE_ID = RBSA2.CREDIT_MEMO_BATCH_SOURCE_ID
          AND RBSA2.BATCH_SOURCE_ID = TRX.BATCH_SOURCE_ID
          AND RCTLA.LINE_TYPE       = 'LINE'
          AND RCTLA.CUSTOMER_TRX_ID = TRX.CUSTOMER_TRX_ID
          AND TRX.ORG_ID            = l_pend.org_id
          AND TRX.STATUS_TRX        = 'OP'
          AND TRX.CUSTOMER_TRX_ID  IN
            (SELECT MAX(CUSTOMER_TRX_ID)
            FROM RA_CUSTOMER_TRX_ALL
            WHERE TRX_NUMBER = TO_CHAR(l_pend.ORIG_SYS_REF)
            AND ORG_ID       = l_pend.org_id
            );
        EXCEPTION
        WHEN OTHERS THEN
          raise e_nf_nota_found;
        END;
        --Alt 3S 01/10/2018 fim
        --
        --             CAMPO('TIPO TRANSACAO ISENTO');
        --             l_cust_trx_type_name_isento := get_artrx_lookup(l_pend.ORG_CODE,l_orig_trx_type_ISENTO,l_pend.item);
        --
        -- Busca Flexfields do Item
        --
        l_campo := 'ITEM/UOM CODE';
        CAMPO('ITEM/UOM CODE');
        --
        SELECT MSI.PRIMARY_UOM_CODE,
          MSI.GLOBAL_ATTRIBUTE2,
          MSI.GLOBAL_ATTRIBUTE3,
          MSI.GLOBAL_ATTRIBUTE4,
          MSI.GLOBAL_ATTRIBUTE5,
          MSI.GLOBAL_ATTRIBUTE6
        INTO L_UOM_CODE,
          L_LINE_GDF_ATTRIBUTE3,
          L_LINE_GDF_ATTRIBUTE4,
          L_LINE_GDF_ATTRIBUTE5,
          L_LINE_GDF_ATTRIBUTE6,
          L_LINE_GDF_ATTRIBUTE7
        FROM INV.MTL_SYSTEM_ITEMS_B MSI
        WHERE MSI.INVENTORY_ITEM_ID = L_PEND.ITEM_ID
        AND MSI.ORGANIZATION_ID    IN
          (SELECT MASTER_ORGANIZATION_ID
          FROM MTL_PARAMETERS MP
          WHERE MP.ORGANIZATION_ID = L_WAREHOUSE_ID
          );
        --
        l_campo := 'CFOP/TAX CODE';
        CAMPO('CFOP/TAX CODE : ' || l_cust_trx_type_name);
        --
        SELECT RCTTA.GLOBAL_ATTRIBUTE3,
          RCTTA.GLOBAL_ATTRIBUTE4
        INTO L_CFOP,
          L_TAX_CODE
        FROM RA_CUST_TRX_TYPES_ALL RCTTA
        WHERE RCTTA.NAME = L_CUST_TRX_TYPE_NAME
        AND RCTTA.ORG_ID = L_PEND.ORG_ID;
        --
        l_campo := 'ALIQUOTA IRRF';
        CAMPO('ALIQUOTA IRRF');
        l_aliq_irrf := get_artrx_lookup(l_pend.ORG_CODE, 'ALIQUOTA IRRF', l_pend.item);
        -- rbs
        l_campo := 'NOP CONTEXTO';
        CAMPO('NOP CONTEXTO');
        reg.header_attribute_category := get_artrx_lookup(l_pend.ORG_CODE, 'NOP CONTEXTO', l_pend.item);
        l_campo                       := 'NOP';
        CAMPO('NOP');
        l_line_attribute15 := get_artrx_lookup(l_pend.ORG_CODE, 'NOP', l_pend.item);
        --
        -- Insert Open Interface
        reg.org_id                 := l_pend.org_id;
        reg.interface_line_context := 'NFSE';
        /*IF l_pend.operation = 1 THEN
        BEGIN
        SELECT XXSTN_AR_INTERF_LINE_ATTRIB1_S.nextval
        INTO l_cont_operation_1
        FROM DUAL;
        EXCEPTION
        WHEN OTHERS THEN
        l_cont_operation_1 := NULL;
        END;
        reg.interface_line_attribute1 := l_cont_operation_1;
        ELSE*/
        reg.interface_line_attribute1 := l_ref_customer_trx_id; -- l_pend.ORIG_SYS_REF; alteracao 3S 26/09/2018
        --END IF;
        reg.interface_line_attribute2 := 'NFSE';
        reg.interface_line_attribute3 := 1;
        reg.interface_line_attribute4 := l_pend.transaction_date;
        reg.batch_source_name         := l_batch_source_name;
        reg.cust_trx_type_name        := l_cust_trx_type_name;
        reg.currency_code             := l_pend.currency_code;
        reg.amount                    := -l_pend.amount; -- rbs
        reg.quantity                  := 1;              -- rbs
        reg.unit_selling_price        := -l_pend.amount; --rbs
        reg.description               := l_pend.description;
        -- carga rbs
        reg.gl_date := NULL; --to_date('31122017','DDMMRRRR');--NULL; -- rbs 20180105
        --carga inicial           reg.gl_date                       := to_date('31012018','DDMMRRRR');--NULL; -- rbs 20180105
        --           reg.gl_date                       := to_date('31012018','DDMMRRRR');--NULL; -- rbs 20180105
        reg.orig_system_bill_customer_ref := l_orig_system_reference_site;
        reg.orig_system_ship_customer_ref := l_orig_system_reference_site;
        reg.orig_system_bill_address_ref  := l_orig_system_reference_loc;
        reg.orig_system_ship_address_ref  := l_orig_system_reference_ship;
        reg.orig_system_sold_customer_ref := l_orig_system_reference_site;
        reg.receipt_method_name           := l_receipt_method_name;
        reg.trx_date                      := l_pend.transaction_date;
        reg.conversion_type               := 'Corporate';
        reg.conversion_rate               := NULL;
        reg.conversion_date               := NULL;
        reg.line_type                     := 'LINE';
        reg.reference_line_context        := NULL;
        reg.header_gdf_attr_category      := 'JL.BR.ARXTWMAI.Additional Info';
        reg.line_gdf_attr_category        := 'JL.BR.ARXTWMAI.Additional Info';
        reg.line_gdf_attribute1           := l_cfop;
        reg.line_gdf_attribute2           := NULL;
        reg.line_gdf_attribute3           := l_line_gdf_attribute3;
        reg.line_gdf_attribute4           := l_line_gdf_attribute4;
        reg.line_gdf_attribute5           := l_line_gdf_attribute5;
        reg.line_gdf_attribute6           := l_line_gdf_attribute6;
        reg.line_gdf_attribute7           := l_line_gdf_attribute7;
        reg.warehouse_id                  := l_warehouse_id;
        reg.created_by                    := g_user_id;
        reg.creation_date                 := SYSDATE;
        reg.last_updated_by               := g_user_id;
        reg.last_update_date              := SYSDATE;
        reg.last_update_login             := g_login_id;
        reg.memo_line_name                := NULL
        /*l_memo_line*/
        ;
        reg.tax_code := NULL
        /*l_tax_code*/
        ;
        --           reg.header_attribute_category := 'NFSE';
        reg.mtl_system_items_seg1 := l_pend.item;
        reg.uom_code              := l_uom_code;
        reg.comments              := l_pend.comments;
        reg.internal_notes        := l_pend.internal_notes;
        --
        -- rbs
        reg.header_attribute4 := l_pend.eletronic_num;
        -- rbs
        reg.interface_line_attribute15 := l_line_attribute15;
        reg.reference_line_id          := l_ref_line_id; -- rbs 2017/12/07 alt 3S 26/09/2018
        -- DERIVAR cfop
        --
        GET_ESTADO_INV_ORG(p_organization_id => l_warehouse_id, p_state => l_state_inv_org);
        --
        GET_DERIV_CFOP(p_customer_state => l_orig_sys_ref_ship_state, p_inv_org_state => l_state_inv_org, p_cust_trx_type_name => L_CUST_TRX_TYPE_NAME, p_org_id => REG.ORG_ID, p_cfop => L_CFOP);
        --
        reg.line_gdf_attribute1 := L_CFOP;
        --           reg.related_trx_number := l_pend.ORIG_SYS_REF;-- rbs 2018/fev/12
        --
        --           OUT_L('antes do insert IF');
        IF l_pend.status = 'R' THEN
          BEGIN
            --           OUT_L('antes do insert da transacao de cancelamento');
            INSERT
            INTO RA_INTERFACE_LINES_ALL VALUES REG;
            l_qtde_inse_reg := l_qtde_inse_reg + 1;
            BEGIN
              UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
              SET STATUS         = 'P',
                ORG_CODE         = l_pend.ORG_CODE,
                ITEM             = l_pend.item,
                LAST_UPDATED_BY  = g_user_id,
                last_update_date = sysdate
              WHERE rowid        = l_pend.xid;
            EXCEPTION
            WHEN OTHERS THEN
              OUT_L('Erro ao atualizar tabela XXSTN_ELECTRONIC_INV_INTERF - '||SQLERRM);
            END;
            --UPDATE_ST('P');
            --
          EXCEPTION
          WHEN OTHERS THEN
            l_pend.ERROR_MESSAGE := 'Erro ao Inserir na Open Interface :' || SQLERRM;
            out_l(l_pend.ERROR_MESSAGE);
            l_qtde_erro_reg := l_qtde_erro_reg + 1;
            --UPDATE_ST('E');
            BEGIN
              UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
              SET STATUS         = 'E',
                ERROR_MESSAGE    = L_PEND.ERROR_MESSAGE,
                ORG_CODE         = l_pend.ORG_CODE,
                ITEM             = l_pend.item,
                LAST_UPDATED_BY  = g_user_id,
                last_update_date = sysdate
              WHERE rowid        = l_pend.xid;
            EXCEPTION
            WHEN OTHERS THEN
              OUT_L('Erro ao atualizar tabela XXSTN_ELECTRONIC_INV_INTERF - '||SQLERRM);
            END;
          END;
        END IF;
        --           OUT_L('depois do insert IF');
        --
      END IF;
    EXCEPTION
      --Alt 3S 01/10/2018 inicio
    WHEN e_nf_nota_found THEN
      l_pend.ERROR_MESSAGE := 'Erro ao Buscar informacoes da NF : ' || l_campo || ' - ' || sqlerrm;
      out_l(l_pend.ERROR_MESSAGE);
      --UPDATE_ST('E');
      l_qtde_erro_reg := l_qtde_erro_reg + 1;
      --UPDATE_ST('E');
      BEGIN
        UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
        SET STATUS         = 'E',
          ERROR_MESSAGE    = L_PEND.ERROR_MESSAGE,
          ORG_CODE         = l_pend.ORG_CODE,
          ITEM             = l_pend.item,
          LAST_UPDATED_BY  = g_user_id,
          last_update_date = sysdate
        WHERE rowid        = l_pend.xid;
      EXCEPTION
      WHEN OTHERS THEN
        OUT_L('Erro ao atualizar tabela XXSTN_ELECTRONIC_INV_INTERF - '||SQLERRM);
      END;
      --Alt 3S 01/10/2018 fim
    WHEN OTHERS THEN
      l_pend.ERROR_MESSAGE := 'Erro ao Buscar informacoes do Campo : ' || l_campo || ' - ' || sqlerrm;
      out_l(l_pend.ERROR_MESSAGE);
      --UPDATE_ST('E');
      l_qtde_erro_reg := l_qtde_erro_reg + 1;
      --UPDATE_ST('E');
      BEGIN
        UPDATE XXSTN.XXSTN_ELECTRONIC_INV_INTERF
        SET STATUS         = 'E',
          ERROR_MESSAGE    = L_PEND.ERROR_MESSAGE,
          ORG_CODE         = l_pend.ORG_CODE,
          ITEM             = l_pend.item,
          LAST_UPDATED_BY  = g_user_id,
          last_update_date = sysdate
        WHERE rowid        = l_pend.xid;
      EXCEPTION
      WHEN OTHERS THEN
        OUT_L('Erro ao atualizar tabela XXSTN_ELECTRONIC_INV_INTERF - '||SQLERRM);
      END;
    END;
  END LOOP;
  CLOSE c_pend;
  --
  out_p('Total Records selected .......: ' || l_qtde_sele_reg);
  out_p('Total Records inserted .......: ' || l_qtde_inse_reg);
  out_p('total Records with errors ....: ' || l_qtde_erro_reg);
  --
  out_p('Carga de Transacoes- Termino: ' || TO_CHAR(sysdate, 'dd/mm/yyyy hh24:mi:ss'));
END PROCESSA_ITF_AR;
PROCEDURE ATUALIZA_CFOP(
    errbuf OUT VARCHAR2,
    retcode OUT VARCHAR2)
IS
  l_cfop  VARCHAR2(100);
  l_count NUMBER;
  --
  CURSOR C1
  IS
    SELECT RCTL.CUSTOMER_TRX_ID,
      RCTL.CUSTOMER_TRX_LINE_ID,
      RCTL.LINE_NUMBER,
      RCT.TRX_NUMBER,
      RCT.COMMENTS,
      RCTL.GLOBAL_ATTRIBUTE1
    FROM RA_CUSTOMER_TRX_LINES RCTL,
      RA_CUSTOMER_TRX RCT
    WHERE RCT.CUSTOMER_TRX_ID = RCTL.CUSTOMER_TRX_ID
    AND RCTL.LINE_TYPE        = 'LINE'
      --and rctl.customer_trx_line_id = 5496
    AND RCTL.GLOBAL_ATTRIBUTE1 IS NULL
    ORDER BY RCT.TRX_NUMBER,
      2;
BEGIN
  OUT_P('STONE (BRL) - AR Atualiza CFOP');
  OUT_P(' ');
  -- fazer cursor das operating units
  FOR X IN
  (SELECT ORGANIZATION_ID, NAME FROM HR_OPERATING_UNITS
  )
  LOOP
    mo_global.init('AR');
    PA_MOAC_UTILS.SET_POLICY_CONTEXT('S', X.organization_id);
    MO_GLOBAL.SET_POLICY_CONTEXT('S', X.organization_id);
    --
    OUT_P('OU: ' || X.name);
    --
    OUT_P('Invoice     Line  CFOP');
    FOR reg IN c1
    LOOP
      JL_BR_CFOP_DEFAULT_PKG.DERIVE_CFOP(p_customer_trx_id => reg.customer_trx_id, p_customer_trx_line_id => reg.customer_trx_line_id, p_cfop_code => l_cfop);
      --
      IF NVL(l_cfop, '*') <> NVL(REG.global_attribute1, '*') THEN
        --
        UPDATE RA_CUSTOMER_TRX_LINES_ALL RCTL
        SET RCTL.global_attribute1    = l_cfop
        WHERE RCTL.customer_trx_id    = REG.customer_trx_id
        AND RCTL.customer_trx_line_id = REG.customer_trx_line_id;
        --
        UPDATE RA_CUSTOMER_TRX_ALL RCT
        SET RCT.comments = REG.comments
          || '.'
        WHERE RCT.customer_trx_id = REG.customer_trx_id;
        --
        l_count := l_count + 1;
        OUT_P(rpad(REG.trx_number, 12, ' ') || rpad(REG.line_number, 5, ' ') || ' ' || l_cfop);
      END IF;
      --
    END LOOP;
    OUT_P('cfops atualizados: ' || l_count);
    OUT_P(' ');
  END LOOP;
END;
END XXSTN_AR_CUSTOM_NEW;
/

EXIT;