  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_WSFECRED_PUB" AS

  G_DEBUG_FLAG     VARCHAR2(1) := 'N';
  G_CONCURRENT_OUT VARCHAR2(1) := 'Y';


  PROCEDURE crea_cabecera_ap ( p_cuit_emisor                  NUMBER
                             , p_cuit_receptor                NUMBER
                             , p_codigo_tipo_comprobante      NUMBER
                             , p_invoice_num                  VARCHAR2
                             , p_currency_code                VARCHAR2
                             , p_exchange_rate                NUMBER
                             , p_invoice_amount               NUMBER
                             , p_invoice_date                 DATE
                             , p_invoice_received_date        DATE
                             , p_description                  VARCHAR2
                             , p_cbu_pago                     VARCHAR2
                             --
                             , x_invoice_id            IN OUT NUMBER
                             , x_vendor_name           IN OUT VARCHAR2
                             , x_error_message         IN OUT VARCHAR2
                             );

  /***************************************************************************
  *                                                                          *
  * Name    : Dummy                                                          *
  * Purpose : Invocacion al servicio dummy                                   *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Dummy( x_response_object   IN OUT NOCOPY  XX_WS_AFIP_DUMMY
                 , x_result            OUT            BOOLEAN
                 , x_error_message     OUT            VARCHAR2
                 );


  /***************************************************************************
  *                                                                          *
  * Name    : Consultar_Comprobantes                                         *
  * Purpose : Invoca al servicio consultarComprobantes                       *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Consultar_Comprobantes( errbuf                        IN OUT NOCOPY VARCHAR2
                                  , retcode                       IN OUT NOCOPY NUMBER
                                  , p_cuit_representado           NUMBER
                                  , p_rol_CUIT_representada       VARCHAR2
                                  , p_CUIT_contraparte            NUMBER   DEFAULT NULL
                                  , p_cod_tipo_comprobante        NUMBER   DEFAULT NULL
                                  , p_estado_comprobante          VARCHAR2 DEFAULT NULL
                                  , p_fecha_tipo                  VARCHAR2 DEFAULT NULL
                                  , p_fecha_desde                 VARCHAR2 DEFAULT NULL
                                  , p_fecha_hasta                 VARCHAR2 DEFAULT NULL
                                  , p_cod_cta_cte                 NUMBER   DEFAULT NULL
                                  , p_estado_cta_cte              VARCHAR2 DEFAULT NULL
                                  );


  /***************************************************************************
  *                                                                          *
  * Name    : Rechazar_FECred                                                *
  * Purpose : Invoca al servicio rechazarFECred                              *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Rechazar_FECred( errbuf                        IN OUT NOCOPY VARCHAR2
                           , retcode                       IN OUT NOCOPY NUMBER
                           , p_cuit_representado           NUMBER
                           , p_cuit_emisor                 NUMBER
                           , p_codigo_tipo_comprobante     NUMBER
                           , p_punto_venta                 NUMBER
                           , p_numero_comprobante          NUMBER
                           , p_codigo_rechazo              NUMBER
                           , p_justificacion               VARCHAR2
                           , p_codigo_cuenta_corriente     NUMBER
                           );


  /***************************************************************************
  *                                                                          *
  * Name    : Informar_Cancelacion_Total                                     *
  * Purpose : Invoca al servicio informarCancelacionTotalFECred              *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Informar_Cancelacion_Total( errbuf                        IN OUT NOCOPY VARCHAR2
                                      , retcode                       IN OUT NOCOPY NUMBER
                                      , p_cuit_representado           NUMBER
                                      , p_invoice_id                  NUMBER
                                      );


  /***************************************************************************
  *                                                                          *
  * Name    : Procesa_Repositorio                                            *
  * Purpose : Rechaza o Acepta comprobantes de forma automática              *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Procesa_Repositorio ( errbuf            IN OUT NOCOPY VARCHAR2
                                , retcode           IN OUT NOCOPY NUMBER
                                , p_dias_fecha_vto                NUMBER
                                , p_operating_unit                NUMBER
                                , p_codigo_rechazo                NUMBER
                                , p_justificacion                 VARCHAR2
                                );

END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_WSFECRED_PUB" AS

  /***************************************************************************
  *                     P R I V A T E    R O U T I N E S                     *
  ****************************************************************************/

  PROCEDURE Debug ( p_message     VARCHAR2 DEFAULT NULL
                  , p_message_c   CLOB     DEFAULT NULL
                  , p_module      VARCHAR2 DEFAULT NULL
                  ) IS
    str_len        NUMBER;
    loop_count     NUMBER := 0;
    l_log_enabled  VARCHAR2(10);
  BEGIN
    IF G_DEBUG_FLAG  = 'Y' THEN

      IF G_CONCURRENT_OUT = 'Y' THEN
        IF p_message IS NOT NULL THEN
          FND_FILE.Put_Line(FND_FILE.LOG, p_message);
        ELSE
          str_len := DBMS_LOB.GETLENGTH(p_message_c);

          WHILE loop_count < str_len LOOP
            --DBMS_OUTPUT.PUT_LINE( SUBSTR(p_message_c, loop_count +1, 255 ) );
            FND_FILE.Put_Line(FND_FILE.LOG, SUBSTR(p_message_c, loop_count +1, 4000 ));
            loop_count := loop_count + 4000;
          END LOOP;

        END IF;
      ELSE
        IF p_message IS NOT NULL THEN
          str_len := LENGTH(p_message);

          WHILE loop_count < str_len LOOP
            DBMS_OUTPUT.PUT_LINE( SUBSTR( p_message, loop_count +1, 255 ) );
            loop_count := loop_count + 255;
          END LOOP;
        ELSE
          str_len := DBMS_LOB.GETLENGTH(p_message_c);

          WHILE loop_count < str_len LOOP
            DBMS_OUTPUT.PUT_LINE( SUBSTR(p_message_c, loop_count +1, 255 ) );
            loop_count := loop_count + 255;
          END LOOP;
        END IF;
      END IF;

      IF p_module IS NOT NULL THEN
        loop_count := 0;
        str_len := DBMS_LOB.GETLENGTH(p_message_c);

        WHILE loop_count < str_len LOOP

          xx_debug_aux_pk.debug( p_module => p_module
                               , p_message => SUBSTR(p_message_c, loop_count +1, 4000)
                               );

          loop_count := loop_count + 4000;
        END LOOP;

      END IF;

    END IF;

  END Debug;


  FUNCTION Get_Num_Chr RETURN VARCHAR2 IS
    l_num_chr VARCHAR2(5);
  BEGIN
    BEGIN
      SELECT nls_numeric_characters
      INTO l_num_chr
      FROM fnd_concurrent_requests
      WHERE request_id = FND_GLOBAL.CONC_REQUEST_ID
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT pov.profile_option_value "VALUE"
          INTO l_num_chr
          FROM fnd_profile_options         po
             , fnd_profile_option_values   pov
             , fnd_user                    usr
          WHERE 1=1
          AND pov.application_id     = po.application_id
          AND pov.profile_option_id  = po.profile_option_id
          AND usr.user_id(+)         = pov.level_value
          --
          AND po.profile_option_name = 'ICX_NUMERIC_CHARACTERS'
          AND pov.level_id = 10004
          AND usr.user_id  = FND_GLOBAL.User_ID;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_num_chr := NULL;
        END;
    END;

    RETURN l_num_chr;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_Num_Chr;

  PROCEDURE Set_Num_Chr ( p_num_chr VARCHAR2 ) IS
  BEGIN
    IF p_num_chr = '.,' THEN
      EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS= ''.,'' ';
    ELSE
      EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '',.'' ';
    END IF;
  END Set_Num_Chr;


  /***************************************************************************
  *                                                                          *
  * Name    : Set_End_Point                                                  *
  * Purpose : Configura el destino de los servicios de LPG.                  *
  *                                                                          *
  ****************************************************************************/
  FUNCTION Set_End_Point RETURN VARCHAR2 IS
  BEGIN
    IF NVL(Fnd_Profile.Value('XX_WSAFIP_PRODUCTION_FLAG'),'N') = 'Y' THEN
      XX_WS_AFIP_FECRED_WRAPPER_PK.setEndpoint(Fnd_Profile.Value('XX_WSAFIP_WSFECRED_PROD_ENDPOINT'));
      RETURN 'PRODUCCION';
    ELSE
      XX_WS_AFIP_FECRED_WRAPPER_PK.setEndpoint(Fnd_Profile.Value('XX_WSAFIP_WSFECRED_HOMO_ENDPOINT'));
      RETURN 'HOMOLOGACION';
    END IF;
    --Homo
    --XX_WS_AFIP_FECRED_WRAPPER_PK.setEndpoint('https://fwshomo.afip.gov.ar/wsfecred/FECredService');
    --Prod
    --XX_WS_AFIP_FECRED_WRAPPER_PK.setEndpoint('https://serviciosjava.afip.gob.ar/wsfecred/FECredService');
    --RETURN 'HOMOLOGACION';
  END Set_End_Point;


  /***************************************************************************
  *                      P U B L I C    R O U T I N E S                      *
  ****************************************************************************/


  PROCEDURE crea_cabecera_ap ( p_cuit_emisor                  NUMBER
                             , p_cuit_receptor                NUMBER
                             , p_codigo_tipo_comprobante      NUMBER
                             , p_invoice_num                  VARCHAR2
                             , p_currency_code                VARCHAR2
                             , p_exchange_rate                NUMBER
                             , p_invoice_amount               NUMBER
                             , p_invoice_date                 DATE
                             , p_invoice_received_date        DATE
                             , p_description                  VARCHAR2
                             , p_cbu_pago                     VARCHAR2
                             --
                             , x_invoice_id            IN OUT NUMBER
                             , x_vendor_name           IN OUT VARCHAR2
                             , x_error_message         IN OUT VARCHAR2
                             ) IS

    CURSOR cVendorR ( p_cuit VARCHAR2 ) IS
      SELECT s.vendor_id
           , s.vendor_name
           , s.party_id
           , s.num_1099||s.global_attribute12 cuit
           , s.terms_id
           , s.pay_group_lookup_code
           , s.payment_method_lookup_code
           , s.accts_pay_code_combination_id
           , ou.organization_id org_id
           , ou.set_of_books_id
           , ou.default_legal_context_id legal_entity_id
      FROM hr_operating_units     ou
         , hr_all_organization_units ou1
         , hr_locations_all       l
         , ap_suppliers           s
      WHERE 1=1
      AND ou1.organization_id = ou.organization_id
      AND l.location_id       = ou1.location_id
      AND s.num_1099||s.global_attribute12 = l.global_attribute11||l.global_attribute12
      AND TRUNC(NVL(s.end_date_active, SYSDATE+1)) >= TRUNC(SYSDATE)
      AND s.num_1099||s.global_attribute12 = p_cuit
      ;

    CURSOR cVendorE ( p_cuit VARCHAR2 ) IS
      SELECT s.vendor_id
           , s.vendor_name
           , s.party_id
           , s.num_1099||s.global_attribute12 cuit
           , s.terms_id
           , s.pay_group_lookup_code
           , s.payment_method_lookup_code
           , s.accts_pay_code_combination_id
      FROM ap_suppliers s
      WHERE 1=1
      AND TRUNC(NVL(s.end_date_active, SYSDATE+1)) >= TRUNC(SYSDATE)
      AND s.num_1099||s.global_attribute12 = p_cuit
      ;

    CURSOR cVendorSite ( p_vendor_id  NUMBER
                       , p_org_id     NUMBER
                       ) IS
      SELECT DISTINCT ps.vendor_site_id, ps.party_site_id, su.primary_per_type
           , ps.terms_id
           , ps.pay_group_lookup_code
           , ps.payment_method_lookup_code
           , ps.accts_pay_code_combination_id
      FROM po_vendor_sites_all ps
         , hz_party_site_uses  su
      WHERE 1=1
      AND su.party_site_id = ps.party_site_id
      AND ps.vendor_id = p_vendor_id
      AND ps.status = 'A'
      AND su.status = 'A'
      AND ps.org_id = p_org_id
      ;


    rVendorR                 cVendorR%ROWTYPE;
    rVendorE                 cVendorE%ROWTYPE;
    rVendorSite              cVendorSite%ROWTYPE;

    l_user_id                NUMBER;
    l_invoice_id             NUMBER;
    l_rowid                  VARCHAR2(2000);
    l_dummy_num              NUMBER;

    l_vendor_id              NUMBER;
    l_vendor_site_id         NUMBER;
    l_party_id               NUMBER;
    l_party_site_id          NUMBER;
    l_term_id                NUMBER;
    l_pay_group_lookup_code  VARCHAR2(250);
    l_set_of_books_id        NUMBER;
    l_accts_pay_cc_id        NUMBER;
    l_payment_method_code    VARCHAR2(250);
    l_legal_entity_id        NUMBER;
    l_org_id                 NUMBER;
    l_source                 VARCHAR2(250);
    l_currency_code          VARCHAR2(10);
    l_curr_code_sob          VARCHAR2(10);
    l_invoice_amount         NUMBER;
    l_base_amount            NUMBER;
    l_exchange_rate_type     VARCHAR2(10);
    l_exchange_date          DATE;
    l_ext_bank_account_id    NUMBER;
    l_tipo_cbte              VARCHAR2(50);

    l_hold_code              VARCHAR2(150) := 'Ret-WSFECRED';
    l_hold_type              VARCHAR2(50);
    l_hold_desc              VARCHAR2(250);
    eNoData                  EXCEPTION;
  BEGIN
    /* Obtengo los datos para Receptor */
    OPEN cVendorR (p_cuit_receptor);
    FETCH cVendorR INTO rVendorR;
    IF cVendorR%NOTFOUND THEN
      x_error_message := 'No se encontraron datos del receptor '||p_cuit_receptor;
      CLOSE cVendorR;
      RAISE eNoData;
    END IF;
    l_org_id := rVendorR.org_id;
    l_set_of_books_id := rVendorR.set_of_books_id;
    l_legal_entity_id := rVendorR.legal_entity_id;
    CLOSE cVendorR;
    rVendorR := NULL;

    BEGIN
      SELECT currency_code
      INTO l_curr_code_sob
      FROM gl_sets_of_books
      WHERE set_of_books_id = l_set_of_books_id;
    EXCEPTION
      WHEN OTHERS THEN
        x_error_message := 'No se encontró moneda para el juego de libro.';
        RAISE eNoData;
    END;

    /* Obtengo los datos para Receptor */
    OPEN cVendorE (p_cuit_emisor);
    FETCH cVendorE INTO rVendorE;
    IF cVendorE%NOTFOUND THEN
      x_error_message := 'No se encontraron datos del emisor '||p_cuit_emisor;
      CLOSE cVendorE;
      RAISE eNoData;
    END IF;
    l_vendor_id := rVendorE.vendor_id;
    l_party_id  := rVendorE.party_id;
    x_vendor_name     := rVendorE.vendor_name;
    l_accts_pay_cc_id := rVendorE.accts_pay_code_combination_id;

    OPEN cVendorSite (l_vendor_id, l_org_id);
    FETCH cVendorSite INTO rVendorSite;
    IF cVendorSite%NOTFOUND THEN
      x_error_message := 'No se encontraron datos a nivel site para el emisor '||p_cuit_emisor;
      CLOSE cVendorSite;
      RAISE eNoData;
    END IF;
    l_vendor_site_id  := rVendorSite.vendor_site_id;
    l_party_site_id   := rVendorSite.party_site_id;

    IF rVendorSite.pay_group_lookup_code IS NOT NULL THEN
      l_pay_group_lookup_code := rVendorSite.pay_group_lookup_code;
    ELSIF rVendorE.pay_group_lookup_code IS NOT NULL THEN
      l_pay_group_lookup_code := rVendorE.pay_group_lookup_code;
    END IF;

    IF rVendorSite.payment_method_lookup_code IS NOT NULL THEN
      l_payment_method_code := rVendorSite.payment_method_lookup_code;
    ELSIF rVendorE.payment_method_lookup_code IS NOT NULL THEN
      l_payment_method_code := rVendorE.payment_method_lookup_code;
    END IF;

    IF rVendorSite.accts_pay_code_combination_id IS NOT NULL THEN
      l_accts_pay_cc_id := rVendorSite.accts_pay_code_combination_id;
    ELSIF rVendorE.accts_pay_code_combination_id IS NOT NULL THEN
      l_accts_pay_cc_id := rVendorE.accts_pay_code_combination_id;
    END IF;

    CLOSE cVendorSite;
    CLOSE cVendorE;
    rVendorE := NULL;

    /* Obtener term_id contado */
    --SELECT term_id INTO l_term_id FROM ap_terms WHERE UPPER(name) LIKE 'CONTADO';

    /* Moneda */
    SELECT meaning
    INTO l_currency_code
    FROM fnd_lookup_values_vl
    WHERE 1=1
    AND lookup_type = 'XX_AR_FC_ELECTRO_MONEDA'
    AND lookup_code = p_currency_code
    ;

    l_invoice_amount := p_invoice_amount;

    IF p_codigo_tipo_comprobante = 203 THEN
      l_invoice_amount := l_invoice_amount * -1;
    END IF;

    IF l_currency_code != 'ARS' THEN
      l_base_amount        := ROUND(l_invoice_amount * p_exchange_rate, 2);
      l_exchange_rate_type := 'User';
      l_exchange_date      := p_invoice_date;

      /*BEGIN
        SELECT conversion_rate
        INTO l_dummy_num
        FROM gl_daily_rates_v
        WHERE 1=1
        AND from_currency = l_currency_code
        AND to_currency   = l_curr_code_sob
        AND user_conversion_type = 'Corporate'
        AND conversion_date = l_exchange_date
        ;
      EXCEPTION
        WHEN OTHERS THEN
          x_error_message := 'Tipo de cambio inexistente.';
          RAISE eNoData;
      END;*/
    ELSE
      l_base_amount        := NULL;
      l_exchange_rate_type := NULL;
      l_exchange_date      := NULL;
    END IF;

    /* Datos de la cuenta bancaria */
    BEGIN
      SELECT DISTINCT eba.ext_bank_account_id
      INTO l_ext_bank_account_id
      FROM iby_account_owners    ao
         , iby_ext_bank_accounts eba
      WHERE 1=1
      AND ao.ext_bank_account_id = eba.ext_bank_account_id
      AND eba.attribute4         = p_cbu_pago
      AND ao.account_owner_party_id = l_party_id
      AND eba.currency_code      = l_currency_code
      ;
    EXCEPTION
      WHEN OTHERS THEN
        l_ext_bank_account_id := NULL;
    END;


    /* Tipo DOC */
    BEGIN
      SELECT DISTINCT
             DECODE(lv_dfv.xx_rg3685_nc, NULL, 'STANDARD', 'CREDIT') tipo_cbte
      INTO l_tipo_cbte
      FROM fnd_lookup_values_vl lv
         , fnd_lookup_values_dfv lv_dfv
      WHERE 1=1
      AND lv_dfv.row_id = lv.rowid
      AND lv_dfv.context = lv.attribute_category
      AND lookup_type = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
      AND lookup_code = p_codigo_tipo_comprobante
      AND UPPER(meaning) LIKE '%MIPYME%'
      ;
    EXCEPTION
      WHEN OTHERS THEN
        x_error_message := 'No fue posible determinar el tipo de comprobante.';
        RAISE eNoData;
    END;

    /* Datos del HOLD */
    SELECT hold_type
         , description
    INTO l_hold_type
       , l_hold_desc
    FROM ap_hold_codes_v
    WHERE UPPER(hold_lookup_code) = UPPER(l_hold_code)
    ;

    BEGIN
      SELECT user_id
      INTO l_user_id
      FROM fnd_user
      WHERE user_name = 'SCHEDULED_REQUESTS';
    EXCEPTION
      WHEN OTHERS THEN
        l_user_id := FND_GLOBAL.User_ID;
    END;

    AP_AI_TABLE_HANDLER_PKG.INSERT_ROW
    (P_ROWID                         => l_rowid
    ,P_INVOICE_ID                    => x_invoice_id
    ,P_CREATION_DATE                 => SYSDATE
    ,P_CREATED_BY                    => l_user_id --FND_GLOBAL.User_ID
    ,P_LAST_UPDATE_DATE              => SYSDATE
    ,P_LAST_UPDATED_BY               => l_user_id --FND_GLOBAL.User_ID
    --
    ,P_VENDOR_ID                     => l_vendor_id
    ,P_VENDOR_SITE_ID                => l_vendor_site_id
    ,P_PARTY_ID                      => l_party_id
    ,P_PARTY_SITE_ID                 => l_party_site_id
    ,P_TERMS_ID                      => NULL--l_term_id
    ,P_TERMS_DATE                    => p_invoice_received_date
    ,P_PAY_GROUP_LOOKUP_CODE         => NULL --l_pay_group_lookup_code
    ,P_ACCTS_PAY_CCID                => l_accts_pay_cc_id
    ,P_PAYMENT_METHOD_CODE           => 'EFT'
    ,P_SET_OF_BOOKS_ID               => l_set_of_books_id
    ,P_LEGAL_ENTITY_ID               => l_legal_entity_id
    ,P_ORG_ID                        => l_org_id
    --
    ,P_SOURCE                        => 'XX_AP_FECRED'
    ,P_INVOICE_TYPE_LOOKUP_CODE      => l_tipo_cbte
    ,P_DESCRIPTION                   => p_description
    ,P_INVOICE_DATE                  => p_invoice_date
    ,P_GL_DATE                       => SYSDATE
    ,P_INVOICE_RECEIVED_DATE         => p_invoice_received_date
    ,P_INVOICE_NUM                   => p_invoice_num
    ,P_INVOICE_AMOUNT                => l_invoice_amount
    ,P_AMT_APPLICABLE_TO_DISCOUNT    => l_invoice_amount
    ,P_INVOICE_CURRENCY_CODE         => l_currency_code
    ,P_PAYMENT_CURRENCY_CODE         => l_currency_code
    ,P_EXCHANGE_DATE                 => l_exchange_date
    ,P_EXCHANGE_RATE                 => p_exchange_rate
    ,P_BASE_AMOUNT                   => l_base_amount
    ,P_EXCHANGE_RATE_TYPE            => l_exchange_rate_type
    ,P_PAYMENT_CROSS_RATE            => 1
    ,P_PAYMENT_CROSS_RATE_DATE       => l_exchange_date
    ,P_PAY_CURR_INVOICE_AMOUNT       => l_invoice_amount --l_base_amount
    ,P_EXTERNAL_BANK_ACCOUNT_ID      => l_ext_bank_account_id
    --
    ,P_ATTRIBUTE_CATEGORY            => 'AR'
    ,P_ATTRIBUTE1                    => NULL
    ,P_ATTRIBUTE2                    => NULL --'00000'
    ,P_ATTRIBUTE3                    => NULL
    ,P_ATTRIBUTE4                    => NULL
    ,P_ATTRIBUTE5                    => NULL
    --
    ,P_GLOBAL_ATTRIBUTE_CATEGORY     => 'JL.AR.APXINWKB.INVOICES'
    ,P_GLOBAL_ATTRIBUTE11            => NULL --'FC BIENES'
    ,P_GLOBAL_ATTRIBUTE12            => NULL --'A'
    ,P_GLOBAL_ATTRIBUTE13            => p_codigo_tipo_comprobante --NULL --'01' SD2085
    ,P_GLOBAL_ATTRIBUTE17            => 'N'
    --
    ,P_PAYMENT_STATUS_FLAG           => 'N'
    ,P_EXCLUSIVE_PAYMENT_FLAG        => 'N'
    ,P_APPROVAL_READY_FLAG           => 'Y'
    ,P_WFAPPROVAL_STATUS             => 'REQUIRED'
    ,P_TAXATION_COUNTRY              => 'AR'
    ,P_FORCE_REVALIDATION_FLAG       => 'Y'
    --
    ,P_AMOUNT_PAID                   => NULL
    ,P_DISCOUNT_AMOUNT_TAKEN         => NULL
    ,P_BATCH_ID                      => NULL
    ,P_GOODS_RECEIVED_DATE           => NULL
    ,P_VOUCHER_NUM                   => NULL
    ,P_APPROVED_AMOUNT               => NULL
    ,P_APPROVAL_STATUS               => NULL
    ,P_APPROVAL_DESCRIPTION          => NULL
    ,P_RECURRING_PAYMENT_ID          => NULL
    ,P_PAYMENT_AMOUNT_TOTAL          => NULL
    ,P_POSTING_STATUS                => NULL
    ,P_AUTHORIZED_BY                 => NULL
    ,P_VENDOR_PREPAY_AMOUNT          => NULL
    ,P_PAYMENT_CROSS_RATE_TYPE       => NULL
    ,P_LAST_UPDATE_LOGIN             => NULL
    ,P_ORIGINAL_PREPAYMENT_AMOUNT    => NULL
    ,P_EARLIEST_SETTLEMENT_DATE      => NULL
    ,P_ATTRIBUTE11                   => NULL
    ,P_ATTRIBUTE12                   => NULL
    ,P_ATTRIBUTE13                   => NULL
    ,P_ATTRIBUTE14                   => NULL
    ,P_ATTRIBUTE6                    => NULL
    ,P_ATTRIBUTE7                    => NULL
    ,P_ATTRIBUTE8                    => NULL
    ,P_ATTRIBUTE9                    => NULL
    ,P_ATTRIBUTE10                   => NULL
    ,P_ATTRIBUTE15                   => NULL
    ,P_CANCELLED_DATE                => NULL
    ,P_CANCELLED_BY                  => NULL
    ,P_CANCELLED_AMOUNT              => NULL
    ,P_TEMP_CANCELLED_AMOUNT         => NULL
    ,P_PO_HEADER_ID                  => NULL
    ,P_DOC_SEQUENCE_ID               => NULL
    ,P_DOC_SEQUENCE_VALUE            => NULL
    ,P_DOC_CATEGORY_CODE             => NULL
    ,P_EXPENDITURE_ITEM_DATE         => NULL
    ,P_EXPENDITURE_ORGANIZATION_ID   => NULL
    ,P_EXPENDITURE_TYPE              => NULL
    ,P_PA_DEFAULT_DIST_CCID          => NULL
    ,P_PA_QUANTITY                   => NULL
    ,P_PROJECT_ID                    => NULL
    ,P_TASK_ID                       => NULL
    ,P_AWT_FLAG                      => NULL
    ,P_AWT_GROUP_ID                  => NULL
    ,P_PAY_AWT_GROUP_ID              => NULL
    ,P_REFERENCE_1                   => NULL
    ,P_REFERENCE_2                   => NULL
    ,P_CALLING_SEQUENCE              => NULL
    ,P_AWARD_ID                      => NULL
    ,P_APPROVAL_ITERATION            => NULL
    ,P_QUICK_PO_HEADER_ID            => NULL
    );


    IF x_invoice_id IS NOT NULL THEN
      MO_GLOBAL.Set_Policy_Context ('S', l_org_id);

      AP_HOLDS_PKG.Insert_Single_Hold( x_invoice_id       => x_invoice_id
                                     , x_hold_lookup_code => l_hold_code
                                     , x_hold_type        => l_hold_type
                                     , x_hold_reason      => l_hold_desc
                                     , x_held_by          => 5
                                     );
    END IF;
  EXCEPTION
    WHEN eNoData THEN
      NULL;
    WHEN OTHERS THEN
      x_error_message := 'Error insertando cabecera: '||SQLERRM;
  END crea_cabecera_ap;


  /***************************************************************************
  *                                                                          *
  * Name    : Dummy                                                          *
  * Purpose : Invocacion al servicio dummy                                   *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Dummy( x_response_object   IN OUT NOCOPY  XX_WS_AFIP_DUMMY
                 , x_result            OUT            BOOLEAN
                 , x_error_message     OUT            VARCHAR2
                 ) IS
    l_instance   VARCHAR2(50);
  BEGIN
    x_result := TRUE;

    -----------------
    -- Inicializo WS
    -----------------
    IF NOT XX_WS_AFIP_WSAA_PK.Set_WebService THEN
      x_result := FALSE;
      x_error_message := 'No fue posible configurar los parametros de sistema.';
    END IF;

    -----------------
    -- Seteo EndPoint
    -----------------
    Debug( p_message => '+ setEendpoint');
    l_instance := Set_End_Point;
    Debug( p_message => 'endPoint '||XX_WS_AFIP_FECRED_WRAPPER_PK.getEndpoint);
    Debug( p_message => '- setEendpoint'||chr(10));

    x_response_object := XX_WS_AFIP_FECRED_WRAPPER_PK.Dummy;

  EXCEPTION
    WHEN XX_WSAFIP_UTIL_PK.JAVA_EXCEPTION THEN
      x_result := FALSE;
      x_error_message := XX_WSAFIP_UTIL_PK.Parse_Java_Error(SQLERRM);
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_message := 'DUMMY Others Error. ' || SQLERRM;
  END Dummy;


/****************************************************************************
 *                                                                          *
 * Name    : Consultar_Comprobantes                                         *
 * Purpose : Invoca al servicio consultarComprobantes                       *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Consultar_Comprobantes( errbuf                        IN OUT NOCOPY VARCHAR2
                                  , retcode                       IN OUT NOCOPY NUMBER
                                  , p_cuit_representado           NUMBER
                                  , p_rol_CUIT_representada       VARCHAR2
                                  , p_CUIT_contraparte            NUMBER   DEFAULT NULL
                                  , p_cod_tipo_comprobante        NUMBER   DEFAULT NULL
                                  , p_estado_comprobante          VARCHAR2 DEFAULT NULL
                                  , p_fecha_tipo                  VARCHAR2 DEFAULT NULL
                                  , p_fecha_desde                 VARCHAR2 DEFAULT NULL
                                  , p_fecha_hasta                 VARCHAR2 DEFAULT NULL
                                  , p_cod_cta_cte                 NUMBER   DEFAULT NULL
                                  , p_estado_cta_cte              VARCHAR2 DEFAULT NULL
                                  ) IS
    l_instance         VARCHAR2(50);
    l_ticket_acceso    XX_WS_AFIP_TICKET;
    l_debug            VARCHAR2(10);

    l_soap_req_c       CLOB;
    l_xml_response     XMLTYPE;
    l_fault_code       VARCHAR2(250);
    l_fault_string     VARCHAR2(4000);
    l_fecha_desde      VARCHAR2(20);
    l_fecha_hasta      VARCHAR2(20);
    l_fecha_tipo       VARCHAR2(20);
    l_row_count_i      NUMBER  := 0;
    l_row_count_u      NUMBER  := 0;

    l_invoice_id       NUMBER;
    l_org_id           NUMBER;
    l_vendor_name      VARCHAR2(250);
    l_error_message    VARCHAR2(2000);
    l_num_chr          VARCHAR2(10);
    l_ref_comerciales  VARCHAR2(2000);

    l_result           BOOLEAN;
    eCommonError       EXCEPTION;
  BEGIN
    BEGIN SELECT FND_PROFILE.VALUE('XX_WSAFIP_LOG_MESSAGES') INTO l_debug FROM DUAL; EXCEPTION WHEN NO_DATA_FOUND THEN l_debug := 'N'; END;
    IF l_debug = 'Y' THEN
      G_DEBUG_FLAG := l_debug;
    END IF;

    l_num_chr := Get_Num_Chr;

    IF l_num_chr IS NULL OR
       SUBSTR(l_num_chr,1,1) != '.' THEN
      Set_Num_Chr ('.,');
    END IF;

    FND_FILE.put_line(FND_FILE.LOG, '----------------------------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '- Procedimiento de Actualización del Repositorio de FECRED');
    FND_FILE.put_line(FND_FILE.LOG, '----------------------------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '');
    FND_FILE.put_line(FND_FILE.LOG, 'Parametros:');
    FND_FILE.put_line(FND_FILE.LOG, 'p_cuit_representado: '||p_cuit_representado);
    FND_FILE.put_line(FND_FILE.LOG, 'p_fecha_desde: '||p_fecha_desde);
    FND_FILE.put_line(FND_FILE.LOG, 'p_fecha_hasta: '||p_fecha_hasta);
    FND_FILE.put_line(FND_FILE.LOG, '');


    FND_FILE.put_line(FND_FILE.OUTPUT, '----------------------------------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, '- Procedimiento de Actualización del Repositorio de FECRED');
    FND_FILE.put_line(FND_FILE.OUTPUT, '----------------------------------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, '');
    FND_FILE.put_line(FND_FILE.OUTPUT, '');

    -----------------
    -- Inicializo WS
    -----------------
    IF NOT XX_WS_AFIP_WSAA_PK.Set_WebService THEN
      errbuf  := 'No fue posible configurar los parametros de sistema.';
      RAISE eCommonError;
    END IF;


    -----------------
    -- Seteo EndPoint
    -----------------
    l_instance := Set_End_Point;

    FOR rMain IN (SELECT lookup_code cuit_representado
                  FROM fnd_lookup_values_vl
                  WHERE 1=1
                  AND lookup_type = 'XX_WSAFIP_WSAA_CERTIFICATES'
                  AND attribute11 LIKE '%wsfecred%'
                  AND lookup_code = NVL(p_cuit_representado, lookup_code)
                 ) LOOP

      ------------------------------
      -- Obtengo el ticket de acceso
      ------------------------------
      l_ticket_acceso := NULL;
      XX_WS_AFIP_WSAA_PK.Obtener_Ticket_Acceso
                        ( p_cuit_representado  => rMain.cuit_representado
                        , p_servicio           => 'wsfecred'
                        , p_instance           => l_instance
                        , x_auth_object        => l_ticket_acceso
                        , x_result             => l_result
                        , x_error_message      => errbuf
                        );

      IF (NOT l_result) THEN
        FND_FILE.put_line(FND_FILE.LOG, 'Error obteniendo tk acceso. '||errbuf);
      ELSE
        l_fecha_desde := TO_CHAR(TRUNC(NVL(TO_DATE(p_fecha_desde, 'RRRR-MM-DD HH24:MI:SS'), SYSDATE-6)), 'RRRR-MM-DD');
        l_fecha_hasta := TO_CHAR(TRUNC(NVL(TO_DATE(p_fecha_hasta, 'RRRR-MM-DD HH24:MI:SS'), SYSDATE)), 'RRRR-MM-DD');
        l_fecha_tipo  := NVL(p_fecha_tipo,'Emision');

        l_soap_req_c :=
        '<consultarComprobantesRequest> '||chr(10)||
        '   <authRequest> '||chr(10)||
        '      <token>'||l_ticket_acceso.token||'</token> '||chr(10)||
        '      <sign>'||l_ticket_acceso.sign||'</sign> '||chr(10)||
        '      <cuitRepresentada>'||l_ticket_acceso.cuit||'</cuitRepresentada> '||chr(10)||
        '   </authRequest> '||chr(10)||
        '   <rolCUITRepresentada>'||p_rol_CUIT_representada||'</rolCUITRepresentada> '||chr(10);
            --<!--Optional:-->
        IF p_CUIT_contraparte IS NOT NULL THEN
          l_soap_req_c := l_soap_req_c || '   <CUITContraparte>'||p_CUIT_contraparte||'</CUITContraparte> '||chr(10);
        END IF;
        --  <!--Optional:-->
        IF p_cod_tipo_comprobante IS NOT NULL THEN
          l_soap_req_c := l_soap_req_c || '   <codTipoCmp>'||p_cod_tipo_comprobante||'</codTipoCmp> '||chr(10);
        END IF;
        --  <!--Optional:-->
        IF p_estado_comprobante IS NOT NULL THEN
          l_soap_req_c := l_soap_req_c || '   <estadoCmp>'||p_estado_comprobante||'</estadoCmp> '||chr(10);
        END IF;
        --  <!--Optional:-->
        IF l_fecha_tipo IS NOT NULL THEN
          l_soap_req_c := l_soap_req_c || '   <fecha> '||chr(10)
                                       || '      <tipo>'||l_fecha_tipo||'</tipo> '||chr(10)
                                       || '      <desde>'||l_fecha_desde||'</desde> '||chr(10)
                                       || '      <hasta>'||l_fecha_hasta||'</hasta> '||chr(10)
                                       || '   </fecha> '||chr(10);
        END IF;
        --  <!--Optional:-->
        IF p_cod_cta_cte IS NOT NULL THEN
          l_soap_req_c := l_soap_req_c || '   <codCtaCte>'||p_cod_cta_cte||'</codCtaCte> '||chr(10);
        END IF;
        --  <!--Optional:-->
        IF p_estado_cta_cte IS NOT NULL THEN
          l_soap_req_c := l_soap_req_c || '   <estadoCtaCte>'||p_estado_cta_cte||'</estadoCtaCte> '||chr(10);
        END IF;

        l_soap_req_c := l_soap_req_c ||
        '</consultarComprobantesRequest> '
        ;

        Debug( p_message_c => chr(10)||l_soap_req_c||chr(10)
             , p_module    => 'XX_AP_WSFECRED_PUB.CONSULTAR_COMPROBANTES - Request'
             );

        ---------------------
        -- Invoco el servicio
        ---------------------
        l_xml_response := XX_WS_AFIP_FECRED_WRAPPER_PK.consultarComprobantes(l_soap_req_c);

        Debug( p_message_c => chr(10)||l_xml_response.getClobVal()||chr(10)
             , p_module    => 'XX_AP_WSFECRED_PUB.CONSULTAR_COMPROBANTES - Response'
             );

        BEGIN
          FOR rError IN ( SELECT EXTRACTVALUE (VALUE (a1), '/S:Fault/faultcode', 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"')  faultcode
                               , EXTRACTVALUE (VALUE (a1), '/S:Fault/faultstring', 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"')  faultstring
                          FROM TABLE
                                (XMLSEQUENCE
                                 (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                                         , '/S:Envelope/S:Body/S:Fault'
                                         , 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"'
                                         )
                                 )
                                ) a1
                        ) LOOP
            errbuf := errbuf||rError.faultcode||' - '|| rError.faultstring||chr(10);
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        IF errbuf IS NOT NULL THEN
          RAISE eCommonError;
        END IF;
        --Debug(p_message_c => l_xml_response.getClobVal());

        FOR r1 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/comprobante/cuitEmisor')  cuitEmisor
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/razonSocialEmi')  razonSocialEmi
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/codTipoCmp')  codTipoCmp
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/ptovta')  ptovta
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/nroCmp')  nroCmp
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/cuitReceptor')  cuitReceptor
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/razonSocialRecep')  razonSocialRecep
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/tipoCodAuto')  tipoCodAuto
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/codAutorizacion')  codAutorizacion
                         , TO_DATE(EXTRACTVALUE (VALUE (a1), '/comprobante/fechaEmision'), 'YYYY-MM-DD')  fechaEmision
                         , TO_DATE(EXTRACTVALUE (VALUE (a1), '/comprobante/fechaPuestaDispo'), 'YYYY-MM-DD')  fechaPuestaDispo
                         , TO_DATE(EXTRACTVALUE (VALUE (a1), '/comprobante/fechaVenPago'), 'YYYY-MM-DD')  fechaVenPago
                         , TO_DATE(EXTRACTVALUE (VALUE (a1), '/comprobante/fechaVenAcep'), 'YYYY-MM-DD')  fechaVenAcep
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/importeTotal')  importeTotal
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/codMoneda')  codMoneda
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/cotizacionMoneda')  cotizacionMoneda
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/CBUEmisor')  CBUEmisor
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/AliasEmisor')  AliasEmisor
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/esAnulacion')  esAnulacion
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/esPostAceptacion')  esPostAceptacion
                         --, EXTRACTVALUE (VALUE (a1), '/comprobante/idComprobanteAsociado')  idComprobanteAsociado
                         --, EXTRACTVALUE (VALUE (a1), '/comprobante/referenciasComerciales/texto')  referenciasComerciales
                         --, EXTRACTVALUE (VALUE (a1), '/comprobante/arraySubtotalesIVA')  arraySubtotalesIVA
                         --, EXTRACTVALUE (VALUE (a1), '/comprobante/arrayOtrosTributos')  arrayOtrosTributos
                         --, EXTRACTVALUE (VALUE (a1), '/comprobante/arrayItems')  arrayItems
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/datosGenerales')  datosGenerales
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/datosComerciales')  datosComerciales
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/leyendaComercial')  leyendaComercial
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/codCtaCte')  codCtaCte
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/estado/estado')  estado
                         , CAST(TO_TIMESTAMP(EXTRACTVALUE (VALUE (a1), '/comprobante/estado/fechaHoraEstado'), 'yyyy-mm-dd"T"hh24:mi:ss') AS DATE) fechaHoraEstado
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/tipoAcep')  tipoAcep
                         , CAST(TO_TIMESTAMP(EXTRACTVALUE (VALUE (a1), '/comprobante/fechaHoraAcep'), 'YYYY-MM-DD"T"HH24:MI:SS') AS DATE)  fechaHoraAcep
                         --, EXTRACTVALUE (VALUE (a1), '/comprobante/arrayMotivosRechazo')  arrayMotivosRechazo
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/infoAgDtpoCltv')  infoAgDtpoCltv
                         , TO_DATE(EXTRACTVALUE (VALUE (a1), '/comprobante/fechaInfoAgDptoCltv'), 'YYYY-MM-DD')  fechaInfoAgDptoCltv
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/idPagoAgDptoCltv')  idPagoAgDptoCltv
                         , EXTRACTVALUE (VALUE (a1), '/comprobante/CBUdePago')  CBUdePago
                         , EXTRACT (VALUE (a1), '/comprobante')  comprobanteXML
                    FROM TABLE
                          (XMLSEQUENCE
                           (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                                   , '/ns2:consultarComprobantesResponse/consultarCmpReturn/arrayComprobantes/comprobante'
                                   , 'xmlns:ns2="http://ar.gob.afip.wsfecred/FECredService/"'
                                   )
                           )
                          ) a1
                  ) LOOP
          BEGIN
            BEGIN
              SELECT DISTINCT ou.organization_id
              INTO l_org_id
              FROM hr_operating_units     ou
                 , hr_all_organization_units ou1
                 , hr_locations_all       l
                 , ap_suppliers           s
              WHERE 1=1
              AND ou1.organization_id = ou.organization_id
              AND l.location_id       = ou1.location_id
              AND s.num_1099||s.global_attribute12 = l.global_attribute11||l.global_attribute12
              AND s.num_1099||s.global_attribute12 = r1.cuitReceptor
              ;
            EXCEPTION
              WHEN OTHERS THEN
                l_org_id := NULL;
            END;

            --Referencias Comerciales
            l_ref_comerciales := NULL;
            FOR r11 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/texto')  referenciasComerciales
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                       , '/comprobante/referenciasComerciales/texto'
                                       )
                               )
                              ) a1
                      ) LOOP
              IF l_ref_comerciales IS NULL THEN
                l_ref_comerciales := r11.referenciasComerciales;
              ELSE
                l_ref_comerciales := l_ref_comerciales||' '||r11.referenciasComerciales;
              END IF;
            END LOOP;

            INSERT INTO xx_ap_mipyme_cbtes
            ( cuit_emisor
            , razon_social_emisor
            , codigo_tipo_comprobante
            , punto_venta
            , numero_comprobante
            , cuit_receptor
            , razon_social_receptor
            , tipo_codigo_autoriza
            , codigo_autorizacion
            , fecha_emision
            , fecha_puesta_disposicion
            , fecha_vto_pago
            , fecha_vto_aceptacion
            , importe_total
            , codigo_moneda
            , cotizacion_moneda
            , cbu_emisor
            , alias_emisor
            , es_anulacion
            , es_post_aceptacion
            --, id_comprobante_asociado
            , referencias_comerciales
            , datos_generales
            , datos_comerciales
            , leyenda_comercial
            , codigo_cuenta_corriente
            , estado
            , fecha_estado
            , tipo_aceptacion
            , fecha_aceptacion
            , informado_agente_deposito
            , fecha_info_agente_deposito
            , id_pago_agente_deposito
            , cbu_pago
            , request_id
            , org_id
            , comprobante_xml
            , created_by
            , creation_date
            , last_updated_by
            , last_update_date
            ) VALUES
            ( r1.cuitEmisor
            , r1.razonSocialEmi
            , r1.codTipoCmp
            , r1.ptovta
            , r1.nroCmp
            , r1.cuitReceptor
            , r1.razonSocialRecep
            , r1.tipoCodAuto
            , r1.codAutorizacion
            , r1.fechaEmision
            , r1.fechaPuestaDispo
            , r1.fechaVenPago
            , NVL(r1.fechaVenAcep, r1.fechaEmision+30)
            , r1.importeTotal
            , r1.codMoneda
            , r1.cotizacionMoneda
            , r1.CBUEmisor
            , r1.AliasEmisor
            , r1.esAnulacion
            , r1.esPostAceptacion
            --idComprobanteAsociado
            , REPLACE(l_ref_comerciales, '"', '')
            --arraySubtotalesIVA
            --arrayOtrosTributos
            --arrayItems
            , REPLACE(r1.datosGenerales, '"', '')
            , REPLACE(r1.datosComerciales, '"', '')
            , REPLACE(r1.leyendaComercial, '"', '')
            , r1.codCtaCte
            , r1.estado
            , r1.fechaHoraEstado
            , r1.tipoAcep
            , r1.fechaHoraAcep
            --, r1.arrayMotivosRechazo
            , r1.infoAgDtpoCltv
            , r1.fechaInfoAgDptoCltv
            , r1.idPagoAgDptoCltv
            , r1.CBUdePago
            , FND_GLOBAL.CONC_REQUEST_ID
            , l_org_id
            , r1.comprobanteXML
            , FND_GLOBAL.User_ID
            , SYSDATE
            , FND_GLOBAL.User_ID
            , SYSDATE
            );

            --
            --idComprobanteAsociado
            --
            FOR r12 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/idComprobanteAsociado/CUITEmisor')  CUITEmisorAsoc
                              , EXTRACTVALUE (VALUE (a1), '/idComprobanteAsociado/codTipoCmp')  codTipoCmpAsoc
                              , EXTRACTVALUE (VALUE (a1), '/idComprobanteAsociado/ptoVta')  ptoVtaAsoc
                              , EXTRACTVALUE (VALUE (a1), '/idComprobanteAsociado/nroCmp')  nroCmpAsoc
                         FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                       , '/comprobante/idComprobanteAsociado'
                                       )
                               )
                              ) a1
                      ) LOOP
              BEGIN
                IF r12.CUITEmisorAsoc IS NOT NULL THEN
                  INSERT INTO xx_ap_mipyme_cbtes_asoc
                  ( cuit_emisor
                  , cuit_receptor
                  , codigo_tipo_comprobante
                  , punto_venta
                  , numero_comprobante
                  , cuit_emisor_asoc
                  , codigo_tipo_cbte_asoc
                  , punto_venta_asoc
                  , numero_cbte_asoc
                  ) VALUES
                  ( r1.cuitEmisor
                  , r1.cuitReceptor
                  , r1.codTipoCmp
                  , r1.ptovta
                  , r1.nroCmp
                  , r12.CUITEmisorAsoc
                  , r12.codTipoCmpAsoc
                  , r12.ptoVtaAsoc
                  , r12.nroCmpAsoc
                  );
                END IF;
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  NULL;
              END;
            END LOOP;

            --
            --arrayItems
            --
            FOR r2 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/item/orden')  orden
                             , EXTRACTVALUE (VALUE (a1), '/item/unidadesMtx')  unidadesMtx
                             , EXTRACTVALUE (VALUE (a1), '/item/codigoMtx')  codigoMtx
                             , EXTRACTVALUE (VALUE (a1), '/item/codigo')  codigo
                             , EXTRACTVALUE (VALUE (a1), '/item/descripcion')  descripcion
                             , EXTRACTVALUE (VALUE (a1), '/item/codNomMercosur')  codNomMercosur
                             , EXTRACTVALUE (VALUE (a1), '/item/cantidad')  cantidad
                             , EXTRACTVALUE (VALUE (a1), '/item/codigoUnidadMedida')  codigoUnidadMedida
                             , EXTRACTVALUE (VALUE (a1), '/item/precioUnitario')  precioUnitario
                             , EXTRACTVALUE (VALUE (a1), '/item/importeBonificacion')  importeBonificacion
                             , EXTRACTVALUE (VALUE (a1), '/item/codigoCondicionIVA')  codigoCondicionIVA
                             , EXTRACTVALUE (VALUE (a1), '/item/importeIVA')  importeIVA
                             , EXTRACTVALUE (VALUE (a1), '/item/importeItem')  importeItem
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                       , '/comprobante/arrayItems/item'
                                       )
                               )
                              ) a1
                      ) LOOP
              BEGIN
                IF r2.codigo IS NOT NULL THEN
                  INSERT INTO xx_ap_mipyme_cbtes_items
                  ( cuit_emisor
                  , cuit_receptor
                  , codigo_tipo_comprobante
                  , punto_venta
                  , numero_comprobante
                  , orden
                  , unidades_mtx
                  , codigo_mtx
                  , codigo
                  , descripcion
                  , codigo_nomenclador_mercosur
                  , cantidad
                  , unidad_medida
                  , precio_unitario
                  , importe_bonificacion
                  , codigo_condicion_IVA
                  , importe_IVA
                  , importe_item
                  ) VALUES
                  ( r1.cuitEmisor
                  , r1.cuitReceptor
                  , r1.codTipoCmp
                  , r1.ptovta
                  , r1.nroCmp
                  , r2.orden
                  , r2.unidadesMtx
                  , r2.codigoMtx
                  , r2.codigo
                  , r2.descripcion
                  , r2.codNomMercosur
                  , r2.cantidad
                  , r2.codigoUnidadMedida
                  , r2.precioUnitario
                  , r2.importeBonificacion
                  , r2.codigoCondicionIVA
                  , r2.importeIVA
                  , r2.importeItem
                  );
                END IF;
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  NULL;
              END;
            END LOOP;


            --
            --arraySubtotalesIVA
            --
            FOR r3 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/subtotalIVA/codigo')  codigo
                             , EXTRACTVALUE (VALUE (a1), '/subtotalIVA/baseImponible')  baseImponible
                             , EXTRACTVALUE (VALUE (a1), '/subtotalIVA/importe')  importe
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                       , '/comprobante/arraySubtotalesIVA/subtotalIVA'
                                       )
                               )
                              ) a1
                      ) LOOP
              BEGIN
                IF r3.codigo IS NOT NULL THEN
                  INSERT INTO xx_ap_mipyme_cbtes_iva
                  ( cuit_emisor
                  , cuit_receptor
                  , codigo_tipo_comprobante
                  , punto_venta
                  , numero_comprobante
                  , codigo
                  , base_imponible
                  , importe
                  ) VALUES
                  ( r1.cuitEmisor
                  , r1.cuitReceptor
                  , r1.codTipoCmp
                  , r1.ptovta
                  , r1.nroCmp
                  , r3.codigo
                  , r3.baseImponible
                  , r3.importe
                  );
                END IF;
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  NULL;
              END;
            END LOOP;


            --
            --arrayOtrosTributos
            --
            FOR r4 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/otroTributo/codigo')  codigo
                             , EXTRACTVALUE (VALUE (a1), '/otroTributo/detalle')  detalle
                             , EXTRACTVALUE (VALUE (a1), '/otroTributo/baseImponible')  baseImponible
                             , EXTRACTVALUE (VALUE (a1), '/otroTributo/importe')  importe
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                       , '/comprobante/arrayOtrosTributos/otroTributo'
                                       )
                               )
                              ) a1
                      ) LOOP
              BEGIN
                IF r4.codigo IS NOT NULL THEN
                  INSERT INTO xx_ap_mipyme_cbtes_otros_trib
                  ( cuit_emisor
                  , cuit_receptor
                  , codigo_tipo_comprobante
                  , punto_venta
                  , numero_comprobante
                  , codigo
                  , detalle
                  , base_imponible
                  , importe
                  ) VALUES
                  ( r1.cuitEmisor
                  , r1.cuitReceptor
                  , r1.codTipoCmp
                  , r1.ptovta
                  , r1.nroCmp
                  , r4.codigo
                  , r4.detalle
                  , r4.baseImponible
                  , r4.importe
                  );
                END IF;
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  NULL;
              END;
            END LOOP;


            --
            --arrayMotivosRechazo
            --
            FOR r5 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/motivoRechazo/codMotivo')  codMotivo
                             , EXTRACTVALUE (VALUE (a1), '/motivoRechazo/descMotivo')  descMotivo
                             , EXTRACTVALUE (VALUE (a1), '/motivoRechazo/justificacion')  justificacion
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                       , '/comprobante/arrayMotivosRechazo/motivoRechazo'
                                       )
                               )
                              ) a1
                      ) LOOP
              BEGIN
                IF r5.codMotivo IS NOT NULL THEN
                  INSERT INTO xx_ap_mipyme_cbtes_rechazos
                  ( cuit_emisor
                  , cuit_receptor
                  , codigo_tipo_comprobante
                  , punto_venta
                  , numero_comprobante
                  , codigo_motivo
                  , descripcion_motivo
                  , justificacion
                  ) VALUES
                  ( r1.cuitEmisor
                  , r1.cuitReceptor
                  , r1.codTipoCmp
                  , r1.ptovta
                  , r1.nroCmp
                  , r5.codMotivo
                  , r5.descMotivo
                  , r5.justificacion
                  );
                END IF;
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  NULL;
              END;
            END LOOP;

            l_row_count_i := l_row_count_i + 1;

            /* CR2173 - Oct 2019 - Se realiza la inserción de cabecera desde el proceso
                                   de escaneo de facturas ABBYY

            l_invoice_id    := NULL;
            l_vendor_name   := NULL;
            l_error_message := NULL;

            IF UPPER(p_rol_CUIT_representada) = 'RECEPTOR' THEN
              crea_cabecera_ap ( p_cuit_emisor           => r1.cuitEmisor
                               , p_cuit_receptor         => r1.cuitReceptor
                               , p_codigo_tipo_comprobante => r1.codTipoCmp
                               , p_invoice_num           => LPAD(r1.ptovta,4,0)||'-'||LPAD(r1.nroCmp,8,0)
                               , p_currency_code         => r1.codMoneda
                               , p_exchange_rate         => r1.cotizacionMoneda
                               , p_invoice_amount        => r1.importeTotal
                               , p_invoice_date          => r1.fechaEmision
                               , p_invoice_received_date => r1.fechaPuestaDispo
                               , p_description           => NVL(r1.leyendaComercial, l_ref_comerciales)
                               , p_cbu_pago              => r1.CBUdePago
                               --
                               , x_invoice_id            => l_invoice_id
                               , x_vendor_name           => l_vendor_name
                               , x_error_message         => l_error_message
                               );

              IF l_invoice_id IS NOT NULL THEN
                UPDATE xx_ap_mipyme_cbtes
                SET invoice_id = l_invoice_id
                WHERE 1=1
                AND cuit_emisor             = r1.cuitEmisor
                AND codigo_tipo_comprobante = r1.codTipoCmp
                AND punto_venta             = r1.ptovta
                AND numero_comprobante      = r1.nroCmp
                ;
              ELSIF l_error_message IS NOT NULL THEN
                UPDATE xx_ap_mipyme_cbtes
                SET error_message = l_error_message
                WHERE 1=1
                AND cuit_emisor             = r1.cuitEmisor
                AND codigo_tipo_comprobante = r1.codTipoCmp
                AND punto_venta             = r1.ptovta
                AND numero_comprobante      = r1.nroCmp
                ;
              END IF;
            END IF;*/

            IF l_row_count_i = 1 THEN
              FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Concurrente   | Nro Comprobante  | Proveedor                          | Errores');
            END IF;

            /* Agregado CR2173 */
            BEGIN
              SELECT aps.vendor_name
                INTO l_vendor_name
                FROM AP_SUPPLIERS aps
               WHERE 1=1
                 AND TRUNC(NVL(aps.end_date_active, SYSDATE+1)) >= TRUNC(SYSDATE)
                 AND aps.num_1099||aps.global_attribute12 = r1.cuitEmisor;
            EXCEPTION
              WHEN OTHERS THEN
                l_vendor_name := r1.cuitEmisor;
            END;
            /**/
            FND_FILE.Put_Line(FND_FILE.OUTPUT, RPAD(FND_GLOBAL.CONC_REQUEST_ID, 16, ' ')
                                             || RPAD(LPAD(r1.ptovta, 4, 0)||'-'||LPAD(r1.nroCmp, 8, 0), 19, ' ')
                                             || RPAD(SUBSTR(l_vendor_name, 1, 36), 37, ' ')
                                             --|| SUBSTR(l_error_message, 1, 70)    CR2173
                                             );
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              UPDATE xx_ap_mipyme_cbtes
              SET es_anulacion            = r1.esAnulacion
                , es_post_aceptacion      = r1.esPostAceptacion
                , referencias_comerciales = REPLACE(l_ref_comerciales, '"', '')
                , datos_generales         = REPLACE(r1.datosGenerales, '"', '')
                , datos_comerciales       = REPLACE(r1.datosComerciales, '"', '')
                , leyenda_comercial       = REPLACE(r1.leyendaComercial, '"', '')
                , codigo_cuenta_corriente = r1.codCtaCte
                , estado                  = r1.estado
                , fecha_estado            = r1.fechaHoraEstado
                , tipo_aceptacion         = r1.tipoAcep
                , fecha_aceptacion        = r1.fechaHoraAcep
                , fecha_vto_pago          = r1.fechaVenPago
                , fecha_vto_aceptacion    = NVL(r1.fechaVenAcep, r1.fechaEmision+30)
                , informado_agente_deposito  = r1.infoAgDtpoCltv
                , fecha_info_agente_deposito = r1.fechaInfoAgDptoCltv
                , id_pago_agente_deposito = r1.idPagoAgDptoCltv
                , cbu_pago                = r1.CBUdePago
                , comprobante_xml         = r1.comprobanteXML
                , last_updated_by         = FND_GLOBAL.User_ID
                , last_update_date        = SYSDATE
              WHERE 1=1
              AND cuit_emisor             = r1.cuitEmisor
              AND codigo_tipo_comprobante = r1.codTipoCmp
              AND punto_venta             = r1.ptovta
              AND numero_comprobante      = r1.nroCmp
              ;

              FOR r5 IN ( SELECT EXTRACTVALUE (VALUE (a1), '/motivoRechazo/codMotivo')  codMotivo
                               , EXTRACTVALUE (VALUE (a1), '/motivoRechazo/descMotivo')  descMotivo
                               , EXTRACTVALUE (VALUE (a1), '/motivoRechazo/justificacion')  justificacion
                          FROM TABLE
                                (XMLSEQUENCE
                                 (EXTRACT(XMLTYPE.CREATEXML(r1.comprobanteXML.getClobVal())
                                         , '/comprobante/arrayMotivosRechazo/motivoRechazo'
                                         )
                                 )
                                ) a1
                        ) LOOP
                BEGIN
                  IF r5.codMotivo IS NOT NULL THEN
                    INSERT INTO xx_ap_mipyme_cbtes_rechazos
                    ( cuit_emisor
                    , cuit_receptor
                    , codigo_tipo_comprobante
                    , punto_venta
                    , numero_comprobante
                    , codigo_motivo
                    , descripcion_motivo
                    , justificacion
                    ) VALUES
                    ( r1.cuitEmisor
                    , r1.cuitReceptor
                    , r1.codTipoCmp
                    , r1.ptovta
                    , r1.nroCmp
                    , r5.codMotivo
                    , r5.descMotivo
                    , r5.justificacion
                    );
                  END IF;
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    UPDATE xx_ap_mipyme_cbtes_rechazos
                    SET codigo_motivo      = r5.codMotivo
                      , descripcion_motivo = r5.descMotivo
                      , justificacion      = r5.justificacion
                    WHERE 1=1
                    AND cuit_emisor        = r1.cuitEmisor
                    AND cuit_receptor      = r1.cuitReceptor
                    AND codigo_tipo_comprobante = r1.codTipoCmp
                    AND punto_venta        = r1.ptovta
                    AND numero_comprobante = r1.nroCmp
                    ;
                END;
              END LOOP;

              l_row_count_u := l_row_count_u + 1;
          END;

        END LOOP;
      END IF;
    END LOOP;

    Debug(p_message => 'Se insertaron '||l_row_count_i||' comprobantes');
    Debug(p_message => 'Se actualizaron '||l_row_count_u||' comprobantes');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Se insertaron '||l_row_count_i||' comprobantes.');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Se actualizaron '||l_row_count_u||' comprobantes.');

    COMMIT;

    IF l_num_chr IS NOT NULL THEN
      Set_Num_Chr(l_num_chr);
    END IF;
  EXCEPTION
    WHEN eCommonError THEN
      retcode := 2;
      Debug(p_message => errbuf);

    WHEN XX_WSAFIP_UTIL_PK.JAVA_EXCEPTION THEN
        xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.CONSULTAR_COMPROBANTES'
                             , p_message => 'Error Consultar_Comprobantes JE. '||SQLERRM
                             );
        retcode := 2;
        errbuf := XX_WSAFIP_UTIL_PK.Parse_Java_Error(SQLERRM);
        Debug(p_message => errbuf);
    WHEN OTHERS THEN
        xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.CONSULTAR_COMPROBANTES'
                             , p_message => 'Error Consultar_Comprobantes OTHERS. '||SQLERRM
                             );
        retcode := 2;
        errbuf := 'Consultar_Comprobantes error. ' || SQLERRM;
        Debug(p_message => errbuf);
  END Consultar_Comprobantes;



  /***************************************************************************
  *                                                                          *
  * Name    : Rechazar_FECred                                                *
  * Purpose : Invoca al servicio rechazarFECred                              *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Rechazar_FECred( errbuf                        IN OUT NOCOPY VARCHAR2
                           , retcode                       IN OUT NOCOPY NUMBER
                           , p_cuit_representado           NUMBER
                           , p_cuit_emisor                 NUMBER
                           , p_codigo_tipo_comprobante     NUMBER
                           , p_punto_venta                 NUMBER
                           , p_numero_comprobante          NUMBER
                           , p_codigo_rechazo              NUMBER
                           , p_justificacion               VARCHAR2
                           , p_codigo_cuenta_corriente     NUMBER
                           ) IS
    l_instance         VARCHAR2(50);
    l_ticket_acceso    XX_WS_AFIP_TICKET;
    l_debug            VARCHAR2(10);

    l_soap_req_c       CLOB;
    l_xml_response     XMLTYPE;
    l_fault_code       VARCHAR2(250);
    l_fault_string     VARCHAR2(4000);
    l_fecha_desde      VARCHAR2(20);
    l_fecha_hasta      VARCHAR2(20);
    l_fecha_tipo       VARCHAR2(20);
    l_row_count_i      NUMBER  := 0;
    l_row_count_u      NUMBER  := 0;

    l_invoice_id       NUMBER;
    l_rechazo_desc     VARCHAR2(250);
    l_resultado        VARCHAR2(50);
    l_error_message    VARCHAR2(2000);
    l_num_chr          VARCHAR2(10);

    l_result           BOOLEAN;
    eCommonError       EXCEPTION;
  BEGIN
    BEGIN SELECT FND_PROFILE.VALUE('XX_WSAFIP_LOG_MESSAGES') INTO l_debug FROM DUAL; EXCEPTION WHEN NO_DATA_FOUND THEN l_debug := 'N'; END;
    IF l_debug = 'Y' THEN
      G_DEBUG_FLAG := l_debug;
    END IF;

    l_num_chr := Get_Num_Chr;

    IF l_num_chr IS NULL OR
       SUBSTR(l_num_chr,1,1) != '.' THEN
      Set_Num_Chr ('.,');
    END IF;

    FND_FILE.put_line(FND_FILE.LOG, '--------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '- Procedimiento Para Rechazo de FECRED');
    FND_FILE.put_line(FND_FILE.LOG, '--------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '');
    FND_FILE.put_line(FND_FILE.LOG, 'Parametros:');
    --FND_FILE.put_line(FND_FILE.LOG, 'p_cuit_representado: '||p_cuit_representado);
    --FND_FILE.put_line(FND_FILE.LOG, 'p_invoice_id: '||p_invoice_id);
    FND_FILE.put_line(FND_FILE.LOG, '');


    --FND_FILE.put_line(FND_FILE.OUTPUT, '-----------------------------------------------');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '- Procedimiento Para Informar Rechazo de FECRED');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '-----------------------------------------------');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '');

    -----------------
    -- Inicializo WS
    -----------------
    IF NOT XX_WS_AFIP_WSAA_PK.Set_WebService THEN
      errbuf  := 'No fue posible configurar los parametros de sistema.';
      RAISE eCommonError;
    END IF;


    -----------------
    -- Seteo EndPoint
    -----------------
    l_instance := Set_End_Point;

    ------------------------------
    -- Obtengo el ticket de acceso
    ------------------------------
    XX_WS_AFIP_WSAA_PK.Obtener_Ticket_Acceso
                      ( p_cuit_representado  => p_cuit_representado
                      , p_servicio           => 'wsfecred'
                      , p_instance           => l_instance
                      , x_auth_object        => l_ticket_acceso
                      , x_result             => l_result
                      , x_error_message      => errbuf
                      );

    IF (NOT l_result) THEN
      RAISE eCommonError;
    END IF;

    BEGIN
      SELECT description
      INTO l_rechazo_desc
      FROM fnd_lookup_values_vl
      WHERE lookup_type = 'XX_AFIP_FECRED_TIPO_RECHAZO'
      AND lookup_code   = p_codigo_rechazo
      ;
    EXCEPTION
      WHEN OTHERS THEN
         errbuf := 'Error obteniendo codigo de rechazo.';
         RAISE eCommonError;
    END;

    l_soap_req_c :=
    '<rechazarFECredRequest> '||chr(10)||
    '   <authRequest> '||chr(10)||
    '      <token>'||l_ticket_acceso.token||'</token> '||chr(10)||
    '      <sign>'||l_ticket_acceso.sign||'</sign> '||chr(10)||
    '      <cuitRepresentada>'||l_ticket_acceso.cuit||'</cuitRepresentada> '||chr(10)||
    '   </authRequest> '||chr(10)||
    '   <idCtaCte> '||chr(10)||
    '     <idFactura> '||chr(10)||
    '        <CUITEmisor>'||p_cuit_emisor||'</CUITEmisor> '||chr(10)||
    '        <codTipoCmp>'||p_codigo_tipo_comprobante||'</codTipoCmp> '||chr(10)||
    '        <ptoVta>'||p_punto_venta||'</ptoVta> '||chr(10)||
    '        <nroCmp>'||p_numero_comprobante||'</nroCmp> '||chr(10)||
    '     </idFactura> '||chr(10)||
    '  </idCtaCte> '||chr(10)||
    '  <arrayMotivosRechazo> '||chr(10)||
    '     <motivoRechazo> '||chr(10)||
    '        <codMotivo>'||p_codigo_rechazo||'</codMotivo> '||chr(10)||
    '        <descMotivo>'||l_rechazo_desc||'</descMotivo> '||chr(10)||
    '        <justificacion>'||p_justificacion||'</justificacion> '||chr(10)||
    '     </motivoRechazo> '||chr(10)||
    '  </arrayMotivosRechazo> '||chr(10)||
    '</rechazarFECredRequest> '
    ;

    Debug( p_message_c => chr(10)||l_soap_req_c||chr(10));
    IF G_DEBUG_FLAG = 'Y' THEN
      xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.RECHAZAR_FECRED - Request'
                           , p_message => l_soap_req_c
                           );
    END IF;

    Debug( p_message_c => chr(10)||l_soap_req_c||chr(10)
         , p_module    => 'XX_AP_WSFECRED_PUB.RECHAZAR_FECRED - Request'
         );

    ---------------------
    -- Invoco el servicio
    ---------------------
    l_xml_response := XX_WS_AFIP_FECRED_WRAPPER_PK.rechazarFECred(l_soap_req_c);

    Debug( p_message_c => chr(10)||l_xml_response.getClobVal()||chr(10)
         , p_module    => 'XX_AP_WSFECRED_PUB.RECHAZAR_FECRED - Response'
         );

    BEGIN
      FOR rError IN ( SELECT EXTRACTVALUE (VALUE (a1), '/S:Fault/faultcode', 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"')  faultcode
                           , EXTRACTVALUE (VALUE (a1), '/S:Fault/faultstring', 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"')  faultstring
                      FROM TABLE
                            (XMLSEQUENCE
                             (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                                     , '/S:Envelope/S:Body/S:Fault'
                                     , 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"'
                                     )
                             )
                            ) a1
                    ) LOOP
        errbuf := errbuf||rError.faultcode||' - '|| rError.faultstring||chr(10);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    IF errbuf IS NOT NULL THEN
      RAISE eCommonError;
    END IF;


    SELECT EXTRACTVALUE(VALUE (a1), '/operacionFECredReturn/resultado') resp
    INTO l_resultado
    FROM TABLE
          (XMLSEQUENCE
           (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                   , '/ns2:rechazarFECredResponse/operacionFECredReturn'
                   , 'xmlns:ns2="http://ar.gob.afip.wsfecred/FECredService/"')
           )
          ) a1;

    IF l_resultado = 'A' THEN
      --Transaccion aprobada, actualizo estado
      BEGIN
        SELECT invoice_id
        INTO l_invoice_id
        FROM xx_ap_mipyme_cbtes
        WHERE 1=1
        AND cuit_receptor = p_cuit_representado
        AND cuit_emisor   = p_cuit_emisor
        AND codigo_tipo_comprobante = p_codigo_tipo_comprobante
        AND punto_venta   = p_punto_venta
        AND numero_comprobante      =  p_numero_comprobante
        ;

        UPDATE ap_payment_schedules_all
        SET hold_flag = 'Y'
        WHERE invoice_id = l_invoice_id
        ;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      Consultar_Comprobantes( errbuf                        => errbuf
                            , retcode                       => retcode
                            , p_cuit_representado           => p_cuit_representado
                            , p_rol_CUIT_representada       => 'Receptor'
                            , p_cod_tipo_comprobante        => p_codigo_tipo_comprobante
                            , p_fecha_tipo                  => 'Emision'
                            , p_fecha_desde                 => TO_CHAR(SYSDATE-90, 'RRRR-MM-DD HH24:MI:SS')
                            , p_fecha_hasta                 => TO_CHAR(SYSDATE, 'RRRR-MM-DD HH24:MI:SS')
                            , p_cod_cta_cte                 => p_codigo_cuenta_corriente
                            );
    ELSE
      BEGIN
        FOR rError IN ( SELECT EXTRACTVALUE(VALUE (a1), 'codigoDescripcion/codigo') error_cod
                             , EXTRACTVALUE(VALUE (a1), 'codigoDescripcion/descripcion') error_desc
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                               , '/ns2:rechazarFECredResponse/operacionFECredReturn/arrayErrores/codigoDescripcion'
                               , 'xmlns:ns2="http://ar.gob.afip.wsfecred/FECredService/"')
                               )
                              ) a1
                      ) LOOP

          errbuf := errbuf||rError.error_cod||' - '|| rError.error_desc||chr(10);
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      IF errbuf IS NOT NULL THEN
        RAISE eCommonError;
      END IF;

    END IF;

      --Debug(p_message_c => l_xml_response.getClobVal());

    IF l_num_chr IS NOT NULL THEN
      Set_Num_Chr(l_num_chr);
    END IF;

    retcode := 0;
  EXCEPTION
    WHEN eCommonError THEN
      retcode := 2;
      Debug(p_message => errbuf);

    WHEN XX_WSAFIP_UTIL_PK.JAVA_EXCEPTION THEN
        xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.RECHAZAR_FECRED'
                             , p_message => 'Error Informar_Cancelacion_Total. '||SQLERRM
                             );
        retcode := 2;
        errbuf := XX_WSAFIP_UTIL_PK.Parse_Java_Error(SQLERRM);
        Debug(p_message => errbuf);
    WHEN OTHERS THEN
        xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.RECHAZAR_FECRED'
                             , p_message => 'Error Informar_Cancelacion_Total. '||SQLERRM
                             );
        retcode := 2;
        errbuf := 'Informar_Cancelacion_Total error. ' || SQLERRM;
        Debug(p_message_c => errbuf);
  END Rechazar_FECred;


  /***************************************************************************
  *                                                                          *
  * Name    : Informar_Cancelacion_Total                                     *
  * Purpose : Invoca al servicio informarCancelacionTotalFECred              *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Informar_Cancelacion_Total( errbuf                        IN OUT NOCOPY VARCHAR2
                                      , retcode                       IN OUT NOCOPY NUMBER
                                      , p_cuit_representado           NUMBER
                                      , p_invoice_id                  NUMBER
                                      ) IS

    CURSOR cInvoices IS

      SELECT DISTINCT
             cte.cuit_emisor
           , cte.codigo_tipo_comprobante
           , cte.punto_venta
           , cte.numero_comprobante
           , cte.cuit_receptor
           , cte.fecha_emision
           , cte.codigo_cuenta_corriente
           , cte.codigo_moneda
           , cte.cotizacion_moneda
           , cte.importe_total
           , (SELECT SUM(DECODE( (SELECT lv_dfv.xx_rg3685_nc
                                  FROM fnd_lookup_values_vl lv
                                     , fnd_lookup_values_dfv lv_dfv
                                  WHERE 1=1
                                  AND lv_dfv.row_id = lv.rowid
                                  AND lv_dfv.context = lv.attribute_category
                                  AND lookup_type = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
                                  AND lookup_code = cad.codigo_tipo_comprobante
                                  AND UPPER(meaning) LIKE '%MIPYME%')
                               , 'Y', cad.importe_total*-1
                               , cad.importe_total)
                               )
              FROM xx_ap_mipyme_cbtes_asoc ca
                 , xx_ap_mipyme_cbtes      cad
              WHERE 1=1
              AND ca.cuit_emisor(+)   = cte.cuit_emisor
              AND ca.codigo_tipo_cbte_asoc(+)    = cte.codigo_tipo_comprobante
              AND ca.punto_venta_asoc(+) = cte.punto_venta
              AND ca.numero_cbte_asoc(+) = cte.numero_comprobante
              AND cad.cuit_emisor(+)     = ca.cuit_emisor
              AND cad.codigo_tipo_comprobante(+) = ca.codigo_tipo_comprobante
              AND cad.punto_venta(+)     = ca.punto_venta
              AND cad.numero_comprobante(+)      = ca.numero_comprobante
              AND UPPER(cad.estado) NOT IN ('ACEPTADO', 'RECHAZADO')
             ) importe_total_asoc
      FROM xx_ap_mipyme_cbtes       cte
         , ap_invoices_all          ai
      WHERE 1=1
      AND ai.invoice_id      = cte.invoice_id
      AND ai.payment_status_flag = 'Y'
      AND cte.codigo_tipo_comprobante IN (SELECT lv.lookup_code
                                          FROM fnd_lookup_values_vl lv
                                          WHERE 1=1
                                          AND lv.lookup_type = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
                                          AND UPPER(lv.meaning) LIKE '%MIPYME%'
                                         )
      AND cte.invoice_id     = p_invoice_id
      ;

    r1                 cInvoices%ROWTYPE;
    l_instance         VARCHAR2(50);
    l_ticket_acceso    XX_WS_AFIP_TICKET;
    l_debug            VARCHAR2(10);

    l_soap_req_c       CLOB;
    l_xml_response     XMLTYPE;
    l_fault_code       VARCHAR2(250);
    l_fault_string     VARCHAR2(4000);
    l_fecha_desde      VARCHAR2(20);
    l_fecha_hasta      VARCHAR2(20);
    l_fecha_tipo       VARCHAR2(20);
    l_row_count_i      NUMBER  := 0;
    l_row_count_u      NUMBER  := 0;

    l_invoice_id       NUMBER;
    l_cancelacion_desc VARCHAR2(250);
    l_resultado        VARCHAR2(50);
    l_error_message    VARCHAR2(2000);
    l_num_chr          VARCHAR2(10);
    l_importe_cancela  NUMBER;

    l_result           BOOLEAN;
    eCommonError       EXCEPTION;
  BEGIN
    BEGIN SELECT FND_PROFILE.VALUE('XX_WSAFIP_LOG_MESSAGES') INTO l_debug FROM DUAL; EXCEPTION WHEN NO_DATA_FOUND THEN l_debug := 'N'; END;
    IF l_debug = 'Y' THEN
      G_DEBUG_FLAG := l_debug;
    END IF;

    l_num_chr := Get_Num_Chr;

    IF l_num_chr IS NULL OR
       SUBSTR(l_num_chr,1,1) != '.' THEN
      Set_Num_Chr ('.,');
    END IF;

    FND_FILE.put_line(FND_FILE.LOG, '---------------------------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '- Procedimiento Para Informar Cancelacion Total de FECRED');
    FND_FILE.put_line(FND_FILE.LOG, '---------------------------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '');
    FND_FILE.put_line(FND_FILE.LOG, 'Parametros:');
    FND_FILE.put_line(FND_FILE.LOG, 'p_cuit_representado: '||p_cuit_representado);
    FND_FILE.put_line(FND_FILE.LOG, 'p_invoice_id: '||p_invoice_id);
    FND_FILE.put_line(FND_FILE.LOG, '');


    --FND_FILE.put_line(FND_FILE.OUTPUT, '---------------------------------------------------------');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '- Procedimiento Para Informar Cancelacion Total de FECRED');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '---------------------------------------------------------');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '');
    --FND_FILE.put_line(FND_FILE.OUTPUT, '');

    -----------------
    -- Inicializo WS
    -----------------
    IF NOT XX_WS_AFIP_WSAA_PK.Set_WebService THEN
      errbuf  := 'No fue posible configurar los parametros de sistema.';
      RAISE eCommonError;
    END IF;


    -----------------
    -- Seteo EndPoint
    -----------------
    l_instance := Set_End_Point;

    ------------------------------
    -- Obtengo el ticket de acceso
    ------------------------------
    XX_WS_AFIP_WSAA_PK.Obtener_Ticket_Acceso
                      ( p_cuit_representado  => p_cuit_representado
                      , p_servicio           => 'wsfecred'
                      , p_instance           => l_instance
                      , x_auth_object        => l_ticket_acceso
                      , x_result             => l_result
                      , x_error_message      => errbuf
                      );

    IF (NOT l_result) THEN
      RAISE eCommonError;
    END IF;

    OPEN cInvoices;
    FETCH cInvoices INTO r1;
    IF cInvoices%NOTFOUND THEN
      errbuf := 'No se encontró el comprobante ('||p_invoice_id||') o el mismo no se encuentra pago.';
      RAISE eCommonError;
    END IF;
    CLOSE cInvoices;



    FOR r1 IN cInvoices LOOP
      l_soap_req_c :=
      '<aceptarFECredRequest> '||chr(10)||
      '   <authRequest> '||chr(10)||
      '      <token>'||l_ticket_acceso.token||'</token> '||chr(10)||
      '      <sign>'||l_ticket_acceso.sign||'</sign> '||chr(10)||
      '      <cuitRepresentada>'||l_ticket_acceso.cuit||'</cuitRepresentada> '||chr(10)||
      '   </authRequest> '||chr(10)||
      '   <idCtaCte> '||chr(10)||
      '     <codCtaCte>'||r1.codigo_cuenta_corriente||'</codCtaCte> '||chr(10)||
      /*'     <idFactura> '||chr(10)||
      '        <CUITEmisor>'||r1.cuit_emisor||'</CUITEmisor> '||chr(10)||
      '        <codTipoCmp>'||r1.codigo_tipo_comprobante||'</codTipoCmp> '||chr(10)||
      '        <ptoVta>'||r1.punto_venta||'</ptoVta> '||chr(10)||
      '        <nroCmp>'||r1.numero_comprobante||'</nroCmp> '||chr(10)||
      '     </idFactura> '||chr(10)||*/
      '  </idCtaCte> '||chr(10);

      IF r1.importe_total_asoc IS NOT NULL THEN
        l_soap_req_c := l_soap_req_c ||
        '  <arrayConfirmarNotasDC> '||chr(10);
        FOR rCA IN (SELECT ca.cuit_emisor, ca.codigo_tipo_comprobante, ca.punto_venta, ca.numero_comprobante
                    FROM xx_ap_mipyme_cbtes_asoc ca
                       , xx_ap_mipyme_cbtes      cad
                    WHERE 1=1
                    AND ca.cuit_emisor      = r1.cuit_emisor
                    AND ca.codigo_tipo_cbte_asoc = r1.codigo_tipo_comprobante
                    AND ca.punto_venta_asoc = r1.punto_venta
                    AND ca.numero_cbte_asoc = r1.numero_comprobante
                    AND cad.cuit_emisor      = ca.cuit_emisor
                    AND cad.codigo_tipo_comprobante = ca.codigo_tipo_comprobante
                    AND cad.punto_venta        = ca.punto_venta
                    AND cad.numero_comprobante = ca.numero_comprobante
                    AND UPPER(cad.estado) NOT IN ('ACEPTADO', 'RECHAZADO')
                   ) LOOP
          l_soap_req_c := l_soap_req_c ||
        '     <confirmarNota> '||chr(10)||
        '        <acepta>S</acepta> '||chr(10)||
        '        <idNota> '||chr(10)||
        '           <CUITEmisor>'||rCA.cuit_emisor||'</CUITEmisor> '||chr(10)||
        '           <codTipoCmp>'||rCA.codigo_tipo_comprobante||'</codTipoCmp> '||chr(10)||
        '           <ptoVta>'||rCA.punto_venta||'</ptoVta> '||chr(10)||
        '           <nroCmp>'||rCA.numero_comprobante||'</nroCmp> '||chr(10)||
        '        </idNota> '||chr(10)||
        '     </confirmarNota> '||chr(10);
        END LOOP;
        l_soap_req_c := l_soap_req_c ||
        '  </arrayConfirmarNotasDC> '||chr(10);
      END IF;

      IF r1.importe_total_asoc IS NULL OR
         r1.importe_total + r1.importe_total_asoc != 0 THEN
        l_soap_req_c := l_soap_req_c ||
        '  <arrayFormasCancelacion> '||chr(10);
        FOR rPay IN (SELECT DISTINCT lv.lookup_code, lv.description
                     FROM ap_invoice_payments_all  ip
                        , ap_checks_all            ac
                        , fnd_lookup_values_vl     lv
                     WHERE 1=1
                     AND ac.check_id        = ip.check_id
                     AND lv.lookup_type     = 'XX_AFIP_FECRED_TIPO_CANCELA'
                     AND INSTR(lv.tag, ac.payment_method_code) > 0
                     AND ip.invoice_id      = p_invoice_id
                    ) LOOP
          l_soap_req_c := l_soap_req_c ||
        '     <codigoDescripcion> '||chr(10)||
        '        <codigo>'||rPay.lookup_code||'</codigo> '||chr(10)||
        '        <descripcion>'||rPay.description||'</descripcion> '||chr(10)||
        '     </codigoDescripcion> '||chr(10);
        END LOOP;
        l_importe_cancela := r1.importe_total + NVL(r1.importe_total_asoc,0);
        l_soap_req_c := l_soap_req_c ||
        '  </arrayFormasCancelacion> '||chr(10)||
        '  <tipoCancelacion>TOT</tipoCancelacion> '||chr(10)||
        '  <importeCancelado>'||l_importe_cancela||'</importeCancelado> '||chr(10);
      END IF;

      l_soap_req_c := l_soap_req_c ||
      '  <saldoAceptado>0</saldoAceptado> '||chr(10)||
      '  <codMoneda>'||r1.codigo_moneda||'</codMoneda> '||chr(10)||
      '  <cotizacionMonedaUlt>'||r1.cotizacion_moneda||'</cotizacionMonedaUlt> '||chr(10)||
      '</aceptarFECredRequest> '
      ;

      Debug( p_message_c => chr(10)||l_soap_req_c||chr(10)
           , p_module    => 'XX_AP_WSFECRED_PUB.INFORMAR_CANCELACION_TOTAL - Request'
           );

      ---------------------
      -- Invoco el servicio
      ---------------------
      l_xml_response := XX_WS_AFIP_FECRED_WRAPPER_PK.aceptarFECred(l_soap_req_c);

      Debug( p_message_c => chr(10)||l_xml_response.getClobVal()||chr(10)
           , p_module    => 'XX_AP_WSFECRED_PUB.INFORMAR_CANCELACION_TOTAL - Response'
           );

      BEGIN
        FOR rError IN ( SELECT EXTRACTVALUE (VALUE (a1), '/S:Fault/faultcode', 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"')  faultcode
                             , EXTRACTVALUE (VALUE (a1), '/S:Fault/faultstring', 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"')  faultstring
                        FROM TABLE
                              (XMLSEQUENCE
                               (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                                       , '/S:Envelope/S:Body/S:Fault'
                                       , 'xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"'
                                       )
                               )
                              ) a1
                      ) LOOP
          errbuf := errbuf||rError.faultcode||' - '|| rError.faultstring||chr(10);
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      IF errbuf IS NOT NULL THEN
        RAISE eCommonError;
      END IF;


      SELECT EXTRACTVALUE(VALUE (a1), '/operacionFECredReturn/resultado') resp
      INTO l_resultado
      FROM TABLE
            (XMLSEQUENCE
             (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                     , '/ns2:aceptarFECredResponse/operacionFECredReturn'
                     , 'xmlns:ns2="http://ar.gob.afip.wsfecred/FECredService/"')
             )
            ) a1;

      IF l_resultado = 'A' THEN
        --Transaccion aprobada, actualizo estado
        Consultar_Comprobantes( errbuf                        => errbuf
                              , retcode                       => retcode
                              , p_cuit_representado           => p_cuit_representado
                              , p_rol_CUIT_representada       => 'Receptor'
                              , p_cod_tipo_comprobante        => r1.codigo_tipo_comprobante
                              , p_fecha_tipo                  => 'Emision'
                              , p_fecha_desde                 => TO_CHAR(r1.fecha_emision, 'RRRR-MM-DD HH24:MI:SS')
                              , p_fecha_hasta                 => TO_CHAR(r1.fecha_emision, 'RRRR-MM-DD HH24:MI:SS')
                              , p_cod_cta_cte                 => r1.codigo_cuenta_corriente
                              );
      ELSE
        BEGIN
          FOR rError IN ( SELECT EXTRACTVALUE(VALUE (a1), 'codigoDescripcion/codigo') error_cod
                               , EXTRACTVALUE(VALUE (a1), 'codigoDescripcion/descripcion') error_desc
                          FROM TABLE
                                (XMLSEQUENCE
                                 (EXTRACT(XMLTYPE.CREATEXML(l_xml_response.getClobVal())
                                 , '/ns2:aceptarFECredResponse/operacionFECredReturn/arrayErrores/codigoDescripcion'
                                 , 'xmlns:ns2="http://ar.gob.afip.wsfecred/FECredService/"')
                                 )
                                ) a1
                        ) LOOP

            errbuf := errbuf||rError.error_cod||' - '|| rError.error_desc||chr(10);
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        IF errbuf IS NOT NULL THEN
          RAISE eCommonError;
        END IF;

      END IF;

      --Debug(p_message_c => l_xml_response.getClobVal());
    END LOOP;

    IF l_num_chr IS NOT NULL THEN
      Set_Num_Chr(l_num_chr);
    END IF;

    retcode := 0;
  EXCEPTION
    WHEN eCommonError THEN
      retcode := 2;
      Debug(p_message => errbuf);

    WHEN XX_WSAFIP_UTIL_PK.JAVA_EXCEPTION THEN
        xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.INFORMAR_CANCELACION_TOTAL'
                             , p_message => 'Error Informar_Cancelacion_Total. '||SQLERRM
                             );
        retcode := 2;
        errbuf := XX_WSAFIP_UTIL_PK.Parse_Java_Error(SQLERRM);
        Debug(p_message => errbuf);
    WHEN OTHERS THEN
        xx_debug_aux_pk.debug( p_module => 'XX_AP_WSFECRED_PUB.INFORMAR_CANCELACION_TOTAL'
                             , p_message => 'Error Informar_Cancelacion_Total. '||SQLERRM
                             );
        retcode := 2;
        errbuf := 'Informar_Cancelacion_Total error. ' || SQLERRM;
        Debug(p_message_c => errbuf);
  END Informar_Cancelacion_Total;


  /***************************************************************************
  *                                                                          *
  * Name    : Procesa_Repositorio                                            *
  * Purpose : Rechaza o Acepta comprobantes de forma automática              *
  *                                                                          *
  ****************************************************************************/
  PROCEDURE Procesa_Repositorio ( errbuf            IN OUT NOCOPY VARCHAR2
                                , retcode           IN OUT NOCOPY NUMBER
                                , p_dias_fecha_vto                NUMBER
                                , p_operating_unit                NUMBER
                                , p_codigo_rechazo                NUMBER
                                , p_justificacion                 VARCHAR2
                                ) IS

    TYPE tRepoType IS RECORD
    ( unidad_operativa    VARCHAR2(300)
    , tipo_comprobante    VARCHAR2(10)
    , punto_venta         VARCHAR2(10)
    , numero_comprobante  VARCHAR2(20)
    , mensaje_codigo      VARCHAR2(250)
    , mensaje             VARCHAR2(4000)
    );
    rRepoType             tRepoType;
    TYPE tRepoTypeTab IS TABLE OF tRepoType;
    rRepoTypeTab          tRepoTypeTab;

    TYPE tOUTab       IS TABLE OF VARCHAR2(500);
    rOUTab                tOUTab;

    CURSOR c1 IS

      SELECT s.vendor_name unidad_operativa
           , cbte.invoice_id
           , cbte.fecha_emision
           , TRUNC(cbte.fecha_vto_aceptacion) fecha_vto_aceptacion
           , cbte.estado
           , cbte.cuit_receptor
           , cbte.cuit_emisor
           , cbte.codigo_tipo_comprobante
           , cbte.punto_venta
           , cbte.numero_comprobante
           , cbte.codigo_cuenta_corriente
           , NVL(ai.payment_status_flag, 'N') payment_status_flag
           , NVL(hp_dfv.xx_ap_rech_aut,'Y') rechazo_automatico
           , AP_INVOICES_PKG.GET_APPROVAL_STATUS (ai.invoice_id
                                                 ,ai.invoice_amount
                                                 ,ai.payment_status_flag
                                                 ,ai.invoice_type_lookup_code) approval_status
      FROM xx_ap_mipyme_cbtes cbte
         , ap_invoices_all    ai
         , ap_suppliers       s
         , hz_parties         hp
         , hz_parties_dfv     hp_dfv
      WHERE 1=1
      AND ai.invoice_id(+) = cbte.invoice_id
      AND s.num_1099||s.global_attribute12 = TO_CHAR(cbte.cuit_receptor)
      AND hp.party_id      = s.party_id
      AND hp_dfv.row_id    = hp.rowid
      AND UPPER(cbte.estado) NOT IN ('RECHAZADO', 'ACEPTADO')
      AND cbte.fecha_vto_aceptacion >= TRUNC(SYSDATE)
      AND XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c(cuit_receptor) = 'Y'
      AND ( p_operating_unit IS NULL OR
            p_operating_unit = XX_SECURITY_PKG.Cuit_Operating_Unit(cbte.cuit_receptor)
          )
      ORDER BY s.vendor_name, cbte.fecha_vto_aceptacion
      ;


    l_error_message   VARCHAR2(4000);
    l_retcode         VARCHAR2(10);
    l_ou              VARCHAR2(500);
    l_num_chr         VARCHAR2(10);
    l_mensaje_codigo  VARCHAR2(50);
    l_mensaje         VARCHAR2(2000);
    l_idx             NUMBER;
    l_exted           BOOLEAN := FALSE;
  BEGIN
    l_num_chr := Get_Num_Chr;

    IF l_num_chr IS NULL OR
       SUBSTR(l_num_chr,1,1) != '.' THEN
      Set_Num_Chr ('.');
    END IF;

    FND_FILE.put_line(FND_FILE.LOG, '----------------------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '- Procedimiento Para Procesar Comprobantes de FECRED');
    FND_FILE.put_line(FND_FILE.LOG, '----------------------------------------------------');
    FND_FILE.put_line(FND_FILE.LOG, '');
    FND_FILE.put_line(FND_FILE.LOG, 'Parámetros');
    FND_FILE.put_line(FND_FILE.LOG, 'p_dias_fecha_vto: '||p_dias_fecha_vto);
    FND_FILE.put_line(FND_FILE.LOG, 'p_operating_unit: '||p_operating_unit);
    FND_FILE.put_line(FND_FILE.LOG, 'p_codigo_rechazo: '||p_codigo_rechazo);
    FND_FILE.put_line(FND_FILE.LOG, 'p_justificacion:  '||p_justificacion);
    FND_FILE.put_line(FND_FILE.LOG, '');

    FND_FILE.put_line(FND_FILE.OUTPUT, '----------------------------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, '- Procedimiento Para Procesar Comprobantes de FECRED');
    FND_FILE.put_line(FND_FILE.OUTPUT, '----------------------------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, '');
    FND_FILE.put_line(FND_FILE.OUTPUT, '');

    rRepoTypeTab := tRepoTypeTab();
    rOUTab := tOUTab();
    l_idx  := 0;

    FOR r1 IN c1 LOOP
      l_error_message := NULL;
      l_exted := FALSE;

      IF r1.payment_status_flag = 'N' AND
         r1.fecha_vto_aceptacion BETWEEN TRUNC(SYSDATE) AND TRUNC(SYSDATE+NVL(p_dias_fecha_vto,1)) AND
         r1.rechazo_automatico = 'N' THEN
        NULL; --No tomo accion
      ELSE

        /* CANCELACION TOTAL */
        IF r1.payment_status_flag = 'Y' THEN
          l_exted := TRUE;
          XX_AP_WSFECRED_PUB.Informar_Cancelacion_Total
                            ( errbuf              => l_error_message
                            , retcode             => l_retcode
                            , p_cuit_representado => r1.cuit_receptor
                            , p_invoice_id        => r1.invoice_id
                            );

          IF l_error_message IS NULL THEN
            FND_FILE.put_line(FND_FILE.LOG, 'El comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||' fue aceptado correctamente.');
            l_mensaje_codigo   := 'CANCELACION';
            l_mensaje          := 'El comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||' fue aceptado correctamente.';
          ELSE
            FND_FILE.put_line(FND_FILE.LOG, 'Error intentando aceptar el comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||'. '||l_error_message);
            l_mensaje_codigo   := 'ERROR';
            l_mensaje          := 'Error intentando aceptar el comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||'. '||l_error_message;
          END IF;

        /* RECHAZAR */
        ELSIF r1.payment_status_flag = 'N' AND
              ( r1.approval_status IS NULL OR
                r1.approval_status != 'APPROVED'
              ) AND
              r1.fecha_vto_aceptacion BETWEEN TRUNC(SYSDATE) AND TRUNC(SYSDATE+NVL(p_dias_fecha_vto,1)) THEN
          l_exted := TRUE;
          XX_AP_WSFECRED_PUB.Rechazar_FECred
                            ( errbuf                        => l_error_message
                            , retcode                       => l_retcode
                            , p_cuit_representado           => r1.cuit_receptor
                            , p_cuit_emisor                 => r1.cuit_emisor
                            , p_codigo_tipo_comprobante     => r1.codigo_tipo_comprobante
                            , p_punto_venta                 => r1.punto_venta
                            , p_numero_comprobante          => r1.numero_comprobante
                            , p_codigo_rechazo              => p_codigo_rechazo
                            , p_justificacion               => p_justificacion
                            , p_codigo_cuenta_corriente     => r1.codigo_cuenta_corriente
                            );

          IF l_error_message IS NULL THEN
            FND_FILE.put_line(FND_FILE.LOG, 'El comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||' fue rechazado correctamente.');
            l_mensaje_codigo   := 'RECHAZO';
            l_mensaje          := 'El comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||' fue rechazado correctamente.';
          ELSE
            FND_FILE.put_line(FND_FILE.LOG, 'Error intentando rechaar el comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||'. '||l_error_message);
            l_mensaje_codigo   := 'ERROR';
            l_mensaje          := 'Error intentando rechaar el comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||'. '||l_error_message;
          END IF;

        /* ERROR */
        ELSIF r1.payment_status_flag = 'P' AND
              r1.fecha_vto_aceptacion BETWEEN TRUNC(SYSDATE) AND TRUNC(SYSDATE+NVL(p_dias_fecha_vto,1)) THEN
          l_exted := TRUE;
          FND_FILE.put_line(FND_FILE.LOG, 'El comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||' no pudo ser Rechazado ni Aceptado ya que cuenta con pagos parciales.');
          l_mensaje_codigo   := 'ERROR';
          l_mensaje          := 'El comprobante '||LPAD(r1.punto_venta,4,0)||'-'||LPAD(r1.numero_comprobante, 8, 0)||' para el proveedor '||r1.cuit_emisor||' no pudo ser Rechazado ni Aceptado ya que cuenta con pagos parciales.';

        END IF;

        IF l_exted THEN
          rRepoTypeTab.EXTEND(1);
          rRepoType.unidad_operativa := r1.unidad_operativa;
          rRepoType.tipo_comprobante := r1.codigo_tipo_comprobante;
          rRepoType.punto_venta      := LPAD(r1.punto_venta,4,0);
          rRepoType.numero_comprobante := LPAD(r1.numero_comprobante,8,0);
          rRepoType.mensaje_codigo   := l_mensaje_codigo;
          rRepoType.mensaje          := l_mensaje;
          l_idx := l_idx + 1;
          rRepoTypeTab(l_idx)  := rRepoType;
        END IF;

      END IF;
    END LOOP;

    l_idx := 1;
    FOR i IN rRepoTypeTab.FIRST .. rRepoTypeTab.LAST LOOP
      IF i = 1 OR
         l_ou != rRepoTypeTab(i).unidad_operativa THEN
        rOUTab.EXTEND(1);
        rOUTab(l_idx) := rRepoTypeTab(i).unidad_operativa;
        l_ou  := rRepoTypeTab(i).unidad_operativa;
        l_idx := l_idx + 1;
      END IF;

    END LOOP;

    l_ou := NULL;

    FND_FILE.put_line(FND_FILE.OUTPUT, ' ');
    FOR j IN rOUTab.FIRST .. rOUTab.LAST LOOP
      FND_FILE.put_line(FND_FILE.OUTPUT, '------------------------------------------');
      FND_FILE.put_line(FND_FILE.OUTPUT, 'Información correspondiente a la compañia: '||rOUTab(j));
      FND_FILE.put_line(FND_FILE.OUTPUT, '------------------------------------------');
      FND_FILE.put_line(FND_FILE.OUTPUT, ' ');

      /* Errores */
      FND_FILE.put_line(FND_FILE.OUTPUT, 'ERRORES:');
      FND_FILE.put_line(FND_FILE.OUTPUT, '--------');
      FOR i IN rRepoTypeTab.FIRST .. rRepoTypeTab.LAST LOOP
        IF rRepoTypeTab(i).mensaje_codigo = 'ERROR' AND
           rRepoTypeTab(i).unidad_operativa = rOUTab(j) THEN
          --DBMS_OUTPUT.PUT_LINE(rRepoTypeTab(i).mensaje);
          FND_FILE.put_line(FND_FILE.OUTPUT, rRepoTypeTab(i).mensaje);
        END IF;
      END LOOP;
      FND_FILE.put_line(FND_FILE.OUTPUT, ' ');

      FND_FILE.put_line(FND_FILE.OUTPUT, 'RECHAZOS:');
      FND_FILE.put_line(FND_FILE.OUTPUT, '--------');
      FOR i IN rRepoTypeTab.FIRST .. rRepoTypeTab.LAST LOOP
        IF rRepoTypeTab(i).mensaje_codigo = 'RECHAZO' AND
           rRepoTypeTab(i).unidad_operativa = rOUTab(j) THEN
          --DBMS_OUTPUT.PUT_LINE(rRepoTypeTab(i).mensaje);
          FND_FILE.put_line(FND_FILE.OUTPUT, rRepoTypeTab(i).mensaje);
        END IF;
      END LOOP;
      FND_FILE.put_line(FND_FILE.OUTPUT, ' ');

      FND_FILE.put_line(FND_FILE.OUTPUT, 'CANCELACIONES TOTALES:');
      FND_FILE.put_line(FND_FILE.OUTPUT, '----------------------');
      FOR i IN rRepoTypeTab.FIRST .. rRepoTypeTab.LAST LOOP
        IF rRepoTypeTab(i).mensaje_codigo = 'CANCELACION' AND
           rRepoTypeTab(i).unidad_operativa = rOUTab(j) THEN
          --DBMS_OUTPUT.PUT_LINE(rRepoTypeTab(i).mensaje);
          FND_FILE.put_line(FND_FILE.OUTPUT, rRepoTypeTab(i).mensaje);
        END IF;
      END LOOP;

      FND_FILE.put_line(FND_FILE.OUTPUT, ' ');
      FND_FILE.put_line(FND_FILE.OUTPUT, ' ');

    END LOOP;

    IF l_num_chr IS NOT NULL THEN
      Set_Num_Chr(l_num_chr);
    END IF;


  END Procesa_Repositorio;

END;
/

exit
