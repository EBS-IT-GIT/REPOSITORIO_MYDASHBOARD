DELETE FROM xx_tcg_gasto_acondicionamiento
      WHERE acond_id IN (6862, 6863, 6864, 6865, 6866, 6841, 6842, );
--7