UPDATE xx_tcg_cartas_porte_all xcp
   SET gastos_acond_calculados_flag = 'N'
 WHERE 1 = 1 AND gastos_acond_calculados_flag = 'Y'
       AND EXISTS
              (SELECT 1
                 FROM xx_tcg_gasto_acondicionamiento xga
                WHERE xga.carta_porte_id = xcp.carta_porte_id
                      AND acond_id IN
                             (6862, 6863, 6864, 6865, 6866, 6841, 6842);
--7