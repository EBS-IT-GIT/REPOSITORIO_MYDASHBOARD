#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2496_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2496
# |
# | HISTORY
# |   22-JUN-20  Rosas, Ines - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2496_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2496_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2496
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/RESPO
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2496" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2496_13933.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2496"
AddAllLogs $CROUT "FND" "CR2496_13933.ldt"
mv CR2496_13933.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXFAXMAREV " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXFAXMAREV.ldt FUNCTION FUNCTION_NAME="XXFAXMAREV"
AddAllLogs $CROUT "FND" "XXFAXMAREV.ldt"
mv XXFAXMAREV.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_AR_FA_NAVIGATE_MULTIENTIDAD " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt MENU MENU_NAME="XX_AR_FA_NAVIGATE_MULTIENTIDAD"
AddAllLogs $CROUT "FND" "XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt"
mv XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-RESPO XX_AR_FA_SUPERVISOR_ENT_ARG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscursp.lct XX_AR_FA_SUPERVISOR_ENT_ARG.ldt FND_RESPONSIBILITY RESP_KEY="XX_AR_FA_SUPERVISOR_ENT_ARG"
AddAllLogs $CROUT "FND" "XX_AR_FA_SUPERVISOR_ENT_ARG.ldt"
mv XX_AR_FA_SUPERVISOR_ENT_ARG.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/RESPO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXFAXMAREV " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXFAXMAREV.fmb ]; then
  cp $AU_TOP/forms/US/XXFAXMAREV.fmb XXFAXMAREV.fmb
  echo `ls -lh XXFAXMAREV.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXFAXMAREV.fmb no existe" >> $CROUT
fi
mv XXFAXMAREV* $DOWNDBDIR/au/12.0.0/forms/US/


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-FUNC XXFAXMAREV " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXFAXMAREV.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-MENU XX_AR_FA_NAVIGATE_MULTIENTIDAD " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_AR_FA_NAVIGATE_MULTIENTIDAD.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-RESPO XX_AR_FA_SUPERVISOR_ENT_ARG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscursp.lct $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXFAXMAREV " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXFAXMAREV.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXFAXMAREV.fmb`" >> $CROUT
mv XXFAXMAREV.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXFAXMAREV.fmx` >> $CROUT
cd $CURDIR
if ! ls /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXFAXMAREV.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXFAXMAREV.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXFAXMAREV.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXFAXMAREV.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXFAXMAREV.fmb -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXFAXMAREV " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXFAXMAREV.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXFAXMAREV.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2496" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2496_13933.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2496_13933.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
