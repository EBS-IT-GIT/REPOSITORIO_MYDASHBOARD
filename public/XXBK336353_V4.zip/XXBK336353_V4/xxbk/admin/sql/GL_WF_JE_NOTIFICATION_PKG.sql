create or replace PACKAGE BODY GL_WF_JE_NOTIFICATION_PKG AS
/* $Header: glwfntfb.pls 120.0.12020000.3 2015/09/10 10:19:18 degoel noship $ */

   g_jour_line_allowed_length     NUMBER        := 32000;  -- Bug 3592883
   g_object_type_code                 VARCHAR2(50)  := 'GL_JOURNAL_APPROVAL';

   TYPE g_string_tab
   IS
   TABLE OF VARCHAR2(32000)
   INDEX BY BINARY_INTEGER;

   g_list_of_approvers            g_string_tab;
   g_index_of_approver            NUMBER        := 0;

--|======================================================================|
--| Name             : diagn_msg                                         |
--|                                                                      |
--| Description      : This procedure inserts debug messages in a custom |
--|                    table XXRB_GL_WF_DEBUG_TMP                        |
--|                                                                      |
--| Parameters       : p_message_string_in IN  VARCHAR2                  |
--|                                                                      |
--| Returns          : N.A                                               |
--|======================================================================|

   PROCEDURE diagn_msg (p_message_string_in IN  VARCHAR2)
   IS
   PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
         IF ( FND_LOG.LEVEL_STATEMENT >= FND_LOG.G_CURRENT_RUNTIME_LEVEL )
         THEN
            Fnd_Log.STRING(log_level => Fnd_Log.LEVEL_STATEMENT,MODULE =>'[GL_WF_JE_NOTIFICATION_PKG] :'  ,message => p_message_string_in);
         END IF;
   EXCEPTION
      WHEN OTHERS THEN
         NULL;
   END diagn_msg;

--|=====================================================================|
--| Name             : get_item_info                    |
--|                                     |
--| Description      : This procedure retrives the itemtype and itemkey |
--|                    from p_documentId_in to build a text/html format |
--|                                     |
--| Parameters       : p_documentId_in IN VARCHAR2          |
--|                    p_itemtype_out  OUT NOCOPY VARCHAR2      |
--|                    p_itemkey_out   OUT NOCOPY VARCHAR2      |
--|
--|                                 |
--| Returns          : NA                                               |
--|=====================================================================|

   PROCEDURE get_item_info(p_documentId_in IN VARCHAR2
                          ,p_itemtype_out  OUT NOCOPY VARCHAR2
                          ,p_itemkey_out   OUT NOCOPY VARCHAR2)
   IS
      l_firstcolon  PLS_INTEGER;
   BEGIN
      l_firstcolon  := instr(p_documentId_in,':',1,1);

      p_itemtype_out := substr(p_documentId_in,1,l_firstcolon - 1);
      p_itemkey_out := substr(p_documentId_in,l_firstcolon + 1,length(p_documentId_in) - 2);

      diagn_msg('p_itemtype_out : '||p_itemtype_out);
      diagn_msg('p_itemkey_out : '||p_itemkey_out);
      diagn_msg('p_documentId_in : '||p_documentId_in);

   END get_item_info;

--|======================================================================|
--| Name             : get_gl_je_approve_msg                 |
--|                                      |
--| Description      : This procedure builds the journal approval message |
--|                    notification                  |
--|                                      |
--| Parameters       : p_documentId_in     IN             VARCHAR2   |
--|                    p_display_type_in   IN             VARCHAR2   |
--|                    p_document_out      IN OUT  NOCOPY VARCHAR2   |
--|                    p_document_type_out IN OUT  NOCOPY VARCHAR2   |
--|                                      |
--| Returns          : NA                                                |
--|======================================================================|

   PROCEDURE get_gl_je_approve_msg(p_documentId_in     IN             VARCHAR2
                                    ,p_document_type_in  IN             VARCHAR2
                                    ,p_document_out      IN OUT  NOCOPY VARCHAR2
                                    ,p_document_type_out IN OUT  NOCOPY VARCHAR2)
   IS
   l_item_type        wf_items.item_type%TYPE;
   l_item_key         wf_items.item_key%TYPE;

   l_batch_id         gl_je_batches.je_batch_id%TYPE;
   l_currency_code    fnd_currencies.CURRENCY_CODE%TYPE;
   l_period_name      VARCHAR2(30);
   l_batch_total      VARCHAR2(30);
   l_forwarded_from   per_people_f.full_name%TYPE;
   l_preparer         per_people_f.full_name%TYPE;
   l_document         VARCHAR2(32000) := '';


   BEGIN

    get_item_info(p_documentId_in,l_item_type,l_item_key);

      diagn_msg('p_documentId_in : '||p_documentId_in);
      diagn_msg('l_item_type : '||l_item_type);
      diagn_msg('l_item_key : '||l_item_key);

      l_batch_id := wf_engine.GetItemAttrNumber(itemtype   => l_item_type
                                               ,itemkey    => l_item_key
                                               ,aname      => 'BATCH_ID');

      l_currency_code := wf_engine.GetItemAttrText(itemtype   => l_item_type
                                                  ,itemkey    => l_item_key
                                                  ,aname      => 'FUNC_CURRENCY');

      l_period_name := wf_engine.GetItemAttrText(itemtype   => l_item_type
                                                ,itemkey    => l_item_key
                                                ,aname      => 'PERIOD_NAME');

      l_batch_total := wf_engine.GetItemAttrText(itemtype   => l_item_type
                                                ,itemkey    => l_item_key
                                                ,aname      => 'BATCH_TOTAL');

      l_forwarded_from := wf_engine.GetItemAttrText(itemtype   => l_item_type
                                                   ,itemkey    => l_item_key
                                                   ,aname      => 'FORWARD_FROM_DISPLAY_NAME');

      l_preparer := wf_engine.GetItemAttrText(itemtype   => l_item_type
                                             ,itemkey    => l_item_key
                                             ,aname      => 'PREPARER_DISPLAY_NAME');



      g_jour_line_allowed_length := 32000;
    get_je_lines_details_link(p_documentId_in,l_document,p_document_type_out);
    p_document_out := l_document||fnd_global.newline;

    diagn_msg('p_document_out : '||p_document_out);

   END get_gl_je_approve_msg;

--|=====================================================================|
--| Name             : get_je_lines_details_link            |
--|                                     |
--| Description      : This procedure builds the journal line details   |
--|                    for the notification             |
--|                                     |
--| Parameters       : p_documentId_in     IN             VARCHAR2  |
--|                    p_display_type_in   IN             VARCHAR2  |
--|                    p_document_out      IN OUT  NOCOPY VARCHAR2  |
--|                    p_document_type_out IN OUT  NOCOPY VARCHAR2  |
--|                                     |
--| Returns          : NA                                               |
--|=====================================================================|

   PROCEDURE get_je_lines_details_link(p_documentId_in     IN             VARCHAR2
                                        ,p_document_out      IN OUT NOCOPY  VARCHAR2
                                        ,p_document_type_out IN OUT NOCOPY  VARCHAR2)
   IS

   l_item_type           wf_items.item_type%TYPE;
   l_item_key            wf_items.item_key%TYPE;
   l_batch_id            gl_je_batches.je_batch_id%TYPE;
   l_document            VARCHAR2(32000) := '';
   l_document_pre_lmt    VARCHAR2(4000) := '';
   l_document_post_lmt   VARCHAR2(4000) := '';
   l_document_Summary    VARCHAR2(32000) := '';
   l_jour_line_msg1      VARCHAR2(2000) := '';
   l_jour_line_msg2      VARCHAR2(1200) := '';
   l_newline             VARCHAR2(1) := fnd_global.newline;
   l_notif_exceed_msg    VARCHAR2(2000) := '';

   CURSOR l_get_func_currency_cur(s_batch_id NUMBER)
   IS
   SELECT   GLL.currency_code
   FROM     gl_je_headers GLH
           ,gl_ledgers GLL
           ,gl_je_batches GLJB
   WHERE    GLJB.je_batch_id = s_batch_id
   AND      GLL.ledger_id = GLH.ledger_id
   AND      GLJB.je_batch_id = GLH.je_batch_id
   GROUP BY GLL.currency_code;

  CURSOR l_notif_lines_exceed_cur
  IS
  SELECT MESSAGE_TEXT
  FROM fnd_new_messages
  WHERE message_name= 'GL_AME_NOTIF_LINES_EXCEED_MSG'
  AND LANGUAGE_CODE =  userenv ('LANG') ;

   l_func_currency   VARCHAR2(100);
   l_query varchar2(4000);

   TYPE l_attribute_query_rectype
   IS
   RECORD(query_string  ame_attribute_usages.query_string%type
         ,string_value  ame_string_values.string_value%type);

   TYPE l_gl_line_rectype
   IS
   RECORD(je_line_num gl_je_lines.je_line_num%TYPE
         ,concatenated_segments gl_code_combinations_kfv.concatenated_segments%TYPE
         ,accounted_dr gl_je_lines.accounted_dr%TYPE
         ,journal_name gl_je_headers.name%TYPE
         ,account_description varchar2(31)
         ,ledger_name GL_LEDGERS.name%type
         ,accounted_cr gl_je_lines.accounted_dr%TYPE
         ,description  gl_je_lines.description%TYPE
         ,stat_amount  gl_je_lines.stat_amount%TYPE
         ,code_combination_id gl_je_lines.code_combination_id%TYPE);

   TYPE l_gl_lines_tabtype IS TABLE OF l_gl_line_rectype INDEX BY binary_integer;
   TYPE l_attr_query_tabtype IS TABLE OF l_attribute_query_rectype INDEX BY BINARY_INTEGER;

   l_gl_line_rec     l_gl_lines_tabtype;

   l_attr_query_rec  l_attr_query_tabtype;

   l_no_lines           number;
   CURSOR l_get_approver_group_cur(s_approval_group_id NUMBER)
   IS
   SELECT AAG.name
   FROM   ame_approval_groups AAG
   WHERE  AAG.approval_group_id = s_approval_group_id
   GROUP BY AAG.name;

    -- ninecon
    l_periodo varchar2(100);
    l_valor varchar2(100);
	l_formatado varchar2(100);

   BEGIN

      get_item_info(p_documentId_in,l_item_type,l_item_key);
      l_batch_id := wf_engine.GetItemAttrNumber(itemtype   => l_item_type
                                               ,itemkey    => l_item_key
                                               ,aname      => 'BATCH_ID');

      OPEN l_get_func_currency_cur(l_batch_id);
      FETCH l_get_func_currency_cur INTO l_func_currency;
      CLOSE l_get_func_currency_cur;
         diagn_msg('g_jour_line_allowed_length : '||g_jour_line_allowed_length);
         l_document := l_document || l_newline || l_newline || '<!-- JOUR_LINES_DETAILS -->'|| l_newline || l_newline || '<P>';

         l_document_pre_lmt := l_document;
         l_document := null;

         g_jour_line_allowed_length := g_jour_line_allowed_length - nvl(lengthb(l_document_pre_lmt),0);
         
         -- ninecon
         SELECT period_name , running_total_dr into l_periodo, l_valor
         FROM gl_je_headers 
         where je_batch_id = l_batch_id;
         
         l_document := l_document || l_newline || '<table width="25%" style="font-family:Tahoma" style="font-size:9pt;" SUMMARY="Notification"><tbody> <tr class="x1r x4j"> <td><strong>Periodo</strong></td> <td><strong>Valor total do lote</strong></td> </tr> <tr class="x1l x4x" style="text-align:left"> <td>';
          l_document := l_document ||l_periodo;
         l_document := l_document || '</td><td>';
		 
		 l_formatado := '';
		 begin
			l_formatado := TO_CHAR(replace(l_valor,'.',','),'L999G999G999G999G999G999G999G999G999G999D99',  'NLS_NUMERIC_CHARACTERS = '',.''  NLS_CURRENCY = '' '' ');
         exception when others then
			l_formatado := TO_CHAR(l_valor,'L999G999G999G999G999G999G999G999G999G999D99',  'NLS_NUMERIC_CHARACTERS = '',.''  NLS_CURRENCY = '' '' ');
		 end;
		 
		 l_document := l_document || l_formatado;
		 l_document := l_document || '</td> </tr>  </tbody> </table>'|| l_newline;
          
         
         -- ninecon
        

         l_document := l_document || '<BR> <TABLE width="100%" style="font-family:Tahoma" style="font-size:9pt;" SUMMARY="Notification">' || l_newline;
         l_document := l_document || '<TR>'|| l_newline;

         l_jour_line_msg1 := '<TD class=instructiontext style="font-size:9pt;"> <B>'||'The Journal lines that require your approval are summarized below.'||'</B>';

         l_document := l_document || l_jour_line_msg1 || l_newline ;
         l_document := l_document || '</TD></TR>' || l_newline;
         l_document := l_document || '</TABLE>' || l_newline;
         l_jour_line_msg1 := l_document;

         l_document     := null;
         g_jour_line_allowed_length  := g_jour_line_allowed_length  - nvl(lengthb(l_jour_line_msg1),0);


         l_document := l_document || '<TABLE width="100%" border="1" cellspacing="0" cellpadding="1" class="x1h" summary="Notification Details"> '|| l_newline;
         l_document := l_document || '<TR class="x1r x4j"> '||l_newline;
         l_document := l_document || '<TH width=20% id="journal_name"><span class="x24">' ||
                      'Journal Name'|| '</span></TH>' || l_newline;
        l_document := l_document || '<TH width=15% id="ledger_name"><span class="x24">' ||
                      'Ledger Name'|| '</span></TH>' || l_newline;
         l_document := l_document || '<TH width=3% id="lineNum_1"><span class="x24">' ||
                      'Line'|| '</span></TH>' || l_newline;

         l_document := l_document || '<TH width=10% id="account_1"><span class="x24">' ||
                      'Account' || '</span></TH>' || l_newline;

          l_document := l_document || '<TH width=10% id="account_description"><span class="x24">' ||
                      'Account Description'|| '</span></TH>' || l_newline;


         l_document := l_document || '<TH width=7% id="debit_1"><span class="x24">' ||
                      'Debit' ||'(' ||l_func_currency || ')' ||'</span></TH>' || l_newline;

         l_document := l_document || '<TH width=7% id="credit_1"><span class="x24">' ||
                      'Credit' ||'(' ||l_func_currency || ')' ||'</span></TH>' || l_newline;

         l_document := l_document || '<TH width=28% id="description_1"><span class="x24">' ||
                      'Description'|| '</span></TH>' || l_newline;
         l_document := l_document || '</TR>' || l_newline;

         l_query := NULL;
         l_query :=  'SELECT  GJL.je_line_num '
                        ||' ,apps.fnd_flex_ext.get_segs(
                            ''SQLGL'',
                            ''GL#'',
                            gcc.chart_of_accounts_id,
                            gcc.Code_combination_id
                            )concatenated_segments  '
                        ||' ,GJL.accounted_dr '
                        ||' ,GJH.name '
                        ||' ,substrb(gl_ame_je_wf_pkg.get_accounting_flex_desc(''GL_ACCOUNT'',GJH.je_header_id,GJL.je_line_num),1,30) naturalaccountdesc '
                        ||' ,GL.name '
                        ||' ,GJL.accounted_cr '
                        ||' ,GJL.description '
                        ||' ,GJL.stat_amount'
                        ||' ,GJL.code_combination_id '
                        ||' FROM gl_je_headers GJH,gl_je_lines GJL, gl_code_combinations GCC, GL_LEDGERS GL '
                        ||' WHERE GJH.je_batch_id = :transaction_id '
                        ||' AND   GJH.je_header_id = GJL.je_header_id '
                        ||' AND   GJL.code_combination_id = GCC.code_combination_id'
                        ||' AND   GL.Ledger_id = GJH.Ledger_id'
                        ||' ORDER BY GJH.name, GJL.je_line_num ';
        diagn_msg('l_query : '||l_query);
       EXECUTE IMMEDIATE l_query BULK COLLECT INTO l_gl_line_rec USING l_batch_id;

       l_no_lines := l_gl_line_rec.count;
      diagn_msg('g_jour_line_allowed_length after loop : '||g_jour_line_allowed_length);

      IF(fnd_profile.value('GL_APPROVER_NOTIF_LINES')<l_gl_line_rec.count)    THEN
          l_no_lines := fnd_profile.value('GL_APPROVER_NOTIF_LINES');
      END IF;

       FOR i in 1.. l_no_lines
       LOOP
             l_document := l_document || '<TR class="x1l x4x">' || l_newline;

             l_document := l_document || '<TD width=20% headers="journal_name">' ||
                          nvl(l_gl_line_rec(i).journal_name,'&'||'nbsp') || '</TD>' || l_newline;

            l_document := l_document || '<TD width=15% headers="ledger_name">' ||
                          nvl(l_gl_line_rec(i).ledger_name,'&'||'nbsp') || '</TD>' || l_newline;

             l_document := l_document || '<TD width=3% headers="lineNum_1">' ||
                          nvl(to_char(l_gl_line_rec(i).je_line_num),'&'||'nbsp') || '</TD>' || l_newline;

             l_document := l_document || '<TD width=10% headers="account_1">' ||
                          nvl(l_gl_line_rec(i).concatenated_segments, '&'||'nbsp') || '</TD>' || l_newline;

            l_document := l_document || '<TD width=10% headers="account_1">' ||
                          nvl(l_gl_line_rec(i).account_description, '&'||'nbsp') || '</TD>' || l_newline;

             l_document := l_document || '<TD width=7% headers="debit_1">' ||
                          nvl(TO_CHAR(l_gl_line_rec(i).accounted_dr, FND_CURRENCY.GET_FORMAT_MASK(l_func_currency, 30)),'&'||'nbsp') || '</TD>' || l_newline;

             l_document := l_document || '<TD width=7% headers="credit_1">' ||
                          nvl(TO_CHAR(l_gl_line_rec(i).accounted_cr, FND_CURRENCY.GET_FORMAT_MASK(l_func_currency, 30)),'&'||'nbsp') || '</TD>' || l_newline;

             l_document := l_document || '<TD width=28% headers="descr_1">' ||
                          nvl(l_gl_line_rec(i).description,'&'||'nbsp') || '</TD>' || l_newline;

             l_document := l_document || '</TR>' || l_newline;

             g_jour_line_allowed_length := g_jour_line_allowed_length - nvl(lengthb(l_document),0);

             IF(g_jour_line_allowed_length<1000) THEN
              EXIT;
            END IF;

              diagn_msg('g_jour_line_allowed_length after loop : '||g_jour_line_allowed_length);
       END LOOP;
       diagn_msg('g_jour_line_allowed_length after loop : '||g_jour_line_allowed_length);
    l_document_summary := l_document_summary ||l_document|| '</TABLE>';

    l_document     := null;

     IF(fnd_profile.value('GL_APPROVER_NOTIF_LINES')<l_gl_line_rec.count or g_jour_line_allowed_length<1000)    THEN

         l_document := l_document || '<BR> <TABLE width="100%" style="font-family:Tahoma" style="font-size:9pt;" SUMMARY="Notification">' || l_newline;
         l_document := l_document || '<TR>'|| l_newline;

         OPEN l_notif_lines_exceed_cur;
         FETCH l_notif_lines_exceed_cur INTO l_notif_exceed_msg;
         CLOSE l_notif_lines_exceed_cur;

         l_jour_line_msg2 := '<TD class=instructiontext style="font-size:9pt;"> <B>'||l_notif_exceed_msg||'</B>';

         l_document := l_document || l_jour_line_msg2 || l_newline ;
         l_document := l_document || '</TD></TR>' || l_newline;
         l_document := l_document || '</TABLE><BR> ' || l_newline;
         l_jour_line_msg2 := l_document;
         l_document     := null;
         g_jour_line_allowed_length  := g_jour_line_allowed_length  - nvl(lengthb(l_jour_line_msg2),0);
      END IF;

      p_document_out      := l_document_pre_lmt||l_jour_line_msg1||l_document_Summary||l_jour_line_msg2;
      p_document_type_out := 'text/html';
      diagn_msg('p_document_out : '||p_document_out);
      diagn_msg('g_jour_line_allowed_length after creation of the notification details : '||g_jour_line_allowed_length);

   END get_je_lines_details_link;

--|=======================================================================|
--| Name             : je_rejection_notification              |
--|                                       |
--| Description      : This procedure sends rejection notification for all|
--|                    prior approvers and preparer of journal batch      |
--|                                       |
--| Parameters       : p_itemtype_in        IN         VARCHAR2       |
--|                    p_itemkey_in         IN         VARCHAR2       |
--|                    p_actid_in           IN         NUMBER         |
--|                    p_funcmode_in        IN         VARCHAR2       |
--|                    p_resultout          OUT NOCOPY VARCHAR2       |
--|                                       |
--| Returns          : NA                                                 |
--|=======================================================================|

   PROCEDURE je_rejection_notification  (p_itemtype_in        IN         VARCHAR2
                                        ,p_itemkey_in         IN         VARCHAR2
                                        ,p_actid_in           IN         NUMBER
                                        ,p_funcmode_in        IN         VARCHAR2
                                        ,p_resultout          OUT NOCOPY VARCHAR2)

   IS
   CURSOR l_list_of_approvers_cur(s_batch_id IN NUMBER)
   IS
   SELECT DISTINCT wf_approver_name
   FROM   gl_wf_action_history
   WHERE  action_code = 'APPROVE'
   AND    object_id = s_batch_id
   AND    wf_item_type = p_itemtype_in
   AND    wf_item_key = p_itemkey_in;

   l_list_of_approvers_rec l_list_of_approvers_cur%ROWTYPE;
   l_batch_id NUMBER;
   i number := 1;

   BEGIN
   diagn_msg('je_rejection_notification Procedure Begins');
      l_batch_id := wf_engine.GetItemAttrNumber(itemtype   => p_itemtype_in
                                               ,itemkey    => p_itemkey_in
                                               ,aname      => 'BATCH_ID');


      IF g_index_of_approver = 0 THEN
         FOR l_list_of_approvers_rec IN l_list_of_approvers_cur(l_batch_id)
         LOOP
            g_list_of_approvers(i) :=  l_list_of_approvers_rec.wf_approver_name;
            i := i + 1;
         END LOOP;

         g_list_of_approvers(i) := wf_engine.GetItemAttrText(itemtype         => p_itemtype_in
                                                            ,itemkey          => p_itemkey_in
                                                            ,aname            => 'PREPARER_NAME'
                                                            ,ignore_notfound  => TRUE);

         g_index_of_approver := g_index_of_approver + 1;

      END IF;
      IF g_index_of_approver > g_list_of_approvers.count THEN
         g_index_of_approver := 0;
         g_list_of_approvers.delete;
         p_resultout:='COMPLETE:'||'F';
         diagn_msg('p_resultout_F : '||p_resultout);
         RETURN;
      END IF;

      wf_engine.SetItemAttrText(itemtype => p_itemtype_in
                               ,itemkey  => p_itemkey_in
                               ,aname    => 'APPROVER_NAME'
                               ,avalue   => g_list_of_approvers(g_index_of_approver));

      g_index_of_approver := g_index_of_approver + 1;

      p_resultout:='COMPLETE:'||'T';
      diagn_msg('p_resultout_T : '||p_resultout);
       diagn_msg('je_rejection_notification Procedure ENDS');
   END je_rejection_notification;

--|==============================================================================|
--| Name             : je_no_approvers                       |
--|                                          |
--| Description      : Procedure to check if there were any approvers identified |
--|                    by AME.                           |
--|                                          |
--| Parameters       : p_itemtype_in        IN         VARCHAR2          |
--|                    p_itemkey_in         IN         VARCHAR2          |
--|                    p_actid_in           IN         NUMBER            |
--|                    p_funcmode_in        IN         VARCHAR2          |
--|                    p_resultout          OUT NOCOPY VARCHAR2          |
--|                                          |
--| Returns          : NA                                                    |
--|==============================================================================|

   PROCEDURE je_no_approvers(p_itemtype_in        IN         VARCHAR2
                            ,p_itemkey_in         IN         VARCHAR2
                            ,p_actid_in           IN         NUMBER
                            ,p_funcmode_in        IN         VARCHAR2
                            ,p_resultout          OUT NOCOPY VARCHAR2)
   IS

      l_batch_id NUMBER;
      l_record_count NUMBER := 0;

   BEGIN
      diagn_msg('je_no_approvers Procedure Begins');
      l_batch_id := wf_engine.GetItemAttrNumber(itemtype   => p_itemtype_in
                                               ,itemkey    => p_itemkey_in
                                               ,aname      => 'BATCH_ID');

      SELECT count(*)
      INTO  l_record_count
      FROM  gl_wf_action_history
      WHERE object_id = l_batch_id
      AND   object_type_code = g_object_type_code
      AND   wf_item_type = p_itemtype_in
      AND   wf_item_key  = p_itemkey_in;

      p_resultout:='COMPLETE:'||'F';

      IF l_record_count = 0 THEN
         p_resultout:='COMPLETE:'||'T';
      ELSIF l_record_count > 0 THEN
         p_resultout:='COMPLETE:'||'F';
      ELSE
         p_resultout:='COMPLETE:'||'T';
      END IF;

      diagn_msg('je_no_approvers_p_resultout : '||p_resultout);

  diagn_msg('je_no_approvers Procedure ENDS');
   END je_no_approvers;

   --|==============================================================================|
--| Name             : je_revarsal_approval                          |
--|                                          |
--| Description      : Procedure to approve all the autoreversed journals |
--|                    by AME.                           |
--|                                          |
--| Parameters       : p_period_name_in        IN         VARCHAR2           |
--|                    p_ledger_id_in        IN         VARCHAR2             |
--|                                          |
--| Returns          : NA                                                    |
--|==============================================================================|

  PROCEDURE je_reversal_approval  (x_errbuf              OUT NOCOPY VARCHAR2
                                  ,x_retcode             OUT NOCOPY NUMBER
                                  ,p_ledger_id_in        IN       VARCHAR2
                                  ,p_period_name_in      IN       VARCHAR2)
  IS
    CURSOR l_journal_reversal_approve_cur
    IS
    SELECT a.name, a.je_header_id, b.je_batch_id, a.ledger_id,
           c.user_je_category_name, b.default_period_name, b.approval_status_code,
           d.name ledger_name
      FROM gl_je_headers_v a, gl_je_batches b, gl_je_categories c, gl_ledgers d
     WHERE a.NAME LIKE 'Reverses%'
       AND a.je_batch_id = b.je_batch_id
       AND b.approval_status_code <> 'A'
                                        --and  a.creation_date >= trunc(sysdate-1)
       AND a.je_category = c.je_category_name
       AND b.default_period_name =
              DECODE (p_period_name_in,
                      'ALL', b.default_period_name,
                      p_period_name_in
                     )
       AND a.ledger_id = d.ledger_id
       AND (a.ledger_id, c.user_je_category_name) IN (
              SELECT glledgerseo.ledger_id, gaov.user_je_category_name
                FROM gl_ledgers glledgerseo,
                     xla_acctg_methods_tl t,
                     fnd_languages_tl fnd,
                     fnd_id_flex_structures_vl coa,
                     gl_transaction_calendar gltcv,
                     gl_suspense_accounts sus,
                     gl_period_types gpt,
                     xla_lookups xl,
                     gl_autorev_criteria_sets autorev,
                     gl_autoreverse_options_v gaov
               WHERE glledgerseo.sla_accounting_method_type = t.accounting_method_type_code(+)
                 AND glledgerseo.sla_accounting_method_code = t.accounting_method_code(+)
                 AND NVL (t.LANGUAGE, USERENV ('LANG')) = USERENV ('LANG')
                 AND glledgerseo.sla_description_language = fnd.language_code(+)
                 AND fnd.source_lang(+) = USERENV ('LANG')
                 AND glledgerseo.chart_of_accounts_id = coa.id_flex_num
                 AND coa.application_id = 101
                 AND coa.id_flex_code = 'GL#'
                 AND coa.enabled_flag = 'Y'
                 AND glledgerseo.transaction_calendar_id = gltcv.transaction_calendar_id(+)
                 AND sus.ledger_id(+) = glledgerseo.ledger_id
                 AND sus.je_source_name(+) = 'Other'
                 AND sus.je_category_name(+) = 'Other'
                 AND gpt.period_type = glledgerseo.accounted_period_type
                 AND xl.lookup_type(+) = 'XLA_OWNER_TYPE'
                 AND glledgerseo.sla_accounting_method_type = xl.lookup_code(+)
                 AND glledgerseo.criteria_set_id = autorev.criteria_set_id(+)
                 AND gaov.criteria_set_id = autorev.criteria_set_id
                 AND gaov.autoreverse_flag = 'Y'
                 AND glledgerseo.ledger_id = p_ledger_id_in);


    CURSOR l_ledger_name_cur
    IS
    SELECT
      d.name ledger_name
      FROM gl_ledgers d
      WHERE d.ledger_id = p_ledger_id_in;

          l_ledger_name VARCHAR2(100);
          l_journal_reversal_approve_rec l_journal_reversal_approve_cur%ROWTYPE;
          l_empty NUMBER := 1;
          l_journal_out_lines VARCHAR2(1000);
          l_journal_header VARCHAR2(1000);
          BEGIN
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,LPAD(' ',50,' ')||RPAD('AutoReverse Journal Approval Report',70,' ')||'DATE : '||RPAD(to_char(sysdate,'DD-MON-YYYY'),30,' '));

         OPEN l_ledger_name_cur;
         FETCH l_ledger_name_cur INTO l_ledger_name;
         CLOSE l_ledger_name_cur;

        FND_FILE.PUT_LINE(FND_FILE.OUTPUT,LPAD(' ',10,' ')||'LEDGER : '||l_ledger_name);
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT,LPAD(' ',10,' ')||'PERIOD : '||p_period_name_in);
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
        l_journal_header := RPAD('JOURNAL NAME',70,' ')||
                            '  '||
                            RPAD('PERIOD',15,' ')||
                            '  '||'APPROVED STATUS';
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,l_journal_header);
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,RPAD('-',70,'-')||'  '||RPAD('-',15,'-')||'  '||RPAD('-',40,'-'));

          FOR l_journal_reversal_approve_rec IN l_journal_reversal_approve_cur
          LOOP
            UPDATE GL_JE_BATCHES
            SET    approval_status_code = 'A'
            WHERE  je_batch_id =l_journal_reversal_approve_rec.je_batch_id ;
            l_empty:=0;
            l_journal_out_lines := RPAD(l_journal_reversal_approve_rec.name,70,' ')||
                                   '  '||
                                   RPAD(l_journal_reversal_approve_rec.default_period_name,15,' ')||
                                   '  '||'APPROVED';
            FND_FILE.PUT_LINE(FND_FILE.OUTPUT,l_journal_out_lines);

         END LOOP;
         IF(l_empty = 1) then
            FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
            FND_FILE.PUT_LINE(FND_FILE.OUTPUT,LPAD('-',57,'-')||RPAD('NO RECORDS FOUND',72,'-'));
          END IF;
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
          FND_FILE.PUT_LINE(FND_FILE.OUTPUT,LPAD(' ',65,' ')||'*****END OF REPORT*****');
  EXCEPTION
    WHEN OTHERS THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG,SQLCODE||'-'||SQLERRM);
  END je_reversal_approval;

END GL_WF_JE_NOTIFICATION_PKG;
/