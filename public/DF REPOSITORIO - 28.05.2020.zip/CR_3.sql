UPDATE apps.XX_ACO_CTGS_B x1
   SET  x1.LAST_UPDATE_DATE = sysdate,
        x1.LAST_UPDATED_BY = 2070,
	x1.DESTINO_ID =
          (SELECT VENDOR_ID
             FROM apps.AP_SUPPLIERS
            WHERE TRIM (CONCAT (NUM_1099, global_attribute12)) = TO_CHAR(x1.CUIT_DESTINO))
 WHERE  x1.DESTINO_ID IS NULL 
       AND x1.CUIT_DESTINO IS NOT NULL
       AND EXISTS
              (SELECT 1
                 FROM apps.AP_SUPPLIERS
                WHERE TRIM (CONCAT (NUM_1099, global_attribute12)) = TO_CHAR(x1.CUIT_DESTINO))
       AND x1.FECHA_EMISION > TO_DATE ('01-01-2020', 'DD-MM-YYYY')
--1500