UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID       =  442981,
        PESO_RETIRO                = 29560 ,
        LAST_UPDATE_DATE = sysdate,
        LAST_UPDATED_BY   = 2070
WHERE LIQUIDACION_ID = 12275       
--1

UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID       = 442982,
        PESO_RETIRO                = 29620,
        LAST_UPDATE_DATE = sysdate,
        LAST_UPDATED_BY    = 2070
WHERE LIQUIDACION_ID = 12274       
--1 