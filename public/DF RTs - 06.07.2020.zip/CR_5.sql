
update  apps.csi_item_instances a
set a.last_vld_organization_id = (select b.current_organization_id
                       from apps.MTL_EAM_ASSET_NUMBERS_ALL_V b
                       where b.maintenance_object_id = a.instance_id
                       and b.instance_number = a.instance_number
)
where exists (select 1
                       from apps.MTL_EAM_ASSET_NUMBERS_ALL_V b
                       where 1=1
                       and b.instance_number = a.instance_number
                       and b.maintenance_object_id = a.instance_id
                       and  b.current_organization_id !=  a.last_vld_organization_id )
and a.instance_number in (
  'NEI-010'
, 'NEI-011'
, 'NEI-012'
, 'NEI-013'
, 'NEI-014'
, 'NEI-015'
, 'NEI-016'
, 'NEI-030'
, 'NEI-077'
, 'REP-002'
)