UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID        = 440019,
         PESO_RETIRO                = 31040,
        LAST_UPDATE_DATE = sysdate,
        LAST_UPDATED_BY    = 2070
WHERE LIQUIDACION_ID = 12266
--1

UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID        = 442619,
         PESO_RETIRO                = 28320,
        LAST_UPDATE_DATE = sysdate,
        LAST_UPDATED_BY    = 2070
WHERE LIQUIDACION_ID = 12226                                              
--1