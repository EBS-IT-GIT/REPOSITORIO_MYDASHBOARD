WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE XXSTN_FA_DEPRE_REPORT_GRB_PKG as
-- +=================================================================+
-- |               Copyright (c) 2017 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_FA_DEPRE_REPORT_GRB_PKS.sql                               |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Projeto Stone Fenix                                           |
-- |                                                                 |
-- | CREATED BY   RODRIGO PERASSO 14/11/2017                         |
-- |                                                                 |
-- | UPDATED BY   RODRIGO PERASSO 14/11/2017                         |
-- |                                                                 |
-- |              Fernando Pavao - 3S               (14/08/2018)     |
-- |     Melhorias relatorio de depreciacao FA                       |
-- |                                                                 |
-- |              Fernando Pavao - 3S    30/10/2018                  |
-- |     Inclusao de condicao DATE_INEFFECTIVE na query principal    |
-- |                                                                 |
-- |              Theodoro Ramos - 3S    29/11/2018                  |
-- |     Utilização de tabelas temporárias e processos core.      |
-- |                                                                 |
-- |              ROGERIO FARTO (NINECON) - 01/11/2019               |
-- |              SR-361093 - NSD306980                              |
-- |     Inclus�o de coluna CANAL (atribuicao ativo)                 |
-- |                                                                 |
-- |              ROGERIO FARTO (NINECON) - 25/06/2020               |
-- |              SR-513923 - NSD-320834                             |
-- |     Copia do objeto original XXSTN_FA_DEPRE_REPORT_PKG          |
-- |     Inclusao de tratamento para recuperar informa��es de todos  |
-- |     os livros, desconsiderando o livro STONE_CORP               |
-- +=================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;
  --
  TYPE RECORD_TYPE IS RECORD(
    CONTA_ATIVO         VARCHAR2(40),
    DESC_CONTA_ATIVO    VARCHAR2(250),
    CONTA_DEPR_ACUM     VARCHAR2(240),
    CONTA_DESP_DEPR     VARCHAR2(240),
    FA_CUSTO            NUMBER,
    GL_CUSTO            NUMBER,
    DEPRECIACAO_MES     NUMBER,
    DEPRECIACAO_ANO     NUMBER,
    FA_DEPRECIACAO_ACUM NUMBER,
    GL_DEPRECIACAO_ACUM NUMBER,
    VALOR_RESIDUAL      NUMBER);
  --
  TYPE l_Table IS TABLE OF RECORD_TYPE INDEX BY BINARY_INTEGER;
  --
  FUNCTION generate_xml_tag(p_data     IN VARCHAR2,
                            p_tag      IN VARCHAR2,
                            p_tag_type IN NUMBER DEFAULT gn_xml_tag_full)
    RETURN VARCHAR2;

  PROCEDURE print_xml_tag(p_data     IN VARCHAR2,
                          p_tag      IN VARCHAR2,
                          p_tag_type IN NUMBER DEFAULT gn_xml_tag_full,
                          p_level    IN NUMBER DEFAULT 0);

  FUNCTION geog_ret_str(p_str in VARCHAR2,
                        p_pos in VARCHAR2,
                        p_del in VARCHAR2) RETURN VARCHAR2;

  function special_character(p_texto IN VARCHAR2) return VARCHAR2;
  --
  procedure update_output(ERRBUF       OUT VARCHAR2,
                          RETCODE      OUT NUMBER,
                          p_file_name  in varchar2,
                          p_REQUEST_ID in number);
  --
  procedure main(ERRBUF        OUT VARCHAR2,
                 RETCODE       OUT NUMBER,
                 P_FA_BOOK     IN VARCHAR2,
                 P_PERIOD_NAME IN VARCHAR2,
                 P_CATEGORY    IN NUMBER);
  --
END XXSTN_FA_DEPRE_REPORT_GRB_PKG;
--Indicativo de Final de Arquivo. Não deve ser removido.
/

EXIT; 