DECLARE
  l_program_short_name  VARCHAR2 (200) := 'XXPOAGRONOMOOC';
  l_program_application VARCHAR2 (200) := 'Business Online';
  l_request_group       VARCHAR2 (200) := 'XX PO All Reports Corp';
  l_group_application   VARCHAR2 (200) := 'Business Online';
  l_check               VARCHAR2 (1);
  
BEGIN
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 );  
  COMMIT;
  
  BEGIN
  SELECT 'Y'
  INTO   l_check
  FROM   fnd_request_groups frg
        ,fnd_request_group_units frgu
        ,fnd_concurrent_programs fcp
  WHERE  frg.request_group_id        = frgu.request_group_id
  AND    frg.application_id          = frgu.application_id
  AND    frgu.request_unit_id        = fcp.concurrent_program_id
  AND    frgu.unit_application_id    = fcp.application_id
  AND    frg.request_group_name      = l_request_group
  AND    fcp.concurrent_program_name = l_program_short_name;
    
  dbms_output.put_line ('Finalización Exitosa');
  
  EXCEPTION
  WHEN no_data_found THEN
    dbms_output.put_line ('Error: '||sqlerrm);
  END;
END;