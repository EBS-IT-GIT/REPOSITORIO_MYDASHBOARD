UPDATE  apps.hz_parties hp
SET     status = 'A', last_update_date = sysdate, last_updated_by = 2070
WHERE  party_name like 'CARRILLO RUBEN BLAS';
--1 Registro