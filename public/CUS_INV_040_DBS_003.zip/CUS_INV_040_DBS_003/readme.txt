==============================================================================
CUSINV040_003 : Guia de Recolhimento de Almoxarifado
==============================================================================

Atualiza��o - CUSINV040_003
Produto     - XX Customizaciones
Data        - 06/01/2020 12:00:00
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSINV040_003

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

Ap�s a aplica��o do patch � necess�rio realizar um Bounce no OACORE do EBS.

Tarefas finais
==============================================================================
N/A

N�o se Aplica

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: JSAECUSINV040.zip
