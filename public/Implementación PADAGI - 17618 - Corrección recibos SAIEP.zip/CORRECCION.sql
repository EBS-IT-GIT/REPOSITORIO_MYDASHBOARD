UPDATE ar_cash_receipts_all acr
SET    cust_site_use_id = 259789, last_update_date = sysdate, last_updated_by = 2070
WHERE  cash_receipt_id IN (10822865,10822870,10822869,10822868,10822866,10822867,10822864);
--7 Registros