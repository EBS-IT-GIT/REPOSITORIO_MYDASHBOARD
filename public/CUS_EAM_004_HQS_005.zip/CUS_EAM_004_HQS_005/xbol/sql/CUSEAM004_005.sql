WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

-- $Header: CUSEAM004_005.sql 120.3 29/04/2020 12:00:00 appldev ship $
-- +==================================================================+
-- |                      SANTO ANTONIO ENERGIA                       |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   CUSEAM004_005.sql                                              |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUS004                                                         |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   Script para Ajustar base de dados de Solicita��es e CA         |
-- |    CASO 1 : Data de 19/10/2019 periodo de 21:00 at� 23:59        |
-- |    CASO 2 : Descri��o de Ativos com quebra de Linha chr(10)      |
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan de Castro Gomes      17/04/2020                          |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--
DECLARE
BEGIN
  -- CASO 1 
  BEGIN 
    UPDATE wip_eam_work_requests
    SET creation_date = to_date(to_char(creation_date , 'DD/MM/RRRR') || ' 20:00:00' ,'DD/MM/RRRR HH24:MI:SS')
    WHERE (creation_date BETWEEN TO_DATE('14/10/2017 21:00:00','DD/MM/RRRR HH24:MI:SS') AND TO_DATE('14/10/2017 23:59:59','DD/MM/RRRR HH24:MI:SS'))
       OR (creation_date BETWEEN TO_DATE('20/10/2018 21:00:00','DD/MM/RRRR HH24:MI:SS') AND TO_DATE('20/10/2018 23:59:59','DD/MM/RRRR HH24:MI:SS'))
       OR (creation_date BETWEEN TO_DATE('16/02/2019 21:00:00','DD/MM/RRRR HH24:MI:SS') AND TO_DATE('16/02/2019 23:59:59','DD/MM/RRRR HH24:MI:SS'))
       OR (creation_date BETWEEN to_date('19/10/2019 21:00:00','DD/MM/RRRR HH24:MI:SS') AND to_date('19/10/2019 23:59:59','DD/MM/RRRR HH24:MI:SS')) ;
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;   
  COMMIT;

  -- CASO 2
  BEGIN 
    UPDATE csi_item_instances
       SET instance_description = REPLACE(REPLACE(instance_description,CHR(10),''),CHR(13),'')
     WHERE (instance_description LIKE '%' || CHR(10) || '%' OR instance_description LIKE '%' || CHR(13) || '%');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;   
  COMMIT;
 
END;
/

WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
