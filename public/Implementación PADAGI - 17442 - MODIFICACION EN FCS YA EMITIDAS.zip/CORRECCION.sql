UPDATE apps.ra_customer_trx_all rct
SET    term_id = (SELECT term_id
                  FROM   apps.ra_terms
                  WHERE  name = 'Contado'), last_update_date = sysdate, last_updated_by = 2070
WHERE  trx_number IN ('E-0007-00000138', 'E-0007-00000139');
--2 Registros