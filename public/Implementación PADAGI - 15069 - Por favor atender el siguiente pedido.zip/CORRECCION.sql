UPDATE apps.hz_parties hp
SET    status = 'A'
WHERE  party_name = 'NUÑEZ JULIO SEBASTIAN';
--1 Registro