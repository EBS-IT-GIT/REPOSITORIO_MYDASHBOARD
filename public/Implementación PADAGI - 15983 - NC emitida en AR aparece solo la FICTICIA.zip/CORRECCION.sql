UPDATE apps.ra_customer_trx_all
SET    trx_date   = to_date('01-03-2020','DD-MM-RRRR')
WHERE  trx_number = 'A-0001-00000511'
AND    org_id     = 192
AND    trx_date LIKE to_date('28-02-2020','DD-MM-RRRR');
--1 Registro
