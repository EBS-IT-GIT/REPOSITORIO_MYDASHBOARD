WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
/* $Header: XXSTN_PO_REL_KPI_COMP_PKG.sql 120.0.12020000.3 2020/12/17 11:00:00 cbergama ship $ */
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_ITEMS_IPROC.sql                                           |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Concurrent para replicar itens para o iproc devido a bug      |
-- |                                                                 |
-- | CREATED BY   Cbergama    17/12/2020                             |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |   Atendimento ao chamado #SR-583409                             |
-- |       Chamado Oracle 3-24294106621                              |
-- +=================================================================+
create or replace procedure XXSTN_ITEMS_IPROC (errbuf   OUT VARCHAR2
                                             ,retcode  OUT NUMBER) IS


cursor orgs is
  select *
  from apps.hr_operating_units
  where 1 = 1
    and date_to is null;

CURSOR req_temp_lin (p_org_id varchar2) IS 
    SELECT sequence_num, 
            item_id, 
            item_description, 
            org_id, 
            ip_category_id ,
            express_name
            FROM PO_REQEXPRESS_LINES_ALL 
            WHERE 1 = 1
              --and express_name = l_EXPRESS_NAME 
              AND org_id = P_org_id; 

BEGIN 

--comment out, this is causing exception 
--po_moac_utils_pvt.set_org_context(l_org_id); 
for x in orgs loop
   --
        FOR var_req_temp_lin IN req_temp_lin (x.organization_id) LOOP 


        PO_ATTRIBUTE_VALUES_PVT.create_default_attributes ( 
                    p_doc_type              => 'REQ_TEMPLATE', 
                    p_po_line_id            => -2, 
                    p_req_template_name     => var_req_temp_lin.EXPRESS_NAME, 
                    p_req_template_line_num => var_req_temp_lin.sequence_num, 
                    p_ip_category_id        => var_req_temp_lin.ip_category_id, 
                    p_inventory_item_id     => var_req_temp_lin.item_id, 
                    p_org_id                => x.organization_id, 
                    p_description           => var_req_temp_lin.item_description 
        ); 

        COMMIT; 
        --
        PO_CATALOG_INDEX_PVT.rebuild_index(p_type => 'REQ_TEMPLATE', 
                                            p_reqexpress_name => var_req_temp_lin.EXPRESS_NAME, 
                                            p_org_id          => x.organization_id); 

        END LOOP; 
        --
        ICX_CAT_INTERMEDIA_INDEX_PVT.rebuild_index; 
        --
        end loop;

END; 
/

EXIT;