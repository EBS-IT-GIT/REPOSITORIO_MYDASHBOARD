  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_INV_NIVELES_DE_SERVICIO_PKG" IS

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    CR2462 - ASilva - Abril 2020 - Creación del reporte 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/****************************************************************************
 *                                                                          *
 * Name    : MAIN                                                           *
 * Purpose : Procedimiento principal que crea los niveles de servicios      *
 *           para la organización indicada y copiando desde otra            *
 *           organización mencionada                                        *
 ****************************************************************************/
  PROCEDURE MAIN( errbuf            OUT VARCHAR2
                , retcode           OUT VARCHAR2
                , p_org_id           IN NUMBER
                , p_org_base         IN NUMBER
                , p_org_destino      IN NUMBER
                );


END XX_INV_NIVELES_DE_SERVICIO_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_INV_NIVELES_DE_SERVICIO_PKG" IS

/****************************************************************************
 *                                                                          *
 * Name    : MAIN                                                           *
 * Purpose : Procedimiento principal que crea los niveles de servicios      *
 *           para la organización indicada y copiando desde otra            *
 *           organización mencionada                                        *
 ****************************************************************************/
  PROCEDURE MAIN( errbuf            OUT VARCHAR2
                , retcode           OUT VARCHAR2
                , p_org_id           IN NUMBER
                , p_org_base         IN NUMBER
                , p_org_destino      IN NUMBER
                )
  IS
  
    l_error_msg                 VARCHAR2(3000);
    eOrgIguales                 EXCEPTION;
    l_oper_unit                 VARCHAR2(240);
    l_org_base                  VARCHAR2(240);
    l_org_destino               VARCHAR2(240);
    l_contexto                  VARCHAR2(10);
    l_asig_org_a_transp_flag    VARCHAR2(1);
    eAsignaOrgsSeteo            EXCEPTION;
    eCarrierErrors              EXCEPTION;
    l_cant_proc                 NUMBER := 0;
    l_cant_ins                  NUMBER := 0;
    l_org_code                  VARCHAR2(5);         
    l_row_id                    ROWID;   
    l_org_carrier_service_id    NUMBER;     
    l_org_carrier_service_info  WSH_ORG_CARRIER_SERVICES_PKG.OCSRECTYPE;  
    l_carrier_info              WSH_ORG_CARRIER_SERVICES_PKG.CarRecType;
    l_CSM_info                  WSH_CARRIER_SHIP_METHODS_PKG.CSMRecType; 
    l_exists_csm                NUMBER;
    l_return_status             VARCHAR2(1) := 'S';
    l_csm_rowid                 ROWID;
    l_carrier_ship_method_id    NUMBER;
    l_procedure                 VARCHAR2(500);
    l_position                  NUMBER;      
    l_sqlerr                    VARCHAR2(1000);
    l_exception_msg             VARCHAR2(1000);     
    l_sql_code                  NUMBER;
    

    CURSOR c_carriers IS
      SELECT wcv.carrier_id
           , wcv.freight_code
           , wcv.carrier_name
           , wcs.carrier_service_id
           , wcs.ship_method_code
           , wcs.service_level service_level_code
           , wcs.enabled_flag
           , wcs.web_enabled
        FROM WSH_CARRIER_SERVICES wcs
           , WSH_CARRIERS_V       wcv
       WHERE wcs.carrier_id             = wcv.carrier_id
         AND wcv.freight_code           = 'TRANS_AR'
         AND NVL(wcs.enabled_flag, 'N') = 'Y'
         AND carrier_service_id         IN (SELECT DISTINCT woc.carrier_service_id   
                                              FROM WSH_ORG_CARRIER_SERVICES  woc
                                             WHERE woc.organization_id = p_org_base )
         AND carrier_service_id     NOT IN (SELECT DISTINCT woc.carrier_service_id   
                                              FROM WSH_ORG_CARRIER_SERVICES  woc
                                             WHERE woc.organization_id = p_org_destino) 
       ORDER BY carrier_service_id;


    CURSOR c_new_org (p_carrier_svc_id IN NUMBER) IS
      SELECT ood.organization_id
           , ood.organization_code
           , ood.organization_name  
           , wocs.row_id
           , wocs.org_carrier_service_id
        FROM ORG_ORGANIZATION_DEFINITIONS   ood
           , HR_ALL_ORGANIZATION_UNITS      haou
           , HR_ALL_ORGANIZATION_UNITS_DFV  haoud
           , WSH_ORG_CARRIER_SERVICES_V     wocs
       WHERE ood.organization_id     = p_org_destino   
         AND ood.organization_id     = haou.organization_id
         AND haou.rowid              = haoud.row_id
         AND haoud.xx_om_asigna_org_a_transp_flag = 'Y'
         AND haoud.context_value     = 'AR' 
         AND wocs.organization_id    = ood.organization_id
         AND ((wocs.carrier_service_id IS NULL 
              AND wocs.organization_id NOT IN (SELECT organization_id
                                                 FROM WSH_ORG_CARRIER_SERVICES
                                                WHERE carrier_service_id = p_carrier_svc_id)) 
             OR (wocs.carrier_service_id = p_carrier_svc_id
                AND wocs.organization_id NOT IN (SELECT organization_id
                                                   FROM WSH_ORG_CARRIER_SERVICES
                                                  WHERE carrier_service_id = p_carrier_svc_id
                                                    AND enabled_flag = 'Y') ));
       
    
  BEGIN
    
    SELECT name
         , ob.organization_name
         , od.organization_name
      INTO l_oper_unit
         , l_org_base
         , l_org_destino    
      FROM HR_OPERATING_UNITS hou
         , ORG_ORGANIZATION_DEFINITIONS ob
         , ORG_ORGANIZATION_DEFINITIONS od
     WHERE hou.organization_id = p_org_id
       AND hou.organization_id = ob.operating_unit
       AND ob.organization_id  = p_org_base
       AND hou.organization_id = od.operating_unit
       AND od.organization_id  = p_org_destino;
         
         
    FND_FILE.put_line (FND_FILE.log ,'Oper_unit:   '||p_org_id||' - '||l_oper_unit);
    FND_FILE.put_line (FND_FILE.log ,'Org_base:    '||p_org_base||' - '||l_org_base);
    FND_FILE.put_line (FND_FILE.log ,'Org_destino: '||p_org_destino||' - '||l_org_destino);
      
    FND_FILE.put_line (FND_FILE.output ,' ');
    FND_FILE.put_line (FND_FILE.output, '======================================================================= ');
    FND_FILE.put_line (FND_FILE.output ,'                   XX INV Migrar Niveles de Servicio                    ');
    FND_FILE.put_line (FND_FILE.output, '======================================================================= ');
    FND_FILE.put_line (FND_FILE.output ,' ');
      
    
    IF (p_org_base = p_org_destino) THEN
      
      l_error_msg := 'La organización de destino debe ser diferente a la organización de base. Por favor, modificar. ';
      FND_FILE.put_line (FND_FILE.output, l_error_msg);
      RAISE eOrgIguales;
      
    END IF;
      
      
    BEGIN
      
      SELECT attribute_category
           , NVL(attribute1, 'N')
        INTO l_contexto
           , l_asig_org_a_transp_flag
        FROM HR_ALL_ORGANIZATION_UNITS
       WHERE organization_id = p_org_destino;
      
      IF (l_asig_org_a_transp_flag = 'N') THEN
        
        l_error_msg := 'La organización de destino ('||l_org_destino||') no está configurada para importar '||
                       'Niveles de Servicio desde la organización de base. '||CHR(10)||
                       'Revisar el valor del flexfield: Detalles Adicionales Unidad Org -> Asigna Organizacion a Transportista.';
        FND_FILE.put_line (FND_FILE.output, l_error_msg);
        RAISE eAsignaOrgsSeteo;
                        
      END IF;
      
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      
        l_error_msg := 'La organización de destino ('||l_org_destino||') debe tener configurado en SI '||
                       'el siguiente flexfield: '||CHR(10)||
                       'Nombre -> Detalles Adicionales Unidad Org; Segmento -> Asigna Organizacion a Transportista. Por favor, modificar. ';
        FND_FILE.put_line (FND_FILE.output, l_error_msg);
        RAISE eAsignaOrgsSeteo;
            
    END;
      

    
    FOR rcs IN  c_carriers LOOP
      
      FND_FILE.put_line (FND_FILE.output,'Carrier service a procesar: '||rcs.carrier_service_id);
      l_cant_proc := l_cant_proc + 1;

      BEGIN
        
        FOR rorg IN c_new_org(rcs.carrier_service_id) LOOP
             
          l_org_code               := rorg.organization_code;
          l_row_id                 := rorg.row_id;
          l_org_carrier_service_id := rorg.org_carrier_service_id;
          
               
          l_org_carrier_service_info.carrier_service_id := rcs.carrier_service_id;
          l_org_carrier_service_info.organization_id    := rorg.organization_id;
          l_org_carrier_service_info.enabled_flag       := rcs.enabled_flag;
          l_org_carrier_service_info.creation_date      := SYSDATE;
          l_org_carrier_service_info.created_by         := 2070;
          l_org_carrier_service_info.last_update_date   := SYSDATE;
          l_org_carrier_service_info.last_updated_by    := 2070;
          l_org_carrier_service_info.last_update_login  := 1;
                
          l_carrier_info.p_freight_code    := rcs.freight_code;
          l_carrier_info.p_carrier_name    := rcs.carrier_name;
          l_carrier_info.creation_date     := SYSDATE;
          l_carrier_info.created_by        := 2070;
          l_carrier_info.last_update_date  := SYSDATE;
          l_carrier_info.last_updated_by   := 2070;
          l_carrier_info.last_update_login := 1;
                    
                  
          ------------------------------------------------
          -- Initialize all the values for inserting into
          -- the table WSH_CARRIER_SHIP_METHODS
          ------------------------------------------------
                
          l_CSM_info.Carrier_id           := rcs.carrier_id;
          l_CSM_info.ship_method_code     := rcs.ship_method_code;
          l_CSM_info.organization_id      := rorg.organization_id;
          l_CSM_info.carrier_site_id      := NULL;
          l_CSM_info.freight_code         := rcs.freight_code; 
          l_CSM_info.service_level        := rcs.service_level_code; 
          l_CSM_info.Enabled_Flag         := rcs.enabled_flag;
          l_CSM_info.Creation_Date        := SYSDATE;
          l_CSM_info.Created_By           := 2070;
          l_CSM_info.Last_Update_date     := SYSDATE;
          l_CSM_info.Last_Updated_by      := 2070;
          l_CSM_info.Last_Update_Login    := 1;
          l_CSM_info.Web_Enabled          := rcs.web_enabled;

         
          IF (l_org_carrier_service_id IS NOT NULL) THEN
            
            SELECT count(*)
              INTO l_exists_csm
              FROM WSH_CARRIER_SHIP_METHODS
             WHERE organization_id =  rorg.organization_id
               AND ship_method_code = rcs.ship_method_code; 
            
            IF (l_exists_csm = 0) THEN
                        
              WSH_CARRIER_SHIP_METHODS_PKG.Create_Carrier_Ship_Method(
                                           p_carrier_ship_method_info    => l_CSM_info,
                                           x_rowid                       => l_csm_rowid,
                                           x_carrier_ship_method_id      => l_carrier_ship_method_id,
                                           x_return_status               => l_return_status);
                                        
              IF (l_return_status <> 'S') THEN
                l_error_msg := '    Error al intentar crear un registro en WSH_CARRIER_SHIP_METHODS '||
                              'para el carrier_service_id '||rcs.carrier_service_id;
                                
                RAISE eCarrierErrors;
                
              END IF;
                      
            END IF;        
            
          END IF;
          
          
          WSH_ORG_CARRIER_SERVICES_PKG.Assign_Org_Carrier_Service (
                                       p_org_carrier_service_info => l_Org_Carrier_Service_Info
                                     , p_carrier_info             => l_carrier_info
                                     , p_CSM_info                 => l_CSM_info
                                     , p_commit                   => 'F'
                                     , x_Rowid                    => l_row_id
                                     , x_Org_Carrier_Service_Id   => l_org_carrier_service_id
                                     , x_Return_Status            => l_return_status
                                     , x_procedure                => l_procedure
                                     , x_position                 => l_position
                                     , x_sqlerr                   => l_sqlerr
                                     , x_sql_code                 => l_sql_code
                                     , x_exception_msg            => l_exception_msg);
                  
                
          IF (l_return_status <> 'S') THEN
            
            l_error_msg := '    Se encontraron Errores Inesperados en posicion ' ||l_position ||
                           ' cuando '||l_procedure||'. Detalles : Mensaje de Excepcion: '||l_exception_msg||
                           ', Error '||l_sqlerr||', Codigo: '||l_sql_code||'.';
            RAISE eCarrierErrors;
            
          ELSE
             FND_FILE.put_line (FND_FILE.output,'   Creacion OK -> Ship_method_code: '||l_CSM_info.ship_method_code ||
                                                ' - Service_level: '||l_CSM_info.service_level||
                                                ' - Org_carrier_service_id: '||l_org_carrier_service_id);
             l_cant_ins := l_cant_ins + 1;
             
          END IF;
             
        END LOOP;     
       
      EXCEPTION
        WHEN eCarrierErrors THEN
          FND_FILE.put_line (FND_FILE.output, l_error_msg);
        
      END;
      
    END LOOP;
    

    COMMIT;
    
    FND_FILE.put_line (FND_FILE.output, ' ');
    FND_FILE.put_line (FND_FILE.output, '========================================================== ');
    FND_FILE.put_line (FND_FILE.output, '                        RESUMEN                            ');
    FND_FILE.put_line (FND_FILE.output, '========================================================== ');
    FND_FILE.put_line (FND_FILE.output, 'Cantidad de Niveles de Servicios procesados: '||l_cant_proc);
    FND_FILE.put_line (FND_FILE.output, 'Cantidad de Niveles de Servicios insertados: '||l_cant_ins);
    
    
    
      
    errbuf :=  'XX_INV_NIVELES_DE_SERVICIO_PKG - Reporte Completado Satisfactoriamente';
    retcode := '0';
      
  EXCEPTION
    WHEN eOrgIguales THEN
      
      errbuf  := l_error_msg;
      retcode := '2';
      
    WHEN eAsignaOrgsSeteo THEN
    
      errbuf  := l_error_msg;
      retcode := '2';
    
    WHEN OTHERS THEN
    
      FND_FILE.put_line (FND_FILE.log,'Error en XX_INV_NIVELES_DE_SERVICIO_PKG.main Procedure - '|| SQLERRM);
      errbuf  := 'Error en XX_INV_NIVELES_DE_SERVICIO_PKG.main Procedure - '|| SQLERRM;
      retcode := '2';
      
  END MAIN;


END XX_INV_NIVELES_DE_SERVICIO_PKG;
/

exit
