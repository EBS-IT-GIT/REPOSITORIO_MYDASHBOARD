==============================================================================
CUSINV041_001 : Trava de Subinvent�rio
==============================================================================

Atualiza��o - CUSINV041_001
Produto     - XX Customizaciones
Data        - 22/06/2020 10:14:06
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSINV041_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_INV_TIPO_ITEM_SUBINV_LKP.ldt
                               SAE_INV_TIPO_TRANSACAO_LKP.ldt
                               SAE_INV_TIPO_ITEM_SUBINV_FNC.ldt
                               SAE_INV_TIPO_TRANSACAO_FNC.ldt
                               SAE_INV_TRAVA_SUBINVENTARIO_MNU.ldt
                               SAE_INV_ALMOXARIFE_MNU.ldt
                               SAE_INV_SUPERVISOR_MNU.ldt
                               SAE_INV_MTL_MAT_TRANS_TRG.trg
