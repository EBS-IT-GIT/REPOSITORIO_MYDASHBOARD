 UPDATE xx_po_asocia_remitos xpar
   SET clave_nro = '6005-' || SUBSTR(clave_nro,6,8),
            clave_id   = 1000000 + clave_id
 WHERE xpar.tipo_documento = 'TCG'
 AND xpar.clave_nro = '0005-86115747'                                                 
--1