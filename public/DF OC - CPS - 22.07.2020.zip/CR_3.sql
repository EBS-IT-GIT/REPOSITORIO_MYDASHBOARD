 UPDATE apps.XX_TCG_CARTAS_PORTE_ALL
SET ITEM_ID = 865,
        LAST_UPDATE_DATE = sysdate,
        LAST_UPDATED_BY  = 2070
WHERE NUMERO_CARTA_PORTE IN ('0005-85732364',
                             '0005-85732365',
                             '0005-85732366',
                             '0005-85732367',
                             '0005-85732368',
                             '0005-85732372')                                  
--6