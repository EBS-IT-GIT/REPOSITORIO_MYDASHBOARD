UPDATE wsh_new_deliveries
SET    waybill = '0018-00008220', last_updated_by = -1, last_update_date = sysdate, last_update_login = -1
WHERE  delivery_id = 79209060;
--1 Registro