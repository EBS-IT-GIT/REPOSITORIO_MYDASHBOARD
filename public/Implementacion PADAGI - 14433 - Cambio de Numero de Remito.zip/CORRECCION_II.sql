UPDATE xx_inv_remitos_impresos
SET    waybill_airbill = '0018-00008204', last_updated_by = -1, last_update_date = sysdate, last_update_login = -1
WHERE  group_id = 92552383;
--1 Registro