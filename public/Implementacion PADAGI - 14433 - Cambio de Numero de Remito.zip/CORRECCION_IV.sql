UPDATE xx_inv_remitos_impresos
SET    waybill_airbill = '0018-00008191', last_updated_by = -1, last_update_date = sysdate, last_update_login = -1
WHERE  group_id = 79317121;
--1 Registro