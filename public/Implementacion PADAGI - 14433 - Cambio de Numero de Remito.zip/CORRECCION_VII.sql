UPDATE ra_customer_trx_lines_all rctl
SET    interface_line_attribute4 = '0018-00008191', last_updated_by = -1, last_update_date = sysdate, last_update_login = -1
WHERE  customer_trx_id = (SELECT customer_trx_id FROM ra_customer_trx_all WHERE trx_number = 'A-0116-00002464')
AND    interface_line_attribute4 IS NOT NULL;
--1 Registro