UPDATE mtl_material_transactions mmt
SET    waybill_airbill = '0018-00008204', last_updated_by = -1, last_update_date = sysdate, last_update_login = -1
WHERE  transaction_set_id = 92552383;
--2 Registros