  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_POSTERGA_FORN_PKG" AS

PROCEDURE XX_PRC_ATU_FORN_360 (            ERRBUF         OUT VARCHAR2,
                                           RETCODE        OUT NUMBER,
                                           P_DIAS         IN VARCHAR2,
                                           P_ORG          IN VARCHAR2);

End XX_AP_POSTERGA_FORN_PKG;

/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_POSTERGA_FORN_PKG" AS

PROCEDURE XX_PRC_ATU_FORN_360 (            ERRBUF         OUT VARCHAR2,
                                           RETCODE        OUT NUMBER,
                                           P_DIAS         IN VARCHAR2,
                                           P_ORG          IN VARCHAR2) AS

  /*  +=================================================================+
      |    Copyright (c) 2020 Adecoagro , Sao Paulo , Brasil            |
      |                         All rights reserved.                    |
      +=================================================================+
      |                                                                 |
      | FILENAME                                                        |
      |   XX_GATEC_ATUALIZA_OS                                          |
      |                                                                 |
      | PURPOSE                                                         |
      |   Oracle                                                        |
      |   Produto : Oracle                                              |
      |   Objetivo: Procedure Teste para Atualizar Clientes +10 anos    |
      | Concurrent Oracle: XX AP Posterga Fornecedores para 10 Anos     |                                                                 |
      |                                                                 |
      |                                                                 |
      | NOTES                                                           |
      |   Creation Date (DD/MM/YYYY): 30/01/2019                        |
      |   Created by - Adecoagro - Daniel Marques                       |
      |                                                                 |
      |   Update Date  Update By       Description                      |
      |   06/02/2020   ASOUZA          Criação da Package para o EBS    |
      +=================================================================+

  */

  -- VARIAVEIS --
  v_linha               varchar2(2000);
  nCOUNT_UPDATE number := 0;
  nCOUNT_INSERT number := 0;
  V_EXIST       NUMBER;
  v_DATA_INI    VARCHAR2(30);
  --v_DATA_FIM              VARCHAR2(30);
  SqlErro            VARCHAR2(240);
  v_COD_FORNEC       VARCHAR2(50);
  v_NFF              VARCHAR2(30);
  v_SEC_CODIGO       VARCHAR2(10);
  v_COD_CENTRO_CUSTO varchar2(20);
  v_CTB_ID           varchar2(20);


  cursor c_0 is
  --> Cursor Principal
  select assa.VENDOR_SITE_ID VENDOR_SITE_ID
         ,asu.Attribute4 HOMOLOGACAO
         ,asu.creation_date DATA_CRIACAO
         ,asu.LAST_UPDATE_DATE DATA_ATUALIZACAO
         ,asu.end_date_active
         ,assa.ATTRIBUTE9 TIPO
         ,asu.vendor_name NOME
         ,asu.vendor_id ID_VENDOR
         ,asu.party_id PARTY_ID
         ,hou.name op_unit
    from   apps.ap_suppliers               asu
    ,      apps.ap_supplier_sites_all      assa
    ,      apps.hz_parties                 hpa
    ,      apps.hr_operating_units         hou
    ,      apps.hr_all_organization_units  haou
    ,      apps.hr_locations_all           hlo
    where  1 = 1
    and    asu.vendor_id                   =  assa.vendor_id
    and    asu.end_date_active             >= sysdate
    and    assa.ORG_ID                      =  hou.organization_id
    and    hou.organization_id             = haou.organization_id
    and    haou.location_id                = hlo.location_id
    and    hlo.country                     = 'BR'
    and    hpa.party_id                    = asu.party_id
    and    assa.ATTRIBUTE9                 in  ('AUTORIDADE FISCAL','INSTITUICAO FINANCEIRA','INTERCOMPANY','PRODUTOR DE CANA','PRODUTOR RURAL','TRANSMISSORA DE ENERGIA ELETRICA')
    and    asu.Attribute4 =                'Homologado'
    and    asu.end_date_active              <= TO_DATE(sysdate+366)
    and    asu.LAST_UPDATE_DATE            <= TO_DATE(sysdate+1)
    and  hou.organization_id like ('%'|| P_ORG ||'%')  -- Parâmetro Não Obrigatório
    and    asu.LAST_UPDATE_DATE            >= TO_DATE(sysdate - P_DIAS ) -- Parâmetro Obrigatório
;
  --===================================================================================
 --- Processa os registros do cursor ---
BEGIN
  
     /*Begin
       V_ORG_ID := FND_PROFILE.VALUE('ORG_ID');
     end;*/
     
   Begin
       -- Abre o Aquivo para Gravação
      DBMS_OUTPUT.ENABLE(9000000000);
      fnd_file.put_line(fnd_file.log,'========================================================================================');
      fnd_file.put_line(fnd_file.log,'Abre Arquivo para Gravação ' || to_char(sysdate, 'dd-mon-yy HH:mi:ss'));
      fnd_file.put_line(fnd_file.log,'Valores dos parâmetros inseridos: ');
      fnd_file.put_line(fnd_file.log,'Dias Retroativos = ' || to_char(P_DIAS));
      fnd_file.put_line(fnd_file.log,'Organizacao = ' || to_char(P_ORG));
      fnd_file.put_line(fnd_file.log,'                                                                                       ');
      fnd_file.put_line(fnd_file.log,'========================================================================================');
    Exception
      When Others Then
        raise_application_error(-20080,sqlerrm || ' Problemas na abertura do arquivo ');
    End;

    -- Monta o Titulo do Relatorio
    v_linha := '' || '|' || '' || '|' || '' || '|' || '' || '|' ||
               '                   XX AP Posterga Fornecedores para 10 Anos ' || '|' || '' || '|' || '';

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;

    -- Monta os Campos Do Cabeçalho --
    v_linha := '  Parametros:           ' || '';

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    ------------------------------------------------------------------------------------------
    v_linha := 'Dias Retroativos: ' ||'|' || P_DIAS;

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    ------------------------------------------------------------------------
    v_linha := 'Organizacao: ' ||'|' || P_ORG;

    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    ------------------------------------------------------------------------------------------
   
    --------------------------------------------------------------------------------------------
  --> ESPAÇO PARA COMEÇAR O CABEÇALHO
   v_linha := '                                                                              ';

    Begin
     Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,'Problemas na gravacao do arquivo');
        raise_application_error(-20030,sqlerrm ||' Problemas na gravacao do arquivo ');
    End;


 v_linha :=   'VENDOR_SITE_ID' || '|' ||
                 'HOMOLOGACAO' || '|' ||
                 'DATA_CRIACAO' || '|' ||
                 'DATA_ATUALIZACAO' || '|' ||
                 'END_DATE_ACTIVE' || '|' ||
                 'TIPO' || '|' ||
                 'NOME' || '|' ||
                 'ID_VENDOR' || '|' ||
                 'PARTY_ID' ||'|'||
                 'OP_UNIT' ;


    BEGIN
      Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,
                          'Problemas na gravacao do arquivo');
        raise_application_error(-20030,
                                sqlerrm ||
                                ' Problemas na gravacao do arquivo ');
    END;
    
    
  --- Processa os registros do cursor ---

  For v_0 in c_0
  Loop

    Exit When c_0%NotFound;

  ----> FINAL DA PROCEDURE INSERE DADOS 
v_linha :=       v_0.VENDOR_SITE_ID || '|' ||
                 v_0.HOMOLOGACAO || '|' ||
                 v_0.DATA_CRIACAO|| '|' ||
                 v_0.DATA_ATUALIZACAO || '|' ||
                 v_0.end_date_active || '|' ||
                 v_0.TIPO|| '|' ||
                 v_0.NOME|| '|' ||
                 v_0.ID_VENDOR || '|' ||
                 v_0.PARTY_ID ||'|'||
                 v_0.OP_UNIT ;

    Begin
        Fnd_File.Put_Line(Fnd_File.Output, v_linha);
    Exception
      When Others Then
        fnd_file.put_line(fnd_file.output,'Problemas na gravacao do arquivo' );
        raise_application_error(-20030, sqlerrm || ' Problemas na gravacao do arquivo ');
    End;

   BEGIN
        update apps.ap_suppliers asu
        set  asu.end_date_active = TO_CHAR(TO_DATE(sysdate+3652,'DD/MM/YYYY')),
        asu.last_update_date = sysdate
        where asu.last_update_date > (sysdate-1)-- PARAMETRO A SER INSERIDO. MAXIMO 7
        and asu.VENDOR_ID = v_0.ID_VENDOR;

          nCOUNT_INSERT := nCOUNT_INSERT + 1;

        COMMIT;

      EXCEPTION
        WHEN OTHERS THEN
          sqlErro := SubStr(SqlErrm, 1, 240);
      END; 
      
  End Loop;
  
  END XX_PRC_ATU_FORN_360;
END XX_AP_POSTERGA_FORN_PKG;
/

exit
