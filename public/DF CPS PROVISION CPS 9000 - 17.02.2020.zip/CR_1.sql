UPDATE apps.XX_TCG_CARTAS_PORTE_ALL x1
   SET PROVISIONAR_FLETE_FLAG = 'N', LAST_UPDATE_DATE = SYSDATE
 WHERE CARTA_PORTE_ID IN
          (SELECT xcp.CARTA_PORTE_ID
             FROM apps.xx_po_asocia_remitos xpar,
                  apps.po_headers_all ph,
                  apps.po_lines_all pl,
                  apps.xx_tcg_cartas_porte_all xcp
            WHERE     xpar.po_header_id = ph.po_header_id
                  AND pl.po_header_id = xpar.po_header_id
                  AND pl.po_line_id = xpar.po_line_id
                  AND xpar.tipo_documento = 'TCG'
                  AND xpar.tipo_erogacion = 'FLETE'        -- p_tipo_erogacion
                  AND xpar.clave_id = xcp.carta_porte_id
                  AND xcp.NUMERO_CARTA_PORTE LIKE '9000%'
                  AND xcp.ANULADO_FLAG = 'N'
                  AND xcp.PROVISIONAR_FLETE_FLAG = 'Y'
                  AND xcp.PROVISIONADO_FLAG = 'Y'
                  AND xcp.COSTO_FLETE <> '4000'
                  AND NVL (ph.cancel_flag, 'Y') = 'Y'
           UNION
           SELECT xcp.CARTA_PORTE_ID
             FROM apps.XX_TCG_CARTAS_PORTE_ALL xcp
            WHERE     1 = 1
                  AND xcp.NUMERO_CARTA_PORTE LIKE '9000%'
                  AND xcp.ANULADO_FLAG = 'N'
                  AND xcp.PROVISIONADO_FLAG = 'Y'
                  AND xcp.PROVISIONAR_FLETE_FLAG = 'Y'
                  AND xcp.COSTO_FLETE <> '4000'
                  AND NOT EXISTS
                             (SELECT *
                                FROM apps.xx_po_asocia_remitos x1,
                                     apps.xx_tcg_cartas_porte_all x2,
                                     apps.po_headers_all ph,
                                     apps.po_lines_all pl
                               WHERE x1.CLAVE_NRO = xcp.NUMERO_CARTA_PORTE
                                     AND x1.CLAVE_NRO = x2.NUMERO_CARTA_PORTE
                                     AND x1.TIPO_EROGACION = 'FLETE'
                                     AND x1.TIPO_DOCUMENTO = 'TCG'
                                     AND x1.CLAVE_NRO LIKE '9000%'
                                     AND x1.COSTO_TOTAL <> '4000'
                                     AND x2.PROVISIONAR_FLETE_FLAG = 'Y'
                                     AND x2.PROVISIONADO_FLAG = 'Y'
                                     AND pl.po_header_id = x1.po_header_id
                                     AND pl.po_line_id = x1.po_line_id
                                     AND x1.po_header_id = ph.po_header_id
                                     AND NVL (ph.cancel_flag, 'N') = 'N'))
--403