UPDATE apps.gl_interface
SET    currency_conversion_date = to_date('26-06-2020','DD-MM-RRRR')
WHERE  status like '%ECW1%';
--4 Registros