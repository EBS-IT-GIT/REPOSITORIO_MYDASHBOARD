WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2

WHENEVER SQLERROR CONTINUE

CREATE OR REPLACE PACKAGE BODY XXSTN_AR_CARGA_LOCAL_IBGE AS
   ---
   PROCEDURE CARGA_LOCALIDADES_PRC(RETCODE            IN  NUMBER,
                                   ERRBUF             OUT VARCHAR2,
                                   P_ENTIDADE         IN  VARCHAR2) as
      ---
      X_RETURN_STATUS             VARCHAR2(10);
      X_MSG_COUNT                 NUMBER;
      X_MSG_DATA                  VARCHAR2(5000);
      X_GEOGRAPHY_ID              NUMBER;
      V_ERRO                      NUMBER;
      V_INSERT                    NUMBER;
      V_RETORNO                   VARCHAR2(50);
      contador                    number;
      --
      V_STATE                     VARCHAR2(2);
      ID_STATE                    NUMBER;
      --
      V_INICIO_EST                NUMBER:= 0;
      V_INICIO_CITY               NUMBER:= 0;
      V_INICIO_CEP                NUMBER:= 0;
      V_INICIO_END                NUMBER:= 0;
      V_INICIO_IBGE_EST           NUMBER:= 0;
      V_INICIO_IBGE_CITY          NUMBER:= 0;
      V_INICIO_EST_EXT            NUMBER:= 0;
      V_INICIO_CITY_EXT           NUMBER:= 0;
      V_INICIO_CRPREF_EST         NUMBER:= 0;
      V_INICIO_CRPREF_CITY        NUMBER:= 0;
      --
      V_FIM_EST                NUMBER:= 0;
      V_FIM_CITY               NUMBER:= 0;
      V_FIM_CEP                NUMBER:= 0;
      V_FIM_END                NUMBER:= 0;
      V_FIM_IBGE_EST           NUMBER:= 0;
      V_FIM_IBGE_CITY          NUMBER:= 0;
      V_FIM_EST_EXT            NUMBER:= 0;
      V_FIM_CITY_EXT           NUMBER:= 0;
      V_RESULT_REL             NUMBER:=0;
      V_FIM_CRPREF_EST         NUMBER:= 0;
      V_FIM_CRPREF_CITY        NUMBER:= 0;
      ---
   BEGIN
      ---
      V_INICIO_EST                := VERIFICA_RESUMOS('ESTADOS');
      V_INICIO_CITY               := VERIFICA_RESUMOS('CIDADES');
      V_INICIO_IBGE_EST           := VERIFICA_RESUMOS('IBGE_ESTADOS');
      V_INICIO_IBGE_CITY          := VERIFICA_RESUMOS('IBGE_CIDADES');
      V_INICIO_EST_EXT            := VERIFICA_RESUMOS('ESTADOS_EXT');
      V_INICIO_CITY_EXT           := VERIFICA_RESUMOS('CIDADES_EXT');
      V_INICIO_CRPREF_EST         := VERIFICA_RESUMOS('CRPREF_ESTADOS');
      V_INICIO_CRPREF_CITY        := VERIFICA_RESUMOS('CRPREF_CIDADES');

      ---------------------------
      -- INSERE ESTADOS
      ---------------------------
      IF ((P_ENTIDADE = 'ESTADOS') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE('ESTADOS');
      END IF;
      ---------------------------
      -- INSERE IBGE para ESTADOS
      ---------------------------
      IF ((P_ENTIDADE = 'IBGE ESTADOS') OR  (P_ENTIDADE IS NULL ))THEN
          V_RETORNO                   := INSERIR_IBGE('ESTADO');
      END IF;
      ---------------------------
      -- CRIAR CIDADES
      ---------------------------
      IF ((P_ENTIDADE = 'CIDADES') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE('CIDADES');
      END IF;
      ---------------------------
      -- CRIAR IBGE para CIDADES
      ---------------------------
      IF ((P_ENTIDADE = 'IBGE CIDADES') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := INSERIR_IBGE('CIDADE');
      END IF;
      ---------------------------
      -- CRIA ESTADOS EXT
      ---------------------------
      IF ((P_ENTIDADE = 'ESTADOS') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE_EXT('ESTADOS');
      END IF;
      --
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236 
      IF ((P_ENTIDADE = 'ESTADOS CA') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE_EXT('ESTADOS');
      END IF;
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236 
      --
      ---------------------------
      -- CRIAR CIDADES
      ---------------------------
      IF ((P_ENTIDADE = 'CIDADES') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE_EXT('CIDADES');
      END IF;
      --
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236 
      IF ((P_ENTIDADE = 'CIDADES CA') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE_EXT('CIDADES');
      END IF;
      
      --
      IF ((P_ENTIDADE = 'COUNTY') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := CRIA_ENTIDADE_EXT('COUNTY');
      END IF;
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236 
      --
      ---------------------------
      ---------------------------
      -- INSERE REFERENCIA CORPORATIVO para ESTADOS
      ---------------------------
      IF ((P_ENTIDADE = 'CRP REF ESTADOS') OR  (P_ENTIDADE IS NULL ))THEN
          V_RETORNO                   := INSERIR_CRP_REF('ESTADO');
      END IF;
      ---------------------------
      -- CRIAR REFERENCIA CORPORATIVO para CIDADES
      ---------------------------
      IF ((P_ENTIDADE = 'CRP REF CIDADES') OR  (P_ENTIDADE IS NULL ))THEN
         V_RETORNO                   := INSERIR_CRP_REF('CIDADE');
      END IF;
      ---------------------------
      -- VERIFICAR RESUMOS
      ---------------------------
      V_FIM_EST                := VERIFICA_RESUMOS('ESTADOS');
      V_FIM_CITY               := VERIFICA_RESUMOS('CIDADES');
      V_FIM_IBGE_EST           := VERIFICA_RESUMOS('IBGE_ESTADOS');
      V_FIM_IBGE_CITY          := VERIFICA_RESUMOS('IBGE_CIDADES');
      V_FIM_EST_EXT            := VERIFICA_RESUMOS('ESTADOS_EXT');
      V_FIM_CITY_EXT           := VERIFICA_RESUMOS('CIDADES_EXT');
      V_FIM_CRPREF_EST         := VERIFICA_RESUMOS('CRPREF_ESTADOS');
      V_FIM_CRPREF_CITY        := VERIFICA_RESUMOS('CRPREF_CIDADES');
      ------------------
      -- INICIO RESUMOS
      -----------------
      fnd_file.put_line(FND_FILE.OUTPUT,' =======================================================');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_EST - V_INICIO_EST;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregados '||V_RESULT_REL||' Estados.' );
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_CITY -  V_INICIO_CITY;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregadas '||V_RESULT_REL||' Cidades.');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_IBGE_EST -  V_INICIO_IBGE_EST;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregados '||V_RESULT_REL||' Códigos IBGE para Estados.');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_IBGE_CITY - V_INICIO_IBGE_CITY;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregados '||V_RESULT_REL||' Códigos IBGE para Cidades.');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_EST_EXT - V_INICIO_EST_EXT;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregados '||V_RESULT_REL||' Estados Estrangeiros.');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_CITY_EXT - V_INICIO_CITY_EXT;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregadas '||V_RESULT_REL||' Cidades Estrangeiras.');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_CRPREF_EST -  V_INICIO_CRPREF_EST;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregados '||V_RESULT_REL||' Códigos do Corporativo para Estados.');
      V_RESULT_REL:=0;
      V_RESULT_REL := V_FIM_CRPREF_CITY - V_INICIO_CRPREF_CITY;
      fnd_file.put_line(FND_FILE.OUTPUT,' Foram carregados '||V_RESULT_REL||' Códigos do Corporativo para Cidades.');
      fnd_file.put_line(FND_FILE.OUTPUT,' =======================================================');
      ---
   END;
   ---
   --------------------------------------------------------------------------------
   ---
   FUNCTION INSERIR_IBGE(TIPO VARCHAR2) RETURN VARCHAR2 AS
      ---
      L_GEO_IDENTIFIER_REC        APPS.HZ_GEOGRAPHY_PUB.GEO_IDENTIFIER_REC_TYPE;
      V_ERRO                      NUMBER;
      V_STATE                     apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      V_CITY                      apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      X_GEOGRAPHY_ID              NUMBER;
      V_START_DATE_CITY           DATE;
      V_END_DATE_CITY             DATE;
      V_INSERT                    NUMBER;
      x_return_status             VARCHAR2(80);
      x_msg_count                 NUMBER;
      x_msg_data                  VARCHAR2(240);
      --
      CURSOR C_UF_CITY(TP VARCHAR2) IS
         SELECT * FROM (
            SELECT DISTINCT PAIS, UF, COD_IBGE_UF, NULL CIDADE,NULL COD_IBGE_MUN
              FROM  XXSTN_AR_LOCALIDADES_IBGE  UF
             WHERE TP = 'ESTADO'
             AND  NOT EXISTS (SELECT 'X'
                             FROM APPS.HZ_GEOGRAPHY_IDENTIFIERS HGI
                                 ,APPS.HZ_GEOGRAPHIES           ST
                                 ,APPS.HZ_GEOGRAPHIES           PA
                             WHERE HGI.GEOGRAPHY_ID       = ST.GEOGRAPHY_ID
                             AND   HGI.IDENTIFIER_SUBTYPE = 'IBGE'
                             AND   HGI.IDENTIFIER_VALUE   = TO_CHAR(UF.COD_IBGE_UF)
                             and   PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                             AND   PA.GEOGRAPHY_CODE      = 'BR'
                             AND   PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                             AND   ST.GEOGRAPHY_TYPE      = 'STATE'
                             AND   TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                             AND   TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                             AND   ST.GEOGRAPHY_CODE      = UF.UF )
            UNION ALL
            SELECT PAIS, UF, COD_IBGE_UF, CIDADE,COD_IBGE_MUN
              FROM XXSTN_AR_LOCALIDADES_IBGE  CT
             WHERE TP = 'CIDADE'
               AND NOT EXISTS ( SELECT 'X'
                                  FROM APPS.HZ_GEOGRAPHY_IDENTIFIERS HGI
                                      ,APPS.HZ_GEOGRAPHIES           ST
                                      ,APPS.HZ_GEOGRAPHIES           PA
                                      ,APPS.HZ_GEOGRAPHIES           CI
                                 WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                                   AND PA.GEOGRAPHY_CODE      = 'BR'
                                   AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                                   AND ST.GEOGRAPHY_TYPE      = 'STATE'
                                   AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                                   AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                                   AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
                                   AND CI.GEOGRAPHY_TYPE      = 'CITY'
                                   AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(CI.START_DATE,SYSDATE)) AND TRUNC(NVL(CI.END_DATE,SYSDATE))
                                   AND ST.GEOGRAPHY_CODE      = CT.UF
                                   AND CI.GEOGRAPHY_CODE      = UPPER(TRANSLATE(SUBSTR(CT.CIDADE,1,30)
                                                              , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                              , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') )
                                   AND hgi.GEOGRAPHY_ID       = ci.GEOGRAPHY_ID
                                   AND hgi.IDENTIFIER_SUBTYPE = 'IBGE'
                                   AND HGI.IDENTIFIER_VALUE   =  TRIM(TO_CHAR(CT.COD_IBGE_MUN)) )
                            )
         order by UF,cidade;
      ---
   BEGIN
      ---
      L_GEO_IDENTIFIER_REC.IDENTIFIER_TYPE      := 'CODE';
      L_GEO_IDENTIFIER_REC.IDENTIFIER_SUBTYPE   := 'IBGE';
      L_GEO_IDENTIFIER_REC.CREATED_BY_MODULE    := 'TCA_V2_API';
      V_STATE                                   := NULL;
      V_CITY                                    := NULL;
      --
      FOR I IN C_UF_CITY(TIPO) LOOP
         --
         V_ERRO :=0;
         --
         V_STATE := UPPER(TRANSLATE(I.UF
                          , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                          , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
         IF TIPO = 'CIDADE' THEN
            V_CITY  := SUBSTR(UPPER(TRANSLATE(I.CIDADE, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ) ,1,30);
         END IF;
         ----------------
         -- LOCALIZAR O ESTADO
         ----------------
         BEGIN
            SELECT ST.GEOGRAPHY_ID
              INTO  x_geography_id
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND PA.GEOGRAPHY_CODE = 'BR'
               AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
               AND ST.GEOGRAPHY_TYPE = 'STATE'
               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
               AND ST.GEOGRAPHY_CODE = V_STATE;
           EXCEPTION
              WHEN NO_DATA_FOUND THEN
                 fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADO O ESTADO DE '||V_STATE);
                 V_ERRO := 1;
              WHEN OTHERS THEN
                 fnd_file.put_line(FND_FILE.OUTPUT,'ERRO NÃO TRATADO PARA LOCALIZAR ESTADO '||V_STATE||' '||sqlerrm);
                V_ERRO := 1;
         END;
         ---------------------
         IF TIPO = 'CIDADE' THEN
            IF V_ERRO = 0 THEN
               ----------------------------------------
               -- Verifica se cidade não existe
               ----------------------------------------
               BEGIN
                  SELECT ST.START_DATE,ST.END_DATE,ST.GEOGRAPHY_ID
                    INTO V_START_DATE_CITY,V_END_DATE_CITY,X_GEOGRAPHY_ID
                    FROM apps.HZ_GEOGRAPHIES ST
                   WHERE GEOGRAPHY_TYPE = 'CITY'
                     AND GEOGRAPHY_ELEMENT2_ID  = to_char(x_geography_id)
                     AND (   (upper(translate(GEOGRAPHY_CODE
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                            = upper(translate(V_CITY
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ))
                          OR (upper(
                          translate(GEOGRAPHY_NAME
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))

                          = upper(translate(V_CITY
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ')))
                         );
                   EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        fnd_file.put_line(FND_FILE.OUTPUT,'1.0 CIDADE NÃO ENCONTRADA. CIDADE= '||V_CITY||' ESTADO= '||V_STATE||' ID GEOGRAFIA= '||to_char(x_geography_id));
                        V_ERRO := 1;
                      WHEN TOO_MANY_ROWS THEN
                        fnd_file.put_line(FND_FILE.OUTPUT,'1.0 - MAIS DE UMA CIDADE PARA O MESMO ESTADO. CIDADE= '||V_CITY||' ESTADO= '||V_STATE);
                        V_ERRO := 2;
                      WHEN OTHERS THEN
                        fnd_file.put_line(FND_FILE.OUTPUT,'ERRO AO LOCALIZAR CIDADE '||V_CITY||' ESTADO= '||V_STATE||' '||sqlerrm);
                        V_ERRO := 3;
               END;
               ---
            END IF;
            ---
         END IF;
         --
         IF V_ERRO = 0 THEN
            ---
            if tipo = 'ESTADO' THEN
               ---
               V_INSERT := 0;
               SELECT COUNT(*) INTO   V_INSERT
                 FROM APPS.hz_geography_identifiers
                WHERE GEOGRAPHY_ID       = x_geography_id
                  AND IDENTIFIER_SUBTYPE = 'IBGE'
                  AND IDENTIFIER_VALUE   = to_char(I.COD_IBGE_UF);
               IF V_INSERT != 0 THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO IBGE JÁ INSERIDO PARA O ESTADO= '||V_STATE);
                  V_ERRO := 5;
               END IF;
               ---
            elsif tipo = 'CIDADE' then
               ---
               V_INSERT := 0;
               SELECT COUNT(*) INTO   V_INSERT
                 FROM APPS.hz_geography_identifiers
                WHERE GEOGRAPHY_ID       = X_GEOGRAPHY_ID
                  AND IDENTIFIER_SUBTYPE = 'IBGE'
                  AND IDENTIFIER_VALUE   = to_char(I.COD_IBGE_MUN);
               ---
               IF V_INSERT != 0 THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO IBGE JÁ INSERIDO PARA A CIDADE= '||V_CITY||' ESTADO= '||V_STATE||' IBGE= '||to_char(I.COD_IBGE_MUN));
                  V_ERRO := 5;
               END IF;
               ---
            else
               ---
               V_ERRO := 6;
               ---
            end if;
            ---
         END IF;
         --
         IF V_ERRO = 0 THEN
            ---
            l_geo_identifier_rec.geography_id         := x_geography_id;
            IF TIPO = 'CIDADE' THEN
               l_geo_identifier_rec.identifier_value     := I.COD_IBGE_MUN;
            ELSIF TIPO = 'ESTADO' THEN
               l_geo_identifier_rec.identifier_value     := I.COD_IBGE_UF;
            ELSE
               NULL;
            END IF;
            ---
            apps.HZ_GEOGRAPHY_PUB.create_geo_identifier(p_init_msg_list            => apps.FND_API.G_TRUE,
                                                        p_geo_identifier_rec      => l_geo_identifier_rec,
                                                        x_return_status           => x_return_status,
                                                        x_msg_count               => x_msg_count,
                                                        x_msg_data                => x_msg_data);
            fnd_file.put_line(FND_FILE.OUTPUT,'  '||X_MSG_DATA);
            ---
         ELSE
            ---
            if tipo = 'ESTADO' then
               fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO IBGE NAO INCLUIDO '||I.COD_IBGE_UF);
            elsif  tipo = 'CIDADE' then
               fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO IBGE NAO INCLUIDO '||I.COD_IBGE_MUN);
            else
               null;
            end if;
            ---
         END IF;
         ---
      end loop;
      ---
      RETURN('ok');
      ---
   END INSERIR_IBGE;
   ---
   --------------------------------------------------------------------------------
   ---
   FUNCTION VERIFICA_RESUMOS(TIPO VARCHAR2) RETURN NUMBER as
      ---
      V_RETORNO  NUMBER;
      ---
   BEGIN
      ---
      V_RETORNO := 0;
      ------------------
      -- INICIO RESUMOS
      -----------------
      IF TIPO = 'ESTADOS' THEN
         SELECT COUNT(*)
           INTO V_RETORNO
           FROM apps.HZ_GEOGRAPHIES           ST
               ,apps.HZ_GEOGRAPHIES           PA
          WHERE ST.GEOGRAPHY_TYPE      = 'STATE'
            AND PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND PA.GEOGRAPHY_CODE      = 'BR'
            AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID;
      END IF;
      ---
      IF TIPO = 'CIDADES' THEN
         SELECT COUNT(*)
           INTO V_RETORNO
           FROM apps.HZ_GEOGRAPHIES          ST
               ,apps.HZ_GEOGRAPHIES          PA
               ,apps.HZ_GEOGRAPHIES          CI
          WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND   PA.GEOGRAPHY_CODE    = 'BR'
            AND   PA.GEOGRAPHY_ID      = ST.GEOGRAPHY_ELEMENT1_ID
            AND   ST.GEOGRAPHY_TYPE    = 'STATE'
            AND   ST.GEOGRAPHY_ID      = CI.GEOGRAPHY_ELEMENT2_ID
            AND   CI.GEOGRAPHY_TYPE    = 'CITY';
      END IF;
      ---
      IF TIPO = 'IBGE_ESTADOS' THEN
         SELECT count(*)
           INTO V_RETORNO
           FROM APPS.hz_geography_identifiers hgi
               ,apps.HZ_GEOGRAPHIES           ST
               ,apps.HZ_GEOGRAPHIES           PA
          WHERE hgi.GEOGRAPHY_ID       = ST.GEOGRAPHY_ID
            AND hgi.IDENTIFIER_SUBTYPE = 'IBGE'
            and PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND PA.GEOGRAPHY_CODE      = 'BR'
            AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
            AND ST.GEOGRAPHY_TYPE      = 'STATE';
      END IF;
      ---
      IF TIPO = 'IBGE_CIDADES' THEN
         SELECT count(*)
           INTO V_RETORNO
           FROM APPS.hz_geography_identifiers hgi
               ,apps.HZ_GEOGRAPHIES            ST
               ,apps.HZ_GEOGRAPHIES            PA
               ,apps.HZ_GEOGRAPHIES            CI
          WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND PA.GEOGRAPHY_CODE      = 'BR'
            AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
            AND ST.GEOGRAPHY_TYPE      = 'STATE'
            AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
            AND CI.GEOGRAPHY_TYPE      = 'CITY'
            AND hgi.GEOGRAPHY_ID       = ci.GEOGRAPHY_ID
            AND hgi.IDENTIFIER_SUBTYPE = 'IBGE';
      END IF;
      ---
      IF TIPO = 'ESTADOS_EXT' THEN
         SELECT COUNT(*)
           INTO V_RETORNO
           FROM apps.HZ_GEOGRAPHIES           ST
               ,apps.HZ_GEOGRAPHIES           PA
          WHERE ST.GEOGRAPHY_TYPE      = 'STATE'
            AND PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND PA.GEOGRAPHY_CODE      = 'BR'
            AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID;
      END IF;
      ---
      IF TIPO = 'CIDADES_EXT' THEN
         SELECT COUNT(*)
           INTO V_RETORNO
           FROM apps.HZ_GEOGRAPHIES          ST
               ,apps.HZ_GEOGRAPHIES          PA
               ,apps.HZ_GEOGRAPHIES          CI
          WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND   PA.GEOGRAPHY_CODE    = 'BR'
            AND   PA.GEOGRAPHY_ID      = ST.GEOGRAPHY_ELEMENT1_ID
            AND   ST.GEOGRAPHY_TYPE    = 'STATE'
            AND   ST.GEOGRAPHY_ID      = CI.GEOGRAPHY_ELEMENT2_ID
            AND   CI.GEOGRAPHY_TYPE    = 'CITY';
      END IF;
      ---
      IF TIPO = 'CRPREF_ESTADOS' THEN
         SELECT count(*)
           INTO V_RETORNO
           FROM APPS.hz_geography_identifiers hgi
               ,apps.HZ_GEOGRAPHIES           ST
               ,apps.HZ_GEOGRAPHIES           PA
          WHERE hgi.GEOGRAPHY_ID       = ST.GEOGRAPHY_ID
            AND hgi.IDENTIFIER_SUBTYPE = 'CRP_REF'
            and PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND PA.GEOGRAPHY_CODE      = 'BR'
            AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
            AND ST.GEOGRAPHY_TYPE      = 'STATE';
      END IF;
      ---
      IF TIPO = 'CRPREF_CIDADES' THEN
         SELECT count(*)
           INTO V_RETORNO
           FROM APPS.hz_geography_identifiers hgi
               ,apps.HZ_GEOGRAPHIES            ST
               ,apps.HZ_GEOGRAPHIES            PA
               ,apps.HZ_GEOGRAPHIES            CI
          WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
            AND PA.GEOGRAPHY_CODE      = 'BR'
            AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
            AND ST.GEOGRAPHY_TYPE      = 'STATE'
            AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
            AND CI.GEOGRAPHY_TYPE      = 'CITY'
            AND hgi.GEOGRAPHY_ID       = ci.GEOGRAPHY_ID
            AND hgi.IDENTIFIER_SUBTYPE = 'CRP_REF';
      END IF;
      ---
      RETURN(V_RETORNO);
      ---
   END VERIFICA_RESUMOS;
   ---
   --------------------------------------------------------------------------------
   ---
   FUNCTION CRIA_ENTIDADE(TIPO VARCHAR2) RETURN VARCHAR2 AS
      ---
      LIN_STATE                   apps.HZ_GEOGRAPHY_PUB.MASTER_GEOGRAPHY_REC_TYPE;
      LIN_CITY                    APPS.HZ_GEOGRAPHY_PUB.MASTER_GEOGRAPHY_REC_TYPE;
      ----
      V_ERRO                      NUMBER;
      V_STATE                     apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      V_CITY                      apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      ---
      X_GEOGRAPHY_ID              NUMBER;
      x_return_status             VARCHAR2(80);
      x_msg_count                 NUMBER;
      x_msg_data                  VARCHAR2(240);
      --
      CURSOR ESTADOS IS
         SELECT distinct UF.SIGLA_PAIS, DECODE(UF.SIGLA_PAIS,'BR',UF.UF,'EX') UF
           FROM XXSTN_AR_LOCALIDADES_IBGE UF
          where UF.SIGLA_PAIS = 'BR'
            AND NOT EXISTS ( SELECT 'X'
                               FROM apps.HZ_GEOGRAPHIES           ST
                                   ,apps.HZ_GEOGRAPHIES           PA
                              WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                                AND PA.GEOGRAPHY_CODE      = 'BR'
                                AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                                AND ST.GEOGRAPHY_TYPE      = 'STATE'
                                AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                                AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                                AND ST.GEOGRAPHY_CODE      = UF.UF)
         ORDER BY UF;
      ---
      CURSOR CIDADES IS
         SELECT CT.UF, COD_IBGE_UF, CIDADE
           FROM XXSTN_AR_LOCALIDADES_IBGE  CT
          where CT.SIGLA_PAIS = 'BR'
            AND NOT EXISTS (SELECT 'X'
                              FROM apps.HZ_GEOGRAPHIES           ST
                                  ,apps.HZ_GEOGRAPHIES           PA
                                  ,apps.HZ_GEOGRAPHIES           CI
                             WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                               AND PA.GEOGRAPHY_CODE      = 'BR'
                               AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                               AND ST.GEOGRAPHY_TYPE      = 'STATE'
                               AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                               AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                               AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
                               AND CI.GEOGRAPHY_TYPE      = 'CITY'
                               AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(CI.START_DATE,SYSDATE)) AND TRUNC(NVL(CI.END_DATE,SYSDATE))
                               AND ST.GEOGRAPHY_CODE      = CT.UF
                               AND CI.GEOGRAPHY_CODE      = substr(upper(translate(CT.cidade
                                                                 , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                                 , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30) )
         ORDER BY UF,cidade;
      -----
   BEGIN
      -- INICIO DE ESTADOS
      IF TIPO = 'ESTADOS' THEN
         ---
         LIN_STATE.GEOGRAPHY_CODE_TYPE    := 'FIPS_CODE';
         LIN_STATE.CREATED_BY_MODULE      := 'TCA_V2_API';
         LIN_STATE.GEOGRAPHY_TYPE         := 'STATE';
         ---
         FOR I IN ESTADOS
         LOOP
            ---
            -- atribue o estado
            V_STATE := UPPER(TRANSLATE(I.UF
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            --
            V_ERRO :=0;
            -- verificar relacionamento para hierarquia acima (Pais)
            LIN_STATE.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('PAIS',NULL,NULL);
            IF LIN_STATE.PARENT_GEOGRAPHY_ID(1) = -1 THEN
               V_ERRO := 1;
            END IF;
            -- verificar se estado já existe
            BEGIN
               SELECT ST.GEOGRAPHY_ID
                 INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                     ,apps.HZ_GEOGRAPHIES PA
                WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
                  AND   PA.GEOGRAPHY_CODE = 'BR'
                  AND   PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
                  AND   ST.GEOGRAPHY_TYPE = 'STATE'
                  AND   TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                  AND   TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                  AND   ST.GEOGRAPHY_CODE = V_STATE;
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO JA EXISTE E NAO SERA INSERIDO. '||V_STATE);
               V_ERRO := 1;
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     -- Não encontrou pode inserir estado
                     LIN_STATE.GEOGRAPHY_NAME        := V_STATE;
                     LIN_STATE.GEOGRAPHY_CODE        := V_STATE;
                  WHEN OTHERS THEN
                     fnd_file.put_line(FND_FILE.OUTPUT,'ERRO NÃO TRATADO PARA ENCONTRAR O ESTADO DE '||V_STATE||' '||SQLERRM);
                     V_ERRO := 1;
            END;
            ----
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_STATE
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA );
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  apps.FND_MSG_PUB.delete_msg;
                  ROLLBACK;
                  dbms_output.put_line('  '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  -- TUDO OK, COMITA ESTADO
                  commit;
               END IF;
               ---
            ELSE
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADO');
            END IF;
            ---
         End loop;
         ---
      ELSIF TIPO = 'CIDADES' THEN  -- FIM DE ESTADOS
         ----------------------
         -- INICIO DE CIDADES
         ----------------------
         LIN_CITY.GEOGRAPHY_TYPE        := 'CITY';
         LIN_CITY.GEOGRAPHY_CODE_TYPE   := 'FIPS_CODE';
         LIN_CITY.CREATED_BY_MODULE     := 'TCA_V2_API';
         FOR I IN CIDADES
         LOOP
            ---
            V_ERRO := 0;
            V_STATE := upper(translate(i.uf
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            V_CITY  := SUBSTR(upper(translate(i.cidade
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30);
            ---------------------
            LIN_CITY.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('ESTADOS',V_STATE,NULL);
            ----------------------------------------
            -- Verifica se cidade não existe
            ----------------------------------------
            BEGIN
               SELECT ST.GEOGRAPHY_ID INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                WHERE GEOGRAPHY_TYPE = 'CITY'
                  AND GEOGRAPHY_ELEMENT2_ID  = to_char(LIN_CITY.PARENT_GEOGRAPHY_ID(1))
                  AND ((upper(translate(GEOGRAPHY_CODE, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                   , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ))
                         OR (upper(
                            translate(GEOGRAPHY_NAME  , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY   , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ')))
                        );
               fnd_file.put_line(FND_FILE.OUTPUT,'A CIDADE '||V_CITY||' JÁ ESTÁ CADASTRADA');
               V_ERRO := 4;
              EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                    -- NÃO ENCONTROU PODE INSERIR A CIDADE
                    LIN_CITY.GEOGRAPHY_NAME        := V_CITY;
                    LIN_CITY.GEOGRAPHY_CODE        := substr(V_CITY,1,30);
                 WHEN TOO_MANY_ROWS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'2.0 MAIS DE UMA CIDADE PARA O MESMO ESTADO. CIDADE= '||LIN_CITY.GEOGRAPHY_CODE||' ESTADO= '||V_STATE);
                    V_ERRO := 2;
                 WHEN OTHERS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'ERRO AO LOCALIZAR CIDADE '||LIN_CITY.GEOGRAPHY_CODE||' '||sqlerrm);
                    V_ERRO := 3;
            END;
            ---
            dbms_output.put_line('==========V_ERRO='||V_ERRO);
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_CITY
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA);
                dbms_output.put_line('RESULTADO=>'||X_MSG_DATA||'-'||  X_MSG_COUNT);
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN  NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  APPS.FND_MSG_PUB.DELETE_MSG;
                  ROLLBACK;
                  dbms_output.put_line(' '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  ---
                  -- TUDO OK, COMITA CIDADE
                  commit;
                  ---
               END IF;
            ELSE
               ---
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADO');
            END IF;
            ---
         END LOOP;
         ---
      ELSE  -- SAIDA DE ESTADO/CIDADE/CEP E ENDEREÇO
         fnd_file.put_line(FND_FILE.OUTPUT,'HIERARQUIA NÃO PREVISTA');
      END IF;
      ---
      COMMIT;
      RETURN('OK');
      ---
   END CRIA_ENTIDADE;
   ---
   --------------------------------------------------------------------------------
   ---
   FUNCTION HIERARQUIA_ACIMA(TIPO VARCHAR2,P_ENTIDADE VARCHAR2,P_STATE VARCHAR2) RETURN NUMBER AS
      ---
      V_RETORNO  NUMBER;
      ---
   BEGIN
      ---
      V_RETORNO  := 0;
      ---
      IF TIPO = 'PAIS' THEN
         BEGIN
            SELECT PA.GEOGRAPHY_ID
              INTO V_RETORNO
              FROM apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND PA.GEOGRAPHY_CODE = 'BR'
               AND PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE));
              RETURN(V_RETORNO);
          EXCEPTION
             WHEN OTHERS THEN
             fnd_file.put_line(FND_FILE.OUTPUT,'PAIS NAO ENCONTRADO. '||' - '||SQLERRM);
             RETURN(-1);
         END;
      END IF;
      --
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236 
      IF TIPO = 'PAIS CA' THEN
         BEGIN
            SELECT PA.GEOGRAPHY_ID
              INTO V_RETORNO
              FROM apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND PA.GEOGRAPHY_CODE = 'CA'
               AND PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE));
              RETURN(V_RETORNO);
          EXCEPTION
             WHEN OTHERS THEN
             fnd_file.put_line(FND_FILE.OUTPUT,'PAIS NAO ENCONTRADO. '||' - '||SQLERRM);
             RETURN(-1);
         END;
      END IF;
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236 
      --
      
      
      ---
      IF TIPO = 'ESTADOS' THEN
         ---
         BEGIN
            SELECT ST.GEOGRAPHY_ID
              INTO V_RETORNO
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND PA.GEOGRAPHY_CODE = 'BR'
               AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
               AND ST.GEOGRAPHY_TYPE = 'STATE'
--               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
--               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
               AND ST.GEOGRAPHY_CODE = P_ENTIDADE;
               RETURN(V_RETORNO);
            EXCEPTION
               WHEN OTHERS THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADO O ESTADO DE '||P_ENTIDADE||' - '||SQLERRM);
                  RETURN(-1);
         END;
         ---
      END IF;
      ---
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236
      IF TIPO = 'ESTADOS US' THEN
         ---
         BEGIN
            SELECT ST.GEOGRAPHY_ID
              INTO V_RETORNO
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
                AND PA.GEOGRAPHY_CODE = 'US'
               AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
               AND ST.GEOGRAPHY_TYPE = 'STATE'
--               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
--               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
               AND ST.GEOGRAPHY_CODE = P_ENTIDADE;
               RETURN(V_RETORNO);
            EXCEPTION
               WHEN OTHERS THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADO O ESTADO DE '||P_ENTIDADE||' - '||SQLERRM);
                  RETURN(-1);
         END;
         ---
      END IF;
      
      IF TIPO = 'ESTADOS CA' THEN
         ---
         BEGIN
            SELECT ST.GEOGRAPHY_ID
              INTO V_RETORNO
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND PA.GEOGRAPHY_CODE = 'CA'
               AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
               AND ST.GEOGRAPHY_TYPE = 'STATE'
--               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
--               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
               AND ST.GEOGRAPHY_CODE = P_ENTIDADE;
               RETURN(V_RETORNO);
            EXCEPTION
               WHEN OTHERS THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADO O ESTADO DE '||P_ENTIDADE||' - '||SQLERRM);
                  RETURN(-1);
         END;
         ---
      END IF;
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236
      ---
      IF TIPO = 'CIDADES' THEN
         ---
         BEGIN
            SELECT CT.GEOGRAPHY_ID
              INTO  V_RETORNO
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
                  ,apps.HZ_GEOGRAPHIES CT
              WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
                AND PA.GEOGRAPHY_CODE = 'BR'
                AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
                AND ST.GEOGRAPHY_TYPE = 'STATE'
                AND ST.GEOGRAPHY_ID   = CT.GEOGRAPHY_ELEMENT2_ID
                AND CT.GEOGRAPHY_TYPE = 'CITY'
                AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(CT.START_DATE,SYSDATE)) AND TRUNC(NVL(CT.END_DATE,SYSDATE))
                AND ST.GEOGRAPHY_CODE = P_STATE
                AND CT.GEOGRAPHY_CODE = P_ENTIDADE;
              RETURN(V_RETORNO);
           EXCEPTION
            WHEN OTHERS THEN
             fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADA A CIDADE DE '||P_ENTIDADE||' - '||SQLERRM);
             RETURN(-1);
         END;
         ---
      END IF;
      --
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236
      IF TIPO = 'CIDADES CA' THEN
         ---
         BEGIN
            SELECT CT.GEOGRAPHY_ID
              INTO  V_RETORNO
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
                  ,apps.HZ_GEOGRAPHIES CT
              WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
                AND PA.GEOGRAPHY_CODE = 'CA'
                AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
                AND ST.GEOGRAPHY_TYPE = 'STATE'
                AND ST.GEOGRAPHY_ID   = CT.GEOGRAPHY_ELEMENT2_ID
                AND CT.GEOGRAPHY_TYPE = 'CITY'
                AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(CT.START_DATE,SYSDATE)) AND TRUNC(NVL(CT.END_DATE,SYSDATE))
                AND ST.GEOGRAPHY_CODE = P_STATE
                AND CT.GEOGRAPHY_CODE = P_ENTIDADE;
              RETURN(V_RETORNO);
           EXCEPTION
            WHEN OTHERS THEN
             fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADA A CIDADE DE '||P_ENTIDADE||' - '||SQLERRM);
             RETURN(-1);
         END;
         ---
         -- end 04/08/2020 -- TICKET: 323082 - #SR-552236
         
      END IF;
   END HIERARQUIA_ACIMA;
   ---
   --------------------------------------------------------------------------------
   ---
   FUNCTION CRIA_ENTIDADE_EXT(TIPO VARCHAR2) RETURN VARCHAR2 AS
      ---
      LIN_STATE                   apps.HZ_GEOGRAPHY_PUB.MASTER_GEOGRAPHY_REC_TYPE;
      LIN_CITY                    APPS.HZ_GEOGRAPHY_PUB.MASTER_GEOGRAPHY_REC_TYPE;
      ----
      V_ERRO                      NUMBER;
      V_STATE                     apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      V_CITY                      apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      ---
      X_GEOGRAPHY_ID              NUMBER;
      x_return_status             VARCHAR2(80);
      x_msg_count                 NUMBER;
      x_msg_data                  VARCHAR2(240);
      --
      CURSOR ESTADOS IS
         SELECT distinct SIGLA_PAIS, UF.UF UF
           FROM XXSTN_AR_LOCALIDADES_IBGE UF
          where UF.SIGLA_PAIS = 'CA'
            AND NOT EXISTS ( SELECT 'X'
                               FROM apps.HZ_GEOGRAPHIES           ST
                                   ,apps.HZ_GEOGRAPHIES           PA
                              WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                                AND PA.GEOGRAPHY_CODE      = 'CA'
                                AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                                AND ST.GEOGRAPHY_TYPE      = 'STATE'
                                AND ST.GEOGRAPHY_CODE      = UF.UF)
         ORDER BY UF;
      ---
      CURSOR CIDADES IS
         SELECT DISTINCT SIGLA_PAIS,  UF, CT.COD_IBGE_UF, CT.CIDADE
           FROM XXSTN_AR_LOCALIDADES_IBGE  CT
          where CT.SIGLA_PAIS = 'CA'
            AND NOT EXISTS (SELECT 'X'
                              FROM apps.HZ_GEOGRAPHIES           ST
                                  ,apps.HZ_GEOGRAPHIES           PA
                                  ,apps.HZ_GEOGRAPHIES           CI
                             WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                               AND PA.GEOGRAPHY_CODE      = 'CA'
                               AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                               AND ST.GEOGRAPHY_TYPE      = 'STATE'
                               AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
                               AND CI.GEOGRAPHY_TYPE      = 'CITY'
                               AND ST.GEOGRAPHY_CODE      = 'EX'
                               AND CI.GEOGRAPHY_CODE      = substr(upper(translate(CT.cidade
                                                                 , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                                 , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30) )
         ORDER BY UF,cidade;
      -----
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236
      CURSOR COUNTY IS
         SELECT DISTINCT SIGLA_PAIS,  UF, CT.COD_IBGE_UF, CT.CIDADE
           FROM XXSTN_AR_LOCALIDADES_IBGE  CT
          where CT.SIGLA_PAIS = 'US'
            AND NOT EXISTS (SELECT 'X'
                              FROM apps.HZ_GEOGRAPHIES           ST
                                  ,apps.HZ_GEOGRAPHIES           PA
                                  ,apps.HZ_GEOGRAPHIES           CI
                             WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                               AND PA.GEOGRAPHY_CODE      = 'US'
                               AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                               AND ST.GEOGRAPHY_TYPE      = 'STATE'
                               AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
                               AND CI.GEOGRAPHY_TYPE      = 'CITY'
                               AND ST.GEOGRAPHY_CODE      = 'EX'
                               AND CI.GEOGRAPHY_CODE      = substr(upper(translate(CT.cidade
                                                                 , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                                 , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30) )
         ORDER BY UF,cidade;
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236
   BEGIN
      -- INICIO DE ESTADOS
      
      IF TIPO = 'ESTADOS' THEN
         ---
         LIN_STATE.GEOGRAPHY_CODE_TYPE    := 'FIPS_CODE';
         LIN_STATE.CREATED_BY_MODULE      := 'TCA_V2_API';
         LIN_STATE.GEOGRAPHY_TYPE         := 'STATE';
         ---
         FOR I IN ESTADOS
         LOOP
            ---
            -- atribue o estado
            V_STATE := UPPER(TRANSLATE(I.UF
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            --
            V_ERRO :=0;
            -- verificar relacionamento para hierarquia acima (Pais)
            LIN_STATE.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('PAIS', NULL, NULL);
            ---
            IF LIN_STATE.PARENT_GEOGRAPHY_ID(1) = -1 THEN
               V_ERRO := 1;
            END IF;
            -- verificar se estado já existe
            fnd_file.put_line(FND_FILE.OUTPUT,'COUNTRY = ' || I.SIGLA_PAIS);
            fnd_file.put_line(FND_FILE.OUTPUT,'STATE   = ' || V_STATE || ' - ' || V_ERRO);
            ---
            BEGIN
               SELECT ST.GEOGRAPHY_ID
                 INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                     ,apps.HZ_GEOGRAPHIES PA
                WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
                  AND PA.GEOGRAPHY_CODE = I.SIGLA_PAIS
                  AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
                  AND ST.GEOGRAPHY_TYPE = 'STATE'
                  AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                  AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                  AND ST.GEOGRAPHY_CODE = V_STATE;
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO JA EXISTE E NAO SERA INSERIDO. '||V_STATE);
               V_ERRO := 1;
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     -- Não encontrou pode inserir estado
                     LIN_STATE.GEOGRAPHY_NAME        := V_STATE;
                     LIN_STATE.GEOGRAPHY_CODE        := V_STATE;
                  WHEN OTHERS THEN
                     fnd_file.put_line(FND_FILE.OUTPUT,'ERRO NÃO TRATADO PARA ENCONTRAR O ESTADO DE '||V_STATE||' '||SQLERRM);
                     V_ERRO := 1;
            END;
            ----
            fnd_file.put_line(FND_FILE.OUTPUT,'V_ERRO - ' || V_ERRO);
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_STATE
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA );
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  fnd_file.put_line(FND_FILE.OUTPUT,'X_MSG_DATA = ' || X_MSG_DATA);
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  apps.FND_MSG_PUB.delete_msg;
                  ROLLBACK;
                  dbms_output.put_line('  '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  -- TUDO OK, COMITA ESTADO
                  commit;
               END IF;
               ---
            ELSE
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADO');
            END IF;
            ---
         End loop;
         ---
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236
      ELSIF TIPO = 'ESTADOS CA' THEN
         ---
         LIN_STATE.GEOGRAPHY_CODE_TYPE    := 'FIPS_CODE';
         LIN_STATE.CREATED_BY_MODULE      := 'TCA_V2_API';
         LIN_STATE.GEOGRAPHY_TYPE         := 'STATE';
         ---
         FOR I IN ESTADOS
         LOOP
            ---
            -- atribue o estado
            V_STATE := UPPER(TRANSLATE(I.UF
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            --
            V_ERRO :=0;
            -- verificar relacionamento para hierarquia acima (Pais)
            LIN_STATE.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('PAIS CA', NULL, NULL);
            ---
            IF LIN_STATE.PARENT_GEOGRAPHY_ID(1) = -1 THEN
               V_ERRO := 1;
            END IF;
            -- verificar se estado já existe
            fnd_file.put_line(FND_FILE.OUTPUT,'COUNTRY = ' || I.SIGLA_PAIS);
            fnd_file.put_line(FND_FILE.OUTPUT,'STATE   = ' || V_STATE || ' - ' || V_ERRO);
            ---
            BEGIN
               SELECT ST.GEOGRAPHY_ID
                 INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                     ,apps.HZ_GEOGRAPHIES PA
                WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
                  AND PA.GEOGRAPHY_CODE = I.SIGLA_PAIS
                  AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
                  AND ST.GEOGRAPHY_TYPE = 'STATE'
                  AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                  AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                  AND ST.GEOGRAPHY_CODE = V_STATE;
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO JA EXISTE E NAO SERA INSERIDO. '||V_STATE);
               V_ERRO := 1;
               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     -- Não encontrou pode inserir estado
                     LIN_STATE.GEOGRAPHY_NAME        := V_STATE;
                     LIN_STATE.GEOGRAPHY_CODE        := V_STATE;
                  WHEN OTHERS THEN
                     fnd_file.put_line(FND_FILE.OUTPUT,'ERRO NÃO TRATADO PARA ENCONTRAR O ESTADO DE '||V_STATE||' '||SQLERRM);
                     V_ERRO := 1;
            END;
            ----
            fnd_file.put_line(FND_FILE.OUTPUT,'V_ERRO - ' || V_ERRO);
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_STATE
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA );
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  fnd_file.put_line(FND_FILE.OUTPUT,'X_MSG_DATA = ' || X_MSG_DATA);
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  apps.FND_MSG_PUB.delete_msg;
                  ROLLBACK;
                  dbms_output.put_line('  '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  -- TUDO OK, COMITA ESTADO
                  commit;
               END IF;
               ---
            ELSE
               fnd_file.put_line(FND_FILE.OUTPUT,'ESTADO '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADO');
            END IF;
            ---
         End loop;
         ---
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236
      --
      ELSIF TIPO = 'CIDADES' THEN  -- FIM DE ESTADOS
      
         ----------------------
         -- INICIO DE CIDADES
         ----------------------
         LIN_CITY.GEOGRAPHY_TYPE        := 'CITY';
         LIN_CITY.GEOGRAPHY_CODE_TYPE   := 'FIPS_CODE';
         LIN_CITY.CREATED_BY_MODULE     := 'TCA_V2_API';
         FOR I IN CIDADES
         LOOP
         
            ---
            V_ERRO := 0;
            V_STATE := upper(translate(i.uf
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            V_CITY  := SUBSTR(upper(translate(i.cidade
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30);
            ---------------------
            
            fnd_file.put_line(FND_FILE.OUTPUT,'PAIS, ESTADO, CIDADE = ' || I.SIGLA_PAIS || ', ' || V_STATE|| ', ' || V_CITY);
            LIN_CITY.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('ESTADOS', V_STATE, NULL);
            ----------------------------------------
            -- Verifica se cidade não existe
            ----------------------------------------
            BEGIN
               SELECT ST.GEOGRAPHY_ID INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                WHERE GEOGRAPHY_TYPE = 'CITY'
                  AND GEOGRAPHY_ELEMENT2_ID  = to_char(LIN_CITY.PARENT_GEOGRAPHY_ID(1))
                  AND ((upper(translate(GEOGRAPHY_CODE, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                   , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ))
                         OR (upper(
                            translate(GEOGRAPHY_NAME  , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY   , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ')))
                        );
               fnd_file.put_line(FND_FILE.OUTPUT,'A CIDADE '||V_CITY||' JÁ ESTÁ CADASTRADA');
               V_ERRO := 4;
              EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                    -- NÃO ENCONTROU PODE INSERIR A CIDADE
                    LIN_CITY.GEOGRAPHY_NAME        := V_CITY;
                    LIN_CITY.GEOGRAPHY_CODE        := substr(V_CITY,1,30);
                    
                 WHEN TOO_MANY_ROWS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'2.0 MAIS DE UMA CIDADE PARA O MESMO ESTADO. CIDADE= '||LIN_CITY.GEOGRAPHY_CODE||' ESTADO= '||V_STATE);
                    V_ERRO := 2;
                 WHEN OTHERS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'ERRO AO LOCALIZAR CIDADE '||LIN_CITY.GEOGRAPHY_CODE||' '||sqlerrm);
                    V_ERRO := 3;
            END;
            ---
            
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_CITY
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_RETURN_STATUS ='||X_RETURN_STATUS);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_MSG_COUNT ='||X_MSG_COUNT);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_MSG_DATA ='||X_MSG_DATA);
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN  NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  APPS.FND_MSG_PUB.DELETE_MSG;
                  ROLLBACK;
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'V_ERRO ='||V_ERRO);
                  dbms_output.put_line(' '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  ---
                  -- TUDO OK, COMITA CIDADE
                  commit;
                  ---
               END IF;
            ELSE
               ---
               fnd_file.put_line(FND_FILE.OUTPUT,'CIDADE '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADA');
            END IF;
            ---
         END LOOP;
         ---
      -- begin 04/08/2020 -- TICKET: 323082 - #SR-552236
      ELSIF TIPO = 'CIDADES CA' THEN  -- FIM DE ESTADOS
      
         ----------------------
         -- INICIO DE CIDADES
         ----------------------
         LIN_CITY.GEOGRAPHY_TYPE        := 'CITY';
         LIN_CITY.GEOGRAPHY_CODE_TYPE   := 'FIPS_CODE';
         LIN_CITY.CREATED_BY_MODULE     := 'TCA_V2_API';
         FOR I IN CIDADES
         LOOP
         
            ---
            V_ERRO := 0;
            V_STATE := upper(translate(i.uf
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            V_CITY  := SUBSTR(upper(translate(i.cidade
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30);
            ---------------------
            
            fnd_file.put_line(FND_FILE.OUTPUT,'PAIS, ESTADO, CIDADE = ' || I.SIGLA_PAIS || ', ' || V_STATE|| ', ' || V_CITY);
            LIN_CITY.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('ESTADOS CA', V_STATE, NULL);
            ----------------------------------------
            -- Verifica se cidade não existe
            ----------------------------------------
            BEGIN
               SELECT ST.GEOGRAPHY_ID INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                WHERE GEOGRAPHY_TYPE = 'CITY'
                  AND GEOGRAPHY_ELEMENT2_ID  = to_char(LIN_CITY.PARENT_GEOGRAPHY_ID(1))
                  AND ((upper(translate(GEOGRAPHY_CODE, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                   , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ))
                         OR (upper(
                            translate(GEOGRAPHY_NAME  , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY   , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ')))
                        );
               fnd_file.put_line(FND_FILE.OUTPUT,'A CIDADE '||V_CITY||' JÁ ESTÁ CADASTRADA');
               V_ERRO := 4;
              EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                    -- NÃO ENCONTROU PODE INSERIR A CIDADE
                    LIN_CITY.GEOGRAPHY_NAME        := V_CITY;
                    LIN_CITY.GEOGRAPHY_CODE        := substr(V_CITY,1,30);
                    
                 WHEN TOO_MANY_ROWS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'2.0 MAIS DE UMA CIDADE PARA O MESMO ESTADO. CIDADE= '||LIN_CITY.GEOGRAPHY_CODE||' ESTADO= '||V_STATE);
                    V_ERRO := 2;
                 WHEN OTHERS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'ERRO AO LOCALIZAR CIDADE '||LIN_CITY.GEOGRAPHY_CODE||' '||sqlerrm);
                    V_ERRO := 3;
            END;
            ---
            
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_CITY
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_RETURN_STATUS ='||X_RETURN_STATUS);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_MSG_COUNT ='||X_MSG_COUNT);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_MSG_DATA ='||X_MSG_DATA);
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN  NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  APPS.FND_MSG_PUB.DELETE_MSG;
                  ROLLBACK;
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'V_ERRO ='||V_ERRO);
                  dbms_output.put_line(' '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  ---
                  -- TUDO OK, COMITA CIDADE
                  commit;
                  ---
               END IF;
            ELSE
               ---
               fnd_file.put_line(FND_FILE.OUTPUT,'CIDADE '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADA');
            END IF;
            ---
         END LOOP;
         ---
      ELSIF TIPO = 'COUNTY' THEN 
      
         ----------------------
         -- INICIO DE CIDADES
         ----------------------
         LIN_CITY.GEOGRAPHY_TYPE        := 'COUNTY';
         LIN_CITY.GEOGRAPHY_CODE_TYPE   := 'FIPS_CODE';
         LIN_CITY.CREATED_BY_MODULE     := 'TCA_V2_API';
         FOR I IN COUNTY
         LOOP
         
            ---
            V_ERRO := 0;
            V_STATE := upper(translate(i.uf
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
            V_CITY  := SUBSTR(upper(translate(i.cidade
                                      , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ),1,30);
            ---------------------
            
            fnd_file.put_line(FND_FILE.OUTPUT,'PAIS, ESTADO, CIDADE = ' || I.SIGLA_PAIS || ', ' || V_STATE|| ', ' || V_CITY);
            LIN_CITY.PARENT_GEOGRAPHY_ID(1) := HIERARQUIA_ACIMA('ESTADOS US', V_STATE, NULL);
            
            ----------------------------------------
            -- Verifica se cidade não existe
            ----------------------------------------
            BEGIN
               SELECT ST.GEOGRAPHY_ID INTO  x_geography_id
                 FROM apps.HZ_GEOGRAPHIES ST
                WHERE GEOGRAPHY_TYPE = 'COUNTY'
                  AND GEOGRAPHY_ELEMENT2_ID  = to_char(LIN_CITY.PARENT_GEOGRAPHY_ID(1))
                  AND ((upper(translate(GEOGRAPHY_CODE, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                   , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ))
                         OR (upper(
                            translate(GEOGRAPHY_NAME  , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                           = upper(translate(V_CITY   , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ')))
                        );
               fnd_file.put_line(FND_FILE.OUTPUT,'A CIDADE '||V_CITY||' JÁ ESTÁ CADASTRADA');
               V_ERRO := 4;
              EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                    -- NÃO ENCONTROU PODE INSERIR A CIDADE
                    LIN_CITY.GEOGRAPHY_NAME        := V_CITY;
                    LIN_CITY.GEOGRAPHY_CODE        := substr(V_CITY,1,30);
                    
                 WHEN TOO_MANY_ROWS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'2.0 MAIS DE UMA CIDADE PARA O MESMO ESTADO. CIDADE= '||LIN_CITY.GEOGRAPHY_CODE||' ESTADO= '||V_STATE);
                    V_ERRO := 2;
                 WHEN OTHERS THEN
                    fnd_file.put_line(FND_FILE.OUTPUT,'ERRO AO LOCALIZAR CIDADE '||LIN_CITY.GEOGRAPHY_CODE||' '||sqlerrm);
                    V_ERRO := 3;
            END;
            ---
            
            IF V_ERRO = 0 THEN
               apps.HZ_GEOGRAPHY_PUB.CREATE_MASTER_GEOGRAPHY(apps.FND_API.G_TRUE
                                                            ,LIN_CITY
                                                            ,X_GEOGRAPHY_ID
                                                            ,X_RETURN_STATUS
                                                            ,X_MSG_COUNT
                                                            ,X_MSG_DATA);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_RETURN_STATUS ='||X_RETURN_STATUS);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_MSG_COUNT ='||X_MSG_COUNT);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'X_MSG_DATA ='||X_MSG_DATA);
               IF X_RETURN_STATUS != APPS.FND_API.G_RET_STS_SUCCESS THEN
                  ---
                  FOR COUNTER IN REVERSE 1..X_MSG_COUNT
                  LOOP
                     ---
                     BEGIN
                        V_ERRO := APPS.FND_MSG_PUB.GET(P_MSG_INDEX    => APPS.FND_MSG_PUB.G_LAST,
                                                       P_ENCODED      => APPS.FND_API.G_FALSE);
                        EXCEPTION
                           WHEN OTHERS THEN  NULL;
                     END;
                     ---
                  END LOOP;
                  ---
                  APPS.FND_MSG_PUB.DELETE_MSG;
                  ROLLBACK;
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'V_ERRO ='||V_ERRO);
                  dbms_output.put_line(' '||V_ERRO);
                  dbms_output.put_line('----------------------------------------');
               ELSE
                  ---
                  -- TUDO OK, COMITA CIDADE
                  commit;
                  ---
               END IF;
            ELSE
               ---
               fnd_file.put_line(FND_FILE.OUTPUT,'CIDADE '||LIN_STATE.GEOGRAPHY_CODE||' NÃO CARREGADA');
            END IF;
            ---
         END LOOP;
         ---
      -- end 04/08/2020 -- TICKET: 323082 - #SR-552236 
      ELSE  -- SAIDA DE ESTADO/CIDADE/CEP E ENDEREÇO
         fnd_file.put_line(FND_FILE.OUTPUT,'HIERARQUIA NÃO PREVISTA');
      END IF;
      ---
      COMMIT;
      RETURN('OK');
      ---
   END CRIA_ENTIDADE_EXT;
   ---
   --------------------------------------------------------------------------------
   ---
   FUNCTION INSERIR_CRP_REF (TIPO VARCHAR2) RETURN VARCHAR2 AS
      ---
      L_GEO_IDENTIFIER_REC        APPS.HZ_GEOGRAPHY_PUB.GEO_IDENTIFIER_REC_TYPE;
      V_ERRO                      NUMBER;
      V_STATE                     apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      V_CITY                      apps.HZ_GEOGRAPHIES.GEOGRAPHY_CODE%TYPE;
      X_GEOGRAPHY_ID              NUMBER;
      V_START_DATE_CITY           DATE;
      V_END_DATE_CITY             DATE;
      V_INSERT                    NUMBER;
      x_return_status             VARCHAR2(80);
      x_msg_count                 NUMBER;
      x_msg_data                  VARCHAR2(240);
      --
      CURSOR C_UF_CITY(TP VARCHAR2) IS
         SELECT * FROM (
            SELECT DISTINCT PAIS, UF, COD_UF_R11, NULL CIDADE,NULL COD_CIDADE_R11
              FROM XXSTN_AR_LOCALIDADES_IBGE  UF
             WHERE TP = 'STATE'
             AND  NOT EXISTS (SELECT 'X'
                             FROM APPS.HZ_GEOGRAPHY_IDENTIFIERS HGI
                                 ,APPS.HZ_GEOGRAPHIES           ST
                                 ,APPS.HZ_GEOGRAPHIES           PA
                             WHERE HGI.GEOGRAPHY_ID       = ST.GEOGRAPHY_ID
                             AND   HGI.IDENTIFIER_SUBTYPE = 'CRP_REF'
                             AND   HGI.IDENTIFIER_VALUE   = TO_CHAR(UF.COD_UF_R11)
                             and   PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                             AND   PA.GEOGRAPHY_CODE      = 'BR'
                             AND   PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                             AND   ST.GEOGRAPHY_TYPE      = 'STATE'
                             AND   TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                             AND   TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                             AND   ST.GEOGRAPHY_CODE      = UF.UF )
            UNION ALL
            SELECT PAIS, UF, COD_UF_R11, CIDADE, COD_CIDADE_R11
              FROM XXSTN_AR_LOCALIDADES_IBGE  CT
             WHERE TP = 'CIDADE'
               AND NOT EXISTS ( SELECT 'X'
                                  FROM APPS.HZ_GEOGRAPHY_IDENTIFIERS HGI
                                      ,APPS.HZ_GEOGRAPHIES           ST
                                      ,APPS.HZ_GEOGRAPHIES           PA
                                      ,APPS.HZ_GEOGRAPHIES           CI
                                 WHERE PA.GEOGRAPHY_TYPE      = 'COUNTRY'
                                   AND PA.GEOGRAPHY_CODE      = 'BR'
                                   AND PA.GEOGRAPHY_ID        = ST.GEOGRAPHY_ELEMENT1_ID
                                   AND ST.GEOGRAPHY_TYPE      = 'STATE'
                                   AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
                                   AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
                                   AND ST.GEOGRAPHY_ID        = CI.GEOGRAPHY_ELEMENT2_ID
                                   AND CI.GEOGRAPHY_TYPE      = 'CITY'
                                   AND TRUNC(SYSDATE)         BETWEEN TRUNC(NVL(CI.START_DATE,SYSDATE)) AND TRUNC(NVL(CI.END_DATE,SYSDATE))
                                   AND ST.GEOGRAPHY_CODE      = CT.UF
                                   AND CI.GEOGRAPHY_CODE      = UPPER(TRANSLATE(SUBSTR(CT.CIDADE,1,30)
                                                              , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                              , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') )
                                   AND hgi.GEOGRAPHY_ID       = ci.GEOGRAPHY_ID
                                   AND hgi.IDENTIFIER_SUBTYPE = 'CRP_REF'
                                   AND HGI.IDENTIFIER_VALUE   =  TRIM(CT.COD_CIDADE_R11) )
                            )
         order by UF,cidade;
      ---
   BEGIN
      ---
      L_GEO_IDENTIFIER_REC.IDENTIFIER_TYPE      := 'CODE';
      L_GEO_IDENTIFIER_REC.IDENTIFIER_SUBTYPE   := 'CRP_REF';
      L_GEO_IDENTIFIER_REC.CREATED_BY_MODULE    := 'TCA_V2_API';
      V_STATE                                   := NULL;
      V_CITY                                    := NULL;
      --
      FOR I IN C_UF_CITY(TIPO) LOOP
         --
         V_ERRO :=0;
         --
         V_STATE := UPPER(TRANSLATE(I.UF
                          , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                          , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') );
         IF TIPO = 'CIDADE' THEN
            V_CITY  := SUBSTR(UPPER(TRANSLATE(I.CIDADE, 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                                                      , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ) ,1,30);
         END IF;
         ----------------
         -- LOCALIZAR O ESTADO
         ----------------
         BEGIN
            SELECT ST.GEOGRAPHY_ID
              INTO  x_geography_id
              FROM apps.HZ_GEOGRAPHIES ST
                  ,apps.HZ_GEOGRAPHIES PA
             WHERE PA.GEOGRAPHY_TYPE = 'COUNTRY'
               AND PA.GEOGRAPHY_CODE = 'BR'
               AND PA.GEOGRAPHY_ID   = ST.GEOGRAPHY_ELEMENT1_ID
               AND ST.GEOGRAPHY_TYPE = 'STATE'
               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(PA.START_DATE,SYSDATE)) AND TRUNC(NVL(PA.END_DATE,SYSDATE))
               AND TRUNC(SYSDATE)    BETWEEN TRUNC(NVL(ST.START_DATE,SYSDATE)) AND TRUNC(NVL(ST.END_DATE,SYSDATE))
               AND ST.GEOGRAPHY_CODE = V_STATE;
           EXCEPTION
              WHEN NO_DATA_FOUND THEN
                 fnd_file.put_line(FND_FILE.OUTPUT,'NÃO ENCONTRADO O ESTADO DE '||V_STATE);
                 V_ERRO := 1;
              WHEN OTHERS THEN
                 fnd_file.put_line(FND_FILE.OUTPUT,'ERRO NÃO TRATADO PARA LOCALIZAR ESTADO '||V_STATE||' '||sqlerrm);
                V_ERRO := 1;
         END;
         ---------------------
         IF TIPO = 'CIDADE' THEN
            IF V_ERRO = 0 THEN
               ----------------------------------------
               -- Verifica se cidade não existe
               ----------------------------------------
               BEGIN
                  SELECT ST.START_DATE,ST.END_DATE,ST.GEOGRAPHY_ID
                    INTO V_START_DATE_CITY,V_END_DATE_CITY,X_GEOGRAPHY_ID
                    FROM apps.HZ_GEOGRAPHIES ST
                   WHERE GEOGRAPHY_TYPE = 'CITY'
                     AND GEOGRAPHY_ELEMENT2_ID  = to_char(x_geography_id)
                     AND (   (upper(translate(GEOGRAPHY_CODE
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))
                            = upper(translate(V_CITY
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ') ))
                          OR (upper(
                          translate(GEOGRAPHY_NAME
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       '))

                          = upper(translate(V_CITY
                            , 'ãÃõÕçÇüÜâÂêÊôÔáÁàÀéÉíÍóÓúÚ!@#$%&*()_+=[]{}/\?:<>|'
                            , 'aAoOcCuUaAeEoOaAaAeEiIoOuU                       ')))
                         );
                   EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        fnd_file.put_line(FND_FILE.OUTPUT,'1.0 CIDADE NÃO ENCONTRADA. CIDADE= '||V_CITY||' ESTADO= '||V_STATE||' ID GEOGRAFIA= '||to_char(x_geography_id));
                        V_ERRO := 1;
                      WHEN TOO_MANY_ROWS THEN
                        fnd_file.put_line(FND_FILE.OUTPUT,'1.0 - MAIS DE UMA CIDADE PARA O MESMO ESTADO. CIDADE= '||V_CITY||' ESTADO= '||V_STATE);
                        V_ERRO := 2;
                      WHEN OTHERS THEN
                        fnd_file.put_line(FND_FILE.OUTPUT,'ERRO AO LOCALIZAR CIDADE '||V_CITY||' ESTADO= '||V_STATE||' '||sqlerrm);
                        V_ERRO := 3;
               END;
               ---
            END IF;
            ---
         END IF;
         --
         IF V_ERRO = 0 THEN
            ---
            if tipo = 'ESTADO' THEN
               ---
               V_INSERT := 0;
               SELECT COUNT(*) INTO   V_INSERT
                 FROM APPS.hz_geography_identifiers
                WHERE GEOGRAPHY_ID       = x_geography_id
                  AND IDENTIFIER_SUBTYPE = 'CRP_REF'
                  AND IDENTIFIER_VALUE   = I.COD_UF_R11;
               IF V_INSERT != 0 THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO DO CORPORATIVO JÁ INSERIDO PARA O ESTADO= '||V_STATE);
                  V_ERRO := 5;
               END IF;
               ---
            elsif tipo = 'CIDADE' then
               ---
               V_INSERT := 0;
               SELECT COUNT(*) INTO   V_INSERT
                 FROM APPS.hz_geography_identifiers
                WHERE GEOGRAPHY_ID       = X_GEOGRAPHY_ID
                  AND IDENTIFIER_SUBTYPE = 'CRP_REF'
                  AND IDENTIFIER_VALUE   = I.COD_CIDADE_R11;
               ---
               IF V_INSERT != 0 THEN
                  fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO DO CORPORATIVO JÁ INSERIDO PARA A CIDADE= '||V_CITY||' ESTADO= '||V_STATE||' CODIGO= '||to_char(I.COD_CIDADE_R11));
                  V_ERRO := 5;
               END IF;
               ---
            else
               ---
               V_ERRO := 6;
               ---
            end if;
            ---
         END IF;
         --
         IF V_ERRO = 0 THEN
            ---
            l_geo_identifier_rec.geography_id         := x_geography_id;
            IF TIPO = 'CIDADE' THEN
               l_geo_identifier_rec.identifier_value     := I.COD_CIDADE_R11;
            ELSIF TIPO = 'ESTADO' THEN
               l_geo_identifier_rec.identifier_value     := I.COD_UF_R11;
            ELSE
               NULL;
            END IF;
            ---
            apps.HZ_GEOGRAPHY_PUB.create_geo_identifier(p_init_msg_list            => apps.FND_API.G_TRUE,
                                                        p_geo_identifier_rec      => l_geo_identifier_rec,
                                                        x_return_status           => x_return_status,
                                                        x_msg_count               => x_msg_count,
                                                        x_msg_data                => x_msg_data);
            fnd_file.put_line(FND_FILE.OUTPUT,'  '||X_MSG_DATA);
            ---
         ELSE
            ---
            if tipo = 'ESTADO' then
               fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO DO CORPORATIVO NAO INCLUIDO '||I.COD_UF_R11);
            elsif  tipo = 'CIDADE' then
               fnd_file.put_line(FND_FILE.OUTPUT,'CODIGO DO CORPORATIVO NAO INCLUIDO '||I.COD_CIDADE_R11);
            else
               null;
            end if;
            ---
         END IF;
         ---
      end loop;
      ---
      RETURN('ok');
      ---
   END INSERIR_CRP_REF;
   ---
END;
/