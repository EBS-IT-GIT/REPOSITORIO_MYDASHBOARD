UPDATE apps.zx_party_tax_profile
SET    rep_registration_number = DECODE(party_id
                                       ,11022122, '180224090016'
                                       ,11022253, '180104670015'
                                       ,rep_registration_number)
WHERE  supplier_flag ='Y'
AND    party_id IN (SELECT party_id
                    FROM   apps.hz_parties
                    WHERE  party_name IN ('CB Agro SRL', 'Marcelo Gustavo Vico Ferrando'));
--2 Registros