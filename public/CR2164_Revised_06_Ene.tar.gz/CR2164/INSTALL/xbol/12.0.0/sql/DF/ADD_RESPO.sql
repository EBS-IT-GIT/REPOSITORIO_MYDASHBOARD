  set define off;
BEGIN
   apps.fnd_program.add_to_group (program_short_name  => 'XXPOFLEPAS',
                                  program_application => 'Business Online',
                                  request_group       => 'XX PO Reports CHS',
                                  group_application   => 'Business Online'                            
                                 );  
  COMMIT;
  EXCEPTION
  WHEN no_data_found THEN
    dbms_output.put_line ('Error en incorporar concurrente al grupo de solicitud');
  END;
END;


exit
