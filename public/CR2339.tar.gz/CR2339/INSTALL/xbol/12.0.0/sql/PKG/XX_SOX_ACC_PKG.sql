  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_SOX_ACC_PKG" IS
  --P_CONC_REQUEST_ID      NUMBER;
  P_RESPONSIBILITY_NAME  VARCHAR2(255);
  P_RESPO_LIKE           VARCHAR2(255);


  FUNCTION BeforeReportTrigger RETURN BOOLEAN ;


  PROCEDURE Analisis_Respo_SOX ( p_errbuf      IN OUT NOCOPY VARCHAR2
                               , p_errcode     IN OUT NOCOPY VARCHAR2
                               , p__responsibility_name      VARCHAR2
                               , p__respo_like               VARCHAR2
                               );

END XX_SOX_ACC_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_SOX_ACC_PKG" IS

  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);

  FUNCTION xml_escape_chars ( p_data VARCHAR2 ) RETURN VARCHAR IS
    l_data VARCHAR2(32767);
  BEGIN
    l_data := REPLACE(REPLACE(REPLACE(p_data, '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
    RETURN l_data;
  END xml_escape_chars;


  FUNCTION BeforeReportTrigger RETURN boolean IS
    errbuf varchar2(200);
    retcode number;
  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '--------------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX Analisis SOX - Responsabilidad - Menu - Funcion');
    FND_FILE.Put_Line(FND_FILE.Log, '--------------------------------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    fnd_file.put_line(fnd_file.log, 'P_RESPO_LIKE = '||P_RESPO_LIKE);
    fnd_file.put_line(fnd_file.log, 'P_RESPONSIBILITY_NAME = '||P_RESPONSIBILITY_NAME);

    XX_ANALISIS_SOX.xx_respo_menu_function (errbuf,
                                            retcode,
                                            P_RESPONSIBILITY_NAME,
                                            P_RESPO_LIKE);

    FND_FILE.Put_Line(FND_FILE.Log,  'errbuf = '||errbuf);

    RETURN(TRUE);
  END BeforeReportTrigger;


  PROCEDURE Analisis_Respo_SOX ( p_errbuf      IN OUT NOCOPY VARCHAR2
                               , p_errcode     IN OUT NOCOPY VARCHAR2
                               , p__responsibility_name      VARCHAR2
                               , p__respo_like               VARCHAR2
                               ) IS

    CURSOR c1 IS
      SELECT xrmf.respo, xrmf.menu, xrmf.sequence, xrmf.orden, xrmf.nivel, fff.user_function_name
           , fmt.description MENU_DESC
           , fmt2.description SUB_MENU_DESC
           , fmt.user_menu_name MENU_NAME
           , fmt2.user_menu_name SUB_MENU_NAME
           , xrmf.function
           , xrmf.menu_id
           , xrmf.sub_menu_id
      FROM xx_respo_menu_func xrmf
         , ( SELECT ff.function_name, ff.user_function_name
             FROM fnd_form_functions_vl ff
           ) fff
         , fnd_menus_vl fmt
         , fnd_menus_vl fmt2
      WHERE 1=1
      AND fff.function_name = xrmf.function
      AND fmt2.menu_id(+)   = xrmf.sub_menu_id
      AND fmt.menu_id(+)    = xrmf.menu_id
      ORDER BY xrmf.respo,xrmf.orden;

    l_result     BOOLEAN;
    l_row_count  NUMBER;
    l_data       VARCHAR2(4000);
  BEGIN
    p_responsibility_name := p__responsibility_name;
    p_respo_like := p__respo_like;

    l_result := BeforeReportTrigger;

    --Significado Params--

    FND_FILE.Put_Line(FND_FILE.Output, 'XX Análisis SOX - Responsabilidad - Menú - Función');
    FND_FILE.Put_Line(FND_FILE.Output, ' ');
    FND_FILE.Put_Line(FND_FILE.Output, 'Responsabilidad:|'||P_RESPONSIBILITY_NAME);
    FND_FILE.Put_Line(FND_FILE.Output, 'Busqueda Selectiva con:|'||P_RESPO_LIKE);
    FND_FILE.Put_Line(FND_FILE.Output, ' ');
    FND_FILE.Put_Line(FND_FILE.Output, 'Orden|Nivel|Menu Desc|Sub Menu Desc|Respo|Menu|Function|Sequence|Menu Id|Sub Menu Id|Function Id');
    FOR r1 IN c1 LOOP
      l_data := r1.ORDEN
         ||'|'||r1.NIVEL
         --||'|'||r1.MENU_DESC CR2339
         ||'|'||nvl(r1.MENU_DESC, r1.MENU_NAME) --CR2339
         --||'|'||r1.SUB_MENU_DESC CR2339
         ||'|'||nvl(r1.SUB_MENU_DESC, r1.SUB_MENU_NAME) --CR2339
         ||'|'||r1.RESPO
         ||'|'||LTRIM(r1.MENU)
         ||'|'||r1.USER_FUNCTION_NAME
         ||'|'||r1.SEQUENCE
         ||'|'||r1.MENU_ID
         ||'|'||r1.SUB_MENU_ID
         ||'|'||r1.FUNCTION;

      l_row_count := c1%ROWCOUNT;

      FND_FILE.Put_Line(FND_FILE.Output, l_data);

    END LOOP;

    FND_FILE.Put_Line(FND_FILE.Log, l_row_count||' registros generados...');

  EXCEPTION
    WHEN OTHERS THEN
      p_errbuf  := SQLERRM;
      p_errcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, p_errbuf);
  END Analisis_Respo_SOX;

END XX_SOX_ACC_PKG;
/

exit
