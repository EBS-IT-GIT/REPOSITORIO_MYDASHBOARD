  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_SLA_ARG_FIN_PKG" IS

FUNCTION xx_po_number_rcv (p_rcv_trx_id NUMBER)
   RETURN VARCHAR2;

FUNCTION xx_po_number_inv (p_trx_id NUMBER)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_icp-------------------------------
--Funcion creada para determinar el segmento ICP de una entidad comercial         --
--                                                                                --
--Parametros                                                                      --
--p_party_id: Identificador de la entidad comercial que se desea analizar         --
----------------------------------------------------------------------------------*/
FUNCTION determinar_icp(p_entity_id hz_parties.party_id%TYPE
                       ,p_entity_code VARCHAR2)
   RETURN VARCHAR2;

/*----------------------------FUNCTION organization_id------------------------------
--Funcion creada para devolver el org_id de la organizacion de inventario en base --
--al codigo de organizacion                                                       --
--Parametros                                                                      --
--p_org_code: Codigo de la organizacion de inventario                             --
----------------------------------------------------------------------------------*/
FUNCTION determinar_org_id(p_org_code mtl_parameters.organization_code%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_account_class---------------------
--Funcion creada para determinar el GL Class de una cuenta de cliente que se      --
--recibe como parametro.                                                          --
--                                                                                --
--Parametros                                                                      --
--p_party_id: Identificador de la entidad comercial que se desea analizar         --
----------------------------------------------------------------------------------*/
FUNCTION determinar_account_class(p_cust_acct_id hz_cust_accounts_all.cust_account_id%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_circuito_ar-----------------------
--Funcion creada para determinar el circuito en el que se enmarca la transaccion  --
--de AR para poder determinar las cuentas de ese comprobante                      --
--                                                                                --
--Parametros                                                                      --
--p_customer_trx_id: Identificador de la transaccion que se desea analizar        --
----------------------------------------------------------------------------------*/
FUNCTION determinar_circuito_ar(p_customer_trx_id    ra_customer_trx_all.customer_trx_id%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_circuito_ap-----------------------
--Funcion creada para determinar el circuito en el que se enmarca la transaccion  --
--de AR para poder determinar las cuentas de ese comprobante                      --
--                                                                                --
--Parametros                                                                      --
--p_invioce_id: Identificador de la transaccion que se desea analizar             --
----------------------------------------------------------------------------------*/
FUNCTION determinar_circuito_ap(p_invoice_id ap_invoices_all.invoice_id%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_circuito_ap-----------------------
--Funcion creada para determinar el circuito en el que se enmarca la transaccion  --
--de AR para poder determinar las cuentas de ese comprobante                      --
--                                                                                --
--Parametros                                                                      --
--p_invioce_dist_id: Identificador de la distribucion que se desea analizar       --
----------------------------------------------------------------------------------*/
FUNCTION determinar_circuito_ap_dist(p_invoice_dist_id ap_invoices_all.invoice_id%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_tipo_cliente_cm-------------------
--Funcion creada para determinar el tipo de cliente para las notas de credito del --
--modulo de Cuentas por Cobrar                                                    --
--                                                                                --
--Parametros                                                                      --
--p_cust_account_id: Identificador de la cuenta del cliente que se desea analizar --
----------------------------------------------------------------------------------*/
FUNCTION determinar_cust_class_cm_ar(p_party_id hz_parties.party_id%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION determinar_gl_class--------------------------
--Funcion creada para determinar el gl_class de un articulo en base al deposito   --
--desde donde se lo esta despachando                                              --
--                                                                                --
--Parametros                                                                      --
--p_organization_code: Codigo de organizacion desde donde se despacha el articulo --
--p_inventory_item_id: Identificador del articulo despachado                      --
--p_return: Valor a retornar por la funcion                                       --
--          VALUE: Retorna el valor del GL_CLASS                                  --
--          ID: Retorna el identificador del GL_CLASS                             --
----------------------------------------------------------------------------------*/
FUNCTION determinar_gl_class(p_organization_code mtl_parameters.organization_code%TYPE
                            ,p_inventory_item_id mtl_system_items.inventory_item_id%TYPE
                            ,p_return            VARCHAR2)
  RETURN VARCHAR2;

/*----------------------------FUNCTION ap_determinar_gl_class-----------------------
--Funcion creada para determinar el gl_class de un articulo en base a la          --
--distribucion de la orden de compra                                              --
--                                                                                --
--Parametros                                                                      --
--p_po_distribution_id: Distribucion de la orden de compra que se desea analizar  --
----------------------------------------------------------------------------------*/
FUNCTION ap_determinar_gl_class(p_po_distribution_id NUMBER
                               ,p_return VARCHAR2)
   RETURN VARCHAR2;

FUNCTION ar_cuenta_pasivo_fc(p_segment VARCHAR2
                           , p_customer_trx_id NUMBER)
   RETURN VARCHAR2;

/*----------------------------FUNCTION desc_asientos_pa-----------------------------
--Funcion creada para recuperar el nombre del lote pre aprobado y la descripcion  --
--de la linea de la erogacion creada                                              --
--Parametros                                                                      --
--p_expenditure_item_id: Identificador de la erogacion generada en el lote        --
----------------------------------------------------------------------------------*/
FUNCTION desc_asientos_pa(p_expenditure_item_id pa_expenditure_items_all.expenditure_item_id%TYPE)
   RETURN VARCHAR2;

/*----------------------------FUNCTION rubro_recepcion_ap---------------------------
--Funcion creada para recuperar la categoria del articulo de una recepcion para   --
--determinar la cuenta de provision de Cuentas por Pagar                          --
--Parametros                                                                      --
--p_distribution_id: Identificador de la distribucion de la orden de compra       --
--asociada a la linea de la factura                                               --
----------------------------------------------------------------------------------*/
FUNCTION rubro_recepcion_ap (p_distribution_id NUMBER)
   RETURN VARCHAR2;

/*----------------------------FUNCTION tipo_anticipo_aplicado_ap--------------------
--Funcion creada para recuperar el tipo de anticipo aplicado a una OC para        --
--determinar la cuenta de anticipo de Cuentas por Pagar                           --
--Parametros                                                                      --
--p_transaction_id: Identificador de la recepcion de la orden de compra           --
----------------------------------------------------------------------------------*/
FUNCTION tipo_anticipo_aplicado_ap (p_transaction_id NUMBER)
   RETURN VARCHAR2;

/*----------------------------FUNCTION tipo_cbte_aplicado_ap------------------------
--Funcion creada para recuperar el tipo de comprobante aplicado a una OC para     --
--determinar la cuenta de anticipo de Cuentas por Pagar                           --
--Parametros                                                                      --
--p_transaction_id: Identificador de la recepcion de la orden de compra           --
----------------------------------------------------------------------------------*/
FUNCTION tipo_cbte_aplicado_ap (p_transaction_id NUMBER)
   RETURN VARCHAR2;

/*----------------------------FUNCTION tipo_anticipo_aplicado_ap--------------------
--Funcion creada para recuperar el tipo de proveedor de una recepcion             --
--Parametros                                                                      --
--p_transaction_id: Identificador de la recepcion de la orden de compra           --
----------------------------------------------------------------------------------*/
FUNCTION tipo_prov_recepcion (p_transaction_id NUMBER)
    RETURN VARCHAR2 ;

END XX_SLA_ARG_FIN_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_SLA_ARG_FIN_PKG" IS

FUNCTION xx_po_number_rcv (p_rcv_trx_id NUMBER)
RETURN VARCHAR2 IS


l_purchase_order varchar2(30);

   BEGIN

    select pha.segment1
    into   l_purchase_order
    from   rcv_transactions rt,
           po_headers_all pha
    where  rt.transaction_id = p_rcv_trx_id
    and    rt.po_header_id = pha.po_header_id;

    return l_purchase_order;

   EXCEPTION WHEN OTHERS THEN

    return null;

   END xx_po_number_rcv;

--------------------------------------------------------------------------------

FUNCTION xx_po_number_inv (p_trx_id NUMBER)
RETURN VARCHAR2 IS


l_purchase_order varchar2(30);

   BEGIN

    select pha.segment1
    into   l_purchase_order
    from   mtl_material_transactions mmt,
           po_headers_all pha
    where  mmt.transaction_id = p_trx_id
    and    mmt.transaction_source_id = pha.po_header_id;

    return l_purchase_order;

   EXCEPTION WHEN OTHERS THEN

    return null;

   END xx_po_number_inv;

--------------------------------------------------------------------------------

FUNCTION determinar_icp(p_entity_id hz_parties.party_id%TYPE
                       ,p_entity_code VARCHAR2)
   RETURN VARCHAR2 IS

   l_icp VARCHAR2(3) := null;
   l_party_id hz_parties.party_id%TYPE;

   BEGIN

      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_ICP', 'p_entity_id: '||p_entity_id);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_ICP', 'p_entity_code: '||p_entity_code);
      END IF;

      IF p_entity_code = 'SITE_USE_ID' THEN
         SELECT hp.party_id
         INTO   l_party_id
         FROM   hz_cust_site_uses_all hcsu
               ,hz_cust_acct_sites_all hcas
               ,hz_cust_accounts hca
               ,hz_parties hp
         WHERE  hca.party_id           = hp.party_id
         AND    hcas.cust_account_id   = hca.cust_account_id
         AND    hcsu.cust_acct_site_id = hcas.cust_acct_site_id
         AND    site_use_id = p_entity_id;

      ELSIF p_entity_code = 'VENDOR_SITE_ID' THEN

        SELECT asp.party_id
         INTO  l_party_id
        FROM apps.ap_suppliers asp,
             apps.ap_supplier_sites_all ass
        WHERE asp.vendor_id = ass.vendor_id
          AND ass.vendor_site_id = p_entity_id;

      ELSE
         l_party_id :=p_entity_id;
      END IF;

      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_ICP', 'l_party_id: '||l_party_id);
      END IF;

      SELECT xx_sla_icp
      INTO   l_icp
      FROM   hz_parties_dfv hp_dfv
            ,hz_parties hp
      WHERE  hp.rowid    = hp_dfv.row_id
      AND    hp.party_id = l_party_id;

      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_ICP', 'l_icp: '||l_icp);
      END IF;

      RETURN l_icp;

   EXCEPTION
      WHEN OTHERS THEN
         IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_ICP', 'Error General: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
         END IF;
         RETURN null;
   END determinar_icp;

FUNCTION determinar_circuito_ar(p_customer_trx_id    ra_customer_trx_all.customer_trx_id%TYPE)
   RETURN VARCHAR2 IS

   l_circuito VARCHAR2(100):= 'OTRO';

   BEGIN
      BEGIN
         SELECT 'INTERESES'
         INTO   l_circuito
         FROM   dual
         WHERE  EXISTS (SELECT 1
                        FROM   ar_memo_lines_all_tl aml_tl
                             , ra_customer_trx_lines_all rctl
                        WHERE aml_tl.name          = 'Intereses Cobrados - GRAVADO'
                        AND   aml_tl.language      = 'ESA'
                        AND   rctl.org_id          = aml_tl.org_id
                        AND   rctl.memo_line_id    = aml_tl.memo_line_id
                        AND   rctl.customer_trx_id = p_customer_trx_id);

         RETURN l_circuito;
      EXCEPTION WHEN OTHERS THEN
         null;
      END;

      BEGIN
         SELECT 'ARRENDAMIENTO'
         INTO   l_circuito
         FROM   dual
         WHERE  EXISTS (SELECT 1
                        FROM   ar_memo_lines_all_tl aml_tl
                             , ra_customer_trx_lines_all rctl
                        WHERE  UPPER(aml_tl.name) LIKE '%ARRENDAMIENTO%'
                        AND    aml_tl.language       = 'ESA'
                        AND    rctl.org_id           =  aml_tl.org_id
                        AND    rctl.memo_line_id     =  aml_tl.memo_line_id
                        AND    rctl.customer_trx_id  =  p_customer_trx_id);
         RETURN l_circuito;

      EXCEPTION WHEN OTHERS THEN
         null;

      END;

      RETURN l_circuito;

   EXCEPTION WHEN OTHERS THEN
      RETURN l_circuito;

   END determinar_circuito_ar;


FUNCTION determinar_org_id(p_org_code mtl_parameters.organization_code%TYPE)
   RETURN VARCHAR2 IS

   l_organization_id mtl_parameters.organization_id%TYPE;

   BEGIN
      SELECT organization_id
      INTO   l_organization_id
      FROM   mtl_parameters
      WHERE  organization_code = p_org_code;

      RETURN l_organization_id;

   EXCEPTION WHEN OTHERS THEN
      RETURN null;
   END;

FUNCTION determinar_account_class(p_cust_acct_id hz_cust_accounts_all.cust_account_id%TYPE)
   RETURN VARCHAR2 IS

   l_account_class VARCHAR2(50);

   BEGIN
      SELECT xx_opm_customer_class
      INTO   l_account_class
      FROM   hz_cust_accounts_all hca
            ,hz_cust_accounts_dfv hca_dfv
      WHERE  hca.rowid = hca_dfv.row_id
      AND    hca.cust_account_id = p_cust_acct_id;

   RETURN l_account_class;

   EXCEPTION
    WHEN OTHERS THEN
      RETURN null;

   END;

FUNCTION determinar_circuito_ap(p_invoice_id ap_invoices_all.invoice_id%TYPE)
   RETURN VARCHAR2 IS

   l_circuito VARCHAR2(100):= 'OTRO';
   l_dias_plazo NUMBER;

   BEGIN
      SELECT flv_dfv.xx_ap_sla_circuito
            ,ai.terms_date - ai.invoice_date
      INTO   l_circuito
            ,l_dias_plazo
      FROM   ap_invoices_all ai
            ,ap_invoices_all2_dfv ai_dfv
            ,fnd_lookup_values    flv
            ,fnd_lookup_values_dfv flv_dfv
      WHERE  flv.rowid                         = flv_dfv.row_id
      AND    ai_dfv.legal_transaction_category = flv.lookup_code
      AND    flv.language                      = userenv('LANG')
      AND    flv.lookup_type                   = 'JLAR_LEGAL_TRX_CATEGORY'
      AND    ai.rowid                          = ai_dfv.row_id
      AND    ai.invoice_id                     = p_invoice_id;

      IF l_circuito = 'ARRENDAMIENTOS' AND l_dias_plazo >=365 THEN
         l_circuito := 'OTRO';
      END IF;

      RETURN l_circuito;

   EXCEPTION WHEN OTHERS THEN
      RETURN l_circuito;

   END determinar_circuito_ap;

FUNCTION determinar_circuito_ap_dist(p_invoice_dist_id ap_invoices_all.invoice_id%TYPE)
   RETURN VARCHAR2 IS
   l_circuito VARCHAR2(100):= 'OTRO';

   BEGIN
      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_CIRCUITO_AP_DIST', 'p_invoice_dist_id: '||p_invoice_dist_id);
      END IF;

      SELECT flv_dfv.xx_ap_sla_circuito
      INTO   l_circuito
      FROM   apps.ap_invoice_distributions_all aid
            ,apps.ap_invoice_distributions_a_dfv aid_dfv
            ,fnd_lookup_values    flv
            ,fnd_lookup_values_dfv flv_dfv
      WHERE  flv.rowid                         = flv_dfv.row_id
      AND    flv.language                      = userenv('LANG')
      AND    aid_dfv.xx_ap_legal_trans_category = flv.lookup_code
      AND    aid.rowid = aid_dfv.row_id
      AND    aid.invoice_distribution_id = p_invoice_dist_id;

      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_CIRCUITO_AP_DIST', 'l_circuito: '||l_circuito);
      END IF;

      RETURN l_circuito;

   EXCEPTION WHEN OTHERS THEN
      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_CIRCUITO_AP_DIST', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
      END IF;

      RETURN l_circuito;

   END determinar_circuito_ap_dist;

FUNCTION determinar_cust_class_cm_ar(p_party_id hz_parties.party_id%TYPE)
   RETURN VARCHAR2 IS

   l_cust_class_cm_ar hz_cust_accounts.customer_class_code%TYPE := null;

   BEGIN

      SELECT customer_class_code
      INTO   l_cust_class_cm_ar
      FROM   hz_cust_accounts
      WHERE  party_id = p_party_id;

      RETURN l_cust_class_cm_ar;

   EXCEPTION WHEN OTHERS THEN
      RETURN 'OTRO';

   END;

FUNCTION determinar_gl_class(p_organization_code mtl_parameters.organization_code%TYPE
                            ,p_inventory_item_id mtl_system_items.inventory_item_id%TYPE
                            ,p_return            VARCHAR2)
  RETURN VARCHAR2 IS

  l_category_set_id mtl_default_category_sets.category_set_id%TYPE;
  l_return            mtl_categories.segment1%TYPE :=null;

   BEGIN
      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_GL_CLASS', 'p_organization_code: '||p_organization_code);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_GL_CLASS', 'p_inventory_item_id: '||p_inventory_item_id);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_GL_CLASS', 'p_return: '||p_return);
      END IF;

      SELECT mdc.category_set_id
      INTO   l_category_set_id
      FROM   apps.mtl_default_category_sets mdc
            ,apps.fnd_lookup_values         flv
      WHERE  flv.lookup_code       = mdc.functional_area_id
      AND    flv.lookup_type       = 'MTL_FUNCTIONAL_AREAS'
      AND    flv.language          = 'US'
      AND    flv.meaning           = 'Process GL Class';

      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_GL_CLASS', 'l_category_set_id: '||l_category_set_id);
      END IF;

      l_return :=XX_SLA_ARG_UTIL_PKG.determinar_inv_cat(p_organization_code => p_organization_code
                                                      , p_inventory_item_id => p_inventory_item_id
                                                      , p_category_set_id => l_category_set_id
                                                      , p_return => p_return);
     RETURN l_return;

     EXCEPTION WHEN OTHERS THEN
       IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'DETERMINAR_GL_CLASS', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
       END IF;

       RETURN null;

   END;

FUNCTION ap_determinar_gl_class(p_po_distribution_id NUMBER
                               ,p_return VARCHAR2)
   RETURN VARCHAR2 IS

l_organization_code mtl_parameters.organization_code%TYPE;
l_item_id           po_lines_all.item_id%TYPE;
l_return            mtl_categories.segment1%TYPE :=null;

BEGIN
    IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AP_DETERMINAR_GL_CLASS', 'p_po_distribution_id: '||p_po_distribution_id);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AP_DETERMINAR_GL_CLASS', 'p_return: '||p_return);
    END IF;

   SELECT mp.organization_code
        , pl.item_id
   INTO   l_organization_code
         ,l_item_id
   FROM   apps.po_distributions_all pd
         ,apps.po_line_locations_all pll
         ,apps.mtl_parameters mp
         ,apps.po_lines_all pl
   WHERE  pll.po_line_id              = pl.po_line_id
   AND    pll.ship_to_organization_id = mp.organization_id
   AND    pd.line_location_id         = pll.line_location_id
   AND    pd.po_distribution_id       = p_po_distribution_id;

   IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AP_DETERMINAR_GL_CLASS', 'l_organization_code: '||l_organization_code);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AP_DETERMINAR_GL_CLASS', 'l_item_id: '||l_item_id);
    END IF;

   l_return:= determinar_gl_class(l_organization_code,l_item_id,p_return);

   IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
      XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AP_DETERMINAR_GL_CLASS', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
   END IF;

   RETURN l_return;

   EXCEPTION WHEN OTHERS THEN
      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AP_DETERMINAR_GL_CLASS', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
      END IF;

    RETURN NULL;

END;

FUNCTION desc_asientos_pa(p_expenditure_item_id pa_expenditure_items_all.expenditure_item_id%TYPE)
   RETURN VARCHAR2 IS

   l_desc_out VARCHAR2(1000);

   BEGIN

      SELECT ' Origen: '||pei.transaction_source ||' - lote: '||pe.expenditure_group||' - comentario: '||ec.expenditure_comment origen
      INTO   l_desc_out
      FROM   pa_expenditure_items_all pei
            ,pa_expenditure_comments ec
            ,pa_expenditures_all pe
      WHERE  pe.expenditure_id = pei.expenditure_id
      AND    pei.expenditure_item_id = ec.expenditure_item_id
      AND    pei.expenditure_item_id = p_expenditure_item_id;

      RETURN l_desc_out;

   EXCEPTION WHEN OTHERS THEN
      RETURN null;

   END;

FUNCTION ar_cuenta_pasivo_fc(p_segment VARCHAR2
                           , p_customer_trx_id NUMBER)
   RETURN VARCHAR2 IS

   l_return gl_code_combinations_kfv.segment2%TYPE;
   l_sql_stmt VARCHAR2(1000):= 'SELECT distinct('||p_segment||')
      FROM   ra_cust_trx_line_gl_dist_all rctl_gl
            ,xla_ae_headers xah
            ,xla_ae_lines xal
            ,gl_code_combinations_kfv gcc_kfv
      WHERE  xal.code_combination_id = gcc_kfv.code_combination_id
      AND    xal.accounting_class_code = ''RECEIVABLE''
      AND    xah.ae_header_id = xal.ae_header_id
      AND    rctl_gl.event_id = xah.event_id
      AND    rctl_gl.customer_trx_line_id IS NULL
      AND    rctl_gl.customer_trx_id= :1';

   BEGIN
      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AR_CUENTA_PASIVO_FC', 'p_customer_trx_id: '||p_customer_trx_id);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AR_CUENTA_PASIVO_FC', 'l_sql_stmt: '||l_sql_stmt);
      END IF;

      EXECUTE IMMEDIATE l_sql_stmt INTO l_return USING p_customer_trx_id;

      IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AR_CUENTA_PASIVO_FC', 'l_return: '||l_return);
      END IF;

      RETURN l_return;

   EXCEPTION WHEN OTHERS THEN
     IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
          XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AR_CUENTA_PASIVO_FC', 'p_customer_trx_id: '||p_customer_trx_id);
          XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AR_CUENTA_PASIVO_FC', 'l_sql_stmt: '||l_sql_stmt);
         XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
         XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'AR_CUENTA_PASIVO_FC', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
      END IF;

      RETURN -100;

   END;

FUNCTION rubro_recepcion_ap (p_distribution_id NUMBER)
    RETURN VARCHAR2 IS
    l_rubro VARCHAR2(10) :='00';

    BEGIN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate,'RUBRO_RECEPCION_AP','p_distribution_id: '||p_distribution_id);
        END IF;

        SELECT  nvl(mc.segment1,'00')
        INTO   l_rubro
        FROM   apps.mtl_categories mc
              ,apps.po_lines_all pl
              ,apps.po_distributions_all pd
        WHERE  pl.category_id        = mc.category_id
        AND    structure_id          = 101 --Identificador de la categoria de articulo de inventario
        AND    pd.po_line_id         = pl.po_line_id
        AND    pd.po_distribution_id = p_distribution_id;

        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate,'RUBRO_RECEPCION_AP','l_rubro: '||l_rubro);
        END IF;

        RETURN l_rubro;

    EXCEPTION
    WHEN OTHERS THEN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'RUBRO_RECEPCION_AP', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
        END IF;
    RETURN '00';

   END rubro_recepcion_ap;

FUNCTION tipo_anticipo_aplicado_ap (p_transaction_id NUMBER)
    RETURN VARCHAR2 IS
    l_return ap_invoices_v.prepayment_type_lookup_code%TYPE;
    BEGIN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
           XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_ANTICIPO_APLICADO_AP', 'p_transaction_id: '||p_transaction_id);
        END IF;

        SELECT DISTINCT DECODE(ai.earliest_settlement_date, '','PERMANENT', 'TEMPORARY')
        INTO   l_return
        FROM   rcv_transactions rt,
               ap_invoices_all ai,
               gmf_xla_extract_headers gxeh
        WHERE  gxeh.transaction_id  = p_transaction_id
        AND    gxeh.organization_id = rt.organization_id
        AND    gxeh.source_line_id  = rt.transaction_id
        AND    rt.po_header_id      = ai.po_header_id;

        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_ANTICIPO_APLICADO_AP', 'l_return: '||l_return);
        END IF;
        RETURN l_return;

    EXCEPTION
    WHEN OTHERS THEN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_ANTICIPO_APLICADO_AP', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
        END IF;
        RETURN 'TEMPORARY';

    END tipo_anticipo_aplicado_ap;

FUNCTION tipo_cbte_aplicado_ap (p_transaction_id NUMBER)
    RETURN VARCHAR2 IS
    l_return ap_invoices_all2_dfv.legal_transaction_category%TYPE;
    BEGIN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
           XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_CBTE_APLICADO_AP', 'p_transaction_id: '||p_transaction_id);
        END IF;

        SELECT ai_dfv.legal_transaction_category
        INTO   l_return
        FROM   rcv_transactions rt,
               ap_invoices_all ai,
               ap_invoices_all2_dfv ai_dfv,
               gmf_xla_extract_headers gxeh
        WHERE  gxeh.transaction_id  = p_transaction_id
        AND    gxeh.organization_id = rt.organization_id
        AND    gxeh.source_line_id  = rt.transaction_id
        AND    rt.po_header_id      = ai.po_header_id
        AND    ai.rowid             = ai_dfv.row_id;

        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_CBTE_APLICADO_AP', 'l_return: '||l_return);
        END IF;
        RETURN l_return;

    EXCEPTION
    WHEN OTHERS THEN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_ANTICIPO_APLICADO_AP', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
        END IF;
        RETURN null;

    END tipo_cbte_aplicado_ap;

FUNCTION tipo_prov_recepcion (p_transaction_id NUMBER)
    RETURN VARCHAR2 IS
    l_return ap_suppliers.vendor_type_lookup_code%TYPE;
    BEGIN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
           XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_PROV_RECEPCION', 'p_transaction_id: '||p_transaction_id);
        END IF;

        SELECT aps.vendor_type_lookup_code
        INTO   l_return
        FROM   rcv_transactions rt,
               ap_suppliers aps,
               gmf_xla_extract_headers gxeh
        WHERE  gxeh.transaction_id = p_transaction_id
        AND    gxeh.organization_id = rt.organization_id
        AND    gxeh.source_line_id = rt.transaction_id
        AND    rt.vendor_id = aps.vendor_id;

        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_PROV_RECEPCION', 'l_return: '||l_return);
        END IF;
        RETURN l_return;

    EXCEPTION
    WHEN OTHERS THEN
        IF XX_SLA_ARG_UTIL_PKG.g_debug_switch = 'Y' THEN
            XX_SLA_ARG_UTIL_PKG.g_sqlerrm := SUBSTR(sqlerrm,1,200);
            XX_SLA_ARG_UTIL_PKG.insert_debug(sysdate, 'TIPO_PROV_RECEPCION', 'g_sqlerrm: '||XX_SLA_ARG_UTIL_PKG.g_sqlerrm);
        END IF;
        RETURN null;

    END tipo_prov_recepcion;

END XX_SLA_ARG_FIN_PKG;
/

exit
