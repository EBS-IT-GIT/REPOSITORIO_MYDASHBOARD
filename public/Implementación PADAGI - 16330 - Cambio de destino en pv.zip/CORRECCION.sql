UPDATE apps.oe_order_headers_all ooh
SET    sold_to_org_id = 1511756, last_update_date = sysdate, last_updated_by = 2070
WHERE  header_id = 8451706 ;
--1 Registro