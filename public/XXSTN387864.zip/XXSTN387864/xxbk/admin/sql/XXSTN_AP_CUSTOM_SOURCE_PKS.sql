WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE APPS.XXSTN_AP_CUSTOM_SOURCE_PKG AS


  FUNCTION Get_Invoice_Num (p_invoice_pmt_id IN NUMBER)
  RETURN VARCHAR2;

  FUNCTION Get_Supplier_Info (p_invoice_pmt_id IN NUMBER)
  RETURN VARCHAR2;

  FUNCTION Get_CNPJ_Info (p_invoice_pmt_id IN NUMBER)
  RETURN VARCHAR2;

  FUNCTION get_ap_adto_aplic_nf_p(p_invoice_id IN NUMBER)
  RETURN VARCHAR2;

  FUNCTION get_ccusto_juros_nf_original(p_invoice_distribution_id IN NUMBER)
  RETURN VARCHAR2;
  
END XXSTN_AP_CUSTOM_SOURCE_PKG;
/

EXIT;
