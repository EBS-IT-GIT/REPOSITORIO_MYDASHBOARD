WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY APPS.XXSTN_AP_CUSTOM_SOURCE_PKG AS

  FUNCTION Get_Invoice_Num (p_invoice_pmt_id IN NUMBER)
  RETURN VARCHAR2
  AS

  BEGIN

  DECLARE
    v_invoice_num varchar2(50);
    BEGIN
      -- BUSCA O INVOICE_TYPE DA INVOICE
      SELECT INVOICE_NUM
      INTO v_invoice_num
      FROM AP_INVOICES_ALL
      WHERE INVOICE_ID = (select invoice_id
                          from ap_invoice_payments_all
                          where invoice_payment_id = p_invoice_pmt_id);

      RETURN v_invoice_num;

   END;
  END Get_Invoice_Num;


  FUNCTION Get_Supplier_Info (p_invoice_pmt_id IN NUMBER)
  RETURN VARCHAR2
  AS

  BEGIN

  DECLARE
    v_sup_info varchar2(240);
    BEGIN
      -- BUSCA OS DADOS DO FORNECEDOR PARA COLOCAR NO HISTÿRICO
      SELECT v.VENDOR_NAME
      INTO v_sup_info
      FROM AP_SUPPLIERS v,
           AP_SUPPLIER_SITES_ALL s
      WHERE s.VENDOR_SITE_ID = (SELECT VENDOR_SITE_ID FROM AP_INVOICES_ALL i
                                WHERE INVOICE_ID = (select invoice_id
                                                    from ap_invoice_payments_all
                                                    where invoice_payment_id = p_invoice_pmt_id))
      AND s.VENDOR_ID = v.VENDOR_ID;

      RETURN v_sup_info;

   END;
  END Get_Supplier_Info;

  FUNCTION Get_CNPJ_Info (p_invoice_pmt_id IN NUMBER)
  RETURN VARCHAR2
  AS

  BEGIN

  DECLARE
    v_sup_info varchar2(240);
    BEGIN
      -- BUSCA OS DADOS DO FORNECEDOR PARA COLOCAR NO HISTÿRICO
      SELECT s.GLOBAL_ATTRIBUTE10||s.GLOBAL_ATTRIBUTE11||s.GLOBAL_ATTRIBUTE12
      INTO v_sup_info
      FROM AP_SUPPLIERS v,
           AP_SUPPLIER_SITES_ALL s
      WHERE s.VENDOR_SITE_ID = (SELECT VENDOR_SITE_ID FROM AP_INVOICES_ALL i
                                WHERE INVOICE_ID = (select invoice_id
                                                    from ap_invoice_payments_all
                                                    where invoice_payment_id = p_invoice_pmt_id))
      AND s.VENDOR_ID = v.VENDOR_ID;

      RETURN v_sup_info;

   END;

  END Get_CNPJ_Info;


FUNCTION get_ap_adto_aplic_nf_p(p_invoice_id IN NUMBER) RETURN VARCHAR2 IS

  --
      v_nr_ap_adto_aplic_nf apps.ap_invoices_all.invoice_num%TYPE;

    BEGIN
      --
      BEGIN

 select f.invoice_num
INTO v_nr_ap_adto_aplic_nf
from ap_suppliers                 a
    ,ap_supplier_sites_all        b
    ,ap_invoices_all              c
    ,ap_invoice_distributions_all d
    ,ap_invoices_all              f
    ,ap_invoice_distributions_all g
where a.vendor_id              = c.vendor_id
and   b.vendor_site_id         = c.vendor_site_id
and   c.invoice_id             = d.invoice_id
and   d.prepay_distribution_id = g.invoice_distribution_id
and   d.line_type_lookup_code  = 'PREPAY'
and  (d.reversal_flag IS NULL OR d.reversal_flag = 'N')
and   g.invoice_id             = f.invoice_id
and   f.invoice_id             = p_invoice_id;

     RETURN v_nr_ap_adto_aplic_nf;

    EXCEPTION
        WHEN OTHERS THEN
          --
          v_nr_ap_adto_aplic_nf := NULL;
          --
      END;
     --
      RETURN(v_nr_ap_adto_aplic_nf);
      --
    END get_ap_adto_aplic_nf_p;

  FUNCTION get_ccusto_juros_nf_original (p_invoice_distribution_id IN NUMBER)
  RETURN VARCHAR2
  AS

  BEGIN

    declare
      v_ccusto apps.gl_code_combinations.segment5%type;
      v_ccusto_default apps.gl_code_combinations.segment5%type;
      v_prorate_int_inv_across_dists apps.ap_system_parameters_all.prorate_int_inv_across_dists%type;
    begin
      --
      begin
        select gcc.segment5
             , nvl(aspa.prorate_int_inv_across_dists,'N')
          into v_ccusto_default
             , v_prorate_int_inv_across_dists
          from apps.ap_invoice_distributions_all aida
             , apps.ap_system_parameters_all aspa
             , apps.gl_code_combinations_kfv gcc
         where 1 = 1
           and aida.invoice_distribution_id = p_invoice_distribution_id
           and aspa.interest_code_combination_id = gcc.code_combination_id
           and aida.org_id = aspa.org_id;
      exception
        when others then
          v_ccusto_default := '000000000';
          v_prorate_int_inv_across_dists := 'N';
      end;
      --
      for r1 in (select rownum linha
                      , aida_int.invoice_distribution_id
                      , air.*
                 from apps.ap_invoice_distributions_all aida_obj
                    , apps.ap_invoice_distributions_all aida_int
                    , apps.ap_invoice_relationships air
                where 1 = 1
                  and aida_obj.invoice_distribution_id = p_invoice_distribution_id
                  and aida_obj.invoice_id = aida_int.invoice_id
                  and aida_int.invoice_id = air.related_invoice_id
                  and v_prorate_int_inv_across_dists = 'Y'
                order 
                   by aida_int.invoice_distribution_id) loop
        --
        exit when v_ccusto is not null;
        --
        if r1.invoice_distribution_id = p_invoice_distribution_id then
          for r2 in (select rownum linha
                          , aida_orig.invoice_distribution_id 
                          , aida_orig.po_distribution_id
                       from apps.ap_invoice_distributions_all aida_orig
                      where 1 = 1
                       and aida_orig.invoice_id = r1.original_invoice_id
                       and aida_orig.line_type_lookup_code in ('ITEM', 'IPV','ACCRUAL')
                     order 
                        by aida_orig.invoice_distribution_id) loop
            --
            exit when v_ccusto is not null;
            --
            if r1.linha = r2.linha then
              if r2.po_distribution_id is not null then
                select gcc.segment5
                  into v_ccusto
                  from apps.po_distributions_all pda
                     , apps.gl_code_combinations_kfv gcc
                 where 1 = 1
                  and pda.po_distribution_id = r2.po_distribution_id
                  and pda.code_combination_id = gcc.code_combination_id;
              end if;
            end if;
          end loop;
        end if;
      end loop;
      --
      if v_ccusto is null then
        v_ccusto := v_ccusto_default;
      end if;
      --
      return(v_ccusto);
      --
    exception
      when others then
        v_ccusto := v_ccusto_default;
        return(v_ccusto);
    end;

  END get_ccusto_juros_nf_original;

END  XXSTN_AP_CUSTOM_SOURCE_PKG;
/

EXIT;
