WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY XXSTN_FA_DEPRE_REPORT_PKG as
-- +=================================================================+
-- |               Copyright (c) 2017 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | xxstn_fa_depre_report_pkg.pls                                   |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Projeto Stone Fenix                                           |
-- |                                                                 |
-- | CREATED BY   RODRIGO PERASSO 14/11/2017                         |
-- |                                                                 |
-- | UPDATED BY   RODRIGO PERASSO 14/11/2017                         |
-- |                                                                 |
-- |              Fernando Pavao - 3S               (14/08/2018)     |
-- |     Melhorias relatorio de depreciacao FA                       |
-- |                                                                 |
-- |              Fernando Pavao - 3S    30/10/2018                  |
-- |     Inclusao de condicao DATE_INEFFECTIVE na query principal    |
-- |                                                                 |
-- |              Theodoro Ramos - 3S    29/11/2018                  |
-- |     Utilização de tabelas temporárias e processos core.      |
-- |                                                                 |
-- |              ROGERIO FARTO (NINECON) - 01/11/2019               |
-- |              SR-361093 - NSD306980                              |
-- |     Inclus�o de coluna CANAL (atribuicao ativo)                 |
-- |                                                                 |
-- | UPDATED BY   ROGERIO FARTO 12/08/2020                           |
-- |              Tratamento para cria��o de nova aba a cada         |
-- |              1 milhao de linhas                                 |
-- |              #SR-558257 - NSD-323746                            |
-- +=================================================================+

    gv_debug_flag VARCHAR2(5) := 'Y';
    -----------------------
    PROCEDURE write_log
    (
      p_write_flag IN VARCHAR2
     ,p_message    IN VARCHAR2
    ) IS
      lv_current_timestamp VARCHAR2(35) := to_char(systimestamp, 'YYYY-MM-DD HH24:MI:SS.FF');
    BEGIN
      IF nvl(upper(substr(p_write_flag, 1, 1)), 'N') = 'Y'
      THEN
        fnd_file.put_line(fnd_file.log, lv_current_timestamp || ' :: ' || p_message);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END write_log;
    -----------------------
    PROCEDURE print_output
    (
      p_level   IN NUMBER
     ,p_message IN VARCHAR2
    ) IS
      ln_level        NUMBER := MOD(p_level, 10);
      lv_level_indent VARCHAR2(25) := '';
    BEGIN
      lv_level_indent := lpad(' ', 2 * ln_level, ' ');
      fnd_file.put_line(fnd_file.output, lv_level_indent || TRIM(p_message));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END print_output;
    -----------------------
    FUNCTION generate_xml_tag
    (
      p_data     IN VARCHAR2
     ,p_tag      IN VARCHAR2
     ,p_tag_type IN NUMBER DEFAULT gn_xml_tag_full
    ) RETURN VARCHAR2 IS
      lv_xml_tag VARCHAR2(32000);
    BEGIN
      IF p_tag_type = gn_xml_tag_full  THEN
          IF p_data IS NULL THEN
             lv_xml_tag := '<' || p_tag || ' />';
          ELSE
             lv_xml_tag := '<' || p_tag || '>' || dbms_xmlgen.convert(p_data) || '</' || p_tag || '>';
          END IF;
      ELSIF p_tag_type = gn_xml_tag_start THEN
          lv_xml_tag := '<' || p_tag || '>';
      ELSIF p_tag_type = gn_xml_tag_end  THEN
          lv_xml_tag := '</' || p_tag || '>';
      END IF;
      RETURN lv_xml_tag;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;
    END generate_xml_tag;
    -----------------------
    PROCEDURE print_xml_tag
    (
      p_data     IN VARCHAR2
     ,p_tag      IN VARCHAR2
     ,p_tag_type IN NUMBER DEFAULT gn_xml_tag_full
     ,p_level    IN NUMBER DEFAULT 0
    ) IS
    BEGIN
      print_output(p_level, generate_xml_tag(p_data, p_tag, p_tag_type));
    END print_xml_tag;
    -----------------------
    FUNCTION geog_ret_str(p_str in VARCHAR2,
                          p_pos in VARCHAR2,
                          p_del in VARCHAR2)  RETURN  VARCHAR2 is
    --
    l_str           VARCHAR2(2000) := p_str || p_del;
    l_pos1          NUMBER;
    l_pos2          NUMBER;
    --
    BEGIN
        IF p_pos = 1 THEN
           l_str := substr(l_str, 1, INSTR(l_str, p_del, 1,p_pos)-1 );
        ELSE
           l_pos1 := INSTR (l_str, p_del, 1, p_pos-1);
           l_pos2 := INSTR (l_str, p_del, 1, p_pos  );
           l_str  := substr(l_str, l_pos1+1, (l_pos2 - l_pos1) -1);
        END IF;
        --
        RETURN (l_str);
    END GEOG_RET_STR;
    --
    function special_character(p_texto IN VARCHAR2) return VARCHAR2
    is
    begin
       IF p_texto IS NOT NULL THEN
          return(REPLACE(CONVERT(p_texto,'US7ASCII', 'WE8DEC'),'??',' '));
       ELSE
          return(NULL);
       END IF;
    end;
    --
    procedure update_output(ERRBUF OUT VARCHAR2
                           ,RETCODE OUT NUMBER
                           ,p_file_name in varchar2
                           ,p_REQUEST_ID in number)
    is
      --PRAGMA AUTONOMOUS_TRANSACTION;
      v_directory_path varchar2(250);
    begin
       DBMS_LOCK.SLEEP (2);
       select directory_path
       into   v_directory_path
       from   dba_directories
       where  directory_name like 'XXSTN_HR_OUT';
       --
       update fnd_conc_req_outputs
       set    file_name = v_directory_path||'/'||p_file_name
       where  concurrent_request_id = p_REQUEST_ID;
       --
       COMMIT;
    end;
    --
    procedure manage_array(p_summary_in  IN l_Table,
                           p_summary_out IN OUT l_Table)
    is
        v_pos NUMBER;
    begin
        --
        FOR i IN 1..NVL(p_summary_out.LAST,-1) LOOP
          IF p_summary_in(1).CONTA_ATIVO||p_summary_in(1).CONTA_DEPR_ACUM||p_summary_in(1).CONTA_DESP_DEPR =
             p_summary_out(i).CONTA_ATIVO||p_summary_out(i).CONTA_DEPR_ACUM||p_summary_out(i).CONTA_DESP_DEPR THEN
               p_summary_out(i).FA_CUSTO             :=  nvl(p_summary_out(i).FA_CUSTO,0)           +  nvl(p_summary_in(1).FA_CUSTO,0) ;
               p_summary_out(i).DEPRECIACAO_MES   :=  nvl(p_summary_out(i).DEPRECIACAO_MES,0) +  nvl(p_summary_in(1).DEPRECIACAO_MES,0) ;
               p_summary_out(i).DEPRECIACAO_ANO   :=  nvl(p_summary_out(i).DEPRECIACAO_ANO,0) +  nvl(p_summary_in(1).DEPRECIACAO_ANO,0) ;
               p_summary_out(i).FA_DEPRECIACAO_ACUM  :=  nvl(p_summary_out(i).FA_DEPRECIACAO_ACUM,0) + nvl(p_summary_in(1).FA_DEPRECIACAO_ACUM,0);
               p_summary_out(i).VALOR_RESIDUAL    :=  nvl(p_summary_out(i).VALOR_RESIDUAL,0)  +  nvl(p_summary_in(1).VALOR_RESIDUAL,0)  ;
               --
               v_pos := i;
              EXIT;
          END IF;
        END LOOP;
        --
        IF v_pos IS NULL THEN
           v_pos := nvl(p_summary_out.LAST,0)+1;
           p_summary_out(v_pos) := p_summary_in(1);
        END IF;
    end;
    --
    procedure main(ERRBUF OUT VARCHAR2
                  ,RETCODE OUT NUMBER
                  ,P_FA_BOOK              IN VARCHAR2
                  ,P_PERIOD_NAME          IN VARCHAR2
                  ,P_CATEGORY             IN NUMBER
                  )
    is
    /* -- 3S - TRAMOS - 28/11/2018 - BEGIN
    CURSOR C_FA  (P_FA_BOOK     IN VARCHAR2 ,
                  P_PERIOD_NAME IN VARCHAR2 ,
                  P_CATEGORY    IN NUMBER
                  ) IS
    SELECT DISTINCT
           GCC.SEGMENT1                          EMPRESA,
           FC.DESCRIPTION                        CATEGORIA,
           CC1.SEGMENT4                          CONTA_ATIVO,
           FV1.DESCRIPTION                       DESC_CONTA_ATIVO,
           CC2.SEGMENT4                          CONTA_DEPR_ACUM,
           CC3.SEGMENT4                          CONTA_DESP_DEPR,
           GCC.SEGMENT5                          CENTRO_DE_CUSTO,
           FA.SERIAL_NUMBER                      NUMERO_SERIAL,
           FA.TAG_NUMBER                         ETIQUETA,
           FA.ASSET_NUMBER                       NUMERO_ATIVO,
           FA.DESCRIPTION                        HISTORICO,
           FIDV.INVOICE_NUMBER                   NOTA_FISCAL,
           FIDV.VENDOR_NAME                      FORNECEDOR,
           FB.DATE_PLACED_IN_SERVICE             DATA_ENTRADA,
           FB.LIFE_IN_MONTHS                     VIDA_UTIL,
           FDD.COST                              FA_CUSTO,
           (select sum(glb.begin_balance_dr) - sum(glb.begin_balance_cr) +
                      sum(glb.period_net_dr) - sum(glb.period_net_cr)
                 from gl.gl_balances          glb,
                      gl.gl_code_combinations gcc,
                      FA.fa_book_controls     fbc,
                      gl.gl_code_combinations gcc1,
                      gl.gl_ledgers           gl
                where 1 = 1
                  and glb.code_combination_id = gcc.code_combination_id
                  and glb.ledger_id = fbc.set_of_books_id
                  and gcc1.code_combination_id = fbc.flexbuilder_defaults_ccid
                  and gcc.segment1 = gcc1.segment1
                  and gcc.segment4 = CC1.SEGMENT4
                  and gl.ledger_id = glb.ledger_id
                  and gl.currency_code = glb.currency_code
                  and glb.period_name = P_PERIOD_NAME
                  and fbc.book_type_code = P_FA_BOOK) GL_CUSTO,
           --FDD.DEPRN_AMOUNT                      DEPRECIACAO_MES,     -- 3S - TRAMOS - 10/11/2018 - BEGIN
           --FDD.YTD_DEPRN                         DEPRECIACAO_ANO,
           CASE
            WHEN FDD.PERIOD_COUNTER < FDP.PERIOD_COUNTER THEN 0
            ELSE FDD.DEPRN_AMOUNT END            DEPRECIACAO_MES,
           CASE
            WHEN FDP.FISCAL_YEAR <> FDP1.FISCAL_YEAR THEN 0
            ELSE FDD.YTD_DEPRN END               DEPRECIACAO_ANO,       -- 3S - TRAMOS - 10/11/2018 - END
           (FDD.COST - FDD.DEPRN_RESERVE)        SALDO_A_DEPRECIAR,
           FDD.DEPRN_RESERVE                     FA_DEPRECIACAO_ACUM,
           (select sum(glb.begin_balance_dr) - sum(glb.begin_balance_cr) +
                    sum(glb.period_net_dr) - sum(glb.period_net_cr)
               from gl.gl_balances          glb,
                    gl.gl_code_combinations gcc,
                    FA.fa_book_controls     fbc,
                    gl.gl_code_combinations gcc1,
                    gl_ledgers              gl
              where 1 = 1
                and glb.code_combination_id = gcc.code_combination_id
                and glb.ledger_id = fbc.set_of_books_id
                and gcc1.code_combination_id = fbc.flexbuilder_defaults_ccid
                and gcc.segment1 = gcc1.segment1
                and gcc.segment4 = CC2.SEGMENT4
                and gl.ledger_id = glb.ledger_id
                and gl.currency_code = glb.currency_code
                and glb.period_name = P_PERIOD_NAME
                and fbc.book_type_code = P_FA_BOOK) GL_DEPRECIACAO_ACUM,
           FL.SEGMENT1||'.'||FL.SEGMENT2         LOCALIZACAO,
           FDD.PERIOD_COUNTER                    FDD_PERIOD_COUNTER,
           FDP1.PERIOD_NAME                      FDD_PERIOD_NAME,
           FDP.PERIOD_COUNTER                    FDP_PERIOD_COUNTER,
           FDP.PERIOD_NAME                       FDP_PERIOD_NAME,
           FA.ASSET_TYPE                         TIPO
    FROM   APPS.FA_ADDITIONS               FA,
           APPS.FA_BOOKS                   FB,
           APPS.FA_DISTRIBUTION_HISTORY    FDH,
           APPS.FA_TRANSACTION_HEADERS     FTH,  -- 3S - TRAMOS - 13/11/2018
           APPS.FA_LOCATIONS               FL,
           APPS.FND_FLEX_VALUES_VL         FV1,
           APPS.FND_FLEX_VALUES_VL         FV2,
           APPS.FND_FLEX_VALUES_VL         FV3,
           APPS.FA_DEPRN_DETAIL            FDD,
           APPS.FA_INVOICE_DETAILS_V       FIDV,
           APPS.FA_DEPRN_PERIODS           FDP,
           APPS.FA_DEPRN_PERIODS           FDP1,
           APPS.FA_CATEGORY_BOOKS          FCB,
           APPS.FA_CATEGORIES              FC,
           APPS.GL_CODE_COMBINATIONS       GCC,
           APPS.GL_CODE_COMBINATIONS       CC1,
           APPS.GL_CODE_COMBINATIONS       CC2,
           APPS.GL_CODE_COMBINATIONS       CC3
    WHERE  FA.ASSET_ID                     = FB.ASSET_ID
    AND    FA.ASSET_ID                     = FDH.ASSET_ID
    AND    FA.ASSET_ID                     = FDD.ASSET_ID
    AND    FA.ASSET_ID                     = FIDV.ASSET_ID (+)
    AND    FA.ASSET_CATEGORY_ID            = FCB.CATEGORY_ID
    AND    FB.ASSET_ID                     = FDD.ASSET_ID
    AND    FB.BOOK_TYPE_CODE               = FDD.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = FDH.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = FCB.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = FDP.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = P_FA_BOOK --'STONE_CORP'
    --AND    FB.DATE_INEFFECTIVE             IS NULL                            -- 3S - TRAMOS - 10/11/2018 - BEGIN
    --AND    FDH.DATE_INEFFECTIVE            IS NULL --ALT 3S 30/10/2018
    AND    NVL(FDP1.PERIOD_CLOSE_DATE,SYSDATE) BETWEEN FB.DATE_EFFECTIVE  AND NVL(FB.DATE_INEFFECTIVE,SYSDATE)
    AND    NVL(FDP1.PERIOD_CLOSE_DATE,SYSDATE) BETWEEN FDH.DATE_EFFECTIVE  AND NVL(FDH.DATE_INEFFECTIVE,SYSDATE)
    AND    NVL(FDP1.PERIOD_CLOSE_DATE,SYSDATE) >= FTH.TRANSACTION_DATE_ENTERED
    AND    ( NVL(FB.PERIOD_COUNTER_FULLY_RETIRED,999999999) >=  FDP.PERIOD_COUNTER
            OR FDP.FISCAL_YEAR = FDP1.FISCAL_YEAR)
    AND    FDH.TRANSACTION_HEADER_ID_IN    = FTH.TRANSACTION_HEADER_ID
    AND    FDH.DISTRIBUTION_ID             = FDD.DISTRIBUTION_ID                -- 3S - TRAMOS - 10/11/2018 - END
    AND    FDH.ASSET_ID                    = FDD.ASSET_ID
    AND    FDH.CODE_COMBINATION_ID         = GCC.CODE_COMBINATION_ID
    AND    FDH.LOCATION_ID                 = FL.LOCATION_ID
    AND    FDH.BOOK_TYPE_CODE              = FDD.BOOK_TYPE_CODE

    --AND    FDH.RETIREMENT_ID               IS NULL
    AND    FCB.ASSET_COST_ACCOUNT_CCID     = CC1.CODE_COMBINATION_ID
    AND    FA.ASSET_TYPE                   = 'CAPITALIZED' -- Alt 3S
    AND    FCB.RESERVE_ACCOUNT_CCID        = CC2.CODE_COMBINATION_ID
    AND    FCB.DEPRN_EXPENSE_ACCOUNT_CCID  = CC3.CODE_COMBINATION_ID
    AND    FCB.CATEGORY_ID                 = FC.CATEGORY_ID
    AND    FV1.FLEX_VALUE                  = CC1.SEGMENT4
    AND    FV1.FLEX_VALUE_SET_ID           = (SELECT FLEX_VALUE_SET_ID FROM APPS.FND_FLEX_VALUE_SETS
                                              WHERE FLEX_VALUE_SET_NAME = 'DLP_GL_CONTA_CONTABIL3')
    AND    FV2.FLEX_VALUE                  = CC2.SEGMENT4
    AND    FV3.FLEX_VALUE                  = CC3.SEGMENT4
    AND    FDD.PERIOD_COUNTER              = (SELECT MAX(FDD1.PERIOD_COUNTER)
                                              FROM   APPS.FA_DEPRN_DETAIL            FDD1
                                              WHERE  FDD1.ASSET_ID       = FDD.ASSET_ID
                                              AND    FDD1.BOOK_TYPE_CODE = FDD.BOOK_TYPE_CODE
                                              AND    FDD1.PERIOD_COUNTER <= FDP.PERIOD_COUNTER)
    AND    FDD.PERIOD_COUNTER              = FDP1.PERIOD_COUNTER
    AND    FDD.BOOK_TYPE_CODE              = FDP1.BOOK_TYPE_CODE
    AND    FDP.PERIOD_NAME                 = P_PERIOD_NAME --'OCT-17'
    AND    FA.ASSET_CATEGORY_ID            = NVL(P_CATEGORY, FA.ASSET_CATEGORY_ID)
    UNION
    SELECT DISTINCT
           GCC.SEGMENT1                          EMPRESA,
           FC.DESCRIPTION                        CATEGORIA,
           CC1.SEGMENT4                          CONTA_ATIVO,
           FV1.DESCRIPTION                       DESC_CONTA_ATIVO,
           CC2.SEGMENT4                          CONTA_DEPR_ACUM,
           CC3.SEGMENT4                          CONTA_DESP_DEPR,
           GCC.SEGMENT5                          CENTRO_DE_CUSTO,
           FA.SERIAL_NUMBER                      NUMERO_SERIAL,
           FA.TAG_NUMBER                         ETIQUETA,
           FA.ASSET_NUMBER                       NUMERO_ATIVO,
           FA.DESCRIPTION                        HISTORICO,
           FIDV.INVOICE_NUMBER                   NOTA_FISCAL,
           FIDV.VENDOR_NAME                      FORNECEDOR,
           FB.DATE_PLACED_IN_SERVICE             DATA_ENTRADA,
           FB.LIFE_IN_MONTHS                     VIDA_UTIL,
           FDD.COST                              FA_CUSTO,
           (select sum(glb.begin_balance_dr) - sum(glb.begin_balance_cr) +
                      sum(glb.period_net_dr) - sum(glb.period_net_cr)
                 from gl.gl_balances          glb,
                      gl.gl_code_combinations gcc,
                      FA.fa_book_controls     fbc,
                      gl.gl_code_combinations gcc1,
                      gl_ledgers              gl
                where 1 = 1
                  and glb.code_combination_id = gcc.code_combination_id
                  and glb.ledger_id = fbc.set_of_books_id
                  and gcc1.code_combination_id = fbc.flexbuilder_defaults_ccid
                  and gcc.segment1 = gcc1.segment1
                  and gcc.segment4 = CC1.SEGMENT4
                  and gl.ledger_id = glb.ledger_id
                  and gl.currency_code = glb.currency_code
                  and glb.period_name = P_PERIOD_NAME
                  and fbc.book_type_code = P_FA_BOOK) GL_CUSTO,
           FDD.DEPRN_AMOUNT                      DEPRECIACAO_MES,
           FDD.YTD_DEPRN                         DEPRECIACAO_ANO,
           (FDD.COST - FDD.DEPRN_RESERVE)        SALDO_A_DEPRECIAR,
           FDD.DEPRN_RESERVE                     FA_DEPRECIACAO_ACUM,
           0 GL_DEPRECIACAO_ACUM,
           FL.SEGMENT1||'.'||FL.SEGMENT2         LOCALIZACAO,
           FDD.PERIOD_COUNTER                    FDD_PERIOD_COUNTER,
           FDP1.PERIOD_NAME                      FDD_PERIOD_NAME,
           FDP.PERIOD_COUNTER                    FDP_PERIOD_COUNTER,
           FDP.PERIOD_NAME                       FDP_PERIOD_NAME,
           FA.ASSET_TYPE                         TIPO
    FROM   APPS.FA_ADDITIONS               FA,
           APPS.FA_BOOKS                   FB,
           APPS.FA_DISTRIBUTION_HISTORY    FDH,
           APPS.FA_LOCATIONS               FL,
           APPS.FND_FLEX_VALUES_VL         FV1,
           APPS.FND_FLEX_VALUES_VL         FV2,
           APPS.FND_FLEX_VALUES_VL         FV3,
           APPS.FA_DEPRN_DETAIL            FDD,
           APPS.FA_INVOICE_DETAILS_V       FIDV,
           APPS.FA_DEPRN_PERIODS           FDP,
           APPS.FA_DEPRN_PERIODS           FDP1,
           APPS.FA_CATEGORY_BOOKS          FCB,
           APPS.FA_CATEGORIES              FC,
           APPS.GL_CODE_COMBINATIONS       GCC,
           APPS.GL_CODE_COMBINATIONS       CC1,
           APPS.GL_CODE_COMBINATIONS       CC2,
           APPS.GL_CODE_COMBINATIONS       CC3
    WHERE  FA.ASSET_ID                     = FB.ASSET_ID
    AND    FA.ASSET_ID                     = FDH.ASSET_ID
    AND    FA.ASSET_ID                     = FDD.ASSET_ID
    AND    FA.ASSET_ID                     = FIDV.ASSET_ID (+)
    AND    FA.ASSET_CATEGORY_ID            = FCB.CATEGORY_ID
    AND    FB.ASSET_ID                     = FDD.ASSET_ID
    AND    FB.BOOK_TYPE_CODE               = FDD.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = FDH.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = FCB.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = FDP.BOOK_TYPE_CODE
    AND    FB.BOOK_TYPE_CODE               = P_FA_BOOK --'STONE_CORP'
    AND    FB.DATE_INEFFECTIVE             IS NULL
    AND    FDH.DATE_INEFFECTIVE            IS NULL --ALT 3S 30/10/2018
    AND    FDH.ASSET_ID                    = FDD.ASSET_ID
    AND    FDH.CODE_COMBINATION_ID         = GCC.CODE_COMBINATION_ID
    AND    FDH.LOCATION_ID                 = FL.LOCATION_ID
    AND    FDH.BOOK_TYPE_CODE              = FDD.BOOK_TYPE_CODE
    AND    NVL(FB.PERIOD_COUNTER_FULLY_RETIRED,999999999) >  FDP.PERIOD_COUNTER
    --AND    FDH.RETIREMENT_ID               IS NULL
    AND    FCB.WIP_COST_ACCOUNT_CCID       = CC1.CODE_COMBINATION_ID
    AND    FA.ASSET_TYPE                   = 'CIP'
    AND    FCB.RESERVE_ACCOUNT_CCID        = CC2.CODE_COMBINATION_ID
    AND    FCB.DEPRN_EXPENSE_ACCOUNT_CCID  = CC3.CODE_COMBINATION_ID
    AND    FCB.CATEGORY_ID                 = FC.CATEGORY_ID
    AND    FV1.FLEX_VALUE                  = CC1.SEGMENT4
    AND    FV1.FLEX_VALUE_SET_ID           = (SELECT FLEX_VALUE_SET_ID FROM APPS.FND_FLEX_VALUE_SETS
                                              WHERE FLEX_VALUE_SET_NAME = 'DLP_GL_CONTA_CONTABIL3')
    AND    FV2.FLEX_VALUE                  = CC2.SEGMENT4
    AND    FV3.FLEX_VALUE                  = CC3.SEGMENT4
    AND    FDD.PERIOD_COUNTER              = (SELECT MAX(FDD1.PERIOD_COUNTER)
                                              FROM   APPS.FA_DEPRN_DETAIL            FDD1
                                              WHERE  FDD1.ASSET_ID       = FDD.ASSET_ID
                                              AND    FDD1.BOOK_TYPE_CODE = FDD.BOOK_TYPE_CODE
                                              AND    FDD1.PERIOD_COUNTER <= FDP.PERIOD_COUNTER)
    AND    FDD.PERIOD_COUNTER              = FDP1.PERIOD_COUNTER
    AND    FDD.BOOK_TYPE_CODE              = FDP1.BOOK_TYPE_CODE
    AND    FDP.PERIOD_NAME                 = P_PERIOD_NAME --'OCT-17'
    AND    FA.ASSET_CATEGORY_ID            = NVL(P_CATEGORY, FA.ASSET_CATEGORY_ID)
    ORDER BY 5;
    */--Alt 3S
    CURSOR C_FA  (P_FA_BOOK     IN VARCHAR2 ,
              P_PERIOD_NAME IN VARCHAR2 ,
              P_CATEGORY    IN NUMBER
              ) IS
    SELECT
            gcc.segment1                        EMPRESA
            ,fca.description                    CATEGORIA
            ,frl.asset_cost_acct                CONTA_ATIVO
            ,gl_flexfields_pkg.get_description(
            gcc.chart_of_accounts_id
            ,'GL_ACCOUNT'
            ,frl.asset_cost_acct)               DESC_CONTA_ATIVO
            ,frl.deprn_reserve_acct             CONTA_DEPR_ACUM
            ,gcc.segment4                       CONTA_DESP_DEPR
            ,gcc.segment5                       CENTRO_DE_CUSTO
            ,gcc.segment7                       CANAL -- ROGERIO FARTO (9CON) - 24/10/2019
            ,fad.serial_number                  NUMERO_SERIAL
            ,fad.tag_number                     ETIQUETA
            ,fad.asset_number                   NUMERO_ATIVO
            ,fad.description                    HISTORICO
            ,fid.invoice_number                 NOTA_FISCAL
            ,fid.vendor_name                    FORNECEDOR
            ,frl.date_placed_in_service         DATA_ENTRADA
            ,frl.life                           VIDA_UTIL
            ,fam.fa_custo                       FA_CUSTO
            ,(select sum(glb.begin_balance_dr) - sum(glb.begin_balance_cr)
                +    sum(glb.period_net_dr)    - sum(glb.period_net_cr)
                from  apps.gl_balances           glb
                      ,apps.fa_book_controls     fbc
                      ,apps.gl_ledgers           gl
                      ,apps.gl_code_combinations gcc2
                where 1 = 1
                and glb.ledger_id           =   fbc.set_of_books_id
                and glb.ledger_id           =   gl.ledger_id
                and glb.currency_code       =   gl.currency_code
                and glb.code_combination_id =   gcc2.code_combination_id
                and gcc.segment1            =   gcc2.segment1
                and frl.asset_cost_acct     =   gcc2.segment4
                and glb.period_name         =   P_PERIOD_NAME
                and fbc.book_type_code      =   P_FA_BOOK) GL_CUSTO
            ,fam.depreciacao_mes                DEPRECIACAO_MES
            ,fam.depreciacao_ano                DEPRECIACAO_ANO
            ,fam.saldo_a_depreciar              SALDO_A_DEPRECIAR
            ,fam.fa_depreciacao_acum            FA_DEPRECIACAO_ACUM
            ,(select sum(glb.begin_balance_dr)  - sum(glb.begin_balance_cr)
                +    sum(glb.period_net_dr)     - sum(glb.period_net_cr)
                from  apps.gl_balances              glb
                      ,apps.fa_book_controls        fbc
                      ,apps.gl_ledgers              gl
                      ,apps.gl_code_combinations    gcc2
                where 1 = 1
                and glb.ledger_id           =   fbc.set_of_books_id
                and glb.ledger_id           =   gl.ledger_id
                and glb.currency_code       =   gl.currency_code
                and glb.code_combination_id =   gcc2.code_combination_id
                and gcc.segment1            =   gcc2.segment1
                and frl.deprn_reserve_acct  =   gcc2.segment4
                and glb.period_name         =   P_PERIOD_NAME
                and fbc.book_type_code      =   P_FA_BOOK) GL_DEPRECIACAO_ACUM
            ,flo.concatenated_segments          LOCALIZACAO
            ,frl.period_counter                 FDD_PERIOD_COUNTER
            ,P_PERIOD_NAME                      FDD_PERIOD_NAME
            ,frl.period_counter                 FDP_PERIOD_COUNTER
            ,P_PERIOD_NAME                      FDP_PERIOD_NAME
            ,fad.asset_type                     TIPO
            ,fad.MANUFACTURER_NAME              FABRICANTE --- alt 25/04/2019 - fpavao
    FROM
        (SELECT asset_id
                ,sum(cost)                 FA_CUSTO
                ,sum(deprn_amount)         DEPRECIACAO_MES
                ,sum(ytd_deprn)            DEPRECIACAO_ANO
                ,sum(cost - deprn_reserve) SALDO_A_DEPRECIAR
                ,sum(deprn_reserve)        FA_DEPRECIACAO_ACUM
         FROM   apps.fa_reserve_ledger_gt
         GROUP BY asset_id)             fam
         ,(SELECT LISTAGG(invoice_number,', ')
                    WITHIN GROUP (ORDER BY invoice_number) invoice_number
                   ,LISTAGG(vendor_name,', ')
                    WITHIN GROUP (ORDER BY vendor_name)    vendor_name
                   ,asset_id
          FROM apps.fa_invoice_details_v
          WHERE invoice_number IS NOT NULL
          GROUP BY asset_id)            fid
         ,apps.fa_reserve_ledger_gt     frl
         ,apps.gl_code_combinations     gcc
         ,apps.fa_additions             fad
         ,apps.fa_categories            fca
         ,apps.fa_distribution_history  fdh
         ,apps.fa_locations_kfv         flo
    WHERE 1=1
    AND frl.asset_id    =   fam.asset_id
    AND frl.dh_ccid     =   gcc.code_combination_id
    AND frl.asset_id    =   fad.asset_id
    AND fca.category_id =   fad.asset_category_id
    AND frl.asset_id    =   fid.asset_id    (+)
    AND frl.asset_id    =   fdh.asset_id
    AND frl.dh_ccid     =   fdh.code_combination_id
    AND flo.location_id         =   fdh.location_id
    AND fdh.book_type_code      =   P_FA_BOOK
    AND frl.date_effective
        BETWEEN fdh.date_effective
        AND NVL(fdh.date_ineffective,sysdate)
    AND frl.percent     =   100
    AND fca.category_id =   NVL(P_CATEGORY,fca.category_id)
    UNION ALL
    SELECT
            gcc.segment1                        EMPRESA
            ,fca.description                    CATEGORIA
            ,fbr.category_books_account         CONTA_ATIVO
            ,gl_flexfields_pkg.get_description(
            gcc.chart_of_accounts_id
            ,'GL_ACCOUNT'
            ,fbr.category_books_account)        DESC_CONTA_ATIVO
            ,fcb.deprn_reserve_acct             CONTA_DEPR_ACUM
            ,gcc.segment4                       CONTA_DESP_DEPR
            ,gcc.segment5                       CENTRO_DE_CUSTO
            ,gcc.segment7                       CANAL -- ROGERIO FARTO (9CON) - 24/10/2019
            ,fad.serial_number                  NUMERO_SERIAL
            ,fad.tag_number                     ETIQUETA
            ,fad.asset_number                   NUMERO_ATIVO
            ,fad.description                    HISTORICO
            ,fid.invoice_number                 NOTA_FISCAL
            ,fid.vendor_name                    FORNECEDOR
            ,fab.date_placed_in_service         DATA_ENTRADA
            ,fab.life_in_months                 VIDA_UTIL
            ,fbr.amount                         FA_CUSTO
            ,(select sum(glb.begin_balance_dr)  - sum(glb.begin_balance_cr)
                    +    sum(glb.period_net_dr)     - sum(glb.period_net_cr)
                    from  apps.gl_balances              glb
                          ,apps.fa_book_controls        fbc
                          ,apps.gl_ledgers              gl
                          ,apps.gl_code_combinations    gcc2
                    where 1 = 1
                    and glb.ledger_id               =   fbc.set_of_books_id
                    and glb.ledger_id               =   gl.ledger_id
                    and glb.currency_code           =   gl.currency_code
                    and glb.code_combination_id     =   gcc2.code_combination_id
                    and gcc.segment1                =   gcc2.segment1
                    --and fbr.cost_account          =   gcc2.segment4         --3S - TRAMOS - 12/04/2019
                    and fbr.category_books_account  =   gcc2.segment4         --3S - TRAMOS - 12/04/2019
                    and glb.period_name             =   P_PERIOD_NAME
                    and fbc.book_type_code          =   P_FA_BOOK) GL_CUSTO
            ,0                                  DEPRECIACAO_MES
            ,0                                  DEPRECIACAO_ANO
            ,fbr.amount                         SALDO_A_DEPRECIAR
            ,0                                  FA_DEPRECIACAO_ACUM
            ,0                                  GL_DEPRECIACAO_ACUM
            ,flo.concatenated_segments          LOCALIZACAO
            ,fdp.period_counter                 FDD_PERIOD_COUNTER
            ,P_PERIOD_NAME                      FDD_PERIOD_NAME
            ,fdp.period_counter                 FDP_PERIOD_COUNTER
            ,P_PERIOD_NAME                      FDP_PERIOD_NAME
            ,fad.asset_type                     TIPO
            ,fad.MANUFACTURER_NAME              FABRICANTE --- alt 25/04/2019 - fpavao
    FROM
         apps.fa_balances_report_gt     fbr
         ,apps.gl_code_combinations     gcc
         ,apps.fa_additions             fad
         ,apps.fa_categories            fca
         ,apps.fa_category_books        fcb
         ,apps.fa_distribution_history  fdh
         ,apps.fa_locations_kfv         flo
         ,apps.fa_deprn_periods         fdp
         ,apps.fa_books                 fab     --3S - TRAMOS - 12/04/2019
         ,(SELECT LISTAGG(invoice_number,', ')
                    WITHIN GROUP (ORDER BY invoice_number) invoice_number
                 ,LISTAGG(vendor_name,', ')
                    WITHIN GROUP (ORDER BY vendor_name)    vendor_name
                 ,asset_id
           FROM apps.fa_invoice_details_v
           WHERE invoice_number IS NOT NULL
           GROUP BY asset_id)          fid
    WHERE 1=1
    AND fbr.distribution_ccid   =   gcc.code_combination_id
    AND fbr.asset_id            =   fad.asset_id
    AND fca.category_id         =   fad.asset_category_id
    AND fca.category_id         =   fcb.category_id
    AND fdh.book_type_code      =   fcb.book_type_code
    AND fbr.asset_id            =   fid.asset_id    (+)
    AND fbr.asset_id            =   fdh.asset_id
    AND flo.location_id         =   fdh.location_id
    AND fdp.book_type_code      =   fdh.book_type_code
    AND fbr.asset_id            =   fab.asset_id                            --3S - TRAMOS - 12/04/2019 - BEGIN
    AND fdh.book_type_code      =   fab.book_type_code
    AND nvl(fdp.period_close_date,SYSDATE)
        BETWEEN fab.date_effective  AND NVL(fab.date_ineffective,SYSDATE)   --3S - TRAMOS - 12/04/2019 - END
    AND NVL(fdp.period_close_date,SYSDATE)
        BETWEEN fdh.date_effective
        AND NVL(fdh.date_ineffective,SYSDATE)
    AND fbr.source_type_code    =   'END'
    AND fdp.period_name         =   P_PERIOD_NAME
    AND fdh.book_type_code      =   P_FA_BOOK
    AND fca.category_id         =   NVL(P_CATEGORY,fca.category_id)
    --ORDER BY 5;                                                           --3S - TRAMOS - 12/04/2019
    ORDER BY    CONTA_ATIVO, NUMERO_ATIVO;                                  --3S - TRAMOS - 12/04/2019
    -- 3S - TRAMOS - 28/11/2018 - END
    --
    l_count          NUMBER       := 0;
    v_lin            NUMBER       := 1;
    v_tab            NUMBER       := 0; -- ROGERIO FARTO 12/08/2020 (#SR-558257 - NSD-323746)
    v_file_name      VARCHAR2(250);
    l_nRequest_Id    number;
    l_user_name      VARCHAR2(40) := fnd_profile.value('USERNAME');
    L_CATEGORIA      FA_CATEGORIES.DESCRIPTION%TYPE;
    l_operation      VARCHAR2(250); -- 3S - TRAMOS - 28/11/2018
    --
    R_Summary      l_Table;
    R_Summary_aux  l_Table;
   --
    begin
       --
       write_log(gv_debug_flag, ' Started Stone - FA Depreciation Report - Detail');
       --
       print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
       print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
       print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
       print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
       print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
       --
       as_xlsx.clear_workbook;
       as_xlsx.new_sheet('Relatorio');
--       as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'F6F287' ) ) ;
       as_xlsx.set_row( 1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )
                         , p_fillId => as_xlsx.get_fill( 'solid', 'F6F287' ));
       --
       as_xlsx.cell( 1, 1, 'EMPRESA');
       as_xlsx.cell( 2, 1, 'CATEGORIA');
       as_xlsx.cell( 3, 1, 'CONTA_ATIVO');
       as_xlsx.cell( 4, 1, 'DESC_CONTA_ATIVO');
       as_xlsx.cell( 5, 1, 'CONTA_DEPR_ACUM');
       as_xlsx.cell( 6, 1, 'CONTA_DESP_DEPR');
       as_xlsx.cell( 7, 1, 'CENTRO_DE_CUSTO');
       as_xlsx.cell( 8, 1, 'CANAL'); -- ROGERIO FARTO (9CON) - 24/10/2019
       as_xlsx.cell( 9, 1, 'NUMERO_SERIAL');
       as_xlsx.cell(10, 1, 'ETIQUETA');
       as_xlsx.cell(11, 1, 'NUMERO_ATIVO');
       as_xlsx.cell(12, 1, 'HISTORICO');
       as_xlsx.cell(13, 1, 'NOTA_FISCAL');
       as_xlsx.cell(14, 1, 'FORNECEDOR');
       as_xlsx.cell(15, 1, 'FABRICANTE'); --alt 25/04/2019 - fpavao
       as_xlsx.cell(16, 1, 'DATA_ENTRADA');
       as_xlsx.cell(17, 1, 'VIDA_UTIL');
       as_xlsx.cell(18, 1, 'CUSTO');
       as_xlsx.cell(19, 1, 'DEPRECIACAO_MES ');
       as_xlsx.cell(20, 1, 'DEPRECIACAO_ANO');
       as_xlsx.cell(21, 1, 'DEPRECIACAO_ACUM');
       as_xlsx.cell(22, 1, 'VALOR RESIDUAL');
       as_xlsx.cell(23, 1, 'LOCALIZACAO');
       --
       -- 3S - TRAMOS - 28/11/2018 - BEGIN
        --
       fa_rsvldg_rep_ins_pkg.rsvldg( book       => P_FA_BOOK
                                    ,period     => P_PERIOD_NAME
                                    ,errbuf     => ERRBUF
                                    ,retcode    => RETCODE
                                    ,operation  => l_operation
                                    ,request_id => fnd_global.conc_request_id);
       --
       farx_bl.cip_balances_rpt (
                                   book                  => P_FA_BOOK
                                  ,start_period_name     => P_PERIOD_NAME
                                  ,end_period_name       => P_PERIOD_NAME
                                  ,request_id            => fnd_global.conc_request_id
                                  ,user_id               => fnd_global.user_id
                                  ,retcode               => RETCODE
                                  ,errbuf                => ERRBUF);
       --
       -- 3S - TRAMOS - 28/11/2018 - END
       --
       FOR r_fa IN c_fa (P_FA_BOOK    ,
                         P_PERIOD_NAME,
                         P_CATEGORY)
       LOOP
           v_lin := v_lin + 1;
           --
           -- INICIO -- ROGERIO FARTO 12/08/2020 (#SR-558257 - NSD-323746)
           --
           if v_lin > 1000001 then
             v_tab := v_tab + 1;
             v_lin := 2;           
             --
             as_xlsx.new_sheet('Relatorio'||v_tab);
             as_xlsx.set_row( 1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )
                               , p_fillId => as_xlsx.get_fill( 'solid', 'F6F287' ));
             --
             as_xlsx.cell( 1, 1, 'EMPRESA');
             as_xlsx.cell( 2, 1, 'CATEGORIA');
             as_xlsx.cell( 3, 1, 'CONTA_ATIVO');
             as_xlsx.cell( 4, 1, 'DESC_CONTA_ATIVO');
             as_xlsx.cell( 5, 1, 'CONTA_DEPR_ACUM');
             as_xlsx.cell( 6, 1, 'CONTA_DESP_DEPR');
             as_xlsx.cell( 7, 1, 'CENTRO_DE_CUSTO');
             as_xlsx.cell( 8, 1, 'CANAL'); -- ROGERIO FARTO (9CON) - 24/10/2019
             as_xlsx.cell( 9, 1, 'NUMERO_SERIAL');
             as_xlsx.cell(10, 1, 'ETIQUETA');
             as_xlsx.cell(11, 1, 'NUMERO_ATIVO');
             as_xlsx.cell(12, 1, 'HISTORICO');
             as_xlsx.cell(13, 1, 'NOTA_FISCAL');
             as_xlsx.cell(14, 1, 'FORNECEDOR');
             as_xlsx.cell(15, 1, 'FABRICANTE'); --alt 25/04/2019 - fpavao
             as_xlsx.cell(16, 1, 'DATA_ENTRADA');
             as_xlsx.cell(17, 1, 'VIDA_UTIL');
             as_xlsx.cell(18, 1, 'CUSTO');
             as_xlsx.cell(19, 1, 'DEPRECIACAO_MES ');
             as_xlsx.cell(20, 1, 'DEPRECIACAO_ANO');
             as_xlsx.cell(21, 1, 'DEPRECIACAO_ACUM');
             as_xlsx.cell(22, 1, 'VALOR RESIDUAL');
             as_xlsx.cell(23, 1, 'LOCALIZACAO');
             --
           end if;
           --
           -- FINAL - ROGERIO FARTO 12/08/2020 (#SR-558257 - NSD-323746)
           --   
           R_Summary_aux(1) := NULL;
           R_Summary_aux(1).CONTA_ATIVO       := r_fa.CONTA_ATIVO;
           R_Summary_aux(1).DESC_CONTA_ATIVO  := r_fa.DESC_CONTA_ATIVO;
           R_Summary_aux(1).CONTA_DEPR_ACUM   := r_fa.CONTA_DEPR_ACUM;
           R_Summary_aux(1).CONTA_DESP_DEPR   := r_fa.CONTA_DESP_DEPR;
           R_Summary_aux(1).FA_CUSTO          := NVL(r_fa.FA_CUSTO,0); --alt 3S
           R_Summary_aux(1).GL_CUSTO          := NVL(r_fa.GL_CUSTO,0); --alt 3S
           --
           as_xlsx.cell( 1,v_lin, special_character(r_fa.EMPRESA));
           as_xlsx.cell( 2,v_lin, special_character(nvl(r_fa.CATEGORIA,' ')) );
           as_xlsx.cell( 3,v_lin, special_character(r_fa.CONTA_ATIVO) );
           as_xlsx.cell( 4,v_lin, special_character(r_fa.DESC_CONTA_ATIVO) );
           as_xlsx.cell( 5,v_lin, special_character(r_fa.CONTA_DEPR_ACUM));
           as_xlsx.cell( 6,v_lin, special_character(r_fa.CONTA_DESP_DEPR));
           as_xlsx.cell( 7,v_lin, special_character(r_fa.CENTRO_DE_CUSTO) );
           as_xlsx.cell( 8,v_lin, special_character(r_fa.CANAL) ); -- ROGERIO FARTO (9CON) - 24/10/2019
           as_xlsx.cell( 9,v_lin, special_character(nvl(r_fa.NUMERO_SERIAL,' ')) );
           as_xlsx.cell(10,v_lin, special_character(nvl(r_fa.ETIQUETA,' ')));
           as_xlsx.cell(11,v_lin, special_character(r_fa.NUMERO_ATIVO) );
           as_xlsx.cell(12,v_lin, special_character(nvl(r_fa.HISTORICO,' ')));
           as_xlsx.cell(13,v_lin, special_character(nvl(r_fa.NOTA_FISCAL,' ')) );
           as_xlsx.cell(14,v_lin, special_character(nvl(r_fa.FORNECEDOR,' ')));
           as_xlsx.cell(15,v_lin, special_character(nvl(r_fa.FABRICANTE,' '))); --alt 25/04/2019 - fpavao
           as_xlsx.cell(16,v_lin, TO_CHAR(r_fa.DATA_ENTRADA,'DD/MM/RRRR'));
           as_xlsx.cell(17,v_lin, r_fa.VIDA_UTIL);
           as_xlsx.cell(18,v_lin, r_fa.FA_CUSTO);
           IF r_fa.FDD_PERIOD_COUNTER =  r_fa.FDP_PERIOD_COUNTER OR r_fa.TIPO IN('CAPITALIZED','CIP') THEN
               as_xlsx.cell(19,v_lin, r_fa.DEPRECIACAO_MES );
               as_xlsx.cell(20,v_lin, r_fa.DEPRECIACAO_ANO  );
               as_xlsx.cell(21,v_lin, r_fa.FA_DEPRECIACAO_ACUM );
               as_xlsx.cell(22,v_lin, r_fa.SALDO_A_DEPRECIAR );
               --
               R_Summary_aux(1).DEPRECIACAO_MES   := r_fa.DEPRECIACAO_MES  ;
               R_Summary_aux(1).DEPRECIACAO_ANO   := r_fa.DEPRECIACAO_ANO  ;
               R_Summary_aux(1).FA_DEPRECIACAO_ACUM  := NVL(r_fa.FA_DEPRECIACAO_ACUM,0); --alt 3S
               R_Summary_aux(1).GL_DEPRECIACAO_ACUM  := NVL(r_fa.GL_DEPRECIACAO_ACUM,0); --alt 3S
               R_Summary_aux(1).VALOR_RESIDUAL    := NVL(r_fa.SALDO_A_DEPRECIAR,0); --alt 3S
           ELSE
               as_xlsx.cell(19,v_lin, 0 );
               IF substr(r_fa.FDP_PERIOD_NAME,5,2) <> substr(r_fa.FDD_PERIOD_NAME,5,2) THEN
                  as_xlsx.cell(20,v_lin, 0);
                  --
                  R_Summary_aux(1).DEPRECIACAO_ANO := 0;
               ELSE
                  as_xlsx.cell(20,v_lin, r_fa.DEPRECIACAO_ANO);
                  --
                  R_Summary_aux(1).DEPRECIACAO_ANO := r_fa.DEPRECIACAO_ANO;
               END IF;
               as_xlsx.cell(21,v_lin, r_fa.FA_DEPRECIACAO_ACUM );
               as_xlsx.cell(22,v_lin, r_fa.SALDO_A_DEPRECIAR );
               --
               R_Summary_aux(1).FA_DEPRECIACAO_ACUM  := NVL(r_fa.FA_DEPRECIACAO_ACUM,0); --alt 3S
               R_Summary_aux(1).VALOR_RESIDUAL    := NVL(r_fa.SALDO_A_DEPRECIAR,0); --alt 3S
           END IF;
           as_xlsx.cell(23,v_lin, special_character(r_fa.LOCALIZACAO) );
           --
           l_count := l_count + 1;
           --
           manage_array(R_Summary_aux,R_Summary);

/*           IF l_count = 1 THEN

            IF P_CATEGORY IS NOT NULL THEN

             L_CATEGORIA := P_CATEGORY;

            END IF;

           END IF;*/

       END LOOP;
       --
       --
       --as_xlsx.set_autofilter( 1,20, p_row_start => 1, p_row_end => v_lin );
       --
       write_log(gv_debug_flag, ' Lines : '||l_count);
       write_log(gv_debug_flag, ' Ended Stone - FA Depreciation Report - Detail ');
       as_xlsx.freeze_rows( 1 );
       v_file_name := 'o'||FND_GLOBAL.CONC_REQUEST_ID||'.xlsx';
       --
       as_xlsx.new_sheet('Sumarizado');
       as_xlsx.set_column_width(1, 20);
       as_xlsx.set_column_width(2, 20);
       --
       as_xlsx.set_row( 1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )
                         , p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ));
       as_xlsx.mergecells( 1, 1, 2, 1 );
       as_xlsx.cell(2 , 1 ,''          , p_borderId => as_xlsx.get_border( 'thick', 'thick', 'thick', 'thick' ));
       as_xlsx.cell(1 , 1 ,'Parametros', p_alignment => as_xlsx.get_alignment( p_horizontal => 'center' ),
                                         p_borderId => as_xlsx.get_border( 'thick', 'thick', 'thick', 'thick' ));
       --
       as_xlsx.cell(1 , 2 ,'Livro do FA',p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(1 , 3 ,'Periodo'    ,p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(1 , 4 ,'Categoria'    ,p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )); --alt 3S
       --
       as_xlsx.cell(2 , 2 ,P_FA_BOOK);
       as_xlsx.cell(2 , 3 ,P_PERIOD_NAME);
       as_xlsx.cell(2 , 4 ,P_CATEGORY); --alt 3S
       --
       as_xlsx.set_row( 6, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )
                         , p_fillId => as_xlsx.get_fill( 'solid', 'F6F287' ));
       --
       as_xlsx.cell( 1, 6, 'CONTA_ATIVO');
       as_xlsx.cell( 2, 6, 'DESC_CONTA_ATIVO');
       as_xlsx.cell( 3, 6, 'CONTA_DEPR_ACUM');
       as_xlsx.cell( 4, 6, 'CONTA_DESP_DEPR');
       as_xlsx.cell( 5, 6, 'FA_CUSTO');
       as_xlsx.cell( 6, 6, 'GL_CUSTO');
       as_xlsx.cell( 7, 6, 'DEPRECIACAO_MES');
       as_xlsx.cell( 8, 6, 'DEPRECIACAO_ANO');
       as_xlsx.cell( 9, 6, 'FA_DEPRECIACAO_ACUM');
       as_xlsx.cell( 10, 6, 'GL_DEPRECIACAO_ACUM');
       as_xlsx.cell( 11, 6, 'VALOR_RESIDUAL');
       --

       SELECT 'A','B','C','D'
       ,sum(FA_CUSTO)
       ,sum(GL_CUSTO)
       ,sum(DEPRECIACAO_MES)
       ,sum(DEPRECIACAO_ANO)
       ,sum(FA_DEPRECIACAO_ACUM)
       ,sum(GL_DEPRECIACAO_ACUM)
       ,sum(VALOR_RESIDUAL)
       INTO   R_Summary(R_Summary.LAST+1)
       FROM   TABLE (R_Summary)
       group by 'A','B','C','D' ;
       --
       FOR i IN 1..R_Summary.LAST LOOP
           IF i = R_Summary.LAST THEN
              as_xlsx.mergecells( 2, i+6 , 4, i+6 );
              as_xlsx.set_row( i+6, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )
                                  , p_fillId => as_xlsx.get_fill( 'solid', 'F6F287' ));
              as_xlsx.cell( 2, i+6,'TOTAL');
           ELSE
               as_xlsx.cell( 1, i+6, R_Summary(i).CONTA_ATIVO      );
               as_xlsx.cell( 2, i+6, R_Summary(i).DESC_CONTA_ATIVO );
               as_xlsx.cell( 3, i+6, R_Summary(i).CONTA_DEPR_ACUM  );
               as_xlsx.cell( 4, i+6, R_Summary(i).CONTA_DESP_DEPR  );
           END IF;
           as_xlsx.cell( 5, i+6, NVL(R_Summary(i).FA_CUSTO,0)            );
           as_xlsx.cell( 6, i+6, NVL(R_Summary(i).GL_CUSTO,0)         );
           as_xlsx.cell( 7, i+6, NVL(R_Summary(i).DEPRECIACAO_MES,0)  );
           as_xlsx.cell( 8, i+6, NVL(R_Summary(i).DEPRECIACAO_ANO,0)  );
           as_xlsx.cell( 9, i+6, NVL(R_Summary(i).FA_DEPRECIACAO_ACUM,0)  );
           as_xlsx.cell( 10, i+6, NVL(R_Summary(i).GL_DEPRECIACAO_ACUM,0) );
           as_xlsx.cell( 11, i+6, NVL(R_Summary(i).VALOR_RESIDUAL,0)   );
       END LOOP;
       --

       --

       --
       as_xlsx.new_sheet('Parametros');
       as_xlsx.set_column_width(1, 20);
       as_xlsx.set_column_width(2, 20);
       as_xlsx.set_column_width(3, 20); --alt 3S
       --
       as_xlsx.set_row( 1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )
                         , p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ));
       --
       as_xlsx.cell(2 , 1 ,'', p_borderId => as_xlsx.get_border( 'thick', 'thick', 'thick', 'thick' ));
       as_xlsx.cell(1 , 1 ,'Parametros', p_alignment => as_xlsx.get_alignment( p_horizontal => 'center' ),
                                         p_borderId => as_xlsx.get_border( 'thick', 'thick', 'thick', 'thick' ));
       as_xlsx.mergecells( 1, 1, 2, 1 );
       --
       as_xlsx.cell(1 , 2 ,'Livro do FA',p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(1 , 3 ,'Periodo'    ,p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(1 , 4 ,'Categoria'    ,p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true )); --alt 3S
       --
       as_xlsx.cell(2 , 2 ,P_FA_BOOK);
       as_xlsx.cell(2 , 3 ,P_PERIOD_NAME);
       as_xlsx.cell(2 , 4 ,P_CATEGORY);
       --
       as_xlsx.mergecells( 3, 5, 7, 5 );
       as_xlsx.cell(3 , 6 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS')
                                                   ||' por '||l_user_name
                          , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
       --fnd_file.put_line(fnd_file.log, 'antes as_xlsx.save');
       as_xlsx.save( 'XXSTN_HR_OUT', v_file_name );
       --fnd_file.put_line(fnd_file.log, 'depois as_xlsx.save');
       --
       --
       l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                  , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                  , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                  , argument1   => v_file_name
                                                  , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
    end;
END xxstn_fa_depre_report_pkg;
/

EXIT; 