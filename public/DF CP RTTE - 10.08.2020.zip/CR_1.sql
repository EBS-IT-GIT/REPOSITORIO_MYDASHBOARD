UPDATE apps.xx_tcg_cartas_porte_all
   SET rtte_comercial_id          = NULL, 
       rtte_comercial             = NULL,
       rtte_comercial_cuit        = NULL,
       rtte_comercial_tipo        = NULL,
       rtte_comercial_retiro      = 'N',
       rtte_comercial_contrato_id = NULL
WHERE carta_porte_id IN (446359,446627,446364,446371)
--4