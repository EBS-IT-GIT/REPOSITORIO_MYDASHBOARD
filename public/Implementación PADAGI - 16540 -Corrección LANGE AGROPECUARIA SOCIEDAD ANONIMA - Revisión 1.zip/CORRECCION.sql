UPDATE apps.hz_cust_accounts
SET    party_id = party_id * -1
WHERE  party_id = 11055358
AND    status = 'I';
--1 Registro