  set define off;
create global temporary table bolinf.xxom_no_granos_gt
(HEADER_ID number)
on commit preserve rows;
create public synonym xxom_no_granos_gt for bolinf.xxom_no_granos_gt;


exit
