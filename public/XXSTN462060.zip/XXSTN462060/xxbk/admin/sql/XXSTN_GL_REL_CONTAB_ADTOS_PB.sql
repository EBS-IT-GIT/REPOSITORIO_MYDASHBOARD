WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY apps.XXSTN_GL_REL_CONTAB_ADTOS IS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_GL_REL_CONTAB_ADTOS_PB.sql                                |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   GL - Relatorio contabil de adiantamentos                      |
-- |                                                                 |
-- | CREATED BY   Rogerio Farto - Ninecon - 14/03/2020               |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+
  -- Function and procedure implementations
  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_ledger_id      IN NUMBER
                              ,p_start_gl_date  IN VARCHAR2
                              ,p_end_gl_date    IN VARCHAR2) IS
  --
  CURSOR c_lanctos IS
         select distinct 
                haou.name                                                           empresa
              , asu.vendor_name                                                     fornecedor
              , asu.segment1                                                        nr_fornecedor
              , decode(assa.global_attribute9,'2',assa.global_attribute10
                                                  || '/'
                                                  || assa.global_attribute11
                                                  || '-'
                                                  || assa.global_attribute12
                                             ,'3',LPAD (assa.party_site_id, 9, '0')
                                                  || '/'
                                                  || assa.global_attribute11
                                                  || '-'
                                                  || assa.global_attribute12
                                                 ,assa.global_attribute10 
                                                  || '-' 
                                                  || assa.global_attribute12)       cnpj
               , 'Pagamento_Antecipado'                                             tipo_nf
               , to_date(apsa.due_date,'DD/MM/RRRR')                                data_vencimento
               , to_date(aia.invoice_date,'DD/MM/RRRR')                             data_emissao
               , gcc.concatenated_segments                                          conta_contabil
               , aia.invoice_currency_code                                          moeda
               , aia.invoice_num                                                    nr_nff
               , to_date(xah.accounting_date,'DD/MM/RRRR')                          data_gl
               , aia.invoice_amount                                                 valor_original
               , (select sum(nvl(x.prepay_amount_remaining, x.amount))
                    from apps.ap_invoice_distributions_all x 
                   where 1 = 1
                     and x.invoice_id = aia.invoice_id)                             vl_adto_em_aberto                      
               , gjb.name                                                           lote_contabil
               , aia.source                                                         origem_ap
               , aia.description                                                    descricao_nf
               , aia.exchange_rate_type                                             tipo_taxa_conversao
               , xal.currency_conversion_rate                                       taxa_conversao
               , aia.base_amount                                                    valor_moeda_funcional
               , apsa.payment_status_flag                                           status_pagamento
               , gjh.status                                                         status_lote_contabil         
           from apps.ap_invoices_all aia
              , apps.hr_all_organization_units haou
              , apps.ap_suppliers asu
              , apps.ap_supplier_sites_all assa
              , apps.ap_payment_schedules_all apsa
              , apps.xla_transaction_entities_upg xteu
              , apps.xla_ae_headers xah
              , apps.xla_ae_lines xal
              , apps.gl_code_combinations_kfv gcc
              , apps.gl_import_references gir
              , apps.gl_je_batches gjb
              , apps.gl_je_headers gjh
          where 1 = 1
            and aia.invoice_type_lookup_code = 'PREPAYMENT'
            and aia.org_id = haou.organization_id
            and aia.vendor_id = asu.vendor_id
            and aia.vendor_site_id = assa.vendor_site_id
            and aia.invoice_id = apsa.invoice_id
            and aia.invoice_id = xteu.source_id_int_1
            and xteu.application_id = 200
            and xteu.entity_code = 'AP_INVOICES'
            and xteu.application_id = xah.application_id
            and xteu.entity_id = xah.entity_id
            and xah.ledger_id = p_ledger_id 
            and nvl(aia.cancelled_date,trunc(to_date(p_end_gl_date,'rrrr/mm/dd hh24:mi:ss')+1)) > trunc(to_date(p_end_gl_date,'rrrr/mm/dd hh24:mi:ss'))
            and xah.accounting_date between trunc(to_date(p_start_gl_date,'rrrr/mm/dd hh24:mi:ss'))
                                        and trunc(to_date(p_end_gl_date,'rrrr/mm/dd hh24:mi:ss'))
            and xah.ae_header_id = xal.ae_header_id
            and xal.accounting_class_code = 'PREPAID_EXPENSE'
            and xal.code_combination_id = gcc.code_combination_id
            and xal.gl_sl_link_id = gir.gl_sl_link_id
            and gir.je_batch_id = gjb.je_batch_id
            and gir.je_header_id = gjh.je_header_id
            and xah.ledger_id = gjh.ledger_id
            and gjb.je_batch_id = gjh.je_batch_id
            and gjh.actual_flag = 'A'
            and gjh.status = 'P'
          order
             by haou.name
              , asu.vendor_name
              , aia.invoice_currency_code
              , to_date(xah.accounting_date,'DD/MM/RRRR')
              , aia.invoice_num;
  --
  TYPE t_lanctos IS TABLE OF c_lanctos%ROWTYPE;
  r_lanctos   t_lanctos;
  --
  v_file_name   VARCHAR2(240);
  l_qtde        NUMBER;
  l_vlr         NUMBER;
  l_lin         NUMBER;
  l_count       NUMBER := 2;
  l_nRequest_Id NUMBER;
  l_ledger_name gl_ledgers.name%type;
  l_user        fnd_user.user_name%type;
  --
  BEGIN
     --busca nome do livro contabil do parametro informado
     BEGIN
      SELECT gl.name
        into l_ledger_name
        FROM apps.gl_ledgers gl
       WHERE 1 = 1
         AND gl.ledger_id = p_ledger_id;
      EXCEPTION
       WHEN OTHERS THEN
        l_ledger_name := null;
     END;
     --busca usuario de execucao do relatorio
     BEGIN
      SELECT user_name
        into l_user
        FROM fnd_user
       WHERE user_id = FND_GLOBAL.USER_ID;
      EXCEPTION
       WHEN OTHERS THEN
        l_user := null;
     END;
     --------------------------------------------------------------------------
     --> Printing Parameters
     --------------------------------------------------------------------------
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'STONE PAGAMENTOS S/A               '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'             Stone - GL - Relatorio contabil de adiantamentos                ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Paramters..:');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_ledger_id..........: '||p_ledger_id);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_start_gl_date......: '||p_start_gl_date);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_end_gl_date........: '||p_end_gl_date);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     --
     dbms_output.put_line('Open lan�mentos '||v_file_name);
     OPEN c_lanctos ;
     FETCH c_lanctos BULK COLLECT INTO r_lanctos;
     CLOSE c_lanctos;
     --
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
     --
     as_xlsx.clear_workbook;
     --
     IF r_lanctos.count > 0 THEN
       --
       as_xlsx.new_sheet('Adiantamentos');
       as_xlsx.set_row(   1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(  3,  1, 'Relatorio contabil de adiantamentos', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 14, p_bold =>true) );
       as_xlsx.cell(  1,  2, 'Empresa', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  2,  2, 'Fornecedor', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  3,  2, 'Numero Fornecedor', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  4,  2, 'CPF - CNPJ', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  5,  2, 'Tipo NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  6,  2, 'Data Vencimento', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  7,  2, 'Data Emissao', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  8,  2, 'Conta Contabil', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  9,  2, 'Moeda', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  10, 2, 'Numero NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  11, 2, 'Data GL', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  12, 2, 'Valor Original', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  13, 2, 'Valor em Aberto Adiantamento', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  14, 2, 'Lote Contabil', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  15, 2, 'Origem AP', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  16, 2, 'Descricao NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  17, 2, 'Tipo Taxa Conversao', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  18, 2, 'Taxa Conversao', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  19, 2, 'Valor Moeda Funcional', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));       
       as_xlsx.cell(  20, 2, 'Status Pagamento', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));       
       as_xlsx.cell(  21, 2, 'Status Lote Contabil', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));       
       --
       FOR i IN r_lanctos.first..r_lanctos.last LOOP
         --
         dbms_output.put_line('Adiantamentos '||v_file_name);
         as_xlsx.cell(  1, l_count+1, r_lanctos(i).empresa);
         as_xlsx.cell(  2, l_count+1, r_lanctos(i).fornecedor);
         as_xlsx.cell(  3, l_count+1, r_lanctos(i).nr_fornecedor);
         as_xlsx.cell(  4, l_count+1, nvl(r_lanctos(i).cnpj,' '));
         as_xlsx.cell(  5, l_count+1, nvl(r_lanctos(i).tipo_nf,' '));
         as_xlsx.cell(  6, l_count+1, r_lanctos(i).data_vencimento);
         as_xlsx.cell(  7, l_count+1, r_lanctos(i).data_emissao);
         as_xlsx.cell(  8, l_count+1, r_lanctos(i).conta_contabil);
         as_xlsx.cell(  9, l_count+1, r_lanctos(i).moeda);
         as_xlsx.cell( 10, l_count+1, r_lanctos(i).nr_nff);
         as_xlsx.cell( 11, l_count+1, r_lanctos(i).data_gl);
         as_xlsx.cell( 12, l_count+1, r_lanctos(i).valor_original);
         as_xlsx.cell( 13, l_count+1, r_lanctos(i).vl_adto_em_aberto);
         as_xlsx.cell( 14, l_count+1, r_lanctos(i).lote_contabil);
         as_xlsx.cell( 15, l_count+1, r_lanctos(i).origem_ap);
         as_xlsx.cell( 16, l_count+1, nvl(r_lanctos(i).descricao_nf,' '));
         as_xlsx.cell( 17, l_count+1, nvl(r_lanctos(i).tipo_taxa_conversao,' '));
         as_xlsx.cell( 18, l_count+1, nvl(r_lanctos(i).taxa_conversao,0));
         as_xlsx.cell( 19, l_count+1, nvl(r_lanctos(i).valor_moeda_funcional,0));
         as_xlsx.cell( 20, l_count+1, r_lanctos(i).status_pagamento);
         as_xlsx.cell( 21, l_count+1, r_lanctos(i).status_lote_contabil);
         --
         l_count := l_count + 1;
         --
       END LOOP;
       --
       as_xlsx.freeze_rows( 2 );
       --
     END IF;
     --
     dbms_output.put_line('Parameters '||v_file_name);
     as_xlsx.new_sheet('Parameters');
     as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ) ) ;
     as_xlsx.cell(1 , 1 ,'Parametros');
     as_xlsx.cell(1 , 2 ,'Livro do GL');
     as_xlsx.cell(1 , 3 ,'Data Contabil Inicial');
     as_xlsx.cell(1 , 4 ,'Data Contabil Final');
     --
     as_xlsx.cell(2 , 2 ,nvl(to_char(p_ledger_id)||l_ledger_name,' '));
     as_xlsx.cell(2 , 3 ,nvl(p_start_gl_date,' '));
     as_xlsx.cell(2 , 4 ,nvl(p_end_gl_date,' '));

     as_xlsx.cell(5 , 7 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS') ||' por '||l_user
                         , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
     --
     v_file_name := 'o'||NVL(TO_CHAR(FND_GLOBAL.CONC_REQUEST_ID),'LanctoContabAdto')||'.xlsx';
     dbms_output.put_line('Arquivo gerado '||v_file_name);
     as_xlsx.save( 'XXSTN_HR_OUT', v_file_name );
     --
     dbms_output.put_line('Arquivo gravado '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'       ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Arquivo Gerado.....: '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Registros Gerados..: '||to_char(l_count-3));
     --
     l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                , argument1   => v_file_name
                                                , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
  EXCEPTION
    --
    WHEN OTHERS THEN
      --------------------------------------------------------------------
      --> Set Errors variables
      --------------------------------------------------------------------
      p_errbuf  := SUBSTR(SQLERRM, 1, 500);
      p_retcode := 2;
      --------------------------------------------------------------------
      --> Print Error Messages
      --------------------------------------------------------------------
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** Unexpected error please contact your system administrator');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_errbuf =  ' || SUBSTR(SQLERRM, 1, 500));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_retcode =  '|| SQLCODE);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
      --
  END generate_report_p;
  --
END XXSTN_GL_REL_CONTAB_ADTOS;
/

EXIT; 