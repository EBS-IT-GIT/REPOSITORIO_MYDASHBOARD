WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE apps.XXSTN_GL_REL_CONTAB_ADTOS IS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_GL_REL_CONTAB_ADTOS_PS.sql                                |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   GL - Relatorio contabil de adiantamentos                      |
-- |                                                                 |
-- | CREATED BY   Rogerio Farto - Ninecon - 14/03/2020               |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;

  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_ledger_id      IN NUMBER
                              ,p_start_gl_date  IN VARCHAR2
                              ,p_end_gl_date    IN VARCHAR2);

END XXSTN_GL_REL_CONTAB_ADTOS;
/

EXIT; 