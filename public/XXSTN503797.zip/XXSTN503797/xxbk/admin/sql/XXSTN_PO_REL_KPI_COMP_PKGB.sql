WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
create or replace PACKAGE BODY XXSTN_PO_REL_KPI_COMP_PKG AS
/* $Header: XXSTN_PO_REL_KPI_COMP_PKG.sql 120.3.12020000.3 2019/12/17 03:27:45 cbergama ship $ */
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PO_REL_KPI_COMP_PKG.sql                                   |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   PO - Relatorio KPI Compras                                    |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S    30/05/2019                  |
-- |                                                                 |
-- | UPDATED BY  Fernando Pavao - 3S 03/07/2019                      |
-- |   Atendimento ao chamado SR#322323                              |
-- |       Fernando Pavao - 3S     23/0/07/2019                      |
-- |    Atendimento ao chamado SR#333868                             |
-- |       Murilo Damasceno - Ninecon     23/10/2019                 |
-- |    Atendimento ao chamado SR#391706                             |
-- +=================================================================+

 --> Variaveis Globais:
 g_bShow_log          BOOLEAN := TRUE; -- FALSE;
 g_bGen_XML           BOOLEAN := FALSE;-- TRUE;

 PROCEDURE gen_relat_po_kpi_p (errbuf OUT VARCHAR2
                              ,retcode OUT NUMBER
                              ,P_EMPRESA IN VARCHAR2
                              ,P_NUM_REQ_DE IN NUMBER
                              ,P_DATA_REQ_DE IN VARCHAR2
                              ,P_DATA_REQ_ATE IN VARCHAR2
                              ) IS

 CURSOR C_DADOS_KPI IS
  select distinct ph.attribute1                          nr_req_nimbi
               ,prh.segment1                             nr_req_oracle
               --
               --Cristiano em 16/12/2019
               ,(select distinct full_name
                from apps.per_all_people_f
                where 1 = 1
                  and person_id = prl.suggested_buyer_id
                  and rownum = 1 --não filtrar inativos
                  ) comprador_sugerido_req
               ,papf.first_name ||' '|| papf.last_name   comprador
               ,decode(ph.authorization_status,'IN PROCESS','Em Andamento'
                                              ,'APPROVED'  ,'Aprovado'
                                              ,'INCOMPLETE','Incompleto'
                                              ,'REJECTED'  ,'Rejeitado'
                                              ,'REQUIRES REAPPROVAL','Exige Reaprovação') status_po
               ,hr.name                                                                   unidade_operacional
               ,papf1.first_name ||' '||papf1.last_name       requisitante
               ,ffv.flex_value||' - '||ffv.description        area_requisitante
               ,ph.attribute11                                tipo_negociacao

               ,null                                          opex_capex

               ,mc.segment1                                   categoria_item
               ,msi.segment1                                  nr_item
               ,msi.description                               descricao_item
               ,ph.comments                                   descricao_po

               ,prh.approved_date                             data_aprovacao_req
               ,prl.need_by_date                              necessario_em

               ,prl.line_num                                  nr_linha_req
               --Cristiano em 16/12/2019
               ,decode(nvl(prl.cancel_flag, 'N'), 'N','NAO', 'SIM')req_cancelada
               --
               --SR-503797 14/04/2020
               --status requisicao
              , case 
                  when prh.authorization_status = 'RETURNED'  
                     and nvl(prl.cancel_flag,'N') = 'N'
                        and prl.line_location_id is null then
                     'Requisicao Devolvida'
                  when (prh.authorization_status = 'RETURNED' or prh.authorization_status = 'APPROVED') 
                     and nvl(prl.cancel_flag,'N') = 'N'
                        and prl.line_location_id is not null then
                     'Linha Associada a OC'
                  else decode(prh.authorization_status,'IN PROCESS','Em Andamento'
                                              ,'APPROVED'  ,'Aprovado'
                                              ,'INCOMPLETE','Incompleto'
                                              ,'REJECTED'  ,'Rejeitado'
                                              ,'REQUIRES REAPPROVAL','Exige Reaprova磯')
              end status_linha_req
               ,prl.unit_price                                preco_req_linha
               ,prd.distribution_num                          nr_distrib_req
               ,prd.req_line_quantity                         qtd_distrib_req

               ,ph.segment1                                   nr_ordem_compra
               ,ph.currency_code                              moeda --23/10/2019 - Murilo Damasceno
               ,pl.line_num                                   nr_linha_oc
               ,pl.unit_price                                 vl_preco_oc
               ,pd.distribution_num                           nr_distr_oc
               ,pd.quantity_ordered                           qtd_solicitada_oc
               ,(pl.unit_price * pd.quantity_ordered)         vl_distrib_oc_multiplicado

               ,nvl(pl.attribute1,0)                                 vl_primeira_proposta_lines

               ,((pl.unit_price * pd.quantity_ordered) - nvl(pl.attribute1,0))        saving_line

               ,decode(pl.attribute1,null,0,0,0,(((pl.unit_price * pd.quantity_ordered) - pl.attribute1)/pl.attribute1))  percent_saving_line

               ,ph.creation_date                              data_criacao_po
               ,ph.approved_date                              data_aprovacao_po --23/10/2019 - Murilo Damasceno
               ,pv.vendor_name                                fornecedor

               ,decode(ph.type_lookup_code,'STANDARD',decode(ph.attribute2,'Y','PO Global','N','PO Spot',null,'Nao se Aplica'),'BLANKET','BLANKET','') tipo_compra --alt fpavao SR#360329
               ,apt.name                                      prazo_pagto
               ,cfi.invoice_num                               nr_nf
               ,pll.promised_date                             data_prevista_receb

               ,(select distinct pah.note
                 from apps.po_action_history pah
                 where pah.object_id = ph.po_header_id
                 and   pah.action_code = 'SUBMIT'
                 and   rownum = 1)                            observacoes

               ,cfeo.receive_date                             data_efetiva_entrega
               ,gcc.segment4                                  conta_contab
               ,tab_entidade.entidade --alt fpavao 03/07/2019
               ,ph.attribute12 status_negociacao --alt fpavao 03/07/2019
               ,DECODE(ph.attribute13,'Y','Sim','N','Nao',ph.attribute13) fornecedor_homolog_bacen --alt fpavao 03/07/2019
               ,ph.attribute5 motivo_stand_by --alt fpavao 23/07/2019 - SR#333868
               ,FND_DATE.canonical_to_date(ph.attribute10) data_stand_by --alt fpavao 23/07/2019 - SR#333868
               ,FND_DATE.canonical_to_date(ph.attribute7) data_retirada_stand_by --alt fpavao 23/07/2019 - SR#333868
--Tabelas
from apps.hr_all_organization_units    hr
   , apps.fnd_flex_values_vl           ffv
   , apps.fnd_flex_value_sets          ffvs
   , apps.gl_code_combinations         gcc
   , apps.per_all_people_f             papf
   , apps.per_all_people_f             papf1
   , apps.po_requisition_headers_all   prh
   , apps.po_requisition_lines_all     prl
   , apps.po_req_distributions_all     prd
   , apps.ap_suppliers                 pv
   , apps.po_agents                    pa
   , apps.po_headers_all               ph
   , apps.po_lines_all                 pl
   , apps.po_line_locations_all        pll
   , apps.po_distributions_all         pd
   , apps.ap_terms                     apt
   , apps.mtl_system_items             msi
   , apps.mtl_categories               mc
   , apps.cll_f189_entry_operations    cfeo
   , apps.cll_f189_invoices            cfi
   , apps.cll_f189_invoice_lines       cfil
   , apps.cll_f189_distributions       cfd
   --alt fpavao 03/07/2019 begin
   , (SELECT distinct ffvv.description entidade, ffvc.flex_value
       FROM apps.fnd_flex_values_vl ffvv,
            apps.fnd_flex_value_children_v ffvc,
            apps.fnd_flex_values_vl ffvv2,
            (SELECT ffvc.parent_flex_value,
                    ffvc.flex_value,
                    ffvc.description second_child,
                    ffvv.hierarchy_level,
                    ffvv2.attribute1 user_group_second_child
               FROM apps.fnd_flex_values_vl        ffvv,
                    apps.fnd_flex_value_children_v ffvc,
                    apps.fnd_flex_values_vl        ffvv2
              WHERE ffvc.parent_flex_value = ffvv.flex_value
                AND ffvc.flex_value_set_id = ffvv.flex_value_set_id
                AND ffvv2.flex_value = ffvc.flex_value
                AND ffvc.flex_value_set_id = ffvv2.flex_value_set_id
                AND ffvv.flex_value_set_id = 1017450) child_level
      WHERE ffvc.parent_flex_value = ffvv.flex_value
        AND ffvc.flex_value_set_id = ffvv.flex_value_set_id
        AND ffvv2.flex_value = ffvc.flex_value
        AND ffvc.flex_value_set_id = ffvv2.flex_value_set_id
        AND ffvv.flex_value_set_id = 1017450
        AND child_level.parent_flex_value(+) = ffvc.flex_value
        AND ffvv.end_date_active IS NULL
        AND ffvc.parent_flex_value like 'E%'
        AND ffvv.flex_value IN (SELECT flex_value
                                  FROM apps.fnd_flex_values_vl
                                 WHERE flex_value_set_id = 1017450
                                   AND enabled_flag = 'Y')) tab_entidade
       --alt fpavao 03/07/2019 end

where prh.requisition_header_id = prl.requisition_header_id   --- bloco Req
  and prl.requisition_line_id   = prd.requisition_line_id
  and prd.distribution_id       = pd.req_distribution_id
  and prh.preparer_id           = papf1.person_id
  and prd.code_combination_id   = gcc.code_combination_id
  and ffv.flex_value_set_id     = ffvs.flex_value_set_id
  and gcc.segment5              = ffv.flex_value
  and ffv.flex_value_set_id     = 1017450                     --- Centro Custo
  and pd.line_location_id       = pll.line_location_id        --- bloco PO
  and pd.po_line_id             = pl.po_line_id
  and pd.po_header_id           = ph.po_header_id
  and ph.po_header_id           = pl.po_header_id
  and ph.po_header_id           = pll.po_header_id
  and pl.po_line_id             = pll.po_line_id
  and prh.org_id                = hr.organization_id
  and ph.vendor_id              = pv.vendor_id
  and ph.terms_id               = apt.term_id
  and prl.item_id               = msi.inventory_item_id
  and prl.category_id           = mc.category_id
  and pa.agent_id               = ph.agent_id
  and pa.agent_id               = papf.person_id
  and msi.organization_id       = pll.ship_to_organization_id
  and pd.po_distribution_id     = cfd.po_distribution_id(+) -- Existe Recebimento
  and cfd.invoice_line_id       = cfil.invoice_line_id (+)
  and cfil.invoice_id           = cfi.invoice_id (+)
  and cfi.operation_id          = cfeo.operation_id (+)
  and cfi.organization_id       = cfeo.organization_id (+)

  and TRUNC(papf.effective_end_date) > TRUNC(SYSDATE)
  and TRUNC(papf1.effective_end_date) > TRUNC(SYSDATE)

  AND hr.NAME                   = NVL(P_EMPRESA,hr.NAME)
  AND prh.REQUISITION_HEADER_ID = NVL(P_NUM_REQ_DE,prh.REQUISITION_HEADER_ID) --BETWEEN NVL(P_NUM_REQ_DE,prh.REQUISITION_HEADER_ID) AND NVL(P_NUM_REQ_ATE,prh.REQUISITION_HEADER_ID)
  AND TRUNC(prh.CREATION_DATE) BETWEEN NVL(to_date(to_date(P_DATA_REQ_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'),TRUNC(prh.CREATION_DATE))
                              AND to_date(to_date(P_DATA_REQ_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')

  and cfeo.reversion_flag is null
  and not exists (select aux.invoice_id
                     from apps.cll_f189_invoices aux
                    where aux.organization_id = cfi.organization_id
                      and nvl(aux.invoice_parent_id,0) = cfi.invoice_id)
  and not exists (select cfri.invoice_type_id
                     from apps.cll_f189_reversion_invoices cfri
                    where cfri.organization_id = cfi.organization_id
                      and cfri.rev_invoice_type_id = cfi.invoice_type_id)

  and tab_entidade.flex_value(+) = ffv.flex_value --alt fpavao 03/07/2019

  union

select distinct null                                     nr_req_nimbi
               ,prh.segment1                             nr_req_oracle
               --Cristiano em 16/12/2019
               ,(select distinct full_name
                from apps.per_all_people_f
                where 1 = 1
                  and person_id = prl.suggested_buyer_id
                  and rownum = 1 --não filtrar inativos
                  ) comprador_sugerido_req
               ,null                                     comprador
               ,null                                     status_po
               ,hr.name                                  unidade_operacional
               ,papf1.first_name ||' '||papf1.last_name  requisitante
               ,ffv.flex_value||' - '||ffv.description   area_requisitante
               ,null                                     tipo_negociacao

               ,null                                     opex_capex

               ,mc.segment1                              categoria_item
               ,msi.segment1                             nr_item
               ,msi.description                          descricao_item
               ,null                                     descricao_po

               ,prh.approved_date                        data_aprovacao_req
               ,prl.need_by_date                         necessario_em

               --Requisicao
               ,prl.line_num                             nr_linha_req
               --Cristiano em 16/12/2019
               ,decode(nvl(prl.cancel_flag, 'N'), 'N','NAO', 'SIM')req_cancelada
               --
               --SR-503797 14/04/2020
               --status requisicao
              , case 
                  when prh.authorization_status = 'RETURNED' 
                     and nvl(prl.cancel_flag,'N') = 'N'
                        and prl.line_location_id is null then
                     'Requisicao Devolvida'
                  when (prh.authorization_status = 'RETURNED' or prh.authorization_status = 'APPROVED') 
                     and nvl(prl.cancel_flag,'N') = 'N'
                        and prl.line_location_id is not null then
                     'Linha Associada a OC'
                  else decode(prh.authorization_status,'IN PROCESS','Em Andamento'
                                              ,'APPROVED'  ,'Aprovado'
                                              ,'INCOMPLETE','Incompleto'
                                              ,'REJECTED'  ,'Rejeitado'
                                              ,'REQUIRES REAPPROVAL','Exige Reaprova磯')
              end status_linha_req
               ,prl.unit_price                           preco_req_linha
               ,prd.distribution_num                     nr_distrib_req
               ,prd.req_line_quantity                    qtd_distrib_req

               ,null                                     nr_ordem_compra
               ,null                                     moeda --23/10/2019 - Murilo Damasceno
               ,null                                     nr_linha_oc
               ,null                                     vl_preco_oc
               ,null                                     nr_distr_oc
               ,null                                     qtd_solicitada_oc
               ,null                                     vl_distrib_oc_multiplicado
               ,null                                     vl_primeira_proposta_lines

               ,null                                     saving_line

               ,null                                     percent_saving_line

               ,null                                     data_criacao_po
               ,null                                     data_aprovacao_po --23/10/2019 - Murilo Damasceno
               ,null                                     fornecedor

               ,null                                     tipo_compra
               ,null                                     prazo_pagto
               ,null                                     nr_nf
               ,null                                     data_prevista_receb
               ,null                                     observacoes
               ,null                                     data_efetiva_entrega
               ,gcc.segment4                             conta_contab
               ,tab_entidade.entidade --alt fpavao 03/07/2019
               ,'' status_negociacao --alt fpavao 03/07/2019
               ,'' fornecedor_homolog_bacen --alt fpavao 03/07/2019
               ,'' motivo_stand_by --alt fpavao 23/07/2019 - SR#333868
               ,null data_stand_by --alt fpavao 23/07/2019 - SR#333868
               ,null data_retirada_stand_by --alt fpavao 23/07/2019 - SR#333868
--Tabelas
from apps.hr_all_organization_units    hr
   , apps.fnd_flex_values_vl           ffv
   , apps.fnd_flex_value_sets          ffvs
   , apps.gl_code_combinations         gcc
   , apps.per_all_people_f             papf1
   , apps.po_requisition_headers_all   prh
   , apps.po_requisition_lines_all     prl
   , apps.po_req_distributions_all     prd
   , apps.mtl_system_items             msi
   , apps.mtl_categories               mc

   --alt fpavao 03/07/2019 begin
   , (SELECT distinct ffvv.description entidade, ffvc.flex_value
       FROM apps.fnd_flex_values_vl ffvv,
            apps.fnd_flex_value_children_v ffvc,
            apps.fnd_flex_values_vl ffvv2,
            (SELECT ffvc.parent_flex_value,
                    ffvc.flex_value,
                    ffvc.description second_child,
                    ffvv.hierarchy_level,
                    ffvv2.attribute1 user_group_second_child
               FROM apps.fnd_flex_values_vl        ffvv,
                    apps.fnd_flex_value_children_v ffvc,
                    apps.fnd_flex_values_vl        ffvv2
              WHERE ffvc.parent_flex_value = ffvv.flex_value
                AND ffvc.flex_value_set_id = ffvv.flex_value_set_id
                AND ffvv2.flex_value = ffvc.flex_value
                AND ffvc.flex_value_set_id = ffvv2.flex_value_set_id
                AND ffvv.flex_value_set_id = 1017450) child_level
      WHERE ffvc.parent_flex_value = ffvv.flex_value
        AND ffvc.flex_value_set_id = ffvv.flex_value_set_id
        AND ffvv2.flex_value = ffvc.flex_value
        AND ffvc.flex_value_set_id = ffvv2.flex_value_set_id
        AND ffvv.flex_value_set_id = 1017450
        AND child_level.parent_flex_value(+) = ffvc.flex_value
        AND ffvv.end_date_active IS NULL
        AND ffvc.parent_flex_value like 'E%'
        AND ffvv.flex_value IN (SELECT flex_value
                                  FROM apps.fnd_flex_values_vl
                                 WHERE flex_value_set_id = 1017450
                                   AND enabled_flag = 'Y')) tab_entidade
       --alt fpavao 03/07/2019 end

where prh.requisition_header_id = prl.requisition_header_id   --- bloco Req
  and prl.requisition_line_id   = prd.requisition_line_id
  and prd.distribution_id not in (select pd.req_distribution_id
                                  from apps.po_distributions_all pd
                                  where prd.distribution_id = pd.req_distribution_id)
  and prh.preparer_id           = papf1.person_id
  and prd.code_combination_id   = gcc.code_combination_id
  and ffv.flex_value_set_id     = ffvs.flex_value_set_id
  and gcc.segment5              = ffv.flex_value
  and ffv.flex_value_set_id     = 1017450                     --- Centro Custo
  and prh.org_id                = hr.organization_id
  and prl.item_id               = msi.inventory_item_id
  and prl.category_id           = mc.category_id
  and msi.organization_id       = prl.destination_organization_id
  and TRUNC(papf1.effective_end_date) > TRUNC(SYSDATE)

  AND hr.NAME                   = NVL(P_EMPRESA,hr.NAME)
  AND prh.REQUISITION_HEADER_ID = NVL(P_NUM_REQ_DE,prh.REQUISITION_HEADER_ID) --BETWEEN NVL(P_NUM_REQ_DE,prh.REQUISITION_HEADER_ID) AND NVL(P_NUM_REQ_ATE,prh.REQUISITION_HEADER_ID)
  AND TRUNC(prh.CREATION_DATE) BETWEEN NVL(to_date(to_date(P_DATA_REQ_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR'),TRUNC(prh.CREATION_DATE))
                              AND to_date(to_date(P_DATA_REQ_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')

  and tab_entidade.flex_value(+) = ffv.flex_value --alt fpavao 03/07/2019

  order by 5,2,16,18;

 l_exec varchar2(500);
 l_capex_opex varchar2(50);
 l_numero_req po_requisition_headers_all.SEGMENT1%TYPE;

 BEGIN

  --> Ativa ou desativa o log de erros de acordo com o parametro
    /*IF p_show_log = 'Y' THEN
    g_bShow_log := TRUE;
  END IF;*/

  l_exec := 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS='',.''';

  execute immediate l_exec;

  show_error_log_p(p_message => 'Inicio do relatorio gen_relat_po_req_p');

  --gen_xml_p('<?xml version="1.0" encoding="UTF-8"?>');
  gen_xml_p('<?xml version="1.0" encoding="ISO-8859-1"?>');
  gen_xml_p('<HEADERS>');

  gen_xml_p(' <HEADER>');

  BEGIN

   SELECT segment1
     INTO l_numero_req
     FROM po_requisition_headers_all
    WHERE requisition_header_id = P_NUM_REQ_DE;

   EXCEPTION
    WHEN OTHERS THEN
     l_numero_req := NULL;

  END;

  gen_xml_p('    <EMPRESA>'  || P_EMPRESA ||'</EMPRESA>');
  gen_xml_p('    <NR_REQ>'  || l_numero_req ||'</NR_REQ>');
  gen_xml_p('    <DATA_REQ_DE>'  || to_char(to_date(P_DATA_REQ_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR') ||'</DATA_REQ_DE>');
  gen_xml_p('    <DATA_REQ_ATE>'  || to_char(to_date(P_DATA_REQ_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')  ||'</DATA_REQ_ATE>');

  FOR R_DADOS_KPI IN C_DADOS_KPI LOOP

   IF R_DADOS_KPI.conta_contab LIKE '4%' THEN

    l_capex_opex := 'Opex';

   ELSIF R_DADOS_KPI.conta_contab LIKE '125%' OR R_DADOS_KPI.conta_contab LIKE '126%' THEN

    l_capex_opex := 'Capex';

   ELSE

    l_capex_opex := 'Outros';

   END IF;

   gen_xml_p('   <LINES_KPI>');

    gen_xml_p('    <NR_REQ_NIMBI>'  || conv_spc_chr(R_DADOS_KPI.NR_REQ_NIMBI) ||'</NR_REQ_NIMBI>');
    gen_xml_p('    <NR_REQ_ORACLE>'  || conv_spc_chr(R_DADOS_KPI.NR_REQ_ORACLE) ||'</NR_REQ_ORACLE>');
    --Cristiano em 16/12/2019
    gen_xml_p('    <COMPRADOR_SUGERIDO_REQ>'  || conv_spc_chr(R_DADOS_KPI.comprador_sugerido_req) ||'</COMPRADOR_SUGERIDO_REQ>');
    --
    gen_xml_p('    <COMPRADOR>'  || conv_spc_chr(R_DADOS_KPI.COMPRADOR) ||'</COMPRADOR>');
    gen_xml_p('    <STATUS_PO>'  || conv_spc_chr(R_DADOS_KPI.STATUS_PO) ||'</STATUS_PO>');
    gen_xml_p('    <UNIDADE_OPERACIONAL>'  || conv_spc_chr(R_DADOS_KPI.UNIDADE_OPERACIONAL) ||'</UNIDADE_OPERACIONAL>');
    gen_xml_p('    <REQUISITANTE>'  || conv_spc_chr(R_DADOS_KPI.REQUISITANTE) ||'</REQUISITANTE>');
    gen_xml_p('    <ENTIDADE>'  || conv_spc_chr(R_DADOS_KPI.ENTIDADE) ||'</ENTIDADE>'); --alt fpavao 03/07/2019
    gen_xml_p('    <AREA_REQUISITANTE>'  || conv_spc_chr(R_DADOS_KPI.AREA_REQUISITANTE) ||'</AREA_REQUISITANTE>');
    gen_xml_p('    <TIPO_NEGOCIACAO>'  || conv_spc_chr(R_DADOS_KPI.TIPO_NEGOCIACAO) ||'</TIPO_NEGOCIACAO>');
    gen_xml_p('    <STATUS_NEGOCIACAO>'  || conv_spc_chr(R_DADOS_KPI.STATUS_NEGOCIACAO) ||'</STATUS_NEGOCIACAO>');--alt fpavao 03/07/2019
    gen_xml_p('    <MOTIVO_STAND_BY>'  || conv_spc_chr(R_DADOS_KPI.MOTIVO_STAND_BY) ||'</MOTIVO_STAND_BY>'); --alt fpavao 23/07/2019 - SR#333868
    gen_xml_p('    <DATA_STAND_BY>'  || TO_CHAR(R_DADOS_KPI.DATA_STAND_BY,'DD/MM/RRRR') ||'</DATA_STAND_BY>'); --alt fpavao 23/07/2019 - SR#333868
    gen_xml_p('    <DATA_RETIRADA_STAND_BY>'  || TO_CHAR(R_DADOS_KPI.DATA_RETIRADA_STAND_BY,'DD/MM/RRRR') ||'</DATA_RETIRADA_STAND_BY>'); --alt fpavao 23/07/2019 - SR#333868
    gen_xml_p('    <FORNECEDOR_HOMOLOG_BACEN>'  || conv_spc_chr(R_DADOS_KPI.FORNECEDOR_HOMOLOG_BACEN) ||'</FORNECEDOR_HOMOLOG_BACEN>');--alt fpavao 03/07/2019
    gen_xml_p('    <OPEX_CAPEX>'  || conv_spc_chr(l_capex_opex) ||'</OPEX_CAPEX>');
    gen_xml_p('    <CATEGORIA_ITEM>'  || conv_spc_chr(R_DADOS_KPI.CATEGORIA_ITEM) ||'</CATEGORIA_ITEM>');
    gen_xml_p('    <NR_ITEM>'  || conv_spc_chr(R_DADOS_KPI.NR_ITEM) ||'</NR_ITEM>');
    gen_xml_p('    <DESCRICAO_ITEM>'  || conv_spc_chr(R_DADOS_KPI.DESCRICAO_ITEM) ||'</DESCRICAO_ITEM>');
    gen_xml_p('    <DESCRICAO_PO>'  || conv_spc_chr(R_DADOS_KPI.DESCRICAO_PO) ||'</DESCRICAO_PO>');
    gen_xml_p('    <DATA_APROVACAO_REQ>'  || TO_CHAR(R_DADOS_KPI.DATA_APROVACAO_REQ,'DD/MM/RRRR') ||'</DATA_APROVACAO_REQ>');
    gen_xml_p('    <NECESSARIO_EM>'  || TO_CHAR(R_DADOS_KPI.NECESSARIO_EM,'DD/MM/RRRR') ||'</NECESSARIO_EM>');
    gen_xml_p('    <NR_LINHA_REQ>'  || conv_spc_chr(R_DADOS_KPI.NR_LINHA_REQ) ||'</NR_LINHA_REQ>');
    --Cristiano em 16/12/2019
    gen_xml_p('    <REQ_CANCELADA>'  || conv_spc_chr(R_DADOS_KPI.req_cancelada) ||'</REQ_CANCELADA>');
    --
    --Cristiano 14/04/2020  SR-503797 
    gen_xml_p('    <STATUS_LINHA_REQ>'  || conv_spc_chr(R_DADOS_KPI.status_linha_req) ||'</STATUS_LINHA_REQ>');
    
    gen_xml_p('    <PRECO_REQ_LINHA>'  || LTRIM(TO_CHAR(conv_spc_chr(R_DADOS_KPI.PRECO_REQ_LINHA),'999G999G990D00')) ||'</PRECO_REQ_LINHA>');
    gen_xml_p('    <NR_DISTRIB_REQ >'  || conv_spc_chr(R_DADOS_KPI.NR_DISTRIB_REQ ) ||'</NR_DISTRIB_REQ >');
    gen_xml_p('    <QTD_DISTRIB_REQ>'  || conv_spc_chr(R_DADOS_KPI.QTD_DISTRIB_REQ) ||'</QTD_DISTRIB_REQ>');
    gen_xml_p('    <DATA_CRIACAO_PO>'  || TO_CHAR(R_DADOS_KPI.DATA_CRIACAO_PO,'DD/MM/RRRR') ||'</DATA_CRIACAO_PO>'); --alt fpavao 23/07/2019 - SR#333868
    gen_xml_p('    <DATA_APROVACAO_PO>'  || TO_CHAR(R_DADOS_KPI.DATA_APROVACAO_PO,'DD/MM/RRRR') ||'</DATA_APROVACAO_PO>');--23/10/2019 - Murilo Damasceno
    gen_xml_p('    <FORNECEDOR>'  || conv_spc_chr(R_DADOS_KPI.FORNECEDOR) ||'</FORNECEDOR>');
    gen_xml_p('    <NR_ORDEM_COMPRA>'  || conv_spc_chr(R_DADOS_KPI.NR_ORDEM_COMPRA) ||'</NR_ORDEM_COMPRA>');
    gen_xml_p('    <MOEDA>'  || conv_spc_chr(R_DADOS_KPI.MOEDA) ||'</MOEDA>'); --23/10/2019 - Murilo Damasceno
    gen_xml_p('    <NR_LINHA_OC>'  || conv_spc_chr(R_DADOS_KPI.NR_LINHA_OC) ||'</NR_LINHA_OC>');
    gen_xml_p('    <VL_PRECO_OC>'  || LTRIM(TO_CHAR(conv_spc_chr(R_DADOS_KPI.VL_PRECO_OC),'999G999G990D00')) ||'</VL_PRECO_OC>');
    gen_xml_p('    <NR_DISTR_OC>'  || conv_spc_chr(R_DADOS_KPI.NR_DISTR_OC) ||'</NR_DISTR_OC>');
    gen_xml_p('    <QTD_SOLICITADA_OC>'  || conv_spc_chr(R_DADOS_KPI.QTD_SOLICITADA_OC) ||'</QTD_SOLICITADA_OC>');
    gen_xml_p('    <VL_DISTRIB_OC_MULTIPLICADO>'  || LTRIM(TO_CHAR(conv_spc_chr(R_DADOS_KPI.VL_DISTRIB_OC_MULTIPLICADO),'999G999G990D00')) ||'</VL_DISTRIB_OC_MULTIPLICADO>');
    gen_xml_p('    <VL_PRIMEIRA_PROPOSTA_LINES>'  || LTRIM(TO_CHAR(conv_spc_chr(R_DADOS_KPI.VL_PRIMEIRA_PROPOSTA_LINES),'999G999G990D00')) ||'</VL_PRIMEIRA_PROPOSTA_LINES>');
    gen_xml_p('    <SAVING_LINE>'  || LTRIM(TO_CHAR(conv_spc_chr(R_DADOS_KPI.SAVING_LINE),'999G999G990D00')) ||'</SAVING_LINE>');
    gen_xml_p('    <PERCENT_SAVING_LINE>'  || LTRIM(TO_CHAR(conv_spc_chr(R_DADOS_KPI.PERCENT_SAVING_LINE),'999G999G990D00')) ||'</PERCENT_SAVING_LINE>');
    gen_xml_p('    <TIPO_COMPRA>'  || conv_spc_chr(R_DADOS_KPI.TIPO_COMPRA) ||'</TIPO_COMPRA>');
    gen_xml_p('    <PRAZO_PAGTO>'  || conv_spc_chr(R_DADOS_KPI.PRAZO_PAGTO) ||'</PRAZO_PAGTO>');
    gen_xml_p('    <NR_NF>'  || conv_spc_chr(R_DADOS_KPI.NR_NF) ||'</NR_NF>');
    gen_xml_p('    <DATA_PREVISTA_RECEB>'  || TO_CHAR(R_DADOS_KPI.DATA_PREVISTA_RECEB,'DD/MM/RRRR') ||'</DATA_PREVISTA_RECEB>');
    gen_xml_p('    <OBSERVACOES>'  || conv_spc_chr(R_DADOS_KPI.OBSERVACOES) ||'</OBSERVACOES>');
    gen_xml_p('    <DATA_EFETIVA_ENTREGA>'  || TO_CHAR(R_DADOS_KPI.DATA_EFETIVA_ENTREGA,'DD/MM/RRRR') ||'</DATA_EFETIVA_ENTREGA>');

   gen_xml_p('   </LINES_KPI>');

  END LOOP;

  gen_xml_p(' </HEADER>');

  gen_xml_p('</HEADERS>');

 END gen_relat_po_kpi_p;

 PROCEDURE show_error_log_p(p_message IN VARCHAR2) IS
 BEGIN
  IF g_bShow_log THEN
    fnd_file.put_line(fnd_file.log, p_message);
  END IF;
 END show_error_log_p;

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER IS

  l_vDecimal_char VARCHAR2(1);

 BEGIN
  --> Recupera o character decimal
  l_vDecimal_char := substr(ltrim(to_char(.3, '0D0')), 2, 1);

  --> Transforma o varchar para um nÿºmero com um decimal vÿ¡lido
  IF l_vDecimal_char = ',' THEN
    RETURN round(to_number(translate(p_value, '.', l_vDecimal_char)), 20);
  ELSE
    RETURN round(to_number(translate(p_value, ',', l_vDecimal_char)), 20);
  END IF;

 END canonical_to_number_f;
 --

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2 IS

  l_vReturn      VARCHAR2(20);
  l_nDecimal_qty NUMBER;
  l_nMask_qty    NUMBER;
  l_vMask        VARCHAR2(100);

 BEGIN

  l_vMask := p_mask;
  l_nMask_qty := length(substr(l_vMask, instr(l_vMask, '.') + 1));

  --> Verifica se deve criar uma mÿ¡scara com mais de 3 decimais- INICIO
  IF l_nMask_qty > 3 THEN

    --> Verifica se hÿ¡ decimais no valor - INICIO
    IF instr(to_char(translate(p_value, ',', '.')), '.') = 0 THEN
      l_nDecimal_qty := 0;
    ELSE
      --> Armazena a quantidade de digitos de decimais
      l_nDecimal_qty := length(substr(to_char(translate(p_value, ',', '.')), instr(to_char(translate(p_value, ',', '.')), '.') + 1));
    END IF;

    --> Verifica se a mascara retornou menos que 2
    IF l_nDecimal_qty <= 2 THEN
      l_nDecimal_qty := 2;
    END IF;

    --> Gera uma novas mÿ¡scara com a quantidade de decimais necessÿ¡rias
    l_vMask := substr(l_vMask, 1,  instr(l_vMask, '.')) || rpad('0', l_nDecimal_qty, '0');

  END IF;

  l_vReturn := lpad(to_char(p_value, l_vMask), 20, ' ');
  l_vReturn := REPLACE( l_vReturn, ',', '@' );
  l_vReturn := REPLACE( l_vReturn, '.', ',' );
  l_vReturn := REPLACE( l_vReturn, '@', '.' );

  RETURN(trim(l_vReturn));

 END format_br_mask_f;
 --

 -- Funÿ§ÿ£o que retorna valor por extenso:
 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2 IS

  valor_string VARCHAR2(256);
  valor_conv   VARCHAR2(25);
  tres_digitos VARCHAR2(3);
  texto_string VARCHAR2(256);
  ind          NUMBER;

 BEGIN
  valor_conv := to_char(trunc((abs(valor) * 100)
                             ,0)
                       ,'0999999999999999999');
  valor_conv := substr(valor_conv
                      ,1
                      ,18) || '0' || substr(valor_conv
                                           ,19
                                           ,2);
  IF to_number(valor_conv) = 0 THEN
    RETURN('Zero ');
  END IF;

  FOR ind IN 1 .. 7 LOOP
    tres_digitos := substr(valor_conv
                          ,(((ind - 1) * 3) + 1)
                          ,3);
    texto_string := '';

    -- Extenso para Centena
    IF substr(tres_digitos
             ,1
             ,1) = '2' THEN
      texto_string := texto_string || 'Duzentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '3' THEN
      texto_string := texto_string || 'Trezentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '4' THEN
      texto_string := texto_string || 'Quatrocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '5' THEN
      texto_string := texto_string || 'Quinhentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '6' THEN
      texto_string := texto_string || 'Seiscentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '7' THEN
      texto_string := texto_string || 'Setecentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '9' THEN
      texto_string := texto_string || 'Novecentos ';
    END IF;

    IF substr(tres_digitos
             ,1
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,2
               ,2) = '00' THEN
        texto_string := texto_string || 'Cem ';
      ELSE
        texto_string := texto_string || 'Cento ';
      END IF;

    END IF;
    -- Extenso para Dezena
    IF substr(tres_digitos
             ,2
             ,1) <> '0'
       AND texto_string IS NOT NULL THEN
      texto_string := texto_string || 'e ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '2' THEN
      texto_string := texto_string || 'Vinte ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '3' THEN
      texto_string := texto_string || 'Trinta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '4' THEN
      texto_string := texto_string || 'Quarenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '5' THEN
      texto_string := texto_string || 'Cinquenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '6' THEN
      texto_string := texto_string || 'Sessenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '7' THEN
      texto_string := texto_string || 'Setenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '9' THEN
      texto_string := texto_string || 'Noventa ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,3
               ,1) <> '0' THEN

        IF substr(tres_digitos
                 ,3
                 ,1) = '1' THEN
          texto_string := texto_string || 'Onze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '2' THEN
          texto_string := texto_string || 'Doze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '3' THEN
          texto_string := texto_string || 'Treze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '4' THEN
          texto_string := texto_string || 'Quatorze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '5' THEN
          texto_string := texto_string || 'Quinze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '6' THEN
          texto_string := texto_string || 'Dezesseis ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '7' THEN
          texto_string := texto_string || 'Dezessete ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '8' THEN
          texto_string := texto_string || 'Dezoito ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '9' THEN
          texto_string := texto_string || 'Dezenove ';
        END IF;

      ELSE
        texto_string := texto_string || 'Dez ';
      END IF;

    ELSE

      -- Extenso para Unidade
      IF substr(tres_digitos
               ,3
               ,1) <> '0'
         AND texto_string IS NOT NULL THEN
        texto_string := texto_string || 'e ';
      END IF;

      IF substr(tres_digitos
               ,3
               ,1) = '1' THEN
        texto_string := texto_string || 'Um ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '2' THEN
        texto_string := texto_string || 'Dois ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '3' THEN
        texto_string := texto_string || 'Tres ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '4' THEN
        texto_string := texto_string || 'Quatro ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '5' THEN
        texto_string := texto_string || 'Cinco ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '6' THEN
        texto_string := texto_string || 'Seis ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '7' THEN
        texto_string := texto_string || 'Sete ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '8' THEN
        texto_string := texto_string || 'Oito ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '9' THEN
        texto_string := texto_string || 'Nove ';
      END IF;

    END IF;

    IF to_number(tres_digitos) > 0 THEN
      IF to_number(tres_digitos) = 1 THEN
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhÿ£o ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhÿ£o ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhÿ£o ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhÿ£o ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      ELSE
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhÿµes ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhÿµes ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhÿµes ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhÿµes ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      END IF;
    END IF;
    valor_string := valor_string || texto_string;
    -- Escrita da Moeda Corrente
    IF ind = 5 THEN
      IF to_number(substr(valor_conv
                         ,16
                         ,3)) > 0
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    ELSE
      IF ind < 5
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    END IF;
    IF ind = 6 THEN
      IF to_number(substr(valor_conv
                         ,1
                         ,18)) > 1 THEN
        valor_string := valor_string || 'Reais ';
      ELSIF to_number(substr(valor_conv
                            ,1
                            ,18)) = 1 THEN
        valor_string := valor_string || 'Real ';
      END IF;

      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 0
         AND length(valor_string) > 0 THEN
        valor_string := valor_string || 'e ';
      END IF;
    END IF;
    -- Escrita para Centavos
    IF ind = 7 THEN
      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 1 THEN
        valor_string := valor_string || 'Centavos ';
      ELSIF to_number(substr(valor_conv
                            ,20
                            ,2)) = 1 THEN
        valor_string := valor_string || 'Centavo ';
      END IF;
    END IF;
  END LOOP;
  RETURN(rtrim(valor_string));
 EXCEPTION
  WHEN OTHERS THEN
    RETURN('*** VALOR INVALIDO ***');
 END;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2 IS

  l_vChar VARCHAR2(4000) := p_char;

 BEGIN
  l_vChar := REPLACE(l_vChar, chr(38), chr(38) || 'amp;');
  l_vChar := REPLACE(l_vChar, '<', ';');
  l_vChar := REPLACE(l_vChar, '>', ';');
  l_vChar := REPLACE(l_vChar, '"', ';');
  l_vChar := REPLACE(l_vChar, '''', ';');
  l_vChar := REPLACE(l_vChar, 'ÿº', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'C');
  l_vChar := REPLACE(l_vChar, 'ÿ§', 'c');
  l_vChar := REPLACE(l_vChar, 'ÿ§', 'c');
  l_vChar := REPLACE(l_vChar, 'ÿ£', 'a');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'A');
  l_vChar := REPLACE(l_vChar, 'ÿ©', 'e');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'E');
  l_vChar := REPLACE(l_vChar, 'ÿ­', 'i');
  l_vChar := REPLACE(l_vChar, 'ÿ?', 'I');
  l_vChar := REPLACE(l_vChar, 'ÿ³', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'O');
  l_vChar := REPLACE(l_vChar, 'ÿº', 'u');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'U');

  RETURN(l_vChar);
 END conv_spc_chr;
 --

 PROCEDURE gen_xml_p(p_message IN VARCHAR2) IS
 BEGIN
   IF g_bGen_XML THEN
     -- Gera Log de execucao
     dbms_output.put_line(p_message);
   ELSE
     -- Grava saida do concurrent:
     fnd_file.put_line(fnd_file.output,p_message);
   END IF;

 END gen_xml_p;
 --
END XXSTN_PO_REL_KPI_COMP_PKG;
/

EXIT;