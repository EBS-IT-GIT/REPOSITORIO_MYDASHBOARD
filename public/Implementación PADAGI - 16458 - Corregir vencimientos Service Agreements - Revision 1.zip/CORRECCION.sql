DECLARE
xamt NUMBER;
CURSOR c_inv IS
    SELECT customer_trx_id
          ,org_id
    FROM   apps.ra_customer_trx_all
    WHERE  customer_trx_id IN (14603208);

BEGIN
    FOR c1 IN c_inv LOOP
        MO_GLOBAL.SET_POLICY_CONTEXT('S',c1.org_id);
        ARP_MAINTAIN_PS.MAINTAIN_PAYMENT_SCHEDULES('I',c1.customer_trx_id,null,null,null,null,null,xamt,null);
        dbms_output.put_line('Actualizacion existosa customer_trx_id: '||c1.customer_trx_id||' - payment_schedule_id: '||xamt);
    END LOOP;

    update xxw_fac_tmp 
    set fecha_vto_cae =to_date ('20200430','yyyymmdd')
         , CAE = '70181558897450'
         , FEX_ERROR_MSG = NULL
         , FEX_EV_ERROR_MSG = NULL
         , FEX_EV_ERROR_CODE = NULL
         , RESULTADO = 'P'
    WHERE id = 14603208;

    UPDATE apps.ra_customer_trx_all
    SET    COMPLETE_FLAG = 'Y'
    WHERE  customer_trx_id IN (14603208);

    COMMIT;
   
EXCEPTION
WHEN OTHERS THEN
   dbms_output.put_line('Error: '||sqlerrm);

END;