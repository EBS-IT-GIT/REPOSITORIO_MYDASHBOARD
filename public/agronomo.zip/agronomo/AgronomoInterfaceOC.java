import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 *
 * @author apetrocelli
 */
public class AgronomoInterfaceOC {
  public static void main(String args[]){  

    String p_action = args[0];
    String p_org_code = args[1];
    String p_fecha_desde = args[2];
    String p_fecha_hasta = args[3];
    String p_request_id  = args[4];
    String p_modo_ejec   = args[5];

    String l_org_code = null;
    if (p_org_code.equalsIgnoreCase("null")) l_org_code = "est.organizacion = est.organizacion"; 
    else l_org_code = "est.organizacion = '"+p_org_code+"'";

    Properties prop = new Properties();
    InputStream configfile;

    String mySQLConnURL;
    Connection mySQLConn = null;

    String oraConnURL;
    Connection oraConn = null;
    
    String sqlStmt = null;
    try {
      configfile = new FileInputStream("agronomo.properties");
      prop.load(configfile);
      } catch (FileNotFoundException e) {
        System.out.println(e.getMessage());
      } catch (IOException e) {
        System.out.println(e.getMessage());
      }

    // OPEN mySQL Connection
    try {
      mySQLConnURL = prop.getProperty("mySQLConURL");
      String mySQLuser = prop.getProperty("mySQLuser");
      String mySQLpassword = prop.getProperty("mySQLpassword");
      System.out.println ("mySQLConnectionString = " + mySQLConnURL);
      Class.forName("com.mysql.jdbc.Driver");
      mySQLConn = DriverManager.getConnection(mySQLConnURL, mySQLuser, mySQLpassword);
      mySQLConn.setAutoCommit(false);
      System.out.println("Conectado a mySQL");

      oraConnURL = prop.getProperty("oraConURL");
      System.out.println ("mySQLConnectionString = " + oraConnURL);
      Class.forName("oracle.jdbc.driver.OracleDriver");
      oraConn = DriverManager.getConnection(oraConnURL);
      oraConn.setAutoCommit(false);
      System.out.println("Conectado a Oracle");
    } catch(ClassNotFoundException e) { 
        System.out.println(e.getMessage());
    } catch (SQLException e) {
        System.out.println(e.getMessage()+"\n"+sqlStmt);
    } 

    Statement mySQLStmt;
    Statement mySQLStmtLine;
    Statement mySQLStmtUpd;
    ResultSet mySQLrs;
    ResultSet mySQLrsLine;
    Statement oraStmt;
    ResultSet orars;

    if (p_action.equalsIgnoreCase("PROCESS_NEWS")){
        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT DISTINCT\n" +
                  "       ot.id                 orden_trabajo\n" +
                  "     , ot.fecha              orden_trabajo_fecha\n" +
                  "     , c.created             fecha_certifica\n" +
                  "     , eo.codigo             unidad_operativa\n" +
                  "     , est.id_organizacion   organizacion_id\n" +
                  "     , est.organizacion      organizacion_codigo\n" +
                  "     , s.id_organizacion     organizacion_envio\n" +
                  "     , al.sub_inventario     subinventario\n" +
                  "     , est.envio             direccion_envio\n" +
                  "     , est.facturacion       direccion_facturacion\n" +
                  "     , CASE WHEN IFNULL(c.moneda_id,1) = 1 THEN 'ARS'\n" +
                  "            WHEN c.moneda_id = 2 THEN 'USD'\n" +
                  "       END moneda\n" +
                  "     , s.id_proveedor_oracle proveedor_id\n" +
                  "     , c.comprador_id_oracle comprador_id\n" +
                  "     , SUBSTR(XX_REFERENCIA_OT(ot.id, est.nombre, s.nombre),1,240) referencia\n" +
                  "     , IFNULL(ot.oracle_oc_flag,'N') oracle_flag\n" +
                  "FROM orden_trabajos                ot\n" +
                  "   , orden_trabajos_estados        ots\n" +
                  "   , orden_trabajos_distribuciones otd\n" +
                  "   , (SELECT otc.orden_trabajo_id, otc.id, otc.created, otc.fecha_final, u.comprador_id_oracle, otc.moneda_id\n" +
                  "      FROM orden_trabajos_certificaciones otc\n" +
                  "         , (SELECT orden_trabajo_id ot_id, MAX(id) cert_id\n" +
                  "            FROM orden_trabajos_certificaciones\n" +
                  "            GROUP BY orden_trabajo_id\n" +
                  "           ) cert\n" +
                  "         , users u\n" +
                  "      WHERE 1=1\n" +
                  "      AND cert.ot_id   = otc.orden_trabajo_id\n" +
                  "      AND cert.cert_id = otc.id\n" +
                  "      AND u.id         = otc.user_id\n" +
                  "     )                             c\n" +
                  "   , proyectos                     p\n" +
                  "   , establecimientos              est LEFT JOIN (SELECT establecimiento_id, MIN(sub_inventario) sub_inventario\n" +
                  "                                                  FROM almacenes\n" +
                  "                                                  GROUP BY establecimiento_id) al ON est.id = al.establecimiento_id\n" +
                  "   , establecimientos_organizaciones eo\n" +
                  "   , proveedores                   s\n" +
                  "WHERE 1=1\n" +
                  "AND ots.id     = ot.orden_trabajos_estado_id\n" +
                  "AND otd.orden_trabajo_id = ot.id\n" +
                  "AND c.orden_trabajo_id = ot.id\n" +
                  "AND p.id       = otd.proyecto_id\n" +
                  "AND est.id     = ot.establecimiento_id\n" +
                  "AND eo.id      = est.establecimientos_organizacione_id\n" +
                  "AND s.id       = ot.proveedore_id\n" +
                  "AND ots.nombre = 'Certificada'\n" +
                  "AND IFNULL(ot.oracle_oc_flag,'N') IN ('N', 'P', 'R')\n" +
                  "AND ot.orden_trabajos_dataload_id IS NULL\n" +
                  "AND "+l_org_code+"\n" + 
                  "AND DATE(c.created) >= '"+p_fecha_desde+"'\n" +
                  "AND DATE(c.created) <= '"+p_fecha_hasta+"'\n" +
                  "ORDER BY ot.id"
                  ;

          //System.out.println(sqlStmt);
          mySQLStmt     = mySQLConn.createStatement();
          mySQLStmtLine = mySQLConn.createStatement();
          mySQLStmtUpd  = mySQLConn.createStatement();
          oraStmt       = oraConn.createStatement();

          mySQLrs = mySQLStmt.executeQuery(sqlStmt);
          int rowi_count = 0;
          int rowu_count = 0;
          while(mySQLrs.next()) {
            if (mySQLrs.getString("oracle_flag").equalsIgnoreCase("N")){
                sqlStmt =
                        "INSERT INTO ADECO_BI.XX_AGRONOMO_INTERFACE_OC\n"+
                        "( ORDEN_TRABAJO\n" +
                        ", ORDEN_TRABAJO_FECHA\n" +
                        ", FECHA_CERTIFICACION\n" +
                        ", UNIDAD_OPERATIVA\n" +
                        ", ORGANIZACION_ID\n" +
                        ", ORGANIZACION_CODIGO\n" +
                        ", ORGANIZACION_ENVIO\n" +
                        ", SUBINVENTARIO\n" +
                        ", DIRECCION_ENVIO\n" +
                        ", DIRECCION_FACTURACION\n" +
                        ", MONEDA\n" +
                        ", PROVEEDOR_ID\n" +
                        ", REFERENCIA\n" +
                        ", COMPRADOR_ID\n" +
                        ", IMPORTADO_FLAG\n" +
                        ", CREATION_DATE\n" +
                        ", LAST_UPDATE_DATE\n" +
                        ", REQUEST_ID\n" +
                        ") VALUES\n"+
                        "("+mySQLrs.getInt("orden_trabajo")+"\n"+
                        ",TO_DATE('"+mySQLrs.getDate("orden_trabajo_fecha")+"', 'YYYY/MM/DD')\n"+
                        ",TO_DATE('"+mySQLrs.getDate("fecha_certifica")+"', 'YYYY/MM/DD')\n"+
                        ","+mySQLrs.getInt("unidad_operativa")+"\n"+
                        ","+mySQLrs.getInt("organizacion_id")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("organizacion_codigo")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("organizacion_envio")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("subinventario")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("direccion_envio")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("direccion_facturacion")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("moneda")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("proveedor_id")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("referencia")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("comprador_id")+"\n"+
                        ",'N'\n"+
                        ",SYSDATE\n"+
                        ",SYSDATE\n"+
                        ","+p_request_id+"\n"+
                        ")\n";

                rowi_count = rowi_count +1;
            } else {
               sqlStmt =
                        "UPDATE ADECO_BI.XX_AGRONOMO_INTERFACE_OC\n"+
                        "SET ORDEN_TRABAJO       = "+mySQLrs.getInt("orden_trabajo")+"\n"+
                        "  , ORDEN_TRABAJO_FECHA = "+"TO_DATE('"+mySQLrs.getDate("orden_trabajo_fecha")+"', 'YYYY/MM/DD')\n"+
                        "  , FECHA_CERTIFICACION = "+"TO_DATE('"+mySQLrs.getDate("fecha_certifica")+"', 'YYYY/MM/DD')\n"+
                        "  , UNIDAD_OPERATIVA    = "+mySQLrs.getInt("unidad_operativa")+"\n"+
                        "  , ORGANIZACION_ID     = "+mySQLrs.getInt("organizacion_id")+"\n"+
                        "  , ORGANIZACION_CODIGO = "+"REPLACE(REPLACE('"+mySQLrs.getString("organizacion_codigo")+"',chr(10),''),chr(13),'')\n"+
                        "  , ORGANIZACION_ENVIO  = "+"REPLACE(REPLACE('"+mySQLrs.getString("organizacion_envio")+"',chr(10),''),chr(13),'')\n"+
                        "  , SUBINVENTARIO       = "+"REPLACE(REPLACE('"+mySQLrs.getString("subinventario")+"',chr(10),''),chr(13),'')\n"+
                        "  , DIRECCION_ENVIO     = "+"REPLACE(REPLACE('"+mySQLrs.getString("direccion_envio")+"',chr(10),''),chr(13),'')\n"+
                        "  , DIRECCION_FACTURACION = "+"REPLACE(REPLACE('"+mySQLrs.getString("direccion_facturacion")+"',chr(10),''),chr(13),'')\n"+
                        "  , MONEDA              = "+"REPLACE(REPLACE('"+mySQLrs.getString("moneda")+"',chr(10),''),chr(13),'')\n"+
                        "  , PROVEEDOR_ID        = "+mySQLrs.getInt("proveedor_id")+"\n"+
                        "  , REFERENCIA          = "+"REPLACE(REPLACE('"+mySQLrs.getString("referencia")+"',chr(10),''),chr(13),'')\n"+
                        "  , COMPRADOR_ID        = "+mySQLrs.getInt("comprador_id")+"\n"+
                        "  , IMPORTADO_FLAG      = "+"'"+mySQLrs.getString("oracle_flag")+"'\n"+
                        "  , LAST_UPDATE_DATE    = SYSDATE\n" + 
                        "  , REQUEST_ID          = "+p_request_id+"\n"+
                        "WHERE 1=1\n" +
                        "AND ORDEN_TRABAJO = "+mySQLrs.getInt("orden_trabajo");

                rowu_count = rowu_count +1;
            }

            //System.out.println(sqlStmt);
            oraStmt.executeUpdate(sqlStmt);

            sqlStmt = "SELECT ot.id                 orden_trabajo\n" +
                      "     , otc.id                certificado_id\n" +
                      "     , otc.created           fecha_certifica\n" +
                      "     , otc.fecha_final       fecha_labor\n" +
                      "     , pl.nombre             proyecto_labor\n" +
                      "     , uom.nombre            unidad_medida\n" +
                      "     , otc.has               cantidad\n" +
                      "     , otc.precio_final      precio\n" +
                      "     , pt.categoria\n" +
                      "     , sec.id_establecimiento_oracle estab_id\n" +
                      "     , l.nombre              lote\n" +
                      "     , p.cultivo\n" +
                      "     , p.segmento            proyecto\n" +
                      "     , pl.task_number        tarea\n" +
                      "     , pl.expenditure_type   tipo_erogacion\n" +
                      //"     , usr.grupo_negocio\n" +
                      //"     , ot.observaciones\n" +
                      "     , SUBSTR(CONCAT('OT:', ot.id, '_', sec.nombre, '_', pl.expenditure_type, '_', uom.nombre, '_', l.nombre, '_', otc.precio_final, '_', ot.observaciones),1,240) referencia\n" +
                      "     , IFNULL(otc.oracle_flag,'N') oracle_flag\n" +
                      "FROM orden_trabajos                 ot\n" +
                      "   , orden_trabajos_distribuciones  otd\n" +
                      "   , proyectos                      p\n" +
                      "   , proyectos_labores              pl\n" +
                      "   , proyectos_tareas               pt\n" +
                      "   , establecimientos               e\n" +
                      "   , users                          usr\n" +
                      "   , lotes                          l\n" +
                      "   , sectores                       sec\n" +
                      "   , orden_trabajos_certificaciones otc\n" +
                      "   , unidades                       uom\n" +
                      "WHERE 1=1\n" +
                      "AND otd.orden_trabajo_id = ot.id\n" +
                      "AND p.id       = otd.proyecto_id\n" +
                      "AND pl.id      = otd.proyectos_labore_id\n" +
                      "AND e.id       = ot.establecimiento_id\n" +
                      "AND usr.id     = otc.user_id\n" +
                      "AND l.id       = otd.lote_id\n" +
                      "AND sec.id     = l.sectore_id\n" +
                      "AND otc.orden_trabajos_distribucione_id = otd.id\n" +
                      "AND uom.id     = otd.unidade_id\n" +
                      "AND pt.id      = pl.proyectos_tarea_id\n" +
                      "AND otc.deleted IS NULL\n" +
                      "AND IFNULL(otc.oracle_flag,'N') IN ('N', 'P', 'R')\n" +
                      "AND ot.id = "+mySQLrs.getInt("orden_trabajo")+"\n" +
                      "ORDER BY ot.id, otc.id";
            
            mySQLrsLine = mySQLStmtLine.executeQuery(sqlStmt);
            while(mySQLrsLine.next()) {
              if (mySQLrsLine.getString("oracle_flag").equalsIgnoreCase("N")){
                  sqlStmt =
                          "INSERT INTO ADECO_BI.XX_AGRONOMO_INTERFACE_OC_LINEA\n"+
                          "( ORDEN_TRABAJO\n" +
                          ", CERTIFICADO_ID\n" +
                          ", FECHA_CERTIFICACION\n" +
                          ", FECHA_LABOR\n" +
                          ", PROYECTO_LABOR\n" +
                          ", UOM\n" +
                          ", CANTIDAD\n" +
                          ", PRECIO\n" +
                          ", CATEGORIA\n" +
                          ", ESTABLECIMIENTO_ID\n" +
                          ", LOTE\n" +
                          ", CULTIVO\n" +
                          ", PROYECTO\n" +
                          ", TAREA\n" +
                          ", TIPO_EROGACION\n" +
                          ", REFERENCIA\n" +
                          ", IMPORTADO_FLAG\n" +
                          ", CREATION_DATE\n" +
                          ", LAST_UPDATE_DATE\n" +
                          ", REQUEST_ID\n" +
                          ") VALUES\n"+
                          "("+mySQLrsLine.getInt("orden_trabajo")+"\n"+
                          ","+mySQLrsLine.getInt("certificado_id")+"\n"+
                          ",TO_DATE('"+mySQLrsLine.getDate("fecha_certifica")+"', 'YYYY/MM/DD')\n"+
                          ",TO_DATE('"+mySQLrsLine.getDate("fecha_labor")+"', 'YYYY/MM/DD')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("proyecto_labor")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("unidad_medida")+"',chr(10),''),chr(13),'')\n"+
                          ","+mySQLrsLine.getDouble("cantidad")+"\n"+
                          ","+mySQLrsLine.getDouble("precio")+"\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("categoria")+"',chr(10),''),chr(13),'')\n"+
                          ","+mySQLrsLine.getDouble("estab_id")+"\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("lote")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("cultivo")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("proyecto")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("tarea")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("tipo_erogacion")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("referencia")+"',chr(10),''),chr(13),'')\n"+
                          ",'N'\n"+
                          ",SYSDATE\n"+
                          ",SYSDATE\n"+
                          ","+p_request_id+"\n"+
                          ")\n";

                  rowi_count = rowi_count +1;
              } else {
                 sqlStmt =
                          "UPDATE ADECO_BI.XX_AGRONOMO_INTERFACE_OC_LINEA\n"+
                          "SET ORDEN_TRABAJO  = "+mySQLrsLine.getInt("orden_trabajo")+"\n"+
                          "  , CERTIFICADO_ID = "+mySQLrsLine.getInt("certificado_id")+"\n"+
                          "  , FECHA_CERTIFICACION = "+"TO_DATE('"+mySQLrsLine.getDate("fecha_certifica")+"', 'YYYY/MM/DD')\n"+
                          "  , FECHA_LABOR    = "+"TO_DATE('"+mySQLrsLine.getDate("fecha_labor")+"', 'YYYY/MM/DD')\n"+
                          "  , PROYECTO_LABOR = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("proyecto_labor")+"',chr(10),''),chr(13),'')\n"+
                          "  , UOM            = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("unidad_medida")+"',chr(10),''),chr(13),'')\n"+
                          "  , CANTIDAD       = "+mySQLrsLine.getDouble("cantidad")+"\n"+
                          "  , PRECIO         = "+mySQLrsLine.getDouble("precio")+"\n"+
                          "  , CATEGORIA      = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("categoria")+"',chr(10),''),chr(13),'')\n"+
                          "  , ESTABLECIMIENTO_ID = "+mySQLrsLine.getDouble("estab_id")+"\n"+
                          "  , LOTE           = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("lote")+"',chr(10),''),chr(13),'')\n"+
                          "  , CULTIVO        = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("cultivo")+"',chr(10),''),chr(13),'')\n"+
                          "  , PROYECTO       = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("proyecto")+"',chr(10),''),chr(13),'')\n"+
                          "  , TAREA          = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("tarea")+"',chr(10),''),chr(13),'')\n"+
                          "  , TIPO_EROGACION = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("tipo_erogacion")+"',chr(10),''),chr(13),'')\n"+
                          "  , REFERENCIA     = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("referencia")+"',chr(10),''),chr(13),'')\n"+
                          "  , IMPORTADO_FLAG = "+"'"+mySQLrsLine.getString("oracle_flag")+"'\n"+
                          "  , LAST_UPDATE_DATE = SYSDATE\n" + 
                          "  , REQUEST_ID     = "+p_request_id+"\n"+
                          "WHERE 1=1\n" +
                          "AND CERTIFICADO_ID = "+mySQLrsLine.getInt("certificado_id");

                  rowu_count = rowu_count +1;
              }

              //System.out.println(sqlStmt);
              oraStmt.executeUpdate(sqlStmt);
            }
          }

          oraConn.commit();
          if (rowi_count>0) System.out.println(rowi_count + " registros insertados en la interface."); 
          if (rowu_count>0) System.out.println(rowu_count + " registros reprocesados en la interface."); 
          if (rowi_count==0 && rowu_count==0) System.out.println("No se encontraron registros para insertar.");

          sqlStmt = 
                  "SELECT orden_trabajo, certificado_id \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_INTERFACE_OC_LINEA\n" +
                  "WHERE request_id = "+p_request_id;

          // System.out.println(sqlStmt);
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE orden_trabajos\n"+
                    "SET oracle_oc_flag = 'Y'\n"+
                    "  , interface_error = ''\n"+
                    "WHERE id = "+orars.getInt("orden_trabajo");

            mySQLStmtUpd.executeUpdate(sqlStmt);

            sqlStmt =
                    "UPDATE orden_trabajos_certificaciones\n"+
                    "SET oracle_flag = 'Y'\n"+
                    "  , interface_error = ''\n"+
                    "WHERE id = "+orars.getInt("certificado_id");

            mySQLStmtUpd.executeUpdate(sqlStmt);
          }

          mySQLStmtUpd.close();
		  mySQLConn.commit();
		  mySQLConn.close();
          oraStmt.close();
		  oraConn.commit();
          oraConn.close();
        } catch (SQLException e) {
          System.out.println(e.getMessage()+"\n"+sqlStmt);
          try {
            mySQLConn.rollback();
          } catch (SQLException e2) {
            System.out.println(e2.getMessage());
          }
        }
    
    } else if (p_action.equalsIgnoreCase("PROCESS_ERRORS")){

        int row_count = 0;
        
        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT orden_trabajo, importado_flag, mensaje_error \n" +
                  "FROM xx_agronomo_interface_oc\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          //int row_count = 0;
          while(orars.next()) {
            sqlStmt =
                    "UPDATE orden_trabajos\n"+
                    "SET oracle_oc_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , interface_error = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("orden_trabajo");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          oraConn.commit();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT orden_trabajo, certificado_id, importado_flag, mensaje_error \n" +
                  "FROM xx_agronomo_interface_oc_linea\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE orden_trabajos_certificaciones\n"+
                    "SET oracle_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , interface_error = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("certificado_id");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          mySQLConn.close();
          oraConn.commit();
          oraConn.close();
          if (row_count>0) System.out.println(row_count + " registros actualizados en Agronomo con errores."); 
          if (row_count==0) System.out.println("No se encontraron registros actualizados en Agronomo con errores."); 

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }
        if (row_count>0) System.out.println(row_count + " registros actualizados en Agronomo con errores."); 
        if (row_count==0) System.out.println("No se encontraron registros actualizados en Agronomo con errores."); 

    }
  }
}
