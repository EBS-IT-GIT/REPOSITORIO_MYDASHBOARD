UPDATE apps.XX_ACO_CTGS_B
SET LOC_ORIGEN_ONCCA_CODE = '11339',
        LOC_ORIGEN_ONCCA_DESC = 'PORVENIR',
        LAST_UPDATE_DATE = sysdate,
        LAST_UPDATED_BY = 2070
WHERE NRO_CTG IN ( 42552352,	
		   52989542,
                   52949754,
                   22704315,
                   62955890,
		   42045586,
                   52870240,
                   72395622,
                   62320765,
                   52361979,
                   82952227,
                   62388242,
                   52097284,
                   72854581,
                   72849129,
                   42149496)
--16