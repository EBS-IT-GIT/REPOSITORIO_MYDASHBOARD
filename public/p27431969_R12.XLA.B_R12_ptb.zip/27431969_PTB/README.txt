
==============================================================================
ACCOUNTING SEQUENCE AND NUMBER NOT ASSIGNED FOR OPM FINANCIALS
==============================================================================

Update   - 27431969
Product  - Oracle Subledger Accounting
Release  - R12
Language - Brazilian Portuguese
Built    - NOV-05-2018 21:45:44

==============================================================================
NLS Notes
==============================================================================
This may be a subset of the original base American English update because
it contains only the translatable files referenced by update 27431969
and its prerequisites. Since this update contains only the files that are
currently translated to Brazilian Portuguese, it's contents may vary compared to
another language.  You should install the American English version of this
update before applying this translation.

SPECIAL INSTRUCTIONS
This update contains the following unified driver file to be applied
with AutoPatch.
    u27431969.drv

******************************************************************************
The following text is from the base US update
******************************************************************************
Instructions For Applying This Patch
==============================================================================


Apply The Patch
==============================================================================
For 12.0.X / 12.1.X / pre-upgrade patches (using adpatch), you must shut down
all Application tier services before performing the tasks in this section.
For 12.2.X patches (using adop), you can perform the tasks in this section
without shutting down the Application tier services.



1. Apply patch [required]
This patch contains the following unified driver file to be applied with
AutoPatch:
    u27431969.drv (This is the unified driver)

==============================================================================
Description
==============================================================================

Accounting sequnce for Valuation method ledger not verified if the create
accounting run for Primary ledger

==============================================================================
Bugs Fixed
==============================================================================
The following bugs are fixed by this patch:

19695217 - FAH: ISSUE IN API - CREATE FINAL ACCOUNTING AND TRANSFER THE JOURNAL TO GL AND P
27431969 - ACCOUNTING SEQUENCE AND NUMBER NOT ASSIGNED FOR OPM FINANCIALS
6675871 - SLA-AP CAN'T GENERATE THE CORRECT ACCOUNTING LINES IN THE SECONDARY LEDGER
6802751 - R12-POSTED PYMNT REGISTER REPORT DOES NOT RESPOND TO THE BANK ACCNT PARMATER
7022979 - P2R BEDROCK:NEED ACCOUNTING SOLUTION FOR CUSTOM APPLICATION BASED ON SEEDED APPS
7109881 - NODATA FOUND ERROR FOR PERIOD END ACCRUAL'S ACCOUNTING
7645837 - SOME LEGAL REQUIREMENTS NOT IN GLOBAL JOURNAL LEDGER REPORT
7834671 - BRAZIL: GLOBAL DAILY JOURNALS REPORT: NO DATA FOUND
8250875 - R12: XLAACCPB - CREATE ACCOUNTING PROGRAM PERFORMANCE ISSUE - RUNNING SLOW
8284764 - RCA: R12:CREATE ACCOUNTING PROCESS DOES NOT DROP QUEUE TABLE
8319065 - CREATE ACCOUNTING PERF: FURTHER IMPROVEMENT AFTER BUG 8250875
8337868 - PARAMETERS TO BE ADDED IN JOURNAL ENTRIES REPORT
8419472 - XLAAARPT R12 ACCOUNT ANALYSIS REPORT APP-FND-00806 SEGMENT P_RESP_APPLICATION_ID
8773522 - XLAAPRPT JAVA.LANG.OUTOFMEMORYERROR: JAVA HEAP SPACE


