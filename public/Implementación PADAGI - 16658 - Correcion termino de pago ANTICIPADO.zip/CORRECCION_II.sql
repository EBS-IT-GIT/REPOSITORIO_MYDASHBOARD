UPDATE apps.ra_terms_lines
SET    relative_amount = 100, due_days = 0, due_date = null, last_update_date = sysdate, last_updated_by = 2070
WHERE  term_id = (SELECT term_id FROM apps.ra_terms WHERE name ='Anticipado');
--1 Registros