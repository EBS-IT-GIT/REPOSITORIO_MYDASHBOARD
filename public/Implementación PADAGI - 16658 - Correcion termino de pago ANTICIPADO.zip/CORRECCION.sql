UPDATE apps.ra_terms
SET    base_amount = 100, last_update_date = sysdate, last_updated_by = 2070
WHERE  name ='Anticipado';
--1 Registro