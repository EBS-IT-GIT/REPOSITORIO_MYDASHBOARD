UPDATE apps.mtl_material_transactions
SET    waybill_airbill = '0044-00054367', last_update_date = sysdate, last_updated_by = 2070
WHERE  waybill_airbill = '0044-00054628';
--1 Registro
