  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_REPORTE_AJUSTES" IS 
/*------------------------------------------------------------------
-- PROCEDURE main                                                 --
-- p_aju_desde       fecha desde la que se consideran los ajustes --
-- p_aju_hasta       fecha hasta la que se consideran los ajustes --
-- p_cont_desde      fecha desde la que se consideran los ajustes --
-- p_cont_hasta      fecha hasta la que se consideran los ajustes --
-- p_party_id        party_id para filtrar por cliente            --
-- p_user_id         user_id para filtrar por usuario             --
-----------------------------------------------------------------*/
PROCEDURE main (errbuf       OUT VARCHAR2
               ,retcode      OUT NUMBER
               ,p_aju_desde  IN  VARCHAR2
               ,p_aju_hasta  IN  VARCHAR2
               ,p_cont_desde IN  VARCHAR2
               ,p_cont_hasta IN  VARCHAR2
               ,p_party_id   IN  NUMBER
               ,p_user_id    IN  NUMBER);

END XX_AR_REPORTE_AJUSTES;


/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_REPORTE_AJUSTES" IS 
PROCEDURE main (errbuf       OUT VARCHAR2
               ,retcode      OUT NUMBER
               ,p_aju_desde  IN  VARCHAR2
               ,p_aju_hasta  IN  VARCHAR2
               ,p_cont_desde IN  VARCHAR2
               ,p_cont_hasta IN  VARCHAR2
               ,p_party_id   IN  NUMBER
               ,p_user_id    IN  NUMBER) IS

CURSOR aju IS            
SELECT 'Recibo' tipo
      ,hp.party_name
      ,aba.name lote_rec
      ,acr.receipt_number nro_trx
      ,acr.currency_code
      ,acr.amount
      ,art.name tipo_ajuste
      ,ara.apply_date
      ,ara.gl_posted_date
      ,ara.amount_applied
      ,fu_creador.user_name user_crea
      ,ara.creation_date
      ,fu_act.user_name user_act
      ,ara.last_update_date
      ,null estado
      ,null user_aprob
FROM   ar_receivable_applications     ara
      ,ar_cash_receipts_all           acr
      ,hz_cust_accounts               hca
      ,hz_parties                     hp
      ,ar_cash_receipt_history_all    acrh
      ,ar_batches_all                 aba
      ,ar_receivables_trx_all         art
      ,fnd_user                       fu_creador
      ,fnd_user                       fu_act
WHERE  ara.last_updated_by             = fu_act.user_id
AND    ara.created_by                  = fu_creador.user_id
AND    ara.receivables_trx_id          = art.receivables_trx_id
AND    acrh.batch_id                   = aba.batch_id (+)
AND    acr.cash_receipt_id             = acrh.cash_receipt_id
AND    hca.party_id                    = hp.party_id
AND    acr.pay_from_customer           = hca.cust_account_id
AND    ara.cash_receipt_id             = acr.cash_receipt_id
AND    ara.display                     = 'Y'
AND    ara.status                      = 'ACTIVITY'
AND    hp.party_id                     = nvl(p_party_id, hp.party_id)
AND    (   ara.created_by              = nvl(p_user_id, ara.created_by)
        OR ara.last_updated_by         = nvl(p_user_id, ara.last_updated_by))
AND    trunc(ara.gl_posted_date) BETWEEN nvl(to_date(p_cont_desde,'RRRR/MM/DD HH24:MI:SS'),trunc(ara.gl_posted_date))
                                 AND     nvl(to_date(p_cont_hasta,'RRRR/MM/DD HH24:MI:SS'),trunc(ara.gl_posted_date))
AND    trunc(ara.apply_date)     BETWEEN nvl(to_date(p_aju_desde,'RRRR/MM/DD HH24:MI:SS'),trunc(ara.apply_date))
                                 AND     nvl(to_date(p_aju_hasta,'RRRR/MM/DD HH24:MI:SS'),trunc(ara.apply_date))
UNION
SELECT 'Factura'
      ,hp.party_name
      ,null lote
      ,rct.trx_number
      ,rct.invoice_currency_code
      ,(SELECT sum(extended_amount)
        FROM   ra_customer_trx_lines_all rctl
        WHERE  rctl.customer_trx_id = rct.customer_trx_id) monto
      ,art.name tipo_ajuste
      ,aa.apply_date
      ,aa.gl_date
      ,aa.amount
      ,fu_creador.user_name user_crea
      ,aa.creation_date
      ,fu_act.user_name user_act
      ,aa.last_update_date
      ,DECODE(aa.status, 'A', 'Aprobado', 'U', 'En Espera Aprobación', 'R', 'Rechazado')
      ,fu_aprob.user_name user_aprob
FROM   ar_adjustments_all     aa
      ,ra_customer_trx_all    rct
      ,ar_receivables_trx_all art
      ,hr_operating_units     hou
      ,fnd_user               fu_creador
      ,fnd_user               fu_act
      ,hz_parties             hp
      ,hz_cust_accounts       hca
      ,fnd_user               fu_aprob
WHERE  hca.party_id            = hp.party_id
AND    rct.bill_to_customer_id = hca.cust_account_id
AND    aa.org_id               = hou.organization_id
AND    aa.approved_by          = fu_aprob.user_id
AND    aa.last_updated_by      = fu_act.user_id
AND    aa.created_by           = fu_creador.user_id
AND    aa.receivables_trx_id   = art.receivables_trx_id
AND    aa.customer_trx_id      = rct.customer_trx_id
AND    aa.customer_trx_id IS NOT NULL
AND    hp.party_id                    = nvl(p_party_id, hp.party_id)
AND    (   aa.created_by              = nvl(p_user_id, aa.created_by)
        OR aa.last_updated_by         = nvl(p_user_id, aa.last_updated_by))
AND    trunc(aa.gl_posted_date) BETWEEN nvl(to_date(p_cont_desde,'RRRR/MM/DD HH24:MI:SS'),trunc(aa.gl_posted_date))
                                 AND     nvl(to_date(p_cont_hasta,'RRRR/MM/DD HH24:MI:SS'),trunc(aa.gl_posted_date))
AND    trunc(aa.apply_date)     BETWEEN nvl(to_date(p_aju_desde,'RRRR/MM/DD HH24:MI:SS'),trunc(aa.apply_date))
                                 AND     nvl(to_date(p_aju_hasta,'RRRR/MM/DD HH24:MI:SS'),trunc(aa.apply_date));

l_org_name  hr_operating_units.name %TYPE;
l_user_name fnd_user.user_name %TYPE;

   BEGIN
      fnd_file.put_line(fnd_file.log,'Parametros');
      fnd_file.put_line(fnd_file.log,'org_id: '||FND_PROFILE.VALUE('ORG_ID'));
      fnd_file.put_line(fnd_file.log,'fecha ajuste desde: '||to_date(p_aju_desde,'RRRR/MM/DD HH24:MI:SS'));
      fnd_file.put_line(fnd_file.log,'fecha ajuste hasta: '||to_date(p_aju_hasta,'RRRR/MM/DD HH24:MI:SS'));
      fnd_file.put_line(fnd_file.log,'fecha contable desde:'|| to_date(p_cont_desde,'RRRR/MM/DD HH24:MI:SS'));
      fnd_file.put_line(fnd_file.log,'fecha contable hasta: '||to_date(p_cont_hasta,'RRRR/MM/DD HH24:MI:SS'));
      fnd_file.put_line(fnd_file.log,'party_id: '||p_party_id);
      fnd_file.put_line(fnd_file.log,'user_id: '||p_user_id);

      fnd_file.put_line(fnd_file.output, '<?xml version="1.0" encoding="UTF-8"?>');
      fnd_file.put_line(fnd_file.output, '<XXARREPAJU>');
      BEGIN
         SELECT name 
         INTO   l_org_name
         FROM   hr_operating_units
         WHERE  organization_id = FND_PROFILE.VALUE('ORG_ID');
      EXCEPTION WHEN OTHERS THEN
         null;
      END;

      BEGIN
         SELECT user_name 
         INTO   l_user_name
         FROM   fnd_user
         WHERE  user_id = p_user_id;
      EXCEPTION WHEN OTHERS THEN
         null;
      END;
      
      fnd_file.put_line(fnd_file.log,'organization name: '||l_org_name);
      fnd_file.put_line(fnd_file.log,'user name: '||l_user_name);

      fnd_file.put_line(fnd_file.output, '<P_ORGANIZATION_NAME>'||l_org_name                                   ||'</P_ORGANIZATION_NAME>');    
      fnd_file.put_line(fnd_file.output,'<P_AJU_DESDE>'         ||to_date(p_aju_desde,'RRRR/MM/DD HH24:MI:SS') ||'</P_AJU_DESDE>');
      fnd_file.put_line(fnd_file.output,'<P_AJU_HASTA>'         ||to_date(p_aju_hasta,'RRRR/MM/DD HH24:MI:SS') ||'</P_AJU_HASTA>');
      fnd_file.put_line(fnd_file.output,'<P_CONT_DESDE>'        ||to_date(p_cont_desde,'RRRR/MM/DD HH24:MI:SS')||'</P_CONT_DESDE>');
      fnd_file.put_line(fnd_file.output,'<P_CONT_HASTA>'        ||to_date(p_cont_hasta,'RRRR/MM/DD HH24:MI:SS')||'</P_CONT_HASTA>');
      fnd_file.put_line(fnd_file.output,'<P_PARTY_ID>'          ||p_party_id                                   ||'</P_PARTY_ID>');
      fnd_file.put_line(fnd_file.output,'<P_USER_ID>'           ||l_user_name                                  ||'</P_USER_ID>');

      FOR c_aju IN aju LOOP
         fnd_file.put_line(fnd_file.output,'<C_AJU>');
         fnd_file.put_line(fnd_file.output,'<TIPO>'      ||c_aju.tipo            ||'</TIPO>');
         fnd_file.put_line(fnd_file.output,'<CLIENTE>'   ||XX_UTIL_PK.xml_escape_chars(c_aju.party_name)||'</CLIENTE>');
         fnd_file.put_line(fnd_file.output,'<LOTE_NUM>'  ||c_aju.lote_rec        ||'</LOTE_NUM>');
         fnd_file.put_line(fnd_file.output,'<REC_NUM>'   ||c_aju.nro_trx         ||'</REC_NUM>');
         fnd_file.put_line(fnd_file.output,'<MONEDA>'    ||c_aju.currency_code   ||'</MONEDA>');
         fnd_file.put_line(fnd_file.output,'<MONTO_REC>' ||c_aju.amount          ||'</MONTO_REC>');
         fnd_file.put_line(fnd_file.output,'<TIPO_AJU>'  ||c_aju.tipo_ajuste     ||'</TIPO_AJU>');
         fnd_file.put_line(fnd_file.output,'<FECHA_AJU>' ||c_aju.apply_date      ||'</FECHA_AJU>');
         fnd_file.put_line(fnd_file.output,'<FECHA_CONT>'||c_aju.gl_posted_date  ||'</FECHA_CONT>');
         fnd_file.put_line(fnd_file.output,'<MONTO_APL>' ||c_aju.amount_applied  ||'</MONTO_APL>');
         fnd_file.put_line(fnd_file.output,'<USER_CREA>' ||c_aju.user_crea       ||'</USER_CREA>');
         fnd_file.put_line(fnd_file.output,'<FECHA_CREA>'||c_aju.creation_date   ||'</FECHA_CREA>');
         fnd_file.put_line(fnd_file.output,'<USER_ACT>'  ||c_aju.user_act        ||'</USER_ACT>');
         fnd_file.put_line(fnd_file.output,'<FECHA_ACT>' ||c_aju.last_update_date||'</FECHA_ACT>');
         fnd_file.put_line(fnd_file.output,'<ESTADO>'    ||c_aju.estado          ||'</ESTADO>');
         fnd_file.put_line(fnd_file.output,'<USER_APROB>'||c_aju.user_aprob      ||'</USER_APROB>');
         fnd_file.put_line(fnd_file.output,'</C_AJU>');
      END LOOP; 

   fnd_file.put_line(fnd_file.output, '</XXARREPAJU>');

   EXCEPTION
      WHEN OTHERS THEN
         errbuf  := sqlerrm;
         retcode := 2;
         fnd_file.put_line(fnd_file.log,'Error General: '||sqlerrm); 
   END main;
END XX_AR_REPORTE_AJUSTES;
/

exit
