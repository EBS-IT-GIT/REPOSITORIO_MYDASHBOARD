  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XXCLK_INV_INTERFACE_PKG" IS
--
-- +===================================================================+
-- |                            TRI-CS                                 |
-- |                      All Rights Reserved.                         |
-- +===================================================================+
-- |                                                                   |
-- | Name       : XXCLK_INV_INTERFACE_PKG                              |
-- |                                                                   |
-- | Description: Package responsible for read the staging table and   |
-- |               import to INV Itens Interface                       |
-- |                                                                   |
-- | History:                                                          |
-- | ==========                                                        |
-- | Version  Date          Author           Description               |
-- | =======  ============  ==============   ========================= |
-- | 1.0      18-MAR-2016   M. Pacheco       Initial Version           |
-- +===================================================================+
--
   -- Global Variables
   g_debug   BOOLEAN := FALSE;
   --
   -- +=======================================================================+
   -- | Name: create_log                                                      |
   -- |                                                                       |
   -- | Descricao: Procedure responsible for printing log on concurrent       |
   -- |              request                                                  |
   -- |                                                                       |
   -- | Parametros:                                                           |
   -- |    p_name   VARCHAR2 - Name of procedure that call the log            |
   -- |    p_msg    VARCHAR2 - Message                                        |
   -- |                                                                       |
   -- | Retorno:                                                              |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE create_log( p_name   IN VARCHAR2
                        ,p_msg    IN VARCHAR2 );

   --
   -- +=======================================================================+
   -- | Name: create_output                                                   |
   -- |                                                                       |
   -- | Description: Procedure responsible for printing output summary of     |
   -- |                concurrent request                                     |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_type            VARCHAR2  - Type of output                       |
   -- |    p_id_material     VARCHAR2  - ID Material COMLINK                  |
   -- |    p_item_number     VARCHAR2  - Item Number EBS                      |
   -- |    p_organization    VARCHAR2  - Material Organization                |
   -- |    p_buyer_name      VARCHAR2  - Standard Buyer                       |
   -- |    p_status          VARCHAR2  - Staus of record                      |
   -- |    p_total           NUMBER    - Total of records                     |
   -- |    p_success         NUMBER    - Total of success records             |
   -- |    p_error           NUMBER    - Total of success error               |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE create_output ( p_type            IN VARCHAR2
                            ,p_id_material     IN NUMBER   DEFAULT NULL
                            ,p_item_number     IN VARCHAR2 DEFAULT NULL
                            ,p_organization    IN VARCHAR2 DEFAULT NULL
                            ,p_buyer_name      IN VARCHAR2 DEFAULT NULL
                            ,p_status          IN VARCHAR2 DEFAULT NULL
                            ,p_total           IN NUMBER   DEFAULT NULL
                            ,p_success         IN NUMBER   DEFAULT NULL
                            ,p_error           IN NUMBER   DEFAULT NULL );

   --
   -- +=======================================================================+
   -- | Name: error_message                                                   |
   -- |                                                                       |
   -- | Description: Procedure responsible of feedback with error messages to |
   -- |               COMLINK transitory tables                               |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_id_cliente    INTEGER  - ID of client to feedback error occurred |
   -- |    p_id_referencia VARCHAR2 - ID of ref. to feedback error occurred   |
   -- |    p_id_material   INTEGER  - ID of item to feedback error occurred   |
   -- |    p_error         VARCHAR2 - Error description                       |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE error_message( p_id_cliente    INTEGER
                           ,p_id_referencia VARCHAR2
                           ,p_id_material   INTEGER
                           ,p_error         VARCHAR2 );

   --
   -- +=======================================================================+
   -- | Name: validate_transitory                                             |
   -- |                                                                       |
   -- | Description: Procedure responsible for update the status of material  |
   -- |               sent by COMLINK for insertion in INV                    |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_id_material   INTEGER  - ID of material in the transitory table  |
   -- |    p_clirefcod     VARCHAR2 - New EBS ID of item                      |
   -- |    p_operation     NUMBER   - Operation Type: 1, Insert 2 Update      |
   -- |    p_id_referencia VARCHAR2 - ID of reference in the transitory table |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE validate_transitory( p_id_material   INTEGER
                                 ,p_clirefcod     VARCHAR2
								         ,p_operation     NUMBER
                                 ,p_id_referencia VARCHAR2 );

   --
   -- +=======================================================================+
   -- | Name: get_category                                                    |
   -- |                                                                       |
   -- | Description: Procedure to get categories information for items        |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_structure_id       NUMBER    - Structure ID                      |
   -- |    p_category_value     VARCHAR2  - Value of category set             |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    p_category_id        NUMBER    - Category ID                       |
   -- +=======================================================================+
   --
   FUNCTION  get_category( p_structure_id   NUMBER
                          ,p_category_value VARCHAR2 ) RETURN NUMBER;

   --
   -- +=======================================================================+
   -- | Name: get_template                                                    |
   -- |                                                                       |
   -- | Descricao: Function that retur template ID                            |
   -- |                                                                       |
   -- | Parametros:                                                           |
   -- |    p_organization_id   NUMBER  - Organization ID                      |
   -- |                                                                       |
   -- | Retorno:                                                              |
   -- |    r_template_id  NUMBER                                              |
   -- +=======================================================================+
   --
   FUNCTION get_template ( p_organization_id NUMBER ) RETURN NUMBER;

   --
   -- +=======================================================================+
   -- | Name: get_itens                                                       |
   -- |                                                                       |
   -- | Descricao: Main procedure responsible to start the process            |
   -- |             of reading transitory table                               |
   -- |                                                                       |
   -- | Parametros:                                                           |
   -- |    errbuf          VARCHAR2  - Return message for concurrent (Core)   |
   -- |    retcode         NUMBER    - Return code for concurrent (Core)      |
   -- |                                                                       |
   -- | Retorno:                                                              |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE get_items ( errbuf         OUT VARCHAR2
                        ,retcode        OUT NUMBER );

END XXCLK_INV_INTERFACE_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XXCLK_INV_INTERFACE_PKG" IS
--
-- +===================================================================+
-- |                            TRI-CS                                 |
-- |                      All Rights Reserved.                         |
-- +===================================================================+
-- |                                                                   |
-- | Name       : XXCLK_INV_INTERFACE_PKG                              |
-- |                                                                   |
-- | Description: Package responsible for read the staging table and   |
-- |               import to INV Itens Interface                       |
-- |                                                                   |
-- | History:                                                          |
-- | ==========                                                        |
-- | Version  Date          Author           Description               |
-- | =======  ============  ==============   ========================= |
-- | 1.0      18-MAR-2016   M. Pacheco       Initial Version           |
-- +===================================================================+
--

   --
   -- +=======================================================================+
   -- | Name: create_log                                                      |
   -- |                                                                       |
   -- | Descricao: Procedure responsible for printing log on concurrent       |
   -- |              request                                                  |
   -- |                                                                       |
   -- | Description:                                                          |
   -- |    p_name   VARCHAR2 - Name of procedure that call the log            |
   -- |    p_msg    VARCHAR2 - Message                                        |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE create_log( p_name   IN VARCHAR2
                        ,p_msg    IN VARCHAR2 ) IS
      --
      l_log_msg fnd_log_messages.message_text%TYPE;
      --
   BEGIN
      --
      l_log_msg := ' -> XXCLK_INV_INTERFACE_PKG.' || p_name || ' = ' || p_msg;
      --
      IF g_debug THEN -- IF debug
         --
         dbms_output.put_line(l_log_msg);
         --
      ELSE -- IF l_debug
         --
         fnd_file.put_line(fnd_file.log, l_log_msg);
         --
      END IF; -- IF l_debug
      --
   END create_log;

   --
   -- +=======================================================================+
   -- | Name: create_output                                                   |
   -- |                                                                       |
   -- | Description: Procedure responsible for printing output summary of     |
   -- |                concurrent request                                     |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_type            VARCHAR2  - Type of output                       |
   -- |    p_id_material     VARCHAR2  - ID Material COMLINK                  |
   -- |    p_item_number     VARCHAR2  - Item Number EBS                      |
   -- |    p_organization    VARCHAR2  - Material Organization                |
   -- |    p_buyer_name      VARCHAR2  - Standard Buyer                       |
   -- |    p_status          VARCHAR2  - Staus of record                      |
   -- |    p_total           NUMBER    - Total of records                     |
   -- |    p_success         NUMBER    - Total of success records             |
   -- |    p_error           NUMBER    - Total of success error               |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE create_output ( p_type            IN VARCHAR2
                            ,p_id_material     IN NUMBER   DEFAULT NULL
                            ,p_item_number     IN VARCHAR2 DEFAULT NULL
                            ,p_organization    IN VARCHAR2 DEFAULT NULL
                            ,p_buyer_name      IN VARCHAR2 DEFAULT NULL
                            ,p_status          IN VARCHAR2 DEFAULT NULL
                            ,p_total           IN NUMBER   DEFAULT NULL
                            ,p_success         IN NUMBER   DEFAULT NULL
                            ,p_error           IN NUMBER   DEFAULT NULL ) IS
      --
      l_trx_number  NUMBER;
      --
   BEGIN
      --
      IF p_type = 'HEADER' THEN -- IF p_type = 'HEADER'
         --
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '|                      ADECO Integracao de Itens COMLINK para INV - XXCLK_INV_INTERFACE_PKG                      |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Item processado                                                                                               |');
         fnd_file.put_line(fnd_file.OUTPUT, '| -------------------                                                                                            |');
         --
      ELSIF p_type = 'ROW_ITEM' THEN -- IF p_type = 'HEADER'
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|      Material: ' || RPAD(p_id_material,23, ' ') || 'Comprador padrao: ' || RPAD(p_buyer_name,54, ' ')     || ' |');
         --
      ELSIF p_type = 'ROW_ORGANIZATION' THEN -- IF p_type = 'HEADER'
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|          Organizacao: ' || RPAD(p_organization,88, ' ')                                                   || ' |');
         --
      ELSIF p_type = 'ROW_RESULT' THEN -- IF p_type = 'HEADER'
         --
         IF p_item_number IS NULL THEN -- IF p_item_number IS NULL
            --
            fnd_file.put_line(fnd_file.OUTPUT, '|      Item processado com ' || RPAD(p_status,85, ' ')                                                   || ' |');
            --
         ELSE -- IF p_item_number IS NULL
            --
            fnd_file.put_line(fnd_file.OUTPUT, '|      Item ' || RPAD(p_item_number,14, ' ') || 'processado com ' || RPAD(p_status,71, ' ')              || ' |');
            --
         END IF; -- IF p_item_number IS NULL
         --
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         --
      ELSIF p_type = 'SUM' THEN-- IF p_type = 'HEADER'
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '| Total itens processados: ' || RPAD(p_total,85, ' ')                                                       || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|     Total itens sucesso: ' || RPAD(p_success,85, ' ')                                                     || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|        Total itens erro: ' || RPAD(p_error,85, ' ')                                                       || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
         --
      END IF;-- IF p_type = 'HEADER'
      --
   END create_output;

   --
   -- +=======================================================================+
   -- | Name: error_message                                                   |
   -- |                                                                       |
   -- | Description: Procedure responsible of feedback with error messages to |
   -- |               COMLINK transitory tables                               |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_id_cliente    INTEGER  - ID of client to feedback error occurred |
   -- |    p_id_referencia VARCHAR2 - ID of ref. to feedback error occurred   |
   -- |    p_id_material   INTEGER  - ID of item to feedback error occurred   |
   -- |    p_error         VARCHAR2 - Error description                       |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE error_message( p_id_cliente    INTEGER
                           ,p_id_referencia VARCHAR2
                           ,p_id_material   INTEGER
                           ,p_error         VARCHAR2 ) IS
      --
      l_error_message NUMBER;
      --
      l_sql_query     VARCHAR2(4000);
      --
   BEGIN
      --
       l_sql_query := 'SELECT COUNT(1) ' ||
                      '  FROM xxclk.mensagem_erro' ||
                      ' WHERE id_cliente    = '''  || p_id_cliente    || '''' ||
                      '   AND id_referencia IN ('  || p_id_referencia || ')'  ||
                      '   AND id_material   = '    || p_id_material;
      --
      EXECUTE IMMEDIATE (l_sql_query) INTO l_error_message;
      --
      IF l_error_message = 0 THEN -- IF l_error_message = 0
         --
         FOR c_ref IN ( SELECT regexp_substr(p_id_referencia,'[^,]+', 1, LEVEL) id_referencia
                          FROM dual
                        CONNECT BY REGEXP_SUBSTR(p_id_referencia, '[^,]+', 1, LEVEL) IS NOT NULL ) LOOP
            --
            INSERT INTO xxclk.mensagem_erro( data_inc             -- 01
                                            ,id_cliente           -- 02
                                            ,id_referencia        -- 03
                                            ,id_material          -- 04
                                            ,mensagem             -- 05
                                           )
                                    VALUES ( sysdate              -- 01
                                            ,p_id_cliente         -- 02
                                            ,c_ref.id_referencia  -- 03
                                            ,p_id_material        -- 04
                                            ,p_error              -- 05
                                           );
         END LOOP;
         --
      ELSE-- IF l_error_message = 0
         --
         l_sql_query := 'UPDATE xxclk.mensagem_erro' ||
                        '   SET mensagem = '''       || p_error         || '''' ||
                        ' WHERE id_cliente    = '    || p_id_cliente    ||
                        '   AND id_referencia IN ('  || p_id_referencia || ')'  ||
                        '   AND id_material   = '    || p_id_material;
         --
         EXECUTE IMMEDIATE (l_sql_query);
         --
      END IF;-- IF l_error_message = 0
      --
      UPDATE xxclk.materiais
         SET liberado    = 'E'
       WHERE id_material = p_id_material;
      --
      COMMIT;
      --
   END error_message;

   --
   -- +=======================================================================+
   -- | Name: validate_transitory                                             |
   -- |                                                                       |
   -- | Description: Procedure responsible for update the status of material  |
   -- |               sent by COMLINK for insertion in INV                    |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_id_material   INTEGER  - ID of material in the transitory table  |
   -- |    p_clirefcod     VARCHAR2 - New EBS ID of item                      |
   -- |    p_operation     NUMBER   - Operation Type: 1, Insert 2 Update      |
   -- |    p_id_referencia VARCHAR2 - ID of reference in the transitory table |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE validate_transitory( p_id_material   INTEGER
                                 ,p_clirefcod     VARCHAR2
                                 ,p_operation     NUMBER
                                 ,p_id_referencia VARCHAR2 ) IS
     --
     l_depara_chk NUMBER;
     --
   BEGIN
      --
      SELECT count(1)
        INTO l_depara_chk
        FROM xxclk.depara_comlink
       WHERE id_material = p_id_material;
      --
      IF l_depara_chk = 0 THEN -- IF l_depara_chk = 0
         --
         INSERT INTO xxclk.depara_comlink ( id_material                  -- 01
                                           ,clirefcod                    -- 02
                                           ,data_inc                     -- 03
                                          )
                                   VALUES (
                                            p_id_material                -- 01
                                           ,p_clirefcod                  -- 02
                                           ,SYSDATE                      -- 03
                                          );
         --
      END IF; -- IF l_depara_chk = 0
      --
      UPDATE xxclk.materiais
         SET liberado    = 'S'
       WHERE id_material = p_id_material;
      --
      IF p_operation = 1 THEN -- IF p_operation = 1
         --
         FOR c_ref IN ( SELECT regexp_substr(p_id_referencia,'[^,]+', 1, LEVEL) id_referencia
                          FROM dual
                        CONNECT BY REGEXP_SUBSTR(p_id_referencia, '[^,]+', 1, LEVEL) IS NOT NULL ) LOOP
            --
            UPDATE xxclk.clientes_referencias
               SET clirefcod     = p_clirefcod
                  ,clirefcodclk  = p_id_material || ' - CLK'
                  ,datacodclk    = NULL
             WHERE id_referencia = c_ref.id_referencia;
            --
         END LOOP;
         --
   END IF; -- IF p_operation = 1
   --
   DELETE FROM xxclk.mensagem_erro WHERE id_material = p_id_material;
   --
   COMMIT;
   --
   END validate_transitory;

   --
   -- +=======================================================================+
   -- | Name: get_category                                                    |
   -- |                                                                       |
   -- | Description: Procedure to get categories information for items        |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    p_structure_id       NUMBER    - Structure ID                      |
   -- |    p_category_value     VARCHAR2  - Value of category set             |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    p_category_id        NUMBER    - Category ID                       |
   -- +=======================================================================+
   --
   FUNCTION  get_category( p_structure_id   NUMBER
                          ,p_category_value    VARCHAR2 ) RETURN NUMBER IS
      --
      l_category_id   NUMBER;
      --
   BEGIN
      --
      SELECT category_id
        INTO l_category_id
        FROM mtl_categories mca
       WHERE segment1||segment2||segment3 = p_category_value
         AND structure_id = p_structure_id;
      --
      RETURN l_category_id;
      --
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
      --
      RAISE_APPLICATION_ERROR(-20004, 'A consulta para o conjunto de categoria '||p_structure_id||' - '||p_category_value||' retornou valor nulo.');
      --
      WHEN OTHERS THEN
      --
      RAISE_APPLICATION_ERROR(-20005, 'Erro ao localizar conjunto de categoria - '||SQLERRM);
      --
   END get_category;

   --
   -- +=======================================================================+
   -- | Name: get_template                                                    |
   -- |                                                                       |
   -- | Descricao: Function that retur template ID                            |
   -- |                                                                       |
   -- | Parametros:                                                           |
   -- |    p_organization_id   NUMBER  - Organization ID                      |
   -- |                                                                       |
   -- | Retorno:                                                              |
   -- |    r_template_id  NUMBER                                              |
   -- +=======================================================================+
   --
   FUNCTION get_template ( p_organization_id NUMBER ) RETURN NUMBER IS
   --
   r_template_id    NUMBER(10);
   --
   BEGIN
      --
      SELECT mit.template_id
        INTO r_template_id
        FROM fnd_lookup_values flv
            ,fnd_lookup_types flt
            ,fnd_application fap
            ,mtl_item_templates mit
       WHERE flv.lookup_type            = flt.lookup_type
         AND flt.application_id         = fap.application_id
         AND flv.lookup_type            = 'XXINV_TEMPLATE_COMLINK'
         AND flv.enabled_flag           = 'Y'
         AND fap.application_short_name = 'INV'
         AND mit.template_name          = flv.meaning
         AND flv.language               = USERENV('LANG')
         AND flv.lookup_code            = p_organization_id;
      --
      RETURN(r_template_id);
      --
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
      --
      RAISE_APPLICATION_ERROR(-20006, 'A consulta para template para a organizacao '||p_organization_id||' retornou valor nulo.');
      --
      WHEN OTHERS THEN
      --
      RAISE_APPLICATION_ERROR(-20007, 'Erro ao localizar o template - '||SQLERRM);
      --
   END get_template;

   --
   -- +=======================================================================+
   -- | Name: get_itens                                                       |
   -- |                                                                       |
   -- | Description: Main procedure responsible to start the process          |
   -- |               of reading transitory table                             |
   -- |                                                                       |
   -- | Parameters:                                                           |
   -- |    errbuf          VARCHAR2  - Return message for concurrent (Core)   |
   -- |    retcode         NUMBER    - Return code for concurrent (Core)      |
   -- |                                                                       |
   -- | Return:                                                               |
   -- |    NA                                                                 |
   -- +=======================================================================+
   --
   PROCEDURE get_items ( errbuf         OUT VARCHAR2
                        ,retcode        OUT NUMBER ) IS
      --
      TYPE segment1_seq IS TABLE OF NUMBER INDEX BY VARCHAR2(64);
      --
      l_id_cliente          CONSTANT NUMBER         := fnd_profile.value('XXCLK_IDCLIENTE'); -- Client ID in the CONLIK system
      l_master_org_id       CONSTANT NUMBER         := fnd_profile.value('XXCLK_MASTERORG'); -- Inventory Organization Master
      l_cat_set_inv         CONSTANT NUMBER         := fnd_profile.value('XXCLK_CATSETINV'); -- Category set ID for Inventory
      l_cat_set_ncm         CONSTANT NUMBER         := fnd_profile.value('XXCLK_CATSETNCM'); -- Category set ID for NCM
      l_conc_request_id     CONSTANT NUMBER         := fnd_global.conc_request_id;
      l_prog_appl_id        CONSTANT NUMBER         := fnd_global.prog_appl_id;
      l_user_id             CONSTANT NUMBER         := fnd_profile.value('USER_ID');
      l_login_id            CONSTANT NUMBER         := fnd_profile.value('LOGIN_ID');
      l_org_id              CONSTANT NUMBER         := fnd_profile.value('ORG_ID');
      l_attribute_category  CONSTANT VARCHAR2(2)    := 'BR';
      l_transaction_type    CONSTANT VARCHAR2(6)    := 'SYNC';
      --
      l_count_success       NUMBER;
      l_count_error         NUMBER;
      l_count_total         NUMBER;
      l_template_id         NUMBER;
      l_organization_id     NUMBER;
      l_inventory_item_id   NUMBER;
      l_incoin_request_id   NUMBER;
      l_category_set_id     NUMBER;
      l_cat_request_id      NUMBER;
      l_set_process_id      NUMBER;
      l_buyer_id            NUMBER;
      l_item_exists         NUMBER;
      l_depara_chk          NUMBER;
      l_category_id         NUMBER;
      --
      l_segment1_seq        VARCHAR2(30);
      l_category            VARCHAR2(8);
      l_subfamily           VARCHAR2(3);
      l_status_upd          VARCHAR2(100);
      l_name                VARCHAR2(100);
      l_error_msg           VARCHAR2(4000);
      l_template_name       VARCHAR2(30);
      l_segment1            VARCHAR2(40);
      l_buyer_name          VARCHAR2(54);
      l_category_value      VARCHAR2(81);
      l_phase               VARCHAR2(50);
      l_status              VARCHAR2(50);
      l_dev_phase           VARCHAR2(50);
      l_dev_status          VARCHAR2(50);
      l_message             VARCHAR2(50);
      l_uom_code            VARCHAR2(3);
      l_unit_of_measure     VARCHAR2(25);
      l_enabled_flag        VARCHAR2(1);
      --
      l_return_status       BOOLEAN;
      l_error               BOOLEAN;
      --
      CURSOR c_itens IS
         SELECT cr.clirefcod
               ,cr.clirefcod_antigo
               ,m.id_material
               ,gc.grucod grupo_cod
               ,gc.grudsc grupo_descr
               ,sb.subgrucod familia_cod
               ,sb.subgrudsc familia_descr
               ,LISTAGG(REPLACE(NVL(ma.marca, ''),CHR(39),CHR(39)||CHR(39)) || ' ' || REPLACE(r.ref,CHR(39),CHR(39)||CHR(39)), ' / ') WITHIN GROUP (ORDER BY marca) marca
               ,REPLACE(n.ncm, '.', '') ncm
               ,TRIM(m.matdscred) matdscred
               ,TRIM(m.matdsccomp) matdsccomp
               ,un.unidade
               ,un.descricao
               ,e.embalagem
               ,CASE WHEN nvl(cr.clirefcod,0) LIKE '%CLK%' THEN 1 ELSE 2 END ordem
               ,LISTAGG(REPLACE(r.id_referencia,CHR(39),CHR(39)||CHR(39)), ',') WITHIN GROUP (ORDER BY r.id_referencia) id_referencia
           FROM xxclk.materiais m
               ,xxclk.referencias r
               ,xxclk.clientes_referencias cr
               ,xxclk.embalagem e
               ,xxclk.ncm n
               ,xxclk.unidade un
               ,xxclk.grupos_cliente gc
               ,xxclk.subgrupos_cliente sb
               ,xxclk.depara_comlink ax
               ,xxclk.marcas ma
          WHERE r.id_material        = m.id_material
            AND cr.id_referencia     = r.id_referencia
            AND m.id_embalagem       = e.id_embalagem (+)
            AND m.id_ncm             = n.id_ncm       (+)
            AND m.id_unidade         = un.id_unidade  (+)
            AND cr.id_grupo          = gc.id_grupo    (+)
            AND cr.id_subgrupo       = sb.id_subgrupo (+)
            AND cr.id_grupo          = sb.id_grupo    (+)
            AND r.id_material        = ax.id_material (+)
            AND m.id_material        = ax.id_material (+)
            AND r.id_marca           = ma.id_marca
            AND m.liberado           = 'N'
            AND cr.id_cliente        = l_id_cliente
            AND NVL(cr.clirefcod, 0) NOT LIKE '%#%'
          GROUP BY
                ax.clirefcod
               ,cr.clirefcod_antigo
               ,m.id_material
               ,n.ncm
               ,m.matdscred
               ,m.matdsccomp
               ,sb.subgrucod
               ,sb.subgrudsc
               ,un.unidade
               ,un.descricao
               ,gc.grucod
               ,gc.grudsc
               ,e.embalagem
               ,cr.clirefcod;
      --
      CURSOR c_variable_data ( p_id_cliente IN INTEGER, p_id_material IN INTEGER, p_attribute IN VARCHAR2 ) IS
         SELECT TRIM(NVL(ss.valor, it.codigo_cliente)) valor
           FROM xxclk.salva_selecao ss
               ,xxclk.mostra_tabelas mt
               ,xxclk.itens_tabela it
          WHERE ss.id_tabela   = mt.id_tabela
            AND it.id_item     = ss.id_item
            AND mt.id_tabela   = it.id_tabela
            AND mt.id_cliente  = p_id_cliente
            AND ss.id_material = p_id_material
            AND mt.tabela      = p_attribute
            AND mt.ativo       = 'S'
            AND it.ativo       = 'S';
      --
      CURSOR c_organization ( p_id_cliente IN INTEGER, p_id_material IN INTEGER, p_clirefcod IN VARCHAR2 ) IS
         SELECT organization_code
           FROM org_organization_definitions
          WHERE organization_id = l_master_org_id
         UNION
         SELECT TRIM(NVL(ss.valor, it.codigo_cliente)) organization_code
           FROM xxclk.salva_selecao ss
               ,xxclk.mostra_tabelas mt
               ,xxclk.itens_tabela it
          WHERE ss.id_tabela   = mt.id_tabela
            AND it.id_item     = ss.id_item
            AND mt.id_tabela   = it.id_tabela
            AND mt.id_cliente  = p_id_cliente
            AND ss.id_material = p_id_material
            AND mt.tabela      = 'CENTROS'
            AND mt.ativo       = 'S'
            AND it.ativo       = 'S';
      --
      CURSOR c_category IS
        SELECT flv.lookup_code category_set_id
              ,mca.category_id
              ,mcs.structure_id
              ,category_set_name
          FROM fnd_lookup_values flv
              ,fnd_lookup_types  flt
              ,fnd_application   fap
              ,mtl_categories    mca
              ,mtl_category_sets mcs
         WHERE flv.lookup_type            = flt.lookup_type
           AND flt.application_id         = fap.application_id
           AND mca.structure_id           = mcs.structure_id
           and flv.meaning                = mca.segment1||mca.segment2||mca.segment3
           and flv.lookup_code            = mcs.category_set_id
           AND flv.lookup_type            = 'XXINV_CATEGORIA_COMLINK'
           AND flv.enabled_flag           = 'Y'
           AND fap.application_short_name = 'INV'
           AND flv.language               = USERENV('LANG');
      --
   BEGIN
      --
      l_name := 'CREATE_ITEM';
      --
      create_log(l_name,' ');
      create_log(l_name,'Iniciando Interface Oracle INV x COMLINK');
      create_log(l_name,' ');
      create_log(l_name,'Iniciando variaveis');
      --
      create_output ( p_type           => 'HEADER' );
      --
      create_log(l_name,'********************************');
      --
      l_count_success   := 0;
      l_count_error     := 0;
      l_count_total     := 0;
      --
      create_log(l_name,'Iniciando sequencias para itens');
      --
      create_log(l_name,'Abrindo c_itens Cursor');
      --
      FOR r_items IN c_itens LOOP -- LOOP r_items
         --
         l_error         := FALSE;
         l_count_total   := l_count_total + 1;
         l_subfamily     := NULL;
         l_category      := NULL;
         l_segment1      := NULL;
         --
         create_log(l_name,'*******************************');
         --
         create_log(l_name,'Item: ' || r_items.id_material );
         --
         IF NOT l_error THEN -- IF NOT l_error - Before Preparations
            --
            OPEN c_variable_data ( p_id_cliente  => l_id_cliente
                                  ,p_id_material => r_items.id_material
                                  ,p_attribute   => 'GRUPO_COMPRADOR'
                                 );
            --
            BEGIN
               --
               FETCH c_variable_data INTO l_buyer_id;
               --
               IF l_buyer_id IS NULL THEN -- IF l_buyer_id IS NULL
                  --
                  RAISE_APPLICATION_ERROR(-20003, 'Consulta de comprador padrao retornou valor nulo');
                  --
               END IF; -- IF l_buyer_id IS NULL
               --
            EXCEPTION
               WHEN OTHERS THEN
               --
               create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
               create_log(l_name,'ERROR: Problema ao buscar comprador padrao - ' || SQLERRM);
               create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
               --
               l_error      := TRUE;
               --
               l_buyer_name := '{nao informado}';
               --
               l_error_msg  := 'Problema ao buscar comprador padrao';
               --
            END;
            --
            IF c_variable_data%ISOPEN THEN -- IF c_variable_data%ISOPEN
               --
               close c_variable_data;
               --
            END IF; -- IF c_variable_data%ISOPEN
            --
            IF NOT l_error THEN -- IF NOT l_error standard buyer
               --
               create_log(l_name,'Encontrada o comprador padrao: ' || NVL(to_char(l_buyer_id), '{NULO}'));
               --
               BEGIN
                  --
                  SELECT fnd.description
                    INTO l_buyer_name
                    FROM po_agents poa
                        ,per_people_f ppf
                        ,apps.fnd_user fnd
                   WHERE poa.agent_id = ppf.person_id
                     AND poa.end_date_active IS NULL
                     AND ppf.person_id = fnd.employee_id
                     AND fnd.description like '%Bra'
                     AND fnd.employee_id = l_buyer_id;
                  --
                  EXCEPTION
                     WHEN OTHERS THEN
                     --
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     create_log(l_name,'ERROR: Comprador padrao nao encontrado no EBS.');
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     --
                     l_buyer_name := '{nao encontrado}';
                     --
                     l_error      := TRUE;
                     --
                     l_error_msg  := 'Comprador padrao nao encontrado no EBS';
                  --
               END;
               --
            END IF; -- IF NOT l_error standard buyer
            --
            create_output ( p_type        => 'ROW_ITEM'
                           ,p_id_material => r_items.id_material
                           ,p_buyer_name  => l_buyer_name
                          );
            --
            IF NOT l_error THEN -- NOT l_error buyer_id
               --
               create_log(l_name,'Verificando informacao para subfamilia');
               --
               OPEN c_variable_data ( p_id_cliente  => l_id_cliente
                                     ,p_id_material => r_items.id_material
                                     ,p_attribute   => 'SUBFAMILIA'
                                    );
               --
               BEGIN
                  --
                  FETCH c_variable_data INTO l_subfamily;
                  --
                  IF l_subfamily IS NULL THEN -- IF l_subfamily IS NULL
                     --
                     RAISE_APPLICATION_ERROR(-20001, 'Consulta de subfamilia retornou valor nulo');
                     --
                  END IF; -- IF l_subfamily IS NULL
                  --
               EXCEPTION
                  WHEN OTHERS THEN
                     --
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     create_log(l_name,'ERROR: Problema ao buscar subfamilia - ' || SQLERRM);
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     --
                     l_error     := TRUE;
                     --
                     l_error_msg := 'Problema ao buscar subfamilia';
                     --
               END;
               --
               IF c_variable_data%ISOPEN THEN -- IF c_variable_data%ISOPEN subfamily
                  --
                  close c_variable_data;
                  --
               END IF; -- IF c_variable_data%ISOPEN subfamily
               --
               create_log(l_name,'Encontrada a subfamilia: ' || NVL(l_subfamily,'{NULO}'));
               --
            END IF; -- NOT l_error buyer_id
            --
            IF NOT l_error THEN -- IF NOT l_error subfamily
               --
               l_category := r_items.grupo_cod||r_items.familia_cod||l_subfamily;
               --
               IF r_items.clirefcod IS NOT NULL AND r_items.ordem = 2 THEN -- IF r_items.clirefcod IS NOT NULL AND r_items.ordem = 2
                  --
                  l_segment1 := r_items.clirefcod;
                  --
               ELSE -- IF r_items.clirefcod IS NOT NULL
                  BEGIN
                     --
                     IF r_items.ordem = 1 THEN -- IF r_items.ordem = 1
                        --
                        SELECT COUNT(1)
                          INTO l_depara_chk
                          FROM xxclk.depara_comlink
                         WHERE id_material = r_items.id_material;
                        --
                        IF l_depara_chk > 0 THEN -- IF l_depara_chk > 0
                           --
                           RAISE_APPLICATION_ERROR(-20008, 'Material enviado como CLK ja existe na tabela depara_comlink.');
                           --
                        END IF; -- IF l_depara_chk > 0
                        --
                     END IF; -- IF r_items.ordem = 1
                     --
                     SELECT MAX(item_seq) + 1
                       INTO l_segment1_seq
                       FROM (
                             SELECT MAX(TO_NUMBER(SUBSTR(msib.segment1,9,5))) item_seq
                               FROM mtl_system_items_b         msib
                              WHERE SUBSTR(msib.segment1,1,8) = l_category
                             UNION
                             SELECT MAX(TO_NUMBER(SUBSTR(msii.segment1,9,5)))
                               FROM mtl_system_items_interface msii
                              WHERE SUBSTR(msii.segment1,1,8) = l_category
                            );
                     --
                     l_segment1 := l_category || LPAD(l_segment1_seq, 5, '0');
                     --
                  EXCEPTION
                     WHEN OTHERS THEN
                     --
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     create_log(l_name,'ERROR: Problema ao atualizar sequencia de item - ' || SQLERRM);
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     --
                     l_error     := TRUE;
                     --
                     l_error_msg := 'Problema ao atualizar sequencia de item';
                     --
                  END;
                  --
               END IF; -- IF r_items.clirefcod IS NOT NULL AND r_items.ordem = 2
               --
               IF NOT l_error THEN -- IF NOT l_error in item sequence
                  --
                  BEGIN
                     --
                     SELECT inventory_item_id
                       INTO l_inventory_item_id
                       FROM mtl_system_items_b
                      WHERE segment1 = l_segment1
                      AND ROWNUM = 1;
                      --
                   EXCEPTION
                      WHEN OTHERS THEN
                      --
                      create_log(l_name,'Gerando novo ID para item de inventario.');
                      --
                      SELECT mtl_system_items_interface_s.NEXTVAL
                      INTO l_inventory_item_id
                      FROM DUAL;
                      --
                  END;
                  --
                  create_log(l_name,'Abrindo c_organization Cursor');
                  --
                  FOR r_organization IN c_organization ( p_id_cliente  => l_id_cliente
                                                        ,p_id_material => r_items.id_material
                                                        ,p_clirefcod   => r_items.clirefcod
                                                       ) LOOP -- LOOP r_organization
                     --
                     BEGIN
                        --
                        SELECT organization_id
                          INTO l_organization_id
                          FROM org_organization_definitions
                         WHERE inventory_enabled_flag = 'Y'
                           AND disable_date IS NULL
                           AND organization_code = r_organization.organization_code;
                        --
                     EXCEPTION
                        WHEN OTHERS THEN
                        --
                        create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                        create_log(l_name,'ERROR: ID da organizacao nao encontrado para codigo: ' || r_organization.organization_code || '.');
                        create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                        --
                        l_error     := TRUE;
                        --
                        l_error_msg := 'ID da organizacao nao encontrado';
                        --
                     END;
                     --
                     create_output ( p_type         => 'ROW_ORGANIZATION'
                                    ,p_organization => r_organization.organization_code );
                     --
                     IF NOT l_error THEN -- IF NOT l_error finding UOM
                        --
                        BEGIN
                           --
                           IF r_items.ordem = 1 and l_organization_id = l_master_org_id THEN -- IF r_items.ordem = 1 and l_organization_id = l_master_org_id
                              --
                              SELECT uom_code
                                    ,unit_of_measure
                                INTO l_uom_code,
                                     l_unit_of_measure
                                FROM mtl_units_of_measure
                               WHERE UPPER(uom_code) = UPPER(r_items.unidade);
                              --
                           END IF; -- IF r_items.ordem = 1 and l_organization_id = l_master_org_id
                           --
                        EXCEPTION
                           WHEN OTHERS THEN
                           --
                           create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           create_log(l_name,'ERROR: Nao foi encontrada no EBS a unidade de medida: ' || r_items.unidade || '.');
                           create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           --
                           l_error     := TRUE;
                           --
                           l_error_msg := 'Nao foi encontrada no EBS a unidade de medida';
                           --
                        END;
                        --
                     END IF; -- IF NOT l_error finding UOM
                     --
                     IF NOT l_error THEN -- IF NOT l_error Before Insert INV Itens Interface
                        --
                        IF l_set_process_id IS NULL AND NOT l_error THEN -- IF l_set_process_id IS NULL AND NOT l_error
                           --
                           SELECT mtl_system_items_intf_sets_s.NEXTVAL
                             INTO l_set_process_id
                            FROM DUAL;
                            --
                        END IF; -- IF l_set_process_id IS NULL AND NOT l_error
                        --
                        create_log(l_name,'Populando tabela Interface de Itens INV ');
                        --
                        BEGIN
                           --
                           -- Change Information for master
                           IF l_organization_id = l_master_org_id THEN -- l_organization_id = l_master_org_id
                              --
                              l_enabled_flag := 'Y';
                              l_buyer_id     := NULL;
                              --
                           ELSE
                              --
                              l_enabled_flag := NULL;
                              --
                           END IF; -- l_organization_id = l_master_org_id
                           --
                           INSERT INTO mtl_system_items_interface ( inventory_item_id                              -- 01
                                                                   ,organization_id                                -- 02
                                                                   ,segment1                                       -- 03
                                                                   ,last_update_date                               -- 04
                                                                   ,last_updated_by                                -- 05
                                                                   ,creation_date                                  -- 06
                                                                   ,created_by                                     -- 07
                                                                   ,last_update_login                              -- 08
                                                                   ,description                                    -- 09
                                                                   ,long_description                               -- 10
                                                                   ,attribute5                                     -- 11
                                                                   ,template_id                                    -- 13
                                                                   ,process_flag                                   -- 14
                                                                   ,transaction_type                               -- 15
                                                                   ,request_id                                     -- 16
                                                                   ,program_application_id                         -- 17
                                                                   ,buyer_id                                       -- 18
                                                                   ,attribute_category                             -- 19
                                                                   ,enabled_flag                                   -- 20
                                                                   ,set_process_id                                 -- 21
                                                                   ,primary_uom_code                               -- 22
                                                                  )
                                                           VALUES ( l_inventory_item_id                            -- 01
                                                                   ,l_organization_id                              -- 02
                                                                   ,l_segment1                                     -- 03
                                                                   ,sysdate                                        -- 04
                                                                   ,l_user_id                                      -- 05
                                                                   ,sysdate                                        -- 06
                                                                   ,l_user_id                                      -- 07
                                                                   ,l_login_id                                     -- 08
                                                                   ,SUBSTR(r_items.matdsccomp, 1, 240)             -- 09
                                                                   ,r_items.matdsccomp                             -- 10
                                                                   ,r_items.marca                                  -- 11
                                                                   ,get_template(l_organization_id)                -- 13
                                                                   ,1                                              -- 14
                                                                   ,l_transaction_type                             -- 15
                                                                   ,l_conc_request_id                              -- 16
                                                                   ,l_prog_appl_id                                 -- 17
                                                                   ,l_buyer_id                                     -- 18
                                                                   ,l_attribute_category                           -- 19
                                                                   ,l_enabled_flag                                 -- 20
                                                                   ,l_set_process_id                               -- 21
                                                                   ,l_uom_code                                     -- 22
                                                                  );
                           --
                           create_log(l_name,'Item inserido na tabela Interface de Itens INV para OI ' || l_organization_id || '.');
                           --
                           create_log(l_name,'Obtendo valores para categorias.');
                           --
                           FOR r_category in c_category LOOP -- r_category
                              --
                              IF l_organization_id = l_master_org_id THEN -- IF l_organization_id = l_master_org_id
                                 --
                                 -- Get for specifc Categories
                                 IF r_category.category_set_id = l_cat_set_inv THEN -- r_category.category_set_id = l_cat_set_inv
                                    --
                                    l_category_id :=  get_category(
                                                                   r_category.structure_id
                                                                  ,r_items.grupo_cod   ||
                                                                   r_items.familia_cod ||
                                                                   l_subfamily
                                                                  );
                                    --
                                 ELSIF r_category.category_set_id = l_cat_set_ncm THEN
                                    --
                                    l_category_id :=  get_category(
                                                                   r_category.structure_id
                                                                  ,r_items.ncm
                                                                  );
                                    --
                                 ELSE
                                    --
                                    l_category_id :=  r_category.category_id;
                                    --
                                 END IF; -- r_category.category_set_id = l_cat_set_inv
                                 --
                                 INSERT INTO mtl_item_categories_interface ( inventory_item_id                    -- 01
                                                                            ,organization_id                      -- 02
                                                                            ,transaction_type                     -- 03
                                                                            ,process_flag                         -- 04
                                                                            ,set_process_id                       -- 05
                                                                            ,category_set_id                      -- 06
                                                                            ,category_id                          -- 07
                                                                            ,creation_date                        -- 08
                                                                            ,created_by                           -- 09
                                                                            ,last_update_date                     -- 10
                                                                            ,last_updated_by                      -- 11
                                                                            ,request_id                           -- 12
                                                                            ,program_application_id               -- 13
                                                                           )
                                                                    VALUES ( l_inventory_item_id                  -- 01
                                                                            ,l_organization_id                    -- 02
                                                                            ,l_transaction_type                   -- 03
                                                                            ,1                                    -- 04
                                                                            ,l_set_process_id                     -- 05
                                                                            ,r_category.category_set_id           -- 06
                                                                            ,l_category_id                        -- 07
                                                                            ,SYSDATE                              -- 08
                                                                            ,l_user_id                            -- 09
                                                                            ,SYSDATE                              -- 10
                                                                            ,l_login_id                           -- 11
                                                                            ,l_conc_request_id                    -- 12
                                                                            ,l_prog_appl_id                       -- 13
                                                                           );
                                 --
                              END IF; -- IF l_organization_id = l_master_org_id
                              --
                           END LOOP; -- r_category
                           --
                        EXCEPTION
                           WHEN OTHERS THEN
                           --
                           create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           create_log(l_name,'ERROR: Erro populando item  na tabela de INV - ' || SQLERRM);
                           create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           --
                           l_error     := TRUE;
                           --
                           l_error_msg := 'Erro populando tabela Interface de Itens INV';
                           --
                        END;
                        --
                     END IF; -- IF NOT l_error Before Insert INV Itens Interface
                     --
                  END LOOP; -- LOOP r_organization
                  --
               END IF; -- IF NOT l_error in item sequence
               --
            END IF; -- IF NOT l_error subfamily;
            --
            IF NOT l_error THEN -- IF NOT l_error after Insert INV Itens Interface
               --
               BEGIN
                  --
                  UPDATE mtl_system_items_b
                     SET buyer_id           = NULL
                        ,description        = SUBSTR(r_items.matdsccomp, 1, 240)
                   WHERE inventory_item_id  = l_inventory_item_id;
                   --
                   UPDATE mtl_system_items_tl
                      SET description        = SUBSTR(r_items.matdsccomp, 1, 240)
                         ,long_description   = r_items.matdsccomp
                    WHERE inventory_item_id  = l_inventory_item_id;
                  --
                  COMMIT;
                  --
                  l_count_success := l_count_success + 1;
                  --
                  l_status_upd    := 'SUCESSO';
                  --
                  create_log(l_name,'Item processado com sucesso');
                  --
                  create_output ( p_type         => 'ROW_RESULT'
                                 ,p_item_number  => l_segment1
                                 ,p_status       => l_status_upd
                                );
                  --
                  create_log(l_name,'Alterando tabela transitoria para validacao da carga do material ' || r_items.id_material || ' - ' || l_segment1);
                  --
                  BEGIN
                    --
                    validate_transitory( p_id_material   => r_items.id_material
                                        ,p_clirefcod     => l_segment1
                                        ,p_operation     => r_items.ordem
                                        ,p_id_referencia => r_items.id_referencia
                                       );
                    --
                  EXCEPTION
                     WHEN OTHERS THEN
                     --
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     create_log(l_name,'ERROR: Erro na validacao da tabela transitoria - ' || SQLERRM);
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     --
                     l_error_msg := 'Erro na validacao da tabela transitoria';
                     --
                  END;
                  --
               EXCEPTION
                  WHEN OTHERS THEN
                  --
                  ROLLBACK;
                  --
                  l_error := TRUE;
                  --
                  create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                  create_log(l_name,'ERROR: Problema ao atualizar BUYER_ID - ' || SQLERRM);
                  create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                  --
                  l_error_msg := 'Problema ao atualizar BUYER_ID';
                  --
                  l_count_error := l_count_error + 1;
                  --
                  l_status_upd  := 'ERRO';
                  --
                  create_log(l_name,'Item processado com erro.');
                  --
                  BEGIN
                     --
                     error_message( p_id_cliente     => l_id_cliente
                                   ,p_id_referencia  => r_items.id_referencia
                                   ,p_id_material    => r_items.id_material
                                   ,p_error          => l_error_msg
                                  );
                     --
                  EXCEPTION
                     WHEN OTHERS THEN
                     --
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     create_log(l_name,'ERROR: Erro atualizando mensagem transitoria de erro - ' || SQLERRM);
                     create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                     --
                     l_error := TRUE;
                     --
                  END;
                  --
                  create_output ( p_type         => 'ROW_RESULT'
                                 ,p_item_number  => l_segment1
                                 ,p_status       => l_status_upd
                                );
                  --
               END;
               --
            ELSE -- IF NOT l_error after Insert INV Itens Interface
               --
               ROLLBACK;
               --
               l_count_error := l_count_error + 1;
               --
               l_status_upd  := 'ERRO';
               --
               create_log(l_name,'Item processado com erro.');
               --
               BEGIN
                  --
                  error_message( p_id_cliente     => l_id_cliente
                                ,p_id_referencia  => r_items.id_referencia
                                ,p_id_material    => r_items.id_material
                                ,p_error          => l_error_msg
                               );
                  --
               EXCEPTION
                  WHEN OTHERS THEN
                  --
                  create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                  create_log(l_name,'ERROR: Erro atualizando mensagem transitoria de erro - ' || SQLERRM);
                  create_log(l_name,'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                  --
                  l_error := TRUE;
                  --
               END;
               --
               create_output ( p_type         => 'ROW_RESULT'
                              ,p_item_number  => l_segment1
                              ,p_status       => l_status_upd
                             );
               --
            END IF; -- IF NOT l_error after Insert INV Itens Interface
            --
            create_log(l_name,'Fim do processamento do item.');
            --
         END IF;  -- IF NOT l_error - Before Preparations
         --
      END LOOP; -- LOOP r_items
      --
      create_log(l_name,'---------------------------------');
      create_log(l_name,'          Total Itens: ' || l_count_total);
      create_log(l_name,'Total Itens (Sucesso): ' || l_count_success);
      create_log(l_name,'  Total Itens (Error): ' || l_count_error);
      create_log(l_name,'---------------------------------');
      --
      create_output ( p_type    => 'SUM'
                     ,p_total   => l_count_total
                     ,p_success => l_count_success
                     ,p_error   => l_count_error);
      --
      IF l_count_total = l_count_success THEN -- IF l_count_total = l_count_success
         --
         retcode := 0;
         errbuf  := 'Interface de Itens INV Oracle x COMLINK com sucesso';
         --
      ELSIF l_count_total = l_count_error THEN -- IF l_count_total = l_count_success
         --
         retcode := 2;
         errbuf  := 'Interface de Itens INV Oracle x COMLINK com erro. Verifique o arquivo de log';
         --
      ELSE -- IF l_count_total = l_count_success
         --
         retcode := 1;
         errbuf  := 'Interface de Itens INV Oracle x COMLINK com advertencia. Verifique o arquivo de log';
         --
      END IF; -- IF l_count_total = l_count_success
      --
      IF retcode != 2 AND l_count_total > 0 THEN -- IF retcode != 2 AND l_count_total > 0
         --
         BEGIN
            --
            l_incoin_request_id := fnd_request.submit_request ( application => 'INV'
                                                               ,program     => 'INCOIN'
                                                               ,description => NULL
                                                               ,start_time  => sysdate
                                                               ,sub_request => FALSE
                                                               ,argument1   => l_org_id
                                                               ,argument2   => 1
                                                               ,argument3   => 1
                                                               ,argument4   => 1
                                                               ,argument5   => 1
                                                               ,argument6   => l_set_process_id
                                                               ,argument7   => 3
                                                               ,argument8   => 1
                                                              );
            --
            COMMIT;
            --
            IF l_incoin_request_id > 0 THEN -- IF l_incoin_request_id > 0
               --
               LOOP
                  --
                  l_return_status    := FND_CONCURRENT.WAIT_FOR_REQUEST ( request_id      => l_incoin_request_id
                                                                         ,interval        => 5
                                                                         ,max_wait        => 10
                                                                         ,phase           => l_phase
                                                                         ,status          => l_status
                                                                         ,dev_phase       => l_dev_phase
                                                                         ,dev_status      => l_dev_status
                                                                         ,message         => l_message
                                                                        );
                  --
                  EXIT WHEN UPPER(SUBSTR(l_phase,1,4))  IN ('COMP', 'CONC')
                         OR UPPER(SUBSTR(l_status,1,4)) IN ('CANC', 'ERRO', 'TERM');
                  --
               END LOOP;
               --
               IF UPPER(SUBSTR(l_phase,1,4)) IN ('COMP', 'CONC') AND UPPER(SUBSTR(l_status,1,4)) = 'ERRO' THEN -- IF UPPER(SUBSTR(l_phase,1,4)) IN ('COMP', 'CONC') AND UPPER(SUBSTR(l_status,1,4)) = 'ERRO'
                  --
                  create_log(l_name,'Erro na execucao do concurrent de integracao de itens. Oracle request id: '||
                             l_incoin_request_id ||' '||SQLERRM);
                  --
               ELSIF UPPER(SUBSTR(l_phase,1,4)) IN ('COMP', 'CONC') AND UPPER(l_status) = 'NORMAL' THEN
                  --
                  create_log(l_name,'Concurrent de integracao de itens executou normalmente com request id: ' ||
                             l_incoin_request_id);
               END IF; -- IF UPPER(SUBSTR(l_phase,1,4)) IN ('COMP', 'CONC') AND UPPER(SUBSTR(l_status,1,4)) = 'ERRO'
               --
            END IF; -- IF l_incoin_request_id > 0
            --
            IF l_conc_request_id = 0 THEN -- IF l_conc_request_id = 0
               --
               create_log(l_name,' ');
               create_log(l_name,'Concurrent de integracao de itens nao executado');
               create_log(l_name,' ');
               --
            ELSE -- IF l_conc_request_id = 0
               --
               create_log(l_name,' ');
               create_log(l_name,'Concurrent ' || l_incoin_request_id || ' de integracao de itens executado.');
               create_log(l_name,' ');
               --
            END IF; -- IF l_conc_request_id = 0
            --
        END;
         --
      END IF; -- IF retcode != 2 AND l_count_total > 0
      --
      create_log(l_name,' ');
      create_log(l_name,'Finalizando Interface de Itens INV Oracle x COMLINK.');
      create_log(l_name,' ');
      --
   END get_items;
   --
END XXCLK_INV_INTERFACE_PKG;
/

exit
