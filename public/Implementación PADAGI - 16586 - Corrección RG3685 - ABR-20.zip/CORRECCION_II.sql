UPDATE  apps.ap_invoice_distributions_all aid
SET    attribute6 = '2019/05/03 00:00:00', last_update_date = sysdate, last_updated_by = 2070
WHERE  attribute4 = '0002-00025955'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'JUAN JOSE WILLINER');
--5 Registros