UPDATE apps.ap_invoices_all ai
SET    global_attribute11 = 'FC SERVICI', global_attribute13 = '11', last_update_date = sysdate, last_updated_by = 2070
WHERE  invoice_num = '0001-00000070'
AND    vendor_id = (SELECT vendor_id
                    FROM   apps.ap_suppliers
                    WHERE  vendor_name = 'CARAN LEZCANO MARIO JUAN MARTIN');
--1 Registro