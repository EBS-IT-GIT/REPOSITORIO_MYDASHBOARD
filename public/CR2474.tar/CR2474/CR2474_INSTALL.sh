#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2474_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2474
# |
# | HISTORY
# |   04-MAY-20  SOUZA, ARNALDO JULIO DE MELO - Bra
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2474_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2474_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2474
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2474" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2474_13899.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2474"
AddAllLogs $CROUT "FND" "CR2474_13899.ldt"
mv CR2474_13899.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OPM_AJUSTE_GATEC_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OPM_AJUSTE_GATEC_PKG','','$PATCHDIR','CR2474');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_AJUSTE_GATEC_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_OPM_AJUSTE_GATEC_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_AJUSTE_GATEC_PKG >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_AJUSTE_GATEC_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_AJUSTE_GATEC_PKG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_AJUSTE_GATEC_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_AJUSTE_GATEC_PKG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_AJUSTE_GATEC_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2474" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2474_13899.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2474_13899.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
