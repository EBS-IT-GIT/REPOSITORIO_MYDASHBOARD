#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2312_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2312
# |
# | HISTORY
# |   07-JAN-20  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2312_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2312_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2312
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2312" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2312_9305.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2312"
AddAllLogs $CROUT "FND" "CR2312_9305.ldt"
mv CR2312_9305.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_WMS_INT_OUT_ASN_ORDERS_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_WMS_INT_OUT_ASN_ORDERS_PK','APPS','$PATCHDIR','CR2312');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_WMS_INT_OUT_ASN_ORDERS_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF BATCH_FLEX_1793_LINEA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct BATCH_FLEX_1793_LINEA.ldt DESC_FLEX APPLICATION_SHORT_NAME="GME" DESCRIPTIVE_FLEXFIELD_NAME="BATCH_FLEX" DESCRIPTIVE_FLEX_CONTEXT_CODE="1793" END_USER_COLUMN_NAME="LINEA"
AddAllLogs $CROUT "FND" "BATCH_FLEX_1793_LINEA.ldt"
mv BATCH_FLEX_1793_LINEA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_WMS_INT_OUT_ASN_ORDERS_PK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='American_America.WE8MSWIN1252'
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_WMS_INT_OUT_ASN_ORDERS_PK >> $CROUT

export NLS_LANG='American_America.WE8MSWIN1252'
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_WMS_INT_OUT_ASN_ORDERS_PK.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_WMS_INT_OUT_ASN_ORDERS_PK.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_WMS_INT_OUT_ASN_ORDERS_PK.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_WMS_INT_OUT_ASN_ORDERS_PK.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_WMS_INT_OUT_ASN_ORDERS_PK.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF BATCH_FLEX_1793_LINEA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/BATCH_FLEX_1793_LINEA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2312" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2312_9305.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2312_9305.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
