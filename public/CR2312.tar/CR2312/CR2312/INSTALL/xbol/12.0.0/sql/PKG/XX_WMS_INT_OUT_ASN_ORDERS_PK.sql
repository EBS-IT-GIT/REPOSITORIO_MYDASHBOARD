  set define off;

create or replace PACKAGE        "XX_WMS_INT_OUT_ASN_ORDERS_PK" AS
/* $Header: $ */
/*#
* This interface returns ASN Information
* @rep:scope public
* @rep:product XBOL
* @rep:displayname xx_wms_int_out_asn_orders_pk
* @rep:lifecycle active
* @rep:compatibility S
* @rep:category BUSINESS_ENTITY GME_PENDING_PRODUCT_LOTS
*/
/*#
* get_inegration_data
* @param P_INT_TYPE Tipo Integracion
* @param X_XML_ASN XML con informacion de ordenes de producción
* @param X_XML_APPOINTMENT XML con informacion de citas
* @param X_REQUEST_ID Identificador de procesamiento
* @param X_RETURN_STATUS Return status indicating success or failure
* @param X_MSG_DATA Return error message
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname WMS ASN Integration OUT
*/

PROCEDURE get_integration_data
(p_int_type                  IN  VARCHAR2
,x_xml_asn                   OUT NOCOPY CLOB
,x_xml_appointment           OUT NOCOPY CLOB
,x_request_id                OUT NUMBER
,x_return_status             OUT VARCHAR2
,x_msg_data                  OUT VARCHAR2
);

/*#
* update_response_integration
* @param P_INT_TYPE Tipo Integracion
* @param P_REQUEST_ID Identificador de procesamiento
* @param P_RETURN_STATUS Return status indicating success or failure
* @param P_MSG_DATA Return error message
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname WMS ASN Integration Update Response
*/

PROCEDURE update_response_integration
(p_int_type                  IN  VARCHAR2
,p_request_id                IN  NUMBER
,p_return_status             IN  VARCHAR2
,p_msg_data                  IN  VARCHAR2
);
END xx_wms_int_out_asn_orders_pk;
/


create or replace PACKAGE BODY xx_wms_int_out_asn_orders_pk
AS
-- --------------------------------------------------------------------------
--  1.0  09-10-2019  MLaudati   Version Original
--  1.1  29-11-2019  MLaudati   Modificado Formato de Fecha de Vencimiento => YYYY-MM-DD.
--	1.2  02-12-2019  MLaudati	Se Comenta el Envio de invn_attr_c en XML de shipment_dtl
--  1.3  02-12-2019  MLaudati	Se Agrega el Campo priority_date en XML de shipment_dtl

    g_pkg_name			constant varchar2(30) := 'XX_WMS_INT_OUT_ASN_ORDERS_PK';
	g_do_debug			constant boolean := case when(nvl(fnd_profile.value('XX_DEBUG_ENABLED'), 'N') = 'Y')then true else false end;

    --//-----------------------------------------------------------
	--//-----------------------------------------------------------
	procedure debug(
		i_message	in varchar2
	)
	is
		pragma autonomous_transaction;
	begin
		if(g_do_debug)then
			insert into xx_debug_messages(
				session_id, debug_sequence, debug_level, created_by, creation_date, last_updated_by, last_update_date, module, message
			) values (
				dbms_session.unique_session_id,
				xx_debug_messages_s.nextval, 1,	fnd_global.user_id, sysdate, fnd_global.user_id, sysdate,
				g_pkg_name, i_message
			);

			commit;
		end if;
	exception
		when others then
			rollback;
	end debug;

PROCEDURE get_integration_data
(p_int_type                  IN  VARCHAR2
,x_xml_asn                   OUT NOCOPY CLOB
,x_xml_appointment           OUT NOCOPY CLOB
,x_request_id                OUT NUMBER
,x_return_status             OUT VARCHAR2
,x_msg_data                  OUT VARCHAR2
) AS

	--//--------------------------------------------------------
    c_days				CONSTANT	NUMBER := 7;
	c_status_wip		CONSTANT	NUMBER := 2;
	c_status_cancelled	CONSTANT	NUMBER := -1;
	c_line_type			CONSTANT	NUMBER := 1;
	--//--------------------------------------------------------
	l_request_id    NUMBER := to_char(sysdate,'YYYYMMDDHH24MI');
	l_date_from     DATE;
	l_items_sdvu    VARCHAR2(2000);
    l_rows          NUMBER;
	e_error         EXCEPTION;
	l_xml			XMLTYPE;
	l_proc			VARCHAR2(30) := 'get_integration_data: ';

	function get_date_from return date
	is
		l_date date;
	begin
		select nvl(to_date(max(request_id), 'YYYYMMDDHH24MI'), (sysdate - c_days)) into l_date from xx_wms_int_asn_orders;
		return l_date;
	end get_date_from;

BEGIN

	l_date_from := get_date_from;

	debug(l_proc || 'Init => ' || p_int_type || ' Request_Id => ' || l_request_id || ' L_Date_From => ' || to_char(l_date_from, 'DD/MM/YYYY HH24:MI:SS'));

  --
  -- Elimino en la tabla los registros con OP que no tienen pending lots asociados
  --
  BEGIN

	DELETE XX_WMS_INT_ASN_ORDERS XIA
	WHERE XIA.PENDING_PRODUCT_LOT_ID IS NULL
	AND XIA.REQUEST_ID != l_request_id
	;

	debug(l_proc || 'Eliminar en la tabla los registros con OP que no tienen pending lots asociados => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al eliminar registros con OP que no tienen pending lots asociados: ' || sqlerrm;
      RAISE e_error;
  END;

  --
  -- Actualizo en la tabla los registros con error para volver a enviar a WMS
  --
  BEGIN

	UPDATE XX_WMS_INT_ASN_ORDERS XIA
	SET XIA.STATUS = 'NEW', XIA.ERROR_MESG = null, XIA.REQUEST_ID = l_request_id, XIA.LAST_UPDATE_DATE = SYSDATE
	--WHERE XIA.STATUS = 'ERROR'
	WHERE XIA.STATUS != 'OK'
	AND XIA.ACTION_CODE != 'DELETE'
	AND XIA.REQUEST_ID != l_request_id
	;

	debug(l_proc || 'Actualizar en la tabla los registros con error para volver a enviar a WMS => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al actualizar registros con error: ' || sqlerrm;
      RAISE e_error;
  END;

  --
  -- Inserto en la tabla las novedades de items para enviar a WMS
  --
  BEGIN
    INSERT INTO xx_wms_int_asn_orders (
		   request_id
          ,batch_id
          ,material_detail_id
		  ,pending_product_lot_id
          ,inventory_item_id
          ,organization_id
		  ,lot_number
          ,action_code
          ,status
          ,error_mesg
          ,creation_date
          ,created_by
          ,last_update_date
          ,last_updated_by
	)
	SELECT
	 request_id
	,batch_id
	,material_detail_id
	,pending_product_lot_id
	,inventory_item_id
	,organization_id
	,lot_number
	,action_code
	,status
	,error_mesg
	,creation_date
	,created_by
	,last_update_date
	,last_updated_by
	FROM (
		SELECT l_request_id request_id
			  ,gbh.batch_id batch_id
			  ,gmt.material_detail_id material_detail_id
			  ,gppl.pending_product_lot_id pending_product_lot_id
			  ,gmt.inventory_item_id inventory_item_id
			  ,gmt.organization_id organization_id
			  ,gppl.lot_number
			  ,case
				when(gppl.creation_date > l_date_from)then 'CREATE'
				when(gppl.last_update_date > l_date_from)then 'UPDATE'
			  end action_code
			  ,'NEW' status
			  ,NULL  error_mesg
			  ,sysdate creation_date
			  ,fnd_global.user_id created_by
			  ,sysdate last_update_date
			  ,fnd_global.user_id last_updated_by
		  FROM gme_batch_header gbh
			  ,gme_material_details gmt
			  ,gme_pending_product_lots gppl
			  ,mtl_system_items msi
			  ,mtl_parameters mp
			  ,fnd_lookup_values_vl flv
			  ,fnd_lookup_values_dfv flv_dfv
		 WHERE 1 = 1
		   AND gbh.batch_id = gmt.batch_id
		   AND msi.inventory_item_id = gmt.inventory_item_id
		   AND msi.organization_id = gmt.organization_id
		   AND msi.organization_id = mp.organization_id
		   AND gppl.material_detail_id = gmt.material_detail_id
		   AND flv.rowid = flv_dfv.row_id
		   AND flv.lookup_type = 'XX_MAPEO_EBS_WMS'
		   AND flv_dfv.xx_org_opm = mp.organization_code
		   AND (
				gppl.creation_date  > l_date_from OR
				gppl.last_update_date  > l_date_from
		   )
		   AND gmt.line_type = c_line_type
		   AND gbh.batch_status = c_status_wip
		   AND NOT EXISTS(
				select 1
				from
				 mtl_material_transactions mtt
				,mtl_transaction_lot_numbers mtln
				where 1=1
				and mtt.transaction_id = mtln.transaction_id
				and mtt.transaction_type_id = 44 --//WIP Completion
				and mtt.transaction_source_id = gbh.batch_id
				and mtln.lot_number = gppl.lot_number
		   )
		   AND EXISTS(
				select 1
				from
				 fm_form_mst_b ffm
				,mtl_system_items_b items
				where 1=1
				and ffm.owner_organization_id = items.organization_id
				and ffm.formula_no = items.segment1
				and items.organization_id = gmt.organization_id
				and items.inventory_item_id = gmt.inventory_item_id
				and ffm.formula_class = 'FR'
				and ffm.inactive_ind = 0
		   )
		UNION
		SELECT l_request_id request_id
			  ,gbh.batch_id batch_id
			  ,gmt.material_detail_id material_detail_id
			  ,NULL pending_product_lot_id
			  ,gmt.inventory_item_id inventory_item_id
			  ,gmt.organization_id organization_id
			  ,NULL lot_number
			  ,'CREATE' action_code
			  ,'ERROR' status
			  ,'No existe pending lot para esta OP'  error_mesg
			  ,sysdate creation_date
			  ,fnd_global.user_id created_by
			  ,sysdate last_update_date
			  ,fnd_global.user_id last_updated_by
		  FROM gme_batch_header gbh
			  ,gme_material_details gmt
			  ,mtl_system_items msi
			  ,mtl_parameters mp
			  ,fnd_lookup_values_vl flv
			  ,fnd_lookup_values_dfv flv_dfv
		 WHERE 1 = 1
		   AND gbh.batch_id = gmt.batch_id
		   AND msi.inventory_item_id = gmt.inventory_item_id
		   AND msi.organization_id = gmt.organization_id
		   AND msi.organization_id = mp.organization_id
		   AND flv.rowid = flv_dfv.row_id
		   AND flv.lookup_type = 'XX_MAPEO_EBS_WMS'
		   AND flv_dfv.xx_org_opm = mp.organization_code
		   AND gmt.line_type = c_line_type
		   AND gbh.batch_status = c_status_wip
		   AND NOT EXISTS(
				select 1
				from gme_pending_product_lots gppl
				where 1=1
				and gppl.batch_id = gbh.batch_id
		   )
		   AND NOT EXISTS(
				select 1
				from xx_wms_int_asn_orders xwiao
				where 1=1
				and xwiao.batch_id = gmt.batch_id
				and xwiao.material_detail_id = gmt.material_detail_id
				and xwiao.organization_id = gmt.organization_id
				and xwiao.inventory_item_id = gmt.inventory_item_id
				and xwiao.status = 'OK'
		   )
		   AND EXISTS(
				select 1
				from
				 fm_form_mst_b ffm
				,mtl_system_items_b items
				where 1=1
				and ffm.owner_organization_id = items.organization_id
				and ffm.formula_no = items.segment1
				and items.organization_id = gmt.organization_id
				and items.inventory_item_id = gmt.inventory_item_id
				and ffm.formula_class = 'FR'
				and ffm.inactive_ind = 0
		   )
		UNION
		SELECT l_request_id request_id
			  ,gbh.batch_id batch_id
			  ,gmt.material_detail_id material_detail_id
			  ,xx.pending_product_lot_id pending_product_lot_id
			  ,gmt.inventory_item_id inventory_item_id
			  ,gmt.organization_id organization_id
			  ,xx.lot_number
			  ,'DELETE' action_code
			  ,'NEW' status
			  ,NULL  error_mesg
			  ,sysdate creation_date
			  ,fnd_global.user_id created_by
			  ,sysdate last_update_date
			  ,fnd_global.user_id last_updated_by
		  FROM gme_batch_header gbh
			  ,gme_material_details gmt
			  ,mtl_system_items msi
			  ,mtl_parameters mp
			  ,fnd_lookup_values_vl flv
			  ,fnd_lookup_values_dfv flv_dfv
			  ,xx_wms_int_asn_orders xx
		 WHERE 1 = 1
		   AND gbh.batch_id = gmt.batch_id
		   AND msi.inventory_item_id = gmt.inventory_item_id
		   AND msi.organization_id = gmt.organization_id
		   AND msi.organization_id = mp.organization_id
		   AND flv.rowid = flv_dfv.row_id
		   AND flv.lookup_type = 'XX_MAPEO_EBS_WMS'
		   AND flv_dfv.xx_org_opm = mp.organization_code
		   AND gmt.line_type = c_line_type
		   AND gbh.batch_status = c_status_wip
		   --//YA EXISTE EN LA TABLA CUSTOM CON ACTION CREATE/UPDATE Y STATUS OK
			and xx.batch_id = gmt.batch_id
			and xx.material_detail_id = gmt.material_detail_id
			and xx.organization_id = gmt.organization_id
			and xx.inventory_item_id = gmt.inventory_item_id
			and xx.action_code != 'DELETE'
			and xx.status = 'OK'
		   --//------------------------------------------------------------
		   AND NOT EXISTS(
				select 1
				from xx_wms_int_asn_orders xwiao
				where 1=1
				and xwiao.batch_id = gmt.batch_id
				and xwiao.material_detail_id = gmt.material_detail_id
				and xwiao.pending_product_lot_id = xx.pending_product_lot_id
				and xwiao.lot_number = xx.lot_number
				and xwiao.organization_id = gmt.organization_id
				and xwiao.inventory_item_id = gmt.inventory_item_id
				and xwiao.action_code = 'DELETE'
		   )
		   AND NOT EXISTS(
				select 1
				from gme_pending_product_lots gppl
				where 1=1
				and gppl.pending_product_lot_id = xx.pending_product_lot_id
				and gppl.lot_number = xx.lot_number
				and gppl.batch_id = xx.batch_id
				and gppl.material_detail_id = xx.material_detail_id
		   )
		UNION
		SELECT l_request_id request_id
			  ,gbh.batch_id batch_id
			  ,gmt.material_detail_id material_detail_id
			  ,gppl.pending_product_lot_id pending_product_lot_id
			  ,gmt.inventory_item_id inventory_item_id
			  ,gmt.organization_id organization_id
			  ,gppl.lot_number
			  ,'DELETE' action_code
			  ,'NEW' status
			  ,NULL  error_mesg
			  ,sysdate creation_date
			  ,fnd_global.user_id created_by
			  ,sysdate last_update_date
			  ,fnd_global.user_id last_updated_by
		  FROM gme_batch_header gbh
			  ,gme_material_details gmt
			  ,gme_pending_product_lots gppl
			  ,mtl_system_items msi
			  ,mtl_parameters mp
			  ,fnd_lookup_values_vl flv
			  ,fnd_lookup_values_dfv flv_dfv
			  ,xx_wms_int_asn_orders xx
		 WHERE 1 = 1
		   AND gbh.batch_id = gmt.batch_id
		   AND msi.inventory_item_id = gmt.inventory_item_id
		   AND msi.organization_id = gmt.organization_id
		   AND msi.organization_id = mp.organization_id
		   AND flv.rowid = flv_dfv.row_id
		   AND flv.lookup_type = 'XX_MAPEO_EBS_WMS'
		   AND flv_dfv.xx_org_opm = mp.organization_code
		   AND gppl.batch_id = gbh.batch_id
		   AND gppl.material_detail_id = gmt.material_detail_id
		   AND gmt.line_type = c_line_type
		   AND gbh.batch_status = c_status_cancelled
		   --//YA EXISTE EN LA TABLA CUSTOM CON ACTION CREATE/UPDATE Y STATUS OK
			and xx.batch_id = gmt.batch_id
			and xx.material_detail_id = gmt.material_detail_id
			and xx.pending_product_lot_id = gppl.pending_product_lot_id
			and xx.lot_number = gppl.lot_number
			and xx.organization_id = gmt.organization_id
			and xx.inventory_item_id = gmt.inventory_item_id
			and xx.action_code != 'DELETE'
			and xx.status = 'OK'
		   --//------------------------------------------------------------
		   AND NOT EXISTS(
				select 1
				from xx_wms_int_asn_orders xwiao
				where 1=1
				and xwiao.batch_id = gmt.batch_id
				and xwiao.material_detail_id = gmt.material_detail_id
				and xwiao.pending_product_lot_id = xx.pending_product_lot_id
				and xwiao.lot_number = xx.lot_number
				and xwiao.organization_id = gmt.organization_id
				and xwiao.inventory_item_id = gmt.inventory_item_id
				and xwiao.action_code = 'DELETE'
		   )
		)
		ORDER BY batch_id
		;

	debug(l_proc || 'Insertar en la tabla las novedades de items para enviar a WMS => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al insertar en xx_wms_int_asn_orders: ' || sqlerrm;
      RAISE e_error;
  END;

  -- Se controla si se parametrizo la cantidad de dias de vida util
  BEGIN

        UPDATE XX_WMS_INT_ASN_ORDERS XIA
        SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
		XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'Item sin vida util configurada'
        WHERE EXISTS(
            SELECT 1--DISTINCT msi.segment1 || '('||mp.organization_code||')' items
              FROM mtl_system_items msi
                  ,mtl_parameters mp
             WHERE 1 = 1
               AND msi.inventory_item_id = xia.inventory_item_id
               AND msi.organization_id = xia.organization_id
               AND msi.organization_id = mp.organization_id
               AND NVL(msi.shelf_life_days,0) = 0 --dias de vida util
        )
        AND REQUEST_ID = l_request_id
        ;

		debug(l_proc || 'Item sin vida util configurada => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al validar items con vida util configurada: ' || sqlerrm;
      RAISE e_error;
  END;

  -- Se controla si las cross references estan configuradas para el item
  BEGIN

        UPDATE XX_WMS_INT_ASN_ORDERS XIA
        SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
		XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'Item sin cross references configurada'
        WHERE NOT EXISTS(
            SELECT 1
              FROM mtl_cross_references mcr
                  ,mtl_cross_references_dfv mcr_dfv
             WHERE 1 = 1
               AND mcr.inventory_item_id = xia.inventory_item_id
               AND nvl(mcr.organization_id, xia.organization_id) = xia.organization_id
               AND mcr.cross_reference_type = 'DUN14'
               AND mcr.rowid = mcr_dfv.row_id
               AND mcr_dfv.xx_uom_wms IS NOT NULL
        )
        AND REQUEST_ID = l_request_id
        ;

		debug(l_proc || 'Item sin cross references configurada => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al validar items con cross references configurada: ' || sqlerrm;
      RAISE e_error;
  END;

--/*
  -- Se controla si el item existe en la tabla de interface de items con WMS en estado OK
  BEGIN

        UPDATE XX_WMS_INT_ASN_ORDERS XIA
        SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
		XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'Item sin enviar a WMS'
        WHERE NOT EXISTS(
            SELECT 1
              FROM
               xx_wms_int_items xii
              ,mtl_parameters mp_item
              ,mtl_parameters mp_order
              ,fnd_lookup_values_vl flv
              ,fnd_lookup_values_dfv flv_dfv
             WHERE 1 = 1
               and xii.inventory_item_id = xia.inventory_item_id
               and mp_item.organization_id = xii.organization_id
               and mp_item.organization_code = flv_dfv.xx_org_transfer_prod
               and mp_order.organization_id = xia.organization_id
               and mp_order.organization_code = flv_dfv.xx_org_opm
               and flv.rowid = flv_dfv.row_id
               and flv.lookup_type = 'XX_MAPEO_EBS_WMS'
               and xii.status = 'OK'
			   and nvl(xii.item_complete_flag, 'N') = 'Y'
        )
        AND REQUEST_ID = l_request_id
        ;

		debug(l_proc || 'Item sin enviar a WMS => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al validar interface de item con WMS: ' || sqlerrm;
      RAISE e_error;
  END;
--*/

--/*
  -- Se controla si existe la conversion de unidad de medida.
  BEGIN

        UPDATE XX_WMS_INT_ASN_ORDERS XIA
        SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
		XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'No existe la conversion de unidad de medida'
        WHERE NOT EXISTS(
			select 1
			from
			 mtl_uom_class_conversions mucc
			,gme_material_details gmt
			,mtl_cross_references mcr
			,mtl_cross_references_dfv mcr_dfv
			where 1=1
			and mcr.inventory_item_id = xia.inventory_item_id
			and nvl(mcr.organization_id, xia.organization_id) = xia.organization_id
			and gmt.material_detail_id = xia.material_detail_id
			and mcr.cross_reference_type = 'DUN14'
			and mcr.rowid = mcr_dfv.row_id
			and mucc.from_uom_code = gmt.dtl_um
			and mucc.to_uom_code = mcr_dfv.xx_uom_wms
        )
        AND REQUEST_ID = l_request_id
        ;

		debug(l_proc || 'No existe la conversion de unidad de medida. => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al validar onversion de unidad de medida: ' || sqlerrm;
      RAISE e_error;
  END;
--*/

--/*
  -- Se controla si el item tiene el peso cargado (valor).
  BEGIN

        UPDATE XX_WMS_INT_ASN_ORDERS XIA
        SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
		XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'No existe peso cargado para el item'
        WHERE NOT EXISTS(
			select 1
			from mtl_system_items_b
			where 1=1
			and inventory_item_id = xia.inventory_item_id
			and organization_id = xia.organization_id
			and unit_weight is not null
        )
        AND REQUEST_ID = l_request_id
        ;

		debug(l_proc || 'No existe peso cargado para el item. => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al validar peso cargado para el item: ' || sqlerrm;
      RAISE e_error;
  END;
--*/

--/*
	-- Se calcula el expiry_date en base al nombre del lote.
	BEGIN

		UPDATE XX_WMS_INT_ASN_ORDERS XWIAO
		SET XWIAO.EXPIRY_DATE = (
			SELECT
				--TO_DATE( SUBSTR(GPPL.LOT_NUMBER, -5), 'YYDDD')
				TO_DATE(
					case
						when(to_char(sysdate, 'Y') = substr(GPPL.LOT_NUMBER, -4, 1))then to_number(to_char(sysdate, 'YY'))
						else to_number(to_char(sysdate, 'YY') + 1)
					end || SUBSTR(GPPL.LOT_NUMBER, -3)
				, 'YYDDD')
			FROM
			 GME_PENDING_PRODUCT_LOTS GPPL
			WHERE 1=1
			AND GPPL.BATCH_ID = XWIAO.BATCH_ID
			AND GPPL.PENDING_PRODUCT_LOT_ID = XWIAO.PENDING_PRODUCT_LOT_ID
			AND GPPL.LOT_NUMBER = XWIAO.LOT_NUMBER
			AND GPPL.MATERIAL_DETAIL_ID = XWIAO.MATERIAL_DETAIL_ID
		)
		WHERE XWIAO.REQUEST_ID = L_REQUEST_ID
		;

		debug(l_proc || 'Se calcula el expiry_date en base al nombre del lote. => ' || sql%rowcount);

	EXCEPTION
		WHEN OTHERS THEN

			DECLARE
				l_error varchar2(240) := sqlerrm;
			BEGIN

				UPDATE XX_WMS_INT_ASN_ORDERS XIA
				SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
				XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'Error al calcular la fecha de vencimiento: ' || l_error
				WHERE 1=1
				AND XIA.EXPIRY_DATE IS NULL
				AND XIA.REQUEST_ID = L_REQUEST_ID
				;

				debug(l_proc || 'Calcula expiry_date en base al nombre del lote error. => ' || sql%rowcount);

			EXCEPTION
				WHEN OTHERS THEN
					x_msg_data := 'Error al calcular el expiry_date en base al nombre del lote: ' || sqlerrm;
					RAISE e_error;
			END;
	END;
--*/

--/*
  -- Se controla que los lotes a cancelar no tengan transacciones de declaracion de produccion
  BEGIN

        UPDATE XX_WMS_INT_ASN_ORDERS XIA
        SET XIA.STATUS = 'ERROR', XIA.LAST_UPDATE_DATE = SYSDATE,
		XIA.ERROR_MESG = case when(xia.error_mesg is null)then '' else XIA.ERROR_MESG || '. ' end || 'El lote tiene transacciones de declaración de producción. No se puede cancelar.'
        WHERE EXISTS(
			select 1
			from
			 mtl_material_transactions mtt
			,mtl_transaction_lot_numbers mtln
			where 1=1
			and mtt.transaction_id = mtln.transaction_id
			and mtt.transaction_type_id = 44
			and mtt.transaction_source_id = XIA.BATCH_ID
			and mtln.lot_number = XIA.LOT_NUMBER
        )
		AND XIA.ACTION_CODE = 'DELETE'
        AND XIA.REQUEST_ID = l_request_id
        ;

		debug(l_proc || 'El lote tiene transacciones de declaración de producción => ' || sql%rowcount);

  EXCEPTION
    WHEN OTHERS THEN
      x_msg_data := 'Error al validar lote con transacciones de declaración de producción.: ' || sqlerrm;
      RAISE e_error;
  END;
--*/

  --
  BEGIN
    SELECT COUNT(1)
    INTO l_rows
    FROM XX_WMS_INT_ASN_ORDERS
    WHERE 1=1
    AND STATUS != 'ERROR'
    AND REQUEST_ID = l_request_id;

  EXCEPTION
    WHEN OTHERS THEN
        l_rows := 0;
  END;

  debug(l_proc || 'Registros a procesar => ' || l_rows);

  IF(l_rows > 0)THEN
    --
    -- Si hay novedades armo xml para mensaje de salida
    --
    -- ASN
    BEGIN

		select
			XMLELEMENT("LgfData",
				XMLELEMENT("Header",
					XMLELEMENT("DocumentVersion", '9.0.1'),
					XMLELEMENT("OriginSystem", 'Host'),
					XMLELEMENT("ClientEnvCode", l_request_id),
					XMLELEMENT("ParentCompanyCode", 'ADECO'),
					XMLELEMENT("Entity", 'ib_shipment'),
					XMLELEMENT("TimeStamp", to_char(sysdate,'YYYY-mm-dd hh24:mi:ss')),
					XMLELEMENT("MessageId", l_request_id)
				)
				,
				XMLELEMENT("ListOfIbShipments",
					(
						select XMLAGG(
							XMLELEMENT("ib_shipment",
								XMLELEMENT("ib_shipment_hdr",
									XMLFOREST(
										 hdr.batch_no ||'-'|| hdr.lot_number "shipment_nbr"
										,hdr.wms_org_code "facility_code"
										,'ADECO' "company_code"
										,hdr.action_code "action_code"
										,hdr.batch_no ||'-'|| hdr.lot_number "load_nbr"
										,hdr.plan_start_date "shipped_date"
										,hdr.lock_code "lock_code"
										,'PROD' "shipment_type"
									)
								)
								,
								--//DETALE
								(
									select XMLAGG(
										XMLELEMENT("ib_shipment_dtl",
											XMLFOREST(
												 dtl.line_no "seq_nbr"
												,dtl.action_code "action_code"
												,dtl.segment1 "item_alternate_code"
												,dtl.shipped_qty "shipped_qty"
												,dtl.expiry_date "expiry_date"
												--
												,dtl.expiry_date "priority_date"
												--
												,dtl.batch_no "cust_field_1"
												,dtl.lot_number "batch_nbr"
												,dtl.lpn_lock_code "lpn_lock_code"
												--,dtl.batch_no "invn_attr_c"
												,dtl.xx_opm_turno "invn_attr_d"
												,dtl.invn_attr_a "invn_attr_a"
											)
										)
									)
									from (
										select
										 line_no
										,action_code
										,segment1
										,sum(shipped_qty) shipped_qty
										,expiry_date
										,batch_no
										,lot_number
										,lpn_lock_code
										,xx_opm_turno
										,invn_attr_a
										from (
											select distinct
											 gmt.line_no
											,'CREATE' action_code
											,msi.segment1
											,inv_convert.inv_um_convert(
												msi.inventory_item_id,
												NULL,
												(sum_qty.quantity * flv_dfv.xx_exceso_op),
												gmt.dtl_um,
												mcr_dfv.xx_uom_wms,
												NULL,
												NULL
											) shipped_qty
											,to_char(xia.expiry_date + NVL(msi.shelf_life_days, 0), 'yyyy-mm-dd') expiry_date
											,gbh.batch_no
											,gppl.lot_number
											,'' lpn_lock_code
											,gbh_dfv.xx_opm_turno
											,(
												select description
												from fnd_lookup_values_vl
												where 1=1
												and lookup_type(+) = 'XX_ATRBUTO_ASN_WMS'
												and substr(lookup_code(+), 1, 3) = flv.lookup_code
												and meaning(+) = substr(gppl.lot_number, 1, 2)
											) invn_attr_a
											from
											 xx_wms_int_asn_orders xia
											,gme_batch_header gbh
											,gme_batch_header_dfv gbh_dfv
											,gme_material_details gmt
											,mtl_system_items msi
											,mtl_parameters mp
											,gme_pending_product_lots gppl
											,fnd_lookup_values_vl flv
											,fnd_lookup_values_dfv flv_dfv
											,mtl_cross_references mcr
											,mtl_cross_references_dfv mcr_dfv
											,(
												select sum(gppl.quantity) quantity, gppl.lot_number, gmd.inventory_item_id
												from
												 gme_pending_product_lots gppl
												,gme_material_details gmd
												where 1=1
												and gmd.material_detail_id = gppl.material_detail_id
												and gmd.batch_id = gppl.batch_id
												group by  gppl.lot_number, gmd.inventory_item_id
											) sum_qty
											where 1 = 1
											and xia.request_id = l_request_id
											and gbh.batch_id = xia.batch_id
											and gbh.rowid = gbh_dfv.row_id
											and gmt.material_detail_id = gppl.material_detail_id
											and gmt.material_detail_id = xia.material_detail_id
											and gppl.pending_product_lot_id = xia.pending_product_lot_id
											and msi.inventory_item_id = xia.inventory_item_id
											and msi.organization_id = xia.organization_id
											and msi.organization_id = mp.organization_id
											and flv.rowid = flv_dfv.row_id
											and flv.lookup_type = 'XX_MAPEO_EBS_WMS'
											and flv_dfv.xx_org_opm = mp.organization_code
											and mcr.inventory_item_id = msi.inventory_item_id
											and nvl(mcr.organization_id, msi.organization_id) = msi.organization_id
											and mcr.cross_reference_type = 'DUN14'
											and mcr.rowid = mcr_dfv.row_id
											and xia.status != 'ERROR'
											and xia.action_code != 'DELETE'
											--//
											and sum_qty.lot_number = xia.lot_number
											and sum_qty.inventory_item_id = xia.inventory_item_id
											--//
											--//RELACION CON HEADER-------------
											and gbh.batch_no = hdr.batch_no
											and gppl.lot_number = hdr.lot_number
											------------------------------------
										)
										group by
										 line_no
										,action_code
										,segment1
										,expiry_date
										,batch_no
										,lot_number
										,lpn_lock_code
										,xx_opm_turno
										,invn_attr_a
									) dtl
								)
								--//FIN DETALLE
							)
						)
						from (
							select distinct
							 gbh.batch_no
							,flv_map.meaning wms_org_code
							,'CREATE' action_code
							,gppl.lot_number
							,mat_status.description lock_code
							,gbh.plan_start_date
							from
							 xx_wms_int_asn_orders xia
							,gme_batch_header gbh
							,gme_pending_product_lots gppl
							,mtl_parameters mp
							,gme_material_details gmt
							,mtl_system_items msi
							,fnd_lookup_values_vl flv_map
							,fnd_lookup_values_dfv flv_map_dfv
							,(
								select flv.description, mms.status_id
								from
								 mtl_material_statuses_vl mms
								,fnd_lookup_values_vl flv
								where 1=1
								and flv.lookup_type like 'XX_MAPEO_ESTADOS_WMS'
								and flv.tag = mms.status_code
								and NVL(flv.enabled_flag,'N') = 'Y'
								and trunc(SYSDATE) between trunc(flv.start_date_active) and trunc(NVL(flv.end_date_active, SYSDATE))
								and mms.lot_control = 1
								and mms.enabled_flag = 1
							) mat_status
							where 1 = 1
							and mp.organization_id = xia.organization_id
							and gbh.batch_id = xia.batch_id
							and gppl.material_detail_id = xia.material_detail_id
							and gppl.material_detail_id = gmt.material_detail_id
							and gppl.pending_product_lot_id = xia.pending_product_lot_id
							and msi.inventory_item_id = gmt.inventory_item_id
							and msi.organization_id = xia.organization_id
							and mat_status.status_id(+) = msi.default_lot_status_id
							and xia.request_id = l_request_id
							and xia.status != 'ERROR'
							and xia.action_code != 'DELETE'
							and flv_map.rowid = flv_map_dfv.row_id
							and flv_map.lookup_type = 'XX_MAPEO_EBS_WMS'
							and flv_map_dfv.xx_org_opm = mp.organization_code
							union
							select distinct
							 gbh.batch_no
							,flv_map.meaning wms_org_code
							,'DELETE' action_code
							,xia.lot_number
							,mat_status.description lock_code
							,gbh.plan_start_date
							from
							 xx_wms_int_asn_orders xia
							,gme_batch_header gbh
							,mtl_parameters mp
							,gme_material_details gmt
							,mtl_system_items msi
							,fnd_lookup_values_vl flv_map
							,fnd_lookup_values_dfv flv_map_dfv
							,(
								select flv.description, mms.status_id
								from
								 mtl_material_statuses_vl mms
								,fnd_lookup_values_vl flv
								where 1=1
								and flv.lookup_type like 'XX_MAPEO_ESTADOS_WMS'
								and flv.tag = mms.status_code
								and NVL(flv.enabled_flag,'N') = 'Y'
								and trunc(SYSDATE) between trunc(flv.start_date_active) and trunc(NVL(flv.end_date_active, SYSDATE))
								and mms.lot_control = 1
								and mms.enabled_flag = 1
							) mat_status
							where 1 = 1
							and mp.organization_id = xia.organization_id
							and gbh.batch_id = xia.batch_id
							and xia.material_detail_id = gmt.material_detail_id
							and msi.inventory_item_id = gmt.inventory_item_id
							and msi.organization_id = xia.organization_id
							and mat_status.status_id(+) = msi.default_lot_status_id
							and xia.request_id = l_request_id
							and xia.status != 'ERROR'
							and xia.action_code = 'DELETE'
							and flv_map.rowid = flv_map_dfv.row_id
							and flv_map.lookup_type = 'XX_MAPEO_EBS_WMS'
							and flv_map_dfv.xx_org_opm = mp.organization_code
						) hdr
					)
				)
			)
		xmltext
		into l_xml
		from dual
		;

		x_xml_asn := l_xml.getClobVal();

		debug(l_proc || 'X_Xml_Asn Length => ' || DBMS_LOB.GETLENGTH(x_xml_asn));

    EXCEPTION
      WHEN OTHERS THEN
        x_msg_data := 'Error al armar x_xml_asn: ' || sqlerrm;
        RAISE e_error;
    END;

	--//NO ENVIAR APPOINTMENTS SI SOLO ESTA PROCESANDO CANCELACION DE LOTES.
	BEGIN
		SELECT COUNT(1)
		INTO l_rows
		FROM XX_WMS_INT_ASN_ORDERS
		WHERE 1=1
		AND STATUS != 'ERROR'
		AND ACTION_CODE != 'DELETE'
		AND REQUEST_ID = l_request_id;

	EXCEPTION
		WHEN OTHERS THEN
		l_rows := 0;
	END;

	debug(l_proc || 'Registros a procesar appointments => ' || l_rows);

	if(l_rows > 0)then

		-- Appointment
		BEGIN
		  SELECT --('<?xml version="1.0" encoding="utf-8"?> '||XMLCONCAT (
		  XMLELEMENT ("LgfData", XMLELEMENT ("Header",
									   XMLELEMENT ("DocumentVersion",
												   '9.0.1'
												  ),
									   XMLELEMENT ("OriginSystem",
												   'LGF'
												  ),
									   XMLELEMENT ("ClientEnvCode",
												   l_request_id --TEST
												  ),
									   XMLELEMENT ("ParentCompanyCode",
												   'ADECO'
												  ),
									   XMLELEMENT ("Entity",
												   'appointment'
												  ),
									   XMLELEMENT ("TimeStamp",
												   to_char(sysdate,'YYYY-mm-dd hh24:mi:ss')
												  ),
									   XMLELEMENT ("MessageId",
												   l_request_id
												  )
								   ),
						 XMLELEMENT ("ListOfAppointments",
				   (SELECT XMLAGG(
							 XMLELEMENT("appointment",
							   XMLFOREST(
								wms_org_code                                    AS "facility_code"
								,'ADECO'                                        AS "company_code"
								,batch_no ||'-'|| lot_number                    AS "appt_nbr"
								,batch_no ||'-'|| lot_number                    AS "load_nbr"
								--,'INBOUND'                                      AS "dock_type"
								,'ENT'                                          AS "dock_type"
								,action_code                                    AS "action_code"
								,''                                             AS "preferred_dock_nbr"
								,to_char(sysdate+ 1/(24*60),'YYYY-mm-dd hh24:mi:ss')  AS "planned_start_ts" --desfasado 1' hacia adelante
								,''                                             AS "duration"
								,''                                             AS "estimated_units"
								,carrier_info                                   AS "carrier_info"
								,''                                             AS "trailer_nbr"
								,''                                             AS "load_type"
							   )
							 )
						   )
					  FROM (SELECT gbh.batch_no
								  ,flv_map.meaning wms_org_code
								  --,xia.action_code
								  ,'CREATE' action_code
								  ,gppl.lot_number
								  ,(
									select substr(long_description, 1, 100)
									from mtl_system_items_tl
									where inventory_item_id = xia.inventory_item_id
									and organization_id = xia.organization_id
									and language = 'ESA'
								  ) carrier_info
							  FROM xx_wms_int_asn_orders xia
								  ,gme_batch_header gbh
								  ,mtl_parameters mp
								  ,fnd_lookup_values_vl flv_map
								  ,fnd_lookup_values_dfv flv_map_dfv
								  ,gme_pending_product_lots gppl
							 WHERE 1 = 1
							   AND mp.organization_id = xia.organization_id
							   AND gbh.batch_id = xia.batch_id
							   AND xia.request_id = l_request_id
							   AND gppl.material_detail_id = xia.material_detail_id
							   AND gppl.pending_product_lot_id = xia.pending_product_lot_id
							   AND xia.status != 'ERROR'
							   AND xia.action_code != 'DELETE'
							   AND flv_map.rowid = flv_map_dfv.row_id
							   AND flv_map.lookup_type = 'XX_MAPEO_EBS_WMS'
							   AND flv_map_dfv.xx_org_opm = mp.organization_code
							 ) a
				   ) "ListOfAppointments"
				  )
				)
				--)
				--)
			xmltext
		   INTO l_xml
		   FROM DUAL;

		 x_xml_appointment := l_xml.getClobVal();

		 debug(l_proc || 'X_Xml_Appointment Length => ' || DBMS_LOB.GETLENGTH(x_xml_appointment));

		EXCEPTION
		  WHEN OTHERS THEN
			x_msg_data := 'Error al armar x_xml_appointment: '||sqlerrm;
			RAISE e_error;
		END;

	ELSE
		--//NO SE GENERA XML DE APPOINTMENTS
		x_xml_appointment := '';
	END IF;

	x_return_status := 'S';
	x_request_id := l_request_id;

  ELSE
    x_return_status := 'X'; -- Indica que no se encontraron novedades
	x_request_id := l_request_id;
  END IF;

  debug(l_proc || 'End => ' || p_int_type || ' => ' || x_return_status);

EXCEPTION
  WHEN e_error THEN
    x_return_status := 'E';
	x_request_id := l_request_id;

	UPDATE XX_WMS_INT_ASN_ORDERS XIA
	SET XIA.STATUS = 'ERROR', XIA.ERROR_MESG = case when(XIA.ERROR_MESG is null)then '' else '. ' end || x_msg_data, XIA.LAST_UPDATE_DATE = SYSDATE
	WHERE XIA.STATUS = 'NEW'
	AND XIA.REQUEST_ID = l_request_id
	;

	debug(l_proc || x_msg_data);

  WHEN OTHERS THEN
    x_return_status := 'E';
	x_request_id := l_request_id;
    x_msg_data := 'Error: ' || sqlerrm;

	UPDATE XX_WMS_INT_ASN_ORDERS XIA
	SET XIA.STATUS = 'ERROR', XIA.ERROR_MESG = case when(XIA.ERROR_MESG is null)then '' else '. ' end || x_msg_data, XIA.LAST_UPDATE_DATE = SYSDATE
	WHERE XIA.STATUS = 'NEW'
	AND XIA.REQUEST_ID = l_request_id
	;

	debug(l_proc || x_msg_data);

END get_integration_data;

PROCEDURE update_response_integration
(p_int_type                  IN  VARCHAR2
,p_request_id                IN  NUMBER
,p_return_status             IN  VARCHAR2
,p_msg_data                  IN  VARCHAR2
)
AS
	l_proc varchar2(50) := 'update_response_integration: ';
BEGIN

	debug(l_proc || 'P_Int_Type => ' || p_int_type || ' P_Request_Id => ' || p_request_id || ' P_Return_Status => ' || p_return_status || ' P_Msg_Data => ' || p_msg_data);

  UPDATE xx_wms_int_asn_orders
     SET status            = decode(p_return_status,'True','OK','ERROR')
        ,error_mesg        = decode(p_return_status,'True','',p_msg_data)
        ,last_update_date  = sysdate
        ,last_updated_by   = fnd_global.user_id
   WHERE request_id = p_request_id
   AND status != 'ERROR';

   debug(l_proc || 'Update Xx_Wms_Int_Asn_Orders => ' || sql%rowcount);

END update_response_integration;

END xx_wms_int_out_asn_orders_pk;
/

exit
