  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_HANDLE_INVOICE_HOLDS_PKG" IS
--
PROCEDURE Validar_Trx_Importadas_Conc ( errbuf                   IN OUT NOCOPY  VARCHAR2
                                      , retcode                  IN OUT NOCOPY  VARCHAR2
                                      , p_invoice_id                            NUMBER
                                      , p_org_id                                NUMBER   DEFAULT NULL
                                      , p_acopio_nd_percepciones                VARCHAR2
                                      );
--
PROCEDURE Liberar_Holds ( p_invoice_id                  NUMBER
                        , p_org_id                      NUMBER   DEFAULT NULL
                        , p_acopio_nd_percepciones      VARCHAR2 DEFAULT 'N' /* Y / N */
                        , x_error_msg               OUT VARCHAR2
                        );
--
PROCEDURE Validar_Transacciones ( errbuf               IN OUT NOCOPY VARCHAR2
                                , retcode              IN OUT NOCOPY VARCHAR2
                                , p_option                           VARCHAR2 DEFAULT NULL-- LOOKUP_CODE FROM LOOKUP_TYPE='MATCHING TEST OPTION'  (All, New)
                                , p_batch_id                         NUMBER   DEFAULT NULL
                                , p_invoice_date_from                VARCHAR2 DEFAULT NULL
                                , p_invoice_date_to                  VARCHAR2 DEFAULT NULL
                                , p_vendor_id                        NUMBER   DEFAULT NULL
                                , p_pay_group                        VARCHAR2 DEFAULT NULL -- LOOKUP_CODE FROM LOOKUP_TYPE='PAY GROUP'
                                , p_invoice_id                       NUMBER   DEFAULT NULL
                                , p_entered_by                       NUMBER   DEFAULT NULL
                                , p_set_of_books                     NUMBER   DEFAULT NULL
                                , p_trace_option                     VARCHAR2 DEFAULT NULL
                                , p_org_id                           NUMBER   DEFAULT NULL
                                , p_commit_size                      NUMBER   DEFAULT NULL
                                );
--
END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_HANDLE_INVOICE_HOLDS_PKG" IS
--
  PROCEDURE ConcatenateErrrors( x_conc_errors   IN OUT  VARCHAR2
                              , x_errors        IN OUT  VARCHAR2
                              , p_error_type           VARCHAR2
                              , p_msg                  VARCHAR2
                              ) IS
  BEGIN
    IF p_error_type = 'ALL' THEN
      IF x_conc_errors IS NULL THEN
        x_conc_errors := p_msg;
      ELSE
        x_conc_errors := x_conc_errors||chr(10)||p_msg;
      END IF;
      x_errors := x_conc_errors;
    ELSIF p_error_type IS NULL THEN
      IF x_errors IS NULL THEN
        x_errors := p_msg;
      ELSE
        x_errors := x_errors||'. '||p_msg;
      END IF;
      x_conc_errors := x_errors;
    END IF;
  END;


  FUNCTION getHoldsInfo ( p_lookup_code           VARCHAR2
                        , x_hold_type         OUT VARCHAR2
                        , x_hold_desc         OUT VARCHAR2
                        , x_release_code      OUT VARCHAR2
                        ) RETURN BOOLEAN IS
    l_release_code  ap_holds_release_name_v.release_lookup_code%type;
  BEGIN
    SELECT attribute1 release_code
    INTO l_release_code
    FROM fnd_lookup_values_vl
    WHERE 1=1
    AND view_application_id = 200
    AND lookup_type  = 'HOLD CODE'
    AND enabled_flag = 'Y'
    AND lookup_code = p_lookup_code;

    SELECT hold_type
         , description
    INTO x_hold_type
       , x_hold_desc
    FROM ap_hold_codes_v
    WHERE UPPER(hold_lookup_code) = UPPER(p_lookup_code)
    ;

    SELECT release_lookup_code
    INTO x_release_code
    FROM ap_holds_release_name_v
    WHERE 1=1
    AND UPPER(release_lookup_code) = UPPER(l_release_code)
    ;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  FUNCTION getHoldStatus ( p_invoice_id    NUMBER
                         , p_hold_code     VARCHAR2
                         ) RETURN VARCHAR2 IS
    l_exists_hold  VARCHAR2(1);
  BEGIN
    SELECT DISTINCT 'Y'
    INTO l_exists_hold
    FROM ap_holds_all
    WHERE 1=1
    AND invoice_id       = p_invoice_id
    AND hold_lookup_code = p_hold_code
    AND release_lookup_code IS NULL;

    RETURN l_exists_hold;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 'N';
  END;


  PROCEDURE Holds_Handler ( p_invoice_id             NUMBER
                          , p_hold_code              VARCHAR2
                          , p_hold_required          VARCHAR2
                          , p_exists_hold            VARCHAR2
                          , p_custom_desc            VARCHAR2 DEFAULT NULL
                          , x_error_msg          OUT VARCHAR2
                          ) IS
    l_hold_type         ap_hold_codes_v.hold_type%type;
    l_hold_desc         ap_hold_codes_v.description%type;
    l_release_code      ap_holds_release_name_v.release_lookup_code%type;
    l_error_msg         VARCHAR2(3200);
  BEGIN
    IF NOT getHoldsInfo ( p_lookup_code       => p_hold_code
                        , x_hold_type         => l_hold_type
                        , x_hold_desc         => l_hold_desc
                        , x_release_code      => l_release_code
                        ) THEN
      l_error_msg := 'No fue posible validar los holds a aplicar a la factura ID: '||p_invoice_id||', Hold Code: '||p_hold_code;

      ConcatenateErrrors( x_conc_errors  => x_error_msg
                        , x_errors       => x_error_msg
                        , p_error_type   => NULL
                        , p_msg          => l_error_msg
                        );

      RETURN;
    END IF;

    IF p_hold_required = 'Y' AND
       p_exists_hold   = 'N' THEN
      FND_FILE.put_line(FND_FILE.OUTPUT, 'Creando HOLD "'||p_hold_code||'.');
      AP_HOLDS_PKG.Insert_Single_Hold( x_invoice_id       => p_invoice_id
                                     , x_hold_lookup_code => p_hold_code
                                     , x_hold_type        => l_hold_type
                                     , x_hold_reason      => NVL(p_custom_desc, l_hold_desc)
                                     , x_held_by          => 5
                                     );
    --
    ELSIF p_hold_required = 'N' AND
          p_exists_hold   = 'Y' THEN
      FND_FILE.put_line(FND_FILE.OUTPUT, 'Liberando HOLD "'||p_hold_code||'.');
      XX_AP_UTIL_PKG.Release_Single_Hold ( p_invoice_id          => p_invoice_id
                                         , p_hold_lookup_code    => p_hold_code
                                         , p_release_lookup_code => l_release_code
                                         , p_held_by             => 5
                                         , p_released_by         => 5
                                         );
    --
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      l_error_msg := 'Error manejando holds para la factura ID: '||p_invoice_id||', Hold Code: '||p_hold_code||'.'||SQLERRM;
      x_error_msg := l_error_msg;
      ConcatenateErrrors( x_conc_errors  => x_error_msg
                        , x_errors       => x_error_msg
                        , p_error_type   => NULL
                        , p_msg          => l_error_msg
                        );
  END;


  --Sequence: 24 - XX AP Copia Datos Comprobante Distribuciones
  FUNCTION Copia_Datos_Cbte_Distrib ( p_invoice_id       NUMBER
                                    , x_error_msg    OUT VARCHAR2
                                    ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y'
      INTO l_hold_required
      FROM ap_invoices_v  ai
      WHERE 1=1
      AND ai.invoice_id  = p_invoice_id
      AND ai.attribute1  = 'Y'
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    IF l_hold_required = 'Y' THEN
      BEGIN
        XX_AP_FACTURAS_PERSONALIZ_PKG.completar_datos_ff_imp_p(p_invoice_id);
      EXCEPTION
        WHEN OTHERS THEN
          x_error_msg := SQLERRM;
      END;
    END IF;

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      x_error_msg := SQLERRM;
      RETURN FALSE;
  END;


  --Sequence: 25 - XX AP Validaci�n Datos Comprobante Distribuciones
  FUNCTION Hold_Datos_Cbte_Dist ( p_invoice_id       NUMBER
                                , x_error_msg    OUT VARCHAR2
                                ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error Lineas s/Imp';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'Existe al menos una l�a de art�lo sin l�a de impuesto vinculada o no coinciden los datos de los comprobantes ingresados en la distribuci�n para una o m�l�as vinculadas.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v ai
      WHERE 1=1
      AND ai.invoice_id  = p_invoice_id
      AND ai.attribute1  = 'Y'
      AND XX_AP_FACTURAS_PERSONALIZ_PKG.validacion_datos_comprobante_f(ai.invoice_id) = 'Y'
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence: 26 - XX AP Validaci�n L�neas Vinculadas
  FUNCTION Hold_Lineas_Vinculadas ( p_invoice_id       NUMBER
                                  , x_error_msg    OUT VARCHAR2
                                  ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error Lineas Vinculadas';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'El c�digo de impuesto de las l�as de tipo impuesto no coincide con el c�digo de impuesto de las l�as de tipo art�lo vinculadas.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v              ai
         , ap_invoice_distributions_v aid
      WHERE 1=1
      AND aid.invoice_id = ai.invoice_id
      AND ai.invoice_id  = p_invoice_id
      AND ai.attribute1  = 'Y'
      AND XX_AP_FACTURAS_PERSONALIZ_PKG.validacion_lineas_vinculadas_f(ai.invoice_id) = 'Y'
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence: 27 - XX AP Validaci�n Distribuciones Hold - Crea
  FUNCTION Hold_Valida_Distribucion ( p_invoice_id       NUMBER
                                    , x_error_msg    OUT VARCHAR2
                                    ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_code            VARCHAR2(50) := 'Lineas de Art s/Cod Imp';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y'
      INTO l_hold_required
      FROM ap_invoices_v  ai
      WHERE 1=1
      AND ai.invoice_id = p_invoice_id
      AND XX_AP_FACTURAS_PERSONALIZ_PKG.valida_distrib_hold_f('Y', ai.invoice_id) = 'Y'
      /*AND ( SELECT COUNT(1)
            FROM ap_holds_all
            WHERE 1=1
            AND invoice_id       = ai.invoice_id
            AND hold_lookup_code = l_hold_code
            AND release_lookup_code IS NULL
          ) = 0*/
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => NULL
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence: 29 - XX AP Validaci�n Distribuciones NO FONDO FIJO
  FUNCTION Hold_Distrib_NOFF ( p_invoice_id       NUMBER
                             , x_error_msg    OUT VARCHAR2
                             ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error Lineas Imp';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'No existe ninguna l�a de art�lo, o alguna l�a de art�lo posee un c�digo de impuesto que no se ve reflejado en las l�as de impuestos.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v  ai
      WHERE 1=1
      AND ai.invoice_id = p_invoice_id
      AND NVL(ai.attribute1,'N') != 'Y'
      AND XX_AP_FACTURAS_PERSONALIZ_PKG.valida_distrib_nff_f('Y',ai.invoice_id) = 'Y'
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence: 35 - XX AP Validaci�n Distribuciones NO FONDO FIJO - Montos
  FUNCTION Hold_ValidaDist_No_FF_Montos ( p_invoice_id       NUMBER
                                        , x_error_msg    OUT VARCHAR2
                                        ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error Lineas de Art s/Imp';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'El importe de IVA no coincide con el c�ulo del impuesto seg�n la base y tasa de IVA definidas.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v  ai
      WHERE 1=1
      AND ai.invoice_id = p_invoice_id
      AND NVL(ai.attribute1,'N') != 'Y'
      AND XX_AP_FACTURAS_PERSONALIZ_PKG.valida_distrib_nff_montos_f('Y', ai.invoice_id) = 'Y'
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence: 80 - XX AP Validar Impuesto - iva 0%
  FUNCTION Hold_Impuesto_IVA0 ( p_invoice_id       NUMBER
                              , x_error_msg    OUT VARCHAR2
                              ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error Impuesto IVA 0%';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold REVISAR!!!!
    BEGIN
      SELECT DISTINCT 'Y', 'No es v�da la combinaci�n de l�as de tipo art�lo distinto de 0 (cero), cuando el c�digo de Impuesto SIRCREB.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v                ai
         , ap_invoice_distributions_all aid  --ap_invoice_distributions_v aid  --Upgrade R12 - Luiz Chacon - 22.Sep.2017
      WHERE 1=1
      AND aid.invoice_id = ai.invoice_id
      AND ai.invoice_id  = p_invoice_id

      AND aid.line_type_lookup_code = 'TAX'
      AND aid.vat_code   = 'SIRCREB'
      AND aid.amount    != 0
      AND NVL(aid.reversal_flag,'N') = 'N'
      AND TO_DATE(TO_CHAR(NVL(aid.last_update_date,SYSDATE),'DD-MM-YYYY'),'DD-MM-YYYY') > TO_DATE('31-08-2015','DD-MM-YYYY')
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence: 88 - XX AP Control Mantenimiento Vehiculos con OC Asociada en Validacion FC
  FUNCTION Hold_Ctrl_Mant_Vehiculo_OC_FC ( p_invoice_id       NUMBER
                                         , x_error_msg    OUT VARCHAR2
                                         ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error Ctrl Mant Veh OC FC';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'Esta utilizando las cuentas 572006 / 543006, por favor ingrese Patente y Km del vehiculo en el Flexfield de Distribuci�n de Facturas.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v              ai
      WHERE 1=1
      AND ai.invoice_id  = p_invoice_id
      AND ( SELECT count(h.segment1)
            FROM ap_invoices_all              i,
                 po_headers_all               h,
                 ap_invoice_distributions_all ida,
                 po_distributions_all         d
            WHERE 1=1
            AND i.invoice_id   = ai.invoice_id
            AND ida.invoice_id = ai.invoice_id
            AND i.invoice_id   = ida.invoice_id + 0
            AND d.po_distribution_id = ida.po_distribution_id + 0
            AND h.po_header_id = d.po_header_id + 0
            AND h.segment1 IS NOT NULL
            AND 'N' = nvl(ida.reversal_flag, 'N')
          ) <> 0
      AND 'INCORRECTO' IN ( SELECT DISTINCT DECODE( ida_dfv.xx_ap_patente_vehiculo
                                                  , NULL, 'INCORRECTO'
                                                  , DECODE( ida_dfv.xx_ap_km_vehiculo
                                                          , NULL, 'INCORRECTO', 'CORRECTO'
                                                          )
                                                  ) estado
                            FROM ap_invoices_all                 i,
                                 ap_invoice_distributions_all    ida,
                                 ap_invoice_distributions_a_dfv  ida_dfv,
                                 po_distributions_all            d,
                                 po_headers_all                  h,
                                 gl_code_combinations            cc
                            WHERE 1=1
                            AND i.invoice_id   = ai.invoice_id
                            AND ida.invoice_id = ai.invoice_id
                            AND i.invoice_id           = ida.invoice_id + 0
                            AND ida_dfv.row_id         = ida.rowid
                            AND d.po_distribution_id   = ida.po_distribution_id + 0
                            AND cc.code_combination_id = d.code_combination_id + 0
                            AND h.po_header_id = d.po_header_id + 0
                            AND ida.amount      > 0
                            AND NVL(ida.reversal_flag, 'N') = 'N'
                            AND ida_dfv.context = 'AR'
                            AND h.segment1 IS NOT NULL
                            AND (cc.segment2 IN ('572006', '543006')
                          ) )
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence 93: XX_AP_Crear_Hold_Provision_Flete
  FUNCTION Hold_Provision_Flete ( p_invoice_id       NUMBER
                                , x_error_msg    OUT VARCHAR2
                                ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_code            VARCHAR2(50) := 'Retencion Flete';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold  REVISAR!!!!
    BEGIN
      SELECT DISTINCT 'Y'
      INTO l_hold_required
      FROM ap_invoices_v ai
      WHERE 1=1
      AND ai.invoice_id = p_invoice_id
      AND ( SELECT COUNT(1)
            FROM ap_invoice_distributions_v
            WHERE 1=1
            AND invoice_id = ai.invoice_id
            AND line_type_lookup_code = 'FREIGHT'
          ) > 0
      AND ( SELECT SUM(amount)
            FROM ap_invoice_distributions_v
            WHERE 1=1
            AND invoice_id = ai.invoice_id
            AND line_type_lookup_code = 'ITEM'
          ) > 300
      AND ( SELECT COUNT(1)
            FROM ap_holds_all
            WHERE 1=1
            AND invoice_id       = ai.invoice_id
            AND hold_lookup_code = l_hold_code
            AND release_lookup_code IS NOT NULL
          ) = 0
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => NULL
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;




  --Sequence 98 - XX AP Validar que CP no este en mas de una linea de flete de una misma factura - al entrar
  FUNCTION Hold_Asigna_CP_Flete ( p_invoice_id       NUMBER
                                , x_error_msg    OUT VARCHAR2
                                ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error asignacion CP';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'No existe ninguna l�a de art�lo, o alguna l�a de art�lo posee un c�digo de impuesto que no se ve reflejado en las l�as de impuestos.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v  ai
      WHERE 1=1
      AND ai.invoice_id = p_invoice_id
      AND EXISTS ( SELECT attribute10
                   FROM ap_invoice_distributions
                   WHERE 1=1
                   AND invoice_id = ai.invoice_id
                   AND NVL(reversal_flag,'N') <> 'Y'
                   AND attribute10 IS NOT NULL
                   GROUP BY attribute10
                   HAVING count(*) > 1
                 )
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --Sequence 100 - XX AP Validar que CP no est� en m�s de una l�nea de flete de una misma factura
  FUNCTION Hold_Asigna_CP_Flete_Mult ( p_invoice_id       NUMBER
                                     , x_error_msg    OUT VARCHAR2
                                     ) RETURN BOOLEAN IS
    l_error_msg            VARCHAR2(3200);
    l_hold_msg             VARCHAR2(240);
    l_hold_code            VARCHAR2(50) := 'Error asignacion CP Mult';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
  BEGIN
    -- Condici�n Hold
    BEGIN
      SELECT DISTINCT 'Y', 'No se puede asignar una carta de porte m�de una vez en una l�a de flete de la misma factura. Por favor ingresar de nuevo la carta de porte.'
      INTO l_hold_required, l_hold_msg
      FROM ap_invoices_v              ai
         , ap_invoice_distributions_v aid
      WHERE 1=1
      AND aid.invoice_id = ai.invoice_id
      AND ai.invoice_id  = p_invoice_id
      AND aid.line_type_lookup_code = 'FREIGHT'
      AND ( SELECT COUNT(*)
            FROM ap_invoice_distributions
            WHERE 1=1
            AND invoice_id  = ai.invoice_id
            AND attribute10 = TO_CHAR(aid.attribute10)
            AND NVL(reversal_flag,'N') <> 'Y'
          ) > 1
      ;
    --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_hold_required := 'N';
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_hold_msg,1,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --
  --Valida Direcci�n de Env�o en l�neas de distribuci�n
  --
  FUNCTION Hold_DirEnvio_Distribucion ( p_invoice_id       NUMBER
                                      , x_error_msg    OUT VARCHAR2
                                      ) RETURN BOOLEAN IS
    CURSOR cDis IS
      SELECT org_id, invoice_id, invoice_distribution_id, line_type_lookup_code, global_attribute_category, global_attribute3
      FROM ap_invoice_distributions_v
      WHERE 1=1
      AND line_type_lookup_code IN ('ITEM', 'TAX', 'FREIGHT', 'MISCELLANEOUS')
      AND invoice_id = p_invoice_id;

    l_error_msg             VARCHAR2(3200);
    l_hold_code             VARCHAR2(50) := 'Error Linas s/Dir Env';
    l_hold_required         VARCHAR2(1);
    l_exists_hold           VARCHAR2(1);
    --
    l_ship_to_loc           VARCHAR2(150);
    l_cont_ship_to_loc      NUMBER;
    l_cont_ship_to_loc_null NUMBER;
  BEGIN
    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    -- Condici�n Hold
    BEGIN
      l_cont_ship_to_loc_null := 0;
      l_cont_ship_to_loc      := 0;
      l_ship_to_loc           := NULL;

      FOR rDis IN cDis LOOP
        IF rDis.global_attribute3 IS NOT NULL THEN
          IF l_ship_to_loc IS NULL OR
             l_ship_to_loc != rDis.global_attribute3 THEN
            l_ship_to_loc := rDis.global_attribute3;
            l_cont_ship_to_loc := l_cont_ship_to_loc + 1;
          END IF;
          --
        ELSE
          l_cont_ship_to_loc_null := l_cont_ship_to_loc_null + 1;
        END IF;
      --
      END LOOP;

      -- Existe mas de una direccion y existen lineas sin direccion
      IF l_cont_ship_to_loc > 1      AND
         l_cont_ship_to_loc_null > 0 THEN

        l_hold_required := 'Y';

      ELSIF l_cont_ship_to_loc = 1   AND
         l_cont_ship_to_loc_null > 0 THEN

        FOR rDis IN cDis LOOP
          IF rDis.global_attribute3 IS NULL THEN
            UPDATE ap_invoice_distributions_all
            SET global_attribute_category = 'JL.AR.APXINWKB.DISTRIBUTIONS'
              , global_attribute3 = l_ship_to_loc
            WHERE invoice_id = rDis.invoice_id
            AND invoice_distribution_id = rDis.invoice_distribution_id
            AND org_id       = rDis.org_id;
          END IF;
          --
        END LOOP;

        l_hold_required := 'N';
        --
      ELSE -- Evaluo quitar hold
        l_hold_required := 'N';
      --
      END IF;
    --
    EXCEPTION
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => NULL
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --
  --Valida Direccion Invalida Ingresada
  --
  FUNCTION Hold_Direccion_invalida ( p_invoice_id       NUMBER
                                   , x_error_msg    OUT VARCHAR2
                                   ) RETURN BOOLEAN IS

    l_error_msg             VARCHAR2(3200);
    l_hold_code             VARCHAR2(50) := 'Direccion Invalida Ingres';
    l_hold_required         VARCHAR2(1);
    l_exists_hold           VARCHAR2(1);
    --
    l_amount                NUMBER;
  BEGIN
    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    -- Condici�n Hold
    BEGIN
      SELECT SUM(aid.amount)
      INTO l_amount
      FROM ap_invoice_distributions_all aid
         , hr_locations_all             hrl
         , hr_locations_all1_dfv        hrl_dfv
      WHERE 1=1
      AND hrl.location_id = aid.global_attribute3
      AND hrl_dfv.row_id  = hrl.rowid
      AND hrl_dfv.context_value = hrl.attribute_category
      AND hrl_dfv.xx_direccion_empresa = 'Y'
      AND aid.invoice_id = p_invoice_id;

      IF l_amount != 0 THEN
        l_hold_required := 'Y';
      ELSE -- Evaluo quitar hold
        l_hold_required := 'N';
      --
      END IF;
    --
    EXCEPTION
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => NULL
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;


  --WSCDC XX AP Constataci�n de Comprobantes
  FUNCTION Hold_AFIP_WSCDC ( p_invoice_id       NUMBER
                           , x_error_msg    OUT VARCHAR2
                           ) RETURN BOOLEAN IS
    CURSOR cCbtes IS
      SELECT 'CAE' tipo_cbte FROM DUAL
      UNION
      SELECT 'CAEA' tipo_cbte FROM DUAL
      UNION
      SELECT 'CAI' tipo_cbte FROM DUAL
      ;

    l_error_msg            VARCHAR2(3200);
    l_hold_code            VARCHAR2(50) := 'Error Validacion AFIP';
    l_hold_required        VARCHAR2(1);
    l_exists_hold          VARCHAR2(1);
    l_cbte_modo            VARCHAR2(50);
    l_cuit_emisor          NUMBER;
    l_cbte_tipo            NUMBER;
    l_punto_venta          NUMBER;
    l_cbte_nro             NUMBER;
    l_cbte_importe         NUMBER;
    l_cbte_fecha           NUMBER;
    l_cod_autorizacion     NUMBER;
    l_cuit_representado    NUMBER;
    l_tipo_doc_receptor    NUMBER;
    l_response             XX_WSCDC_COMPROBANTES_RESP;
    l_result               BOOLEAN;
  BEGIN
    IF NVL(FND_PROFILE.Value('XX_WSAFIP_WSCDC_ENABLE'),'N') = 'N' THEN
      l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

      IF l_exists_hold = 'Y' THEN
        Holds_Handler( p_invoice_id        => p_invoice_id
                     , p_hold_code         => l_hold_code
                     , p_hold_required     => 'N'
                     , p_exists_hold       => l_exists_hold
                     , p_custom_desc       => SUBSTR(l_error_msg,3,240)
                     , x_error_msg         => x_error_msg
                     );
      END IF;

      IF x_error_msg IS NULL THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;

    END IF;

    -- Condici�n Hold
    BEGIN
      SELECT ai.global_attribute8                                  comprobante_modo
           , v.num_1099||v.global_attribute12                      cuit_emisor
           , ai.global_attribute13                                 comprobante_tipo
           , SUBSTR(ai.invoice_num,1,INSTR(ai.invoice_num, '-')-1) punto_venta
           , SUBSTR(ai.invoice_num,INSTR(ai.invoice_num, '-')+1,8) comprobante_nro
           , ai.invoice_amount                                     comprobante_importe
           , TO_CHAR(ai.invoice_date, 'YYYYMMDD')                  comprobante_fecha
           , ai.global_attribute19                                 cod_autorizacion
           , v1.cuit_representado
           , v1.tipo_doc_receptor
      INTO l_cbte_modo
         , l_cuit_emisor
         , l_cbte_tipo
         , l_punto_venta
         , l_cbte_nro
         , l_cbte_importe
         , l_cbte_fecha
         , l_cod_autorizacion
         , l_cuit_representado
         , l_tipo_doc_receptor
      FROM ap_invoices_v  ai
         , ap_suppliers   v                  --po_vendors  v   --Upgrade R12 - Luiz Chacon - 21.Sep.2017
         , ( SELECT DISTINCT ou.organization_id org_id, v.num_1099||v.global_attribute12 cuit_representado, v.global_attribute10 tipo_doc_receptor
             FROM hr_organization_units ou
                , hr_locations          l
                , ap_suppliers          v    --po_vendors  v   --Upgrade R12 - Luiz Chacon - 21.Sep.2017
             WHERE 1=1
             AND l.location_id      = ou.location_id
             AND v.num_1099||v.global_attribute12 = l.global_attribute11||l.global_attribute12
             AND ou.name         LIKE 'AR %'
           ) v1
      WHERE 1=1
      AND v.vendor_id   = ai.vendor_id
      AND v1.org_id     = ai.org_id
      AND ai.invoice_id = p_invoice_id
      ;
    --
    EXCEPTION
      WHEN OTHERS THEN
        l_error_msg := 'Error evaluando condici�n para la factura ID: '||p_invoice_id||'.'||SQLERRM;

        ConcatenateErrrors( x_conc_errors  => x_error_msg
                          , x_errors       => x_error_msg
                          , p_error_type   => NULL
                          , p_msg          => l_error_msg
                          );
        RETURN FALSE;
    END;

    FOR rCbtes IN cCbtes LOOP
      XX_AP_WSCDC_PUB.ComprobanteConstatar ( p_cuit_representado    => l_cuit_representado
                                           --
                                           , p_comprobante_modo     => rCbtes.tipo_cbte
                                           , p_cuit_emisor          => l_cuit_emisor
                                           , p_comprobante_tipo     => l_cbte_tipo
                                           , p_punto_venta          => l_punto_venta
                                           , p_comprobante_numero   => l_cbte_nro
                                           , p_comprobante_fecha    => l_cbte_fecha
                                           , p_importe_total        => l_cbte_importe
                                           --, p_opcionales           IN XX_WSCDC_OPCIONAL_TBL DEFAULT NULL
                                           , p_codigo_autorizacion  => l_cod_autorizacion
                                           , p_doc_tipo_receptor    => l_tipo_doc_receptor
                                           , p_doc_nro_receptor     => l_cuit_representado
                                           --
                                           , x_response_object      => l_response
                                           , x_result               => l_result
                                           , x_error_message        => l_error_msg
                                           );

      IF (l_response.errores IS NOT NULL AND l_response.errores.COUNT > 0) THEN
        FOR l_index IN 1 .. l_response.errores.COUNT LOOP
          l_error_msg := l_error_msg ||'. '||l_response.errores(l_index).msg;
        END LOOP;
      END IF;

      IF (l_response.eventos IS NOT NULL AND l_response.eventos.COUNT > 0) THEN
        FOR l_index IN 1 .. l_response.eventos.COUNT LOOP
          l_error_msg := l_error_msg ||'. '||l_response.eventos(l_index).msg;
        END LOOP;
      END IF;

      IF (l_response.observaciones IS NOT NULL AND l_response.observaciones.COUNT > 0) THEN
        FOR l_index IN 1 .. l_response.observaciones.COUNT LOOP
          l_error_msg := l_error_msg ||'. '||l_response.observaciones(l_index).msg;
        END LOOP;
      END IF;

      l_exists_hold := getHoldStatus (p_invoice_id, l_hold_code);

      IF l_response.respuesta = 'A' THEN --A=Aprobado, R=Rechazado
        l_hold_required := 'N';
        EXIT;
      ELSE
        l_hold_required := 'Y';
      END IF;
    END LOOP;

    Holds_Handler( p_invoice_id        => p_invoice_id
                 , p_hold_code         => l_hold_code
                 , p_hold_required     => l_hold_required
                 , p_exists_hold       => l_exists_hold
                 , p_custom_desc       => SUBSTR(l_error_msg,3,240)
                 , x_error_msg         => x_error_msg
                 );

    IF x_error_msg IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  --
  EXCEPTION
    WHEN Others THEN
      ConcatenateErrrors( x_conc_errors  => x_error_msg
                        , x_errors       => x_error_msg
                        , p_error_type   => NULL
                        , p_msg          => SQLERRM
                        );
      RETURN FALSE;
    --
  END;


  PROCEDURE Validar_Trx_Importadas_Conc ( errbuf                   IN OUT NOCOPY  VARCHAR2
                                        , retcode                  IN OUT NOCOPY  VARCHAR2
                                        , p_invoice_id                            NUMBER
                                        , p_org_id                                NUMBER   DEFAULT NULL
                                        , p_acopio_nd_percepciones                VARCHAR2
                                        ) IS
    CURSOR cInv IS

      SELECT DISTINCT
             ai.org_id, ai.invoice_id, ai.invoice_num
           , XX_AP_UTIL_PKG.Get_Approval_Status ( ai.invoice_id
                                                , ai.invoice_amount
                                                , ai.payment_status_flag
                                                , ai.invoice_type_lookup_code
                                                , ai.org_id
                                                ) approval_status
      FROM fnd_lookup_values_vl         lv
         , ap_invoices_all              ai
         /*Modificado KHRONUS/E.Sly 20191021 En comprobantes de PERCEPCIONES no se crean distribuciones*/
         --, ap_invoice_distributions_all aid
         ,ap_invoice_lines_all aid
         /*FIn Modificado KHRONUS/E.Sly 20191021 En comprobantes de PERCEPCIONES no se crean distribuciones*/
         , gl_period_statuses           glps
      WHERE 1=1
      AND lv.lookup_code = ai.source
      AND aid.invoice_id = ai.invoice_id
      AND glps.set_of_books_id = ai.set_of_books_id
      AND lv.lookup_type = 'SOURCE'
      AND aid.accounting_date BETWEEN glps.start_date AND glps.end_date
      AND glps.application_id  = 200
      AND glps.closing_status  IN ('O', 'F')
      AND NVL (glps.adjustment_period_flag, 'N') = 'N'
      AND (p_invoice_id IS NULL OR              -- Modificado CR2579
           p_invoice_id = ai.invoice_id)
      AND ( p_org_id IS NULL OR
            p_org_id = ai.org_id
          )
      AND ( p_acopio_nd_percepciones IS NULL OR
            p_acopio_nd_percepciones = lv.attribute1
          )
      ORDER BY ai.org_id, ai.invoice_id
      ;

    l_error_msg            VARCHAR2(3200);
    l_ret_code             NUMBER;
    l_report_holds_count   NUMBER;
    eNextRec               EXCEPTION;
    eValida                EXCEPTION;
  BEGIN
    FND_FILE.put_line(FND_FILE.LOG, 'Inicio Validar_Trx_Importadas_Conc');
    FND_FILE.new_line(FND_FILE.LOG, 1);
    FND_FILE.put_line(FND_FILE.LOG, 'Par�tros:');
    FND_FILE.put_line(FND_FILE.LOG, 'p_invoice_id: '||p_invoice_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_org_id: '||p_org_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_acopio_nd_percepciones: '||p_acopio_nd_percepciones);


    FOR rInv IN cInv LOOP
      l_error_msg := NULL;

      --dbms_application_info.set_client_info(rInv.org_id);
      FND_FILE.put_line(FND_FILE.LOG, 'Invoice_id: '||rInv.invoice_id);

      BEGIN
        IF rInv.approval_status NOT IN ('NEEDS REAPPROVAL', 'NEVER APPROVED', 'UNAPPROVED') THEN
          FND_FILE.put_line(FND_FILE.LOG, 'Estado de factura no procesable: '||rInv.approval_status);
          RAISE eNextRec;
        END IF;

        SAVEPOINT BeginValidation;

        FND_FILE.New_Line(FND_FILE.LOG, 1);
        FND_FILE.put_line(FND_FILE.LOG, 'Procesando factura '||rInv.invoice_num||' en la organizaci�n '||rInv.org_id||chr(10));
        FND_FILE.put_line(FND_FILE.LOG, 'Calling Batch_Approval');
        FND_FILE.New_Line(FND_FILE.LOG, 1);

        IF NOT AP_APPROVAL_PKG.Batch_Approval ( p_run_option         => 'ALL'
                                              , p_sob_id             => NULL
                                              , p_inv_start_date     => NULL
                                              , p_inv_end_date       => NULL
                                              , p_inv_batch_id       => NULL
                                              , p_vendor_id          => NULL
                                              , p_pay_group          => NULL
                                              , p_invoice_id         => rInv.invoice_id
                                              , p_entered_by         => NULL
                                              , p_debug_switch       => 'Y'
                                              , p_conc_request_id    => FND_GLOBAL.CONC_REQUEST_ID
                                              , p_commit_size        => NULL
                                              , p_org_id             => rInv.org_id   --Upgrade R12 - Luiz Chacon - 25.SEP.2017
                                              , p_report_holds_count => l_report_holds_count
                                              ) THEN

          l_error_msg := 'Error validando la factura '||rInv.invoice_num;
          RAISE eValida;
        END IF;

        FND_FILE.New_Line(FND_FILE.LOG, 1);
        FND_FILE.put_line(FND_FILE.LOG, 'Ending Batch_Approval.');

        IF l_error_msg IS NULL THEN
          FND_FILE.New_Line(FND_FILE.LOG, 1);
          FND_FILE.put_line(FND_FILE.LOG, 'Calling Validar_Transacciones');

          Validar_Transacciones ( errbuf       => l_error_msg
                                , retcode      => l_ret_code
                                , p_invoice_id => rInv.invoice_id
                                );

          FND_FILE.New_Line(FND_FILE.LOG, 1);
          FND_FILE.put_line(FND_FILE.LOG, 'Ending Validar_Transacciones.');
          IF l_error_msg IS NOT NULL THEN
            l_error_msg := 'Error creando holds customs en la factura '||rInv.invoice_num||'. '||l_error_msg;
            RAISE eValida;
          END IF;
        END IF;

        IF l_error_msg IS NULL THEN
          FND_FILE.New_Line(FND_FILE.LOG, 1);
          FND_FILE.put_line(FND_FILE.LOG, 'Calling Liberar_Holds');

          Liberar_Holds ( --p_invoice_id              => p_invoice_id    Modificado CR2579
                          p_invoice_id              => rInv.invoice_id
                        , p_org_id                  => p_org_id
                        , p_acopio_nd_percepciones  => p_acopio_nd_percepciones
                        , x_error_msg               => l_error_msg
                        );

          FND_FILE.New_Line(FND_FILE.LOG, 1);
          FND_FILE.put_line(FND_FILE.LOG, 'Ending Liberar_Holds '||l_error_msg);
          IF l_error_msg IS NOT NULL THEN
            l_error_msg := 'Error liberando holds en la factura '||rInv.invoice_num||'. '||l_error_msg;
            RAISE eValida;
          END IF;
        END IF;

        COMMIT;
      EXCEPTION
        WHEN eNextRec THEN
          NULL;
        WHEN eValida THEN
          FND_FILE.New_Line(FND_FILE.LOG, 1);
          FND_FILE.put_line(FND_FILE.LOG, l_error_msg);
          ROLLBACK TO BeginValidation;
          retcode := 1;
      END;
    END LOOP;
  END;


  PROCEDURE Liberar_Holds ( p_invoice_id                  NUMBER
                          , p_org_id                      NUMBER   DEFAULT NULL
                          , p_acopio_nd_percepciones      VARCHAR2 DEFAULT 'N' /* Y / N */
                          , x_error_msg               OUT VARCHAR2
                          ) IS
    CURSOR cHolds IS
      SELECT ah.*
      FROM ap_holds_all ah
      WHERE 1=1
      AND ah.held_by = 5
      AND ah.release_lookup_code IS NULL
      AND ( ( p_acopio_nd_percepciones = 'Y' AND
              ah.org_id = p_org_id AND
              -- Modificado CR2579
              ah.invoice_id = p_invoice_id AND
              --
              ah.hold_lookup_code IN ('PO REQUIRED', 'TAX VARIANCE', 'TAX AMOUNT RANGE') AND
              EXISTS ( SELECT 1
                        FROM fnd_lookup_values_vl lv
                           , ap_invoices_all      ai
                        WHERE 1=1
                        AND ai.invoice_id  = ah.invoice_id
                        AND lv.lookup_code = ai.source
                        AND lv.lookup_type = 'SOURCE'
                        AND lv.attribute1  = 'Y'
                        AND XX_AP_UTIL_PKG.Get_Approval_Status ( ai.invoice_id
                                                               , ai.invoice_amount
                                                               , ai.payment_status_flag
                                                               , ai.invoice_type_lookup_code
                                                               , ai.org_id
                                                               ) != 'CANCELLED'
                     )
            )
          ) OR
          ( ( p_acopio_nd_percepciones = 'N' AND
              ah.invoice_id  = p_invoice_id AND
              ah.created_by != 5
            )
          )
      ;

  BEGIN
    FOR rFreeMe IN cHolds LOOP
      --dbms_application_info.set_client_info(rFreeMe.org_id);
      Holds_Handler( p_invoice_id        => rFreeMe.invoice_id
                   , p_hold_code         => rFreeMe.hold_lookup_code
                   , p_hold_required     => 'N'
                   , p_exists_hold       => 'Y'
                   , x_error_msg         => x_error_msg
                   );

      IF p_acopio_nd_percepciones = 'Y' THEN
        IF x_error_msg IS NULL THEN
          FND_FILE.put_line(FND_FILE.LOG, 'Se procedi� con la liberaci�n del c�digo de retenci�n "'||rFreeMe.hold_lookup_code||'" para la factura ID: '||rFreeMe.invoice_id);
        END IF;
      END IF;

    END LOOP;

    --COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;


  PROCEDURE Validar_Transacciones ( errbuf               IN OUT NOCOPY VARCHAR2
                                  , retcode              IN OUT NOCOPY VARCHAR2
                                  , p_option                           VARCHAR2 DEFAULT NULL-- LOOKUP_CODE FROM LOOKUP_TYPE='MATCHING TEST OPTION'  (All, New)
                                  , p_batch_id                         NUMBER   DEFAULT NULL
                                  , p_invoice_date_from                VARCHAR2 DEFAULT NULL
                                  , p_invoice_date_to                  VARCHAR2 DEFAULT NULL
                                  , p_vendor_id                        NUMBER   DEFAULT NULL
                                  , p_pay_group                        VARCHAR2 DEFAULT NULL -- LOOKUP_CODE FROM LOOKUP_TYPE='PAY GROUP'
                                  , p_invoice_id                       NUMBER   DEFAULT NULL
                                  , p_entered_by                       NUMBER   DEFAULT NULL
                                  , p_set_of_books                     NUMBER   DEFAULT NULL
                                  , p_trace_option                     VARCHAR2 DEFAULT NULL
                                  , p_org_id                           NUMBER   DEFAULT NULL
                                  , p_commit_size                      NUMBER   DEFAULT NULL
                                  ) IS
    CURSOR cInvoices IS
      SELECT ai.*
           , ( SELECT attribute15
               FROM fnd_lookup_values_vl
               WHERE lookup_type = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
               AND lookup_code = ai.global_attribute13
             ) valida_cae
      FROM ap_invoices_all ai
      WHERE 1=1
      AND p_invoice_id IS NOT NULL
      AND ai.invoice_id = p_invoice_id
      UNION
      SELECT ai.*
           , ( SELECT attribute15
               FROM fnd_lookup_values_vl
               WHERE lookup_type = 'JLAR_TAX_AUTHORITY_TRX_TYPE'
               AND lookup_code = ai.global_attribute13
             ) valida_cae
           /*, ( SELECT attribute2
               FROM fnd_lookup_values_vl
               WHERE lookup_type = 'JLAR_LEGAL_TRX_CATEGORY'
               AND lookup_code = ai.global_attribute11
             ) valida_cae*/
      FROM ap_invoices_all ai
      WHERE 1=1
      AND XX_AP_UTIL_PKG.Get_Approval_Status( ai.invoice_id
                                            , ai.invoice_amount
                                            , ai.payment_status_flag
                                            , ai.invoice_type_lookup_code
                                            , ai.org_id
                                            ) IN ('NEEDS REAPPROVAL', 'NEVER APPROVED', 'UNAPPROVED')
      -- Parameter
      AND ( p_batch_id IS NULL OR
            p_batch_id = ai.batch_id
          )
      AND ( p_invoice_date_from IS NULL OR
            ai.invoice_date >= TRUNC(TO_DATE(p_invoice_date_from, 'YYYY/MM/DD HH24:MI:SS'))
          )
      AND ( p_invoice_date_to IS NULL OR
            ai.invoice_date <= TRUNC(TO_DATE(p_invoice_date_to, 'YYYY/MM/DD HH24:MI:SS'))
          )
      AND ( p_vendor_id IS NULL OR
            p_vendor_id = ai.vendor_id
          )
      AND ( p_pay_group IS NULL OR
            p_pay_group = ai.pay_group_lookup_code
          )
      AND p_invoice_id IS NULL
      AND ( p_entered_by IS NULL OR
            p_entered_by = ai.created_by
          )
      AND ( p_set_of_books IS NULL OR
            p_set_of_books = ai.set_of_books_id
          )
      AND ( p_org_id IS NULL OR
            p_org_id = ai.org_id
          )
      ORDER BY 90, 1
      ;

    l_exists_hold  VARCHAR2(1);
    l_proc_error   VARCHAR2(32000);
    l_conc_error   VARCHAR2(32000);
    l_ou_name      VARCHAR2(500);
    l_invoice_id   NUMBER;
    l_row_count    NUMBER;
  BEGIN
    FND_FILE.put_line(FND_FILE.OUTPUT, '------------------------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, '- Procedimiento de Validaci�n de Facturas Custom');
    FND_FILE.put_line(FND_FILE.OUTPUT, '------------------------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, '');

    FND_FILE.put_line(FND_FILE.LOG, '-------------');
    FND_FILE.put_line(FND_FILE.LOG, '- Par�tros:');
    FND_FILE.put_line(FND_FILE.LOG, '-------------');
    FND_FILE.put_line(FND_FILE.LOG, '');

    FND_FILE.put_line(FND_FILE.LOG, 'p_option: '||p_option);
    FND_FILE.put_line(FND_FILE.LOG, 'p_batch_id: '||p_batch_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_invoice_date_from: '||p_invoice_date_from);
    FND_FILE.put_line(FND_FILE.LOG, 'p_invoice_date_to: '||p_invoice_date_to);
    FND_FILE.put_line(FND_FILE.LOG, 'p_vendor_id: '||p_vendor_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_pay_group: '||p_pay_group);
    FND_FILE.put_line(FND_FILE.LOG, 'p_invoice_id: '||p_invoice_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_entered_by: '||p_invoice_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_set_of_books: '||p_set_of_books);
    FND_FILE.put_line(FND_FILE.LOG, 'p_trace_option: '||p_trace_option);
    FND_FILE.put_line(FND_FILE.LOG, 'p_org_id: '||p_org_id);
    FND_FILE.put_line(FND_FILE.LOG, 'p_commit_size: '||p_commit_size);


    FOR rInv IN cInvoices LOOP
      BEGIN
        SELECT l.description
        INTO l_ou_name
        FROM hr_all_organization_units ou
           , hr_locations              l
        WHERE 1=1
        AND l.location_id = ou.location_id
        AND ou.name       LIKE 'AR %'
        AND ou.organization_id = rInv.org_id;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_ou_name := rInv.org_id;
      END;

      FND_FILE.put_line(FND_FILE.OUTPUT, '');
      FND_FILE.put_line(FND_FILE.OUTPUT, '--------------------------------------------------------------------------------------------');
      FND_FILE.put_line(FND_FILE.OUTPUT, 'Procesando Factura: '||rInv.invoice_num||' en la empresa '||l_ou_name||'.');

      --dbms_application_info.set_client_info(rInv.org_id);
      l_conc_error := NULL;

      --
      --Sequence: 24 - XX AP Copia Datos Comprobante Distribuciones
      --
      l_proc_error := NULL;

      IF NOT Copia_Datos_Cbte_Distrib ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Copia_Datos_Cbte_Distrib:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence: 25 - XX AP Validaci�n Datos Comprobante Distribuciones
      --
      l_proc_error := NULL;

      IF NOT Hold_Datos_Cbte_Dist ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Datos_Cbte_Dist:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence: 26 - XX AP Validaci�n L�neas Vinculadas
      --
      l_proc_error := NULL;

      IF NOT Hold_Lineas_Vinculadas ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Lineas_Vinculadas:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence: 27 - XX AP Validaci�n Distribuciones Hold - Crea
      --
      l_proc_error := NULL;

      IF NOT Hold_Valida_Distribucion ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Valida_Distribucion:'||chr(10)||l_proc_error
                          );
      END IF;
      --Sequence: 28 - XX AP Validaci�n Distribuciones Hold - Crea  | Se resuelve en la Seq27


      --
      --Sequence: 29 - XX AP Validaci�n Distribuciones NO FONDO FIJO
      --
      l_proc_error := NULL;

      IF NOT Hold_Distrib_NOFF ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Distrib_NOFF:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence: 35 - XX AP Validaci�n Distribuciones NO FONDO FIJO - Montos
      --
      l_proc_error := NULL;

      IF NOT Hold_ValidaDist_No_FF_Montos ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_ValidaDist_No_FF_Montos:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence: 80 - XX AP Validar Impuesto - iva 0%
      --
      /*
      l_proc_error := NULL;

      IF NOT Hold_Impuesto_IVA0 ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Impuesto_IVA0:'||chr(10)||l_proc_error
                          );
      END IF;
      */

      --
      --Sequence: 88 - XX AP Control Mantenimiento Vehiculos con OC Asociada en Validacion FC
      --
      l_proc_error := NULL;

      IF NOT Hold_Ctrl_Mant_Vehiculo_OC_FC ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Ctrl_Mant_Vehiculo_OC_FC:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence 93: XX_AP_Crear_Hold_Provision_Flete
      --
      l_proc_error := NULL;

      IF NOT Hold_Provision_Flete ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Provision_Flete:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Sequence 98 - XX AP Validar que CP no este en mas de una linea de flete de una misma factura - al entrar
      --
      /*
      l_proc_error := NULL;

      IF NOT Hold_Asigna_CP_Flete ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Asigna_CP_Flete:'||chr(10)||l_proc_error
                          );
      END IF;
        */

      --
      --Sequence 100 - XX AP Validar que CP no est� en m�s de una l�nea de flete de una misma factura
      --
      /*
      l_proc_error := NULL;

      IF NOT Hold_Asigna_CP_Flete_Mult ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Asigna_CP_Flete_Mult:'||chr(10)||l_proc_error
                          );
      END IF;
        */

      --
      --Valida Direcci�n de Env�o en l�neas de distribuci�n
      --
      l_proc_error := NULL;

      IF NOT Hold_DirEnvio_Distribucion ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_DirEnvio_Distribucion:'||chr(10)||l_proc_error
                          );
      END IF;


      --
      --Valida Direccion Invalida Ingresada
      --
      l_proc_error := NULL;

      IF NOT Hold_Direccion_Invalida ( rInv.invoice_id, l_proc_error ) THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_Direccion_Invalida:'||chr(10)||l_proc_error
                          );
      END IF;

      --
      --WSCDC XX AP Constataci�n de Comprobantes
      --
      l_proc_error := NULL;

      IF NOT ( rInv.global_attribute12 = 'Y' OR
               NVL(rInv.valida_cae,'N') = 'N'
             ) THEN

        IF NOT Hold_AFIP_WSCDC ( rInv.invoice_id, l_proc_error ) THEN
          ConcatenateErrrors( x_conc_errors  => l_conc_error
                            , x_errors       => l_conc_error
                            , p_error_type   => 'ALL'
                            , p_msg          => 'ERROR en Hold_AFIP_WSCDC:'||chr(10)||l_proc_error
                            );
        END IF;
      ELSE
        l_exists_hold := getHoldStatus (rInv.invoice_id, 'Error Validacion AFIP' /*l_hold_code*/);

        IF l_exists_hold = 'Y' THEN
          Holds_Handler( p_invoice_id        => rInv.invoice_id
                       , p_hold_code         => 'Error Validacion AFIP' /*l_hold_code*/
                       , p_hold_required     => 'N'
                       , p_exists_hold       => l_exists_hold
                        , p_custom_desc      => SUBSTR(l_conc_error,1,240)
                        , x_error_msg        => l_proc_error
                       );

          IF l_proc_error IS NOT NULL THEN
            ConcatenateErrrors( x_conc_errors  => l_conc_error
                              , x_errors       => l_conc_error
                              , p_error_type   => 'ALL'
                              , p_msg          => 'ERROR en Hold_AFIP_WSCDC:'||chr(10)||l_proc_error
                              );
          END IF;
        END IF;

      END IF;

      -- Hold del proceso
      l_proc_error  := NULL;
      l_exists_hold := getHoldStatus (p_invoice_id, 'Error proceso validacion');

      IF l_conc_error IS NOT NULL THEN
        retcode := 1;
        FND_FILE.put_line(FND_FILE.OUTPUT, 'Error validando factura '||rInv.invoice_num||'. Para mayor detalle ver LOG.');

        Holds_Handler( p_invoice_id        => p_invoice_id
                     , p_hold_code         => 'Error proceso validacion'
                     , p_hold_required     => 'Y'
                     , p_exists_hold       => l_exists_hold
                     , p_custom_desc       => SUBSTR(l_conc_error,1,240)
                     , x_error_msg         => l_proc_error
                     );
      ELSIF l_conc_error IS NULL AND
            l_exists_hold = 'Y' THEN
        Holds_Handler( p_invoice_id        => p_invoice_id
                     , p_hold_code         => 'Error proceso validacion'
                     , p_hold_required     => 'N'
                     , p_exists_hold       => l_exists_hold
                     , p_custom_desc       => NULL
                     , x_error_msg         => l_proc_error
                     );
      END IF;

      IF l_proc_error IS NOT NULL THEN
        ConcatenateErrrors( x_conc_errors  => l_conc_error
                          , x_errors       => l_conc_error
                          , p_error_type   => 'ALL'
                          , p_msg          => 'ERROR en Hold_AFIP_WSCDC:'||chr(10)||l_proc_error
                          );
      END IF;

      IF l_conc_error IS NOT NULL THEN
        FND_FILE.put_line(FND_FILE.LOG, '');
        FND_FILE.put_line(FND_FILE.LOG, 'Error validando factura '||rInv.invoice_num||'.'||chr(10)||l_conc_error);
      END IF;

      l_row_count := NVL(l_row_count,0) + 1;
    --
    END LOOP;

    FND_FILE.put_line(FND_FILE.OUTPUT, '');
    FND_FILE.put_line(FND_FILE.OUTPUT, '-----------------------------------');
    FND_FILE.put_line(FND_FILE.OUTPUT, l_row_count||' registros procesados.');

    IF retcode = 1 THEN
      errbuf := 'Error validando factura. Por favor verificar la solapa "Retenciones".';
    END IF;

    --COMMIT;
  --
  EXCEPTION
    WHEN OTHERS THEN
      retcode     := 2;
      errbuf      := SQLERRM;
      ROLLBACK;
  END;


END;
/

exit
