UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID         = 436925,
        PESO_RETIRO                  = 30900,
        LAST_UPDATE_DATE  = sysdate,
        LAST_UPDATED_BY     = 2070
WHERE LIQUIDACION_ID = 11579
--1


UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID         = 436892,
         PESO_RETIRO                 = 29180,
         LAST_UPDATE_DATE  = sysdate,
         LAST_UPDATED_BY    = 2070
WHERE LIQUIDACION_ID = 11578
--1