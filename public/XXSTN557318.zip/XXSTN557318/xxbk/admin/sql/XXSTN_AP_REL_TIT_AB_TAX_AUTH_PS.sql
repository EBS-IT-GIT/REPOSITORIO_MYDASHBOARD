WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE apps.XXSTN_AP_REL_TIT_AB_TAX_AUTH IS
-- +==========================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                        |
-- |                   All rights reserved.                                   |
-- +==========================================================================+
-- | FILENAME                                                                 |
-- |   XXSTN_AP_REL_TIT_AB_TAX_AUTH_PS.sql                                    |
-- |                                                                          |
-- | PURPOSE                                                                  |
-- |                                                                          |
-- | DESCRIPTION                                                              |
-- |   Stone - Relat�rio de titulos em aberto TAX AUTHORITY                   |
-- |                                                                          |
-- | CREATED BY   Rogerio Farto - Ninecon - 15/08/2020                        |
-- |              SR#557318- NSD-323705                                       |
-- |                                                                          |
-- | UPDATED BY                                                               |
-- |                                                                          |
-- +==========================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;

  PROCEDURE generate_report_p (p_errbuf          OUT VARCHAR2
                              ,p_retcode         OUT NUMBER
                              ,p_org_id           IN NUMBER
                              ,p_invoice_date_de  IN VARCHAR2
                              ,p_invoice_date_ate IN VARCHAR2);

END XXSTN_AP_REL_TIT_AB_TAX_AUTH;
/

EXIT; 