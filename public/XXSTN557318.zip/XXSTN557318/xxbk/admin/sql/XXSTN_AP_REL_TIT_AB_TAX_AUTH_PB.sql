WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY apps.XXSTN_AP_REL_TIT_AB_TAX_AUTH IS
-- +==========================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                        |
-- |                   All rights reserved.                                   |
-- +==========================================================================+
-- | FILENAME                                                                 |
-- |   XXSTN_AP_REL_TIT_AB_TAX_AUTH_PB.sql                                    |
-- |                                                                          |
-- | PURPOSE                                                                  |
-- |                                                                          |
-- | DESCRIPTION                                                              |
-- |   Stone - Relat�rio de titulos em aberto TAX AUTHORITY                   |
-- |                                                                          |
-- | CREATED BY   Rogerio Farto - Ninecon - 15/08/2020                        |
-- |              SR#557318- NSD-323705                                       |
-- |                                                                          |
-- | UPDATED BY                                                               |
-- |                                                                          |
-- +==========================================================================+
  -- Function and procedure implementations
  PROCEDURE generate_report_p (p_errbuf          OUT VARCHAR2
                              ,p_retcode         OUT NUMBER
                              ,p_org_id           IN NUMBER
                              ,p_invoice_date_de  IN VARCHAR2
                              ,p_invoice_date_ate IN VARCHAR2) IS
  --
  CURSOR c_invoices IS
    select distinct 
           haou.name                                                                  empresa
         , flv_it.meaning Tipo_NF                                          
         , asu.vendor_name Fornecedor
         , assa.vendor_site_code Local_Fornecedor
         , decode(assa.global_attribute9,'2',assa.global_attribute10 || '/' || 
                                             assa.global_attribute11 || '-' || 
                                             assa.global_attribute12
                                        ,'3',lpad(assa.party_site_id,9,'0') || '/' || 
                                             assa.global_attribute11 || '-' || 
                                             assa.global_attribute12
                                            ,assa.global_attribute10 || '-' || 
                                             assa.global_attribute12)                 cnpj
         , to_char(aia.invoice_date,'dd/mm/rrrr')                                     dt_nff
         , aia.invoice_date
         , to_char(apsa.due_date,'dd/mm/rrrr')                                        dt_vencto
         , aia.invoice_num                                                            num_nff
         , aia.invoice_amount                                                         vlr_nff
         , aia.invoice_currency_code                                                  moeda_nff
         , nvl(aia.amount_paid,0)                                                     vlr_pago
         , apsa.amount_remaining                                                      vlr_aberto_parcela
         , apsa.payment_num                                                           num_parcela
         , aia.invoice_id                                                             invoice_id
         , aia.creation_date                                                          dt_criacao
         , aia.payment_method_code                                                    metodo_nff
         , aia.pay_group_lookup_code                                                  grupo_pagto
         , aia.wfapproval_status                                                      status_aprovacao
      from apps.ap_suppliers asu
         , apps.ap_invoices_all aia
         , apps.ap_supplier_sites_all assa
         , apps.hr_all_organization_units haou
         , apps.fnd_lookup_values flv_it
         , apps.ap_payment_schedules_all apsa
     where 1 = 1
       and asu.vendor_type_lookup_code = 'TAX AUTHORITY'
       and asu.vendor_id = aia.vendor_id
       and aia.org_id = nvl(p_org_id,aia.org_id)
       and aia.cancelled_date is null
       and aia.invoice_date between to_date(nvl(p_invoice_date_de,'1900/01/01 00:00:00'),'rrrr/mm/dd hh24:mi:ss' )
                                and to_date(p_invoice_date_ate,'rrrr/mm/dd hh24:mi:ss' ) 
       and aia.vendor_site_id = assa.vendor_site_id
       and aia.org_id = haou.organization_id
       and aia.invoice_type_lookup_code = flv_it.lookup_code
       and flv_it.lookup_type = 'INVOICE TYPE'
       and flv_it.language = 'PTB'
       and aia.invoice_id = apsa.invoice_id  
       and nvl(apsa.payment_status_flag,'N') != 'Y'
     order 
        by haou.name
         , aia.invoice_date
         , apsa.payment_num;
  --
  TYPE t_invoices IS TABLE OF c_invoices%ROWTYPE;
  r_invoices   t_invoices;
  --
  v_file_name   VARCHAR2(240);
  l_qtde        NUMBER;
  l_vlr         NUMBER;
  l_lin         NUMBER;
  l_count       NUMBER := 2;
  l_nRequest_Id NUMBER;
  l_ledger_name gl_ledgers.name%type;
  l_user        fnd_user.user_name%type;
  --
  BEGIN
     --busca usuario de execucao do relatorio
     BEGIN
      SELECT user_name
        into l_user
        FROM fnd_user
       WHERE user_id = FND_GLOBAL.USER_ID;
      EXCEPTION
       WHEN OTHERS THEN
        l_user := null;
     END;
     --------------------------------------------------------------------------
     --> Printing Parameters
     --------------------------------------------------------------------------
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'STONE PAGAMENTOS S/A               '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'          Stone - AP - Relat�rio de titulos em aberto TAX AUTHORITY          ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Paramters..:');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_org_id.............: '||p_org_id);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_invoice_date_de....: '||p_invoice_date_de);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_invoice_date_ate...: '||p_invoice_date_ate);     
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     --
     dbms_output.put_line('Open invoices '||v_file_name);
     OPEN c_invoices ;
     FETCH c_invoices BULK COLLECT INTO r_invoices;
     CLOSE c_invoices;
     --
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
     --
     as_xlsx.clear_workbook;
     --
     IF r_invoices.count > 0 THEN
       --
       as_xlsx.new_sheet('Titulos');
       as_xlsx.set_row(   1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(  3,  1, 'Stone - AP - Relat�rio de titulos em aberto TAX AUTHORITY', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 14, p_bold =>true) );
       as_xlsx.cell(  1,  2, 'Empresa', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  2,  2, 'CNPJ - CPF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  3,  2, 'Data NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  4,  2, 'Data vencimento', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  5,  2, 'Numero NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  6,  2, 'Valor NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  7,  2, 'Moeda NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  8,  2, 'Valor pago', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  9,  2, 'Valor aberto parcela', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 10,  2, 'Numero parcela', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 11,  2, 'ID NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 12,  2, 'Data criacao', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 13,  2, 'Metodo NFF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 14,  2, 'Grupo pagto', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 15,  2, 'Status aprovacao', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));        
       --
       FOR i IN r_invoices.first..r_invoices.last LOOP
         --
         dbms_output.put_line('Titulos '||v_file_name);                                                         
         
         as_xlsx.cell(  1, l_count+1, nvl(r_invoices(i).empresa,' '));
         as_xlsx.cell(  2, l_count+1, nvl(r_invoices(i).cnpj,' '));
         as_xlsx.cell(  3, l_count+1, r_invoices(i).dt_nff);
         as_xlsx.cell(  4, l_count+1, r_invoices(i).dt_vencto);
         as_xlsx.cell(  5, l_count+1, nvl(r_invoices(i).num_nff,' '));
         as_xlsx.cell(  6, l_count+1, nvl(r_invoices(i).vlr_nff,0));
         as_xlsx.cell(  7, l_count+1, nvl(r_invoices(i).moeda_nff,' '));
         as_xlsx.cell(  8, l_count+1, nvl(r_invoices(i).vlr_pago,0));
         as_xlsx.cell(  9, l_count+1, nvl(r_invoices(i).vlr_aberto_parcela,0));
         as_xlsx.cell( 10, l_count+1, nvl(r_invoices(i).num_parcela,0));
         as_xlsx.cell( 11, l_count+1, nvl(r_invoices(i).invoice_id,0));  
         as_xlsx.cell( 12, l_count+1, r_invoices(i).dt_criacao);
         as_xlsx.cell( 13, l_count+1, nvl(r_invoices(i).metodo_nff,' '));
         as_xlsx.cell( 14, l_count+1, nvl(r_invoices(i).grupo_pagto,' '));
         as_xlsx.cell( 15, l_count+1, nvl(r_invoices(i).status_aprovacao,' '));
         --
         l_count := l_count + 1;
         --
       END LOOP;
       --
       as_xlsx.freeze_rows( 2 );
       --
     END IF;
     --
     dbms_output.put_line('Parameters '||v_file_name);
     as_xlsx.new_sheet('Parameters');
     as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ) ) ;
     as_xlsx.cell(1 , 1 ,'Parametros');
     as_xlsx.cell(1 , 2 ,'Empresa');
     as_xlsx.cell(1 , 3 ,'Data NFF De');
     as_xlsx.cell(1 , 4 ,'Data NFF Ate');
     --
     as_xlsx.cell(2 , 2 ,nvl(to_char(p_org_id),' '));
     as_xlsx.cell(2 , 3 ,nvl(to_char(p_invoice_date_de),' '));
     as_xlsx.cell(2 , 4 ,nvl(to_char(p_invoice_date_ate),' '));

     as_xlsx.cell(5 , 7 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS') ||' por '||l_user
                         , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
     --
     v_file_name := 'o'||NVL(TO_CHAR(FND_GLOBAL.CONC_REQUEST_ID),'NFFAbertoTaxAuth')||'.xlsx';
     dbms_output.put_line('Arquivo gerado '||v_file_name);
     as_xlsx.save( 'XXSTN_HR_OUT', v_file_name );
     --
     dbms_output.put_line('Arquivo gravado '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'       ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Arquivo Gerado.....: '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Registros Gerados..: '||to_char(l_count-3));
     --
     l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                , argument1   => v_file_name
                                                , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
  EXCEPTION
    --
    WHEN OTHERS THEN
      --------------------------------------------------------------------
      --> Set Errors variables
      --------------------------------------------------------------------
      p_errbuf  := SUBSTR(SQLERRM, 1, 500);
      p_retcode := 2;
      --------------------------------------------------------------------
      --> Print Error Messages
      --------------------------------------------------------------------
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** Unexpected error please contact your system administrator');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_errbuf =  ' || SUBSTR(SQLERRM, 1, 500));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_retcode =  '|| SQLCODE);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
      --
  END generate_report_p;
  --
END XXSTN_AP_REL_TIT_AB_TAX_AUTH;
/

EXIT; 