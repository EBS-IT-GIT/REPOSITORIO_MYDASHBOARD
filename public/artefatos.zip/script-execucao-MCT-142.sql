DEFINE DIRETORIO = NULL;
PAUSE 'Digite <ENTER> para comecar a EXECUTAR o script de alteracao de banco do MCT...'
ACCEPT DIRETORIO PROMPT 'Informe caminho do diretorio de origem dos arquivos: '

SPOOL &DIRETORIO\log-script-execucao-MCT-142.SQL;

PROMPT Iniciando a execucao do script...

PROMPT V_EMPRESA.sql
@&DIRETORIO\V_EMPRESA.sql;
PROMPT FIM V_EMPRESA.sql

PROMPT Processo Finalizado! Favor verificar no arquivo de log log-script-execucao-MCT-142.SQL para verificar se o script foi executado com sucesso.
SPOOL OFF;