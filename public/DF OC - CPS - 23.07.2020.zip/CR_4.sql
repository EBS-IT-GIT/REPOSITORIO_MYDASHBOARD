UPDATE xx_po_asocia_remitos xpar
   SET clave_nro = '0005-' || SUBSTR(clave_nro,6,8),
       clave_id  =  clave_id - 1000000
 WHERE xpar.tipo_documento = 'TCG'
   AND xpar.clave_id > 1000000;                                                  
--1