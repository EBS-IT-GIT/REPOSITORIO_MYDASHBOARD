UPDATE apps.wsh_new_deliveries
SET    waybill = '0072-00036305'
WHERE  waybill = '0072-00036605';
--1 Registro