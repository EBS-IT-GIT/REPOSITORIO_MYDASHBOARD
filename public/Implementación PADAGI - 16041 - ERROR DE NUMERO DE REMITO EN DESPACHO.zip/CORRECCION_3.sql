UPDATE apps.mtl_material_transactions
SET    waybill_airbill = '0072-00036305'
WHERE  waybill_airbill = '0072-00036605';
--1 Registro