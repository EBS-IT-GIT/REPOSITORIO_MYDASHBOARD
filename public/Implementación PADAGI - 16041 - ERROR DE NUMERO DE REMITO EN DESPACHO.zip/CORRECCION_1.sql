UPDATE apps.xx_inv_remitos_impresos
SET    waybill_airbill = '0072-00036305'
WHERE  waybill_airbill = '0072-00036605';
--1 Registro
