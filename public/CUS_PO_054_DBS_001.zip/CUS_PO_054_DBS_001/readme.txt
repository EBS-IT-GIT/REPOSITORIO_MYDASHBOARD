==============================================================================
CUSPO054_001 : Valida��es na Ordem de Compra
==============================================================================

Atualiza��o - CUSPO054_001
Produto     - XX Customizaciones
Data        - 31/03/2020 14:38:38
HotPatch    - N�o
Fornecedor  - HQS Plus

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSPO054_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

Realizar bounce no OACORE.


Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_PO_VALIDATION_PO_PKS.pls
                               SAE_PO_VALIDATION_PO_PKB.pls
                               SAE_PO_VALIDATION_PO_PK.grt
                               SAE_PO_VALIDATION_PO_PK.syn
                               jSAECUSPO054.zip
