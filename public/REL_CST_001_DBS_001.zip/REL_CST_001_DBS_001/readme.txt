==============================================================================
RELCST001_001 : Relat�rio de Verifica��o de Fechamento INV
==============================================================================

Atualiza��o - RELCST001_001
Produto     - XX Customizaciones
Data        - 11/12/2019 07:47:07
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121RELCST001_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_CST_FECH_SUMM_INV.tab
                               SAE_CST_FECH_SUMM_INV.grt
                               SAE_CST_FECH_SUMM_INV.syn
                               SAE_CST_ORG_FECH_INV_V.vw
                               SAE_CST_ORG_FECH_INV_V.syn
                               SAE_CST_PERIODO_INV_V.vw
                               SAE_CST_PERIODO_INV_V.syn
                               SAE_CST_FECHAMENTO_PKS.pls
                               SAE_CST_FECHAMENTO_PKB.pls
                               SAE_CST_FECHAMENTO_PK.grt
                               SAE_CST_FECHAMENTO_PK.syn
                               SAE_CST_CONTAS_FECHAMENTO_LKP.ldt
                               SAE_CST_CONTAS_FECHAMENTO_FNC.ldt
                               SAE_CST_CONTAS_AJUSTE_LKP.ldt
                               SAE_CST_CONTAS_AJUSTE_FNC.ldt
                               SAE_CST_FECHAMENTO_INV_CCR.ldt
                               SAE_CST_FECHAMENTO_INV_FNC.ldt
                               SAE_CST_PER_CLOSE_PERIODS_VST.ldt
                               SAE_CST_ITEM_FECH_INV_VST.ldt
                               SAE_CST_FECHAMENTO_INV_XDO.ldt
                               SAE_CST_FECHAMENTO_INV.rtf
                               SAE_CST_FECHAMENTO_INV_MNU.ldt
                               CST_SLA_NAVIGATE_MNU.ldt
