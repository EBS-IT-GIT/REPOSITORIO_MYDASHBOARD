#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2535_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2535
# |
# | HISTORY
# |   19-JUN-20  Braunstein Bayer, Lucas - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2535_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2535_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2535
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2535/CR2535_20200619"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=DESA12

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/PKG
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT
svn up /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2535" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2535_13980.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2535"
AddAllLogs $CROUT "FND" "CR2535_13980.ldt"
mv CR2535_13980.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_WS_AFIP_FEAR_PUB " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_WS_AFIP_FEAR_PUB','APPS','$PATCHDIR','CR2535');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_WS_AFIP_FEAR_PUB* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_WS_AFIP_FEAR2_PUB " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_WS_AFIP_FEAR2_PUB','APPS','$PATCHDIR','CR2535');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_WS_AFIP_FEAR2_PUB* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_AR_PLANEX_INVOICES_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_AR_PLANEX_INVOICES_PK','APPS','$PATCHDIR','CR2535');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_PLANEX_INVOICES_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF DIR_PIL " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','DIR_PIL','','$PATCHDIR','CR2535');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv DIR_PIL* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF DIR_L3N " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','DIR_L3N','','$PATCHDIR','CR2535');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv DIR_L3N* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXARPLIN " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='LATIN AMERICAN SPANISH'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXARPLIN.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXARPLIN"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XXARPLIN.ldt"
mv XXARPLIN.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-LOOKUP XX_AR_PLANEX_FEAR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/aflvmlu.lct XX_AR_PLANEX_FEAR.ldt FND_LOOKUP_TYPE APPLICATION_SHORT_NAME="XBOL" LOOKUP_TYPE="XX_AR_PLANEX_FEAR"
AddAllLogs $CROUT "FND" "XX_AR_PLANEX_FEAR.ldt"
mv XX_AR_PLANEX_FEAR.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/LOOKUP


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
