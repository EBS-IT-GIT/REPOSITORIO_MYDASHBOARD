  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_WS_AFIP_FEAR_PUB" IS

/*Agregado KHRONUS/E.Sly 20200522*/
PROCEDURE run_planex(p_customer_trx_id IN ra_customer_trx_all.customer_trx_id%TYPE);
/*Fin Agregado KHRONUS/E.Sly 20200522*/

  PROCEDURE obtener_cae (p_customer_trx_id IN ra_customer_trx_all.customer_trx_id%TYPE
  , x_status_code OUT VARCHAR2
  , x_error_msg OUT VARCHAR2
  );
END XX_WS_AFIP_FEAR_PUB; 
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_WS_AFIP_FEAR_PUB" IS

/*Agregado KHRONUS/E.Sly 20200522*/
PROCEDURE run_planex(p_customer_trx_id IN ra_customer_trx_all.customer_trx_id%TYPE) IS

v_trx_date         RA_CUSTOMER_TRX_ALL.TRX_DATE%TYPE;
v_batch_source_id  RA_CUSTOMER_TRX_ALL.BATCH_SOURCE_ID%TYPE;
v_trx_number       RA_CUSTOMER_TRX_ALL.TRX_NUMBER%TYPE;
v_customer_id      RA_CUSTOMER_TRX_ALL.BILL_TO_CUSTOMER_ID%TYPE;
v_cust_trx_type    RA_CUST_TRX_TYPES_ALL.TYPE%TYPE;
v_org_id           RA_CUSTOMER_TRX_ALL.ORG_ID%TYPE;

v_dummy            NUMBER;
v_request_id       NUMBER;
v_path             FND_LOOKUP_VALUES_VL.DESCRIPTION%TYPE;
v_error_message    VARCHAR2(2000);
e_cust_exception   EXCEPTION;

BEGIN

    BEGIN
        SELECT COUNT(1)
          INTO v_dummy
          FROM ra_customer_trx_all rct
              ,hz_cust_accounts hca
              ,hz_cust_accounts_dfv hca_dfv
         WHERE nvl(rct.bill_to_customer_id,rct.ship_to_customer_id) = hca.cust_account_id
           and hca.rowid = hca_dfv.row_id
           and hca_dfv.xx_ar_planex_codigo IS NOT NULL
           and rct.customer_trx_id = nvl(p_customer_trx_id,rct.customer_trx_id);
    EXCEPTION
     WHEN OTHERS THEN 
      v_dummy := 0; 
    END;

    IF v_dummy > 0 THEN 
    
        BEGIN
            SELECT rct.trx_date
                  ,rct.batch_source_id
                  ,rct.trx_number
                  ,rct.bill_to_customer_id
                  ,rctt.type
                  ,rct.org_id
              INTO v_trx_date
                  ,v_batch_source_id
                  ,v_trx_number
                  ,v_customer_id
                  ,v_cust_trx_type
                  ,v_org_id
              FROM ra_customer_trx_all rct
                  ,ra_cust_trx_types_all rctt
             WHERE rct.customer_trx_id = p_customer_trx_id
               AND rct.cust_trx_type_id = rctt.cust_trx_type_id;
               
        EXCEPTION
         WHEN OTHERS THEN
           v_error_message := 'Error al obtener los datos del comprobante para ejecutar Planex';
           RAISE e_cust_exception;
        END;
        
        BEGIN
        
            SELECT description
              INTO v_path
              FROM fnd_lookup_values_vl
             WHERE lookup_type = 'XX_AR_PLANEX_FEAR'
               and lookup_code = TO_CHAR(v_org_id)
               and tag = 'DIR'
               and NVL(start_date_active,trunc(SYSDATE)) <= TRUNC(SYSDATE)
               and NVL(end_date_active,trunc(SYSDATE)) >= TRUNC(SYSDATE);
        EXCEPTION
         WHEN OTHERS THEN
            v_error_message := 'Error al obtener el directorio Planex';
            RAISE e_cust_exception;
        END;
      
        BEGIN
        
            SELECT COUNT(1)
              INTO v_dummy
              FROM fnd_lookup_values_vl
             WHERE lookup_type = 'XX_AR_PLANEX_FEAR'
               and lookup_code = v_cust_trx_type
               and tag = 'TRX_TYPE';
        EXCEPTION
         WHEN OTHERS THEN
            v_dummy := 0;
        END;
        
        IF v_dummy > 0 THEN 
    
            v_request_id :=  fnd_request.submit_request ( application => 'XBOL',
                                                          program     => 'XXARPLIN',
                                                          description => NULL,
                                                          start_time  => NULL,
                                                          sub_request => FALSE,
                                                          argument1   => TO_CHAR(v_trx_date,'YYYY/MM/DD HH24:MI:SS'),
                                                          argument2   => TO_CHAR(v_trx_date,'YYYY/MM/DD HH24:MI:SS'),
                                                          argument3   => v_batch_source_id,
                                                          argument4   => v_trx_number,
                                                          argument5   => v_trx_number,
                                                          argument6   => v_customer_id,
                                                          argument7   => v_path,
                                                          argument8   => p_customer_trx_id);
            
            IF v_request_id = 0  THEN
                 v_error_message := 'Error Ejecutando FND_REQUEST.SUBMIT_REQUEST. XXARPLIN. Error: '
                           || fnd_message.get
                           || ', '
                           || SQLERRM;
                 RAISE e_cust_exception;
            END IF;
            
            COMMIT;
            
        END IF;
    
    END IF;
    
EXCEPTION
 WHEN e_cust_exception THEN
   fnd_file.put_line(fnd_file.log,v_error_message);
 WHEN OTHERS THEN
   v_error_message := 'Error OTHERS al ejecutar XX AR Exportacion Facturas Planex. Error: '||SQLERRM;
   fnd_file.put_line(fnd_file.log,v_error_message);
END;
/*Fin Agregado KHRONUS/E.Sly 20200522*/

  PROCEDURE obtener_cae (p_customer_trx_id IN ra_customer_trx_all.customer_trx_id%TYPE
    , x_status_code OUT VARCHAR2
    , x_error_msg OUT VARCHAR2
    ) IS
  --p_customer_trx_id  ra_customer_trx_all.customer_trx_id%TYPE := 6184046;

    l_ofilename VARCHAR2(255);
    l_ofilename2 VARCHAR2(255);
    l_bfileo BFILE;
    l_bfileo2 BFILE;
    l_oclob CLOB;


    l_xfilename VARCHAR2(255);
    l_bfilex BFILE;
    l_xclob CLOB;


    l_host_path    VARCHAR2(255);
    l_file_exists NUMBER;
    l_resultado    VARCHAR2(255);
    l_error_msg    VARCHAR2(255);

    l_step         VARCHAR2(255);
  BEGIN
    -- obtengo directorio
    SELECT NVL (MAX (directory_path),'X')
        INTO l_host_path
       FROM ALL_DIRECTORIES
     WHERE directory_name = 'XX_WS_AFIP_EXC';

    IF l_host_path = 'X' THEN
      raise_application_error(-10001, 'Directorio XX_WS_AFIP_EXC no definido');
    END IF;


    IF p_customer_trx_id IS NULL THEN


      l_ofilename2 := 'queue_out'||to_char(sysdate, 'ddmmyyyy-mihh24ss');
      fnd_log.string(log_level => fnd_log.LEVEL_STATEMENT, module    => 'XX_WS_AFIP_FEAR_PUB' , message   => l_host_path||'/afipws2  '||l_ofilename);

      host_command (p_command =>  'cd '||l_host_path||';./afipws2 '||l_ofilename2);
      l_ofilename2 := l_ofilename2||'.log';

      l_bfileo2 := bfilename('XX_WS_AFIP_EXC', l_ofilename2);
      l_file_exists := dbms_lob.fileexists (l_bfileo2);

      IF l_file_exists = 1 THEN
        l_step :='Step 0.2.2';
      ELSE
        l_step :='Step 0.2.3';
        x_status_code := 'E';
        x_error_msg := 'Error al invocar al WS';
      END IF;

    ELSE
      l_step :='Step 0.1';
      COMMIT;
      dbms_lob.createtemporary(l_oclob, true);
      dbms_lob.createtemporary(l_xclob, true);




      fnd_log.string(log_level => fnd_log.LEVEL_STATEMENT, module    => 'XX_WS_AFIP_FEAR_PUB' , message   => 'createtemporary ');

      l_ofilename := to_char(p_customer_trx_id)||'_EXC.log';
      l_xfilename := to_char(p_customer_trx_id)||'.log';

      --DBMS_JAVA.SET_OUTPUT(2000000);
      fnd_log.string(log_level => fnd_log.LEVEL_STATEMENT, module    => 'XX_WS_AFIP_FEAR_PUB' , message   => l_host_path||'/afipws  '||l_ofilename);

      host_command (p_command =>  'cd '||l_host_path||';./afipws '||p_customer_trx_id ||' '||l_ofilename);

      fnd_log.string(log_level => fnd_log.LEVEL_STATEMENT, module    => 'XX_WS_AFIP_FEAR_PUB' , message   => l_host_path||'/afipws  ok');

      l_bfileo := bfilename('XX_WS_AFIP_EXC', l_ofilename);
      l_file_exists := dbms_lob.fileexists (l_bfileo);


      fnd_log.string(log_level => fnd_log.LEVEL_STATEMENT, module    => 'XX_WS_AFIP_FEAR_PUB' , message   => 'l_file_exists = '||l_file_exists);

      /* si el archivo existe, entonces el WS se ejecuto satisfactoriamente */

      IF l_file_exists = 1 THEN

        DECLARE
          l_file BFILE;
          l_dest_loc CLOB;
          l_dest_off NUMBER(38) := 1;
          l_src_off NUMBER(38) := 1;
          l_context NUMBER(38) := DBMS_LOB.DEFAULT_LANG_CTX;
          l_warning NUMBER(38);
          l_length NUMBER;
          l_csid NUMBER := DBMS_LOB.DEFAULT_CSID;
        BEGIN
          --
          -- Open the file
          --
          DBMS_LOB.OPEN(l_bfileo, DBMS_LOB.LOB_READONLY);
          --
          -- Now load the file into the table
          --
          l_length := DBMS_LOB.GETLENGTH(l_bfileo);
          DBMS_LOB.LOADCLOBFROMFILE (
              dest_lob => l_oclob,
              src_bfile => l_bfileo,
              amount => l_length,
              dest_offset => l_dest_off,
              src_offset => l_src_off,
              bfile_csid => l_csid,
              lang_context => l_context,
              warning => l_warning);
          --
          -- tidy up
          --
          DBMS_LOB.CLOSE(l_bfileo);
        END;
        l_step :='Step 0.1.1';
        l_bfilex := bfilename('XX_WS_AFIP_EXC', l_xfilename);
        l_file_exists := dbms_lob.fileexists (l_bfilex);

        IF l_file_exists = 1 THEN
          l_step :='Step 0.1.2';
          DECLARE
            l_file BFILE;
            l_dest_loc CLOB;
            l_dest_off NUMBER(38) := 1;
            l_src_off NUMBER(38) := 1;
            l_context NUMBER(38) := DBMS_LOB.DEFAULT_LANG_CTX;
            l_warning NUMBER(38);
            l_length NUMBER;
            l_csid NUMBER := DBMS_LOB.DEFAULT_CSID;
          BEGIN
            l_step :='Step 0.1.2.1';
            --
            -- Open the file
            --
            DBMS_LOB.OPEN(l_bfilex, DBMS_LOB.LOB_READONLY);
            --
            -- Now load the file into the table
            --
            l_step :='Step 0.1.2.2';
            l_length := DBMS_LOB.GETLENGTH(l_bfilex);
            l_step :='Step 0.1.2.2.1';
            DBMS_LOB.LOADCLOBFROMFILE (
                dest_lob => l_xclob,
                src_bfile => l_bfilex,
                amount => l_length,
                dest_offset => l_dest_off,
                src_offset => l_src_off,
                bfile_csid => l_csid,
                lang_context => l_context,
                warning => l_warning);
            l_step :='Step 0.1.2.2.2';
            --
            -- tidy up
            --
            DBMS_LOB.CLOSE(l_bfilex);
            l_step :='Step 0.1.2.3';
          END;
          l_step :='Step 0.1.3';
          xx_ws_common_uy_pub.genera_attachment (to_char(p_customer_trx_id),l_xclob, l_xfilename, 'RA_CUSTOMER_TRX', 'MISC', 'text/html');
        END IF;
        l_step :='Step 0.1.4';
        xx_ws_common_uy_pub.genera_attachment (to_char(p_customer_trx_id),l_oclob, l_ofilename, 'RA_CUSTOMER_TRX', 'MISC', 'text/html');

        BEGIN
          SELECT resultado, substr(fex_error_msg, 1, 240)
          INTO l_resultado, l_error_msg
          FROM BOLINF.XXW_FAC_TMP
          WHERE id = p_customer_trx_id;
        EXCEPTION
          WHEN OTHERS THEN
          l_error_msg := substr(sqlerrm,1,240);
        END;

        IF NVL(l_resultado,'X') != 'P' THEN
          x_status_code := 'E';
          x_error_msg := 'Error en WS : '||l_error_msg;
        /*Agregado KHRONUS/E.Sly 20200522 Al obtener CAE Debe enviar el comprobante a Planex*/
        ELSE
          run_planex(p_customer_trx_id => p_customer_trx_id);
        /*Fin Agregado KHRONUS/E.Sly 20200522 Al obtener CAE Debe enviar el comprobante a Planex*/
        END IF;

      ELSE
        x_status_code := 'E';
        x_error_msg := 'Error al invocar al WS';
      END IF;  --IF l_file_exists = 1 THEN

      dbms_lob.freetemporary (l_oclob);
      dbms_lob.freetemporary (l_xclob);
    END IF;
  EXCEPTION WHEN OTHERS
    THEN

    x_status_code := 'E';
    x_error_msg := 'Error al invocar al WS '||l_step||' , error = '||substr (sqlerrm, 1, 254);
  END obtener_cae;
END XX_WS_AFIP_FEAR_PUB; 
/

exit
