  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_WS_AFIP_FEAR2_PUB" IS
  PROCEDURE obtener_cae_impo (
                      errbuf OUT VARCHAR2,
                    retcode OUT VARCHAR2,
                    p_batch_source_id IN ra_batch_sources_all.batch_source_id%TYPE,
                    p_customer_trx_id IN ra_customer_trx_all.customer_trx_id%TYPE,
                    p_queue IN VARCHAR2,
                    p_fecha_d IN VARCHAR2
                    );

END "XX_WS_AFIP_FEAR2_PUB";
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_WS_AFIP_FEAR2_PUB" IS
  PROCEDURE obtener_cae_impo (
                      errbuf OUT VARCHAR2,
                    retcode OUT VARCHAR2,
                    p_batch_source_id IN ra_batch_sources_all.batch_source_id%TYPE,
                    p_customer_trx_id IN ra_customer_trx_all.customer_trx_id%TYPE,
                    p_queue IN VARCHAR2,
                    p_fecha_d IN VARCHAR2
                    ) IS
  CURSOR c_trx (p_customer_trx_id IN NUMBER) IS
  SELECT
  rcta.trx_number, rcta.customer_trx_id
  FROM
  ra_customer_trx_all rcta
  , ra_batch_sources_all rbsa
  , ra_batch_sources_all_dfv rbsad
  , xxw_fac_tmp xft
  WHERE
  rcta.batch_source_id = rbsa.batch_source_id
  AND rbsad.row_id = rbsa.rowid
  AND rbsad.XXW_FAC_ELEC IN ('WSFEV1','WSFEX','WSMTXCA')

  --AND rbsa.batch_source_type = 'FOREIGN'
  AND rcta.customer_trx_id = xft.id (+)
  AND xft.cae IS NULL
  AND rcta.complete_flag = 'Y'
  AND rcta.customer_trx_id = NVL(p_customer_trx_id, rcta.customer_trx_id)
  ;
  
  /*Agregado KHRONUS/E.Sly 20200427 Recorro los comprobantes no finalizados para completarlos y puedan obtener CAE*/
  CURSOR c_nocae IS
  SELECT
    rcta.trx_number, rcta.customer_trx_id
  FROM
    ra_customer_trx_all rcta
  , ra_batch_sources_all rbsa
  , ra_batch_sources_all_dfv rbsad
  , xxw_fac_tmp xft
  WHERE
  rcta.batch_source_id = rbsa.batch_source_id
  AND rcta.batch_source_id = NVL(p_batch_source_id, rcta.batch_source_id)
  AND rbsad.row_id = rbsa.rowid
  AND rbsa.batch_source_type = 'FOREIGN'
  AND rbsad.XXW_FAC_ELEC IN ('WSFEV1','WSFEX','WSMTXCA')
  AND rcta.customer_trx_id = xft.id(+)
  AND xft.cae IS NULL
  AND NVL(rcta.complete_flag,'N') = 'N'
  AND rcta.customer_trx_id = NVL(p_customer_trx_id, rcta.customer_trx_id)
  AND rcta.creation_date >= NVL(TO_DATE (p_fecha_d , 'YYYY/MM/DD HH24:MI:SS'), rcta.creation_date)
  AND rcta.org_id = fnd_global.org_id
  ORDER BY rcta.customer_trx_id
  ;
  /*Fin Agregado KHRONUS/E.Sly 20200427 Recorro los comprobantes no finalizados para completarlos y puedan obtener CAE*/

  CURSOR c_tmp IS
  SELECT
  trx_number, customer_trx_id, org_id, trx_date
  FROM
  XXW_FEAR_TMP
  ;

  CURSOR c_tmp2 IS
  SELECT
  xft.trx_number, xft.customer_trx_id, xft.org_id, xft.trx_date, xft2.cae
  , xft2.fex_error_msg
  FROM
  XXW_FEAR_TMP xft, xxw_fac_tmp xft2
  WHERE
  xft.customer_trx_id = xft2.id (+)
    ORDER BY xft.trx_number
  ;

  CURSOR c_queue IS
  SELECT user_data FROM BOLINF.XXW_FEAR_QT;

  l_trx_number   VARCHAR2(255);
  l_id           VARCHAR2(255);
  l_org_id       VARCHAR(255);
  l_trx_date     VARCHAR2(255);
  r_queue        c_queue%ROWTYPE;
  l_message      SYS.AQ$_JMS_TEXT_MESSAGE;
  l_status_code  VARCHAR2(255);
  l_error_msg    VARCHAR2(255);
  l_proc_cnt     NUMBER := 0;
  l_sucs_cnt     NUMBER := 0;
  r_trx          c_trx%ROWTYPE;
  l_outputline   VARCHAR2 (1023);
  r_tmp          c_tmp%ROWTYPE;
  r_tmp2         c_tmp2%ROWTYPE;
  
  /*Agregado KHRONUS/E.Sly 20200427 Finalizo las transacciones incompletas para obtener cae*/
  v_cae NUMBER;
  l_applied_commitment_amt NUMBER;
  /*Fin Agregado KHRONUS/E.Sly 20200427 Finalizo las transacciones incompletas para obtener cae*/

  l_fecha_desde  DATE := NULL;
  BEGIN

    fnd_file.put_line(fnd_file.log, 'p_fecha_d = '||p_fecha_d);
    fnd_file.put_line(fnd_file.log, 'p_customer_trx_id = '||p_customer_trx_id);
    IF p_fecha_d IS NOT NULL THEN
      l_fecha_desde := TO_DATE (p_fecha_d , 'YYYY/MM/DD HH24:MI:SS'); --2016/06/23 00:00:00
    END IF;
    
    /*Agregado KHRONUS/E.Sly 20200427 Finalizo las transacciones incompletas para obtener cae*/
    FOR r_nocae in c_nocae LOOP
    
        v_cae := 0;
        fnd_file.put_line(fnd_file.log,'Completando Transaccion: '||r_nocae.trx_number);
    
        BEGIN
        
             arp_maintain_ps.maintain_payment_schedules('I',
                                                        r_nocae.customer_trx_id,
                                                        NULL,   -- ps_id
                                                        NULL,   -- line_amount
                                                        NULL,   -- tax_amount
                                                        NULL,   -- frt_amount
                                                        NULL,   -- charge_amount
                                                        l_applied_commitment_amt);
                                                        
             v_cae := 1;
             fnd_file.put_line(fnd_file.log,'Payment Schedule Generado.');                                           
        EXCEPTION
          WHEN OTHERS THEN
             v_cae := 0; 
             fnd_file.put_line(fnd_file.log,'Error regenerando payment Schedule');
        END;
        
        IF v_cae = 1 THEN 
        
            update apps.ra_customer_trx_all
               set complete_flag = 'Y'
             where customer_trx_id = r_nocae.customer_trx_id;
             
             commit;
        
        END IF;
    
    END LOOP;
    /*Fin Agregado KHRONUS/E.Sly 20200427 Finalizo las transacciones incompletas para obtener cae*/

    fnd_file.put_line(fnd_file.output, '________________________________________________________________________________________________________________________');
    fnd_file.put_line(fnd_file.output, '|Numero Trx          |Status CAE     |Errores                                                                           |');
    fnd_file.put_line(fnd_file.output, '------------------------------------------------------------------------------------------------------------------------');


    IF p_customer_trx_id IS NULL THEN

      IF p_queue = 'N' THEN
        INSERT INTO XXW_FEAR_TMP (
        trx_number, customer_trx_id, org_id, trx_date
        )
        SELECT
        rcta.trx_number, rcta.customer_trx_id, rcta.org_id,rcta.trx_date
        FROM
        ra_customer_trx_all rcta
        , ra_batch_sources_all rbsa
        , ra_batch_sources_all_dfv rbsad
        , xxw_fac_tmp xft
        WHERE
        rcta.batch_source_id = rbsa.batch_source_id
        AND rbsad.row_id = rbsa.rowid
        AND rcta.batch_source_id = NVL(p_batch_source_id, rcta.batch_source_id)
        AND rbsad.XXW_FAC_ELEC IN ('WSFEV1','WSFEX','WSMTXCA')

        --AND rbsa.batch_source_type = 'FOREIGN'
        AND rcta.customer_trx_id = xft.id (+)
        AND xft.cae IS NULL
        AND rcta.complete_flag = 'Y'
        AND rcta.customer_trx_id = NVL(p_customer_trx_id, rcta.customer_trx_id)
        AND rcta.creation_date >= NVL(l_fecha_desde, rcta.creation_date)
        AND rcta.org_id = fnd_global.org_id
        ORDER BY rcta.trx_number
        ;

        OPEN c_tmp  ;
          LOOP
            FETCH c_tmp INTO r_tmp;
            EXIT WHEN c_tmp%NOTFOUND;
            fnd_file.put_line(fnd_file.log, ' r_tmp.customer_trx_id = '|| r_tmp.customer_trx_id);
            xxw_wsfe_ar_pkg.xxw_enqueue_facturas( p_trx_id    =>  r_tmp.customer_trx_id --
                                     , p_trx_number => r_tmp.trx_number
                                     , p_org_id     => r_tmp.org_id
                                     , p_trx_date   => r_tmp.trx_date
                                     );
          END LOOP;
        CLOSE c_tmp;
        COMMIT;
      ELSE
        OPEN c_queue  ;
          LOOP
              FETCH c_queue INTO r_queue;
              EXIT WHEN c_queue%NOTFOUND;
              --dbms_output.put_line ('queue');
              l_message := r_queue.user_data;


              l_message.get_text(l_id);
              l_trx_number := l_message.get_string_property ('trxNumber');
              l_org_id := l_message.get_string_property ('orgId');
              l_trx_date :=  l_message.get_string_property ('trxDate');
              fnd_file.put_line(fnd_file.log, ' r_queue l_id = '|| l_id);
              IF l_id IS NOT NULL THEN
                INSERT INTO XXW_FEAR_TMP (
                trx_number, customer_trx_id, org_id, trx_date
                )
                SELECT
                trx_number, customer_trx_id, org_id, trx_date
                FROM ra_customer_trx_all rcta
                WHERE
                rcta.customer_trx_id= l_id;
              END IF;
           END LOOP;

        CLOSE c_queue;
      END IF;

      fnd_file.put_line(fnd_file.log, ' xx_ws_afip_fear_pub.obtener_cae ');
      xx_ws_afip_fear_pub.obtener_cae (NULL, l_status_code, l_error_msg);

      IF (nvl (l_status_code,'X') = 'X') THEN
       OPEN c_tmp2  ;
          LOOP
            FETCH c_tmp2 INTO r_tmp2;
            EXIT WHEN c_tmp2%NOTFOUND;
            l_proc_cnt := l_proc_cnt +1;
            IF r_tmp2.cae IS NOT NULL THEN
              l_sucs_cnt := l_sucs_cnt + 1;
              /*Agregado KHRONUS/E.Sly 20200522 Proceso Envio a Planex*/
              xx_ws_afip_fear_pub.run_planex(r_tmp2.customer_trx_id);
              /*Fin Agregado KHRONUS/E.Sly 20200522 Proceso Envio a Planex*/
            END IF;
            SELECT  '|'||RPAD (r_tmp2.trx_number, 21)||'|'
            ||RPAD (r_tmp2.cae,15)||'|'
            ||RPAD (nvl(r_tmp2.fex_error_msg,' '), 80)||'|'
            INTO l_outputline
            FROM DUAL;
            fnd_file.put_line(fnd_file.output, l_outputline);
          END LOOP;
        CLOSE c_tmp2;
      ELSE
        fnd_file.put_line(fnd_file.output, 'Error al invocar WS masivo '||l_error_msg);
      END IF;


    ELSE
      OPEN c_trx  (p_customer_trx_id);
        LOOP
            FETCH c_trx INTO r_trx;
            EXIT WHEN c_trx%NOTFOUND;
            l_proc_cnt := l_proc_cnt +1;
            fnd_file.put_line(fnd_file.log, 'c_trx.customer_trx_id = '||r_trx.customer_trx_id);
            xx_ws_afip_fear_pub.obtener_cae (r_trx.customer_trx_id, l_status_code, l_error_msg);

            IF (nvl (l_status_code,'X') = 'X') THEN
              l_sucs_cnt := l_sucs_cnt + 1;
            END IF;
            SELECT  '|'||RPAD (r_trx.trx_number, 21)||'|'
            ||RPAD (NVL(l_status_code,NVL((SELECT xft.cae FROM xxw_fac_tmp xft WHERE xft.id = r_trx.customer_trx_id),'E')),15)||'|'
            ||RPAD (nvl(l_error_msg,' '), 80)||'|'
            INTO l_outputline
            FROM DUAL;
            fnd_file.put_line(fnd_file.output, l_outputline);

        END LOOP;
      CLOSE c_trx;

    END IF;
    fnd_file.put_line(fnd_file.output, '________________________________________________________________________________________________________________________');
    fnd_file.put_line(fnd_file.output, '________________________________________________________________________________________________________________________');

    fnd_file.put_line(fnd_file.output, 'TOTAL TRANSACCIONES PROCESADAS = '||l_proc_cnt);
    fnd_file.put_line(fnd_file.output, 'TOTAL TRANSACCIONES PROCESADAS OK = '||l_sucs_cnt);
    IF l_proc_cnt != l_sucs_cnt THEN
      retcode := '1';
    END IF;
  EXCEPTION WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log, 'error no manejado : '||substr (sqlerrm, 1,255));
    retcode := '1';
  END obtener_cae_impo;
END "XX_WS_AFIP_FEAR2_PUB"; 
/

exit
