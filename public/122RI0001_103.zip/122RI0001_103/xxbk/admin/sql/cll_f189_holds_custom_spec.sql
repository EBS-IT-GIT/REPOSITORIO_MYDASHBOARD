set define off;
CREATE OR REPLACE PACKAGE cll_f189_holds_custom_pkg AUTHID CURRENT_USER as
/* $Header: CLLVRJLS.pls 120.5 2007/08/22 18:48:10 afavero noship $ */

FUNCTION func_holds_custom
(p_operation_id       IN  NUMBER,
 p_organization_id    IN  NUMBER) RETURN NUMBER;

END cll_f189_holds_custom_pkg;
/

show errors package apps.cll_f189_holds_custom_pkg 

EXIT
/