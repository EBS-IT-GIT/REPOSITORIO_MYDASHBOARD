CREATE OR REPLACE TRIGGER XXSTN_PIS_COFINS_RECUP_TRG
      BEFORE INSERT ON "GL"."GL_INTERFACE#"
      REFERENCING OLD AS OLD NEW AS NEW FOR EACH ROW

when (NEW.user_je_source_name = 'CLL F189 INTEGRATED RCV' 
  AND NEW.REFERENCE11 IN('Recebimento Item','ITEM'))
DECLARE
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PIS_COFINS_RECUP_TRG.sql                                  |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   RI - Conta Redutora Pis e Cofins a Recuperar                  |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S          17/05/2019            |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

--Pragma Autonomous_Transaction;

CURSOR c_itens(PC_OPERATION_ID cll_f189_entry_operations.operation_id%type
              ,PC_ORGANIZATION_ID cll_f189_entry_operations.organization_id%type
              ,PC_PO_DISTRIBUTION_ID po_distributions_all.po_distribution_id%type) IS 
 select distinct hr.name Org_Inventario,
                 mtl.organization_code Cod_Organizacao,
                 pv.vendor_name Fornecedor,
                 pvs.vendor_site_code Local_Fornecedor,
                 (select case
                           when global_attribute9 = '2' then
                            global_attribute10 || '/' || global_attribute11 || '-' ||
                            global_attribute12
                           when global_attribute9 = '3' then
                            lpad(party_site_id, 9, '0') || '/' ||
                            global_attribute11 || '-' || global_attribute12
                           else
                            global_attribute10 || '-' || global_attribute12
                         end cnpj
                    from apps.ap_supplier_sites_all x
                   where x.vendor_site_id = pvs.vendor_site_id) Cnpj,
                 cfeo.source Origem_RI,
                 cfeo.status Status_RI,
                 cfeo.reversion_flag Reversao_RI,
                 cfeo.operation_id Nr_RI,
                 to_char(cfeo.receive_date, 'dd/mm/yyyy') Data_RI,
                 to_char(cfeo.gl_date, 'dd/mm/yyyy') Data_GL,
                 upper(cfit.invoice_type_code) Cod_Tipo_NF,
                 cfit.description Desc_Tipo_NF,
                 decode(cfit.operation_type, 'E', 'Entrada', 'S''Saida') Tipo_Operacao,
                 cfi.invoice_num Nr_NF,
                 cfi.invoice_num_ap Nr_NF_AP,
                 to_char(cfi.invoice_date, 'dd/mm/yyyy') Data_NF,
                 cfi.fiscal_document_model Especie_NF,
                 cfi.series Serie,
                 cfi.invoice_amount Vl_NF,
                 cfi.gross_total_amount Vl_Bruto_NF,
                 ph.segment1 Nr_PO,
                 ms.segment1 Item,
                 ms.description Desc_Item,
                 cfil.pis_amount_recover,
                 cfil.cofins_amount_recover,
                 cfil.pis_base_amount,
                 cfil.pis_tax_rate,
                 cfil.pis_amount,
                 cfil.cofins_base_amount,
                 cfil.cofins_tax_rate,
                 cfil.cofins_amount,
                 cfil.pis_amount_rec_lin vl_pis_recuperar,
                 cfil.cofins_amount_rec_lin vl_cofins_recuperar,
                 ms.attribute1 Redutora_Pis_Cofins_a_Rec,
                 cfeo.organization_id,
                 pda.po_distribution_id,
                 pda.code_combination_id distr_code_combination_id,
                 cfi.invoice_parent_id,
                 cfi.invoice_id,
                 pv.vendor_name,
                 cfit.invoice_type_code,
                 pda.quantity_delivered,
                 cfil.db_code_combination_id,
                 cfil.cofins_tax_rate cfil_cofins_tax_rate,
                 cfil.pis_tax_rate cfil_pis_tax_rate 
   from apps.mtl_parameters               mtl,
        apps.hr_alL_organization_units    hr,
        apps.cll_f189_entry_operations    cfeo,
        apps.cll_f189_invoice_types       cfit,
        apps.ap_suppliers                 pv,
        apps.ap_supplier_sites_all        pvs,
        apps.cll_f189_invoices            cfi,
        apps.cll_f189_fiscal_entities_all cffe,
        apps.cll_f189_invoice_lines       cfil,
        apps.po_line_locations_all        pll,
        apps.po_headers_all               ph,
        apps.mtl_system_items_b           ms,
        apps.po_distributions_all         pda 
  where mtl.organization_id = hr.organization_id
    and hr.organization_id = cfeo.organization_id
    and cfeo.organization_id = cfi.organization_id
    and cfeo.operation_id = cfi.operation_id
    and cfi.entity_id = cffe.entity_id
    and cffe.vendor_site_id = pvs.vendor_site_id
    and pvs.vendor_id = pv.vendor_id
    and cfi.invoice_type_id = cfit.invoice_type_id
    and cfi.invoice_id = cfil.invoice_id
    and cfil.line_location_id = pll.line_location_id(+)
    and pll.po_header_id = ph.po_header_id
    and cfil.item_id = ms.inventory_item_id
    and cfil.organization_id = ms.organization_id
    and (nvl(cfil.pis_amount_rec_lin,0) <> 0 or
         nvl(cfil.cofins_amount_rec_lin,0) <> 0) 
    and cfeo.operation_id = PC_OPERATION_ID 
    and cfeo.organization_id = PC_ORGANIZATION_ID
    and pda.po_distribution_id = PC_PO_DISTRIBUTION_ID
    and pda.line_location_id = cfil.line_location_id
    and pda.po_header_id = ph.po_header_id
  order by hr.name, cfeo.operation_id, pv.vendor_name;

l_operation_id cll_f189_entry_operations.operation_id%type;
l_organization_id cll_f189_entry_operations.organization_id%type;
l_set_of_books_id gl_interface.set_of_books_id%type;
l_created_by gl_interface.created_by%type;
l_period_name gl_interface.period_name%type;
l_group_id gl_interface.group_id%type;
l_ledger_id gl_interface.ledger_id%type;
l_reference_1 gl_interface.reference1%type; 
l_reference_2 gl_interface.reference2%type;
l_reference_21 gl_interface.reference21%type;
l_reference_22 gl_interface.reference22%type;
l_chart_of_accounts_id gl_interface.chart_of_accounts_id%type;
l_accounted_cr number;
l_accounted_dr number;
l_segment1 gl_code_combinations.segment1%type;
l_segment2 gl_code_combinations.segment1%type;
l_segment3 gl_code_combinations.segment1%type; 
l_segment5 gl_code_combinations.segment1%type;
l_segment6 gl_code_combinations.segment1%type;
l_segment7 gl_code_combinations.segment1%type;
l_segment8 gl_code_combinations.segment1%type;
l_reference10 gl_interface.reference10%type;
l_reference25 gl_interface.reference25%type; 
l_reference27 gl_interface.reference27%type;
l_code_combination_id gl_code_combinations.code_combination_id%type;
l_po_distribution_id po_distributions_all.po_distribution_id%type; 
l_sum_pis_amount_recover number;
l_sum_cofins_amount_recover number;
l_count_sem_pis_cofins number;

BEGIN

 l_operation_id    := :NEW.REFERENCE2;
 l_organization_id := :NEW.REFERENCE1;
 l_po_distribution_id := :NEW.REFERENCE3;
 
 FOR r_itens IN c_itens(l_operation_id,l_organization_id,l_po_distribution_id) LOOP
 
 IF r_itens.invoice_parent_id IS NULL THEN
 
  /*l_count_sem_pis_cofins := 0;
  BEGIN
  
   SELECT count(*)
     INTO l_count_sem_pis_cofins
     FROM cll_f189_invoice_lines
    WHERE invoice_id = r_itens.invoice_id   
      AND (nvl(pis_amount_rec_lin,0) = 0 OR
          nvl(cofins_amount_rec_lin,0) = 0);

   EXCEPTION  
    WHEN OTHERS THEN  
     RAISE_APPLICATION_ERROR(-20000,'Erro ao buscar soma pis_amount_recover ' ||SQLERRM);

  END;
  
  IF l_count_sem_pis_cofins = 0 THEN 
 
   :NEW.accounted_dr := r_itens.vl_bruto_nf;
   
   BEGIN
   
    SELECT SUM(cfil.pis_amount_recover)
      INTO l_sum_pis_amount_recover
      FROM cll_f189_invoice_lines cfil
     WHERE invoice_id = r_itens.invoice_id; 
     
    EXCEPTION  
     WHEN OTHERS THEN  
      RAISE_APPLICATION_ERROR(-20001,'Erro ao buscar soma pis_amount_recover ' ||SQLERRM);   
     
   END; 
   
   BEGIN
   
    SELECT SUM(cfil.cofins_amount_recover)
      INTO l_sum_cofins_amount_recover
      FROM cll_f189_invoice_lines cfil
     WHERE invoice_id = r_itens.invoice_id;
        
    EXCEPTION  
     WHEN OTHERS THEN  
      RAISE_APPLICATION_ERROR(-20002,'Erro ao buscar soma cofins_amount_recover ' ||SQLERRM);
     
   END; 
   
   l_accounted_dr := NVL(l_sum_pis_amount_recover,0) + NVL(l_sum_cofins_amount_recover,0);

  ELSE*/
  
  IF r_itens.db_code_combination_id IS NOT NULL THEN
  
   :NEW.accounted_dr := NVL(r_itens.pis_base_amount,r_itens.cofins_base_amount);
   :NEW.entered_dr := NVL(r_itens.pis_base_amount,r_itens.cofins_base_amount);
   
   l_accounted_dr := NVL(r_itens.pis_amount_recover,0) + NVL(r_itens.cofins_amount_recover,0);
   
  ELSE
  
   :NEW.accounted_dr := r_itens.quantity_delivered;  
   :NEW.entered_dr := r_itens.quantity_delivered;
   
   l_accounted_dr := ((r_itens.cfil_pis_tax_rate + r_itens.cfil_cofins_tax_rate) * r_itens.quantity_delivered) / 100;
   
  END IF; 
   
  --END IF; 

  l_set_of_books_id := :NEW.set_of_books_id;
  l_created_by := :NEW.created_by;
  l_period_name := :NEW.period_name;
  l_group_id := :NEW.group_id;
  l_ledger_id := :NEW.ledger_id;
  l_reference_1 := :NEW.reference1;
  l_reference_2 := :NEW.reference2;
  l_reference_21 := :NEW.reference21;
  l_reference_22 := :NEW.reference22;
  l_chart_of_accounts_id := :NEW.chart_of_accounts_id;
  l_reference10 := r_itens.invoice_type_code||':'||l_operation_id||'-'||'Redutora Pis e Cofins-'||r_itens.vendor_name;
  l_reference25 := :NEW.reference25;
  l_reference27 := :NEW.reference27;

  BEGIN
  
   SELECT segment1
         ,segment2
         ,segment3
         ,segment5
         ,segment6
         ,segment7
         ,segment8
     INTO l_segment1  
         ,l_segment2
         ,l_segment3
         ,l_segment5
         ,l_segment6
         ,l_segment7
         ,l_segment8
     FROM gl_code_combinations     
    WHERE code_combination_id = r_itens.distr_code_combination_id;  

   EXCEPTION    
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20003,'Erro ao buscar segments atraves do po_distribution_id ' ||SQLERRM);
     --null;
  
  END;

  BEGIN
  
    --inserindo registro conta redutora
    INSERT INTO GL_INTERFACE
      (STATUS,               --01
       SET_OF_BOOKS_ID,      --02
       ACCOUNTING_DATE,      --03
       CURRENCY_CODE,        --04
       DATE_CREATED,         --05
       CREATED_BY,           --06
       ACTUAL_FLAG,          --07
       USER_JE_CATEGORY_NAME,--08  
       USER_JE_SOURCE_NAME,  --09
       ENCUMBRANCE_TYPE_ID,  --10
       SEGMENT1,             --11
       SEGMENT2,             --12
       SEGMENT3,             --13
       SEGMENT4,             --14
       SEGMENT5,             --15
       SEGMENT6,             --16
       SEGMENT7,             --17
       SEGMENT8,             --18       
       ACCOUNTED_CR,         --19
       ACCOUNTED_DR,         --20
       ENTERED_CR,           --21
       ENTERED_DR,           --22
       TRANSACTION_DATE,     --23
       REFERENCE1,           --24
       REFERENCE2,           --25
       REFERENCE4,           --26
       REFERENCE5,           --27
       REFERENCE6,           --28
       REFERENCE10,          --29
       REFERENCE11,          --30
       REFERENCE21,          --31
       REFERENCE22,          --32
       REFERENCE23,          --33
       REFERENCE24,          --34
       REFERENCE25,          --35
       REFERENCE26,          --36
       REFERENCE27,          --37
       REFERENCE30,          --38
       JE_BATCH_ID,          --39
       PERIOD_NAME,          --40
       JE_HEADER_ID,         --41
       JE_LINE_NUM,          --42
       CODE_COMBINATION_ID,  --43
       DATE_CREATED_IN_GL,   --44
       STATUS_DESCRIPTION,   --45
       GROUP_ID,             --46
       REQUEST_ID,           --47
       GL_SL_LINK_ID,        --48
       GL_SL_LINK_TABLE,     --49
       LEDGER_ID,            --50
       CHART_OF_ACCOUNTS_ID  --51
       )
    VALUES                   
      ('NEW',                   --01                            
       l_set_of_books_id,       --02
       SYSDATE,                 --03
       'BRL',                    --04
       SYSDATE,                 --05
       l_created_by,            --06
       'A',                     --07
       'REC',                   --08
       'CLL F189 INTEGRATED RCV', --09
       '',                    --10
       l_segment1,              --11
       l_segment2,              --12
       l_segment3,              --13
       r_itens.Redutora_Pis_Cofins_a_Rec,              --14
       l_segment5,              --15
       l_segment6,              --16
       l_segment7,              --17
       l_segment8,              --18       
       l_accounted_dr,              --19
       '',            --20
       l_accounted_dr,            --21
       '',            --22
       TRUNC(SYSDATE),          --23
       l_reference_1,            --24
       l_reference_2,            --25
       NULL,                    --26
       NULL,                    --27
       NULL,                    --28
       l_reference10,                    --29
       'Recebimento Redutora Pis e Cofins',                    --30
       l_reference_21,         --31
       l_reference_22,         --32
       NULL,                    --33
       NULL,                    --34
       l_reference25,                    --35
       NULL,                    --36
       l_reference27,                    --37
       NULL,                    --38
       NULL,                    --39
       l_period_name,           --40
       NULL,                    --41
       NULL,                    --42
       '',      --43
       SYSDATE,                 --44           
       NULL,                    --45
       l_group_id,                    --46
       NULL,                    --47
       NULL,                    --48
       NULL,                    --49
       l_ledger_id,             --50
       l_chart_of_accounts_id   --51 
       );
  
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20004,'Erro ao inserir registro na GL_INTERFACE ' ||SQLERRM);
      --null;
    
  END;
  
  ELSIF r_itens.invoice_parent_id IS NOT NULL THEN
  
  /*l_count_sem_pis_cofins := 0;
  BEGIN
  
   SELECT count(*)
     INTO l_count_sem_pis_cofins
     FROM cll_f189_invoice_lines
    WHERE invoice_id = r_itens.invoice_id   
      AND (nvl(pis_amount_rec_lin,0) = 0 OR
          nvl(cofins_amount_rec_lin,0) = 0);
  
   EXCEPTION  
    WHEN OTHERS THEN  
     RAISE_APPLICATION_ERROR(-20005,'Erro ao buscar l_count_sem_pis_cofins ' ||SQLERRM);
  
  END;
  
  IF l_count_sem_pis_cofins = 0 THEN 
  
   :NEW.accounted_cr := r_itens.vl_bruto_nf;
   
   BEGIN
   
    SELECT SUM(cfil.pis_amount_recover)
      INTO l_sum_pis_amount_recover
      FROM cll_f189_invoice_lines cfil
     WHERE invoice_id = r_itens.invoice_id; 
     
    EXCEPTION  
     WHEN OTHERS THEN  
      RAISE_APPLICATION_ERROR(-20006,'Erro ao buscar soma pis_amount_recover ' ||SQLERRM);   
     
   END; 
   
   BEGIN
   
    SELECT SUM(cfil.cofins_amount_recover)
      INTO l_sum_cofins_amount_recover
      FROM cll_f189_invoice_lines cfil
     WHERE invoice_id = r_itens.invoice_id;
        
    EXCEPTION  
     WHEN OTHERS THEN  
      RAISE_APPLICATION_ERROR(-20007,'Erro ao buscar soma cofins_amount_recover ' ||SQLERRM);
     
   END; 
   
   l_accounted_cr := NVL(l_sum_pis_amount_recover,0) + NVL(l_sum_cofins_amount_recover,0);
   
  ELSE*/
  
  IF r_itens.db_code_combination_id IS NOT NULL THEN
  
   :NEW.accounted_cr := NVL(r_itens.pis_base_amount,r_itens.cofins_base_amount);
   :NEW.entered_cr := NVL(r_itens.pis_base_amount,r_itens.cofins_base_amount);
   
   l_accounted_cr := NVL(r_itens.pis_amount_recover,0) + NVL(r_itens.cofins_amount_recover,0);
   
  ELSE
  
   :NEW.accounted_cr := r_itens.quantity_delivered;  
   :NEW.entered_cr := r_itens.quantity_delivered; 

   l_accounted_cr := ((r_itens.cfil_pis_tax_rate + r_itens.cfil_cofins_tax_rate) * r_itens.quantity_delivered) / 100;
   
  END IF;    
   
  --END IF; 
  
  l_set_of_books_id := :NEW.set_of_books_id;
  l_created_by := :NEW.created_by;
  l_period_name := :NEW.period_name;
  l_group_id := :NEW.group_id;
  l_ledger_id := :NEW.ledger_id;
  l_reference_1 := :NEW.reference1;
  l_reference_2 := :NEW.reference2;
  l_reference_21 := :NEW.reference21;
  l_reference_22 := :NEW.reference22;
  l_chart_of_accounts_id := :NEW.chart_of_accounts_id;
  l_reference10 := r_itens.invoice_type_code||':'||l_operation_id||'-'||'Redutora Pis e Cofins-'||r_itens.vendor_name;
  l_reference25 := :NEW.reference25;
  l_reference27 := :NEW.reference27;

  BEGIN
  
   SELECT segment1
         ,segment2
         ,segment3
         ,segment5
         ,segment6
         ,segment7
         ,segment8
     INTO l_segment1  
         ,l_segment2
         ,l_segment3
         ,l_segment5
         ,l_segment6
         ,l_segment7
         ,l_segment8
     FROM gl_code_combinations     
    WHERE code_combination_id = r_itens.distr_code_combination_id;  
  
   EXCEPTION    
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20008,'Erro ao buscar segments atraves do po_distribution_id ' ||SQLERRM);
     --null;
  
  END;  
  
  BEGIN
  
    --inserindo registro conta redutora
    INSERT INTO GL_INTERFACE
      (STATUS,               --01
       SET_OF_BOOKS_ID,      --02
       ACCOUNTING_DATE,      --03
       CURRENCY_CODE,        --04
       DATE_CREATED,         --05
       CREATED_BY,           --06
       ACTUAL_FLAG,          --07
       USER_JE_CATEGORY_NAME,--08  
       USER_JE_SOURCE_NAME,  --09
       ENCUMBRANCE_TYPE_ID,  --10
       SEGMENT1,             --11
       SEGMENT2,             --12
       SEGMENT3,             --13
       SEGMENT4,             --14
       SEGMENT5,             --15
       SEGMENT6,             --16
       SEGMENT7,             --17
       SEGMENT8,             --18       
       ACCOUNTED_CR,         --19
       ACCOUNTED_DR,         --20
       ENTERED_CR,           --21
       ENTERED_DR,           --22
       TRANSACTION_DATE,     --23
       REFERENCE1,           --24
       REFERENCE2,           --25
       REFERENCE4,           --26
       REFERENCE5,           --27
       REFERENCE6,           --28
       REFERENCE10,          --29
       REFERENCE11,          --30
       REFERENCE21,          --31
       REFERENCE22,          --32
       REFERENCE23,          --33
       REFERENCE24,          --34
       REFERENCE25,          --35
       REFERENCE26,          --36
       REFERENCE27,          --37
       REFERENCE30,          --38
       JE_BATCH_ID,          --39
       PERIOD_NAME,          --40
       JE_HEADER_ID,         --41
       JE_LINE_NUM,          --42
       CODE_COMBINATION_ID,  --43
       DATE_CREATED_IN_GL,   --44
       STATUS_DESCRIPTION,   --45
       GROUP_ID,             --46
       REQUEST_ID,           --47
       GL_SL_LINK_ID,        --48
       GL_SL_LINK_TABLE,     --49
       LEDGER_ID,            --50
       CHART_OF_ACCOUNTS_ID  --51
       )
    VALUES                   
      ('NEW',                   --01                            
       l_set_of_books_id,       --02
       SYSDATE,                 --03
       'BRL',                    --04
       SYSDATE,                 --05
       l_created_by,            --06
       'A',                     --07
       'REC',                   --08
       'CLL F189 INTEGRATED RCV', --09
       '',                    --10
       l_segment1,              --11
       l_segment2,              --12
       l_segment3,              --13
       r_itens.Redutora_Pis_Cofins_a_Rec,              --14
       l_segment5,              --15
       l_segment6,              --16
       l_segment7,              --17
       l_segment8,              --18       
       '',              --19
       l_accounted_cr,            --20
       '',            --21
       l_accounted_cr,            --22
       TRUNC(SYSDATE),          --23
       l_reference_1,            --24
       l_reference_2,            --25
       NULL,                    --26
       NULL,                    --27
       NULL,                    --28
       l_reference10,                    --29
       'Recebimento Redutora Pis e Cofins',                    --30
       l_reference_21,         --31
       l_reference_22,         --32
       NULL,                    --33
       NULL,                    --34
       l_reference25,                    --35
       NULL,                    --36
       l_reference27,                    --37
       NULL,                    --38
       NULL,                    --39
       l_period_name,           --40
       NULL,                    --41
       NULL,                    --42
       '',      --43
       SYSDATE,                 --44           
       NULL,                    --45
       l_group_id,                    --46
       NULL,                    --47
       NULL,                    --48
       NULL,                    --49
       l_ledger_id,             --50
       l_chart_of_accounts_id   --51 
       );
  
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20009,'Erro ao inserir registro na GL_INTERFACE ' ||SQLERRM);
      --null;
    
  END;
  
  END IF; --IF r_itens.invoice_parent_id IS NULL THEN
 
 END LOOP;
 
 EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20010,'Erro inesperado na trigger XXSTN_PIS_COFINS_RECUP_TRG ' ||SQLERRM);

END XXSTN_PIS_COFINS_RECUP_TRG;
/
