UPDATE XX_WS_EFACTURA_TALONARIO_ALL
SET    ultimo_nro = ultimo_nro + 1
WHERE  tipo_cbte = 182
AND     estado = 'A';
--1 Registro