#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2357_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2357
# |
# | HISTORY
# |   14-FEB-20  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2357_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2357_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2357
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2357/CR2357_20200214"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=CRP3

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/sql/PKG
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT
svn up /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2357" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2357_9336.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2357"
AddAllLogs $CROUT "FND" "CR2357_9336.ldt"
mv CR2357_9336.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_WMS_INT_IN_TRX_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_WMS_INT_IN_TRX_PK','APPS','$PATCHDIR','CR2357');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_WMS_INT_IN_TRX_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_WMS_INT_IN_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_WMS_INT_IN_PK','APPS','$PATCHDIR','CR2357');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_WMS_INT_IN_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-LOOKUP XX_EBS_WMS_RESPO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/aflvmlu.lct XX_EBS_WMS_RESPO.ldt FND_LOOKUP_TYPE APPLICATION_SHORT_NAME="INV" LOOKUP_TYPE="XX_EBS_WMS_RESPO"
AddAllLogs $CROUT "FND" "XX_EBS_WMS_RESPO.ldt"
mv XX_EBS_WMS_RESPO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/LOOKUP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOPO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOPO.ldt DESC_FLEX APPLICATION_SHORT_NAME="FND" DESCRIPTIVE_FLEXFIELD_NAME="FND_COMMON_LOOKUPS" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_EBS_WMS_RESPO" END_USER_COLUMN_NAME="XX_RESPO_PO"
AddAllLogs $CROUT "FND" "FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOPO.ldt"
mv FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOPO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOSPLITOM " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOSPLITOM.ldt DESC_FLEX APPLICATION_SHORT_NAME="FND" DESCRIPTIVE_FLEXFIELD_NAME="FND_COMMON_LOOKUPS" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_EBS_WMS_RESPO" END_USER_COLUMN_NAME="XX_RESPO_SPLIT_OM"
AddAllLogs $CROUT "FND" "FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOSPLITOM.ldt"
mv FND_COMMON_LOOKUPS_XXEBSWMSRESPO_XXRESPOSPLITOM.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
