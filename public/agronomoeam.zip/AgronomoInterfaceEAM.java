import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 *
 * @author apetrocelli
 */
public class AgronomoInterfaceEAM {
  public static void main(String args[]){  

    String p_action = args[0];
    String p_org_code = args[1];
    String p_fecha_desde = args[2];
    String p_fecha_hasta = args[3];
    String p_request_id  = args[4];
    String p_modo_ejec   = args[5];

    String l_org_code = null;
    if (p_org_code.equalsIgnoreCase("null")) l_org_code = "est.organizacion = est.organizacion"; 
    else l_org_code = "est.organizacion = '"+p_org_code+"'";

    Properties prop = new Properties();
    InputStream configfile;

    String mySQLConnURL;
    Connection mySQLConn = null;

    String oraConnURL;
    Connection oraConn = null;
    
    String sqlStmt = null;
    try {
      configfile = new FileInputStream("agronomo.properties");
      prop.load(configfile);
      } catch (FileNotFoundException e) {
        System.out.println(e.getMessage());
      } catch (IOException e) {
        System.out.println(e.getMessage());
      }

    // OPEN mySQL Connection
    try {
      mySQLConnURL = prop.getProperty("mySQLConURL");
      String mySQLuser = prop.getProperty("mySQLuser");
      String mySQLpassword = prop.getProperty("mySQLpassword");
      System.out.println ("mySQLConnectionString = " + mySQLConnURL);
      Class.forName("com.mysql.jdbc.Driver");
      mySQLConn = DriverManager.getConnection(mySQLConnURL, mySQLuser, mySQLpassword);
      mySQLConn.setAutoCommit(false);
      System.out.println("Conectado a mySQL");

      oraConnURL = prop.getProperty("oraConURL");
      System.out.println ("mySQLConnectionString = " + oraConnURL);
      Class.forName("oracle.jdbc.driver.OracleDriver");
      oraConn = DriverManager.getConnection(oraConnURL);
      oraConn.setAutoCommit(false);
      System.out.println("Conectado a Oracle");
    } catch(ClassNotFoundException e) { 
        System.out.println(e.getMessage());
    } catch (SQLException e) {
        System.out.println(e.getMessage()+"\n"+sqlStmt);
    } 

    Statement mySQLStmt;
    Statement mySQLStmtLine;
    Statement mySQLStmtInv;
    Statement mySQLStmtUpd;
    ResultSet mySQLrs;
    ResultSet mySQLrsLine;
    ResultSet mySQLrsInv;
    Statement oraStmt;
    ResultSet orars;

    if (p_action.equalsIgnoreCase("PROCESS_NEWS")){
        try {
          mySQLStmt     = mySQLConn.createStatement();
          mySQLStmtLine = mySQLConn.createStatement();
          mySQLStmtInv  = mySQLConn.createStatement();
          mySQLStmtUpd  = mySQLConn.createStatement();
          oraStmt       = oraConn.createStatement();

          int rowi_count = 0;
          int rowu_count = 0;

          // Get mySQL info
          sqlStmt = 
                  "SELECT DISTINCT\n" +
                  "       s.id                 servicio\n" +
                  "     , s.descripcion\n" +
                  "     , se.id                servicio_estado\n" +
                  "     , CASE WHEN s.em_servicios_tipo_id IN (1,4) THEN 2\n" +
                  "            WHEN s.em_servicios_tipo_id = 3 THEN 1\n" +
                  "            WHEN s.em_servicios_tipo_id = 2 THEN 4\n" +
                  "       END tipo_servicio\n" +
                  "     , s.fecha_inicio\n" +
                  "     , s.fecha_fin\n" +
                  "     , est.envio            direccion_envio\n" +
                  "     , est.facturacion      direccion_facturacion\n" +
                  "     , est.id_organizacion   organizacion_id\n" +
                  "     , m.identificador\n" +
                  "     , u.comprador_id_oracle comprador_id\n" +
                  "     , IFNULL(s.oracle_flag, 'N') oracle_flag\n" +
                  "     , CASE WHEN s.cerrado = 0 THEN 'N'\n" +
                  "            WHEN s.cerrado = 1 THEN 'Y'\n" +
                  "       END cerrado_flag\n" +
                  "FROM em_servicios         s\n" +
                  "   , establecimientos     est\n" +
                  "   , em_maquinas          m\n" +
                  "   , em_maquinas_modelos  mm\n" +
                  "   , em_servicios_estados se\n" +
                  "   , users                u\n" +
                  "WHERE 1=1\n" +
                  "AND est.id    = s.establecimiento_id\n" +
                  "AND m.id      = s.em_maquina_id\n" +
                  "AND mm.id     = m.em_maquinas_modelo_id\n" +
                  "AND se.id     = s.em_servicios_estado_id\n" +
                  "AND u.id      = s.user_id\n" +
                  "AND se.nombre = 'Certificado'\n" +
                  "AND IFNULL(s.oracle_flag, 'N') IN ('Y', 'N', 'P', 'R')\n" +
                  "AND IFNULL(s.oracle_completion_flag, 'N') = 'N'\n" +
                  "AND "+l_org_code+"\n" + 
                  "AND DATE(s.fecha_inicio) >= '"+p_fecha_desde+"'\n" +
                  "AND DATE(s.fecha_inicio) <= '"+p_fecha_hasta+"'\n" +
                  "ORDER BY s.id"
                  ;

          //System.out.println(sqlStmt);
          mySQLrs = mySQLStmt.executeQuery(sqlStmt);

          while(mySQLrs.next()) {
            if (mySQLrs.getString("oracle_flag").equalsIgnoreCase("N")){
                sqlStmt =
                        "INSERT INTO ADECO_BI.XX_AGRONOMO_EAM_INT\n"+
                        "( SERVICIO\n" +
                        ", DESCRIPCION\n" +
                        ", SERVICIO_ESTADO\n" +
                        ", TIPO_SERVICIO\n" +
                        ", FECHA_INICIO\n" +
                        ", FECHA_FIN\n" +
                        ", DIRECCION_ENVIO\n" +
                        ", DIRECCION_FACTURACION\n" +
                        ", ORGANIZACION_ID\n" +
                        ", IDENTIFICADOR\n" +
                        ", COMPRADOR_ID\n" +
                        ", IMPORTADO_FLAG\n" +
                        ", CERRADO_FLAG\n" +
                        ", CREATION_DATE\n" +
                        ", LAST_UPDATE_DATE\n" +
                        ", REQUEST_ID\n" +
                        ") VALUES\n"+
                        "("+mySQLrs.getInt("servicio")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("descripcion")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("servicio_estado")+"\n"+
                        ","+mySQLrs.getInt("tipo_servicio")+"\n"+
                        ",TO_DATE('"+mySQLrs.getDate("fecha_inicio")+"', 'YYYY/MM/DD HH24:MI:SS')\n"+
                        ",TO_DATE('"+mySQLrs.getDate("fecha_fin")+"', 'YYYY/MM/DD HH24:MI:SS')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("direccion_envio")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("direccion_facturacion")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("organizacion_id")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("identificador")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("comprador_id")+"\n"+
                        ",'"+mySQLrs.getString("oracle_flag")+"'\n"+
                        ",'"+mySQLrs.getString("cerrado_flag")+"'\n"+
                        ",SYSDATE\n"+
                        ",SYSDATE\n"+
                        ","+p_request_id+"\n"+
                        ")\n";


                rowi_count = rowi_count +1;
            } else {
               sqlStmt =
                        "UPDATE ADECO_BI.XX_AGRONOMO_EAM_INT\n"+
                        "SET SERVICIO_ESTADO     = "+mySQLrs.getInt("servicio_estado")+"\n"+
                        "  , TIPO_SERVICIO       = "+mySQLrs.getInt("tipo_servicio")+"\n"+
                        "  , FECHA_INICIO         = "+"TO_DATE('"+mySQLrs.getDate("fecha_inicio")+"', 'YYYY/MM/DD HH24:MI:SS')\n"+
                        "  , FECHA_FIN           = "+"TO_DATE('"+mySQLrs.getDate("fecha_fin")+"', 'YYYY/MM/DD HH24:MI:SS')\n"+
                        "  , DIRECCION_ENVIO     = "+"REPLACE(REPLACE('"+mySQLrs.getString("direccion_envio")+"',chr(10),''),chr(13),'')\n"+
                        "  , DIRECCION_FACTURACION = "+"REPLACE(REPLACE('"+mySQLrs.getString("direccion_facturacion")+"',chr(10),''),chr(13),'')\n"+
                        "  , ORGANIZACION_ID     = "+mySQLrs.getInt("organizacion_id")+"\n"+
                        "  , IDENTIFICADOR       = "+"REPLACE(REPLACE('"+mySQLrs.getString("identificador")+"',chr(10),''),chr(13),'')\n"+
                        "  , COMPRADOR_ID        = "+mySQLrs.getInt("comprador_id")+"\n"+
                        "  , IMPORTADO_FLAG      = "+"'"+mySQLrs.getString("oracle_flag")+"'\n"+
                        "  , CERRADO_FLAG        = "+"'"+mySQLrs.getString("cerrado_flag")+"'\n"+
                        "  , LAST_UPDATE_DATE    = SYSDATE\n" + 
                        "  , REQUEST_ID          = "+p_request_id+"\n"+
                        "WHERE 1=1\n" +
                        "AND SERVICIO = "+mySQLrs.getInt("servicio");

                rowu_count = rowu_count +1;
            }

            //System.out.println(sqlStmt);
            oraStmt.executeUpdate(sqlStmt);

            sqlStmt = "SELECT s.id                  servicio\n" +
                      "	    , st.id                 servicio_tercero_id\n" +
                      "	    , p.id_proveedor_oracle proveedor_id\n" +
                      "	    , CASE WHEN st.moneda_id = 1 THEN 'ARS'\n" +
                      "	           WHEN st.moneda_id = 2 THEN 'USD'\n" +
                      "	      END moneda\n" +
                      "	    , st.precio\n" +
                      "	    , st.em_subsistema_id\n" +
                      "	    , CASE WHEN st.bien = 0 THEN sbs.cod_serv_ref_oracle\n" +
                      "	           WHEN st.bien = 1 THEN sbs.cod_prod_ref_oracle\n" +
                      "	      END item\n" +
                      "     , IFNULL(st.oracle_flag, 'N') oracle_flag\n" +
                      "FROM em_servicios          s\n" +
                      "   , establecimientos      est\n" +
                      "   , em_servicios_terceros st\n" +
                      "   , proveedores           p\n" +
                      "   , em_subsistemas        sbs\n" +
                      "WHERE 1=1\n" +
                      "AND est.id            = s.establecimiento_id\n" +
                      "AND st.em_servicio_id = s.id\n" +
                      "AND p.id              = st.proveedore_id\n" +
                      "AND sbs.id            = st.em_subsistema_id\n" +
                      "AND st.certificado    = 1\n" +
                      "AND IFNULL(st.oracle_flag, 'N') IN ('N', 'P', 'R')\n" +
                      "AND s.id = "+mySQLrs.getInt("servicio")+"\n" +
                      "ORDER BY s.id, st.id";

            mySQLrsLine = mySQLStmtLine.executeQuery(sqlStmt);
            while(mySQLrsLine.next()) {
              if (mySQLrsLine.getString("oracle_flag").equalsIgnoreCase("N")){
                  sqlStmt =
                          "INSERT INTO ADECO_BI.XX_AGRONOMO_EAM_OC_INT\n"+
                          "( SERVICIO\n" +
                          ", SERVICIO_TERCERO_ID\n" +
                          ", PROVEEDOR_ID\n" +
                          ", MONEDA\n" +
                          ", PRECIO\n" +
                          ", EM_SUBSISTEMA_ID\n" +
                          ", PRODUCTO\n" +
                          ", IMPORTADO_FLAG\n" +
                          ", CREATION_DATE\n" +
                          ", LAST_UPDATE_DATE\n" +
                          ", REQUEST_ID\n" +
                          ") VALUES\n"+
                          "("+mySQLrsLine.getInt("servicio")+"\n"+
                          ","+mySQLrsLine.getInt("servicio_tercero_id")+"\n"+
                          ","+mySQLrsLine.getInt("proveedor_id")+"\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("moneda")+"',chr(10),''),chr(13),'')\n"+
                          ","+mySQLrsLine.getDouble("precio")+"\n"+
                          ","+mySQLrsLine.getInt("em_subsistema_id")+"\n"+
                          ",REPLACE(REPLACE('"+mySQLrsLine.getString("item")+"',chr(10),''),chr(13),'')\n"+
                          ",'N'\n"+
                          ",SYSDATE\n"+
                          ",SYSDATE\n"+
                          ","+p_request_id+"\n"+
                          ")\n";

                  rowi_count = rowi_count +1;
              } else {
                 sqlStmt =
                          "UPDATE ADECO_BI.XX_AGRONOMO_EAM_OC_INT\n"+
                          "SET PROVEEDOR_ID   = "+mySQLrsLine.getInt("proveedor_id")+"\n"+
                          "  , MONEDA         = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("moneda")+"',chr(10),''),chr(13),'')\n"+
                          "  , PRECIO         = "+mySQLrsLine.getDouble("precio")+"\n"+
                          "  , EM_SUBSISTEMA_ID = "+mySQLrsLine.getDouble("em_subsistema_id")+"\n"+
                          "  , PRODUCTO       = "+"REPLACE(REPLACE('"+mySQLrsLine.getString("item")+"',chr(10),''),chr(13),'')\n"+
                          "  , IMPORTADO_FLAG = "+"'"+mySQLrsLine.getString("oracle_flag")+"'\n"+
                          "  , LAST_UPDATE_DATE = SYSDATE\n" + 
                          "  , REQUEST_ID     = "+p_request_id+"\n"+
                          "WHERE 1=1\n" +
                          "AND SERVICIO = "+mySQLrsLine.getInt("servicio")+"\n" +
                          "AND SERVICIO_TERCERO_ID = "+mySQLrsLine.getInt("servicio_tercero_id");

                  rowu_count = rowu_count +1;
              }

              //System.out.println(sqlStmt);
              oraStmt.executeUpdate(sqlStmt);
            }

            sqlStmt = "SELECT s.id               servicio\n" +
                      "     , mlie.id            mov_insumo_id\n" +
                      "	    , mlie.fecha         fecha_mov\n" +
                      "	    , al.sub_inventario  subinventario\n" +
                      "	    , al.localizacion    localizador\n" +
                      "     , mlie.cantidad\n" +
                      "     , mlie.impacto\n" +
                      "     , p.codigooracle     producto\n" +
                      "     , p.em_subsistema_id\n" +
                      "     , IFNULL(mlie.oracle_flag, 'N') oracle_flag\n" +
                      "FROM em_servicios_modelos_lineas_insumos_entregas mlie\n" +
                      "   , em_servicios_modelos_lineas_insumos          mli\n" +
                      "   , em_servicios                                 s\n" +
                      "   , almacenes                                    al\n" +
                      "   , productos                                    p\n" +
                      "WHERE 1=1\n" +
                      "AND mli.id = mlie.em_servicios_modelos_lineas_insumo_id\n" +
                      "AND s.id   = mli.em_servicio_id\n" +
                      "AND al.id  = mlie.almacene_id\n" +
                      "AND p.id   = mli.producto_id\n" +
                      "AND IFNULL(mlie.oracle_flag, 'N') IN ('N', 'P', 'R')\n" +
                      "AND s.id = "+mySQLrs.getInt("servicio")+"\n" +
                      "ORDER BY s.id, mlie.id";

            mySQLrsInv = mySQLStmtInv.executeQuery(sqlStmt);
            while(mySQLrsInv.next()) {
              if (mySQLrsInv.getString("oracle_flag").equalsIgnoreCase("N")){
                  sqlStmt =
                          "INSERT INTO ADECO_BI.XX_AGRONOMO_EAM_INV_INT\n"+
                          "( SERVICIO\n" +
                          ", MOV_INSUMO_ID\n" +
                          ", FECHA\n" +
                          ", SUBINVENTARIO\n" +
                          ", LOCALIZADOR\n" +
                          ", CANTIDAD\n" +
                          ", IMPACTO\n" +
                          ", PRODUCTO\n" +
                          ", EM_SUBSISTEMA_ID\n" +
                          ", IMPORTADO_FLAG\n" +
                          ", CREATION_DATE\n" +
                          ", LAST_UPDATE_DATE\n" +
                          ", REQUEST_ID\n" +
                          ") VALUES\n"+
                          "("+mySQLrsInv.getInt("servicio")+"\n"+
                          ","+mySQLrsInv.getInt("mov_insumo_id")+"\n"+
                          ","+"TO_DATE('"+mySQLrsInv.getDate("fecha_mov")+"', 'YYYY/MM/DD')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsInv.getString("subinventario")+"',chr(10),''),chr(13),'')\n"+
                          ",REPLACE(REPLACE('"+mySQLrsInv.getString("localizador")+"',chr(10),''),chr(13),'')\n"+
                          ","+mySQLrsInv.getDouble("cantidad")+"\n"+
                          ","+mySQLrsInv.getDouble("impacto")+"\n"+
                          ",REPLACE(REPLACE('"+mySQLrsInv.getString("producto")+"',chr(10),''),chr(13),'')\n"+
                          ","+mySQLrsInv.getInt("em_subsistema_id")+"\n"+
                          ",'N'\n"+
                          ",SYSDATE\n"+
                          ",SYSDATE\n"+
                          ","+p_request_id+"\n"+
                          ")\n";

                  rowi_count = rowi_count +1;
              } else {
                 sqlStmt =
                          "UPDATE ADECO_BI.XX_AGRONOMO_EAM_INV_INT\n"+
                          "SET FECHA          = "+"TO_DATE('"+mySQLrsInv.getDate("fecha_mov")+"', 'YYYY/MM/DD')\n"+
                          "  , SUBINVENTARIO  = "+"REPLACE(REPLACE('"+mySQLrsInv.getString("subinventario")+"',chr(10),''),chr(13),'')\n"+
                          "  , LOCALIZADOR    = "+"REPLACE(REPLACE('"+mySQLrsInv.getString("localizador")+"',chr(10),''),chr(13),'')\n"+
                          "  , CANTIDAD       = "+mySQLrsInv.getDouble("cantidad")+"\n"+
                          "  , IMPACTO        = "+mySQLrsInv.getDouble("impacto")+"\n"+
                          "  , PRODUCTO       = "+"REPLACE(REPLACE('"+mySQLrsInv.getString("producto")+"',chr(10),''),chr(13),'')\n"+
                          "  , EM_SUBSISTEMA_ID = "+mySQLrsInv.getInt("em_subsistema_id")+"\n"+
                          "  , IMPORTADO_FLAG = "+"'"+mySQLrsInv.getString("oracle_flag")+"'\n"+
                          "  , LAST_UPDATE_DATE = SYSDATE\n" + 
                          "  , REQUEST_ID     = "+p_request_id+"\n"+
                          "WHERE 1=1\n" +
                          "AND SERVICIO = "+mySQLrsInv.getInt("servicio")+"\n" +
                          "AND MOV_INSUMO_ID = "+mySQLrsInv.getInt("mov_insumo_id");

                  rowu_count = rowu_count +1;
              }

              //System.out.println(sqlStmt);
              oraStmt.executeUpdate(sqlStmt);
            }

          }

          oraConn.commit();

          if (rowi_count>0) System.out.println(rowi_count + " registros insertados en la interface."); 
          if (rowu_count>0) System.out.println(rowu_count + " registros reprocesados en la interface."); 
          if (rowi_count==0 && rowu_count==0) System.out.println("No se encontraron registros para insertar.");

          sqlStmt = 
                  "SELECT mov_insumo_id \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_INV_INT\n" +
                  "WHERE request_id = "+p_request_id;

          // System.out.println(sqlStmt);
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios_modelos_lineas_insumos_entregas\n"+
                    "SET oracle_flag = 'Y'\n"+
                    "  , error_interfaces = ''\n"+
                    "WHERE id = "+orars.getInt("mov_insumo_id");

            mySQLStmtUpd.executeUpdate(sqlStmt);
          }

          sqlStmt = 
                  "SELECT servicio_tercero_id \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_OC_INT\n" +
                  "WHERE request_id = "+p_request_id;

          // System.out.println(sqlStmt);
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios_terceros\n"+
                    "SET oracle_flag = 'Y'\n"+
                    "  , error_interfaces = ''\n"+
                    "WHERE id = "+orars.getInt("servicio_tercero_id");

            mySQLStmtUpd.executeUpdate(sqlStmt);
          }
		  
          sqlStmt = 
                  "SELECT servicio \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_INT\n" +
                  "WHERE request_id = "+p_request_id;

          // System.out.println(sqlStmt);
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios\n"+
                    "SET oracle_flag = 'Y'\n"+
                    "  , error_interfaces = ''\n"+
                    "WHERE id = "+orars.getInt("servicio");

            mySQLStmtUpd.executeUpdate(sqlStmt);
          }

          mySQLStmtUpd.close();
		  mySQLConn.commit();
		  mySQLConn.close();
          oraStmt.close();
		  oraConn.commit();
          oraConn.close();
        } catch (SQLException e) {
          System.out.println(e.getMessage()+"\n"+sqlStmt);
          try {
            mySQLConn.rollback();
          } catch (SQLException e2) {
            System.out.println(e2.getMessage());
          }
        }
    
    } else if (p_action.equalsIgnoreCase("PROCESS_ERRORS")){

        int row_count = 0;
        
        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT servicio, importado_flag, mensaje_error \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_INT\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          //int row_count = 0;
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios\n"+
                    "SET oracle_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , error_interfaces = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("servicio");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          oraConn.commit();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT servicio, servicio_tercero_id, importado_flag, mensaje_error \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_OC_INT\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios_terceros\n"+
                    "SET oracle_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , error_interfaces = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("servicio_tercero_id");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          oraConn.commit();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT servicio, mov_insumo_id, importado_flag, mensaje_error \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_INV_INT\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios_modelos_lineas_insumos_entregas\n"+
                    "SET oracle_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , error_interfaces = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("mov_insumo_id");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          mySQLConn.close();
          oraConn.commit();
          oraConn.close();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        if (row_count>0) System.out.println(row_count + " registros actualizados en Agronomo con errores."); 
        if (row_count==0) System.out.println("No se encontraron registros actualizados en Agronomo con errores."); 

    } else if (p_action.equalsIgnoreCase("PROCESS_COMPLETE")){

        int row_count = 0;
        
        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT servicio, completado_flag\n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_INT\n" +
                  "WHERE completado_flag = 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          //int row_count = 0;
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_servicios\n"+
                    "SET oracle_completion_flag_flag = '"+orars.getString("completado_flag")+"'\n"+
                    "WHERE id = "+orars.getInt("servicio");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          mySQLConn.close();
          oraConn.commit();
          oraConn.close();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        if (row_count>0) System.out.println(row_count + " registros actualizados en Agronomo con OTs completadas."); 
        if (row_count==0) System.out.println("No se encontraron registros de OTs completadas."); 

    }
  }
}
