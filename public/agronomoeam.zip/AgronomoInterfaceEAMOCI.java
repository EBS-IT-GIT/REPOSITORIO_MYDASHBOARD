import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Savepoint;
import java.util.Properties;

/**
 *
 * @author apetrocelli
 */
public class AgronomoInterfaceEAMOCI {
  public static void main(String args[]){  

    String p_action = args[0];
    String p_org_code = args[1];
    String p_fecha_desde = args[2];
    String p_fecha_hasta = args[3];
    String p_request_id  = args[4];
    String p_modo_ejec   = args[5];

    String l_org_code = null;
    if (p_org_code.equalsIgnoreCase("null")) l_org_code = "est.organizacion = est.organizacion"; 
    else l_org_code = "est.organizacion = '"+p_org_code+"'";

    Properties prop = new Properties();
    InputStream configfile;

    String mySQLConnURL;
    Connection mySQLConn = null;

    String oraConnURL;
    Connection oraConn = null;
    
    String sqlStmt = null;
    try {
      configfile = new FileInputStream("agronomo.properties");
      prop.load(configfile);
      } catch (FileNotFoundException e) {
        System.out.println(e.getMessage());
      } catch (IOException e) {
        System.out.println(e.getMessage());
      }

    // OPEN mySQL Connection
    try {
      mySQLConnURL = prop.getProperty("mySQLConURL");
      String mySQLuser = prop.getProperty("mySQLuser");
      String mySQLpassword = prop.getProperty("mySQLpassword");
      System.out.println ("mySQLConnectionString = " + mySQLConnURL);
      Class.forName("com.mysql.jdbc.Driver");
      mySQLConn = DriverManager.getConnection(mySQLConnURL, mySQLuser, mySQLpassword);
      mySQLConn.setAutoCommit(false);
      System.out.println("Conectado a mySQL");

      oraConnURL = prop.getProperty("oraConURL");
      System.out.println ("mySQLConnectionString = " + oraConnURL);
      Class.forName("oracle.jdbc.driver.OracleDriver");
      oraConn = DriverManager.getConnection(oraConnURL);
      oraConn.setAutoCommit(false);
      System.out.println("Conectado a Oracle");
    } catch(ClassNotFoundException e) { 
        System.out.println(e.getMessage());
    } catch (SQLException e) {
        System.out.println(e.getMessage()+"\n"+sqlStmt);
    } 

    Statement mySQLStmt;
    Statement mySQLStmtLine;
    Statement mySQLStmtInv;
    Statement mySQLStmtUpd;
    ResultSet mySQLrs;
    ResultSet mySQLrsLine;
    ResultSet mySQLrsInv;
    Statement oraStmt;
    ResultSet orars;

    if (p_action.equalsIgnoreCase("PROCESS_NEWS")){
        try {
          mySQLStmt    = mySQLConn.createStatement();
		  mySQLStmtUpd = mySQLConn.createStatement();
		  oraStmt      = oraConn.createStatement();

          int rowi_count = 0;
          int rowu_count = 0;

          // Get mySQL info
          sqlStmt = 
                  "SELECT DISTINCT\n" +
                  "       ioc.id       insumo_oc_id\n" +
                  "     , iod.id       insumo_oc_det_id\n" +
                  "     , ioc.descripcion\n" +
                  "     , ioc.fecha\n" +
                  "     , est.envio             direccion_envio\n" +
                  "     , est.facturacion       direccion_facturacion\n" +
                  "     , est.id_organizacion   organizacion_id\n" +
                  "     , s.id_proveedor_oracle proveedor_id\n" +
                  "     , CASE WHEN iod.moneda_id = 1 THEN 'ARS'\n" +
                  "            WHEN iod.moneda_id = 2 THEN 'USD'\n" +
                  "       END moneda\n" +
                  "     , iod.cantidad\n" +
                  "     , iod.precio\n" +
                  "     , IFNULL(iod.em_insumo_id, iod.producto_id) po_line_number" +
                  "     , CASE WHEN iod.em_insumo_id IS NOT NULL THEN 'EXPENSE'\n" +
                  "            WHEN iod.producto_id IS NOT NULL THEN 'INVENTORY'\n" +
                  "       END tipo_destino\n" +
                  "     , IFNULL(ss.cod_gasto_ref_oracle, p.codigooracle) producto\n" +
                  "     , u.comprador_id_oracle comprador_id\n" +
                  "     , IFNULL(ioc.oracle_flag, 'N') oracle_flag\n" +
                  "FROM em_insumos_ocs          ioc\n" +
                  "   , establecimientos        est\n" +
                  "   , em_insumos_ocs_detalles iod\n" +
                  "	  LEFT JOIN em_insumos i ON iod.em_insumo_id = i.id\n" +
                  "	            LEFT JOIN em_subsistemas ss ON i.em_subsistema_id = ss.id\n" +
                  "     LEFT JOIN productos p ON iod.producto_id = p.id\n" +
                  "   , proveedores          s\n" +
                  "   , em_servicios_estados se\n" +
                  "   , users                u\n" +
                  "WHERE 1=1\n" +
                  "AND est.id = ioc.establecimiento_id\n" +
                  "AND iod.em_insumos_oc_id = ioc.id\n" +
                  "AND s.id   = ioc.proveedore_id\n" +
                  "AND se.id  = ioc.em_insumos_ocs_estado_id\n" +
                  "AND u.id   = ioc.user_id\n" +
                  "AND IFNULL(ioc.oracle_flag, 'N') IN ('N', 'P', 'R')\n" +
                  "AND IFNULL(iod.oracle_flag, 'N') IN ('N', 'P', 'R')\n" +
                  "AND "+l_org_code+"\n" + 
                  "AND DATE(ioc.fecha) >= '"+p_fecha_desde+"'\n" +
                  "AND DATE(ioc.fecha) <= '"+p_fecha_hasta+"'\n" +
                  "ORDER BY ioc.id, iod.id"
                  ;

          //System.out.println(sqlStmt);
          mySQLrs = mySQLStmt.executeQuery(sqlStmt);

          while(mySQLrs.next()) {
            if (mySQLrs.getString("oracle_flag").equalsIgnoreCase("N")){
                sqlStmt =
                        "INSERT INTO ADECO_BI.XX_AGRONOMO_EAM_OCI_INT\n"+
                        "( INSUMO_OC_ID\n" +
                        ", INSUMO_OC_DET_ID\n" +						
                        ", DESCRIPCION\n" +
                        ", FECHA\n" +
                        ", DIRECCION_ENVIO\n" +
                        ", DIRECCION_FACTURACION\n" +
                        ", ORGANIZACION_ID\n" +
                        ", PROVEEDOR_ID\n" +
                        ", MONEDA\n" +
                        ", CANTIDAD\n" +
                        ", PRECIO\n" +
                        ", PO_LINE_NUMBER\n" +
                        ", TIPO_DESTINO\n" +
                        ", PRODUCTO\n" +
                        ", COMPRADOR_ID\n" +
                        ", IMPORTADO_FLAG\n" +
                        ", CREATION_DATE\n" +
                        ", LAST_UPDATE_DATE\n" +
                        ", REQUEST_ID\n" +
                        ") VALUES\n"+
                        "("+mySQLrs.getInt("insumo_oc_id")+"\n"+
                        ","+mySQLrs.getInt("insumo_oc_det_id")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("descripcion")+"',chr(10),''),chr(13),'')\n"+
                        ",TO_DATE('"+mySQLrs.getDate("fecha")+"', 'YYYY/MM/DD HH24:MI:SS')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("direccion_envio")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("direccion_facturacion")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("organizacion_id")+"\n"+
                        ","+mySQLrs.getInt("proveedor_id")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("moneda")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getDouble("cantidad")+"\n"+
                        ","+mySQLrs.getDouble("precio")+"\n"+
                        ","+mySQLrs.getInt("po_line_number")+"\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("tipo_destino")+"',chr(10),''),chr(13),'')\n"+
                        ",REPLACE(REPLACE('"+mySQLrs.getString("producto")+"',chr(10),''),chr(13),'')\n"+
                        ","+mySQLrs.getInt("comprador_id")+"\n"+
                        ",'N'\n"+
                        ",SYSDATE\n"+
                        ",SYSDATE\n"+
                        ","+p_request_id+"\n"+
                        ")\n";


                rowi_count = rowi_count +1;
            } else {
               sqlStmt =
                        "UPDATE ADECO_BI.XX_AGRONOMO_EAM_OCI_INT\n"+
                        "SET DESCRIPCION        = "+"REPLACE(REPLACE('"+mySQLrs.getString("descripcion")+"',chr(10),''),chr(13),'')\n"+
                        "  , FECHA              = "+"TO_DATE('"+mySQLrs.getDate("fecha")+"', 'YYYY/MM/DD HH24:MI:SS')\n"+
                        "  , DIRECCION_ENVIO     = "+"REPLACE(REPLACE('"+mySQLrs.getString("direccion_envio")+"',chr(10),''),chr(13),'')\n"+
                        "  , DIRECCION_FACTURACION = "+"REPLACE(REPLACE('"+mySQLrs.getString("direccion_facturacion")+"',chr(10),''),chr(13),'')\n"+
                        "  , ORGANIZACION_ID     = "+mySQLrs.getInt("organizacion_id")+"\n"+
                        "  , PROVEEDOR_ID        = "+mySQLrs.getInt("proveedor_id")+"\n"+
                        "  , MONEDA              = "+"'"+mySQLrs.getString("moneda")+"'\n"+
                        "  , CANTIDAD            = "+mySQLrs.getDouble("cantidad")+"\n"+
                        "  , PRECIO              = "+mySQLrs.getDouble("precio")+"\n"+
                        "  , PO_LINE_NUMBER      = "+mySQLrs.getInt("po_line_number")+"\n"+
                        "  , TIPO_DESTINO        = "+"REPLACE(REPLACE('"+mySQLrs.getString("tipo_destino")+"',chr(10),''),chr(13),'')\n"+
                        "  , PRODUCTO            = "+"REPLACE(REPLACE('"+mySQLrs.getString("producto")+"',chr(10),''),chr(13),'')\n"+
                        "  , COMPRADOR_ID        = "+mySQLrs.getInt("comprador_id")+"\n"+
                        "  , IMPORTADO_FLAG      = "+"'"+mySQLrs.getString("oracle_flag")+"'\n"+
                        "  , LAST_UPDATE_DATE    = SYSDATE\n" + 
                        "  , REQUEST_ID          = "+p_request_id+"\n"+
                        "WHERE 1=1\n" +
                        "AND INSUMO_OC_ID = "+mySQLrs.getInt("insumo_oc_id")+"\n" +
                        "AND INSUMO_OC_DET_ID = "+mySQLrs.getInt("insumo_oc_det_id");

                rowu_count = rowu_count +1;
            }

            //System.out.println(sqlStmt);
            oraStmt.executeUpdate(sqlStmt);
          }

          //oraStmt.close();
		  oraConn.commit();
          //oraConn.close();
          if (rowi_count>0) System.out.println(rowi_count + " registros insertados en la interface."); 
          if (rowu_count>0) System.out.println(rowu_count + " registros reprocesados en la interface."); 
          if (rowi_count==0 && rowu_count==0) System.out.println("No se encontraron registros para insertar.");

          sqlStmt = 
                  "SELECT insumo_oc_id, insumo_oc_det_id \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_OCI_INT\n" +
                  "WHERE request_id = "+p_request_id;

          // System.out.println(sqlStmt);
          //oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_insumos_ocs\n"+
                    "SET oracle_flag = 'Y'\n"+
                    "  , error_interfaces = ''\n"+
                    "WHERE id = "+orars.getInt("insumo_oc_id");

            mySQLStmtUpd.executeUpdate(sqlStmt);

            sqlStmt =
                    "UPDATE em_insumos_ocs_detalles\n"+
                    "SET oracle_flag = 'Y'\n"+
                    "  , error_interfaces = ''\n"+
                    "WHERE id = "+orars.getInt("insumo_oc_det_id");

            mySQLStmtUpd.executeUpdate(sqlStmt);
          }

          mySQLStmtUpd.close();
		  mySQLConn.commit();
		  mySQLConn.close();
          oraStmt.close();
		  oraConn.commit();
          oraConn.close();
        } catch (SQLException e) {
          System.out.println(e.getMessage()+"\n"+sqlStmt);
          try {
            mySQLConn.rollback();
          } catch (SQLException e2) {
            System.out.println(e2.getMessage());
          }
        }
    
    } else if (p_action.equalsIgnoreCase("PROCESS_ERRORS")){

        int row_count = 0;
        
        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT DISTINCT insumo_oc_id, importado_flag, mensaje_error \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_OCI_INT\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          //int row_count = 0;
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_insumos_ocs\n"+
                    "SET oracle_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , error_interfaces = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("insumo_oc_id");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          oraConn.commit();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        try {
          // Get mySQL info
          sqlStmt = 
                  "SELECT insumo_oc_id, insumo_oc_det_id, importado_flag, mensaje_error \n" +
                  "FROM ADECO_BI.XX_AGRONOMO_EAM_OCI_INT\n" +
                  "WHERE importado_flag != 'Y'\n"
                  ;

          // System.out.println(sqlStmt);
          oraStmt = oraConn.createStatement();
          orars   = oraStmt.executeQuery(sqlStmt);                   
          while(orars.next()) {
            sqlStmt =
                    "UPDATE em_insumos_ocs_detalles\n"+
                    "SET oracle_flag = '"+orars.getString("importado_flag")+"'\n"+
                    "  , error_interfaces = '"+orars.getString("mensaje_error")+"'\n"+
                    "WHERE id = "+orars.getInt("insumo_oc_det_id");

            mySQLStmtUpd = mySQLConn.createStatement();
            mySQLStmtUpd.executeUpdate(sqlStmt);
            mySQLStmtUpd.close();
            row_count = row_count +1;
          }

          mySQLConn.commit();
          oraConn.commit();

          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        try { 
          mySQLConn.close();
          oraConn.close();
          } catch (SQLException e) {
            System.out.println(e.getMessage()+"\n"+sqlStmt);
        }

        if (row_count>0) System.out.println(row_count + " registros actualizados en Agronomo con errores."); 
        if (row_count==0) System.out.println("No se encontraron registros actualizados en Agronomo con errores."); 

    }
  }
}
