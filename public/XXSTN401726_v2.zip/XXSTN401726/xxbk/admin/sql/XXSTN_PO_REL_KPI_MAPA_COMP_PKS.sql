WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
create or replace PACKAGE XXSTN_PO_REL_KPI_MAPA_COMP_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PO_REL_KPI_MAPA_COMP_PKG.pls                              |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   PO - Relatorio KPI Compras - Mapa de Compras                  |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S    29/08/2019                  |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

TYPE rc_lin_tp IS RECORD
(
UNIDADE_OPERACIONAL hr_all_organization_units.name%type
,FORNECEDOR po_vendors.vendor_name%type
,CNPJ_CPF VARCHAR2(500)
,TIPO_PO VARCHAR2(100)
,COMPRADOR VARCHAR2(500)
,STATUS_PO VARCHAR2(100)
,NR_PO po_headers_all.segment1%type
,NR_RELEASE po_releases_all.release_num%type
,DATA_CRIACAO_PO date
,DATA_APROVACAO_PO  date
,DATA_INICIO_COMPETENCIA date
,DATA_FIM_COMPETENCIA date
,REQUISITANTE VARCHAR2(500)
,NR_REQUISICAO po_requisition_headers_all.segment1%type
,DATA_CRIACAO_REQ date
,DATA_APROVACAO_REQ date

,GLOBAL    VARCHAR2(100)
,TOTAL_ACORDO number
,DATA_INICIO date
,DATA_FIM date
,MOEDA VARCHAR2(100)
,COND_PAGTO VARCHAR2(100)
,NR_LINHA po_lines_all.line_num%type
,TIPO_LINHA po_line_types.line_type%type
,NOME_CATEGORIA mtl_categories.segment1%type
,NR_ITEM mtl_system_items_b.segment1%type
,DESCRICAO_ITEM po_lines_all.item_description%type
,NR_DISTRIBUICAO_CONTABIL po_distributions_all.distribution_num%type
,CENTRO_CUSTO gl_code_combinations.segment5%type
,DESCRICAO_CENTRO_CUSTO fnd_flex_values_vl.description%type
,APROVADOR_CC varchar2(200)
,UNIDADE_NEGOCIO gl_code_combinations.segment7%type
,DESCRICAO_UNIDADE_NEGOCIO fnd_flex_values_vl.description%type
,PRECO number
,QUANTIDADE po_lines_all.quantity%type
,QUANTIDADE_SOLICITADA po_lines_all.quantity%type
,QUANTIA_LANCADA_RI number
,LAST_RECEIPT date
,SALDO_RECEBIDO number
,LAST_PAYMENT date
,SALDO_FINANCEIRO number
,SALDO_RELEASE number
,OI_ENTREGA VARCHAR2(1000)
);

 PROCEDURE gen_rel_po_kpi_mapa_p (errbuf OUT VARCHAR2
                              ,retcode OUT NUMBER
                              --,P_EMPRESA IN VARCHAR2
                              ,P_DATA_DE IN VARCHAR2
                              ,P_DATA_ATE IN OUT VARCHAR2
                              );

 PROCEDURE show_error_log_p(p_message IN VARCHAR2);

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER;

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2;

 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2;

 PROCEDURE gen_xml_p(p_message IN VARCHAR2);

END XXSTN_PO_REL_KPI_MAPA_COMP_PKG;
/

EXIT;