WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
create or replace PACKAGE BODY XXSTN_PO_REL_KPI_MAPA_COMP_PKG AS
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_PO_REL_KPI_MAPA_COMP_PKG.pls                              |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   PO - Relatorio KPI Compras - Mapa de Compras                  |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S    29/08/2019                  |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

 --> Variaveis Globais:
 g_bShow_log          BOOLEAN := TRUE; -- FALSE;
 g_bGen_XML           BOOLEAN := FALSE;-- TRUE;

 PROCEDURE gen_rel_po_kpi_mapa_p (errbuf OUT VARCHAR2
                              ,retcode OUT NUMBER
                              --,P_EMPRESA IN VARCHAR2
                              ,P_DATA_DE IN VARCHAR2
                              ,P_DATA_ATE IN OUT VARCHAR2
                              ) IS

 CURSOR c_cc_aprov IS
  select distinct fnd.meaning
    from apps.fnd_lookup_values fnd
        ,apps.per_all_people_f  papf
    where fnd.attribute4  = papf.person_id
    and   fnd.lookup_type = 'STN_STONE_APPROVAL_REQ'
    and   papf.current_employee_flag     = 'Y'
    --and   trunc(papf.effective_end_date) = to_date('31/12/4712')--'31-dez-4712'
    and   fnd.language    = userenv('lang')
    --Cristiano em 28/02/2020
    --SR - 401726
    --and papf.person_id IN (select employee_id
    --                        from fnd_user
    --                        where user_id = FND_GLOBAL.USER_ID)
    --Fim
    order by fnd.meaning;

 CURSOR c_nao_aprov IS
  select distinct f.segment5
    from apps.per_all_people_f      a,
         apps.per_all_assignments_f c,
         apps.per_all_people_f      e,
         apps.gl_code_combinations  f,
         apps.gl_ledgers            g,
         apps.hr_locations          h,
         apps.per_all_positions     pos
   where a.person_id(+) = c.person_id
     and e.person_id = c.supervisor_id(+)
     and c.default_code_comb_id = f.code_combination_id(+)
     and c.set_of_books_id = g.ledger_id
     and c.location_id = h.location_id
     and c.position_id = pos.position_id(+)
        --and   trunc(c.effective_end_date) = to_date('31/12/4712')--'31-DEZ-4712'
     and c.primary_flag = 'Y'
     and a.effective_end_date =
         (select max(y.effective_end_date)
            from apps.per_all_people_f y
           where a.person_id = y.person_id)
     and e.effective_end_date =
         (select max(z.effective_end_date)
            from apps.per_all_people_f z
           where e.person_id = z.person_id)
     and c.effective_end_date =
         (select max(x.effective_end_date)
            from apps.per_all_assignments_f x
           where c.person_id = x.person_id)
     --AND a.person_id IN (select employee_id
     --                     from fnd_user
     --                     where user_id = FND_GLOBAL.USER_ID)
                          ;

 l_exec varchar2(500);
 l_capex_opex varchar2(50);
 l_numero_req po_requisition_headers_all.SEGMENT1%TYPE;
 l_exist_aprov varchar2(1);
 l_cc varchar2(4000);
 l_cont_aprov number;
 l_cont_nao_aprov number;
 l_user_id number;
 L_QUERY     VARCHAR2(32767);
 L_QUERY2     VARCHAR2(32767);
 --L_QUERY     long;
 rf_value    SYS_REFCURSOR;
 TYPE tp_value IS TABLE OF rc_lin_tp;
 lin_value tp_value;
 L_COST_CENTER varchar2(4000);
 l_cont_entr number;
 l_saldo_recebido number;
 l_saldo_financeiro number;
 l_saldo_release number;
 L_DATA_ATE DATE;

 BEGIN

  --> Ativa ou desativa o log de erros de acordo com o parametro
    /*IF p_show_log = 'Y' THEN
    g_bShow_log := TRUE;
  END IF;*/

  l_exec := 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS='',.''';

  execute immediate l_exec;

  show_error_log_p(p_message => 'Inicio do relatorio gen_rel_po_kpi_mapa_p');

  --verifica centro de custo
  l_user_id := FND_GLOBAL.USER_ID;

  l_exist_aprov := 'N';
  BEGIN

   Select 'X'
     Into l_exist_aprov
     From  apps.po_requisition_lines_all pql
          ,apps.po_req_distributions_all prq
          ,apps.gl_code_combinations gcc
          ,apps.fnd_lookup_values_vl flv
          ,apps.per_all_people_f     papf
    Where 1 = 1
      And pql.requisition_line_id = prq.requisition_line_id
      And prq.code_combination_id = gcc.code_combination_id
      and flv.attribute4          = papf.person_id
      And flv.lookup_type = 'STN_STONE_APPROVAL_REQ'
      And gcc.segment5 = flv.meaning
      --and flv.attribute4 IN (select employee_id
      --                        from fnd_user
      --                        where user_id = FND_GLOBAL.USER_ID)
      and rownum = 1;

   EXCEPTION
    WHEN OTHERS THEN
     l_exist_aprov := 'N';

  END;

  l_cont_entr := 0;
  IF l_exist_aprov = 'X' THEN

   l_cont_aprov := 0;
   FOR r_cc_aprov IN c_cc_aprov LOOP
   l_cont_entr := l_cont_entr + 1;

    IF l_cont_aprov = 0 THEN

     l_cc := r_cc_aprov.meaning;

     l_cont_aprov := l_cont_aprov + 1;

    ELSE

     l_cc := l_cc ||','||r_cc_aprov.meaning;

    END IF;

   END LOOP;

  ELSE

   l_cont_nao_aprov := 0;
   FOR r_nao_aprov IN c_nao_aprov LOOP
   l_cont_entr := l_cont_entr + 1;

    IF l_cont_nao_aprov = 0 THEN

     l_cc := r_nao_aprov.segment5;

     l_cont_nao_aprov := l_cont_nao_aprov + 1;

    ELSE

     l_cc := l_cc ||','||r_nao_aprov.segment5;

    END IF;

   END LOOP;

  END IF; --IF l_exist_aprov = 'X' THEN

  IF l_cont_entr = 0 THEN

   l_cc := '('||'000000000'||')';

  ELSIF l_cont_entr >= 1 THEN

   l_cc := '('||l_cc ||','|| '000000000'||')';
   --l_cc := '('||'307000001'||','||'307000004'||','||'307000005'||','||'307000006'||','||'1017450' ||','|| '000000000'||')';

  END IF;

  L_COST_CENTER := l_cc;

  fnd_file.put_line(fnd_file.log, 'Centro(s) de Custo(s): '||L_COST_CENTER);

  --show_error_log_p(p_message => 'P_DATA_ATE: '||P_DATA_ATE);

  --L_DATA_ATE := trunc(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'));

  --L_DATA_ATE := to_date(L_DATA_ATE||' 23:59:59','RRRR/MM/DD HH24:MI:SS');

  --show_error_log_p(p_message => 'L_DATA_ATE: '||L_DATA_ATE);

  P_DATA_ATE := REPLACE(P_DATA_ATE,'00:00:00','23:59:59');

  show_error_log_p(p_message => 'P_DATA_ATE: '||P_DATA_ATE);

  L_QUERY := 'select distinct hr.name                                                                    Unidade_Operacional
                 ,pv.vendor_name                                                             Fornecedor
                 ,(select case
                  when global_attribute9 = ''2'' then
                       global_attribute10 || ''/'' || global_attribute11 || ''-'' || global_attribute12
                  when global_attribute9 = ''3'' then
                       lpad(party_site_id,9,''0'') || ''/'' || global_attribute11 || ''-'' || global_attribute12
                  else
                       global_attribute10  || ''-'' || global_attribute12
                  end cnpj from apps.ap_supplier_sites_all x
                  where x.vendor_site_id = pvs.vendor_site_id)                               CNPJ_CPF

       ,decode(ph.type_lookup_code,''STANDARD'',''Ordem de Compra-Padrao''
                                  ,''BLANKET'' ,''Acordo de Compra em Aberto''
                                  ,''PLANNED'' ,''Ordem Compra Planejada''
                                  ,''CONTRACT'',''Acordo de Compra do Contrato'') Tipo_PO
       ,papf.first_name || '' '' || papf.last_name                                             Comprador

       ,decode(ph.authorization_status,''IN PROCESS'',''Em Andamento''
                                      ,''APPROVED''  ,''Aprovado''
                                      ,''INCOMPLETE'',''Incompleto''
                                      ,''REJECTED''  ,''Rejeitado''
                                      ,''REQUIRES REAPPROVAL'',''Exige Reaprovação''
                                      ,null        ,''Incompleto'')                           Status_PO

       ,ph.segment1                                                                          Nr_PO
       ,pr.release_num                                                                       Nr_Release

       ,ph.creation_date                                                                     Data_Criacao_PO
       ,ph.approved_date                                                                     Data_Aprovacao_PO
       ,FND_DATE.canonical_to_date(ph.attribute3)                                            Data_Inicio_Competencia
       ,FND_DATE.canonical_to_date(ph.attribute4)                                            Data_Fim_Competencia

       ,papf1.first_name || '' '' || papf1.last_name                                           Requisitante
       ,prh.segment1                                                                         Nr_Requisicao
       ,prh.creation_date                                                                    Data_Criacao_Req
       ,prh.approved_date                                                                    Data_Aprovacao_Req

       ,decode(ph.type_lookup_code,''STANDARD'',decode(ph.attribute2,''Y'',''PO Global'',''N'',''PO Spot'',null,''Nao se Aplica''),''BLANKET'',''BLANKET'') Global

       ,nvl(ph.blanket_total_amount,0)                                                       Total_Acordo

       ,ph.start_date                                                                        Data_Inicio
       ,ph.end_date                                                                          Data_Fim
       ,ph.currency_code                                                                     Moeda
       ,apt.name                                                                             Cond_Pagto

       ,pl.line_num                                                                          Nr_Linha
       ,plt.line_type                                                                        Tipo_Linha
       ,mc.segment1                                                                          Nome_Categoria

       , msi.segment1                                                                        Nr_Item
       , pl.item_description                                                                 Descricao_Item

       , pd.distribution_num                                                                 Nr_Distribuicao_Contabil

       ,gcccc.segment5                                                                       Centro_Custo

       ,ffvcc.description                                                                    Descricao_Centro_Custo
       --
       --Cristiano
       ,(select distinct --não filtrar data de efetividade para recuperar funcionatios inativos
               papf.full_name
        from --apps.per_all_people_f papf,
             apps.per_people_v7 papf,
             apps.po_action_history pah
        where 1 = 1
          and pah.object_id = prh.requisition_header_id
          and pah.object_type_code = ''REQUISITION''
          and pah.object_sub_type_code = ''PURCHASE''
          and pah.action_code = ''APPROVE''
          and pah.employee_id = papf.person_id
          and pah.sequence_num = (select max(x.sequence_num)
                                  from apps.po_action_history x
                                  where 1 = 1
                                    and x.object_id = pah.object_id
                                    and x.object_type_code = ''REQUISITION''
                                    and x.object_sub_type_code = ''PURCHASE''
                                    and x.action_code = ''APPROVE''
                                    and nvl(x.approval_group_id,-1) != 26041)
          )  aprovador_cc
       --
       , gcc.segment7                                                                        Unidade_Negocio

       , ffv.description                                                                     Descricao_Unidade_Negocio

       ,pl.unit_price                                                                        Preco
       ,pl.quantity                                                                          Quantidade
       ,pd.quantity_ordered                                                                  quantidade_solicitada

       , pd.quantity_delivered * pl.unit_price                                               Quantia_Lancada_RI
       --
       --Cristiano
       ,(select max(trunc(reo.receive_date))
         from apps.cll_f189_entry_operations reo,
              apps.cll_f189_invoices ri,
              apps.cll_f189_invoice_lines ril
         where 1 = 1
           and ril.line_location_id = pll.line_location_id
           and ril.invoice_id = ri.invoice_id
           and ri.operation_id = reo.operation_id
           and ri.organization_id = reo.organization_id) last_receipt
       --
       , decode(ph.type_lookup_code,''BLANKET'',nvl((select sum(nvl(ph.blanket_total_amount,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id
         and   pra.po_release_id = pr.po_release_id) -
        (select sum(nvl(pl.unit_price,0) * nvl(pd.quantity_ordered,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id),0),((nvl(pd.quantity_ordered,0) * pl.unit_price) - (pl.unit_price * nvl(pd.quantity_delivered,0)))) Saldo_Recebido
       --
       --Cristiano
       ,(select  max (aca.check_date)
         from apps.ap_checks_all aca,
              apps.ap_invoice_payments_all aip ,
              apps.ap_invoice_lines_all aila
         where 1 = 1
           and aca.check_id = aip.check_id
           and nvl(aip.reversal_flag,''N'') = ''N''
           and aip.invoice_id = aila.invoice_id
           and aila.line_type_lookup_code = ''ITEM''
           and aila.po_header_id = ph.po_header_id) last_payment
        --
       , decode(ph.type_lookup_code,''BLANKET'',nvl((select sum(nvl(ph.blanket_total_amount,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id
         and   pra.po_release_id = pr.po_release_id) -
        (select sum(nvl(pl.unit_price,0) * nvl(pd.quantity_ordered,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id),0),((nvl(pd.quantity_ordered,0) * pl.unit_price) - (pl.unit_price * nvl(pd.amount_billed,0))))  Saldo_Financeiro

       , nvl((select sum(nvl(ph.blanket_total_amount,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id
         and   pra.po_release_id = pr.po_release_id) -
        (select sum(nvl(pl.unit_price,0) * nvl(pd.quantity_ordered,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id),0) Saldo_Release

       , mp.organization_code||''-''||hl.location_code                                         OI_Entrega

  from apps.hr_all_organization_units    hr
     , apps.hr_locations                 hl
     , apps.org_organization_definitions mp
     , apps.ap_suppliers                 pv
     , apps.ap_supplier_sites_all        pvs
     , apps.po_headers_all               ph
     , apps.po_lines_all                 pl
     , apps.po_line_locations_all        pll
     , apps.po_distributions_all         pd
     , apps.po_releases_all              pr
     , apps.po_line_types                plt
     , apps.ap_terms                     apt
     , apps.mtl_system_items             msi
     , apps.mtl_categories               mc
     , apps.po_agents                    pa
     , apps.per_all_people_f             papf
     , apps.per_all_people_f             papf1
     , apps.po_requisition_headers_all   prh
     , apps.po_requisition_lines_all     prl
     , apps.po_req_distributions_all     prd
     , apps.gl_code_combinations         gcc
     , apps.fnd_flex_value_sets          ffvs
     , apps.fnd_flex_values_vl           ffv
     , apps.gl_code_combinations         gcccc
     , apps.fnd_flex_value_sets          ffvscc
     , apps.fnd_flex_values_vl           ffvcc
  where ph.org_id             = hr.organization_id
    and ph.po_header_id       = pl.po_header_id
    and ph.po_header_id       = pll.po_header_id
    --Cristiano
    and ph.vendor_id not in (select flv.attribute1
                            from apps.FND_LOOKUP_VALUES_VL flv,
                                 apps.FND_LOOKUP_TYPES_VL flt
                            where 1 = 1
                              and flt.lookup_type = ''XXSTN_BUYER_NOT_IN''
                              and flt.lookup_type = flv.lookup_type)
    --
    and ph.po_header_id       = pd.po_header_id
    and pr.po_header_id(+)    = ph.po_header_id
    and pl.po_line_id         = pll.po_line_id
    and pl.po_line_id         = pd.po_line_id
    and pll.line_location_id  = pd.line_location_id
    and ph.vendor_id          = pv.vendor_id
    and ph.vendor_site_id     = pvs.vendor_site_id
    and pvs.vendor_id         = pv.vendor_id
    and ph.terms_id           = apt.term_id
    and pl.line_type_id       = plt.line_type_id
    and pl.item_id            = msi.inventory_item_id
    and pl.category_id        = mc.category_id
    and pa.agent_id           = ph.agent_id
    and pa.agent_id           = papf.person_id
    and papf.effective_end_date =  (select max(y.effective_end_date)
                                    from apps.per_all_people_f y
                                    where papf.person_id = y.person_id)
    and prh.preparer_id       = papf1.person_id
    and papf1.effective_end_date = (select max(y.effective_end_date)
                                    from apps.per_all_people_f y
                                    where papf1.person_id = y.person_id)
    and prh.preparer_id       = papf1.person_id
    and hl.location_id        = ph.ship_to_location_id
    and msi.organization_id   = pll.ship_to_organization_id
    and mp.organization_id    = msi.organization_id
    and pd.code_combination_id    = gcc.code_combination_id
    and ffv.flex_value_set_id     = ffvs.flex_value_set_id
    and gcc.segment7              = ffv.flex_value
    and ffvs.flex_value_set_id    = 1017448                    ------> Unidade Negocio

    and pd.code_combination_id      = gcccc.code_combination_id
    and ffvcc.flex_value_set_id     = ffvscc.flex_value_set_id
    and gcccc.segment5              = ffvcc.flex_value
    and nvl(pll.po_release_id,1)  = nvl (pr.po_release_id, 1)
    and prh.requisition_header_id = prl.requisition_header_id
    and prl.requisition_line_id   = prd.requisition_line_id
    and prd.distribution_id       = pd.req_distribution_id(+)
    and nvl(ph.cancel_flag,''N'')   = ''N''
    and nvl(ph.closed_code,''OPEN'')!= ''FINALLY CLOSED''
    and ffvscc.flex_value_set_id    = 1017450
    --
    and ph.creation_date between NVL(to_date(to_date('''||P_DATA_DE||''',''RRRR/MM/DD HH24:MI:SS''),''DD/MM/RRRR''),TRUNC(ph.CREATION_DATE))
                              and to_date('''||P_DATA_ATE||''',''RRRR/MM/DD HH24:MI:SS'')

    and gcccc.segment5    IN '||L_COST_CENTER||'
    union ';
l_query2 := '
  select distinct hr.name                                                                    Unidade_Operacional
                 ,pv.vendor_name                                                             Fornecedor
                 ,(select case
                  when global_attribute9 = ''2'' then
                       global_attribute10 || ''/'' || global_attribute11 || ''-'' || global_attribute12
                  when global_attribute9 = ''3'' then
                       lpad(party_site_id,9,''0'') || ''/'' || global_attribute11 || ''-'' || global_attribute12
                  else
                       global_attribute10  || ''-'' || global_attribute12
                  end cnpj from apps.ap_supplier_sites_all x
                  where x.vendor_site_id = pvs.vendor_site_id)                               CNPJ_CPF
       ,decode(ph.type_lookup_code,''STANDARD'',''Ordem de Compra-Padrao''
                                  ,''BLANKET'' ,''Acordo de Compra em Aberto''
                                  ,''PLANNED'' ,''Ordem Compra Planejada''
                                  ,''CONTRACT'',''Acordo de Compra do Contrato'') Tipo_PO
       ,papf.first_name || '' '' || papf.last_name                                             Comprador

       ,decode(ph.authorization_status,''IN PROCESS'',''Em Andamento''
                                      ,''APPROVED''  ,''Aprovado''
                                      ,''INCOMPLETE'',''Incompleto''
                                      ,''REJECTED''  ,''Rejeitado''
                                      ,''REQUIRES REAPPROVAL'',''Exige Reaprovacao''
                                      ,null        ,''Incompleto'')                           Status_PO

       ,ph.segment1                                                                          Nr_PO
       ,pr.release_num                                                                       Nr_Release

       ,ph.creation_date                                                                     Data_Criacao_PO
       ,ph.approved_date                                                                     Data_Aprovacao_PO
       ,FND_DATE.canonical_to_date(ph.attribute3)                                            Data_Inicio_Competencia
       ,FND_DATE.canonical_to_date(ph.attribute4)                                            Data_Fim_Competencia

       ,null                                                                                 Requisitante
       ,null                                                                                 Nr_Requisicao
       ,null                                                                                 Data_Criacao_Req
       ,null                                                                                 Data_Aprovacao_Req

       ,decode(ph.type_lookup_code,''STANDARD'',decode(ph.attribute2,''Y'',''PO Global'',''N'',''PO Spot'',null,''Nao se Aplica''),''BLANKET'',''BLANKET'') Global

       ,nvl(ph.blanket_total_amount,0)                                                       Total_Acordo

       ,ph.start_date                                                                        Data_Inicio
       ,ph.end_date                                                                          Data_Fim
       ,ph.currency_code                                                                     Moeda
       ,apt.name                                                                             Cond_Pagto

       ,pl.line_num                                                                          Nr_Linha
       ,plt.line_type                                                                        Tipo_Linha
       ,mc.segment1                                                                          Nome_Categoria

       , msi.segment1                                                                        Nr_Item
       , pl.item_description                                                                 Descricao_Item

       , pd.distribution_num                                                                 Nr_Distribuicao_Contabil

       ,gcccc.segment5                                                                       Centro_Custo

       ,ffvcc.description                                                                    Descricao_Centro_Custo
       --
       --Cristiano
       ,(select distinct --não filtrar data de efetividade para recuperar funcionatios inativos
               papf.full_name
        from apps.per_all_people_f papf,
             apps.po_action_history pah
        where 1 = 1
          and pah.object_id = ph.po_header_id
          and pah.object_type_code = ''PO''
          and pah.object_sub_type_code = ''STANDARD''
          and pah.action_code = ''APPROVE''
          and pah.employee_id = papf.person_id
          and pah.sequence_num = (select max(x.sequence_num)
                                  from apps.po_action_history x
                                  where 1 = 1
                                    and x.object_id = pah.object_id
                                    and x.object_type_code = ''PO''
                                    and x.object_sub_type_code = ''STANDARD''
                                    and x.action_code = ''APPROVE''
                                    )) aprovador_cc
       --
       , gcc.segment7                                                                        Unidade_Negocio

       , ffv.description                                                                     Descricao_Unidade_Negocio

       ,pl.unit_price                                                                        Preco
       ,pl.quantity                                                                          Quantidade
       ,pd.quantity_ordered                                                                  quantidade_solicitada

       , pd.quantity_delivered * pl.unit_price                                               Quantia_Lancada_RI
       --
       --Cristiano
       ,(select max(trunc(reo.receive_date))
         from apps.cll_f189_entry_operations reo,
              apps.cll_f189_invoices ri,
              apps.cll_f189_invoice_lines ril
         where 1 = 1
           and ril.line_location_id = pll.line_location_id
           and ril.invoice_id = ri.invoice_id
           and ri.operation_id = reo.operation_id
           and ri.organization_id = reo.organization_id) last_receipt
       --
       , decode(ph.type_lookup_code,''BLANKET'',nvl((select sum(nvl(ph.blanket_total_amount,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id
         and   pra.po_release_id = pr.po_release_id) -
        (select sum(nvl(pl.unit_price,0) * nvl(pd.quantity_ordered,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id),0),((nvl(pd.quantity_ordered,0) * pl.unit_price) - (pl.unit_price * nvl(pd.quantity_delivered,0)))) Saldo_Recebido
       --
       --Cristiano
       ,(select  max (aca.check_date)
         from apps.ap_checks_all aca,
              apps.ap_invoice_payments_all aip ,
              apps.ap_invoice_lines_all aila
         where 1 = 1
           and aca.check_id = aip.check_id
           and nvl(aip.reversal_flag,''N'') = ''N''
           and aip.invoice_id = aila.invoice_id
           and aila.line_type_lookup_code = ''ITEM''
           and aila.po_header_id = ph.po_header_id) last_payment
        --
       , decode(ph.type_lookup_code,''BLANKET'',nvl((select sum(nvl(ph.blanket_total_amount,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id
         and   pra.po_release_id = pr.po_release_id) -
        (select sum(nvl(pl.unit_price,0) * nvl(pd.quantity_ordered,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id),0),((nvl(pd.quantity_ordered,0) * pl.unit_price) - (pl.unit_price * nvl(pd.amount_billed,0))))  Saldo_Financeiro

       , (select sum(nvl(ph.blanket_total_amount,0))
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id
         and   pra.po_release_id = pr.po_release_id) -
         (select nvl(sum(nvl(pl.unit_price,0) * nvl(pd.quantity_ordered,0)),0)
         from apps.po_headers_all        pha
             ,apps.po_lines_all          pla
             ,apps.po_line_locations_all plla
             ,apps.po_releases_all       pra
         where pha.po_header_id   = pla.po_header_id
         and   pha.po_header_id   = plla.po_header_id
         and   pla.po_line_id     = plla.po_line_id
         and   plla.po_release_id = pra.po_release_id
         and   pra.authorization_status = ''APPROVED''
         and   pha.po_header_id = ph.po_header_id) Saldo_Release

       , mp.organization_code||''-''||hl.location_code                                         OI_Entrega

  from apps.hr_all_organization_units    hr
     , apps.hr_locations                 hl
     , apps.org_organization_definitions mp
     , apps.ap_suppliers                 pv
     , apps.ap_supplier_sites_all        pvs
     , apps.po_headers_all               ph
     , apps.po_lines_all                 pl
     , apps.po_line_locations_all        pll
     , apps.po_distributions_all         pd
     , apps.po_releases_all              pr
     , apps.po_line_types                plt
     , apps.ap_terms                     apt
     , apps.mtl_system_items             msi
     , apps.mtl_categories               mc
     , apps.po_agents                    pa
     , apps.per_all_people_f             papf
     , apps.gl_code_combinations         gcc
     , apps.fnd_flex_value_sets          ffvs
     , apps.fnd_flex_values_vl           ffv
     , apps.gl_code_combinations         gcccc
     , apps.fnd_flex_value_sets          ffvscc
     , apps.fnd_flex_values_vl           ffvcc
  where ph.org_id             = hr.organization_id
    and ph.po_header_id       = pl.po_header_id
    and ph.po_header_id       = pll.po_header_id
    --Cristiano
    and ph.vendor_id not in (select flv.attribute1
                            from apps.FND_LOOKUP_VALUES_VL flv,
                                 apps.FND_LOOKUP_TYPES_VL flt
                            where 1 = 1
                              and flt.lookup_type = ''XXSTN_BUYER_NOT_IN''
                              and flt.lookup_type = flv.lookup_type)
    and ph.po_header_id       = pd.po_header_id
    and pr.po_header_id(+)    = ph.po_header_id
    and pl.po_line_id         = pll.po_line_id
    and pl.po_line_id         = pd.po_line_id
    and pll.line_location_id  = pd.line_location_id
    and ph.vendor_id          = pv.vendor_id
    and ph.vendor_site_id     = pvs.vendor_site_id
    and pvs.vendor_id         = pv.vendor_id
    and ph.terms_id           = apt.term_id
    and pl.line_type_id       = plt.line_type_id
    and pl.item_id            = msi.inventory_item_id
    and pl.category_id        = mc.category_id
    and pa.agent_id           = ph.agent_id
    and pa.agent_id           = papf.person_id
    and papf.effective_end_date =  (select max(y.effective_end_date)
                                    from apps.per_all_people_f y
                                    where papf.person_id = y.person_id)
    and hl.location_id        = ph.ship_to_location_id
    and msi.organization_id   = pll.ship_to_organization_id
    and mp.organization_id    = msi.organization_id
    and pd.code_combination_id    = gcc.code_combination_id
    and ffv.flex_value_set_id     = ffvs.flex_value_set_id
    and gcc.segment7              = ffv.flex_value
    and ffvs.flex_value_set_id    = 1017448                    ------> Unidade Negocio

    and pd.code_combination_id      = gcccc.code_combination_id
    and ffvcc.flex_value_set_id     = ffvscc.flex_value_set_id
    and gcccc.segment5              = ffvcc.flex_value
    and ffvscc.flex_value_set_id    = 1017450
    and pd.req_distribution_id is null

    and nvl(pll.po_release_id,1)  = nvl (pr.po_release_id, 1)

    and nvl(ph.cancel_flag,''N'')   = ''N''
    and nvl(ph.closed_code,''OPEN'')!= ''FINALLY CLOSED''
    and ph.creation_date between NVL(to_date(to_date('''||P_DATA_DE||''',''RRRR/MM/DD HH24:MI:SS''),''DD/MM/RRRR''),TRUNC(ph.CREATION_DATE))
                              and to_date('''||P_DATA_ATE||''',''RRRR/MM/DD HH24:MI:SS'')

    and gcccc.segment5    IN '||L_COST_CENTER||'
  order by 1,7,23';

  --show_error_log_p(p_message => 'L_QUERY: '||L_QUERY);

  --gen_xml_p('<?xml version="1.0" encoding="UTF-8"?>');
  gen_xml_p('<?xml version="1.0" encoding="ISO-8859-1"?>');
  gen_xml_p('<HEADERS>');

  gen_xml_p(' <HEADER>');

  --gen_xml_p('    <EMPRESA>'  || P_EMPRESA ||'</EMPRESA>');
  gen_xml_p('    <DATA_REQ_DE>'  || to_char(to_date(P_DATA_DE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR') ||'</DATA_REQ_DE>');
  gen_xml_p('    <DATA_REQ_ATE>'  || to_char(to_date(P_DATA_ATE,'RRRR/MM/DD HH24:MI:SS'),'DD/MM/RRRR')  ||'</DATA_REQ_ATE>');
  --
  fnd_file.put_line(fnd_file.log, 'l_query '||L_QUERY||l_query2);
  --
  OPEN rf_value FOR L_QUERY||l_query2;
  FETCH rf_value BULK COLLECT INTO lin_value;
  CLOSE rf_value;

  IF lin_value.count > 0 THEN

   FOR i IN lin_value.first..lin_value.last LOOP

   gen_xml_p('   <LINES_KPI>');

    gen_xml_p('    <UNIDADE_OPERACIONAL>'  || conv_spc_chr(lin_value(i).UNIDADE_OPERACIONAL) ||'</UNIDADE_OPERACIONAL>');
    gen_xml_p('    <FORNECEDOR>'  || conv_spc_chr(lin_value(i).FORNECEDOR) ||'</FORNECEDOR>');
    gen_xml_p('    <CNPJ_CPF>'  || conv_spc_chr(lin_value(i).CNPJ_CPF) ||'</CNPJ_CPF>');
    gen_xml_p('    <TIPO_PO>'  || conv_spc_chr(lin_value(i).TIPO_PO) ||'</TIPO_PO>');
    gen_xml_p('    <COMPRADOR>'  || conv_spc_chr(lin_value(i).COMPRADOR) ||'</COMPRADOR>');
    gen_xml_p('    <STATUS_PO>'  || conv_spc_chr(lin_value(i).STATUS_PO) ||'</STATUS_PO>');
    gen_xml_p('    <NR_PO>'  || conv_spc_chr(lin_value(i).NR_PO) ||'</NR_PO>');
    gen_xml_p('    <NR_RELEASE>'  || conv_spc_chr(lin_value(i).NR_RELEASE) ||'</NR_RELEASE>');
    gen_xml_p('    <DATA_CRIACAO_PO>'  || TO_CHAR(lin_value(i).DATA_CRIACAO_PO,'DD/MM/RRRR') ||'</DATA_CRIACAO_PO>');
    gen_xml_p('    <DATA_APROVACAO_PO>'  || TO_CHAR(lin_value(i).DATA_APROVACAO_PO,'DD/MM/RRRR') ||'</DATA_APROVACAO_PO>');
    gen_xml_p('    <DATA_INICIO_COMPETENCIA>'  || TO_CHAR(lin_value(i).DATA_INICIO_COMPETENCIA,'DD/MM/RRRR') ||'</DATA_INICIO_COMPETENCIA>');
    gen_xml_p('    <DATA_FIM_COMPETENCIA>'  || TO_CHAR(lin_value(i).DATA_FIM_COMPETENCIA,'DD/MM/RRRR') ||'</DATA_FIM_COMPETENCIA>');
    gen_xml_p('    <REQUISITANTE>'  || conv_spc_chr(lin_value(i).REQUISITANTE) ||'</REQUISITANTE>');
    gen_xml_p('    <NR_REQUISICAO>'  || conv_spc_chr(lin_value(i).NR_REQUISICAO) ||'</NR_REQUISICAO>');
    gen_xml_p('    <DATA_CRIACAO_RQ>'  || TO_CHAR(lin_value(i).DATA_CRIACAO_REQ,'DD/MM/RRRR') ||'</DATA_CRIACAO_RQ>');
    gen_xml_p('    <DATA_APROVACAO_RQ>'  || TO_CHAR(lin_value(i).DATA_APROVACAO_REQ,'DD/MM/RRRR') ||'</DATA_APROVACAO_RQ>');
    --Cristiano
    gen_xml_p('    <APROVADOR_CC>'  || conv_spc_chr(lin_value(i).APROVADOR_CC) ||'</APROVADOR_CC>');
    --
    gen_xml_p('    <GLOBAL>'  || conv_spc_chr(lin_value(i).GLOBAL) ||'</GLOBAL>');
    gen_xml_p('    <TOTAL_ACORDO>'  || LTRIM(TO_CHAR(conv_spc_chr(lin_value(i).TOTAL_ACORDO),'999G999G990D00')) ||'</TOTAL_ACORDO>');
    gen_xml_p('    <DATA_INICIO>'  || TO_CHAR(lin_value(i).DATA_INICIO,'DD/MM/RRRR') ||'</DATA_INICIO>');
    gen_xml_p('    <DATA_FIM>'  || TO_CHAR(lin_value(i).DATA_FIM,'DD/MM/RRRR') ||'</DATA_FIM>');
    gen_xml_p('    <MOEDA>'  || conv_spc_chr(lin_value(i).MOEDA) ||'</MOEDA>');
    gen_xml_p('    <COND_PAGTO>'  || conv_spc_chr(lin_value(i).COND_PAGTO) ||'</COND_PAGTO>');
    gen_xml_p('    <NR_LINHA>'  || conv_spc_chr(lin_value(i).NR_LINHA) ||'</NR_LINHA>');
    gen_xml_p('    <TIPO_LINHA>'  || conv_spc_chr(lin_value(i).TIPO_LINHA) ||'</TIPO_LINHA>');
    gen_xml_p('    <NOME_CATEGORIA>'  || conv_spc_chr(lin_value(i).NOME_CATEGORIA) ||'</NOME_CATEGORIA>');
    gen_xml_p('    <NR_ITEM>'  || conv_spc_chr(lin_value(i).NR_ITEM) ||'</NR_ITEM>');
    gen_xml_p('    <DESCRICAO_ITEM>'  || conv_spc_chr(lin_value(i).DESCRICAO_ITEM) ||'</DESCRICAO_ITEM>');
    gen_xml_p('    <NR_DISTRIBUICAO_CONTABIL>'  || conv_spc_chr(lin_value(i).NR_DISTRIBUICAO_CONTABIL) ||'</NR_DISTRIBUICAO_CONTABIL>');
    gen_xml_p('    <CENTRO_CUSTO>'  || conv_spc_chr(lin_value(i).CENTRO_CUSTO) ||'</CENTRO_CUSTO>');
    gen_xml_p('    <DESCRICAO_CENTRO_CUSTO>'  || conv_spc_chr(lin_value(i).DESCRICAO_CENTRO_CUSTO) ||'</DESCRICAO_CENTRO_CUSTO>');
    gen_xml_p('    <UNIDADE_NEGOCIO>'  || conv_spc_chr(lin_value(i).UNIDADE_NEGOCIO) ||'</UNIDADE_NEGOCIO>');
    gen_xml_p('    <DESCRICAO_UNIDADE_NEGOCIO>'  || conv_spc_chr(lin_value(i).DESCRICAO_UNIDADE_NEGOCIO) ||'</DESCRICAO_UNIDADE_NEGOCIO>');
    gen_xml_p('    <PRECO>'  || LTRIM(TO_CHAR(conv_spc_chr(lin_value(i).PRECO),'999G999G990D00')) ||'</PRECO>');
    gen_xml_p('    <QUANTIDADE>'  || conv_spc_chr(lin_value(i).QUANTIDADE) ||'</QUANTIDADE>');
    gen_xml_p('    <QUANTIDADE_SOLICITADA>'  || conv_spc_chr(lin_value(i).QUANTIDADE_SOLICITADA) ||'</QUANTIDADE_SOLICITADA>');
    gen_xml_p('    <QUANTIA_LANCADA_RI>'  || conv_spc_chr(lin_value(i).QUANTIA_LANCADA_RI) ||'</QUANTIA_LANCADA_RI>');
    --Cristiano
    gen_xml_p('    <LAST_RECEIPT>'  || conv_spc_chr(TO_CHAR(lin_value(i).LAST_RECEIPT,'DD/MM/RRRR')) ||'</LAST_RECEIPT>');
    --

    IF lin_value(i).SALDO_RECEBIDO < 0 THEN

     l_saldo_recebido := lin_value(i).SALDO_RECEBIDO * -1;

    ELSE

     l_saldo_recebido := lin_value(i).SALDO_RECEBIDO;

    END IF;

    IF lin_value(i).SALDO_RELEASE < 0 THEN

     l_saldo_release := lin_value(i).SALDO_RELEASE * -1;

    ELSE

     l_saldo_release := lin_value(i).SALDO_RELEASE;

    END IF;

    IF lin_value(i).SALDO_FINANCEIRO < 0 THEN

     l_saldo_financeiro := lin_value(i).SALDO_FINANCEIRO * -1;

    ELSE

     l_saldo_financeiro := lin_value(i).SALDO_FINANCEIRO;

    END IF;

    gen_xml_p('    <SADO_RECEBIDO>'  || LTRIM(TO_CHAR(conv_spc_chr(l_saldo_recebido),'999G999G990D00')) ||'</SADO_RECEBIDO>');
    --Cristiano
    gen_xml_p('    <LAST_PAYMENT>'  || TO_CHAR(lin_value(i).LAST_PAYMENT,'DD/MM/RRRR') ||'</LAST_PAYMENT>');
    --
    gen_xml_p('    <SADO_FINANCEIRO>'  || LTRIM(TO_CHAR(conv_spc_chr(l_saldo_financeiro),'999G999G990D00')) ||'</SADO_FINANCEIRO>');
    gen_xml_p('    <SADO_RELEASE>'  || LTRIM(TO_CHAR(conv_spc_chr(l_saldo_release),'999G999G990D00')) ||'</SADO_RELEASE>');
    gen_xml_p('    <OI_ENTREGA>'  || conv_spc_chr(lin_value(i).OI_ENTREGA) ||'</OI_ENTREGA>');

   gen_xml_p('   </LINES_KPI>');

  END LOOP;

  END IF;

  gen_xml_p(' </HEADER>');

  gen_xml_p('</HEADERS>');

 END gen_rel_po_kpi_mapa_p;

 PROCEDURE show_error_log_p(p_message IN VARCHAR2) IS
 BEGIN
  IF g_bShow_log THEN
    fnd_file.put_line(fnd_file.log, p_message);
  END IF;
 END show_error_log_p;

 FUNCTION canonical_to_number_f(p_value VARCHAR2) RETURN NUMBER IS

  l_vDecimal_char VARCHAR2(1);

 BEGIN
  --> Recupera o character decimal
  l_vDecimal_char := substr(ltrim(to_char(.3, '0D0')), 2, 1);

  --> Transforma o varchar para um nÿºmero com um decimal vÿ¡lido
  IF l_vDecimal_char = ',' THEN
    RETURN round(to_number(translate(p_value, '.', l_vDecimal_char)), 20);
  ELSE
    RETURN round(to_number(translate(p_value, ',', l_vDecimal_char)), 20);
  END IF;

 END canonical_to_number_f;
 --

 FUNCTION format_br_mask_f(p_value IN NUMBER
                        , p_mask  IN VARCHAR2) RETURN VARCHAR2 IS

  l_vReturn      VARCHAR2(20);
  l_nDecimal_qty NUMBER;
  l_nMask_qty    NUMBER;
  l_vMask        VARCHAR2(100);

 BEGIN

  l_vMask := p_mask;
  l_nMask_qty := length(substr(l_vMask, instr(l_vMask, '.') + 1));

  --> Verifica se deve criar uma mÿ¡scara com mais de 3 decimais- INICIO
  IF l_nMask_qty > 3 THEN

    --> Verifica se hÿ¡ decimais no valor - INICIO
    IF instr(to_char(translate(p_value, ',', '.')), '.') = 0 THEN
      l_nDecimal_qty := 0;
    ELSE
      --> Armazena a quantidade de digitos de decimais
      l_nDecimal_qty := length(substr(to_char(translate(p_value, ',', '.')), instr(to_char(translate(p_value, ',', '.')), '.') + 1));
    END IF;

    --> Verifica se a mascara retornou menos que 2
    IF l_nDecimal_qty <= 2 THEN
      l_nDecimal_qty := 2;
    END IF;

    --> Gera uma novas mÿ¡scara com a quantidade de decimais necessÿ¡rias
    l_vMask := substr(l_vMask, 1,  instr(l_vMask, '.')) || rpad('0', l_nDecimal_qty, '0');

  END IF;

  l_vReturn := lpad(to_char(p_value, l_vMask), 20, ' ');
  l_vReturn := REPLACE( l_vReturn, ',', '@' );
  l_vReturn := REPLACE( l_vReturn, '.', ',' );
  l_vReturn := REPLACE( l_vReturn, '@', '.' );

  RETURN(trim(l_vReturn));

 END format_br_mask_f;
 --

 -- Funÿ§ÿ£o que retorna valor por extenso:
 FUNCTION extenso_monetario_f(valor NUMBER) RETURN VARCHAR2 IS

  valor_string VARCHAR2(256);
  valor_conv   VARCHAR2(25);
  tres_digitos VARCHAR2(3);
  texto_string VARCHAR2(256);
  ind          NUMBER;

 BEGIN
  valor_conv := to_char(trunc((abs(valor) * 100)
                             ,0)
                       ,'0999999999999999999');
  valor_conv := substr(valor_conv
                      ,1
                      ,18) || '0' || substr(valor_conv
                                           ,19
                                           ,2);
  IF to_number(valor_conv) = 0 THEN
    RETURN('Zero ');
  END IF;

  FOR ind IN 1 .. 7 LOOP
    tres_digitos := substr(valor_conv
                          ,(((ind - 1) * 3) + 1)
                          ,3);
    texto_string := '';

    -- Extenso para Centena
    IF substr(tres_digitos
             ,1
             ,1) = '2' THEN
      texto_string := texto_string || 'Duzentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '3' THEN
      texto_string := texto_string || 'Trezentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '4' THEN
      texto_string := texto_string || 'Quatrocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '5' THEN
      texto_string := texto_string || 'Quinhentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '6' THEN
      texto_string := texto_string || 'Seiscentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '7' THEN
      texto_string := texto_string || 'Setecentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitocentos ';
    ELSIF substr(tres_digitos
                ,1
                ,1) = '9' THEN
      texto_string := texto_string || 'Novecentos ';
    END IF;

    IF substr(tres_digitos
             ,1
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,2
               ,2) = '00' THEN
        texto_string := texto_string || 'Cem ';
      ELSE
        texto_string := texto_string || 'Cento ';
      END IF;

    END IF;
    -- Extenso para Dezena
    IF substr(tres_digitos
             ,2
             ,1) <> '0'
       AND texto_string IS NOT NULL THEN
      texto_string := texto_string || 'e ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '2' THEN
      texto_string := texto_string || 'Vinte ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '3' THEN
      texto_string := texto_string || 'Trinta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '4' THEN
      texto_string := texto_string || 'Quarenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '5' THEN
      texto_string := texto_string || 'Cinquenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '6' THEN
      texto_string := texto_string || 'Sessenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '7' THEN
      texto_string := texto_string || 'Setenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '8' THEN
      texto_string := texto_string || 'Oitenta ';
    ELSIF substr(tres_digitos
                ,2
                ,1) = '9' THEN
      texto_string := texto_string || 'Noventa ';
    END IF;

    IF substr(tres_digitos
             ,2
             ,1) = '1' THEN

      IF substr(tres_digitos
               ,3
               ,1) <> '0' THEN

        IF substr(tres_digitos
                 ,3
                 ,1) = '1' THEN
          texto_string := texto_string || 'Onze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '2' THEN
          texto_string := texto_string || 'Doze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '3' THEN
          texto_string := texto_string || 'Treze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '4' THEN
          texto_string := texto_string || 'Quatorze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '5' THEN
          texto_string := texto_string || 'Quinze ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '6' THEN
          texto_string := texto_string || 'Dezesseis ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '7' THEN
          texto_string := texto_string || 'Dezessete ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '8' THEN
          texto_string := texto_string || 'Dezoito ';
        ELSIF substr(tres_digitos
                    ,3
                    ,1) = '9' THEN
          texto_string := texto_string || 'Dezenove ';
        END IF;

      ELSE
        texto_string := texto_string || 'Dez ';
      END IF;

    ELSE

      -- Extenso para Unidade
      IF substr(tres_digitos
               ,3
               ,1) <> '0'
         AND texto_string IS NOT NULL THEN
        texto_string := texto_string || 'e ';
      END IF;

      IF substr(tres_digitos
               ,3
               ,1) = '1' THEN
        texto_string := texto_string || 'Um ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '2' THEN
        texto_string := texto_string || 'Dois ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '3' THEN
        texto_string := texto_string || 'Tres ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '4' THEN
        texto_string := texto_string || 'Quatro ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '5' THEN
        texto_string := texto_string || 'Cinco ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '6' THEN
        texto_string := texto_string || 'Seis ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '7' THEN
        texto_string := texto_string || 'Sete ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '8' THEN
        texto_string := texto_string || 'Oito ';
      ELSIF substr(tres_digitos
                  ,3
                  ,1) = '9' THEN
        texto_string := texto_string || 'Nove ';
      END IF;

    END IF;

    IF to_number(tres_digitos) > 0 THEN
      IF to_number(tres_digitos) = 1 THEN
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhÿ£o ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhÿ£o ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhÿ£o ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhÿ£o ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      ELSE
        IF ind = 1 THEN
          texto_string := texto_string || 'Quatrilhÿµes ';
        ELSIF ind = 2 THEN
          texto_string := texto_string || 'Trilhÿµes ';
        ELSIF ind = 3 THEN
          texto_string := texto_string || 'Bilhÿµes ';
        ELSIF ind = 4 THEN
          texto_string := texto_string || 'Milhÿµes ';
        ELSIF ind = 5 THEN
          texto_string := texto_string || 'Mil ';
        END IF;
      END IF;
    END IF;
    valor_string := valor_string || texto_string;
    -- Escrita da Moeda Corrente
    IF ind = 5 THEN
      IF to_number(substr(valor_conv
                         ,16
                         ,3)) > 0
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    ELSE
      IF ind < 5
         AND valor_string IS NOT NULL THEN
        valor_string := rtrim(valor_string) || ', ';
      END IF;
    END IF;
    IF ind = 6 THEN
      IF to_number(substr(valor_conv
                         ,1
                         ,18)) > 1 THEN
        valor_string := valor_string || 'Reais ';
      ELSIF to_number(substr(valor_conv
                            ,1
                            ,18)) = 1 THEN
        valor_string := valor_string || 'Real ';
      END IF;

      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 0
         AND length(valor_string) > 0 THEN
        valor_string := valor_string || 'e ';
      END IF;
    END IF;
    -- Escrita para Centavos
    IF ind = 7 THEN
      IF to_number(substr(valor_conv
                         ,20
                         ,2)) > 1 THEN
        valor_string := valor_string || 'Centavos ';
      ELSIF to_number(substr(valor_conv
                            ,20
                            ,2)) = 1 THEN
        valor_string := valor_string || 'Centavo ';
      END IF;
    END IF;
  END LOOP;
  RETURN(rtrim(valor_string));
 EXCEPTION
  WHEN OTHERS THEN
    RETURN('*** VALOR INVALIDO ***');
 END;

 FUNCTION conv_spc_chr(p_char IN VARCHAR2) RETURN VARCHAR2 IS

  l_vChar VARCHAR2(4000) := p_char;

 BEGIN
  l_vChar := REPLACE(l_vChar, chr(38), ';');
  l_vChar := REPLACE(l_vChar, '<', ';');
  l_vChar := REPLACE(l_vChar, '>', ';');
  l_vChar := REPLACE(l_vChar, '"', ';');
  l_vChar := REPLACE(l_vChar, '''', ';');
  l_vChar := REPLACE(l_vChar, 'ÿº', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'C');
  l_vChar := REPLACE(l_vChar, 'ÿ§', 'c');
  l_vChar := REPLACE(l_vChar, 'ÿ§', 'c');
  l_vChar := REPLACE(l_vChar, 'ÿ£', 'a');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'A');
  l_vChar := REPLACE(l_vChar, 'ÿ©', 'e');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'E');
  l_vChar := REPLACE(l_vChar, 'ÿ­', 'i');
  l_vChar := REPLACE(l_vChar, 'ÿ?', 'I');
  l_vChar := REPLACE(l_vChar, 'ÿ³', 'o');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'O');
  l_vChar := REPLACE(l_vChar, 'ÿº', 'u');
  l_vChar := REPLACE(l_vChar, 'ÿ¿', 'U');

  RETURN(l_vChar);
 END conv_spc_chr;
 --

 PROCEDURE gen_xml_p(p_message IN VARCHAR2) IS
 BEGIN
   IF g_bGen_XML THEN
     -- Gera Log de execucao
     dbms_output.put_line(p_message);
   ELSE
     -- Grava saida do concurrent:
     fnd_file.put_line(fnd_file.output,p_message);
   END IF;

 END gen_xml_p;
 --

END XXSTN_PO_REL_KPI_MAPA_COMP_PKG;
/

EXIT;