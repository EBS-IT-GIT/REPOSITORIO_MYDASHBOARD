==============================================================================
RELAP040_003 : SAE - Relat�rio T�tulos Pagos - BNDES
==============================================================================

Atualiza��o - RELAP040_003
Produto     - XX Customizaciones
Data        - 14/06/2019 15:30:47
HotPatch    - N�o
Fornecedor  - HQS Plus

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121RELAP040_003

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_AP_REL_BNDES_PKGS.pls
                               SAE_AP_REL_BNDES_PKGB.pls