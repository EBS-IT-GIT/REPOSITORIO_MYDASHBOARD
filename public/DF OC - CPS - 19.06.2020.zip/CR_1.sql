UPDATE xx_po_asocia_remitos xpar
   SET clave_nro = '6005-' || SUBSTR(clave_nro,6,8),
            clave_id   = 1000000 + clave_id
 WHERE xpar.tipo_documento = 'TCG'
 WHERE xpar.clave_nro IN
          ('0005-85732373',
           '0005-85732374',
           '0005-85732375',
           '0005-85732377',
           '0005-85732327',
           '0005-85732328')                                       
--6