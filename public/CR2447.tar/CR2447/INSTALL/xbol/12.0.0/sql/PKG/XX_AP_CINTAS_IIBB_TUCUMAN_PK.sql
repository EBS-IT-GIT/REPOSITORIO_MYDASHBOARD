  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_CINTAS_IIBB_TUCUMAN_PK" AS

procedure ap_cintas (retcode             OUT NUMBER
                    ,errbuf              OUT VARCHAR2
                    ,p_path               IN VARCHAR2
                    ,p_jurisdiction_type  IN VARCHAR2
                    ,p_awt_type_code      IN VARCHAR2
                    ,p_awt_type_code_cast IN VARCHAR2
                    ,p_start_date         IN VARCHAR2
                    ,p_end_date           IN VARCHAR2);

END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_CINTAS_IIBB_TUCUMAN_PK" AS

PROCEDURE print_output (p_message IN VARCHAR2) IS
BEGIN
    fnd_file.put_line(fnd_file.output,p_message);
END;

PROCEDURE print_log (p_message IN VARCHAR2) IS
BEGIN
    fnd_file.put_line(fnd_file.log,p_message);
END;

PROCEDURE print_file (p_status            OUT VARCHAR2
                     ,p_error_message     OUT VARCHAR2
                     ,p_path               IN VARCHAR2) IS

v_file_type UTL_FILE.FILE_TYPE;
v_line VARCHAR2(2000);
e_cust_exception EXCEPTION;

CURSOR c_out (p_line_type VARCHAR2) IS
SELECT rowid row_id,xacit.*
FROM XX_AP_CINTAS_IIBB_TUC xacit
WHERE status = 'N'
and line_type = p_line_type
ORDER BY line_num,text;

BEGIN

    print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.PRINT_FILE (+)');

    v_file_type := UTL_FILE.FOPEN(p_path,'RETPER.txt', 'W');

    FOR r_out IN c_out ('PRO') LOOP

        UTL_FILE.PUT_LINE(v_file_type,r_out.text);

        update XX_AP_CINTAS_IIBB_TUC
        set status = 'P'
        where rowid = r_out.row_id;

    END LOOP;

    utl_file.fclose(v_file_type);

    v_file_type := UTL_FILE.FOPEN(p_path,'DATOS.txt', 'W');

    FOR r_out IN c_out ('OP') LOOP

        UTL_FILE.PUT_LINE(v_file_type,r_out.text);

        update XX_AP_CINTAS_IIBB_TUC
        set status = 'P'
        where rowid = r_out.row_id;

    END LOOP;

    utl_file.fclose(v_file_type);

    print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.PRINT_FILE (-)');
EXCEPTION
 WHEN e_cust_exception THEN
   p_status := 'W';
   print_log(p_error_message);
   print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.PRINT_FILE (!)');
 WHEN OTHERS THEN
   p_status := 'W';
   p_error_message := 'Error OTHERS en PRINT_FILE. Error: '||SQLERRM;
   print_log(p_error_message);
   print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.PRINT_FILE (!)');
END;

procedure get_data_ap (p_status            OUT VARCHAR2
                      ,p_error_message     OUT VARCHAR2
                      ,p_start_date         IN VARCHAR2
                      ,p_end_date           IN VARCHAR2
                      ,p_jurisdiction_type  IN VARCHAR2
                      ,p_awt_type_code      IN VARCHAR2
                      ,p_awt_type_code_cast IN VARCHAR2) IS

v_line VARCHAR2(2000);
v_lin NUMBER;
e_cust_exception EXCEPTION;

CURSOR c_wh is
select TO_CHAR(awt_date,'RRRRMMDD') awt_date
,pov.vendor_id
,lpad(substr(nvl(pov.global_attribute10,'0'),1,2),2,'0') supp_tax_identification_type
,LPAD(NVL(rtrim(substr(replace(pov.num_1099,'-'),1,10))||substr(pov.global_attribute12,1,1),' '),11,' ')             cuit_number
,'99' tax_authority_transaction_type
, ' ' transaction_letter
, '    ' terminal_tuc
, LPAD(doc_sequence_value,8,' ')        document_number
, atc.name
,ROUND((((abs(jlc.withholding_amount)*100)/(select rate from XX_AP_IIBB_AWT_RATES xaiar where xaiar.vendor_id = pov.vendor_id and supp_awt_code_id = jsc.supp_awt_code_id and awt_date between date_from and date_to))),2) base_amount
,(select rate from XX_AP_IIBB_AWT_RATES xaiar where xaiar.vendor_id = pov.vendor_id and supp_awt_code_id = jsc.supp_awt_code_id and awt_date between date_from and date_to) alicuota
,abs(jlc.withholding_amount) amount
FROM
    jl_ar_ap_awt_certif        jlc,
    jl_zz_ap_awt_types         jat,
    ap_tax_codes               atc,
    ap_tax_codes_all_dfv       atc_dfv, 
    jl_zz_ap_supp_awt_types    jst,
    JL_ZZ_AP_SUP_AWT_Cd jsc,
    ap_suppliers               pov,
    hr_locations               hrl,
    jl_zz_ap_comp_awt_types    jct,
    ap_checks                  ac
WHERE  1=1
AND    NVL(jlc.status,' ') <>'VOID'
AND    NVL(ac.status_lookup_code,' ') <> 'VOIDED'
AND    atc.rowid = atc_dfv.row_id  
AND    atc.name = jlc.tax_name
AND    pov.vendor_id = jlc.vendor_id
AND    jat.awt_type_code = jlc.awt_type_code
AND    hrl.location_id = jlc.location_id
AND    jct.location_id = hrl.location_id
AND    jct.awt_type_code = jat.awt_type_code
AND    jst.vendor_id = pov.vendor_id
AND    jst.awt_type_code = jat.awt_type_code
AND    ac.vendor_id       = jlc.vendor_id
AND    ac.check_number    = jlc.check_number
AND    jlc.awt_date between TO_DATE(p_start_date,'YYYY/MM/DD HH24:MI:SS') and TO_DATE(p_end_date,'YYYY/MM/DD HH24:MI:SS')
AND    jat.jurisdiction_type = p_jurisdiction_type
AND    jat.awt_type_code IN (p_awt_type_code,p_awt_type_code_cast)
AND    jlc.withholding_amount        <  0
and    jst.supp_awt_type_id = jsc.supp_awt_type_id
and    jsc.tax_id = atc.tax_id
AND    NOT EXISTS (SELECT 1
        FROM ap_inv_selection_criteria_all aisc 
        WHERE aisc.checkrun_name = jlc.checkrun_name
        AND    aisc.status like 'CANCEL%')
order by 4,3,1;

CURSOR c_vendor IS
SELECT Rpad(substr(nvl(pov.global_attribute10,'0'),1,2),2,'0') supp_tax_identification_type
      ,Rpad(NVL(rtrim(substr(replace(pov.num_1099,'-'),1,10))||substr(pov.global_attribute12,1,1),' '),11,' ') cuit_number
      ,RPAD(SUBSTR(REPLACE(REPLACE(REPLACE(pov.vendor_name,chr(50065),'N'),chr(241),'n'),chr(193),'A'),1,40),40,' ') 
       vendor_name
      ,RPAD(SUBSTR(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(XX_UTIL_PK.xml_escape_chars(pvs.address_line1),chr(50065),'N'),chr(241),'n'),chr(50061),'I'),chr(49840),'*'),chr(49850),'*'),chr(50097),'n'),1,40),40,' ') 
      direccion
      ,'    1' numero
      ,RPAD(NVL(REPLACE(REPLACE(REPLACE(NVL(pvs.address_line2,pvs.city),chr(50065),'N'),chr(241),'n'),chr(50067),'O'),' '),15,' ')
       localidad
      ,RPAD(NVL(REPLACE(REPLACE(REPLACE(NVL(hg.geography_name,pvs.province),chr(50065),'N'),chr(241),'n'),chr(50067),'O'),' '),15,' ')
       provincia
      ,LPAD(NVL(pvs.zip,'0000'),8,' ') codpos
FROM
    jl_ar_ap_awt_certif        jlc,
    jl_zz_ap_awt_types         jat,
    ap_tax_codes               atc,
    ap_tax_codes_all_dfv       atc_dfv, 
    jl_zz_ap_supp_awt_types    jst,
    JL_ZZ_AP_SUP_AWT_Cd jsc,
    ap_suppliers               pov,
    ap_supplier_sites          pvs,
    hr_locations               hrl,
    jl_zz_ap_comp_awt_types    jct,
    ap_checks                  ac,
    hz_geographies hg
WHERE  1=1
AND    NVL(jlc.status,' ') <>'VOID'
AND    NVL(ac.status_lookup_code,' ') <> 'VOIDED'
AND    atc.rowid = atc_dfv.row_id  
AND    atc.name = jlc.tax_name
AND    pov.vendor_id = jlc.vendor_id
AND    jat.awt_type_code = jlc.awt_type_code
AND    hrl.location_id = jlc.location_id
AND    jct.location_id = hrl.location_id
AND    jct.awt_type_code = jat.awt_type_code
AND    jst.vendor_id = pov.vendor_id
AND    jst.awt_type_code = jat.awt_type_code
AND    ac.vendor_id       = jlc.vendor_id
AND    ac.check_number    = jlc.check_number
AND    ac.vendor_site_id  = pvs.vendor_site_id
and    pvs.vendor_id = pov.vendor_id
and  hg.geography_type(+) = 'PROVINCE'
and hg.geography_code(+) = pvs.province
and hg.created_by_module(+) = 'HZ_GEO_HIERARCHY'
And hg.country_code(+) = pvs.country
AND    jlc.awt_date between TO_DATE(p_start_date,'YYYY/MM/DD HH24:MI:SS') and TO_DATE(p_end_date,'YYYY/MM/DD HH24:MI:SS')
AND    jat.jurisdiction_type = p_jurisdiction_type
AND    jat.awt_type_code IN (p_awt_type_code,p_awt_type_code_cast)
AND    jlc.withholding_amount        <  0
and    jst.supp_awt_type_id = jsc.supp_awt_type_id
and    jsc.tax_id = atc.tax_id
AND    NOT EXISTS (SELECT 1
        FROM ap_inv_selection_criteria_all aisc 
        WHERE aisc.checkrun_name = jlc.checkrun_name
        AND    aisc.status like 'CANCEL%')
GROUP BY Rpad(substr(nvl(pov.global_attribute10,'0'),1,2),2,'0')
      ,Rpad(NVL(rtrim(substr(replace(pov.num_1099,'-'),1,10))||substr(pov.global_attribute12,1,1),' '),11,' ')
      ,RPAD(SUBSTR(REPLACE(REPLACE(REPLACE(pov.vendor_name,chr(50065),'N'),chr(241),'n'),chr(193),'A'),1,40),40,' ') 
      ,RPAD(SUBSTR(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(XX_UTIL_PK.xml_escape_chars(pvs.address_line1),chr(50065),'N'),chr(241),'n'),chr(50061),'I'),chr(49840),'*'),chr(49850),'*'),chr(50097),'n'),1,40),40,' ') 
      ,RPAD(NVL(REPLACE(REPLACE(REPLACE(NVL(pvs.address_line2,pvs.city),chr(50065),'N'),chr(241),'n'),chr(50067),'O'),' '),15,' ')
      ,RPAD(NVL(REPLACE(REPLACE(REPLACE(NVL(hg.geography_name,pvs.province),chr(50065),'N'),chr(241),'n'),chr(50067),'O'),' '),15,' ') 
      ,LPAD(NVL(pvs.zip,'0000'),8,' ')
ORDER BY 2,1;

BEGIN

    print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.GET_DATA_AP (+)');

    FOR r_vendor in c_vendor LOOP

      print_log('Procesando Proveedor: '||r_vendor.vendor_name);

      BEGIN

       v_line := null;
       v_line := v_line||r_vendor.supp_tax_identification_type;
       v_line := v_line||r_vendor.cuit_number;
       v_line := v_line||r_vendor.vendor_name;
       v_line := v_line||r_vendor.direccion;
       v_line := v_line||r_vendor.numero;
       v_line := v_line||r_vendor.localidad;
       v_line := v_line||r_vendor.provincia;
       v_line := v_line||'           '; --No usado
       v_line := v_line||r_vendor.codpos;

       INSERT INTO xx_ap_cintas_iibb_tuc VALUES ('PRO',null,v_line,'N',fnd_global.conc_request_id,sysdate,fnd_global.user_id,sysdate,fnd_global.user_id);
       COMMIT;

       EXCEPTION
        WHEN OTHERS THEN
         p_error_message := 'Error en RETPER - Proveedor: '||r_vendor.vendor_name||'. Error: '||SQLERRM;
         print_log(p_error_message);
         p_status := 'W';
      END;

    END LOOP;

    v_lin := 0;

    FOR r_wh in c_wh LOOP

        print_log('Procesando Orden de Pago: '||r_wh.document_number);
        v_line := null;

      BEGIN

        v_lin := v_lin +1;

        v_line := v_line||r_wh.awt_date;
        v_line := v_line||r_wh.supp_tax_identification_type;
        v_line := v_line||r_wh.cuit_number;
        v_line := v_line||r_wh.tax_authority_transaction_type;
        v_line := v_line||r_wh.transaction_letter;
        v_line := v_line||r_wh.terminal_tuc;
        v_line := v_line||r_wh.document_number;
        v_line := v_line||LPAD(TRIM(TO_CHAR(ROUND(r_wh.base_amount,2),'9999999999990D99', 'NLS_NUMERIC_CHARACTERS=''.,''')),15,'0'); /*Monto Pasible*/
        v_line := v_line||LPAD(TRIM(TO_CHAR(ROUND(r_wh.alicuota,3),'9999999999990D999', 'NLS_NUMERIC_CHARACTERS=''.,''')),6,'0'); /*Alicuota*/
        v_line := v_line||LPAD(TRIM(TO_CHAR(ROUND(r_wh.amount,2),'9999999999990D99', 'NLS_NUMERIC_CHARACTERS=''.,''')),15,'0'); /*Monto retenido*/

        INSERT INTO xx_ap_cintas_iibb_tuc VALUES ('OP',v_lin,v_line,'N',fnd_global.conc_request_id,sysdate,fnd_global.user_id,sysdate,fnd_global.user_id);
        COMMIT;

      EXCEPTION
        WHEN OTHERS THEN
         p_error_message := 'Error en Orden de Pago: '||r_wh.document_number||'. Error: '||SQLERRM;
         print_log(p_error_message);
         p_status := 'W';
      END;
    END LOOP;

    if p_status is null then
      p_status:= 'S';
      print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.GET_DATA_AP (-)');
    else
      RAISE e_cust_exception;
    end if;

EXCEPTION
 WHEN e_cust_exception then
   p_status := 'W';
   print_log(p_error_message);
   print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.GET_DATA_AP (!)');
 when others then
   p_status := 'W';
   p_error_message := 'Error OTHERS en GET_DATA_AP. Error: '||SQLERRM;
   print_log(p_error_message);
   print_log('XX_AP_CINTAS_IIBB_TUCUMAN_PK.GET_DATA_AP (!)');
END;

procedure ap_cintas (retcode             OUT NUMBER
                    ,errbuf              OUT VARCHAR2
                    ,p_path               IN VARCHAR2
                    ,p_jurisdiction_type  IN VARCHAR2
                    ,p_awt_type_code      IN VARCHAR2
                    ,p_awt_type_code_cast IN VARCHAR2
                    ,p_start_date         IN VARCHAR2
                    ,p_end_date           IN VARCHAR2) IS

v_status        VARCHAR2(1);
v_error_message VARCHAR2(2000);
e_cust_exception exception;

BEGIN

    Print_log ('XX_AP_CINTAS_IIBB_TUCUMAN_PK.AP_CINTAS (+)');

    print_log ('P_PATH: '                ||p_path);
    print_log ('P_JURISDICTION_TYPE: '   ||p_jurisdiction_type);
    print_log ('P_AWT_TYPE_CODE: '       ||p_awt_type_code);
    print_log ('P_AWT_TYPE_CODE_CAST: '  ||p_awt_type_code_cast);
    print_log ('P_START_DATE: '          ||p_start_date);
    print_log ('P_END_DATE: '            ||p_end_date);

    get_data_ap(p_status             => v_status
               ,p_error_message      => v_error_message
               ,p_start_date         => p_start_date
               ,p_end_date           => p_end_date
               ,p_jurisdiction_type  => p_jurisdiction_type
               ,p_awt_type_code      => p_awt_type_code
               ,p_awt_type_code_cast => p_awt_type_code_cast);

    IF v_status != 'S' THEN
      RAISE e_cust_exception;
    END IF;

    print_file (p_status        => v_status
               ,p_error_message => v_error_message
               ,p_path          => p_path);

    IF v_status != 'S' THEN
      RAISE e_cust_exception;
    END IF;

    Print_log ('XX_AP_CINTAS_IIBB_TUCUMAN_PK.AP_CINTAS (-)');

EXCEPTION
 WHEN e_cust_exception THEN
   retcode := 1;
   errbuf := v_error_message;
   print_log (errbuf);
   IF not fnd_concurrent.set_completion_status('WARNING',errbuf) THEN
      v_error_message := 'Error seteando estado de finalizacion: ' || sqlerrm;
      print_log (v_error_message);
    ELSE
      print_log ('Estado de finalizacion seteado');
    END IF;
   Print_log ('XX_AP_CINTAS_IIBB_TUCUMAN_PK.AP_CINTAS (!)');
 WHEN OTHERS THEN
   retcode := 2;
   errbuf  := 'Error OTHERS en AP_CINTAS. Error: '||SQLERRM;
   print_log (errbuf);
   Print_log ('XX_AP_CINTAS_IIBB_TUCUMAN_PK.AP_CINTAS (!)');
   RAISE_APPLICATION_ERROR(-20000,errbuf);
END;

END; 
/

exit
