#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2283_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2283
# |
# | HISTORY
# |   04-DEC-19  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2283_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2283_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2283
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2283/CR2283_20191204"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=DESA12

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/REQGRP
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/REQGRP
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT
svn up /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2283" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2283_13787.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2283"
AddAllLogs $CROUT "FND" "CR2283_13787.ldt"
mv CR2283_13787.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_ASIG_GI_PROD_RES_ORG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_ASIG_GI_PROD_RES_ORG','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_ASIG_GI_PROD_RES_ORG* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_ASIG_GI_RESOURCE_ORG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_ASIG_GI_RESOURCE_ORG','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_ASIG_GI_RESOURCE_ORG* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_ASIG_GI_SUMGL_RES_ORG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_ASIG_GI_SUMGL_RES_ORG','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_ASIG_GI_SUMGL_RES_ORG* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_CONF_GI_AJUSTES_CC " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_CONF_GI_AJUSTES_CC','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_AJUSTES_CC* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_CONF_GI_COLUMNAS_DET " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_CONF_GI_COLUMNAS_DET','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_COLUMNAS_DET* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_CONF_GI_COLUMNAS_HDR " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_CONF_GI_COLUMNAS_HDR','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_COLUMNAS_HDR* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_CONF_GI_LINEAS_DET " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_CONF_GI_LINEAS_DET','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_LINEAS_DET* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OPM_CONF_GI_LINEAS_HDR " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OPM_CONF_GI_LINEAS_HDR','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_LINEAS_HDR* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_OPM_CONF_GI_AJUSTES_CC_S " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_OPM_CONF_GI_AJUSTES_CC_S','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_AJUSTES_CC_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_OPM_CONF_GI_COLUMNAS_DET_S " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_OPM_CONF_GI_COLUMNAS_DET_S','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_COLUMNAS_DET_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_OPM_CONF_GI_COLUMNAS_HDR_S " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_OPM_CONF_GI_COLUMNAS_HDR_S','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_COLUMNAS_HDR_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_OPM_CONF_GI_LINEAS_HDR_S " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_OPM_CONF_GI_LINEAS_HDR_S','BOLINF','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_CONF_GI_LINEAS_HDR_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OPM_PROC_GI_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OPM_PROC_GI_PK','APPS','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_PROC_GI_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXOPMCONFGCOLU.ldt FUNCTION FUNCTION_NAME="XXOPMCONFGCOLU"
AddAllLogs $CROUT "FND" "XXOPMCONFGCOLU.ldt"
mv XXOPMCONFGCOLU.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXOPMCONFGILIN.ldt FUNCTION FUNCTION_NAME="XXOPMCONFGILIN"
AddAllLogs $CROUT "FND" "XXOPMCONFGILIN.ldt"
mv XXOPMCONFGILIN.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_OPM_MAIN_MENU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_OPM_MAIN_MENU.ldt MENU MENU_NAME="XX_OPM_MAIN_MENU"
AddAllLogs $CROUT "FND" "XX_OPM_MAIN_MENU.ldt"
mv XX_OPM_MAIN_MENU.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-REQGRP XXOPMAllReports " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpreqg.lct XXOPMAllReports.ldt REQUEST_GROUP REQUEST_GROUP_NAME="XX OPM All Reports" APPLICATION_SHORT_NAME="XBOL"
AddAllLogs $CROUT "FND" "XXOPMAllReports.ldt"
mv XXOPMAllReports.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/REQGRP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOPMPGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOPMPGI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOPMPGI"
AddAllLogs $CROUT "FND" "XXOPMPGI.ldt"
mv XXOPMPGI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOPMRGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOPMRGI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOPMRGI"
AddAllLogs $CROUT "FND" "XXOPMRGI.ldt"
mv XXOPMRGI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOPMAGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOPMAGI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOPMAGI"
AddAllLogs $CROUT "FND" "XXOPMAGI.ldt"
mv XXOPMAGI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PERSO XXOPMCONFGCOLU_10 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct XXOPMCONFGCOLU_10.ldt FND_FORM_CUSTOM_RULES FUNCTION_NAME="XXOPMCONFGCOLU" SEQUENCE="10"
AddAllLogs $CROUT "FND" "XXOPMCONFGCOLU_10.ldt"
mv XXOPMCONFGCOLU_10.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PERSO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PERSO XXOPMCONFGCOLU_20 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct XXOPMCONFGCOLU_20.ldt FND_FORM_CUSTOM_RULES FUNCTION_NAME="XXOPMCONFGCOLU" SEQUENCE="20"
AddAllLogs $CROUT "FND" "XXOPMCONFGCOLU_20.ldt"
mv XXOPMCONFGCOLU_20.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PERSO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb ]; then
  cp $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb XXOPMCONFGCOLU.fmb
  echo `ls -lh XXOPMCONFGCOLU.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb no existe" >> $CROUT
fi
mv XXOPMCONFGCOLU* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXOPMCONFGILIN.fmb ]; then
  cp $AU_TOP/forms/US/XXOPMCONFGILIN.fmb XXOPMCONFGILIN.fmb
  echo `ls -lh XXOPMCONFGILIN.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXOPMCONFGILIN.fmb no existe" >> $CROUT
fi
mv XXOPMCONFGILIN* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXOPMRGI " >> $CROUT; echo "" >> $CROUT

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE DATA_TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXOPMRGI \
-LANGUAGE "00" \
-TERRITORY "00" \
-XDO_FILE_TYPE XML \
-FILE_NAME XXOPMRGI_v02.xml \
-CUSTOM_MODE FORCE \
-LOG_FILE XXOPMRGI_xmldt_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXOPMRGI.ldt"
mv XXOPMRGI* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXOPMRGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXOPMRGI.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXOPMRGI"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXOPMRGI \
-LANGUAGE "en" \
-TERRITORY "00" \
-LOG_FILE XXOPMRGI_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXOPMRGI.ldt"
mv XXOPMRGI* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
