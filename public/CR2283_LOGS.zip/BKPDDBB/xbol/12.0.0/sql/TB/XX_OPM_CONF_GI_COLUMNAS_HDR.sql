  set define off;

exec AD_ZD_TABLE.Upgrade('BOLINF', 'XX_OPM_CONF_GI_COLUMNAS_HDR');

exit
