  set define off;

exec AD_ZD_TABLE.Upgrade('BOLINF', 'XX_OPM_ASIG_GI_RESOURCE_ORG');

exit
