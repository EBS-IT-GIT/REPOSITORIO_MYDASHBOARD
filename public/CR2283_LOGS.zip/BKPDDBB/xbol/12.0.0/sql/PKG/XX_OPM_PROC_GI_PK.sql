  set define off;
ORA-31603: object "XX_OPM_PROC_GI_PK" of type PACKAGE_SPEC not found in schema "APPS"
ORA-06512: at "SYS.DBMS_METADATA", line 6078
ORA-06512: at "SYS.DBMS_METADATA", line 8686
ORA-06512: at line 1
ORA-31603: object "XX_OPM_PROC_GI_PK" of type PACKAGE_BODY not found in schema "APPS"
ORA-06512: at "SYS.DBMS_METADATA", line 6078
ORA-06512: at "SYS.DBMS_METADATA", line 8686
ORA-06512: at line 1

exit
