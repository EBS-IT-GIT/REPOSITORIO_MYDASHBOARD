  set define off;

exit
