set define off;
DECLARE
  l_program_short_name  VARCHAR2 (200);
  l_program_application VARCHAR2 (200);
  l_request_group       VARCHAR2 (200);
  l_group_application   VARCHAR2 (200);
  l_check               VARCHAR2 (2);
  
   p_short_name        VARCHAR2(200) := 'FNDRSSUB2371';       -- Request Set Short Name
   p_application       VARCHAR2(200)    := 'Latin America Localizations';                           -- Request Set Application Short Name
   p_request_group     VARCHAR2(200) := 'All Reports';  -- Request Group Name
   p_group_application VARCHAR2(200) := 'PO';                           -- Request Group Application Short Name

  --
BEGIN
  --
  
  IF 1 = 1 THEN 
  
  --Assign CONCURRENT PROGRAM 
  l_program_short_name  := 'XXOMSUCMODPRIC';
  l_program_application := 'Business Online';
  l_request_group       := 'XX AR Consulta';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   BEGIN
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 );  
   EXCEPTION
    WHEN OTHERS THEN
        NULL;
   END;
  --
  l_program_short_name  := 'XXOMSUCMODPRIC';
  l_program_application := 'Business Online';
  l_request_group       := 'XX AR Cobranzas';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   BEGIN
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 );  
   EXCEPTION
    WHEN OTHERS THEN
        NULL;
   END;
  --
  l_program_short_name  := 'XXOMSUCMODPRIC';
  l_program_application := 'Business Online';
  l_request_group       := 'XX AR Facturacion';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   BEGIN
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 );  
   EXCEPTION
    WHEN OTHERS THEN
        NULL;
   END;

  l_program_short_name  := 'XXOMSUCMODPRIC';
  l_program_application := 'Business Online';
  l_request_group       := 'JLAR + AR Reports';
  l_group_application   := 'Latin America Localizations';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   BEGIN
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 );  
   EXCEPTION
    WHEN OTHERS THEN
        NULL;
   END;
  END IF;
   
   
  IF 1 = 2 THEN

  --ASSIGN REQUEST SET TO GROUP 
   fnd_set.add_set_to_group(request_set => p_short_name,
                                         set_application => p_application ,
                                         request_group => p_request_group ,
                                         group_application => p_group_application );

  END IF;   

  --
  COMMIT;
END;
/
exit