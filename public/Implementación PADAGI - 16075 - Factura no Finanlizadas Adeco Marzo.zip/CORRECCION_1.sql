UPDATE apps.ra_customer_trx_all rct
SET    trx_number = decode(customer_trx_id, 13821277,'B-0159-00000001',13942285,'B-0159-00000002')
WHERE  customer_trx_id IN (13821277,13942285);
--2 Registros