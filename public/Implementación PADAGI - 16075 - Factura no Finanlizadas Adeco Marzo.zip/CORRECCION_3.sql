UPDATE  ar_payment_schedules_all
SET     amount_due_remaining = 0,amount_line_items_remaining = 0, tax_remaining = 0, acctd_amount_due_remaining = 0
WHERE   customer_trx_id IN (13821277,13942285,14153200,14171196,14185375,14192232);
--6 Registros