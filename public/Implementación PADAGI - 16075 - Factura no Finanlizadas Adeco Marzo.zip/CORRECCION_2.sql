 DECLARE 
   l_applied_commitment_amt NUMBER;
   
   CURSOR c_trx IS
   select customer_trx_id
   from ra_customer_trx_all
   where customer_trx_id IN (13821277,13942285,14153200,14171196,14185375,14192232);
BEGIN
   mo_global.set_policy_context ('S', 102);
   fnd_global.apps_initialize(-1,50277,222);
   
   FOR r_trx in c_trx loop       
       arp_maintain_ps.maintain_payment_schedules('U',
                                           r_trx.customer_trx_id,
                                           NULL,   -- ps_id
                                           NULL,   -- line_amount
                                           NULL,   -- tax_amount
                                           NULL,   -- frt_amount
                                           NULL,   -- charge_amount
                                           l_applied_commitment_amt);
                                           
        update ra_customer_trx_all
        set complete_flag = 'Y'
        where customer_trx_id = r_trx.customer_trx_id
        and complete_flag = 'N';
                
        commit;
   
   END LOOP;
   
END ;   