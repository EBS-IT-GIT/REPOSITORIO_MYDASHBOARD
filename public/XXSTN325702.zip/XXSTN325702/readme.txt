********************************************************************************
* XXSTN325702
********************************************************************************
* This patch contains
* =================
* 
* Gap XXSTN325702
* 
* 
* PRE-REQS:  
* ==============
	1. drop tables XXSTN.XXSTN_AP_REL_LOGO and XXSTN.XXSTN_AP_REL_LOGO_CONF

* 
* POST-PATCH:
* ====================

	1. Create a temp directory into linux
	2. Create a entry to dba_directories point to temp directory created at step 1
	3. Copy content of logo folder to temp directory
	4. Change the file diretorios.sql with correct directory
	5. Change the file upload_logo.sql with correct directory
	6. Run upload_logo.sql

	7. Execute md120.docx step by step

* 
********************************************************************************  

################################################################################
###                        Installation procedures                           ###
################################################################################

1) Apply unified driver

	