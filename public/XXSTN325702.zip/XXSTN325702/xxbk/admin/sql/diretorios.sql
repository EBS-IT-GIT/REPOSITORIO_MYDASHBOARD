
--JLBR + AP Reports

CREATE OR REPLACE DIRECTORY
    LOGO_DIR
    AS
    '/app/DEVEBS/fs1/EBSapps/comn/java/classes/oracle/apps/media/Logos';
/


