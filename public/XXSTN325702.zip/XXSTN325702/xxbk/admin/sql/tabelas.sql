

CREATE TABLE XXSTN.XXSTN_AP_REL_LOGO (
  org_id        NUMBER,
  logo			BLOB
)
/


CREATE TABLE XXSTN.XXSTN_AP_REL_LOGO_CONF (
empresa varchar2(1000),
org_id	varchar2(1000),
pagador varchar2(1000),
fornecedor varchar2(1000),
cnpj varchar2(1000),
nome_conta_bancaria_pagto varchar2(1000),
nr_documento_pgto varchar2(1000),
data_pagto varchar2(1000),
nr_nf varchar2(1000),
data_nf varchar2(1000),
quantia varchar2(1000),
retencoes varchar2(1000),
vl_pago varchar2(1000),
email_address varchar2(1000),
nr_banco varchar2(1000),
nome_banco varchar2(1000),
nr_agencia varchar2(1000),
nr_conta varchar2(1000),
barcode varchar2(1000),
mensagem varchar2(1000),
processo varchar2(1000)) 

/
