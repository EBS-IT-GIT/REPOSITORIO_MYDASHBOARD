DECLARE
  src_lob  BFILE ;
  dest_lob BLOB;
BEGIN

    FOR X IN ( SELECT '442' as id ,'Stone_Logo.png' as filename from dual union
        SELECT '443','Stone_Logo.png' from dual union
        SELECT '162','Stone_Logo.png' from dual union
        SELECT '322','Stone_Logo.png' from dual union
        SELECT '82','Stone_Logo.png' from dual union
        SELECT '422','Stone_Logo.png' from dual union
        SELECT '81','Stone.co_Logo (Verde Grandes Contas).png' from dual union
        SELECT '142','Stone.co_Logo (Verde Grandes Contas).png' from dual union
        SELECT '222','Stone.co_Logo (Verde Grandes Contas).png' from dual union
        SELECT '122','Stone.co_Logo (Verde Grandes Contas).png' from dual union
        SELECT '83','Stone.co_Logo (Verde Grandes Contas).png' from dual union
        SELECT '88','Buy4-LogoFinal1.png' from dual union
        SELECT '84','cappta_logo.png' from dual union
        SELECT '85','Equals_Logo.png' from dual union
        SELECT '86','Mundipagg_Logo.png' from dual union
        SELECT '87','PAGARME_logo_cor_2019.png' from dual union
        SELECT '204','LOGO_TAG_2020.png' from dual )
      LOOP

          INSERT INTO XXSTN.XXSTN_AP_REL_LOGO VALUES(x.id, EMPTY_BLOB())
             RETURNING logo INTO dest_lob;
          src_lob := BFILENAME('CE_INBOUND', x.filename);
          DBMS_LOB.OPEN(src_lob, DBMS_LOB.LOB_READONLY);
          DBMS_LOB.LoadFromFile( DEST_LOB => dest_lob,
                                 SRC_LOB  => src_lob,
                                 AMOUNT   => DBMS_LOB.GETLENGTH(src_lob) );
          DBMS_LOB.CLOSE(src_lob);
        
          COMMIT;
    END LOOP;
END;
/

