
/
set define off;

create or replace PACKAGE XXSTN_AP_REL_AVISO_PAGTO AS
   
   PROCEDURE LOADFILE ( p_filename in varchar2, p_blob      IN OUT NOCOPY BLOB);

   PROCEDURE SENDMAIL (
						P_ERRBUF                  IN OUT VARCHAR2
                        , P_RETCODE                 IN OUT VARCHAR2,
						p_dt_inicial in varchar2,
						p_dt_final in varchar2,
						p_org_id in varchar2) ;

end;

/

set define off;

create or replace PACKAGE BODY xxstn_ap_rel_aviso_pagto AS

    PROCEDURE loadfile (
        p_filename IN VARCHAR2,
        p_blob IN OUT NOCOPY BLOB
    ) AS
        l_bfile bfile;
        l_dest_offset   INTEGER := 1;
        l_src_offset    INTEGER := 1;
    BEGIN
          dbms_output.put_line ('p_filename ' ||p_filename);
        l_bfile := bfilename('CE_INBOUND', p_filename);
        dbms_lob.fileopen(l_bfile, dbms_lob.file_readonly);
		dbms_lob.createtemporary(p_blob, true);
        dbms_lob.trim(p_blob, 0);
        IF dbms_lob.getlength(l_bfile) > 0 THEN
            dbms_lob.loadblobfromfile(dest_lob => p_blob, src_bfile => l_bfile, amount => dbms_lob.lobmaxsize, dest_offset => l_dest_offset
            , src_offset => l_src_offset);
        END IF;

        dbms_lob.fileclose(l_bfile);
    END loadfile;


	PROCEDURE SENDMAIL (
						P_ERRBUF                  IN OUT VARCHAR2
                        , P_RETCODE                 IN OUT VARCHAR2,
						p_dt_inicial in varchar2,
						p_dt_final in varchar2,
						p_org_id in varchar2) AS

	conn utl_smtp.connection;
    BOUNDARY  VARCHAR2 (256) := '-----090303020209010600070908';
    i         pls_integer;
    len       pls_integer;
    buff_size pls_integer := 57;
    l_raw     raw(57);
    p_image blob;
    MailServer          VARCHAR2(50) := 'localhost';

	l_message			VARCHAR2(32767);
	l_message_temp		VARCHAR2(32767);
	l_filename			VARCHAR2(100);

	l_total_quantia		NUMBER;
	l_total_retencoes	NUMBER;
	l_total_valor		NUMBER;
    
    l_email             VARCHAR2(100);
    l_org_id            NUMBER;
	l_check_id			VARCHAR2(1000);

	l_nr_document		varchar2(100);
	
	l_erro				varchar2(2000);
	
	l_vXdo_Short_Name	VARCHAR2(100);
    l_vTemplate_Code	VARCHAR2(100);
    l_vDefault_Lang		VARCHAR2(100);
    l_vTerritory		VARCHAR2(100);
    l_vOut_Type_Code	VARCHAR2(100);
	l_bLayout_Xml		boolean;
	L_NREQUEST_ID		NUMBER;

    l_message_to_send_header           VARCHAR2(32767) :='<html>
		<body>
         <img src="cid:logo.jpg" alt="logo" width="125" height="100"/>
        <br/>
		<table style="width: 75%;">
        <tbody>
        <tr>
        <td style="width: 35%; background-color: #80ff80;" colspan="2"><strong>Dados do Pagador&nbsp;</strong></td>
        </tr>
        <tr>
        <td style="width: 35%">Nome</td>
        <td style="width: 65%;">pagador_nome</td>
        </tr>
        <tr>
        <td style="width: 35%">Logradouro</td>
        <td style="width: 65%;">pagador_end</td>
        </tr>
        <tr>
        <td style="width: 35%">Complemento</td>
        <td style="width: 65%;">pagador_compl</td>
        </tr>
        <tr>
        <td style="width: 35%">Bairro</td>
        <td style="width: 65%;">pagador_bairro</td>
        </tr>
        <tr>
        <td style="width: 35%">Munic&iacute;pio</td>
        <td style="width: 65%;">pagador_cidade</td>
        </tr>
        <tr>
        <td style="width: 35%">UF</td>
        <td style="width: 65%;">pagador_estado</td>
        </tr>
        <tr>
        <td style="width: 35%">Pa&iacute;s</td>
        <td style="width: 65%;">pagador_pais</td>
        </tr>
        <tr>
        <td style="width: 35%">CEP</td>
        <td style="width: 65%;">pagador_cep</td>
        </tr>
        </tbody>
        </table>
		<br/>
        <table style="width: 75%;">
		<tbody>
        <tr>
        <td style="width: 35%; background-color: #80ff80;" colspan="2"><strong>Dados do Fornecedor&nbsp;</strong></td>
        </tr>
        <tr>
        <td style="width: 35%">Nome</td>
        <td style="width: 65%;">fornecedor_nome</td>
        </tr>
        <tr>
        <td style="width: 35%">Logradouro</td>
        <td style="width: 65%;">fornecedor_end</td>
        </tr>
		<tr>
        <td style="width: 35%">Complemento</td>
        <td style="width: 65%;">fornecedor_compl</td>
        </tr>
        <tr>
        <td style="width: 35%">Bairro</td>
        <td style="width: 65%;">fornecedor_bairro</td>
        </tr>
        <tr>
        <td style="width: 35%">Munic&iacute;pio</td>
        <td style="width: 65%;">fornecedor_cidade</td>
        </tr>
        <tr>
        <td style="width: 35%">Pa&iacute;s</td>
        <td style="width: 65%;">fornecedor_pais</td>
        </tr>
        <tr>
        <td style="width: 35%">CEP</td>
        <td style="width: 65%;">fornecedor_cep</td>
        </tr>
        </tbody>
        </table>
        <br/>
		<table style="width: 75%;">
        <tbody>
        <tr>
        <td style="width: 35%; background-color: #80ff80;" colspan="2"><strong>Dados Bancarios Fornecedor&nbsp;</strong></td>
        </tr>
        <tr>
        <td style="width: 35%">Banco</td>
        <td style="width: 65%;">fornecedor_banco</td>
        </tr>
        <tr>
        <td style="width: 35%">Agencia</td>
        <td style="width: 65%;">fornecedor_agencia</td>
        </tr>
        <tr>
        <td style="width: 35%">Conta</td>
        <td style="width: 65%;">fornecedor_conta</td>
        </tr>
        <tr>
        <td style="width: 35%">Codigo de barras</td>
        <td style="width: 65%;">fornecedor_barra</td>
        </tr>
        
        </tbody>
        </table>
        <br/>
		<table style="width: 75%;">
        <tbody>
        <tr>
        <td style="width: 35%; background-color: #80ff80;" colspan="2"><strong>Informacoes Pagamento&nbsp;</strong></td>
        </tr>
        <tr>
        <td style="width: 35%">Numero</td>
        <td style="width: 65%;">pag_numero</td>
        </tr>
        <tr>
        <td style="width: 35%">Data pagamento</td>
        <td style="width: 65%;">pag_data</td>
        </tr>
        <tr>
        <td style="width: 35%">Moeda pagamento</td>
        <td style="width: 65%;">pag_moeda</td>
        </tr>
        <tr>
        <td style="width: 35%">Quantia pagamento</td>
        <td style="width: 65%;">pag_quantia</td>
        </tr>
        
        </tbody>
        </table>
		<br/>
		<table style="width: 75%;">
        <tbody>
        <tr>
        <td style="width: 35%; background-color: #80ff80;" colspan="5"><strong>Detalhe da Remessa&nbsp;</strong></td>
        </tr>
        <tr>
        <td width="20%">&nbsp;</td>
        <td width="20%">&nbsp;</td>
        <td width="20%">&nbsp;</td>
        <td width="20%">&nbsp;</td>
        <td width="20%">&nbsp;</td>
        </tr>
        <tr>
        <td>N&ordm; Documento</td>
        <td>Data Documento</td>
        <td>Quantia</td>
        <td>Reten&ccedil;&otilde;es</td>
        <td>Valor Pago</td>
        </tr>
        <tr>';


	l_message_to_send_repeat  VARCHAR2(32767) := '<tr>
		<td>nro_documento</td>
		<td>data_documento</td>
		<td>quantia_documento</td>
		<td>ret_documento</td>
		<td>valor_documento</td>
		</tr>';


	l_message_to_send_footer  VARCHAR2(32767) := '<tr>
		<td>&nbsp;</td>
		<td>Total</td>
		<td>total_quantia</td>
		<td>total_ret</td>
		<td>total_valor</td>
		</tr>
		</tbody>
		</table>
		</body>
		</html>';


	
	cursor principal  is
		select base.* ,  nvl(vl_retido,0) + nvl(iss_amount,0) + nvl(ir_amount,0) + nvl(inss_amount,0) as retencao ,0
				  from (select distinct 
							   haou.organization_id                                  organization_id
							 , haou.name                                             empresa
							 , xep.name                                              pagador
							 , hl.address_line_1                                     logradouro_p
							 , hl.address_line_2                                     numero_p
							 , hl.address_line_3                                     complemento_p
							 , hl.region_1                                           bairro_p
							 , hl.town_or_city                                       cidade_p
							 , hl.region_2                                           uf_p
							 , hl.country                                            pais_p
							 , hl.postal_code                                        cep_p     
							 , asu.vendor_name                                       fornecedor
							 , (select case when global_attribute9 = '2' then
											  global_attribute10 || '/' || 
											  global_attribute11 || '-' || 
											  global_attribute12
											when global_attribute9 = '3' then
											  lpad(party_site_id,9,'0') || '/' || 
											  global_attribute11 || '-' || 
											  global_attribute12
											else
											  global_attribute10  || '-' || 
											  global_attribute12
											end cnpj 
								  from apps.ap_supplier_sites_all assa_sc
								 where 1 = 1
								   and assa_sc.vendor_site_id = assa.vendor_site_id) cnpj
							 , assa.address_line1                                    logradouro_f
							 , assa.address_line2                                    numero_f
							 , UTL_I18N.ESCAPE_REFERENCE(assa.address_line3, 'us7ascii')    complemento_f 
							 , assa.address_line4                                    bairro_f      
							 , assa.city                                             cidade_f
							 , assa.state                                            estado_f
							 , assa.country                                          pais_f
							 , assa.zip                                              cep_f           
							 , aca.bank_account_name                                 nome_conta_bancaria_pagto
							 , aca.check_number                                      nr_documento_pgto
							 , aca.check_date                                        data_pagto
							 , aca.currency_code                                     moeda_pagto
							 , apsa.attribute1                                       bar_code
							 , aia.invoice_num                                       nr_nf
							 , aia.invoice_date                                      data_nf
							 , decode(aia.invoice_type_lookup_code,'CREDIT',cfi.gross_total_amount*(-1) ,cfi.gross_total_amount) gross_total_amount
							 , aia.invoice_amount                                    vl_nf
							 , aipa.amount                                           vl_pago
							 , idpa.amount_withheld                                  vl_retido
							 , cfi.iss_amount                                        iss_amount
							 , cfi.ir_amount                                         ir_amount
							 , cfi.inss_amount                                       inss_amount
							 , aca.status_lookup_code                                status_lote_pgto
							 , aia.source                                            source
							 , assa.email_address                                    email_address_old  
							 , iepa.remit_advice_email                               email_address      
							 , cbbv.bank_number                                      nr_banco
							 , cbbv.bank_name                                        nome_banco
							 , cbbv.branch_number                                    nr_agencia
							 , ieba.bank_account_num                                 nr_conta
							 , ieba.check_digits                                     digito  
							 , cfi.operation_id                                      operation_id
							 , apsa.payment_method_code                              payment_method_code
							 , apsa.global_attribute11                               global_attribute11
							 , apsa.global_attribute8                                global_attribute8
							 , fbacda.document_number                                document_number
							 , fbacda.barcode                                        barcode
							 , aca.check_id                                          check_id
							 , aca.attribute10                                       attribute10
						  from apps.hr_all_organization_units     haou
							 , apps.hr_operating_units            hou
							 , apps.hr_locations                  hl
							 , apps.xle_entity_profiles           xep  
							 , apps.ap_suppliers                  asu
							 , apps.ap_supplier_sites_all         assa
							 , apps.ap_invoices_all               aia
							 , apps.ap_invoice_payments_all       aipa
							 , apps.ap_checks_all                 aca
							 , apps.ap_payment_schedules_all      apsa
							 , apps.gl_ledgers                    gl
							 , apps.iby_payment_profiles          ipp
							 , apps.iby_payments_all              ipa
							 , apps.ce_bank_branches_v            cbbv
							 , apps.iby_ext_bank_accounts         ieba
							 , apps.iby_docs_payable_all          idpa
							 , apps.cll_f189_invoices             cfi
							 , apps.jl_br_ap_collection_docs_all  fbacda
							 , apps.iby_external_payees_all       iepa 
						 where 1 = 1
						   and haou.organization_id          = hou.organization_id
						   and haou.location_id              = hl.location_id
						   and hou.default_legal_context_id  = xep.legal_entity_id
						   and haou.organization_id          = aia.org_id
						   and aia.vendor_id                 = asu.vendor_id
						   and aia.vendor_site_id            = assa.vendor_site_id
						   and aia.invoice_id                = aipa.invoice_id
						   and aipa.check_id                 = aca.check_id
						   and aia.invoice_id                = apsa.invoice_id
						   and aipa.set_of_books_id          = gl.ledger_id
						   and aipa.payment_num              = apsa.payment_num
						   and aca.payment_profile_id        = ipp.payment_profile_id 
						   and nvl(aipa.reversal_flag,'N')   = 'N'
						   and aca.payment_id                = ipa.payment_id
						   and aca.payment_id                = idpa.payment_id
						   and aia.invoice_id                = idpa.calling_app_doc_unique_ref2
						   and apsa.external_bank_account_id = ieba.ext_bank_account_id(+)
						   and ieba.branch_id                = cbbv.branch_party_id (+)
						   and cfi.invoice_id                = aia.reference_key1
						   and apsa.global_attribute11       = fbacda.bank_collection_id (+)
						   and assa.vendor_site_id           = iepa.supplier_site_id(+) 
						union all
						select distinct 
							   haou.organization_id                                  organization_id
							 , haou.name                                             empresa
							 , xep.name                                              pagador
							 , hl.address_line_1                                     logradouro_p
							 , hl.address_line_2                                     numero_p
							 , hl.address_line_3                                     complemento_p
							 , hl.region_1                                           bairro_p
							 , hl.town_or_city                                       cidade_p
							 , hl.region_2                                           uf_p
							 , hl.country                                            pais_p
							 , hl.postal_code                                        cep_p     
							 , asu.vendor_name                                       fornecedor
							 , (select case when global_attribute9 = '2' then
											  global_attribute10 || '/' || 
											  global_attribute11 || '-' || 
											  global_attribute12
											when global_attribute9 = '3' then
											  lpad(party_site_id,9,'0') || '/' || 
											  global_attribute11 || '-' || 
											  global_attribute12
											else
											  global_attribute10  || '-' || 
											  global_attribute12
											end cnpj 
								  from apps.ap_supplier_sites_all assa_sc
								 where 1 = 1
								   and assa_sc.vendor_site_id = assa.vendor_site_id) cnpj
							 , assa.address_line1                                    logradouro_f
							 , assa.address_line2                                    numero_f
							 , UTL_I18N.ESCAPE_REFERENCE(assa.address_line3, 'us7ascii')      complemento_f 
							 , assa.address_line4                                    bairro_f      
							 , assa.city                                             cidade_f
							 , assa.state                                            estado_f
							 , assa.country                                          pais_f
							 , assa.zip                                              cep_f           
							 , aca.bank_account_name                                 nome_conta_bancaria_pagto
							 , aca.check_number                                      nr_documento_pgto
							 , aca.check_date                                        data_pagto
							 , aca.currency_code                                     moeda_pagto
							 , apsa.attribute1                                       bar_code
							 , aia.invoice_num                                       nr_nf
							 , aia.invoice_date                                      data_nf             
							 , null gross_total_amount       
							 , aia.invoice_amount                                    vl_nf
							 , aipa.amount                                           vl_pago
							 , idpa.amount_withheld                                  vl_retido
							 , null                                                  iss_amount
							 , null                                                  ir_amount
							 , null                                                  inss_amount
							 , aca.status_lookup_code                                status_lote_pgto
							 , aia.source                                            source
							 , assa.email_address                                    email_address_old 
							 , iepa.remit_advice_email                               email_address     
							 , cbbv.bank_number                                      nr_banco
							 , cbbv.bank_name                                        nome_banco
							 , cbbv.branch_number                                    nr_agencia
							 , ieba.bank_account_num                                 nr_conta
							 , ieba.check_digits                                     digito
							 , null                                                  operation_id
							 , apsa.payment_method_code                              payment_method_code
							 , apsa.global_attribute11                               global_attribute11
							 , apsa.global_attribute8                                global_attribute8
							 , fbacda.document_number                                document_number 
							 , fbacda.barcode                                        barcode
							 , aca.check_id                                          check_id
							 , aca.attribute10                                       attribute_10
						  from apps.hr_all_organization_units     haou
							 , apps.hr_operating_units            hou
							 , apps.hr_locations                  hl
							 , apps.xle_entity_profiles           xep  
							 , apps.ap_suppliers                  asu
							 , apps.ap_supplier_sites_all         assa
							 , apps.ap_invoices_all               aia
							 , apps.ap_invoice_payments_all       aipa
							 , apps.ap_checks_all                 aca
							 , apps.ap_payment_schedules_all      apsa
							 , apps.gl_ledgers                    gl
							 , apps.iby_payment_profiles          ipp
							 , apps.iby_payments_all              ipa
							 , apps.ce_bank_branches_v            cbbv
							 , apps.iby_ext_bank_accounts         ieba
							 , apps.iby_docs_payable_all          idpa
							 , apps.jl_br_ap_collection_docs_all  fbacda
							 , apps.iby_external_payees_all       iepa 
						 where 1 = 1
						   and haou.organization_id          = hou.organization_id
						   and haou.location_id              = hl.location_id
						   and hou.default_legal_context_id  = xep.legal_entity_id
						   and haou.organization_id          = aia.org_id
						   and aia.vendor_id                 = asu.vendor_id
						   and aia.vendor_site_id            = assa.vendor_site_id
						   and aia.invoice_id                = aipa.invoice_id
						   and aipa.check_id                 = aca.check_id
						   and aia.invoice_id                = apsa.invoice_id
						   and aipa.set_of_books_id          = gl.ledger_id
						   and aipa.payment_num              = apsa.payment_num
						   and aca.payment_profile_id        = ipp.payment_profile_id 
						   and nvl(aipa.reversal_flag,'N')   = 'N'
						   and aca.payment_id                = ipa.payment_id
						   and aca.payment_id                = idpa.payment_id
						   and aia.invoice_id                = idpa.calling_app_doc_unique_ref2
						   and apsa.external_bank_account_id = ieba.ext_bank_account_id(+)
						   and ieba.branch_id                = cbbv.branch_party_id (+)
						   and apsa.global_attribute11       = fbacda.bank_collection_id (+)
						   and aia.source                   <> 'CLL F189 INTEGRATED RCV'
						   and assa.vendor_site_id           = iepa.supplier_site_id(+)
						) base
				 where 1 = 1
				   and base.status_lote_pgto         = 'RECONCILED'
				
				   and (base.nr_conta               is not null
					or  base.barcode                is not null)
				   and nvl(base.attribute10,'N')    <> 'Y'
				   and base.organization_id         = nvl (p_org_id, base.organization_id )
				   and base.data_pagto between to_date (p_dt_inicial , 'yyyy/mm/dd hh24:mi:ss' )  
				                           and to_date (p_dt_final , 'yyyy/mm/dd hh24:mi:ss' )   

				-- and  nr_documento_pgto = 7148
				 union all
            
            select
                    0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
                null,-1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
                null,null,null,null,null,null,null,null,null,null,null,1
            from dual
            
            order 
					by 2,12,22,52;


		l_line principal%rowtype;

	begin


		l_nr_document := null;
		
		FND_FILE.PUT(FND_FILE.LOG, 'Data Inicial :' || p_dt_inicial);
		FND_FILE.PUT(FND_FILE.LOG, 'Data Final : '|| p_dt_inicial);


		FOR cPrincipal IN principal
        LOOP
		
			FND_FILE.PUT_LINE(FND_FILE.LOG, 'Nro Documento : '|| cPrincipal.nr_documento_pgto);
			
			l_line := cPrincipal;

            BEGIN

					-- enviar email
					-- teve registro e o proximo é diferente
					if ( l_nr_document is not null and l_nr_document <> cPrincipal.nr_documento_pgto and l_email is not null ) then


						l_message := replace (l_message,'pag_quantia', to_char(l_total_valor ,'FM999G999G990D90', 'nls_numeric_characters='',.''') );
						
						l_message_temp := l_message_to_send_footer ;

						l_message_temp := replace (l_message_temp,'total_quantia', to_char(l_total_quantia ,'FM999G999G990D90', 'nls_numeric_characters='',.''') );
						l_message_temp := replace (l_message_temp,'total_ret', to_char(l_total_retencoes ,'FM999G999G990D90', 'nls_numeric_characters='',.''') );
						l_message_temp := replace (l_message_temp,'total_valor', to_char(l_total_valor ,'FM999G999G990D90', 'nls_numeric_characters='',.''') );

						l_message := l_message || l_message_temp;
						
						i  := null;
						len := null;
						buff_size := 57;
						l_raw  :=  null;
						
						--l_email := 'daniel.pegas@ninecon.com.br';

						SELECT logo into p_image FROM XXSTN.XXSTN_AP_REL_LOGO
									WHERE org_id = l_org_id ;
									
						apps.fnd_file.put_line(apps.fnd_file.log,'Enviando email para  ' || l_email );
						
						
						BEGIN

							--loadfile ( l_filename, p_image );
							conn := utl_smtp.open_connection(MailServer, 25);
							UTL_SMTP.helo (conn, MailServer);
							UTL_SMTP.mail (conn, 'oracleprod@stone.com.br');
							UTL_SMTP.rcpt (conn, l_email);
							UTL_SMTP.open_data (conn);
							UTL_SMTP.write_data (conn, 'From' || ': ' || 'oracleprod@stone.com.br'|| UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn, 'To' || ': ' || l_email || UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn, 'MIME-Version: 1.0' || UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn, 'Subject: Aviso de Pagamento' || UTL_TCP.CRLF) ;
							UTL_SMTP.write_data (conn, 'Content-Type: multipart/mixed; boundary="' || BOUNDARY || '"' || UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn, UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn,  '--' || BOUNDARY || UTL_TCP.CRLF );
							UTL_SMTP.write_data (conn,  'Content-Type: text/html; charset=US-ASCII'|| UTL_TCP.CRLF );
							UTL_SMTP.write_data (conn, l_message|| UTL_TCP.CRLF );
							UTL_SMTP.write_data (conn, '--' || BOUNDARY || UTL_TCP.CRLF );
							UTL_SMTP.write_data (conn, 'Content-Type: image/jpg;'|| UTL_TCP.CRLF );
							UTL_SMTP.write_data (conn, 'Content-Disposition: inline; filename="logo.jpg"' || UTL_TCP.CRLF);
							UTL_SMTP.WRITE_DATA (conn, 'Content-ID:<logo.jpg> ' || UTL_TCP.CRLF); 
							UTL_SMTP.write_data (conn, 'Content-Transfer-Encoding' || ': ' || 'base64' || UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn, UTL_TCP.CRLF);
							i := 1;
							len := dbms_lob.getlength(p_image);
							while i < len
							loop
							  dbms_lob.read(p_image, buff_size, i, l_raw);
							  utl_smtp.write_raw_data(conn, utl_encode.base64_encode(l_raw));
							  utl_smtp.write_data(conn, utl_tcp.crlf);
							  i := i + buff_size;
							end loop;
							utl_smtp.write_data(conn, utl_tcp.crlf);
							UTL_SMTP.write_data (conn, '--' || BOUNDARY || '--' || UTL_TCP.CRLF);
							UTL_SMTP.write_data (conn, UTL_TCP.CRLF);
							UTL_SMTP.close_data (conn);
							UTL_SMTP.quit (conn);
						
						EXCEPTION WHEN OTHERS THEN
							
							UTL_SMTP.close_data (conn);
							UTL_SMTP.quit (conn);
							raise_application_error (sqlcode, sqlerrm);
						END;

					end if;


					-- primeiro registro
					if ( l_nr_document is null or l_nr_document <> cPrincipal.nr_documento_pgto ) then
						
						l_nr_document := cPrincipal.nr_documento_pgto;

						l_email :=  cPrincipal.email_address;
						l_org_id := cPrincipal.organization_id;

						-- um email por remessa
						l_message := l_message_to_send_header;

						l_message := replace (l_message,'pagador_nome', cPrincipal.pagador  );
						l_message := replace (l_message,'pagador_end', cPrincipal.logradouro_p || ' ' || cPrincipal.numero_p  );
						l_message := replace (l_message,'pagador_compl', cPrincipal.complemento_p  );
						l_message := replace (l_message,'pagador_cidade', cPrincipal.cidade_p  );
						l_message := replace (l_message,'pagador_estado', cPrincipal.uf_p  );
						l_message := replace (l_message,'pagador_cep', cPrincipal.cep_p  );
						l_message := replace (l_message,'pagador_bairro', cPrincipal.bairro_p  );
						l_message := replace (l_message,'pagador_pais', cPrincipal.pais_p  );


						l_message := replace (l_message, 'fornecedor_nome', cPrincipal.fornecedor  );
						l_message := replace (l_message,'fornecedor_end', cPrincipal.logradouro_f || ' ' || cPrincipal.numero_f);
						l_message := replace (l_message,'fornecedor_compl', cPrincipal.complemento_f   );
						l_message := replace (l_message,'fornecedor_cidade', cPrincipal.cidade_f  );
					--	l_message := replace (l_message,'fornecedor_estado', cPrincipal.uf_f  );
						l_message := replace (l_message,'fornecedor_cep', cPrincipal.cep_f  );
						l_message := replace (l_message,'fornecedor_bairro', cPrincipal.bairro_f  );
						l_message := replace (l_message,'fornecedor_pais', cPrincipal.pais_f  );

						l_message := replace (l_message,'fornecedor_banco', cPrincipal.nr_banco || '-'||cPrincipal.nome_banco  );
						l_message := replace (l_message,'fornecedor_agencia', cPrincipal.nr_agencia  );
						l_message := replace (l_message,'fornecedor_conta', cPrincipal.nr_conta||'-'||cPrincipal.digito  );
						l_message := replace (l_message,'fornecedor_barra', cPrincipal.barcode  );

						l_message := replace (l_message,'pag_numero', cPrincipal.nr_documento_pgto  );
						l_message := replace (l_message,'pag_data', to_char(cPrincipal.data_pagto, 'DD/MM/YYYY') );
						l_message := replace (l_message,'pag_moeda', cPrincipal.moeda_pagto  );
						

						l_total_quantia		:= 0;
						l_total_retencoes	:= 0;
						l_total_valor		:= 0;

						l_message_temp := l_message_to_send_repeat;

					end if;

					l_total_quantia := l_total_quantia + nvl(cPrincipal.gross_total_amount, cPrincipal.vl_nf) ;
					l_total_retencoes := l_total_retencoes + nvl(cPrincipal.retencao,0)  ;
					l_total_valor := l_total_valor + nvl(cPrincipal.vl_pago,0);
					
					l_message_temp := replace (l_message_temp,'nro_documento', cPrincipal.nr_nf  );
					l_message_temp := replace (l_message_temp,'data_documento', TO_CHAR(cPrincipal.data_nf, 'DD/MM/YYYY')  );
					l_message_temp := replace (l_message_temp,'quantia_documento', to_char(nvl(cPrincipal.gross_total_amount, cPrincipal.vl_nf),'FM999G999G990D90', 'nls_numeric_characters='',.''') );
					l_message_temp := replace (l_message_temp,'ret_documento', to_char(nvl(cPrincipal.vl_retido,0) + nvl(cPrincipal.iss_amount,0) + nvl(cPrincipal.ir_amount,0) + nvl(cPrincipal.inss_amount,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.''') );
					l_message_temp := replace (l_message_temp,'valor_documento', to_char(cPrincipal.vl_pago ,'FM999G999G990D90', 'nls_numeric_characters='',.''') );


					l_message := l_message || l_message_temp;
					l_message_temp := l_message_to_send_repeat;
					
					if ((l_email is null or TRIM(l_email) = '') and l_line.nr_documento_pgto <> '-1')  then
						
						apps.fnd_file.put_line(apps.fnd_file.log,'Email nao encontrado.' );
				
						INSERT INTO XXSTN.XXSTN_AP_REL_LOGO_CONF (
								empresa ,
								org_id,
								pagador ,
								fornecedor ,
								cnpj ,
								nome_conta_bancaria_pagto ,
								nr_documento_pgto ,
								data_pagto ,
								nr_nf ,
								data_nf ,
								quantia ,
								retencoes ,
								vl_pago ,
								email_address ,
								nr_banco ,
								nome_banco ,
								nr_agencia ,
								nr_conta ,
								barcode ,
								mensagem,
								processo ) VALUES
								
								(
										l_line.empresa,
										l_line.organization_id,
										l_line.pagador,
										l_line.fornecedor,
										l_line.cnpj,
										l_line.nome_conta_bancaria_pagto,
										l_line.nr_documento_pgto,
										l_line.data_pagto,
										l_line.nr_nf,
										l_line.data_nf,
										to_char(nvl(l_line.gross_total_amount, l_line.vl_nf) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										to_char(nvl(l_line.retencao,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										to_char(nvl(l_line.vl_pago,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										l_line.email_address,
										l_line.nr_banco,
										l_line.nome_banco,
										l_line.nr_agencia,
										l_line.nr_conta||'-'||l_line.digito,
										l_line.barcode,
										'Não - E-mail do fornecedor não cadastrado.',
										fnd_global.conc_request_id					
								);
								
								commit;
								
								continue;
											
					end if;
					
				
					if ( l_line.nr_documento_pgto <> '-1') then

								INSERT INTO XXSTN.XXSTN_AP_REL_LOGO_CONF (
											empresa ,
											org_id,
											pagador ,
											fornecedor ,
											cnpj ,
											nome_conta_bancaria_pagto ,
											nr_documento_pgto ,
											data_pagto ,
											nr_nf ,
											data_nf ,
											quantia ,
											retencoes ,
											vl_pago ,
											email_address ,
											nr_banco ,
											nome_banco ,
											nr_agencia ,
											nr_conta ,
											barcode ,
											mensagem,
											processo ) VALUES
											
											(
													l_line.empresa,
													l_line.organization_id,
													l_line.pagador,
													l_line.fornecedor,
													l_line.cnpj,
													l_line.nome_conta_bancaria_pagto,
													l_line.nr_documento_pgto,
													l_line.data_pagto,
													l_line.nr_nf,
													l_line.data_nf,
													to_char(nvl(l_line.gross_total_amount, l_line.vl_nf) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
													to_char(nvl(l_line.retencao,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
													to_char(nvl(l_line.vl_pago,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
													l_line.email_address,
													l_line.nr_banco,
													l_line.nome_banco,
													l_line.nr_agencia,
													l_line.nr_conta||'-'||l_line.digito,
													l_line.barcode,
													'Sim',
													fnd_global.conc_request_id					
											);
											
																								
							update ap_checks_all 
							set attribute10 = 'Y'
							where check_id = l_line.check_id;
							
							commit;
								
						end if;
								

				
			exception when no_data_found then
			
				IF (l_line.empresa IS NOT NULL) THEN
					
					update ap_checks_all 
					set attribute10 = null
					where check_id = l_line.check_id;
			
					INSERT INTO XXSTN.XXSTN_AP_REL_LOGO_CONF (
								empresa ,
								org_id,
								pagador ,
								fornecedor ,
								cnpj ,
								nome_conta_bancaria_pagto ,
								nr_documento_pgto ,
								data_pagto ,
								nr_nf ,
								data_nf ,
								quantia ,
								retencoes ,
								vl_pago ,
								email_address ,
								nr_banco ,
								nome_banco ,
								nr_agencia ,
								nr_conta ,
								barcode ,
								mensagem,
								processo ) VALUES
								
								(
										l_line.empresa,
										l_line.organization_id,
										l_line.pagador,
										l_line.fornecedor,
										l_line.cnpj,
										l_line.nome_conta_bancaria_pagto,
										l_line.nr_documento_pgto,
										l_line.data_pagto,
										l_line.nr_nf,
										l_line.data_nf,
										to_char(nvl(l_line.gross_total_amount, l_line.vl_nf) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										to_char(nvl(l_line.retencao,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										to_char(nvl(l_line.vl_pago,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										l_line.email_address,
										l_line.nr_banco,
										l_line.nome_banco,
										l_line.nr_agencia,
										l_line.nr_conta||'-'||l_line.digito,
										l_line.barcode,
										'Nao - Logo não encontrado.',
										fnd_global.conc_request_id					
								);
								
								commit;
								
					END IF;
			
			WHEN OTHERS THEN
			
				dbms_output.put_line ('Processo : ' || SQLERRM);
			
				IF (l_line.empresa IS NOT NULL) THEN
				
					l_erro := SQLERRM;
					
					apps.fnd_file.put_line(apps.fnd_file.log,'Atualizando  ' || cPrincipal.check_id );
								
					update ap_checks_all 
					set attribute10 = null
					where check_id = l_line.check_id;
			
					INSERT INTO XXSTN.XXSTN_AP_REL_LOGO_CONF (
								empresa ,
								org_id,
								pagador ,
								fornecedor ,
								cnpj ,
								nome_conta_bancaria_pagto ,
								nr_documento_pgto ,
								data_pagto ,
								nr_nf ,
								data_nf ,
								quantia ,
								retencoes ,
								vl_pago ,
								email_address ,
								nr_banco ,
								nome_banco ,
								nr_agencia ,
								nr_conta ,
								barcode ,
								mensagem,
								processo ) VALUES
								
								(
										l_line.empresa,
										l_line.organization_id,
										l_line.pagador,
										l_line.fornecedor,
										l_line.cnpj,
										l_line.nome_conta_bancaria_pagto,
										l_line.nr_documento_pgto,
										l_line.data_pagto,
										l_line.nr_nf,
										l_line.data_nf,
										to_char(nvl(l_line.gross_total_amount, l_line.vl_nf) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										to_char(nvl(l_line.retencao,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										to_char(nvl(l_line.vl_pago,0) ,'FM999G999G990D90', 'nls_numeric_characters='',.'''),
										l_line.email_address,
										l_line.nr_banco,
										l_line.nome_banco,
										l_line.nr_agencia,
										l_line.nr_conta||'-'||l_line.digito,
										l_line.barcode,
										'Nao - ' || l_erro,
										fnd_global.conc_request_id					
								);
								
								commit;
								
				END IF;
			
		
			END;

		END LOOP;
		
		BEGIN
            --
            BEGIN
              SELECT xtv.application_short_name
                    ,xtv.template_code
                    ,xtv.default_language
                    ,xtv.mls_territory
                    ,xtv.default_output_type
                INTO l_vXdo_Short_Name
                    ,l_vTemplate_Code
                    ,l_vDefault_Lang
                    ,l_vTerritory
                    ,l_vOut_Type_Code
                FROM xdo_templates_vl xtv
               WHERE template_code = 'XXSTN_AP_REL_LOGO_CONF';
            EXCEPTION
              WHEN OTHERS THEN
              apps.fnd_file.put_line(apps.fnd_file.log,'Erro ao localizar o Setup do Template_Code XXSTN_AP_REL_LOGO_CONF: ' || SQLERRM );
              raise_application_error( -20112,' Erro ao localizar o Setup do Template_Code XXSTN_AP_REL_LOGO_CONF : ' || SQLERRM );
            END;
            --
            apps.fnd_file.put_line(apps.fnd_file.log,'Template_Code  ' || l_vTemplate_Code );
            --
            l_bLayout_Xml := apps.FND_REQUEST.ADD_LAYOUT( l_vXdo_Short_Name
                                                        , l_vTemplate_Code
                                                        , l_vDefault_Lang
                                                        , l_vTerritory
                                                        , l_vOut_Type_Code
                                                        );
            --
            IF l_bLayout_Xml THEN
              l_nRequest_Id := apps.fnd_request.submit_request('XXSN'
                                                              ,'XXSTN_AP_REL_LOGO_CONF'
                                                              ,'XXSTN - AP - Relatório de Conferência de Aviso de Pagamento'
                                                              ,SYSDATE
                                                              ,FALSE
                                                              ,fnd_global.conc_request_id
                                                              ,p_dt_inicial
                                                              ,p_dt_final
															  ,null
                                                              );
              --
              COMMIT;
              apps.fnd_file.put_line(apps.fnd_file.log,'After call concurrent Excel: ' || l_nRequest_Id );
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              l_nRequest_Id := 0;
              apps.fnd_file.put_line(apps.fnd_file.output, 'XXSTN - AP - Relatório de Conferência de Aviso de Pagamento: ' || SQLERRM );
          END;


	END SENDMAIL;

END;
/