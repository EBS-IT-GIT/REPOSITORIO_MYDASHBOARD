==============================================================================
CUSPO056_002 : Requisi��o de Aditivo para Blankets
==============================================================================

Atualiza��o - CUSPO056_002
Produto     - XX Customizaciones
Data        - 12/06/2020 12:05:55
HotPatch    - N�o
Fornecedor  - DBS-Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSPO056_002

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

Realizar um Bounce no OACORE


Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

Patch's  aplicados =>  u121CUSPO056_001
                                         
                 

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: jSAECUSPO056.zip
                               SAE_PO_REQ_ADTV_BLANK_PKS.pls 
                               SAE_PO_REQ_ADTV_BLANK_PKB.pls 
                               SAE_ICX_ADTV_CMPR_DRTA_PKS.pls
                               SAE_ICX_ADTV_CMPR_DRTA_PKB.pls
