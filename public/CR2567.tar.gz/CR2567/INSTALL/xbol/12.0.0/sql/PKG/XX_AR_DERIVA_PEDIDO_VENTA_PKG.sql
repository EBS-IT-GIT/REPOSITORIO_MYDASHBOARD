  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_DERIVA_PEDIDO_VENTA_PKG" AS

  PROCEDURE deriva_pv ( p_batch_source_id        NUMBER
                      , p_cust_trx_type_id       NUMBER
                      , p_receipt_method_id      NUMBER
                      , p_trx_date               DATE
                      , p_conversion_date        DATE
                      , p_header_id              NUMBER
                      , p_shipping_note          VARCHAR2
                      , p_ship_to_org_id         NUMBER
                      , p_inv_to_org_id          NUMBER
                      , x_customer_trx_id    OUT NUMBER
                      , x_error_message      OUT VARCHAR2
                      );

END XX_AR_DERIVA_PEDIDO_VENTA_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_DERIVA_PEDIDO_VENTA_PKG" AS

  PROCEDURE deriva_pv ( p_batch_source_id        NUMBER
                      , p_cust_trx_type_id       NUMBER
                      , p_receipt_method_id      NUMBER
                      , p_trx_date               DATE
                      , p_conversion_date        DATE
                      , p_header_id              NUMBER
                      , p_shipping_note          VARCHAR2
                      , p_ship_to_org_id         NUMBER
                      , p_inv_to_org_id          NUMBER
                      , x_customer_trx_id    OUT NUMBER
                      , x_error_message      OUT VARCHAR2
                      ) IS

    CURSOR cH IS
      SELECT oh.header_id
           , ot.name                tipo_pedido
           , oh.order_number        pedido_venta
           , ca.cust_account_id
           , hp.party_name          cliente
           , oh.transactional_curr_code
           , mf.moneda_fun
           , oh.conversion_type_code
           , oh.conversion_rate
           , oh.conversion_rate_date
           , oh.payment_term_id
           , oh.ordered_date        fecha_solicitud
           , oh.creation_date       fecha_creacion
      FROM oe_order_headers          oh
         , hz_cust_accounts_all      ca
         , hz_parties                hp
         , oe_transaction_types_tl   ot
         , (SELECT DISTINCT od.operating_unit, sob.currency_code moneda_fun
            FROM org_organization_definitions od
               , gl_sets_of_books             sob
            WHERE 1=1
            AND sob.set_of_books_id = od.set_of_books_id
           )                        mf
      WHERE 1=1
      AND ca.cust_account_id    = oh.sold_to_org_id
      AND hp.party_id           = ca.party_id
      AND ot.transaction_type_id = oh.order_type_id
      AND ot.language           = 'ESA'
      AND mf.operating_unit(+)  = oh.org_id
      AND oh.header_id          = p_header_id;

    CURSOR cL IS
      SELECT ol.line_id
           , ol.line_number||'.'||ol.shipment_number numero_linea
           , ol.inventory_item_id
           , msi.segment1           articulo
           , msi.description        articulo_desc
           , ol.order_quantity_uom  um
           , dpv.quantity           cantidad
           , ol.unit_selling_price  precio_venta
           , ol.ship_from_org_id
           , ol.ship_to_org_id
           , ol.invoice_to_org_id
           , dpv.translated_description
      FROM xx_ar_deriva_pedido_venta dpv
         , oe_order_lines_all        ol
         , mtl_system_items          msi
      WHERE 1=1
      AND ol.line_id            = dpv.line_id
      AND msi.organization_id   = ol.ship_from_org_id
      AND msi.inventory_item_id = ol.inventory_item_id
      AND dpv.process_flag      = 'Y'
      AND dpv.customer_trx_id   IS NULL
      AND ol.header_id          = p_header_id
      ;

    CURSOR list_errors IS
      SELECT trx_header_id, trx_line_id, trx_salescredit_id, trx_dist_id, trx_contingency_id, error_message, invalid_value
      FROM ar_trx_errors_gt;

    rH                     cH%ROWTYPE;

    l_return_status        VARCHAR2(1);
    l_msg_count            NUMBER;
    l_msg_data             VARCHAR2(2000);
    l_batch_id             NUMBER;
    l_cnt                  NUMBER;
    l_batch_source_rec     AR_INVOICE_API_PUB.batch_source_rec_type;
    l_trx_header_tbl       AR_INVOICE_API_PUB.trx_header_tbl_type;
    l_trx_lines_tbl        AR_INVOICE_API_PUB.trx_line_tbl_type;
    l_trx_dist_tbl         AR_INVOICE_API_PUB.trx_dist_tbl_type;
    l_trx_salescredits_tbl AR_INVOICE_API_PUB.trx_salescredits_tbl_type;
    l_tax_rate             NUMBER;
    l_customer_trx_id      NUMBER;
    l_idx                  NUMBER;
    l_trx_header_id        NUMBER;
    l_trx_line_id          NUMBER;
    l_order_type           VARCHAR2(250);
    l_order_number         VARCHAR2(50);
    eNoData                EXCEPTION;
  BEGIN

   -- c. Set the applications context
    MO_GLOBAL.INIT('AR');
    MO_GLOBAL.SET_POLICY_CONTEXT('S',FND_GLOBAL.ORG_ID);
    FND_GLOBAL.APPS_INITIALIZE(FND_GLOBAL.USER_ID, FND_GLOBAL.RESP_ID, FND_GLOBAL.RESP_APPL_ID);

    --CABECERA
    OPEN cH;
    FETCH cH INTO rH;
    IF cH%NOTFOUND THEN
      RAISE eNoData;
    END IF;
    CLOSE cH;
    -- d. Populate batch source information.
    l_batch_source_rec.batch_source_id := p_batch_source_id;


    SELECT RA_CUSTOMER_TRX_S.nextval
    INTO l_trx_header_id
    FROM DUAL;

    -- e. Populate header information.
    l_trx_header_tbl(1).trx_header_id       := l_trx_header_id;
    l_trx_header_tbl(1).cust_trx_type_id    := p_cust_trx_type_id;
    l_trx_header_tbl(1).trx_date            := p_trx_date;

    l_trx_header_tbl(1).trx_currency        := rH.transactional_curr_code;

    IF rH.transactional_curr_code != rH.moneda_fun THEN
      l_trx_header_tbl(1).exchange_rate_type  := rH.conversion_type_code;
      l_trx_header_tbl(1).exchange_date       := rH.conversion_rate_date;
      l_trx_header_tbl(1).exchange_rate       := rH.conversion_rate;

      IF rH.conversion_type_code = 'Corporate' THEN
        l_trx_header_tbl(1).exchange_date := p_conversion_date;
      END IF;
    ELSE
      l_trx_header_tbl(1).exchange_rate_type  := NULL;
      l_trx_header_tbl(1).exchange_date       := NULL;
      l_trx_header_tbl(1).exchange_rate       := NULL;
    END IF;

    l_trx_header_tbl(1).term_id             := rH.payment_term_id;
    l_trx_header_tbl(1).receipt_method_id   := p_receipt_method_id;

    l_trx_header_tbl(1).ship_to_customer_id := rH.cust_account_id;
    l_trx_header_tbl(1).ship_to_site_use_id := p_ship_to_org_id;

    l_trx_header_tbl(1).bill_to_customer_id := rH.cust_account_id;
    l_trx_header_tbl(1).bill_to_site_use_id := p_inv_to_org_id;

    l_trx_header_tbl(1).sold_to_customer_id := rH.cust_account_id;

    l_trx_header_tbl(1).attribute_category  := FND_PROFILE.value('DEFAULT_COUNTRY');

    l_trx_header_tbl(1).interface_header_context    := 'ORDER ENTRY';
    l_trx_header_tbl(1).interface_header_attribute1 := rH.pedido_venta;
    l_trx_header_tbl(1).interface_header_attribute2 := rH.tipo_pedido;

    l_order_type   := rH.tipo_pedido;
    l_order_number := rH.pedido_venta;

    l_trx_header_tbl(1).global_attribute_category := 'JL.AR.ARXTWMAI.TGW_HEADER';


    --LINEAS
    FOR rL IN cL LOOP
      -- f. Populate line 1 information.
      SELECT RA_CUSTOMER_TRX_LINES_S.nextval
      INTO l_trx_line_id
      FROM DUAL;

      l_idx := cL%ROWCOUNT;
      l_trx_lines_tbl(l_idx).trx_header_id := l_trx_header_id;
      l_trx_lines_tbl(l_idx).trx_line_id   := l_trx_line_id;

      l_trx_lines_tbl(l_idx).line_number        := l_idx;
      l_trx_lines_tbl(l_idx).inventory_item_id  := rL.inventory_item_id;
      l_trx_lines_tbl(l_idx).description        := rL.articulo_desc;
      l_trx_lines_tbl(l_idx).uom_code           := rL.um;
      l_trx_lines_tbl(l_idx).quantity_invoiced  := rL.cantidad;
      l_trx_lines_tbl(l_idx).unit_selling_price := rL.precio_venta;
      l_trx_lines_tbl(l_idx).line_type          := 'LINE';

      l_trx_lines_tbl(l_idx).attribute_category := FND_PROFILE.value('DEFAULT_COUNTRY');

      l_trx_lines_tbl(l_idx).interface_line_context    := 'ORDER ENTRY';
      l_trx_lines_tbl(l_idx).interface_line_attribute1 := rH.pedido_venta;
      l_trx_lines_tbl(l_idx).interface_line_attribute2 := rH.tipo_pedido;
      l_trx_lines_tbl(l_idx).interface_line_attribute6 := rL.line_id;

      l_trx_lines_tbl(l_idx).global_attribute_category := 'JL.AR.ARXTWMAI.LINES';

      l_trx_lines_tbl(l_idx).warehouse_id       := rL.ship_from_org_id;

    END LOOP;

    -- j. Call the invoice api to create the invoice
    AR_INVOICE_API_PUB.create_single_invoice
    ( p_api_version          => 1.0
    , p_init_msg_list        => FND_API.G_TRUE
    , p_commit               => FND_API.G_FALSE
    , p_batch_source_rec     => l_batch_source_rec
    , p_trx_header_tbl       => l_trx_header_tbl
    , p_trx_lines_tbl        => l_trx_lines_tbl
    , p_trx_dist_tbl         => l_trx_dist_tbl
    , p_trx_salescredits_tbl => l_trx_salescredits_tbl
    , x_customer_trx_id      => l_customer_trx_id
    , x_return_status        => l_return_status
    , x_msg_count            => l_msg_count
    , x_msg_data             => l_msg_data
    );

    -- j. Check for errors
    IF l_return_status = FND_API.g_ret_sts_error OR
       l_return_status = FND_API.g_ret_sts_unexp_error THEN
      x_error_message := 'Error inesperado en API.';
    ELSE
      SELECT count(*)
      INTO l_cnt
      FROM ar_trx_errors_gt;

      IF l_cnt = 0 THEN
        AR_TRANSACTION_GRP.INCOMPLETE_TRANSACTION
        ( p_api_version      => 1.0
        , p_init_msg_list    => FND_API.G_TRUE
        , p_commit           => FND_API.G_FALSE
        , p_customer_trx_id  => l_customer_trx_id
        , x_return_status    => l_return_status
        , x_msg_count        => l_msg_count
        , x_msg_data         => l_msg_data
        );

        x_customer_trx_id := l_customer_trx_id;
        x_error_message   := 'OK';

        UPDATE ra_customer_trx_all
        SET attribute5  = l_order_type
          , attribute6  = l_order_number
          , attribute11 = p_shipping_note
        WHERE customer_trx_id = l_customer_trx_id;

        FOR rL IN cL LOOP
          UPDATE ra_customer_trx_lines_all
          SET translated_description = rl.translated_description
          WHERE 1=1
          AND customer_trx_id = l_customer_trx_id
          AND interface_line_attribute6 = rl.line_id
          ;
        END LOOP;

      ELSE
         FOR i in list_errors LOOP
           IF list_errors%ROWCOUNT = 1 THEN
             x_error_message := i.error_message;
           ELSE
             x_error_message := x_error_message||'. '||i.error_message;
           END IF;
         END LOOP;
      END IF;
    END IF;

  EXCEPTION
    WHEN eNoData THEN
      x_error_message := 'No se encontraron datos del PV.';
    WHEN OTHERS THEN
      x_error_message := 'Error general inesperado. '||SQLERRM;
  END deriva_pv;

END XX_AR_DERIVA_PEDIDO_VENTA_PKG;
/

exit
