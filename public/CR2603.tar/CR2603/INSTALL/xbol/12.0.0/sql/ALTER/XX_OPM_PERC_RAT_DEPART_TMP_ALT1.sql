  set define off;
ALTER TABLE bolinf.xx_opm_perc_rat_depart_tmp ADD (und_produtiva_recebido VARCHAR2(5));

exit
