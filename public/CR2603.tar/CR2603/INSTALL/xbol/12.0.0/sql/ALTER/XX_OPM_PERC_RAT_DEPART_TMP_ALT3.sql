  set define off;
ALTER TABLE bolinf.xx_opm_perc_rat_depart_tmp ADD (c_c_recebido VARCHAR2(10));

exit
