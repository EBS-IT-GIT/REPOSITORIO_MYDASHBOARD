set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AP_FACT_NO_VALIDADAS_PK" AS

/****************************************************************************
 *                                                                                                                                                   *
 * Name    : MAIN_FNV                                                                                                                    *
 * Purpose : Procedimiento principal que crea el listado de Facturas no                                                *
 *           Validadas                                                                                                                          *
 *                                                                                                                                                   *
 ****************************************************************************/
--    PROCEDURE MAIN_FNV(errbuf      OUT VARCHAR2
--                      ,retcode     OUT VARCHAR2
--                      ,p_directory IN  VARCHAR2
--                      ,p_ccopia    IN  VARCHAR2
--                      ,p_holds     IN  VARCHAR2
--                      ,p_mail_para IN  VARCHAR2
--                      );


/****************************************************************************
 *                                                                                                                                                     *
 * Name    : MAIN_FNVR                                                                                                                     *
 * Purpose : Procedimiento principal que crea el listado de Facturas no                                                   *
 *           Validadas y/o retenidas                                                                                                         *
 *            Aviso: Para pasar a PRODUCCION quitar el harcodeo en el env�de los mails y modificar           *
 *                      el asunto y el texto de los mail                                                                                    *
 ****************************************************************************/
  PROCEDURE MAIN_FNVR (errbuf           OUT VARCHAR2
                      ,retcode          OUT VARCHAR2
                      ,p_envia_mail     IN  VARCHAR2
                      ,p_ret_fin        IN  VARCHAR2
                      ,p_comprob        IN  VARCHAR2
                      ,p_retencion      IN  VARCHAR2
                      ,p_directorio     IN  VARCHAR2
                      ,p_chk_envia_mail IN  VARCHAR2
                      ,p_envia_user     IN  VARCHAR2
                      ,p_dest_copia     IN  VARCHAR2
                      ,p_id_proveedor   IN  VARCHAR2
                      ,p_fecha_desde    IN  VARCHAR2
                      ,p_fecha_hasta    IN  VARCHAR2
                      );

  PROCEDURE concat (x_value     IN OUT NOCOPY VARCHAR2,
                    p_new_value IN VARCHAR2,
                    p_separador IN VARCHAR2);


END XX_AP_FACT_NO_VALIDADAS_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AP_FACT_NO_VALIDADAS_PK" AS


--  PROCEDURE MAIN_FNV(errbuf       OUT VARCHAR2
--                    ,retcode      OUT VARCHAR2
--                    ,p_directory  IN  VARCHAR2
--                    ,p_ccopia     IN  VARCHAR2
--                    ,p_holds      IN  VARCHAR2
--                    ,p_mail_para  IN  VARCHAR2
--                    )
--  IS

--  CURSOR c_invoices IS
--    SELECT ai.invoice_amount                                                      MONTO,
--           ai.invoice_currency_code                                               MONEDA,
--           ai.invoice_date                                                        FECHA,
--           ai.invoice_num                                                         NUMERO,
--           ai.invoice_type_lookup_code                                            TIPO,
--           pv.vendor_name                                                         PROVEEDOR,
--           pv.segment1                                                            NUM_PROVEEDOR,
--           DECODE(AP_INVOICES_PKG.get_approval_status(ai.invoice_id,
--                                                      ai.invoice_amount,
--                                                      ai.payment_status_flag,
--                                                      ai.invoice_type_lookup_code),
--                 'NEVER APPROVED','No Validada',
--                 'NEEDS REAPPROVAL','Necesita Reval',
--                 'Otro')                                                          ESTADO,
--           name                                                                   EMPRESA,
--           fnd.user_name                                                          USUARIO,
--           -- Agregado CR1269 QUITAR AL PASAR A PROD!!!!!
--           DECODE(fnd.user_name,'CTORRES',fnd.email_address
--                               ,'ASILVA',fnd.email_address
--                               ,'LPAATS',fnd.email_address
--                               ,'PPANNUNZIO',fnd.email_address
--                               ,'nasilva@adecoagro.com')                          MAIL,
--           --
--           ai.pay_group_lookup_code                                               GRUPO_PAGO
--    FROM AP_INVOICES_ALL            ai,
--         FND_USER                   fnd,
--         PO_VENDORS                 pv,
--         HR_ALL_ORGANIZATION_UNITS  haou
--    WHERE AP_INVOICES_PKG.get_approval_status(ai.invoice_id,
--                                              ai.invoice_amount,
--                                              ai.payment_status_flag,
--                                              ai.invoice_type_lookup_code) IN ('NEEDS REAPPROVAL',
--                                                                               'NEVER APPROVED')
--    AND   ai.vendor_id           = pv.vendor_id
--    AND   fnd.user_id            = ai.created_by
--    AND   ai.org_id              = haou.organization_id
--    AND   TRUNC(ai.invoice_date) > TO_DATE('31/12/2009', 'DD/MM/YYYY')
--    ORDER BY fnd.email_address,
--             ai.invoice_date,
--             ai.invoice_num;

--  CURSOR c_invoices_and_holds IS
--    SELECT ai.invoice_amount                                                      MONTO,
--           ai.invoice_currency_code                                               MONEDA,
--           ai.invoice_date                                                        FECHA,
--           ai.invoice_num                                                         NUMERO,
--           ai.invoice_type_lookup_code                                            TIPO,
--           pv.vendor_name                                                         PROVEEDOR,
--           pv.segment1                                                            NUM_PROVEEDOR,
--           DECODE (AP_INVOICES_PKG.get_approval_status(ai.invoice_id,
--                                                       ai.invoice_amount,
--                                                       ai.payment_status_flag,
--                                                       ai.invoice_type_lookup_code),
--                   'NEVER APPROVED', 'No Validada',
--                   'NEEDS REAPPROVAL', 'Necesita Reval',
--                   'Otro')                                                        ESTADO,
--           aha.hold_name                                                          RETENCION,
--           name                                                                   EMPRESA,
--           fnd.user_name                                                          USUARIO,
--           -- Agregado CR1269 QUITAR AL PASAR A PROD!!!!!
--           DECODE(fnd.user_name,'CTORRES',TRIM(fnd.email_address)
--                               ,'ASILVA',TRIM(fnd.email_address)
--                               ,'LPAATS',TRIM(fnd.email_address)
--                               ,'PPANNUNZIO',TRIM(fnd.email_address)
--                               ,'nasilva@adecoagro.com')                          MAIL,
--           --
--           ai.pay_group_lookup_code                                               GRUPO_PAGO
--    FROM AP_INVOICES_ALL            ai,
--         FND_USER                   fnd,
--         AP_HOLDS_V                 aha,
--         PO_VENDORS                 pv,
--         HR_ALL_ORGANIZATION_UNITS  haou
--    WHERE AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                               ai.invoice_amount,
--                                               ai.payment_status_flag,
--                                               ai.invoice_type_lookup_code) IN ('NEEDS REAPPROVAL', 'NEVER APPROVED')
--    AND   ai.vendor_id           = pv.vendor_id
--    AND   aha.invoice_id (+)     = ai.invoice_id
--    AND   fnd.user_id            = ai.created_by
--    AND   ai.org_id              = haou.organization_id
--    AND   TRUNC(ai.invoice_date) > TO_DATE('31/12/2009', 'DD/MM/YYYY')
--    --Agregado CR1269
--    AND   (aha.invoice_id IS NULL OR (aha.invoice_id IS NOT NULL AND aha.release_date IS NULL))
--    --
--    ORDER BY fnd.email_address,
--             ai.invoice_date,
--             ai.invoice_num;


--    TYPE LINEA_ENVIOS IS RECORD
--    (DESTINATARIO VARCHAR2(240),
--     ARCHIVO      VARCHAR2(240),
--     ASUNTO       VARCHAR2(240)
--     );

--    TYPE ENVIOS_MAIL IS TABLE OF
--      linea_envios NOT NULL
--    INDEX BY BINARY_INTEGER;

--    v_envios      ENVIOS_MAIL;
--    v_file_name   VARCHAR2(240);
--    v_subject     VARCHAR2(240);
--    v_textmail    VARCHAR2(240);
--    v_mail        VARCHAR2(240);
--    v_exists      NUMBER;
--    v_rep_file    UTL_FILE.file_type;
--    v_separator   VARCHAR2(1):= '|';
--    v_text        VARCHAR2(32760);
--    v_inv_count   NUMBER:=0;
--    e_Error       EXCEPTION;
--    v_req_id      NUMBER;
--    v_empresa     VARCHAR2(240);

--  BEGIN

--    --Destinatario
--    v_mail := 'sin_destinatario';
--    --Texto del mail:
--    v_textmail  := '//DESARROLLO EN TEST - NO CONSIDERAR // Listado de facturas no validadas , ver adjunto';


--    BEGIN

--      IF nvl(p_holds,'Y')='Y' THEN


--        -- Se recorre el cursor para crear los archivos con las lineas de facturas
--        FOR r_inv_holds IN c_invoices_and_holds LOOP

--          IF v_mail = r_inv_holds.mail THEN

--            v_text := r_inv_holds.monto         || v_separator ||
--                      r_inv_holds.moneda        || v_separator ||
--                      r_inv_holds.fecha         || v_separator ||
--                      r_inv_holds.numero        || v_separator ||
--                      r_inv_holds.grupo_pago    || v_separator ||
--                      r_inv_holds.tipo          || v_separator ||
--                      r_inv_holds.proveedor     || v_separator ||
--                      r_inv_holds.num_proveedor || v_separator ||
--                      r_inv_holds.estado        || v_separator ||
--                      r_inv_holds.retencion     || v_separator ||
--                      r_inv_holds.empresa       || v_separator ||
--                      r_inv_holds.usuario;

--            UTL_FILE.put_line(v_rep_file,v_text);
--            FND_FILE.put_line(FND_FILE.output,v_text);

--          ELSE

--            -- Antes de comenzar un nuevo destinatario, se cierra el archivo anterior
--            IF v_inv_count>0 THEN
--              UTL_FILE.fclose(v_rep_file);
--            END IF;

--          --Asunto del mail:
--            v_subject:= '//TEST// Facturas no validadas o que necesitan revalidacion - '
--                        ||SUBSTR(r_inv_holds.empresa,+1,INSTR(r_inv_holds.empresa,' UO',1)-1);

--            v_inv_count := v_inv_count + 1;
--            v_mail      := NVL(r_inv_holds.mail,p_ccopia); -- Si el usuario no tiene mail, se envia la
--                                                           -- notificacion a quien deba estar en copia
--            v_file_name := 'XX_AP_Facturas_No_Validadas_'||REPLACE(SUBSTR(r_inv_holds.empresa,+1,INSTR(r_inv_holds.empresa,' UO',1)-1),' ','_')
--                           ||'_'||TO_CHAR(SYSDATE,'DD_Mon_YYYY_HH24_MI_SS')||'_'||v_inv_count
--                           --Modificado CR1269
--                           --||'.txt';
--                           ||'.csv';
--                           --


--            -- Se completa la tabla PL para despues hacer el envio de mail
--            v_envios(v_inv_count).destinatario:= v_mail;
--            v_envios(v_inv_count).archivo     := v_file_name;
--            v_envios(v_inv_count).asunto      := v_subject;


--            v_rep_file  := UTL_FILE.fopen(p_directory,v_file_name,'A',32760);

--            v_text      := 'MONTO'          || v_separator ||
--                           'MONEDA'         || v_separator ||
--                           'FECHA'          || v_separator ||
--                           'NUM FACT'       || v_separator ||
--                           'G DE PAGO'      || v_separator ||
--                           'TIPO'           || v_separator ||
--                           'PROVEEDOR'      || v_separator ||
--                           'NUM PROV'       || v_separator ||
--                           'ESTADO'         || v_separator ||
--                           'RETENCION'      || v_separator ||
--                           'EMPRESA'        || v_separator ||
--                           'USUARIO';

--            UTL_FILE.put_line(v_rep_file,v_text);
--            FND_FILE.put_line(FND_FILE.output,v_text);

--            v_text := r_inv_holds.monto         || v_separator ||
--                      r_inv_holds.moneda        || v_separator ||
--                      r_inv_holds.fecha         || v_separator ||
--                      r_inv_holds.numero        || v_separator ||
--                      r_inv_holds.grupo_pago    || v_separator ||
--                      r_inv_holds.tipo          || v_separator ||
--                      r_inv_holds.proveedor     || v_separator ||
--                      r_inv_holds.num_proveedor || v_separator ||
--                      r_inv_holds.estado        || v_separator ||
--                      r_inv_holds.retencion     || v_separator ||
--                      r_inv_holds.empresa       || v_separator ||
--                      r_inv_holds.usuario;

--            UTL_FILE.put_line(v_rep_file,v_text);
--            FND_FILE.put_line(FND_FILE.output,v_text);

--          END IF;

--        END LOOP;

--        UTL_FILE.fclose(v_rep_file);


--      ELSIF p_holds='N' THEN

--        BEGIN

--          SELECT name
--          INTO v_empresa
--          FROM HR_OPERATING_UNITS
--          WHERE organization_id = FND_PROFILE.value('ORG_ID');

--        EXCEPTION
--          WHEN others THEN
--            v_empresa:= '';
--        END;

--        --Solo se envia listado completo a los destinatarios asignados
--        v_mail      := p_mail_para;
--        v_file_name := 'XX_AP_Facturas_No_Validadas_'||REPLACE(SUBSTR(v_empresa,+1,INSTR(v_empresa,' UO',1)-1),' ','_')
--                       ||'_'||TO_CHAR(SYSDATE,'DD_Mon_YYYY_HH24_MI_SS')
--                       --Modificado CR1269
--                       --||'txt';
--                       ||'.csv';
--                       --

--        -- Se completa la tabla PL para despues hacer el envio de mail
--        v_envios(1).destinatario:= v_mail;
--        v_envios(1).archivo     := v_file_name;
--        v_envios(1).asunto   := '//TEST// Facturas No Validadas '||v_empresa;

--        v_rep_file  := UTL_FILE.fopen(p_directory,v_file_name,'W',32760);

--        v_text      := 'MONTO'          || v_separator ||
--                       'MONEDA'         || v_separator ||
--                       'FECHA'          || v_separator ||
--                       'NUM FACTURA'    || v_separator ||
--                       'GRUPO DE PAGO'  || v_separator ||
--                       'TIPO'           || v_separator ||
--                       'PROVEEDOR'      || v_separator ||
--                       'NUM PROV'       || v_separator ||
--                       'ESTADO'         || v_separator ||
--                       'EMPRESA'        || v_separator ||
--                       'USUARIO';

--        UTL_FILE.put_line(v_rep_file,v_text);
--        FND_FILE.put_line(FND_FILE.output,v_text);

--        FOR r_invoices IN c_invoices LOOP

--          v_text := r_invoices.monto         || v_separator ||
--                    r_invoices.moneda        || v_separator ||
--                    r_invoices.fecha         || v_separator ||
--                    r_invoices.numero        || v_separator ||
--                    r_invoices.grupo_pago    || v_separator ||
--                    r_invoices.tipo          || v_separator ||
--                    r_invoices.proveedor     || v_separator ||
--                    r_invoices.num_proveedor || v_separator ||
--                    r_invoices.estado        || v_separator ||
--                    r_invoices.empresa       || v_separator ||
--                    r_invoices.usuario;

--          UTL_FILE.put_line(v_rep_file,v_text);
--          FND_FILE.put_line(FND_FILE.output,v_text);
--          v_inv_count:= v_inv_count+1;

--        END LOOP;

--        UTL_FILE.fclose(v_rep_file);

--        IF v_inv_count>0 THEN
--          v_inv_count:= 1; --Solo se necesita enviar un solo archivo en este caso
--        END IF;

--      END IF;

--    EXCEPTION

--      WHEN UTL_FILE.write_error THEN
--        IF UTL_FILE.is_open(v_rep_file ) THEN
--          UTL_FILE.fclose(v_rep_file);
--        END IF;
--        FND_FILE.put_line(FND_FILE.log,'UTL FILE ERROR An error occured writing data into output file. ');
--        RAISE e_Error;

--      WHEN UTL_FILE.invalid_path THEN
--        IF UTL_FILE.is_open(v_rep_file) THEN
--          UTL_FILE.fclose(v_rep_file);
--        END IF;
--        FND_FILE.put_line(FND_FILE.log,'UTL FILE ERROR Invalid output Path');
--        RAISE e_Error;

--      WHEN UTL_FILE.invalid_operation THEN
--        IF UTL_FILE.is_open(v_rep_file ) THEN
--          UTL_FILE.fclose(v_rep_file);
--        END IF;
--        FND_FILE.put_line(FND_FILE.log,'INVALID_OPERATION error occured writing data into output file.');
--        RAISE e_Error;

--      WHEN others THEN
--        FND_FILE.put_line(FND_FILE.log,'Oracle Err: ' || SQLERRM);
--        RAISE e_Error;
--    END;


--    -- Envios de mail
--    IF NVL(v_inv_count,0)>0 THEN

--      BEGIN

--        FOR i IN v_envios.FIRST..v_envios.LAST
--        LOOP

--          v_req_id:= FND_REQUEST.submit_request('XBIL',                               --application
--                                                'XXAPFNVEM',                          --program
--                                                NULL,                                 --description
--                                                NULL,                                 --start_time
--                                                FALSE,                                --sub_request
--                                                p_directory||'/'||
--                                                v_envios(i).archivo,                  --argument1
--                                                v_envios(i).asunto,                   --argument2
--                                                v_envios(i).destinatario,             --argument3
--                                                p_ccopia,                             --argument4
--                                                v_textmail,                           --argument5
--                                                chr(0),
--                                                '','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','','',
--                                                '','','','','','','','','',''
--                                                );

--          COMMIT;

--          IF nvl(v_req_id,0)=0 THEN
--            FND_FILE.put_line(FND_FILE.log,'Error al llamar al concurrente: XX AP Facturas No Validadas - Envio de mail ' || SQLERRM);
--          ELSE
--               FND_FILE.put_line(FND_FILE.log,'Llamada exitosa al concurrente: XX AP Facturas No Validadas - Envio de mail ');
--            FND_FILE.put_line(FND_FILE.log,'Destinatario: '||v_envios(i).destinatario||' - Adjunto: '||v_envios(i).archivo);
--          END IF;

--        END LOOP;

--      EXCEPTION
--        WHEN others THEN
--          FND_FILE.put_line(FND_FILE.log,'Error en concurrente: XX AP Facturas No Validadas - Envio de mail ' || SQLERRM);
--          RAISE e_Error;
--      END;

--    END IF;



--    errbuf  := 'XX_AP_FACT_NO_VALIDADAS_PK - Report Completed Successfully';
--    retcode := '0';


--  EXCEPTION
--    WHEN e_Error THEN
--      errbuf  := 'eError in XX_AP_FACT_NO_VALIDADAS_PK.MAIN_FNV Procedure - ' ||  SQLERRM;
--      retcode := '2';

--    WHEN others THEN
--      FND_FILE.put_line(FND_FILE.log, 'Others error in XX_AP_FACT_NO_VALIDADAS_PK.MAIN_FNV Procedure - '|| SQLERRM);
--      errbuf := 'Others error in XX_AP_FACT_NO_VALIDADAS_PK.MAIN_FNV Procedure - ' ||  SQLERRM;
--      retcode := '2';

--  END MAIN_FNV;


  PROCEDURE concat (x_value     IN OUT NOCOPY VARCHAR2,
                    p_new_value IN VARCHAR2,
                    p_separador IN VARCHAR2) IS

    v_new_value VARCHAR2(1000);
  BEGIN

    IF (p_new_value IS NULL) THEN
        v_new_value := ' ';
    ELSE
        v_new_value := p_new_value;
    END IF;

    IF (x_value IS NULL) THEN
        x_value := v_new_value;
    ELSE
        x_value := x_value ||p_separador||v_new_value;
    END IF;

  END concat;



  PROCEDURE MAIN_FNVR (errbuf           OUT VARCHAR2
                      ,retcode          OUT VARCHAR2
                      ,p_envia_mail     IN  VARCHAR2
                      ,p_ret_fin        IN  VARCHAR2
                      ,p_comprob        IN  VARCHAR2
                      ,p_retencion      IN  VARCHAR2
                      ,p_directorio     IN  VARCHAR2
                      ,p_chk_envia_mail IN  VARCHAR2
                      ,p_envia_user     IN  VARCHAR2
                      ,p_dest_copia     IN  VARCHAR2
                      ,p_id_proveedor   IN  VARCHAR2
                      ,p_fecha_desde    IN  VARCHAR2
                      ,p_fecha_hasta    IN  VARCHAR2
                      )
  IS

    v_ret_financieras       VARCHAR2(10) := 'FALSE';
    v_holds_activos         VARCHAR2(10) := 'FALSE';
    v_fact_no_validadas     VARCHAR2(10) := 'FALSE';
    v_caso_excep            VARCHAR2(10) := 'FALSE';
    v_line                  VARCHAR2(32000);
    v_separador             VARCHAR2(1)  := '|';
    v_cant_lineas           NUMBER       := 0;
    v_ctas_contables        VARCHAR2(1000);


    TYPE LINEA_ENVIOS IS RECORD
    (DESTINATARIO VARCHAR2(240),
     ARCHIVO      VARCHAR2(240),
     ASUNTO       VARCHAR2(240)
     );

    TYPE ENVIOS_MAIL IS TABLE OF
      linea_envios NOT NULL
    INDEX BY BINARY_INTEGER;

    v_envios      ENVIOS_MAIL;
    v_file_name   VARCHAR2(240);
    v_subject     VARCHAR2(240);
    v_dest_copia  VARCHAR2(240);
    v_textmail    VARCHAR2(240);
    v_mail        VARCHAR2(240);
    v_rep_file    UTL_FILE.file_type;
    v_separator   VARCHAR2(1):= '|';
    v_text        VARCHAR2(32760);
    v_inv_count   NUMBER:=0;
    e_Error       EXCEPTION;
    v_req_id      NUMBER;
    v_empresa     VARCHAR2(240);
    v_hold_code   VARCHAR2(30);

    -- Agregado CR2332 - asilva - febrero 2016
    v_cant        NUMBER;
    v_vdr_name    VARCHAR2(240);
    v_vdr_num     VARCHAR2(30);
    --
    -- CR2260 - Correccion Directorio XX AP Validación Facturas AP
    l_directorio    VARCHAR2(240);
    --
    CURSOR c_invoices IS
--      -- Retenciones financieras en pagos programados
--      SELECT /*+ INDEX_JOIN(AI) */  haou.name                            empresa,
--             pv.vendor_name,
--             pv.segment1                                              vendor_num,
--             it.displayed_field                                     tipo_factura,
--             ai.invoice_num,
--             ai.invoice_currency_code,
--             ai.invoice_amount,
--             ai.invoice_date                                       fecha_factura,
--             NULL                                                    fecha_plazo,
--             ai.creation_date                                        fecha_carga,
--             aps.due_date                                        fecha_retencion,
--             ai.pay_group_lookup_code                                 grupo_pago,
--             DECODE(AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                         ai.invoice_amount,
--                                                         ai.payment_status_flag,
--                                                         ai.invoice_type_lookup_code),
--                    'APPROVED',         'Validado',
--                    'FULL',             'Completamente Imputado',
--                    'NEEDS REAPPROVAL', 'Necesita Revalidaci¿n',
--                    'NEVER APPROVED',   'Nunca Validado')                 estado,
--             'Facturas c/Retenciones Pago Programadas'                 retencion,
--             fu.user_name                                                usuario,
--             NULL                                                 permite_contab,
--             fu.email_address
--             email,
--             NULL                                                      hold_code,
--             ai.invoice_id
--        FROM AP_INVOICES                ai,
--             AP_PAYMENT_SCHEDULES       aps,
--             PO_VENDORS                 pv,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             AP_LC_INVOICE_TYPES_V      it
--       WHERE ai.invoice_id                      = aps.invoice_id
--         AND ai.vendor_id                       = pv.vendor_id
--         AND ai.org_id                          = haou.organization_id
--         AND ai.created_by                      = fu.user_id
--         AND ai.invoice_type_lookup_code        = it.lookup_code
--         AND v_ret_financieras                  = 'TRUE'
--         AND aps.hold_flag                      = 'Y'
--         AND NVL(pv.hold_all_payments_flag,'N') = 'N'
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) <> 'CANCELLED'
--         AND pv.vendor_id                       = NVL(P_ID_PROVEEDOR,pv.vendor_id)
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--         -- CR1269 Revised - Enero 2015 - asilva
--         AND NVL(ai.payment_status_flag,'N') != 'Y'
--         --
--       UNION
--      -- Retenciones financieras en proveedor
--      SELECT haou.name,
--             pv.vendor_name,
--             pv.segment1,
--             it.displayed_field,
--             ai.invoice_num,
--             ai.invoice_currency_code,
--             ai.invoice_amount,
--             ai.invoice_date,
--             NULL,
--             ai.creation_date,
--             NULL,
--             ai.pay_group_lookup_code,
--             DECODE(AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                         ai.invoice_amount,
--                                                         ai.payment_status_flag,
--                                                         ai.invoice_type_lookup_code),
--                    'APPROVED',         'Validado',
--                    'FULL',             'Completamente Imputado',
--                    'NEEDS REAPPROVAL', 'Necesita Revalidaci¿n',
--                    'NEVER APPROVED',   'Nunca Validado')                 estado,
--             'Fact c/Suc Prvdor Definida p/Retener Todos Pagos',
--             fu.user_name,
--             NULL ,
--             fu.email_address,
--             NULL                                                      hold_code,
--             ai.invoice_id
--        FROM AP_INVOICES                ai,
--             PO_VENDORS                 pv,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             AP_LC_INVOICE_TYPES_V      it
--       WHERE ai.vendor_id                       = pv.vendor_id
--         AND ai.org_id                          = haou.organization_id
--         AND ai.created_by                      = fu.user_id
--         AND ai.invoice_type_lookup_code        = it.lookup_code
--         AND v_ret_financieras                  = 'TRUE'
--         AND NVL(pv.hold_all_payments_flag,'N') = 'Y'
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) <> 'CANCELLED'
--         AND pv.vendor_id                       = NVL(P_ID_PROVEEDOR, pv.vendor_id)
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--         -- CR1269 Revised - Enero 2015 - asilva
--         AND NVL(ai.payment_status_flag,'N') != 'Y'
--         --
--       UNION
--      -- Caso excepcion, retenciones liberadas pero con estado de factura Necesita Reval
--      SELECT haou.name,
--             pv.vendor_name,
--             pv.segment1,
--             it.displayed_field,
--             ai.invoice_num,
--             ai.invoice_currency_code,
--             ai.invoice_amount,
--             ai.invoice_date,
--             NULL,
--             ai.creation_date,
--             NULL,
--             ai.pay_group_lookup_code,
--             'Necesita Revalidaci¿n',
--             NULL,
--             fu.user_name,
--             DECODE(NVL(ahc.postable_flag,'N'),'Y','Si',
--                                               'N','No'),
--             fu.email_address,
--             NULL                                                      hold_code,
--             ai.invoice_id
--        FROM AP_INVOICES                ai,
--             AP_HOLDS_V                 ah,
--             PO_VENDORS                 pv,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             AP_LC_INVOICE_TYPES_V      it,
--             AP_HOLD_CODES_V            ahc
--       WHERE ai.invoice_id                = ah.invoice_id
--         AND ai.vendor_id                 = pv.vendor_id
--         AND ai.org_id                    = haou.organization_id
--         AND ai.created_by                = fu.user_id
--         AND ai.invoice_type_lookup_code  = it.lookup_code
--         AND ah.hold_lookup_code          = ahc.hold_lookup_code
--         AND v_caso_excep                 = 'TRUE'
--         AND ah.release_date              IS NOT NULL
--         AND 0 = (SELECT count(*)
--                    FROM AP_HOLDS_V       ah1
--                   WHERE ah1.invoice_id   = ai.invoice_id
--                     AND ah1.release_date IS NULL)
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) = 'NEEDS REAPPROVAL'
--         AND pv.vendor_id                       = NVL(P_ID_PROVEEDOR,pv.vendor_id)
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--       UNION
--      -- Holds activos en facturas que necesitan revalidaci¿n
--      SELECT haou.name,
--             pv.vendor_name,
--             pv.segment1,
--             it.displayed_field,
--             ai.invoice_num,
--             ai.invoice_currency_code,
--             ai.invoice_amount,
--             ai.invoice_date,
--             NULL,
--             ai.creation_date,
--             ah.hold_date, -- esto hace que se me multipliquen las lineas
--             ai.pay_group_lookup_code,
--             'Necesita Revalidaci¿n',
--             ah.hold_name,
--             fu.user_name,
--             DECODE(NVL(ahc.postable_flag,'N'),'Y','Si',
--                                               'N','No'),
--             fu.email_address,
--             ahc.hold_lookup_code                                      hold_code,
--             ai.invoice_id
--        FROM AP_INVOICES                ai,
--             AP_HOLDS_V                 ah,
--             PO_VENDORS                 pv,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             AP_LC_INVOICE_TYPES_V      it,
--             AP_HOLD_CODES_V            ahc
--       WHERE ai.vendor_id               = pv.vendor_id
--         AND ai.org_id                    = haou.organization_id
--         AND ai.invoice_id                = ah.invoice_id
--         AND ai.created_by                = fu.user_id
--         AND ai.invoice_type_lookup_code  = it.lookup_code
--         AND ah.hold_lookup_code          = ahc.hold_lookup_code
--         AND v_holds_activos              = 'TRUE'
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) = 'NEEDS REAPPROVAL'
--         AND ah.release_date              IS NULL
--         AND ah.hold_lookup_code          = NVL(P_RETENCION,ah.hold_lookup_code)
--         AND pv.vendor_id                 = NVL(P_ID_PROVEEDOR,pv.vendor_id)
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--      UNION
--      -- Facturas nunca validadas
--      SELECT haou.name,
--             pv.vendor_name,
--             pv.segment1,
--             it.displayed_field,
--             ai.invoice_num,
--             ai.invoice_currency_code,
--             ai.invoice_amount,
--             ai.invoice_date,
--             NULL,
--             ai.creation_date,
--             NULL,
--             ai.pay_group_lookup_code,
--             'Nunca Validado',
--             NULL,
--             fu.user_name,
--             NULL ,
--             fu.email_address,
--             NULL                                                      hold_code,
--             ai.invoice_id
--        FROM AP_INVOICES                ai,
--             PO_VENDORS                 pv,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             AP_LC_INVOICE_TYPES_V      it
--       WHERE ai.vendor_id                 = pv.vendor_id
--         AND ai.org_id                    = haou.organization_id
--         AND ai.created_by                = fu.user_id
--         AND ai.invoice_type_lookup_code  = it.lookup_code
--         AND v_fact_no_validadas          = 'TRUE'
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) = 'NEVER APPROVED'
--         AND pv.vendor_id                 = NVL(P_ID_PROVEEDOR,pv.vendor_id)
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--       ORDER BY 15,
--                8,
--                5;
      -- CR2332 - Query modificado para mejorar la performance - febrero 2016 - asilva
      -- Retenciones financieras en pagos programados
      SELECT 1                                                            bloque,
             haou.name                                                   empresa,
             flv.meaning                                            tipo_factura,
             ai.invoice_num,
             ai.invoice_currency_code,
             ai.invoice_amount,
             ai.invoice_date                                       fecha_factura,
             NULL                                                    fecha_plazo,
             ai.creation_date                                        fecha_carga,
             aps.due_date                                        fecha_retencion,
             ai.pay_group_lookup_code                                 grupo_pago,
             DECODE(AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
                                                         ai.invoice_amount,
                                                         ai.payment_status_flag,
                                                         ai.invoice_type_lookup_code),
                    'APPROVED',         'Validado',
                    'FULL',             'Completamente Imputado',
                    'NEEDS REAPPROVAL', 'Necesita Revalidaci¿n',
                    'NEVER APPROVED',   'Nunca Validado')                 estado,
             'Facturas c/Retenciones Pago Programadas'                 retencion,
             fu.user_name                                                usuario,
             fu.email_address                                              email,
             NULL                                                 permite_contab,
             NULL                                                      hold_code,
             ai.invoice_id  ,
             AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
                                                 ai.invoice_amount,
                                                 ai.payment_status_flag,
                                                 ai.invoice_type_lookup_code) approval_status -- CR2059 se incorpora columna para después filtrar -- Agregado ADM S14148
        FROM AP_INVOICES                ai,
             AP_PAYMENT_SCHEDULES       aps,
             HR_ALL_ORGANIZATION_UNITS  haou,
             FND_USER                   fu,
             FND_LOOKUP_VALUES          flv
       WHERE v_ret_financieras                  = 'TRUE'
         AND ai.cancelled_date                  IS NULL
         AND  (cancelled_date is  null or cancelled_by is  null or  cancelled_amount is  null or temp_cancelled_amount is  null)   -- CR2059 se toman las no canceladas
         -- CR1269 Revised - Enero 2015 - asilva
         AND NVL(ai.payment_status_flag,'N')   != 'Y'
         --
         AND ai.invoice_id                      = aps.invoice_id
         AND aps.hold_flag                      = 'Y'
         AND ai.created_by                      = fu.user_id
         AND ai.invoice_type_lookup_code        = flv.lookup_code
         AND flv.lookup_type                    = 'INVOICE TYPE'
         AND flv.view_application_id            = 200
         AND flv.lookup_code                   != 'INTEREST'
         AND flv.security_group_id              = 0
         AND flv.language                       = 'ESA'
         AND ai.org_id                          = haou.organization_id
         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
         AND EXISTS (SELECT 'Y'
                       FROM AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                           ,AP_SUPPLIER_SITES assi
                      WHERE pv.vendor_id = ai.vendor_id
                        AND 1=1 --NVL(pv.hold_all_payments_flag,'N') = 'Y'
                        AND assi.vendor_id = pv.vendor_id
                        AND assi.vendor_site_id = ai.vendor_site_id  -- ADM 29/04/2020 C1277: Comprobantes retenidos para esa sucursal
                        AND NVL(assi.hold_all_payments_flag,'N') = 'N' -- ADM 21/04/2020 C1277: tiene que tener los tildes de retener pago en la suc de la cía donde se está ejecutando el reporte, el solo tener los tildes en la cabecera no impide pagar los comprobantes.
                        AND pv.vendor_id = NVL(P_ID_PROVEEDOR,pv.vendor_id))
       UNION ALL
      -- Retenciones financieras en proveedor
      SELECT 2,
             haou.name,
             flv.meaning,
             ai.invoice_num,
             ai.invoice_currency_code,
             ai.invoice_amount,
             ai.invoice_date,
             NULL,
             ai.creation_date,
             NULL,
             ai.pay_group_lookup_code,
             DECODE(AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
                                                         ai.invoice_amount,
                                                         ai.payment_status_flag,
                                                         ai.invoice_type_lookup_code),
                    'APPROVED',         'Validado',
                    'FULL',             'Completamente Imputado',
                    'NEEDS REAPPROVAL', 'Necesita Revalidaci¿n',
                    'NEVER APPROVED',   'Nunca Validado')                 estado,
             'Fact c/Suc Prvdor Definida p/Retener Todos Pagos',
             fu.user_name,
             fu.email_address,
             NULL,
             NULL,
             ai.invoice_id,
             AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
                                                 ai.invoice_amount,
                                                 ai.payment_status_flag,
                                                 ai.invoice_type_lookup_code) approval_status -- CR2059 se incorpora columna para después filtrar -- Agregado ADM S14148
        FROM AP_INVOICES                ai,
             HR_ALL_ORGANIZATION_UNITS  haou,
             FND_USER                   fu,
             FND_LOOKUP_VALUES          flv
       WHERE v_ret_financieras                  = 'TRUE'
         -- CR1269 Revised - Enero 2015 - asilva
         AND NVL(ai.payment_status_flag,'N') != 'Y'
          AND  (cancelled_date is  null or cancelled_by is  null or  cancelled_amount is  null or temp_cancelled_amount is  null)   -- CR2059 se toman las no canceladas
           --
         AND ai.cancelled_date                  IS NULL
         AND ai.org_id                          = haou.organization_id
         AND ai.created_by                      = fu.user_id
         AND ai.invoice_type_lookup_code        = flv.lookup_code
         AND flv.lookup_type                    = 'INVOICE TYPE'
         AND flv.view_application_id            = 200
         AND flv.lookup_code                   != 'INTEREST'
         AND flv.security_group_id              = 0
         AND flv.language                       = 'ESA'
         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
         AND EXISTS (SELECT 'Y'
                       FROM AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                           ,AP_SUPPLIER_SITES assi
                      WHERE pv.vendor_id = ai.vendor_id
                        AND 1=1 --NVL(pv.hold_all_payments_flag,'N') = 'Y'
                        AND assi.vendor_id = pv.vendor_id
                        AND assi.vendor_site_id = ai.vendor_site_id  -- ADM 29/04/2020 C1277: Comprobantes retenidos para esa sucursal
                        AND NVL(assi.hold_all_payments_flag,'N') = 'Y' -- ADM 21/04/2020 C1277: tiene que tener los tildes de retener pago en la suc de la cía donde se está ejecutando el reporte, el solo tener los tildes en la cabecera no impide pagar los comprobantes.
                        AND pv.vendor_id = NVL(P_ID_PROVEEDOR,pv.vendor_id))
       UNION ALL
      -- Caso excepcion, retenciones liberadas pero con estado de factura Necesita Reval   CR2059 se toman las no canceladas SE COMENTA TODO POR PERFORMANCE
--      SELECT 3,
--             haou.name,
--             flv.meaning,
--             ai.invoice_num,
--             ai.invoice_currency_code,
--             ai.invoice_amount,
--             ai.invoice_date,
--             NULL,
--             ai.creation_date,
--             NULL,
--             ai.pay_group_lookup_code,
--             'Necesita Revalidaci¿n',
--             NULL,
--             fu.user_name,
--             fu.email_address,
--             DECODE(NVL(ah.postable_flag,'N'),'Y','Si',
--                                              'N','No'),
--             NULL,
--             ai.invoice_id
--        FROM AP_INVOICES                ai,
--             AP_HOLDS_V                 ah,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             FND_LOOKUP_VALUES          flv
--       WHERE v_caso_excep                  = 'TRUE'
--         AND ai.invoice_id                = ah.invoice_id
--         AND ai.org_id                    = haou.organization_id
--         AND ai.created_by                = fu.user_id
--         AND ai.invoice_type_lookup_code  = flv.lookup_code
--         AND flv.lookup_type              =  'INVOICE TYPE'
--         AND flv.view_application_id      = 200
--         AND flv.lookup_code             != 'INTEREST'
--         AND flv.security_group_id        = 0
--         AND flv.language                 = 'ESA'
--         AND ah.release_date              IS NOT NULL
--         AND 0 = (SELECT count(*)
--                    FROM AP_HOLDS_V       ah1
--                   WHERE ah1.invoice_id   = ai.invoice_id
--                     AND ah1.release_date IS NULL)
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) = 'NEEDS REAPPROVAL'
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--         AND EXISTS (SELECT 'Y'
--                       FROM AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
--                      WHERE pv.vendor_id = ai.vendor_id
--                        AND pv.vendor_id = NVL(P_ID_PROVEEDOR,pv.vendor_id))
--       UNION ALL
      -- Holds activos en facturas que necesitan revalidaci¿n
--      SELECT 4,
--             haou.name,
--             flv.meaning,
--             tai.invoice_num,
--             tai.invoice_currency_code,
--             tai.invoice_amount,
--             tai.invoice_date,
--             NULL,
--             tai.creation_date,
--             ah.hold_date, -- esto hace que se me multipliquen las lineas
--             tai.pay_group_lookup_code,
--             'Necesita Revalidaci¿n',
--             ah.hold_name,
--             fu.user_name,
--             fu.email_address,
--             DECODE(NVL(ah.postable_flag,'N'),'Y','Si',
--                                              'N','No'),
--             ah.hold_lookup_code,
--             tai.invoice_id
--        --   CR2059 cambia por performance
--        FROM AP_INVOICES                ai,
--             AP_HOLDS_V                 ah,
--             HR_ALL_ORGANIZATION_UNITS  haou,
--             FND_USER                   fu,
--             FND_LOOKUP_VALUES          flv
--       WHERE v_holds_activos              = 'TRUE'
--         AND ah.release_date              IS NULL
--         AND ah.hold_lookup_code          = NVL(P_RETENCION,ah.hold_lookup_code)
--         AND ai.org_id                    = haou.organization_id
--         AND ai.invoice_id                = ah.invoice_id
--         AND ai.created_by                = fu.user_id
--         AND ai.invoice_type_lookup_code  = flv.lookup_code
--         AND flv.lookup_type              = 'INVOICE TYPE'
--         AND flv.view_application_id      = 200
--         AND flv.lookup_code             != 'INTEREST'
--         AND flv.security_group_id        = 0
--         AND flv.language                 = 'ESA'
--         AND AP_INVOICES_PKG.get_approval_status (tai.invoice_id,
--                                                  tai.invoice_amount,
--                                                  tai.payment_status_flag,
--                                                  tai.invoice_type_lookup_code) = 'NEEDS REAPPROVAL'
--         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
--                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
--         AND EXISTS (SELECT 'Y'
--                       FROM AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
--                      WHERE pv.vendor_id = ai.vendor_id
--                        AND pv.vendor_id = NVL(P_ID_PROVEEDOR,pv.vendor_id))
--  -- CR2059 se toman las no canceladas reformulado por performance
    select  4,
                 name,
                 meaning,
                 invoice_num,
                 invoice_currency_code,
                 invoice_amount,
                 invoice_date,
                 NULL,
                 creation_date,
                 hold_date,
                 pay_group_lookup_code,
                 'Necesita Revalidación',
                 hold_name,
                 user_name,
                 email_address,
                 DECODE(NVL(postable_flag,'N'),'Y','Si',  'N','No'),
                 hold_lookup_code,
                 invoice_id,
                 AP_INVOICES_PKG.get_approval_status (tprev.invoice_id,
                                                      tprev.invoice_amount,
                                                      tprev.payment_status_flag,
                                                      tprev.invoice_type_lookup_code) approval_status -- se incorpora columna para después filtrar
              from (
            SELECT /*  Leading (tai)  use_nl( ah, haou, fu, flv) */  tai.*,
                                  haou.name,
                                 flv.meaning,
                                 ah.hold_date, -- esto hace que se me multipliquen las lineas
                             ALC1.DISPLAYED_FIELD hold_name, --ah.hold_name, -- adm 06/04/2020 1277 mejora de performance
                                 fu.user_name,
                                 fu.email_address,
                                 ahc.postable_flag, -- ah.postable_flag, -- adm 06/04/2020 1277 mejora de performance
                                 ah.hold_lookup_code
            FROM (select  ai.org_id,
                                 ai.invoice_id,
                                 ai.invoice_currency_code,
                                 ai.invoice_amount,
                                 ai.invoice_date,
                                 ai.creation_date,
                                 ai.pay_group_lookup_code,
                                 ai.created_by,
                                 ai.invoice_type_lookup_code,
                                 ai.payment_status_flag,
                                 ai.vendor_id ,
                                 ai.invoice_num
                            from  AP_INVOICES                ai
                            where     (cancelled_date is  null or cancelled_by is  null or  cancelled_amount is  null or temp_cancelled_amount is  null)
                                AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
                                AND TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
                                and exists (select 1 from AP_HOLDS ah where ah.invoice_id = ai.invoice_id and ah.release_lookup_code is null)
                                )                tai,
                 -- Inicio adm 06/04/2020 1277 mejora de performance
                 --AP_HOLDS_v                   ah, -- adm 06/04/2020 1277 mejora de performance
                 AP_HOLDS              AH,
                 AP_HOLD_CODES         AHC,
                 AP_LOOKUP_CODES       ALC1,
                 AP_LOOKUP_CODES       ALC2,
                 -- Fin adm 06/04/2020 1277 mejora de performance
                 HR_ALL_ORGANIZATION_UNITS  haou,
                 FND_USER                   fu,
                 FND_LOOKUP_VALUES          flv
           WHERE v_holds_activos              = 'TRUE'
             and ah.release_lookup_code is null --AND ah.release_date              IS NULL -- adm 06/04/2020 1277 mejora de performance
             AND ah.hold_lookup_code          = NVL(P_RETENCION,ah.hold_lookup_code)
             -- Inicio adm 06/04/2020 1277 mejora de performance
            AND ALC1.LOOKUP_TYPE (+)    = 'HOLD CODE'
            AND ALC1.LOOKUP_CODE (+)    = AH.HOLD_LOOKUP_CODE
            AND ALC2.LOOKUP_TYPE (+)    = 'HOLD TYPE'
            AND ALC2.LOOKUP_CODE (+)    = AHC.HOLD_TYPE
            AND AH.HOLD_LOOKUP_CODE     = AHC.HOLD_LOOKUP_CODE (+)
             -- Fin adm 06/04/2020 1277 mejora de performance
             AND tai.org_id                    = haou.organization_id
             AND tai.invoice_id                = ah.invoice_id
             AND tai.created_by                = fu.user_id
             AND tai.invoice_type_lookup_code  = flv.lookup_code
             AND flv.lookup_type              = 'INVOICE TYPE'
             AND flv.view_application_id      = 200
             AND flv.lookup_code             != 'INTEREST'
             AND flv.security_group_id        = 0
             AND flv.language                 = 'ESA'
             AND (P_ID_PROVEEDOR is null or EXISTS (SELECT 'Y'
                           FROM AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                          WHERE pv.vendor_id = tai.vendor_id
                            AND pv.vendor_id = P_ID_PROVEEDOR))
                                                                                                ) tprev
      UNION ALL
      -- Facturas nunca validadas
      SELECT 5,
             haou.name,
             flv.meaning,
             ai.invoice_num,
             ai.invoice_currency_code,
             ai.invoice_amount,
             ai.invoice_date,
             NULL,
             ai.creation_date,
             NULL,
             ai.pay_group_lookup_code,
             'Nunca Validado',
             NULL,
             fu.user_name,
             fu.email_address,
             NULL,
             NULL,
             ai.invoice_id,
             AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
                                                  ai.invoice_amount,
                                                  ai.payment_status_flag,
                                                  ai.invoice_type_lookup_code) approval_status -- CR2059 se incorpora columna para después filtrar
        FROM AP_INVOICES                ai,
             HR_ALL_ORGANIZATION_UNITS  haou,
             FND_USER                   fu,
             FND_LOOKUP_VALUES          flv
       WHERE v_fact_no_validadas          = 'TRUE'
            AND  (cancelled_date is  null or cancelled_by is  null or  cancelled_amount is  null or temp_cancelled_amount is  null)   -- CR2059 se toman las no canceladas
           AND nvl(payment_status_flag,'N') = 'N' -- CR2059 se toman las sin pagos
          AND earliest_settlement_date is null -- CR2059 se toman las sin fecha de prepago
          AND NOT EXISTS (SELECT 1 FROM AP_HOLDS  AH WHERE AH.INVOICE_ID = ai.invoice_id) -- CR2059 se excluyen todas las que tuvieron algun hold por performance
         AND ai.org_id                    = haou.organization_id
         AND ai.created_by                = fu.user_id
         AND ai.invoice_type_lookup_code  = flv.lookup_code
         AND flv.lookup_type              = 'INVOICE TYPE'
         AND flv.view_application_id      = 200
         AND flv.lookup_code             != 'INTEREST'
         AND flv.security_group_id        = 0
         AND flv.language                 = 'ESA'
         -- CR2059 se mueve al select por performance
--         AND AP_INVOICES_PKG.get_approval_status (ai.invoice_id,
--                                                  ai.invoice_amount,
--                                                  ai.payment_status_flag,
--                                                  ai.invoice_type_lookup_code) = 'NEVER APPROVED'
         AND (P_ID_PROVEEDOR is null or  EXISTS (SELECT 'Y'
                       FROM AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                      WHERE pv.vendor_id = ai.vendor_id
                        AND pv.vendor_id = P_ID_PROVEEDOR))
         AND ai.creation_date BETWEEN TRUNC(TO_DATE(NVL(p_fecha_desde,'1900/01/01 00:00:00'),'YYYY/MM/DD HH24:MI:SS'))
                              AND     TRUNC(TO_DATE(NVL(p_fecha_hasta,TO_CHAR(SYSDATE+1,'YYYY/MM/DD HH24:MI:SS')),'YYYY/MM/DD HH24:MI:SS'))
       ORDER BY 15,
                8,
                5;


     CURSOR c_gl_accounts(p_invoice_id IN NUMBER) IS
       SELECT DISTINCT gcck.concatenated_segments
         FROM AP_INVOICES                ai,
              AP_HOLDS_V                 ah,
              AP_INVOICE_DISTRIBUTIONS_V aid,
              GL_CODE_COMBINATIONS_V     gcc,
              GL_CODE_COMBINATIONS_KFV   gcck
        WHERE ai.invoice_id                = ah.invoice_id
          AND ai.invoice_id                = aid.invoice_id
          AND aid.dist_code_combination_id = gcc.code_combination_id
          AND gcc.code_combination_id      = gcck.code_combination_id
          AND NVL(gcc.enabled_flag,'N')    = 'N'
          AND ah.hold_lookup_code          IN ('DIST ACCT INVALID',
                                               'AWT ACCT INVALID',
                                               'ERV ACCT INVALID')
          AND release_date                 IS NULL
          AND ai.invoice_id                = p_invoice_id;

sigte_registro                   EXCEPTION;

  BEGIN

   dbms_output.put_line('=========================================');
      dbms_output.put_line('Par¿tros:');
     dbms_output.put_line('=========================================');
      dbms_output.put_line('Env¿mail:                      '||P_ENVIA_MAIL);
      dbms_output.put_line('Retenciones Financieras:         '||P_RET_FIN);
      dbms_output.put_line('Comprobantes:                    '||P_COMPROB);
      dbms_output.put_line('C¿digo de Retenci¿n:             '||P_RETENCION);
      dbms_output.put_line('Directorio:                      '||P_DIRECTORIO);
      dbms_output.put_line('Enviar Mail a Creador:           '||P_ENVIA_USER);
      dbms_output.put_line('Destinatario en Copia:           '||P_DEST_COPIA);
      dbms_output.put_line('Id del Proveedor:                '||P_ID_PROVEEDOR);
      dbms_output.put_line('Fecha Creaci¿n de Factura Desde: '||P_FECHA_DESDE);
      dbms_output.put_line('Fecha Creaci¿n de Factura Hasta: '||P_FECHA_HASTA);


--      FND_FILE.put_line(FND_FILE.log,'=========================================');
--      FND_FILE.put_line(FND_FILE.log,'Par¿tros:');
--      FND_FILE.put_line(FND_FILE.log,'=========================================');
--      FND_FILE.put_line(FND_FILE.log,'Env¿mail:                      '||P_ENVIA_MAIL);
--      FND_FILE.put_line(FND_FILE.log,'Retenciones Financieras:         '||P_RET_FIN);
--      FND_FILE.put_line(FND_FILE.log,'Comprobantes:                    '||P_COMPROB);
--      FND_FILE.put_line(FND_FILE.log,'C¿digo de Retenci¿n:             '||P_RETENCION);
--      FND_FILE.put_line(FND_FILE.log,'Directorio:                      '||P_DIRECTORIO);
--      FND_FILE.put_line(FND_FILE.log,'Enviar Mail a Creador:           '||P_ENVIA_USER);
--      FND_FILE.put_line(FND_FILE.log,'Destinatario en Copia:           '||P_DEST_COPIA);
--      FND_FILE.put_line(FND_FILE.log,'Id del Proveedor:                '||P_ID_PROVEEDOR);
--      FND_FILE.put_line(FND_FILE.log,'Fecha Creaci¿n de Factura Desde: '||P_FECHA_DESDE);
--      FND_FILE.put_line(FND_FILE.log,'Fecha Creaci¿n de Factura Hasta: '||P_FECHA_HASTA);


      IF (p_ret_fin='SI') THEN

        IF (p_comprob='CON_RETENCIONES') THEN

          -- Retenciones Financieras en comprobantes en cualquier estado +
          -- holds activos en facturas que necesitan revalidaci¿n
          v_ret_financieras := 'TRUE';
          v_holds_activos   := 'TRUE';

        ELSIF (p_comprob='NO_VALIDADOS') THEN

          --Retenciones Financieras en comprobantes en cualquier estado +
          -- comprobantes nunca validados + casos de excepci¿n
          v_ret_financieras   := 'TRUE';
          v_fact_no_validadas := 'TRUE';
          v_caso_excep        := 'TRUE';

        ELSIF (p_comprob='AMBOS') THEN

          --Retenciones Financieras en comprobantes en cualquier estado +
          -- holds activos en facturas que necesitan revalidaci¿n +
          -- comprobantes nunca validados + casos de excepcion
          v_ret_financieras   := 'TRUE';
          v_holds_activos     := 'TRUE';
          v_fact_no_validadas := 'TRUE';
          v_caso_excep        := 'TRUE';

        END IF;

      ELSIF (p_ret_fin='NO') THEN

        IF (p_comprob='CON_RETENCIONES') THEN

          -- Holds activos en facturas que necesitan revalidaci¿n
          v_holds_activos     := 'TRUE';

        ELSIF (p_comprob='NO_VALIDADOS') THEN

          --Comprobantes nunca validadas + casos de excepci¿n
          v_fact_no_validadas := 'TRUE';
          v_caso_excep        := 'TRUE';

        ELSIF (p_comprob='AMBOS') THEN

          --Comprobantes nunca validados + holds activos en facturas que
          --necesitan revalidaci¿n + casos de excepci¿n
          v_fact_no_validadas := 'TRUE';
          v_holds_activos     := 'TRUE';
          v_caso_excep        := 'TRUE';

        END IF;

      ELSIF (p_ret_fin='SOLO_FINANCIERAS') THEN

        IF (p_comprob='CON_RETENCIONES') THEN

          -- Retenciones financieras en comprobantes en cualquier estado
          v_ret_financieras   := 'TRUE';

        ELSIF (p_comprob IN ('NO_VALIDADOS','AMBOS')) THEN

          --Retenciones Financieras en comprobantes en cualquier estado +
          -- casos de excepci¿n
          v_ret_financieras   := 'TRUE';
          v_caso_excep        := 'TRUE';

        END IF;

      END IF;

      dbms_output.put_line('');
      dbms_output.put_line('=========================================');
      dbms_output.put_line('Variables:');
      dbms_output.put_line('=========================================');
      dbms_output.put_line('v_ret_financieras:   '||v_ret_financieras);
      dbms_output.put_line('v_holds_activos:     '||v_holds_activos);
      dbms_output.put_line('v_fact_no_validadas: '||v_fact_no_validadas);
      dbms_output.put_line('v_caso_excep:        '||v_caso_excep);
      dbms_output.put_line('');


--      FND_FILE.put_line(FND_FILE.log,'');
--      FND_FILE.put_line(FND_FILE.log,'=========================================');
--      FND_FILE.put_line(FND_FILE.log,'Variables:');
--      FND_FILE.put_line(FND_FILE.log,'=========================================');
--      FND_FILE.put_line(FND_FILE.log,'v_ret_financieras:   '||v_ret_financieras);
--      FND_FILE.put_line(FND_FILE.log,'v_holds_activos:     '||v_holds_activos);
--      FND_FILE.put_line(FND_FILE.log,'v_fact_no_validadas: '||v_fact_no_validadas);
--      FND_FILE.put_line(FND_FILE.log,'v_caso_excep:        '||v_caso_excep);
--      FND_FILE.put_line(FND_FILE.log,'');


      BEGIN
         dbms_output.put_line('antes del if  --->                ' ||p_envia_mail );
        IF (p_envia_mail='Y') THEN
         dbms_output.put_line('dentro del if  --->                ' ||p_envia_mail );
          --Texto del mail:
          v_textmail   := 'Listado de facturas no validadas y/o retenidas, ver adjunto';

                   dbms_output.put_line('antes del if  user --->                ' ||p_envia_user );
          IF (NVL(p_envia_user,'N')='Y')  or  (NVL(p_envia_user,'N')='N')  THEN
                   dbms_output.put_line('detnro del if  user --->                ' ||p_envia_user );

            --Destinatario
            v_mail       := 'sin_destinatario';
            v_dest_copia := p_dest_copia;


            v_cant := 0;
            -- Se recorre el cursor para crear los archivos con las lineas de facturas
             dbms_output.put_line('antes del cursor --->                ');
            FOR r_inv IN c_invoices LOOP
            begin

                        if (r_inv.bloque = 4 and r_inv.approval_status <> 'NEEDS REAPPROVAL') or
                           (r_inv.bloque = 5 and r_inv.approval_status <> 'NEVER APPROVED') Then
                           raise sigte_registro;
                        end if;

                        -- Inicio S14148 25/03/2020 ADM Filtro documentos Validados
                        if  r_inv.approval_status in ('APPROVED','FULL') Then
                           raise sigte_registro;
                        end if;
                        -- Fin S14148

                       dbms_output.put_line('dentro del cursor --->                ');
                          v_cant := v_cant + 1;
                          v_ctas_contables:= '';

                          -- Agregado CR2332 - asilva - febrero 2016
                          SELECT vendor_name
                               , segment1
                            INTO v_vdr_name
                               , v_vdr_num
                            FROM AP_INVOICES_ALL ai
                               , AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                           WHERE ai.invoice_id = r_inv.invoice_id
                             AND ai.vendor_id = pv.vendor_id;


                          IF v_mail = r_inv.email THEN
                            IF (v_holds_activos='TRUE') AND (r_inv.hold_code IN ('DIST ACCT INVALID',
                                                                                 'AWT ACCT INVALID',
                                                                                 'ERV ACCT INVALID')) THEN

                              FOR r_gl_acc IN c_gl_accounts(r_inv.invoice_id) LOOP
                                IF (v_ctas_contables IS NULL) THEN
                                  v_ctas_contables := r_gl_acc.concatenated_segments;
                                ELSE
                                  v_ctas_contables := v_ctas_contables ||' / '|| r_gl_acc.concatenated_segments;
                                END IF;
                              END LOOP;

                            END IF;

                            v_text := r_inv.empresa                 ||v_separador||
                                      -- Modificado CR2332
            --                          r_inv.vendor_name             ||v_separador||
            --                          r_inv.vendor_num              ||v_separador||
                                      v_vdr_name                    ||v_separador||
                                      v_vdr_num                     ||v_separador||
                                      --
                                      r_inv.tipo_factura            ||v_separador||
                                      r_inv.invoice_num             ||v_separador||
                                      r_inv.invoice_currency_code   ||v_separador||
                                      r_inv.invoice_amount          ||v_separador||
                                      r_inv.fecha_factura           ||v_separador||
                                      r_inv.fecha_plazo             ||v_separador||
                                      r_inv.fecha_carga             ||v_separador||
                                      r_inv.fecha_retencion         ||v_separador||
                                      r_inv.grupo_pago              ||v_separador||
                                      r_inv.estado                  ||v_separador||
                                      r_inv.retencion               ||v_separador||
                                      r_inv.usuario                 ||v_separador||
                                      r_inv.permite_contab          ||v_separador||
                                      v_ctas_contables;

                            UTL_FILE.put_line(v_rep_file,v_text);

                          ELSE

                            -- Antes de comenzar un nuevo destinatario, se cierra el archivo anterior
                            IF v_inv_count > 0 THEN
                              UTL_FILE.fclose(v_rep_file);
                            END IF;

                            --Asunto del mail:
                            v_subject:= 'Facturas No Validadas y/o retenidas - '
                                        ||SUBSTR(r_inv.empresa,+1,INSTR(r_inv.empresa,' UO',1)-1);

                            v_inv_count := v_inv_count + 1;
                            v_mail      := NVL(r_inv.email,p_dest_copia); -- Si el usuario no tiene mail, se envia la
                                                                          -- notificacion a quien deba estar en copia
                            v_file_name := 'XX_AP_Facturas_No_Valid_o_Ret_'||REPLACE(SUBSTR(r_inv.empresa,+1,INSTR(r_inv.empresa,' UO',1)-1),' ','_')
                                           ||'_'||TO_CHAR(SYSDATE,'DD_Mon_YYYY_HH24_MI_SS')||'_'||v_inv_count||'.csv';
                            
                            -- Se completa la tabla PL para despues hacer el envio de mail
                            v_envios(v_inv_count).destinatario:= v_mail;
                            v_envios(v_inv_count).archivo     := v_file_name;
                            v_envios(v_inv_count).asunto      := v_subject;
                            
                            v_rep_file  := UTL_FILE.fopen(p_directorio,v_file_name,'A',32760);
                                                        
                             -- Agregado CR2332 - asilva - febrero 2016
                              SELECT vendor_name
                                   , segment1
                                INTO v_vdr_name
                                   , v_vdr_num
                                FROM AP_INVOICES_ALL ai
                                   , AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                               WHERE ai.invoice_id = r_inv.invoice_id
                                 AND ai.vendor_id = pv.vendor_id;

                            v_text      :=  'EMPRESA'                       ||v_separador||
                                            'PROVEEDOR'                     ||v_separador||
                                            'NUMERO PROVEEDOR'              ||v_separador||
                                            'TIPO'                          ||v_separador||
                                            'NUMERO FACTURA'                ||v_separador||
                                            'MONEDA'                        ||v_separador||
                                            'MONTO'                         ||v_separador||
                                            'FECHA FACTURA'                 ||v_separador||
                                            'FECHA PLAZO'                   ||v_separador||
                                            'FECHA CARGA COMPROBANTE'       ||v_separador||
                                            'FECHA RETENCION'               ||v_separador||
                                            'GRUPO DE PAGO'                 ||v_separador||
                                            'ESTADO'                        ||v_separador||
                                            'RETENCION'                     ||v_separador||
                                            'USUARIO'                       ||v_separador||
                                            'PERMITE CONTABILIZAR'          ||v_separador||
                                            'COMBINACION CONTABLE INVALIDA' ||v_separador;

                            UTL_FILE.put_line(v_rep_file,v_text);
                            
                            IF (v_holds_activos='TRUE') AND (r_inv.hold_code IN ('DIST ACCT INVALID',
                                                                                 'AWT ACCT INVALID',
                                                                                 'ERV ACCT INVALID')) THEN

                              FOR r_gl_acc IN c_gl_accounts(r_inv.invoice_id) LOOP
                                IF (v_ctas_contables IS NULL) THEN
                                  v_ctas_contables := r_gl_acc.concatenated_segments;
                                ELSE
                                  v_ctas_contables := v_ctas_contables ||' / '|| r_gl_acc.concatenated_segments;
                                END IF;
                              END LOOP;

                            END IF;

                            v_text := r_inv.empresa                 ||v_separador||
                                      -- Modificado CR2332
          --                          r_inv.vendor_name             ||v_separador||
          --                          r_inv.vendor_num              ||v_separador||
                                      v_vdr_name                    ||v_separador||
                                      v_vdr_num                     ||v_separador||
                                      --
                                      r_inv.tipo_factura            ||v_separador||
                                      r_inv.invoice_num             ||v_separador||
                                      r_inv.invoice_currency_code   ||v_separador||
                                      r_inv.invoice_amount          ||v_separador||
                                      r_inv.fecha_factura           ||v_separador||
                                      r_inv.fecha_plazo             ||v_separador||
                                      r_inv.fecha_carga             ||v_separador||
                                      r_inv.fecha_retencion         ||v_separador||
                                      r_inv.grupo_pago              ||v_separador||
                                      r_inv.estado                  ||v_separador||
                                      r_inv.retencion               ||v_separador||
                                      r_inv.usuario                 ||v_separador||
                                      r_inv.permite_contab          ||v_separador||
                                      v_ctas_contables;
                            
                            UTL_FILE.put_line(v_rep_file,v_text);
                          END IF;

            EXCEPTION WHEN SIGTE_REGISTRO THEN 
                     null;
            END;
            END LOOP;
            -- CR2260 - Correccion Directorio XX AP Validación Facturas AP
            UTL_FILE.fflush(v_rep_file);
            --    
            UTL_FILE.fclose(v_rep_file);

          ELSE
                
            BEGIN

              SELECT name
              INTO v_empresa
              FROM HR_OPERATING_UNITS
              WHERE organization_id = FND_GLOBAL.ORG_ID;  -- Upgrate R12  FND_PROFILE.value('ORG_ID');

            EXCEPTION
              WHEN others THEN
                v_empresa:= '';
            END;

            --Solo se envia listado completo a los destinatarios asignados
            v_mail       := p_dest_copia;
            v_dest_copia := '';
            v_file_name  := 'XX_AP_Facturas_No_Valid_o_Ret_'||REPLACE(SUBSTR(v_empresa,+1,INSTR(v_empresa,' UO',1)-1),' ','_')
                            ||'_'||TO_CHAR(SYSDATE,'DD_Mon_YYYY_HH24_MI_SS')||'.csv';

            -- Se completa la tabla PL para despues hacer el envio de mail
            v_envios(1).destinatario:= v_mail;
            v_envios(1).archivo     := v_file_name;
            v_envios(1).asunto      := 'Facturas No Validadas y/o Retenidas '||v_empresa;
            v_rep_file  := UTL_FILE.fopen(p_directorio,v_file_name,'W',32767);

            v_text      := 'EMPRESA'                       ||v_separador||
                           'PROVEEDOR'                     ||v_separador||
                           'NUMERO PROVEEDOR'              ||v_separador||
                           'TIPO'                          ||v_separador||
                           'NUMERO FACTURA'                ||v_separador||
                           'MONEDA'                        ||v_separador||
                           'MONTO'                         ||v_separador||
                           'FECHA FACTURA'                 ||v_separador||
                           'FECHA PLAZO'                   ||v_separador||
                           'FECHA CARGA COMPROBANTE'       ||v_separador||
                           'FECHA RETENCION'               ||v_separador||
                           'GRUPO DE PAGO'                 ||v_separador||
                           'ESTADO'                        ||v_separador||
                           'RETENCION'                     ||v_separador||
                           'USUARIO'                       ||v_separador||
                           'PERMITE CONTABILIZAR'          ||v_separador||
                           'COMBINACION CONTABLE INVALIDA' ||v_separador;

            UTL_FILE.put_line(v_rep_file,v_text);


            FOR r_inv IN c_invoices LOOP
                begin
                    --Agregado C1879 14/04/2020- ADM - faltaba filtra comprobantes validados
                    if (r_inv.bloque = 4 and r_inv.approval_status <> 'NEEDS REAPPROVAL') or
                       (r_inv.bloque = 5 and r_inv.approval_status <> 'NEVER APPROVED')  Then
                       raise sigte_registro;
                    end if;

                    v_ctas_contables := '';

                -- Agregado CR2332 - asilva - febrero 2016
                  SELECT vendor_name
                       , segment1
                    INTO v_vdr_name
                       , v_vdr_num
                    FROM AP_INVOICES_ALL ai
                       , AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                   WHERE ai.invoice_id = r_inv.invoice_id
                     AND ai.vendor_id = pv.vendor_id;

                  IF (v_holds_activos='TRUE') AND (r_inv.hold_code IN ('DIST ACCT INVALID',
                                                                       'AWT ACCT INVALID',
                                                                       'ERV ACCT INVALID')) THEN

                    FOR r_gl_acc IN c_gl_accounts(r_inv.invoice_id) LOOP
                      IF (v_ctas_contables IS NULL) THEN
                        v_ctas_contables := r_gl_acc.concatenated_segments;
                      ELSE
                        v_ctas_contables := v_ctas_contables ||' / '|| r_gl_acc.concatenated_segments;
                      END IF;
                    END LOOP;

                  END IF;

                  v_text := r_inv.empresa                 ||v_separador||
                        -- Modificado CR2332
--                        r_inv.vendor_name             ||v_separador||
--                        r_inv.vendor_num              ||v_separador||
                        v_vdr_name                    ||v_separador||
                        v_vdr_num                     ||v_separador||
                        --
                        r_inv.tipo_factura            ||v_separador||
                        r_inv.invoice_num             ||v_separador||
                        r_inv.invoice_currency_code   ||v_separador||
                        r_inv.invoice_amount          ||v_separador||
                        r_inv.fecha_factura           ||v_separador||
                        r_inv.fecha_plazo             ||v_separador||
                        r_inv.fecha_carga             ||v_separador||
                        r_inv.fecha_retencion         ||v_separador||
                        r_inv.grupo_pago              ||v_separador||
                        r_inv.estado                  ||v_separador||
                        r_inv.retencion               ||v_separador||
                        r_inv.usuario                 ||v_separador||
                        r_inv.permite_contab          ||v_separador||
                        v_ctas_contables;

                    UTL_FILE.put_line(v_rep_file,v_text);

                    v_inv_count:= v_inv_count+1;

                exception when sigte_registro then null;
                end;

            END LOOP;
            -- CR2260 - Correccion Directorio XX AP Validación Facturas AP
            UTL_FILE.fflush(v_rep_file);
            --
            UTL_FILE.fclose(v_rep_file);


            IF v_inv_count>0 THEN
              v_inv_count:= 1; --Solo se necesita enviar un solo archivo en este caso
            END IF;


          END IF;
          
          -- CR2260 - Correccion Directorio XX AP Validación Facturas AP
          BEGIN
          select directory_path
            into l_directorio
            from all_directories
           where directory_name = p_directorio;
          EXCEPTION 
           WHEN OTHERS THEN
                l_directorio:= null;
          END;

          -- Envios de mail
          IF NVL(v_inv_count,0)>0 THEN

            BEGIN

              FOR i IN v_envios.FIRST..v_envios.LAST
              LOOP


                v_req_id:= FND_REQUEST.submit_request('XBIL',                               --application
                                                      'XXAPFNVEM',                          --program
                                                      NULL,                                 --description
                                                      NULL,                                 --start_time
                                                      FALSE,                                --sub_request
                                                      l_directorio||'/'||
                                                      v_envios(i).archivo,                  --argument1
                                                      v_envios(i).asunto,                   --argument2
                                                      v_envios(i).destinatario,             --argument3
                                                      v_dest_copia,                         --argument4
                                                      v_textmail,                           --argument5
                                                      chr(0),
                                                      '','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','','',
                                                      '','','','','','','','','',''
                                                       );

                COMMIT;

                IF nvl(v_req_id,0)=0 THEN
                  FND_FILE.put_line(FND_FILE.log,'Error al llamar al concurrente: XX AP Facturas No Validadas - Envio de mail ' || SQLERRM);
                ELSE
                  FND_FILE.put_line(FND_FILE.log,'Llamada exitosa al concurrente: XX AP Facturas No Validadas - Envio de mail ');
                  FND_FILE.put_line(FND_FILE.log,'Destinatario: '||v_envios(i).destinatario||' - Adjunto: '||v_envios(i).archivo);
                END IF;


              END LOOP;

            EXCEPTION
              WHEN others THEN
                FND_FILE.put_line(FND_FILE.log,'Error en concurrente: XX AP Facturas No Validadas - Envio de mail ' || SQLERRM);
                RAISE e_Error;
            END;

          END IF;



        ELSE

          -- No se env¿mail, el listado sale por output en la aplicaci¿n
          concat(v_line,'Empresa',v_separador);
          concat(v_line,'Proveedor',v_separador);
          concat(v_line,'Numero Proveedor',v_separador);
          concat(v_line,'Tipo',v_separador);
          concat(v_line,'Numero Factura',v_separador);
          concat(v_line,'Moneda',v_separador);
          concat(v_line,'Monto',v_separador);
          concat(v_line,'Fecha Factura',v_separador);
          concat(v_line,'Fecha Plazo',v_separador);
          concat(v_line,'Fecha Carga Comprobante',v_separador);
          concat(v_line,'Fecha Retencion',v_separador);
          concat(v_line,'Grupo de Pago',v_separador);
          concat(v_line,'Estado',v_separador);
          concat(v_line,'Retencion',v_separador);
          concat(v_line,'Usuario',v_separador);
          concat(v_line,'Permite Contabilizar',v_separador);
          concat(v_line,'Combinacion Contable Invalida',v_separador);

          FND_FILE.put_line(FND_FILE.output,v_line);

          FOR r_inv IN c_invoices LOOP
            begin
                --Agregado C1879 14/04/2020- ADM - faltaba filtra comprobantes validados
                if (r_inv.bloque = 4 and r_inv.approval_status <> 'NEEDS REAPPROVAL') or
                   (r_inv.bloque = 5 and r_inv.approval_status <> 'NEVER APPROVED') Then
                   raise sigte_registro;
                end if;

                v_ctas_contables := '';

                    -- Agregado CR2332 - asilva - febrero 2016
                      SELECT vendor_name
                           , segment1
                        INTO v_vdr_name
                           , v_vdr_num
                        FROM AP_INVOICES_ALL ai
                           , AP_SUPPLIERS pv -- Upgrate R12  PO_VENDORS pv
                       WHERE ai.invoice_id = r_inv.invoice_id
                         AND ai.vendor_id = pv.vendor_id;

                IF (v_holds_activos='TRUE') AND (r_inv.hold_code IN ('DIST ACCT INVALID',
                                                                     'AWT ACCT INVALID',
                                                                     'ERV ACCT INVALID')) THEN

                  FOR r_gl_acc IN c_gl_accounts(r_inv.invoice_id) LOOP
                    IF (v_ctas_contables IS NULL) THEN
                      v_ctas_contables := r_gl_acc.concatenated_segments;
                    ELSE
                      v_ctas_contables := v_ctas_contables ||' / '|| r_gl_acc.concatenated_segments;
                    END IF;
                  END LOOP;

                END IF;

                v_line := NULL;

                concat(v_line,r_inv.empresa,v_separador);
                -- Modificado CR2332 - asilva - febrero 2016
    --            concat(v_line,r_inv.vendor_name,v_separador);
    --            concat(v_line,r_inv.vendor_num,v_separador);
                concat(v_line,v_vdr_name,v_separador);
                concat(v_line,v_vdr_num,v_separador);
                --
                concat(v_line,r_inv.tipo_factura,v_separador);
                concat(v_line,r_inv.invoice_num,v_separador);
                concat(v_line,r_inv.invoice_currency_code,v_separador);
                concat(v_line,r_inv.invoice_amount,v_separador);
                concat(v_line,r_inv.fecha_factura,v_separador);
                concat(v_line,r_inv.fecha_plazo,v_separador);
                concat(v_line,r_inv.fecha_carga,v_separador);
                concat(v_line,r_inv.fecha_retencion,v_separador);
                concat(v_line,r_inv.grupo_pago,v_separador);
                concat(v_line,r_inv.estado,v_separador);
                concat(v_line,r_inv.retencion,v_separador);
                concat(v_line,r_inv.usuario,v_separador);
                concat(v_line,r_inv.permite_contab,v_separador);
                concat(v_line,v_ctas_contables,v_separador);

                FND_FILE.put_line(FND_FILE.output,v_line);

                v_cant_lineas := v_cant_lineas + 1;
            exception when sigte_registro then null;
            end;

          END LOOP;


--          FND_FILE.put_line(FND_FILE.log,'');
--          FND_FILE.put_line(FND_FILE.log,'Cantidad de lineas: '||v_cant_lineas);

          dbms_output.put_line('');
          dbms_output.put_line('Cantidad de lineas: '||v_cant_lineas);


        END IF;


      EXCEPTION

        WHEN UTL_FILE.write_error THEN
          IF UTL_FILE.is_open(v_rep_file ) THEN
            UTL_FILE.fclose(v_rep_file);
          END IF;
          FND_FILE.put_line(FND_FILE.log,'UTL FILE ERROR An error occured writing data into output file. ');
          RAISE e_Error;

        WHEN UTL_FILE.invalid_path THEN
          IF UTL_FILE.is_open(v_rep_file) THEN
            UTL_FILE.fclose(v_rep_file);
          END IF;
          FND_FILE.put_line(FND_FILE.log,'UTL FILE ERROR Invalid output Path');
          FND_FILE.put_line(FND_FILE.log,v_file_name);
          FND_FILE.put_line(FND_FILE.log,p_directorio);
          RAISE e_Error;

        WHEN UTL_FILE.invalid_operation THEN
          IF UTL_FILE.is_open(v_rep_file ) THEN
            UTL_FILE.fclose(v_rep_file);
          END IF;
          FND_FILE.put_line(FND_FILE.log,'INVALID_OPERATION error occured writing data into output file.');
          RAISE e_Error;

        WHEN others THEN
          FND_FILE.put_line(FND_FILE.log,'Oracle Err: ' || SQLERRM);
          RAISE e_Error;
      END;



      errbuf  := 'XX_AP_FACT_NO_VALIDADAS_PK - Reporte Completado Satisfactoriamente';
      retcode := '0';


  EXCEPTION
    WHEN e_Error THEN
      errbuf  := 'e_Error in XX_AP_FACT_NO_VALIDADAS_PK.MAIN_FNVR Procedure - ' ||  SQLERRM;
      retcode := '2';


    WHEN others THEN
      FND_FILE.put_line(FND_FILE.log, 'Others error in XX_AP_FACT_NO_VALIDADAS_PK.MAIN_FNVR Procedure - '|| SQLERRM);
      errbuf := 'Others error in XX_AP_FACT_NO_VALIDADAS_PK.MAIN_FNVR Procedure - ' ||  SQLERRM;
      retcode := '2';

  END MAIN_FNVR;

END XX_AP_FACT_NO_VALIDADAS_PK;
/
exit
