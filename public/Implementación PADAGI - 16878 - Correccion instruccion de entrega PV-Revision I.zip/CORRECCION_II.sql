UPDATE apps.xx_inv_remitos_impresos
SET    copies = 1, last_update_date = sysdate, last_updated_by = 2070
WHERE  waybill_airbill = '0141-00000828';
--1 Registro
