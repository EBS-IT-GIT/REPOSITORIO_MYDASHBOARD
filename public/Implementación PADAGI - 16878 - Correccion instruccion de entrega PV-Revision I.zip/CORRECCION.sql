UPDATE apps.oe_order_headers_all
SET    shipping_instructions = null, packing_instructions = null, last_update_date = sysdate, last_updated_by = 2070
WHERE  header_id = 9691732;
--1 Registro