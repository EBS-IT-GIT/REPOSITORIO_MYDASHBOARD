  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "BOLINF"."XX_RI_CHAVE_NFE_V" ("ORG_ID"
                                                                         , "ORGANIZATION_ID"
                                                                         , "KEY") AS 
  SELECT a1.org_id
      ,a1.interface_header_attribute10 AS organization_id
      ,a1.electronic_inv_access_key    AS KEY
  FROM apps.cll_f255_ar_invoices_v a1
 WHERE a1.trx_date >= ADD_MONTHS(SYSDATE,-4)
;


exit
