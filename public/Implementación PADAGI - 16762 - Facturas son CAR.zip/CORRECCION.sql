DELETE apps.xxw_fac_tmp
WHERE  creation_date > '01-01-2020'
AND    resultado = 'E'
AND    fecha_env_comprobante = '19-03-2020'
AND    comprobante like 'B%';
--6 Registros