UPDATE apps.ra_customer_trx_lines_all rct
SET    interface_line_attribute4 = '0005-00003701', last_update_date = sysdate, last_updated_by = 2070
WHERE  customer_trx_id = (SELECT customer_trx_id
                          FROM   apps.ra_customer_trx_all
                          WHERE  trx_number = 'A-0038-00002405')
AND    interface_line_attribute4 = '0005-00003702';
--2 Registros