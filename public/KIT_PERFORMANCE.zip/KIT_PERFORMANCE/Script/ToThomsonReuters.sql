set pagesize 40
accept __owner prompt "Nome do usuario dono do ESQUEMA......: "
SET MARKUP HTML ON SPOOL ON
SET ECHO OFF feed off SET VERIFY OFF term off
spool ToThonsomReutersBD.html
--
--
TTITLE COL 1  'Versao e status do Banco de Dados'
select * from v$version
/
--
TTITLE COL 1  'Situacao da Instancia'
SELECT
    instance_number instance_number
  , instance_name   instance_name
  , host_name       host_name
  , version         version
  , parallel        parallel
  , status          status
  , TO_CHAR(startup_time,'DD/MM/YYYY HH24:MI:SS') start_time
  , TO_CHAR(sysdate,'DD/MM/YYYY HH24:MI:SS')      current_time
  , ROUND(TO_CHAR(SYSDATE-startup_time), 2)       uptime
  , logins
  , archiver
FROM gv$instance
/
TTITLE COL 1  'NLS PARAMETERS'
select * from nls_database_parameters
/
--
TTITLE COL 1  'Usuarios do Banco de dados'
select username, INITIAL_RSRC_CONSUMER_GROUP from dba_users order by username
/
--
TTITLE COL 1  'Monitoramento da Mem�ria - ADVIDOR - MEMORY_TARGET'
select * from v$memory_target_advice
/
TTITLE COL 1  'Monitoramento da Mem�ria - ADVISOR - SGA'
select * from v$sga_target_advice
/
--
TTITLE COL 1  'Monitoramento da Mem�ria - ADVISOR - PGA'
select * from v$pga_target_advice
/
--
TTITLE COL 1  'Estat�sticas do Sistema'
select * from sys.aux_stats$
/
--
TTITLE COL 1  'Tamanho das tablespaces - (M)'

SELECT
    DECODE( d.status, 'OFFLINE', d.status, d.status )  status
  , d.tablespace_name                 name
  , d.contents                        type
  , d.extent_management               extent_mgt
  , d.segment_space_management        segment_mgt
  , NVL(a.bytes/1024/1024, 0)                   ts_size
  , NVL(f.bytes/1024/1024, 0)                   free
  , NVL((a.bytes/1024/1024) - NVL(f.bytes/1024/1024, 0), 0) used
  , DECODE ( (1-SIGN(1-SIGN(TRUNC(NVL((a.bytes - NVL(f.bytes, 0)) / (a.bytes) * 100, 0)) - 90)))
            , 1
            , TO_CHAR(TRUNC(NVL(( (a.bytes) - NVL(f.bytes, 0)) / (a.bytes) * 100, 0))) 
            , TO_CHAR(TRUNC(NVL(( (a.bytes) - NVL(f.bytes, 0)) / (a.bytes) * 100, 0)))
          ) pct_used
FROM 
    dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_data_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes) bytes
      from dba_free_space
      group by tablespace_name
    ) f
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = f.tablespace_name(+)
  AND NOT (
    d.extent_management like 'LOCAL'
    AND
    d.contents like 'TEMPORARY'
  )
UNION ALL 
SELECT
    DECODE(   d.status, 'OFFLINE', d.status, d.status) status
  , d.tablespace_name                            name
  , d.contents                                   type
  , d.extent_management                          extent_mgt
  , d.segment_space_management                   segment_mgt
  , NVL(a.bytes/1024/1024, 0)                    ts_size
  , NVL((a.bytes/1024/1024) - NVL(t.bytes/1024/1024,0), 0) free
  , NVL(t.bytes/1024/1024, 0)                    used
  , DECODE ( (1-SIGN(1-SIGN(TRUNC(NVL((t.bytes / a.bytes) * 100, 0)) - 90)))
            , 1
            , TO_CHAR(TRUNC(      NVL((t.bytes / a.bytes) * 100, 0)))
            , TO_CHAR(TRUNC(      NVL((t.bytes / a.bytes) * 100, 0)))
          )   pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_cached) bytes
      from v$temp_extent_pool
      group by tablespace_name
    ) t
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
ORDER BY 2
/

TTITLE COL 1  'Arquivos do Banco de dados'

SELECT /*+ ordered */
    d.tablespace_name             tablespace
  , d.file_name                   filename
  , d.bytes/1024/1024             Mbytes
  ,  NVL(d.autoextensible, '')    autoextensible
  , (d.increment_by * e.value)/1024/1024      increment_by
  , d.maxbytes/1024/1024          maxbytes
FROM
    sys.dba_data_files d
  , v$datafile v
  , (SELECT value
     FROM v$parameter 
     WHERE name = 'db_block_size') e
WHERE
  (d.file_name = v.name)
UNION
SELECT
     d.tablespace_name           tablespace 
  ,  d.file_name                 filename
  , d.bytes/1024/1024            filesize
  , NVL(d.autoextensible, '')    autoextensible
  , (d.increment_by * e.value)/1024/1024     increment_by
  , d.maxbytes/1024/1024         maxbytes
FROM
    sys.dba_temp_files d
  , (SELECT value
     FROM v$parameter 
     WHERE name = 'db_block_size') e
UNION
SELECT
    '[ ONLINE REDO LOG ]'
  ,  a.member 
  ,  (b.bytes/1024/1024)
  ,  null
  ,  null
  ,  null
FROM
    v$logfile a
  , v$log b
WHERE
    a.group# = b.group#
UNION
SELECT
    '[ CONTROL FILE    ]'
  , a.name
  , null
  , null
  , null
  , null
FROM
    v$controlfile a
ORDER BY
    1
  , 2
/
--
TTITLE COL 1  'Directories'
SELECT OWNER, DIRECTORY_NAME, DIRECTORY_PATH
FROM   dba_directories
/
--TTITLE COL 1  'Privilegio dos Directories'
-- select * from dba_tab_privs where table_name in (select DIRECTORY_NAME  from dba_directories) order by table_name,PRIVILEGE
--/
--
TTITLE COL 1  'Maiores Segmentos'
SELECT * FROM (
SELECT
	  segment_name NOME
	, segment_type TIPO
	, bytes/1024/1024 MB
	, tablespace_name,
          OWNER
  FROM DBA_SEGMENTS where owner NOT IN ('SYS','SYSTEM','APEX_040200','AUDSYS') and segment_type not like 'LOB%'
	 order by 3 DESC, 1, 2)
	WHERE ROWNUM <=50 ORDER BY MB DESC
/
--
TTITLE COL 1  'Objetos Inv�lidos no Banco de dados'
SELECT
    owner
  , COunt(1) "Total de Objetos Invalidos"
FROM all_objects
WHERE status <> 'VALID' and object_type <> 'SYNONYM'
group  by owner
/
--
TTITLE COL 1  'Par�metros de Banco de dados'
SELECT
    DECODE(   p.isdefault
            , 'FALSE'
            , SUBSTR(p.name,0,512)
            , SUBSTR(p.name,0,512) )    pname
  , DECODE(   p.isdefault
            , 'FALSE'            , i.instance_name
            , i.instance_name )         instance_name_print
  , DECODE(   p.isdefault
            , 'FALSE'
            , SUBSTR(p.value,0,512) 
            , SUBSTR(p.value,0,512) )   value
  , DECODE(   p.isdefault
            , 'FALSE'
            , p.isdefault 
            , p.isdefault )             isdefault
  , DECODE(   p.isdefault
            , 'FALSE'
            , p.issys_modifiable
            , p.issys_modifiable )      issys_modifiable
FROM
    gv$parameter p
  , gv$instance  i
WHERE
    p.inst_id = i.inst_id
ORDER BY
    p.name
  , i.instance_name
/
--
TTITLE COL 1  'Log Switch'
SELECT
    TO_CHAR(first_time, 'YYYYMMDD')  DAY
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'00',1,0)) H00
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'01',1,0)) H01
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'02',1,0)) H02
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'03',1,0)) H03
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'04',1,0)) H04
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'05',1,0)) H05
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'06',1,0)) H06
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'07',1,0)) H07
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'08',1,0)) H08
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'09',1,0)) H09
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'10',1,0)) H10
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'11',1,0)) H11
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'12',1,0)) H12
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'13',1,0)) H13
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'14',1,0)) H14
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'15',1,0)) H15
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'16',1,0)) H16
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'17',1,0)) H17
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'18',1,0)) H18
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'19',1,0)) H19
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'20',1,0)) H20
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'21',1,0)) H21
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'22',1,0)) H22
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'23',1,0)) H23
  , COUNT(*)                                                                      TOTAL
FROM
  v$log_history  a
GROUP BY TO_CHAR(first_time, 'YYYYMMDD')
ORDER BY 1 
/

spool ToThonsomReutersSegs.html

TTITLE COL 1  'Tabelas e �ndices Particionados'

SELECT OWNER,
       NVL (INDEX_NAME, TABLE_NAME) NAME,
       (SELECT COLUMN_NAME
          FROM ALL_PART_KEY_COLUMNS B
         WHERE     B.OWNER = A.OWNER
               AND B.NAME = NVL (A.INDEX_NAME, A.TABLE_NAME))
           Coluna,
       interval
  FROM (SELECT TABLE_NAME,
               NULL INDEX_NAME,
               OWNER,
               INTERVAL
          FROM ALL_PART_TABLES
         WHERE OWNER = upper('&&__OWNER')
        UNION ALL
        SELECT TABLE_NAME,
               INDEX_NAME,
               OWNER,
               NULL
          FROM ALL_PART_INDEXES
         WHERE OWNER = upper('&&__OWNER')) A
/
TTITLE COL 1  'Estat�sticas das tabelas'
select table_name, num_rows, sample_size, last_analyzed, partitioned, degree, COMPRESSION, COMPRESS_FOR, TEMPORARY, avg_row_len, next_extent
    from DBA_tables where owner=upper('&&__OWNER') ORDER BY TABLE_NAME
/   
break ON table_name on index_name on UNIQUENESS on INI_TRANS on MAX_TRANS on NEXT on distinct_keys on NUM_ROWS on last_analyzed on VISIBILITY on BLEVEL on degree on INDEX_TYPE on partitioned;
TTITLE COL 1  'Indices '
select  I.TABLE_NAME,
        i.INDEX_NAME,
        C.COLUMN_NAME,
        i.UNIQUENESS,
        i.INI_TRANS,
        i.MAX_TRANS,
        TRUNC(I.NEXT_EXTENT/1024/1024) NEXT,
        i.distinct_keys,
        i.NUM_ROWS,
        i.last_analyzed,
        i.VISIBILITY,
        i.BLEVEL,
        i.degree,
        i.INDEX_TYPE,
        i.partitioned
  from dba_INDEXES I, 
       dba_ind_columns c
  where    i.TABLE_OWNER=upper('&&__OWNER')
      and  i.table_owner= c.table_owner and
           i.table_name = c.table_name  and
           i.index_name = c.index_name  
  order by i.table_name,i.index_name,c.column_position
/ 
clear break

TTITLE COL 1  'Sqls em ordem de tempo de execu��o '

with W_Sql as (
  SELECT st.sql_id,
         st.PLAN_HASH_VALUE,
         ST.CPU_TIME_DELTA,
         st.optimizer_cost,
         st.DISK_READS_DELTA,
         st.BUFFER_GETS_DELTA,
         st.ROWS_PROCESSED_DELTA,
         st.ELAPSED_TIME_DELTA,
         st.EXECUTIONS_DELTA
    FROM sys.WRH$_SQLSTAT st
   WHERE st.snap_id in (select snap_id from dba_hist_snapshot where BEGIN_INTERVAL_TIME > sysdate-2) 
   ORDER BY EXECUTIONS_DELTA DESC)
select * from W_SQL where rownum < 20 

/

spool ToTHomsonReutersSql.html

TTITLE COL 1  'SqlProfiles'
select * from dba_sql_profiles
/

spool off


whenever sqlError Exit 1
declare
    vl_Return number(10);
begin
    select 1 into vl_return from dba_tables where table_name = 'PRT_PAR_MSAF' and owner=upper('&&__OWNER');
End;
/

spool ToThonsomReutersMsaf.html

TTITLE COL 1  'Par�metros da Aplica��o'
select * from &&__owner..PRT_PAR_MSAF
/

TTITLE COL 1  'Hist�rico de processos '
SELECT a.proc_id, 
       a.sp_nome, 
       to_char(l.data_inicio,'dd/mm/rrrr hh24:mi:ss') data_inicio, 
       to_char(l.data_fim,'dd/mm/rrrr hh24:mi:ss') data_fim, 
 decode(l.aplicacao,'','PROGRAMADO', l.aplicacao) IND_PROG,
  to_char(count(s.proc_id)) as num_linhas
FROM &&__owner..lib_processo l, 
     &&__owner..LIB_PROC_SAIDA s,
     (SELECT max(p.proc_id) proc_id, p.sp_nome 
        FROM &&__owner..lib_processo p                
                       group by p.sp_nome) a
WHERE a.proc_id = l.proc_id
  and l.proc_id = s.PROC_ID
  and l.proc_id = (SELECT max(proc_id) 
                     FROM &&__owner..lib_processo p                
                    where p.proc_id = s.proc_id 
                     group by sp_nome)
 group by a.proc_id, 
          a.sp_nome, 
          l.data_inicio, 
          l.data_fim, 
          l.aplicacao
 Order by 1 desc  
/
TTITLE COL 1  'Hist�rico de Atualiza��o de Patch '
select * from &&__owner..saf_controle_patch where dsc_patch like 'V2%' order by dsc_patch
/

spool off


exit
