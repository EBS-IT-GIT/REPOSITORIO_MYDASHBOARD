#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2531_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2531
# |
# | HISTORY
# |   19-JUN-20  SOUZA, ARNALDO JULIO DE MELO - Bra
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2531_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2531_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2531
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/FNDLOAD/PROF
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2531" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2531_9549.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2531"
AddAllLogs $CROUT "FND" "CR2531_9549.ldt"
mv CR2531_9549.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XXCLK_INV_INTERFACE_PKG " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'

export NLS_LANG='American_America.UTF8'
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XXCLK_INV_INTERFACE_PKG','APPS','$PATCHDIR','CR2531');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XXCLK_INV_INTERFACE_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_CATSETNCM " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_CATSETNCM.ldt PROFILE PROFILE_NAME="XXCLK_CATSETNCM" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_CATSETNCM.ldt"
mv XXCLK_CATSETNCM.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_CATSETINV " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_CATSETINV.ldt PROFILE PROFILE_NAME="XXCLK_CATSETINV" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_CATSETINV.ldt"
mv XXCLK_CATSETINV.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_MASTERORG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_MASTERORG.ldt PROFILE PROFILE_NAME="XXCLK_MASTERORG" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_MASTERORG.ldt"
mv XXCLK_MASTERORG.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_IDCLIENTE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_IDCLIENTE.ldt PROFILE PROFILE_NAME="XXCLK_IDCLIENTE" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_IDCLIENTE.ldt"
mv XXCLK_IDCLIENTE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XX_INV_INTEGRACAO_ITEM_CLK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XX_INV_INTEGRACAO_ITEM_CLK.ldt PROGRAM APPLICATION_SHORT_NAME="XXCLK" CONCURRENT_PROGRAM_NAME="XX_INV_INTEGRACAO_ITEM_CLK"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XX_INV_INTEGRACAO_ITEM_CLK.ldt"
mv XX_INV_INTEGRACAO_ITEM_CLK.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-LOOKUP XXINV_CATEGORIA_COMLINK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/aflvmlu.lct XXINV_CATEGORIA_COMLINK.ldt FND_LOOKUP_TYPE APPLICATION_SHORT_NAME="INV" LOOKUP_TYPE="XXINV_CATEGORIA_COMLINK"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XXINV_CATEGORIA_COMLINK.ldt"
mv XXINV_CATEGORIA_COMLINK.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/LOOKUP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-LOOKUP XXINV_TEMPLATE_COMLINK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/aflvmlu.lct XXINV_TEMPLATE_COMLINK.ldt FND_LOOKUP_TYPE APPLICATION_SHORT_NAME="INV" LOOKUP_TYPE="XXINV_TEMPLATE_COMLINK"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XXINV_TEMPLATE_COMLINK.ldt"
mv XXINV_TEMPLATE_COMLINK.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/LOOKUP


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XXCLK_INV_INTERFACE_PKG " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XXCLK_INV_INTERFACE_PKG >> $CROUT

export NLS_LANG='American_America.UTF8'
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XXCLK_INV_INTERFACE_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XXCLK_INV_INTERFACE_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XXCLK_INV_INTERFACE_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XXCLK_INV_INTERFACE_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XXCLK_INV_INTERFACE_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF XXCLK_CATSETNCM " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETNCM.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF XXCLK_CATSETINV " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_CATSETINV.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF XXCLK_MASTERORG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_MASTERORG.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF XXCLK_IDCLIENTE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/XXCLK_IDCLIENTE.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XX_INV_INTEGRACAO_ITEM_CLK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt CUSTOM_MODE=FORCE

export NLS_LANG='American_America.UTF8'

echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XX_INV_INTEGRACAO_ITEM_CLK' 
              ,program_application => 'XXCLK' 
              ,request_group       => 'All Inclusive GUI' 
              ,group_application   => 'INV') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XX_INV_INTEGRACAO_ITEM_CLK' 
              ,program_application => 'XXCLK' 
              ,request_group       => 'All Inclusive GUI' 
              ,group_application   => 'INV'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XX_INV_INTEGRACAO_ITEM_CLK' 
              ,program_application => 'XXCLK' 
              ,request_group       => 'System Administrator Reports' 
              ,group_application   => 'FND') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XX_INV_INTEGRACAO_ITEM_CLK' 
              ,program_application => 'XXCLK' 
              ,request_group       => 'System Administrator Reports' 
              ,group_application   => 'FND'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XX_INV_INTEGRACAO_ITEM_CLK.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-LOOKUP XXINV_CATEGORIA_COMLINK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/aflvmlu.lct $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt CUSTOM_MODE=FORCE
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_CATEGORIA_COMLINK.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-LOOKUP XXINV_TEMPLATE_COMLINK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/aflvmlu.lct $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt CUSTOM_MODE=FORCE
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/LOOKUP/XXINV_TEMPLATE_COMLINK.ldt -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2531" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2531_9549.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2531_9549.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
