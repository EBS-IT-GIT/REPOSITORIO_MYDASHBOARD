#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2531_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2531
# |
# | HISTORY
# |   19-JUN-20  SOUZA, ARNALDO JULIO DE MELO - Bra
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2531_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2531_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2531
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2531/CR2531_20200619"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=CRP3

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/FNDLOAD/PROF
mkdir -p xbol/12.0.0/sql/PKG
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/LOOKUP
mkdir -p xbol/12.0.0/FNDLOAD/PROF
mkdir -p xbol/12.0.0/sql/PKG
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT
svn up /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2531" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2531_9549.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2531"
AddAllLogs $CROUT "FND" "CR2531_9549.ldt"
mv CR2531_9549.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XXCLK_INV_INTERFACE_PKG " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'

export NLS_LANG='American_America.UTF8'
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XXCLK_INV_INTERFACE_PKG','APPS','$PATCHDIR','CR2531');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XXCLK_INV_INTERFACE_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_CATSETNCM " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_CATSETNCM.ldt PROFILE PROFILE_NAME="XXCLK_CATSETNCM" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_CATSETNCM.ldt"
mv XXCLK_CATSETNCM.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_CATSETINV " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_CATSETINV.ldt PROFILE PROFILE_NAME="XXCLK_CATSETINV" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_CATSETINV.ldt"
mv XXCLK_CATSETINV.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_MASTERORG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_MASTERORG.ldt PROFILE PROFILE_NAME="XXCLK_MASTERORG" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_MASTERORG.ldt"
mv XXCLK_MASTERORG.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PROF XXCLK_IDCLIENTE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscprof.lct XXCLK_IDCLIENTE.ldt PROFILE PROFILE_NAME="XXCLK_IDCLIENTE" APPLICATION_SHORT_NAME="XXCLK" LEV="APPLICATION" LEV_NAME=""
AddAllLogs $CROUT "FND" "XXCLK_IDCLIENTE.ldt"
mv XXCLK_IDCLIENTE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PROF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XX_INV_INTEGRACAO_ITEM_CLK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XX_INV_INTEGRACAO_ITEM_CLK.ldt PROGRAM APPLICATION_SHORT_NAME="XXCLK" CONCURRENT_PROGRAM_NAME="XX_INV_INTEGRACAO_ITEM_CLK"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XX_INV_INTEGRACAO_ITEM_CLK.ldt"
mv XX_INV_INTEGRACAO_ITEM_CLK.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-LOOKUP XXINV_CATEGORIA_COMLINK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/aflvmlu.lct XXINV_CATEGORIA_COMLINK.ldt FND_LOOKUP_TYPE APPLICATION_SHORT_NAME="INV" LOOKUP_TYPE="XXINV_CATEGORIA_COMLINK"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XXINV_CATEGORIA_COMLINK.ldt"
mv XXINV_CATEGORIA_COMLINK.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/LOOKUP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-LOOKUP XXINV_TEMPLATE_COMLINK " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/aflvmlu.lct XXINV_TEMPLATE_COMLINK.ldt FND_LOOKUP_TYPE APPLICATION_SHORT_NAME="INV" LOOKUP_TYPE="XXINV_TEMPLATE_COMLINK"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XXINV_TEMPLATE_COMLINK.ldt"
mv XXINV_TEMPLATE_COMLINK.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/LOOKUP


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
