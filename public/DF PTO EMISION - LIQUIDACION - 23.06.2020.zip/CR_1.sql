UPDATE apps.XX_TCG_LIQUIDACIONES
SET  organization_id = 1942,
          pto_emision_liq_aju = 13,
          last_update_date = sysdate,
          last_updated_by = 2070
WHERE liquidacion_id > 32844 
AND estado_coe = 'SOLICITAR'
AND pto_emision_liq_aju = '14' 
--70