UPDATE apps.ra_batch_sources_all rbs
SET    global_attribute3 = 'E'
WHERE  rbs.org_id = 194
AND    rbs.name like 'e-Tkt%'
AND    global_attribute3 is not null;
--7 Registros