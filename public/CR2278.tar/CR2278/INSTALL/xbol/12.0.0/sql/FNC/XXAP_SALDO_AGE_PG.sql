  set define off;

  CREATE OR REPLACE FUNCTION "APPS"."XXAP_SALDO_AGE_PG" (P_INVOICE_ID  IN NUMBER
                                          ,P_DATA_REF    IN DATE
                                          ,P_PAYMENT_NUM IN NUMBER
 ) RETURN NUMBER AS
  --
  l_dData_ref      DATE;
  l_nGross_amount  NUMBER;
  l_nInvoice_id    NUMBER;-- := 8399764;-- 1812618;-- 8399764;
  l_nSaldo         NUMBER :=0;
  l_nTotalAdiantamento NUMBER := 0;
  l_nSaldoAdiantamento NUMBER := 0;
  l_nAdiantamento  NUMBER :=0;
  l_nExisteParc    NUMBER :=0;
  l_n_payment_num NUMBER;
  l_vZerouAdto     VARCHAR2(1) := 'N';
  --
BEGIN
  --
  l_n_payment_num := P_PAYMENT_NUM;
  l_nInvoice_id   := P_INVOICE_ID;
  l_dData_ref     := P_DATA_REF;
  --
SELECT
 (SELECT nvl(sum(aipa.amount), 0) + nvl(sum(aipa.discount_taken), 0) --
    FROM apps.ap_invoice_payments_all aipa
   WHERE 1 = 1
     AND AIPA.PAYMENT_NUM = l_n_payment_num
     AND aipa.invoice_id = aia.invoice_id
     AND AIPA.ACCOUNTING_DATE <= l_dData_ref -- trunc(:DATA_REFERENCIA)
     AND NVL(AIPA.REVERSAL_FLAG, 'N') <> 'Y') +
 -- mais imposto
 NVL((SELECT ABS(SUM(AIDA.AMOUNT))
       FROM APPS.AP_INVOICE_PAYMENTS_ALL      AIPA,
            apps.ap_invoice_distributions_all AIDA
      WHERE 1 = 1
        AND AIPA.INVOICE_ID = aia.invoice_id
        AND AIPA.PAYMENT_NUM = l_n_payment_num
        AND AIPA.ACCOUNTING_DATE <= l_dData_ref -- (:DATA_REFERENCIA)
        AND NVL(AIPA.REVERSAL_FLAG, 'N') <> 'Y'
        AND AIDA.line_type_lookup_code = 'AWT'
        AND AIDA.ACCOUNTING_DATE <= l_dData_ref -- (:DATA_REFERENCIA)
        AND AIDA.INVOICE_ID = AIPA.INVOICE_ID
        AND AIPA.INVOICE_PAYMENT_ID = AIDA.AWT_INVOICE_PAYMENT_ID),
     0)
      ,apsa.gross_amount
  INTO l_nSaldo
      ,l_nGross_amount
  FROM apps.ap_invoices_all aia
      ,apps.ap_payment_schedules_all apsa
 WHERE 1 = 1
   AND aia.invoice_id = l_nInvoice_id
   AND aia.invoice_id = apsa.invoice_Id
   AND apsa.payment_num = l_n_payment_num;

-- calculo Adiantamento
begin
 SELECT nvl(ABS(SUM(amount)), 0)
    INTO l_nTotalAdiantamento
    FROM apps.ap_invoice_lines_all ail
   WHERE ail.invoice_id = l_nInvoice_id
     AND accounting_date < = l_dData_ref --trunc(:DATA_REFERENCIA)
     AND ail.line_type_lookup_code = 'PREPAY';
 exception when others then
   l_nTotalAdiantamento := 0;
 end;



  if l_nTotalAdiantamento <> 0 then
  -- verificar se existe parcela com gross amount igual ao valor adiantamento
  BEGIN
    SELECT payment_num
      INTO l_nExisteParc
      FROM apps.ap_payment_schedules_all
     WHERE invoice_Id = l_nInvoice_id
     --  and payment_num =
       AND gross_Amount = l_nTotalAdiantamento;
  --
  EXCEPTION
     when too_many_rows then
        --
        begin
        SELECT payment_num
          INTO l_nExisteParc
          FROM apps.ap_payment_schedules_all
         WHERE invoice_Id = l_nInvoice_id
           AND gross_Amount = l_nTotalAdiantamento
           and payment_num = l_n_payment_num;
      exception
        WHEN OTHERS THEN
         l_nExisteParc := 0;
      end;
    WHEN OTHERS THEN
      l_nExisteParc := 0;
  END;
  --
  IF l_nExisteParc = l_n_payment_num THEN
    -- se existir parcela com valor igual ao adiantamento
    -- entao vou solocar o saldo = total do adiantamento
    l_nSaldo := l_nSaldo - l_nTotalAdiantamento;
  ELSE
    -- calculo de adiantamento
    FOR i IN (SELECT payment_num,gross_amount
                FROM apps.ap_payment_schedules_all
               WHERE invoice_id = l_nInvoice_id
               ORDER BY 1) LOOP
      --
      l_nSaldoAdiantamento := l_nTotalAdiantamento;

      IF l_nTotalAdiantamento < i.gross_amount THEN
        --
         dbms_output.put_line('11  i.gross_amount '||  i.gross_amount);
          --
        IF i.payment_num = l_n_payment_num THEN
          l_nSaldo := l_nSaldo - l_nTotalAdiantamento;
        ELSE
          l_nSaldoAdiantamento := l_nTotalAdiantamento - i.gross_amount;
          IF l_nSaldoAdiantamento < 0 THEN
            l_vZerouAdto := 'Y';
          END IF;
                   dbms_output.put_line('12  l_nSaldoAdiantamento '||  l_nSaldoAdiantamento);
        END IF;
        --
      ELSIF (l_nTotalAdiantamento > i.gross_amount
              AND  l_vZerouAdto = 'N' ) THEN
        --
        IF i.payment_num <> l_n_payment_num THEN

         dbms_output.put_line('22 i.payment_num <> l_n_payment_num: '|| l_nTotalAdiantamento);
          --
          l_nSaldoAdiantamento := l_nTotalAdiantamento - i.gross_amount;
          --
        ELSE

         dbms_output.put_line('33 ELSE i.payment_num = l_n_payment_num: '|| l_nSaldoAdiantamento);

          l_nSaldo := l_nSaldo - l_nSaldoAdiantamento;--l_nSaldoAdiantamento;
          l_nSaldoAdiantamento := l_nSaldoAdiantamento + abs(l_nSaldo);

        END IF;
        --
      END IF;
    END LOOP;
    END IF;
  END IF;
  --
  if (l_nGross_amount > 0
       AND l_nSaldo < 0) then
    l_nSaldo := 0;
  ELSIF (l_nGross_amount < 0
       AND l_nSaldo > 0) then
    l_nSaldo := 0;
  end IF;
  l_nSaldo := abs(l_nSaldo);
  RETURN(l_nSaldo);
  --
EXCEPTION
  WHEN OTHERS THEN
    RETURN(0);
END;

grant all on APPS.XXAP_SALDO_AGE_PG to BOLLINK;
grant all on APPS.XXAP_SALDO_AGE_PG to BOLINF;
/

exit
