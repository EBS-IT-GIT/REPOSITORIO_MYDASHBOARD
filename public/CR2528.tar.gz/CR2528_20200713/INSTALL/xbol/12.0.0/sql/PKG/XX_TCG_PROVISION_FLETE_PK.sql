  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_TCG_PROVISION_FLETE_PK" AUTHID CURRENT_USER AS

  /*------------------------------------------------------------------------
  |  Function:   Principal                                                 |
  |  Purpose:    Procedimiento principal del paquete                       |
  |  Parameters: errbuf                         OUT VARCHAR2               |
  |              retcode                        OUT VARCHAR2
  |              p_draft_mode                    IN VARCHAR2               |
  |              p_debug_flag                    IN VARCHAR2               |
  |              p_submit_flag                   IN VARCHAR2               |
  ------------------------------------------------------------------------*/
  g_provision_account_id       NUMBER;
  g_flete_por_vta_account_id   NUMBER;
  g_flete_por_cpra_account_id  NUMBER;
  g_structure_number           NUMBER;
  g_set_of_books_id            NUMBER;
  g_sob_name                   GL_LEDGERS.name%type;
  g_nseg_unidad_negocio        NUMBER;
  g_nseg_producto              NUMBER;
  g_nseg_uni_productiva        NUMBER;
  g_nseg_ctro_costo            NUMBER;
  g_nseg_proyecto              NUMBER;
  g_nseg_interco               NUMBER;
  g_unidad_negocio             VARCHAR2(10);                                    --CR2528



  PROCEDURE principal (errbuf         OUT VARCHAR2
                      ,retcode        OUT VARCHAR2
                      ,p_uni_oper      IN VARCHAR2 -- Upgrade R12
                      ,p_draft_mode    IN VARCHAR2
                      ,p_debug_flag    IN VARCHAR2
                      ,p_submit_flag   IN VARCHAR2);


  FUNCTION ORG_DESTINO ( p_cuit_destino          IN NUMBER
                       , p_cuit_provisionado_por IN NUMBER
                       , p_cuit_titular          IN NUMBER
                       , p_es_retiro             IN VARCHAR2
                       , p_item_id               IN NUMBER
                       , p_estab_id              IN NUMBER
                       , p_estab_id_tit          IN NUMBER
                       , x_org_id               OUT NUMBER
                       , x_errmsg               OUT VARCHAR2
                       ) RETURN BOOLEAN;

END XX_TCG_PROVISION_FLETE_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_TCG_PROVISION_FLETE_PK" AS

/*
 +=================================================================================+
 | Copyright 2012 Adeco Agropecuaria, Buenos Aires, Argentina |
 | All rights reserved. |
 +=================================================================================+
 |
 | FILENAME: XX_TCG_PROVISION_FLETEB_PK.sql
 |
 | DESCRIPTION:
---- | Cuerpo de paquete para manejo de provisiones de acopio.
 |
 | HISTORY
 | 12-07-12 abaracca CR384: En procedimiento INSERTAR_REGISTRO, se modifica
 | la Referencia que se graba en el campo Reference4 debido
 | a que la interface de GL: Importaci¿n de Asientos(GLLEZL)
 | solo toma los primeros 25 caracteres y con id de CP mayor
 | a 5 digitos se pasa esa longitud y la provisi¿n es agrupada
 | en lotes.
 | 16-08-13 asilva CR823: se modifica el procedimiento Principal para evitar
 | asientos dobles en GL debido a concurrentes cancelados
 |
 *=================================================================================*/

 /*-----------------------------------------------------------------------
 | P U B L I C V A R I A B L E S |
 -----------------------------------------------------------------------*/
 g_debug_flag VARCHAR2(2);

 /*-----------------------------------------------------------------------
 | E N D P U B L I C V A R I A B L E S |
 -----------------------------------------------------------------------*/

 -------------------------------------------------------------------------
 /*-----------------------------------------------------------------------
 | P R I V A T E P R O C E D U R E S |
 -----------------------------------------------------------------------*/

 /*------------------------------------------------------------------------
 | Procedure: debug_line |
 | Purpose: MANDa mensajes de debug en caso de que p_debug_flag='Y' |
 | Parameters: p_errmsg IN VARCHAR2 |
 ------------------------------------------------------------------------*/

 PROCEDURE debug_line (p_errmsg IN VARCHAR2)
 IS
 BEGIN
 IF g_debug_flag = 'Y' THEN
 xx_debug_pk.debug(p_errmsg, 1);
 END IF;
 END;



FUNCTION Convertir_Monto(p_monto              IN NUMBER,
                         p_currency_code_from IN VARCHAR2,
                         p_currency_code_to   IN VARCHAR2,
                         p_conversion_type    IN VARCHAR2 DEFAULT NULL,
                         p_conversion_date    IN DATE  DEFAULT NULL,
                         p_conversion_rate    IN NUMBER DEFAULT NULL) RETURN NUMBER IS

    v_rate             NUMBER;
BEGIN

    IF p_conversion_type = 'User' THEN
        v_rate := p_conversion_rate;
    ELSE
        BEGIN
            v_rate := gl_currency_api.get_rate (
                x_from_currency   => p_currency_code_from,
                x_to_currency     => p_currency_code_to,
                x_conversion_date => p_conversion_date,
                x_conversion_type => p_conversion_type);

        EXCEPTION
            WHEN others THEN
                Raise_Application_Error(-20001,'No fue posible realizar la converion '||
                               'de monedas. Error obteniENDo tasa de conversion.');
        END;
    END IF;

    RETURN p_monto * v_rate;
END Convertir_Monto;
 /*------------------------------------------------------------------------
 | Function: insertar_registro |
 | Purpose: Registra en la interfaz los nuevos asientos contables |
 | Note: p_asiento_tipo = 'D' => Cuentas de Debito  p_asiento_tipo = 'C' => Cuentas de Credito |
 ------------------------------------------------------------------------*/

  FUNCTION insertar_registro (p_set_of_books_id     IN NUMBER
                             ,p_registro            IN XX_TCG_CARTAS_PORTE_ALL%rowtype
                             ,p_code_combination_id IN NUMBER
                             ,p_asiento_tipo        IN VARCHAR2
                             ,p_group_id            IN NUMBER
                             ,p_cp_descripcion      IN VARCHAR2
                             ,x_errmsg             OUT VARCHAR2
                             ) RETURN BOOLEAN IS
    v_costo_flete_converted_value NUMBER;
    v_converted_currency_code VARCHAR2(25);
    v_vENDor_number po_vENDors.segment1%TYPE;
    v_vENDor_name po_vENDors.vENDor_name%TYPE;
  BEGIN
    -- Obtengo la moneda para el juego de libros
    BEGIN
      SELECT currency_code
      INTO v_converted_currency_code
      FROM gl_ledgers
      WHERE ledger_id = p_set_of_books_id;
    EXCEPTION
      WHEN OTHERS THEN
        x_errmsg := 'No fue posible encontrar la moneda para el juego de libros: '|| p_set_of_books_id
                 || '. Verifique la configuracion de los juegos de libros';
        RETURN(false);
    END;

    IF p_registro.costo_flete_currency_code IS NOT NULL THEN
      -- COnvierto a la moneda del juego de libros ## rEVISAR EL TIPO DE CAMBIO
          v_costo_flete_converted_value := Convertir_Monto(p_monto =>p_registro.costo_flete,
                                                                                    p_currency_code_from =>p_registro.costo_flete_currency_code,
                                                                                    p_currency_code_to =>v_converted_currency_code);
    ELSE
          x_errmsg := 'No se pudo insertar el registro ya que la moneda del costo de flete no fue especificada.'
                   || 'Verifique los datos de la carta de porte';
          RETURN(false);
    END IF;
    -- nombre

    BEGIN
        IF p_registro.intermediario_flete_id IS NOT NULL THEN
            SELECT party_number, party_name
              INTO v_vENDor_number,
                   v_vENDor_name
              FROM hz_parties
             WHERE party_id = p_registro.intermediario_flete_id;
        ELSIF p_registro.carrier_service_id is NULL THEN
              SELECT party_number, party_name
                INTO v_vENDor_number,  v_vENDor_name
                FROM hz_parties   hp
                        , hz_party_usg_assignments hpa
                        , ap_suppliers s
                 WHERE  hpa.party_id = hp.party_id
                      AND s.party_id   = hp.party_id
                      AND hpa.party_usage_code = 'SUPPLIER'
                      AND hp.status    = 'A'
                      AND DECODE( hp.attribute_category   , 'AR', hp.jgzz_fiscal_code||s.global_attribute12
                                   , 'UY', s.vat_registration_num
                                   ) = p_registro.transportista_cuit;
        ELSE
              SELECT pov.segment1,
                     pov.vENDor_name
              INTO v_vENDor_number,
                   v_vENDor_name
              FROM wsh_carrier_services wcs
                      , wsh_carrier_services_dfv wcs_dfv
                     , ap_suppliers pov
              WHERE wcs.rowid = wcs_dfv.row_id
              AND wcs_dfv.xx_aco_proveedor = pov.vENDor_id
              AND p_registro.carrier_service_id = wcs.carrier_service_id;
        END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        x_errmsg := 'No fue posible encontrar el numero de transportista para la carta de porte numero: '|| p_registro.numero_carta_porte
                 || '. Por favor, verifique los datos ingresados en la carta de porte.' ;
        RETURN(false);
      WHEN OTHERS THEN
        x_errmsg := 'Se produjo un error inesperado al buscar el numero de transportista para la carta de porte numero: '
                  || p_registro.numero_carta_porte||'. Detalle:' || SQLERRM ;
        RETURN(false);
    END;

    INSERT INTO gl_interface
    (status
    ,ledger_id
    ,set_of_books_id
    ,accounting_date
    ,currency_code
    ,date_created
    ,created_by
    ,actual_flag
    ,user_je_source_name
    ,user_je_category_name
    ,code_combination_id
    ,entered_dr
    ,entered_cr
    ,accounted_dr
    ,accounted_cr
    ,reference1
    ,reference4
    ,reference5
    ,reference10
    ,reference21
    ,reference22
    ,reference23
    ,reference24
    ,group_id
    )
    VALUES
    (
    'NEW'
    ,p_set_of_books_id
    ,p_set_of_books_id
    ,SYSDATE
    ,p_registro.costo_flete_currency_code
    ,SYSDATE
    ,FND_GLOBAL.user_id
    ,'A'
    ,'Acopio Fletes' -- se debe definir en la pantalla de GL de sources
    ,'Provision Acopio' -- se debe definir en la pantalla de GL de categories
    ,p_code_combination_id
    ,DECODE(p_asiento_tipo, 'D', round(p_registro.costo_flete,2), NULL)
    ,DECODE(p_asiento_tipo, 'C', round(p_registro.costo_flete,2), NULL)
    ,DECODE(p_asiento_tipo, 'D', round(v_costo_flete_converted_value,2), NULL)
    ,DECODE(p_asiento_tipo, 'C', round(v_costo_flete_converted_value,2), NULL)
    ,v_vendor_number
    -- CR 384 - AB - 12/07/2012
    -- ,'Carta de Porte Ref: '||p_registro.carta_porte_id
    ,'Carta Porte: '||p_registro.carta_porte_id
    ,'Provision de Flete Acopio'
    ,'Provision de Flete Acopio'
    ,p_registro.carta_porte_id
    ,NULL
    ,v_vendor_name
    ,p_cp_descripcion --CR2301
    ,p_group_id
    );

    RETURN(TRUE);
  EXCEPTION
    WHEN OTHERS THEN
      x_errmsg := 'No fue posible insertar el registro para la carta de porte numero '|| p_registro.numero_carta_porte||'. Detalle: ' ||SQLERRM;
      RETURN(FALSE);
  END;

 /*------------------------------------------------------------------------
 | Function: Ejecutar_Concurrente |
 | Purpose: Ejecuta el concurrente de GL |
 ------------------------------------------------------------------------*/

  FUNCTION ejecutar_concurrente (p_set_of_books_id IN NUMBER
                                ,p_group_id IN VARCHAR2
                                ,x_request_id OUT NUMBER
                                ,x_errmsg OUT VARCHAR2
                                ) RETURN BOOLEAN IS
    v_current_run_id NUMBER;
    v_request_id NUMBER;
    v_group_id NUMBER := P_GROUP_ID;
  BEGIN
    v_current_run_id := gl_interface_control_pkg.get_unique_run_id;

    BEGIN
      GL_JOURNAL_IMPORT_PKG.populate_interface_control(user_je_source_name => 'Acopio Fletes',
                                                       group_id => v_group_id,
                                                       set_of_books_id => p_set_of_books_id,
                                                       interface_run_id => v_current_run_id);

    EXCEPTION
      WHEN others THEN
        x_errmsg := 'Error insertANDo datos de control en la tabla GL_INTERFACE_CONTROL. ' ||SQLERRM;
        RETURN(FALSE);
    END;

    x_request_id := fnd_request.submit_request
                    ('SQLGL'
                    ,'GLLEZL'
                    ,''
                    ,''
                    ,FALSE
                    ,TO_CHAR(v_current_run_id)
                    ,TO_CHAR(p_set_of_books_id)
                    ,'N'
                    ,''
                    ,''
                    ,'N'
                    ,'N'
                    ,NULL
                    ,'',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    ,'','','','','','','','','',''
                    );
    IF x_request_id = 0 THEN
      x_errmsg :='Error ejecutando la Importacion';
      RETURN(FALSE);
    ELSE
      XX_MSG_PK.msg('Id de Solicitud: '||TO_CHAR(x_request_id));
    END IF;

    RETURN(TRUE);
  END;
    FUNCTION DATOS_SEGMENTOS (p_oper_unit    IN NUMBER
                             ,x_errmsg             OUT VARCHAR2
                             ) RETURN BOOLEAN IS
  e_asiento_gral EXCEPTION;

BEGIN
      BEGIN
        SELECT hou.set_of_books_id , sob.name
        INTO g_set_of_books_id, g_sob_name
        from hr_operating_units  hou
                , gl_ledgers sob
            where hou.organization_id = p_oper_unit
            AND sob.ledger_id = hou.set_of_books_id;
      EXCEPTION
                WHEN OTHERS THEN
                  x_errmsg := 'No se pudo recuperar el juego de libros para la unidad operativa ' || p_oper_unit;
                 RETURN(FALSE);
      END;

    BEGIN
      SELECT gsob.chart_of_accounts_id
      INTO g_structure_number
      FROM gl_ledgers gsob
      WHERE g_set_of_books_id = gsob.ledger_id;
    EXCEPTION
      WHEN others THEN
        x_errmsg := 'No se pudo obtener la estructura contable para la organizacion: ';
        RETURN(FALSE);
    END;
    debug_line('Estructura del flexfield contable: '|| g_structure_number);

                 IF NOT Fnd_Flex_Apis.get_qualifier_segnum(appl_id => XX_TCG_UTIL_PKG.c_gl_appl_id,
                                                        key_flex_code => XX_TCG_UTIL_PKG.c_gl_id_flex_code,
                                                        structure_number => g_structure_number,
                                                        flex_qual_name => XX_TCG_UTIL_PKG.C_GL_SEGMENT_BU_TYPE, -- unidad de negoci
                                                        segment_number => g_nseg_unidad_negocio) THEN
                x_errmsg := 'No fue posible obtener el numero de segmento para el calificador: '|| XX_TCG_UTIL_PKG.c_gl_segment_bu_type
                          ||' para el juego de libros : ' || g_set_of_books_id;
                RETURN(FALSE);
              END IF;
              IF NOT Fnd_Flex_Apis.get_qualifier_segnum(appl_id => XX_TCG_UTIL_PKG.C_GL_APPL_ID,
                                                        key_flex_code => XX_TCG_UTIL_PKG.C_GL_ID_FLEX_CODE,
                                                        structure_number => g_structure_number,
                                                        flex_qual_name => XX_TCG_UTIL_PKG.C_GL_SEGMENT_PRODUCT_TYPE, -- producto
                                                        segment_number => g_nseg_producto) THEN
                x_errmsg := 'No fue posible obtener el numero de segmento para el calificador: '|| XX_TCG_UTIL_PKG.C_GL_SEGMENT_PRODUCT_TYPE
                          ||' para el juego de libros : ' || g_set_of_books_id;
                RAISE e_asiento_gral;
              END IF;
                IF NOT Fnd_Flex_Apis.get_qualifier_segnum(appl_id => XX_TCG_UTIL_PKG.c_gl_appl_id,
                                                        key_flex_code => XX_TCG_UTIL_PKG.c_gl_id_flex_code,
                                                        structure_number => g_structure_number,
                                                        flex_qual_name => XX_TCG_UTIL_PKG.C_GL_SEGMENT_UP_TYPE, -- unidad  productiva
                                                        segment_number => g_nseg_uni_productiva) THEN
                x_errmsg := 'No fue posible obtener el numero de segmento para el calificador: '|| XX_TCG_UTIL_PKG.c_gl_segment_bu_type
                          ||' para el juego de libros : ' || g_set_of_books_id;
                RETURN(FALSE);
              END IF;
                 IF NOT Fnd_Flex_Apis.get_qualifier_segnum(appl_id => XX_TCG_UTIL_PKG.c_gl_appl_id,
                                                        key_flex_code => XX_TCG_UTIL_PKG.c_gl_id_flex_code,
                                                        structure_number => g_structure_number,
                                                        flex_qual_name => XX_TCG_UTIL_PKG.C_GL_SEGMENT_CC_TYPE, -- centro costo
                                                        segment_number => g_nseg_ctro_costo) THEN
                x_errmsg := 'No fue posible obtener el numero de segmento para el calificador: '|| XX_TCG_UTIL_PKG.c_gl_segment_bu_type
                          ||' para el juego de libros : ' || g_set_of_books_id;
                RETURN(FALSE);
              END IF;
                               IF NOT Fnd_Flex_Apis.get_qualifier_segnum(appl_id => XX_TCG_UTIL_PKG.c_gl_appl_id,
                                                        key_flex_code => XX_TCG_UTIL_PKG.c_gl_id_flex_code,
                                                        structure_number => g_structure_number,
                                                        flex_qual_name => XX_TCG_UTIL_PKG.C_GL_SEGMENT_PROYECTO_TYPE, -- proyecto
                                                        segment_number => g_nseg_proyecto) THEN
                x_errmsg := 'No fue posible obtener el numero de segmento para el calificador: '|| XX_TCG_UTIL_PKG.c_gl_segment_bu_type
                          ||' para el juego de libros : ' || g_set_of_books_id;
                RETURN(FALSE);
              END IF;

                 IF NOT Fnd_Flex_Apis.get_qualifier_segnum(appl_id => XX_TCG_UTIL_PKG.c_gl_appl_id,
                                                        key_flex_code => XX_TCG_UTIL_PKG.c_gl_id_flex_code,
                                                        structure_number => g_structure_number,
                                                        flex_qual_name => XX_TCG_UTIL_PKG.C_GL_SEGMENT_CURRENCY_TYPE, -- interco
                                                        segment_number => g_nseg_interco) THEN
                x_errmsg := 'No fue posible obtener el numero de segmento para el calificador: '|| XX_TCG_UTIL_PKG.c_gl_segment_bu_type
                          ||' para el juego de libros : ' || g_set_of_books_id;
                RETURN(FALSE);
              END IF;
    debug_line('Se obtuvieron las posiciones de los segmentos contables  de la estructura: '|| g_structure_number);
    return true;
    EXCEPTION
    WHEN e_asiento_gral THEN
      debug_line(x_errmsg);
      RETURN(false);
    WHEN others THEN
      x_errmsg := 'Error inesperado al intentar obtener la combinacion contable para la cuenta de fletes por venta para la carta de porte numero: '||'. Detalle: '|| SQLERRM;
      RETURN FALSE;
END DATOS_SEGMENTOS;

 /*------------------------------------------------------------------------
 | Function: cuenta_provision |
 | Purpose: Genera la cuenta de provision de fletes |
 | Parameters: p_registro in XX_TCG_CARTAS_PORTE_ALL%rowtype |
 | x_account_id in number |
 | x_errmsg OUT VARCHAR2 |
 ------------------------------------------------------------------------*/
  FUNCTION cuenta_provision (p_registro    IN XX_TCG_CARTAS_PORTE_ALL%rowtype
                            ,x_account_id OUT NUMBER
                            ,x_errmsg     OUT VARCHAR2
                            ) RETURN BOOLEAN 
  IS
      
    e_asiento_provision_flete EXCEPTION;
--    v_segment_num             NUMBER;
--    v_code_combination_id     NUMBER;
    v_n_segments              NUMBER;
--    v_unidad_negocios         VARCHAR2(25);
    v_segmentarray fnd_flex_ext.segmentarray;
--    v_nsegments               NUMBER;

  BEGIN

    /* CR2528 Se solicita que la cuenta de Provisión tenga la misma Unidad de Negocio que la cuenta de Fletes */
    debug_line('Se obtienen los segmentos de combinacion contable standard de provisión.');

    IF NOT FND_FLEX_EXT.get_segments(application_short_name => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                    ,key_flex_code          => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                    ,structure_number       => g_structure_number
                                    ,combination_id         => g_provision_account_id
                                    ,n_segments             => v_n_segments
                                    ,segments               => v_segmentarray) THEN

      x_errmsg := 'No se pudieron obtener los segmentos del template de la combinacion contable : '||g_provision_account_id
                  ||'. Detalle: ' ||fnd_flex_ext.get_message;
      RAISE e_asiento_provision_flete;
      
    END IF;
    
    v_segmentarray(g_nseg_unidad_negocio) := g_unidad_negocio;
    g_unidad_negocio := NULL;
     
    debug_line('Nueva combinacion contable con UN = '||v_segmentarray(g_nseg_unidad_negocio));

    IF NOT FND_FLEX_KEYVAL.validate_segs
                          ('CREATE_COMBINATION'
                          ,XX_TCG_UTIL_PKG.c_gl_application_short_name
                          ,XX_TCG_UTIL_PKG.c_gl_id_flex_code
                          ,g_structure_number
                          ,FND_FLEX_EXT.concatenate_segments
                                       (n_segments => v_n_segments
                                       ,segments   => v_segmentarray
                                       ,delimiter  => (FND_FLEX_EXT.get_delimiter
                                                                   (application_short_name => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                                                   ,key_flex_code          => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                                                   ,structure_number       => g_structure_number)))
                          ,'V'
                          ,SYSDATE
                          ,'ALL'
                          ,NULL
                          ,NULL
                          ,NULL
                          ,NULL
                          ,NULL
                          ,NULL
                          ,FND_GLOBAL.resp_id
                          ,FND_GLOBAL.resp_appl_id
                          ,FND_GLOBAL.user_id
                          ,NULL
                          ,NULL
                          ,NULL ) THEN
                                        
      x_errmsg := 'No fue posible obtener la combinacion contable para los segmentos: '
                  ||FND_FLEX_EXT.concatenate_segments
                                 (n_segments => v_n_segments
                                 ,segments   => v_segmentarray
                                 ,delimiter  => (FND_FLEX_EXT.get_delimiter
                                                              (application_short_name => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                                              ,key_flex_code          => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                                              ,structure_number       => g_structure_number)))
                  ||' Se produjo un error en el segmento: '|| FND_FLEX_KEYVAL.error_segment||'. Detalle: '|| FND_FLEX_KEYVAL.error_message;
      RETURN(FALSE);
      
    END IF;

    x_account_id := FND_FLEX_KEYVAL.combination_id;  
    /* fin CR2528 */
    
    /* CR2528
    debug_line('Verifico cuenta de provisión ');

    IF NOT FND_FLEX_KEYVAL.validate_ccid (appl_short_name  => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                         ,key_flex_code    => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                         ,structure_number => g_structure_number
                                         ,combination_id   => g_provision_account_id        
                                         ,resp_appl_id     => FND_GLOBAL.resp_appl_id
                                         ,resp_id          => FND_GLOBAL.resp_id
                                         ,user_id          => FND_GLOBAL.user_id) THEN
           
      x_errmsg := ' Combinación contable de provisión inválida: '||g_provision_account_id   
                  ||'. Detalle: '|| FND_FLEX_KEYVAL.error_message;
      RETURN(FALSE);
      
    END IF;
    
    x_account_id := g_provision_account_id;                                  
    */
    debug_line('La combinacion contable de provisión es valida y corresponde al ID: '|| x_account_id);
    
    RETURN(TRUE);
    
  EXCEPTION
    WHEN e_asiento_provision_flete THEN
      debug_line(x_errmsg);
      RETURN(FALSE);
    
    WHEN others THEN
      x_errmsg := 'Error inesperado obteniendo cuenta de provision. Detalle: '||SQLERRM;
      RETURN(FALSE);
    
  END;

  FUNCTION ORG_DESTINO ( p_cuit_destino IN number
                                            , p_cuit_provisionado_por in number
                                            , p_cuit_titular           in number
                                            , p_es_retiro   in VARCHAR2
                                            , p_item_id in number
                                            , p_estab_id in number
                                            , p_estab_id_tit in number
                                            , x_org_id OUT NUMBER
                                            , x_errmsg OUT VARCHAR2
                                            ) RETURN BOOLEAN IS

  TYPE mainCurTyp      IS REF CURSOR;
  l_main_cursor              mainCurTyp;
  rOrgInfo                      XX_TCG_FUNCTIONS_PKG.trOrgInfo;
  l_main_cursor_stmt           VARCHAR2(4000);
  l_second_cursor_stmt       VARCHAR2(4000);
  l_org_id                           NUMBER;
  v_esreacon                       NUMBER;
BEGIN
    if p_es_retiro = 'Y' THEN
          if XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(p_cuit_titular) THEN
                    l_main_cursor_stmt := XX_TCG_FUNCTIONS_PKG.c_main_cursor_stmt
                    ||'AND pc.operating_unit_cuit = '''||p_cuit_titular||''' '||chr(10)
                    ||'AND est.establecimiento_id = '||p_estab_id_tit||' ';
                    debug_line('Cia del grupo  : '|| p_cuit_titular);

                  OPEN l_main_cursor FOR l_main_cursor_stmt;
                          FETCH l_main_cursor INTO rOrgInfo;
                          l_org_id := rOrgInfo.organization_id;
                  CLOSE l_main_cursor;
                   debug_line('Org_id : '|| l_org_id);
                     x_org_id := l_org_id;
                     return true;
            else -- Empresas que no son del grupo
                    SELECT count(*)
                    INTO v_esreacon
                    FROM ap_suppliers a
                    WHERE num_1099 || global_attribute12 = p_cuit_titular
                   AND vENDor_type_lookup_code = 'REACONDICIONADOR';

                  l_main_cursor_stmt := XX_TCG_FUNCTIONS_PKG.c_main_cursor_stmt
                                                      ||'AND pc.operating_unit_cuit = '||p_cuit_provisionado_por ||' '||chr(10);
                  IF NVL(v_esreacon,0)  = 1 THEN  -- Reacondicionador
                         l_main_cursor_stmt := l_main_cursor_stmt  ||'AND msi_dfv.xx_tcg_tipos = ''REACONDICIONADOR'' ';
                         debug_line('Reacondicionadora : '|| p_cuit_titular);

                  ELSE  -- No es Reacondicionador. Se  llega a la org_id primero por articulo y después sin articulo
                         l_second_cursor_stmt       :=   l_main_cursor_stmt;
                         l_main_cursor_stmt          := l_main_cursor_stmt
                                                                    ||'AND msi_dfv.xx_tcg_especie_oncca = '''||XX_TCG_FUNCTIONS_PKG.Obtiene_Especie_ONCCA(p_item_id)||''' '||chr(10)
                                                                    ||'AND msi_dfv.xx_tcg_tipos = ''PUERTO'' ';
                        l_second_cursor_stmt        := l_second_cursor_stmt
                                                                     ||'AND msi_dfv.xx_tcg_tipos = ''PUERTO'' ';
                        debug_line('Puerto : '|| p_cuit_destino);
                  END IF;

                      l_org_id := NULL;
                          OPEN l_main_cursor FOR l_main_cursor_stmt;
                                  FETCH l_main_cursor INTO rOrgInfo;
                                  l_org_id := rOrgInfo.organization_id;
                          CLOSE l_main_cursor;
                          x_org_id := l_org_id;
                          return true;
            END if;
    END if;
    IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (p_cuit_destino) = 'N' THEN
    -- Empresas que no son del grupo
            SELECT count(*)
            INTO v_esreacon
            FROM ap_suppliers a
            WHERE num_1099 || global_attribute12 = p_cuit_destino
           AND vENDor_type_lookup_code = 'REACONDICIONADOR';

          l_main_cursor_stmt := XX_TCG_FUNCTIONS_PKG.c_main_cursor_stmt
                                              ||'AND pc.operating_unit_cuit = '||p_cuit_provisionado_por||' '||chr(10);
          IF NVL(v_esreacon,0)  = 1 THEN  -- Reacondicionador
                 l_main_cursor_stmt := l_main_cursor_stmt  ||'AND msi_dfv.xx_tcg_tipos = ''REACONDICIONADOR'' ';
                 debug_line('Reacondicionadora : '|| p_cuit_destino);

          ELSE  -- No es Reacondicionador. Se  llega a la org_id primero por articulo y después sin articulo
                 l_second_cursor_stmt       :=   l_main_cursor_stmt;
                 l_main_cursor_stmt          := l_main_cursor_stmt
                                                            ||'AND msi_dfv.xx_tcg_especie_oncca = '''||XX_TCG_FUNCTIONS_PKG.Obtiene_Especie_ONCCA(p_item_id)||''' '||chr(10)
                                                            ||'AND msi_dfv.xx_tcg_tipos = ''PUERTO'' ';
                l_second_cursor_stmt        := l_second_cursor_stmt
                                                             ||'AND msi_dfv.xx_tcg_tipos = ''PUERTO'' ';
                debug_line('Puerto : '|| p_cuit_destino);

          END IF;

          l_org_id := NULL;
          OPEN l_main_cursor FOR l_main_cursor_stmt;
                  FETCH l_main_cursor INTO rOrgInfo;
                  l_org_id := rOrgInfo.organization_id;
          CLOSE l_main_cursor;

          if l_org_id is NULL AND   l_second_cursor_stmt IS NOT NULL THEN
                   OPEN l_main_cursor FOR l_second_cursor_stmt;
                          FETCH l_main_cursor INTO rOrgInfo;
                          l_org_id := rOrgInfo.organization_id;
                  CLOSE l_main_cursor;
          END if;
         debug_line('Org_id : '|| l_org_id);
        x_org_id := l_org_id;
       return true;
ELSE        -- Empresas del grupo

    l_main_cursor_stmt := XX_TCG_FUNCTIONS_PKG.c_main_cursor_stmt
    ||'AND pc.operating_unit_cuit = '''||p_cuit_destino||''' '||chr(10)
    ||'AND est.establecimiento_id = '||p_estab_id||' ';
    debug_line('Cia del grupo  : '|| p_cuit_destino);

          OPEN l_main_cursor FOR l_main_cursor_stmt;
                  FETCH l_main_cursor INTO rOrgInfo;
                  l_org_id := rOrgInfo.organization_id;
          CLOSE l_main_cursor;
                   debug_line('Org_id : '|| l_org_id);
          x_org_id := l_org_id;
         return true;

END IF;
EXCEPTION
    WHEN others THEN
        x_errmsg := 'Error al obtener org_id del cuit de destino ' || p_cuit_destino || ' cuit_provisionado_por ' || p_cuit_provisionado_por  || sqlerrm;
        return false;
END ORG_DESTINO;


  /*------------------------------------------------------------------------
  | Function: cuenta_flete |
  | Purpose: Obtiene la combinacion contable para la cuenta de fletes |
  |+------------------------------------------------------------------------*/
  FUNCTION cuenta_flete( p_carta_porte_rec IN XX_TCG_CARTAS_PORTE_ALL%rowtype
                       , x_account_id OUT NUMBER
                       , x_errmsg OUT VARCHAR2
                       ) RETURN BOOLEAN 
  IS

    v_code_combination_id      NUMBER;
    v_code_combi_id_flete      NUMBER;
    v_n_segments               NUMBER;
    v_segmentarray             FND_FLEX_EXT.segmentarray;
    e_asiento_provision_flete  EXCEPTION;

    v_compania                 VARCHAR2(25);
    v_cuenta                   VARCHAR2(25);
    v_unidad_negocios          VARCHAR2(25);
    v_producto                 VARCHAR2(25);
    v_unidad_productiva        VARCHAR2(25);
    v_centro_costos            VARCHAR2(25);
    v_proyecto                 VARCHAR2(25);
    v_interco                  VARCHAR2(25);
    v_es_chs                   NUMBER(3);
    v_grano_semillero          NUMBER;
    v_es_retiro                VARCHAR2(1);
    v_cuit_provisionado_por    NUMBER;
    v_organization_id          NUMBER;

    v_organization_code        VARCHAR2(3);
    v_category_set_id          NUMBER;

    v_esreacon                 NUMBER(1);
  
  BEGIN
    
    debug_line('Iniciando cuenta_flete');
    
    v_cuit_provisionado_por:= XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (p_carta_porte_rec.provisionado_por);
    
    -----------------------------------------------------
    -- Defino la combinacion a utilizar
    -------------------------------------------------------
    -- cr2351  Para destino <> de grupo se verifica si es reacondicionadora
    IF NOT XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo( p_carta_porte_rec.destino_cuit)  THEN
      
      SELECT count(*)
        INTO v_esreacon
        FROM AP_SUPPLIERS a
       WHERE num_1099 || global_attribute12 = p_carta_porte_rec.destino_cuit
         AND vendor_type_lookup_code = 'REACONDICIONADOR';
      
    ELSE
      
      v_esreacon := 0;
      
    END IF;
    
    --C#1390 iNICIO ABARACCA
    --Solo Pilaga y Arroz     --   Cuenta: Fletes Internos
    IF v_cuit_provisionado_por = 30506898591 AND
      XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) = '021' AND
      (XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo(p_carta_porte_rec.destino_cuit) OR v_esreacon = 1 ) THEN    -- CR2351  Feb-20 para que no tome el arroz vendido a otra cía
      
      v_code_combi_id_flete := 24392;

    ELSIF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) = '003' THEN -- Si es Mani Caja tiene que provisionar a la cuenta 5130001  - provision flete mani planta a planta
      
      IF p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND  p_carta_porte_rec.destino_estab_id = '330' THEN
        
        v_code_combi_id_flete := 5071913;  -- confirmar con ale
        
      ELSE
        
        v_code_combi_id_flete := 9252;
        
      END IF;

    ELSIF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) = '007' AND -- provision flete mani planta a planta
      p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND  p_carta_porte_rec.destino_estab_id = '330' THEN
      
      v_code_combi_id_flete := 5071913;  -- se eligio una comibinacion existente que tuviera
      
    --C#1390 FIN
      
    ELSIF v_cuit_provisionado_por IN (NVL(p_carta_porte_rec.intermediario_cuit,0)
                                     ,NVL(p_carta_porte_rec.titular_cp_cuit,0)
                                     ,NVL( p_carta_porte_rec.rtte_comercial_cuit,0)) AND 
      p_carta_porte_rec.intermediario_retiro = 'N' AND 
      p_carta_porte_rec.rtte_comercial_retiro = 'N' THEN
      
      v_code_combi_id_flete := g_flete_por_vta_account_id;    -->    Cuenta Flete por Venta. (Es prioridad de elección)
      
    ELSIF ( p_carta_porte_rec.intermediario_retiro = 'Y' AND 
      NVL(p_carta_porte_rec.intermediario_cuit,0) = v_cuit_provisionado_por) OR
      (p_carta_porte_rec.rtte_comercial_retiro = 'Y' AND 
      NVL(p_carta_porte_rec.rtte_comercial_cuit,0) = v_cuit_provisionado_por) THEN
      
      v_code_combi_id_flete := g_flete_por_vta_account_id;    -->    Cuenta Flete por Venta. (Es prioridad de elección)
      
    ELSIF (v_cuit_provisionado_por = p_carta_porte_rec.titular_cp_cuit) AND 
      ((p_carta_porte_rec.rtte_comercial_cuit IS NOT NULL AND 
        XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_C(p_carta_porte_rec.rtte_comercial_cuit) = 'N') OR
        (p_carta_porte_rec.intermediario_cuit IS NOT NULL AND 
        XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_C(p_carta_porte_rec.intermediario_cuit) = 'N') ) AND 
        (p_carta_porte_rec.intermediario_retiro = 'Y' OR p_carta_porte_rec.rtte_comercial_retiro = 'Y') THEN

      v_code_combi_id_flete := g_flete_por_cpra_account_id; --> cuenta por compra
      
    ELSIF (v_cuit_provisionado_por = p_carta_porte_rec.destino_cuit) OR
      (v_cuit_provisionado_por = p_carta_porte_rec.destinatario_cuit) THEN

      v_code_combi_id_flete := g_flete_por_cpra_account_id; --> cuenta por compra
      
    ELSE
      
      x_errmsg := 'No se puede provisionar la carta de porte por definición de cuenta flete : ' || p_carta_porte_rec.NUMERO_CARTA_PORTE || ' '
                  || p_carta_porte_rec.titular_cp_cuit;
      RAISE e_asiento_provision_flete;
      
    END IF;


    debug_line('Obtengo combinacion contable a utilizar: ' ||v_code_combi_id_flete );


    ---------------------------------------------------
    -- Obtengo la estructura del flexfield contable
    ----------------------------------------------------
    debug_line('Obtengo segmentos de combinacion contable del flete .');

    IF NOT FND_FLEX_EXT.get_segments(application_short_name => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                    ,key_flex_code          => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                    ,structure_number       => g_structure_number
                                    ,combination_id         => v_code_combi_id_flete
                                    ,n_segments             => v_n_segments
                                    ,segments               => v_segmentarray) THEN

      x_errmsg := 'No se pudieron obtener los segmentos del template de la combinacion contable : '||v_code_combi_id_flete
                  ||'. Detalle: ' ||fnd_flex_ext.get_message;
      RAISE e_asiento_provision_flete;
      
    END IF;
    
    ------------------------------------------
    --- Busca la organización de destino
    ------------------------------------------
    IF p_carta_porte_rec.intermediario_retiro = 'Y' OR
      p_carta_porte_rec.rtte_comercial_retiro = 'Y' THEN  -- Es CP de Retiro
      
      v_es_retiro := 'Y';
      
    ELSE
      
      v_es_retiro := 'N';
      
    END IF;

    IF NOT ORG_DESTINO (p_cuit_destino          => p_carta_porte_rec.destino_cuit
                       ,p_cuit_provisionado_por => v_cuit_provisionado_por
                       ,p_cuit_titular          => p_carta_porte_rec.titular_cp_cuit
                       ,p_es_retiro             => v_es_retiro
                       ,p_item_id               => p_carta_porte_rec.item_id
                       ,p_estab_id              => p_carta_porte_rec.destino_estab_id
                       ,p_estab_id_tit          => p_carta_porte_rec.titular_cp_estab_id
                       ,x_org_id                => v_organization_id
                       ,x_errmsg                => x_errmsg
                       ) THEN
      
      RAISE e_asiento_provision_flete;
        
    END IF;

    IF v_organization_id is  NULL THEN
      
      x_errmsg := 'No se pudo obtener la organizacion para carta de porte :  '||p_carta_porte_rec.numero_carta_porte || 
                  ' Cuit Provisionado ' || v_cuit_provisionado_por;
      RAISE e_asiento_provision_flete;

    END IF;

    debug_line('Ejecutó ORG_DESTINO valor organizacion ' || v_organization_id);

    -----------------------------------------------------
    -- Altera segmentos en caso de corresponder
    ----------------------------------------------------
    ---------------------
    -- Unidad de Negocios
    ---------------------
    v_unidad_negocios := NULL;
    
    BEGIN

      SELECT count(1)
        INTO v_grano_semillero
        FROM XX_OPM_ESTABLECIMIENTOS
       WHERE establecimiento_id = p_carta_porte_rec.destino_estab_id
         AND UPPER(campo) LIKE '%SEMILLERO%'
         AND XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) <> '021' ;

      IF v_grano_semillero > 0 THEN
        
        v_unidad_negocios := '25';

      ELSE
        
        SELECT DECODE(SUBSTR(name,4,3),'CHS',1,0) 
          INTO v_es_chs 
          FROM HR_ALL_ORGANIZATION_UNITS 
         WHERE organization_id = v_organization_id;

        SELECT xmsv.value_constant
          INTO v_unidad_negocios
          FROM XLA_MAPPING_SET_VALUES xmsv
         WHERE mapping_set_code          = (SELECT meaning 
                                              FROM FND_LOOKUPS
                                             WHERE LOOKUP_TYPE = 'XX_TCG_PROVISION_FLETE_MAPPING'
                                               AND LOOKUP_CODE = DECODE(NVL(v_es_chs,0),0,'U_NEGOCIOS','U_NEGOCIOS_CHS')
                                           )
           AND amb_context_code          = 'DEFAULT'
           AND xmsv.input_value_constant = v_organization_id;
       
      END IF;
      
    EXCEPTION 
      WHEN others THEN
        NULL;
    END;

    -- CR 1696 -- Inicio
    -- Si obtiene unidad de Negocio de Arroz y no es Arroz, cambia la misma
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) <> '021' AND
      v_es_chs = 0 AND
      v_unidad_negocios IN ( '10', '30' ) THEN

      CASE 
        WHEN v_unidad_negocios = '10' THEN
          v_unidad_negocios := '05';
        WHEN v_unidad_negocios = '30' THEN
          v_unidad_negocios := '25';
      END CASE;

    END IF;

    -- Si obtiene unidad de Negocio No de Arroz y  es Arroz, cambia la misma
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) = '021' AND
      v_es_chs = 0 AND
      v_unidad_negocios IN ( '05', '25' ) THEN

      CASE
        WHEN v_unidad_negocios = '05' THEN
          v_unidad_negocios := '10';
        WHEN v_unidad_negocios = '25' THEN
          v_unidad_negocios := '30';
      END CASE;

    END IF;

    -- Si es mani se cambia unidad de negocios
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) IN ( '006', '007' ) AND
      v_es_chs = 0 AND
      v_unidad_negocios = 25 THEN

      v_unidad_negocios := '75';

    END IF;
    -- CR 1696 -- Fin

    ---C#1390 - provision flete mani planta a planta     - MANI PLANTA A PLANTA
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) in ('003','006','007') AND
      p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND  p_carta_porte_rec.destino_estab_id = '330' THEN
      
      v_unidad_negocios := 75;  
      
    END IF;
    --C#1390 FIN

    IF v_unidad_negocios IS NOT NULL THEN
      
      debug_line('Cambio unidad negocios ' || v_segmentarray(g_nseg_unidad_negocio) || ' por ' ||  v_unidad_negocios);
      v_segmentarray(g_nseg_unidad_negocio) := v_unidad_negocios;
      
      g_unidad_negocio := v_unidad_negocios;                                    --CR2528
      
    END IF;

    -----------
    -- Producto
    -----------
    v_producto := NULL;
    
    BEGIN
      
      SELECT organization_code
        INTO v_organization_code
        FROM MTL_PARAMETERS mp
       WHERE organization_id = v_organization_id;

      SELECT category_set_id
        INTO v_category_set_id
        FROM MTL_CATEGORY_SETS
       WHERE category_set_name LIKE '%Categor%Producto%OPM%';
     
    EXCEPTION
      WHEN others THEN
        x_errmsg := 'No se pudo obtener producto de la combinación contable  : '||v_code_combi_id_flete
                    ||'. Y Carta de porte : ' ||p_carta_porte_rec.numero_carta_porte;
        RAISE e_asiento_provision_flete;
    END;

    v_producto := XX_SLA_ARG_UTIL_PKG.determinar_inv_cat(p_organization_code => v_organization_code
                                                        ,p_inventory_item_id => p_carta_porte_rec.item_id
                                                        ,p_category_set_id   => v_category_set_id
                                                        ,p_return            => 'VALUE');

    --Se cambia el producto para mani C#1390
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) in ('003','006','007') THEN
      
      v_producto:= '068';
      
    END IF;

    IF v_producto IS NOT NULL THEN
      
      debug_line('Cambio Producto ' || v_segmentarray(g_nseg_producto) || ' por ' ||  v_producto);
      v_segmentarray(g_nseg_producto) := v_producto;
      
    END IF;

    --------------------
    -- Unidad productiva
    --------------------
    v_unidad_productiva := NULL;
    
    BEGIN
      
      SELECT DECODE(SUBSTR(name,4,3),'CHS',1,0) 
        INTO v_es_chs 
        FROM HR_ALL_ORGANIZATION_UNITS 
       WHERE organization_id = v_organization_id;

      SELECT xmsv.value_constant
        INTO v_unidad_productiva
        FROM XLA_MAPPING_SET_VALUES xmsv
       WHERE mapping_set_code          = (SELECT meaning 
                                            FROM FND_LOOKUPS
                                           WHERE lookup_type = 'XX_TCG_PROVISION_FLETE_MAPPING'
                                             AND lookup_code = DECODE(NVL(v_es_chs,0),0,'U_PRODUCTIVA','U_PRODUCTIVA_CHS')
                                         )
         AND xmsv.amb_context_code     = 'DEFAULT'
         AND xmsv.input_value_constant = v_organization_id;
        
    EXCEPTION 
      WHEN others THEN
        NULL;
    END;

    -- CR 1696 -- Inicio
    -- Si es Arroz, Titular no es empresa del grupo y Remitente Comercial Pilaga y es Retiro

    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id)      = '021'  AND
      XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_C(p_carta_porte_rec.titular_cp_cuit) = 'N'    AND
      ((p_carta_porte_rec.intermediario_retiro = 'Y' AND NVL(p_carta_porte_rec.intermediario_cuit,0)  = 30506898591 ) OR
       (p_carta_porte_rec.rtte_comercial_retiro = 'Y' AND NVL(p_carta_porte_rec.rtte_comercial_cuit,0) = 30506898591 ) ) THEN
      
      v_unidad_productiva := 12117;

    END IF;


    ---C#1390 - provision flete mani planta a planta     - MANI PLANTA A PLANTA
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) in ('003','006','007') AND
      p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND  p_carta_porte_rec.destino_estab_id = '330' THEN
      
      v_unidad_productiva := 10216;  --
      
    END IF;
    --C#1390 -- y PLANTA A CLIENTE
    
    IF XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) in ('003','006','007') AND
      p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND  NVL(p_carta_porte_rec.destino_estab_id,0) <> '330' THEN
      
      v_unidad_productiva := 10216;  --
      
    END IF;
    --C#1390  -- FIN

    -- Fin

    IF v_unidad_productiva IS NOT NULL THEN
      
      debug_line('Cambio Unidad Productiva ' || v_segmentarray(g_nseg_uni_productiva) || ' por ' ||  v_unidad_productiva);
      v_segmentarray(g_nseg_uni_productiva) := v_unidad_productiva;
      
    END IF;

    -------------------
    -- Centro de Costos
    -------------------
    BEGIN
      
      v_centro_costos :=  v_segmentarray(g_nseg_ctro_costo);

      -- VN  -12-09 se agrega condicion para determinar centro de costos 3811 c#1390  para mani
      IF (XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) IN ('003','006','007') AND 
        p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND 
        p_carta_porte_rec.destino_estab_id = '330') THEN
        
        v_centro_costos := '3811';
        
      ELSIF (XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) IN ('003','006','007') AND 
        p_carta_porte_rec.titular_cp_tipo = 'OPERADOR' AND 
        NVL(p_carta_porte_rec.destino_estab_id,0) <> '330') THEN  --PLANTA A CLIENTE
        
        v_centro_costos := '3823';
        
      ELSIF (XX_TCG_FUNCTIONS_PKG.Obtiene_Codigo_ONCCA (p_carta_porte_rec.item_id) IN ('003','006','007') AND 
        p_carta_porte_rec.titular_cp_tipo = 'PRODUCTOR' AND 
        NVL(p_carta_porte_rec.destino_estab_id,0) = '330') THEN  --CAMPO A PLANTA
        
        v_centro_costos := '3812';
        
      ELSIF v_producto = 100 THEN
        
        v_centro_costos := '3812';
        
      ELSE
        
        v_centro_costos := '2003';
        
      END IF;

      SELECT xmsv.value_constant
        INTO v_centro_costos
        FROM XLA_MAPPING_SET_VALUES xmsv
       WHERE mapping_set_code          = (SELECT meaning 
                                            FROM FND_LOOKUPS
                                           WHERE lookup_type = 'XX_TCG_PROVISION_FLETE_MAPPING'
                                             AND lookup_code = 'CENTRO_COSTO')
         AND xmsv.amb_context_code     = 'DEFAULT'
         AND xmsv.input_value_constant = v_organization_id;
      
    EXCEPTION 
      WHEN others THEN
        NULL;
    END;
    
    IF v_centro_costos IS NOT NULL THEN
      
      debug_line('Cambio Centro Costo ' || v_segmentarray(g_nseg_ctro_costo) || ' por ' ||  v_centro_costos);
      v_segmentarray(g_nseg_ctro_costo) := v_centro_costos;
      
    END if;

    -----------
    -- Proyecto
    -----------
    BEGIN
      
      SELECT xmsv.value_constant
        INTO v_proyecto
        FROM XLA_MAPPING_SET_VALUES xmsv
       WHERE xmsv.mapping_set_code     = (SELECT meaning 
                                            FROM FND_LOOKUPS
                                           WHERE lookup_type = 'XX_TCG_PROVISION_FLETE_MAPPING'
                                             AND lookup_code = 'PROYECTO')
         AND xmsv.amb_context_code     = 'DEFAULT'
         AND xmsv.input_value_constant = p_carta_porte_rec.lot_no;
      
    EXCEPTION 
      WHEN others THEN
        NULL;
    END;

    IF v_proyecto IS NOT NULL THEN
         
      debug_line('Cambio Proyecto ' || v_segmentarray(g_nseg_proyecto) || ' por ' ||  v_proyecto);
      v_segmentarray(g_nseg_proyecto) := v_proyecto;
      
    END IF;
    
    -----------
    -- CIA INTERCO
    -----------
    v_interco := '0';
    v_segmentarray(g_nseg_interco) := v_interco;

    ----------------------------------
    -- Obtengo la combinacion contable
    ----------------------------------
    debug_line('Obtengo nueva combinacion contable.');

    IF NOT FND_FLEX_KEYVAL.validate_segs
                          ('CREATE_COMBINATION'
                          ,XX_TCG_UTIL_PKG.c_gl_application_short_name
                          ,XX_TCG_UTIL_PKG.c_gl_id_flex_code
                          ,g_structure_number
                          ,FND_FLEX_EXT.concatenate_segments
                                       (n_segments => v_n_segments
                                       ,segments   => v_segmentarray
                                       ,delimiter  => (FND_FLEX_EXT.get_delimiter
                                                                   (application_short_name => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                                                   ,key_flex_code          => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                                                   ,structure_number       => g_structure_number)))
                          ,'V'
                          ,SYSDATE
                          ,'ALL'
                          ,NULL
                          ,NULL
                          ,NULL
                          ,NULL
                          ,NULL
                          ,NULL
                          ,FND_GLOBAL.resp_id
                          ,FND_GLOBAL.resp_appl_id
                          ,FND_GLOBAL.user_id
                          ,NULL
                          ,NULL
                          ,NULL ) THEN
                                        
      x_errmsg := 'No fue posible obtener la combinacion contable para los segmentos: '
                  ||FND_FLEX_EXT.concatenate_segments
                                 (n_segments => v_n_segments
                                 ,segments   => v_segmentarray
                                 ,delimiter  => (FND_FLEX_EXT.get_delimiter
                                                              (application_short_name => XX_TCG_UTIL_PKG.c_gl_application_short_name
                                                              ,key_flex_code          => XX_TCG_UTIL_PKG.c_gl_id_flex_code
                                                              ,structure_number       => g_structure_number)))
                  ||' Se produjo un error en el segmento: '|| FND_FLEX_KEYVAL.error_segment||'. Detalle: '|| FND_FLEX_KEYVAL.error_message;
      RETURN(FALSE);
      
    END IF;

    x_account_id := FND_FLEX_KEYVAL.combination_id;
    debug_line('Id de combinacion contable obtenida: '|| x_account_id);
    debug_line('Fin cuenta_flete');


    RETURN TRUE;

  EXCEPTION
    WHEN e_asiento_provision_flete THEN
      debug_line(x_errmsg);
      RETURN(false);
    WHEN others THEN
      x_errmsg := 'Error inesperado al intentar obtener la combinacion contable para la cuenta de fletes por venta para la carta de porte numero: '
                 ||p_carta_porte_rec.numero_carta_porte ||'. Detalle: '|| SQLERRM;
      -- debug_line('Error: '|| x_errmsg);
      RETURN FALSE;
      
  END CUENTA_FLETE;


 /*------------------------------------------------------------------------
 | Function: Generar_Asiento |
 | Purpose: Genera los asientos contables necesarios |
 | Parameters: costo_flete IN NUMBER |
 | costo_flete_currency_code IN VARCHAR2 |
 | x_errmsg OUT VARCHAR2 |
 | x_status OUT VARCHAR2 |
 | Clave: G: generated |
 | E: error |
 | W: warning |
 ------------------------------------------------------------------------*/

  FUNCTION generar_asiento (p_reversar_flag   IN VARCHAR2 DEFAULT 'N'
                           ,p_registro        IN XX_TCG_CARTAS_PORTE_ALL%rowtype
                           ,p_set_of_books_id IN NUMBER
                           ,p_group_id        IN NUMBER
                           ,x_errmsg         OUT VARCHAR2
                           ,x_status         OUT VARCHAR2) RETURN BOOLEAN 
  IS
  
    v_combination           NUMBER;
    v_descripcion           VARCHAR2(2000);
    v_asiento_tipo          VARCHAR2(1);
    v_errmsg                VARCHAR2(2000);
    e_gen_asiento           EXCEPTION;
    -- Agregado CR1181
    v_cant                  NUMBER;
    v_cuit_provisionado_por NUMBER;
    v_cuit_descri           NUMBER;
    --
    l_dummy                 NUMBER;
    
  BEGIN

    --  g_uni_provisionado_por := XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit(XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (p_registro.provisionado_por)) ;
    v_cuit_provisionado_por := XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (p_registro.provisionado_por);
    
    ----------------------------------------------
    -- Obtengo la descripcion de la carta de porte
    ----------------------------------------------
    v_descripcion := NULL;
    
    IF p_registro.intermediario_retiro = 'Y' OR p_registro.rtte_comercial_retiro = 'Y' THEN
      
      NULL;
      
    ELSE
      
      BEGIN
        
        IF v_cuit_provisionado_por = p_registro.destinatario_cuit THEN
          v_cuit_descri := p_registro.rtte_comercial_cuit;
        ELSIF v_cuit_provisionado_por = p_registro.rtte_comercial_cuit THEN
          v_cuit_descri := p_registro.intermediario_cuit;
        ELSIF v_cuit_provisionado_por = p_registro.intermediario_cuit THEN
          v_cuit_descri := p_registro.titular_cp_cuit;
        ELSE
          v_cuit_descri := v_cuit_provisionado_por;
        END IF;

        SELECT vendor_name
          INTO v_descripcion
          FROM AP_SUPPLIERS pav
         WHERE pav.num_1099||pav.global_attribute12 = v_cuit_descri;
        
      EXCEPTION 
        WHEN OTHERS THEN 
          NULL;
      END;
      
    END IF;

    -- Obtengo el codigo de combinacion contable de la cuenta de flete
    ---INICIO VN -07/08/2019
    IF (p_reversar_flag = 'N') THEN --VN
      
      IF NOT CUENTA_FLETE(p_carta_porte_rec => p_registro
                         ,x_account_id      => v_combination
                         ,x_errmsg          => v_errmsg
                         ) THEN
        x_status := 'E';
        RAISE e_gen_asiento;
        
      ELSE
        
        SELECT count(*)
          INTO v_cant
          FROM GL_INTERFACE
         WHERE reference21 = TO_CHAR(p_registro.carta_porte_id)
           AND code_combination_id = v_combination;
        
        IF (v_cant>0) THEN
          
          v_errmsg := 'La carta de porte '||p_registro.numero_carta_porte||' con code_combination_id '||v_combination
                      ||' (cuenta flete venta) ya fue registrada en GL_INTERFACE. ';
          x_status := 'W';
          RAISE e_gen_asiento;
         
        END IF;
        
      END IF;
      
    ELSE
      
      ---CUENTA FLETE DE REVERSION SOBRE EL ASIENTO GENERADO POR LA PROVISION
      
      SELECT gjl.code_combination_id 
        INTO v_combination
        FROM GL_JE_HEADERS gjh                                                  -- apps.GL_JE_HEADERS gjh  CR2528
           , GL_JE_lines   gjl                                                  -- apps.GL_JE_lines   gjl
       WHERE 1=1
         AND gjh.je_source           = 'Acopio Fletes'
         AND gjh.je_header_id        = gjl.je_header_id
         AND gjl.reference_1         = TO_CHAR(p_registro.carta_porte_id)
         AND gjl.code_combination_id NOT IN (SELECT DISTINCT a.provision_account_id 
                                               FROM XX_TCG_PARAMETROS_COMPANIA a       -- apps.XX_TCG_PARAMETROS_COMPANIA A  CR2528
                                              WHERE a.operating_unit      = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit(XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (p_registro.provisionado_por)))
                                                AND NVL(gjl.entered_Dr,0) <>0
                                                AND gjh.je_header_id      = (SELECT MAX(gjh.je_header_id)
                                                                               FROM GL_JE_HEADERS gjh            -- apps.GL_JE_HEADERS gjh,  CR2528
                                                                                  , GL_JE_lines   gjl            -- apps.GL_JE_lines gjl
                                                                              WHERE 1=1
                                                                                AND gjh.je_source         = 'Acopio Fletes'
                                                                                AND gjh.je_header_id      = gjl.je_header_id
                                                                                AND gjl.reference_1       = TO_CHAR(p_registro.carta_porte_id)
                                                                                AND NVL(gjl.entered_Dr,0) <> 0
                                                                                AND gjl.code_combination_id NOT IN (SELECT DISTINCT a.provision_account_id 
                                                                                                                      FROM XX_TCG_PARAMETROS_COMPANIA a        -- apps.XX_TCG_PARAMETROS_COMPANIA A CR2528
                                                                                                                     WHERE a.operating_unit = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit(XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (p_registro.provisionado_por)))
                                                                             );
      
    END IF;
    ---fin VN -07/08/2019

    -- Inserto registro en la tabla de interfaz
    IF (p_reversar_flag = 'N') THEN
      v_asiento_tipo := 'D';
    ELSE
      v_asiento_tipo := 'C';
    END IF;
    
    debug_line('Va a insertar_registro para juego de libros ' || g_set_of_books_id || ' combinacion ' || v_combination || ' tipo asiento ' || v_asiento_tipo);
    
    IF NOT insertar_registro (p_set_of_books_id     => g_set_of_books_id
                             ,p_registro            => p_registro
                             ,p_code_combination_id => v_combination
                             ,p_asiento_tipo        => v_asiento_tipo
                             ,p_group_id            => p_group_id
                             ,p_cp_descripcion      => v_descripcion
                             ,x_errmsg              => v_errmsg
                             ) THEN
      
      x_status := 'E';
      RAISE e_gen_asiento;
      
    END IF;

    -- Obtengo el codigo de combinacion contable de la cuenta de Provision
    IF (p_reversar_flag = 'N') THEN                                             -- CR2528
     
      IF NOT cuenta_provision (p_registro   => p_registro
                              ,x_account_id => v_combination
                              ,x_errmsg     => v_errmsg) THEN
        
        x_status := 'E';
        RAISE e_gen_asiento;
        
      ELSE  -- verifica que no exista un registro para igual carta y combinación
        
        SELECT count(*)
          INTO v_cant
          FROM GL_INTERFACE
         WHERE reference21         = TO_CHAR(p_registro.carta_porte_id)
           AND code_combination_id = v_combination;
        
        IF (v_cant>0) THEN
          
          v_errmsg := 'La carta de porte '||p_registro.numero_carta_porte||' con code_combination_id '|| v_combination
                      ||' (cuenta provision) ya fue registrada en GL_INTERFACE. ';
          x_status := 'W';
          RAISE e_gen_asiento;
         
        END IF;
        
      END IF;

    /* CR2528 */  
    ELSE 
      
      SELECT gjl.code_combination_id
        INTO v_combination  
        FROM GL_JE_HEADERS            gjh
           , GL_JE_LINES              gjl
           , GL_CODE_COMBINATIONS_KFV gcck
       WHERE 1=1
         AND gjh.je_source           = 'Acopio Fletes'
         AND gjh.je_header_id        = gjl.je_header_id
         AND gjl.reference_1         = TO_CHAR(p_registro.carta_porte_id)
         AND gjl.code_combination_id = gcck.code_combination_id
         AND gjh.je_header_id        = (SELECT MAX(gjh.je_header_id)
                                          FROM GL_JE_HEADERS            gjh  
                                             , GL_JE_LINES              gjl     
                                             , GL_CODE_COMBINATIONS_KFV gcc 
                                         WHERE 1=1
                                           AND gjh.je_source           = 'Acopio Fletes'
                                           AND gjh.je_header_id        = gjl.je_header_id
                                           AND gjl.reference_1         = TO_CHAR(p_registro.carta_porte_id)
                                           AND gjl.code_combination_id = gcc.code_combination_id
                                           AND gcc.segment2            = gcck.segment2
                                           AND gcc.segment2            = (SELECT cck.segment2
                                                                            FROM XX_TCG_PARAMETROS_COMPANIA  xcp
                                                                               , GL_CODE_COMBINATIONS_KFV    cck
                                                                           WHERE xcp.operating_unit       = p_registro.operating_unit
                                                                             AND xcp.provision_account_id = cck.code_combination_id ));
                                                                               
    END IF;
    /* CR2528 */
    
    -- Inserto registro en la tabla de interfaz
    IF (p_reversar_flag = 'N') THEN
      v_asiento_tipo := 'C';
    ELSE
      v_asiento_tipo := 'D';
    END IF;

    IF NOT insertar_registro (p_set_of_books_id     => p_set_of_books_id
                             ,p_registro            => p_registro
                             ,p_code_combination_id => v_combination
                             ,p_asiento_tipo        => v_asiento_tipo
                             ,p_group_id            => p_group_id
                             ,p_cp_descripcion      => v_descripcion
                             ,x_errmsg              => v_errmsg
                             ) THEN

      x_status := 'E';
      RAISE e_gen_asiento;
      
    END IF;

    x_status := 'G';
    RETURN(TRUE);

  EXCEPTION
    WHEN e_gen_asiento THEN
      -- debug_line(v_errmsg);
      x_errmsg := 'No se pudo generar el asiento. ' || v_errmsg;
      RETURN(FALSE);
  END;

 /*-----------------------------------------------------------------------
 | E N D P R I V A T E P R O C E D U R E S |
 -----------------------------------------------------------------------*/
 -------------------------------------------------------------------------
 /*-----------------------------------------------------------------------
 | P U B L I C P R O C E D U R E S |
 -----------------------------------------------------------------------*/

 /*------------------------------------------------------------------------
 | Function: Principal |
 | Purpose: Procedimiento principal del paquete |
 | Parameters: errbuf OUT VARCHAR2 |
 | retcode OUT VARCHAR2
 | p_draft_mode IN VARCHAR2 |
 | p_debug_flag IN VARCHAR2 |
 | p_submit_flag IN VARCHAR2 |
 ------------------------------------------------------------------------*/
  PROCEDURE principal (errbuf       OUT VARCHAR2
                      ,retcode      OUT VARCHAR2
                      ,p_uni_oper    IN VARCHAR2 -- Cambiado por R12
                      ,p_draft_mode  IN VARCHAR2
                      ,p_debug_flag  IN VARCHAR2
                      ,p_submit_flag IN VARCHAR2) 
  IS


    v_errmsg          VARCHAR2(2000);
    v_EXCEPTION_ppal  EXCEPTION;
    v_EXCEPTION_ccte  EXCEPTION;

    v_group_id        NUMBER;
    v_request_id      NUMBER;
    v_org_id          NUMBER;
    v_registros       NUMBER:=0;
    v_cant_exito      NUMBER:=0;
    v_flag_proceso    VARCHAR2(50) := 'Generacion de asientos';

    v_reg_cp          XX_TCG_CARTAS_PORTE_ALL%rowtype;

    -- Agregado CR1181
    v_submit_flag     VARCHAR2(1);
    x_status          VARCHAR2(1);
    --

    --Agregado CR823
    v_draft_mode      VARCHAR2(1);
    v_cant_req        NUMBER:= NULL;
    v_sec_req         NUMBER;
    v_estado          VARCHAR2(50);
    e_no_unioper      EXCEPTION;
    e_End_Conc        EXCEPTION;
    v_cnc_cancelado   BOOLEAN:= FALSE;

    --CR2301
    l_result          BOOLEAN;
    l_sql_stmt        VARCHAR2(2000);
    --l_error_msg     VARCHAR2(2000);
    l_request_id      NUMBER;

    v_flag            VARCHAR2(1);
    e_error_reversion EXCEPTION;


    FUNCTION GET_REQ_STATUS (p_request_id  IN NUMBER
                            ,p_type        IN VARCHAR2 DEFAULT 'PH'
                            ,p_application IN VARCHAR2 DEFAULT NULL
                            ,p_program     IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2 
    IS
    
      v_cnc        BOOLEAN;
      v_phase      VARCHAR2(100);
      v_status     VARCHAR2(100);
      v_dev_phase  VARCHAR2(50);
      v_dev_status VARCHAR2(50);
      v_message    VARCHAR2(300);
      v_request_id NUMBER;
    
    BEGIN
      
      v_request_id := p_request_id;

      v_cnc := FND_CONCURRENT.GET_REQUEST_STATUS(v_request_id,
                                                 p_application,
                                                 p_program,
                                                 v_phase,
                                                 v_status,
                                                 v_dev_phase,
                                                 v_dev_status,
                                                 v_message);
      IF (NOT v_cnc) THEN
        XX_MSG_PK.msg('No se puede verificar el status del concurrente paralelo '||p_request_id);
        RETURN NULL;
      END IF;

      IF p_type = 'PH' THEN
        RETURN v_dev_phase;
      ELSE
        RETURN v_dev_status;
      END IF;

    EXCEPTION
      WHEN others THEN
        XX_MSG_PK.msg(p_message => 'Error al verificar el status del concurrente paralelo '||p_request_id||' - Detalle: '||SQLERRM ,
                                 p_message_length => 1000 );
        RETURN NULL;
    END get_req_status;
    -- fin CR823

  BEGIN
    
    g_debug_flag := p_debug_flag;
    debug_line('+ XX_TCG_PROVISION_FLETE Inicio del concurrente');

    -- Fuerzo al concurrente a devolver los mensajes en la pantalla de OUTPUT
    XX_MSG_PK.force_on(p_output    => 'CONC_OUT'
                      ,p_directory => NULL
                      ,p_file      => NULL
                      ,p_other_statement => NULL
                      ,p_message_length  => 4000
                      );

    -- Fuerzo al concurrente a devolver los mensajes en la pantalla de OUTPUT
    XX_DEBUG_PK.force_on(p_output    => 'CONC_LOG'
                        ,p_level     => 1
                        ,p_directory => NULL
                        ,p_file      => NULL
                        ,p_other_statement => NULL
                        ,p_message_length  => 4000
                        );


    XX_MSG_PK.msg(LPAD('=', 80, '='));
    XX_MSG_PK.msg('P R O V I S I O N D E F L E T E S');
    XX_MSG_PK.msg(LPAD('=', 80, '='));

    -- Se agrega la siguiente validacion para evitar que se importe en GL dos lineas
    -- identicas a causa de dos concurrentes que se lanzan proximos en el tiempo
    -- y uno de ellos es cancelado
    v_draft_mode  := p_draft_mode;
    v_submit_flag := p_submit_flag;
    v_cant_req    := 0;

    FOR r_reqs IN (SELECT request_id
                     FROM fnd_conc_req_summary_v
                    WHERE program_short_name = 'XXTCGPVF'
                      AND request_id < FND_GLOBAL.conc_request_id
                    ORDER BY actual_start_date NULLS FIRST) LOOP


      v_estado:= get_req_status(r_reqs.request_id,'PH');

      IF v_estado NOT IN ('COMPLETE','INACTIVE') THEN
        v_cant_req:= v_cant_req + 1;
        v_sec_req := r_reqs.request_id;
      END IF;

    END LOOP;

    IF v_cant_req > 0 THEN
      v_errmsg:= 'Existe otro concurrente XX TCG Provision Flete en curso por lo que se cancela este programa (request_id vigente: '||v_sec_req||')';
      RAISE e_End_Conc;
    END IF;

    v_org_id := NULL;

    ------------------------------
    -- Proceso de provisión
    ------------------------------
    FOR r_uni_oper IN (SELECT * 
                         FROM XX_TCG_PARAMETROS_COMPANIA
                        WHERE operating_unit = NVL(p_uni_oper,operating_unit)) LOOP
      
      debug_line('---> Empieza tratamiento unidad operativa '|| r_uni_oper.operating_unit);

      XX_MSG_PK.msg(LPAD('-', 80, '-'));
      XX_MSG_PK.msg('UNIDAD OPERATIVA : '|| r_uni_oper.operating_unit);
      XX_MSG_PK.msg(LPAD('-', 80, '-'));

      g_provision_account_id      := r_uni_oper.provision_account_id;
      g_flete_por_vta_account_id  := r_uni_oper.flete_por_vta_account_id;
      g_flete_por_cpra_account_id := r_uni_oper.flete_por_cpra_account_id;

      BEGIN
        
        IF NOT DATOS_SEGMENTOS(r_uni_oper.operating_unit, v_errmsg) THEN
          
          v_errmsg:= 'Error al procesar juego libros, numeros de segmento y estructura de combinación contable -' || v_errmsg;
          RAISE e_no_unioper;
          
        END IF;
        
        v_registros  := 0;
        v_cant_exito := 0;
        -- Genero group_id unico para estos registros de la unidad operativa
        v_group_id   := TO_NUMBER(LPAD(MOD(r_uni_oper.operating_unit,1000),3,'0') || TO_CHAR(SYSDATE,'yymmddhh24miss'));
        debug_line('---> group_id calculado ' || v_group_id);

        FOR r_cartas_porte IN (SELECT xtcp.*
                                 FROM XX_TCG_CARTAS_PORTE_ALL    xtcp
                                    , XX_TCG_PARAMETROS_COMPANIA xpar
                                WHERE xpar.operating_unit                     = r_uni_oper.operating_unit
                                  AND xpar.operating_unit                     = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit(XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (xtcp.provisionado_por))
                                  AND NVL(xtcp.provisionar_flete_flag, 'N')   = 'Y'
                                  AND NVL(xtcp.provisionado_flag, 'N')        = 'N'
                                  AND xtcp.anulado_flag                       = 'N'
                                  AND xtcp.recibido_flag                      = 'Y'
                                  AND provisionado_por                        IS NOT NULL
                                UNION ALL
                               SELECT xtcp.*
                                 FROM XX_TCG_CARTAS_PORTE_ALL    xtcp
                                    , XX_TCG_PARAMETROS_COMPANIA xpar
                                WHERE xpar.operating_unit                     = r_uni_oper.operating_unit
                                  AND xpar.operating_unit                     = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit(XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (xtcp.provisionado_por))
                                  AND NVL(xtcp.provisionar_flete_flag, 'N')   = 'Y'
                                  AND NVL(xtcp.provisionado_flag, 'N')        = 'N'
                                  AND xtcp.anulado_flag                       = 'N'
                                  AND xtcp.recibido_flag                      = 'N'
                                  AND xtcp.transferido_flag                   = 'Y'
                                  AND (NVL(xtcp.intermediario_retiro,'N')     = 'Y'
                                       OR NVL(xtcp.rtte_comercial_retiro,'N') = 'Y' )
                                  AND xtcp.provisionado_por                   IS NOT NULL) 
        LOOP
              
          BEGIN
              
            debug_line('---> Empieza tratamiento PROVISION carta de porte '|| r_cartas_porte.numero_carta_porte);
            SAVEPOINT sp_carta_porte_ppal;
            v_reg_cp    := r_cartas_porte;
            v_registros := v_registros + 1;

            -- Verifico que la carta de porte tenga un valor en el costo de flete
            IF r_cartas_porte.costo_flete IS NULL THEN
              
              v_errmsg := 'La carta de porte no tiene especificado un valor de costo de flete. Verifique los datos de la carta de porte';
              RAISE v_EXCEPTION_ppal;
              
            END IF;

            v_estado:= get_req_status(FND_GLOBAL.conc_request_id,'S');
              
            IF v_estado IN ('TERMINATING','CANCELLED', 'TERMINATED') THEN
              
              v_cnc_cancelado:= TRUE;
              v_draft_mode:= 'Y';
              EXIT;
              
            END IF;
            --

            -- Genero el asiento en la tabla de interfaz
            IF generar_asiento (p_registro        => v_reg_cp
                               ,p_set_of_books_id => g_set_of_books_id
                               ,p_group_id        => v_group_id
                               ,x_errmsg          => v_errmsg
                               ,x_status          => x_status
                               ) THEN
              
              BEGIN
                
                -- Actualizo la tabla de cartas de porte.
                UPDATE XX_TCG_CARTAS_PORTE_ALL
                   SET provisionado_flag    = 'Y'
                     , provision_request_id = FND_GLOBAL.conc_request_id
                     , last_updated_by      = FND_GLOBAL.user_id
                     , last_update_login    = FND_GLOBAL.login_id
                     , last_update_date     = SYSDATE
                 WHERE carta_porte_id = r_cartas_porte.carta_porte_id;
                
                debug_line('update  tabla provisionado_flag = Y ' || r_cartas_porte.carta_porte_id );

                XX_MSG_PK.msg('Generado correctamente el asiento para la carta de porte: '||r_cartas_porte.numero_carta_porte);
                v_cant_exito := v_cant_exito + 1;
                
              EXCEPTION
                WHEN OTHERS THEN
                  v_errmsg := 'No se pudo actualizar la carta de porte = '||r_cartas_porte.numero_carta_porte || '. Detalle: '|| SQLERRM;
                  RAISE v_EXCEPTION_ppal;
              END;
              
            ELSE
              
              IF (x_status = 'W') THEN
                
                debug_line(v_errmsg);
                XX_MSG_PK.msg(p_message => 'W-No se puede procesar la carta de porte '|| r_cartas_porte.numero_carta_porte||'. '||v_errmsg 
                             ,p_message_length => 1000 );
                retcode := 2;
                
              ELSE
                
                RAISE v_EXCEPTION_ppal;
                
              END IF;

            END IF;

          EXCEPTION
            WHEN v_EXCEPTION_ppal THEN
              debug_line('- BOLINF.xx_TCG_provision_flete_pk '||v_errmsg);
              XX_MSG_PK.msg(p_message => 'No se puede procesar la carta de porte '|| r_cartas_porte.numero_carta_porte||'. '||v_errmsg 
                           ,p_message_length => 1000 );
              retcode := 1;
              ROLLBACK TO sp_carta_porte_ppal;
            
            WHEN OTHERS THEN
              debug_line('- BOLINF.xx_TCG_provision_flete_pk wo:'||SQLERRM);
              XX_MSG_PK.msg(p_message => 'No se puede procesar la carta de porte '|| r_cartas_porte.numero_carta_porte||'. Error inesperado: '||SQLERRM
                           ,p_message_length => 1000 );
              retcode := 1;
              ROLLBACK TO sp_carta_porte_ppal;
          END;
          --
        END LOOP; --r_cartas_porte
        
        debug_line('Fin cartas porte operating_units  . . .');
        v_estado:= get_req_status(FND_GLOBAL.conc_request_id,'S');

        IF v_estado IN ('TERMINATING','CANCELLED','TERMINATED') THEN
          v_cnc_cancelado:= TRUE;
          v_draft_mode:= 'Y';
        END IF;

        IF v_draft_mode = 'N' AND v_registros > 0 THEN  -- SI NO ESTOY EN EL MODO DRAFT, COMITEO LO QUE ANDUVO BIEN
          COMMIT;
        END IF;

        XX_MSG_PK.msg('Cantidad de registros disponibles para provisionar : '||v_registros);
        XX_MSG_PK.msg('Registros procesados exitosamente: '||v_cant_exito);
        XX_MSG_PK.msg('Registros no procesados : '||TO_CHAR(v_registros-v_cant_exito));
        XX_MSG_PK.msg(LPAD('-', 80, '-'));

        IF v_cnc_cancelado THEN
          XX_MSG_PK.msg('Concurrente cancelado, no se procesan registros. Proceso finalizado.');
        ELSIF v_registros = 0 THEN
          XX_MSG_PK.msg('No hay registros disponibles para procesar. Proceso finalizado.');
        ELSIF v_cant_exito = 0 THEN
          XX_MSG_PK.msg(p_message => 'No fue posible procesar ninguno de los '||v_registros||' disponibles. Proceso finalizado.' 
                       ,p_message_length => 1000 );
        ELSIF v_submit_flag = 'N' THEN
          XX_MSG_PK.msg(p_message => 'No se hara el llamado a los concurrentes de GL ya que el parametro Submit se encuentra en No. Proceso finalizado.'
                       ,p_message_length => 1000 );
        ELSIF v_draft_mode = 'Y' THEN
          XX_MSG_PK.msg(p_message => 'No se hara el llamado a los concurrentes de GL ya que el parametro Draft_Mode se encuentra en Si. Proceso finalizado.'
                       ,p_message_length => 1000 );
        ELSE
          -- Llamo al concurrente por cada juego de libros recuperado.
          XX_MSG_PK.msg(LPAD('-', 80, '-'));
          XX_MSG_PK.msg('InvocANDo a la ejecucion del concurrente GLLEZL . . .');
          XX_MSG_PK.msg(LPAD('-', 80, '-'));
          v_flag_proceso := 'Lanzamiento de concurrentes';
          -- Invocacion a la ejecucion del concurrente (set_of_books_tab(v_org_id))
          BEGIN
            
            XX_MSG_PK.msg( p_message => 'El ID unico de grupo generado es: '||v_group_id );
            
            IF NOT ejecutar_concurrente (p_set_of_books_id => g_set_of_books_id
                                        ,p_group_id        => v_group_id
                                        ,x_request_id      => v_request_id
                                        ,x_errmsg          => v_errmsg
                                        ) THEN
              RAISE v_EXCEPTION_ccte;
             
            ELSE
              
              COMMIT;
              XX_MSG_PK.msg('El concurrente fue lanzado correctamente para el juego de libros de '||g_sob_name);
              
            END IF;

          EXCEPTION
            WHEN v_EXCEPTION_ccte THEN
              debug_line('- xx_TCG_provision_flete '
                        ||'Error al lanzar el concurrente GLLEZL con el juego de libros de '
                        || g_sob_name
                        ||'. Por favor, ejecute la generacion de asientos manualmente'
                        ||'. Detalle: ' ||v_errmsg);
              XX_MSG_PK.msg(p_message => 'Error al lanzar el concurrente GLLEZL con el juego de libros de '
                           || g_sob_name
                           ||'. Por favor, ejecute la generacion de asientos manualmente'
                           ||'. Detalle: ' ||v_errmsg
                           ,p_message_length => 1000 );
              retcode := 1;
           
          END;

          
        END IF ;

        -- Proceso de Reversion
        XX_MSG_PK.msg(LPAD('-', 80, '-'));
        XX_MSG_PK.msg('Verificando Provisiones a Revertir');
        XX_MSG_PK.msg(LPAD('-', 80, '-'));

        v_registros  := 0;
        v_cant_exito := 0;
        debug_line('---> Empieza tratamiento Reversion');

        FOR r_cartas_revertir IN (SELECT xtcp.*
                                    FROM XX_TCG_CARTAS_PORTE_ALL    xtcp
                                       , XX_TCG_PARAMETROS_COMPANIA xpar
                                   WHERE xpar.operating_unit                    = r_uni_oper.operating_unit
                                     AND xpar.operating_unit                    = XX_TCG_FUNCTIONS_PKG.CUIT_Operating_Unit(XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (xtcp.provisionado_por))
                                     AND (NVL(xtcp.provisionar_flete_flag,'N')  = 'N'
                                          OR (xtcp.provisionar_flete_flag       = 'Y' 
                                             AND xtcp.anulado_flag              = 'Y')
                                         )
                                     AND xtcp.provisionado_flag                 = 'Y'
                                     AND xtcp.id_factura_ap                     IS NULL
                                     AND costo_flete                            IS NOT NULL) 
        LOOP  -- Verifico que la carta de porte tenga un valor en el costo de flete
          
          debug_line('---> Empieza tratamiento Reversion carta de porte '|| r_cartas_revertir.numero_carta_porte);
           
          BEGIN
            
            SAVEPOINT sp_revertir_provision_ppal;
            v_reg_cp := r_cartas_revertir;
            v_registros := v_registros + 1;

            v_estado := get_req_status(FND_GLOBAL.conc_request_id,'S');

            IF v_estado IN ('TERMINATING','CANCELLED', 'TERMINATED') THEN

              v_cnc_cancelado := TRUE;
              v_draft_mode    := 'Y';
              EXIT;
              
            END IF;
            
            SAVEPOINT revertir_provision_svp;
            
            BEGIN

              v_group_id := r_cartas_revertir.carta_porte_id ||TO_NUMBER(TO_CHAR(SYSDATE,'hh24miss')); -- Genero un group_id unico para estos registros a revertir
              
              -- Genero el asiento en la tabla de interfaz
              IF generar_asiento (p_reversar_flag   => 'Y'
                                 ,p_registro        => v_reg_cp
                                 ,p_set_of_books_id => g_set_of_books_id
                                 ,p_group_id        => v_group_id
                                 ,x_errmsg          => v_errmsg
                                 ,x_status          => x_status
                                  ) THEN
                
                BEGIN
                  
                  -- Actualizo la tabla de cartas de porte.
                  UPDATE XX_TCG_CARTAS_PORTE_ALL
                     SET provisionado_flag    = 'N'
                       , provision_request_id = FND_GLOBAL.conc_request_id
                       , last_updated_by      = FND_GLOBAL.user_id
                       , last_update_login    = FND_GLOBAL.login_id
                       , last_update_date     = SYSDATE
                   WHERE carta_porte_id = r_cartas_revertir.carta_porte_id;
                  
                  debug_line('update reversion tabla provisionado_flag = N ' || r_cartas_revertir.carta_porte_id );

                EXCEPTION
                  WHEN OTHERS THEN
                    v_errmsg := 'Se produjo un error al intentar actualizar la carta de porte cuANDo se estaba revirtiENDo el asiento de provision de fletes. '
                                ||'Detalle: '|| SQLERRM;
                    RAISE e_error_reversion;

                END;

                v_estado:= get_req_status(FND_GLOBAL.conc_request_id,'S');

                IF v_estado IN ('TERMINATING','CANCELLED', 'TERMINATED') THEN
                  
                  v_cnc_cancelado:= TRUE;
                  v_draft_mode:= 'Y';
                  EXIT;
                  
                END IF;
                
                IF v_cnc_cancelado THEN
                  XX_MSG_PK.msg('Concurrente cancelado, no se procesan registros. Proceso finalizado.');
                ELSIF v_submit_flag = 'N' THEN
                  XX_MSG_PK.msg(p_message => 'No se hara el llamado a los concurrentes de GL ya que el parametro Submit se encuentra en No. Proceso finalizado.'
                               ,p_message_length => 1000 );
                ELSIF v_draft_mode = 'Y' THEN
                  XX_MSG_PK.msg(p_message => 'No se hara el llamado a los concurrentes de GL ya que el parametro Draft_Mode se encuentra en Si. Proceso finalizado.'
                               ,p_message_length => 1000 );
                ELSE
                  -- Llamo al concurrente por cada juego de libros recuperado.
                  XX_MSG_PK.msg(LPAD('-', 80, '-'));
                  XX_MSG_PK.msg('Invocando a la ejecucion del concurrente GLLEZL . . .');
                  XX_MSG_PK.msg(LPAD('-', 80, '-'));
                  v_flag_proceso := 'Lanzamiento de concurrentes';
                  -- Invocacion a la ejecucion del concurrente (set_of_books_tab(v_org_id))
                  
                  IF NOT ejecutar_concurrente (p_set_of_books_id => G_set_of_books_id
                                              ,p_group_id        => v_group_id
                                              ,x_request_id      => v_request_id
                                              ,x_errmsg          => v_errmsg
                                              ) THEN
                    
                    v_errmsg := 'Se produjo un error al intentar generar el asiento de reversion de provision de fletes. Detalle: '|| v_errmsg;
                    RAISE e_error_reversion;
                    
                  END IF;
                  
                END IF;
                
              ELSE --generar_asiento (p_reversar_flag => 'Y'
                
                v_errmsg := 'Error al generar la reversion del asiento de provision de fletes. Detalle: ' || v_errmsg;
                RAISE e_error_reversion;
                
              END IF;

            EXCEPTION
              WHEN e_error_reversion THEN
                ROLLBACK TO revertir_provision_svp;
                --   v_errmsg := l_error_msg; Se eliminó no mostraba error
                RAISE v_EXCEPTION_ppal;
              
            END;
            --
           
             /* CR1399 XX TCG Cartas de Porte - Ajustes Provision -- Inicio (Provision -  Desprovisionar CP) */
            IF NVL(r_cartas_revertir.anulado_flag,'N') = 'N' THEN
              
              UPDATE XX_TCG_CARTAS_PORTE_ALL 
                 SET --  provisionado_por  = NULL
                     costo_flete_xton  = NULL
                   , costo_flete       = NULL
                   , last_updated_by   = FND_GLOBAL.user_id
                   , last_update_login = FND_GLOBAL.login_id
                   , last_update_date  = FND_DATE.canonical_to_date(FND_DATE.date_to_canonical(SYSDATE))
               WHERE carta_porte_id = r_cartas_revertir.carta_porte_id;
               
              debug_line('update reversion - desprovisiona  ' || r_cartas_revertir.carta_porte_id );

            END IF;
            
            /* CR1399 XX TCG Cartas de Porte - Ajustes Provision -- Inicio (Provision -  Desprovisionar CP) */
            XX_MSG_PK.msg(p_message => 'Generado correctamente el asiento de reversión para la carta de porte: '||r_cartas_revertir.numero_carta_porte
                         ,p_message_length => 1000 );
            
            v_cant_exito := v_cant_exito + 1;
            --
          EXCEPTION
            WHEN v_EXCEPTION_ppal THEN
              debug_line('- BOLINF.xx_tcg_provision_flete_pk '||v_errmsg);
              XX_MSG_PK.msg(p_message => 'No se puede procesar la carta de porte '|| r_cartas_revertir.numero_carta_porte||'. '||v_errmsg
                           ,p_message_length => 1000 );
              retcode := 1;
              ROLLBACK TO sp_revertir_provision_ppal;
            
            WHEN OTHERS THEN
              debug_line('- BOLINF.xx_tcg_provision_flete_pk wo:'||SQLERRM);
              XX_MSG_PK.msg(p_message => 'No se puede procesar la carta de porte '|| r_cartas_revertir.numero_carta_porte||'. Error inesperado: '||SQLERRM
                           ,p_message_length => 1000 );
              retcode := 1;
              ROLLBACK TO sp_revertir_provision_ppal;
          END;
          --
          
        END LOOP; --r_cartas_revertir

        v_estado:= get_req_status(FND_GLOBAL.conc_request_id,'S');

        IF v_estado IN ('TERMINATING','CANCELLED','TERMINATED') THEN
          
          v_cnc_cancelado := TRUE;
          v_draft_mode    := 'Y';
          
        END IF;
        --

        debug_line('Saliendo del LOOP principal . . .');
        -- SI NO ESTOY EN EL MODO DRAFT, COMITEO LO QUE ANDUVO BIEN
        IF v_draft_mode = 'N' AND v_registros > 0 THEN
          COMMIT;
        END IF;

        XX_MSG_PK.msg(LPAD('-', 80, '-'));
        XX_MSG_PK.msg('Cantidad de registros disponibles para revertir : '||v_registros);
        XX_MSG_PK.msg('Registros procesados exitosamente: '||v_cant_exito);
        XX_MSG_PK.msg('Registros no procesados : '||TO_CHAR(v_registros-v_cant_exito));
        XX_MSG_PK.msg(LPAD('-', 80, '-'));


        -- SI ESTOY EN MODO DRAFT, HAGO UN ROLLBACK GENERAL
        IF v_draft_mode = 'Y' THEN
          ROLLBACK;
        END IF;

      EXCEPTION 
        WHEN e_no_unioper THEN
          NULL;
      END;

    END LOOP; -- fin R_UNI_OPER

  --
  EXCEPTION
    WHEN e_End_Conc THEN
      debug_line(v_errmsg);
      XX_MSG_PK.msg(p_message => v_errmsg, p_message_length => 1000 );
      retcode := 1;
    --
    WHEN OTHERS THEN
      v_errmsg := 'Ocurrio un error inesperado en la funcion principal durante la etapa ' || v_flag_proceso
                ||' del concurrente XX_TCG_PROVISION_FLETE_PK. Detalle: '|| SQLERRM;
      debug_line(v_errmsg);
      XX_MSG_PK.msg(p_message => v_errmsg, p_message_length => 1000 );
      retcode := 2;
      ROLLBACK;
  END principal;

END XX_TCG_PROVISION_FLETE_PK;
/

exit
