CREATE OR REPLACE FORCE  VIEW "APPS"."XXW_CMP" ("TIPO_CBTE", "FECHA_CBTE", "PUNTO_VTA", "CBT_NRO", "ID_PERMISOS", "DST_MERC", "CLIENTE", "DOMICILIO_CLIENTE_ADDR1", "DOMICILIO_CLIENTE_ADDR2", "DOMICILIO_CLIENTE_ADDR3", "DOMICILIO_CLIENTE_ADDR4", "DOMICILIO_CLIENTE_CITY", "DOMICILIO_CLIENTE_PROVINCE", "DOMICILIO_CLIENTE_POSTAL_CODE", "DOMICILIO_CLIENTE_COUNTRY", "ID_IMPOSITIVO", "MONEDA_ID", "MONEDA_CTZ", "IMP_TOTAL", "IDIOMA_CBTE", "CUSTOMER_TRX_ID", "BILL_TO_SITE_USE_ID", "BILL_TO_CUSTOMER_ID", "PARTY_ID", "PARTY_SITE_ID", "ORG_ID", "FECHA_PAGO") AS
SELECT DECODE (rctt.TYPE,  'INV', 19,  'DM', 20,  'CM', 21) tipo_cbte,
--hcsu.cust_acct_site_id ,
TO_CHAR (rcta.trx_date, 'yyyymmdd') fecha_cbte,
SUBSTR (rcta.TRX_NUMBER, 3, 4) punto_vta,
SUBSTR (rcta.TRX_NUMBER, 8, 8) cbt_nro --,decode(p_profile,'Exportacion Definitiva de bienes',1,'Servicios',2,'Otros',4) tipo_expo
, /* 23-MAR-2011 MGalindez: rctad.xxw_embarque_cliente */
rctad.XX_AR_EMBARQUE id_permisos, /* 23-Mar_2011 MGalindez: flv.lookup_code */
flv.meaning dst_merc,
rc.customer_name cliente,
RTRIM (RPAD (hl.ADDRESS1, 40)) DOMICILIO_CLIENTE_ADDR1,
RTRIM (RPAD (hl.ADDRESS2, 40)) DOMICILIO_CLIENTE_ADDR2,
RTRIM (RPAD (hl.ADDRESS3, 40)) DOMICILIO_CLIENTE_ADDR3,
RTRIM (RPAD (hl.ADDRESS4, 40)) DOMICILIO_CLIENTE_ADDR4,
hl.CITY DOMICILIO_CLIENTE_CITY,
NVL (hl.STATE, hl.PROVINCE) DOMICILIO_CLIENTE_PROVINCE,
hl.POSTAL_CODE DOMICILIO_CLIENTE_POSTAL_CODE,
hl.COUNTRY DOMICILIO_CLIENTE_COUNTRY,
hp.TAX_REFERENCE ID_IMPOSITIVO, /* 23-Mar-2011 MGalindez: fcd.XXW_AFIP_CURR */
lv_curr.lookup_code MONEDA_ID,
XXW_EXPO_FE_PUB_PKG.EXCHANGE_RATE (rcta.customer_trx_id) MONEDA_CTZ --si es pesos tiene que ser 1
,
ABS (SUM (rctl.EXTENDED_AMOUNT)) IMP_TOTAL /* 23-ago-2011 MG: agregado ABS */
, /* 23-Mar-2011 MGalindez - hcasad.XXW_IDIOMA_FACTURA */
/*rctad.XX_AR_FC_ELECTRO_IDIOMA - CR1994 */ 1 Idioma_cbte,
rcta.CUSTOMER_TRX_ID,
rcta.BILL_TO_SITE_USE_ID,
rcta.BILL_TO_CUSTOMER_ID,
hp.PARTY_ID,
hps.PARTY_SITE_ID,
rcta.org_id
, to_char(arpt_sql_func_util.get_first_due_date(term_id,trx_date),'yyyymmdd') fecha_pago
FROM                            /*ra_addresses_all ra_bill,     R11i */
(SELECT acct_site.cust_acct_site_id address_id, loc.province, loc.country
FROM HZ_PARTY_SITES party_site,
--HZ_LOC_ASSIGNMENTS loc_assign,
HZ_LOCATIONS loc,
HZ_CUST_ACCT_SITES_ALL acct_site
WHERE     acct_site.party_site_id = party_site.party_site_id
AND loc.location_id = party_site.location_id
--AND loc.location_id = loc_assign.location_id
--AND NVL (acct_site.org_id, -99) =NVL (loc_assign.org_id, -99)
) ra_bill,
RA_CUSTOMER_TRX_ALL rcta,
--RA_BATCH_SOURCES rbs,                       r11i
RA_BATCH_SOURCES_ALL rbs,                                 /* r12*/
RA_BATCH_SOURCES_ALL_DFV rbsad,
ra_customer_trx_all_dfv rctad,
ra_customer_trx_lines_all rctl,
ra_cust_trx_types_all rctt,
hz_cust_SITE_USES_ALL hcsu,
hz_cust_accounts hca,
/*ra_customers rc,  R11i */
(SELECT hca.cust_account_id customer_id,
hp.party_name customer_name
FROM HZ_PARTIES hp, HZ_CUST_ACCOUNTS hca
WHERE hca.party_id = hp.party_id) rc,
hz_cust_acct_sites_ALL hcas,
hz_party_sites hps,
hz_locations hl,
hz_parties hp /* 23-Mar_2011 MGalindez - XXW_IDIOMA_FACTURA ,hz_cust_acct_sites_all_dfv hcasad */
/* 23-Mar-2011 MGalindez - XXW_AFIP_CURR - inicio */
--,fnd_currencies fc
--,fnd_currencies_dfv fcd
,
fnd_lookup_values lv_curr /* 23-Mar-2011 MGalindez - XXW_AFIP_CURR - fin */
,
fnd_lookup_values flv
WHERE     rcta.ROWID = rctad.row_id
AND rbs.batch_source_id = rcta.batch_source_id
AND rbsad.XXW_FAC_ELEC IN ('WSFE', 'WSFEX', 'WSFEV1')
AND rbs.ROWID = rbsad.row_id
/* 23-Mar-2011 MGalindez - XXW_AFIP_CURR - inicio */
--AND fc.currency_code=rcta.invoice_currency_code
--AND fc.rowid=fcd.row_id
--AND fcd.context='AFIP'
AND lv_curr.lookup_type = 'XX_AR_FC_ELECTRO_MONEDA'
AND lv_curr.meaning = rcta.invoice_currency_code
AND lv_curr.language = 'ESA'
/* 23-Mar-2011 MGalindez - XXW_AFIP_CURR - fin */
AND hcsu.site_use_code = 'BILL_TO'
AND hcsu.SITE_USE_ID = rcta.bill_TO_SITE_USE_ID
AND hca.CUST_account_ID = rcta.bill_TO_CUSTOMER_ID
AND rcta.bill_to_customer_id = rc.customer_id
AND hcsu.cust_acct_site_ID = hcas.cust_acct_site_ID
AND hcas.party_site_id = hps.party_site_id
AND hl.location_id = hps.location_id
/* 23-Mar-2011 MGalindez - XXW_FEX_PAIS - inicio */
--AND flv.lookup_type='XXW_FEX_PAIS'
--AND hl.country=flv.meaning
-- pais destino
AND ra_bill.address_id   = hcsu.cust_acct_site_id
AND flv.lookup_type = 'XX_AR_PAIS_FACTURA_ELECTRONICA'
AND flv.lookup_code = ra_bill.country /* ra_bill.province cambio TCA r12 */
AND flv.language = 'ESA'
/* 23-Mar-2011 MGalindez - XXW_FEX_PAIS - fin */
AND hca.party_id = hp.party_id
/* 23-Mar_2011 MGalindez - XXW_IDIOMA_FACTURA - inicio */
--AND hcasad.ROW_ID=hcas.ROWID
--AND hcasad.context_value='AFIP'
/* 23-Mar_2011 MGalindez - XXW_IDIOMA_FACTURA - fin */
AND rcta.customer_trx_id = rctl.customer_trx_id
AND rctl.line_type = 'LINE'
AND rcta.cust_trx_type_id = rctt.cust_trx_type_id
AND rcta.org_id = rctt.org_id
AND NOT EXISTS (SELECT 1 FROM xxw_fac_tmp xft
WHERE xft.cae IS NOT NULL
AND xft.id = rcta.customer_trx_id
)
GROUP BY rctt.TYPE,
--hcsu.cust_acct_site_id ,
rcta.trx_date,
rcta.TRX_NUMBER, /* 23-MAR-2011 MGalindez: rctad.xxw_embarque_cliente */
rctad.XX_AR_EMBARQUE,
rc.customer_name,
RTRIM (RPAD (hl.ADDRESS1, 40)),
RTRIM (RPAD (hl.ADDRESS2, 40)),
RTRIM (RPAD (hl.ADDRESS3, 40)),
RTRIM (RPAD (hl.ADDRESS4, 40)),
hl.CITY,
NVL (hl.STATE, hl.PROVINCE),
hl.POSTAL_CODE,
hl.COUNTRY,
hp.TAX_REFERENCE,
rcta.INVOICE_CURRENCY_CODE,
rcta.exchange_rate, /* 23-Mar_2011 MGalindez -  hcasad.XXW_IDIOMA_FACTURA */
rctad.XX_AR_FC_ELECTRO_IDIOMA,
rcta.CUSTOMER_TRX_ID,
rcta.BILL_TO_SITE_USE_ID,
rcta.BILL_TO_CUSTOMER_ID,
hp.PARTY_ID,
hps.PARTY_SITE_ID,
rcta.org_id,
flv.meaning,        /* 23-Mar-2011 MGalindez: fcd.XXW_AFIP_CURR */
lv_curr.lookup_code
, to_char(arpt_sql_func_util.get_first_due_date(term_id,trx_date),'yyyymmdd')

/
exit
