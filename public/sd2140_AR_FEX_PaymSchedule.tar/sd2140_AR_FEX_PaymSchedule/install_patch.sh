# | $Header: install_apps.sh 1.0  24/06/2020  M. Di Francesco             |
# *=======================================================================+
# |                2014 Ancap IT SRL, Buenos Aires, Argentina             |
# |                         All rights reserved.                          |
# +=======================================================================+
# | FILENAME                                                              |
# |     install_patch.sh - Driver de Instalacion                          |
# |                                                                       |
# | SOURCE CONTROL                                                        |
# |    Version: 1.0                                                       |
# |    Fecha  : 24/06/2020                                                |
# |    Descripcion: XXXX                                                  |
# |                                                                       |
# | HISTORY                                                               |
# |    24/06/2020       M. Di Francesco/Ancap IT   Version Inicial        |
# |                                                                       |
# |                                                                       |
# |                                                                       |
# +=======================================================================+

DIRECTORIO_PARCHE=`pwd`
ARCHIVO_LOG=$DIRECTORIO_PARCHE/install_patch.log
ARCHIVO_ERR=$DIRECTORIO_PARCHE/install_patch.err
sendLog()
{
  echo $1
  echo $1 >> $ARCHIVO_LOG
}

##################################################################################
# CHK_PASSWORD                                                                   #
# Descripcion: Funcion que comprueba que el usuario y la password sean correctos #
##################################################################################
chk_password()
{
sqlplus -s /nolog > /dev/null 2>&1 <<EOF
whenever sqlerror exit failure
connect $1/$2@$3
exit success
EOF

if [ $? -ne 0 ]; then
  echo Wrong Username or Password.
  exit 1
fi
}

sendLog '====================================' 
sendLog 'Shell install.sh ' 
sendLog '====================================' 

sendLog 'Please, enter the APPS USER: '
APPS_USER=APPS
sendLog 'Please, enter the APPS PASSWORD: '
read -s APPS 
sendLog 'Please, enter the DATABASE HOST: '
#HOST=ad-ar-crp1-db12.adeco.net.ar
read HOST
sendLog 'Please, enter the DATABASE PORT: '
#PORT=1521 
read PORT
sendLog 'Please, enter the DATABASE name: '
#BASE=DESA12 
read BASE
sendLog 'Conectandose con ' $APPS_USER 
sendLog 'Base ' $BASE 

chk_password $APPS_USER $APPS $BASE

sendLog '=============================================================================='
sendLog 'Registering and installing SQL objects' 
sendLog '=============================================================================='
sqlplus -s APPS/$APPS  @INSTALL/sql/XXW_CMP_VIEW.sql >> $ARCHIVO_LOG 2>> $ARCHIVO_ERR

sendLog '=============================================================================='
sendLog 'Registering and installing FILE objects' 
sendLog '=============================================================================='
cp INSTALL/custom/ua1001/fs_ne/ADECO/afipws/dist/sd2140.tar /ua1001/fs_ne/ADECO/afipws/dist
tar -xvf /ua1001/fs_ne/ADECO/afipws/dist/sd2140.tar -C /ua1001/fs_ne/ADECO/afipws/dist >> $ARCHIVO_LOG 2>> $ARCHIVO_ERR

sendLog '=============================================================================='
sendLog 'Registering and installing OAF objects' 
sendLog '=============================================================================='

sendLog '=============================================================================='
sendLog 'Registering and installing AOL objects' 
sendLog '=============================================================================='
