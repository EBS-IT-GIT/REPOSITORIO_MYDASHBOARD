@extends('adminlte::page')

@section('title','Administração')

@section('content_header')

    <h1><i class="fa fa-users" aria-hidden="true"></i>
Administração <small>Administração</small></h1>
  
@stop
@section('content')

<input type="hidden" value="" id="parent">
<div class="row">
<div class="col-md-12 col-xs-12">
<div class="modal fade bd-recalcular-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
          <h1 class="modal-title" id="exampleModalLabel">Escolha os filtros</h1>
        </div>
        <div class="modal-body col-md-12">

        <div class="col-md-3">
          <div class="form-group">
            <label>Tipo</label>
            <select id="tipo-modal" class="form-control input-sm filters">
              
            </select>
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
        <div class="col-md-3">
          <div class="form-group">
            <label>Prioridade</label>
            <select id="prioridade-modal" class="form-control input-sm">
              <option value="">Selecione a prioridade...</option>
                @foreach($prio as $p)
                  <option value="{{$p->id}}">{{$p->name}}</option>
                @endforeach
            </select>
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
        <div class="col-md-3">
          <div class="form-group">
            <label>Situação</label>
            <select id="situacao-modal" class="form-control input-sm">
            </select>
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
        <div class="col-md-3">
          <div class="form-group">
            <label>Abertura</label>
            <select id="data-modal" class="form-control input-sm">
              <option value="=">Igual a</option>
              <option value=">">Maior</option>
              <option value="<">Menor</option>
              <option value="><">Entre</option>
            </select>
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
        <div class="col-md-3">
          <div class="form-group">
          <label>Início</label>
            <input class= "form-control input-sm" type="date" value="" id="data-modal-inicio"/>
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
        <div hidden id = "modal-fim" class="col-md-3">
          <div class="form-group">
          <label>Fim</label>
            <input class= "form-control input-sm" type="date" value="" id="data-modal-fim"/>
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
      </div>
      <div class="modal-footer">
      <div class="col-md-12">
      <button type="button" id="btn-recalcular" class="btn btn-sm btn-warning"><i class="fa fa-calculator" aria-hidden="true"></i> Recalcular</button>
      </div>
      </div>
    </div>
  </div>
</div>
<div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
          <li class="active">
            <a href="#adm_1" data-toggle="tab">
            <i class="fa fa-handshake-o" aria-hidden="true" style="color:#00a65a"></i> Acordo de Nível de Serviço(SLA)</a>
          </li>
          <li>
            <a href="#adm_2" data-toggle="tab" id="aba-log">
            <i class="fa fa-tasks" style="color:#00a65a"></i> LOG de Atividades</a>
          </li>
          </ul>
        <div class="tab-content">
    <div class="tab-pane active" id="adm_1">
  <div class="box box-success" id="content-tarefa">
      <div class="box-header">
        <div class="box-tools pull-right">  
          <button type="button" id="btn-pesquisar" name="btn-pesquisar" class="btn btn-sm btn-success"><i class="fa fa-search"></i> pesquisar</button>

        </div>                   
      </div><!-- /.box-header -->
                            
    <div class="box-body">
      <!-- Filtro situação -->
      <div class="col-md-3">
          <div class="form-group">
            <label>Projeto</label>
            {!! $html !!}
           </div><!-- /.form-group -->
        </div><!-- /.col-md-3 -->
   </div> <!-- /.box-body -->

            <div class="box box-default box-body">
              <div class="col-md-6">
                <div id="message"></div>   
                <div id="aviso"></div>                         
              </div><!-- /.col-md-6 -->
              <div class="col-md-6">
                <div class="box-tools pull-right">
                  <div id="cadastro"></div>
                </div>
              </div><!-- /.col-md-6 -->
              
              <div class="col-md-12">
                <div class="form-group table-responsive">                                        
                <table id="table-calendario" class="table table-striped table-bordered table-hover display compact">
                    <thead style="font-weight:700;"> 
                    <tr>
                    <td>Calendario</td>
                    <td>Domingo</td>
                    <td>Segunda</td>
                    <td>Terça</td>
                    <td>Quarta</td>
                    <td>Quinta</td>
                    <td>Sexta</td>
                    <td>Sábado</td>
                    <td>Feriado</td>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                </div><!-- /.form-group -->
             </div>
           <div class="col-md-12">
              <div class="form-group table-responsive"> 
                                                     
                  <table id="table-sla" class="table table-striped table-bordered table-hover display compact">
                      <thead style="font-weight:700;"> 
                      <tr>
                      <td style="width:110px">Tipo</td>
                      @foreach($prio as $p)
                      <td style="width:110px">{{$p->name}}</td>
                      @endforeach
                      </tr>
                      </thead>
                      <tbody>
                      
                      </tbody>
                     </table>

              </div><!-- /.form-group -->
            </div><!-- /.col-md-5 -->
           
            </div>
                                
 </div><!-- /.box -->
 </div>
 <div class="tab-pane" id="adm_2">
 <div class="box box-success" id="content-log">
</div>
</div>
 
</div>
 </div>
  </div>
  </div>
      
                       
@stop
@section('js')
                        
<script>
$(document).on('change', '#data-modal', function(e){
  if($('#data-modal').val() == '><'){
    $('#modal-fim').show();
  }
  else{
    $('#modal-fim').hide();
  }
})
    
 $(document).on('click', '#aba-log', function(e){
      $('#content-log').html('<div class="box-body">Carregando dados...</div>');

      $.ajax({
        url : '{{ URL::to('/logs')}}',
        type: 'GET',
        success: function(data){
          $('#content-log').html(data);
        },
        error: function(xhr, textStatus, errorThrown){
          Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });    
        }
      });
    });
 $('#table-sla').DataTable({
                "dom": '<f<t>lip>',
                'language': {
                  url: '{{ asset('/')}}js/Portuguese-Brasil.json'
                },
                "searching": false,
                "paging": false,

  }).order([]).draw();

  $('#table-calendario').DataTable({
                "dom": '<f<t>lip>',
                'language': {
                  url: '{{ asset('/')}}js/Portuguese-Brasil.json'
  },
                "searching": false,
                "paging": false,
}).order([]).draw();
              //botão para recalcular

              $(document).on('click','#btn-recalcular', function(e){
                e.preventDefault();
                var project_id = $('#projetos-adm').val();
                var tipo = $('#tipo-modal').val();
                var prioridade = $('#prioridade-modal').val();
                var situacao = $('#situacao-modal').val();
                var data_modal = $('#data-modal').val();
                var data_inicio = $('#data-modal-inicio').val();
                var data_fim = $('#data-modal-fim').val();


                var data = '&tipo=' + tipo +  '&prioridade=' + prioridade + 
                 '&situacao=' + situacao +  '&data_inicio=' + data_inicio +  '&data_fim=' + data_fim;
                 if(!tipo && !situacao && !prioridade && !data_inicio){
                  Swal.fire({
                            title: 'Error!',
                            html: 'Selecione um filtro!',
                            icon: 'error',                       
                           });
                           return false;
                 }
              data += '&project_id=' + project_id + '&data=' + data_modal;
              $.ajax({
              url: '{{ URL::to('/encontrar_ids')}}',
              data: data,
              type: 'POST',
              success: function (data) {
                Swal.fire({
                title: data['count'] + ' chamados encontrados. Deseja continuar?',
                text: "Você não será capaz de reverter isso!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim'
              }).then((result) => {
                if (result.isConfirmed) {
                  $.ajax({
                        url : '{{ URL::to('/recalcular')}}',
                        type: 'POST',
                        data: {
                          'ids' : data['ids']
                        },
                        success: function(data){

                          Swal.fire({
                            title: 'Success!',
                            html: 'SLA recalculado!',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                              $('.modal').modal('hide');
                            }
                           })  
                        },
                        error: function(xhr, textStatus, errorThrown){
                          Swal.fire({
                                            title: 'Error!',
                                            html: xhr.responseJSON.message,
                                            icon: 'error',
                                            confirmButtonText: 'OK'
                                            });    
                        }
                      });
              }});  
              },
              error: function(xhr, textStatus, errorThrown){
                Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });    
              
            }
            });
         });
            function carregarSla()
            {
                $("#table-sla tbody").empty().html("<tr><td colspan=10 class=text-center> Carregando registros ...</td></tr>");
                $("#table-calendario tbody").empty().html("<tr><td colspan=10 class=text-center> Carregando registros ...</td></tr>");

                

                var filtro = $('#projetos-adm').val();
                if(!filtro){
                  Swal.fire({
                            title: 'Error!',
                            html: "Selecione um projeto!",
                            icon: 'error',
                            confirmButtonText: 'OK'
                          }).then((result) => {
                            if (result.isConfirmed) {
                              location.reload(true);
                            }
                           })   
                }
                $.ajax({
                    url : '{{ URL::to('/administrationlist')}}',
                    type: 'POST',
                    data: '&project_id='+filtro,
                    dataType: 'json',
                    success: function(data){
                        html_calendario = data['calendario'];
                        $('#message').html(data['message']);
                        $('#cadastro').html(data['cadastro']);
                        $('#parent').val(data['parent']);
                        $('#aviso').html(data['aviso']);
                        $('#tipo-modal').html(data['tipo']);
                        $('#situacao-modal').html(data['situacao']);


                        var html_sla = data['sla'];
                        $('#table-sla').DataTable().destroy();

                        $('#table-sla tbody').empty().html(html_sla);
                        $('#table-calendario').DataTable().destroy();

                        $('#table-calendario tbody').empty().append(html_calendario);
                        $('#table-sla').DataTable({
                          "dom": '<f<t>lip>',
                          'language': {
                            url: '{{ asset('/')}}js/Portuguese-Brasil.json'
                          },
                          "searching": false,
                          "paging": false,
                        }).order([]).draw();

                        $('#table-calendario').DataTable({
                          "dom": '<f<t>lip>',
                          'language': {
                           url: '{{ asset('/')}}js/Portuguese-Brasil.json'
                        },
                          "searching": false,
                          "paging": false,
                      }).order([]).draw();
                       

                    },
                    error: function(xhr, textStatus, errorThrown){
                        Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });   
                    }
                });
            }
            $(document).on('click','#btn-pesquisar', function(e){
                e.preventDefault();
                carregarSla()
            });
            $(document).on('click','#redirecionar', function(e){
              $('#projetos-adm').val($('#parent').val());
                carregarSla()
            });

          

</script>
@stop