<?php

namespace App\Http\Controllers;

use App\Cronometro;
use Redmine\Client as Client;
use Illuminate\Http\Request;
use App\Http\Controllers\HomeController;
use Carbon\Carbon;

class ReportsController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

      $conn = HomeController::connectApi();
      $activity = $conn->time_entry_activity->all();
      $activities = [];
      if(isset($activity['time_entry_activities']))
        $activities = $activity['time_entry_activities'];
      $contador = Cronometro::listarContadorEmAberto();

      return view('reports',
        [
          'usuarios'=> $this->listarUsuarios(),
          'projetos'=> $this->listarProjetos(),
          'situacao'=> $this->listarSituacao(),
          'contador'=> $contador,
          'activities'=> $activities,
        ]
      );
    }

    public function listarUsuarios()
    {
      $isAdmin = \Session::get('isAdmin');

      $sql = 'SELECT id, CONCAT_WS(" ",firstname, lastname) name FROM users';
      $sql .= ' WHERE type="User" AND status = 1';
      if($isAdmin!=9)
        $sql .= ' AND id = '.\Auth::user()->id;
      $sql .= ' ORDER BY name';
      $usuarios = \DB::connection('mysql_redmine')->select($sql);

      return $usuarios;
    }

    public function listarProjetos(){
      $isAdmin = \Session::get('isAdmin');

      $sql = 'SELECT id, name FROM projects where status = 1';
      $sql .= ' ORDER BY name';
      $projetos = \DB::connection('mysql_redmine')->select($sql);

      return $projetos;
    }

    public function listarSituacao()
    {

      $sql = 'SELECT id, name FROM issue_statuses';
      $sql .= ' ORDER BY name';
      $situacao = \DB::connection('mysql_redmine')->select($sql);

      return $situacao;
    }

    public function toJson(Request $request)
    {
      if($request){
        $conn = HomeController::connectApi();
        $inicio = '';
        $fim = '';
        $now = '';
        $dados = [];

        if($request->inicio && $request->termino){
          $inicio = $request->inicio;
          $fim = $request->termino;
        }
        else{
          $now = Carbon::now();
        }
        $times = $conn->time_entry->all([
          'user_id' => \Session::get('user')['id'],
          'project_id' => $request->projeto,
          'status_id' => $request->situacao,
          'from' => $request->inicio,
          'to' => $request->termino,
          'spent_on' =>  $now,
          'limit' => 100,
        ])['time_entries'];

        $projeto = '';
        $function = '';
        $mensagem = '';
        $intervalo = '';
        $retorno = '';
        foreach($times as $time){

        $projeto = explode('-',$time['project']['name']);
        $intervalo = $time['custom_fields'][1]['value'];
        $retorno = $time['custom_fields'][2]['value'];

        $function = 'CALL redmine.prc_verificar_apontamento("'.$time['custom_fields'][0]['value'].'","'.$intervalo.'","'.$retorno.'","'.$time['custom_fields'][3]['value'].'","'.$time['hours'].'")';

        $function = \DB::connection('mysql_redmine')->select($function);
        $mensagem = '';
        foreach($function as $f){
        if(isset($f->{""})){
          $mensagem = $f->{""};
        }
        else{
          $mensagem = $f->mensagem;
        }
        if (strpos($mensagem, 'válidas') == true) {
         $mensagem = '<span class="text-green">'.$mensagem.'</span>';
        }
        else{
          $mensagem = '<span class="text-red">'.$mensagem.'</span>';
        }
      }
        $task = $conn->issue->show($time['issue']['id'])['issue'];

          $dados[] = [
            'id_horas' => $time['id'],
            'id_chamado' => $time['issue']['id'],
            'chamado' => $task['subject'],
            'projeto' => $projeto[0],
            'data_apontamento_format' => date_format(date_create($time['spent_on']),'d/m/Y'),
            'data_apontamento' =>  $time['spent_on'],
            'hora_entrada' => date_format(date_create($time['custom_fields'][0]['value']),'H:i'),
            'hora_saida_almoco' => $time['custom_fields'][1]['value'],
            'hora_retorno_almoco' => $time['custom_fields'][2]['value'],
            'hora_saida' => date_format(date_create($time['custom_fields'][3]['value']),'H:i'),
            'horas' => $time['hours'],
            'situacao' => $task['status']['name'],
            'activity_id' => $time['activity']['id'],
            'atividades' => $time['custom_fields'][4]['value'],
            'tipo_hora' => $time['custom_fields'][5]['value'],
            'status_horas' => '<strong>'.$mensagem.'</strong>',
          ];
         

        }
      }
      return json_encode($dados);
    }

}
