<?php

namespace App\Http\Controllers;

use App\Log;
use App\Cronometro;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Testing\MimeType;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Redmine\Client as Client;
use function MongoDB\BSON\fromJSON;


class EmailController extends Controller
{


    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
//enviar email sla e feedback

   
     public function email(){
        $i = '';
        $user_ativo = 'select u.id usuario from users u
        inner join groups_users gu on u.id = gu.user_id
        inner join users g on gu.group_id = g.id and g.lastname like "%Fila%"
        where u.status = 1
        union
        select g.id from users g where g.lastname like "%Fila%" and g.status = 1
        ';
        $user_ativo = \DB::connection('mysql_redmine')->select($user_ativo);
        foreach($user_ativo as $user_ativos){
            $id = $user_ativos->usuario;

            $email = $this->email_body($id);
            $email_sla = $email['sla'];
            $email_feed = $email['feed'];

            if ($email_sla){
                
                $json = json_encode($email_sla); 
            }
            else{
                $json = json_encode($email_feed); 

            }
            $json = json_decode($json, true); 

            if($json){
            $json = $json[0];
           
             $user = (object)[
                'email_sla' => $email_sla,
                'email_feed' => $email_feed,
                'name' =>  $json['equipe_analista'],
                'email' =>   $json['email'],
                'cc' =>   'gestores@ebs-it.services',
                'bcc'=> 'camila.martins@ebs-it.services',
            ];
           
    //return new \App\Mail\emailLaravel((object) $user);
        \Illuminate\Support\Facades\Mail::send(new \App\Mail\emailLaravel((object) $user));
            }
    }

}
public static function email_body($id){
      
    $sql='SELECT status_name, email , equipe_analista, 
    dtnumber, cliente, cdchamado,dschamado 
   from(
   select datediff( str_to_date(dtnumber,"%d/%m/%Y %H:%i:%s"),now()) diferenca,chamados.*
   from (
   SELECT DATE_FORMAT(if(a.status_id = 1,if( isla.dt_vencimento_resposta is null, a.created_on, isla.dt_vencimento_resposta)
               ,if( isla.dt_vencimento_solucao is null, a.created_on, isla.dt_vencimento_solucao)),"%d/%m/%Y %H:%i:%s") dtnumber,
                     a.id cdchamado,
                     a.status_id status,
                     s.name status_name,
                   SUBSTRING(a.subject,1,300) dschamado,
                     LEFT(b.name,4) cliente,
                 IFNULL(CONCAT(u.firstname," ",u.lastname),"SEM EQUIPE") equipe_analista,
                 if(em.address is null,(select els.email from redmine_sla.emails_extras els where els.user_id = u.id), em.address) email
                 FROM redmine.issues a
             LEFT JOIN redmine_sla.expiration_sla isla ON isla.issue_id = a.id
                 INNER JOIN redmine.projects b ON a.project_id = b.id
                 INNER JOIN redmine.users u ON a.assigned_to_id = u.id
                 INNER JOIN issue_statuses s ON a.status_id = s.id
                 INNER JOIN redmine.custom_values cv ON cv.customized_id = b.id AND cv.customized_type = "Project" AND cv.custom_field_id = 14
                 LEFT JOIN email_addresses em on em.user_id = a.assigned_to_id
             WHERE a.status_id NOT IN (SELECT id FROM redmine_sla.aux_status WHERE is_sla = 0)
                 AND cv.value = "Suporte e Monitoramento" and u.id = '.$id.') chamados
   where datediff( str_to_date(dtnumber,"%d/%m/%Y %H:%i:%s"),now()) < 1
   order by 1 asc) sub ';

    $email_sla = \DB::connection('mysql_redmine')->select($sql);

    $sql = 'SELECT * from (
        SELECT if(em.address is null,(select els.email from redmine_sla.emails_extras els where els.user_id = u.id), em.address) email, LEFT(b.name,4) cliente_feed,IFNULL(CONCAT(u.firstname," ",u.lastname),"SEM EQUIPE") equipe_analista, i.assigned_to_id atribuido_para, i.id id, i.subject titulo, date_format(sub.dt_feedback,"%d/%m/%y %H:%i:%s") desde_de, sub.ultima_atualizacao, datediff(now(),sub.ultima_atualizacao) dias
        from issues i
        inner join 
            (select j2.journalized_id, j2.created_on dt_feedback , ua.ultima_atualizacao, jd2.old_value, jd2.value 
            from journals j2 
            inner join journal_details jd2 on jd2.journal_id = j2.id 
            inner join (select journalized_id issue_id, max(jd.id) jd_id from journals j 
                        inner join journal_details jd on jd.journal_id = j.id
                        where journalized_id in (select id from issues where status_id = 7 and project_id in (select p.id from projects p
                        inner join custom_values cv on cv.customized_id = p.id and customized_type = "Project" and value = "Suporte e Monitoramento")) and jd.prop_key = "status_id"
                        group by journalized_id) fd on fd.jd_id = jd2.id
            left join (select journalized_id issue_id, max(created_on) ultima_atualizacao
                        from journals j 
                        where journalized_id in (select id from issues where status_id = 7 and project_id in (select p.id from projects p
                        inner join custom_values cv on cv.customized_id = p.id and customized_type = "Project" and value = "Suporte e Monitoramento")) 
                        and  LENGTH(j.notes) > 0
                        group by journalized_id ) ua on ua.issue_id = j2.journalized_id) sub on i.id = sub.journalized_id
                        INNER JOIN redmine.projects b ON i.project_id = b.id
                        INNER JOIN redmine.users u ON i.assigned_to_id = u.id
                        LEFT JOIN email_addresses em on em.user_id = i.assigned_to_id
        ) sub2  where dias > 5 AND atribuido_para = '.$id.'';

    $email_feed = \DB::connection('mysql_redmine')->select($sql);

    $dados['sla'] = $email_sla;
    $dados['feed'] =  $email_feed;


    return $dados;
}

}

?>
