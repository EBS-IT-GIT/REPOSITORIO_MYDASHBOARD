@extends('adminlte::page')

@section('title','Editar SLA')

@section('content_header')

<h1><i class="fa fa-folder"></i> @foreach($project_name as $p){{$p->name}}@endforeach<small><i class="fa fa-pencil" aria-hidden="true"></i> Editar SLA</small></h1>

  
@stop
@section('content')
<div class="row">
    <div class="col-md-12 col-xs-12">


      <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
          <li class="active">
            <a href="#tabsla_1" data-toggle="tab">
            <i class="fa fa-calendar-o text-blue" aria-hidden="true"></i> Calendário</a>
          </li>
          <li>
            <a href="#tabsla_2" data-toggle="tab">
              <i class="fa fa-clock-o text-red"></i> Tempo de SLA</a>
          </li>
          </ul>
        <div class="tab-content">
          <div class="tab-pane active" id="tabsla_1">
          @if($herda !== 0 && $herda !== 2 )
          <div class="box box-primary">
          <div class="box-header">
          <h3 class="box-title">Editar Calendário</h3>
          </div>
          <div class="box-body">
          <div class="col-md-12">
                <div class="form-group table-responsive" id="lista-calendario">                                        
                <table class="table table-striped table-bordered table-hover display compact table-calendario-form">
                    <thead style="font-weight:700;"> 
                    <tr>
                    <td>Calendario</td>
                    <td>Domingo</td>
                    <td>Segunda</td>
                    <td>Terça</td>
                    <td>Quarta</td>
                    <td>Quinta</td>
                    <td>Sexta</td>
                    <td>Sábado</td>
                    <td>Feriado</td>
                    <td></td>
                    </tr>
                    </thead>
                    <tbody>
                    {!!$calendario!!}
                    </tbody>
                </table>
                </div><!-- /.form-group -->
             </div>
          </div>
          </div>
          @endif

                        <div class="box box-primary">
                            <div class="box-header">
                            <h3 class="box-title">Cadastrar Calendário</h3>
                            </div>
                            <div class="box-body">
                            <label><span class="text-red">*</span> Campos obrigatórios</label>
                            <form id= "form-calen" enctype="multipart/form-data">
                            <div class="col-md-12">
                                        <div class="form-group table-responsive" id="form-calendario">                                        
                                        <table class="table table-striped table-bordered table-hover display compact table-calendario-form">
                                            <thead style="font-weight:700;"> 
                                            <tr>
                                            <td>Calendário<span class="text-red">*</span></td>
                                            <td>Domingo<span class="text-red">*</span></td>
                                            <td>Segunda<span class="text-red">*</span></td>
                                            <td>Terça<span class="text-red">*</span></td>
                                            <td>Quarta<span class="text-red">*</span></td>
                                            <td>Quinta<span class="text-red">*</span></td>
                                            <td>Sexta<span class="text-red">*</span></td>
                                            <td>Sábado<span class="text-red">*</span></td>
                                            <td>Feriado<span class="text-red">*</span></td>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                            <td><input  class="form-control input-sm" type="text" placeholder = "Ex: dias uteis"required=required value= "" id="nome-form" /></td>
                                            <td><input type="text" required=required  class="form-control input-sm" placeholder = "00:00-00:00" value= "" id="dom-form" /></td>
                                            <td><input type="text" required=required class="form-control input-sm" placeholder = "00:00-00:00" value= ""  id="seg-form" /></td>
                                            <td><input type="text" required=required  class="form-control input-sm" placeholder = "00:00-00:00" value= "" id="ter-form" /></td>
                                            <td><input type="text" required=required class="form-control input-sm" placeholder = "00:00-00:00" value= "" id="quar-form" /></td>
                                            <td><input type="text" required=required class="form-control input-sm" placeholder = "00:00-00:00" value= "" id="quin-form" /></td>
                                            <td><input type="text" required=required class="form-control input-sm" placeholder = "00:00-00:00" value= "" id="sex-form" /></td>
                                            <td><input type="text" required=required class="form-control input-sm" placeholder = "00:00-00:00" value= "" id="sab-form" /></td>
                                            <td>nacional<input type="hidden" required=required value= "nacional" id="feriado-form" /></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>      
                                   
                                    <div class="col-md-12" style="text-align:center;">
                            <button type="button" class="btn btn-warning" id="btn_new_calendario"><span class="glyphicon glyphicon-send"></span> Criar Calendário</button>
                            </div>
                            </form>
                            </div> <!-- /.box-body -->
                            
                         </div><!-- /.box -->
            </div><!-- /tab-pane -->
            <div class="tab-pane" id="tabsla_2">
            <div class="row">
            @if($herda !== 0 && $herda !== 1)
            <div class="col-md-6">
            <div class="box box-danger">
            

            <div class="box-header">
            <h3 class="box-title">Editar SLA</h3>
            </div>
            <div class="box-body">

              <div class="form-group table-responsive">                                        
                  <table class="table table-striped table-bordered table-hover display compact table-sla-form">
                      <thead style="font-weight:700;"> 
                      <tr>
                      <td hidden></td>
                      <td>Tipo</td>
                      <td>Calendario</td>
                      <td>Prioridade</td>
                      <td>SLA de Resposta</td>
                      <td>SLA de Solução</td>
                      <td></td>
                      </tr>
                      </thead>
                      <tbody>
                      {!!$sla!!}
                      </tbody>
                     </table>

              </div><!-- /.form-group -->
            </div> 
            </div>
            </div>
            @endif
            @if($form_sla)
            <div class="col-md-6">
            <div class="box box-danger">

                            <div class="box-header">
                            <h3 class="box-title">Cadastrar SLA</h3>
                            </div>
                            <div class="box-body">
                            <label><span class="text-red">*</span> Campos obrigatórios</label>

                            <form id= "form-sla" enctype="multipart/form-data">
                                    <div class="form-group table-responsive">                                        
                                        <table class="table table-striped table-bordered table-hover display compact table-calendario-form">
                                            <thead style="font-weight:700;"> 
                                            <tr>
                                            <td>Tipo<span class="text-red">*</span></td>
                                            <td>Calendário<span class="text-red">*</span></td>
                                            <td>Prioridade<span class="text-red">*</span></td>
                                            <td>SLA de Resposta<span class="text-red">*</span></td>
                                            <td>SLA de Solução<span class="text-red">*</span></td>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {!!$form_sla!!}
                                            </tbody>
                                            </thead>
                                            </table>
                                    </div>
                            <div class="col-md-12" style="text-align:center;">
                            <button type="button" class="btn btn-warning" id="btn_new_sla"><span class="glyphicon glyphicon-send"></span> Criar SLA</button>
                            </div>
                            </form>
                            </div> <!-- /.box-body -->
                            </div>
                         </div><!-- /.box -->
                         @endif
            </div>
            </div>
        </div><!-- /tab-content -->
        </div><!--nav-tabs-->

    </div>
    <!-- c...12 -->
</div>
<!-- row -->
@stop
@section('js')

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
<link rel="stylesheet" href="{{asset('DataTables/datatables.css')}}" type="text/css">
<script type="text/javascript" src="{{ asset('DataTables/datatables.min.js') }}"></script>
<script>
 $('.table-sla-form').DataTable({'pageLength'  : 10,
                "dom": '<f<t>lip>',
                'language': {
                  url: '{{ asset('/')}}js/Portuguese-Brasil.json'
                },
                "searching": false,
                "paging": false,
  }).order([]).draw();

  $('.table-calendario-form').DataTable({
                "dom": '<f<t>lip>',
                'language': {
                  url: '{{ asset('/')}}js/Portuguese-Brasil.json'
  },
                "searching": false,
                "paging": false,
}).order([]).draw();


 $("#dom-form").mask("00:00-00:00");
 $("#seg-form").mask("00:00-00:00");
 $("#ter-form").mask("00:00-00:00");
 $("#quar-form").mask("00:00-00:00");
 $("#quin-form").mask("00:00-00:00");
 $("#sex-form").mask("00:00-00:00");
 $("#sab-form").mask("00:00-00:00");

 $(".mask").mask("00:00-00:00");

 
 $(document).on('click','#btn_new_calendario', function(e){

  var conti = 1;
  $('#form-calen').find('[required=required]').each(function(){
          if(!$(this).val()){
            Swal.fire({
                            title: 'Error!',
                            html: 'Campos obrigatórios não preenchidos!',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
            conti = 0;

          }
    });   

  if(conti == 1){
   var nome_calendario_util = $('#nome-form').val();
   var feriado_util = $('#feriado-form').val();
   var dom_util =  $('#dom-form').val();
   var seg_util =  $('#seg-form').val();
   var ter_util =  $('#ter-form').val();
   var quar_util =  $('#quar-form').val();
   var quin_util =  $('#quin-form').val();
   var sex_util =  $('#sex-form').val();
   var sab_util =  $('#sab-form').val();


   var project_id = {{$project_id}};

   var data = '&project_id=' + project_id + '&nome_calendario_util=' + nome_calendario_util + '&feriado_util=' + feriado_util +
               '&dom_util=' + dom_util +'&seg_util=' + seg_util +'&ter_util=' +ter_util + '&quar_util=' + quar_util +'&quin_util=' + quin_util + '&sex_util=' + sex_util +'&sab_util=' +sab_util;
    $.ajax({
              url: '{{ URL::to('/savecalendario')}}',
              data: data,
              type: 'POST',
              success: function (data) {
                if(data['result']){
                Swal.fire({
                            title: 'Error!',
                            html: data['result'],
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
              }
              else{
                Swal.fire({
                            title: 'Success!',
                            html: 'Calendário Criado Com Sucesso!',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                              location.reload(true);
                            }
                           }) 
              }
                },
              error: function(xhr, textStatus, errorThrown){
                Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });         
            }
            });
          }
});

$(document).on('click','#btn_new_sla', function(e){
  var conti = 1;
  $('#form-sla').find('[required=required]').each(function(){
          if(!$(this).val()){
            Swal.fire({
                            title: 'Error!',
                            html: 'Campos obrigatórios não preenchidos!',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
            conti = 0;

          }
    });   

  if(conti == 1){
  var data = '';
  for (var i = 0; i < {{$rowid}}; i++) {

   data +=  '&tipo[]' + '=' + $('#tipo-form'+i ).val() + '&calendario[]' + '=' + $('#tipo-calendario-form'+i ).val() +'&prioridade[]' + '=' + $('#prioridade-form'+i ).val() +'&p_sla[]' + '=' + $('#p-sla-form'+i ).val()  +'&tempo[]' + '=' + $('#p-tempo-form'+i ).val();
  }
  
  data += '&project_id=' + {{$project_id}} + '&rowid=' + i;
   if(data){
    $.ajax({
              url: '{{ URL::to('/savesla')}}',
              data: data,
              type: 'POST',
              success: function (data) {

                Swal.fire({
                            title: 'Success!',
                            html: 'SLA Criado Com Sucesso!',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                              location.reload(true);
                            }
                           }) 
                },
              error: function(xhr, textStatus, errorThrown){
                Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });         
            }
            });
  }
  else{
    Swal.fire({
                            title: 'Error!',
                            html: 'Dados Insuficientes',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
  }
  }

});

$(document).on('click','.btn-save-newscalendario', function(e){
              var timeid = $(this).data('timeid');
              var id_calendario = $('#id_calendario'+timeid).val();
              var dom = $('#dom'+timeid).val();
              var seg = $('#seg'+timeid).val();
              var ter = $('#ter'+timeid).val();
              var quar = $('#quar'+timeid).val();
              var quin = $('#quin'+timeid).val();
              var sex = $('#sex'+timeid).val();
              var sab = $('#sab'+timeid).val();
              var project_id =  {{$project_id}};
              var nome_calendario = $('#nome_calendario'+timeid).val();

              var data = 'projectid=' + project_id +  '&id_calendario=' + id_calendario + '&nome_calendario=' + nome_calendario +
               '&dom=' +dom +'&seg=' + seg +'&ter=' +ter + '&quar=' + quar +'&quin=' +quin + '&sex=' + sex +'&sab=' +sab;

              if(!nome_calendario || !dom || !seg || !ter || !quar || !quin || !sex || !sab){
                Swal.fire({
                            title: 'Error!',
                            html: 'Dados insuficientes!',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
              }
              else{
               $.ajax({
              url: '{{ URL::to('/editcalendario')}}',
              data: data,
              type: 'POST',
              success: function (data) {
              if(data['result']){
                Swal.fire({
                            title: 'Error!',
                            html: data['result'],
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
              }
              else if(data == 1){
                Swal.fire({
                            title: 'Success!',
                            html: 'Calendário Atualizado Corretamente!',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                              location.reload(true);
                            }
                           }) 
              }
              else{
                Swal.fire({
                            title: 'Error!',
                            html: 'Não foi possível Atualizar o Calendário',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 

              }   

              },
              error: function(xhr, textStatus, errorThrown){
                Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });    
              
            }
            });
          }
            });
            
            $(document).on('click','.btn-save-newsla', function(e){
              var timeid = $(this).data('timeid');
              var id_sla = $('#rowid'+timeid).val();
              var nome_calendario = $('#nome_calendario'+timeid).val();

              if(!nome_calendario && $('#nome_calendario_input'+timeid).val()) {
                nome_calendario = $('#id_calendario_sla'+timeid).val();
              }
              var p_sla = $('#p_sla'+timeid).val();
              var tempo = $('#tempo'+timeid).val();
              var project_id =  {{$project_id}};

              var data = 'projectid=' + project_id +  '&id_sla=' + id_sla + '&nome_calendario=' +nome_calendario +'&p_sla=' +p_sla +'&tempo=' +tempo;

              if(!nome_calendario || !p_sla || !tempo){
                Swal.fire({
                            title: 'Error!',
                            html: 'Dados insuficientes!',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 
              }
              else{
              $.ajax({
              url: '{{ URL::to('/editsla')}}',
              data: data,
              type: 'POST',
              success: function (data) {

              if(data == 1){
                Swal.fire({
                            title: 'Success!',
                            html: 'SLA Atualizado Corretamente!',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                              location.reload(true);
                            }
                           }) 
              }
              else{
                Swal.fire({
                            title: 'Error!',
                            html: 'Não foi possível Atualizar o SLA',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            }).then((result) => {
                            if (result.isConfirmed) {
                            }
                           }) 

              }   

              },
              error: function(xhr, textStatus, errorThrown){
                Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });    
              
            }
            });
          }
            });



            $(document).on('click','.nome_calendario_input', function(e){
              var timeid = $(this).data('timeid');

              $('#nome_calendario_input'+timeid).prop('type', 'hidden');
              $('#nome_calendario'+timeid).css("display", "");


            });
    

 </script>
 @stop