
            <div class="box-header">
              <div class="box-tools">
                <button type="button" id="btn-pesquisar-log" name="btn-pesquisar" class="btn btn-sm btn-success"><i class="fa fa-search"></i> pesquisar</button>
              </div>
            </div>
            <div class="box-body">

                <div class="col-md-2">
                  <div class="form-group">
                     <label>Período: Início</label>
                     <input type="date" id="datainicio" name="datainicio" class="form-control input-sm" value="" />
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                     <label>Término</label>
                     <input type="date" id="datatermino" name="datatermino" class="form-control input-sm" value="" />
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                     <label>Situação</label>
                     <select id="situacao" class="form-control input-sm">
                       <option value=""></option>
                       @foreach($situacao as $sit)
                       <option value="{{ $sit->id }}">{{ $sit->name }}</option>
                       @endforeach
                     </select>
                  </div>
                </div>


                <div class="col-md-6">
                    <div class="form-group">
                       <label>Analista <small><i class="fa fa-info-circle" aria-hidden="true"></i> Selecione múltiplos registros pressionando Ctrl</small></label>
                       <select multiple="multiple" id="analista" class="form-control input-sm">
                           <option value=""></option>
                           @foreach($usuarios as $usuario)
                           <option value="{{ $usuario->id }}">{{ $usuario->name }}</option>
                           @endforeach
                      </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                       <label>Projetos <small><i class="fa fa-info-circle" aria-hidden="true"></i> Selecione múltiplos registros pressionando Ctrl</small></label>
                       <select multiple="multiple" id="projeto" class="form-control input-sm">
                           <option value=""></option>
                           @foreach($projetos as $projeto)
                           <option value="{{ $projeto->id }}">{{ $projeto->name }}</option>
                           @endforeach
                      </select>
                    </div>
                </div>
    </div>
    <div class="box box-default">
      <!-- /.box-header -->
      <div class="box-body" >
      <div class="col-md-12">
        <div class="form-group table-responsive" id="lista-fatura"> 
        <table id="table-reports" class="table table-striped table-bordered table-hover display compact">
          <thead style="font-weight:700;">
          <tr>
            <td>Analista</td>
            <td>Projeto</td>
            <td>Atividade</td>
            <td>Data/Horas</td>
            <td>Ação</td>
            <td>Situação</td>
            <td>Prioridade</td>
          </tr>
          </tdead>
          <tbody>

          </tbody>
        </table>
      </div>
      <!-- /.box-body -->
      </div>
      </div>
  </div>
    <script>
      $(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#table-reports').DataTable();

        function carregarDados()
        {
          $("#table-reports tbody").empty().html("<tr><td colspan=10 class=text-center> Carregando registros ...</td></tr>");

          var situacao = $('#situacao').val();
          var usuario = $('#analista').val();
          var projeto = $('#projeto').val();
          var inicio = $('#datainicio').val();
          var termino = $('#datatermino').val();

          var filtro = '';
          if(situacao!='') filtro += '&situacao=' + situacao;
          if(usuario!='') filtro += '&usuario=' + usuario;
          if(projeto!='') filtro += '&projeto=' + projeto;
          if(inicio!='') filtro += '&inicio=' + inicio;
          if(termino!='') filtro += '&termino=' + termino;

          $.ajax({
            url : '{{ URL::to('/logs/json')}}',
            type: 'POST',
            data: filtro,
            dataType: 'json',
            success: function(data){
              var html;
              for(var i in data){
                var item = data[i];

                html += '<tr>' +
                    '<td>' + item.analista + '</td>'+
                    '<td>' + item.projeto + '</td>'+
                    '<td>' + '['+ item.id_chamado +'] ' + item.chamado + '</td>'+
                    '<td>' + item.datahora + '</td>'+
                    '<td>' + item.acao + '</td>'+
                    '<td>' + item.situacao + '</td>'+
                    '<td>' + item.prioridade + '</td>'+
                  '</tr>';
              }
              $('#table-reports').DataTable().destroy();
              $('#table-reports tbody').empty().append(html);
              $('#table-reports').DataTable({'pageLengtd'  : 50}).draw();
            },
          error: function(xhr, textStatus, errorThrown){
          Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });    
        }
          });
        }

        $('#table-reports').DataTable();

        $(document).on('click','#btn-pesquisar-log', function(e){
          e.preventDefault();

          carregarDados();
      });
    });
    </script>
