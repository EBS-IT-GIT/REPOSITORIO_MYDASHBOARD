<?php

namespace App\Http\Controllers;

use App\Http\Controllers\HomeController;
use App\Log;
use App\Cronometro;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Testing\MimeType;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\ReportsController;
use Redmine\Client as Client;
use function MongoDB\BSON\fromJSON;

class AdministrationController extends Controller
{
    public function administration(){
        $conn = HomeController::connectApi();
        $activities = [];
        if (isset($activity['time_entry_activities'])) $activities = $activity['time_entry_activities'];

        $contador = Cronometro::listarContadorEmAberto();

        $projects = 'SELECT p.name,p.id FROM redmine.projects p INNER JOIN redmine.custom_values cv on 
        cv.customized_id = p.id AND cv.custom_field_id = 14 and cv.customized_type = "Project" AND cv.value in("Suporte e Monitoramento","Projeto aberto - Com fila") AND  p.status = 1';
        $projects = \DB::connection('mysql_redmine')->select($projects);

        asort($projects);


        $priori = 'SELECT id, name FROM redmine.enumerations where type="IssuePriority" order by position asc';
        $priori = \DB::connection('mysql_redmine')->select($priori);

        $situacao = 'SELECT id,name FROM redmine.issue_statuses';
        $situacao = \DB::connection('mysql_redmine')->select($situacao);


        $html = '<select id="projetos-adm" class="form-control input-sm filters">
        <option value="">Selecione o projeto...</option>';
       
    
        //query

        $estrutura = 'SELECT gpj.id id_group, gpj.name name_group, pj.id id_project, pj.name name_project FROM projects pj 
        INNER JOIN redmine.custom_values cv on cv.customized_id = pj.id 
        left join (select id, name from projects where parent_id in(select distinct parent_id from projects where parent_id is not null)) gpj
        on gpj.id = pj.parent_id
        WHERE   cv.custom_field_id = 14 and cv.customized_type = "Project" AND cv.value in("Suporte e Monitoramento","Projeto aberto - Com fila") and pj.status = 1  AND pj.name not like "%*%" and pj.id not in(16,22) order by id_group,pj.name asc' ;
        $estrutura = \DB::connection('mysql_redmine')->select($estrutura);
        $project_pai = array_column($estrutura, 'id_group');
        

        $ver = '';    
        $result = array_unique($project_pai);

        foreach($estrutura as $e){
        if($ver != $e->id_group){

        
            $html .= '<option style="font-weight:bold;" value="'.$e->id_group.'">'.$e->name_group.'</option>';
            
            $ver = $e->id_group;

        }
        
            foreach($result as $r){
            if($e->id_group == $r){
                $html .= '<option value="'.$e->id_project.'">'.$e->name_project.'</option>';
            }
        }
        }
        $html.= '</select>';

        
        return view('administration',[
            'contador' => $contador,
            'activities' => $activities,
            'projects' => $projects,
            // 'tipo' => $tipo,
            'prio' => $priori,
            'situacao' => $situacao,
            'html' => $html,

        ]);
    }

    public function verificar_calendario($inicio, $fim, $dia){
        $result = '';
        if($inicio && $fim){
        if($inicio > $fim && $fim != '00:00'){
            $result = 'O início do calendário de <strong>'.$dia.'</strong> não pode ser maior que o fim!<br>';
        }
        else if($fim == '00:00' && $inicio != '00:00'){
            $result = 'O fim do calendário de <strong>'.$dia.'</strong> não pode ser <strong>00:00</strong>!<br>';
        }
        }
        else{
            $result = 'O início ou fim do calendário de <strong>'.$dia.'</strong> não pode ser nulo!<br>';
        }   
        return $result;
        
    }
    
    public function administrationlist(Request $request){
        if($request->project_id){
            $conn = HomeController::connectApi();
            $project_orig = $request->project_id;
            $parent = '';
            $cadastro = '';
            $html_calendario = '';
            $html_sla = '';
            $distinct = '';  
            $border = '';     
            $html_tipo = '<option value="">Selecione o tipo...</option>';
            $html_situacao = '<option value="">Selecione a situação...</option>';

            //filtro tipo por projeto
            $tipos = 'SELECT t.id, t.name from redmine.trackers t 
            INNER JOIN redmine.projects_trackers pt ON pt.tracker_id = t.id AND pt.project_id = '.$project_orig.'';
            $tipos = \DB::connection('mysql_redmine')->select($tipos);

            foreach($tipos as $t){
                $html_tipo .= '<option value="'.$t->id.'">'.$t->name.'</option>';     
            }

            $situacao = 'SELECT DISTINCT inew.id id, inew.name name
            FROM workflows w
            INNER JOIN issue_statuses inew ON inew.id = w.new_status_id
            INNER JOIN (
            SELECT distinct mr.role_id
            FROM members mb
            INNER JOIN member_roles mr ON mb.id = mr.member_id
            WHERE mb.project_id = '.$project_orig.' and mb.user_id in (select distinct id from users where lastname like "%Fila%")
            ) grp ON w.role_id = grp.role_id
            WHERE w.type = "WorkflowTransition" and w.tracker_id in (SELECT distinct t.id from redmine.trackers t
            INNER JOIN redmine.projects_trackers pt ON pt.tracker_id = t.id AND pt.project_id = '.$project_orig.')';

            $situacao = \DB::connection('mysql_redmine')->select($situacao);

            foreach($situacao as $s){
                $html_situacao .= '<option value="'.$s->id.'">'.$s->name.'</option>';     
            }


            $dados = $this->list($project_orig);
            $parent = $dados['parent'];
            $cadastro = '<a class="btn btn-sm btn-info" style="cursor:pointer" target="_blank" href="/newsla/'.$project_orig.'"><i class="fa fa-pencil"></i> Editar SLA</a>';
            
            foreach($dados['calendario'] as $c){
                
               $html_calendario .=  '<tr><td>' . $c->nome_calendario . '</td><td>'. $c->dom . '-' . $c->dom_f . '</td><td>' . $c->seg . '-' . $c->seg_f . '</td><td> '. $c->ter . '-' . $c->ter_f . '</td><td>' . $c->quar . '-' . $c->quar_f . '</td><td>' . $c->quin . '-' . $c->quin_f . '</td><td>' . $c->sex . '-' . $c->sex_f . '</td><td>' . $c->sab . '-' . $c->sab_f . '</td><td>' . $c->tipo_feriado . '</td></tr>';


            }     
            if($dados['registros']){     
              
            $html_sla .= '<tr>';
            $count = 0;
            foreach($dados['registros'] as $r){
                
                    if($distinct != $r->tipo){
                       if($count != 0) $html_sla.= '</tr><tr>';
                        
                       
                       $html_sla .=  '<td>' . $r->tipo . '<br>
                       <strong>Calendário: </strong><br>
                       <strong>SLA resposta: </strong><br>
                       <strong>SLA solução: </strong></td>';
                       $boder='';

                    }
                    $html_sla .= '<td><br>'.$r->nome_calendario.'<br>'. $r->p_sla. '<br>' . $r->tempo .'</td>';
                    $border='';
                $distinct = $r->tipo;
               $count++;
            }
            $html_sla.= '</tr>';
        }

            $dados['calendario'] = $html_calendario;
            $dados['message'] = $dados['message'];
            $dados['parent'] = $parent;
            $dados['sla'] = $html_sla;
            $dados['cadastro'] = '<button type="button" id="btn-modal-recalcular" data-toggle="modal" data-target=".bd-recalcular-modal-lg" class="btn btn-sm btn-warning"><i class="fa fa-calculator" aria-hidden="true"></i> Recalcular SLA</button>'. ' ' . $cadastro;
            $dados['aviso'] = $dados['aviso'];
            $dados['tipo'] = $html_tipo;
            $dados['situacao'] = $html_situacao;

            
            return json_encode($dados, JSON_UNESCAPED_UNICODE);

        }
    }

    public function list($project_id){
        $dados = [];
        $count = 1;

        $project_id_sla = $project_id;
        $project_id_calend = $project_id;
        $aviso = '';
        $sla_aviso = '';
        $tipos_aviso = '';
        $parent_id = '';
        $message = '';
        $herda = '';

         while($count == 1){

            $sql = 'SELECT IFNULL(c.nome_calendario,"<span class=text-red style=font-weight:bold;>Sem Nome</span>") nome_calendario, s.id_sla, s.id_project, s.id_tracker, s.id_calendario, s.id_priority, IFNULL(s.tempo, "<span class=text-red style=font-weight:bold;>Sem SLA solução</span>") tempo, IFNULL(s.p_sla, "<span class=text-red style=font-weight:bold;>Sem SLA resposta</span>") p_sla, IFNULL(t.name, "<span class=text-red style=font-weight:bold;>Sem tipo</span>") as tipo, IFNULL(e.name, "<span class=text-red style=font-weight:bold;>Sem prioridade</span>") as prioridade
            FROM redmine_sla.sla s 
            left JOIN  redmine_sla.calendars c ON c.id_calendario = s.id_calendario
            INNER join redmine.trackers t ON  s.id_tracker = t.id 
            INNER JOIN redmine.projects p on p.id = s.id_project
            INNER JOIN redmine.enumerations e ON s.id_priority = e.id AND s.id_project = '.$project_id_sla.' AND IF( p.name not like "%*%" or p.id != '.$project_id.',t.id IN(SELECT tracker_id FROM redmine.projects_trackers WHERE project_id = '.$project_id.'), e.type = "IssuePriority") ORDER BY s.id_tracker,e.position asc';
            

            $registros = \DB::connection('mysql_redmine')->select($sql);
            
            $sql = 'SELECT id_calendario, IFNULL(nome_calendario, "<span class=text-red style=font-weight:bold;>Sem Nome</span>") nome_calendario, IFNULL(TIME_FORMAT(dt_dom_inicio,"%H:%i"), "<span class=text-red style=font-weight:bold;>Sem Início</span>") dom,IFNULL(TIME_FORMAT(dt_dom_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") dom_f,
            IFNULL(TIME_FORMAT(dt_seg_inicio,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Início</span>") seg,
            IFNULL(TIME_FORMAT(dt_seg_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") seg_f, 
            IFNULL(TIME_FORMAT(dt_ter_inicio,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Início</span>") ter,
            IFNULL(TIME_FORMAT(dt_ter_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") ter_f, 
            IFNULL(TIME_FORMAT(dt_quar_inicio,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Início</span>") quar,
            IFNULL(TIME_FORMAT(dt_quar_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") quar_f,
            IFNULL(TIME_FORMAT(dt_quin_inicio,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Início</span>") quin,
            IFNULL(TIME_FORMAT(dt_quin_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") quin_f, 
            IFNULL(TIME_FORMAT(dt_sex_inicio,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Início</span>") sex,
            IFNULL(TIME_FORMAT(dt_sex_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") sex_f, 
            IFNULL(TIME_FORMAT(dt_sab_inicio,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Início</span>") sab,
            IFNULL(TIME_FORMAT(dt_sab_fim,"%H:%i"),"<span class=text-red style=font-weight:bold;>Sem Fim</span>") sab_f, 
            IFNULL(tipo_feriado, "<span class=text-red style=font-weight:bold;>Sem Feriado</span>") tipo_feriado FROM redmine_sla.calendars WHERE id_project = '.$project_id_calend.'';

            $calendario = \DB::connection('mysql_redmine')->select($sql);

            if($project_id == $project_id_sla && $project_id == $project_id_calend){


            if(!$registros || !$calendario){
                $parent_id = 'SELECT parent_id from redmine.projects where id = '.$project_id.'';
                $parent_id = \DB::connection('mysql_redmine')->select($parent_id);


                foreach($parent_id as $pai){
                    if(!$registros){
                        $project_id_sla = $pai->parent_id;  
                    }
                    if(!$calendario){
                        $project_id_calend = $pai->parent_id;
                        
                    }
                    $parent_id = $pai->parent_id;
                }          
            }
            else{
                $count = 2;
               
            }
            }
            else{
                    $count = 2;
            }  
            }
            if($parent_id){
                if($registros && $calendario && $parent_id == $project_id_sla && $parent_id == $project_id_calend){
                    $message = '<label class="text-red">Calendário e tempo de SLA herdados!</label> <a style="cursor:pointer;" id="redirecionar"href="#"><i class="fa fa-eye" aria-hidden="true"></i> Visualizar</a>';
                    $herda = 0;
                }  
                else if($registros && $parent_id == $project_id_sla){
                    $message = '<label class="text-red">Tempo de SLA herdado!</label> <a style="cursor:pointer;" id="redirecionar"href="#"><i class="fa fa-eye" aria-hidden="true"></i> Visualizar</a>';
                    $herda = 1;
                }
                else if($calendario && $parent_id == $project_id_calend){
                    $message = '<label class="text-red">Calendário de SLA herdado!</label> <a style="cursor:pointer;" id="redirecionar"href="#"><i class="fa fa-eye" aria-hidden="true"></i> Visualizar</a>';
                    $herda = 2;
                }

                }
                $sql = 'SELECT t.name tipo_name from redmine.projects pj
                inner join redmine.projects_trackers pjt on pjt.project_id = pj.id
                inner join redmine.trackers t on t.id = pjt.tracker_id where pj.id = '.$project_id_sla.' AND t.id NOT in (SELECT DISTINCT id_tracker from redmine_sla.sla where id_project = '.$project_id_sla.')'; 
                
                $tipos_aviso = \DB::connection('mysql_redmine')->select($sql);
    
                $count = count($tipos_aviso);
                $i = 1;
                if($tipos_aviso){
                    foreach($tipos_aviso as $tipo){
                        if($i == $count && $i > 1){
                            $aviso .= ' e ' . $tipo->tipo_name . '';  
                        }
                        elseif($i != 1){
                            $aviso .= ', ' . $tipo->tipo_name . '';  
                        }
                        else{
                            $aviso .=  'Cadastre SLA para o tipo '. $tipo->tipo_name . '';  
                        }
                        $i++;
                    }
                    $aviso = '<label class="text-red"> '. $aviso. '!</label>';     
                }
            
            $dados['calendario'] = $calendario;
            $dados['registros'] = $registros;
            $dados['project_id_sla'] = $project_id_sla;
            $dados['project_id_calend'] = $project_id_calend;
            $dados['aviso'] = $aviso;
            $dados['message'] = $message;
            $dados['parent'] = $parent_id;
            $dados['herda'] = $herda;

            return $dados;

    }

    public function editsla(Request $request){
        if($request){
            $id_sla = $request->id_sla;
            $id_calendario = $request->nome_calendario;
            $p_sla = $request->p_sla;
            $tempo = $request->tempo;
            $project_id = $request->projectid;

            if($id_calendario) $id_calendario = ',id_calendario = '.$id_calendario.'';
            if($p_sla) $p_sla = 'p_sla = '.$p_sla.'';
            if($tempo) $tempo = ',tempo = '.$tempo.'';

            $sql = '';

            if(($project_id && $id_sla) || ($p_sla || $tempo || $id_calendario)){
                
            $sql = 'UPDATE redmine_sla.sla set '.$p_sla.' '.$tempo.' '.$id_calendario. ' WHERE id_sla = '.$id_sla.' AND id_project = '.$project_id.'';

            $update = \DB::connection('mysql_redmine_sla')->update($sql);

            $log = new Log;
            $log->datahora = Carbon::now();
            $log->analista = \Session::get('user')['firstname'] . ' ' . \Session::get('user')['lastname'];
            $log->acao = 'Alteração no SLA';
            $log->json = json_encode($sql, JSON_UNESCAPED_UNICODE);
            $log->save();

                return 1;
            }
            else{
                return 0;
            }
        }
    }
    public function editcalendario(Request $request){
        if($request){
            $id_calendario = $request->id_calendario;
            $nome_calendario = $request->nome_calendario;
            $project_id = $request->projectid;
            $dom_inicio = '';
            $seg_inicio = '';
            $ter_inicio = '';
            $quar_inicio = '';
            $quin_inicio = '';
            $sex_inicio =  '';
            $sab_inicio =  '';
            $dom_fim = '';
            $seg_fim = '';
            $ter_fim = '';
            $quar_fim = '';
            $quin_fim = '';
            $sex_fim =  '';
            $sab_fim =  '';
            $piece = '';
            $a = '';
            $verificar = '';

            if($request->dom){
                $piece = explode("-", $request->dom);
                if($piece[0]){
                    
                    $dom_inicio = 'dt_dom_inicio= "'.$piece[0].'"';
                    $a = ',';
                    
                } 
                if($piece[1]) {
                    $dom_fim = ''.$a.'dt_dom_fim= "'.$piece[1].'"';
                }
                $verificar .= $this->verificar_calendario($piece[0], $piece[1],'Domingo');
               
            }  
            if($request->seg){
                $piece = explode("-", $request->seg);
                if($piece[0]) {
                    $seg_inicio = ''.$a.'dt_seg_inicio= "'.$piece[0].'"';
                    $a = ',';
                }
                if($piece[1]) $seg_fim = ''.$a.'dt_seg_fim= "'.$piece[1].'"';

                $verificar .= $this->verificar_calendario($piece[0], $piece[1],'Segunda');
            }
            if($request->ter){
                $piece = explode("-", $request->ter);
                if($piece[0]) {
                    $ter_inicio = ''.$a.'dt_ter_inicio= "'.$piece[0].'"';
                    $a = ',';
                }                
                if($piece[1]) $ter_fim = ''.$a.'dt_ter_fim= "'.$piece[1].'"';

                $verificar .= $this->verificar_calendario($piece[0], $piece[1],'Terça');
            }
            if($request->quar){
                $piece = explode("-", $request->quar);
                if($piece[0]) {
                    $quar_inicio = ''.$a.'dt_quar_inicio= "'.$piece[0].'"';
                    $a = ',';
                }
                if($piece[1]) $quar_fim = ''.$a.'dt_quar_fim= "'.$piece[1].'"';

                $verificar .= $this->verificar_calendario($piece[0], $piece[1],'Quarta');
            }
            if($request->quin){
                $piece = explode("-", $request->quin);
                if($piece[0]) {
                    $quin_inicio = ''.$a.'dt_quin_inicio= "'.$piece[0].'"';
                    $a = ',';
                }
                if($piece[1]) $quin_fim = ''.$a.'dt_quin_fim= "'.$piece[1].'"';

                $verificar .= $this->verificar_calendario($piece[0], $piece[1], 'Quinta');

            }
            if($request->sex){
                $piece = explode("-", $request->sex);
                if($piece[0]) {
                    $sex_inicio = ''.$a.'dt_sex_inicio= "'.$piece[0].'"';
                    $a = ',';
                }
                if($piece[1]) $sex_fim = ''.$a.'dt_sex_fim= "'.$piece[1].'"';

                $verificar .= $this->verificar_calendario($piece[0], $piece[1], 'Sexta');

            }
            if($request->sab){
                $piece = explode("-", $request->sab);
                if($piece[0]) {
                    $sab_inicio = ''.$a.'dt_sab_inicio= "'.$piece[0].'"';
                    $a = ',';
                }
                if($piece[1]) $sab_fim = ',dt_sab_fim= "'.$piece[1].'"';

                $verificar .= $this->verificar_calendario($piece[0], $piece[1], 'Sábado');
            }

            if($request->nome_calendario) $nome_calendario = 'nome_calendario = "'.$nome_calendario.'",';


            $sql = '';
            $dados[] = [];
            if($verificar != ''){
                $dados['result'] = $verificar;
                return $dados;
            } 

            if($project_id && $id_calendario){
                
            $sql = 'UPDATE redmine_sla.calendars set '.$nome_calendario. ' '.$dom_inicio.''.$dom_fim.''.$seg_inicio. ''.$seg_fim. ''.$ter_inicio. ''.$ter_fim. ''.$quar_inicio. ''.$quar_fim. ' '.$quin_inicio. ''.$quin_fim. ''.$sex_inicio. ''.$sex_fim. ''.$sab_inicio. ' '.$sab_fim. ' WHERE id_calendario = '.$id_calendario.'  AND id_project = '.$project_id.'';

            $update = \DB::connection('mysql_redmine_sla')->update($sql);

            $log = new Log;
            $log->datahora = Carbon::now();
            $log->analista = \Session::get('user')['firstname'] . ' ' . \Session::get('user')['lastname'];
            $log->acao = 'Alteração no Calendário';
            $log->json = json_encode($sql, JSON_UNESCAPED_UNICODE);
            $log->save();

                return 1;
            }
            else{
                return 0;
            }
        }
    }
    public function newsla($project_id){   
    
        if($project_id){
            $html_calendario = '';
            $html_sla = '';
            $form_sla = '';
            $dados = $this->list($project_id);
            $select = '<option value="">Selecione...</option>';
            $activities = [];
            if (isset($activity['time_entry_activities']))
            $activities = $activity['time_entry_activities'];
            $contador = Cronometro::listarContadorEmAberto();

           
            $project_name = 'select name from redmine.projects where id = '.$project_id.'';
            $project_name = \DB::connection('mysql_redmine')->select($project_name);
            //formulário
            $sql = 'SELECT t.id tipo_id, t.name tipo, e.id prioridade_id, e.name prioridade from projects p
            inner join projects_trackers pt on p.id = pt.project_id
            inner join trackers t on t.id = pt.tracker_id,
            (select * from enumerations where type = "IssuePriority" order by position asc) e
            where p.id = '.$project_id.' and t.id not in(SELECT id_tracker from redmine_sla.sla where id_project = '.$project_id.')order by tipo asc';

            $tipos = \DB::connection('mysql_redmine')->select($sql);
            $sql = 'SELECT id_calendario,nome_calendario from redmine_sla.calendars where id_project = '.$project_id.'';

            $calendario_form = \DB::connection('mysql_redmine')->select($sql);   

            $sql = 'SELECT * from redmine_sla.sla where id_project = '.$project_id.'';

            $verifica = \DB::connection('mysql_redmine')->select($sql);   

            $rowid=1;
            $border = '';

            foreach($dados['calendario'] as $c){
                
                
               $html_calendario .=  '<tr><td><input id="id_calendario'.$rowid.'" type="hidden" value="' . $c->id_calendario . '"/>';
               
               if(strpos($c->nome_calendario, 'Sem')) {
                $c->nome_calendario = '';
                $border = 'style="border-color:red;"';
                }
                else{
                    $select .= '
                    <option value="'.$c->id_calendario.'">'.$c->nome_calendario.'</option>';
                }
               $html_calendario .=  '<input '.$border.' id="nome_calendario'.$rowid.'" class="form-control input-sm" type="text" value="' . $c->nome_calendario . '"/></td>';
               $border = '';

               if(strpos($c->dom, 'Sem')) {
                $c->dom = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->dom_f, 'Sem')){
                    $c->dom_f = '';
                    $border = 'style="border-color:red;"';
                }
               $html_calendario .=  '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->dom . '-' . $c->dom_f . '" class="form-control input-sm mask" id="dom'.$rowid.'" value = "' . $c->dom . '-' . $c->dom_f . '"/></td>';
               $border = '';

               if(strpos($c->seg, 'Sem')) {
                $c->seg = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->seg_f, 'Sem')){
                    $c->seg_f = '';
                    $border = 'style="border-color:red;"';
                }

               $html_calendario .= '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->seg . '-' . $c->seg_f . '" class="form-control input-sm mask" id="seg'.$rowid.'" value = "' . $c->seg . '-' . $c->seg_f . '"/></td>';
               $border = '';

               if(strpos($c->ter, 'Sem')) {
                $c->ter = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->ter_f, 'Sem')){
                    $c->ter_f = '';
                    $border = 'style="border-color:red;"';
                }

               $html_calendario .=  '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->ter . '-' . $c->ter_f . '" class="form-control input-sm mask" id="ter'.$rowid.'" value = "' . $c->ter . '-' . $c->ter_f . '"/></td>';
               $border = '';

               if(strpos($c->quar, 'Sem')) {
                $c->quar = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->quar_f, 'Sem')){
                    $c->quar_f = '';
                    $border = 'style="border-color:red;"';
                }
                
               $html_calendario .=  '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->quar . '-' . $c->quar_f . '" class="form-control input-sm mask" id="quar'.$rowid.'" value = "' . $c->quar . '-' . $c->quar_f . '"/></td>';
               $border = '';

               if(strpos($c->quin, 'Sem')) {
                $c->quin = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->quin_f, 'Sem')){
                    $c->quin_f = '';
                    $border = 'style="border-color:red;"';
                }

               $html_calendario .= '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->quin . '-' . $c->quin_f . '" class="form-control input-sm mask" id="quin'.$rowid.'" value = "' . $c->quin . '-' . $c->quin_f . '"/></td>' ;
               $border = '';

               if(strpos($c->sex, 'Sem')) {
                $c->sex = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->sex_f, 'Sem')){
                    $c->sex_f = '';
                    $border = 'style="border-color:red;"';
                }

               $html_calendario .= '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->sex . '-' . $c->sex_f . '" class="form-control input-sm mask"  id="sex'.$rowid.'" value = "' . $c->sex . '-' . $c->sex_f . '"/></td>';
               $border = '';

               if(strpos($c->sab, 'Sem')) {
                $c->sab = '';
                $border = 'style="border-color:red;"';
                }
                elseif(strpos($c->sab_f, 'Sem')){
                    $c->sab_f = '';
                    $border = 'style="border-color:red;"';
                }

               $html_calendario .=  '<td ><input '.$border.' type="text" placeholder = "00:00-00:00" title="' . $c->sab . '-' . $c->sab_f . '" class="form-control input-sm mask" id="sab'.$rowid.'" value = "' . $c->sab . '-' . $c->sab_f . '"/></td><td>' . $c->tipo_feriado . '</td><td><button type="button" class="btn btn-primary btn-sm btn-save-newscalendario" data-timeid="'.$rowid.'"><i class="fa fa-floppy-o"></i></button> </td></tr>';
               $border = '';
    
                                                
                $rowid++;
            }
            
            foreach($dados['registros'] as $r){
                
                $html_sla .= '<tr>' .
                '<td hidden><input '.$border.' id="rowid'.$rowid.'" type="text" value="' . $r->id_sla . '"/></td>
                <td>' . $r->tipo . '</td>';
                
                if(strpos($r->nome_calendario, 'Sem')) {
                    $r->nome_calendario = '';
                    $border = 'style="border-color:red;"';
                }
                $html_sla .= '<td><input id="id_calendario_sla'.$rowid.'" type="hidden" value="' . $r->id_calendario . '"/><input '.$border.' type="text" data-timeid="'.$rowid.'" class="form-control input-sm nome_calendario_input" id="nome_calendario_input'.$rowid.'" value = "'.$r->nome_calendario.'" /><select class="form-control input-sm" style="display:none;"id="nome_calendario'.$rowid.'">'.$select. '</select></td>
                <td>' . $r->prioridade . '</td>';
                $border = '';


                if(strpos($r->p_sla, 'Sem')) {
                    $r->p_sla = '';
                    $border = 'style="border-color:red;"';
                }
                
                $html_sla .= '<td><input '.$border.' type="text" class="form-control input-sm" id="p_sla'.$rowid.'" value = "'. $r->p_sla .'" /></td>';
                $border = '';
                
                if(strpos($r->tempo, 'Sem')) {
                $r->tempo = '';
                $border = 'style="border-color:red;"';
                }
                $html_sla .= '<td><input '.$border.' type="text" class="form-control input-sm" id="tempo'.$rowid.'" value = "'. $r->tempo .'" /></td><td>';
                $border = '';

                $html_sla .= '<button type="button" class="btn btn-primary btn-sm btn-save-newsla" data-timeid="'.$rowid.'"><i class="fa fa-floppy-o"></i></button>';

                $html_sla .= '</td></tr>';
                $rowid++;
            }

            $rowid = 0;

            
            if($tipos){
            foreach($tipos as $t){
            $html = '<select required=required class="form-control input-sm" id="tipo-calendario-form'.$rowid.'"><option value="">Selecione...</option>';
            if($calendario_form){
            foreach($calendario_form as $form){
                if($form->nome_calendario != '')
                $html .= '<option value="'.$form->id_calendario.'">'.$form->nome_calendario.'</option>';
                
            }
            }
            $html .= '</select>';
            $form_sla .=  '<tr>
            <td>'.$t->tipo.'<input type="hidden" required=required class="form-control input-sm" value= "'.$t->tipo_id.'" id="tipo-form'.$rowid.'"/></td>
            <td>'.$html.'</td>
            <td>'.$t->prioridade.'<input type="hidden" required=required class="form-control input-sm" value= "'.$t->prioridade_id.'" id="prioridade-form'.$rowid.'"/></td>
            <td><input type="text" required=required class="form-control input-sm" value= "" id="p-sla-form'.$rowid.'"/></td>
            <td><input type="text" required=required class="form-control input-sm" value= "" id="p-tempo-form'.$rowid.'"/></td>
            </tr>';
            $rowid++;
            }
            }

            return view('newsla',[
                'project_id' => $project_id,
                'form_sla' => $form_sla,
                'contador' => $contador,
                'activities' => $activities,
                'project_name' => $project_name,
                'rowid' => $rowid,
                'sla' =>  $html_sla,
                'calendario' => $html_calendario,
                'herda' => $dados['herda'],

            ]);
        }
        

    }

    public function savesla(Request $request){
            $sla = '';
            if($request){
            for ($i = 0; $i < $request->rowid; $i++) {

            $sql = 'INSERT INTO redmine_sla.sla(id_project,id_tracker,id_calendario,id_priority,tempo,p_sla) values ('.$request->project_id.','.$request->tipo[$i].','.$request->calendario[$i].','.$request->prioridade[$i].','.$request->p_sla[$i].','.$request->tempo[$i].')';

            $sla = \DB::connection('mysql_redmine_sla')->insert($sql);
            }
            $log = new Log;
            $log->datahora = Carbon::now();
            $log->analista = \Session::get('user')['firstname'] . ' ' . \Session::get('user')['lastname'];
            $log->acao = 'Criação de Tempo de SLA';
            $log->json = json_encode($sql, JSON_UNESCAPED_UNICODE);
            $log->save();
        }
            return json_encode($sla);
        
        
    }

    public function savecalendario(Request $request){
        if($request){
            $verificar = '';
            $dados[] = [];
            $nome_calendario_util = $request->nome_calendario_util;
            $feriado_util = $request->feriado_util;
            $project_id = $request->project_id;
            $dom_util = explode('-',$request->dom_util);

            $verificar .= $this->verificar_calendario($dom_util[0], $dom_util[1],'Domingo');

            $seg_util = explode('-',$request->seg_util);

            $verificar .= $this->verificar_calendario($seg_util[0], $seg_util[1],'Segunda');

            $ter_util = explode('-',$request->ter_util);

            $verificar .= $this->verificar_calendario($ter_util[0], $ter_util[1],'Terça');

            $quar_util = explode('-',$request->quar_util);

            $verificar .= $this->verificar_calendario($quar_util[0], $quar_util[1],'Quarta');

            $quin_util = explode('-',$request->quin_util);

            $verificar .= $this->verificar_calendario($quin_util[0], $quin_util[1],'Quinta');

            $sex_util = explode('-',$request->sex_util);

            $verificar .= $this->verificar_calendario($sex_util[0], $sex_util[1],'Sexta');

            $sab_util = explode('-',$request->sab_util);

            $verificar .= $this->verificar_calendario($sab_util[0], $sab_util[1],'Sábado');

            if($verificar != '') {
                $dados['result'] = $verificar;
                return $dados;
            } 

            $dias_uteis = 'INSERT INTO redmine_sla.calendars(id_project,nome_calendario, dt_dom_inicio,dt_dom_fim, dt_seg_inicio, dt_seg_fim, dt_ter_inicio, dt_ter_fim, dt_quar_inicio, dt_quar_fim, dt_quin_inicio, dt_quin_fim, dt_sex_inicio, dt_sex_fim, dt_sab_inicio, dt_sab_fim, tipo_feriado) values ("'.$project_id.'","'.$nome_calendario_util.'","'.$dom_util[0].'","'.$dom_util[1].'","'.$seg_util[0].'","'.$seg_util[1].'","'.$ter_util[0].'","'.$ter_util[1].'","'.$quar_util[0].'","'.$quar_util[1].'","'.$quin_util[0].'","'.$quin_util[1].'","'.$sex_util[0].'","'.$sex_util[1].'","'.$sab_util[0].'","'.$sab_util[1].'","'.$feriado_util.'")';

            $dias_uteis = \DB::connection('mysql_redmine')->insert($dias_uteis);
            
            $dados[] = $dias_uteis;

            $log = new Log;
            $log->datahora = Carbon::now();
            $log->analista = \Session::get('user')['firstname'] . ' ' . \Session::get('user')['lastname'];
            $log->acao = 'Criação de Calendário de SLA';
            $log->json = json_encode($dias_uteis, JSON_UNESCAPED_UNICODE);
            $log->save();

            return $dados;

        }
    }

    public function encontrar_ids(Request $request){
        if($request){

            $data = '';
            $situacao = '';
            $prioridade = '';
            $tipo = '';
            $projeto = '';
            $and = '';
            $sinal = $request->data;

            if($sinal == '><') $sinal = 'BETWEEN';
            
            if($request->data_inicio){
                $and = 'AND';
                $data = ''.$and.' i.start_date '.$sinal.' "'.$request->data_inicio.'"';
                if($request->data_fim) $data .= ' AND "'.$request->data_fim.'"';
            } 
            if($request->situacao) {
                $and = 'AND';
                $situacao = ''.$and.' i.status_id = '.$request->situacao.'';
            }
            if($request->prioridade){
                $and = 'AND';
                $prioridade = ''.$and.' i.priority_id = '.$request->prioridade.'';
            } 
            if($request->tipo){
                $and = 'AND';
                $tipo = ''.$and.' i.tracker_id = '.$request->tipo.'';
            }
            if($request->project_id){
                $and = 'AND';
                $projeto = ''.$and.' i.project_id = '.$request->project_id.'';
            }

            $dados = $data.' '.$situacao.' '.$prioridade.' '.$tipo.' '.$projeto;

            $sql = 'SELECT i.id id from redmine.issues i INNER JOIN redmine.custom_values cv on 
            cv.customized_id = i.project_id AND cv.custom_field_id = 14 and cv.customized_type = "Project"
            AND cv.value in("Suporte e Monitoramento","Projeto aberto - Com fila") '.$dados.'';

            $ids = \DB::connection('mysql_redmine')->select($sql);

            $data = [];
            $data['ids'] = $ids;
            $data['count'] = count($ids);

            return $data;
        }
    }
    public function recalcular(Request $request){
        $dados = $request->ids;
        if($request->ids){
            foreach($dados as $i){
                $function = 'SELECT redmine_sla.fct_preencher_sla('.$i['id'].')';
                $function = \DB::connection('mysql_redmine')->select($function);
            }
            }
            
            $log = new Log;
            $log->datahora = Carbon::now();
            $log->analista = \Session::get('user')['firstname'] . ' ' . \Session::get('user')['lastname'];
            $log->acao = 'SLA recalculado';
            $log->json = json_encode($request->ids, JSON_UNESCAPED_UNICODE);
            $log->save();

            return $request->ids;

    }

}

