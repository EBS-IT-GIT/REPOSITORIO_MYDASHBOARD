@extends('adminlte::page')

@section('title', 'Relatórios')

@section('content_header')
    <h1 ><i class="fa fa-list-alt"></i> Relatórios
        <small>Relatórios</small>
    </h1>
@stop

@section('content')
    <div class="row">
        <div class="col-md-12">

            <div class="box box-success">
                <div class="box-header">
                    <h3 class="box-title">Apontamentos</h3>
                    <div class="box-tools">
                        <button type="button" id="btn-pesquisar" name="btn-pesquisar" class="btn btn-sm btn-success"><i class="fa fa-search"></i> pesquisar</button>
                    </div>
                </div>

                <div class="box-body">

                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Início</label>
                                <input type="date" id="datainicio" name="datainicio" min="{{ date('Y-01-01') }}" max="{{ date('Y-m-d') }}" class="form-control input-sm" value="" />
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Fim</label>
                                <input type="date" id="datatermino" name="datatermino" min="{{ date('Y-01-01') }}" max="{{ date('Y-m-d') }}" class="form-control input-sm" value="" />
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Situação</label>
                                <select id="situacao" class="form-control input-sm">
                                    <option value=""></option>
                                    @foreach($situacao as $sit)
                                        <option value="{{ $sit->id }}">{{ $sit->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="col-md-5">
                            <div class="form-group">
                                <label>Projetos <small><i class="fa fa-info-circle" aria-hidden="true"></i> Selecione múltiplos registros pressionando Ctrl</small></label>
                                <select multiple="multiple" id="projeto" class="form-control input-sm">
                                    <option value=""></option>
                                    @foreach($projetos as $projeto)
                                        <option value="{{ $projeto->id }}">{{ $projeto->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
            </div>
       

 
    <div class="box box-default box-body">

                <!-- /.box-header -->
                <div class="box-body table-responsive" id="lista-fatura">
                    <table id="table-" class="table table-striped table-bordered table-hover display compact">
                        <thead>
                        <tr>
                            <th style="width:50px;">Chamado</th>
                            <th>Projeto</th>
                            <th style="width:180px;">Título</th>
                            <th>Data</th>
                            <th style="width:70px;">Entrada</th>
                            <th style="width:70px;">Intervalo</th>
                            <th style="width:70px;">Retorno</th>
                            <th style="width:70px;">Saída</th>
                            <th style="width:70px;">Horas</th>
                            <th>Situação</th>
                            <th>Verificação</th>
                            <th id="edit"></th>
                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                    
                    <table class="table table-striped table-bordered table-hover display compact">
                        <tbody>
                        <tr>
                            <th style="text-align: right; width: 50%">Total de Horas</th>
                            <td id="totalhoras">0.00</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>


    <div class="modal fade fade bd-example-modal-lg" tabindex="-1" role="dialog" data-toggle="modal" id="modal-edittime" data-backdrop = "false" style="display:none; ">
    <input type="hidden" name="taskid" id="taskid" value="" />
        <div class="modal-dialog modal-lg" style="width: 1135px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                            <h1 class="modal-title">Editar Horas</h1> 
                            <label id="alerta_horario"></label><br>
                             <label id="alerta_apontamento"></label>
                </div>
                <div class="modal-body">
                
                
                <div class="table-responsive">
                    <label id="alerta_horario" class="pull-left"></label>
                    <label id="alerta_apontamento" class="pull-left"></label>

                    <table id="table-reports" class="table table-striped table-bordered table-hover table-striped display compact">

                        <thead>
                        <tr>
                        <!-- <th>#</th> -->
                        <th style="white-space: nowrap;">Data <span class="text-red">*</span></th>
                        <th style="white-space: nowrap;">Entrada <span class="text-red">*</span></th>
                        <th>Intervalo</th>
                        <th>Retorno</th>
                        <th style="white-space: nowrap;">Saída <span class="text-red">*</span></th>
                        <th style="white-space: nowrap;">Horas <span class="text-red">*</span></th>
                        <th style="padding:5px 35px;white-space: nowrap;">Atendimento <span class="text-red">*</span></th>
                        <th style="padding:5px 30px;">Atividade<span class="text-red">*</span></th>
                        <th style="padding:5px 20px;white-space: nowrap;">Tipo Hora <span class="text-red">*</span></th>
                        
                        </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                <input type="date" name="spent_on" id="spent_on" value="" class="form-control input-sm calcular_edit calcular_report" data-timeid=""/>                                </td>
                                <td>
                                <input type="time" name="hora_entrada_trabalho" id="hora_entrada_trabalho" value="" placeholder="00:00" class="form-control input-sm calcular_edit calcular_report" data-timeid="" >
                                <input type="hidden" name="hora_entrada_trabalhohidden" id="hora_entrada_trabalhohidden" value="" placeholder="00:00" class="form-control input-sm calcular_edit" data-timeid="" >

                                </td>
                                <td>
                                <input type="time" name="hora_saida_almoco" id="hora_saida_almoco" value="" placeholder="00:00" class="form-control input-sm calcular_edit calcular_report" data-timeid="" >
                                <input type="hidden" name="hora_saida_almocohidden" id="hora_saida_almocohidden" value="" placeholder="00:00" class="form-control input-sm calcular_edit" data-timeid="" >

                                </td>
                                <td>
                                <input type="time" name="hora_retorno_almoco" id="hora_retorno_almoco" value="" placeholder="00:00" class="form-control input-sm calcular_edit calcular_report" data-timeid="" >
                                <input type="hidden" name="hora_retorno_almocohidden" id="hora_retorno_almocohidden" value="" placeholder="00:00" class="form-control input-sm calcular_edit" data-timeid="" >
                                </td>
                                <td>
                                <input type="time" name="hora_saida_trabalho" id="hora_saida_trabalho" value="" placeholder="00:00" class="form-control input-sm calcular_edit calcular_report" data-timeid="" >
                                <input type="hidden" name="hora_saida_trabalhohidden" id="hora_saida_trabalhohidden" value="" placeholder="00:00" class="form-control input-sm calcular_edit" data-timeid="" >
                                </td>
                                <td>
                                <input type="text" name="horas" id="horas" value="" placeholder="0.00" class="form-control input-sm" data-timeid="" disabled="disabled">

                                </td>
                                <td style="max-width:180px;">
                                <textarea rows="3" class="form-control input-sm " name="atividades" id="atividades" value="" placeholder="atividades"  style="max-width:160px;min-height:32px;"></textarea></td>
                                <td>
                                <select class="form-control input-sm " name="activities" id="activities">
                                        <option value="9">Execução</option>
                                        <option value="8">Planejamento</option>
                                        <option value="10">Documentação</option>
                                    </select>
                                </td>
                                <td>
                                <select class="form-control input-sm " name="tipo_hora" id="tipo_hora">
                                        <option value="Normal">Normal</option>
                                        <option value="Extra">Extra</option>
                                    </select>
                                </td>
                    </tr>
                        </tbody>
                    </table>
                </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-primary" id="btn-edit-time-report" data-timeid="" ><i class="fa fa-floppy-o"></i></button>
                </div>
            </div>
        </div>
</div>

@stop

@section('js')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
                        
    <script>
    
    window.onload = function() {
        $(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#table-').DataTable();

            function carregarDadosReport()
            {
                $("#table- tbody").empty().html("<tr><td colspan=12 class=text-center> Carregando registros ...</td></tr>");

                var situacao = $('#situacao').val();
                var projeto = $('#projeto').val();
                var inicio = $('#datainicio').val();
                var termino = $('#datatermino').val();

                var filtro = '';
                if(situacao!='') filtro += '&situacao=' + situacao;
                if(projeto!='') filtro += '&projeto=' + projeto;
                if(inicio!='') filtro += '&inicio=' + inicio;
                if(termino!='') filtro += '&termino=' + termino;

               
                $.ajax({
                    url : '{{ URL::to('/reports/json')}}',
                    type: 'POST',
                    data: filtro,
                    dataType: 'json',
                    success: function(data){
                        var html;
                        var totalhoras=0.00;
                        for(var i in data){
                            var item = data[i];

                            totalhoras += parseFloat(item.horas);

                            html += '<tr>' +
                                '<td>' + '<a target="_blank" href="{{ url('/taskreport')}}/'+ item.id_chamado +'" class="btn btn-default btn-xs taskdetail">' + item.id_chamado + '</a> </td>'+
                                '<td>' + item.projeto + '</td>'+
                                '<td>' + item.chamado + '</td>'+
                                '<td>' + item.data_apontamento_format + '</td>' +
                                '<td>' + item.hora_entrada  + '</td>' +
                                '<td>' + item.hora_saida_almoco + '</td>' +
                                '<td>' + item.hora_retorno_almoco + '</td>' +
                                '<td>' + item.hora_saida + '</td>'+
                                '<td>' + item.horas + '</td>'+
                                '<td>' + item.situacao + '</td>'+
                                '<td>' + item.status_horas + '</td>'+
                                '<td>' +
                                '<button type="button" class="btn btn-sm btn-info edit-time" data-target="#modal-edittime" name="button" ' +
                                'data-timeid="' + item.id_horas + '" ' +
                                'data-taskid="' + item.id_chamado + '" ' +
                                'data-spent_on="' + item.data_apontamento + '" ' +
                                'data-hora_entrada_trabalho="' + item.hora_entrada + '" ' +
                                'data-hora_saida_almoco="' + item.hora_saida_almoco + '" ' +
                                'data-hora_retorno_almoco="' + item.hora_retorno_almoco + '" ' +
                                'data-hora_saida_trabalho="' + item.hora_saida + '" ' +
                                'data-horas="' + item.horas + '" ' +
                                'data-activities="' + item.activity_id + '" ' +
                                'data-atividades="' + item.atividades + '" ' +
                                'data-tipo_hora="' + item.tipo_hora + '"><i class="fa fa-pencil"></i> </button>' +
                                '<button type="button" class="btn btn-sm btn-danger btn-delete-time-report" name="button" data-timeid="' + item.id_horas + '"  data-taskid="' + item.id_chamado + '" data-horas="' + item.horas + '"><i class="fa fa-trash-o"></i> </button>' +
                                '</td>'+
                                '</tr>';
                        }
                        $('#table-').DataTable().destroy();
                        $('#table- tbody').empty().append(html);
                        $('#table-').DataTable({'pageLength'  : 100}).draw();
                        $('#totalhoras').html('<b>'+totalhoras+'</b>');

                    },
                    error: function(xhr, textStatus, errorThrown){
                        Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });   
                        }
                });
            }
           
            $('#table-').DataTable();

            $(document).on('click','#btn-pesquisar', function(e){
                e.preventDefault();
                carregarDadosReport();
            });
            


            $(document).on('click','.edit-time', function(e){
                e.preventDefault();
                var timeid = $(this).data('timeid');
                var taskid = $(this).data('taskid');
                var spent_on = $(this).data('spent_on');
                var hora_entrada_trabalho = $(this).data('hora_entrada_trabalho');
                var hora_saida_almoco = $(this).data('hora_saida_almoco');
                var hora_retorno_almoco = $(this).data('hora_retorno_almoco');
                var hora_saida_trabalho = $(this).data('hora_saida_trabalho');
                var horas = $(this).data('horas');
                var activities = $(this).data('activities');
                var atividades = $(this).data('atividades');
                var tipo_hora = $(this).data('tipo_hora');

                $('#btn-edit-time-report').attr('data-timeid',timeid);
                $('#taskid').val(taskid);
                $('#spent_on').val(spent_on);
                $('#hora_entrada_trabalho').val(hora_entrada_trabalho);
                $('#hora_entrada_trabalhohidden').val(hora_entrada_trabalho);

                $('#hora_saida_almoco').val(hora_saida_almoco);
                $('#hora_saida_almocohidden').val(hora_saida_almoco);

                $('#hora_retorno_almoco').val(hora_retorno_almoco);
                $('#hora_retorno_almocohidden').val(hora_retorno_almoco);

                $('#hora_saida_trabalho').val(hora_saida_trabalho);
                $('#hora_saida_trabalhohidden').val(hora_saida_trabalho);

                $('#horas').val(horas);
                $('#horashiddenreport').val(horas);

                $('#activities').val(activities);
                $('#atividades').val(atividades);
                $('#tipo_hora').val(tipo_hora);
                localStorage.setItem('data-timeid', timeid);
                $('#modal-edittime').modal('show');
                $('#horas').attr('data-timeid', timeid);
                $('#horas').attr('data-taskid', taskid);


            });

            /*
            ** Funcao de Atualizar Apontamento existente
            */
            $(document).on('click', '#btn-edit-time-report', function(e){
                var timeid = localStorage.getItem('data-timeid');
                checarhorario('',timeid);
                if(localStorage.getItem('conflito') != 1) {
                var save = 1;
                var ismanual = 1;
                var taskid = $('#taskid').val();
                var spent_on = $('#spent_on').val();
                var hours = $('#horas').val();
                var atividades = escape($('#atividades').val());
                var atividade = $('#activities').val();
                var hora_entrada_trabalho = $('#hora_entrada_trabalho').val();
                var hora_entrada_trabalhohidden = $('#hora_entrada_trabalhohidden').val();

                var hora_saida_almoco = $('#hora_saida_almoco').val();
                var hora_saida_almocohidden = $('#hora_saida_almocohidden').val();

                var hora_retorno_almoco = $('#hora_retorno_almoco').val();
                var hora_retorno_almocohidden = $('#hora_retorno_almocohidden').val();

                var hora_saida_trabalho = $('#hora_saida_trabalho').val();
                var hora_saida_trabalhohidden = $('#hora_saida_trabalhohidden').val();

                var tipo_hora = $('#tipo_hora').val();

              
                if(timeid && hours && atividades && spent_on && taskid && hora_entrada_trabalho &&  hora_saida_trabalho)
                {

                    var data = 'timeid='+timeid+
                        '&taskid='+taskid+
                        '&spent_on='+spent_on+
                        '&hours='+hours+
                        '&atividades='+atividades+
                        '&activity='+atividade+
                        '&hora_entrada_trabalho='+hora_entrada_trabalho+
                        '&hora_saida_almoco='+hora_saida_almoco+
                        '&hora_retorno_almoco='+hora_retorno_almoco+
                        '&hora_saida_trabalho='+hora_saida_trabalho+
                        '&tipo_hora='+tipo_hora+'&save='+save+'&ismanual='+ismanual;

                    $.ajax({
                        url : '{{ URL::to('/savetime')}}',
                        data: data,
                        type: 'POST',
                        success: function(data){
                            Swal.fire({
                            title: 'Success!',
                            html: 'Dados Atualizados Corretamente',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            });  
                            carregarDadosReport();
                            $('#modal-edittime').modal('hide');

                        },
                        error: function(xhr, textStatus, errorThrown){
                        Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });   
                        }
                    });
                }else{
                    var campos = '';
                    if(!notes) campos += '  '
                    Swal.fire({
                            title: 'Error!',
                            html: 'Campos Obrigatórios',
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });   
                }
                }
            });

            /*
            ** FunÃ§Ã£o de Atualizar Apontamento existente
            */


            $(document).on('click', '.btn-delete-time-report', function(e){
                var timeid = $(this).data('timeid');
                var taskid = $(this).data('taskid');
              
                    Swal.fire({
                    title: 'Realmente deseja excluir o apontamento?',
                    text: "Você não será capaz de reverter isso!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sim'
                    }).then((result) => {
                    if (result.isConfirmed) {
                      
                var data = 'timeid=' + timeid + '&taskid='+ taskid;
                
                $.ajax({
                    url : '{{ URL::to('/deletetime')}}',
                    data: data,
                    type: 'POST',
                    success: function(data){
                        
                        Swal.fire({
                            title: 'Success!',
                            html: 'Apontamento excluído corretamente!',
                            icon: 'success',
                            confirmButtonText: 'OK'
                            });  
                        carregarDadosReport();

                    },
                    error: function(xhr, textStatus, errorThrown){
                        Swal.fire({
                            title: 'Error!',
                            html: xhr.responseJSON.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                            });                    }
                });
                }
            })


            });
        });
    };
        $(".calcular_report").change(function(){
            var result = verificarApontamento($('#hora_saida_trabalho'),$('#hora_entrada_trabalho'),$('#hora_saida_almoco'),$('#hora_retorno_almoco'),'');

            if(result == false){
            $("#btn-edit-time-report").attr("disabled", true);

            }
            else{
                $("#btn-edit-time-report").attr("disabled", false);
            }
        });
        jQuery(function($){
            $("#hora_entrada_trabalho").mask("00:00");
            $("#hora_saida_almoco").mask("00:00");
            $("#hora_retorno_almoco").mask("00:00");
            $("#hora_saida_trabalho").mask("00:00");
        });
       

    </script>
@stop
