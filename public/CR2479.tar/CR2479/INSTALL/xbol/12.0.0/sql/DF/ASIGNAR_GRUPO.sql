  set define off;
DECLARE
  l_program_short_name  VARCHAR2 (200);
  l_program_application VARCHAR2 (200);
  l_request_group       VARCHAR2 (200);
  l_group_application   VARCHAR2 (200);
  l_check               VARCHAR2 (2);
  --
BEGIN
  --
  l_program_short_name  := 'XXARALRA';
  l_program_application := 'Business Online';
  l_request_group       := 'XX AR Cobranzas';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 );  
  --
  l_program_short_name  := 'XXARALRA';
  l_program_application := 'Business Online';
  l_request_group       := 'JLAR + AR Reports';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   apps.fnd_program.add_to_group (program_short_name  => l_program_short_name,
                                  program_application => l_program_application,
                                  request_group       => l_request_group,
                                  group_application   => l_group_application                            
                                 ); 
  --
  l_program_short_name  := 'FNDRSSUB2611';
  l_program_application := 'Business Online';
  l_request_group       := 'XX AR Cobranzas';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   fnd_set.add_set_to_group (request_set => l_program_short_name,
                             set_application => l_program_application,
                             request_group => l_request_group,
                             group_application => l_group_application
                             );
  --
  l_program_short_name  := 'FNDRSSUB2611';
  l_program_application := 'Business Online';
  l_request_group       := 'JLAR + AR Reports';
  l_group_application   := 'Business Online';
  --
  --Calling API to assign concurrent program to a reqest group
  --
   fnd_set.add_set_to_group (request_set => l_program_short_name,
                             set_application => l_program_application,
                             request_group => l_request_group,
                             group_application => l_group_application
                             );
  --
  COMMIT;
END;
/
EXIT