#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2283_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2283
# |
# | HISTORY
# |   29-MAR-20  Gallucci, Pablo Nicolás - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2283_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2283_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2283
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2283/CR2283_20200329"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=DESA12

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/REQGRP
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/REQGRP
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT
svn up /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2283" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2283_13787.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2283"
AddAllLogs $CROUT "FND" "CR2283_13787.ldt"
mv CR2283_13787.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OPM_PROC_GI_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OPM_PROC_GI_PK','APPS','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_PROC_GI_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb ]; then
  cp $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb XXOPMCONFGCOLU.fmb
  echo `ls -lh XXOPMCONFGCOLU.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb no existe" >> $CROUT
fi
mv XXOPMCONFGCOLU* $DOWNDBDIR/au/12.0.0/forms/US/


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
