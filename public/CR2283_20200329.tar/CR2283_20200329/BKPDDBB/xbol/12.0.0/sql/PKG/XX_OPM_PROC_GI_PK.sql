  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OPM_PROC_GI_PK" 
/*****************************************************************************************
     NAME:       APPS.XX_OPM_PROC_GI_PK

     REVISIONS:
     Ver        Date                Author          Description
     ---------  ----------         ------------    ---------------------------------
     1.0        18-OCT-2019       ITC             Initial Creation
     1.1        20-MAR-2020       ITC             Mejora #1-Ociocidad cuando CR_RSRC_MST_VL.CAPACITY_CONSTRAINT = 1
                                                  Mejora #2-AGREGAR EN EL REPORTE Y EL PROCESO DE CÁLCULO TODOS LOS ITEMS QUE TENGAN WIP Completion y Return
                                                            (actualmente solo trae los que tienen usage). En esos casos el usage DEBE SER 0. En la columna de 
                                                            calculo si el usage es 0 tambien debe ser 0
******************************************************************************************/
AS

/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Principal                                                             |
|                                                                          |
| Description                                                              |
|    Procedure para procesar los gastos indirectos                         |
|                                                                          |
+=========================================================================*/
    PROCEDURE Principal ( errbuf                 OUT  VARCHAR2
                        , retcode                OUT  VARCHAR2
                        , p_organization_id      IN  NUMBER
                        , p_legal_entity_id      IN  NUMBER
                        , p_period_id            IN  NUMBER
                        , p_ledger_id            IN  NUMBER
                        , p_gl_period            IN  VARCHAR2
                        , p_update_res_cost      IN  VARCHAR2
                        , p_Debug                IN  VARCHAR2
                        );

    PROCEDURE delete_adj ( errbuf                 OUT  VARCHAR2
                         , retcode                OUT  VARCHAR2
                         , p_organization_id      IN  NUMBER
                         , p_legal_entity_id      IN  NUMBER
                         , p_Debug                IN  VARCHAR2
                         );

    -- Global variables for authentification
    g_user_id                NUMBER := fnd_global.user_id;
    g_conc_request_id        NUMBER := fnd_global.conc_request_id;
    g_responsibility_id      NUMBER := fnd_global.resp_id;
    g_resp_application_id    NUMBER := fnd_global.resp_appl_id;
    g_login_id               NUMBER := fnd_global.login_id;
    g_user_name              VARCHAR2(80) := fnd_profile.value('USERNAME');
    g_resp_id                NUMBER       := apps.fnd_profile.value('RESP_ID');
    g_appl_resp_id           NUMBER       := apps.fnd_profile.value('APPL_RESP_ID');
    g_Debug                  VARCHAR2(1)  := 'Y';

    g_retcode      VARCHAR2(1):='0';

    g_Time_Before                    BINARY_INTEGER;
    g_Time_After                     BINARY_INTEGER;

    C_REPORT_NAME          constant varchar2(80) := 'XX OPM Proceso Asignacion Automatica de Gastos Indirectos';

    C_REPORT_DEL_NAME      constant varchar2(80) := 'XX OPM Proceso Borrar Ajustes de Gastos Indirectos';

END XX_OPM_PROC_GI_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OPM_PROC_GI_PK" 
/*****************************************************************************************
     NAME:       APPS.XX_OPM_PROC_GI_PK

     REVISIONS:
     Ver        Date                Author          Description
     ---------  ----------         ------------    ---------------------------------
     1.0        18-OCT-2019       ITC             Initial Creation
     1.1        20-MAR-2020       ITC             Mejoras #1-Ociocidad cuando CR_RSRC_MST_VL.CAPACITY_CONSTRAINT = 1
                                                          #2-AGREGAR EN EL REPORTE Y EL PROCESO DE CÁLCULO TODOS LOS ITEMS QUE TENGAN WIP Completion y Return
                                                            (actualmente solo trae los que tienen usage). En esos casos el usage DEBE SER 0. En la columna de 
                                                            calculo si el usage es 0 tambien debe ser 0
******************************************************************************************/
AS
   PROCEDURE debug_print (p_print_flag IN VARCHAR2, p_debug_mesg IN VARCHAR2) IS
   BEGIN
     IF p_print_flag = 'Y' THEN
       apps.fnd_file.put_line (fnd_file.output, p_debug_mesg);
     END IF;
   END debug_print;

/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Principal                                                             |
|                                                                          |
| Description                                                              |
|    Procedure para procesar los gastos indirectos                         |
|                                                                          |
+=========================================================================*/
    PROCEDURE Principal ( errbuf                 OUT  VARCHAR2
                        , retcode                OUT  VARCHAR2
                        , p_organization_id      IN  NUMBER
                        , p_legal_entity_id      IN  NUMBER
                        , p_period_id            IN  NUMBER
                        , p_ledger_id            IN  NUMBER
                        , p_gl_period            IN  VARCHAR2
                        , p_update_res_cost      IN  VARCHAR2
                        , p_Debug                IN  VARCHAR2
                        )
    IS
      -- Local  Variables
      v_error_details       VARCHAR2 (4000);
      v_error_code          VARCHAR2 (30);
      v_err_stage           VARCHAR2 (4000);
      e_validate_error      EXCEPTION;

      v_legal_entity_name   VARCHAR2(240);
      v_period_code         VARCHAR2(10);
      v_period_status       VARCHAR2(1);
      v_period_status_desc  VARCHAR2(40);
      v_count_res_org       NUMBER := 0;
      v_sum_accounted_dr    NUMBER;
      v_sum_accounted_cr    NUMBER;
      v_sum_gl_amount       NUMBER;
      v_acum_gl_amount_org_rec  NUMBER;
      v_new_res_cost        NUMBER;
      v_flag_res_cost       VARCHAR2(1);
      v_nominal_cost        NUMBER;
      v_delete_mark         NUMBER;

    -------------------------------------------
    -- Lines to be processed - resources by org
    -------------------------------------------
    CURSOR c_cur_opm_res_by_org IS
      SELECT gps.legal_entity_id
           , mp.organization_code
           , mp.organization_id
           , msi.segment1 item_code
           , msi.description
           , msi.inventory_item_id
           , gps.calendar_code
           , gps.period_id
           , gps.period_code
           , gps.period_status
           , cmm.cost_mthd_code
           , cbd.resources
           , ccm.cost_cmpntcls_code comp_cost
           , cbd.cost_analysis_code an_cod
           , cbd.burden_qty
           , cbd.burden_usage
           , cbd.burden_uom
           , cbd.item_qty
           , cbd.item_uom
           , (SELECT nominal_cost
                FROM cm_rsrc_dtl crd
               WHERE crd.resources = cbd.resources
                 AND crd.period_id = cbd.period_id
                 AND crd.cost_type_id = cbd.cost_type_id
                 AND crd.organization_id = cbd.organization_id) cost
           , NVL((SELECT SUM (primary_quantity)
                    FROM mtl_material_transactions mmt
                   WHERE cbd.organization_id = mmt.organization_id
                     AND cbd.inventory_item_id = mmt.inventory_item_id
                     AND transaction_source_type_id = 5
                    --WIP Return(43), WIP Completion(44), NO VA=> WIP Byproduct Completion (1002), WIP Byproduct Return(1003)
                     AND transaction_type_id IN ( 43, 44)
                     AND transaction_action_id IN (31, 32) -- wip assy cmp and return
                     AND TRUNC (transaction_date) BETWEEN gps.start_date
                                                      AND gps.end_date),0) produc
        FROM cm_brdn_dtl         cbd
           , gmf_period_statuses gps
           , mtl_parameters      mp
           , mtl_system_items_b  msi
           , cm_mthd_mst         cmm
           , cm_cmpt_mst_vl      ccm
       WHERE cbd.period_id         = gps.period_id
         AND cbd.organization_id   = mp.organization_id
         AND cbd.organization_id   = msi.organization_id
         AND cbd.inventory_item_id = msi.inventory_item_id
         AND cbd.cost_cmpntcls_id  = ccm.cost_cmpntcls_id
         AND cmm.cost_type_id      = cbd.cost_type_id
         AND cbd.delete_mark       = 0
         AND gps.legal_entity_id   = p_legal_entity_id
         AND gps.period_id         = p_period_id
         AND EXISTS (SELECT 1
                       FROM xx_opm_conf_gi_lineas_det xx_lines_det
                      WHERE xx_lines_det.legal_entity_id = gps.legal_entity_id
                        and xx_lines_det.resources       = cbd.resources
                    )
/************************************************************************************************************
  Mejora #2-AGREGAR EN EL REPORTE Y EL PROCESO DE CÁLCULO TODOS LOS ITEMS QUE TENGAN WIP Completion y Return
            (actualmente solo trae los que tienen usage). En esos casos el usage DEBE SER 0. En la columna de 
            calculo si el usage es 0 tambien debe ser 0
************************************************************************************************************/
  UNION ALL
      SELECT gps.legal_entity_id
           , mp.organization_code
           , mp.organization_id
           , msi.segment1 item_code
           , msi.description
           , msi.inventory_item_id
           , gps.calendar_code
           , gps.period_id
           , gps.period_code
           , gps.period_status
           , NULL cost_mthd_code
           , NULL resources
           , NULL comp_cost
           , NULL an_cod
           , NULL burden_qty
           , 0 burden_usage
           , NULL burden_uom
           , NULL item_qty
           , NULL item_uom
           , NULL cost
           , NVL(SUM (primary_quantity),0) produc
        FROM gmf_period_statuses gps
           , mtl_parameters      mp
           , mtl_system_items_b  msi
           , mtl_material_transactions mmt
           , xx_opm_conf_gi_columnas_hdr xx_conf_col_hdr
       WHERE mmt.organization_id   = mp.organization_id
         AND mmt.organization_id   = msi.organization_id
         AND mmt.inventory_item_id = msi.inventory_item_id
         AND gps.legal_entity_id   = p_legal_entity_id
         AND gps.period_id         = p_period_id
         AND mmt.transaction_source_type_id = 5
         --WIP Return(43), WIP Completion(44), NO VA=> WIP Byproduct Completion (1002), WIP Byproduct Return(1003)
         AND mmt.transaction_type_id IN ( 43, 44) 
         AND mmt.transaction_action_id IN (31, 32) -- wip assy cmp and return
         AND TRUNC (mmt.transaction_date) BETWEEN gps.start_date AND gps.end_date
         AND xx_conf_col_hdr.legal_entity_id = p_legal_entity_id
         AND xx_conf_col_hdr.organization_id = mmt.organization_id
         AND NOT EXISTS (SELECT 1
                           FROM cm_brdn_dtl cbd
                          WHERE period_id = gps.period_id
                            AND cbd.organization_id   = mmt.organization_id
                            AND cbd.inventory_item_id = mmt.inventory_item_id
                            AND cbd.delete_mark       = 0)
         GROUP BY gps.legal_entity_id
           , mp.organization_code
           , mp.organization_id
           , msi.segment1 
           , msi.description
           , msi.inventory_item_id
           , gps.calendar_code
           , gps.period_id
           , gps.period_code
           , gps.period_status;

    -------------------------------------------
    -- SUM lines has been processed - resources by org
    -------------------------------------------
    CURSOR c_cur_prod_res_by_org IS
      SELECT legal_entity_id
           , legal_entity_name
           , period_id
           , period_code
           , period_status
           , organization_code
           , organization_id
           , calendar_code
           , cost_mthd_code
           , resources
           , comp_cost
           , SUM(xx_gi_res_org.calc_prod_usage) sum_prod_usage
        FROM XX_OPM_ASIG_GI_RESOURCE_ORG xx_gi_res_org
       WHERE xx_gi_res_org.legal_entity_id = p_legal_entity_id
         AND xx_gi_res_org.period_id       = p_period_id
       GROUP BY legal_entity_id
              , legal_entity_name
              , period_id
              , period_code
              , period_status
              , organization_code
              , organization_id
              , calendar_code
              , cost_mthd_code
              , resources
              , comp_cost;

    -------------------------------------------
    -- GL information has been processed - sum GL for resources by org
    -------------------------------------------
    CURSOR c_cur_gl_res_by_org ( p_organization_id NUMBER, p_resources VARCHAR2) IS
      SELECT xx_conf_col_hdr.legal_entity_id
           , xx_conf_col_hdr.legal_entity_name
           , xx_conf_col_hdr.chart_of_accounts_id
           , xx_conf_col_hdr.organization_id
           , xx_conf_col_hdr.organization_code
           -- Mejora #1-Ociocidad cuando CR_RSRC_MST_VL.CAPACITY_CONSTRAINT = 1
           , xx_conf_col_hdr.ociosidad * (SELECT capacity_constraint 
                                            FROM cr_rsrc_mst_vl 
                                           WHERE resources = xx_conf_lin_det.resources) ociosidad
           , xx_conf_col_hdr.orden
           , xx_conf_lin_det.resources
           , xx_conf_lin_det.segment1
           , xx_conf_lin_det.segment2
           , xx_conf_col_det.unidad_negocio
           , xx_conf_col_det.producto
           , xx_conf_col_det.unidad_prod
           , xx_conf_col_det.centro_costo
           , xx_conf_col_det.proyecto
           , xx_conf_col_det.intercompany
--           , xx_conf_col_det.ajuste
           , (SELECT SUM(Ajuste)
                FROM xx_opm_conf_gi_ajustes_cc xx_aju
               WHERE xx_aju.code_combination_id = gcc.code_combination_id
                 AND xx_aju.enabled_flag = 'Y') ajuste
           , gcc.concatenated_segments
           , gcc.code_combination_id
        FROM xx_opm_conf_gi_columnas_det xx_conf_col_det
           , xx_opm_conf_gi_columnas_hdr xx_conf_col_hdr
           , xx_opm_conf_gi_lineas_det   xx_conf_lin_det
           , gl_code_combinations_kfv gcc
       WHERE 1=1
         AND xx_conf_lin_det.legal_entity_id = p_legal_entity_id
         AND xx_conf_lin_det.organization_id = p_organization_id
         AND xx_conf_lin_det.resources       = p_resources
         AND xx_conf_lin_det.enabled_flag    = 'Y'
         AND xx_conf_lin_det.legal_entity_id = xx_conf_col_hdr.legal_entity_id
         AND xx_conf_lin_det.organization_id = xx_conf_col_hdr.organization_id
         AND xx_conf_col_det.legal_entity_id = xx_conf_col_hdr.legal_entity_id
         AND xx_conf_col_det.organization_id = xx_conf_col_hdr.organization_id
         AND xx_conf_col_det.enabled_flag    = 'Y'
         AND gcc.chart_of_accounts_id = xx_conf_col_hdr.chart_of_accounts_id
         AND gcc.segment1 = xx_conf_lin_det.segment1
         AND gcc.segment2 = xx_conf_lin_det.segment2
         AND gcc.segment3 = NVL(xx_conf_col_det.unidad_negocio,gcc.segment3)
         AND gcc.segment4 = NVL(xx_conf_col_det.producto,gcc.segment4)
         AND gcc.segment5 = NVL(xx_conf_col_det.unidad_prod,gcc.segment5)
         AND gcc.segment6 = NVL(xx_conf_col_det.centro_costo,gcc.segment6)
         AND gcc.segment7 = NVL(xx_conf_col_det.proyecto,gcc.segment7)
         AND gcc.segment8 = NVL(xx_conf_col_det.intercompany,gcc.segment8);


   BEGIN
     g_Debug := p_Debug;
     --
     BEGIN
       SELECT glcd.object_name
         INTO v_legal_entity_name
         FROM gl_ledger_config_details glcd
        WHERE glcd.object_type_code = 'LEGAL_ENTITY'
          AND glcd.object_id        = p_legal_entity_id;
     EXCEPTION WHEN OTHERS THEN
        v_error_code := 'GLB_MAIN_001';
        v_error_details := 'General Error for to get legal entity name ' || sqlerrm;
        RAISE e_validate_error;
     END;
     --
     BEGIN
       SELECT gps.period_code
            , gps.period_status
            , DECODE(gps.period_status, 'O', 'Abierto(O)', 'C', 'Cerrado(C)', 'F', 'Congelado(F)', 'Nunca Abierto(N)') period_status_desc
         INTO v_period_code
            , v_period_status
            , v_period_status_desc
         FROM gmf_period_statuses gps
        WHERE gps.period_id = p_period_id;
     EXCEPTION WHEN OTHERS THEN
        v_error_code := 'GLB_MAIN_002';
        v_error_details := 'General Error for to get period code and period status ' || sqlerrm;
        RAISE e_validate_error;
     END;
     --
     v_err_stage := '==============================================================================';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := 'Parameters';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Program                     ==> ' ||C_REPORT_NAME;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Concurrent                  ==> ' ||g_conc_request_id;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  User                        ==> ' ||g_user_name;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Date                        ==> ' ||TO_CHAR(SYSDATE,'DD-MM-YYYY HH24:mm:ss');
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Legal Entity                ==> ' ||v_legal_entity_name|| '(ID='||p_legal_entity_id||')';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Ledger Id                   ==> ' ||p_ledger_id;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Period OPM                  ==> ' ||v_period_code|| '(ID='||p_period_id||')';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Status Period OPM           ==> ' ||v_period_status_desc;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Period GL                   ==> ' ||p_gl_period;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Enable debug                ==> ' ||p_Debug;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '==============================================================================';
     debug_print (g_Debug, v_err_stage);

     --Para los estados Frozen y Closed solo muestra la foto guardada
     --El proceso de cálculo y actualización solo se ejecuta sobre períodos “Abiertos”
     IF v_period_status = 'O' THEN

       DELETE FROM xx_opm_asig_gi_resource_org
        WHERE legal_entity_id = p_legal_entity_id
          AND period_id       = p_period_id;

       DELETE FROM xx_opm_asig_gi_prod_res_org
        WHERE legal_entity_id = p_legal_entity_id
          AND period_id       = p_period_id;

       DELETE FROM xx_opm_asig_gi_sumgl_res_org
        WHERE legal_entity_id = p_legal_entity_id
          AND period_id       = p_period_id;

     END IF; --IF v_period_status = 'O' THEN

     BEGIN
       SELECT COUNT(1)
         INTO v_count_res_org
         FROM xx_opm_asig_gi_resource_org
        WHERE legal_entity_id = p_legal_entity_id
          AND period_id       = p_period_id;
     EXCEPTION WHEN OTHERS THEN
        v_error_code := 'GLB_MAIN_000';
        v_error_details := 'General Error searching count record in xx_opm_asig_gi_resource_org ' || sqlerrm;
        RAISE e_validate_error;
     END;

     IF v_count_res_org = 0 THEN  -- Si periodo es Open fue borrado previamente. Si periodo es Closed o Frozen y nunca fue ejecutado.

       g_Time_Before := DBMS_UTILITY.GET_TIME;

       -- Cycle 1 - Load Resorces by Org Code
       FOR l_reg IN c_cur_opm_res_by_org LOOP

           BEGIN
             INSERT INTO xx_opm_asig_gi_resource_org
               ( legal_entity_id
               , legal_entity_name
               , period_id
               , period_code
               , period_status
               , organization_code
               , organization_id
               , item_code
               , description
               , inventory_item_id
               , calendar_code
               , cost_mthd_code
               , resources
               , comp_cost
               , an_cod
               , burden_qty
               , burden_usage
               , burden_uom
               , item_qty
               , item_uom
               , cost
               , produc
               , calc_prod_usage
               , request_id
               , creation_date
               , created_by
               , last_update_date
               , last_updated_by
               , last_update_login
               )
             VALUES
               ( l_reg.legal_entity_id
               , v_legal_entity_name
               , l_reg.period_id
               , l_reg.period_code
               , l_reg.period_status
               , l_reg.organization_code
               , l_reg.organization_id
               , l_reg.item_code
               , l_reg.description
               , l_reg.inventory_item_id
               , l_reg.calendar_code
               , l_reg.cost_mthd_code
               , l_reg.resources
               , l_reg.comp_cost
               , l_reg.an_cod
               , l_reg.burden_qty
               , l_reg.burden_usage
               , l_reg.burden_uom
               , l_reg.item_qty
               , l_reg.item_uom
               , l_reg.cost
               , l_reg.produc
               , l_reg.burden_usage * l_reg.produc -- calc_prod_usage
               , g_conc_request_id                 -- request_id
               , SYSDATE                           -- creation_date
               , g_user_id                         -- created_by
               , SYSDATE                           -- last_update_date
               , g_user_id                         -- last_updated_by
               , g_login_id                        -- last_update_login
               );
           EXCEPTION WHEN OTHERS THEN
              v_error_code := 'GLB_MAIN_003';
              v_error_details := 'General Error inserting in xx_opm_asig_gi_resource_org ' || sqlerrm;
              RAISE e_validate_error;
           END;
       --
       END LOOP;

       -- Cycle 1 - Load SUM lines has been processed for Resorces by Org Code
       FOR l_reg IN c_cur_prod_res_by_org LOOP
           BEGIN
             INSERT INTO xx_opm_asig_gi_prod_res_org
               ( legal_entity_id
               , legal_entity_name
               , period_id
               , period_code
               , period_status
               , organization_code
               , organization_id
               , calendar_code
               , cost_mthd_code
               , resources
               , comp_cost
               , sum_prod_usage
               , request_id
               , creation_date
               , created_by
               , last_update_date
               , last_updated_by
               , last_update_login
               )
             VALUES
               ( l_reg.legal_entity_id
               , v_legal_entity_name
               , l_reg.period_id
               , l_reg.period_code
               , l_reg.period_status
               , l_reg.organization_code
               , l_reg.organization_id
               , l_reg.calendar_code
               , l_reg.cost_mthd_code
               , l_reg.resources
               , l_reg.comp_cost
               , l_reg.sum_prod_usage              -- sum_prod_usage
               , g_conc_request_id                 -- request_id
               , SYSDATE                           -- creation_date
               , g_user_id                         -- created_by
               , SYSDATE                           -- last_update_date
               , g_user_id                         -- last_updated_by
               , g_login_id                        -- last_update_login
               );
           EXCEPTION WHEN OTHERS THEN
              v_error_code := 'GLB_MAIN_004';
              v_error_details := 'General Error inserting in xx_opm_asig_gi_prod_res_org ' || sqlerrm;
              RAISE e_validate_error;
           END;
       --
         v_acum_gl_amount_org_rec := 0;

         FOR l_reg_gl IN c_cur_gl_res_by_org (l_reg.organization_id, l_reg.resources) LOOP
           BEGIN

               BEGIN
                 SELECT NVL(SUM(NVL(gjl.accounted_dr,0)),0) accounted_dr
                      , NVL(SUM(NVL(gjl.accounted_cr,0)),0) accounted_cr
                   INTO v_sum_accounted_dr
                      , v_sum_accounted_cr
                   FROM gl_je_lines   gjl
                  WHERE EXISTS (SELECT 1
                                  FROM gl_je_headers gjh
                                 WHERE gjh.ledger_id   = p_ledger_id
                                   AND gjh.period_name = p_gl_period
                                   AND gjh.status      = 'P'
                                   AND gjh.je_header_id = gjl.je_header_id
                               )
                    AND gjl.code_combination_id = l_reg_gl.code_combination_id;
               EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                   v_sum_accounted_dr := 0;
                   v_sum_accounted_cr := 0;
                 WHEN OTHERS THEN
                   v_error_code := 'GLB_MAIN_005-A';
                   v_error_details := 'General Error searching sum_gl_amount for code_combination_id= ' || l_reg_gl.code_combination_id || sqlerrm;
                   RAISE e_validate_error;
               END;

             v_sum_gl_amount := ((v_sum_accounted_dr - v_sum_accounted_cr) + NVL(l_reg_gl.ajuste,0)) * (1 - NVL(l_reg_gl.ociosidad,0) / 100);
             v_acum_gl_amount_org_rec := v_acum_gl_amount_org_rec + v_sum_gl_amount;

             INSERT INTO xx_opm_asig_gi_sumgl_res_org
               ( legal_entity_id
               , legal_entity_name
               , period_id
               , period_code
               , period_status
               , organization_code
               , organization_id
               , resources
               , chart_of_accounts_id
               , period_gl_code
               , ledger_id
               , sum_gl_amount
               , sum_accounted_dr
               , sum_accounted_cr
               , config_orden
               , config_ociosidad
               , config_ajuste
               , segment1
               , segment2
               , unidad_negocio
               , producto
               , unidad_prod
               , centro_costo
               , proyecto
               , intercompany
               , concatenated_segments
               , code_combination_id
               , request_id
               , creation_date
               , created_by
               , last_update_date
               , last_updated_by
               , last_update_login
               )
             VALUES
               ( l_reg.legal_entity_id
               , v_legal_entity_name
               , l_reg.period_id
               , l_reg.period_code
               , l_reg.period_status
               , l_reg.organization_code
               , l_reg.organization_id
               , l_reg.resources
               , l_reg_gl.chart_of_accounts_id
               , p_gl_period
               , p_ledger_id
               , v_sum_gl_amount
               , v_sum_accounted_dr
               , v_sum_accounted_cr
               , l_reg_gl.orden
               , l_reg_gl.ociosidad
               , l_reg_gl.ajuste
               , l_reg_gl.segment1
               , l_reg_gl.segment2
               , l_reg_gl.unidad_negocio
               , l_reg_gl.producto
               , l_reg_gl.unidad_prod
               , l_reg_gl.centro_costo
               , l_reg_gl.proyecto
               , l_reg_gl.intercompany
               , l_reg_gl.concatenated_segments
               , l_reg_gl.code_combination_id
               , g_conc_request_id                 -- request_id
               , SYSDATE                           -- creation_date
               , g_user_id                         -- created_by
               , SYSDATE                           -- last_update_date
               , g_user_id                         -- last_updated_by
               , g_login_id                        -- last_update_login
               );
           EXCEPTION WHEN OTHERS THEN
              v_error_code := 'GLB_MAIN_005-B';
              v_error_details := 'General Error inserting in xx_opm_asig_gi_sumgl_res_org ' || sqlerrm;
              RAISE e_validate_error;
           END;
         END LOOP;

         IF l_reg.sum_prod_usage != 0 THEN
           v_new_res_cost := ROUND(v_acum_gl_amount_org_rec / l_reg.sum_prod_usage,9);
         ELSE
           v_new_res_cost := NULL;
         END IF;

         UPDATE xx_opm_asig_gi_prod_res_org
            SET sum_gl_amount  = v_acum_gl_amount_org_rec
              , resource_cost  = v_new_res_cost
              , period_gl_code = p_gl_period
              , ledger_id      = p_ledger_id
          WHERE legal_entity_id = p_legal_entity_id
            AND period_id       = p_period_id
            AND organization_id = l_reg.organization_id
            AND resources       = l_reg.resources;

         --El proceso de cálculo y actualización solo se ejecuta sobre períodos “Abiertos”
         IF v_period_status = 'O' and p_update_res_cost = 'Y' THEN

           BEGIN
             SELECT 'Y'
                  , nominal_cost
                  , delete_mark
               INTO v_flag_res_cost
                  , v_nominal_cost
                  , v_delete_mark
               FROM CM_RSRC_DTL
              WHERE PERIOD_ID = p_period_id
                AND RESOURCES = l_reg.resources
                AND ORGANIZATION_ID = l_reg.organization_id
                AND LEGAL_ENTITY_ID = p_legal_entity_id;

             IF v_delete_mark = 1 THEN
               v_err_stage := '  No es posible actualizar costo porque está marcado para purga el Recurso ==> ' ||l_reg.resources
                              || ' en Organizacion = '||l_reg.organization_code
                              ||' - period = '|| l_reg.period_code;
               debug_print (g_Debug, v_err_stage);
             ELSE
               IF l_reg.sum_prod_usage = 0 THEN
                 v_err_stage := '  No es posible actualizar costo porque la suma de litros prod es 0 para el Recurso ==> ' ||l_reg.resources
                                || ' en Organizacion = '||l_reg.organization_code
                                ||' - period = '|| l_reg.period_code;
                 debug_print (g_Debug, v_err_stage);
               ELSE
                 UPDATE CM_RSRC_DTL
                    SET nominal_cost      = v_new_res_cost
                      , last_update_date  = SYSDATE
                      , last_updated_by   = g_user_id
                      , last_update_login = g_login_id
                  WHERE PERIOD_ID = p_period_id
                    AND RESOURCES = l_reg.resources
                    AND ORGANIZATION_ID = l_reg.organization_id
                    AND LEGAL_ENTITY_ID = p_legal_entity_id;
                 v_err_stage := '  Actualizacion costo Recurso ==> ' ||l_reg.resources
                                || ' en Organizacion = '||l_reg.organization_code
                                ||' - period = '|| l_reg.period_code
                                ||' - costo anterior = '|| v_nominal_cost
                                ||' - costo nuevo = '|| v_new_res_cost;
                 debug_print (g_Debug, v_err_stage);
               END IF;
             END IF;

           EXCEPTION
             WHEN NO_DATA_FOUND THEN
               v_err_stage := '  Falla Actualizacion porque no existe Recurso ==> ' ||l_reg.resources
                              || ' en Organizacion = '||l_reg.organization_code
                              ||' - period = '|| l_reg.period_code;
               debug_print (g_Debug, v_err_stage);
             WHEN OTHERS THEN
                v_error_code := 'GLB_MAIN_006';
                v_error_details := 'General Error updating in CM_RSRC_DTL ' || sqlerrm;
             RAISE e_validate_error;
           END;

         END IF;
       --
       END LOOP;
     --
     END IF; --IF v_count_res_org = 0 THEN

     IF g_retcode != '0' THEN
       v_err_stage := '  Errors in '||C_REPORT_NAME;
       debug_print (g_Debug, v_err_stage);
       ROLLBACK;
     ELSE
       v_err_stage := '  '||C_REPORT_NAME||' have been succesfully processed';
       debug_print (g_Debug, v_err_stage);
       COMMIT;
     END IF;

     v_err_stage := '==============================================================================';
     debug_print (g_Debug, v_err_stage);

     retcode := g_retcode;

   EXCEPTION
     WHEN e_validate_error THEN
       ROLLBACK;
       debug_print (g_Debug, '   '||v_error_code ||' - ' ||v_error_details);
       g_retcode := '1';
       v_err_stage := '==============================================================================';
       debug_print (g_Debug, v_err_stage);
       retcode := g_retcode;
     WHEN OTHERS THEN
       raise_application_error(-20001, 'Error in Load_Costs. ' || SUBSTR (SQLERRM, 1, 100));
       g_retcode := '2';
       retcode := g_retcode;
   END Principal;

   PROCEDURE delete_adj  ( errbuf                 OUT  VARCHAR2
                         , retcode                OUT  VARCHAR2
                         , p_organization_id      IN  NUMBER
                         , p_legal_entity_id      IN  NUMBER
                         , p_Debug                IN  VARCHAR2
                         )

    IS
      -- Local  Variables
      v_error_details       VARCHAR2 (4000);
      v_error_code          VARCHAR2 (30);
      v_err_stage           VARCHAR2 (4000);
      e_validate_error      EXCEPTION;

      v_legal_entity_name   VARCHAR2(240);

   BEGIN
     g_Debug := p_Debug;
     --
     BEGIN
       SELECT glcd.object_name
         INTO v_legal_entity_name
         FROM gl_ledger_config_details glcd
        WHERE glcd.object_type_code = 'LEGAL_ENTITY'
          AND glcd.object_id        = p_legal_entity_id;
     EXCEPTION WHEN OTHERS THEN
        v_error_code := 'GLB_MAIN_001';
        v_error_details := 'General Error for to get legal entity name ' || sqlerrm;
        RAISE e_validate_error;
     END;
     --
     --
     v_err_stage := '==============================================================================';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := 'Parameters';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Program                     ==> ' ||C_REPORT_DEL_NAME;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Concurrent                  ==> ' ||g_conc_request_id;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  User                        ==> ' ||g_user_name;
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Date                        ==> ' ||TO_CHAR(SYSDATE,'DD-MM-YYYY HH24:mm:ss');
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '  Legal Entity                ==> ' ||v_legal_entity_name|| '(ID='||p_legal_entity_id||')';
     debug_print (g_Debug, v_err_stage);
     v_err_stage := '==============================================================================';
     debug_print (g_Debug, v_err_stage);


     DELETE FROM xx_opm_conf_gi_ajustes_cc xx_aju
      WHERE EXISTS (SELECT 1
                      FROM xx_opm_conf_gi_columnas_hdr xx_col_h
                     WHERE xx_col_h.gi_columna_id = xx_aju.gi_columna_id
                       AND xx_col_h.legal_entity_id = p_legal_entity_id
                   );

     IF g_retcode != '0' THEN
       v_err_stage := '  Errors in ||C_REPORT_DEL_NAME';
       debug_print (g_Debug, v_err_stage);
       ROLLBACK;
     ELSE
       v_err_stage := '  '||C_REPORT_DEL_NAME||' have been succesfully processed';
       debug_print (g_Debug, v_err_stage);
       COMMIT;
     END IF;

     v_err_stage := '==============================================================================';
     debug_print (g_Debug, v_err_stage);

     retcode := g_retcode;

   EXCEPTION
     WHEN e_validate_error THEN
       ROLLBACK;
       debug_print (g_Debug, '   '||v_error_code ||' - ' ||v_error_details);
       g_retcode := '1';
       v_err_stage := '==============================================================================';
       debug_print (g_Debug, v_err_stage);
       retcode := g_retcode;
     WHEN OTHERS THEN
       raise_application_error(-20001, 'Error in Load_Costs. ' || SUBSTR (SQLERRM, 1, 100));
       g_retcode := '2';
       retcode := g_retcode;
   END delete_adj;

END XX_OPM_PROC_GI_PK;
/

exit
