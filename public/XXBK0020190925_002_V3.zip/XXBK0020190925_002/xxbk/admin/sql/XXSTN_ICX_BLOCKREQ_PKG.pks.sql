REM $Header: XXSTN_ICX_BLOCKREQ_PKG.pks.sql 12.0.0.1 2019/07/16 19:55:08 lcarmo noship $
REM ****************************************************************************
REM   File    : XXSTN_ICX_BLOCKREQ_PKG.pks.sql
REM   Propose : This is the package Spec for XXSTN_ICX_BLOCKREQ_PKG
REM   Author  : lcarmo
REM   Date    : 08-18-2019
REM  
REM   History
REM   Version  |Date       |Author        | Desc
REM   --------------------------------------------------------------------------
REM   1.0      |08-18-2019 |lcarmo        | Initial
REM ****************************************************************************
SET FEEDBACK ON
SET ECHO OFF
SET VERIFY OFF

WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

CREATE OR REPLACE PACKAGE XXSTN_ICX_BLOCKREQ_PKG IS

  /****************************************************************************
   validate_item -
   ***************************************************************************/
  PROCEDURE check_requisition(p_reqHeaderId IN VARCHAR2, p_status OUT VARCHAR2, p_message OUT VARCHAR2);

END XXSTN_ICX_BLOCKREQ_PKG;
/

SHOW ERRORS

EXIT;

