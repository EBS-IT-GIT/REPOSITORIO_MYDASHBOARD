---------------------------------------------------------------------------
-- +===================================================================+ --
-- |                     TRI Consulting - Brasil                       | --
-- |                       All rights reserved.                        | --
-- +===================================================================+ --
-- |  # Nro. SR :      120_XXCLKENH_002                                | --
-- |  # Descrição SR:  Melhorias Integracao COMLINK x EBS              | --
-- |  # Versão:        1.0                                             | --
-- |  # Data:          08-NOV-2019                                     | --
-- |  # Autor:         Joao Adami                                      | --
-- +===================================================================+ --

---------------------------------------------------------------------------
###### 1. Pré-Instalação:                                            ######
---------------------------------------------------------------------------
 # Verificar se possui todos os acessos/permissoes para aplicacao deste patch;
 # Certificar-se que a aplicacao xxclk esta criada (aplicativo, db e unix);
 # Certificar que possui as senhas dos users de BANCO: APPS;
 # Realizar backup dos arquivos que serao sobrepostos (caso existam).
 # Certificar que o patch do COMLINK criando os novos campos ja foi aplicado no ambiente.

---------------------------------------------------------------------------
###### 2. Instalação:                                                ######
---------------------------------------------------------------------------
1) Copie o arquivo 120_XXCLKENH_002.zip para $PATCH_TOP

2) Faça a extração do arquivo

	$ cd $PATCH_TOP
	$ unzip 120_XXCLKENH_002.zip
	$ cd 120_XXCLKENH_002

  2.1) O patch deve ser aplicado de forma manual

    Execute os comandos abaixo no UNIX

				# Copia dos arquivos
				-- 
				cp -f xxclk/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb $XXCLK_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb

				Set the NLS_LANG variable before start adop application patch
				export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"
				
				# APPS objects
				-- 
				sqlplus apps/$apps_pass @$XXCLK_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb

---------------------------------------------------------------------------
###### 3. Passos Pós-instalação:                                     ######
---------------------------------------------------------------------------

1) NA

# *** Fim da Aplicação ***
# *** Verifique TODOS os logs para assegurar que o patch foi aplicado corretamente ***