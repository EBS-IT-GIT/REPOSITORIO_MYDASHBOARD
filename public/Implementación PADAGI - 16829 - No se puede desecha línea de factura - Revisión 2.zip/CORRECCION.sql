UPDATE apps.ap_invoice_lines_all
SET    item_description = description
WHERE  invoice_id = 6291783
AND    line_number = 1;