#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2073_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2073
# |
# | HISTORY
# |   19-NOV-19  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2073_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2073_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2073
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2073/CR2073_20191119"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=DESA12

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/RESPO
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/RESPO
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT
svn up /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2073" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2073_13416.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2073"
AddAllLogs $CROUT "FND" "CR2073_13416.ldt"
mv CR2073_13416.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_AR_OM_CONSULTA_CREDITO " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='LATIN AMERICAN SPANISH'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_AR_OM_CONSULTA_CREDITO.ldt MENU MENU_NAME="XX_AR_OM_CONSULTA_CREDITO"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XX_AR_OM_CONSULTA_CREDITO.ldt"
mv XX_AR_OM_CONSULTA_CREDITO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_AR_AR_COBRANZAS " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='LATIN AMERICAN SPANISH'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_AR_AR_COBRANZAS.ldt MENU MENU_NAME="XX_AR_AR_COBRANZAS"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XX_AR_AR_COBRANZAS.ldt"
mv XX_AR_AR_COBRANZAS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_OM_CREDITO " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='LATIN AMERICAN SPANISH'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_OM_CREDITO.ldt MENU MENU_NAME="XX_OM_CREDITO"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XX_OM_CREDITO.ldt"
mv XX_OM_CREDITO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-RESPO PIL_OM_CONSULTA_CRED_ARG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscursp.lct PIL_OM_CONSULTA_CRED_ARG.ldt FND_RESPONSIBILITY RESP_KEY="PIL_OM_CONSULTA_CRED_ARG"
AddAllLogs $CROUT "FND" "PIL_OM_CONSULTA_CRED_ARG.ldt"
mv PIL_OM_CONSULTA_CRED_ARG.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/RESPO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-RESPO XX_AR_OM_L3N_CONSULTA_CREDITO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afscursp.lct XX_AR_OM_L3N_CONSULTA_CREDITO.ldt FND_RESPONSIBILITY RESP_KEY="XX_AR_OM_L3N_CONSULTA_CREDITO"
AddAllLogs $CROUT "FND" "XX_AR_OM_L3N_CONSULTA_CREDITO.ldt"
mv XX_AR_OM_L3N_CONSULTA_CREDITO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/RESPO


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
