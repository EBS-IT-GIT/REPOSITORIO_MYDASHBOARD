  set define off;
insert into XX_TCG_IIBB_SALDO_INI_HIS (select 'JUN-20',  A.* from xx_tcg_iibb_saldo_ini A);
insert into XX_TCG_IIBB_ORIGEN_HIS (select 'JUN-20',  A.* from XX_TCG_IIBB_ORIGEN A);
commit;


exit
