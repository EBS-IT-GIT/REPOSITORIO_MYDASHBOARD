  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_IIBB_PROCESO_CEREAL_PK" AUTHID CURRENT_USER AS

   PROCEDURE Actualiza_Saldo ( p_periodo         VARCHAR2
                            , p_status          VARCHAR2 DEFAULT 'PRELIMINAR' --PRELIMINAR / FINAL
                            , x_error_msg   OUT VARCHAR2
                            );


  PROCEDURE Procesa_CPS_Origen_IIBB ( p_periodo         VARCHAR2
                                    , x_error_msg   OUT VARCHAR2
                                    );


/**************************************************************************+
| Public Procedure                                                         |
|    XX_AR_IIBB_PRINCIPAL                                                  |
|                                                                          |
| Description                                                              |
|    ejecuta el concurrente                                                |
| Parameters                                                               |
|    errbuf       OUT     VARCHAR2 Uso interno del concurrente.            |
|    retcode      OUT     VARCHAR2 Uso interno del concurrente.            |
|    p_logica     IN      VARCHAR2 L?gica a aplicar                        |
|    p_tipo_proc  IN      VARCHAR2 Tipo de procesamiento del concurrente   |
|    p_periodo    IN      VARCHAR2 Periodo de GL para filtrar las trx      |
|                                                                          |                                                         |          |
+***************************************************************************/

PROCEDURE XX_AR_IIBB_PRINCIPAL ( errbuf            OUT         VARCHAR2
                               , retcode           OUT         NUMBER
                               , p_periodo_fiscal  IN          VARCHAR2
                               , p_periodo         IN          VARCHAR2
                               , p_logica          IN          VARCHAR2
                               , p_tipo_proc       IN          VARCHAR2
                               , p_msgerr          IN  OUT     VARCHAR2
                                , p_factura          in varchar default null
                               );

procedure  Recalculo_CP_Origen ( errbuf                   IN OUT VARCHAR
                                        , errcode                  IN OUT NUMBER
                                       , p_periodo in VARCHAR2);


END XX_AR_IIBB_PROCESO_CEREAL_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_IIBB_PROCESO_CEREAL_PK" AS
G_REQUEST_ID NUMBER;
  g_precision              NUMBER := 5;
  g_org_id_ingreso number(3) := 102; --  Es organización fija para la cabecera de 'INGRESO' .

  g_header_id              NUMBER;
  g_hdr_id_otros           NUMBER;
  g_hdr_id_propio          NUMBER;
  g_hdr_id_tercero         NUMBER;
  g_fecha_ini              date;
  g_fecha_fin              date;

-- registro para informacion cabecera factura
  TYPE fac_rec IS RECORD
  ( trx_id                     ra_customer_trx.customer_trx_id%type,
    trx_number                 ra_customer_trx.trx_number%type,
    trx_date                   ra_customer_trx.trx_date%type,
    customer_name              ra_customers.customer_name%type,
    customer_id                ra_customers.customer_id%type,
    xx_ar_tipo_pedido_om       ra_customer_trx_all_dfv.xx_ar_tipo_pedido_om%type,
    xx_ar_nro_pedido_om        ra_customer_trx_all_dfv.xx_ar_nro_pedido_om%type,
    exchange_rate              ra_customer_trx.exchange_rate%type,
    org_id                     ra_customer_trx.org_id%type,
    pcia_destino_fc            hz_geographies.geography_name%type,
    tipo_trx                   varchar2(10),
    tipo_liq                   varchar2(30),
    cant_lineas                number, --  El nro de linea que se esta tratando
    tipo_recla_final           varchar2(1) , -- 'H' para historicas, 'A' , para con anticiplo , ''X' PARA FINALES SIN reclasificar
    mezcla_recla_final         varchar2(1) , -- 'S' para historicas,null
    reclasifica_final          number(1),   -- Marca que identifica con 1 si la liquidacion final corresponde que reclasifique . Se hace solo en el 1er regitstro y cuando tiene informacion de la parcial
    esinterco                  boolean,
    trx_final                  number,
    ship_to_customer_id        number
  );

  g_fac_rec                    fac_rec;
  g_empty_fac_rec              fac_rec;
  g_fac_rev                    fac_rec;

  -- registro para tabla de CP de salida
  TYPE TipoCPSalRec IS RECORD
  ( numero_carta_porte         xx_tcg_cartas_porte.numero_carta_porte%type, -- carta de porte de salida
    carta_porte_id             xx_tcg_cartas_porte.carta_porte_id%type,  -- carta de porte de salida
    nro_pedido                 oe_order_headers.order_number%type,
    tipo_pedido                oe_transaction_types.name%type,
    cant_adar_origen           number,
    pcia_destino_cp            hz_geographies.geography_name%type);

    g_empty_SqlRec         TipoCPSalRec;


 TYPE TipoTablaCP IS TABLE OF TipoCPSalRec INDEX BY BINARY_INTEGER ;
 g_tab_CPSal               TipoTablaCP;



-- registro para informacion linea factura
  TYPE lin_art_rec IS RECORD
  ( trx_line_id                       ra_customer_trx_lines.customer_trx_line_id%type,
    line_number                       ra_customer_trx_lines.line_number%type,
    item_desc                         ra_customer_trx_lines.description%type,
    quantity_invoiced                 ra_customer_trx_lines.quantity_invoiced%type,
    quantity_credited                 ra_customer_trx_lines.quantity_credited%type,
    unit_selling_price                ra_customer_trx_lines.unit_selling_price%type,
    uom_code                          ra_customer_trx_lines.uom_code%type,
    extended_amount                   ra_customer_trx_lines.extended_amount%type,
    memo_line_id                      ra_customer_trx_lines.memo_line_id%type,
    item_id                           ra_customer_trx_lines.inventory_item_id%type,
    pedido_num                        ra_customer_trx_lines.interface_line_attribute1%type,
    pedido_tipo                       ra_customer_trx_lines.interface_line_attribute2%type,
    categ_seg_concat                  VARCHAR2(100),
    org_id                            hr_organization_information.org_information3%type,
    pcia_origen_fc                    hz_geographies.geography_name%type,
    pcia_origen_pv                    hz_geographies.geography_name%type,
    primary_uom_code                  mtl_system_items_vl.primary_uom_code%type,
    cant_a_consumir                   number,
    origen_mercaderia                 varchar2(10),
    dto_COMERCIAL                     number,
    conpedido                         number,
    factor_conver_um                  number,
    consume_origen                    number(1),
    tipo_operacion                    varchar2(1),
    order_type_id                     number,
    xx_aco_codigo_oncca               varchar2(20),
    tab_CP_Sal                        TipoTablaCP
  );

  g_lin_art_rec                   lin_art_rec;
  g_empty_lin_art_rec             lin_art_rec;
  g_lin_art_rev                   lin_art_rec;

  g_error_flag     boolean := FALSE;
  g_error_msg      varchar2(2000);

    function update_inf_source (x_periodo        IN  VARCHAR2
                                            ,x_error          OUT VARCHAR2
                                          ) return boolean;
 function Concu_en_proceso(p_executable_name in varchar2) return number is
 l_concu number;
 begin
        SELECT  count(1) into l_concu
        FROM    fnd_concurrent_requests req,
                fnd_concurrent_programs prog,
                fnd_executables exe
        WHERE   req.program_application_id = prog.application_id
          AND   req.concurrent_program_id = prog.concurrent_program_id
          AND   req.phase_code = 'R'
         AND    req.request_id <> G_REQUEST_ID
          AND   prog.executable_application_id = exe.application_id
          AND   prog.executable_id = exe.executable_id
          AND   exe.executable_name = p_executable_name;
          return l_concu;
end   Concu_en_proceso;

  -- ---------------------------------------------------------------------------
  --
  -- PROCEDURE: DEBUG
  -- DESCRIPCION:
  --
  -- ---------------------------------------------------------------------------
  PROCEDURE debug ( p_message IN VARCHAR2
                  , p_indent  IN NUMBER DEFAULT 2
                  ) IS
    l_blanks  VARCHAR2(250);
    l_indent  NUMBER;
    l_osuser  varchar2(10);
  BEGIN
    l_indent := p_indent;

    IF l_indent > 250 THEN
      l_indent := 250;
    END IF;

    SELECT lpad(' ', l_indent, ' ')
    INTO l_blanks
    FROM DUAL ;

  select osuser into l_osuser from v$session where audsid = userenv('SESSIONID');
  if l_osuser = 'irosas' then
    dbms_output.put_line (l_blanks || p_message);
   else
    xx_debug_pk.debug(l_blanks || p_message);
    end if;

  END;



  PROCEDURE Actualiza_Saldo ( p_periodo         VARCHAR2
                            , p_status          VARCHAR2 DEFAULT 'PRELIMINAR' --PRELIMINAR / FINAL
                            , x_error_msg   OUT VARCHAR2
                            ) IS
    l_dummy  NUMBER;
    eError   EXCEPTION;
  BEGIN
    IF p_status NOT IN ('PRELIMINAR', 'FINAL') THEN
      x_error_msg := 'El estado debe ser PRELIMINAR o FINAL';
      RAISE eError;
    END IF;

    SELECT count(1)
    INTO l_dummy
    FROM xx_tcg_iibb_saldo_ini
    WHERE acct_period = p_periodo
    AND status = 'FINAL';

    IF l_dummy > 0 THEN
      x_error_msg := 'El saldo para el periodo '||p_periodo||' ya se encuentra en estado Final.';
      RAISE eError;
    END IF;

    SELECT count(1)
    INTO l_dummy
    FROM xx_tcg_iibb_saldo_ini
    WHERE acct_period = p_periodo
    AND status = 'PRELIMINAR'
    AND used_quantity != 0;

    IF l_dummy > 0 THEN
      x_error_msg := 'No es posible recrear el saldo para el periodo '||p_periodo||' ya que el mismo ya fue asignado a CPs de origen.';
      RAISE eError;
    END IF;

    INSERT INTO XX_TCG_IIBB_SALDO_INI
    SELECT MAX(mi.transaction_id) transaction_id, mi.carta_porte_id, mi.numero_carta_porte, mi.inventory_item_id
         , mi.transaction_source_type_id
         , mi.transaction_type_id
         , mi.transaction_action_id
         , mi.reason_id
         , mi.lot_number
         , mi.acct_period
         , mi.operating_unit, mi.organization_id, mi.subinventory_code, mi.locator_id
         , mi.transfer_operating_unit, mi.transfer_organization_id, mi.transfer_subinventory, mi.transfer_locator_id
         , mi.owning_operating_unit, mi.owning_organization_id
         , mi.xfr_owning_organization_id
         , mis.transaction_quantity
         , 0, 'PRELIMINAR'
         , mi.item_oncca_iibb
    FROM xx_tcg_movimiento_inventario_v mi
       , ( SELECT mip.carta_porte_id, mip.inventory_item_id, mip.lot_number, mip.acct_period, mip.organization_id, mip.subinventory_code, mip.locator_id
                , mip.transfer_organization_id, mip.transfer_subinventory, mip.transfer_locator_id
                , SUM(mip.transaction_quantity) transaction_quantity
           FROM xx_tcg_movimiento_inventario_v mip
              , ( SELECT DISTINCT carta_porte_id
                  FROM xx_tcg_movimiento_inventario_v
                  WHERE 1=1
                  AND acct_period = p_periodo
                  AND tipo_movimiento LIKE 'R%'
                ) mipc
           WHERE 1=1
           AND mipc.carta_porte_id = mip.carta_porte_id
           AND mip.transaction_source_type = 'Inventory'
           AND mip.tipo_movimiento LIKE 'R%'
           AND mip.lot_number NOT LIKE '%T'
           AND mip.reason_code NOT IN ('AJME', 'AJDP')
           AND NOT EXISTS (SELECT 1 FROM xx_tcg_cartas_porte_all cp WHERE cp.carta_porte_id = mip.carta_porte_id AND cp.anulado_flag = 'Y')
           AND NOT EXISTS (SELECT 1 FROM xx_tcg_iibb_saldo_ini si
                           WHERE si.carta_porte_id = mipc.carta_porte_id
                          )
           GROUP BY mip.carta_porte_id, mip.inventory_item_id, mip.lot_number, mip.acct_period, mip.organization_id, mip.subinventory_code, mip.locator_id
                  , mip.transfer_organization_id, mip.transfer_subinventory, mip.transfer_locator_id
           HAVING SUM(mip.transaction_quantity) > 0
         ) mis
    WHERE 1=1
    AND mis.carta_porte_id       = mi.carta_porte_id
    AND mis.inventory_item_id    = mi.inventory_item_id
    AND mis.lot_number           = mi.lot_number
    AND mis.acct_period          = mi.acct_period
    AND mis.organization_id      = mi.organization_id
    AND mis.subinventory_code    = mi.subinventory_code
    AND mis.locator_id           = mi.locator_id
    AND mis.transaction_quantity = mi.transaction_quantity
    AND mis.transfer_organization_id = mi.transfer_organization_id
    AND mis.transfer_subinventory    = mi.transfer_subinventory
    AND mis.transfer_locator_id      = mi.transfer_locator_id
    AND mis.acct_period          = p_periodo
    AND NOT EXISTS ( SELECT 1 FROM xx_tcg_iibb_saldo_ini WHERE carta_porte_id = mi.carta_porte_id )
    GROUP BY mi.carta_porte_id, mi.numero_carta_porte,  mi.item_oncca_iibb, mi.inventory_item_id  -- SD1166
         , mi.transaction_source_type_id
         , mi.transaction_type_id
         , mi.transaction_action_id
         , mi.reason_id
         , mi.lot_number
         , mi.acct_period
         , mi.operating_unit, mi.organization_id, mi.subinventory_code, mi.locator_id
         , mi.transfer_operating_unit, mi.transfer_organization_id, mi.transfer_subinventory, mi.transfer_locator_id
         , mi.owning_operating_unit, mi.owning_organization_id
         , mi.xfr_owning_organization_id
         , mis.transaction_quantity
    UNION --SD1166
    SELECT MAX(mi.transaction_id) transaction_id, mi.carta_porte_id, mi.numero_carta_porte, mi.inventory_item_id
         , mi.transaction_source_type_id
         , mi.transaction_type_id
         , mi.transaction_action_id
         , mi.reason_id
         , REPLACE(mi.lot_number,'T','') lot_number
         , mi.acct_period
         , mi.operating_unit, mi.organization_id, mi.subinventory_code, mi.locator_id
         , mi.transfer_operating_unit, mi.transfer_organization_id, mi.transfer_subinventory, mi.transfer_locator_id
         , mi.owning_operating_unit, mi.owning_organization_id
         , mi.xfr_owning_organization_id
         , mis.transaction_quantity
         , 0, 'PRELIMINAR'
         , mi.item_oncca_iibb
    FROM xx_tcg_movimiento_inventario_v mi
       , ( SELECT mip.carta_porte_id, mip.inventory_item_id, mip.lot_number, mip.acct_period, mip.organization_id, mip.subinventory_code, mip.locator_id
                , mip.transfer_organization_id, mip.transfer_subinventory, mip.transfer_locator_id
                , SUM(mip.transaction_quantity) transaction_quantity
           FROM xx_tcg_movimiento_inventario_v mip
              , ( SELECT DISTINCT carta_porte_id
                  FROM xx_tcg_movimiento_inventario_v
                  WHERE 1=1
                  AND acct_period = p_periodo
                  AND tipo_movimiento LIKE 'R%'
                ) mipc
           WHERE 1=1
           AND mipc.carta_porte_id = mip.carta_porte_id
           AND mip.transaction_source_type = 'Inventory'
           AND mip.tipo_movimiento LIKE 'R%'
           AND mip.lot_number LIKE '%T'
           AND mip.reason_code NOT IN ('AJME', 'AJDP')
           AND EXISTS (SELECT 1
                       FROM xx_tcg_cartas_porte_all cp
                          , xx_tcg_contratos_compra cc
                       WHERE 1=1
                       AND cp.carta_porte_id = mip.carta_porte_id
                       AND ( cp.intermediario_contrato_id = cc.contrato_id OR
                             cp.rtte_comercial_contrato_id = cc.contrato_id OR
                             cp.destinatario_contrato_id = cc.contrato_id
                           )
                       AND cc.tipo_contrato = 'COMPRA'
                      )
           AND NOT EXISTS (SELECT 1 FROM xx_tcg_cartas_porte_all cp WHERE cp.carta_porte_id = mip.carta_porte_id AND cp.anulado_flag = 'Y')
           AND NOT EXISTS (SELECT 1 FROM xx_tcg_iibb_saldo_ini si
                           WHERE si.carta_porte_id = mipc.carta_porte_id
                          )
           GROUP BY mip.carta_porte_id, mip.inventory_item_id, mip.lot_number, mip.acct_period, mip.organization_id, mip.subinventory_code, mip.locator_id
                  , mip.transfer_organization_id, mip.transfer_subinventory, mip.transfer_locator_id
           HAVING SUM(mip.transaction_quantity) > 0
         ) mis
    WHERE 1=1
    AND mis.carta_porte_id       = mi.carta_porte_id
    AND mis.inventory_item_id    = mi.inventory_item_id
    AND mis.lot_number           = mi.lot_number
    AND mis.acct_period          = mi.acct_period
    AND mis.organization_id      = mi.organization_id
    AND mis.subinventory_code    = mi.subinventory_code
    AND mis.locator_id           = mi.locator_id
    AND mis.transaction_quantity = mi.transaction_quantity
    -- AND mis.transfer_organization_id = mi.transfer_organization_id     Comentado por Lalo
    --AND mis.transfer_subinventory    = mi.transfer_subinventory
    --AND mis.transfer_locator_id      = mi.transfer_locator_id
    AND mis.acct_period          = p_periodo
    AND NOT EXISTS ( SELECT 1 FROM xx_tcg_iibb_saldo_ini WHERE carta_porte_id = mi.carta_porte_id )
    GROUP BY mi.carta_porte_id, mi.numero_carta_porte,  mi.item_oncca_iibb, mi.inventory_item_id
         , mi.transaction_source_type_id
         , mi.transaction_type_id
         , mi.transaction_action_id
         , mi.reason_id
         , REPLACE(mi.lot_number,'T','')
         , mi.acct_period
         , mi.operating_unit, mi.organization_id, mi.subinventory_code, mi.locator_id
         , mi.transfer_operating_unit, mi.transfer_organization_id, mi.transfer_subinventory, mi.transfer_locator_id
         , mi.owning_operating_unit, mi.owning_organization_id
         , mi.xfr_owning_organization_id
         , mis.transaction_quantity
    ;

    COMMIT;
  EXCEPTION
    WHEN eError THEN
      ROLLBACK;
    WHEN OTHERS THEN
      x_error_msg := 'Error generando saldo para el periodo '||p_periodo||'. '||SQLERRM;
      ROLLBACK;
  END;


  PROCEDURE Procesa_CPS_Origen_IIBB ( p_periodo         VARCHAR2
                                    , x_error_msg   OUT VARCHAR2
                                    ) IS

    CURSOR cMain ( p_period  VARCHAR2 )IS

      SELECT *
      FROM
      ( SELECT cp.*, XX_TCG_CALIDAD_PKG.Get_Peso_Aplicado (cp.carta_porte_id) peso_aplicado
        FROM xx_tcg_cartas_porte_all cp
           , ( SELECT DISTINCT carta_porte_id
               FROM xx_tcg_movimiento_inventario_v
               WHERE acct_period = p_period
             ) mi
        WHERE 1=1
        AND cp.transferido_flag = 'Y'
        AND cp.recibido_flag  = 'Y'
        AND mi.carta_porte_id = cp.carta_porte_id
        AND NOT EXISTS ( SELECT 1 FROM xx_tcg_iibb_origen WHERE documento_id = cp.carta_porte_id )
        UNION
        SELECT cp.*, XX_TCG_CALIDAD_PKG.Get_Peso_Aplicado (cp.carta_porte_id) peso_aplicado
        FROM xx_tcg_cartas_porte_all cp
           , ( SELECT DISTINCT carta_porte_id
               FROM xx_tcg_movimiento_inventario_v
               WHERE acct_period = p_period
             ) mi
        WHERE 1=1
        AND cp.recibido_flag  = 'Y'
        AND mi.carta_porte_id = cp.carta_porte_id
        AND XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (cp.titular_cp_cuit) = 'N'
        AND XX_TCG_FUNCTIONS_PKG.Proveedor_Reac (cp.titular_cp_id) = 'N'
        AND ( XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (cp.intermediario_cuit)  = 'Y' OR
              XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (cp.rtte_comercial_cuit) = 'Y'
            )
        AND NOT EXISTS ( SELECT 1 FROM xx_tcg_iibb_origen WHERE documento_id = cp.carta_porte_id )
      ) cp
      ORDER BY cp.carta_porte_id
      ;


    l_error_msg    VARCHAR2(2000);
    l_trx_id       NUMBER;
    l_periodo      VARCHAR2(10);
    l_ou           NUMBER;
    l_contrato_id  NUMBER;
    l_ini_date     DATE := SYSDATE;
    eError         EXCEPTION;


    FUNCTION Get_Trx_ID ( p_carta_porte_id    NUMBER
                        , p_operating_unit    NUMBER
                        ) RETURN NUMBER IS
      CURSOR cTRX ( p_carta_porte_id NUMBER
                  , p_operating_unit NUMBER
                  ) IS
        SELECT transaction_id
        FROM xx_tcg_movimiento_inventario_v
        WHERE 1=1
        AND carta_porte_id = p_carta_porte_id
        AND operating_unit = p_operating_unit
        AND tipo_movimiento  = 'T'
        AND transaction_quantity < 0
        AND reason_code NOT IN ('AJDP', 'AJME')
        ORDER BY transaction_id DESC
        ;

      rTRX   cTRX%ROWTYPE;
    BEGIN
      OPEN cTRX ( p_carta_porte_id, p_operating_unit );
      FETCH cTRX INTO rTRX;
      CLOSE cTRX;

      RETURN rTRX.transaction_id;
    END Get_Trx_ID;


    FUNCTION Get_Trx_ID_Owning ( p_carta_porte_id    NUMBER
                               , p_operating_unit    NUMBER
                               ) RETURN NUMBER IS
      CURSOR cTRX ( p_carta_porte_id NUMBER
                  , p_operating_unit NUMBER
                  ) IS
        SELECT transaction_id
        FROM xx_tcg_movimiento_inventario_v
        WHERE 1=1
        AND carta_porte_id = p_carta_porte_id
        AND operating_unit = p_operating_unit
        AND transfer_operating_unit = p_operating_unit
        AND tipo_movimiento  = 'T'
        AND transaction_quantity < 0
        AND reason_code NOT IN ('AJDP', 'AJME')
        ORDER BY transaction_id DESC
        ;

      rTRX   cTRX%ROWTYPE;
    BEGIN
      OPEN cTRX ( p_carta_porte_id, p_operating_unit );
      FETCH cTRX INTO rTRX;
      CLOSE cTRX;

      RETURN rTRX.transaction_id;
    END Get_Trx_ID_Owning;


    FUNCTION Popula_IIBB_Origen ( p_periodo                VARCHAR2
                                , p_operating_unit         NUMBER
                                , p_documento_tipo         VARCHAR2
                                , p_documento_id           NUMBER
                                , p_cereal_tipo            VARCHAR2
                                , p_transaction_id         NUMBER
                                , p_kilos                  NUMBER
                                , p_origen_provincia       VARCHAR2
                                , p_origen_localidad       VARCHAR2
                                , p_carta_porte_origen     VARCHAR2
                                , p_contrato_id            NUMBER
                                , x_error_msg          OUT VARCHAR2
                                ) RETURN BOOLEAN IS
      l_origen_iibb_id  NUMBER;
    BEGIN
      SELECT XX_TCG_IIBB_ORIGEN_S.nextval
      INTO l_origen_iibb_id
      FROM DUAL;

      INSERT INTO XX_TCG_IIBB_ORIGEN
      ( ORIGEN_IIBB_ID
      , PERIODO
      , OPERATING_UNIT
      , DOCUMENTO_TIPO
      , DOCUMENTO_ID
      , CEREAL_TIPO
      , TRANSACTION_ID
      , KILOS
      , ORIGEN_PROVINCIA
      , ORIGEN_LOCALIDAD
      , CARTA_PORTE_ORIGEN
      , CONTRATO_ID
      , CREATED_BY
      , CREATION_DATE
      , LAST_UPDATED_BY
      , LAST_UPDATE_DATE
      , LAST_UPDATE_LOGIN
      ) VALUES
      ( l_origen_iibb_id
      , p_periodo
      , p_operating_unit
      , p_documento_tipo
      , p_documento_id
      , p_cereal_tipo
      , p_transaction_id
      , p_kilos
      , p_origen_provincia
      , p_origen_localidad
      , p_carta_porte_origen
      , p_contrato_id
      , -1
      , SYSDATE
      , -1
      , SYSDATE
      , -1
      );

      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        x_error_msg := SQLERRM;
        RETURN FALSE;
    END Popula_IIBB_Origen;


    FUNCTION Consumir_Origen ( p_periodo         IN  VARCHAR2
                             , p_operating_unit  IN  NUMBER
                             , p_documento_id    IN  NUMBER
                             , p_trx_id          IN  NUMBER
                             , p_peso_aplicado   IN  NUMBER
                             , p_contrato_id     IN  NUMBER
                             , p_owning_flag     IN  VARCHAR2 DEFAULT 'N'
                             , x_error_msg       OUT VARCHAR2
                             ) RETURN BOOLEAN IS

      CURSOR cSaldos ( p_trx_id      NUMBER
                     , p_owning_flag VARCHAR2
                     ) IS

        SELECT si.transaction_id, si.carta_porte_id, si.numero_carta_porte, cp.titular_cp_provincia, cp.titular_cp_localidad, si.transaction_quantity - si.used_quantity disponible
        FROM xx_tcg_iibb_saldo_ini          si
           , xx_tcg_movimiento_inventario_v mi
           , xx_tcg_cartas_porte_all        cp
        WHERE 1=1
        AND cp.carta_porte_id       = mi.carta_porte_id
        --AND si.inventory_item_id    = mi.inventory_item_id SD1166
        AND si.item_oncca_iibb      = mi.item_oncca_iibb
        AND si.lot_number           = mi.lot_number
        AND ( ( p_owning_flag        = 'N' AND
                si.organization_id   = mi.organization_id   AND
                si.subinventory_code = mi.subinventory_code AND
                si.locator_id        = mi.locator_id
              ) OR
              ( p_owning_flag                 = 'Y' AND
                si.owning_organization_id     = mi.owning_organization_id AND
                si.xfr_owning_organization_id = mi.xfr_owning_organization_id
              )
           )
        AND si.transaction_quantity > si.used_quantity
        AND mi.transaction_id       = p_trx_id --75740106
        ORDER BY si.carta_porte_id
        ;

      rSaldos           cSaldos%ROWTYPE;
      l_peso_consumido  NUMBER := 0;
      l_peso_a_usar     NUMBER := 0;
    BEGIN
      OPEN cSaldos ( p_trx_id, p_owning_flag );
      LOOP
        FETCH cSaldos INTO rSaldos;
        IF cSaldos%NOTFOUND THEN
          x_error_msg := 'Error consumiendo con Transaction '||p_trx_id||' me quede sin saldo.';
          EXIT;
        END IF;

        l_peso_a_usar := (p_peso_aplicado - l_peso_consumido);

        IF l_peso_a_usar = rSaldos.disponible THEN

          UPDATE xx_tcg_iibb_saldo_ini
          SET used_quantity = l_peso_a_usar
          WHERE transaction_id = rSaldos.transaction_id;

        ELSIF rSaldos.disponible != l_peso_a_usar  THEN

          IF rSaldos.disponible < l_peso_a_usar  THEN
            l_peso_a_usar := rSaldos.disponible;
          END IF;

          UPDATE xx_tcg_iibb_saldo_ini
          SET used_quantity = used_quantity + l_peso_a_usar
          WHERE transaction_id = rSaldos.transaction_id;

        END IF;

        IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                  , p_operating_unit     => p_operating_unit
                                  , p_documento_tipo     => 'XXTCGCP'
                                  , p_documento_id       => p_documento_id
                                  , p_cereal_tipo        => 'P'
                                  , p_transaction_id     => p_trx_id
                                  , p_kilos              => l_peso_a_usar
                                  , p_origen_provincia   => rSaldos.titular_cp_provincia
                                  , p_origen_localidad   => rSaldos.titular_cp_localidad
                                  , p_carta_porte_origen => rSaldos.numero_carta_porte
                                  , p_contrato_id        => p_contrato_id
                                  , x_error_msg          => l_error_msg
                                  ) THEN
          x_error_msg := 'Error insertando en IIBB Origen: '||l_error_msg;
        END IF;

        l_peso_consumido := l_peso_consumido +  l_peso_a_usar;

        EXIT WHEN l_peso_consumido = p_peso_aplicado;

      END LOOP;

      CLOSE cSaldos;

      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        x_error_msg := SQLERRM;
        RETURN FALSE;
    END Consumir_Origen;

  BEGIN
    --DELETE XX_TCG_IIBB_ORIGEN WHERE periodo = l_periodo;-- AND origen_iibb_id < 1000000;

    FOR rMain IN cMain ( p_periodo ) LOOP

      -- TITULAR EG PRODUCTOR
      IF rMain.titular_cp_tipo = 'PRODUCTOR' AND
         XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.titular_cp_cuit) THEN

        l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                               , p_operating_unit => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.titular_cp_cuit)
                               );
        IF l_trx_id IS NOT NULL THEN
          IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                    , p_operating_unit     => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.titular_cp_cuit)
                                    , p_documento_tipo     => 'XXTCGCP'
                                    , p_documento_id       => rMain.carta_porte_id
                                    , p_cereal_tipo        => 'P'
                                    , p_transaction_id     => l_trx_id
                                    , p_kilos              => rMain.peso_aplicado
                                    , p_origen_provincia   => rMain.titular_cp_provincia
                                    , p_origen_localidad   => rMain.titular_cp_localidad
                                    , p_carta_porte_origen => rMain.numero_carta_porte
                                    , p_contrato_id        => NULL
                                    , x_error_msg          => l_error_msg
                                    ) THEN
            x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
            RAISE eError;
          END IF;
        ELSE
          x_error_msg := 'No fue posible encontrar Trx ID para Titular Productor para la CP ('||rMain.carta_porte_id||')';
          RAISE eError;
        END IF;

        IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.intermediario_cuit) THEN
          --l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
          --                       , p_operating_unit => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.intermediario_cuit)
          --                       );
          --IF l_trx_id IS NOT NULL THEN
            IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                      , p_operating_unit     => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.intermediario_cuit)
                                      , p_documento_tipo     => 'XXTCGCP'
                                      , p_documento_id       => rMain.carta_porte_id
                                      , p_cereal_tipo        => 'T'
                                      , p_transaction_id     => l_trx_id
                                      , p_kilos              => rMain.peso_aplicado
                                      , p_origen_provincia   => rMain.titular_cp_provincia
                                      , p_origen_localidad   => rMain.titular_cp_localidad
                                      , p_carta_porte_origen => rMain.numero_carta_porte
                                      , p_contrato_id        => rMain.intermediario_contrato_id
                                      , x_error_msg          => l_error_msg
                                      ) THEN
              x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
              RAISE eError;
            END IF;
          --ELSE
            --DBMS_OUTPUT.PUT_LINE('No fue posible encontrar Trx ID para Intermediario CP ID '||rMain.carta_porte_id);
          --END IF;
        END IF;

        IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.rtte_comercial_cuit) THEN
          --l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
          --                       , p_operating_unit => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
          --                       );
          --IF l_trx_id IS NOT NULL THEN
            IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                      , p_operating_unit     => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                      , p_documento_tipo     => 'XXTCGCP'
                                      , p_documento_id       => rMain.carta_porte_id
                                      , p_cereal_tipo        => 'T'
                                      , p_transaction_id     => l_trx_id
                                      , p_kilos              => rMain.peso_aplicado
                                      , p_origen_provincia   => rMain.titular_cp_provincia
                                      , p_origen_localidad   => rMain.titular_cp_localidad
                                      , p_carta_porte_origen => rMain.numero_carta_porte
                                      , p_contrato_id        => rMain.rtte_comercial_contrato_id
                                      , x_error_msg          => l_error_msg
                                      ) THEN
              x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
              RAISE eError;
            END IF;
          --ELSE
            --DBMS_OUTPUT.PUT_LINE('No fue posible encontrar Trx ID para Rtte Comercial CP ID '||rMain.carta_porte_id);
          --END IF;
        END IF;
        --

      ELSIF rMain.titular_cp_tipo = 'OPERADOR' AND
            XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.titular_cp_cuit) THEN

        -- TITULAR EG - Int = EG
        IF ( rMain.titular_cp_cuit = rMain.intermediario_cuit AND
             rMain.intermediario_tipo = 'PRODUCTOR'
           ) OR
           ( rMain.intermediario_cuit IS NULL AND
             rMain.titular_cp_cuit = rMain.rtte_comercial_cuit AND
             rMain.rtte_comercial_tipo = 'PRODUCTOR'
           ) THEN



          IF rMain.titular_cp_cuit = rMain.intermediario_cuit AND
             rMain.intermediario_tipo = 'PRODUCTOR' THEN
            l_ou     := XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.intermediario_cuit);
            l_contrato_id := rMain.intermediario_contrato_id;
            l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                   , p_operating_unit => l_ou
                                   );
          ELSIF rMain.titular_cp_cuit = rMain.rtte_comercial_cuit AND
                rMain.rtte_comercial_tipo = 'PRODUCTOR' AND
                rMain.intermediario_cuit IS NULL THEN
            l_ou     := XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit);
            l_contrato_id := rMain.rtte_comercial_contrato_id;
            l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                   , p_operating_unit => l_ou
                                   );
          END IF;


          --consumir origen
          IF NOT Consumir_Origen ( p_periodo        => p_periodo
                                 , p_operating_unit => l_ou
                                 , p_documento_id   => rMain.carta_porte_id
                                 , p_trx_id         => l_trx_id
                                 , p_peso_aplicado  => rMain.peso_aplicado
                                 , p_contrato_id    => l_contrato_id
                                 , p_owning_flag    => 'N'
                                 , x_error_msg      => l_error_msg
                                 ) THEN
            x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
            RAISE eError;
          END IF;

          IF rMain.titular_cp_cuit != rMain.rtte_comercial_cuit AND
             XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.rtte_comercial_cuit) THEN

            IF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.titular_cp_cuit)     AND --SD2010
               XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.intermediario_cuit)  AND
               XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.rtte_comercial_cuit) AND
               rMain.titular_cp_cuit  = rMain.intermediario_cuit  AND
               rMain.titular_cp_cuit != rMain.rtte_comercial_cuit AND
               rMain.intermediario_tipo = 'PRODUCTOR' THEN
              NULL;
            ELSE
              l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                     , p_operating_unit => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                     );
            END IF;

            IF l_trx_id IS NOT NULL THEN
              IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                        , p_operating_unit     => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                        , p_documento_tipo     => 'XXTCGCP'
                                        , p_documento_id       => rMain.carta_porte_id
                                        , p_cereal_tipo        => 'T'
                                        , p_transaction_id     => l_trx_id
                                        , p_kilos              => rMain.peso_aplicado
                                        , p_origen_provincia   => rMain.titular_cp_provincia
                                        , p_origen_localidad   => rMain.titular_cp_localidad
                                        , p_carta_porte_origen => rMain.numero_carta_porte
                                        , p_contrato_id        => rMain.rtte_comercial_contrato_id
                                        , x_error_msg          => l_error_msg
                                        ) THEN
                x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
                RAISE eError;
              END IF;
            ELSE
              x_error_msg := 'No fue posible encontrar Trx ID para Rtte Comercial2 CP ID '||rMain.carta_porte_id||'. '||l_error_msg;
              RAISE eError;
            END IF;

          END IF;
          --

        -- TITULAR EG - Int != EG
        ELSIF ( rMain.titular_cp_cuit != rMain.intermediario_cuit AND
                rMain.intermediario_tipo = 'PRODUCTOR'
              ) OR
              ( rMain.titular_cp_cuit != rMain.rtte_comercial_cuit AND
                rMain.rtte_comercial_tipo = 'PRODUCTOR' AND
                rMain.intermediario_cuit  IS NULL
              ) THEN

          IF rMain.intermediario_tipo = 'PRODUCTOR' THEN
            l_ou     := XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.intermediario_cuit);
            l_contrato_id := rMain.intermediario_contrato_id;
            l_trx_id := Get_Trx_ID_Owning ( p_carta_porte_id => rMain.carta_porte_id
                                          , p_operating_unit => l_ou
                                          );
          ELSIF rMain.rtte_comercial_tipo = 'PRODUCTOR' THEN
            l_ou     := XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit);
            l_contrato_id := rMain.rtte_comercial_contrato_id;
            l_trx_id := Get_Trx_ID_Owning ( p_carta_porte_id => rMain.carta_porte_id
                                          , p_operating_unit => l_ou
                                          );
          END IF;

          --consumir origen
          IF NOT Consumir_Origen ( p_periodo        => p_periodo
                                 , p_operating_unit => l_ou
                                 , p_documento_id   => rMain.carta_porte_id
                                 , p_trx_id         => l_trx_id
                                 , p_peso_aplicado  => rMain.peso_aplicado
                                 , p_contrato_id    => l_contrato_id
                                 , p_owning_flag    => 'Y'
                                 , x_error_msg      => l_error_msg
                                 ) THEN
            x_error_msg := 'Error consumiendo desde Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
            RAISE eError;
          END IF;


          IF rMain.intermediario_cuit != rMain.rtte_comercial_cuit AND
             XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.intermediario_cuit) AND
             XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.rtte_comercial_cuit) THEN

            l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                   , p_operating_unit => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                   );
            IF l_trx_id IS NOT NULL THEN
              IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                        , p_operating_unit     => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                        , p_documento_tipo     => 'XXTCGCP'
                                        , p_documento_id       => rMain.carta_porte_id
                                        , p_cereal_tipo        => 'T'
                                        , p_transaction_id     => l_trx_id
                                        , p_kilos              => rMain.peso_aplicado
                                        , p_origen_provincia   => rMain.titular_cp_provincia
                                        , p_origen_localidad   => rMain.titular_cp_localidad
                                        , p_carta_porte_origen => rMain.numero_carta_porte
                                        , p_contrato_id        => rMain.rtte_comercial_contrato_id
                                        , x_error_msg          => l_error_msg
                                        ) THEN
                    x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
                RAISE eError;
              END IF;
            ELSE
              x_error_msg := 'No fue posible encontrar Trx ID para Rtte Comercial3 CP ID '||rMain.carta_porte_id||'. '||l_error_msg;
              RAISE eError;
            END IF;

          END IF;

        END IF;

      -- TITULAR Reac
--      ELSIF XX_TCG_FUNCTIONS_PKG.Proveedor_Reac (rMain.titular_cp_id) = 'Y' AND
      -- TITULAR Reac o Saco Mercadería del grupo de una planta de Tercero
      ELSIF ( XX_TCG_FUNCTIONS_PKG.Proveedor_Reac (rMain.titular_cp_id) = 'Y' OR   -- SD1166
                ( rMain.transferido_flag = 'Y' AND rMain.titular_cp_tipo = 'OPERADOR' AND
                  XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (rMain.titular_cp_cuit) = 'N'  ) ) AND
            ( ( XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.intermediario_cuit) AND
                rMain.intermediario_tipo = 'PRODUCTOR'
              ) OR
              ( rMain.intermediario_cuit IS NULL AND
                XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.rtte_comercial_cuit) AND
                rMain.rtte_comercial_tipo = 'PRODUCTOR'
              )
            ) THEN

        IF rMain.intermediario_tipo = 'PRODUCTOR' THEN
          l_ou     := XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.intermediario_cuit);
          l_contrato_id := rMain.intermediario_contrato_id;
          l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                 , p_operating_unit => l_ou
                                 );
        ELSIF rMain.rtte_comercial_tipo = 'PRODUCTOR' THEN
          l_ou     := XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit);
          l_contrato_id := rMain.rtte_comercial_contrato_id;
          l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                 , p_operating_unit => l_ou
                                 );
        END IF;

        --consumir origen
        IF NOT Consumir_Origen ( p_periodo        => p_periodo
                               , p_operating_unit => l_ou
                               , p_documento_id   => rMain.carta_porte_id
                               , p_trx_id         => l_trx_id
                               , p_peso_aplicado  => rMain.peso_aplicado
                               , p_contrato_id    => l_contrato_id
                               , p_owning_flag    => 'N'
                               , x_error_msg      => l_error_msg
                               ) THEN
          x_error_msg := 'Error consumiendo desde Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
          RAISE eError;
        END IF;

        IF rMain.intermediario_cuit != rMain.rtte_comercial_cuit AND
           XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.intermediario_cuit) AND
           XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo (rMain.rtte_comercial_cuit) THEN

          l_trx_id := Get_Trx_ID ( p_carta_porte_id => rMain.carta_porte_id
                                 , p_operating_unit => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                 );
          IF l_trx_id IS NOT NULL THEN
            IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                      , p_operating_unit     => XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit)
                                      , p_documento_tipo     => 'XXTCGCP'
                                      , p_documento_id       => rMain.carta_porte_id
                                      , p_cereal_tipo        => 'T'
                                      , p_transaction_id     => l_trx_id
                                      , p_kilos              => rMain.peso_aplicado
                                      , p_origen_provincia   => rMain.titular_cp_provincia
                                      , p_origen_localidad   => rMain.titular_cp_localidad
                                      , p_carta_porte_origen => rMain.numero_carta_porte
                                      , p_contrato_id        => rMain.rtte_comercial_contrato_id
                                      , x_error_msg          => l_error_msg
                                      ) THEN
              x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
              RAISE eError;
            END IF;
          ELSE
            x_error_msg := 'No fue posible encontrar Trx ID para Rtte Comercial4 CP ID '||rMain.carta_porte_id||'. '||l_error_msg;
            RAISE eError;
          END IF;

        END IF;

      -- Terceros
      ELSIF XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (rMain.titular_cp_cuit) = 'N' AND
            XX_TCG_FUNCTIONS_PKG.Proveedor_Reac (rMain.titular_cp_id) = 'N' AND
            ( XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (rMain.intermediario_cuit)  = 'Y' OR
              XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (rMain.rtte_comercial_cuit) = 'Y'
            ) THEN

        IF NOT Popula_IIBB_Origen ( p_periodo            => p_periodo
                                  , p_operating_unit     => NVL(XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.intermediario_cuit), XX_TCG_FUNCTIONS_PKG.Cuit_Operating_Unit(rMain.rtte_comercial_cuit))
                                  , p_documento_tipo     => 'XXTCGCP'
                                  , p_documento_id       => rMain.carta_porte_id
                                  , p_cereal_tipo        => 'T'
                                  , p_transaction_id     => l_trx_id
                                  , p_kilos              => rMain.peso_aplicado
                                  , p_origen_provincia   => rMain.titular_cp_provincia
                                  , p_origen_localidad   => rMain.titular_cp_localidad
                                  , p_carta_porte_origen => rMain.numero_carta_porte
                                  , p_contrato_id        => NVL(rMain.intermediario_contrato_id, rMain.rtte_comercial_contrato_id)
                                  , x_error_msg          => l_error_msg
                                  ) THEN
          x_error_msg := 'Error insertando en IIBB Origen para la CP ('||rMain.carta_porte_id||'): '||l_error_msg;
          RAISE eError;
        END IF;

      END IF;

    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Tiempo total de ejecucion: '||XX_UTIL_PK.GetElapsedTime(l_ini_date, SYSDATE));

    COMMIT;
  EXCEPTION
    WHEN eError THEN
      ROLLBACK;
    WHEN OTHERS THEN
      x_error_msg := 'Error gral: '||SQLERRM;
      ROLLBACK;
  END;
---===============================================
-- Generacion casos en tablas xx_ar_iibb para reporte
---===============================================

PROCEDURE GET_DATOS_ITEMS (p_item_id in number, p_warehouse_id in number) is
BEGIN

              SELECT  msi.primary_uom_code, mc.segment1 || '.' || mc.segment2||'.'||mc.segment3               AS categ_seg_concat  , MSI.DESCRIPTION,  msi_dfv.xx_aco_codigo_oncca
                INTO  g_lin_art_rec.primary_uom_code, g_lin_art_rec.categ_seg_concat, g_lin_art_rec.item_desc, g_lin_art_rec.xx_aco_codigo_oncca
                FROM     mtl_system_items_b      msi
                         , mtl_item_categories_v              mic
                        , mtl_categories                     mc
                           , mtl_system_items_b_dfv  msi_dfv
                WHERE  msi.inventory_item_id (+)     = p_item_id
                                    AND msi.organization_id   (+)     = p_warehouse_id
                                    AND mic.inventory_item_id (+)     = msi.inventory_item_id
                                    AND mic.organization_id   (+)     = msi.organization_id
                                    AND mc.category_id        (+)     = mic.category_id
                                    AND mic.category_set_name (+)     = 'Inventory'
                                     AND msi_dfv.row_id(+) = msi.ROWID;

exception when others then
            g_lin_art_rec.primary_uom_code:= null;
             g_lin_art_rec.categ_seg_concat :=  null;
             g_lin_art_rec.xx_aco_codigo_oncca := null;
             g_lin_art_rec.item_desc := 'Item no existente';
END GET_DATOS_ITEMS;

  /**************************************************************************+
  | Private Procedure                                                         |
  |    INSERTAR_CONSUMO                                                       |
  |                                                                           |
  | Description                                                               |
  |    Actualiza la tabla auxiliar XX_AR_IIBB_CONS                            |
  |                                                                           |
  +***************************************************************************/
  FUNCTION INSERTAR_CONSUMO (  p_documento_id       IN NUMBER
                              , p_documento_num         IN VARCHAR2
                              , p_documento_tipo          IN VARCHAR2
                              , p_fecha                         IN DATE
                              , p_cantidad_total            IN NUMBER
                              , p_consumo                   IN NUMBER
                              , p_province           IN VARCHAR2
                              , p_carta_porte_envio  IN VARCHAR2
                              , p_carta_porte_insumo IN VARCHAR2
                              , p_provincia_envio    IN VARCHAR2
                              , p_cantidad_envio     IN NUMBER
                              , p_record_level       IN VARCHAR2
                              , p_indent             IN NUMBER DEFAULT 2
                              , x_errmsg             OUT VARCHAR2
                              )
                              RETURN BOOLEAN IS

    l_indent     NUMBER := p_indent;
            l_trx_line_id                            number;
        l_trx_id                                   number;
        l_item_id                                 number;
        l_pedido_num                          number;
        l_uom_code                            varchar2(10);

  BEGIN
  x_errmsg := null;

    IF (p_consumo = 0) THEN
        x_errmsg := '- ' || 'INSERTAR_CONSUMO' || ' ' || 'la cantidad a consumir no puede ser 0.'
                ||' Id Documento: '||p_documento_id
                ||' Nro Documento: '||p_documento_num
                ||' Tipo Documento: '||p_documento_tipo
                ||' Cantidad Total: '||p_cantidad_total
                ||' Consumo: '||p_consumo;
      debug(x_errmsg, l_indent);
      RETURN FALSE;
    END IF;

    debug(' + ' || 'INSERTAR_CONSUMO' || ' Insertando : '
                 ||' Id Documento: '||p_documento_id
                 ||' Nro Documento: '||p_documento_num
                 ||' Tipo Documento: '||p_documento_tipo
                 ||' Cantidad Total: '||p_cantidad_total
                 ||' Consumo: '||p_consumo, l_indent);
    if g_lin_art_rec.origen_mercaderia = 'PROPIA' THEN
         g_header_id := g_hdr_id_propio;
    ELSE
          g_header_id := g_hdr_id_tercero;
    END IF;

  IF p_record_level = 'R' THEN
        l_trx_line_id                             :=       g_lin_art_rev.trx_line_id;
        l_trx_id                                    :=      g_fac_rev.trx_id;
        l_item_id                                  :=     g_lin_art_rev.item_id;
        l_pedido_num                           :=     g_lin_art_rev.pedido_num;
        l_uom_code                              :=     g_lin_art_rev.uom_code;
   ELSE
        l_trx_line_id                             :=       g_lin_art_rec.trx_line_id;
        l_trx_id                                    :=      g_fac_rec.trx_id;
        l_item_id                                  :=     g_lin_art_rec.item_id;
        l_pedido_num                           :=     g_lin_art_rec.pedido_num;
        l_uom_code                              :=     g_lin_art_rec.uom_code;
   end if;

    INSERT INTO xx_ar_iibb_CONS
    ( CONSUMO_ID
    , HEADER_ID
    , DOCUMENTO_ID
    , DOCUMENTO_NUM
    , TIPO_DOCUMENTO
    , FECHA_DOCUMENTO
    , CANTIDAD_TOTAL
    , CONSUMO
    , TRX_LINE_ID
    , TRX_ID
    , PROVINCIA_ORIGEN
    , CONSUMIDO_FLAG
    , PRECIO_COMPRA
    , CARTA_PORTE_ENVIO
    , REMITO
    , CARTA_PORTE_INSUMO
    , PROVINCIA_ENVIO
    , ITEM_ID
    , UOM
    , CANTIDAD_ENVIO
    , RECORD_LEVEL
   ) VALUES
   ( xx_ar_iibb_cons_s.NEXTVAL
   , g_header_id
   , p_documento_id
   , p_documento_num
   , p_documento_tipo
   , p_fecha
   , p_cantidad_total
   , p_consumo
   , l_trx_line_id
   , l_trx_id
   , p_province
   , 'N'    -- consumido_flag
   , null
   , p_carta_porte_envio
   , l_pedido_num   -- en la columna remito
   , p_carta_porte_insumo
   , p_provincia_envio
   , l_item_id
   , l_uom_code
   , p_cantidad_envio
   , p_record_level
   );

   RETURN TRUE;


  EXCEPTION
    WHEN OTHERS THEN
    x_errmsg := 'Error general insertando registro de consumo. '|| SQLERRM;
      debug('- ' || 'INSERTAR_CONSUMO' || ' ' ||  x_errmsg);
        g_error_flag      := TRUE;
        IF G_ERROR_MSG IS NOT NULL  THEN
            g_error_msg := 'INSERTAR_CONSUMO -> ' || sqlerrm || g_error_msg;
        else
            g_error_msg   := 'INSERTAR_CONSUMO --> ' || sqlerrm;
       end if;
      RETURN FALSE;
  END INSERTAR_CONSUMO;


  /**************************************************************************+
  | Private Procedure                                                         |
  |    GET_DESC_COMERCIAL                                                     |
  |                                                                           |
  | Description                                                               |
  |    Retorna el descuento comercial aplicado a una linea de articulo en una   trx, a partir de una memoline de tipo descuento comercial en la misma   trx.                                                                   |
  +***************************************************************************/

  PROCEDURE GET_DESC_COMERCIAL ( d_trx_id            IN NUMBER
                               , d_trx_line_num      IN NUMBER
                               , d_desc_com          OUT NUMBER
                               , x_errmsg             OUT VARCHAR2
                               , p_result            OUT BOOLEAN
                               ) IS
    -- ------------------------------------------
    -- Cursor de las lineas de trx con memo lines
    -- ------------------------------------------
    CURSOR lineas_memo (pc_cust_trx_id NUMBER, pc_line_number NUMBER) IS
      SELECT Sum(rctl.extended_amount)
                  FROM ra_customer_trx_lines_all          rctl
                     , ra_customer_trx_lines_all_dfv      rctl_dfv
                     , ar_memo_lines_all_b                aml
                     , ar_memo_lines_all_b_dfv            aml_dfv
                  WHERE 1=1
                  AND rctl.rowid                                             = rctl_dfv.row_id
                  AND aml.rowid                                            = aml_dfv.row_id
                  AND aml.memo_line_id(+)                            = rctl.memo_line_id
                  AND rctl.line_type                                         LIKE 'LINE'
                  AND Nvl(aml_dfv.xx_ar_desc_com_flag,'N')      = 'Y'
                  AND rctl.inventory_item_id                             IS NULL
                  AND rctl.customer_trx_id                               = pc_cust_trx_id
                  AND rctl_dfv.xx_ar_linea_cod_arroz                = pc_line_number
                  GROUP BY rctl_dfv.xx_ar_linea_cod_arroz;

   l_desc_com   NUMBER;
   l_total_trx  NUMBER;
   l_total_desc NUMBER;

  BEGIN

  x_errmsg := null;

    -- obtener , si hay el descuento comercial de la linea
    debug(  '+ '|| 'GET_DESC_COMERCIAL' || ' Abro cursor lineas_memo. customer_trx_id: '||d_trx_id||' xx_ar_linea_cod_arroz: '|| d_trx_line_num, NULL );

    OPEN lineas_memo (d_trx_id, d_trx_line_num );
    FETCH lineas_memo INTO d_desc_com;
    CLOSE lineas_memo;

    p_result:= TRUE;
    if d_desc_com is not null then
        debug( '- '||'GET_DESC_COMERCIAL'||' descuento: '||To_Char(d_desc_com), NULL );
    end if;
  EXCEPTION
    WHEN no_data_found THEN
      IF (lineas_memo%ISOPEN) THEN
         CLOSE lineas_memo;
      END IF;

      d_desc_com := NULL;
    WHEN OTHERS THEN
      p_result := FALSE;
      x_errmsg  := 'GET_DESC_COMERCIAL  ->'|| SQLERRM;
      xx_debug_pk.debug(x_errmsg);
       g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'GET_DESC_COMERCIAL -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := x_errmsg;
         end if;
  END GET_DESC_COMERCIAL;



  /**************************************************************************+
  | Private Procedure                                                         |
  |    GET_FECHAS_PERIODO                                                     |
  |                                                                           |
  | Description                                                               |
  |    Obtiene fecha de inicio y fecha de fin dado un periodo de GL           |
  | Parameters                                                                |
  |    p_periodo       IN     VARCHAR2  Periodo de GL                         |
  |    p_desde         OUT    DATE      Fecha inicio del periodo              |
  |    p_hasta         OUT    DATE      Fecha fin del periodo                 |
  |                                                                           |
  +***************************************************************************/
  FUNCTION GET_FECHAS_PERIODO( p_periodo  IN  VARCHAR2
                             , p_indent   IN  NUMBER
                             , x_desde    OUT DATE
                             , x_hasta    OUT DATE
                             , x_errmsg    OUT VARCHAR2
                               ) RETURN BOOLEAN IS


    l_indent     NUMBER := p_indent;

  BEGIN
    debug('+ ' || 'GET_FECHAS_PERIODO' || '. Parametros -> p_periodo ' || p_periodo, l_indent );
    x_errmsg := null;

   SELECT trunc(start_date) , trunc(end_date)
    INTO x_desde , x_hasta
    FROM gl_period_statuses
    WHERE application_id = 101
    AND set_of_books_id IN (select set_of_books_id from financials_system_parameters )
    AND closing_status  IN ( 'O', 'F', 'C')
    AND period_name     LIKE p_periodo;

    debug('- ' || 'GET_FECHAS_PERIODO' || ' x_desde ' || x_desde || ' x_hasta ' || x_hasta, l_indent);

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      x_errmsg := '- Error en GET_FECHAS_PERIODO -> ' || SQLERRM;
      debug(x_errmsg, l_indent);
       g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'GET_FECHAS_PERIODO -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := x_errmsg;
         end if;
      RETURN FALSE;
  END GET_FECHAS_PERIODO;


  /***************************************************************************+
  | Function                                                                  |
  |    INSERTAR_CABECERA_IIBB                                                 |
  |                                                                           |
  | Description                                                               |
  |    Inserta Cabecera del Proceso de IIBB                                   |
  |                                                                           |
  | Parameters                                                                |
  |    p_logica     IN      VARCHAR2 Logica a procesar                        |
  |    p_tipo_proc  IN      VARCHAR2 Tipo de procesamiento del concurrente    |
  |    p_periodo    IN      VARCHAR2 Periodo de GL para filtrar las trx       |
  |    p_indent     IN      NUMBER   Nivel de indentacion de mensajes         |
  |    p_header_id  OUT     NUMBER  Id de la cabecera                         |
  |    x_errmsg     OUT     VARCHAR2 Descripcion en caso de errores           |
  |                                                                           |                                                          |          |
  +***************************************************************************/
  FUNCTION INSERTAR_CABECERA_IIBB ( p_logica          IN   VARCHAR2
                                  , p_tipo_proc       IN   VARCHAR2
                                  , p_periodo         IN   VARCHAR2
                                  , p_indent          IN   VARCHAR2
                                  , p_header_id       OUT  VARCHAR2
                                  , x_errmsg          OUT  VARCHAR2
                                  )
                                  RETURN BOOLEAN IS

  BEGIN
      x_errmsg := null;

    debug( '+ '||'INSERTAR_CABECERA_IIBB'||'. Parametros -> Periodo: '||p_periodo
                                          ||' Logica: ' ||p_logica
                                          ||' Tipo proceso: '||p_tipo_proc, p_indent);

    INSERT INTO xx_ar_iibb_CAB_all
    ( HEADER_ID
    , PERIODO
    , TIPO_LOGICA
    , TIPO_EJECUCION
    , CONCURRENTE_ID
    , FECHA_EJECUCION
    , ORG_ID
    , USUARIO_ID
    ) VALUES
    ( XX_AR_IIBB_CAB_S.NEXTVAL
    , P_PERIODO
    , P_LOGICA
    , P_TIPO_PROC
    , fnd_global.CONC_REQUEST_ID
    , SYSDATE
    , DECODE (P_LOGICA,'INGRESO',g_org_id_ingreso,fnd_global.ORG_ID)  --  la cabecera de 'INGRESO'  es fija
    , fnd_global.USER_ID
    );

    SELECT xx_ar_iibb_cab_s.currval
    INTO p_header_id
    FROM dual;

    debug( '- '||'INSERTAR_CABECERA_IIBB', p_indent);
    RETURN (TRUE);

  EXCEPTION
    WHEN OTHERS THEN
      x_errmsg := 'Error INSERTAR_CABECERA_IIBB -> ' || SQLERRM;
      debug( '- '||'INSERTAR_CABECERA_IIBB'||x_errmsg, p_indent);
        g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'INSERTAR_CABECERA_IIBB -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := x_errmsg;
         end if;
      RETURN (FALSE);

  END INSERTAR_CABECERA_IIBB;


  /**************************************************************************+
  | Private Procedure                                                         |
  |    INSERTAR_DETALLE                                                 |
  | Description                                                               |
  |    Inserta linea de detalle en tabla xx_ar_iibb_det                       |
  +***************************************************************************/

  PROCEDURE INSERTAR_DETALLE (
                                      p_provincia_origen       IN  VARCHAR2,
                                      p_cantidad_por_origen    IN  NUMBER,
                                      p_provincia_destino      IN  VARCHAR2,
                                      p_cantidad_por_destino   IN  NUMBER,
                                      p_carta_porte_envio       in varchar2,
                                      p_carta_porte_insumo in varchar2,
                                      p_tipo_oper                in varchar2 ,
                                      p_observa                  in varchar2 default null,
                                      x_errmsg                  OUT VARCHAR2,
                                      p_result                 OUT BOOLEAN) IS

    v_cantidad_por_origen       number;
    v_cantidad_por_destino      number;
    v_unidad_medida               varchar2(5);
    v_unit_selling_price            number;
   l_fac_rec                            fac_rec;
   l_lin_art_rec                       lin_art_rec;
   v_linea                  number;
  BEGIN

      x_errmsg := null;

    --   debug( '+ '||'   inserta_detalle  ' || p_carta_porte_envio || ' observa ' || p_observa  , NULL );
    if g_lin_art_rec.origen_mercaderia = 'PROPIA' THEN
         g_header_id := g_hdr_id_propio;
    ELSE
          g_header_id := g_hdr_id_tercero;
    END IF;

    l_fac_rec := g_empty_fac_rec;
    l_lin_art_rec := g_empty_lin_art_rec;


    IF p_tipo_oper = 'REVIERTE' THEN
            l_fac_rec.trx_id                                  :=    g_fac_rev.trx_id;
            l_fac_rec.trx_number                         := g_fac_rev.trx_number;
            l_fac_rec.trx_date                             := g_fac_rev.trx_date;
            l_fac_rec.tipo_trx                              := g_fac_rev.tipo_trx;
            l_fac_rec.customer_id                        := g_fac_rev.customer_id;
            l_fac_rec.customer_name                  := g_fac_rev.customer_name;
            l_lin_art_rec.trx_line_id                      := g_lin_art_rev.trx_line_id;
            l_lin_art_rec.item_id                          := g_lin_art_rev.item_id;
            l_lin_art_rec.categ_seg_concat           := g_lin_art_rev.categ_seg_concat;
            l_lin_art_rec.item_desc                      := g_lin_art_rev.item_desc;
            l_lin_art_rec.xx_aco_codigo_oncca      := g_lin_art_rev.xx_aco_codigo_oncca;
            l_lin_art_rec.dto_COMERCIAL             := g_lin_art_rev.dto_COMERCIAL;
            l_lin_art_rec.extended_amount          := g_lin_art_rev.extended_amount;
            l_lin_art_rec.pedido_num                  := g_lin_art_rev.pedido_num;
            l_lin_art_rec.quantity_invoiced           := g_lin_art_rev.quantity_invoiced;
            l_lin_art_rec.quantity_credited           := g_lin_art_rev.quantity_credited;
            l_lin_art_rec.uom_code                     := g_lin_art_rev.uom_code;
            l_lin_art_rec.primary_uom_code        := g_lin_art_rev.primary_uom_code;
            l_lin_art_rec.unit_selling_price           := g_lin_art_rev.unit_selling_price;
            l_lin_art_rec.factor_conver_um         :=  g_lin_art_rev.factor_conver_um;
            l_lin_art_rec.tipo_operacion              := 'R';

            v_cantidad_por_origen                      := p_cantidad_por_origen;
            v_cantidad_por_destino                     := p_cantidad_por_destino;
            v_unidad_medida                              := g_lin_art_rev.primary_uom_code;
            v_unit_selling_price                           := g_lin_art_rev.unit_selling_price;
   ELSE
        l_fac_rec.trx_id                                  :=    g_fac_rec.trx_id;
        l_fac_rec.trx_number                         := g_fac_rec.trx_number;
        l_fac_rec.trx_date                             := g_fac_rec.trx_date;
        l_fac_rec.tipo_trx                              := g_fac_rec.tipo_trx;
        l_fac_rec.customer_id                        := g_fac_rec.customer_id;
        l_fac_rec.customer_name                  := g_fac_rec.customer_name;
        l_lin_art_rec.trx_line_id                      := g_lin_art_rec.trx_line_id;
        l_lin_art_rec.item_id                          := g_lin_art_rec.item_id;
        l_lin_art_rec.categ_seg_concat           := g_lin_art_rec.categ_seg_concat;
        l_lin_art_rec.item_desc                      := g_lin_art_rec.item_desc;
        l_lin_art_rec.xx_aco_codigo_oncca     := g_lin_art_rec.xx_aco_codigo_oncca;
        l_lin_art_rec.dto_COMERCIAL             := g_lin_art_rec.dto_COMERCIAL;
        l_lin_art_rec.extended_amount          := g_lin_art_rec.extended_amount;
        l_lin_art_rec.pedido_num                  := g_lin_art_rec.pedido_num;
        l_lin_art_rec.quantity_invoiced           := g_lin_art_rec.quantity_invoiced;
        l_lin_art_rec.quantity_credited           := g_lin_art_rec.quantity_credited;
        l_lin_art_rec.uom_code                     := g_lin_art_rec.uom_code;
        l_lin_art_rec.primary_uom_code        := g_lin_art_rec.primary_uom_code;
        l_lin_art_rec.unit_selling_price           := g_lin_art_rec.unit_selling_price;
        l_lin_art_rec.factor_conver_um         :=  g_lin_art_rec.factor_conver_um;
        l_lin_art_rec.tipo_operacion              := g_lin_art_rec.tipo_operacion;

        if l_fac_rec.tipo_trx = 'CM' then

            IF l_lin_art_rec.item_id is null then
               v_unidad_medida := null;
               v_unit_selling_price := l_lin_art_rec.extended_amount * -1;
               v_cantidad_por_origen := -1; -- cr2264 , cambio de signo
               v_cantidad_por_destino := -1;  --cr2264, cambio de signo
            else
                v_cantidad_por_origen := p_cantidad_por_origen;
                v_cantidad_por_destino := p_cantidad_por_destino;
                v_unidad_medida := l_lin_art_rec.primary_uom_code;
                v_unit_selling_price :=l_lin_art_rec.unit_selling_price;
           end if;

        ELSE
            IF l_lin_art_rec.item_id is null then
               v_cantidad_por_origen := 1;
               v_cantidad_por_destino := 1;
               v_unidad_medida := null;
               v_unit_selling_price := l_lin_art_rec.extended_amount;
            else
               v_unidad_medida := l_lin_art_rec.primary_uom_code;
               v_unit_selling_price := l_lin_art_rec.unit_selling_price;
               if l_lin_art_rec.uom_code <> 'KG' then -- convierte las cantidades
                  v_cantidad_por_origen := p_cantidad_por_origen / l_lin_art_rec.factor_conver_um;
                  v_cantidad_por_destino := p_cantidad_por_destino/ l_lin_art_rec.factor_conver_um;
               else
                  v_cantidad_por_origen := p_cantidad_por_origen;
                  v_cantidad_por_destino := p_cantidad_por_destino;
               end if;
            END IF;
         end if;
    END IF;

    INSERT INTO xx_ar_iibb_det_all
       (   LINE_ID
    , HEADER_ID
    , TRX_ID
    , TRX_NUM
    , TRX_DATE
    , CLIENTE_ID
    , CLIENTE_NOMBRE
    , PROVINCIA_ORIGEN
    , CANTIDAD_POR_ORIGEN
    , PROVINCIA_DESTINO
    , CANTIDAD_POR_DESTINO
    , TRX_LINE_ID
    , ITEM_ID
    , ITEM_CATEGORY
    , ITEM_DESC
    , UNIDAD_MEDIDA_PRIMARIA
    , PRECIO_UNITARIO_VENTA
    , PRECIO_UNITARIO_COMPRA
    , DESCUENTO_COMERCIAL
    , PRECIO_TOTAL_VENTA
    , TIPO_OPERACION
    , CANTIDAD_ARROZ_CASCARA
    , TIPO_ARROZ_CASCARA_ID
    , TIPO_ARROZ_CASCARA_DESC
    , TIPO_ARROZ_CASCARA_UM
    , CARTA_PORTE_ENVIO
    , PEDIDO
    , REMITO
    , CARTA_PORTE_INSUMO
    , PROVINCIA_ENVIO
    , CANTIDAD_FACTURADA
    , UNIDAD_MEDIDA_TRX
    , TRX_FINAL
    , OBSERVACIONES
    ) VALUES
    (xx_ar_iibb_det_s.NEXTVAL
    , g_header_id
    , l_fac_rec.trx_id
    , l_fac_rec.trx_number
    , l_fac_rec.trx_date
    , l_fac_rec.customer_id
    , l_fac_rec.customer_name
    , upper(p_provincia_origen)
    , v_cantidad_por_origen
    , upper(p_provincia_destino)
    , v_cantidad_por_destino
    , l_lin_art_rec.trx_line_id
    , l_lin_art_rec.item_id
    , l_lin_art_rec.categ_seg_concat
    , l_lin_art_rec.item_desc
    , v_unidad_medida
    , v_unit_selling_price
    , NULL
    , l_lin_art_rec.dto_COMERCIAL
    , l_lin_art_rec.extended_amount
    , l_lin_art_rec.tipo_operacion
    , NULL
    , NULL
    , NULL
    , NULL
    , p_carta_porte_envio
    , l_lin_art_rec.pedido_num
    , null
    , p_carta_porte_insumo
    , upper(p_provincia_destino)
    , nvl( l_lin_art_rec.quantity_invoiced, l_lin_art_rec.quantity_credited )
    , l_lin_art_rec.uom_code
    , g_fac_rec.trx_final
    , p_observa
    );

<<FIN_INSERTA>>
    p_result := TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      p_result          := FALSE;
      x_errmsg        := 'Error en INSERTAR_DETALLE -> '|| SQLERRM;
      g_error_flag    := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'INSERTAR_DETALLE -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := x_errmsg;
         end if;
      debug('- '||'INSERTAR_DETALLE'||x_errmsg , NULL);

  END INSERTAR_DETALLE;

  /**************************************************************************+
  | Private Procedure                                                         |
  |    INSERTAR_ERROR                                                |
  | Description                                                               |
  |    Inserta linea de ERRORES  en tabla xx_ar_iibb_err                       |
  +***************************************************************************/

  PROCEDURE INSERTAR_ERROR (p_observa                  in varchar2 default null,
                                                      p_cp_salida_error      in varchar2 default null,
                                                      p_cp_origen_error      in varchar2 default null,
                                                      x_errmsg                  OUT VARCHAR2,
                                                      p_result                 OUT BOOLEAN) IS

  BEGIN
      x_errmsg := null;

    --   debug( '+ '||'   inserta_error   ' || p_carta_porte_envio || ' observa ' || p_observa  , NULL );
    if g_lin_art_rec.origen_mercaderia = 'PROPIA' THEN
         g_header_id := g_hdr_id_propio;
    ELSE
          g_header_id := g_hdr_id_tercero;
    END IF;


   INSERT into  BOLINF.XX_AR_IIBB_ERR_ALL
                   (trx_id
                  , HEADER_ID
                  , CARTA_PORTE_SALIDA
                  , CARTA_PORTE_ORIGEN
                  , OBSERVACIONES
               ) VALUES
                (g_fac_rec.trx_id
                , g_header_id
                , p_cp_salida_error
                , p_cp_origen_error
                , p_observa
                );

    p_result := TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      p_result          := FALSE;
      x_errmsg        := 'Error en INSERTAR_ERROR -> '|| SQLERRM;
      g_error_flag    := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'INSERTAR_ERROR -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := x_errmsg;
         end if;
      debug('- '||'INSERTAR_ERROR'||x_errmsg , NULL);

  END INSERTAR_ERROR;

   /********************************************************************************+
  | Function                                                                       |
  |    Nota_credito_RevierteFC                                                  |
  | Description                                                                    |
  |    Obtiene las Cartas de Porte de una Liquidacion Interco                      |
  | Parameters                                                                     |
  |    pc_liquidacion   IN      Numero de Liquidacion Interco                      |
  |    pc_tabla         IN      Tabla de Cartas de Porte de la Liquidacion Interco |
  +********************************************************************************/
  FUNCTION Nota_credito_RevierteFC( p_trx_id  IN  number
                                      ) RETURN BOOLEAN IS

    l_errmsg             VARCHAR2(1000);
    l_trx_id_fact        number;
    hay_errores        EXCEPTION;
    l_result               BOOLEAN;
    l_inserta            number := 0;


  BEGIN

    -- obtiene la transacion original por aplicacion de pago
    select Max(aps_ori.customer_trx_id)
      into l_trx_id_fact
    from AR_PAYMENT_SCHEDULES aps,
           AR_RECEIVABLE_APPLICATIONS ara,
           AR_PAYMENT_SCHEDULES  aps_ori ,
           ra_customer_trx rct
    where aps.customer_trx_id = p_trx_id
    and ara.payment_schedule_id = aps.payment_schedule_id
    and ara.application_type = 'CM'
    and aps_ori.payment_schedule_id = ara.applied_payment_schedule_id
    and rct.customer_trx_id = aps_ori.customer_trx_id
    and rct.trx_number = g_fac_rec.trx_number;

    -- si no encontro busca la factura por igual numero de transaccion / cliente
    if l_trx_id_fact is null then
        select min(customer_trx_id)
          into l_trx_id_fact
         from ra_customer_trx rct
        where trx_number = g_fac_rec.trx_number
        and g_fac_rec.ship_to_customer_id = rct.ship_to_customer_id
        and customer_trx_id < p_trx_id;
    end if;

        debug( '+ '||'Nota_credito_RevierteFC'||' -> TRX_id  ' || p_trx_id || ' credito sobre id  ' || l_trx_id_fact || ' item_id ' || g_lin_art_rec.item_id, NULL );

 if l_trx_id_fact is not null then

         select attribute1   -- obtiene el segment1 de la factura original
         into  g_fac_rec.tipo_liq
         from ra_customer_trx rct
         where customer_trx_id = l_trx_id_fact;

        if   g_lin_art_rec.item_id is not null then
                FOR C_Cons in  (SELECT documento_id, documento_num, CARTA_PORTE_INSUMO, cantidad_total, consumo, provincia_origen, CARTA_PORTE_ENVIO,
                                                    provincia_envio, cantidad_envio
                                        FROM XX_AR_IIBB_CONS
                                        WHERE TRX_ID = l_trx_id_fact
                                        and item_id = g_lin_art_rec.item_id ) LOOP
                          IF NOT INSERTAR_CONSUMO ( p_documento_id       => c_CONS.documento_id
                                                                      , p_documento_num                => c_CONS.documento_num
                                                                      , p_documento_tipo                 => 'CARTAS_PORTE'
                                                                      , p_fecha                               => g_fac_rec.trx_date
                                                                      , p_cantidad_total                   => c_CONS.cantidad_total * -1
                                                                      , p_consumo                          => c_cons.consumo * -1
                                                                      , p_province                          => c_CONS.provincia_origen
                                                                      , p_carta_porte_envio             => c_CONS.CARTA_PORTE_ENVIO
                                                                      , p_carta_porte_insumo        =>  c_CONS.CARTA_PORTE_INSUMO
                                                                      , p_provincia_envio               =>  c_CONS. PROVINCIA_ENVIO
                                                                      , p_cantidad_envio                => c_cons.CANTIDAD_ENVIO
                                                                      , p_record_level                   => 'F'
                                                                      , p_indent                            => 2
                                                                      , x_errmsg                          => l_errmsg
                                                                                      ) THEN

                                                                l_errmsg := 'Error en Nota_credito_RevierteFC - ' || l_errmsg;
                                                                RAISE hay_errores;
                          END IF;
                            l_inserta := l_inserta +1;

                    END LOOP;
                FOR C_dets in  (SELECT  PROVINCIA_ORIGEN, CANTIDAD_POR_ORIGEN, CANTIDAD_POR_DESTINO,PROVINCIA_DESTINO, CARTA_PORTE_ENVIO,CARTA_PORTE_INSUMO, PRECIO_UNITARIO_VENTA
                                         FROM xx_ar_iibb_det
                                         WHERE TRX_ID = L_TRX_ID_FACT
                                          and item_id = g_lin_art_rec.item_id
                                          and nvl(tipo_operacion,'X') <> 'R'
                                        ) LOOP

                       g_lin_art_rec.extended_amount :=  C_dets.precio_unitario_venta * C_dets.CANTIDAD_POR_ORIGEN * -1;
                       g_lin_art_rec.unit_selling_price   :=  C_dets.precio_unitario_venta;
                      INSERTAR_DETALLE (  p_provincia_origen                 => C_dets.PROVINCIA_ORIGEN
                                                      , p_cantidad_por_origen           =>  C_dets.CANTIDAD_POR_ORIGEN * -1
                                                      , p_provincia_destino               => C_dets.PROVINCIA_DESTINO
                                                      , p_cantidad_por_destino         => C_dets.CANTIDAD_POR_DESTINO * -1
                                                      , p_carta_porte_envio              => C_dets.CARTA_PORTE_ENVIO
                                                      , p_carta_porte_insumo           => C_dets.CARTA_PORTE_INSUMO
                                                      , p_tipo_oper                          => 'CLASIFICA'
                                                      , x_errmsg                                => l_errmsg
                                                      , p_result                               => l_result
                                                       );

                      IF (NOT l_result) THEN
                          l_errmsg :=  'Error en Nota_credito_RevierteFC -  '||l_errmsg;
                          RAISE hay_errores;
                      END IF;
                        l_inserta := l_inserta +1;

                    END LOOP;
        else
                        FOR C_dets in  (SELECT  PROVINCIA_ORIGEN, CANTIDAD_POR_ORIGEN, CANTIDAD_POR_DESTINO,PROVINCIA_DESTINO, CARTA_PORTE_ENVIO,CARTA_PORTE_INSUMO, PRECIO_UNITARIO_VENTA
                                                     FROM xx_ar_iibb_det WHERE TRX_ID = L_TRX_ID_FACT
                                        and ITEM_DESC = g_lin_art_rec.item_desc
                                        and nvl(tipo_operacion,'X') <> 'R') LOOP
                              g_lin_art_rec.extended_amount :=  C_dets.precio_unitario_venta * C_dets.CANTIDAD_POR_ORIGEN * -1;
                              g_lin_art_rec.unit_selling_price   :=  C_dets.precio_unitario_venta;
                              INSERTAR_DETALLE (  p_provincia_origen                 => C_dets.PROVINCIA_ORIGEN
                                                              , p_cantidad_por_origen           =>   -1
                                                              , p_provincia_destino               => C_dets.PROVINCIA_DESTINO
                                                              , p_cantidad_por_destino         =>  -1
                                                              , p_carta_porte_envio              => C_dets.CARTA_PORTE_ENVIO
                                                              , p_carta_porte_insumo           => C_dets.CARTA_PORTE_INSUMO
                                                              , p_tipo_oper                          => 'CLASIFICA'
                                                              , x_errmsg                                => l_errmsg
                                                              , p_result                               => l_result
                                                               );

                      IF (NOT l_result) THEN
                          l_errmsg :=  'Error en Nota_credito_RevierteFC sin articulo-  '||l_errmsg;
                          RAISE hay_errores;
                      END IF;
                        l_inserta := l_inserta +1;

                    END LOOP;
        end if;

 else

          INSERTAR_DETALLE (  p_provincia_origen                     => nvl(g_lin_art_rec.pcia_origen_pv,g_lin_art_rec.pcia_origen_fc)  -- toma origen del pv, o de la linea de la factura
                                              , p_cantidad_por_origen           =>  g_lin_art_rec.cant_a_consumir
                                              , p_provincia_destino               => g_fac_rec.pcia_destino_fc                                                      -- destino de la cabecera de factura
                                              , p_cantidad_por_destino         => g_lin_art_rec.cant_a_consumir
                                              , p_carta_porte_envio              => 'Nota Credito - Directa'
                                              , p_carta_porte_insumo           => NULL
                                              , p_tipo_oper                          => 'CLASIFICA'
                                              , x_errmsg                                => l_errmsg
                                              , p_result                               => l_result
                                               );
                    l_inserta := 1;
                      IF (NOT l_result) THEN
                          l_errmsg :=  'Error en Nota_credito_RevierteFC -  '||l_errmsg;
                          RAISE hay_errores;
                      END IF;

 end if;
        if l_inserta > 0 then
                debug( '+ '||'Nota_credito_RevierteFC'||' -> revirtio detalles / consumo' , NULL );
            return true;
       else
                   debug( '+ '||'Nota_credito_RevierteFC'||' -> No hay informacion a revertir', NULL );
            return false;
       end if;
  EXCEPTION
    WHEN hay_errores then
      debug( '- '||l_errmsg ||'. '||SQLERRM, NULL );
       g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'Nota_credito_RevierteFC  -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := 'Nota_credito_revierte_fc --> ' || sqlerrm;
         end if;
      return false;
  END Nota_credito_RevierteFC;


 /********************************************************************************+
  | Function                                                                       |
  |    INTERCO_OBTIENE_CP_SALIDA                                                  |
  | Description                                                                    |
  |    Obtiene las Cartas de Porte de salida  una Liquidacion Interco                      |
  | Parameters                                                                     |
  |    pc_liquidacion   IN      Numero de Liquidacion Interco                      |
  |    pc_tabla         IN      Tabla de Cartas de Porte de la Liquidacion Interco |
  +********************************************************************************/
  FUNCTION INTERCO_OBTIENE_CP_SALIDA ( PC_LIQUIDACION  IN  VARCHAR2) RETURN TipoTablaCP IS

    l_CP_sal                                 TipoCPSalRec;
    l_tabla                                    TipoTablaCP;
    hay_errores                            EXCEPTION;
    v_result                                   BOOLEAN;
    l_pcia_origen_liq                       hz_geographies.geography_name%type;
    l_pcia_destino_liq                      hz_geographies.geography_name%type;
    l_liquidacion                             xx_tcg_liquidaciones.NUMERO_LIQUIDACION%type;

    l_errmsg                                      VARCHAR2(4000);

  BEGIN
    debug( '+ '||'INTERCO_OBTIENE_CP_SALIDA'||' -> liquidacion: ' || PC_LIQUIDACION ||' -> g_fac_rec.tipo_liq : ' || g_fac_rec.tipo_liq  || '  g_fac_rec.pcia_destino_fc ' || g_fac_rec.pcia_destino_fc, NULL );
    l_tabla.delete;
    IF SUBSTR(pc_liquidacion,1,2) = 'A-' then
       l_liquidacion    := SUBSTR(pc_liquidacion,3,20);
    ELSE
        l_liquidacion   := pc_liquidacion;
    END IF;

    BEGIN

            SELECT xtp_o.GEOGRAPHY_NAME, xtp_d.GEOGRAPHY_NAME
              INTO l_pcia_origen_liq, l_pcia_destino_liq
              FROM XX_TCG_LIQUIDACIONES xliq,
                       XX_TCG_PROVINCIAS_ARG xtp_o,
                       XX_TCG_PROVINCIAS_ARG xtp_d
             WHERE     xliq.PROCEDENCIA = xtp_o.GEOGRAPHY_CODE(+)
                   AND xliq.PROVINCIA_DESTINO_CODE = xtp_d.GEOGRAPHY_CODE(+)
                   AND xliq.NUMERO_LIQUIDACION = l_LIQUIDACION;

   EXCEPTION when others then
                            l_pcia_origen_liq := null;
                            l_pcia_destino_liq := null;
    end;
    l_pcia_origen_liq := nvl(l_pcia_origen_liq , g_lin_art_rec.pcia_origen_fc);
    l_pcia_destino_liq := nvl(l_pcia_destino_liq,  g_fac_rec.pcia_destino_fc);
    g_lin_art_rec.tipo_operacion := 'C';

      FOR cp IN  (  SELECT xliq.NUMERO_LIQUIDACION
                                            ,xcpl.carta_porte_id
                                            ,cdp.numero_carta_porte
                                            ,cdp.pcia_destino_cp
                                           , sum(xcpl.cantidad_a_liquidar) cant_adar_origen
                         FROM apps.xx_tcg_liquidaciones           xliq
                                 , apps.xx_tcg_cartas_porte_liquidadas xcpl
                                , (select numero_carta_porte, carta_porte_id, upper(xtp.GEOGRAPHY_name) pcia_destino_cp
                                     from xx_tcg_cartas_porte_all xtcp    , XX_TCG_PROVINCIAS_ARG  xtp
                                    where nvl(anulado_flag,'N') = 'N'
                                        and xtcp.DESTINO_PROVINCIA                                = xtp.GEOGRAPHY_CODE
                                    UNION
                                   select numero_carta_porte, carta_porte_id , UPPER(DESTINO_GRANO_PROVINCIA) pcia_destino_cp
                                     from xx_aco_cartas_porte_b where nvl(anulado_flag,'N') = 'N')  cdp
                        WHERE xliq.liquidacion_id = xcpl.liquidacion_id
                            AND xcpl.liquidacion_id = xliq.liquidacion_id
                            AND xliq.NUMERO_LIQUIDACION =   l_liquidacion
                            AND xcpl.cantidad_a_liquidar <> 0
                            AND cdp.carta_porte_id = xcpl.carta_porte_id
                         GROUP BY xliq.NUMERO_LIQUIDACION ,xcpl.carta_porte_id,cdp.numero_carta_porte,cdp.pcia_destino_cp
                                 ) LOOP

                  l_cp_sal                                   := g_empty_SqlRec;
                  l_CP_Sal.numero_carta_porte    := cp.numero_carta_porte;
                  l_CP_Sal.cant_adar_origen         := cp.cant_adar_origen;
                  l_CP_Sal.carta_porte_id             := cp.carta_porte_id;
                  l_CP_Sal.pcia_destino_cp           := cp.pcia_destino_cp;

                 begin
                               SELECT max(order_number)
                               INTO   l_CP_Sal.nro_pedido
                               FROM XX_TCG_ASOCIA_PEDIDO_VENTA xtap,
                                          oe_order_headers_all ooh
                                 WHERE xtap.carta_porte_id = cp.carta_porte_id
                                 AND xtap.oe_order_header_id = ooh.HEADER_ID;

                                 select  max(oot.name)
                                 INTO   l_CP_Sal.tipo_pedido
                                 from oe_transaction_types_v   oot ,
                                          oe_order_headers_all ooh
                                 where oot.transaction_type_id = ooh.order_type_id
                                 and ooh.order_number =   l_CP_Sal.nro_pedido;

                 EXCEPTION WHEN OTHERS THEN
                           l_CP_Sal.nro_pedido  := NULL;
                           l_CP_Sal.tipo_pedido := NULL;
                 END;

              debug('- '||'INTERCO_OBTIENE_CP_SALIDA'||' nro  CP ' ||  l_CP_Sal.numero_carta_porte || ' id_cp ' || l_CP_Sal.carta_porte_id , NULL )  ;

      l_tabla (l_tabla.count+1)    := l_CP_Sal;
     END LOOP;
       -- se asume que están ok los kgs , no hay control si faltan kgs a clasificar o si no alcanzan ##
       -- Inserta detalle : por remanente sin liquidaciones
      IF l_tabla.count  = 0     THEN

            -- ------------------------------
            -- Inserto en la tabla de detalle
            -- ------------------------------
          debug ( 'Inserta sin liquidaciones ' || g_lin_art_rec.pcia_origen_fc || '  Destino ' || g_fac_rec.pcia_destino_fc, NULL );

          INSERTAR_DETALLE (  p_provincia_origen                 => g_lin_art_rec.pcia_origen_fc
                                          , p_cantidad_por_origen           =>  g_lin_art_rec.cant_a_consumir
                                          , p_provincia_destino               => g_fac_rec.pcia_destino_fc
                                          , p_cantidad_por_destino         => g_lin_art_rec.cant_a_consumir
                                          , p_carta_porte_envio              => 'Inter Sin liquidaciones'
                                          , p_carta_porte_insumo           => NULL
                                          , p_tipo_oper                          => 'CLASIFICA'
                                          , x_errmsg                                => l_errmsg
                                          , p_result                               => v_result
                                           );

          IF (NOT v_result) THEN
              l_errmsg := 'Error en INTERCO_OBTIENE_CP_SALIDA  '||l_errmsg;
              RAISE hay_errores;
          END IF;

      END IF;

    debug('- '||'INTERCO_OBTIENE_CP_SALIDA'||' cantidad de CP ' || l_tabla.count , NULL )  ;
    RETURN ( l_tabla );

  EXCEPTION
    WHEN hay_errores then
      debug( '- '||'INTERCO_OBTIENE_CP_SALIDA'||'. '||SQLERRM, NULL );
       g_error_flag      := TRUE;
               IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'INTERCO_OBTIENE_CP_SALIDA  -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := 'INTERCO_OBTIENE_CP_SALIDA -> ' || sqlerrm;
         end if;

  END INTERCO_OBTIENE_CP_SALIDA;


PROCEDURE GET_DATOS_PEDIDO   IS
l_item_id    number;
l_especie_oncca_iibb varchar2(100);
  BEGIN

          -- Obtiene si el pedido es propio o de terceros para despues cargar consumo
         SELECT NVL(MAX( DECODE(NVL(XX_OM_ORIGEN_MERCADERIA,'TERCEROS'),'PROPIA PRODUCCION','PROPIA','TERCEROS')),'TERCEROS'), count(1),
                     max( nvl(upper(xtpa.GEOGRAPHY_NAME),xx_om_procedencia_mercaderia)), max( ooh.order_type_id )
            INTO g_lin_art_rec.origen_mercaderia, g_lin_art_rec.conpedido, g_lin_art_rec.pcia_origen_pv, g_lin_art_rec.order_type_id
           FROM  oe_order_headers_all_dfv  ooh_dfv
                    , oe_order_headers_all      ooh
                    , XX_TCG_PROVINCIAS_ARG  xtpa
           WHERE 1=1
               AND ooh.order_number        = g_lin_art_rec.pedido_num
               AND ooh.order_type_id       IN  ( SELECT max(transaction_type_id) FROM   oe_transaction_types_v WHERE  name LIKE '%' || g_lin_art_rec.pedido_tipo || '%')
               AND ooh_dfv.row_id          = ooh.rowid
               and xtpa.GEOGRAPHY_CODE(+) = xx_om_procedencia_mercaderia;
               g_lin_art_rec.conpedido := nvl(g_lin_art_rec.conpedido,0);

         -------------------------------------------------------------------------------------------------------
         -- CR2273  si es articulo Mani, se toma del pedido. Sino se toma según punto emision
         ----------------------------------------------------------------------------------------------------

           if g_lin_art_rec.item_id is not null then
               l_item_id := g_lin_art_rec.item_id;
           else
                select max(INVENTORY_ITEM_ID) into l_item_id
                from oe_order_lines_all ool
                 , oe_order_headers_all      ooh
                WHERE  ooh.order_number        = g_lin_art_rec.pedido_num
                     AND ooh.order_type_id       IN  ( SELECT max(transaction_type_id) FROM   oe_transaction_types_v WHERE  name LIKE '%' || g_lin_art_rec.pedido_tipo || '%')
                     and ool.header_id = ooh.header_id;
           end if;

          IF l_item_id is not null then
                SELECT max(XX_especie_oncca_iibb) into l_especie_oncca_iibb
                  FROM mtl_system_items_b msi
                           , mtl_system_items_b_dfv mdfv
                            , fnd_lookup_values flv, fnd_lookup_values_DFV fdfv
                   WHERE    msi.organization_id = 135
                          AND msi.inventory_item_id = l_item_id
                          and msi.rowid = mdfv.row_id
                          and  flv.lookup_type = 'XX_ACO_ESPECIES_ONCCA'
                       AND flv.lookup_code = mdfv.XX_ACO_CODIGO_ONCCA
                       AND flv.ROWID = fdfv.row_id
                       and flv.language=userenv('LANG');
         else
                l_especie_oncca_iibb := null;
          end if;

            if nvl(l_especie_oncca_iibb,'XX')  = 'MANI' then
                g_lin_art_rec.origen_mercaderia := nvl(g_lin_art_rec.origen_mercaderia,'TERCEROS');
            else
                if      substr( g_fac_rec.trx_number,3,4 ) in ('3301','3302') then
                            g_lin_art_rec.origen_mercaderia := 'PROPIA';
                else
                             g_lin_art_rec.origen_mercaderia :='TERCEROS';
                end if;
            end if;
        -----------------------------------------------------------------------
        -- FIN CR2273
        -----------------------------------------------------

    debug( '- '||'GET_DATOS_PEDIDO' ||' ' || g_lin_art_rec.pedido_num || '-' || g_lin_art_rec.order_type_id  || ' cant ' ||g_lin_art_rec.conpedido || 'origen pv ' || g_lin_art_rec.pcia_origen_pv  || ' Origen Merc ' || g_lin_art_rec.origen_mercaderia, NULL );
end GET_DATOS_PEDIDO;
PROCEDURE GET_VALORES_FINALES   (p_item_id in out number,
                                                        p_cantidad_total in out number,
                                                         p_precio_unitario in out number,
                                                          p_organization_id in out number,
                                                          p_uom_code in out varchar2) is
l_precio_total      number;
l_casos number;
begin
select count(*) into l_casos from  bolinf.XX_AR_TCG_ASOCIA_LIQ  where cust_trx_id_final = g_fac_rec.trx_id;
if l_casos > 0 then
    SELECT MAX(NVL(INVENTORY_ITEM_ID,0)) ITEM_ID ,
            SUM( DECODE(NVL(INVENTORY_ITEM_ID,0),0,0,QUANTITY_INVOICED)) CANTIDAD_TOTAL,
            SUM( EXTENDED_AMOUNT) PRECIO_TOTAL,
            MAX(NVL(warehouse_id,0)) organization_id,
            max(decode(nvl(inventory_item_id,0),0,'',rctl.uom_code)) uom_code
            into p_item_id, p_cantidad_total, l_precio_total, p_organization_id, p_uom_code
            FROM RA_CUSTOMER_TRX_LINES rctl
             WHERE customer_trx_id in (
                                     select g_fac_rec.trx_id from dual
                                     union
                                     select cust_trx_id_parcial from  bolinf.XX_AR_TCG_ASOCIA_LIQ  atal
                                      where cust_trx_id_final = g_fac_rec.trx_id
                                         and ( g_fac_rec.mezcla_recla_final = 'N'
                                                or
                                               (not exists (select 1 from   ra_customer_trx   rct
                                                                       where  rct.customer_trx_id = atal.cust_trx_id_parcial
                                                                          and attribute1 = 'Parcial'
                                                                          and not exists (select 1 from BOLINF.XX_AR_TCG_PARC_ARECLA arec where  arec.CUST_TRX_ID_PARCIAL = rct.customer_trx_id)
                                                                     )
                                                      )
                                                       )) -- ajuste unico y parciales , si están mezcladas que no sean de las nuevas
            AND line_type = 'LINE'
            AND EXISTS ( SELECT 1                           --  la linea corresponda a cereales
                                FROM ar_memo_lines_all_b_dfv ml_dfv,
                                         ar_memo_lines_all_b     ml
                                WHERE 1=1
                                AND rctl.memo_line_id is not null
                                AND ml.memo_line_id = rctl.memo_line_id
                                AND ml_dfv.row_id = ml.rowid
                                AND nvl(ml_dfv.xx_incluir_reporte_iibb,'N/A') = 'CEREAL'
                                UNION ALL
                                SELECT 1
                                FROM mtl_categories_b_dfv  mc_dfv,
                                         mtl_categories_v      mc,
                                        mtl_item_categories_v micv
                                WHERE 1=1
                                AND micv.organization_id = rctl.warehouse_id
                                AND micv.inventory_item_id = rctl.inventory_item_id
                                AND micv.category_set_name = 'Inventory'
                                AND mc.category_id = micv.category_id
                                AND mc_dfv.row_id = mc.row_id
                                AND nvl(mc_dfv.xx_incluir_reporte_iibb,'N/A') = 'CEREAL'
                                );

                    if  nvl(p_cantidad_total,1) = 0 then
                       p_precio_unitario :=  round(l_precio_total ,5);
                    else
                         p_precio_unitario       := round(l_precio_total / nvl(p_cantidad_total,1),5);
                    end if;
    else
            p_precio_unitario := 0;
            p_cantidad_total  := 0;
            p_item_id := 0;
            p_organization_id := 0;
    end if;
 debug( 'GET_VALORES_FINALES CANTIDAD_FINAL :' || p_cantidad_total, 5 );

end GET_VALORES_FINALES;
PROCEDURE FINAL_RECLASIFICA IS

    e_exception     EXCEPTION;
    saltea_reversion EXCEPTION;

l_item_id                       NUMBER;
l_cantidad_final              NUMBER;
l_precio_uni_final           NUMBER;
l_organization_id            NUMBER;
 v_carta_porte_envio      xx_ar_iibb_det_all.carta_porte_envio%type;
l_errmsg                       VARCHAR2(4000);
 v_result                        BOOLEAN;
 l_uom_code                  varchar2(10);
 l_leyen                          varchar2(70);
 l_casos_mezcla_anti       number := 0;
 l_casos_mezcla_parc       number := 0;
 l_aux number(2);
 l_facturas                     varchar2(4000);

BEGIN
            l_facturas := null;
            l_casos_mezcla_anti := 0;
            l_casos_mezcla_parc := 0;
             g_fac_rec.mezcla_recla_final := 'N';

            for c1_parc in (select rct.trx_number, cust_trx_id_parcial , rct.attribute1
                                     from bolinf.XX_AR_TCG_ASOCIA_LIQ atal,
                                             ra_customer_trx                   rct
                                    where atal.cust_trx_id_final             =  g_fac_rec.trx_id
                                    and rct.customer_trx_id = atal.cust_trx_id_parcial) loop
                IF l_facturas is null then
                   l_facturas := 'Liq. Parciales : ' || c1_parc.trx_number;
                ELSE
                   l_facturas := l_facturas || ' , ' || c1_parc.trx_number;
                END IF;

                IF g_fac_rec.tipo_recla_final = 'H' then
                     if c1_parc.attribute1 = 'Anticipo' then
                        g_fac_rec.mezcla_recla_final := 'S';
                        l_casos_mezcla_parc := l_casos_mezcla_parc + 1;
                        l_facturas := l_facturas || '(Anti)';
                     ELSE
                         select count(1)     INTO L_AUX from BOLINF.XX_AR_TCG_PARC_ARECLA arec where  arec.CUST_TRX_ID_PARCIAL = C1_PARC.CUST_TRX_ID_PARCIAL;
                         if l_aux = 0 then
                            l_casos_mezcla_parc := l_casos_mezcla_parc + 1;
                            g_fac_rec.mezcla_recla_final := 'S';
                            l_facturas := l_facturas || '(Parc)' ;
                         END IF;
                     END IF;
                ELSE
                     if c1_parc.attribute1 <> 'Anticipo' then  -- Verifica que  las parciales correspondan a anticipos
                        l_casos_mezcla_anti := l_casos_mezcla_anti + 1;
                        l_facturas := l_facturas || '(Parc)';
                        g_fac_rec.mezcla_recla_final := 'S';
                    end if;

                END IF;
             END LOOP;
             IF length(l_facturas) > 1900  then
                l_facturas := substr(l_facturas,1,1900) || '...mas...';
             END IF;

            g_lin_art_rec.tipo_operacion := 'C';
            if g_fac_rec.tipo_recla_final = 'A' then
                   l_leyen := 'Liq.Final de Anticipos';
                IF l_casos_mezcla_anti > 0 then
                    l_leyen :=   l_leyen || '- CON OTROS';
                    l_facturas :=  'Con parciales <> a Anticipo ' || l_facturas ;
               END IF;
            else
                   l_leyen :=  'Liq.Final Parc.Histo';
                IF l_casos_mezcla_parc > 0 then
                    l_leyen := l_leyen || ' - CON OTROS';
                    l_facturas :=  'Con parciales <> a Historicas ' || l_facturas ;  -- Distinguir y solo reclasificar las viejas
               END IF;
            END IF;
            INSERTAR_DETALLE (  p_provincia_origen                 => nvl(g_lin_art_rec.pcia_origen_pv,g_lin_art_rec.pcia_origen_fc)  -- toma origen del pv, o de la linea de la factura
                                              , p_cantidad_por_origen           =>  g_lin_art_rec.cant_a_consumir
                                              , p_provincia_destino               => g_fac_rec.pcia_destino_fc                                                      -- destino de la cabecera de factura
                                              , p_cantidad_por_destino         => g_lin_art_rec.cant_a_consumir
                                              , p_carta_porte_envio              => l_leyen
                                              , p_carta_porte_insumo           => NULL
                                              , p_tipo_oper                          => 'CLASIFICA'
                                              , p_observa                           =>   l_facturas
                                              , x_errmsg                                => l_errmsg
                                              , p_result                               => v_result
                                               );

              IF (NOT v_result) THEN
                  l_errmsg := 'Error en FINAL_RECLASIFICA  '||l_errmsg;
                  RAISE e_exception;
              END IF;

              begin
                    g_lin_art_rec.tipo_operacion := 'R';
                     --- Obtiene nro liquidacion de parcial , numero de transacciones -->  parcial y final. y datos final
                    g_fac_rev           := g_empty_fac_rec;
                    g_lin_art_rev       := g_empty_lin_art_rec;
                     GET_VALORES_FINALES   (p_item_id               => l_item_id
                                                         , p_cantidad_total     => l_cantidad_final
                                                         , p_precio_unitario    => l_precio_uni_final
                                                         , p_organization_id   => l_organization_id
                                                         ,p_uom_code           => l_uom_code);

                    FOR c_parc in (select g_fac_rec.trx_id    trx_id  from dual where l_item_id <> 0
                                            union
                                          select atal.cust_trx_id_parcial  trx_id                  -- obtiene los numeros de trx de parcial
                                            from  bolinf.XX_AR_TCG_ASOCIA_LIQ atal
                                          where cust_trx_id_final             =  g_fac_rec.trx_id
                                             AND g_fac_rec.cant_lineas     = 1
                                             and ( g_fac_rec.mezcla_recla_final = 'N' or
                                                      (not exists (select 1 from   ra_customer_trx   rct
                                                                       where  rct.customer_trx_id = atal.cust_trx_id_parcial
                                                                          and attribute1 = 'Parcial'
                                                                          and not exists (select 1 from BOLINF.XX_AR_TCG_PARC_ARECLA arec where  arec.CUST_TRX_ID_PARCIAL = rct.customer_trx_id)
                                                                     )
                                                      )
                                                      )  --  parciales , si están mezcladas que no sean de las nuevas
                                             order by 1 ) loop

                         debug(' FINAL_RECLASIFICA Antes loop -> g_fac_rec.trx_id  : ' || g_fac_rec.trx_id  ||' ->  c_parc.cust_trx_id_parcial : ' ||  c_parc.TRX_ID , 5 );

                        -- Se revierten los  registros uno por final y uno o varios por parcial . La parcial no genero consumos, por lo que no se revierten
                         FOR c_rev IN (select   rct.trx_number , rct.CUSTOMER_TRX_ID , xdet.TRX_ID, xdet.TRX_NUM, xdet.TRX_DATE, xdet.TRX_LINE_ID, xdet.ITEM_ID, xdet.ITEM_DESC,
                                                            xdet.DESCUENTO_COMERCIAL dto_COMERCIAL, xdet.ITEM_CATEGORY, xdet.UNIDAD_MEDIDA_PRIMARIA, xdet.PRECIO_UNITARIO_VENTA,
                                                            xdet.PRECIO_TOTAL_VENTA, xdet.PEDIDO, xdet.CARTA_PORTE_INSUMO,  xdet.provincia_origen, xdet.provincia_destino,  xdet.CANTIDAD_FACTURADA,
                                                            xdet.UNIDAD_MEDIDA_TRX, xdet.CANTIDAD_POR_ORIGEN, xdet.CANTIDAD_POR_destino
                                               FROM  ra_cust_trx_types_all_dfv      rctt_dfv
                                                       , ra_cust_trx_types                 rctt
                                                       , ra_customer_trx_all_dfv        rct_dfv
                                                       , ra_customer_trx                   rct
                                                       ,  xx_ar_iibb_cab_all               xcab
                                                       , xx_ar_iibb_det_all                xdet
                                                       , ra_customer_trx_lines          ctl
                                              WHERE  rct.customer_trx_id               = c_parc.trx_id
                                              AND rct.complete_flag                      = 'Y'
                                              AND rct_dfv.row_id                          = rct.ROWID
                                              AND rctt.cust_trx_type_id                  = rct.cust_trx_type_id
                                              AND rctt_dfv.row_id                         = rctt.rowid
                                              AND nvl(rctt_dfv.xx_ar_rep_iibb,'Y')   = 'Y'
                                              AND xcab.org_id                              = xdet.org_id
                                              AND xcab.org_id                              = rct.org_id
                                              AND ctl.customer_trx_id                   = rct.customer_trx_id
                                              AND xdet.trx_line_id                         = ctl.customer_trx_line_id
                                              AND xcab.header_id                         = xdet.header_id
                                              AND xcab.tipo_logica                        LIKE 'CEREAL%'
                                              AND nvl(xdet.carta_porte_envio,'X')               not like 'Reversion%'
                                              and (c_parc.trx_id  <> g_fac_rec.trx_id
                                                         or not exists (select 1 from    xx_ar_iibb_det xex  --  verifica que no lo haya cargado en lineas anteriores de la liquidacion final (solo si la final tiene mas de una linea)
                                                                             where nvl(xex.carta_porte_envio,'X')  like 'Reversion%'
                                                                              and xex.tipo_operacion = 'R'
                                                                              and xex.trx_id = xdet.TRX_ID
                                                                              and xex.trx_line_id = xdet.TRX_LINE_ID
                                                                              and xex.HEADER_ID in (g_hdr_id_propio,  g_hdr_id_tercero )
                                                                             )
                                                     )
                                              order by rct.trx_number, TRX_LINE_ID ) loop

                                       debug(' FINAL_RECLASIFICA en loop -> g_fac_rec.trx_id  : ' || g_fac_rec.trx_id  ||' ->  c_parc.cust_trx_id_parcial : ' ||  c_parc.TRX_ID , 5 );

                                        g_fac_rev.trx_id                                  :=    c_rev.trx_id;
                                        g_fac_rev.trx_number                         := c_rev.trx_num;
                                        g_fac_rev.trx_date                             := c_rev.trx_date;
                                        g_fac_rev.tipo_trx                              := g_fac_rec.tipo_trx;
                                        g_fac_rev.customer_id                        := g_fac_rec.customer_id;
                                        g_fac_rev.customer_name                  := g_fac_rec.customer_name;
                                        g_lin_art_rev.trx_line_id                      := c_rev.trx_line_id;
                                        g_lin_art_rev.item_id                          := c_rev.item_id;
                                        g_lin_art_rev.categ_seg_concat           := c_rev.ITEM_CATEGORY;
                                        g_lin_art_rev.item_desc                      := c_rev.item_desc;
                                        g_lin_art_rev.xx_aco_codigo_oncca     := null;
                                        g_lin_art_rev.dto_COMERCIAL             := c_rev.dto_COMERCIAL;
                                        g_lin_art_rev.extended_amount          := c_rev.PRECIO_TOTAL_VENTA;
                                        g_lin_art_rev.pedido_num                  :=  c_rev.PEDIDO;
                                        g_lin_art_rev.quantity_invoiced           := c_rev.CANTIDAD_FACTURADA;
                                        g_lin_art_rev.quantity_credited           := 0;
                                        g_lin_art_rev.uom_code                     := c_rev.UNIDAD_MEDIDA_TRX;
                                        g_lin_art_rev.primary_uom_code        := c_rev.UNIDAD_MEDIDA_PRIMARIA;
                                        g_lin_art_rev.unit_selling_price           := c_rev.PRECIO_UNITARIO_VENTA;
                                        g_lin_art_rev.factor_conver_um         :=  g_lin_art_rec.factor_conver_um;

                                        if    c_rev.trx_id = g_fac_rec.trx_id   then
                                                v_carta_porte_envio := 'Reversion Final Pedido';
                                        else
                                                v_carta_porte_envio := 'Reversion Parcial Pedido';
                                        end if;

                                        INSERTAR_DETALLE (  p_provincia_origen                 => c_rev.provincia_origen
                                                                          , p_cantidad_por_origen           =>  c_rev.cantidad_por_origen*-1
                                                                          , p_provincia_destino               => c_rev.provincia_destino
                                                                          , p_cantidad_por_destino         => c_rev.cantidad_por_destino*-1
                                                                          , p_carta_porte_envio              =>  v_carta_porte_envio
                                                                          , p_carta_porte_insumo           => NULL
                                                                          , p_tipo_oper                          => 'REVIERTE'
                                                                          , x_errmsg                                => l_errmsg
                                                                          , p_result                               => v_result
                                                                           );

                                          IF (NOT v_result) THEN
                                              l_errmsg := 'Error en FINAL_RECLASIFICA  '||l_errmsg;
                                              RAISE e_exception;
                                          END IF;

                         end loop;

                     end loop;

                    if l_item_id = 0 THEN -- no tiene informacion la tabla auxiliar solo se toma la final sin reclasificar se fuerza la cantidad de lineas a 2
                         g_fac_rec.reclasifica_final := 0;
                    elsif g_fac_rec.cant_lineas > 1 then
                         g_fac_rec.reclasifica_final := 0;
                    else -- obtiene datos para hacer la reclasificacion
                          g_fac_rec.reclasifica_final := 1;
                          GET_DATOS_ITEMS(l_item_id, l_organization_id);--> ACTUALIZA primary_uom_code  y categ_seg_concat
                          g_lin_art_rec.item_id                         := l_item_id;
                          g_lin_art_rec.memo_line_id                := null;
                          g_lin_art_rec.unit_selling_price           := l_precio_uni_final;
                          g_lin_art_rec.extended_amount          := round(l_precio_uni_final * l_cantidad_final,2);
                          g_lin_art_rec.quantity_invoiced           := l_cantidad_final;
                          g_lin_art_rec.quantity_credited           := 0;
                          g_lin_art_rec.uom_code                    := l_uom_code ;
                          if nvl(g_lin_art_rec.uom_code , 'X' ) = 'BOL' THEN -- Se supone que son semillas y no tienen pedidos
                                g_lin_art_rec.factor_conver_um := 1;
                          ELSif nvl(g_lin_art_rec.uom_code , 'X' ) <> 'KG' then
                              g_lin_art_rec.factor_conver_um  := INV_CONVERT.inv_um_convert( item_id       =>g_lin_art_rec.item_id
                                                                                    , precision     => 5
                                                                                    , from_quantity => 1
                                                                                    , from_unit     => g_lin_art_rec.uom_code
                                                                                    , to_unit       => 'KG'
                                                                                    , from_name     => null
                                                                                    , to_name       => null);

                                  IF (g_lin_art_rec.factor_conver_um = -99999) THEN
                                      l_errmsg := 'Error en INV_CONVERT.inv_um_convert. Item_id '|| g_lin_art_rec.item_id
                                                        ||', From Unit '||g_lin_art_rec.uom_code ||', To Unit '|| 'KG';
                                      RAISE e_exception;
                                  END IF;
                         else
                                g_lin_art_rec.factor_conver_um := 1;
                         END IF;

                         g_lin_art_rec.cant_a_consumir           := l_cantidad_final *  g_lin_art_rec.factor_conver_um;

                    end if;

                    debug( 'FINAL_RECLASIFICA Sale :'||g_lin_art_rec.pedido_num || ' TipoPedido:' || g_lin_art_rec.pedido_tipo || ' Item:' || l_item_id|| ' cant/precio' || l_cantidad_final ||'/' ||l_precio_uni_final, 5 );
              exception
                            WHEN saltea_reversion THEN NULL;
              END;

    EXCEPTION
                WHEN e_exception then
                    debug( '- '||l_errmsg||'. '||SQLERRM, NULL );
                    g_error_flag      := TRUE;
                    IF g_error_msg IS NOT NULL  THEN
                       g_error_msg := 'FINAL_RECLASIFICA  -> ' || sqlerrm || g_error_msg;
                    else
                          g_error_msg   := 'FINAL_RECLASIFICA --> ' || SQLERRM;
                     end if;

END FINAL_RECLASIFICA;


    FUNCTION PEDIDO_OBTIENE_CP_SALIDA  RETURN TipoTablaCP IS

    l_errmsg                  VARCHAR2(1000);
    l_CP_Sal                 TipoCPSalRec;
    l_tabla                     TipoTablaCP;
    e_exception             EXCEPTION;
    e_continue_next       EXCEPTION;

    v_existe_lineas_pv                  BOOLEAN;
    v_existe_cp_consaldo              BOOLEAN;
    v_result                                 BOOLEAN;
    v_peso_aplicado_totcp            number;
    v_consumido_cp                     numbeR;
    v_a_consumir_fac                   number;
    v_peso_pedido_cp                   number;
    v_a_consumir_paso                 number;
    v_carta_porte_envio                xx_ar_iibb_det_all.carta_porte_envio%type;
    v_pcia_destino                        hz_geographies.geography_name%type;
    v_pcia_origen                         hz_geographies.geography_name%type;
    l_factor_conversion                 number := 1;
    l_cant_cp                               number := 0;
    l_cant_cp_cons                       number :=0;
    v_consumido_relacion             number;
    v_disponible_relacion              number;
   v_disponible_cp                       number;
   -- informacion para liquidacion final
   l_item_id                               number;
   l_organization_id                    number;
   l_precio_uni_final                   number;
   l_cantidad_final                      number;
   -- Para Final

   l_casos_parciales                   number;

   l_anula_total                          number(2);
   lf_item_id                              number;
   lf_cantidad_final                     number;
   lf_precio_uni_final                  number;
   lf_organization_id                   number;
   lf_uom_code                          varchar2(10);
   lf_cantidad_por_origen            number;
   lf_cantidad_por_destino           number;
   lf_carta_porte_envio                varchar2(70);
   lf_carta_porte_insumo             varchar2(70);

   v_cp_conerror                        number;
   v_eserr                                  varchar2(1);
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Bloque para Final : si es anulacion total (debe cancelar con las cp y los consumos de las parciales)
--                            si es una final com de una parcial --> toma solo origen y destino
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
procedure   FINAL_SIN_RECLA(p_anula_total in number)  is
l_facturas varchar2(4000);
begin

            l_facturas := null;
            for c1_parc in (select rct.trx_number
                                 FROM bolinf.XX_AR_TCG_ASOCIA_LIQ atal,
                                         ra_customer_trx                   rct
                WHERE atal.cust_trx_id_final             =  g_fac_rec.trx_id
                and rct.customer_trx_id = atal.cust_trx_id_parcial) loop
                if l_facturas is null then
                   l_facturas := 'Liq. Parciales : ' || c1_parc.trx_number;
                else
                   l_facturas := l_facturas || ', ' || c1_parc.trx_number;
                end if;
             end loop;
            IF length(l_facturas) > 1900  then
                l_facturas := substr(l_facturas,1,1900) || '...mas...';
             END IF;
           debug( '+ '||'   FINAL_SIN_RECLA  - ' || l_facturas || ' CANT. LINEAS ' || p_anula_total, NULL );

           l_casos_parciales := 0;

            --  p_anula_total, para determinar la cantidad de lineas a recuperar de las parciales asociadas
             -- si tiene p_anula_total = 2 , toma solo la primer parcial
             -- si p_anula_total = 99, toma todas las parciales)

            g_fac_rec.mezcla_recla_final := 'N';


           for c_parc in (select xata.cust_trx_id_parcial
                             FROM bolinf.XX_AR_TCG_ASOCIA_LIQ xata
                             where xata.cust_trx_id_final = g_fac_rec.trx_id
                               AND xata.org_id                = g_fac_rec.org_id
                               AND rownum < p_anula_total                      --> Obtiene todas las parciales para anulación o solo la primera para final comun
                               and exists (select 1
                                                    FROM  XX_AR_IIBB_det_all xaid
                                                     WHERE  g_fac_rec.org_id= xaid.org_id
                                                         AND xaid.trx_id = xata.cust_trx_id_parcial
                                                         AND xaid.tipo_operacion = 'C' )) loop

                      l_casos_parciales := l_casos_parciales + 1;

                      debug( '+ '||'   FINAL_SIN_RECLA  -  parciales ' || c_parc.cust_trx_id_parcial  , NULL );

                        for c_dets in ( SELECT xaid.provincia_origen, xaid.provincia_destino, xaid.cantidad_por_origen, xaid.cantidad_por_destino,
                                                        xaid.carta_porte_envio, xaid.carta_porte_insumo
                                      FROM  XX_AR_IIBB_det_all xaid
                                     WHERE  g_fac_rec.org_id= xaid.org_id
                                           AND xaid.trx_id = c_parc.cust_trx_id_parcial
                                           AND xaid.tipo_operacion = 'C'
                                           AND rownum < p_anula_total) loop

                                debug( '+ '||'   FINAL_SIN_RECLA  -  detalle  ' || c_dets.provincia_origen  , NULL );

                                 IF p_anula_total <> 99 then
                                    lf_cantidad_por_origen          := g_lin_art_rec.cant_a_consumir;
                                    lf_cantidad_por_destino         := g_lin_art_rec.cant_a_consumir;
                                    lf_carta_porte_envio              :=  'Liq.Ajuste Unico';
                                    lf_carta_porte_insumo           := null;

                                 else
                                    lf_cantidad_por_origen          := c_dets.cantidad_por_origen*-1;
                                    lf_cantidad_por_destino         :=  c_dets.cantidad_por_destino*-1;
                                    lf_carta_porte_envio              :=  c_dets.carta_porte_envio;
                                    lf_carta_porte_insumo           := c_dets.carta_porte_insumo;
                                    l_facturas                              := 'Cancelacion TOTAL : ' || l_facturas;
                                  end if;


                                INSERTAR_DETALLE (  p_provincia_origen                => c_dets.provincia_origen
                                                         , p_cantidad_por_origen           =>  lf_cantidad_por_origen
                                                         , p_provincia_destino               => c_dets.provincia_destino
                                                         , p_cantidad_por_destino         => lf_cantidad_por_destino
                                                         , p_carta_porte_envio              => lf_carta_porte_envio
                                                         , p_carta_porte_insumo           => lf_carta_porte_insumo
                                                         , p_tipo_oper                          => 'CLASIFICA'
                                                         , p_observa                            => l_facturas
                                                         , x_errmsg                             => l_errmsg
                                                         , p_result                               => v_result
                                                           );
                              IF (NOT v_result) THEN

                                  l_errmsg := 'Error en Final Detalle- PEDIDO_OBTIENE_CP_SALIDA '||l_errmsg;
                                  RAISE e_exception;
                              END IF;
                end loop;

                if p_anula_total = 99 then
                             FOR C_Cons in  (SELECT documento_id, documento_num, CARTA_PORTE_INSUMO, cantidad_total, consumo, provincia_origen, CARTA_PORTE_ENVIO,
                                                             provincia_envio, cantidad_envio
                                                   FROM XX_AR_IIBB_CONS WHERE TRX_ID = c_parc.cust_trx_id_parcial)  LOOP
                                  IF NOT INSERTAR_CONSUMO ( p_documento_id       => c_CONS.documento_id
                                                                              , p_documento_num                => c_CONS.documento_num
                                                                              , p_documento_tipo                 => 'CARTAS_PORTE'

                                                                              , p_fecha                               => g_fac_rec.trx_date
                                                                              , p_cantidad_total                   => c_CONS.cantidad_total * -1
                                                                              , p_consumo                          => c_cons.consumo * -1
                                                                              , p_province                          => c_CONS.provincia_origen
                                                                              , p_carta_porte_envio             => c_CONS.CARTA_PORTE_ENVIO
                                                                              , p_carta_porte_insumo        =>  c_CONS.CARTA_PORTE_INSUMO
                                                                              , p_provincia_envio               =>  c_CONS. PROVINCIA_ENVIO
                                                                              , p_cantidad_envio                => c_cons.CANTIDAD_ENVIO
                                                                              , p_record_level                   => 'F'

                                                                              , p_indent                            => 2
                                                                              , x_errmsg                          => l_errmsg
                                                                                              ) THEN


                                                                        l_errmsg :=  'Error en Final Detalle- PEDIDO_OBTIENE_CP_SALIDA ' || l_errmsg;
                                                                        RAISE e_exception;
                                  END IF;

                            END LOOP;
              end if;
        end loop;
 if l_casos_parciales = 0 then -- no encontró parciales liquidadas  dar de alta solo para detectar error
                                         INSERTAR_DETALLE (  p_provincia_origen                => ''
                                                         , p_cantidad_por_origen           =>   g_lin_art_rec.cant_a_consumir
                                                         , p_provincia_destino               => ''
                                                         , p_cantidad_por_destino         =>  g_lin_art_rec.cant_a_consumir
                                                         , p_carta_porte_envio              =>  'Liq.Ajuste Unico'
                                                         , p_carta_porte_insumo           => null
                                                         , p_tipo_oper                          => 'CLASIFICA'
                                                         , p_observa                            => 'Parcial  sin liquidar - ' || l_facturas
                                                         , x_errmsg                             => l_errmsg
                                                         , p_result                               => v_result
                                                           );
                              IF (NOT v_result) THEN
                                  l_errmsg := 'Error en Final Detalle- PEDIDO_OBTIENE_CP_SALIDA '||l_errmsg;
                                  RAISE e_exception;
                              END IF;
end if;
 debug( '-' ||'   FINAL_SIN_RECLA  - ' || l_facturas, NULL );
exception when others then
       g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'FINAL_SIN_RECLA -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := 'FINAL_SIN_RECLA --> ' || SQLERRM;
         end if;
end;

  BEGIN

    debug( '+ '||'PEDIDO_OBTIENE_CP_SALIDA  - ' || g_fac_rec.tipo_liq || ' Nro linea  ' || g_fac_rec.cant_lineas || ' tipo final ' || g_fac_rec.tipo_recla_final , NULL );

    l_tabla.delete;
    g_lin_art_rec.tipo_operacion := 'C';
    g_fac_rec.mezcla_recla_final := 'N';

       if  g_fac_rec.tipo_liq = 'Anticipo' THEN  -- Tiene Liq, pero no cp. Se toma origen y destino del pedido / Factura (antes eran parciales)
         g_fac_rec.trx_final := null;
          INSERTAR_DETALLE (  p_provincia_origen                     => nvl(g_lin_art_rec.pcia_origen_pv,g_lin_art_rec.pcia_origen_fc)  -- toma origen del pv, o de la linea de la factura
                                              , p_cantidad_por_origen           =>  g_lin_art_rec.cant_a_consumir
                                              , p_provincia_destino               => g_fac_rec.pcia_destino_fc                                                      -- destino de la cabecera de factura
                                              , p_cantidad_por_destino         => g_lin_art_rec.cant_a_consumir
                                              , p_carta_porte_envio              => 'Anticipo'
                                              , p_carta_porte_insumo           => NULL
                                              , p_tipo_oper                          => 'CLASIFICA'
                                              , x_errmsg                                => l_errmsg
                                              , p_result                               => v_result
                                               );
              IF (NOT v_result) THEN
                  l_errmsg := 'Error en Anticipo - PEDIDO_OBTIENE_CP_SALIDA '||l_errmsg;
                  RAISE e_exception;
              END IF;
        RETURN ( l_tabla );
    end if;

    if  g_fac_rec.tipo_liq = 'Final' THEN
        if g_fac_rec.tipo_recla_final = 'S' then -- Sin parciales asignadas
                INSERTAR_DETALLE (  p_provincia_origen                => nvl(g_lin_art_rec.pcia_origen_pv,g_lin_art_rec.pcia_origen_fc)  -- toma origen del pv, o de la linea de la factura
                                             , p_cantidad_por_origen           =>  g_lin_art_rec.cant_a_consumir
                                             , p_provincia_destino               => g_fac_rec.pcia_destino_fc                                                      -- destino de la cabecera de factura
                                             , p_cantidad_por_destino         => g_lin_art_rec.cant_a_consumir
                                             , p_carta_porte_envio              => 'Liq.Ajuste Unico SIN PARCIALES'
                                             , p_carta_porte_insumo           => NULL
                                             , p_tipo_oper                          => 'CLASIFICA'
                                             , x_errmsg                             => l_errmsg
                                             , p_observa                            => 'Liq.Ajuste Unico SIN PARCIALES'
                                           , p_result                               => v_result
                                           );
              IF (NOT v_result) THEN
                  l_errmsg := 'Error en final sin parciales - PEDIDO_OBTIENE_CP_SALIDA '||l_errmsg;
                  RAISE e_exception;
           END IF;
               RETURN ( l_tabla );
         END IF;

         -- verifica si es una anulación
             if g_lin_art_rec.cant_a_consumir < 0 then -- si es una final negativa , verifica si la cantidad_total = 0, entonces es una anulacion total
                                 GET_VALORES_FINALES   (p_item_id               => lf_item_id
                                                                 , p_cantidad_total     => lf_cantidad_final
                                                                 , p_precio_unitario    => lf_precio_uni_final
                                                                 , p_organization_id   => lf_organization_id
                                                                 ,p_uom_code           => lf_uom_code);
                    if lf_cantidad_final = 0 then
                        FINAL_SIN_RECLA(99); --> revierte las parciales
                        RETURN ( l_tabla );
                    end if;
             end if;


        if g_fac_rec.tipo_recla_final = 'X' then
            FINAL_SIN_RECLA(2);        -->   para las nuevas finales
            RETURN ( l_tabla );
        elsif g_fac_rec.tipo_recla_final in ('A','H')  then
            FINAL_RECLASIFICA();      --> finales de historicas o anticipo
            IF g_fac_rec.reclasifica_final = 0  THEN
                RETURN ( l_tabla );
            END IF;
         end if;
    end if;

    ---- procesa 1er linea de parcial y de  Unica
            debug( 'PEDIDO_OBTIENE_CP_SALIDA --> Pedido:'||g_lin_art_rec.pedido_num || ' TipoPedido:' || g_lin_art_rec.pedido_tipo || ' Item:' || g_lin_art_rec.item_id || ' con pedido ' || g_lin_art_rec.conpedido, NULL );

            v_existe_lineas_pv             := FALSE;
            v_existe_cp_consaldo        := FALSE;

            v_a_consumir_fac              := g_lin_art_rec.cant_a_consumir;
            if g_lin_art_rec.conpedido > 0  Then

                 -- Cartas de porte por Nro Pedido . Se agrupan las cp porque puede estar asignada la misma cp en mas de una llinea.
                 for C_CP_xPed in (SELECT ooh.order_number                                  AS pedido_num
                                           , ooh.header_id                                                     AS pedido_id
                                           , t_lineas.asociacion_id                                       AS asociacion_id                -- nuevo
                                           , t_lineas.peso_asociado                                   AS ordered_quantity
                                           , t_lineas.uom
                                           , ooh.org_id
                                           , cdp.numero_carta_porte
                                           , cdp.carta_porte_id
                                           ,cdp.pcia_destino_cp
                                           , cdp.version_cp
                                      FROM
                                          (select oe_order_header_id, asociacion_id, carta_porte_id, peso_asociado, 'KG' UOM
                                            from xx_tcg_asocia_pedido_venta
                                            union
                                           select oe_order_header_id, APLICACION_CONTRATO_ID  asociacion_id , carta_porte_id, peso peso_asociado, 'KG' uom
                                             from xx_aco_aplicacion_contratos) t_lineas
                                         , oe_order_headers_all_dfv  ooh_dfv
                                         , oe_order_headers_all      ooh
                                         ,  (SELECT '12' version_cp, numero_carta_porte, carta_porte_id, upper(xtp.GEOGRAPHY_NAME) pcia_destino_cp
                                                 from xx_tcg_cartas_porte_all xtcp    , XX_TCG_PROVINCIAS_ARG  xtp
                                              where nvl(anulado_flag,'N') = 'N'
                                                and xtcp.DESTINO_PROVINCIA                                = xtp.GEOGRAPHY_CODE
                                              UNION all
                                           select '11' version_cp, numero_carta_porte, carta_porte_id , UPPER(DESTINO_GRANO_PROVINCIA) pcia_destino_cp
                                            from xx_aco_cartas_porte_b
                                            where nvl(anulado_flag,'N') = 'N')        cdp
                                      WHERE 1=1
                                      AND ooh.order_number                      = g_lin_art_rec.pedido_num
                                      and t_lineas.oe_order_header_id        = ooh.header_id
                                      AND ooh.order_type_id                     = g_lin_art_rec.order_type_id
                                      AND ooh_dfv.row_id                          = ooh.rowid
--                                      and (ool.ordered_item_id     = g_lin_art_rec.item_id or  g_lin_art_rec.item_id is null) -- para articulo o memoline toma solo el primer pv.
                                      and t_lineas.carta_porte_id               = cdp.carta_porte_id
                                      and t_lineas.peso_asociado is not null
                               ORDER BY asociacion_id )
                                                                             LOOP

                            BEGIN

                              v_existe_lineas_pv  := TRUE;
                              l_cp_sal    := g_empty_SqlRec;

                              if v_a_consumir_fac = 0 then --> Saldo que falta consumir de la factura
                                 exit;
                              end if;

                              l_cant_cp         := l_cant_cp + 1;

                               v_disponible_cp         := 0;
                               v_disponible_relacion := 0;

                               IF g_lin_art_rec.item_id IS not NULL and g_lin_art_rec.consume_origen = 1 THEN

                                   -- control que la cp no haya sido utilizada con error , solo una vez
                                     select count(1) into v_cp_conerror
                                        from XX_AR_IIBB_ERR
                                        where header_id in ( g_hdr_id_propio, g_hdr_id_tercero)
                                        and  CARTA_PORTE_SALIDA =  C_CP_xPed.numero_carta_porte;

                                    if v_cp_conerror > 0 then
                                       debug( 'CP DESCARTADA : '|| C_CP_xPed.numero_carta_porte   || '  Existe en error '  , NULL );
                                        raise e_continue_next;
                                    end if;

                                         -- todas las cp esta en KG se convierte factura si tiene unidad de medida distinta
                                         IF nvl(C_CP_xPed.UOM,'X' )  = 'BOL' THEN-- Se supone que son semillas y no tienen pedidos
                                                l_factor_conversion := 1;
                                         ELSIF nvl(C_CP_xPed.UOM,'X' ) <> 'KG' then
                                                  l_factor_conversion  := INV_CONVERT.inv_um_convert( item_id       =>g_lin_art_rec.item_id
                                                                                                    , precision     => 5
                                                                                                    , from_quantity => 1
                                                                                                    , from_unit     => C_CP_xPed.UOM
                                                                                                    , to_unit       => 'KG'
                                                                                                    , from_name     => null
                                                                                                    , to_name       => null);

                                                  IF (l_factor_conversion = -99999) THEN
                                                      l_errmsg := 'Error en PEDIDO_OBTIENE_CP_SALIDA --> en INV_CONVERT.inv_um_convert. Item_id '|| g_lin_art_rec.item_id
                                                                        ||', From Unit '|| C_CP_xPed.UOM||', To Unit '|| 'KG';
                                                      RAISE e_exception;
                                                  END IF;
                                         else
                                                l_factor_conversion := 1;
                                         END IF;

                                        v_peso_pedido_cp := C_CP_xPed.ordered_quantity * l_factor_conversion;          -->  kg asignados de la cp a este pv

                                       -- cantidad total de la cp --> v_peso_aplicado_totcp
                                       if C_CP_xPed.version_cp = '12' then
                                            v_peso_aplicado_totcp :=  xx_tcg_CALIDAD_pkg.Get_Peso_Aplicado ( p_carta_porte_id => C_CP_xPed.carta_porte_id
                                                                                                                                         --       , p_item_oncca_code => g_lin_art_rec.xx_aco_codigo_oncca -- comentado 03/09 para que compile
                                                                                                                                               , p_tipo           =>  'RECEP');
                                       else
                                            v_peso_aplicado_totcp :=  xx_aco_acopio_pk.Get_Peso_Aplicado (p_carta_porte_id => C_CP_xPed.carta_porte_id);
                                       end if;
                                       -- buscar lo consumido de : total cp y de la relacion cp origen y destino
                                           SELECT nvl(sum(nvl(xaic.consumo,0)),0),  nvl(sum(decode(nvl(xaic.remito,'0'),g_lin_art_rec.pedido_num,nvl(xaic.consumo,0),0)),0)
                                                INTO v_consumido_cp, v_consumido_relacion
                                                FROM xx_ar_iibb_cons  xaic
                                                WHERE xaic.carta_porte_envio         = C_CP_xPed.numero_carta_porte
                                                AND xaic.item_id                       = g_lin_art_rec.item_id
                                                AND xaic.tipo_documento           =  'CARTAS_PORTE';
                                     -- los consumidos no deberian dar negativos, pero por temas de NC para evitar que se consuma mas que lo asignado a pedido, se consideran cero.
                                      if v_consumido_cp < 0 then
                                        v_consumido_cp := 0;
                                      end if;
                                      if v_consumido_relacion < 0 then
                                        v_consumido_relacion := 0;
                                      end if;
                                      v_disponible_cp         := v_peso_aplicado_totcp - v_consumido_cp;
                                      v_disponible_relacion := v_peso_pedido_cp - v_consumido_relacion;

                                      -- obtiene saldo a consumir  del renglon del pedido y controla consumos
                                      if  g_lin_art_rec.cant_a_consumir <=  0      then   -- es nota de credito
                                            v_a_consumir_paso   :=  v_a_consumir_fac;
                                      elsif  v_disponible_cp <= 0    then  -- la cp ya fue totalmente consumida y no es una nota de credito
                                            l_cant_cp_cons         := l_cant_cp_cons + 1;
                                             debug( 'asociacion_id: '||C_CP_xPed.asociacion_id ||' -  cp: '||C_CP_xPed.numero_carta_porte|| 'Totalmente consumida' , null);
                                            raise e_continue_next;
                                      elsif   v_disponible_relacion <= 0  then  -- la cant.asociada entre cp del pedido fue totalmente consumida y no es una nota de credito
                                             debug( 'asociacion_id: '||C_CP_xPed.asociacion_id   ||' -  cp: '||C_CP_xPed.numero_carta_porte|| 'disponible_relacion=0' , null);
                                            l_cant_cp_cons         := l_cant_cp_cons + 1;
                                            raise e_continue_next;
                                      else
                                              if v_disponible_relacion > v_disponible_cp then -- se puede dar en los casos que no tiene cargado el numero de pedido asociado
                                                 v_disponible_relacion := v_disponible_cp;
                                              end if;

                                              if  v_disponible_relacion >= v_a_consumir_fac   then  -- calcula lo que se consumira en este paso
                                                  v_a_consumir_paso    := v_a_consumir_fac;
                                              else
                                                  v_a_consumir_paso    := v_disponible_relacion;
                                              end if;
                                       end if;
                                ELSE --(g_lin_art_rec.item_id IS NULL or g_lin_art_rec.consume_origen = 0 ) para memoline fuerza el valor a consumir, que no se debe usar. Solo es la plata para el detalle
                                           l_factor_conversion := 1;
                                           v_a_consumir_paso  := g_lin_art_rec.cant_a_consumir;
                                END IF;
                               debug( 'asociacion_id: '||C_CP_xPed.asociacion_id   || ' pedido_id  '||C_CP_xPed.pedido_id||' -  cp: '||C_CP_xPed.numero_carta_porte|| ' Cant: '|| C_CP_xPed.ordered_quantity
                                            || ' a cons paso '||v_a_consumir_paso  || ' a cons fac ' || v_a_consumir_fac, NULL );

                               l_CP_Sal.numero_carta_porte      := C_CP_xPed.numero_carta_porte; -- carta porte salida
                               l_CP_Sal.cant_adar_origen           := v_a_consumir_paso;
                               l_CP_Sal.carta_porte_id               := C_CP_xPed.carta_porte_id; -- carta porte salida
                               l_CP_Sal.nro_pedido                    :=  C_CP_xPed.pedido_num;
                               l_CP_Sal.tipo_pedido                   := g_lin_art_rec.pedido_tipo;
                               l_CP_Sal.pcia_destino_cp             := C_CP_xPed.pcia_destino_cp;

                               l_tabla (l_tabla.count+1)         := l_CP_Sal;
                               v_a_consumir_fac                  := v_a_consumir_fac  - v_a_consumir_paso;
                               v_existe_cp_consaldo             := true;
                               if g_lin_art_rec.item_id is null then
                                   exit;
                               end if;
                        EXCEPTION
                                  When e_continue_next then
                                     NULL;
                        END;
                 END LOOP; -- fin pedidos

             end if;

             debug( 'v_a_consumir_fac: '|| v_a_consumir_fac   || ' g_lin_art_rec.item_id: '|| g_lin_art_rec.item_id ||' -  g_lin_art_rec.consume_origen: '||g_lin_art_rec.consume_origen , NULL );

            -- Inserta detalle : por remanente/sin cp disponibles , es memoline o no se toma la cp
              if v_a_consumir_fac > 0  OR
                g_lin_art_rec.item_id is  null  OR
                g_lin_art_rec.consume_origen = 0    THEN

                if    g_lin_art_rec.item_id is  null then
                     v_carta_porte_envio := null;
                end if;

                v_pcia_origen   := nvl(g_lin_art_rec.pcia_origen_pv,g_lin_art_rec.pcia_origen_fc);  -- toma origen del pv, o de la linea de la factura
                v_pcia_destino  := g_fac_rec.pcia_destino_fc;                                                      -- destino de la cabecera de factura

                if g_lin_art_rec.item_id is  not null     then
                       if g_lin_art_rec.cant_a_consumir < 0 then
                           v_carta_porte_envio := 'Nota credito - Pedido';
                        elsif l_cant_cp   = l_cant_cp_cons and l_cant_cp > 0 Then
                           v_carta_porte_envio := 'CPs PV Tot Consumidas';
                        elsif g_lin_art_rec.conpedido = 0 then
                             v_carta_porte_envio := 'Sin PV asignado';
                         elsif not v_existe_lineas_pv then
                              v_carta_porte_envio := 'Sin lineas PV';
                        elsif not v_existe_cp_consaldo THEN
                               v_carta_porte_envio := 'CPs PV ya consumidas';
                        else
                               v_carta_porte_envio := 'Remanente Transaccion PV';
                         end if;
                else  -- se toma como  memoline
                            if g_lin_art_rec.consume_origen = 0 then
                                if g_fac_rec.tipo_trx = 'CM' then
                                    v_a_consumir_fac := -1;
                                else
                                    v_a_consumir_fac    := g_lin_art_rec.cant_a_consumir;
                                end if;
                            else
                                v_a_consumir_fac    := 1;
                            end if;
                            if l_tabla.count > 0  then
                                v_carta_porte_envio     := null; -- l_tabla(1).numero_carta_porte;
                                 v_pcia_destino            := nvl(l_tabla(1).pcia_destino_cp, g_fac_rec.pcia_destino_fc);
                            elsif g_lin_art_rec.conpedido = 0 then
                                  v_carta_porte_envio   := 'Sin Articulo Sin PV asignado ';
                            else
                                  v_carta_porte_envio   := 'Sin Articulo Sin CP';
                             end if;
                end if;
                    -- ------------------------------
                    -- Inserto en la tabla de detalle
                    -- ------------------------------
                    -- si no tiene cartas de porte asociadas y si tiene pedido asociado, obtener el origen desde el pedido
                    -- si no tiene tampoco pedido, obtener el origen de la linea de la trx

                  debug ( 'Restante inserta detalle. Origen ' || v_pcia_origen || '  Destino ' || v_pcia_destino, NULL );

                  INSERTAR_DETALLE (  p_provincia_origen                 => v_pcia_origen
                                                  , p_cantidad_por_origen           =>  v_a_consumir_fac
                                                  , p_provincia_destino               => v_pcia_destino
                                                  , p_cantidad_por_destino         => v_a_consumir_fac  -- NVL(g_lin_art_rec.cant_a_consumir,0)
                                                  , p_carta_porte_envio              => v_carta_porte_envio
                                                  , p_carta_porte_insumo           => NULL -- queda null o se informa la primera cuando exista
                                                  , p_tipo_oper                          => 'CLASIFICA'
                                                  , x_errmsg                                => l_errmsg
                                                  , p_result                               => v_result
                                                   );

                  IF (NOT v_result) THEN
                      l_errmsg := 'Error en Restante PEDIDO_OBTIENE_CP_SALIDA  '||l_errmsg;
                      RAISE e_exception;
                  END IF;

                end if;
                debug('- '||'PEDIDO_OBTIENE_CP_SALIDA'||' cantidad de CP ' || l_tabla.count , NULL )  ;
                RETURN ( l_tabla );

              EXCEPTION
                WHEN e_exception then
                  debug( '- '||l_errmsg||'. '||SQLERRM, NULL );
                         g_error_flag      := TRUE;
                       IF g_error_msg IS NOT NULL  THEN
                           g_error_msg := 'PEDIDO_OBTIENE_CP_SALIDA -> ' || sqlerrm || g_error_msg;
                        else
                              g_error_msg   := 'PEDIDO_OBTIENE_CP_SALIDA --> ' || SQLERRM;
                         end if;
                         g_error_msg   := SQLERRM;
                  raise_application_error(-20000, l_errmsg);
  END PEDIDO_OBTIENE_CP_SALIDA;


  /***************************************************************************+
  | Procedure                                                                 |
  |    PROCESO_ORIGENES                                                         |
  |                                                                           |
  | Description                                                               |
  |    Procesa Linas de IIBB para logica CEREAL                              |
  |                                                                           |
  | Parameters                                                                |
  |    p_indent       IN      NUMBER  Margen de indentacion de mensajes       |
  |    x_errmsg       OUT     VARCHAR2 Descripcion en caso de errores         |
  |    p_result       OUT     BOOLEAN Resultado del procesamiento             |
  |                                                                           |
  +***************************************************************************/
  PROCEDURE PROCESO_ORIGENES (  p_indent          IN     NUMBER
                           , x_errmsg          OUT    VARCHAR2
                           , p_result          OUT    BOOLEAN
                           ) IS

    v_existe_alguna_cp     BOOLEAN;
    v_result                      BOOLEAN;
    l_errmsg                        VARCHAR2(4000);
    e_exception                EXCEPTION;
    e_continue_next         EXCEPTION;

    v_a_consumir_sal          number;
    v_consumido_cp          number;
    v_disponible            number;
    v_a_consumir_paso     number;
    v_peso_aplicado_totcp   number;
    v_disponible_cp         number;
    v_consumido_pcia       number;
    v_peso_por_pcia         number;
    v_disponible_pcia       number;

    l_total_consumo        NUMBER;

      l_cant_consumo         NUMBER;
      l_idx_tab              NUMBER;
      l_cantidad             NUMBER;
      l_cp_leyenda           xx_ar_iibb_det_all.carta_porte_envio%type;

      l_nro_carta_porte_sal                      xx_tcg_cartas_porte.numero_carta_porte%type; -- carta de porte de salida
      l_carta_porte_id_sal                               xx_tcg_cartas_porte.carta_porte_id%type;  -- carta de porte de salida
      l_nro_pedido                                   oe_order_headers.order_number%type;
      l_tipo_pedido                                   oe_transaction_types.name%type;
      l_cant_adar_origen                           number;
      l_pcia_destino_cp                           hz_geographies.geography_name%type;



      v_peso_pcia_total              number;
      v_peso_pcia_distinto          number;
      v_casos_iguales                  number;
      v_casos_distintos number;
      v_tipo_oper                  varchar2(20);

      v_observa                 varchar2(2000) := null;
      v_pcia_origen      hz_geographies.geography_name%type;

  BEGIN
      x_errmsg := null;

    l_errmsg:='+ '||'PROCESO_ORIGENES'||': Trx: ' || g_fac_rec.trx_number   ||' Linea: ' || g_lin_art_rec.line_number      ||' Tipo Pedido: ' || g_lin_art_rec.pedido_tipo   ||' Pedido: ' || g_lin_art_rec.pedido_num;
    debug( l_errmsg, NULL );

    l_idx_tab := g_lin_art_rec.tab_CP_Sal.last;
     if   g_fac_rec.tipo_liq = 'Final' THEN
        v_tipo_oper          := 'RECLASIFICA'; -- IF  g_fac_rec.esinterco AND
     else
        v_tipo_oper         := 'CLASIFICA';
      end if;

    v_existe_alguna_cp := FALSE;
    l_total_consumo     := 0;
    l_pcia_destino_cp             :=  g_fac_rec.pcia_destino_fc;
    FOR idx IN 1..l_idx_tab LOOP  --  recorre las cp de salida asociadas a la factura

                  if g_fac_rec.esinterco OR
                    g_lin_art_rec.tab_CP_Sal.count > 0   THEN
                        l_nro_pedido                      := g_lin_art_rec.tab_CP_Sal(idx).nro_pedido;
                        l_tipo_pedido                      := g_lin_art_rec.tab_CP_Sal(idx).tipo_pedido;
                        l_nro_carta_porte_sal         := g_lin_art_rec.tab_CP_Sal(idx).numero_carta_porte;  -- carta porte de venta
                        l_carta_porte_id_sal            := g_lin_art_rec.tab_CP_Sal(idx).carta_porte_id;
                        l_cant_adar_origen              := g_lin_art_rec.tab_CP_Sal(idx).cant_adar_origen;
                        l_pcia_destino_cp                := nvl(g_lin_art_rec.tab_CP_Sal(idx).pcia_destino_cp, g_fac_rec.pcia_destino_fc);

                  ELSE   -- el pedido es el asociado a  la transaccion
                        l_nro_pedido                     := g_lin_art_rec.pedido_num;
                        l_tipo_pedido                    := g_lin_art_rec.pedido_tipo;
                        l_nro_carta_porte_sal       := null;
                        l_carta_porte_id_sal               := null;
                        l_cant_adar_origen           :=  g_lin_art_rec.cant_a_consumir;
                        l_pcia_destino_cp              := null;
                  END IF;



                  debug('    ' || '..idx='||idx||' org ' || g_fac_rec.org_id || ' ped  '||  l_nro_pedido ||'/'|| l_tipo_pedido ||' cp_id '|| l_carta_porte_id_sal ||' cant '||l_cant_adar_origen , 4 )  ;
                  v_a_consumir_sal := l_cant_adar_origen; --> cantidad a consumir de la cp de salida
                  v_observa                 := null;

                for c_Origen in (  SELECT xtio.documento_id cp_salida_id,
                                                    xtio.KILOS,
                                                    (select upper(xtp.GEOGRAPHY_name)
                                                      from XX_TCG_PROVINCIAS_ARG xtp
                                                      where xtio.ORIGEN_PROVINCIA = xtp.GEOGRAPHY_CODE)  PCIA_ORIGEN ,
                                                      xtio.origen_provincia,
                                                    xtio.CARTA_PORTE_ORIGEN,
                                                    cdp.carta_porte_id cp_id_origen,
                                                    cdp.fecha_recepcion,
                                                    cdp.version_cp
                                           FROM bolinf.xx_tcg_iibb_origen  xtio,
                                            (SELECT  '12' version_cp, carta_porte_id, numero_carta_porte, fecha_recepcion from xx_tcg_cartas_porte_all xtcp where nvl(anulado_flag,'N') = 'N'
                                             UNION ALL
                                             SELECT '11' version_cp, carta_porte_id, numero_carta_porte, fecha_recepcion  from xx_aco_cartas_porte_b where nvl(anulado_flag,'N') = 'N')  cdp
                                           WHERE xtio.documento_tipo         =    'XXTCGCP'
                                           AND xtio.documento_id                =     l_carta_porte_id_sal
                                           AND xtio.OPERATING_UNIT          =     g_fac_rec.org_id
                                           AND cdp.numero_carta_porte      =     xtio.CARTA_PORTE_ORIGEN
                                           ) loop

                               begin

                                           v_existe_alguna_cp := TRUE;
                                           -- ----------------------------------------------------------------------
                                           -- Control del consumo de la cp de origen, por total y por pcia
                                           -- ----------------------------------------------------------------------
                                           if c_Origen.version_cp = '12' then  --> peso total de la cp de origen
                                               v_peso_aplicado_totcp :=  xx_tcg_CALIDAD_pkg.Get_Peso_Aplicado ( p_carta_porte_id => c_Origen.cp_id_origen,
                                                                                                                                          --          p_item_oncca_code => g_lin_art_rec.xx_aco_codigo_oncca,            -- comentado 03/09 para que compile
                                                                                                                                                    p_tipo           =>  'RECEP');
                                           else
                                               v_peso_aplicado_totcp :=  xx_aco_acopio_pk.Get_Peso_Aplicado (p_carta_porte_id => c_Origen.cp_id_origen);
                                           end if;

                                           SELECT nvl(sum(xaic.consumo),0), nvl(sum(decode(xaic.PROVINCIA_ORIGEN,c_origen.PCIA_ORIGEN, nvl(xaic.consumo,0),0)),0)
                                           INTO v_consumido_cp, v_consumido_pcia   --> consumido de la cp  de origen y consumido de cp de origen y pcia
                                           FROM xx_ar_iibb_cons  xaic
                                           WHERE xaic.carta_porte_insumo  = C_Origen.carta_porte_origen
                                           AND xaic.item_id                       = g_lin_art_rec.item_id
                                           AND xaic.tipo_documento           =  'CARTAS_PORTE';

                                           debug('en c_Origen --> cp salida ' || l_nro_carta_porte_sal || ' cp origen '  || C_Origen.carta_porte_origen || ' n pcia '
                                                        || c_origen.PCIA_ORIGEN || ' kilos ' || c_Origen.kilos || ' v_a_consumir_sal'
                                                        || v_a_consumir_sal || ' v_consumido_cp ' || v_consumido_cp || ' v_peso_aplicado_totcp' || v_peso_aplicado_totcp, null);

                                            if  v_consumido_cp >= v_peso_aplicado_totcp then -- la cp  ya fue totalmente consumida se continua con la siguiente
                                                raise e_continue_next;
                                            end if;

                                            v_disponible_cp := v_peso_aplicado_totcp - v_consumido_cp; --> disponible de la cp origen

                                            -- control  asignado por cp de origen y pcia de origen. Se excluye  en el query las cartas de porte iguales
                                           SELECT sum( nvl(xtio.KILOS,0)) kilos_totales,
                                                       sum(decode(xtio.documento_id,cdp.carta_porte_id,0, nvl(xtio.KILOS,0))) kilos_distintos,
                                                       sum(decode(xtio.documento_id,cdp.carta_porte_id,1,0)) casos_iguales,
                                                       sum(decode(xtio.documento_id,cdp.carta_porte_id,0,1)) casos_distintos
                                           INTO v_peso_pcia_total, v_peso_pcia_distinto, v_casos_iguales, v_casos_distintos     --> peso de la pcia disponible de origen
                                           FROM bolinf.xx_tcg_iibb_origen  xtio,
                                                    (SELECT  carta_porte_id, numero_carta_porte
                                                        from xx_tcg_cartas_porte_all xtcp
                                                     WHERE nvl(anulado_flag,'N') = 'N'
                                                    UNION all
                                                    SELECT  carta_porte_id , numero_carta_porte
                                                    FROM xx_aco_cartas_porte_b
                                                    WHERE nvl(anulado_flag,'N') = 'N')  cdp
                                           WHERE xtio.documento_tipo                =    'XXTCGCP'
                                           AND xtio.CARTA_PORTE_ORIGEN         =     C_Origen.carta_porte_origen
                                           AND xtio.OPERATING_UNIT                  =     g_fac_rec.org_id
                                           and origen_provincia                           =     C_origen.origen_provincia
                                           and cdp.numero_carta_porte                =    xtio.CARTA_PORTE_ORIGEN;

                                           if v_casos_distintos = 0 then
                                              v_peso_por_pcia := v_peso_pcia_total;   --> solo existe origen y destino igual, tomo ese peso
                                           else
                                               v_peso_por_pcia := v_peso_pcia_distinto;  --> existe origen y destinos <> , tomo solo el peso de esos casos.
                                            end if;


                                            v_disponible_pcia := v_peso_por_pcia - v_consumido_pcia; --> disponible por pcia de origen

                                           if v_peso_por_pcia >  v_peso_aplicado_totcp  OR
                                              v_disponible_pcia <= 0   then

                                                v_observa   := substr(v_observa || ' Dif.Kgs en CP Origen :  ' || c_Origen.CARTA_PORTE_ORIGEN,1,1990);
                                                debug('             ---> v_peso_por_pcia ' || v_peso_por_pcia || ' v_disponible_pcia' || v_disponible_pcia || ' v_consumido_pcia ' || v_consumido_pcia, null);

                                                INSERTAR_ERROR ( p_observa                            =>  ' Dif.Kgs en CP Origen :  ' || c_Origen.CARTA_PORTE_ORIGEN || ' Kgs. Aplicado ' || v_peso_aplicado_totcp
                                                                                                                                    || '  Peso Origen  ' || v_peso_por_pcia  || ' Consumido ' || v_consumido_pcia || '  Disponible ' || v_disponible_pcia
                                                                             , x_errmsg                             => l_errmsg
                                                                             , p_result                               => v_result
                                                                             , p_cp_origen_error                 => c_Origen.CARTA_PORTE_ORIGEN
                                                                             , p_cp_salida_error                 => l_nro_carta_porte_sal
                                                                                       );

                                                raise e_continue_next;
                                           else
                                                if v_disponible_pcia > v_disponible_cp then
                                                    v_disponible_pcia := v_disponible_cp;
                                                end if;

                                                if nvl(c_Origen.kilos,0) > v_disponible_pcia then  --> v_disponible saldo restante para consumir por pcia
                                                    v_disponible :=  v_disponible_pcia;
                                               else
                                                    v_disponible := nvl(c_Origen.kilos,0);
                                                end if;
                                            END IF;

                                              if  v_disponible  >= v_a_consumir_sal then  --> calcula lo que se consumieron este paso, cuanto insertar en consumo
                                                  v_a_consumir_paso    := v_a_consumir_sal;    --> cant_a_consumir de la cp de salida
                                              else
                                                  v_a_consumir_paso    := v_disponible;
                                              end if;

                                            v_a_consumir_sal      := v_a_consumir_sal - v_a_consumir_paso;
                                            l_total_consumo        := l_total_consumo  +    v_a_consumir_paso;


                                             -- no convierto porque ya esta en kilos

                                            IF NOT INSERTAR_CONSUMO ( p_documento_id       => c_origen.cp_id_origen
                                                                          , p_documento_num                => c_origen.CARTA_PORTE_ORIGEN
                                                                          , p_documento_tipo                 => 'CARTAS_PORTE'
                                                                          , p_fecha                               => c_origen.fecha_recepcion
                                                                          , p_cantidad_total                   => c_Origen.kilos
                                                                          , p_consumo                          => v_a_consumir_paso
                                                                          , p_province                          => c_origen.PCIA_ORIGEN
                                                                          , p_carta_porte_envio             => l_nro_carta_porte_sal
                                                                          , p_carta_porte_insumo        =>  c_origen.CARTA_PORTE_ORIGEN
                                                                          , p_provincia_envio               =>  l_pcia_destino_cp
                                                                          , p_cantidad_envio                => 0
                                                                          , p_record_level                   => 'F'
                                                                          , p_indent                            => p_indent
                                                                          , x_errmsg                          => l_errmsg
                                                                          ) THEN

                                                    l_errmsg := 'Error en PROCESO_ORIGENES' || l_errmsg;
                                                    RAISE e_exception;
                                            END IF;

                                            if v_a_consumir_sal = 0 then
                                                exit;
                                            end if;
                                     exception
                                     when e_continue_next then null;
                                     end;
                    end loop;



                    if v_a_consumir_sal <> 0 then    --  Es un error porque no se consume No tiene cp de origen asociadas a la de entrada
                       v_pcia_origen  := nvl(g_lin_art_rec.pcia_origen_pv,g_lin_art_rec.pcia_origen_fc);

                        if v_observa is null then
                           v_observa := 'Remanente Transaccion Origen';
                           select   max(pcia_tit)
                               into   v_pcia_origen
                            FROM (SELECT  '12',  carta_porte_id , numero_carta_porte,
                                          decode(TITULAR_CP_TIPO,'PRODUCTOR',(select  geography_name from xx_tcg_provincias_arg where geography_code =TITULAR_CP_PROVINCIA),null) pcia_tit
                                      from xx_tcg_cartas_porte_all xtcp where nvl(anulado_flag,'N') = 'N'
                                     UNION ALL
                                     SELECT '11', carta_porte_id , numero_carta_porte, null   from xx_aco_cartas_porte_b where nvl(anulado_flag,'N') = 'N')  cdp
                                    WHERE cdp.carta_porte_id      =    l_carta_porte_id_sal;
                        end if;
                            INSERTAR_DETALLE (  p_provincia_origen             => v_pcia_origen
                                   , p_cantidad_por_origen           =>  v_a_consumir_sal
                                   , p_provincia_destino               =>  nvl(l_pcia_destino_cp, g_fac_rec.pcia_destino_fc)   -------> si no tiene de pedido/cp, va la de factura
                                   , p_cantidad_por_destino         => v_a_consumir_sal
                                   , p_carta_porte_envio              =>  l_nro_carta_porte_sal
                                   , p_carta_porte_insumo           => l_nro_carta_porte_sal
                                   , p_tipo_oper                          => v_tipo_oper
                                   , p_observa                            => v_observa
                                   , x_errmsg                             => l_errmsg
                                   , p_result                               => v_result
                                   );
                              IF (NOT v_result) THEN
                                l_errmsg := 'Error en  Remanente Transaccion Origen-PROCESO_ORIGENES. '||l_errmsg;
                                RAISE e_exception;
                              END IF;
                              INSERTAR_ERROR ( p_observa             => v_observa
                                         , p_cp_origen_error                 => NULL
                                         , p_cp_salida_error                 => l_nro_carta_porte_sal
                                         , x_errmsg                             => l_errmsg
                                         , p_result                               => v_result
                                                   );

                              IF (NOT v_result) THEN
                                  l_errmsg := 'Error en  Remanente Transaccion Origen-PROCESO_ORIGENES. '||l_errmsg;
                                  RAISE e_exception;
                              END IF;
                            debug( 'Se Inserto detalle Remanente ' || l_nro_carta_porte_sal || ' - ' || v_a_consumir_sal ||' de TRX : ' || g_fac_rec.trx_number ||' destino: ' ||g_fac_rec.pcia_destino_fc, NULL );

                    end if;

       END LOOP;

       IF v_existe_alguna_cp and l_total_consumo != 0 THEN
              l_errmsg := 'Existen CP, inserta detalle desde tabla de consumos.';
              debug ( l_errmsg, NULL );

                g_header_id := g_hdr_id_propio;

              -- Obtener el/los origenes de la tabla de consumos e insertar por cada uno
              debug( 'Abro cursor c_origenes. Parametros: Trx ID: '||g_fac_rec.trx_id||' Trx Line ID: '||g_lin_art_rec.trx_line_id, NULL );

                for c_consu in (       SELECT header_id
                                               , provincia_origen        AS provincia_origen
                                               , carta_porte_envio       AS carta_porte_envio
                                               , provincia_envio         AS provincia_envio
                                               , sum(cantidad_envio)     AS cantidad_envio
                                               , carta_porte_insumo      AS carta_porte_insumo
                                               , Sum(consumo)            AS cant_por_origen
                                               , Avg(precio_compra) AS precio_unit_compra
                                          FROM  xx_ar_iibb_cons
                                          WHERE trx_id                 = g_fac_rec.trx_id
                                          AND   trx_line_id            = g_lin_art_rec.trx_line_id
                                          AND   nvl(record_level,'F')  = 'F'
                                          GROUP BY header_id
                                                 , carta_porte_envio
                                                 , provincia_envio
                                                 , provincia_origen
                                                 , carta_porte_insumo
                                                 , provincia_envio
                                          ) loop

                    l_cant_consumo := c_consu.cant_por_origen;
                    debug('Inserta detalle desde Tabla consumo: ' || l_cant_consumo, p_indent+4);

                      INSERTAR_DETALLE (  p_provincia_origen             => c_consu.provincia_origen
                                       , p_cantidad_por_origen          =>  c_consu.cant_por_origen
                                       , p_provincia_destino            => c_consu.provincia_envio
                                       , p_cantidad_por_destino      => c_consu.cant_por_origen
                                       , p_carta_porte_envio           => c_consu.carta_porte_envio
                                       , p_carta_porte_insumo        => c_consu.carta_porte_insumo
                                       , p_tipo_oper                          => v_tipo_oper
                                       , x_errmsg                             => l_errmsg
                                       , p_result                           => v_result
                                       );

                    IF (NOT v_result) THEN
                      l_errmsg := 'Error en detalle desde consumo PROCESO_ORIGENES '||l_errmsg;
                      RAISE e_exception;
                    END IF;

              END LOOP;
      end if;

    x_errmsg := ' - PROCESO_ORIGENES';
    debug( '- '||'PROCESO_ORIGENES', NULL );
    p_result := TRUE;

    RETURN;

  EXCEPTION
    WHEN e_exception THEN
      x_errmsg := ' -> PROCESO_ORIGENES: ' || l_errmsg;
      debug( '- '||'. Error: '||l_errmsg, NULL );
      p_result := FALSE;
      g_error_flag      := TRUE;
              IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'PROCESO_ORIGENES -> '  || sqlerrm || g_error_msg;
        else
              g_error_msg   := 'PROCESO_ORIGENES -> ' || SQLERRM;
         end if;

    WHEN OTHERS THEN
      x_errmsg := ' -> PROCESO_ORIGENES: ' || SQLERRM;
      debug( '- '||'PROCESO_ORIGENES'||'. Error: '||SQLERRM, NULL );
      p_result := FALSE;
      g_error_flag      := TRUE;
               IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'PROCESO_ORIGENES -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := 'PROCESO_ORIGENES --> ' || SQLERRM;
         end if;

  END PROCESO_ORIGENES;


  /**************************************************************************+
  | Private Procedure                                                        |
  |    MOSTRAR_DATOS                                                         |
  |                                                                          |
  | Description                                                              |
  |    Genera reporte preliminar                                             |
  | Parameters                                                               |
  |                                                                          |
  +**************************************************************************/
  PROCEDURE MOSTRAR_DATOS( x_periodo        IN  VARCHAR2
                         , x_periodo_fiscal IN  VARCHAR2  -- Agregado CR2642
                         , x_tipo_logica    IN  VARCHAR2
                         , x_tipo_proc      IN  VARCHAR2
                         , x_error          OUT VARCHAR2
                         , x_result         OUT BOOLEAN) IS
    l_errmsg        VARCHAR2(2000):= ' + Procedimiento MOSTRAR_DATOS';
    v_cab         NUMBER;
  BEGIN
    debug( '+ '||'MOSTRAR_DATOS', NULL );
    x_error  :=  null;

    SELECT count(1)
      INTO v_cab
      FROM xx_ar_iibb_CAB_all        cab
     WHERE 1=1
        and  org_id = TO_NUMBER (SUBSTRB (USERENV ('CLIENT_INFO'), 1, 10)) -- uso all
       AND ((X_PERIODO_FISCAL IS NULL
            AND cab.periodo = X_PERIODO
            AND cab.tipo_ejecucion  = decode(X_TIPO_PROC,'CONSULTA', cab.tipo_ejecucion, X_TIPO_PROC))
           OR
           -- Se solicita que el mes de diciembre del año solicitado este cerrado y haya sido corrida
           -- ejecucion como definitiva
           (X_PERIODO_FISCAL IS NOT NULL
           AND periodo IN (SELECT gp.period_name
                             FROM GL_PERIODS gp
                                , GL_PERIOD_STATUSES gs
                            WHERE gp.period_name         = gs.period_name
                              AND gp.period_set_name     ='ADECO_CALENDARI'
                              AND gp.period_year         = X_PERIODO_FISCAL
                              AND gp.end_date            = TO_DATE('31/12/'||gp.period_year,'DD/MM/YYYY')
                              AND gs.application_id      = 101
                              AND gs.set_of_books_id     IN (select set_of_books_id from financials_system_parameters )
                              AND gs.closing_status      = 'C'
                              AND gp.entered_period_name IN ('DIC','DEC'))
           AND tipo_ejecucion = 'DEFINITIVO'))
       AND (( X_TIPO_LOGICA IS NULL)
          OR ( X_TIPO_LOGICA='CEREAL' AND cab.tipo_logica LIKE 'CEREAL%' )
          OR ( cab.tipo_logica = X_TIPO_LOGICA )
          )      ;


    x_result:= TRUE;

    IF v_cab = 0 THEN
      --CR2642
      IF (X_PERIODO_FISCAL IS NOT NULL) THEN
        x_error := '********** Debe generar como definitivo el periodo de Diciembre del año seleccionado '||
                   'o verificar que el mismo este cerrado en GL.*******' ;
        debug( '- '||'MOSTRAR_DATOS'||' '||x_error, NULL );
        x_result:= FALSE;
      ELSE
        x_error := '********** No se encontraron datos generados para el Periodo y Logica solicitados.*******' ;
        debug( '- '||'MOSTRAR_DATOS'||' '||x_error, NULL );
        x_result:= FALSE;
      END IF;
    END IF;

    debug( '- '||'MOSTRAR_DATOS', NULL );

  EXCEPTION
    WHEN OTHERS THEN
      x_error := ' + Error en MOSTRAR_DATOS  ' || SQLERRM;
      debug( '- '||'MOSTRAR_DATOS'||' Error: '||SQLERRM, NULL );
      x_result:= FALSE;
       g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'MOSTRAR_DATOS -> ' || sqlerrm || g_error_msg;
        else
              g_error_msg   := 'MOSTRAR_DATOS --> ' || SQLERRM;
         end if;
  END MOSTRAR_DATOS;


  /**************************************************************************+
  | Private Procedure                                                        |
  |    GENERAR_PRELIMINAR                                                    |
  |                                                                          |
  | Description                                                              |
  |    Genera reporte preliminar                                             |
  | Parameters                                                               |
  |                                                                          |
  +**************************************************************************/
  PROCEDURE GENERAR_PRELIMINAR( x_periodo        IN  VARCHAR2
                               ,x_tipo_logica    IN  VARCHAR2
                               ,x_tipo_proc      IN  VARCHAR2
                               ,x_factura         in varchar2
                               ,x_error          OUT VARCHAR2
                               ,x_result         OUT BOOLEAN) IS


    l_errmsg        VARCHAR2(4000):= ' + Procedimiento GENERAR_PELIMINAR';
    v_org_id     NUMBER := fnd_global.org_id;
    v_error      VARCHAR2(2000);
    v_result     BOOLEAN;


    -- -----------------------
    -- Definicion de Variables
    -- -----------------------
    e_exception                 EXCEPTION;
    sigte_caso                   EXCEPTION;
        error_en_loop   EXCEPTION;

    l_header_id                 NUMBER;
    l_indent                    NUMBER        := 0;
    l_result                    BOOLEAN;
    v_fecha_desde               DATE;
    v_fecha_hasta               DATE;

    l_cant_regis            number;

   BEGIN
    debug( '+ '||'GENERAR_PRELIMINAR', NULL );
    x_error := null;


    -- borro datos de detalle
    BEGIN
      DELETE FROM xx_ar_iibb_det_all
      WHERE header_id IN ( SELECT header_id
                                       FROM xx_ar_iibb_cab_all
                                       WHERE periodo       = x_periodo
                                       AND  ( X_TIPO_LOGICA IS NULL
                                                  OR   tipo_logica LIKE X_TIPO_LOGICA || '%' )
                                       AND org_id         = v_org_id);

      debug( 'Borrando detalles...', NULL );

      DELETE FROM xx_ar_iibb_err_all
      WHERE header_id IN ( SELECT header_id
                                       FROM xx_ar_iibb_cab_all
                                       WHERE periodo       = x_periodo
                                       AND  ( X_TIPO_LOGICA IS NULL
                                                  OR   tipo_logica LIKE X_TIPO_LOGICA || '%' )
                                       AND org_id         = v_org_id);

    EXCEPTION
      WHEN OTHERS THEN
        l_errmsg:='Error borrando detalles: '||SQLERRM;
        debug( l_errmsg, NULL );
        g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'Error borrando detalles: '|| SQLERRM || g_error_msg;
        else
              g_error_msg   := l_errmsg;
         end if;
    END;

    --borro consumos
    BEGIN
      DELETE FROM xx_ar_iibb_cons_all
      WHERE header_id IN ( SELECT header_id
                                       FROM xx_ar_iibb_cab_all
                                       WHERE periodo       = x_periodo
                                        AND  ( X_TIPO_LOGICA IS NULL
                                                  OR   tipo_logica LIKE X_TIPO_LOGICA || '%' )
                                      -- AND tipo_ejecucion = x_tipo_proc
                                       AND org_id         = v_org_id);

      debug( 'Borrando consumos...', NULL );

    EXCEPTION
      WHEN OTHERS THEN
        l_errmsg:='Error borrando consumos: '||SQLERRM;
        debug( l_errmsg, NULL );
        g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'Error borrando consumos: '|| SQLERRM || g_error_msg;
        else
              g_error_msg   := l_errmsg;
         end if;
    END;

    -- borro cabecera
    BEGIN
      DELETE FROM xx_ar_iibb_cab_all
      WHERE periodo        = x_periodo
           AND  ( X_TIPO_LOGICA IS NULL
                                          OR   tipo_logica LIKE X_TIPO_LOGICA || '%' )
       --   AND tipo_ejecucion  = x_tipo_proc
          AND org_id          = v_org_id;

      debug( 'Borrando cabecera...', NULL );
    EXCEPTION
      WHEN OTHERS THEN
        l_errmsg:='Error borrando cabecera: '||SQLERRM;
        debug( l_errmsg, NULL );
        g_error_flag      := TRUE;
        IF g_error_msg IS NOT NULL  THEN
           g_error_msg := 'Error borrando cabecera: '|| SQLERRM || g_error_msg;
        else
              g_error_msg   := l_errmsg;
         end if;
    END;

    -- Generar nuevos datos para el reporte  -- bloque de lineas
    begin
        debug( '+ '||'GENERAR_PRELIMINAR', NULL );

        -- --------------------------------------------------------------
        -- Actualizar tabla xx_ar_iibb_cab
        -- --------------------------------------------------------------
        IF x_tipo_logica = 'CEREAL' THEN
              If not INSERTAR_CABECERA_IIBB ( 'CEREAL_PROPIO', x_tipo_proc, x_periodo, l_indent, l_header_id, l_errmsg ) THEN
                RAISE e_exception;
              END IF;

              g_hdr_id_propio := l_header_id;

              IF NOT INSERTAR_CABECERA_IIBB ( 'CEREAL_TERCERO', x_tipo_proc, x_periodo, l_indent, l_header_id, l_errmsg ) THEN
                 RAISE e_exception;
              END IF;

              g_hdr_id_tercero := l_header_id;
        ELSE
              IF NOT INSERTAR_CABECERA_IIBB ( x_tipo_logica, x_tipo_proc, x_periodo, l_indent, l_header_id, l_errmsg ) THEN
                RAISE e_exception;
              END IF;

              g_hdr_id_otros := l_header_id;
              g_header_id    := l_header_id;
        END IF;

        -- --------------------------------------
        -- Obtengo datos del parametro x_periodo
        -- --------------------------------------
        IF NOT GET_FECHAS_PERIODO ( x_periodo    , l_indent  , v_fecha_desde , v_fecha_hasta   , l_errmsg   ) THEN

          RAISE e_exception;
        END IF;

        -- -------------------------
        -- Recorre las C_Facturas
        -- -------------------------
        debug( 'Abro cursor C_Facturas. Parametros: logica: '||x_tipo_logica  ||' v_fecha_desde: '||To_Char(v_fecha_desde,'DD-MON-YY')    ||' v_fecha_hasta: '||To_Char(v_fecha_hasta,'DD-MON-YY'), NULL );

        FOR R_Fact IN (SELECT rct.customer_trx_id                                                 AS trx_id
                                        , rct.trx_number                                                         AS trx_number
                                        , rct.trx_date                                                              AS trx_date
                                        , tcus.party_name                                                       AS customer_name
                                        , tcus.cust_account_id                                                 as customer_id
                                        , tcus.provincia_destino                                               as pcia_destino_fc
                                        , rtrim(rct_dfv.xx_ar_tipo_pedido_om)                          AS xx_ar_tipo_pedido_om
                                        , rct_dfv.xx_ar_nro_pedido_om
                                        , rct.interface_header_context
                                        , nvl(rct.exchange_rate,1) exchange_rate
                                        , rct.org_id
                                        , rctt.type                                                                  as tipo_trx
                                        , rct.interface_header_attribute1                                  as nro_liq
                                        , tcus.CUSTOMER_CLASS_CODE
                                        , rctt.name  cust_trx_type_name
                                        , nvl(rct.attribute1,'Otros')                                                           as tipo_liq -- deja Otros cuando no es cereales
                                        , rct.ship_to_customer_id
                              FROM  ra_cust_trx_types_all_dfv       rctt_dfv
                                       , ra_cust_trx_types                  rctt
                                       , ra_customer_trx_all_dfv          rct_dfv
                                       , ra_customer_trx                  rct
                                       ,  (select  hp.party_name,  hca.cust_account_id , rsu.site_use_id  , upper(prov.GEOGRAPHY_NAME) provincia_destino, CUSTOMER_CLASS_CODE
                                            from hz_cust_site_uses                    rsu
                                                   , hz_cust_accounts                   hca
                                                   , hz_party_sites                       hps
                                                   , hz_parties                             hp
                                                   , hz_locations                          hl
                                                   , hz_cust_acct_sites_all            hcas
                                                   , XX_TCG_PROVINCIAS_ARG    prov
                                            where    hps.party_id                            = hca.party_id
                                                 AND  hca.party_id                             = hp.party_id
                                                AND     hcas.party_site_id                    = hps.party_site_id
                                                AND     hl.location_id                           = hps.location_id
                                                AND    hcas.cust_acct_site_id               = rsu.cust_acct_site_id
                                                AND    prov.geography_code(+)           = hl.province)     tcus
                              WHERE  1=1
                              and rct.trx_number = nvl(x_factura,rct.trx_number)
                              AND rct.trx_date BETWEEN v_fecha_desde AND v_fecha_hasta
                              AND rct.complete_flag             = 'Y'
                              AND rct_dfv.row_id                = rct.ROWID
                              AND rctt.cust_trx_type_id         = rct.cust_trx_type_id
                              AND rctt_dfv.row_id               = rctt.rowid
                              AND nvl(rctt_dfv.xx_ar_rep_iibb,'Y') = 'Y'
                              AND  tcus.cust_account_id                 = rct.ship_to_customer_id
                              AND tcus.site_use_id                        = rct.ship_to_site_use_id
                              -- no procesadas anteriormente
                              AND NOT EXISTS ( SELECT 'procesada'
                                                           FROM xx_ar_iibb_cab_all       c,
                                                                xx_ar_iibb_det_all        d,
                                                                ra_customer_trx_lines ctl
                                                           WHERE 1=1
                                                            AND c.org_id = d.org_id
                                                           AND c.org_id = rct.org_id
                                                           AND ctl.customer_trx_id = rct.customer_trx_id
                                                           AND d.trx_line_id = ctl.customer_trx_line_id
                                                           AND c.header_id   = d.header_id
                                                           AND c.tipo_logica LIKE x_tipo_logica || '%'
                                                         )
                               AND ( NVL(rct.attribute1,'XX') in ('Unica','Final','Parcial','Anticipo')                      -- liquidaciones de granos
                                        OR
                                        exists (  SELECT 1                           --  la linea corresponda a cereales
                                                        FROM  ra_customer_trx_lines              rctl,
                                                                   ar_memo_lines_all_b_dfv ml_dfv,
                                                                   ar_memo_lines_all_b     ml
                                                        WHERE rct.customer_trx_id = rctl.customer_trx_id
                                                            AND rctl.memo_line_id is not null
                                                            AND ml.memo_line_id = rctl.memo_line_id
                                                            AND ml_dfv.row_id = ml.rowid
                                                            AND nvl(ml_dfv.xx_incluir_reporte_iibb,'N/A') = x_tipo_logica
                                                        UNION ALL
                                                        SELECT 1
                                                        FROM  ra_customer_trx_lines              rctl,
                                                                   mtl_categories_b_dfv  mc_dfv,
                                                                   mtl_categories_v      mc,
                                                                   mtl_item_categories_v micv
                                                        WHERE rct.customer_trx_id = rctl.customer_trx_id
                                                            AND micv.organization_id = rctl.warehouse_id
                                                            AND micv.inventory_item_id = rctl.inventory_item_id
                                                            AND micv.category_set_name = 'Inventory'
                                                            AND mc.category_id = micv.category_id
                                                            AND mc_dfv.row_id = mc.row_id
                                                            AND nvl(mc_dfv.xx_incluir_reporte_iibb,'N/A') = x_tipo_logica
                                                        )
                                             )
                              --     AND  NOT EXISTS (select 1 from xx_tcg_liquidaciones xtg where numero_liquidacion = rct.ct_reference and xtg.cancelado_flag = 'Y')
                              ORDER BY  rct.trx_number, rct.customer_trx_id) -- se ordena rct.trx_date, porque habia casos de parcial con fecha mayor
                  LOOP
               g_fecha_ini := sysdate;

            debug(  '=========>Transaccion_id: '|| R_Fact.trx_id|| ' Nro: '|| R_Fact.trx_number, NULL );
               g_fac_rec                                :=   g_empty_fac_rec;

              g_fac_rec.trx_id                          := R_Fact.trx_id;
              g_fac_rec.trx_final                       := R_Fact.trx_id;
              g_fac_rec.trx_number                  := R_Fact.trx_number;
              g_fac_rec.trx_date                       := R_Fact.trx_date;
              g_fac_rec.customer_name            := substr(R_Fact.customer_name,1,50);
              g_fac_rec.customer_id                 := R_Fact.customer_id;
              g_fac_rec.pcia_destino_fc             := R_Fact.pcia_destino_fc;
              g_fac_rec.xx_ar_nro_pedido_om   := R_Fact.xx_ar_nro_pedido_om;
              g_fac_rec.xx_ar_tipo_pedido_om  := R_Fact.xx_ar_tipo_pedido_om;
              g_fac_rec.exchange_rate             := R_Fact.exchange_rate;
              g_fac_rec.org_id                         := R_Fact.org_id;
              g_fac_rec.tipo_trx                       := R_Fact.tipo_trx;
              g_fac_rec.tipo_liq                        := R_Fact.tipo_liq;
              g_fac_rec.ship_to_customer_id     := R_Fact.ship_to_customer_id;
              g_fac_rec.esinterco                     := FALSE;
              g_fac_rec.cant_lineas                  := 0;
              -- si se necesita la liquidacion se toma de trx_number
               if  R_Fact.CUSTOMER_CLASS_CODE = 'INTERCOMPANY'     AND
                     R_Fact.cust_trx_type_name   LIKE '%ACO%'        THEN
                                           g_fac_rec.esinterco                     :=TRUE;
               end if;
            -- --------------------------------------
            -- Recorre las lineas de articulos
            -- --------------------------------------
                g_lin_art_rec                   :=        g_empty_lin_art_rec ;
                  debug( 'Abro cursor lineas_articulos. Parametros: Trx ID: '||R_Fact.trx_id ||' Exchange Rate: '||R_Fact.exchange_rate   ||' Logica: '||x_tipo_logica , NULL );
                  FOR R_lin IN (SELECT  rctl.customer_trx_line_id                                 AS trx_line_id
                                    , rctl.line_number
                                    , rctl.description                                                             AS item_desc
                                    , rctl.quantity_invoiced
                                    , rctl.quantity_credited
                                    , rctl.unit_selling_price * R_Fact.exchange_rate                AS unit_selling_price
                                    , rctl.uom_code                                                              AS uom_code
                                    , rctl.extended_amount  * R_Fact.exchange_rate               AS extended_amount
                                    , rctl.memo_line_id
                                    , rctl.inventory_item_id                                                    AS item_id
                                    , rctl.previous_customer_trx_line_id
                                    , rctl.interface_line_context
                                    , rctl.warehouse_id
                                    , decode(rctl.interface_line_context, 'ORDER ENTRY', rctl.interface_line_attribute1, '')  AS pedido_num
                                    , decode(rctl.interface_line_context, 'ORDER ENTRY', rctl.interface_line_attribute2, '')  AS pedido_tipo
                                    , rctl.org_id
                                    , (SELECT upper(xtpa.GEOGRAPHY_name)
                                          FROM hr_organization_information hoi,
                                               mtl_parameters mp,
                                               hr_organization_units hou,
                                               hr_locations_all hl,
                                               XX_TCG_PROVINCIAS_ARG xtpa
                                         WHERE     hoi.organization_id = rctl.warehouse_id
                                               AND hoi.org_information_context = 'Accounting Information'
                                               AND mp.organization_id = hoi.organization_id
                                               AND hou.organization_id = hoi.organization_id
                                               AND hl.location_id = hou.location_id
                                               and xtpa.GEOGRAPHY_CODE = hl.region_2
                                               )  pcia_origen_fc
                                    FROM   ra_customer_trx_lines_all_dfv      rctl_dfv
                                              , ra_customer_trx_lines              rctl
                                    WHERE 1=1
                                    AND rctl.customer_trx_id          =  R_Fact.trx_id
                                    AND rctl.line_type                = 'LINE'
                                    AND NOT EXISTS ( SELECT 'linea procesada'      -- no procesadas anteriormente
                                                                FROM xx_ar_iibb_det_all
                                                                WHERE trx_line_id = rctl.customer_trx_line_id
                                                                 and org_id = R_Fact.org_id --- uso all
                                                                 )
                                    AND rctl_dfv.row_id                                  = rctl.rowid
                                    AND EXISTS ( SELECT 1                           --  la linea corresponda a cereales
                                                        FROM ar_memo_lines_all_b_dfv ml_dfv,
                                                                 ar_memo_lines_all_b     ml
                                                        WHERE 1=1
                                                        AND rctl.memo_line_id is not null
                                                        AND ml.memo_line_id = rctl.memo_line_id
                                                        AND ml_dfv.row_id = ml.rowid
                                                        AND nvl(ml_dfv.xx_incluir_reporte_iibb,'N/A') = x_tipo_logica
                                                        UNION ALL
                                                        SELECT 1
                                                        FROM mtl_categories_b_dfv  mc_dfv,
                                                                 mtl_categories_v      mc,
                                                                mtl_item_categories_v micv
                                                        WHERE 1=1
                                                        AND micv.organization_id = rctl.warehouse_id
                                                        AND micv.inventory_item_id = rctl.inventory_item_id
                                                        AND micv.category_set_name = 'Inventory'
                                                        AND mc.category_id = micv.category_id
                                                        AND mc_dfv.row_id = mc.row_id
                                                        AND nvl(mc_dfv.xx_incluir_reporte_iibb,'N/A') = x_tipo_logica
                                                        )
                                    ORDER BY rctl.line_number
                                    )
                  LOOP

                        begin
                                debug(  'Linea - id: ' || R_lin.trx_line_id  || ' Item: ' || R_lin.item_id || ' Cant: ' || To_Char(NVL(R_lin.quantity_invoiced, R_lin.quantity_credited)) || ' MONTO ' || R_lin.extended_amount || ' TIPO ' ||  R_Fact.tipo_trx , NULL );

                                 IF r_lin.item_id is not null THEN
                                        GET_DATOS_ITEMS(R_lin.item_id, R_lin.warehouse_id);--> ACTUALIZA primary_uom_code  y categ_seg_concat
                                 ELSE
                                        g_lin_art_rec.primary_uom_code      := NULL;
                                        g_lin_art_rec.categ_seg_concat        := NULL;
                                        g_lin_art_rec.xx_aco_codigo_oncca   := NULL;
                                        g_lin_art_rec.item_desc                   := R_lin.item_desc;
                                 END IF;
                                  g_fac_rec.cant_lineas                  :=  g_fac_rec.cant_lineas  + 1;

                                g_lin_art_rec.trx_line_id              := R_lin.trx_line_id;
                                g_lin_art_rec.line_number           := R_lin.line_number;
                                g_lin_art_rec.quantity_invoiced     := R_lin.quantity_invoiced;

                                IF R_Fact.tipo_trx = 'CM' /*AND R_lin.extended_amount < 0 AND R_lin.quantity_credited > 0 */  THEN-- cr2264 , cambio de signo
                                  g_lin_art_rec.quantity_credited  :=  ABS(R_lin.quantity_credited) * -1; -- cr2264 , cambio de signo
                                  g_lin_art_rec.unit_selling_price := abs(R_lin.unit_selling_price);
                               ELSE
                                    g_lin_art_rec.quantity_credited  := R_lin.quantity_credited;
                                    g_lin_art_rec.unit_selling_price := R_lin.unit_selling_price;
                                END IF;

                                g_lin_art_rec.uom_code                                    := NVL(R_lin.uom_code,g_lin_art_rec.primary_uom_code);
                                g_lin_art_rec.extended_amount                         := R_lin.extended_amount;
                                g_lin_art_rec.memo_line_id                              := R_lin.memo_line_id;
                                g_lin_art_rec.item_id                                        := R_lin.item_id;
                                g_lin_art_rec.pedido_num                                 := nvl(R_Fact.xx_ar_nro_pedido_om, R_lin.pedido_num);
                                g_lin_art_rec.pedido_tipo                                  := nvl(R_Fact.xx_ar_tipo_pedido_om,R_lin.pedido_tipo) ;
                                g_lin_art_rec.org_id                                          := R_lin.org_id;

                                IF g_lin_art_rec.item_id is null THEN
                                    g_lin_art_rec.pcia_origen_fc                           := g_fac_rec.pcia_destino_fc; -- Para memoline toma la provincia envio de la cabecera
                                ELSE
                                     g_lin_art_rec.pcia_origen_fc                          := R_lin.pcia_origen_fc;
                                END IF;

                                g_lin_art_rec.tipo_operacion := 'C';

                                get_Datos_Pedido;
                                -- obtener el descuento comercial de la linea
                                GET_DESC_COMERCIAL ( d_trx_id            => R_Fact.trx_id
                                                                    ,d_trx_line_num      => R_lin.line_number
                                                                    ,d_desc_com          => g_lin_art_rec.dto_COMERCIAL
                                                                    ,x_errmsg             => l_errmsg
                                                                    ,p_result            => v_result);
                                IF (NOT v_result) THEN
                                  l_errmsg := 'Error en GET_DESC_COMERCIAL. '||l_errmsg;
                                  RAISE e_exception;
                                END IF;

                                -- Obtiene cantidad a consumir

                                IF g_lin_art_rec.item_id IS NULL or
                                     R_Fact.tipo_trx = 'CM'  THEN
                                     g_lin_art_rec.factor_conver_um := 1;
                                ELSE
                                         -- todas las cp estan en KG se convierte factura si tiene unidad de medida distinta
                                          IF nvl(R_lin.uom_code,'X' ) = 'BOL' THEN-- Se supone que son semillas y no tienen pedidos
                                                g_lin_art_rec.factor_conver_um := 1;
                                         ELSIF nvl(R_lin.uom_code,'X' ) <> 'KG' then
                                                  g_lin_art_rec.factor_conver_um  := INV_CONVERT.inv_um_convert( item_id       =>g_lin_art_rec.item_id
                                                                                                    , precision     => 5
                                                                                                    , from_quantity => 1
                                                                                                    , from_unit     => R_lin.uom_code
                                                                                                    , to_unit       => 'KG'
                                                                                                    , from_name     => null
                                                                                                    , to_name       => null);

                                                  IF (g_lin_art_rec.factor_conver_um = -99999) THEN
                                                      l_errmsg := 'Error en INV_CONVERT.inv_um_convert. Item_id '|| g_lin_art_rec.item_id
                                                                        ||', From Unit '|| R_lin.uom_code||', To Unit '|| 'KG';
                                                      RAISE e_exception;
                                                  END IF;
                                         else
                                                g_lin_art_rec.factor_conver_um := 1;
                                         END IF;
                                END IF;

                                g_lin_art_rec.cant_a_consumir   := NVL(R_lin.quantity_invoiced, R_lin.quantity_credited) *  g_lin_art_rec.factor_conver_um;



                                 g_lin_art_rec.tab_CP_Sal.delete;   -- borra cp salida asociadas al item

                               IF  R_Fact.tipo_trx = 'CM'  then  -- Nota credito  buscar origina y revierte  consumo de la cp
                                       g_lin_art_rec.consume_origen         := 0;
                                       if G_fac_rec.tipo_liq <> 'Otros'  THEN
                                            if NOT Nota_credito_RevierteFC(R_Fact.trx_id) then -- tuvo problemas para revertir
                                                    g_lin_art_rec.tab_CP_Sal                    := PEDIDO_OBTIENE_CP_SALIDA;
                                            END IF;
                                       ELSE
                                                    g_lin_art_rec.tab_CP_Sal                    := PEDIDO_OBTIENE_CP_SALIDA;
                                       end if;
                               else
                                     IF  g_fac_rec.tipo_liq  = 'Unica' THEN
                                               g_lin_art_rec.consume_origen         := 1;
                                     ELSIF  g_fac_rec.tipo_liq  = 'Anticipo' THEN
                                               g_lin_art_rec.consume_origen         := 0; --> no procesa origen, no consume
                                     ELSIF   g_fac_rec.tipo_liq = 'Parcial' THEN
                                                g_lin_art_rec.consume_origen          :=  1;
                                     ELSIF  g_fac_rec.tipo_liq  =  'Final' THEN
                                                  select count(*)          into  l_cant_regis
                                                   from  bolinf.XX_AR_TCG_ASOCIA_LIQ aso
                                                  where aso.cust_trx_id_final = g_fac_rec.trx_id;
                                                  IF l_cant_regis = 0 then   --> FINAL sin parcial asociada
                                                     g_fac_rec.tipo_recla_final := 'S';
                                                     g_lin_art_rec.consume_origen         := 0;
                                                  ELSE
                                                         select count(*)  into  l_cant_regis
                                                          from  bolinf.XX_AR_TCG_ASOCIA_LIQ aso,
                                                                    BOLINF.XX_AR_TCG_PARC_ARECLA arec   where aso.cust_trx_id_final = g_fac_rec.trx_id
                                                          and  aso.CUST_TRX_ID_PARCIAL = arec.CUST_TRX_ID_PARCIAL;
                                                         IF l_cant_regis > 0 then --> FINAL con parcial historica
                                                              g_fac_rec.tipo_recla_final               := 'H';
                                                              g_lin_art_rec.consume_origen         := 1;
                                                         ELSE
                                                                select count(*)  into  l_cant_regis
                                                                from  bolinf.XX_AR_TCG_ASOCIA_LIQ aso,
                                                                        ra_customer_trx rct
                                                                where aso.cust_trx_id_final = g_fac_rec.trx_id
                                                                and  aso.CUST_TRX_ID_PARCIAL = rct.CUSTOMER_TRX_ID
                                                                AND RCT.attribute1 = 'Anticipo';
                                                                IF l_cant_regis > 0 then --> FINAL con Anticipo
                                                                    g_fac_rec.tipo_recla_final            := 'A';
                                                                    g_lin_art_rec.consume_origen      := 1;
                                                                ELSE  --> FINAL sin consumo
                                                                    g_fac_rec.tipo_recla_final            := 'X';
                                                                    g_lin_art_rec.consume_origen     := 0;
                                                                END IF;
                                                         END IF;
                                                   END IF;
                                                   debug(  '    liq  ' || g_fac_rec.tipo_liq   || '  tipo_recla_final: ' || g_fac_rec.tipo_recla_final , NULL );

                                     END IF;

                                       IF  g_fac_rec.esinterco and
                                           g_fac_rec.tipo_liq  = 'Unica'   THEN   -- mantiene procesamiento como interco
                                            g_lin_art_rec.pedido_num    := null;
                                            g_lin_art_rec.pedido_tipo     := null;
                                             g_lin_art_rec.tab_CP_Sal           := INTERCO_OBTIENE_CP_SALIDA ( R_Fact.nro_liq );
                                      ELSE
                                              g_lin_art_rec.tab_CP_Sal          := PEDIDO_OBTIENE_CP_SALIDA;
                                       END IF;
                                END IF;


                                   IF  g_lin_art_rec.tab_CP_Sal.count > 0 AND
                                        g_lin_art_rec.item_id is not null                   and
                                        g_lin_art_rec.consume_origen = 1                   then
                                        l_result := true;
                                          PROCESO_ORIGENES (  l_indent, l_errmsg,l_result );

                                          IF NOT l_result THEN
                                            RAISE error_en_loop;
                                          END IF;
                                   END IF;

                        EXCEPTION
                                when sigte_caso then null;
                                WHEN error_en_loop THEN
                                      x_error  := ' -> GENERAR_PRELIMINAR  dentro loop : ' || l_errmsg;
                                      debug( '- '||'GENERAR_PRELIMINAR dentro loop '||'. Error: '||l_errmsg, NULL );
                                       x_result:= FALSE;
                                       g_error_flag      := TRUE;
                                        IF g_error_msg IS NOT NULL  THEN
                                            g_error_msg := ' GENERAR_PRELIMINAR dentro loop --> '|| SQLERRM || g_error_msg;
                                       else
                                             g_error_msg   := x_error;
                                        end if;

                                      ROLLBACK;
                                      RETURN;
                            end;

                  END LOOP; -- fin lineas_articulos
         --
                debug('Tiempo ejecucion linea : '||XX_UTIL_PK.GetElapsedTime(g_fecha_ini, SYSDATE),  null);
        END LOOP; -- fin C_Facturas
        x_error := null;
        COMMIT;
        debug( '- '|| ' - Procedimiento ' || 'GENERAR_PRELIMINAR' , NULL );

      EXCEPTION
        WHEN e_exception THEN
          x_error  := ' -> GENERAR_PRELIMINAR bloque  lineas : ' || l_errmsg;
          debug( '- '||'GENERAR_PRELIMINAR'||'. Error: '||l_errmsg, NULL );
           x_result:= FALSE;
          x_error  := v_error;
          x_result := v_result;
          g_error_flag      := TRUE;
           IF g_error_msg IS NOT NULL  THEN
               g_error_msg := ' GENERAR_PRELIMINAR bloque lineas --> '|| SQLERRM || g_error_msg;
           else
              g_error_msg   := x_error;
           end if;
          ROLLBACK;
          RETURN;


        WHEN OTHERS THEN
          x_error  := ' -> GENERAR_PRELIMINAR: bloque lineas -->  ' || SQLERRM;
          debug( '- '||'GENERAR_PRELIMINAR'||'. Error: '||SQLERRM, NULL );
           x_result:= FALSE;
           g_error_flag      := TRUE;
           IF g_error_msg IS NOT NULL  THEN
               g_error_msg := ' GENERAR_PRELIMINAR bloque lineas--> '|| SQLERRM || g_error_msg;
           else
              g_error_msg   := x_error;
           end if;
          ROLLBACK;
          RETURN;

      END;

   if x_error is null then
           debug( '- '||'GENERAR_PRELIMINAR', NULL );
           x_error  := '';
           x_result := TRUE;
   end if;

  EXCEPTION
    WHEN OTHERS THEN
      x_error := ' + Error en GENERAR_PRELIMINAR funcion ' || SQLERRM;
      debug( '- '||'GENERAR_PRELIMINAR'||' Error. '||SQLERRM, NULL );
      x_result:= FALSE;
       g_error_flag      := TRUE;
           IF g_error_msg IS NOT NULL  THEN
               g_error_msg := ' GENERAR_PRELIMINAR funcion --> '|| SQLERRM || g_error_msg;
           else
              g_error_msg   := x_error;
           end if;
      ROLLBACK;
  END GENERAR_PRELIMINAR;

  /**************************************************************************+
  | Private Procedure                                                        |
  |    GENERAR_DEFINITIVO                                                    |
  |                                                                          |
  | Description                                                              |
  |    Genera reporte preliminar                                             |
  | Parameters                                                               |
  |                                                                          |
  +**************************************************************************/
  PROCEDURE GENERAR_DEFINITIVO ( x_periodo        IN  VARCHAR2
                               , x_tipo_logica    IN  VARCHAR2
                               , x_tipo_proc      IN  VARCHAR2
                               , x_error          OUT VARCHAR2
                               , x_result         OUT BOOLEAN) IS

    l_errmsg        VARCHAR2(2000);
    v_org_id     NUMBER := fnd_global.org_id;
    v_error      VARCHAR2(2000);
    v_result     BOOLEAN;
    l_tipo_ejecucion varchar2(30);
    l_guarda_per varchar2(1);
    l_header_id number;
    HisError   EXCEPTION;
  BEGIN
    debug('+ '||'GENERAR_DEFINITIVO', NULL );
        x_error := null;


    UPDATE xx_ar_iibb_cab_all
    SET tipo_ejecucion = 'DEFINITIVO'
    WHERE 1=1
    AND periodo         = x_periodo
    AND (   ( x_tipo_logica IS NULL)
         OR ( x_tipo_logica='CEREAL' AND tipo_logica LIKE 'CEREAL%' )
         OR ( tipo_logica = x_tipo_logica )
        )
    AND org_id           = v_org_id
    ;
   -- CR2272  Actualización de registro de cálculo y guardado de back up
     begin
           l_guarda_per := 'N';
          -- cierre del periodo y recupera back-up
           SELECT tipo_ejecucion
                 into l_tipo_ejecucion
             FROM xx_ar_iibb_CAB_all
             where org_id = g_org_id_ingreso  --  la org_id de 'INGRESO'  es fija
                 and periodo = x_periodo
                  AND TIPO_LOGICA = 'INGRESO';

                     IF l_tipo_ejecucion = 'PRELIMINAR' THEN
                         l_guarda_per := 'Y';
                         update     xx_ar_iibb_CAB_all
                            set tipo_ejecucion = 'DEFINITIVO'
                            where org_id = g_org_id_ingreso --  la org_id de INGRESO' es fija
                              and periodo = x_periodo
                              AND TIPO_LOGICA = 'INGRESO';
                    end if;
             exception when no_data_found then
                      If not INSERTAR_CABECERA_IIBB (p_logica => 'INGRESO',
                                                    p_tipo_proc => 'DEFINITIVO',
                                                               p_periodo => x_periodo,
                                                               p_indent => NULL,
                                                               p_header_id =>l_header_id,
                                                               x_errmsg=>  l_errmsg ) THEN
                                raise HisError;
                      END IF;
                      l_guarda_per := 'Y';
             end;
     if l_guarda_per = 'Y' THEN
            DELEte from bolinf.xx_tcg_iibb_saldo_ini_his where HIS_PERIODO = x_periodo;
              insert into  bolinf.xx_tcg_iibb_saldo_ini_his( HIS_PERIODO, TRANSACTION_ID, CARTA_PORTE_ID, NUMERO_CARTA_PORTE, INVENTORY_ITEM_ID,
                                                                                TRANSACTION_SOURCE_TYPE_ID, TRANSACTION_TYPE_ID, TRANSACTION_ACTION_ID, REASON_ID,
                                                                                 LOT_NUMBER, ACCT_PERIOD, OPERATING_UNIT, ORGANIZATION_ID, SUBINVENTORY_CODE,
                                                                                  LOCATOR_ID, TRANSFER_OPERATING_UNIT, TRANSFER_ORGANIZATION_ID, TRANSFER_SUBINVENTORY,
                                                                                   TRANSFER_LOCATOR_ID, OWNING_OPERATING_UNIT, OWNING_ORGANIZATION_ID, XFR_OWNING_ORGANIZATION_ID,
                                                                                   TRANSACTION_QUANTITY, USED_QUANTITY, STATUS, ITEM_ONCCA_IIBB)
                                                                                   select x_periodo, TRANSACTION_ID, CARTA_PORTE_ID, NUMERO_CARTA_PORTE, INVENTORY_ITEM_ID,
                                                                                TRANSACTION_SOURCE_TYPE_ID, TRANSACTION_TYPE_ID, TRANSACTION_ACTION_ID, REASON_ID,
                                                                                 LOT_NUMBER, ACCT_PERIOD, OPERATING_UNIT, ORGANIZATION_ID, SUBINVENTORY_CODE,
                                                                                  LOCATOR_ID, TRANSFER_OPERATING_UNIT, TRANSFER_ORGANIZATION_ID, TRANSFER_SUBINVENTORY,
                                                                                   TRANSFER_LOCATOR_ID, OWNING_OPERATING_UNIT, OWNING_ORGANIZATION_ID, XFR_OWNING_ORGANIZATION_ID,
                                                                                   TRANSACTION_QUANTITY, USED_QUANTITY, STATUS, ITEM_ONCCA_IIBB
                                                                                     from  bolinf.xx_tcg_iibb_saldo_ini a;
            commit;
            delete from bolinf.XX_TCG_IIBB_ORIGEN_his where HIS_PERIODO = x_periodo;
            insert into  bolinf.XX_TCG_IIBB_ORIGEN_his( HIS_PERIODO, ORIGEN_IIBB_ID, PERIODO, OPERATING_UNIT, DOCUMENTO_TIPO, DOCUMENTO_ID,
                                                                        CEREAL_TIPO, TRANSACTION_ID, KILOS, ORIGEN_PROVINCIA, ORIGEN_LOCALIDAD, CARTA_PORTE_ORIGEN,
                                                                         CONTRATO_ID, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, LAST_UPDATE_LOGIN)
                                                                         select x_periodo, ORIGEN_IIBB_ID, PERIODO, OPERATING_UNIT, DOCUMENTO_TIPO, DOCUMENTO_ID,
                                                                        CEREAL_TIPO, TRANSACTION_ID, KILOS, ORIGEN_PROVINCIA, ORIGEN_LOCALIDAD, CARTA_PORTE_ORIGEN,
                                                                         CONTRATO_ID, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, LAST_UPDATE_LOGIN
                                                                          from  bolinf.XX_TCG_IIBB_ORIGEN b;
           commit;
     end if;
    COMMIT;

    debug('- '||'GENERAR_DEFINITIVO', NULL );
    x_error  := '';
    x_result := TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      x_error := '- No se encontraron datos en GENERAR_DEFINITIVO ' || SQLERRM;
      debug( '- '||'GENERAR_DEFINITIVO'||'. No se encontraron datos. '||SQLERRM, NULL );
      x_result:= FALSE;
      Fnd_File.put_line(Fnd_File.LOG,'La logica' || x_tipo_logica ||' para el periodo '|| x_periodo ||' no tiene un preliminar.');
                         g_error_flag      := TRUE;
           IF g_error_msg IS NOT NULL  THEN
               g_error_msg := ' GENERAR_DEFINITIVO --> '|| SQLERRM || g_error_msg;
           else
              g_error_msg   := x_error;
           end if;

    WHEN HisError THEN
      x_error := ' + Error en GENERAR_DEFINITIVO actualizacion historico ' || SQLERRM;
      debug( '- '||'GENERAR_DEFINITIVO historico'||'. Error: '||SQLERRM, NULL );
      x_result:= FALSE;

    WHEN OTHERS THEN
      x_error := ' + Error en GENERAR_DEFINITIVO ' || SQLERRM;
      debug( '- '||'GENERAR_DEFINITIVO'||'. Error: '||SQLERRM, NULL );
      x_result:= FALSE;
                         g_error_flag      := TRUE;
           IF g_error_msg IS NOT NULL  THEN
               g_error_msg := ' GENERAR_DEFINITIVO --> '|| SQLERRM || g_error_msg;
           else
              g_error_msg   := x_error;
           end if;

  END GENERAR_DEFINITIVO;


  /***************************************************************************+
  | Private Procedure                                                         |
  |    XX_AR_IIBB_PRINCIPAL                                                   |
  |                                                                           |
  | Description                                                               |
  |    Genera reporte preliminar                                              |
  | Parameters                                                                |
  |                                                                           |
  +***************************************************************************/

PROCEDURE XX_AR_IIBB_PRINCIPAL ( errbuf            OUT         VARCHAR2
                               , retcode           OUT         NUMBER
                               , p_periodo_fiscal  IN          VARCHAR2
                               , p_periodo         IN          VARCHAR2
                               , p_logica          IN          VARCHAR2
                               , p_tipo_proc       IN          VARCHAR2
                               , p_msgerr          IN  OUT     VARCHAR2
                                                              , p_factura          in varchar default null) IS

    -- ---------
    -- VARIABLES
    -- ---------

    l_errmsg                       VARCHAR2(4000);
    l_msgbuff                   VARCHAR2(2000);
    v_error                     VARCHAR2(2000);
    v_result                    BOOLEAN;
    hay_periodos_anteriores     EXCEPTION;
    periodo_actual    EXCEPTION;
    eFiscalYear                 EXCEPTION;
        error_actualiza         EXCEPTION;
    v_logica                    VARCHAR2(30);
    v_datos_logica              NUMBER := 0;
        l_tipo_ejecucion            varchar2(30);
    --
    l_osuser varchar2(10);
    e_errores     EXCEPTION;
    v_cuenta            NUMBER;

  BEGIN
     errbuf := null;
       select osuser into l_osuser from v$session where audsid = userenv('SESSIONID');
  if l_osuser != 'irosas' then
    xx_debug_pk.force_on('CONC_LOG'
                        , 9    --p_level           IN      NUMBER
                        , NULL --p_directory       IN      VARCHAR2
                        , NULL --p_file            IN      VARCHAR2
                        , NULL --p_other_statement IN      VARCHAR2
                        , 250  --p_message_length  IN      NUMBER
                        );
    end if;
    G_REQUEST_ID := FND_GLOBAL.CONC_REQUEST_ID();
    debug( '+ '||'XX_AR_IIBB_PROCESO_PK.XX_AR_IIBB_PRINCIPAL'||' inicio:'||sysdate, NULL );
    retcode := 0; -- Successfull (1:warning 2: error)

    -- ----------------------------------------------
    -- por cada logica seleccionada (una o todas)
    -- correr el proceso
    -- ----------------------------------------------
    l_msgbuff := 'Parametros: p_logica: '|| p_logica || ' x_tipo_proc: '|| p_tipo_proc ||' p_periodo: '|| p_periodo||' p_periodo_fiscal: '||p_periodo_fiscal;
    debug( l_msgbuff, NULL );


    debug( 'Abro cursor logicas.', NULL );
    FOR v_reg IN (SELECT MEANING           ,DESCRIPTION           ,lookup_code  AS logica
                              FROM fnd_lookup_values_vl
                              WHERE lookup_type = 'XX_AR_IIBB_LOGICAS_PROCESO'
                              AND NVL(start_date_active,sysdate-1) <= sysdate
                              AND NVL(end_date_active,sysdate+1) >= sysdate
                              AND enabled_flag = 'Y'
                              AND lookup_code  = Nvl(p_logica,lookup_code))  LOOP
      debug( 'Logica: '|| v_reg.logica, NULL );

      IF p_tipo_proc = 'CONSULTA' THEN

            MOSTRAR_DATOS( p_periodo
                         , p_periodo_fiscal -- Agregado CR2642
                         , v_reg.logica
                         , p_tipo_proc
                         , v_error
                         , v_result
                         );

            IF (NOT v_result) THEN
                  p_msgerr := v_error;
            ELSE
                  IF (p_periodo_fiscal IS NOT NULL) THEN
                    v_datos_logica := v_datos_logica + 1;
                  END IF;
            END IF;


      ELSIF p_tipo_proc = 'DEFINITIVO' THEN

                IF  Concu_en_proceso('XXARIIBBREC') > 0  then
                     l_errmsg := 'Hay un proceso de recalculo en proceso -  por favor espere que el anterior termine y re ejecute el reporte' ;
                       raise E_ERRORES;
                end if;

            GENERAR_DEFINITIVO( p_periodo
                              , v_reg.logica
                              , p_tipo_proc
                              , v_error
                              , v_result );

            IF (NOT v_result) THEN
              p_msgerr := v_error;
              ROLLBACK;
              RETURN;
            END IF;

      ELSIF  p_tipo_proc = 'PRELIMINAR' THEN
                IF  Concu_en_proceso('XXARIIBBREC') > 0  then
                     l_errmsg := 'Hay un proceso de recalculo en proceso -  por favor espere que el anterior termine y re ejecute el reporte' ;
                       raise E_ERRORES;
                end if;

        /* impedir que se procesen periodos posteriores a periodos no definitivos  - inicio */
        debug( 'PRELIMINAR - Verif.periodos anter', NULL );
        l_errmsg := null;

        FOR periodos_anteriores IN ( SELECT DISTINCT gp.start_date, cab.periodo, cab.tipo_ejecucion
                                     FROM gl_periods           gp,
                                          xx_ar_iibb_cab_all      cab,
                                          gl_period_statuses   gps,
                                          ar_system_parameters asp
                                     WHERE cab.org_id = TO_NUMBER (SUBSTRB (USERENV ('CLIENT_INFO'), 1, 10))  -- uso de all
                                     and gps.set_of_books_id = asp.set_of_books_id
                                     AND gps.application_id = 222
                                     AND gps.period_name = P_PERIODO
                                     AND gp.end_date < gps.start_date
                                     AND cab.periodo = gp.period_name
                                     AND cab.tipo_logica like P_LOGICA || '%'
                                     AND cab.tipo_ejecucion = 'PRELIMINAR'
                                     ORDER BY gp.start_date
                                 ) LOOP
                  IF l_errmsg IS NULL THEN
                        l_errmsg := periodos_anteriores.periodo ||' '|| periodos_anteriores.tipo_ejecucion ||' '|| P_LOGICA;
                  ELSE
                        l_errmsg := l_errmsg || chr(10)
                             || periodos_anteriores.periodo ||' '|| periodos_anteriores.tipo_ejecucion ||' '|| P_LOGICA;
                  END IF;

        END LOOP;

        IF l_errmsg IS NOT NULL THEN
          RAISE hay_periodos_anteriores;
        END IF;
        /* Verificar que no exista el definitivo para ese periodo */
         debug( 'PRELIMINAR - Verif.periodos anter', NULL );
        l_errmsg := null;
            select  COUNT(1) INTO v_cuenta
              from xx_ar_iibb_cab_all cab
             where     cab.org_id = TO_NUMBER (SUBSTRB (USERENV ('CLIENT_INFO'), 1, 10))  -- uso de all
             AND cab.periodo = P_PERIODO
             AND cab.tipo_logica like P_LOGICA || '%'
             AND cab.tipo_ejecucion = 'DEFINITIVO';

        IF v_cuenta > 0  THEN
          RAISE periodo_actual;
        END IF;

        if not update_inf_source (x_periodo  => p_periodo              -- CR2273 LLAMADO a actualizacion
                                            ,x_error          => v_error
                                                )  then
              RAISE error_actualiza;
        end if;

        GENERAR_PRELIMINAR( p_periodo
                          , v_reg.logica
                         , p_tipo_proc
                         , p_factura
                         , v_error
                        , v_result);

        if g_error_flag then
              RAISE E_ERRORES;
        elsIF (NOT v_result) THEN
          p_msgerr := v_error;
          ROLLBACK;
          RETURN;
        END IF;

      END IF;

    END LOOP;

    --CR2642
    IF (p_periodo_fiscal IS NOT NULL) THEN
      IF (v_datos_logica = 0) THEN  -- Si para algun tipo de logica se encontraron datos
        retcode := 1;               -- devuelvo OK, sino advertencia
      ELSE
        retcode := 0;
      END IF;
    END IF;
    xx_debug_pk.debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||' fin:'||sysdate, NULL );
    --
  EXCEPTION
    WHEN hay_periodos_anteriores THEN
      p_msgerr := chr(10)
                ||'************************' || CHR(10)
                ||'Se debe realizar primero el proceso definitivo de los siguientes periodos: ' || chr(10)
                ||l_errmsg || chr(10)
                ||'************************' || CHR(10)
                || ' ';
      debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||'. '||p_msgerr, NULL);
      retcode := 2;

    WHEN periodo_actual  THEN
      p_msgerr := chr(10)
                ||'************************' || CHR(10)
                ||'No se puede ejecutar un proceso preliminar sobre  el periodo , porque tiene proceso definitivo: ' || chr(10)
                ||'************************' || CHR(10)
                || ' ';
      debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||'. '||p_msgerr, NULL);
      retcode := 2;

    WHEN eFiscalYear THEN
      retcode := 2;
      debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||'. '||p_msgerr, NULL);
      RAISE FND_API.G_EXC_ERROR;

   WHEN error_actualiza  THEN
      p_msgerr := chr(10)
                ||'**************************************************************' || CHR(10)
                || 'Problemas durante la actualización de información de ingreso para el reporte: ' || chr(10)
                ||v_error || chr(10)
                ||'**************************************************************' || CHR(10)
                || ' ';
      debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||'. '||p_msgerr, NULL);
      retcode := 2;

    WHEN E_ERRORES  THEN
      p_msgerr := ' + Error en  XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL' ||' Error '|| g_error_msg;
      debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||'. '||g_error_msg, NULL );
      retcode := 2;
      ROLLBACK;
      RAISE FND_API.G_EXC_ERROR;

    WHEN OTHERS THEN
      p_msgerr := ' + Error en  XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL' ||' Error '|| SQLERRM;
      debug( '- '||'XX_AR_IIBB_PROCESO_CEREAL_PK.XX_AR_IIBB_PRINCIPAL'||'. '||SQLERRM, NULL );
      retcode := 2;
      ROLLBACK;
      RAISE FND_API.G_EXC_ERROR;


  END XX_AR_IIBB_PRINCIPAL;

  function update_inf_source (x_periodo        IN  VARCHAR2
                                            ,x_error          OUT VARCHAR2
                                          ) return boolean is
l_registros number(2);
l_calculado NUMBER(2);
l_concu_ejec number(2);
l_header_id NUMBER;
l_errmsg varchar2(2000);

BEGIN
 -- Verifica si existe calculado , devuelve ok y continua reporte
            select COUNT(1),                     NVL(sum(decode(NVL(tipo_ejecucion,'XX'),'PRELIMINAR',1,0)),0)+NVL(sum(decode(NVL(tipo_ejecucion,'XX'),'DEFINITIVO',1,0)),0)
                          INTO l_registros, l_calculado
             from xx_ar_iibb_CAB_all where org_id = g_org_id_ingreso and periodo = x_periodo  AND TIPO_LOGICA = 'INGRESO'; --  la org_id de 'INGRESO' es fija

             IF l_calculado > 0 THEN
                    debug( 'Ingreso ya calculado  ' || l_registros , NULL );
                      RETURN TRUE;
            END IF;

 -- Verifica si existe un concurrente ejecutando en ese momento y cancela
          IF  Concu_en_proceso('XXARIBRE') > 0  then
             x_error := 'Hay otro proceso de actualizacion en proceso - por favor espere que el anterior termine y re ejecute el reporte' ;
                return false;
            end if;

         if l_registros = 0 then      --- Nuevo registro en cabecera
             If not INSERTAR_CABECERA_IIBB (p_logica => 'INGRESO',
                                                               p_tipo_proc => 'EJECUTANDO',
                                                               p_periodo => x_periodo,
                                                               p_indent => NULL,
                                                               p_header_id =>l_header_id,
                                                               x_errmsg=>  l_errmsg ) THEN
                x_error := 'Error durante el insert de la cabecera ' || l_errmsg;
                return false;
              END IF;
         else   -- si no tiene preliminar/definitivo (cancelo mientras ejecutaba)
                update     xx_ar_iibb_CAB_all    set tipo_ejecucion = 'EJECUTANDO'
                              where org_id =g_org_id_ingreso and periodo = x_periodo  AND TIPO_LOGICA = 'INGRESO'; --  la org_id de 'INGRESO'  es fija
        end if;
        commit;
          debug( 'Calculando saldo - ingreso de informacion para el periodo '  || x_periodo , NULL );


          XX_AR_IIBB_PROCESO_CEREAL_PK.Actualiza_Saldo ( p_periodo   => x_periodo
                                                      , p_status    => 'PRELIMINAR'
                                                      , x_error_msg => l_errmsg
                                                      );

          IF l_errmsg IS NOT NULL THEN
                 x_error := 'Error actualizando Sald ' || l_errmsg;
              return false;
       END IF;
          debug( 'Calculando origen - ingreso de informacion para el periodo '  || x_periodo , NULL );

           XX_AR_IIBB_PROCESO_CEREAL_PK.Procesa_CPS_Origen_IIBB ( p_periodo   => x_periodo
                                                       , x_error_msg => l_errmsg
                                                       );

           IF l_errmsg IS NOT NULL THEN
                     x_error := 'Error procesando origen IIBB ' || l_errmsg;
                    return false;
          END IF;

          update     xx_ar_iibb_CAB_all    set tipo_ejecucion = 'PRELIMINAR'
                              where org_id =g_org_id_ingreso and periodo = x_periodo  AND TIPO_LOGICA = 'INGRESO'; --  la org_id de 'INGRESO'  es fija
          COMMIT;

          debug( 'Calculo origen - finalizado para el periodo ' || l_registros , NULL );
        return true;

 end update_inf_source;

procedure  Recalculo_CP_Origen ( errbuf                   IN OUT VARCHAR
                                        , errcode                  IN OUT NUMBER
                                       , p_periodo in VARCHAR2) is

reca_error exception;
l_tipo_ejecucion varchar2(30);
l_errmsg varchar2(2000);
v_flag          BOOLEAN;
L_SALDOS number := 0;
L_origen number := 0;
L_period_ant varchar2(10);

 BEGIN
       G_REQUEST_ID := FND_GLOBAL.CONC_REQUEST_ID();
        IF  Concu_en_proceso('XXARIIBBREC') > 0  then
             l_errmsg := 'Hay un proceso de recalculo en proceso -  por favor espere que el anterior termine' ;
             raise reca_error;
        end if;
         begin
          -- Verifica que esté en preliminar para recalcular
           SELECT tipo_ejecucion
                 into l_tipo_ejecucion
             FROM xx_ar_iibb_CAB_all
             where org_id =  g_org_id_ingreso
                 and periodo = p_periodo
                  AND TIPO_LOGICA = 'INGRESO';

                     IF l_tipo_ejecucion = 'DEFINITIVO' THEN
                            l_errmsg :=  'El periodo informado a recalcular esta cerrado '  || p_periodo;
                            raise reca_error;

                     ELSIF l_tipo_ejecucion = 'EJECUTANDO'  THEN
                             l_errmsg :=  'El periodo informado a recalcular se esta calculando actualmente '  || p_periodo || '. Espere que finalice el proceso y ejecute el reporte';
                            raise reca_error;

                     ELSIF l_tipo_ejecucion NOT IN ('PRELIMINAR','RECALCULANDO')  THEN
                             l_errmsg := 'El periodo informado a recalcular esta en estado ' || l_tipo_ejecucion || ' para el periodo '  || p_periodo  || '.Revise el periodo  y vuelva a procesar';
                            raise reca_error;
                     ELSE
                         update     xx_ar_iibb_CAB_all
                            set tipo_ejecucion = 'RECALCULANDO'
                            where org_id =g_org_id_ingreso
                              and periodo = p_periodo
                              AND TIPO_LOGICA = 'INGRESO';
                          COMMIT;
                      END IF;
             exception when no_data_found then
                     l_errmsg :=  'El periodo informado a recalcular '  || p_periodo || ' no fue calculado.Revise el periodo  y vuelva a procesar';
                            raise reca_error;
             end;

                SELECT p_ant.period_name
                    INTO L_period_ant
                  FROM gl_periods P_ACT,
                           gl_periods P_Ant
                 WHERE p_act.period_set_name = 'ADECO_CALENDARI'
                       and p_act.period_name = p_periodo
                       and p_act.adjustment_period_flag = 'N'
                       and p_ant.period_set_name = 'ADECO_CALENDARI'
                       and p_ant.start_date = add_months(p_act.start_date,-1)
                       and p_ant.adjustment_period_flag = 'N';

                    SELECT COUNT(1) INTO l_saldos FROM bolinf.xx_tcg_iibb_saldo_inI_his where his_periodo = L_period_ant;
                    SELECT COUNT(1) INTO l_origen FROM bolinf.XX_TCG_IIBB_ORIGEN_his where his_periodo = L_period_ant;

                    IF l_saldos+ l_origen = 0 THEN
                        l_errmsg :=  'No existen movimientos resguardados para el periodo anterior a recalcular '  || L_period_ant || ' contactese con el Administrador';
                            raise reca_error;
                    end if;

              execute immediate 'truncate table bolinf.xx_tcg_iibb_saldo_ini';
               insert into  bolinf.XX_TCG_IIBB_SALDO_INI( TRANSACTION_ID, CARTA_PORTE_ID, NUMERO_CARTA_PORTE, INVENTORY_ITEM_ID,
                                                                                TRANSACTION_SOURCE_TYPE_ID, TRANSACTION_TYPE_ID, TRANSACTION_ACTION_ID, REASON_ID,
                                                                                 LOT_NUMBER, ACCT_PERIOD, OPERATING_UNIT, ORGANIZATION_ID, SUBINVENTORY_CODE,
                                                                                  LOCATOR_ID, TRANSFER_OPERATING_UNIT, TRANSFER_ORGANIZATION_ID, TRANSFER_SUBINVENTORY,
                                                                                   TRANSFER_LOCATOR_ID, OWNING_OPERATING_UNIT, OWNING_ORGANIZATION_ID, XFR_OWNING_ORGANIZATION_ID,
                                                                                   TRANSACTION_QUANTITY, USED_QUANTITY, STATUS, ITEM_ONCCA_IIBB)
                                                                                   select  TRANSACTION_ID, CARTA_PORTE_ID, NUMERO_CARTA_PORTE, INVENTORY_ITEM_ID,
                                                                                TRANSACTION_SOURCE_TYPE_ID, TRANSACTION_TYPE_ID, TRANSACTION_ACTION_ID, REASON_ID,
                                                                                 LOT_NUMBER, ACCT_PERIOD, OPERATING_UNIT, ORGANIZATION_ID, SUBINVENTORY_CODE,
                                                                                  LOCATOR_ID, TRANSFER_OPERATING_UNIT, TRANSFER_ORGANIZATION_ID, TRANSFER_SUBINVENTORY,
                                                                                   TRANSFER_LOCATOR_ID, OWNING_OPERATING_UNIT, OWNING_ORGANIZATION_ID, XFR_OWNING_ORGANIZATION_ID,
                                                                                   TRANSACTION_QUANTITY, USED_QUANTITY, STATUS, ITEM_ONCCA_IIBB
                                                                                     from  bolinf.XX_TCG_IIBB_SALDO_INI_HIS
                                                                                     where his_periodo = L_period_ant;
            commit;
            execute immediate 'truncate table bolinf.XX_TCG_IIBB_ORIGEN';
            insert into  bolinf.XX_TCG_IIBB_ORIGEN( ORIGEN_IIBB_ID, PERIODO, OPERATING_UNIT, DOCUMENTO_TIPO, DOCUMENTO_ID,
                                                                        CEREAL_TIPO, TRANSACTION_ID, KILOS, ORIGEN_PROVINCIA, ORIGEN_LOCALIDAD, CARTA_PORTE_ORIGEN,
                                                                         CONTRATO_ID, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, LAST_UPDATE_LOGIN)
                                                                         select ORIGEN_IIBB_ID, PERIODO, OPERATING_UNIT, DOCUMENTO_TIPO, DOCUMENTO_ID,
                                                                        CEREAL_TIPO, TRANSACTION_ID, KILOS, ORIGEN_PROVINCIA, ORIGEN_LOCALIDAD, CARTA_PORTE_ORIGEN,
                                                                         CONTRATO_ID, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, LAST_UPDATE_LOGIN
                                                                          from  bolinf.XX_TCG_IIBB_ORIGEN_HIS where his_periodo = L_period_ant;

          commit;
          debug( 'Calculando el ingreso de informacion para el periodo ' || p_periodo , NULL );
          FND_FILE.Put_Line(FND_FILE.Output,  'Calculando el ingreso de informacion para el periodo ' || p_periodo);

          XX_AR_IIBB_PROCESO_CEREAL_PK.Actualiza_Saldo ( p_periodo   => p_periodo
                                                       , p_status    => 'PRELIMINAR'
                                                       , x_error_msg => l_errmsg
                                                       );

          IF l_errmsg IS NOT NULL THEN
                raise reca_error;
          END IF;

           XX_AR_IIBB_PROCESO_CEREAL_PK.Procesa_CPS_Origen_IIBB ( p_periodo   => p_periodo
                                                       , x_error_msg => l_errmsg
                                                       );

           IF l_errmsg IS NOT NULL THEN
                   raise reca_error;

          END IF;

          update     xx_ar_iibb_CAB_all    set tipo_ejecucion = 'PRELIMINAR'
                              where org_id =g_org_id_ingreso and periodo = p_periodo  AND TIPO_LOGICA = 'INGRESO'; -- el org_id para INGRESO es fija
          COMMIT;
         FND_FILE.Put_Line(FND_FILE.Output,  'Calculo origen - finalizado para el periodo ' || p_periodo);
          debug( 'Calculo origen - finalizado para el periodo ' || p_periodo , NULL );

 exception when reca_error then
                     errbuf := l_errmsg;
                                                  FND_FILE.Put_Line(FND_FILE.Output, l_errmsg);
                                       debug( l_errmsg , NULL );
          v_flag := FND_CONCURRENT.SET_COMPLETION_STATUS('ERROR',l_errmsg);

 end Recalculo_CP_Origen;

END XX_AR_IIBB_PROCESO_CEREAL_PK;
/

exit
