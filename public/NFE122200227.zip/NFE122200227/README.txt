====================================
- BEGIN - NFE122200227
====================================

Product  - XXSN - Ninecon Solutions
Release  - R12.1 / R12.2
Platform - Generic Platform
Built    - 2018/08/22

====================================
(1) Pre-install Tasks
====================================

 a) Apply patch NFE122_0514_008.

====================================
(2) Verify Oracle EBS version
====================================

====================================
(2.1) Apply Patch - for EBS releases 12.1 only
====================================

 a) Extract file NFE122200227.zip on your on directory structure for patch application:

   $ cd <directory structure>
   $ unzip NFE122200227.zip
   $ cd NFE122200227

  b) Execute this patch by "adpatch" for the drivers below:

    $ adpatch options=hotpatch driver=uNFE122200227.drv logfile=uNFE122200227.log patchtop=$PWD workers=1

====================================
(2.2) Apply Patch - for EBS releases 12.2 only
====================================

 a) Extract file NFE122200227.zip on $PATCH_TOP

   $ cd $PATCH_TOP
   $ unzip NFE122200227.zip
   $ cd NFE122200227

 b) Execute this patch by "adop" for the drivers below:

   $ adop phase=apply patches=NFE122200227:uNFE122200227.drv workers=1

====================================
(3) Post-install Tasks
====================================


====================================
- END OF FILE
====================================
