set scan off;
set define off;
--WHENEVER SQLERROR EXIT FAILURE ROLLBACK
--CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
--
DECLARE
  --$Header: NFEE_UPD_CLASSPATH.sql 122.5.14.001 2018-08-15 00:00:00 ninecon noship $
  --
  l_nprogram_id        NUMBER;
  l_vexecution_options VARCHAR2(500);
  --
BEGIN
  --
  SELECT concurrent_program_id
        ,execution_options
    INTO l_nprogram_id
        ,l_vexecution_options
    FROM fnd_concurrent_programs_vl v
   WHERE upper(user_concurrent_program_name) LIKE '%NFE%'
     AND execution_options       IS NOT NULL
     and execution_options not like '%&1%'
     AND concurrent_program_name != 'NFEEDISTRIBUICAO'
     AND rownum = 1  -- apenas um
     AND application_id IN
         (SELECT fa.application_id
            FROM fnd_application fa
           WHERE application_short_name = 'XXSN');
  BEGIN
    UPDATE fnd_concurrent_programs
       SET execution_options       = l_vexecution_options
     WHERE 1=1
       AND concurrent_program_name in ('NFEEDISTRIBUICAO','NFEE_EXEC_JAVA_NRE');
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  --
  COMMIT;
  --
EXCEPTION
  WHEN OTHERS THEN
    NULL;
END;
/
show errors
EXIT;