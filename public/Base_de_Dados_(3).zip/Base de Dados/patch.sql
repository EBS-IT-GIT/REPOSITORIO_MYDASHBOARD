Set feed off
set echo off
set line 200;
set serveroutput on size 1000000;
spool PATCH.LST
Prompt ===
Prompt === USUARIO Mastersaf
show user
Prompt ===
Prompt ===
Prompt === Versao da instancia Oracle
select * from v$version;
Prompt ===
Prompt ===
Prompt ===

Prompt  ===  package   LIB_BD.pck
@@LIB_BD.pck
SHOW ERROR

BEGIN
    DBMS_OUTPUT.PUT_LINE( '************************************************************************** ' ) ;  	
    DBMS_OUTPUT.PUT_LINE( 'Rela��o das Tablespaces que serao utilizadas na aplicacao do patch' ) ;
    DBMS_OUTPUT.PUT_LINE( 'Dados  - ' || lib_bd.get_tbspace_dados );
    DBMS_OUTPUT.PUT_LINE( 'Indice - ' || lib_bd.get_tbspace_indice );
    DBMS_OUTPUT.PUT_LINE( '************************************************************************** ' ) ; 
    
    lib_bd.set_release('V2R01.0');
    lib_bd.set_dt_release(TO_DATE('06/08/2014','DD/MM/YYYY'));
    
    if not FALSE 
    Then
      lib_bd.set_NO_DDL;  
    End If;
    
    dbms_output.put_line('***********************************************************************');
    dbms_output.put_line('***********************************************************************');
    dbms_output.put_line('***********************************************************************');
    dbms_output.put_line('**************                                      *******************');
    dbms_output.put_line('**************                                       ******************');
    dbms_output.put_line('**************                                      *******************');
    dbms_output.put_line('**************                                      *******************');
    dbms_output.put_line('**************                                      *******************');
    dbms_output.put_line('***********************************************************************');
    dbms_output.put_line('***********************************************************************');
    dbms_output.put_line('***********************************************************************');
    
END ;
/
alter session set nls_date_format='dd-mm-yy hh:mi:ss';
commit;
select sysdate from dual;


prompt === 
prompt === 
prompt =====================================================================
prompt === 
prompt === Contagem de objetos invalidos ANTERIOR
select count(*) from user_objects where status = 'INVALID';
prompt === 
prompt === 
prompt =====================================================================
prompt === 
prompt === Listagem de objetos invalidos ANTERIOR
select object_name, object_type from user_objects where status = 'INVALID';
prompt === 
prompt === 
prompt =====================================================================
prompt =====================================================================
prompt =====================================================================
prompt ===

/*
==========================================
        Iniciando Atualizacao
==========================================
*/





prompt  === objeto   ===  MUN_FGMAISS_GERA_PREST.sql
@@MUN_FGMAISS_GERA_PREST.sql
prompt  === objeto   ===  MUN_FGMAISS_CC_MM_FPROC.sql
@@MUN_FGMAISS_CC_MM_FPROC.sql
prompt  === objeto   ===  GISS_ABAT_GERA_SUB.pks
@@GISS_ABAT_GERA_SUB.pks
prompt  === objeto   ===  GISS_ABAT_GERA_SUB.pkb
@@GISS_ABAT_GERA_SUB.pkb
prompt  === objeto   ===  GISS_ENTSAI_MM_FPROC.sql
@@GISS_ENTSAI_MM_FPROC.sql
prompt  === objeto   ===  MUN_ATENDENET_CC_MM_FPROC.sql
@@MUN_ATENDENET_CC_MM_FPROC.sql
prompt  === objeto   ===  MUN_ISSDIGITALBH_GERA_DEDUC.sql
@@MUN_ISSDIGITALBH_GERA_DEDUC.sql
prompt  === objeto   ===  MUN_ATENDENET_GERA_PREST.sql
@@MUN_ATENDENET_GERA_PREST.sql
prompt  === objeto   ===  MUN_ATENDENET_GERA_TOMAD.sql
@@MUN_ATENDENET_GERA_TOMAD.sql
prompt  === objeto   ===  GISS_ENTSAI_DADOS_PREST.sql
@@GISS_ENTSAI_DADOS_PREST.sql
prompt  === objeto   ===  MUN_DESGASPAR_MM_FPROC.sql
@@MUN_DESGASPAR_MM_FPROC.sql
prompt  === objeto   ===  s_expto8.sql
@@s_expto8.sql
prompt  === objeto   ===  MUN_EGOVERNO_GERA_TOMAD.sql
@@MUN_EGOVERNO_GERA_TOMAD.sql
prompt  === objeto   ===  MUN_EGOVERNO_GERA_TOMAD.sql
@@MUN_EGOVERNO_GERA_TOMAD.sql
prompt  === objeto   ===  MUN_ITAJAI_MM_FPROC.sql
@@MUN_ITAJAI_MM_FPROC.sql
prompt  === objeto   ===  MUN_QUIRINOPOLIS_CC_MM_FPROC.sql
@@MUN_QUIRINOPOLIS_CC_MM_FPROC.sql
prompt  === objeto   ===  MUN_QUIRINOPOLIS_GERA_PREST.sql
@@MUN_QUIRINOPOLIS_GERA_PREST.sql
prompt  === objeto   ===  MUN_DIFJ_MM_FPROC.sql
@@MUN_DIFJ_MM_FPROC.sql
prompt  === objeto   ===  MUN_SAATRINFSE_GERA_TOMAD.sql
@@MUN_SAATRINFSE_GERA_TOMAD.sql
prompt  === objeto   ===  SAF_GERA_PROD_INCENT.sql
@@SAF_GERA_PROD_INCENT.sql
prompt  === objeto   ===  jvs_arquivos_servidor_gemt.jsp
@@jvs_arquivos_servidor_gemt.jsp
prompt  === objeto   ===  jvs_arquivos_servidor.jsp
@@jvs_arquivos_servidor.jsp
prompt  === objeto   ===  PKG_JS_FPROC.pck
@@PKG_JS_FPROC.pck
prompt  === objeto   ===  pkg_parallel_fproc.pks
@@pkg_parallel_fproc.pks
prompt  === objeto   ===  safe196.sql
@@safe196.sql




SHOW ERROR

Prompt ===
prompt =====================================================================
prompt =====================================================================
prompt =====================================================================
prompt =====================================================================
Prompt ===

/*
==========================================
               Final
==========================================
*/
set echo off

alter session set nls_date_format='dd-mm-yyyy hh24:mi:ss';
commit;
select sysdate from dual;

exec lib_bd.exibe_status_patch();

spool off
set echo off
set feed on

@@validar.sql

