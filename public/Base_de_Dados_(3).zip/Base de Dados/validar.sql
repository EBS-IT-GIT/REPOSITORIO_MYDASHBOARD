/******************************************************************************/
/* Mastersaf Brasil SA                                                        */
/* Script para recompilar objetos invalidos da base                           */
/******************************************************************************/

spool erros.lst

Prompt /******************************************************************************/
Prompt /* Processando Compila��o de Objetos Inv�lidos.                               */
Prompt /* Por favor aguarde, este processo poder� ser demorado, e nenhuma mensagem   */
Prompt /* ser� dada durante esta execu��o.                                           */
Prompt /******************************************************************************/
Prompt  
Prompt 
Prompt 

SET serveroutput on size 1000000 arraysize 5 linesize 1000 feed OFF

Declare
	mcount      INTEGER;
 obj_invalid INTEGER;
	comando_w   VARCHAR2(1000);
  nome_objeto varchar2(100) := 'X';
  check_bb varchar2(10);

	PROCEDURE compila(comando VARCHAR2) IS
	 	 l_cursor Integer Default 0;
	 	 rc Integer Default 0;
	BEGIN
			 l_cursor := dbms_sql.open_cursor;
			 dbms_sql.parse(l_cursor, comando, dbms_sql.native);
			 rc := dbms_sql.Execute(l_cursor);
			 dbms_sql.close_cursor(l_cursor);
	EXCEPTION
		  WHEN OTHERS THEN	NULL;
	END;

 FUNCTION SAF_REMOVE_ACT(P_TEXTO IN VARCHAR2) RETURN VARCHAR2 IS
 
 RESULT VARCHAR2(2000);
 BEGIN
   RESULT := P_TEXTO;
   RESULT := REPLACE(RESULT,'�','A');
   RESULT := REPLACE(RESULT,'�','A');
   RESULT := REPLACE(RESULT,'�','A');
   RESULT := REPLACE(RESULT,'�','A');
   RESULT := REPLACE(RESULT,'�','A');
   RESULT := REPLACE(RESULT,'�','C');
   RESULT := REPLACE(RESULT,'�','E');
   RESULT := REPLACE(RESULT,'�','E');
   RESULT := REPLACE(RESULT,'�','E');
   RESULT := REPLACE(RESULT,'�','E');
   RESULT := REPLACE(RESULT,'�','I');
   RESULT := REPLACE(RESULT,'�','I');
   RESULT := REPLACE(RESULT,'�','I');
   RESULT := REPLACE(RESULT,'�','I');
   RESULT := REPLACE(RESULT,'�','N');
   RESULT := REPLACE(RESULT,'�','O');
   RESULT := REPLACE(RESULT,'�','O');
   RESULT := REPLACE(RESULT,'�','O');
   RESULT := REPLACE(RESULT,'�','O');
   RESULT := REPLACE(RESULT,'�','O');
   RESULT := REPLACE(RESULT,'�','U');
   RESULT := REPLACE(RESULT,'�','U');
   RESULT := REPLACE(RESULT,'�','U');
   RESULT := REPLACE(RESULT,'�','U');
   RESULT := REPLACE(RESULT,'�','Y');
   RESULT := REPLACE(RESULT,'�','a');
   RESULT := REPLACE(RESULT,'�','a');
   RESULT := REPLACE(RESULT,'�','a');
   RESULT := REPLACE(RESULT,'�','a');
   RESULT := REPLACE(RESULT,'�','a');
   RESULT := REPLACE(RESULT,'�','c');
   RESULT := REPLACE(RESULT,'�','e');
   RESULT := REPLACE(RESULT,'�','e');
   RESULT := REPLACE(RESULT,'�','e');
   RESULT := REPLACE(RESULT,'�','e');
   RESULT := REPLACE(RESULT,'�','i');
   RESULT := REPLACE(RESULT,'�','i');
   RESULT := REPLACE(RESULT,'�','i');
   RESULT := REPLACE(RESULT,'�','i');
   RESULT := REPLACE(RESULT,'�','n');
   RESULT := REPLACE(RESULT,'�','o');
   RESULT := REPLACE(RESULT,'�','o');
   RESULT := REPLACE(RESULT,'�','o');
   RESULT := REPLACE(RESULT,'�','o');
   RESULT := REPLACE(RESULT,'�','o');
   RESULT := REPLACE(RESULT,'�','u');
   RESULT := REPLACE(RESULT,'�','u');
   RESULT := REPLACE(RESULT,'�','u');
   RESULT := REPLACE(RESULT,'�','u');
   RESULT := REPLACE(RESULT,'�','y');
   RESULT := REPLACE(RESULT,'�','y');
   
   -- Caracteres especiais
   RESULT := REPLACE(RESULT,chr(10),' ');
   RESULT := REPLACE(RESULT,chr(13),' ');
   RESULT := REPLACE(RESULT,chr(9),' ');
   
   RETURN(RESULT);
 END SAF_REMOVE_ACT;

Begin

	-- por problemas de referencias cruzadas entre packages e pack body
	-- vou compilar todas as packages primeiro
	FOR c1 IN (SELECT object_name
        				  FROM user_objects
       				  WHERE object_type = 'PACKAGE BODY'
         				  AND status      = 'INVALID')
	LOOP
		  comando_w := 'alter package ' || c1.object_name || ' compile body';
  		compila(comando_w);
	END LOOP;

	-- a rotina tentar� recompilar os objetos principais (chamadores)
	FOR c1 IN (SELECT DISTINCT c.object_type, c.object_name
        				  FROM user_objects c
       				  WHERE c.status = 'INVALID'
         				  AND c.object_type <> 'PACKAGE BODY'
         				  AND Not Exists (SELECT NULL
                           						FROM user_dependencies b
                        			  			WHERE b.referenced_name = c.object_name))
	LOOP
  		comando_w := 'alter ' || c1.object_type || ' ' || c1.object_name || ' compile';
  		compila(comando_w);
	END LOOP;


	FOR c1 IN (SELECT DISTINCT c.object_type, c.object_name, c.owner
        				  FROM all_objects c
       				  WHERE c.status = 'INVALID'
         				  AND c.object_type in ('PROCEDURE','FUNCTION','TRIGGER','PACKAGE','TYPE','TYPE BODY','VIEW') 
         				  AND OWNER  IN (select username from user_users)
         	order by object_type, object_name)
	LOOP
  		comando_w := 'alter '||c1.object_type||' '||c1.owner||'.'||c1.object_name||' compile';
  		compila(comando_w);
	END LOOP;
	
	-- por problemas de referencias cruzadas entre packages e pack body
	-- vou compilar todas as packages primeiro
	FOR c1 IN (SELECT object_name
        				  FROM user_objects
       				  WHERE object_type = 'PACKAGE BODY'
         				  AND status      = 'INVALID')
	LOOP
		  comando_w := 'alter package ' || c1.object_name || ' compile body';
  		compila(comando_w);
	END LOOP;

	-- a rotina tentar� recompilar os objetos principais (chamadores)
	FOR c1 IN (SELECT DISTINCT c.object_type, c.object_name
        				  FROM user_objects c
       				  WHERE c.status = 'INVALID'
         				  AND c.object_type <> 'PACKAGE BODY'
         				  AND Not Exists (SELECT NULL
                           						FROM user_dependencies b
                        			  			WHERE b.referenced_name = c.object_name))
	LOOP
  		comando_w := 'alter ' || c1.object_type || ' ' || c1.object_name || ' compile';
  		compila(comando_w);
	END LOOP;	

	FOR c1 IN (SELECT DISTINCT c.object_type, c.object_name, c.owner
        				  FROM all_objects c
       				  WHERE c.status = 'INVALID'
         				  AND c.object_type in ('PROCEDURE','FUNCTION','TRIGGER','PACKAGE','TYPE','TYPE BODY','VIEW') 
         				  AND OWNER  IN (select username from user_users)
         	order by object_type, object_name)
	LOOP
  		comando_w := 'alter '||c1.object_type||' '||c1.owner||'.'||c1.object_name||' compile';
  		compila(comando_w);
	END LOOP;


 -- verifica se ainda existem objetos inv�lidos
	SELECT COUNT(*) INTO obj_invalid
   FROM user_objects
  WHERE status = 'INVALID';
  
	IF obj_invalid = 0 THEN
	/*variavel adicionada para verificacao de objetos invalidos no bamboo*/
		check_bb := 'NORMAL';	
  		dbms_output.put_line('/******************************************************************************/');	
  		dbms_output.put_line('/* Todos os objetos foram recompilados com sucesso, e n�o existem objetos     */');	
		dbms_output.put_line('/* inv�lidos. '|| check_bb ||'                                                */');	
  		dbms_output.put_line('/******************************************************************************/');	
	ELSE
     dbms_output.put_line('|' || rpad('*',144,'*') || '|');	
     dbms_output.put_line('|' || rpad(' Rela��o de Objetos Inv�lidos',144,' ') || '|');	     

    FOR C IN 
       (SELECT E.NAME,
               E.TYPE,
               E.LINE,
               E.POSITION,
               E.TEXT,
               O.OBJECT_TYPE,
               LPAD(' ', 200) LINHA_CODIGO
          FROM USER_ERRORS  E,
               USER_OBJECTS O
         WHERE E.NAME = O.OBJECT_NAME
           AND O.STATUS = 'INVALID')
    LOOP
         BEGIN

					 SELECT replace(replace(S.TEXT, chr(10), null), chr(9), ' ')
						 INTO C.LINHA_CODIGO
						 FROM USER_SOURCE S
						WHERE S.name = C.name
							AND S.TYPE = C.OBJECT_TYPE
							AND S.line = C.line;
         EXCEPTION
            WHEN OTHERS THEN 
                NULL;
         END;

        if nome_objeto <> c.name then
           nome_objeto := c.name;
        	 dbms_output.put_line('|' || rpad('*',144,'*') || '|');	

           dbms_output.put_line('| ' || RPAD(' OBJETO: ' || RPAD(C.NAME,50) || ' TIPO: '   || C.TYPE ,142) || ' |' );
           
           dbms_output.put('|  ');
           dbms_output.put(rpad('LINHA', 5));
           dbms_output.put(' | ');
           dbms_output.put(rpad('ERRO', 50));
           dbms_output.put(' | ');           
           dbms_output.put(rpad('CODIGO', 80));
           dbms_output.put_line(' |');
        end if;
       
       dbms_output.put('|  ');
       dbms_output.put(rpad(C.LINE, 5));
       dbms_output.put(' | ');
       dbms_output.put(rpad(SAF_REMOVE_ACT(C.TEXT), 50));		
       dbms_output.put(' | ');                         
       dbms_output.put(rpad(substr(c.linha_codigo,1,80), 80));
       dbms_output.put_line(' |');
       

    END LOOP;

  	dbms_output.put_line('|' || rpad('*',144,'*') || '|');	

    dbms_output.put_line(chr(9));
    dbms_output.put_line(chr(9));
    dbms_output.put_line(chr(9));
    dbms_output.put_line(chr(9));
		
		/*variavel utilizada para verificacao de objetos invalidos na base - para o bamboo*/
		
		check_bb := 'BASE';
		
  		dbms_output.put_line('/******************************************************************************/');	
  		dbms_output.put_line('/* ATEN��O: Existem ' || rpad(obj_invalid || ' objetos inv�lidos.',23) || '   */');	
  		dbms_output.put_line('/******************************************************************************/');	
  		dbms_output.put_line('/* Acima est�o listados os erros que est�o invalidando os objetos no banco    */');
		dbms_output.put_line('/* de dados. Os erros apresentados neste log foram gravados em um arquivo     */');
		dbms_output.put_line('/* chamado ERROS.LST, que poder� ser encontrado dentro do diret�rio de        */');
		dbms_output.put_line('/* instala��o do oracle %ORACLE_HOME%\BIN.                                    */');
		dbms_output.put_line('/* Solicitamos que o arquivo ERROS.LST seja enviado para a equipe de suporte  */');
		dbms_output.put_line('/* MasterSAF. ' || check_bb || 'ERRORS                                        */');
  		dbms_output.put_line('/******************************************************************************/');	
	END IF;
END;
/
spool off;
