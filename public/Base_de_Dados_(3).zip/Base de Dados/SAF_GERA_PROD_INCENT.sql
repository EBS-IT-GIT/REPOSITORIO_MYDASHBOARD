CREATE OR REPLACE PROCEDURE SAF_GERA_PROD_INCENT (P_STATUS OUT NUMBER) IS
  CONT_W  NUMBER := 0;
  P_GRUPO VARCHAR2(9);
  v_cod_param prt_prod_msaf.Cod_Param%TYPE;
  CHAVE_W VARCHAR2(2000);
BEGIN
--OS3722 - script para gerar os dados das novas parametriza��es por produto

FOR C1 IN (SELECT A.COD_EMPRESA,A.COD_ESTAB,A.COD_GRP_INCENT,A.IND_GRP_ESP,
                  X2013.GRUPO_PRODUTO,X2013.IND_PRODUTO,X2013.COD_PRODUTO,X2013.VALID_PRODUTO
           FROM   X2013_PRODUTO X2013,ICT_GRP_INCENT A
           WHERE  X2013.COD_GRP_INCENT = A.COD_GRP_INCENT
           AND    NVL(A.IND_GRP_ESP,'1') <> '2'
           AND    X2013.GRUPO_PRODUTO IN
                  (  SELECT B.GRUPO_ESTAB
                     FROM   RELAC_TAB_GRUPO B
                     WHERE  B.VALID_INICIAL <= X2013.VALID_PRODUTO
                     AND    B.COD_TABELA     = 2013
                     AND    B.COD_ESTAB      = A.COD_ESTAB
                     AND    B.COD_EMPRESA    = A.COD_EMPRESA)
           ORDER  BY A.COD_EMPRESA,A.COD_ESTAB,X2013.GRUPO_PRODUTO,X2013.IND_PRODUTO,X2013.COD_PRODUTO,X2013.VALID_PRODUTO DESC
           )
LOOP
-- SAF_PEGA_GRUPO(C1.COD_EMPRESA,C1.COD_ESTAB, 2013, C1.VALID_PRODUTO, P_GRUPO);

 IF NVL(C1.IND_GRP_ESP,'1') = '1' THEN
    v_cod_param := '572';
 ELSIF C1.IND_GRP_ESP = '3' THEN
    v_cod_param := '573';
 END IF;
 CHAVE_W:= RPAD(C1.COD_EMPRESA,3)||' - '||RPAD(C1.COD_ESTAB,6)||' - '||RPAD(v_cod_param,3)
                         ||' - '||RPAD(P_GRUPO,9)||' - '||C1.ind_produto||' - '||RPAD(C1.cod_produto,35);
 
 BEGIN
 insert into prt_prod_msaf
   (cod_empresa, cod_estab, cod_param, grupo_produto, ind_produto, cod_produto_ini, cod_produto_fim,
    ind_excecao, cod_grp_incent, tipo_codigo_declan, codigo_declan)
 values
   (C1.COD_EMPRESA,C1.COD_ESTAB, v_cod_param, C1.GRUPO_PRODUTO, C1.ind_produto, C1.cod_produto, C1.cod_produto, 'N', C1.cod_grp_incent, NULL, NULL);
 EXCEPTION
   WHEN DUP_VAL_ON_INDEX THEN
     NULL;
   WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERRO NA INSERCAO:'||CHAVE_W||' - '||SUBSTR(SQLERRM,1,50));
 END; 
CONT_W := CONT_W +1;
IF CONT_W > 500 THEN
  CONT_W := 0;
  COMMIT;
END IF;

END LOOP;
COMMIT;
P_STATUS := 1;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('SAF_GERA_PROD_INCENT: Erro durante a execu��o da procedure.');
    DBMS_OUTPUT.PUT_LINE('ERRO NAO PREVISTO:' || CHAVE_W || '): ' || SQLERRM);
    ROLLBACK;
    P_STATUS := 0;
    RETURN;
END;
/
