CREATE OR REPLACE PROCEDURE saf_exporta_tab(p_num_job      IN NUMBER,
														  p_num_proc_ini OUT NUMBER,
														  p_num_proc_fim OUT NUMBER,
														  p_status       OUT NUMBER) IS

	/* VARIAVEIS DE TRABALHO */
	TYPE file_type IS RECORD(
		id BINARY_INTEGER);
	arq_w utl_file.file_type;

	/* CONTADORES */
	num_op_commit_w NUMBER;
	tot_reg         NUMBER;

	/* VARIAVEIS DE TRATAMENTO DE ERRO */
	chave_w        log_det_proc.mens_erro%TYPE;
	ac_reg         NUMBER := 0;
	status_w       NUMBER := 0;
	seq_erro       NUMBER := 0;
	erro           NUMBER := -1;
	num_processo_w log_processo.num_processo%TYPE;
	nome_arq_w     VARCHAR(200);
	existe_w       NUMBER;
	vez_w          NUMBER := 0;
	dir_w          VARCHAR2(4000);
	tabela_w       VARCHAR2(4000);
	proximo_job EXCEPTION;
	valor_erro_w VARCHAR(200);

	CURSOR reg1 IS
		SELECT a.num_job
         , a.cod_empresa
         , D.cod_estab
         , D.dsc_diretorio         
         , a.dat_refer_ini
         , a.dat_refer_fim
         , a.ind_dat_arq
         , NVL(ltrim(rtrim(D.DSC_DIRETORIO)),ltrim(rtrim(A.DSC_DIRETORIO))) diretorio 
         , a.dat_ini_job
         , a.dat_fim_job
         , b.grupo_arquivo
         , b.numero_arquivo
         , ltrim(rtrim(c.nom_tab_work)) tabela			
         , E.COD_MASC_IMP prefixo
         , B.IND_GERA_X530 
         , B.IND_GERA_X751
				 , B.IND_GERA_IRPJ
		  FROM job_export    a
         , job_exp_tab   b
         , cat_prior_imp c
         , job_exp_estab d
         , IBT_MASC_IMP  e
     WHERE b.numero_arquivo = c.numero_arquivo
       AND b.grupo_arquivo = c.grupo_arquivo
       AND a.status = 'PEND'
       AND a.num_job = b.num_job
       AND a.num_job = nvl(p_num_job, a.num_job)
       AND D.NUM_JOB = a.num_job
       AND D.COD_EMPRESA = E.COD_EMPRESA (+)
       AND D.COD_ESTAB = E.COD_ESTAB (+)
  ORDER BY b.grupo_arquivo  DESC
         , b.numero_arquivo DESC ;

  c1 reg1%ROWTYPE;
  vIND_TAB_ARQ CHAR(1);
	/* INICIO */

BEGIN
	p_status := 0;

	OPEN reg1;
	FETCH reg1
		INTO c1;
	WHILE reg1%FOUND LOOP
		BEGIN
			/* GERA O NUMERO DO PROCESSO PARA A TABELA A SER EXPORTADA */
			saf_ini_proc('EXPX' || substr(c1.tabela, 5), c1.cod_empresa,
							 c1.cod_estab, c1.dat_refer_ini, c1.dat_refer_fim, 'EXP',
							 'GER', num_processo_w);
			vez_w := vez_w + 1;
			IF vez_w = 1 THEN
				p_num_proc_ini := num_processo_w;
			END IF;
		
			p_num_proc_fim := num_processo_w;
		
			BEGIN
				UPDATE job_export
				SET    dat_ini_job = SYSDATE,
						 status      = 'INC'
				WHERE  num_job = c1.num_job;
			EXCEPTION
				WHEN OTHERS THEN
					status_w := -1;
					seq_erro := seq_erro + 1;
					saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 60112,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
			END;
			COMMIT;
		  /* OS 2210 */
			IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
				tabela_w := c1.tabela;
			ELSE
				IF c1.tabela = 'SAFX01' THEN
					 tabela_w := 'IRPJ_CONTABIL';
				ELSIF c1.tabela = 'SAFX02' THEN
					 tabela_w := 'IRPJ_SALDOS_CONTABEIS';
				ELSIF c1.tabela = 'SAFX80' THEN
					 tabela_w := 'IRPJ_SALDOS_CONTABEIS_CC';
				ELSIF c1.tabela = 'SAFX2002' THEN
					 tabela_w := 'IRPJ_PLANO_CONTAS';
				ELSIF c1.tabela = 'SAFX2003' THEN
					 tabela_w := 'IRPJ_CENTRO_CUSTO';		
				ELSIF c1.tabela = 'SAFX2057' THEN
					 tabela_w := 'IRPJ_CADASTRO_SCP';		
				END IF;
			END IF;	
					 
			IF nvl(c1.ind_dat_arq, 'N') IN ('G', 'S') THEN
				nome_arq_w := lower(tabela_w) || to_char(SYSDATE, 'YYYYMMDD') || '.txt';
			ELSIF nvl(c1.ind_dat_arq, 'N') = 'P' THEN
				nome_arq_w := lower(tabela_w) || to_char(c1.dat_refer_fim, 'YYYYMMDD') || '.txt';
      ELSIF nvl(c1.ind_dat_arq, 'N') = 'N' THEN
				nome_arq_w := lower(tabela_w) || '.txt';
			END IF;		
			
      /* OS 1547 */
			IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
				dir_w := c1.diretorio;
				IF C1.PREFIXO IS NOT NULL THEN
					 nome_arq_w := REPLACE(LOWER(nome_arq_w),'safx',C1.PREFIXO);
				END IF;
			ELSE
        BEGIN
          SELECT  IND_TAB_ARQ
          INTO    vIND_TAB_ARQ
          FROM    PRT_INTEGRA_IRPJ
          WHERE   COD_EMPRESA = c1.cod_empresa
          AND     COD_ESTAB   = c1.cod_estab;
        EXCEPTION
          WHEN OTHERS THEN
               vIND_TAB_ARQ     := NULL;

        END;
        IF vIND_TAB_ARQ IS NULL OR vIND_TAB_ARQ = 'A' THEN
				IF C1.PREFIXO IS NOT NULL THEN
					 nome_arq_w := REPLACE(LOWER(nome_arq_w),'irpj',C1.PREFIXO);
				END IF;
				Begin
				 Select f.directory_name
				   Into dir_w 
				   From prt_diretorios_irpj f
				  Where f.cod_empresa = c1.cod_empresa
					  And f.cod_estab = c1.cod_estab
						And f.cod_tabela = c1.tabela
						And f.cod_modulo = 'JOB SERVIDOR';	
				Exception
					When no_data_found Then
						 dir_w := ' ';
					When others Then	 
						 dir_w := ' ';
						 status_w := 2;
  					 seq_erro := seq_erro + 1;
					   saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 90999,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
					   RAISE proximo_job;					
				End;		
			  END IF;
      END IF;	   
		  /* OS 1547 */
    
			/* ABRE ARQUIVO TEXTO DE SAIDA */
      IF dir_w is not null THEN
			BEGIN
				-- esta chamada de FOPEN so pode ser utilizada a partir do Oracle 8.0.0.5    
				arq_w := utl_file.fopen(dir_w, nome_arq_w, 'w', 32767);
				--    ARQ_W := UTL_FILE.FOPEN (C1.DIRETORIO, NOME_ARQ_W, 'w'); -->Oracle 7.2
			
			EXCEPTION
				WHEN utl_file.invalid_path THEN
					status_w := 2;
					seq_erro := seq_erro + 1;
					saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 90733,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
					RAISE proximo_job;
				WHEN utl_file.invalid_operation THEN
					status_w := 2;
					seq_erro := seq_erro + 1;
					saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 90732,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
					RAISE proximo_job;
				WHEN OTHERS THEN
					status_w := 2;
					seq_erro := seq_erro + 1;
					saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 90999,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
					RAISE proximo_job;
			END;
      END IF;
		
			IF c1.tabela = 'SAFX01' THEN
          IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
              saf_exp_x01(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                      c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                      status_w);
          ELSE
					   irpj_exp_x01(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
									c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
									status_w);				
          END IF;
			ELSIF c1.tabela = 'SAFX02' THEN
          IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
				     saf_exp_x02(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
				  ELSE					
					   irpj_exp_x02(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
									c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
									status_w);				
          END IF;      
			ELSIF c1.tabela = 'SAFX100' THEN
				saf_exp_x100(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX101' THEN
				saf_exp_x101(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX102' THEN
				saf_exp_x102(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX103' THEN
				saf_exp_x103(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);                 
			ELSIF c1.tabela = 'SAFX104' THEN
				saf_exp_x104(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);                 
			ELSIF c1.tabela = 'SAFX105' THEN
				saf_exp_x105(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);                 
			ELSIF c1.tabela = 'SAFX106' THEN
				saf_exp_x106(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);                 
			ELSIF c1.tabela = 'SAFX03' THEN
				saf_exp_x03(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX301' THEN
				saf_exp_x301(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX300' THEN
				saf_exp_x300(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX04' THEN
				saf_exp_x04(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX05' THEN
				saf_exp_x05(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX501' THEN
				saf_exp_x501(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX500' THEN
				saf_exp_x500(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX06' THEN
				saf_exp_x06(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX07' THEN
				saf_exp_x07(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX08' THEN
				saf_exp_x08(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX09' THEN
				saf_exp_x09(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX10' THEN
				saf_exp_x10(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX11' THEN
				saf_exp_x11(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX12' THEN
				saf_exp_x12(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX13' THEN
				saf_exp_x13(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX14' THEN
				saf_exp_x14(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX15' THEN
				saf_exp_x15(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX16' THEN
				saf_exp_x16(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX17' THEN
				saf_exp_x17(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX18' THEN
				saf_exp_x18(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX19' THEN
				saf_exp_x19(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX2001' THEN
				saf_exp_x2001(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2002' THEN
				IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
					saf_exp_x2002(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
										c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
										status_w);
				ELSE
					irpj_exp_x2002(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
										c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
										status_w);					
				END IF;						
			ELSIF c1.tabela = 'SAFX2003' THEN
				IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
					saf_exp_x2003(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
										c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
										status_w);
				ELSE						
					irpj_exp_x2003(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
										c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
										status_w);
				END IF;						
			ELSIF c1.tabela = 'SAFX2004' THEN
				saf_exp_x2004(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2005' THEN
				saf_exp_x2005(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2006' THEN
				saf_exp_x2006(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2007' THEN
				saf_exp_x2007(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2008' THEN
				saf_exp_x2008(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2009' THEN
				saf_exp_x2009(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2010' THEN
				saf_exp_x2010(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2011' THEN
				saf_exp_x2011(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2012' THEN
				saf_exp_x2012(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2013' THEN
				saf_exp_x2013(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2014' THEN
				saf_exp_x2014(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2015' THEN
				saf_exp_x2015(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2016' THEN
				saf_exp_x2016(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2017' THEN
				saf_exp_x2017(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2018' THEN
				saf_exp_x2018(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2019' THEN
				saf_exp_x2019(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2020' THEN
				saf_exp_x2020(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2021' THEN
				saf_exp_x2021(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2022' THEN
				saf_exp_x2022(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2023' THEN
				saf_exp_x2023(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2024' THEN
				saf_exp_x2024(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			/* OS2630 */
			ELSIF c1.tabela = 'SAFX2025' THEN
				saf_exp_x2025(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2027' THEN
				saf_exp_x2027(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2028' THEN
				saf_exp_x2028(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2029' THEN
				saf_exp_x2029(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2030' THEN
				saf_exp_x2030(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2031' THEN
				saf_exp_x2031(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2032' THEN
				saf_exp_x2032(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2033' THEN
				saf_exp_x2033(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2034' THEN
				saf_exp_x2034(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2035' THEN
				saf_exp_x2035(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2036' THEN
				saf_exp_x2036(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2037' THEN
				saf_exp_x2037(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2042' THEN
				saf_exp_x2042(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2043' THEN
				saf_exp_x2043(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2044' THEN
				saf_exp_x2044(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2045' THEN
				saf_exp_x2045(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2047' THEN
				saf_exp_x2047(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2048' THEN
				saf_exp_x2048(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2049' THEN
				saf_exp_x2049(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			/* OS2260 */
			ELSIF c1.tabela = 'SAFX2050' THEN
				saf_exp_x2050(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2053' THEN
				saf_exp_x2053(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2054' THEN
				saf_exp_x2054(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
      /* OS3924 */
			ELSIF c1.tabela = 'SAFX2055' THEN
				saf_exp_x2055(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
      /* OS3835-A */
			ELSIF c1.tabela = 'SAFX2056' THEN
				saf_exp_x2056(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);                  
      /*OS4316*/            
			ELSIF c1.tabela = 'SAFX2057' THEN
				IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
          saf_exp_x2057(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                    c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                    status_w);
				ELSE
					irpj_exp_x2057(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
										c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
										status_w);					
				END IF;						

			ELSIF c1.tabela = 'SAFX2058' THEN
				saf_exp_x2058(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
                  
			ELSIF c1.tabela = 'SAFX2059' THEN
				saf_exp_x2059(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);                          

			/* OS2388-Zdw */
			ELSIF c1.tabela = 'SAFX2060' THEN
				saf_exp_x2060(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2061' THEN
				saf_exp_x2061(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2062' THEN
				saf_exp_x2062(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			/* OS2388-Zdw */
			ELSIF c1.tabela = 'SAFX2080' THEN
				saf_exp_x2080(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2081' THEN
				saf_exp_x2081(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2082' THEN
				saf_exp_x2082(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2083' THEN
				saf_exp_x2083(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2084' THEN
				saf_exp_x2084(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2085' THEN
				saf_exp_x2085(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2087' THEN
				saf_exp_x2087(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);            
			ELSIF c1.tabela = 'SAFX2088' THEN
				saf_exp_x2088(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2089' THEN
				saf_exp_x2089(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2090' THEN
				saf_exp_x2090(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2091' THEN
				saf_exp_x2091(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2092' THEN
				saf_exp_x2092(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2093' THEN
				saf_exp_x2093(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2094' THEN
				saf_exp_x2094(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2095' THEN
				saf_exp_x2095(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2096' THEN
				saf_exp_x2096(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2097' THEN
				saf_exp_x2097(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2098' THEN
				saf_exp_x2098(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2099' THEN
				saf_exp_x2099(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
      ELSIF c1.tabela = 'SAFX2108' THEN
        saf_exp_x2108(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);            
      ELSIF c1.tabela = 'SAFX2109' THEN
				saf_exp_x2109(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);            
      ELSIF c1.tabela = 'SAFX2110' THEN
				saf_exp_x2110(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);            
      ELSIF c1.tabela = 'SAFX2111' THEN
				saf_exp_x2111(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);         
      ELSIF c1.tabela = 'SAFX2112' THEN
				saf_exp_x2112(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);                             
                     
			ELSIF c1.tabela = 'SAFX2113' THEN
				saf_exp_x2113(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      
      ELSIF c1.tabela = 'SAFX2114' THEN
				saf_exp_x2114(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX21' THEN
				saf_exp_x21(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX207' THEN
				saf_exp_x207(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
 			ELSIF c1.tabela = 'SAFX208' THEN
				saf_exp_x208(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX209' THEN
				saf_exp_x209(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX210' THEN -- NRFREITAS
				saf_exp_x210(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX211' THEN
				saf_exp_x211(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX212' THEN
				saf_exp_x212(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX213' THEN -- OS3974
				saf_exp_x213(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX2101' THEN
				saf_exp_x2101(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2102' THEN
				saf_exp_x2102(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2103' THEN
				saf_exp_x2103(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
			ELSIF c1.tabela = 'SAFX2105' THEN
				saf_exp_x2105(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								  status_w);
      ELSIF c1.tabela = 'SAFX2106' THEN
        saf_exp_x2106(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);
      ELSIF c1.tabela = 'SAFX2107' THEN
        saf_exp_x2107(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);									
			ELSIF c1.tabela = 'SAFX22' THEN
				saf_exp_x22(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX23' THEN
				saf_exp_x23(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX24' THEN
				saf_exp_x24(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX25' THEN
				saf_exp_x25(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX26' THEN
				saf_exp_x26(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX27' THEN
				saf_exp_x27(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX28' THEN
				saf_exp_x28(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX280' THEN
				saf_exp_x280(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX281' THEN
				saf_exp_x281(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX29' THEN
				saf_exp_x29(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX291' THEN
				saf_exp_x291(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX292' THEN
				saf_exp_x292(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								 c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								 status_w);
			ELSIF c1.tabela = 'SAFX30' THEN
				saf_exp_x30(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX32' THEN
				saf_exp_x32(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX34' THEN
				saf_exp_x34(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX35' THEN
				saf_exp_x35(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX36' THEN
				saf_exp_x36(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX37' THEN
				saf_exp_x37(c1.dat_refer_ini, c1.dat_refer_fim, arq_w,
								num_processo_w, tot_reg, status_w);
			ELSIF c1.tabela = 'SAFX38' THEN
				saf_exp_x38(c1.dat_refer_ini, c1.dat_refer_fim, arq_w,
								num_processo_w, tot_reg, status_w);
			ELSIF c1.tabela = 'SAFX39' THEN
				saf_exp_x39(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini, c1.dat_refer_fim, arq_w,
								num_processo_w, tot_reg, status_w);
			ELSIF c1.tabela = 'SAFX40' THEN
				saf_exp_x40(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX41' THEN
				saf_exp_x41(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX42' THEN
				saf_exp_x42(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX43' THEN
				saf_exp_x43(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX431' THEN
				saf_exp_x431(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX44' THEN
				saf_exp_x44(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX45' THEN
				saf_exp_x45(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX46' THEN
				saf_exp_x46(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX47' THEN
				saf_exp_x47(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX48' THEN
				saf_exp_x48(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX49' THEN
				saf_exp_x49(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX50' THEN
				saf_exp_x50(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX51' THEN
				saf_exp_x51(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX52' THEN
				saf_exp_x52(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX53' THEN
				saf_exp_x53(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, c1.ind_gera_x530, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX54' THEN
				saf_exp_x54(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX55' THEN
				saf_exp_x55(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX56' THEN
				saf_exp_x56(c1.dat_refer_ini, c1.dat_refer_fim, arq_w,
								num_processo_w, tot_reg, status_w);
			ELSIF c1.tabela = 'SAFX57' THEN
				saf_exp_x57(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX58' THEN
				saf_exp_x58(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX59' THEN
				saf_exp_x59(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX60' THEN
				saf_exp_x60(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX62' THEN
				saf_exp_x62(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX63' THEN
				saf_exp_x63(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX64' THEN
				saf_exp_x64(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX65' THEN
				saf_exp_x65(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX66' THEN
				saf_exp_x66(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX67' THEN
				saf_exp_x67(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX68' THEN
				saf_exp_x68(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX69' THEN
				saf_exp_x69(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX70' THEN
				saf_exp_x70(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX700' THEN
				saf_exp_x700(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX701' THEN
				saf_exp_x701(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX702' THEN
				saf_exp_x702(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX71' THEN
				saf_exp_x71(c1.cod_empresa, c1.cod_estab, arq_w, num_processo_w,
								tot_reg, status_w);
			ELSIF c1.tabela = 'SAFX72' THEN
				saf_exp_x72(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX75' THEN
				saf_exp_x75(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, c1.IND_GERA_X751, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX76' THEN
				saf_exp_x76(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX77' THEN
				saf_exp_x77(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX78' THEN
				saf_exp_x78(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX79' THEN
				saf_exp_x79(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX80' THEN
				IF NVL(C1.IND_GERA_IRPJ, 'N') = 'N' THEN
					saf_exp_x80(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
									c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
									status_w);
				ELSE					
					irpj_exp_x80(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
									c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
									status_w);
				END IF;					
			ELSIF c1.tabela = 'SAFX81' THEN
				saf_exp_x81(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX82' THEN
				saf_exp_x82(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX83' THEN
				saf_exp_x83(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX84' THEN
				saf_exp_x84(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX85' THEN
				saf_exp_x85(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX86' THEN
				saf_exp_x86(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX87' THEN
				saf_exp_x87(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX88' THEN
				saf_exp_x88(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX90' THEN
				saf_exp_x90(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX91' THEN
				saf_exp_x91(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX96' THEN
				saf_exp_x96(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX97' THEN
				saf_exp_x97(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
			ELSIF c1.tabela = 'SAFX98' THEN
				saf_exp_x98(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX99' THEN
				saf_exp_x99(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX991' THEN
				saf_exp_x991(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX992' THEN
				saf_exp_x992(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX993' THEN
				saf_exp_x993(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX994' THEN
				saf_exp_x994(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX995' THEN
				saf_exp_x995(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                                                  
     ELSIF c1.tabela = 'SAFX107' THEN
				saf_exp_x107(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX108' THEN
				saf_exp_x108(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX109' THEN
				saf_exp_x109(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX110' THEN
				saf_exp_x110(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX111' THEN
				saf_exp_x111(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX112' THEN
				saf_exp_x112(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX113' THEN
				saf_exp_x113(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX114' THEN
				saf_exp_x114(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX115' THEN
				saf_exp_x115(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX116' THEN
				saf_exp_x116(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX117' THEN
				saf_exp_x117(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX118' THEN
				saf_exp_x118(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX119' THEN
				saf_exp_x119(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
    ELSIF c1.tabela = 'SAFX192' THEN
				saf_exp_x192(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                
    ELSIF c1.tabela = 'SAFX194' THEN
				saf_exp_x194(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX195' THEN
				saf_exp_x195(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
/* OS3743 */
     ELSIF c1.tabela = 'SAFX196' THEN
				saf_exp_x196(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX199' THEN
				saf_exp_x199(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX200' THEN
				saf_exp_x200(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);               
     ELSIF c1.tabela = 'SAFX215' THEN
				saf_exp_x215(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);               
     ELSIF c1.tabela = 'SAFX120' THEN
				saf_exp_x120(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  
		 /* OS2388-Zdw */
		 ELSIF c1.tabela = 'SAFX121' THEN
				saf_exp_x121(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);     
	   ELSIF c1.tabela = 'SAFX122' THEN
				saf_exp_x122(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);       
		 ELSIF c1.tabela = 'SAFX123' THEN
				saf_exp_x123(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);     
		 ELSIF c1.tabela = 'SAFX124' THEN
				saf_exp_x124(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  
		 ELSIF c1.tabela = 'SAFX125' THEN
				saf_exp_x125(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
		 /* OS2388-Zdw */ 
		ELSIF c1.tabela = 'SAFX502' THEN
				saf_exp_x502(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
		ELSIF c1.tabela = 'SAFX481' THEN
				saf_exp_x481(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                      
		 /* OS2388-A1 */ 
		ELSIF c1.tabela = 'SAFX126' THEN
				saf_exp_x126(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
		ELSIF c1.tabela = 'SAFX127' THEN
				saf_exp_x127(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);            
        ELSIF c1.tabela = 'SAFX128' THEN /* OS2737 */
				saf_exp_x128(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);					
                
        ELSIF c1.tabela = 'SAFX129' THEN  /* 2328-RTT-1 */
				saf_exp_x129(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX130' THEN
				saf_exp_x130(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);      

     ELSIF c1.tabela = 'SAFX131' THEN
				saf_exp_x131(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);          

     ELSIF c1.tabela = 'SAFX132' THEN
				saf_exp_x132(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);            
     ELSIF c1.tabela = 'SAFX133' THEN
				saf_exp_x133(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);            
     ELSIF c1.tabela = 'SAFX134' THEN
				saf_exp_x134(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);            
     ELSIF c1.tabela = 'SAFX135' THEN
				saf_exp_x135(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);            
     ELSIF c1.tabela = 'SAFX136' THEN
				saf_exp_x136(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);            
			ELSIF c1.tabela = 'SAFX137' THEN
				saf_exp_x137(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX138' THEN
				saf_exp_x138(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
      ELSIF c1.tabela = 'SAFX139' THEN
				saf_exp_x139(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
     ELSIF c1.tabela = 'SAFX142' THEN
				saf_exp_x142(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                

     ELSIF c1.tabela = 'SAFX140' THEN
				saf_exp_x140(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);      

     ELSIF c1.tabela = 'SAFX141' THEN
				saf_exp_x141(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
                
     ELSIF c1.tabela = 'SAFX143' THEN
				saf_exp_x143(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX144' THEN
				saf_exp_x144(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX145' THEN
				saf_exp_x145(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX146' THEN
				saf_exp_x146(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                

     ELSIF c1.tabela = 'SAFX147' THEN
				saf_exp_x147(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX148' THEN
				saf_exp_x148(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX149' THEN
				saf_exp_x149(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX150' THEN
				saf_exp_x150(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX151' THEN
				saf_exp_x151(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX152' THEN
				saf_exp_x152(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                
     ELSIF c1.tabela = 'SAFX153' THEN
				saf_exp_x153(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX154' THEN
				saf_exp_x154(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

     ELSIF c1.tabela = 'SAFX155' THEN
				saf_exp_x155(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                
     ELSIF c1.tabela = 'SAFX156' THEN
				saf_exp_x156(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                

     ELSIF c1.tabela = 'SAFX153' THEN
				saf_exp_x153(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

  	 ELSIF c1.tabela = 'SAFX158' THEN
  				saf_exp_x158(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);
  
  	 ELSIF c1.tabela = 'SAFX159' THEN
  				saf_exp_x159(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);
  	 ELSIF c1.tabela = 'SAFX161' THEN
  				saf_exp_x161(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);
  	 ELSIF c1.tabela = 'SAFX162' THEN
  				saf_exp_x162(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);

  	 ELSIF c1.tabela = 'SAFX163' THEN
  				saf_exp_x163(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);

  	 ELSIF c1.tabela = 'SAFX164' THEN
  				saf_exp_x164(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);

  	 ELSIF c1.tabela = 'SAFX165' THEN
  				saf_exp_x165(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);

  	 ELSIF c1.tabela = 'SAFX168' THEN
  				saf_exp_x168(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);
									
  	 ELSIF c1.tabela = 'SAFX170' THEN
				saf_exp_x170(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

  	 ELSIF c1.tabela = 'SAFX180' THEN
  				saf_exp_x180(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
  								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
  								status_w);
								
    ELSIF c1.tabela = 'SAFX181' THEN	
		    	saf_exp_x181(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  								

    ELSIF c1.tabela = 'SAFX182' THEN	
	    		saf_exp_x182(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  								

    ELSIF c1.tabela = 'SAFX183' THEN
				  saf_exp_x183(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  							

   	ELSIF c1.tabela = 'SAFX190' THEN	
				  saf_exp_x190(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  								
								
    ELSIF c1.tabela = 'SAFX191' THEN
				  saf_exp_x191(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  							
    ELSIF c1.tabela = 'SAFX520' THEN
				saf_exp_x520(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                
    ELSIF c1.tabela = 'SAFX531' THEN
				saf_exp_x531(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                
    ELSIF c1.tabela = 'SAFX532' THEN
				saf_exp_x532(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                                
    /*OS3482*/
    ELSIF c1.tabela = 'SAFX996' THEN
				saf_exp_x996(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  							                

			ELSIF c1.tabela = 'SAFX2051' THEN /* OS3122 */
				saf_exp_x2051(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                
                
      ELSIF c1.tabela = 'SAFX185' THEN /* OS3584-DW1 */
				saf_exp_x185(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

      ELSIF c1.tabela = 'SAFX187' THEN /* OS3169-25CDW */
            saf_exp_x187(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);  							

      ELSIF c1.tabela = 'SAFX193' THEN /* OS3620 */
            saf_exp_x193(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);  							
      ELSIF c1.tabela = 'SAFX194' THEN
				saf_exp_x194(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

      ELSIF c1.tabela = 'SAFX195' THEN
          saf_exp_x195(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);
/* OS3743 */
     ELSIF c1.tabela = 'SAFX196' THEN
				saf_exp_x196(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

      ELSIF c1.tabela = 'SAFX197' THEN
          saf_exp_x197(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);   
                                
      ELSIF c1.tabela = 'SAFX198' THEN
          saf_exp_x198(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);               
                                
      ELSIF c1.tabela = 'SAFX201' THEN
          saf_exp_x201(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);     
                                
      ELSIF c1.tabela = 'SAFX202' THEN
          saf_exp_x202(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);       
                  
      ELSIF c1.tabela = 'SAFX203' THEN
          saf_exp_x203(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);                                             
       ELSIF c1.tabela = 'SAFX175' THEN
          saf_exp_x175(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);                  
       ELSIF c1.tabela = 'SAFX176' THEN
          saf_exp_x176(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);        
                  
       ELSIF c1.tabela = 'SAFX214' THEN
          saf_exp_x214(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);           
                  
       ELSIF c1.tabela = 'SAFX188' THEN
          saf_exp_x188(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);            
                  
       ELSIF c1.tabela = 'SAFX189' THEN
          saf_exp_x189(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);            
                  
       ELSIF c1.tabela = 'SAFX2104' THEN
          saf_exp_x2104(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                  c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                  status_w);  
       --OS4657           
       ELSIF c1.tabela = 'SAFX157' THEN
				saf_exp_x157(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                
       --OS4710        
       ELSIF c1.tabela = 'SAFX221' THEN
				saf_exp_x221(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  
       --OS4710        
       ELSIF c1.tabela = 'SAFX222' THEN
				saf_exp_x222(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  
       --OS4711      
      ELSIF c1.tabela = 'SAFX169' THEN
				saf_exp_x169(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
       --OS4027       
       ELSIF c1.tabela = 'SAFX216' THEN
				saf_exp_x216(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);         
       ELSIF c1.tabela = 'SAFX217' THEN
				saf_exp_x217(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);       
      ELSIF c1.tabela = 'SAFX218' THEN
				saf_exp_x218(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
       ELSIF c1.tabela = 'SAFX219' THEN
				saf_exp_x219(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);       
       ELSIF c1.tabela = 'SAFX220' THEN
				saf_exp_x220(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                                                                                                                                 
      --MFS2132      
       ELSIF c1.tabela = 'SAFX223' THEN
				saf_exp_x223(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  

      --MFS2405     
       ELSIF c1.tabela = 'SAFX224' THEN
				   saf_exp_x224(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);   								

		
						
		
	/* MFS2631  - INICIO */
	ELSIF c1.tabela = 'SAFX225' THEN

				saf_exp_x225(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

		ELSIF c1.tabela = 'SAFX226' THEN
				saf_exp_x226(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

		ELSIF c1.tabela = 'SAFX227' THEN
    			saf_exp_x227(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

		ELSIF c1.tabela = 'SAFX228' THEN
    			saf_exp_x228(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

		ELSIF c1.tabela = 'SAFX229' THEN
    			saf_exp_x229(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

		ELSIF c1.tabela = 'SAFX230' THEN
				saf_exp_x230(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
		ELSIF c1.tabela = 'SAFX231' THEN
    			saf_exp_x231(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);

		ELSIF c1.tabela = 'SAFX232' THEN
    			saf_exp_x232(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
		
    
    --MFS2711     
    ELSIF c1.tabela = 'SAFX179' THEN
				   saf_exp_x179(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
                
   --MFS3615     
    ELSIF c1.tabela = 'SAFX233' THEN
				   saf_exp_x233(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
                      
    ELSIF c1.tabela = 'SAFX234' THEN
				   saf_exp_x234(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);    
                
   --MFS4991
                
    ELSIF c1.tabela = 'SAFX235' THEN
				   saf_exp_x235(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
                
    ELSIF c1.tabela = 'SAFX236' THEN
				   saf_exp_x236(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  			
                
    ELSIF c1.tabela = 'SAFX237' THEN
				   saf_exp_x237(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  
                
    ELSIF c1.tabela = 'SAFX238' THEN
				   saf_exp_x238(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);  
                
    ELSIF c1.tabela = 'SAFX239' THEN
				   saf_exp_x239(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);
                
    /*MFS-9667 - Inicio*/            
    ELSIF c1.tabela = 'SAFX240' THEN
				   saf_exp_x240(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                                                                     					
    ELSIF c1.tabela = 'SAFX241' THEN
				   saf_exp_x241(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
    ELSIF c1.tabela = 'SAFX242' THEN
				   saf_exp_x242(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
    ELSIF c1.tabela = 'SAFX243' THEN
				   saf_exp_x243(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w); 
    ELSIF c1.tabela = 'SAFX244' THEN
				   saf_exp_x244(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
								c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
								status_w);                                                 

    /*MFS-9667 - Fim*/    
         
    
    /*MFS8105*/
    ELSIF c1.tabela = 'SAFX245' THEN
           saf_exp_x245(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);    
                
                
   ELSIF c1.tabela = 'SAFX246' THEN
           saf_exp_x246(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w); 
                 
   ELSIF c1.tabela = 'SAFX247' THEN
           saf_exp_x247(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w); 
                
   ELSIF c1.tabela = 'SAFX248' THEN
           saf_exp_x248(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w); 
                
   ELSIF c1.tabela = 'SAFX249' THEN
           saf_exp_x249(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);                                 
                
   ELSIF c1.tabela = 'SAFX250' THEN
           saf_exp_x250(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);                       

    /*MFS10565 - Inicio*/
    ELSIF c1.tabela = 'SAFX204' THEN
           saf_exp_x204(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);           
    ELSIF c1.tabela = 'SAFX205' THEN
           saf_exp_x205(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);               
    /* I.MFS11100 */
    
        ELSIF c1.tabela = 'SAFX206' THEN
           saf_exp_x206(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);               
    /* F.MFS11100 */

	/* MFS14409 */
    ELSIF c1.tabela = 'SAFX251' THEN
       saf_exp_x251(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
            c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
            status_w); 

    ELSIF c1.tabela = 'SAFX252' THEN
           saf_exp_x252(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w); 
                
    -- MFS15195
    ELSIF c1.tabela = 'SAFX253' THEN
           saf_exp_x253(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w); 
    -- MFS15698
    ELSIF c1.tabela = 'SAFX257' THEN
           saf_exp_x257(c1.cod_empresa, c1.cod_estab, c1.dat_refer_ini,
                c1.dat_refer_fim, arq_w, num_processo_w, tot_reg,
                status_w);             
                				
		END IF;

			-- FECHA ARQUIVO TEXTO
			utl_file.fclose(arq_w);
		
			/*BEGIN
				SELECT DISTINCT 1
				INTO   existe_w
				FROM   hist_export
				WHERE  num_job = c1.num_job
				AND    grupo_arquivo = c1.grupo_arquivo
				AND    numero_arquivo = c1.numero_arquivo;
			
				UPDATE hist_export
				SET    num_processo     = num_processo_w,
						 qtd_reg_exp      = tot_reg,
						 dat_fim_processo = SYSDATE,
						 status           = status_w
				WHERE  num_job = c1.num_job
				AND    grupo_arquivo = c1.grupo_arquivo
				AND    numero_arquivo = c1.numero_arquivo;
			EXCEPTION
				WHEN no_data_found THEN*/
			BEGIN
				INSERT INTO hist_export
					(num_job,
					 grupo_arquivo,
					 numero_arquivo,
					 num_processo,
					 dat_fim_processo,
					 qtd_reg_exp,
					 status,
           cod_empresa,
           cod_estab)
				VALUES
					(c1.num_job,
					 c1.grupo_arquivo,
					 c1.numero_arquivo,
					 num_processo_w,
					 SYSDATE,
					 tot_reg,
					 status_w,
           c1.cod_empresa,
           c1.cod_estab);
			EXCEPTION
				WHEN OTHERS THEN
					status_w := -1;
					seq_erro := seq_erro + 1;
					saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 60114,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
			END;
				/*WHEN OTHERS THEN
					status_w := -1;
					seq_erro := seq_erro + 1;
					saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
								  valor_erro_w, 60113,
								  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
			END;*/
			IF status_w = 0 THEN
				saf_log_proc(num_processo_w, 'OK');
				BEGIN
					UPDATE job_export
					SET    status      = 'OK',
							 dat_fim_job = SYSDATE
					WHERE  num_job = c1.num_job;
				EXCEPTION
					WHEN OTHERS THEN
						status_w := -1;
						seq_erro := seq_erro + 1;
						saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
									  valor_erro_w, 60112,
									  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
				END;
			ELSIF status_w = -1 THEN
				saf_log_proc(num_processo_w, 'ERR');
				BEGIN
					UPDATE job_export
					SET    status      = 'ERR',
							 dat_fim_job = SYSDATE
					WHERE  num_job = c1.num_job;
				EXCEPTION
					WHEN OTHERS THEN
						status_w := -1;
						seq_erro := seq_erro + 1;
						saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
									  valor_erro_w, 60112,
									  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
				END;
			END IF;
		EXCEPTION
			WHEN proximo_job THEN
				/*BEGIN
					SELECT DISTINCT 1
					INTO   existe_w
					FROM   hist_export
					WHERE  num_job = c1.num_job
					AND    grupo_arquivo = c1.grupo_arquivo
					AND    numero_arquivo = c1.numero_arquivo;
				
					UPDATE hist_export
					SET    num_processo     = num_processo_w,
							 qtd_reg_exp      = tot_reg,
							 dat_fim_processo = SYSDATE,
							 status           = status_w
					WHERE  num_job = c1.num_job
					AND    grupo_arquivo = c1.grupo_arquivo
					AND    numero_arquivo = c1.numero_arquivo;
				EXCEPTION
					WHEN no_data_found THEN*/
				BEGIN
					INSERT INTO hist_export
						(num_job,
						 grupo_arquivo,
						 numero_arquivo,
						 num_processo,
						 dat_fim_processo,
						 qtd_reg_exp,
						 status,
             cod_empresa,
             cod_estab)
					VALUES
						(c1.num_job,
						 c1.grupo_arquivo,
						 c1.numero_arquivo,
						 num_processo_w,
						 SYSDATE,
						 tot_reg,
						 status_w,
             c1.cod_empresa,
             c1.cod_estab);
				EXCEPTION
					WHEN OTHERS THEN
						status_w := -1;
						seq_erro := seq_erro + 1;
						saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w,
									  NULL, valor_erro_w, 60114,
									  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
				END;
					/*WHEN OTHERS THEN
						status_w := -1;
						seq_erro := seq_erro + 1;
						saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
									  valor_erro_w, 60113,
									  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
				END;*/
				saf_log_proc(num_processo_w, 'WAR');
				BEGIN
					UPDATE job_export
					SET    status      = 'WAR',
							 dat_fim_job = SYSDATE
					WHERE  num_job = c1.num_job;
				EXCEPTION
					WHEN OTHERS THEN
						status_w := -1;
						seq_erro := seq_erro + 1;
						saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL,
									  valor_erro_w, 60112,
									  substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
				END;
		END;
		COMMIT;
 	p_status := status_w;
 	IF status_w = 0 THEN
 		seq_erro := seq_erro + 1;
 		saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL, valor_erro_w,
 					  60123, substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
 	END IF;
		FETCH reg1
			INTO c1;
	END LOOP;

	RETURN;
EXCEPTION
	WHEN OTHERS THEN
		p_status := -1;
		IF utl_file.is_open(arq_w) THEN
			utl_file.fclose(arq_w);
		END IF;
		seq_erro := seq_erro + 1;
		saf_at_log(num_processo_w, seq_erro, ac_reg, chave_w, NULL, valor_erro_w,
					  90999, substr('SAF_EXPORTA_TAB: ' || SQLERRM, 1, 200));
		RETURN;
END; 
/
