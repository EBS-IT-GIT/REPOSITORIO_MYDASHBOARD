UPDATE apps.ap_suppliers asup
SET    vat_registration_num  = DECODE( vendor_name
                                    , 'CB Agro SRL','180224090016'
                                    , 'Marcelo Gustavo Vico Ferrando', '180104670015'
                                    ,  vat_registration_num)
WHERE  vendor_name IN ('CB Agro SRL', 'Marcelo Gustavo Vico Ferrando');
--2 Registros