REM $Header: XXSTN_ICX_BLOCKREQ_PKG.pkb.sql 12.0.0.1 2019/07/16 19:55:08 lcarmo noship $
REM ****************************************************************************
REM   File    : XXSTN_ICX_BLOCKREQ_PKG.pkb.sql
REM   Propose : This is the package Body for XXSTN_ICX_BLOCKREQ_PKG
REM   Author  : lcarmo
REM   Date    : 08-18-2019
REM  
REM   History
REM   Version  |Date       |Author        | Desc
REM   --------------------------------------------------------------------------
REM   1.0      |08-18-2019 |lcarmo        | Initial
REM ****************************************************************************
SET FEEDBACK ON
SET ECHO OFF
SET VERIFY OFF

WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

CREATE OR REPLACE PACKAGE BODY XXSTN_ICX_BLOCKREQ_PKG IS


  /****************************************************************************
   validate_item - 
   ***************************************************************************/
  PROCEDURE check_requisition(p_reqHeaderId IN VARCHAR2, p_status OUT VARCHAR2, p_message OUT VARCHAR2)
  IS
    l_is_ok BOOLEAN    := true;
    l_status  VARCHAR2(30) := 'SUCCESS';
    l_message VARCHAR2(4200) := '';
    l_blanket_total_amount po_headers_all.blanket_total_amount%TYPE := 0;
    l_po_number            po_headers_all.segment1%TYPE := '';

    CURSOR l_maincur IS
        -- SQL 1: Obter os detalhes da requisicao
        SELECT DISTINCT
            reqh.requisition_header_id,
            reqlin.item_description,
            reqlin.unit_price   pre�o,
            reqlin.quantity     quantidade,
            ( reqlin.unit_price * reqlin.quantity ) vl_preco_quant,
            reqlin.blanket_po_header_id,
            reqlin.blanket_po_line_num
        FROM
            apps.po_req_distributions_all     reqdist,
            apps.gl_code_combinations         gcc,
            apps.po_requisition_lines_all     reqlin,
            apps.po_requisition_headers_all   reqh,
            apps.per_all_people_f             papf,
            apps.mtl_system_items             mtl,
            apps.hr_all_organization_units    hr,
            apps.po_distributions_all         pd,
            apps.po_headers_all               ph
        WHERE
            reqdist.code_combination_id = gcc.code_combination_id
            AND reqdist.requisition_line_id = reqlin.requisition_line_id
            AND reqlin.requisition_header_id = reqh.requisition_header_id
            AND reqlin.item_id = mtl.inventory_item_id (+)
            AND mtl.organization_id = reqlin.destination_organization_id
            AND reqdist.org_id = hr.organization_id
            AND reqh.preparer_id = papf.person_id
            AND reqdist.distribution_id = pd.req_distribution_id (+)
            AND pd.po_header_id = ph.po_header_id (+)
            AND papf.current_employee_flag = 'Y'
            AND reqh.requisition_header_id = p_reqHeaderId
        ORDER BY
            reqh.requisition_header_id;
    l_mainrec l_maincur%ROWTYPE;

  BEGIN

    DBMS_OUTPUT.PUT_LINE('VALIDACAO PARA O REQUISITION_HEADER_ID ' ||
                                                             p_reqHeaderId );

    OPEN l_maincur;
    LOOP
     FETCH l_maincur INTO l_mainrec;
     EXIT WHEN l_maincur%NOTFOUND;
       l_po_number := '';
       l_blanket_total_amount := 0;
       DBMS_OUTPUT.PUT_LINE('PO BLANKET ID: ' ||
                            l_mainrec.blanket_po_header_id);
       BEGIN
          -- SQL 2: VALIDA SE O CONTRATO ESTA ATIVO
          SELECT ph.segment1
            INTO l_po_number
            FROM po_headers_all   ph,
                 po_lines_all     pl
           WHERE ph.po_header_id = l_mainrec.blanket_po_header_id
             AND ph.type_lookup_code = 'BLANKET'
             AND ph.po_header_id = pl.po_header_id
             AND TRUNC(SYSDATE) BETWEEN NVL(TRUNC(ph.start_date), TRUNC(SYSDATE))
                                    AND NVL(TRUNC(ph.end_date), TRUNC(SYSDATE))
             AND TRUNC(NVL(pl.expiration_date, SYSDATE)) >= TRUNC(SYSDATE)
             GROUP BY ph.segment1;

           DBMS_OUTPUT.PUT_LINE('CONTRATO ESTA ATIVO. BLANKET PO NUMBER: ' ||l_po_number );
       EXCEPTION
       WHEN NO_DATA_FOUND THEN
         DBMS_OUTPUT.PUT_LINE('CONTRATO NAO ESTA ATIVO. PO BLANKET ID ' ||
                              l_mainrec.blanket_po_header_id);
         l_is_ok := FALSE;
         l_status := 'ERROR';
         l_message := SUBSTR(l_message ||
                             'O contrato da requisi��o n�o esta ativo. ', 4200);
       WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('FALHA AO LOCALIZAR CONTRATO ATIVO. PO BLANKET ID  ' ||
                              l_mainrec.blanket_po_header_id);
         l_is_ok := FALSE;
         l_status := 'ERROR';
         l_message := SUBSTR(l_message || ' ' || SQLERRM, 4200);
       END;

       IF l_is_ok = FALSE THEN
         EXIT;
       END IF;

       BEGIN
          -- SQL 3: OBTER QUANTIDADE DO CONTRATO
          SELECT SUM(blanket_total_amount - total_utilizado) disponivel
          INTO l_blanket_total_amount
          FROM (
                SELECT ph.po_header_id, ph.blanket_total_amount,
                   SUM(pl.unit_price * pll.quantity) total_utilizado
                  FROM po_headers_all          ph,
                       po_lines_all            pl,
                       po_line_locations_all   pll,
                       po_releases_all         pra
                 WHERE ph.po_header_id = l_mainrec.blanket_po_header_id
                   AND ph.type_lookup_code = 'BLANKET'
                   AND ph.po_header_id = pl.po_header_id
                   AND pll.po_header_id = ph.po_header_id
                   AND pll.po_line_id = pl.po_line_id
                   AND pra.po_release_id = pll.po_release_id
                   AND pra.authorization_status = 'APPROVED'
                   AND trunc(SYSDATE) BETWEEN nvl(trunc(ph.start_date), trunc(SYSDATE)) 
                                          AND nvl(trunc(ph.end_date), trunc(SYSDATE))
                   AND trunc(nvl(pl.expiration_date, SYSDATE)) >= trunc(SYSDATE)
                 GROUP BY ph.po_header_id, ph.blanket_total_amount);

            DBMS_OUTPUT.PUT_LINE('VALOR DA REQUISICAO (PRECO X QTDE) : ' ||
                                         l_mainrec.vl_preco_quant );
            DBMS_OUTPUT.PUT_LINE('SALDO DO CONTRATO: ' ||
                                         l_blanket_total_amount );
            IF( l_mainrec.vl_preco_quant > l_blanket_total_amount )
            THEN
               l_is_ok := FALSE;
               l_status := 'ERROR';
               l_message := l_message ||
                         'A quantidade � superior ao dispon�vel no contrato '||
                         l_po_number || '.';
               DBMS_OUTPUT.PUT_LINE( l_message );
            END IF;

       EXCEPTION
       WHEN OTHERS THEN
         l_is_ok := FALSE;
         l_status := 'WARNING';
         l_message := SUBSTR(l_message || ' ' || SQLERRM, 4200);
       END;
    END LOOP;
    CLOSE l_maincur;

    p_status := l_status;
    p_message := l_message;
  EXCEPTION
   WHEN OTHERS THEN
   IF l_maincur%ISOPEN THEN CLOSE l_maincur; END IF;
   ROLLBACK;
  END check_requisition;

END XXSTN_ICX_BLOCKREQ_PKG;
/

SHOW ERRORS

EXIT;