*******************************************************************************
* XXBK0020190925
*******************************************************************************
* This patch contains
* =================
* 
* Gap XXBK0020190925
* 
* 
* PRE-REQS:  
* ==============
* N/A 
* 
* POST-PATCH:
* ====================

1- Execute os passos a seguir para verificar se o patch foi aplicado como o
esperado.
Após alicar o patch execute o comando abaixo:

$ unzip $PATCH_TOP/XXBK0020190925/xxbk_classes.zip -d $JAVA_TOP
$ chmod -R 0755 $JAVA_TOP/xxbk/oracle/apps/icx

[Atenção]: Os itens 2 e 3 são obrigatórios.

2- Execute o comando adcgnjar, conforme abaixo
cd $AD_TOP/bin/

adcgnjar
(Parâmetros para este comando, deve ser informado o usuário APPS,
 e a senha do APPS)
 
3- Execute weblogic bounce (oacore_server)

Executar o script de bounce, informando a senha do weblogic

admanagedsrvctl.sh stop oacore_server1
admanagedsrvctl.sh start oacore_server1

*
* 
*******************************************************************************

