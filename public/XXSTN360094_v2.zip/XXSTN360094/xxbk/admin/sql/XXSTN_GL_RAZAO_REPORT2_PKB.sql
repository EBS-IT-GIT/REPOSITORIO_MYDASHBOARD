WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
create or replace PACKAGE BODY XXSTN_GL_RAZAO_REPORT2_PKG as
-- +=================================================================+
-- |               Copyright (c) 2017 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | xxstn_gl_razao_report_pkg.pls                                   |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Projeto Accounting Hub                                        |
-- |                                                                 |
-- | CREATED BY   RODRIGO PERASSO 14/11/2017                         |
-- |                                                                 |
-- | UPDATED BY   RODRIGO PERASSO 14/11/2017                         |
-- |                                                                 |
-- |              ROGERIO FARTO (NINECON) - 01/11/2019               |
-- |              SR-391718 - NSD307714                              |
-- |              Escopo: Correcao do campo saldo final.             |
-- |                      Considerar para fins de calculo o Valor    |
-- | Contabilizado. Hoje, estamos considerando o Valor Entrado       |
-- |                                                                 |
-- | UPDATED BY  INICIO LEANDRO W CAVALHEIRO (NINECON) - 18-03-2020  |
-- | 316534 - SR-360094 Contabilidade Projeto Informacoes no Razao GL|                            
-- |                                                                 |
-- +=================================================================+

    gv_debug_flag VARCHAR2(5) := 'Y';
    -----------------------
    PROCEDURE write_log
    (
      p_write_flag IN VARCHAR2
     ,p_message    IN VARCHAR2
    ) IS
      lv_current_timestamp VARCHAR2(35) := to_char(systimestamp, 'YYYY-MM-DD HH24:MI:SS.FF');
    BEGIN
      IF nvl(upper(substr(p_write_flag, 1, 1)), 'N') = 'Y'
      THEN
        fnd_file.put_line(fnd_file.log, lv_current_timestamp || ' :: ' || p_message);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END write_log;
    -----------------------
    PROCEDURE print_output
    (
      p_level   IN NUMBER
     ,p_message IN VARCHAR2
    ) IS
      ln_level        NUMBER := MOD(p_level, 10);
      lv_level_indent VARCHAR2(25) := '';
    BEGIN
      lv_level_indent := lpad(' ', 2 * ln_level, ' ');
      fnd_file.put_line(fnd_file.output, lv_level_indent || TRIM(p_message));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END print_output;
    -----------------------
    FUNCTION generate_xml_tag
    (
      p_data     IN VARCHAR2
     ,p_tag      IN VARCHAR2
     ,p_tag_type IN NUMBER DEFAULT gn_xml_tag_full
    ) RETURN VARCHAR2 IS
      lv_xml_tag VARCHAR2(32000);
    BEGIN
      IF p_tag_type = gn_xml_tag_full  THEN
          IF p_data IS NULL THEN
             lv_xml_tag := '<' || p_tag || ' />';
          ELSE
             lv_xml_tag := '<' || p_tag || '>' || dbms_xmlgen.convert(p_data) || '</' || p_tag || '>';
          END IF;
      ELSIF p_tag_type = gn_xml_tag_start THEN
          lv_xml_tag := '<' || p_tag || '>';
      ELSIF p_tag_type = gn_xml_tag_end  THEN
          lv_xml_tag := '</' || p_tag || '>';
      END IF;
      RETURN lv_xml_tag;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;
    END generate_xml_tag;
    -----------------------
    PROCEDURE print_xml_tag
    (
      p_data     IN VARCHAR2
     ,p_tag      IN VARCHAR2
     ,p_tag_type IN NUMBER DEFAULT gn_xml_tag_full
     ,p_level    IN NUMBER DEFAULT 0
    ) IS
    BEGIN
      print_output(p_level, generate_xml_tag(p_data, p_tag, p_tag_type));
    END print_xml_tag;
    -----------------------
    FUNCTION stn_ret_str(p_str in VARCHAR2,
                          p_pos in VARCHAR2,
                          p_del in VARCHAR2)  RETURN  VARCHAR2 is
    --
    l_str           VARCHAR2(2000) := p_str || p_del;
    l_pos1          NUMBER;
    l_pos2          NUMBER;
    --
    BEGIN
        IF p_pos = 1 THEN
           l_str := substr(l_str, 1, INSTR(l_str, p_del, 1,p_pos)-1 );
        ELSE
           l_pos1 := INSTR (l_str, p_del, 1, p_pos-1);
           l_pos2 := INSTR (l_str, p_del, 1, p_pos  );
           l_str  := substr(l_str, l_pos1+1, (l_pos2 - l_pos1) -1);
        END IF;
        --
        RETURN (l_str);
    END STN_RET_STR;
    --
    function special_character(p_texto IN VARCHAR2) return VARCHAR2
    is
    begin
       IF p_texto IS NOT NULL THEN
          return(REPLACE(CONVERT(p_texto,'US7ASCII', 'WE8DEC'),'??',' '));
       ELSE
          return(NULL);
       END IF;
    end;
    --
    function get_initial_balance(P_CONTA_CONTABIL IN VARCHAR2,
                                 P_START_PERIOD   IN VARCHAR2,
                                 P_START_DATE     IN VARCHAR2,
                                 P_LEDGER_ID      IN NUMBER,
                                 P_CURRENCY_CODE  IN VARCHAR2,
                                 P_START_SEGMENT1 IN VARCHAR2,
                                 P_END_SEGMENT1   IN VARCHAR2,
                                 P_START_SEGMENT2 IN VARCHAR2,
                                 P_END_SEGMENT2   IN VARCHAR2,
                                 P_START_SEGMENT3 IN VARCHAR2,
                                 P_END_SEGMENT3   IN VARCHAR2,
                                 P_START_SEGMENT5 IN VARCHAR2,
                                 P_END_SEGMENT5   IN VARCHAR2,
                                 P_START_SEGMENT6 IN VARCHAR2,
                                 P_END_SEGMENT6   IN VARCHAR2,
                                 P_START_SEGMENT7 IN VARCHAR2,
                                 P_END_SEGMENT7   IN VARCHAR2,
                                 P_START_SEGMENT8 IN VARCHAR2,
                                 P_END_SEGMENT8   IN VARCHAR2

                                 ) RETURN NUMBER
    is
        ln_initial_value number;
        ld_initial_date  date;
    begin
        BEGIN
           select NVL(SUM(NVL(gb.begin_balance_dr, 0) - NVL(gb.begin_balance_cr, 0)),0)
           into   ln_initial_value
           from   gl_balances          gb
                 ,gl_code_combinations gcc
           where  gb.code_combination_id =  gcc.code_combination_id
           and    gb.period_name         =  P_START_PERIOD   --'APR-18'
           and    gb.ledger_id           =  P_LEDGER_ID      --2026
           and    gb.currency_code       =  P_CURRENCY_CODE  --'BRL'
           and    gcc.segment1            = NVL(P_START_SEGMENT1,gcc.SEGMENT1)
           --and    gcc.segment1           <= NVL(P_END_SEGMENT1  ,gcc.SEGMENT1)
           and    gcc.segment4           =  P_CONTA_CONTABIL; --'11303002'
        EXCEPTION
           WHEN OTHERS THEN
              ln_initial_value := 0;
        END;
        --
        BEGIN
           select  gps.start_date
           into    ld_initial_date
           from    gl_period_statuses   gps
           where   gps.period_name     = P_START_PERIOD
           and     gps.ledger_id       = P_LEDGER_ID
           and     gps.application_id  = 101;
        EXCEPTION
           WHEN OTHERS THEN
              ld_initial_date := sysdate;
              RETURN(ln_initial_value);
        END;
        --
        write_log(gv_debug_flag,'P_START_DATE '||P_START_DATE);
        --
        IF P_START_DATE IS NOT NULL
           AND P_START_DATE <> ld_initial_date THEN
           --
           FOR C1 IN (SELECT  NVL(SUM(NVL(A.ENTERED_DR,0))   - SUM(NVL(A.ENTERED_CR,0)),0) SALDO
                             ,NVL(SUM(NVL(A.ACCOUNTED_DR,0)) - SUM(NVL(A.ACCOUNTED_CR,0)),0) SALDO_CONV
                      FROM    APPS.GL_JE_LINES          A
                             ,APPS.GL_CODE_COMBINATIONS D
                             ,APPS.GL_JE_HEADERS        E
                             ,APPS.GL_JE_BATCHES        F
                      WHERE 1=1
                      AND A.CODE_COMBINATION_ID = D.CODE_COMBINATION_ID
                      AND A.JE_HEADER_ID        = E.JE_HEADER_ID
                      AND E.JE_BATCH_ID         = F.JE_BATCH_ID
                      AND A.PERIOD_NAME         = P_START_PERIOD
                      AND E.LEDGER_ID           = P_LEDGER_ID --'2024'
                      --AND E.JE_SOURCE = '2'
                      AND E.STATUS              = 'P'                          --POSTED/UNPOSTED JOURNALS
                      AND E.DEFAULT_EFFECTIVE_DATE >= ld_initial_date
                      AND E.DEFAULT_EFFECTIVE_DATE <  P_START_DATE
                      AND D.SEGMENT1                = NVL(P_START_SEGMENT1,D.SEGMENT1)
                      --AND D.SEGMENT1               <= NVL(P_END_SEGMENT1  ,D.SEGMENT1)
                      AND D.SEGMENT2               >= NVL(P_START_SEGMENT2,D.SEGMENT2)
                      AND D.SEGMENT2               <= NVL(P_END_SEGMENT2  ,D.SEGMENT2)
                      AND D.SEGMENT3               >= NVL(P_START_SEGMENT3,D.SEGMENT3)
                      AND D.SEGMENT3               <= NVL(P_END_SEGMENT3  ,D.SEGMENT3)
                      AND D.SEGMENT4                = P_CONTA_CONTABIL
                      AND D.SEGMENT5               >= NVL(P_START_SEGMENT5,D.SEGMENT5)
                      AND D.SEGMENT5               <= NVL(P_END_SEGMENT5  ,D.SEGMENT5)
                      AND D.SEGMENT6               >= NVL(P_START_SEGMENT6,D.SEGMENT6)
                      AND D.SEGMENT6               <= NVL(P_END_SEGMENT6  ,D.SEGMENT6)
                      AND D.SEGMENT7               >= NVL(P_START_SEGMENT7,D.SEGMENT7)
                      AND D.SEGMENT7               <= NVL(P_END_SEGMENT7  ,D.SEGMENT7)
                      AND D.SEGMENT8               >= NVL(P_START_SEGMENT8,D.SEGMENT8)
                      AND D.SEGMENT8               <= NVL(P_END_SEGMENT8  ,D.SEGMENT8))
           LOOP
               ln_initial_value := NVL(ln_initial_value,0) + NVL(C1.SALDO_CONV,0);
           END LOOP;
           --
        END IF;
        --
        RETURN(ln_initial_value);
    end;
    --
    function get_flex_value_set_id(p_id_flex_num in number,
                                   p_segment_num in number)
    return number
    is
    v_flex_value_set_id number;
    begin
       select FLEX_VALUE_SET_ID
       into   V_FLEX_VALUE_SET_ID
       from   FND_ID_FLEX_SEGMENTS_VL
       where  APPLICATION_ID = 101
       and    ID_FLEX_CODE   = 'GL#'
       and    ID_FLEX_NUM    = 50388
       and    SEGMENT_NUM    = p_segment_num;
       --
       return(V_FLEX_VALUE_SET_ID);
    exception
       when others then
          return (null);
    end;
    --
    function get_period_num(p_period_name in VARCHAR2,
                            p_ledger_id1  in NUMBER)
    return number
    is
      v_period_num number;
    begin
       select GPS2.effective_period_num
       into   v_period_num
       from   gl_period_statuses   GPS2
       where  GPS2.period_name     = p_period_name
       and    GPS2.ledger_id       = p_ledger_id1
       and    GPS2.application_id  = 101;
       --
       return(v_period_num);
    exception
       when others then
          return(null);
    end;
    --
    procedure update_output(ERRBUF OUT VARCHAR2
                           ,RETCODE OUT NUMBER
                           ,p_file_name in varchar2
                           ,p_REQUEST_ID in number)
    is
      --PRAGMA AUTONOMOUS_TRANSACTION;
      v_directory_path varchar2(250);
    begin
       DBMS_LOCK.SLEEP (2);
       select directory_path
       into   v_directory_path
       from   dba_directories
       where  directory_name like 'XXSTN_HR_OUT';
       --
       update fnd_conc_req_outputs
       set    file_name = v_directory_path||'/'||p_file_name
       where  concurrent_request_id = p_REQUEST_ID;
       --
       COMMIT;
       --
       -- Delete the old files
       --
       begin
           for c1 in (select substr(file_name,
                                    instr(file_name, '/HR/outbound/o') + 13,
                                    25) file_name
                        from fnd_conc_req_outputs
                       where file_name like '%.xlsx'
                         and file_creation_date >= sysdate - 30
                         and file_creation_date <= sysdate - 2) loop
               begin
                   UTL_FILE.FREMOVE('XXSTN_HR_OUT', c1.file_name);
               exception
                   when others then
                       null;
               end;
           end loop;
       end;
    end;
    --
    procedure main(ERRBUF OUT VARCHAR2
                  ,RETCODE OUT NUMBER
                  ,P_ACCESS_SET_ID        in number
                  ,P_CHART_OF_ACCOUNTS_ID in NUMBER
                  ,P_LEDGER_ID            IN NUMBER
                  ,P_LEDGER_CURRENCY      IN VARCHAR2
                  ,P_START_PERIOD         IN VARCHAR2
                  ,P_END_PERIOD           IN VARCHAR2
                  ,P_START_DATE           IN VARCHAR2
                  ,P_END_DATE             IN VARCHAR2
                  ,P_START_SEGMENT1       IN VARCHAR2
                  ,P_END_SEGMENT1         IN VARCHAR2
                  ,P_START_SEGMENT2       IN VARCHAR2
                  ,P_END_SEGMENT2         IN VARCHAR2
                  ,P_START_SEGMENT3       IN VARCHAR2
                  ,P_END_SEGMENT3         IN VARCHAR2
                  ,P_START_SEGMENT4       IN VARCHAR2
                  ,P_END_SEGMENT4         IN VARCHAR2
                  ,P_START_SEGMENT5       IN VARCHAR2
                  ,P_END_SEGMENT5         IN VARCHAR2
                  ,P_START_SEGMENT6       IN VARCHAR2
                  ,P_END_SEGMENT6         IN VARCHAR2
                  ,P_START_SEGMENT7       IN VARCHAR2
                  ,P_END_SEGMENT7         IN VARCHAR2
                  ,P_START_SEGMENT8       IN VARCHAR2
                  ,P_END_SEGMENT8         IN VARCHAR2
                  )
    is
    CURSOR C_RAZAO (P_FLEX_VALUE_SET_ID4 IN NUMBER ,
                    V_START_PERIOD_NUM   IN NUMBER ,
                    V_END_PERIOD_NUM     IN NUMBER) IS
    SELECT   D.SEGMENT1                     Empresa
            ,D.SEGMENT2                     Bandeira
            ,D.SEGMENT3                     Produto
            ,D.SEGMENT4                     Conta_Contabil
            ,FV4.DESCRIPTION                Descri_Conta_Contabil
            ,D.SEGMENT5                     Centro_Custo
            ,D.SEGMENT6                     Intercompany
            ,D.SEGMENT7                     Unidade_Negocio
            ,D.SEGMENT8                     Futuro2
            ,E.DEFAULT_EFFECTIVE_DATE       Data_Contabil
            ,E.POSTED_DATE                  Data_Postada
            ,E.CURRENCY_CODE                Moeda
            ,A.DESCRIPTION                  Descri_linha
            ,F.NAME                         Journal_Batch
            ,E.NAME                         Journal_Entry
            -- INICIO LEANDRO W CAVALHEIRO (NINECON) - 11-03-2020
            -- 316534 - SR-360094 Contabilidade Projeto Informações demonstradas no Razão GL            
            --,nvl(LTRIM(SUBSTR(A.DESCRIPTION,decode(INSTR(A.DESCRIPTION,'|',-1),0,1000,INSTR(A.DESCRIPTION,'|',-1))+1)),' ')  Fornecedor
            --,nvl(LTRIM(SUBSTR(A.DESCRIPTION,decode(INSTR(A.DESCRIPTION,';',-1),0,1000,INSTR(A.DESCRIPTION,';',-1))+1)),' ')  Item
            ,CASE 
              WHEN INSTR(A.DESCRIPTION,'Fornecedor:') > 0 
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Fornecedor:')+12,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Fornecedor:')))-(INSTR(A.DESCRIPTION,'Fornecedor:')+12))
              WHEN INSTR(A.DESCRIPTION,'Fornec:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Fornec:')+8,80)
              WHEN INSTR(A.DESCRIPTION,'Arrecadador:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Arrecadador:')+13,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Arrecadador:')))-(INSTR(A.DESCRIPTION,'Arrecadador:')+13))
              WHEN INSTR(A.DESCRIPTION,'Funcion') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Funcion')+13,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Funcion')))-(INSTR(A.DESCRIPTION,'Funcion')+13))
             ELSE
               nvl(LTRIM(SUBSTR(A.DESCRIPTION,decode(INSTR(A.DESCRIPTION,'|',-1),0,1000,INSTR(A.DESCRIPTION,'|',-1))+1)),' ') 
            END Fornecedor
            -- TRATATIVA Item
            ,CASE 
              WHEN INSTR(A.DESCRIPTION,'Fornec:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'NFF:')+5,
                          (INSTR(A.DESCRIPTION,', Seq:',INSTR(A.DESCRIPTION,'NFF:')))-(INSTR(A.DESCRIPTION,'NFF:')+5)) 
              WHEN INSTR(A.DESCRIPTION,'Repetitiva:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Repetitiva:')+12,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Repetitiva:')))-(INSTR(A.DESCRIPTION,'Repetitiva:')+12))              
              WHEN INSTR(A.DESCRIPTION,'Prest.Contas:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Prest.Contas:')+15,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Prest.Contas:')))-(INSTR(A.DESCRIPTION,'Prest.Contas:')+15))
              WHEN INSTR(A.DESCRIPTION,'Nr. Adto:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Nr. Adto:')+11,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Nr. Adto:')))-(INSTR(A.DESCRIPTION,'Nr. Adto:')+11))
              WHEN INSTR(A.DESCRIPTION,'Nr Revers') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Nr Revers')+13,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Nr Revers')))-(INSTR(A.DESCRIPTION,'Nr Revers')+13))
              WHEN INSTR(A.DESCRIPTION,'Nr da NFF:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'Nr da NFF:')+11,
                          (INSTR(A.DESCRIPTION,'|',INSTR(A.DESCRIPTION,'Nr da NFF:')))-(INSTR(A.DESCRIPTION,'Nr da NFF:')+11))
              WHEN INSTR(A.DESCRIPTION,'NFF nr:') > 0
               THEN substr(A.DESCRIPTION,INSTR(A.DESCRIPTION,'NFF nr:')+8,(INSTR(A.DESCRIPTION,'|'
                    ,INSTR(A.DESCRIPTION,'NFF nr:')))-(INSTR(A.DESCRIPTION,'NFF nr:')+8))
             ELSE
              nvl(LTRIM(SUBSTR(A.DESCRIPTION,decode(INSTR(A.DESCRIPTION,';',-1),0,1000,INSTR(A.DESCRIPTION,';',-1))+1)),' ')
            END Item 
            -- FIM LEANDRO W CAVALHEIRO (NINECON) - 11-03-2020            
            ,A.PERIOD_NAME                  Mes
            ,AC.USER_NAME                   Criado_Por
            ,A.JE_LINE_NUM                  Num_Lin
            ,DECODE(E.STATUS,'P',AU.USER_NAME
                            ,'U','')        Postado_Por
            ,A.ENTERED_DR                   Total_Debito                 --VALOR A DEBITO
            ,A.ENTERED_CR                   Total_Credito                --VALOR A CREDITO
            ,A.ACCOUNTED_DR                 Total_Debito_Conv
            ,A.ACCOUNTED_CR                 Total_Credito_Conv
    FROM APPS.GL_JE_LINES A                     --TABELA DAS LINHAS CONTABEIS
        ,APPS.GL_CODE_COMBINATIONS D            --TABELA DAS COMBINACOES CONTABEIS
        ,APPS.GL_JE_HEADERS E                   --TABELA DOS LANCAMENTOS CONTABEIS
        ,APPS.GL_JE_BATCHES F                   --TABELA DOS LOTES CONTABEIS
        ,APPS.FND_USER      AC                  --TABELA DE USUARIOS
        ,APPS.FND_USER      AU                  --TABELA DE USUARIOS
        ,APPS.GL_PERIOD_STATUSES GPS
        ,APPS.FND_FLEX_VALUES_VL FV4            --TABELA DA DESCRICAO DAS CONTAS

    WHERE 1=1
    AND A.CODE_COMBINATION_ID = D.CODE_COMBINATION_ID
    AND A.JE_HEADER_ID        = E.JE_HEADER_ID
    AND E.JE_BATCH_ID         = F.JE_BATCH_ID
    AND A.CREATED_BY          = AC.USER_ID(+)
    AND A.PERIOD_NAME         = GPS.PERIOD_NAME
    AND E.LEDGER_ID           = GPS.LEDGER_ID
    AND GPS.application_id    = 101
    AND A.LAST_UPDATED_BY     = AU.USER_ID(+)
    AND FV4.FLEX_VALUE        = D.SEGMENT4
    AND FV4.FLEX_VALUE_SET_ID = P_FLEX_VALUE_SET_ID4
    AND E.LEDGER_ID           = P_LEDGER_ID --'2024'
    --AND E.JE_SOURCE = '2'
    AND E.STATUS              = 'P'                          --POSTED/UNPOSTED JOURNALS
    AND GPS.effective_period_num >= V_START_PERIOD_NUM                --PERIOD
    AND GPS.effective_period_num <= V_END_PERIOD_NUM
    AND E.DEFAULT_EFFECTIVE_DATE >= NVL(TO_DATE(P_START_DATE,'YYYY/MM/DD HH24:MI:SS'),E.DEFAULT_EFFECTIVE_DATE)
    AND E.DEFAULT_EFFECTIVE_DATE <= NVL(TO_DATE(P_END_DATE  ,'YYYY/MM/DD HH24:MI:SS'),E.DEFAULT_EFFECTIVE_DATE)
    AND D.SEGMENT1  = NVL(P_START_SEGMENT1,D.SEGMENT1)
    --AND D.SEGMENT1 <= NVL(P_END_SEGMENT1  ,D.SEGMENT1)
    AND D.SEGMENT2 >= NVL(P_START_SEGMENT2,D.SEGMENT2)
    AND D.SEGMENT2 <= NVL(P_END_SEGMENT2  ,D.SEGMENT2)
    AND D.SEGMENT3 >= NVL(P_START_SEGMENT3,D.SEGMENT3)
    AND D.SEGMENT3 <= NVL(P_END_SEGMENT3  ,D.SEGMENT3)
    AND D.SEGMENT4 >= NVL(P_START_SEGMENT4,D.SEGMENT4)
    AND D.SEGMENT4 <= NVL(P_END_SEGMENT4  ,D.SEGMENT4)
    AND D.SEGMENT5 >= NVL(P_START_SEGMENT5,D.SEGMENT5)
    AND D.SEGMENT5 <= NVL(P_END_SEGMENT5  ,D.SEGMENT5)
    AND D.SEGMENT6 >= NVL(P_START_SEGMENT6,D.SEGMENT6)
    AND D.SEGMENT6 <= NVL(P_END_SEGMENT6  ,D.SEGMENT6)
    AND D.SEGMENT7 >= NVL(P_START_SEGMENT7,D.SEGMENT7)
    AND D.SEGMENT7 <= NVL(P_END_SEGMENT7  ,D.SEGMENT7)
    AND D.SEGMENT8 >= NVL(P_START_SEGMENT8,D.SEGMENT8)
    AND D.SEGMENT8 <= NVL(P_END_SEGMENT8  ,D.SEGMENT8)
    ORDER BY D.SEGMENT4,E.DEFAULT_EFFECTIVE_DATE;
    --
    V_ID_FLEX_NUM         NUMBER;
    V_FLEX_VALUE_SET_ID4  NUMBER;
    V_START_PERIOD_NUM    NUMBER;
    V_END_PERIOD_NUM      NUMBER;
    --
    l_user_name           VARCHAR2(40) := fnd_profile.value('USERNAME');
    --
    l_concat              VARCHAR2(5) := '';--'Ã?Â ';
    l_count               NUMBER      := 0;
    v_lin                 NUMBER      := 1 ;
    v_file_name           VARCHAR2(250);
    v_directory_path      VARCHAR2(250);
    l_nRequest_Id         NUMBER;
    --
    v_fornecedor          VARCHAR2(400);
    --
    lv_conta_contabil     apps.gl_code_combinations.segment4%type;
    vn_initial_balance    NUMBER;
    --
    begin
       V_ID_FLEX_NUM        := P_CHART_OF_ACCOUNTS_ID;
       V_FLEX_VALUE_SET_ID4 := GET_FLEX_VALUE_SET_ID(V_ID_FLEX_NUM,4);
       --
       V_START_PERIOD_NUM   := get_period_num(P_START_PERIOD,P_LEDGER_ID);
       V_END_PERIOD_NUM     := get_period_num(P_END_PERIOD,P_LEDGER_ID);
       --
       write_log(gv_debug_flag, ' Started Stone Razao');
       write_log(gv_debug_flag, ' Getting Description Segments');

       print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
       print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
       print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
       print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
       print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
       --
       as_xlsx.clear_workbook;
       as_xlsx.new_sheet('Relatorio');
       as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'F6F287' ) ) ;
       as_xlsx.cell( 1, 1, 'Empresa');
       as_xlsx.cell( 2, 1, 'Bandeira');
       as_xlsx.cell( 3, 1, 'Produto');
       as_xlsx.cell( 4, 1, 'Conta Contabil');
       as_xlsx.cell( 5, 1, 'Descri Conta Contabil');
       as_xlsx.cell( 6, 1, 'Centro Custo');
       as_xlsx.cell( 7, 1, 'Intercompany');
       as_xlsx.cell( 8, 1, 'Unidade Negocio');
       as_xlsx.cell( 9, 1, 'Futuro2');
       as_xlsx.cell(10, 1, 'Data Contabil');
       as_xlsx.cell(11, 1, 'Data Postada');
       as_xlsx.cell(12, 1, 'Moeda');
       as_xlsx.cell(13, 1, 'Descri Linha');
       as_xlsx.cell(14, 1, 'Journal Batch');
       as_xlsx.cell(15, 1, 'Journal Entry');
       as_xlsx.cell(16, 1, 'Fornecedor');
       as_xlsx.cell(17, 1, 'Item');
       as_xlsx.cell(18, 1, 'Mes');
       as_xlsx.cell(19, 1, 'Criado Por');
       as_xlsx.cell(20, 1, 'Num Lin');
       as_xlsx.cell(21, 1, 'Postado Por');
       as_xlsx.cell(22, 1, 'Saldo Inicial');
       as_xlsx.cell(23, 1, 'Total Debito');
       as_xlsx.cell(24, 1, 'Total Credito');
       as_xlsx.cell(25, 1, 'Total Debito Conv');
       as_xlsx.cell(26, 1, 'Total Credito Conv');
       as_xlsx.cell(27, 1, 'Saldo Final');
--       as_xlsx.cell(28, 1,
--       as_xlsx.cell(29, 1,
--       as_xlsx.cell(30, 1,
--       as_xlsx.cell(31, 1,
--       as_xlsx.cell(32, 1,
       FOR r_razao IN c_razao(V_FLEX_VALUE_SET_ID4,
                              V_START_PERIOD_NUM,
                              V_END_PERIOD_NUM  )
       LOOP
          v_lin := v_lin + 1;
          --
          IF NVL(lv_conta_contabil,'"!@#$%Â¨&') <> r_razao.Conta_Contabil THEN
             write_log(gv_debug_flag,'P_START_DATE '||P_START_DATE);
             vn_initial_balance := GET_INITIAL_BALANCE(r_razao.Conta_Contabil,
                                                       P_START_PERIOD,
                                                       TO_DATE(P_START_DATE,'YYYY/MM/DD HH24:MI:SS'),
                                                       P_LEDGER_ID,
                                                       P_LEDGER_CURRENCY,
                                                       P_START_SEGMENT1,
                                                       P_END_SEGMENT1  ,
                                                       P_START_SEGMENT2,
                                                       P_END_SEGMENT2  ,
                                                       P_START_SEGMENT3,
                                                       P_END_SEGMENT3  ,
                                                       P_START_SEGMENT5,
                                                       P_END_SEGMENT5  ,
                                                       P_START_SEGMENT6,
                                                       P_END_SEGMENT6  ,
                                                       P_START_SEGMENT7,
                                                       P_END_SEGMENT7  ,
                                                       P_START_SEGMENT8,
                                                       P_END_SEGMENT8  );
             --
             lv_conta_contabil := r_razao.Conta_Contabil;
             --
             --as_xlsx.cell( 4,v_lin,  special_character(r_razao.Conta_Contabil) );
             --as_xlsx.cell( 5,v_lin,  special_character(r_razao.Descri_Conta_Contabil) );
             --as_xlsx.cell(13,v_lin, 'Saldo Inicial '||lv_conta_contabil);
             as_xlsx.cell(22,v_lin, vn_initial_balance           );
             --
             --v_lin := v_lin + 1;
          END IF;
          --
          IF SUBSTR(r_razao.Journal_Entry,1,3) = 'REC' THEN
             v_fornecedor := NVL(STN_RET_STR(r_razao.Descri_linha,3,'-'),' ');
          ELSE
             v_fornecedor := NVL(r_razao.Fornecedor,' ');
          END IF;     
          --
          -- INICIO ROGERIO FARTO (NINECON) - 391718 NSD307714

          -- vn_initial_balance := nvl(vn_initial_balance,0) + nvl(r_razao.Total_Debito,0) - nvl(r_razao.Total_Credito,0);
          vn_initial_balance := nvl(vn_initial_balance,0) + nvl(r_razao.Total_Debito_Conv,0) - nvl(r_razao.Total_Credito_Conv,0);

          -- FIM ROGERIO FARTO (NINECON) - 391718 NSD307714
          --
          as_xlsx.cell( 1,v_lin, special_character(r_razao.Empresa)        );
          as_xlsx.cell( 2,v_lin, special_character(r_razao.Bandeira)       );
          as_xlsx.cell( 3,v_lin, special_character(r_razao.Produto)        );
          as_xlsx.cell( 4,v_lin, special_character(r_razao.Conta_Contabil) );
          as_xlsx.cell( 5,v_lin, special_character(r_razao.Descri_Conta_Contabil)    );
          as_xlsx.cell( 6,v_lin, special_character(r_razao.Centro_Custo)   );
          as_xlsx.cell( 7,v_lin, special_character(r_razao.Intercompany)   );
          as_xlsx.cell( 8,v_lin, special_character(r_razao.Unidade_Negocio));
          as_xlsx.cell( 9,v_lin, special_character(r_razao.Futuro2)        );
          as_xlsx.cell(10,v_lin, special_character(r_razao.Data_Contabil)  );
          as_xlsx.cell(11,v_lin, special_character(r_razao.Data_Postada)   );
          as_xlsx.cell(12,v_lin, special_character(r_razao.Moeda)          );
          as_xlsx.cell(13,v_lin, special_character(r_razao.Descri_linha)   );
          as_xlsx.cell(14,v_lin, special_character(r_razao.Journal_Batch)  );
          as_xlsx.cell(15,v_lin, special_character(r_razao.Journal_Entry)  );
          as_xlsx.cell(16,v_lin, v_fornecedor               );
          as_xlsx.cell(17,v_lin, r_razao.Item               );
          as_xlsx.cell(18,v_lin, special_character(r_razao.Mes)            );
          as_xlsx.cell(19,v_lin, special_character(r_razao.Criado_Por)     );
          as_xlsx.cell(20,v_lin, special_character(r_razao.Num_Lin)        );
          as_xlsx.cell(21,v_lin, special_character(r_razao.Postado_Por)    );
          as_xlsx.cell(23,v_lin, r_razao.Total_Debito             );
          as_xlsx.cell(24,v_lin, r_razao.Total_Credito            );
          as_xlsx.cell(25,v_lin, r_razao.Total_Debito_Conv        );
          as_xlsx.cell(26,v_lin, r_razao.Total_Credito_Conv       );
          as_xlsx.cell(27,v_lin, vn_initial_balance               );
          --
          l_count := l_count + 1;
       end loop;
       --
       write_log(gv_debug_flag, ' Lines : '||l_count);
       --
       as_xlsx.freeze_rows( 1 );
       v_file_name := 'o'||FND_GLOBAL.CONC_REQUEST_ID||'.xlsx';
       --
       as_xlsx.new_sheet('Parametros');
       as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ) ) ;
       as_xlsx.cell(1 , 1 ,'Parametros');
       as_xlsx.cell(2 , 1 ,'De');
       as_xlsx.cell(3 , 1 ,'Ate');
       as_xlsx.cell(1 , 2 ,'Currency')   ;
       as_xlsx.cell(1 , 3 ,'Periood Name') ;
       as_xlsx.cell(1 , 4 ,'Date');
       as_xlsx.cell(1 , 5 ,'Empresa');
       as_xlsx.cell(1 , 6 ,'Bandeira');
       as_xlsx.cell(1 , 7 ,'Produto');
       as_xlsx.cell(1 , 8 ,'Conta Contabil');
       as_xlsx.cell(1 , 9 ,'Centro Custo');
       as_xlsx.cell(1 ,10 ,'Intercompany');
       as_xlsx.cell(1 ,11 ,'Unidade Negocio');
       as_xlsx.cell(1 ,12 ,'Futuro2');
       --
       as_xlsx.cell(2 , 2 ,nvl(P_LEDGER_CURRENCY,' '));
       as_xlsx.cell(2 , 3 ,nvl(P_START_PERIOD,' '));
       as_xlsx.cell(3 , 3 ,nvl(P_END_PERIOD,' '));
       as_xlsx.cell(2 , 4 ,nvl(P_START_DATE,' '));
       as_xlsx.cell(3 , 4 ,nvl(P_END_DATE,' '));
       as_xlsx.cell(2 , 5 ,nvl(P_START_SEGMENT1,' '));
       --as_xlsx.cell(3 , 5 ,nvl(P_END_SEGMENT1,' '));
       as_xlsx.cell(2 , 6 ,nvl(P_START_SEGMENT2,' '));
       as_xlsx.cell(3 , 6 ,nvl(P_END_SEGMENT2,' '));
       as_xlsx.cell(2 , 7 ,nvl(P_START_SEGMENT3,' '));
       as_xlsx.cell(3 , 7 ,nvl(P_END_SEGMENT3,' '));
       as_xlsx.cell(2 , 8 ,nvl(P_START_SEGMENT4,' '));
       as_xlsx.cell(3 , 8 ,nvl(P_END_SEGMENT4,' '));
       as_xlsx.cell(2 , 9 ,nvl(P_START_SEGMENT5,' '));
       as_xlsx.cell(3 , 9 ,nvl(P_END_SEGMENT5,' '));
       as_xlsx.cell(2 ,10 ,nvl(P_START_SEGMENT6,' '));
       as_xlsx.cell(3 ,10 ,nvl(P_END_SEGMENT6,' '));
       as_xlsx.cell(2 ,11 ,nvl(P_START_SEGMENT7,' '));
       as_xlsx.cell(3 ,11 ,nvl(P_END_SEGMENT7,' '));
       as_xlsx.cell(2 ,12 ,nvl(P_START_SEGMENT8,' '));
       as_xlsx.cell(3 ,12 ,nvl(P_END_SEGMENT8,' '));
       --
       as_xlsx.mergecells( 5, 12 ,9, 12 );
       as_xlsx.cell(5 , 12 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS')
                           , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
       --
       write_log(gv_debug_flag, ' Saving the excel file ');
       as_xlsx.save( 'XXSTN_HR_OUT', v_file_name );
       write_log(gv_debug_flag, ' Ended Stone Razao REPORT ');
       --
       l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                  , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                  , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                  , argument1   => v_file_name
                                                  , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
    end;
END XXSTN_GL_RAZAO_REPORT2_PKG;
/

EXIT;