  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_ADECUENTAS_INT_PKG" AS

g_batch_source_nd VARCHAR2(50);
g_batch_source_nc VARCHAR2(50);
g_memo_line VARCHAR2(50);
g_term_id NUMBER;
g_collector_id NUMBER;

PROCEDURE  main_process (retcode          OUT VARCHAR2
                        ,errbuf           OUT VARCHAR2
                        ,p_batch_source_id IN NUMBER
                        ,p_collector_id    IN NUMBER);

PROCEDURE trx_out_int (retcode    OUT VARCHAR2
                      ,errbuf     OUT VARCHAR2
                      ,p_path     IN  VARCHAR2
                      ,p_customer_class_code IN VARCHAR2);

PROCEDURE customer_out_int (retcode    OUT VARCHAR2
                           ,errbuf     OUT VARCHAR2
                           ,p_path     IN  VARCHAR2
                           ,p_customer_class_code IN VARCHAR2);

PROCEDURE BATCH_CONFIRM_OUT_INT (retcode    OUT VARCHAR2
                                ,errbuf     OUT VARCHAR2
                                ,p_path     IN  VARCHAR2);

PROCEDURE get_receipt_info (retcode    OUT VARCHAR2
                           ,errbuf     OUT VARCHAR2
                           ,p_path     IN  VARCHAR2
                           ,p_filename IN  VARCHAR2);
END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_ADECUENTAS_INT_PKG" AS


PROCEDURE trx_out_int (retcode    OUT VARCHAR2
                      ,errbuf     OUT VARCHAR2
                      ,p_path     IN  VARCHAR2
                      ,p_customer_class_code IN VARCHAR2
                      --,p_batch_source_id IN NUMBER
                       ) IS

v_count NUMBER;
v_sign VARCHAr2(1);
v_sign1 VARCHAr2(1);
v_sign2 VARCHAr2(1);

e_cust_exception EXCEPTION;
v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);

v_file_type utl_file.file_type;
v_line VARCHAR2(2000);
v_org_code VARCHAR2(80);

CURSOR c_trx IS
select hl.global_attribute11||hl.global_attribute12 org_cuit
      ,hp.party_id
      ,hp.party_name
      ,apsa.payment_schedule_id
      ,rcta.customer_trx_id
      ,rcta.trx_date
      ,rcta.invoice_currency_code
      ,(select sum(extended_amount) from ra_customer_trx_lines_all rctla where rctla.customer_trx_id = rcta.customer_trx_id) extended_amount
      ,apsa.due_date
      ,rt.term_id
      ,rt.name term_name
      ,rcta.trx_number
      ,hca.sales_channel_code
      ,rcta.comments
      ,apsa.amount_due_remaining
      ,apsa.amount_due_original
      ,rctta.cust_trx_type_id
      ,rctta_dfv.xx_ar_clase_doc_adecuentas
      ,hca.customer_class_code
  from ra_customer_trx_all rcta
      ,ar_payment_schedules_all apsa
      ,hr_all_organization_units haou
      ,hr_locations hl
      ,hz_parties hp
      ,hz_cust_accounts hca
      ,ra_cust_trx_types_all rctta
      ,ra_cust_trx_types_all_dfv rctta_dfv
      ,ra_terms rt
      ,hz_cust_acct_sites_all hcas
      ,hz_cust_site_uses_all hcsu
      ,hz_party_sites hps
      ,ra_salesreps_all rsa
where rcta.org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'))
   and rcta.org_id = haou.organization_id
   and haou.location_id = hl.location_id
   and rcta.customer_trx_id = apsa.customer_trx_id
   and rcta.org_id = apsa.org_id
   and rcta.cust_trx_type_id = rctta.cust_trx_type_id
   and nvl(rcta.term_id,1000) = rt.term_id
   and apsa.amount_due_remaining != 0
   and hp.party_id = hca.party_id
   and hca.cust_account_id = rcta.bill_to_customer_id
   and hca.cust_account_id = hcas.cust_account_id
   and hcas.party_site_id = hps.party_site_id
   and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
   and hcsu.primary_salesrep_id = rsa.salesrep_id(+)
   and rctta.rowid = rctta_dfv.row_id
   and rctta_dfv.xx_ar_clase_doc_adecuentas is not null
   and hcsu.site_use_code = 'BILL_TO'
   and hcsu.primary_flag = 'Y'
   and hcas.org_id = rcta.org_id
   order by 3,4,5;

CURSOR c_rec IS
select  hl.global_attribute11||hl.global_attribute12 org_cuit
       ,hp.party_id
       ,hp.party_name
       ,apsa.payment_schedule_id
       ,acr.cash_receipt_id -- rcta.customer_trx_id
       ,acr.receipt_date --rcta.trx_date
       ,acr.currency_code  --rcta.invoice_currency_code
       ,acr.amount --extended_amount
       ,apsa.due_date --que fecha ponemos
       --,rt.term_id null
       ,'Pago a Cuenta' term_name
       ,ab.name||'-'||acr.receipt_number trx_number --rcta.trx_number
       ,hca.sales_channel_code
       ,acr.comments --rcta.comments
       ,apsa.amount_due_remaining amount_due_remaining
       ,apsa.amount_due_original amount_due_original
       ,acr.receipt_method_id cust_trx_type_id
       ,'PAG' xx_ar_clase_doc_adecuentas
       ,hca.customer_class_code
from    ar_cash_receipts acr
       ,ar_batches ab
       ,ar_cash_receipt_history acrh
       ,ar_payment_schedules_all apsa
       ,hz_cust_site_uses_all hcsu
       ,hz_cust_acct_sites_all hcas
       ,hz_cust_accounts hca
       ,hz_parties hp
       ,hr_locations hl
       ,hr_all_organization_units haou
where   acr.type = 'CASH'
and     acr.receipt_date > sysdate-10
and     acr.creation_date > sysdate-10
and     acr.reversal_date is null --ver si revierten
and     acr.cash_receipt_id = acrh.cash_receipt_id
and     acrh.batch_id = ab.batch_id
and     acrh.first_posted_record_flag = 'Y'
--and     ab.batch_source_id = 1671 --p_batch_source_id
and     acr.cash_receipt_id = apsa.cash_receipt_id
and     acr.customer_site_use_id = hcsu.site_use_id
and     hcsu.cust_acct_site_id = hcas.cust_acct_site_id
and     hcas.cust_account_id = hca.cust_account_id
and     hca.party_id = hp.party_id
and     acr.org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'))
and     acr.org_id = haou.organization_id
and     haou.location_id = hl.location_id
and     apsa.amount_due_remaining != 0
and     hca.customer_class_code = NVL(p_customer_class_code,hca.customer_class_code)
order by 3,4,5;

BEGIN


   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.TRX_OUT_INT (+)');

   v_count := 0;
   
   begin
    select  meaning
    into    v_org_code
    from    fnd_lookups
    where   lookup_type ='XX_AR_ADECUENTAS_OU'
    and     lookup_code = to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')))
    and     trunc(sysdate) between nvl(start_date_active,trunc(sysdate)) and nvl(end_date_active,trunc(sysdate));
    
   exception
   when others then
    fnd_file.put_line(fnd_file.log,'Error al obtener el codigo de la empresa en lookup XX_AR_ADECUENTAS_OU para org_id: '||to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')))
                    ||'. Error: '||sqlerrm);
   end;

   --v_file_type := utl_file.fopen(p_path,'SDD_Deuda'||TO_CHAR(SYSDATE,'YYYYMMDD')||'.txt', 'W');
   v_file_type := utl_file.fopen(p_path,v_org_code||'_SDD_Deuda'||TO_CHAR(SYSDATE,'YYYYMMDD')||'.txt', 'W');


   UTL_FILE.PUT_LINE(v_file_type,'1'||TO_CHAR(SYSDATE,'YYYYMMDD'));

   fnd_file.put_line (fnd_file.output,RPAD('Cliente:',60,' ')||'  '||RPAD('Clase',5,' ')||'  '||RPAD('Nro Trans',15,' ')||'  '||RPAD('Monto Cuota',15,' ')||'  '||RPAD('Detalles',120,' '));
   fnd_file.put_line (fnd_file.output,RPAD('-',60,'-')||'  '||RPAD('-',5,'-')||'  '||RPAD('-',15,'-')||'  '||RPAD('-',15,'-')||'  '||RPAD('-',120,'-'));

   FOR r_trx In c_trx LOOP

    BEGIN

        IF NVL(r_trx.customer_class_code,'*') != p_customer_class_code THEN
            v_status := 'W';
            v_error_message := 'El Cliente '||r_trx.party_name||' No tiene clase de Cliente '||p_customer_class_code||' este cliente no se ha informado en la interfaz';
            RAISE e_cust_exception;
        END IF;

        if r_trx.extended_amount < 0 THEN
        v_sign := '-';
        else
        v_sign := '0';
        end if;

        if r_trx.amount_due_remaining < 0 THEN
        v_sign1 := '-';
        else
        v_sign1 := '0';
        end if;

        if r_trx.amount_due_original < 0 THEN
        v_sign2 := '-';
        else
        v_sign2 := '0';
        end if;

        v_line := '2'
                ||RPAD(NVL(r_trx.org_cuit,' '),11,' ')
                ||LPAD(TO_CHAR(r_trx.party_id),11,'0')
                ||LPAD(TO_CHAR(r_trx.payment_schedule_id),15,'0')
                ||RPAD(to_char(r_trx.trx_date,'YYYYMMDD'),10,' ')
                ||r_trx.invoice_currency_code
                ||RPAD(NVL(r_trx.xx_ar_clase_doc_adecuentas,'  '),5,' ')
                ||v_sign||LPAD(trim(to_char(round(r_trx.extended_amount,2),'999999999999999.90')),19,'0')
                ||RPAD(to_char(r_trx.due_date,'YYYYMMDD'),10,' ')
                ||RPAD(r_trx.term_name,15,' ')
                ||RPAD(TO_CHAR(r_trx.customer_trx_id),10,' ')
                ||RPAD(r_trx.trx_number,20,' ')
                ||v_sign1||LPAD(trim(to_char(round(r_trx.amount_due_remaining,2),'999999999999999.90')),19,'0')
                ||v_sign2||LPAD(trim(to_char(round(r_trx.amount_due_original,2),'999999999999999.90')),19,'0')
                ||RPAD(TO_CHAR(r_trx.cust_trx_type_id),15,' ');


         UTL_FILE.PUT_LINE(v_file_type,v_line);

         fnd_file.put_line (fnd_file.output,RPAD(r_trx.party_name,60,' ')||'  '||RPAD(r_trx.xx_ar_clase_doc_adecuentas,5,' ')||'  '||RPAD(r_trx.trx_number,15,' ')||'  '||RPAD(r_trx.amount_due_remaining,15,' ')||'  '||'Procesado');

         v_count := v_count + 1;

    EXCEPTION
     WHEN e_cust_exception THEN
        fnd_file.put_line (fnd_file.output,RPAD(r_trx.party_name,60,' ')||'  '||RPAD(r_trx.xx_ar_clase_doc_adecuentas,5,' ')||'  '||RPAD(r_trx.trx_number,15,' ')||'  '||RPAD(r_trx.amount_due_remaining,15,' ')||'  '||'NO TIENE CLASE DE CLIENTE '||p_customer_class_code||' NO SE HA INFORMADO EN LA INTERFAZ');
    END;

   END LOOP;
   
   --Agregado KHRONUS/MNazarre 20200309: Se agrega los recibos "Pago a Cuenta" recibos con saldo a ser enviados a Adecuentas
   FOR r_rec In c_rec LOOP

    BEGIN

        IF NVL(r_rec.customer_class_code,'*') != p_customer_class_code THEN
            v_status := 'W';
            v_error_message := 'El Cliente '||r_rec.party_name||' No tiene clase de Cliente '||p_customer_class_code||' este cliente no se ha informado en la interfaz';
            RAISE e_cust_exception;
        END IF;

        if r_rec.amount < 0 THEN
        v_sign := '-';
        else
        v_sign := '0';
        end if;

        if r_rec.amount_due_remaining < 0 THEN
        v_sign1 := '-';
        else
        v_sign1 := '0';
        end if;

        if r_rec.amount_due_original < 0 THEN
        v_sign2 := '-';
        else
        v_sign2 := '0';
        end if;
        

        v_line := '2'
                ||RPAD(NVL(r_rec.org_cuit,' '),11,' ')
                ||LPAD(TO_CHAR(r_rec.party_id),11,'0')
                ||LPAD(TO_CHAR(r_rec.payment_schedule_id),15,'0')
                ||RPAD(to_char(r_rec.receipt_date,'YYYYMMDD'),10,' ')
                ||r_rec.currency_code
                ||RPAD(NVL(r_rec.xx_ar_clase_doc_adecuentas,'  '),5,' ')
                --||v_sign||LPAD(trim(to_char(round(r_rec.amount,2),'999999999999999.90')),19,'0')
                ||v_sign2||LPAD(trim(to_char(round(r_rec.amount_due_original,2),'999999999999999.90')),19,'0')
                ||RPAD(to_char(r_rec.due_date,'YYYYMMDD'),10,' ')
                ||RPAD(r_rec.term_name,15,' ')
                ||RPAD(TO_CHAR(r_rec.cash_receipt_id),10,' ')
                ||RPAD(r_rec.trx_number,20,' ')
                ||v_sign1||LPAD(trim(to_char(round(r_rec.amount_due_remaining,2),'999999999999999.90')),19,'0')
                ||v_sign2||LPAD(trim(to_char(round(r_rec.amount_due_original,2),'999999999999999.90')),19,'0')
                ||RPAD(TO_CHAR(r_rec.cust_trx_type_id),15,' ');


         UTL_FILE.PUT_LINE(v_file_type,v_line);

         fnd_file.put_line (fnd_file.output,RPAD(r_rec.party_name,60,' ')||'  '||RPAD(r_rec.xx_ar_clase_doc_adecuentas,5,' ')||'  '||RPAD(r_rec.trx_number,15,' ')||'  '||RPAD(r_rec.amount_due_remaining,15,' ')||'  '||'Procesado');

         v_count := v_count + 1;

    EXCEPTION
     WHEN e_cust_exception THEN
        fnd_file.put_line (fnd_file.output,RPAD(r_rec.party_name,60,' ')||'  '||RPAD(r_rec.xx_ar_clase_doc_adecuentas,5,' ')||'  '||RPAD(r_rec.trx_number,15,' ')||'  '||RPAD(r_rec.amount_due_remaining,15,' ')||'  '||'NO TIENE CLASE DE CLIENTE '||p_customer_class_code||' NO SE HA INFORMADO EN LA INTERFAZ');
    END;

   END LOOP;
   --Fin Agregado KHRONUS/MNazarre 20200309: 

   UTL_FILE.PUT_LINE(v_file_type,'9'||LPAD(v_count,10,'0'));

   UTL_FILE.FCLOSE(v_file_type);

   IF NVL(v_status,'S') != 'S' THEN

    retcode := 1;
    errbuf := v_error_message;

    fnd_file.put_line(fnd_file.log,errbuf);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.TRX_OUT_INT (!)');

    IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Error Seteando Estado De Finalizacion');
    ELSE
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Estado de finalizacion seteado');
    END IF;

   ELSE

   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.TRX_OUT_INT (-)');

   END IF;

EXCEPTION
  WHEN OTHERS THEN
    retcode := 2;
    errbuf := 'Error en customer_out_int. '||SQLERRM;
    fnd_file.put_line(fnd_file.log,errbuf);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.TRX_OUT_INT (!)');
    RAISE_APPLICATION_ERROR(-20000,errbuf);
END;

PROCEDURE customer_out_int (retcode    OUT VARCHAR2
                           ,errbuf     OUT VARCHAR2
                           ,p_path     IN  VARCHAR2
                           ,p_customer_class_code IN VARCHAR2) IS

v_count NUMBER;

v_file_type utl_file.file_type;
v_line VARCHAR2(2000);

CURSOR c_clients IS
select hca.customer_class_code
      ,hp.jgzz_fiscal_code||hca.global_attribute12 cuit
      ,hp.party_name
      ,hl.address1
      ,hca.sales_channel_code
      ,jrs_dfv.xx_ar_username_adecuentas salesrep_number
      ,hp.party_id
      ,hps.party_site_id
  from hz_cust_accounts hca
      ,hz_parties hp
      ,hz_cust_acct_sites_all hcas
      ,hz_cust_site_uses_all hcsu
      ,hz_party_sites hps
      ,hz_locations hl
      ,ra_salesreps_all rsa
      ,jtf_rs_salesreps jrs
      ,jtf_rs_salesreps_dfv jrs_dfv
 where hca.party_id = hp.party_id
   and hca.cust_account_id  = hcas.cust_account_id
   and hcas.party_site_id = hps.party_site_id
   and hps.party_id = hp.party_id
   and hps.location_id = hl.location_id
   and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
   and hcsu.primary_salesrep_id = rsa.salesrep_id(+)
   and hcsu.site_use_code = 'BILL_TO'
   and hcsu.primary_flag = 'Y'
   and hcas.org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'))
   and rsa.salesrep_id = jrs.salesrep_id (+)
   and jrs.rowid = jrs_dfv.row_id (+)
   and hca.customer_class_code = NVL(p_customer_class_code,hca.customer_class_code);

   v_email VARCHAR2(2000);
   e_cust_exception EXCEPTION;
   v_org_code VARCHAR2(80);

BEGIN


    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CUSTOMER_OUT_INT (+)');

    v_count := 0;

    begin
        select  meaning
        into    v_org_code
        from    fnd_lookups
        where   lookup_type ='XX_AR_ADECUENTAS_OU'
        and     lookup_code = to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')))
        and     trunc(sysdate) between nvl(start_date_active,trunc(sysdate)) and nvl(end_date_active,trunc(sysdate));
            
    exception
        when others then
        fnd_file.put_line(fnd_file.log,'Error al obtener el codigo de la empresa en lookup XX_AR_ADECUENTAS_OU para org_id: '||to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')))
                        ||'. Error: '||sqlerrm);
        raise e_cust_exception;
    end;
    

    --v_file_type := utl_file.fopen(p_path,'SDD_Clientes'||TO_CHAR(SYSDATE,'YYYYMMDD')||'.txt', 'W');
    v_file_type := utl_file.fopen(p_path,v_org_code||'_SDD_Clientes'||TO_CHAR(SYSDATE,'YYYYMMDD')||'.txt', 'W');
    
    UTL_FILE.PUT_LINE(v_file_type,'1'||TO_CHAR(SYSDATE,'YYYYMMDD'));


    fnd_file.put_line (fnd_file.output,RPAD('Cliente:',60,' ')||'  '||RPAD('Direccion',60,' ')||'  '||RPAD('Detalles',120,' '));
    fnd_file.put_line (fnd_file.output,RPAD('-',60,'-')||'  '||RPAD('-',60,'-')||'  '||RPAD('-',120,'-'));


    FOR r_clients IN c_clients LOOP

        v_email := null;

      BEGIN

        /*Obtengo el mail, en caso de mas de un email o no haber, debo informar error*/
        BEGIN

            select hcp.email_address
              into v_email
              from hz_contact_points hcp
             where hcp.contact_point_type = 'EMAIL'
             and hcp.contact_point_purpose = 'ADECUENTAS'
               and hcp.status = 'A'
               and hcp.owner_table_name = 'HZ_PARTY_SITES' and hcp.owner_table_id  = r_clients.party_site_id;

        EXCEPTION
         WHEN NO_DATA_FOUND THEN
            BEGIN

                select hcp.email_address
                  into v_email
                  from hz_contact_points hcp
                 where hcp.contact_point_type = 'EMAIL'
                 and hcp.contact_point_purpose = 'ADECUENTAS'
                   and hcp.status = 'A'
                   AND hcp.owner_table_name = 'HZ_PARTIES' and hcp.owner_table_id  = r_clients.party_id;

            EXCEPTION
             WHEN NO_DATA_FOUND THEN
                retcode := 1;
                errbuf := 'No encontro un email adecuentas para el cliente: '||r_clients.party_name||'. Direccion: '||r_clients.address1;
                 fnd_file.put_line(fnd_file.log,errbuf);--RAISE e_cust_exception;
             WHEN TOO_MANY_ROWS THEN
                retcode := 1;
                errbuf := 'Se encontro mas de un email adecuentas para el cliente: '||r_clients.party_name||'. Direccion: '||r_clients.address1;
                fnd_file.put_line(fnd_file.log,errbuf);--RAISE e_cust_exception;
             WHEN OTHERS THEN
                retcode := 1;
                errbuf := 'Error al obtener email adecuentas asociado al cliente: '||r_clients.party_name||'. Direccion: '||r_clients.address1;
                fnd_file.put_line(fnd_file.log,errbuf);--RAISE e_cust_exception;
            END;

         WHEN TOO_MANY_ROWS THEN
            retcode := 1;
            errbuf := 'Se encontro mas de un email adecuentas para el cliente: '||r_clients.party_name||'. Direccion: '||r_clients.address1;
            fnd_file.put_line(fnd_file.log,errbuf);--RAISE e_cust_exception;
         WHEN OTHERS THEN
            retcode := 1;
            errbuf := 'Error al obtener email adecuentas asociado al cliente: '||r_clients.party_name||'. Direccion: '||r_clients.address1;
            fnd_file.put_line(fnd_file.log,errbuf);--RAISE e_cust_exception;
        END;


        v_line := '2'
                ||RPAD(NVL(TO_CHAR(r_clients.party_id),' '),11,' ')
                ||RPAD(NVL(TO_CHAR(r_clients.cuit),' '),11,' ')
                ||RPAD(NVL(r_clients.party_name,' '),360,' ')
                ||RPAD(NVL(r_clients.address1,' '),100,' ')
                ||RPAD(NVL(v_email,' '),30,' ')
                ||RPAD(NVL(r_clients.sales_channel_code,' '),10,' ')
                ||RPAD(NVL(TO_CHAR(r_clients.customer_class_code),' '),30,' ')
                ||RPAD(NVL(TO_CHAR(r_clients.salesrep_number),' '),10,' ');

        UTL_FILE.PUT_LINE(v_file_type,v_line);

        fnd_file.put_line (fnd_file.output,RPAD(r_clients.party_name,60,' ')||'  '||RPAD(r_clients.address1,60,' ')||'  '||'Procesado');

        v_count := v_count +1;
        


     EXCEPTION
       WHEN e_cust_exception THEN
        fnd_file.put_line (fnd_file.output,RPAD(r_clients.party_name,60,' ')||'  '||RPAD(r_clients.address1,60,' ')||'  '||errbuf);
     END;

    END LOOP;

   UTL_FILE.PUT_LINE(v_file_type,'9'||LPAD(v_count,10,'0'));
   

   UTL_FILE.FCLOSE(v_file_type);

   IF errbuf is not null THEN

    fnd_file.put_line(fnd_file.log,errbuf);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CUSTOMER_OUT_INT (!)');

    IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Error Seteando Estado De Finalizacion');
    ELSE
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Estado de finalizacion seteado');
    END IF;

   ELSE

   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CUSTOMER_OUT_INT (-)');

   END IF;



EXCEPTION
  WHEN OTHERS THEN
    retcode := 2;
    errbuf := 'Error en customer_out_int. '||SQLERRM;
    fnd_file.put_line(fnd_file.log,errbuf);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CUSTOMER_OUT_INT (!)');
    RAISE_APPLICATION_ERROR(-20000,errbuf);
END;

PROCEDURE BATCH_CONFIRM_OUT_INT (retcode    OUT VARCHAR2
                                ,errbuf     OUT VARCHAR2
                                ,p_path     IN  VARCHAR2) IS

v_count NUMBER;
v_file_type utl_file.file_type;
v_line VARCHAR2(2000);
v_org_code VARCHAR2(80);
e_cust_exception EXCEPTION;

CURSOR c_batches IS
SELECT *
FROM bolinf.xx_ar_adec_batches
WHERE status = 'C'
AND  org_id = to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')));

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.BATCH_CONFIRM_OUT_INT (+)');

    v_count := 0;
    
    begin
        select  meaning
        into    v_org_code
        from    fnd_lookups
        where   lookup_type ='XX_AR_ADECUENTAS_OU'
        and     lookup_code = to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')))
        and     trunc(sysdate) between nvl(start_date_active,trunc(sysdate)) and nvl(end_date_active,trunc(sysdate));
            
    exception
        when others then
        fnd_file.put_line(fnd_file.log,'Error al obtener el codigo de la empresa en lookup XX_AR_ADECUENTAS_OU para org_id: '||to_char(nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')))
                        ||'. Error: '||sqlerrm);
        raise e_cust_exception;
    end;

    --v_file_type := utl_file.fopen(p_path,'SDD_RecepcionPagos'||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')||'.txt', 'W');
    v_file_type := utl_file.fopen(p_path,v_org_code||'_SDD_RecepcionPagos'||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')||'.txt', 'W');

    UTL_FILE.PUT_LINE(v_file_type,'1'||TO_CHAR(SYSDATE,'YYYYMMDD'));


    fnd_file.put_line (fnd_file.output,RPAD('Lotes Confirmado',20,' '));
    fnd_file.put_line (fnd_file.output,RPAD('-',20,'-'));

    FOR r_batch IN c_batches LOOP

        v_line := '2'
               ||RPAD(TO_CHAR(SYSDATE,'YYYYMMDD'),10,' ')
               ||RPAD(r_batch.party_id,15,' ')
               ||RPAD('C',5,' ')
               ||RPAD(r_batch.batch_name,20,' ');

        UTL_FILE.PUT_LINE(v_file_type,v_line);
        v_count := v_count + 1;
        fnd_file.put_line (fnd_file.output,RPAD(r_batch.batch_name,20,' '));

        UPDATE xx_ar_adec_batches
        SET status = 'X'
        WHERE adec_batch_id =  r_batch.adec_batch_id;

    END LOOP;

    v_line := '9' || LPAD(v_count,10,'0');

    UTL_FILE.PUT_LINE(v_file_type,v_line);

    UTL_FILE.FCLOSE(v_file_type);

   IF errbuf is not null THEN

    fnd_file.put_line(fnd_file.log,errbuf);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.BATCH_CONFIRM_OUT_INT (!)');

    IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Error Seteando Estado De Finalizacion');
    ELSE
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Estado de finalizacion seteado');
    END IF;

   ELSE

   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.BATCH_CONFIRM_OUT_INT (-)');

   END IF;

EXCEPTION
  WHEN OTHERS THEN
    retcode := 2;
    errbuf := 'Error en batch_confirm_out_int. '||SQLERRM;
    fnd_file.put_line(fnd_file.log,errbuf);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.BATCH_CONFIRM_OUT_INT (!)');
    RAISE_APPLICATION_ERROR(-20000,errbuf);
END;

FUNCTION get_applied_trx (p_cash_receipt_id IN NUMBER) RETURN VARCHAR2 IS

CURSOR c_trx IS
select rcta.trx_number
from ar_receivable_applications_all araa
,ra_customer_trx_all rcta
where araa.cash_receipt_id = p_cash_receipt_id
and araa.status = 'APP'
and araa.reversal_gl_date is null
and araa.applied_customer_trx_id = rcta.customer_trx_id;

v_trxs VARCHAR2(2000);

BEGIN

    FOR r_trx IN c_trx LOOP

        if v_trxs is not null then
        v_trxs := v_trxs||'/';
        end if;
        v_trxs := v_trxs || r_trx.trx_number;
    END LOOP;

    RETURN (v_trxs);
EXCEPTION
 WHEN OTHERS THEN
 RETURN (NULL);
END;

PROCEDURE check_batch_status (p_status IN OUT VARCHAR2
                             ,p_adec_batch_id       IN NUMBER) IS

CURSOR c_batch IS
select adec_batch_id
      ,batch_name
      ,party_id
      ,status
      ,error_message
from xx_ar_adec_batches xaab
where adec_batch_id = p_adec_batch_id
and NVL(xaab.error_message,'*') != 'Ya existe este recibo en el sistema'
and xaab.request_id = fnd_global.conc_request_id;

CURSOR c_rec (p_batch_name VARCHAR2,p_party_id NUMBER) IS
select adec_receipt_id
      ,row_type
      ,receipt_number
      ,cash_receipt_id
      ,status
      ,error_message
from xx_ar_adec_receipts xaar
where xaar.batch_name = p_batch_name
and xaar.party_id = p_party_id
and xaar.request_id = fnd_global.conc_request_id
order by adec_receipt_id;

CURSOR c_app (p_batch_name VARCHAR2,p_party_id NUMBER) IS
select xaaa.adec_application_id
      ,xaaa.trx_number
      ,xaaa.payment_schedule_id
      ,xaaa.status
      ,xaaa.error_message
      ,NVL((select receipt_number from ar_cash_receipts_all where cash_receipt_id = xaaa.TRX_APPL_ID),' ') receipts
from xx_ar_adec_applications xaaa
where xaaa.batch_name = p_batch_name
and xaaa.party_id = p_party_id
and xaaa.payment_schedule_id is not null
and xaaa.request_id = fnd_global.conc_request_id
order by adec_application_id;

v_party_name HZ_PARTIES.PARTY_NAME%TYPE;

v_error_flag NUMBER;

v_count     NUMBER;
v_count_err NUMBER;
v_count_nop NUMBER;
v_count_pro NUMBER;
v_count_ot  NUMBER;

v_count_ap     NUMBER;
v_count_err_ap NUMBER;
v_count_nop_ap NUMBER;
v_count_pro_ap NUMBER;
v_count_ot_ap  NUMBER;

v_error_message VARCHAR2(2000);

BEGIN


    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CHECK_BATCH_STATUS (+)');

    v_error_flag := 0;



    /*revisamos el lote*/
    FOR r_batch IN c_batch LOOP

        fnd_file.put_line(fnd_file.output,RPAD('Lote',10,' ')||'  '||RPAD('Cliente',30,' ')||'  '||'Estado      '||'  '||'Mensaje');
        fnd_file.put_line(fnd_file.output,RPAD('-',10,'-')||'  '||RPAD('-',30,'-')||'  '||RPAD('-',10,'-')||'  '||RPAD('-',70,'-'));


        BEGIN

            select party_name
              into v_party_name
              from hz_parties hp
             where party_id = r_batch.party_id;

        EXCEPTION
         WHEN OTHERS THEN
         v_party_name := '(Error al obtener cliente)';
        END;

        fnd_file.put_line(fnd_file.output,RPAD(r_batch.batch_name,10,' ')||'  '||RPAD(v_party_name,30,' ')||'  '||RPAD(r_batch.status,10,' ')||'  '||RPAD(r_batch.error_message,70,' '));

        v_count := 0;
        v_count_err := 0;
        v_count_nop := 0;
        v_count_pro := 0;
        v_count_ot  := 0;

        fnd_file.put_line(fnd_file.output,'');
        fnd_file.put_line(fnd_file.output,'Recibos'||'  '||RPAD('Tipo',10,' ')||'  '||RPAD('Numero',15,' ')||'  '||RPAD('Estado',11,' ')||'  '||RPAD('Mensaje/Aplicaciones',70,' '));
        fnd_file.put_line(fnd_file.output,'-------'||'  '||RPAD('-',10,'-')||'  '||RPAD('-',15,'-')||'  '||RPAD('-',11,'-')||'  '||RPAD('-',70,'-'));

        /*revisamos los recibos*/
        FOR r_rec IN c_rec (r_batch.batch_name,r_batch.party_id) LOOP

            v_count := v_count + 1;

            IF r_rec.status = 'E' THEN
                v_count_err := v_count_err + 1;
                fnd_file.put_line(fnd_file.output,'       '||'  '||RPAD(r_rec.row_type,10,' ')||'  '||RPAD(NVL(r_rec.receipt_number,'(vacio)'),15,' ')||'  '||RPAD('Error',11,' ')||'  '||RPAD(r_rec.error_message,120,' '));
            ELSIF r_rec.status = 'P' THEN

                IF r_rec.row_type IN ('REC','AWT','DEB') THEN
                    v_count_nop := v_count_nop + 1;
                    fnd_file.put_line(fnd_file.output,'       '||'  '||RPAD(r_rec.row_type,10,' ')||'  '||RPAD(NVL(r_rec.receipt_number,'(vacio)'),15,' ')||'  '||RPAD('No Aplicado',11,' ')||'  '||RPAD(r_rec.error_message,120,' '));--'Este Recibo no se ha aplicado correctamente');
                ELSE
                    update xx_ar_adec_receipts
                       set status = 'S'
                          ,last_update_date = sysdate
                          ,last_updated_by = fnd_global.user_id
                     where adec_receipt_id = r_rec.adec_receipt_id;
                    COMMIT;
                    v_count_pro := v_count_pro + 1;
                    fnd_file.put_line(fnd_file.output,'       '||'  '||RPAD(r_rec.row_type,10,' ')||'  '||RPAD(NVL(r_rec.receipt_number,'(vacio)'),15,' ')||'  '||RPAD('Procesado',11,' ')||'  '||get_applied_trx(r_rec.cash_receipt_id));
                END IF;

            ELSIF r_rec.status = 'S' THEN
                v_count_pro := v_count_pro + 1;
                fnd_file.put_line(fnd_file.output,'       '||'  '||RPAD(r_rec.row_type,10,' ')||'  '||RPAD(NVL(r_rec.receipt_number,'(vacio)'),15,' ')||'  '||RPAD('Procesado',11,' ')||'  '||get_applied_trx(r_rec.cash_receipt_id));
            ELSE
                v_count_ot := v_count_ot + 1;
                fnd_file.put_line(fnd_file.output,'       '||'  '||RPAD(r_rec.row_type,10,' ')||'  '||RPAD(NVL(r_rec.receipt_number,'(vacio)'),15,' ')||'  '||RPAD('Otros',11,' ')||'  '||'Estado: '||r_rec.status);
            END IF;

        END LOOP;

        IF v_count != v_count_pro THEN
          v_error_flag := 1;
        END IF;

        v_count_ap := 0;
        v_count_err_ap := 0;
        v_count_pro_ap := 0;
        v_count_ot_ap  := 0;


        fnd_file.put_line(fnd_file.output,'');
        fnd_file.put_line(fnd_file.output,'Aplicaciones'||'  '||RPAD('Transaccion',15,' ')||'  '||RPAD('Recibo',15,' ')||'  '||RPAD('Estado',11,' ')||'  '||RPAD('Mensaje',70,' '));
        fnd_file.put_line(fnd_file.output,'------------'||'  '||RPAD('-',15,'-')||'  '||RPAD('-',15,'-')||'  '||RPAD('-',11,'-')||'  '||RPAD('-',70,'-'));

        /*revisamos las aplicaciones*/
        FOR r_app IN c_app (r_batch.batch_name,r_batch.party_id) LOOP

            v_count_ap := v_count_ap + 1;
            IF r_app.status = 'E' THEN
               v_count_err_ap := v_count_err_ap + 1;
               fnd_file.put_line(fnd_file.output,'            '||'  '||RPAD(r_app.trx_number,15,' ')||'  '||RPAD(r_app.receipts,15,' ')||'  '||RPAD('Error',11,' ')||'  '||RPAD(r_app.error_message,70,' '));
            ELSIF r_app.status = 'S' THEN
               v_count_pro_ap := v_count_pro_ap + 1;
               fnd_file.put_line(fnd_file.output,'            '||'  '||RPAD(r_app.trx_number,15,' ')||'  '||RPAD(r_app.receipts,15,' ')||'  '||RPAD('Procesado',11,' '));
            ELSIF r_app.status = 'P' AND r_app.payment_schedule_id IS NULL THEN
                update xx_ar_adec_applications
                   set status = 'S'
                      ,last_update_date = sysdate
                      ,last_updated_by = fnd_global.user_id
                 where ADEC_APPLICATION_ID = r_app.ADEC_APPLICATION_ID;
                COMMIT;
                v_count_pro_ap := v_count_pro_ap + 1;
                fnd_file.put_line(fnd_file.output,'            '||'  '||RPAD(r_app.trx_number,15,' ')||'  '||RPAD(r_app.receipts,15,' ')||'  '||RPAD('Procesado',11,' '));
            ELSE
               v_count_ot_ap  := v_count_ot_ap  + 1;
               fnd_file.put_line(fnd_file.output,'            '||'  '||RPAD(r_app.trx_number,15,' ')||'  '||RPAD(r_app.receipts,15,' ')||'  '||RPAD('Error',11,' ')||'  '||RPAD(r_app.error_message,70,' '));
            END IF;

        END LOOP;


        fnd_file.put_line(fnd_file.output,'');
        fnd_file.put_line(fnd_file.output,'');

        fnd_file.put_line(fnd_file.log,'Cantidad de Recibos Total     : '||to_char(v_count));
        fnd_file.put_line(fnd_file.output,'Cantidad de Recibos Total     : '||to_char(v_count));
        fnd_file.put_line(fnd_file.log,'Cantidad de Recibos Error     : '||to_char(v_count_err));
        fnd_file.put_line(fnd_file.output,'Cantidad de Recibos Error     : '||to_char(v_count_err));
        fnd_file.put_line(fnd_file.log,'Cantidad de Recibos No Proc   : '||to_char(v_count_nop));
        fnd_file.put_line(fnd_file.output,'Cantidad de Recibos No Proc   : '||to_char(v_count_nop));
        fnd_file.put_line(fnd_file.log,'Cantidad de Recibos Procesados: '||to_char(v_count_pro));
        fnd_file.put_line(fnd_file.output,'Cantidad de Recibos Procesados: '||to_char(v_count_pro));
        fnd_file.put_line(fnd_file.log,'Cantidad de Recibos Otros     : '||to_char(v_count_ot));
        fnd_file.put_line(fnd_file.output,'Cantidad de Recibos Otros     : '||to_char(v_count_ot));

        fnd_file.put_line(fnd_file.log,'Cantidad de Aplicac Total     : '||to_char(v_count_ap));
        fnd_file.put_line(fnd_file.output,'Cantidad de Aplicac Total     : '||to_char(v_count_ap));
        fnd_file.put_line(fnd_file.log,'Cantidad de Aplicac Error     : '||to_char(v_count_err_ap));
        fnd_file.put_line(fnd_file.output,'Cantidad de Aplicac Error     : '||to_char(v_count_err_ap));
        fnd_file.put_line(fnd_file.log,'Cantidad de Aplicac Procesados: '||to_char(v_count_pro_ap));
        fnd_file.put_line(fnd_file.output,'Cantidad de Aplicac Procesados: '||to_char(v_count_pro_ap));
        fnd_file.put_line(fnd_file.log,'Cantidad de Aplicac Otros     : '||to_char(v_count_ot_ap));
        fnd_file.put_line(fnd_file.output,'Cantidad de Aplicac Otros     : '||to_char(v_count_ot_ap));

        fnd_file.put_line(fnd_file.output,'');
        fnd_file.put_line(fnd_file.output,'');

        IF v_error_flag = 0 THEN
           IF v_count_ap != v_count_pro_ap THEN
              v_error_flag := 1;
           END IF;
        END IF;

        IF v_error_flag = 0 THEN

            UPDATE xx_ar_adec_batches
               SET status = 'C'  /*CONFIRMED*/
                  ,last_update_date = sysdate
                  ,last_updated_by = fnd_global.user_id
             WHERE adec_batch_id = r_batch.adec_batch_id;

             fnd_file.put_line(fnd_file.log,'Lote Confirmado');

        ELSE

             fnd_file.put_line(fnd_file.log,'Lote con Errores');
             p_status := 'W';

        END IF;

    END LOOP;

    FND_FILE.PUT_LINE(FND_FILE.LOG,'XX_AR_ADECUENTAS_INT_PKG.CHECK_BATCH_STATUS (-)');

EXCEPTION
 WHEN OTHERS THEN
   v_error_message := 'Error al validar el estado de los lotes. Error: '||SQLERRM;
   FND_FILE.PUT_LINE(FND_FILE.LOG,v_error_message);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'XX_AR_ADECUENTAS_INT_PKG.CHECK_BATCH_STATUS (!)');
END;

PROCEDURE apply_trx(p_customer_trx_nd_id    IN NUMBER,
                    p_customer_trx_nc_id    IN NUMBER,
                    p_status               OUT VARCHAR2,
                    p_error_message        OUT VARCHAR2)
IS
    v_error_message         VARCHAR2(2000);
    l_msg_data              VARCHAR2(2000);
    l_return_status         VARCHAR2(10);
    l_msg_count             NUMBER;
    l_count                 NUMBER;
    e_cust_exception        EXCEPTION;

CURSOR c_ps_cm IS
select payment_schedule_id
from ar_payment_schedules
where customer_trx_id = p_customer_trx_nc_id;

CURSOR c_ps_dm IS
select aps.payment_schedule_id,rct.trx_date,aps.amount_due_remaining amount
from ar_payment_schedules aps
      ,ra_customer_trx rct
where rct.customer_trx_id = p_customer_trx_nd_id
  and rct.customer_trx_id = aps.customer_trx_id;

v_trx_date DATE;
v_cm_ps_id NUMBER;
v_dm_ps_id NUMBER;
v_amount NUMBER;

p_out_rec_application_id NUMBER;
p_acctd_amount_applied_from NUMBER;
p_acctd_amount_applied_to NUMBER;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_TRX (+)');

    fnd_file.put_line(fnd_file.log,'ND Customer_trx_id: '||p_customer_trx_nd_id);
    fnd_file.put_line(fnd_file.log,'NC Customer_trx_id: '||p_customer_trx_nc_id);

    BEGIN

        select payment_schedule_id
          into v_cm_ps_id
          from  ar_payment_schedules aps
         where aps.customer_trx_id = p_customer_trx_nc_id;

    EXCEPTION
    WHEN OTHERS THEN
      p_error_message := 'Error al obtener payment_schedule_id de NC. Error: '||SQLERRM;
      RAISE e_cust_exception;
    END;

    fnd_file.put_line(fnd_file.log,'NC Payment_schedule_id: '||v_cm_ps_id);

     FOR r_ps_dm IN c_ps_dm LOOP

        fnd_file.put_line(fnd_file.log,'ND Payment_schedule_id: '||r_ps_dm.payment_schedule_id );
        fnd_file.put_line(fnd_file.log,'ND Amount: '||r_ps_dm.amount);

         ARP_PROCESS_APPLICATION.CM_APPLICATION (p_cm_ps_id => v_cm_ps_id
                                                ,p_invoice_ps_id => r_ps_dm.payment_schedule_id
                                                ,p_amount_applied => r_ps_dm.amount
                                                ,p_apply_date => r_ps_dm.trx_date
                                                ,p_gl_date =>  TRUNC(sysdate)
                                                ,p_ussgl_transaction_code => NULL
                                                ,p_attribute_category => NULL
                                                ,p_attribute1 => NULL
                                                ,p_attribute2 => NULL
                                                ,p_attribute3 => NULL
                                                ,p_attribute4 => NULL
                                                ,p_attribute5 => NULL
                                                ,p_attribute6 => NULL
                                                ,p_attribute7 => NULL
                                                ,p_attribute8 => NULL
                                                ,p_attribute9 => NULL
                                                ,p_attribute10 => NULL
                                                ,p_attribute11 => NULL
                                                ,p_attribute12 => NULL
                                                ,p_attribute13 => NULL
                                                ,p_attribute14 => NULL
                                                ,p_attribute15 => NULL
                                                ,p_global_attribute_category => NULL
                                                ,p_global_attribute1 => NULL
                                                ,p_global_attribute2 => NULL
                                                ,p_global_attribute3 => NULL
                                                ,p_global_attribute4 => NULL
                                                ,p_global_attribute5 => NULL
                                                ,p_global_attribute6 => NULL
                                                ,p_global_attribute7 => NULL
                                                ,p_global_attribute8 => NULL
                                                ,p_global_attribute9 => NULL
                                                ,p_global_attribute10 => NULL
                                                ,p_global_attribute11 => NULL
                                                ,p_global_attribute12 => NULL
                                                ,p_global_attribute13 => NULL
                                                ,p_global_attribute14 => NULL
                                                ,p_global_attribute15 => NULL
                                                ,p_global_attribute16 => NULL
                                                ,p_global_attribute17 => NULL
                                                ,p_global_attribute18 => NULL
                                                ,p_global_attribute19 => NULL
                                                ,p_global_attribute20 => NULL
                                                ,p_customer_trx_line_id => null
                                                ,p_comments => null
                                                ,p_module_name => '1'
                                                ,p_module_version => '1.0'
                                                ,p_out_rec_application_id =>  p_out_rec_application_id
                                                ,p_acctd_amount_applied_from  => p_acctd_amount_applied_from
                                                ,p_acctd_amount_applied_to => p_acctd_amount_applied_to);

        COMMIT;

        fnd_file.put_line(fnd_file.log,'Receivable_application_id: '||p_out_rec_application_id);

        if p_out_rec_application_id is null then
            p_status := 'W';
            p_error_message := 'Error al aplicar CM to DM';
            RAISE e_cust_exception;
        ELSE
            p_status := 'S';
        END IF;

     END LOOP;

     fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_TRX (+)');

EXCEPTION
 WHEN e_cust_exception THEN
    p_error_message := v_error_message;
    fnd_file.put_line(fnd_file.log,v_error_message);
    p_status := 'W';
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_TRX (!)');
 WHEN OTHERS THEN
    p_error_message := 'Excepcion OTHERS en apply_trx para customer_trx_nd_id:' || TO_CHAR(p_customer_trx_nd_id)||' y p_customer_trx_nc_id:'||to_char(p_customer_trx_nc_id)||'. Error: '||SQLERRM;
    fnd_file.put_line(fnd_file.log,p_error_message);
    p_status := 'W';
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_TRX (!)');
END apply_trx;

PROCEDURE api_create_trx(p_cash_receipt_id IN NUMBER
                        ,p_batch_source    IN VARCHAR2
                        ,p_amount          IN NUMBER
                        ,p_customer_trx_id OUT NUMBER
                        ,p_status          OUT VARCHAR2
                        ,p_error_message   OUT VARCHAR2) IS


v_cr_rec                    ar_cash_receipts%ROWTYPE;

v_ccid                  NUMBER;
v_cust_trx_type_id      NUMBER;
v_bill_to_address_id    NUMBER;
v_ship_to_address_id    NUMBER;
l_trx_number          ra_customer_trx_all.trx_number%TYPE;
x_customer_trx_id       ra_customer_trx_all.customer_trx_id%TYPE;
v_trx_type              ra_cust_trx_types%rowtype;

l_batch_source_rec     ar_invoice_api_pub.batch_source_rec_type;
l_trx_header_tbl       ar_invoice_api_pub.trx_header_tbl_type;
l_trx_lines_tbl        ar_invoice_api_pub.trx_line_tbl_type;
l_trx_dist_tbl         ar_invoice_api_pub.trx_dist_tbl_type;
l_trx_salescredits_tbl ar_invoice_api_pub.trx_salescredits_tbl_type;
l_return_status        varchar2(1);
l_msg_count            number;
l_msg_data             varchar2(2000);
l_cnt                  number := 0;

api_msg_error           VARCHAR2(2000);
v_sob_id                NUMBER;
v_inv_org_id            NUMBER;
v_term_id               NUMBER;
v_memo_line_id          NUMBER;
v_batch_source_id       NUMBER;
v_vat_tax_id NUMBER;
v_amount                NUMBER;
v_gdf_attr2             VARCHAR2(150);
v_gdf_attr3             VARCHAR2(150);
v_description           VARCHAR2(80);
v_cust_trx_type         VARCHAR2(20);
e_cust_exception        EXCEPTION;

l_closing_status        VARCHAR2(1);

  cursor list_errors is
   SELECT trx_header_id, trx_line_id, trx_salescredit_id, trx_dist_id,
          trx_contingency_id, error_message, invalid_value
   FROM   ar_trx_errors_gt;

--v_rule_start_date          ra_customer_trx_lines.rule_start_date%type;
--v_accounting_rule_duration ra_customer_trx_lines.accounting_rule_duration%type;
--v_gl_date DATE;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.API_CREATE_TRX (+)');

    BEGIN

          SELECT *
            INTO v_cr_rec
            FROM ar_cash_receipts
           WHERE cash_receipt_id = p_cash_receipt_id;

    EXCEPTION
     WHEN OTHERS THEN
       p_error_message := 'Error al obtener datos del recibo. id: '||p_cash_receipt_id;
       RAISE e_cust_exception;
    END;

    BEGIN

          SELECT account_code_combination_id
            INTO v_ccid
            FROM ar_cash_receipt_history
           WHERE cash_receipt_id = p_cash_receipt_id
           and status = 'CONFIRMED';

    EXCEPTION
     WHEN NO_DATA_FOUND THEN
       BEGIN
             SELECT account_code_combination_id
                    INTO v_ccid
                    FROM ar_cash_receipt_history
                   WHERE cash_receipt_id = p_cash_receipt_id
                   and account_code_combination_id is not null
                   and rownum = 1;
       EXCEPTION
       WHEN OTHERS THEN
         p_error_message := 'Error al obtener datos del recibo (HISTORY).ID: '||p_cash_receipt_id;
         RAISE e_cust_exception;
       END;
     WHEN OTHERS THEN
       p_error_message := 'Error al obtener datos del recibo (HISTORY).ID: '||p_cash_receipt_id;
       RAISE e_cust_exception;
    END;

    BEGIN

        select default_inv_trx_type,rctt.type,rbs.batch_source_id
        into v_cust_trx_type_id,v_cust_trx_type,v_batch_source_id
        FROM ra_batch_sources rbs
        ,ra_cust_trx_types rctt
        --where rbs.batch_source_id = p_batch_source_id
        where rbs.name = p_batch_source
        and rbs.default_inv_trx_type is not null
        and rbs.default_inv_trx_type = rctt.cust_trx_type_id;

    EXCEPTION
     WHEN OTHERS THEN
        p_error_message := 'Error al obtener Tipo de Transaccion asociado al origen: '||p_batch_source||'. Error: '||SQLERRM;
        RAISE e_cust_exception;
    END;

    BEGIN
      SELECT *
        INTO v_trx_type
        FROM ra_cust_trx_types
       WHERE cust_trx_type_id = v_cust_trx_type_id;

    EXCEPTION
      WHEN OTHERS THEN
        p_error_message := 'Error al obtener datos del Tipo de Transaccion asociado al origen: '||p_batch_source||'. Error: '||SQLERRM;
        RAISE e_cust_exception;
    END;

    IF v_cust_trx_type = 'CM' THEN
        v_term_id := null;
        v_amount := -1*NVL(p_amount,v_cr_rec.amount);
    else
        v_term_id := g_term_id;
        v_amount := NVL(p_amount,v_cr_rec.amount);
    END IF;

    BEGIN
       SELECT inventory_organization_id
         INTO v_inv_org_id
         FROM FINANCIALS_SYSTEM_PARAMS_ALL
        WHERE org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'));

     EXCEPTION
       WHEN no_data_found THEN
         p_error_message := 'No se encontraron Parametros de la '    ||
                         'Organizacion para la Unidad Operativa ' ||
                         'en las Opciones Financieras';
         RAISE e_cust_exception;
       WHEN others THEN
         p_error_message := 'Error buscando Parametros de la '       ||
                         'Organizacion para la Unidad Operativa ' ||
                         'en las Opciones Financieras. '          ||
                         SQLERRM;
         RAISE e_cust_exception;
     END;

     BEGIN
                    SELECT hcsu.site_use_id
                      INTO v_ship_to_address_id
                      FROM hz_cust_acct_sites hcas
                          ,hz_cust_site_uses hcsu
                     WHERE hcas.cust_account_id = v_cr_rec.pay_from_customer
                       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
                       and hcsu.site_use_code = 'SHIP_TO'
                       and hcsu.primary_flag = 'Y';
      EXCEPTION
      WHEN OTHERS THEN
            p_error_message := 'Error al obtener el domicilio primario de Envio. Error: '||SQLERRM;
            raise e_cust_exception;
      END;

      BEGIN

                    SELECT hcsu.site_use_id
                      INTO v_bill_to_address_id
                      FROM hz_cust_acct_sites hcas
                          ,hz_cust_site_uses hcsu
                          ,hz_cust_accounts hca
                     WHERE hca.cust_account_id = hcas.cust_account_id
                       and hcas.cust_account_id = v_cr_rec.pay_from_customer
                       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
                       and hcsu.site_use_code = 'BILL_TO'
                       and hcsu.primary_flag = 'Y';

      EXCEPTION
        WHEN OTHERS THEN
            p_error_message := 'Error al obtener el domicilio primario de Facturacion. Error: '||SQLERRM;
            raise e_cust_exception;
      END;

      BEGIN

      SELECT global_attribute1,global_attribute2,description,memo_line_id
      into v_gdf_attr2,v_gdf_attr3,v_description,v_memo_line_id
      from ar_memo_lines
      /*Modificado Khronus/E.Sly 20180718*/
      --where memo_line_id = g_memo_line_id;
      where name = g_memo_line;
      /*Fin Modificado Khronus/E.Sly 20180718*/

      EXCEPTION
       WHEN OTHERS THEN
         p_error_message := 'Error al obtener datos de la Linea de Nota. Error: '||SQLERRM;
         raise e_cust_exception;
      END;


      BEGIN

           SELECT  vat_tax_id
        into v_vat_tax_id
        FROM    ar_vat_tax
        WHERE   tax_code = 'IVA 0% Exento'
        AND     tax_type = 'VAT'
        AND     sysdate between nvl(start_date,sysdate) and nvl(end_date,sysdate)
        AND     global_attribute1 = '51'
        AND     enabled_flag = 'Y';

      EXCEPTION
       WHEN OTHERS THEN
         p_error_message := 'Error al obtener datos de un impuesto exento. Error: '||SQLERRM;
         raise e_cust_exception;
      END;

      l_trx_lines_tbl.DELETE;
      l_trx_header_tbl.DELETE;
      l_trx_dist_tbl.DELETE;

    l_batch_source_rec.batch_source_id := v_batch_source_id;

    fnd_file.put_line(fnd_file.log,'BATCH_SOURCE_ID: '||l_batch_source_rec.batch_source_id);

    l_trx_header_tbl(1).trx_header_id := 101; --ID de relacion entre Cabecera y lineas
    l_trx_header_tbl(1).bill_to_customer_id := v_cr_rec.pay_from_customer;
    l_trx_header_tbl(1).bill_to_site_use_id := v_bill_to_address_id;
    l_trx_header_tbl(1).ship_to_customer_id := v_cr_rec.pay_from_customer;
    l_trx_header_tbl(1).ship_to_site_use_id := v_ship_to_address_id;
    l_trx_header_tbl(1).term_id             := v_term_id;
    l_trx_header_tbl(1).cust_trx_type_id    := v_cust_trx_type_id;
    l_trx_header_tbl(1).trx_currency              := v_cr_rec.currency_code;
    l_trx_header_tbl(1).trx_date                  := v_cr_rec.receipt_date;
    l_trx_header_tbl(1).org_id                    := nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'));
    l_trx_header_tbl(1).status_trx                := 'OP';
    l_trx_header_tbl(1).printing_option           := 'PRI';
    l_trx_header_tbl(1).comments                  := 'Creado por Adecuentas';
    l_trx_header_tbl(1).global_attribute_category := 'JL.AR.ARXTWMAI.TGW_HEADER';

    l_trx_header_tbl(1).exchange_date             := v_cr_rec.exchange_date;
    l_trx_header_tbl(1).exchange_rate_type        := v_cr_rec.exchange_rate_type;
    l_trx_header_tbl(1).exchange_rate             := v_cr_rec.exchange_rate;


    fnd_file.put_line(fnd_file.log,'BILL_TO_CUSTOMER_ID: '|| l_trx_header_tbl(1).bill_to_customer_id);
    fnd_file.put_line(fnd_file.log,'bill_to_site_use_id: '|| l_trx_header_tbl(1).bill_to_site_use_id);
    fnd_file.put_line(fnd_file.log,'ship_to_customer_id: '|| l_trx_header_tbl(1).ship_to_customer_id);
    fnd_file.put_line(fnd_file.log,'ship_to_site_use_id: '|| l_trx_header_tbl(1).ship_to_site_use_id);
    fnd_file.put_line(fnd_file.log,'term_id: '|| l_trx_header_tbl(1).term_id);
    fnd_file.put_line(fnd_file.log,'cust_trx_type_id: '|| l_trx_header_tbl(1).cust_trx_type_id);
    fnd_file.put_line(fnd_file.log,'trx_currency: '|| l_trx_header_tbl(1).trx_currency);
    --fnd_file.put_line(fnd_file.log,'trx_date: '|| l_trx_header_tbl(1).trx_date); CR1620
    fnd_file.put_line(fnd_file.log,'org_id: '|| l_trx_header_tbl(1).org_id);
    fnd_file.put_line(fnd_file.log,'status_trx: '|| l_trx_header_tbl(1).status_trx);
    fnd_file.put_line(fnd_file.log,'printing_option: '|| l_trx_header_tbl(1).printing_option);
    fnd_file.put_line(fnd_file.log,'comments: '|| l_trx_header_tbl(1).comments);
    fnd_file.put_line(fnd_file.log,'global_attribute_category: '|| l_trx_header_tbl(1).global_attribute_category);
    fnd_file.put_line(fnd_file.log,'exchange_date: '|| l_trx_header_tbl(1).exchange_date);
    fnd_file.put_line(fnd_file.log,'exchange_rate_type: '|| l_trx_header_tbl(1).exchange_rate_type);
    fnd_file.put_line(fnd_file.log,'exchange_rate: '|| l_trx_header_tbl(1).exchange_rate);

    --Inicio CR1620
    BEGIN
        SELECT closing_status
        INTO   l_closing_status
        FROM   apps.gl_period_statuses gps
              ,apps.hr_operating_units hou
        WHERE  gps.application_id = 222
        AND    hou.set_of_books_id = gps.set_of_books_id
        AND    l_trx_header_tbl(1).trx_date BETWEEN gps.start_date AND gps.end_date
        AND    hou.organization_id =  nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'));

        IF l_closing_status != 'O' THEN
            SELECT min(start_date)
            INTO   l_trx_header_tbl(1).trx_date
            FROM   apps.gl_period_statuses gps
                  ,apps.hr_operating_units hou
            WHERE  gps.application_id = 222
            AND    hou.set_of_books_id = gps.set_of_books_id
            AND    closing_status = 'O'
            AND    hou.organization_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'));
        END IF;
     EXCEPTION
       WHEN OTHERS THEN
         p_error_message := 'Error al obtener fecha del recibo. Error: '||SQLERRM;
         raise e_cust_exception;
      END;

      --Fin CR1620

    fnd_file.put_line(fnd_file.log,'trx_date: '|| l_trx_header_tbl(1).trx_date);

    /*Lineas*/



    l_trx_lines_tbl(1).trx_header_id := 101;
    l_trx_lines_tbl(1).line_number   := 1;
    l_trx_lines_tbl(1).trx_line_id   := 101;

    l_trx_lines_tbl(1).memo_line_id       := v_memo_line_id;
    l_trx_lines_tbl(1).line_type          := 'LINE';
    l_trx_lines_tbl(1).description        := v_description;
    l_trx_lines_tbl(1).quantity_invoiced  := 1;
    l_trx_lines_tbl(1).unit_selling_price := v_amount;

    l_trx_lines_tbl(1).vat_tax_id           := v_vat_tax_id;
    l_trx_lines_tbl(1).tax_exempt_flag      := 'S';

    l_trx_lines_tbl(1).global_attribute_category := 'JL.AR.ARXTWMAI.LINES';
    l_trx_lines_tbl(1).global_attribute2         := v_gdf_attr2;
    l_trx_lines_tbl(1).global_attribute3         := v_gdf_attr3;

    l_trx_lines_tbl(1).amount_includes_tax_flag := 'N';
    l_trx_lines_tbl(1).warehouse_id             := v_inv_org_id;

    l_trx_lines_tbl(1).interface_line_context    := 'ADECUENTAS';
    l_trx_lines_tbl(1).interface_line_attribute1 := v_cr_rec.cash_receipt_id;
    l_trx_lines_tbl(1).interface_line_attribute2 := v_cust_trx_type;


    fnd_file.put_line(fnd_file.log,'memo_line_id: '|| l_trx_lines_tbl(1).memo_line_id);
    fnd_file.put_line(fnd_file.log,'description: '|| l_trx_lines_tbl(1).description);
    fnd_file.put_line(fnd_file.log,'unit_selling_price: '|| l_trx_lines_tbl(1).unit_selling_price);
    fnd_file.put_line(fnd_file.log,'vat_tax_id: '|| l_trx_lines_tbl(1).vat_tax_id);
    fnd_file.put_line(fnd_file.log,'global_attribute2: '|| l_trx_lines_tbl(1).global_attribute2);
    fnd_file.put_line(fnd_file.log,'global_attribute3: '|| l_trx_lines_tbl(1).global_attribute3);
    fnd_file.put_line(fnd_file.log,'interface_line_attribute1: '|| l_trx_lines_tbl(1).interface_line_attribute1);
    fnd_file.put_line(fnd_file.log,'interface_line_attribute2: '|| l_trx_lines_tbl(1).interface_line_attribute2);


    AR_INVOICE_API_PUB.create_single_invoice( p_api_version          => 1.0,
                                              p_batch_source_rec     => l_batch_source_rec,
                                              p_trx_header_tbl       => l_trx_header_tbl,
                                              p_trx_lines_tbl        => l_trx_lines_tbl,
                                              p_trx_dist_tbl         => l_trx_dist_tbl,
                                              p_trx_salescredits_tbl => l_trx_salescredits_tbl,
                                              x_customer_trx_id      => x_customer_trx_id,
                                              x_return_status        => l_return_status,
                                              x_msg_count            => l_msg_count,
                                              x_msg_data             => l_msg_data);


    IF l_return_status = fnd_api.g_ret_sts_error OR
      l_return_status = fnd_api.g_ret_sts_unexp_error THEN

      SELECT count(*)
      INTO   l_cnt
      FROM   ar_trx_errors_gt;

      IF l_cnt != 0 THEN
         FOR i in list_errors LOOP
             p_error_message := p_error_message ||' - '||i.error_message;
         END LOOP;
      END IF;
     END IF;

     if p_error_message is not null then
        raise e_cust_exception;
--     else
--        BEGIN
--
--            select trx_number
--            into l_trx_number
--            from ra_customer_trx_all
--            where customer_trx_id = x_customer_trx_id;
--
--        EXCEPTION
--         WHEN OTHERS THEN
--           p_error_message := 'Error al obtener trx_number. Error: '||SQLERRM;
--           RAISE e_cust_exception;
--        END;
     end if;

    IF p_status IS NULL THEN
       p_status := 'S';
       p_customer_trx_id := x_customer_trx_id;
       fnd_file.put_line(fnd_file.log,'ID de Transaccion Creado: '||x_customer_trx_id);
       fnd_file.put_line(fnd_file.log,'Numero de Transaccion Creado: '||l_trx_number);
       COMMIT;
       fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.API_CREATE_TRX (-)');
    ELSE
      fnd_file.put_line(fnd_file.log,p_status);
      RAISE e_cust_exception;
    END IF;

EXCEPTION
 WHEN e_cust_exception THEN
  ROLLBACK;
  p_status := 'W';
  fnd_file.put_line(fnd_file.log,p_error_message);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.API_CREATE_TRX (!)');
 WHEN OTHERS THEN
  ROLLBACK;
  p_status := 'W';
  p_error_message := 'Error OTHERS en create_trx: '||SQLERRM;
  fnd_file.put_line(fnd_file.log,p_error_message);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.API_CREATE_TRX (!)');
END;


PROCEDURE apply_receipt(p_cash_receipt_id       IN NUMBER,
                        p_customer_trx_id       IN NUMBER,
                        p_payment_schedule_id   IN NUMBER,
                        p_amount_applied        IN NUMBER,
                        p_comments              IN VARCHAR2,
                        p_status               OUT VARCHAR2,
                        p_error_message        OUT VARCHAR2)
IS
    v_error_message         VARCHAR2(2000);
    l_msg_data              VARCHAR2(2000);
    l_return_status         VARCHAR2(10);
    l_msg_count             NUMBER;
    l_count                 NUMBER;
    e_cust_exception        EXCEPTION;

    v_rem NUMBER;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_RECEIPT (+)');

    fnd_file.put_line(fnd_file.log,'Cash_receipt_id: '||p_cash_receipt_id);
    fnd_file.put_line(fnd_file.log,'Customer_trx_id: '||p_customer_trx_id);
    fnd_file.put_line(fnd_file.log,'Payment_Schedule_id: '||p_payment_schedule_id);
    fnd_file.put_line(fnd_file.log,'Amount: '||p_amount_applied);

    IF p_payment_schedule_id IS NOT NULL THEN

        /*Verifico el saldo*/
        BEGIN

            select NVL(SUM(NVL(amount_due_remaining,0)),0)
            into v_rem
            from ar_payment_schedules_all
            where payment_schedule_id = p_payment_schedule_id;

        EXCEPTION
          WHEN OTHERS THEN
            v_error_message := 'Error al obtener el saldo del comprobante a Aplicar';
            RAISE e_cust_exception;
        END;

        IF v_rem = 0 THEN
            v_error_message := 'La Transaccion no tiene saldo disponible en Oracle';
            RAISE e_cust_exception;
        END IF;

    END IF;

    AR_RECEIPT_API_PUB.apply (p_api_version         => 1.0,
                              p_init_msg_list         => FND_API.G_TRUE,
                              p_commit                => FND_API.G_FALSE,
                              p_validation_level      => FND_API.G_VALID_LEVEL_FULL,
                              p_cash_receipt_id       => p_cash_receipt_id,
                              p_customer_trx_id       => p_customer_trx_id,
                              p_applied_payment_schedule_id => p_payment_schedule_id,
                              p_amount_applied        => p_amount_applied,
                              p_comments              => p_comments,
                              x_return_status         => l_return_status,
                              x_msg_count             => l_msg_count,
                              x_msg_data              => l_msg_data);


    fnd_file.put_line(fnd_file.log,'Status: ' || l_return_status);
    fnd_file.put_line(fnd_file.log,'Message count: ' || l_msg_count);

    l_count := 0;

    IF l_msg_count = 1 THEN

        p_status := 'W';
        fnd_file.put_line(fnd_file.log,'Message: ' || l_msg_count ||'.'||l_msg_data);
        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_RECEIPT (!)');

    ELSIF l_msg_count > 1 THEN

        p_status := 'W';
        LOOP
            l_count := l_count+1;
            l_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            p_error_message := p_error_message || l_count ||'.'|| l_msg_data;
            fnd_file.put_line(fnd_file.log,'Message: ' || l_count ||'.'||l_msg_data);
             IF l_msg_data IS NULL or l_count >= 1 THEN
                EXIT;
            END IF;
        END LOOP;
        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_RECEIPT (!)');

    ELSE

        p_status := 'S';
        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_RECEIPT (-)');

    END IF;

EXCEPTION
 WHEN e_cust_exception THEN
    p_error_message := v_error_message;
    fnd_file.put_line(fnd_file.log,v_error_message);
    p_status := 'W';
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_RECEIPT (!)');
 WHEN OTHERS THEN
    p_error_message := 'Excepcion OTHERS en apply_receipt para cash_receipt_id:' || TO_CHAR(p_cash_receipt_id)||' y payment_schedule_id:'||to_char(p_payment_schedule_id);
    fnd_file.put_line(fnd_file.log,p_error_message);
    p_status := 'W';
    fnd_file.put_line(fnd_file.log,SQLERRM);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_RECEIPT (!)');
END apply_receipt;

PROCEDURE  apply_onaccount (p_cash_receipt_id IN  NUMBER
                           ,p_amount          IN  NUMBER
                           ,p_status          OUT VARCHAR2
                           ,p_error_message   OUT VARCHAR2) IS

l_customer_trx_nd_id NUMBER;
l_customer_trx_nc_id NUMBER;

v_amount NUMBER;

v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);

e_cust_exception EXCEPTION;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_ONACCOUNT (+)');

    /*Modificar para calcular el saldo del recibo*/

    BEGIN

        select NVL(p_amount,amount)
        into v_amount
        from ar_cash_receipts
        where cash_receipt_id = p_cash_receipt_id;

    EXCEPTION
     WHEN OTHERS THEN
       p_error_message := 'Error al obtener el monto del recibo a aplicar';
       raise e_cust_exception;
    END;

    /*Creo la Nota de Debito*/
     api_create_trx(p_cash_receipt_id,g_batch_source_nd,v_amount,l_customer_trx_nd_id,v_status,v_error_message);

     IF v_status != 'S' THEN
        RAISE e_cust_exception;
     END IF;

     /*Aplico la Nota de Debito con el recibo*/
     apply_receipt(p_cash_receipt_id,l_customer_trx_nd_id,null,v_amount,NULL,v_status,v_error_message);

     IF v_status != 'S' THEN
        RAISE e_cust_exception;
     END IF;

     /*Creo la Nota de Credito*/
     api_create_trx(p_cash_receipt_id,g_batch_source_nc,v_amount,l_customer_trx_nc_id,v_status,v_error_message);

     IF v_status != 'S' THEN
        RAISE e_cust_exception;
     END IF;

     IF p_status IS NULL THEN
       p_status := 'S';
     END IF;

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_ONACCOUNT (-)');

EXCEPTION
 WHEN e_cust_exception THEN
    p_status := 'W';
    p_error_message := v_error_message;
    fnd_file.put_line(fnd_file.log,p_error_message);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_ONACCOUNT (!)');
 WHEN OTHERS THEN
    p_status := 'E';
    p_error_message := 'Exception OTHERS en APPLY_ONACCOUNT: '||SQLERRM;
    fnd_file.put_line(fnd_file.log,p_error_message);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.APPLY_ONACCOUNT (!)');
END;

PROCEDURE validate_applications(p_status        IN OUT VARCHAR2
                               ,p_error_message IN OUT VARCHAR
                               ,p_batch_name    IN VARCHAR2
                               ,p_party_id      IN NUMBER) IS


CURSOR c_rec IS
SELECT *
from xx_ar_adec_receipts xaaa
where xaaa.status = 'P'
and xaaa.request_id = fnd_global.conc_request_id
and xaaa.batch_name = p_batch_name
and xaaa.party_id = p_party_id
order by amount;

/*Recorrer las aplicaciones del mismo lote*/
CURSOR c_app IS
select xaaa.adec_application_id
,xaaa.batch_name
,xaaa.party_id
,xaaa.trx_number
,xaaa.currency_code
,NVL(xaaa.amount_remaining,amount) amount
,xaaa.payment_schedule_id
,xaaa.comments
from xx_ar_adec_applications xaaa
where xaaa.status = 'N'
and xaaa.request_id IS NULL
and xaaa.batch_name = p_batch_name
and xaaa.party_id = p_party_id
and xaaa.payment_schedule_id IS NOT NULL
order by amount;

v_amount_applied NUMBER;
v_saldo_appl NUMBER;
v_saldo_rec NUMBER;
v_applied NUMBER;
v_applied1 NUMBER;
v_cust_applied NUMBER;

v_error_flag NUMBER;

v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);

e_rec_exception exception;
e_app_exception exception;


BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.VALIDATE_APPLICATIONS (+)');

    v_error_flag := 0;

  FOR r_rec IN c_rec LOOP


    BEGIN

        SELECT NVL(SUM(NVL(amount_applied,0)),0)
        INTO v_amount_applied
        FROM ar_receivable_applications
        where cash_receipt_id = r_rec.cash_receipt_id
        and status = 'APP';

    EXCEPTION
      WHEN OTHERS THEN
        v_amount_applied := 0;
    END;

    v_saldo_rec := r_rec.amount-v_amount_applied;

    BEGIN

    IF v_amount_applied = r_rec.amount THEN

        /*Chequeo las aplicaciones que tuvo contra c_app y update = S*/
        FOR r_app IN c_app LOOP


                BEGIN
                              SELECT 1
                                INTO v_applied1
                                FROM ar_receivable_applications_all
                                where applied_payment_schedule_id =  r_app.payment_schedule_id
                                and status = 'APP'
                                and reversal_gl_date is null
                                and cash_receipt_id =  r_rec.cash_receipt_id;
                EXCEPTION
                 WHEN OTHERS THEN
                 v_applied1 := 0;
                END;

                IF v_applied1 = 1 THEN
                    UPDATE xx_ar_adec_applications
                       SET status = 'S'
                          ,trx_appl_id = r_rec.cash_receipt_id
                          ,request_id = fnd_global.conc_request_id
                          ,last_update_date = sysdate
                          ,last_updated_by = fnd_global.user_id
                     where adec_application_id = r_app.adec_application_id;
                END IF;
        END LOOP;

        UPDATE xx_ar_adec_receipts
           SET amount_remaining = 0
              ,status = 'S'
              ,last_update_date = sysdate
              ,last_updated_by = fnd_global.user_id
         WHERE cash_receipt_id = r_rec.cash_receipt_id
           AND request_id = fnd_global.conc_request_id
           AND status = 'P';
    ELSE

        FOR r_app IN c_app LOOP

            BEGIN

--              BEGIN
--                  select amount_due_remaining
--                    into v_saldo_appl
--                    from ar_payment_schedules_all
--                    where payment_schedule_id = r_app.payment_schedule_id;
--              EXCEPTION
--                WHEN OTHERS THEN
--                   v_saldo_appl := 0;
--              END;

--             IF v_saldo_appl = 0 THEN

              BEGIN
                  SELECT NVL(SUM(NVL(amount_applied,0)),0)
                    INTO v_cust_applied
                    FROM ar_receivable_applications_all
                    where applied_payment_schedule_id =  r_app.payment_schedule_id
                    and status = 'APP'
                    and reversal_gl_date is null
                    and cash_receipt_id IN (select cash_receipt_id from xx_ar_adec_receipts where request_id = fnd_global.conc_request_id and batch_name = p_batch_name and party_id = p_party_id);
              EXCEPTION
                  when others then
                   v_cust_applied := 0;
              END;

              IF v_cust_applied = r_app.amount THEN
                v_applied := 1;
              ELSIF  v_cust_applied < r_app.amount THEN
                v_saldo_appl := r_app.amount - v_cust_applied;
                v_applied := 0;
              ELSE
                v_applied := -1;
              END IF;

             IF v_applied = 1 THEN

                UPDATE xx_ar_adec_applications
                   SET status = 'S'
                      ,trx_appl_id = r_rec.cash_receipt_id
                      ,request_id = fnd_global.conc_request_id
                      ,last_update_date = sysdate
                      ,last_updated_by = fnd_global.user_id
                 where adec_application_id = r_app.adec_application_id;

             ELSIF  v_applied = -1 THEN

                UPDATE xx_ar_adec_applications
                   SET Status = 'E'
                      ,error_message = 'Comprobante sin Saldo. No es posible procesar. Aplica a Recibo: '||r_rec.receipt_number
                      ,request_id = fnd_global.conc_request_id
                      ,last_update_date = sysdate
                      ,last_updated_by = fnd_global.user_id
                 WHERE adec_application_id = r_app.adec_application_id;


             ELSE


                    IF v_saldo_appl >  r_app.amount THEN
                       v_saldo_appl := r_app.amount;
                    END IF;

                    IF v_saldo_rec = v_saldo_appl THEN

                               FND_FILE.PUT_LINE(FND_FILE.LOG,'1');
                               FND_FILE.PUT_LINE(FND_FILE.LOG,'SALDO_APPL: '||v_saldo_appl);
                               FND_FILE.PUT_LINE(FND_FILE.LOG,'SALDO_REC: '||v_saldo_rec);

                               apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                             p_customer_trx_id      => NULL,
                                             p_payment_schedule_id  => r_app.payment_schedule_id,
                                             p_amount_applied       => v_saldo_appl,
                                             p_comments             => r_app.comments,
                                             p_status               => v_status,
                                             p_error_message        => v_error_message);

                                IF v_status = 'S' THEN

                                            UPDATE xx_ar_adec_applications
                                               SET status = 'S'
                                                  ,request_id = fnd_global.conc_request_id
                                                  ,trx_appl_id = r_rec.cash_receipt_id
                                                  ,amount_remaining = 0
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_application_id = r_app.adec_application_id
                                               AND status = 'N';

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = 0
                                                      ,status = 'S'
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                   AND request_id = fnd_global.conc_request_id
                                                   AND status = 'P';

                                ELSE

                                    UPDATE xx_ar_adec_applications
                                       SET status = 'E'
                                          ,error_message = 'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                          ,request_id = fnd_global.conc_request_id
                                          ,trx_appl_id = r_rec.cash_receipt_id
                                          ,amount_remaining = 0
                                          ,last_update_date = sysdate
                                          ,last_updated_by = fnd_global.user_id
                                     WHERE adec_application_id = r_app.adec_application_id
                                       AND status = 'N';

                                        UPDATE xx_ar_adec_receipts
                                           SET error_message = 'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                              ,last_update_date = sysdate
                                              ,last_updated_by = fnd_global.user_id
                                          WHERE adec_receipt_id = r_rec.adec_receipt_id
                                           AND request_id = fnd_global.conc_request_id
                                           AND status = 'P';

                                    fnd_file.put_line(fnd_file.log,'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                    v_error_flag := 1;
                                END IF;

--                        EXIT;

                        RAISE e_rec_exception;

                    ELSIF v_saldo_appl > v_saldo_rec THEN

                               FND_FILE.PUT_LINE(FND_FILE.LOG,'2');
                               FND_FILE.PUT_LINE(FND_FILE.LOG,'SALDO_APPL: '||v_saldo_appl);
                               FND_FILE.PUT_LINE(FND_FILE.LOG,'SALDO_REC: '||v_saldo_rec);

                               apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                             p_customer_trx_id      => NULL,
                                             p_payment_schedule_id  => r_app.payment_schedule_id,
                                             p_amount_applied       => v_saldo_rec,
                                             p_comments             => r_app.comments,
                                             p_status               => v_status,
                                             p_error_message        => v_error_message);

                                IF v_status = 'S' THEN

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = 0
                                                      ,status = 'S'
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                   AND request_id = fnd_global.conc_request_id
                                                   AND status = 'P';



                                ELSE

                                        UPDATE xx_ar_adec_receipts
                                           SET error_message = error_message ||'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                              ,last_update_date = sysdate
                                              ,last_updated_by = fnd_global.user_id
                                          WHERE cash_receipt_id = r_rec.cash_receipt_id
                                           AND request_id = fnd_global.conc_request_id
                                           AND status = 'P';

                                    IF v_error_message = 'La Transaccion no tiene saldo disponible en Oracle' THEN

                                         UPDATE xx_ar_adec_applications
                                           SET status = 'E'
                                              ,error_message = 'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                              ,request_id = fnd_global.conc_request_id
                                              ,last_update_date = sysdate
                                              ,last_updated_by = fnd_global.user_id
                                         WHERE adec_application_id = r_app.adec_application_id
                                           AND status = 'N';

                                    END IF;

                                    fnd_file.put_line(fnd_file.log,'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                    v_error_flag := 1;
                                END IF;

--                        EXIT;

                       RAISE e_rec_exception;

                    ELSE

                        FND_FILE.PUT_LINE(FND_FILE.LOG,'3');
                        FND_FILE.PUT_LINE(FND_FILE.LOG,'SALDO_APPL: '||v_saldo_appl);
                        FND_FILE.PUT_LINE(FND_FILE.LOG,'SALDO_REC: '||v_saldo_rec);

                        apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                             p_customer_trx_id      => NULL,
                                             p_payment_schedule_id  => r_app.payment_schedule_id,
                                             p_amount_applied       => v_saldo_appl,
                                             p_comments             => r_app.comments,
                                             p_status               => v_status,
                                             p_error_message        => v_error_message);

                                IF v_status = 'S' THEN

                                            UPDATE xx_ar_adec_applications
                                               SET status = 'S'
                                                  ,request_id = fnd_global.conc_request_id
                                                  ,trx_appl_id = r_rec.cash_receipt_id
                                                  ,amount_remaining = 0
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_application_id = r_app.adec_application_id
                                               AND status = 'N';

                                ELSE

                                        UPDATE xx_ar_adec_applications
                                       SET status = 'E'
                                          ,error_message = 'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                          ,request_id = fnd_global.conc_request_id
                                          ,trx_appl_id = r_rec.cash_receipt_id
                                          ,amount_remaining = 0
                                          ,last_update_date = sysdate
                                          ,last_updated_by = fnd_global.user_id
                                     WHERE adec_application_id = r_app.adec_application_id
                                       AND status = 'N';

                                    fnd_file.put_line(fnd_file.log,'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                    v_error_flag := 1;
                                END IF;

                        v_saldo_rec := v_saldo_rec - v_saldo_appl;

                    END IF;

             END IF;

            EXCEPTION
             WHEN e_app_exception then
             RAISE e_rec_exception;
             END;

        END LOOP;

      END IF;


      --Comentado KHRONUS/MNazarre 20200218: Se comenta la creacion de ND y NC a cuenta
      --a futuro se va a enviar el saldo en el archivo de transacciones
      /*
      IF v_saldo_rec > 0 then

        apply_onaccount (r_rec.cash_receipt_id,v_saldo_rec,v_status,v_error_message);

            IF v_status = 'S' THEN

                UPDATE xx_ar_adec_receipts
                   SET status = 'S'
                      ,amount_remaining = 0
                      ,last_update_date = sysdate
                      ,last_updated_by = fnd_global.user_id
                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                   AND status = 'P';

                   COMMIT;

            ELSE

                UPDATE xx_ar_adec_receipts
                   SET error_message = v_error_message
                      ,amount_remaining = 0
                      ,last_update_date = sysdate
                      ,last_updated_by = fnd_global.user_id
                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                   AND status = 'P';

                 COMMIT;

            END IF;

      END IF;
      */
      --Fin Comentado KHRONUS/MNazarre 20200218

      EXCEPTION
             WHEN e_rec_exception then NULL;
     END;


    END LOOP;


    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.VALIDATE_APPLICATIONS (-)');


    if v_error_flag = 1 THEN
        p_status := 'W';
        p_error_message := 'Error al valdiar recibos aplicados anteriormente';
    END IF;

EXCEPTION
WHEN OTHERS THEN
  p_status := 'W';
  p_error_message := 'Error OTHERS en Validate_applications. Error: '||sqlerrm;
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.VALIDATE_APPLICATIONS (!)');
END;

FUNCTION Commitear_Validar_trx_generada ( p_nombre_form        IN     VARCHAR2
                                        , p_customer_trx_id           ra_customer_trx.customer_trx_id%TYPE
                                        , p_trx_type                  ra_cust_trx_types%ROWTYPE
                                        , x_msg_error             OUT VARCHAR2)
RETURN BOOLEAN
IS

BEGIN

  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Commitear_Validar_trx_generada (+)');

   arp_process_header.post_commit (  p_nombre_form
                                   , NULL
                                   , p_customer_trx_id
                                   , NULL
                                   , 'Y'
                                   , NULL
                                   , NULL
                                   , p_trx_type.creation_sign
                                   , p_trx_type.allow_overapplication_flag
                                   , p_trx_type.natural_application_only_flag
                                   , NULL);
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Commitear_Validar_trx_generada (-)');

   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_OTHERS_VALIDAR_TRX');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      x_msg_error := fnd_message.get;
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Commitear_Validar_trx_generada: Error General='||sqlerrm);
      RETURN (FALSE);
END Commitear_Validar_trx_generada;


FUNCTION Completar_generar_nro_trx_arg (  p_customer_trx_id           ra_customer_trx.customer_trx_id%TYPE
                                        , p_create_trx_number         VARCHAR2
                                        , x_trx_number            OUT ra_customer_trx.trx_number%TYPE
                                        , x_msg_error             OUT VARCHAR2)
RETURN BOOLEAN
IS
   CURSOR c_trx (p_cust_trx_id NUMBER) IS
   SELECT rct.*
     FROM ra_customer_trx rct
    WHERE customer_trx_id = p_cust_trx_id;
   CURSOR c_tipo_trx (p_cust_trx_type_id NUMBER) IS
   SELECT rctt.TYPE tipo
     FROM ra_cust_trx_types rctt
    WHERE rctt.cust_trx_type_id = p_cust_trx_type_id;
   CURSOR c_batch (p_batch_source_id NUMBER) IS
   SELECT name                             l_name
        , batch_source_type                l_batch_source_type
        , SUBSTR (a.global_attribute2,1,4) l_branch_number
        , SUBSTR (a.global_attribute3,1,1) l_document_letter
        , a.auto_trx_numbering_flag        l_auto_trx_numbering_flag
     FROM ra_batch_sources a
    WHERE batch_source_id = p_batch_source_id;
   l_batch                   c_batch%ROWTYPE;
   l_trx_class               c_tipo_trx%ROWTYPE;
   r_trx                     c_trx%ROWTYPE;
   l_imp_batch_src           NUMBER (15);
   l_so_org_id               NUMBER (3);
   l_point_of_sale           VARCHAR2 (4)                         := NULL;
   l_return_code             VARCHAR2 (30);
   l_ship_to_address_id      NUMBER;
   l_last_trx_date           DATE;
   f_org_id                  NUMBER (3);
   l_prefix                  VARCHAR2 (15);
   l_adv_day                 NUMBER;
   l_adv_days                DATE;
   l_seq_name                VARCHAR2 (30);
   l_seq_no                  NUMBER;
   l_errcode3                VARCHAR2 (30);
   l_trx_number              ra_customer_trx.trx_number%TYPE;
BEGIN
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg (+)');
   /***** Lectura de la cabecera de transacciones, si no existe, es un error *****/
   OPEN c_trx(p_customer_trx_id);
   FETCH c_trx INTO r_trx;
   IF c_trx%NOTFOUND THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                         'El id de transaccion no existe en la tabla de cabeceras: '|| p_customer_trx_id);
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_ID_NO_EXISTE');
      fnd_message.set_token('CUSTOMER_TRX_ID', p_customer_trx_id);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: Se obtuvieron los datos de la cabecera');
   /***** Si la transaccion ya esta completa no se modifica.*****/
   IF r_trx.complete_flag = 'Y' THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                         'Transaccion Completa no se puede modificar:'||
                         ' (customer_trx_id:'|| p_customer_trx_id|| ')');
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_TRX_COMPLETA');
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: La transaccion no estaba completa');
   /***** Lectura del tipo de transaccion, si no existe, es un error *****/
   OPEN c_tipo_trx(r_trx.cust_trx_type_id);
   FETCH c_tipo_trx INTO l_trx_class;
   IF c_tipo_trx%NOTFOUND THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                         'El id del tipo de  transaccion no existe en la tabla de ra_customer_trx_types: '||
                         r_trx.cust_trx_type_id);
      fnd_message.set_name('XX', 'XX_AR_TRX_ID_TRX_TYP_INEX');
      fnd_message.set_token('XX_TRX_TYPE_ID', r_trx.cust_trx_type_id);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                      'El tipo de transaccion existe y es '||l_trx_class.tipo);
   /***** Recupera el batch importado asociado con al Batch manual *****/
   l_imp_batch_src  := NULL;
   l_imp_batch_src  := jl_ar_doc_numbering_pkg.get_imported_batch_source (r_trx.batch_source_id);
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: Despues de obtener el batch_source');
   /***** Obtencion de los datos del Batch Importado *****/
   OPEN c_batch(l_imp_batch_src);
   FETCH c_batch INTO l_batch;
   IF c_batch%NOTFOUND THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: No existe el batch de id='||
                         l_imp_batch_src);
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_INEX');
      fnd_message.set_token('XX_BATCH_ID', l_imp_batch_src);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                      'Despues de Obtener los Datos del Batch l_batch.l_name='||l_batch.l_name);
   /****** INICIO Validaciones relacionadas con el Bacth Source ******/
   IF (l_batch.l_auto_trx_numbering_flag = 'N') THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                         'El Batch: '||l_batch.l_name||
                         ' no esta parametrizado como origen de lote Automatico. Verifique '||
                         ' el seteo del lote');
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_NO_ORI_AUTOM');
      fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   IF (l_batch.l_batch_source_type != 'FOREIGN') THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'El Batch: '|| l_batch.l_name||
                          ' no esta parametrizado como origen de lote Importado. Verifique'||
                          ' el seteo del lote');
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_NO_ORI_IMP');
      fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   IF (l_batch.l_branch_number IS NULL OR l_batch.l_document_letter IS NULL) THEN
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'El Batch: '|| l_batch.l_name||
                          ' tiene en nula la letra o el punto de venta . Verifique el seteo del lote');
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_NO_LETRA');
      fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                      'FIN Validaciones relacionadas con el Batch Source');
   /***** Se recupera el SO_ORGANIZATION_ID *****/
   l_so_org_id            := oe_profile.VALUE ('SO_ORGANIZATION_ID');
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'Recupero el organization_id l_so_org_id='||l_so_org_id);
   /***** Se recupera el la Letra *****/
   l_batch.l_document_letter      := jl_ar_doc_numbering_pkg.get_doc_letter (l_imp_batch_src);
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'Letra recuperada l_batch.l_document_letter='||l_batch.l_document_letter);
   /***** Se recupera el Punto de Venta *****/
   l_point_of_sale        := jl_ar_doc_numbering_pkg.get_branch_number (l_imp_batch_src);
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'Punto de venta l_point_of_sale='||l_point_of_sale);
   /***** Se valida la letra del documento *****/
   l_return_code          := NULL;
   l_return_code          := jl_ar_doc_numbering_pkg.validate_document_letter (l_imp_batch_src
                                                                               ,NULL
                                                                               ,'ARXTWMAI'
                                                                               ,NVL (r_trx.ship_to_site_use_id
                                                                                    ,r_trx.bill_to_site_use_id)
                                                                               ,l_batch.l_document_letter
                                                                               ,l_so_org_id);
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'DEspues de validate_document_letter');
   IF UPPER (l_return_code) != 'SUCCESS' THEN
       fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'Error al validar la letra del documento: '|| l_batch.l_document_letter||
                          ' - Batch:'|| l_imp_batch_src||
                          ' - Ship_to_address_id:'|| NVL (r_trx.ship_to_site_use_id,r_trx.bill_to_site_use_id)||
                          ' - So_Org_Id:'|| l_so_org_id||
                          '(RETURN_CODE='||l_return_code||')');
       fnd_message.set_name('XX', 'XX_AR_TRX_VALD_LETRA');
       fnd_message.set_token('XX_LETRA', l_batch.l_document_letter);
       fnd_message.set_token('XX_BATCH_ID', l_imp_batch_src);
       fnd_message.set_token('XX_SHIP_TO_ADD_ID', l_ship_to_address_id);
       fnd_message.set_token('XX_SO_ORG_ID', l_so_org_id);
       fnd_message.set_token('XX_RETURN_CODE', l_return_code);
       BEGIN
         SELECT con_tax_attribute_name || ' | ' || con_tax_attribute_value
         INTO   x_msg_error
         FROM   jl_ar_ar_doc_letter
         WHERE  document_letter = l_batch.l_document_letter
         AND    rownum = 1
         AND    sysdate between start_date_active and nvl(end_date_active,sysdate);
       EXCEPTION
          WHEN OTHERS THEN x_msg_error := 'Buscando la letra de la FC con el seteo de la localizacion, error: ' || sqlerrm;
       END;
       --x_msg_error := 'XX_AR_TRX_VALD_LETRA: ' || l_batch.l_document_letter || ' - ' || l_return_code; --fnd_message.get;
       x_msg_error := 'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg (llamando a jl_ar_doc_numbering_pkg.validate_document_letter): '||
                          'Error al validar la letra del documento: '|| l_batch.l_document_letter||
                          ' -Batch:'|| l_imp_batch_src||
                          ' -Ship_to_address_id:'|| l_ship_to_address_id||
                          ' -So_Org_Id:'|| l_so_org_id||
                          '(RETURN_CODE='||l_return_code||') Falta setear el "Customer Site Tax Profile" del cliente con los siguientes datos: '  || x_msg_error;
       RETURN (FALSE);
   END IF;
   /** Se valida el tipo de transaccion **/
   l_return_code          := NULL;
   l_return_code          := jl_ar_doc_numbering_pkg.validate_trx_type (  l_imp_batch_src
                                                                         , r_trx.cust_trx_type_id
                                                                         , l_trx_class.tipo
                                                                         , l_batch.l_document_letter
                                                                         , NULL
                                                                         , 'ARXTWMAI');
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'Despues de validar el tipo de transaccion');
   IF UPPER (l_return_code) != 'SUCCESS' THEN
       fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'Error al validar el tipo de transaccion: '|| r_trx.cust_trx_type_id||
                          ' -Batch:'|| l_imp_batch_src||
                          ' -Letra del documento: '|| l_batch.l_document_letter||
                          ' -So_Org_Id:'|| l_so_org_id||
                          '(RETURN_CODE='||l_return_code||')');
       fnd_message.set_name('XX', 'XX_AR_TRX_VALD_TIPO_TRX');
       fnd_message.set_token('XX_TIPO_TRX_ID', r_trx.cust_trx_type_id);
       fnd_message.set_token('XX_BATCH_ID', l_imp_batch_src);
       fnd_message.set_token('XX_DOCUMENT_LETTER', l_batch.l_document_letter);
       fnd_message.set_token('XX_SO_ORG_ID', l_so_org_id);
       fnd_message.set_token('XX_RETURN_CODE', l_return_code);
       x_msg_error := fnd_message.get;
       RETURN (FALSE);
   END IF;
   /* Valida ADVANCE DAYS */
   l_return_code          := NULL;
   l_return_code          := jl_ar_doc_numbering_pkg.validate_Transaction_date ( r_trx.trx_date
                                                                                , l_imp_batch_src);
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'Despues de validar los advance days');
   IF UPPER (l_return_code) != 'SUCCESS' THEN
       l_last_trx_date := JL_AR_DOC_NUMBERING_PKG.get_last_trx_date(l_imp_batch_src);
       fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'Despues de get_last_trx_date');
       l_adv_day       := TO_NUMBER(nvl(JL_AR_DOC_NUMBERING_PKG.get_adv_days(l_imp_batch_src),0));
       l_adv_days      := SYSDATE + l_adv_day;
       fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'Ingrese una fecha de transaccion entre '||l_last_trx_date||
                          ' y '|| l_adv_days||
                          ' para el origen de transaccion '|| l_batch.l_name);
       fnd_message.set_name('XX', 'XX_AR_TRX_FECHAS_INVALIDAS');
       fnd_message.set_token('XX_LAST_TRX_DATE', l_last_trx_date);
       fnd_message.set_token('XX_ADV_DAYS', l_adv_days);
       fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
       x_msg_error := fnd_message.get;
       RETURN (FALSE);
   END IF;
   /***** Actualizacion de la Ultima Fecha del Batch Source  *****/
   l_last_trx_date        := NULL;
   l_last_trx_date        := jl_ar_doc_numbering_pkg.get_last_trx_date (l_imp_batch_src);
   IF (NVL (l_last_trx_date ,TO_DATE ('01-01-1901','DD-MM-YYYY')) <= r_trx.trx_date) THEN
      UPDATE ra_batch_sources
         SET global_attribute4 = fnd_date.date_to_canonical (r_trx.trx_date)
       WHERE batch_source_id   = TO_CHAR (l_imp_batch_src);
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: Despues del update del batch');
   ELSE
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'La fecha de transaccion: '|| r_trx.trx_date||
                          ' es menor a la ultima fecha registrada en el batch: '||l_last_trx_date||
                          ' verifique el seteo del batch ');
      fnd_message.set_name('XX', 'XX_AR_TRX_FECHA_MENOR_BATCH');
      fnd_message.set_token('XX_TRX_DATE', r_trx.trx_date);
      fnd_message.set_token('XX_LAST_DATE', l_last_trx_date);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   /***** Generacion del numero de la transaccion (TRX_NUMBER) *****/
   /***** Se recupera la organnizacion *****/
   fnd_profile.get ( 'ORG_ID' ,f_org_id);
   if f_org_id is null then
       f_org_id := mo_global.get_current_org_id;
   end if;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                      'Organizacion recuperada f_org_id='||f_org_id);
   /* Se arma el nombre de la sequencia relacionada con el Batch*/
   l_seq_name             :=    'JL_ZZ_TRX_NUM_' --'RA_TRX_NUMBER_'
                                  || TO_CHAR (l_imp_batch_src)
                                  || '_'
                                  || f_org_id
                                  || '_S';
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                       'Nombre de la secuencia l_seq_name='||l_seq_name);
   IF (NVL (p_create_trx_number,'N') = 'Y') THEN
      /* Se recupera el siguiente numero de la secuencia*/
      jl_zz_ar_library_1_pkg.get_next_seq_number ( l_seq_name
                                                   , l_seq_no
                                                   , 1
                                                   , l_errcode3);
      /* Si no existen errores se formatea.*/
      IF l_errcode3 = 0 THEN
         l_trx_number      :=    l_batch.l_document_letter
                                     || '-'
                                     || l_point_of_sale
                                     || '-'
                                     || LPAD (TO_CHAR (l_seq_no),8,'0');
      ELSE
         fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                             'Error al obtener el proximo numero de la sequencia: '|| l_seq_name);
         fnd_message.set_name('XX', 'XX_AR_TRX_ERR_NEXT_SEQ');
         fnd_message.set_token('XX_L_SEQ_NAME', l_seq_name);
         x_msg_error := fnd_message.get;
         RETURN (FALSE);
      END IF;
      /* Valido el prefijo del numero generado.*/
      l_prefix          := NVL (SUBSTR (l_trx_number,1,6),'000000');
      IF (   NVL ( l_batch.l_document_letter ,'^&*~')|| '-'|| NVL ( l_point_of_sale ,'~')) != l_prefix THEN
         fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                             'Error al validar el prefijo el numero generado: '|| l_trx_number);
         fnd_message.set_name('XX', 'XX_AR_TRX_ERR_PREFIJO');
         fnd_message.set_token('XX_TRX_NUMBER', l_trx_number);
         x_msg_error := fnd_message.get;
         RETURN (FALSE);
      END IF;
      /* Se devuelve el numero generado*/
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                          'Numero de transaccion'||l_trx_number);
      x_trx_number := l_trx_number;
      BEGIN
         UPDATE ra_customer_trx
            SET trx_number      = l_trx_number
              , complete_flag   = 'Y'
          WHERE customer_trx_id = p_customer_trx_id;
         UPDATE ar_payment_schedules
            SET trx_number      = l_trx_number
          WHERE customer_trx_id = p_customer_trx_id;
         fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: Realizo los updates');
      EXCEPTION
         WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg: '||
                                'Error al actualizar el numero de la transaccion:'|| l_trx_number||
                                ' para las tablas ra_customer_trx y ar_payment_schedules '||
                                'para el customer_trx_id: '|| p_customer_trx_id||
                                ' ERROR:'|| SQLERRM);
            fnd_message.set_name('XX', 'XX_AR_TRX_ERR_GEN_NRO');
            fnd_message.set_token('XX_TRX_NUMBER', l_trx_number);
            fnd_message.set_token('XX_CUSTOMER_TRX_ID', p_customer_trx_id);
            fnd_message.set_token('XX_SQLERRM', SQLERRM);
            x_msg_error := fnd_message.get;
            RETURN (FALSE);
      END;
   END IF;
   CLOSE c_batch;
   CLOSE c_trx;
   CLOSE c_tipo_trx;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Completar_generar_nro_trx_arg (-)');
   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
      IF c_trx%ISOPEN THEN
         CLOSE c_trx;
      END IF;
      IF c_tipo_trx%ISOPEN THEN
         CLOSE c_tipo_trx;
      END IF;
      IF c_batch%ISOPEN THEN
         CLOSE c_batch;
      END IF;
      fnd_message.set_name('XX', 'XX_AR_TRX_OTHERS_GEN_NRO');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      x_msg_error := fnd_message.get;
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.Commitear_Validar_trx_generada: Error General='||sqlerrm);
      RETURN (FALSE);
END Completar_generar_nro_trx_arg;

PROCEDURE create_trx(p_cash_receipt_id IN NUMBER
                    ,p_batch_source_id IN NUMBER
                    ,p_amount          IN NUMBER
                    ,p_customer_trx_id OUT NUMBER
                    ,p_status          OUT VARCHAR2
                    ,p_error_message   OUT VARCHAR2) IS

v_cr_rec ar_cash_receipts%ROWTYPE;

v_cust_trx_type_id NUMBER;
v_batch_source_name VARCHAR2(50);
v_bill_to_address_id NUMBER;
v_ship_to_address_id NUMBER;
v_inv_org_id number;
v_set_of_books_id number;
v_term_id NUMBER;
v_memo_line_id NUMBER;
v_amount NUMBER;
v_gdf_attr2 VARCHAR2(150);
v_gdf_attr3 VARCHAR2(150);
v_cust_trx_type VARCHAr2(20);
e_cust_exception EXCEPTION;
v_trx_number VARCHAR2(20);
l_customer_trx_id number;


v_conc_phase                   VARCHAR2(50);
v_conc_status                  VARCHAR2(50);
v_conc_dev_phase               VARCHAR2(50);
v_conc_dev_status              VARCHAR2(50);
v_conc_message                 VARCHAR2(250);
v_message                      VARCHAR2(1000);
v_request_id                   NUMBER;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_TRX (+)');

    BEGIN

          SELECT *
            INTO v_cr_rec
            FROM ar_cash_receipts
           WHERE cash_receipt_id = p_cash_receipt_id;

    EXCEPTION
     WHEN OTHERS THEN
       p_error_message := 'Error al obtener datos del recibo';
       RAISE e_cust_exception;
    END;

    BEGIN
        select name
        into v_batch_source_name
        from ra_batch_sources_all
        where batch_source_id = p_batch_source_id;
    EXCEPTION
     WHEN OTHERS THEN
       p_error_message := 'Error al obtener Nombre Origen de Comprobante ID: '||p_batch_source_id;
       RAISE e_cust_exception;
    END;

    fnd_file.put_line(fnd_file.log,'Origen: '||v_batch_source_name);

    BEGIN

        select default_inv_trx_type,rctt.type
        into v_cust_trx_type_id,v_cust_trx_type
        FROM ra_batch_sources rbs
        ,ra_cust_trx_types rctt
        where rbs.batch_source_id = p_batch_source_id
        and rbs.default_inv_trx_type is not null
        and rbs.default_inv_trx_type = rctt.cust_trx_type_id;

    EXCEPTION
     WHEN OTHERS THEN
        p_error_message := 'Error al obtener Tipo de Transaccion asociado al origen ID: '||p_batch_source_id||'. Error: '||SQLERRM;
        RAISE e_cust_exception;
    END;

    IF v_cust_trx_type = 'CM' THEN
    v_term_id := null;
    v_amount := -1*NVL(p_amount,v_cr_rec.amount);
    else
    v_term_id := g_term_id;
    v_amount := NVL(p_amount,v_cr_rec.amount);
    END IF;

    BEGIN
       SELECT inventory_organization_id
             ,set_of_books_id
         INTO v_inv_org_id
             ,v_set_of_books_id
         FROM FINANCIALS_SYSTEM_PARAMS_ALL
        WHERE org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'));

     EXCEPTION
       WHEN no_data_found THEN
         p_error_message := 'No se encontraron Parametros de la '    ||
                         'Organizacion para la Unidad Operativa ' ||
                         'en las Opciones Financieras';
         RAISE e_cust_exception;
       WHEN others THEN
         p_error_message := 'Error buscando Parametros de la '       ||
                         'Organizacion para la Unidad Operativa ' ||
                         'en las Opciones Financieras. '          ||
                         SQLERRM;
         RAISE e_cust_exception;
     END;

      BEGIN
                    SELECT hcas.cust_acct_site_id
                      INTO v_ship_to_address_id
                      FROM hz_cust_acct_sites hcas
                          ,hz_cust_site_uses hcsu
                     WHERE hcas.cust_account_id = v_cr_rec.pay_from_customer
                       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
                       and hcsu.site_use_code = 'SHIP_TO'
                       and hcsu.primary_flag = 'Y';
      EXCEPTION
      WHEN OTHERS THEN
            p_error_message := 'Error al obtener el domicilio primario de Envio. Error: '||SQLERRM;
            raise e_cust_exception;
      END;

      BEGIN

                    SELECT hcas.cust_acct_site_id
                      INTO v_bill_to_address_id
                      FROM hz_cust_acct_sites hcas
                          ,hz_cust_site_uses hcsu
                          ,hz_cust_accounts hca
                     WHERE hca.cust_account_id = hcas.cust_account_id
                       and hcas.cust_account_id = v_cr_rec.pay_from_customer
                       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
                       and hcsu.site_use_code = 'BILL_TO'
                       and hcsu.primary_flag = 'Y';

      EXCEPTION
        WHEN OTHERS THEN
            p_error_message := 'Error al obtener el domicilio primario de Facturacion. Error: '||SQLERRM;
            raise e_cust_exception;
      END;

      BEGIN

      SELECT global_attribute1,global_attribute2,v_memo_line_id
      into v_gdf_attr2,v_gdf_attr3,v_memo_line_id
      from ar_memo_lines
      /*Modificado Khronus/E.Sly 20180718*/
      --where memo_line_id = g_memo_line_id;
      where name = g_memo_line;
      /*Fin Modificado Khronus/E.Sly 20180718*/

      EXCEPTION
       WHEN OTHERS THEN
         p_error_message := 'Error al obtener datos de la Linea de Nota. Error: '||SQLERRM;
         raise e_cust_exception;
      END;

      delete ra_interface_lines_all
      where interface_line_context = 'ADECUENTAS'
      and batch_source_name = v_batch_source_name;

    INSERT INTO ra_interface_lines_all
               (interface_line_context
               ,interface_line_attribute1
               ,interface_line_attribute2
               ,batch_source_name
               ,set_of_books_id
               ,line_type
               ,description
               ,currency_code
               ,amount
               ,cust_trx_type_id
               ,orig_system_bill_customer_id
               ,orig_system_bill_address_id
               ,orig_system_ship_customer_id
               ,orig_system_ship_address_id
               ,orig_system_sold_customer_id
               ,conversion_type
               ,conversion_date
               ,trx_date
               ,gl_date
               ,line_number
               ,memo_line_id
               ,quantity_ordered
               ,unit_selling_price
               ,primary_salesrep_id
               ,created_by
               ,creation_date
               ,last_updated_by
               ,last_update_date
               ,last_update_login
               ,org_id
               ,term_id
               ,line_gdf_attr_category
               ,line_gdf_attribute2
               ,line_gdf_attribute3
               ,warehouse_id)
               values
               ('ADECUENTAS'
               ,p_cash_receipt_id
               ,v_cust_trx_type
               ,v_batch_source_name
               ,v_set_of_books_id
               ,'LINE'
               ,'Transaccion Adecuentas para Recibo: '||v_cr_rec.receipt_number
               ,v_cr_rec.currency_code
               ,v_amount
               ,v_cust_trx_type_id
               ,v_cr_rec.pay_from_customer
               ,v_bill_to_address_id
               ,v_cr_rec.pay_from_customer
               ,v_ship_to_address_id
               ,v_cr_rec.pay_from_customer
               ,'Corporate'
               ,v_cr_rec.receipt_date
               ,v_cr_rec.receipt_date
               ,TRUNC(sysdate)
               ,1
               ,v_memo_line_id
               ,1
               ,v_amount
               ,-3
               ,fnd_global.user_id
               ,SYSDATE
               ,fnd_global.user_id
               ,SYSDATE
               ,fnd_global.login_id
               ,fnd_global.org_id
               ,v_term_id
               ,'JL.AR.ARXTWMAI.LINES'
               ,v_gdf_attr2
               ,v_gdf_attr3
               ,v_inv_org_id);

     COMMIT;
             /*Ejecuto Autoinvoice*/
        v_request_id := fnd_request.submit_request(
                                                     'AR'
                                                   , 'RAXMTR'
                                                   , ''
                                                   , ''
                                                   , FALSE
                                                   , 1                  -- Argument 1 Number of Instances
                                                   , p_batch_source_id  -- Argument 3 Batch Source Id
                                                   , v_batch_source_name-- Argument 4 Batch Source Name
                                                   , TO_CHAR(v_cr_rec.receipt_date,'YYYY/MM/DD HH24:MI:SS')-- Argument 5 Default Date
                                                   , NULL               -- Argument 6 Transaction Flexfield
                                                   , NULL               -- Argument 7 Transaction Type
                                                   , NULL               -- Argument 8 (Low) Bill To Customer Number
                                                   , NULL               -- Argument 9 (High) Bill To Customer Number
                                                   , NULL               -- Argument 10 (Low) Bill To Customer Name
                                                   , NULL               -- Argument 11 (High) Bill To Customer Name
                                                   , NULL               -- Argument 12 (Low) GL Date
                                                   , NULL               -- Argument 13 (High) GL Date
                                                   , NULL               -- Argument 14 (Low) Ship Date
                                                   , NULL               -- Argument 15 (High) Ship Date
                                                   , NULL               -- Argument 16 (Low) Transaction Number
                                                   , NULL               -- Argument 17 (High) Transaction Number
                                                   , NULL               -- Argument 18 (Low) Sales Order Number
                                                   , NULL               -- Argument 19 (High) Sales Order Number
                                                   , NULL               -- Argument 20 (Low) Invoice Date
                                                   , NULL               -- Argument 21 (High) Invoice Date
                                                   , NULL               -- Argument 22 (Low) Ship To Customer Number
                                                   , NULL               -- Argument 23 (High) Ship To Customer Number
                                                   , NULL               -- Argument 24 (Low) Ship To Customer Name
                                                   , NULL               -- Argument 25 (High) Ship To Customer Name
                                                   , 'Y'                -- Argument 26 Base Due Date on Trx Date
                                                   , NULL
                                                   ,nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID')));             -- Argument 27 Due Date Adjustment Days

          IF v_request_id = 0 THEN
            v_message := fnd_message.get;
            p_error_message := 'Error ejecutando el concurrente Argentine Receivables Autoinvoice Master Program. ' || v_message || ' ' || sqlerrm;
            RAISE e_cust_exception;
          END IF;

          COMMIT;

          IF NOT fnd_concurrent.wait_for_request(
                                  v_request_id
                                 ,10
                                 ,18000
                                 ,v_conc_phase
                                 ,v_conc_status
                                 ,v_conc_dev_phase
                                 ,v_conc_dev_status
                                 ,v_conc_message) THEN
            v_message := fnd_message.get;
            p_error_message := 'Error ejecutando FND_REQUEST.WAIT_FOR_REQUEST. ' || v_message || ' ' || SQLERRM;
            RAISE e_cust_exception;
          END IF;

          IF v_conc_dev_phase != 'COMPLETE' OR v_conc_dev_status != 'NORMAL' THEN
            v_message := fnd_message.get;
            p_error_message := 'Error en la ejecucion de la solicitud ' || TO_CHAR(v_request_id) || '. ' || v_message || ' ' || SQLERRM;
            RAISE e_cust_exception;
          END IF;

     /*Obtenemos el customer_trx_id*/
     BEGIN
        select rct.customer_trx_id,rct.trx_number
          into l_customer_trx_id,v_trx_number
          from ra_customer_trx rct
              ,ra_customer_trx_lines rctl
         where rct.customer_trx_id = rctl.customer_trx_id
           and rctl.interface_line_context = 'ADECUENTAS'
           and rctl.interface_line_attribute1 = TO_CHAR(p_cash_receipt_id)
           and rct.batch_source_id = p_batch_source_id;

     EXCEPTION
      WHEN OTHERS THEN
        l_customer_trx_id := null;
        p_status := 'W';
        p_error_message := 'Error al obtener customer_trx_id';
        fnd_file.put_line(fnd_file.log,p_error_message);
        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_TRX (!)');
     END;

     IF p_status IS NULL THEN
       p_status := 'S';
       p_customer_trx_id := l_customer_trx_id;
       fnd_file.put_line(fnd_file.log,'Numero de Transaccion Creado: '||v_trx_number);
       fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_TRX (-)');
     END IF;

EXCEPTION
 WHEN e_cust_exception THEN
  p_status := 'W';
  fnd_file.put_line(fnd_file.log,p_error_message);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_TRX (!)');
 WHEN OTHERS THEN
  p_status := 'W';
  p_error_message := 'Error OTHERS en create_trx: '||SQLERRM;
  fnd_file.put_line(fnd_file.log,p_error_message);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_TRX (!)');
END;



PROCEDURE create_remittance(p_status            OUT VARCHAR2
                           ,p_error_message     OUT VARCHAR2
                           ,p_remit_number      IN  VARCHAR2
                           ,p_cash_receipt_id   IN NUMBER) IS

v_cr_rec AR_CASH_RECEIPTS_ALL%ROWTYPE;

v_batch_name           VARCHAR2(20);

v_batch_id         NUMBER;
v_bank_branch_id NUMBER;
v_batch_sourcE_id NUMBER;

v_conc_phase                   VARCHAR2(50);
v_conc_status                  VARCHAR2(50);
v_conc_dev_phase               VARCHAR2(50);
v_conc_dev_status              VARCHAR2(50);
v_conc_message                 VARCHAR2(250);
v_message                      VARCHAR2(1000);
v_request_id                   NUMBER;

e_cust_exception EXCEPTION;

BEGIN

        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_REMITTANCE (+)');

        fnd_file.put_line(fnd_file.log,'Buscando Remesa: '||p_remit_number);
        BEGIN

            SELECT aba.batch_id
              INTO v_batch_id
              FROM ar_batches aba
              ,ar_batch_sources absa
            WHERE  aba.type = 'REMITTANCE'
            and aba.batch_source_id = absa.batch_source_id
            and absa.name = 'AUTOMATIC RECEIPTS'
            and aba.name = p_remit_number
            and p_remit_number IN (select remit_number
                                     from xx_ar_adec_receipts
                                    where cash_receipt_id != p_cash_receipt_id); --La remesa se haya creado en adecuentas.

        EXCEPTION
         WHEN OTHERS THEN
          v_batch_id := NULL;
        END;

        fnd_file.put_line(fnd_file.log,'ID Remesa: '||v_batch_id);

        IF v_batch_id is null THEN

        /*creamos la remesa*/
            fnd_file.put_line(fnd_file.log,'Creando Remesa...');

            fnd_file.put_line(fnd_file.log,'Obteniendo datos del recibo');
            BEGIN

                SELECT *
                  INTO v_cr_rec
                  FROM ar_cash_receipts_all
                WHERE cash_receipt_id = p_cash_receipt_id;
            EXCEPTION
             WHEN OTHERS THEN
               p_error_message := 'Error al obtener datos de recibo para crear Remesa';
               RAISE e_cust_exception;
            END;

          select AR_BATCHES_S.nextval
            into v_batch_id
            from dual;

          select ba.bank_branch_id
          into     v_bank_branch_id
          from     ap_bank_accounts ba
          where     ba.bank_account_id = v_cr_rec.remittance_bank_account_id;

          update ar_batch_sources
          set      last_batch_num = nvl(last_batch_num,0)+1
          where     name='AUTOMATIC RECEIPTS';

          select  batch_source_id
          into    v_batch_source_id
          from ar_batch_sources
          where name='AUTOMATIC RECEIPTS';

          insert into ar_batches_all(batch_id
                                 ,remittance_bank_branch_id
                            ,remit_method_code
                            ,batch_source_id
                            ,name
                            ,comments
                            ,request_id
                            ,set_of_books_id
                            ,type
                            ,batch_applied_status
                            ,currency_code
                            ,remittance_bank_account_id
                            ,batch_date
                            ,gl_date
                            ,created_by
                            ,creation_date
                            ,last_updated_by
                            ,last_update_date
                            ,last_update_login)
                    values
                            (v_batch_id
                            ,v_bank_branch_id
                            ,'STANDARD'
                            ,v_batch_source_id
                            ,p_remit_number
                            ,'Remesa Adecuentas: '||p_remit_number
                            ,fnd_global.conc_request_id
                            ,v_cr_rec.set_of_books_id
                            ,'REMITTANCE'
                            ,'COMPLETED_CREATION'
                            ,v_cr_rec.currency_code
                            ,v_cr_rec.remittance_bank_account_id
                            ,trunc(v_cr_rec.receipt_date)
                            ,TRUNC(sysdate)
                            ,fnd_global.user_id
                            ,sysdate
                            ,fnd_global.user_id
                            ,sysdate
                            ,fnd_global.login_id
                            );

              commit;

              fnd_file.put_line(fnd_file.log,'Remesa Creada. ID: '||v_batch_id);
        ELSE
            p_error_message := 'Ya existe el lote de Remesa';
            RAISE e_cust_exception;
        END IF;

        IF v_batch_id is not null then

              Update ar_cash_receipts
                 Set selected_remittance_batch_id = v_batch_id
                   , last_update_date  = sysdate
                   , last_updated_by   = fnd_global.user_id
                   , last_update_login = fnd_global.login_id
               Where cash_receipt_id   = p_cash_receipt_id;

               IF sql%rowcount != 1 THEN
                   p_error_message := 'El Recibo no pudo ser asociado a la nueva remesa';
                   RAISE e_cust_exception;
               ELSE
                   COMMIT;
               END IF;

               /*Correr el proceso de seleccion*/

             update ar_batches
                set batch_applied_status = 'STARTED_APPROVAL'
                   ,control_count = NVL(control_count,0) + 1
                   ,control_amount = NVL(control_amount,0) + v_cr_rec.amount
              where batch_id = v_batch_id;

              COMMIT;

                  v_request_id := fnd_request.submit_request( 'AR'
                                                            , 'ARZCAR_REMIT'
                                                            , ''
                                                            , ''
                                                            , FALSE
                                                            , 'REMIT'       -- Parametro 1
                                                            , NULL
                                                            , NULL
                                                            , 'N'
                                                            , 'Y'
                                                            , 'Y'
                                                            , v_batch_id
                                                            , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
                                                            , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
                                                            , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
                                                            , NULL, NULL, NULL, NULL, NULL);


                  IF v_request_id = 0 THEN
                    v_message := fnd_message.get;
                    p_error_message := 'Error ejecutando el concurrente Programa de Creación de Remesas Automáticas. ' || v_message || ' ' || sqlerrm;
                    RAISE e_cust_exception;
                  END IF;

                  COMMIT;

                  IF NOT fnd_concurrent.wait_for_request(
                                          v_request_id
                                         ,10
                                         ,18000
                                         ,v_conc_phase
                                         ,v_conc_status
                                         ,v_conc_dev_phase
                                         ,v_conc_dev_status
                                         ,v_conc_message) THEN
                    v_message := fnd_message.get;
                    p_error_message := 'Error ejecutando FND_REQUEST.WAIT_FOR_REQUEST. ' || v_message || ' ' || SQLERRM;
                    RAISE e_cust_exception;
                  END IF;

                  IF v_conc_dev_phase != 'COMPLETE' OR v_conc_dev_status != 'NORMAL' THEN
                    v_message := fnd_message.get;
                    p_error_message := 'Error en la ejecucion de la solicitud ' || TO_CHAR(v_request_id) || '. ' || v_message || ' ' || SQLERRM;
                    RAISE e_cust_exception;
                  END IF;

        ELSE
            p_error_message := 'El lote de Remesa no se ha creado';
            RAISE e_cust_exception;
        END IF;

        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_REMITTANCE (-)');

EXCEPTION
 WHEN e_cust_exception THEN
    p_status := 'W';
    fnd_file.put_line(fnd_file.log,p_error_message);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_REMITTANCE (!)');
 WHEN OTHERS THEN
    p_status := 'W';
    p_error_message := 'Error general. Error: '||SQLERRM;
    fnd_file.put_line(fnd_file.log,p_error_message);
    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_REMITTANCE (!)');
END;

PROCEDURE Create_cash_receipt  (p_currency_code              IN VARCHAR2
                               ,p_amount                     IN NUMBER
                               ,p_pay_from_customer          IN NUMBER
                               ,p_receipt_number             IN VARCHAR2
                               ,p_receipt_date               IN DATE
                               ,p_maturity_date              IN DATE
                               ,p_comments                   IN VARCHAR2
                               ,p_exchange_rate_type         IN VARCHAR2
                               ,p_exchange_rate              IN NUMBER
                               ,p_exchange_date              IN DATE
                               ,p_batch_id                   IN NUMBER
                               ,p_remittance_bank_account_id IN NUMBER
                               ,p_remit_bank_acct_use_id     IN NUMBER
                               ,p_customer_site_use_id       IN NUMBER
                               ,p_receipt_method_id          IN NUMBER
                               ,p_certif_number              IN VARCHAR2
                               ,p_certif_date                IN DATE
                               ,p_regime_code                IN VARCHAR2
                               ,p_cr_id                     OUT NUMBER
                               ,p_status                    OUT VARCHAR2
                               ,p_error_message             OUT VARCHAR2) IS


l_cr_id NUMBER;
l_ps_id NUMBER;
l_row_id VARCHAR2(50);

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_CASH_RECEIPT (+)');

   ARP_PROC_RECEIPTS2.insert_cash_receipt(  p_currency_code               => p_currency_code,
                                            p_amount                      => p_amount,
                                            p_pay_from_customer           => p_pay_from_customer,
                                            p_receipt_number              => p_receipt_number,
                                            p_receipt_date                => p_receipt_date,
                                            p_gl_date                     => TRUNC(sysdate), --TRUNC(p_receipt_date),
                                            p_maturity_date               => p_maturity_date,
                                            p_comments                    => p_comments,
                                            p_exchange_rate_type          => p_exchange_rate_type,
                                            p_exchange_rate               => p_exchange_rate,
                                            p_exchange_date               => p_exchange_date,
                                            p_batch_id                    => p_batch_id,
                                            p_attribute_category          => NULL,
                                            p_attribute1                  => NULL,
                                            p_attribute2                  => NULL,
                                            p_attribute3                  => NULL,
                                            p_attribute4                  => NULL,
                                            p_attribute5                  => NULL,
                                            p_attribute6                  => NULL,
                                            p_attribute7                  => NULL,
                                            p_attribute8                  => NULL,
                                            p_attribute9                  => NULL,
                                            p_attribute10                 => NULL,
                                            p_attribute11                 => NULL,
                                            p_attribute12                 => NULL,
                                            p_attribute13                 => NULL,
                                            p_attribute14                 => NULL,
                                            p_attribute15                 => NULL,
                                            p_override_remit_account_flag => 'N',
                                            p_remittance_bank_account_id  => p_remit_bank_acct_use_id,--p_remittance_bank_account_id,
                                            p_customer_bank_account_id    => NULL,
                                            p_customer_site_use_id        => p_customer_site_use_id,
                                            p_customer_receipt_reference  => NULL,
                                            p_factor_discount_amount      => NULL,
                                            p_deposit_date                => p_maturity_date,
                                            p_receipt_method_id           => p_receipt_method_id,
                                            p_doc_sequence_value          => NULL,
                                            p_doc_sequence_id             => NULL,
                                            p_ussgl_transaction_code      => NULL,
                                            p_vat_tax_id                  => NULL,
                                            p_anticipated_clearing_date   => NULL,
                                            p_customer_bank_branch_id     => NULL,
                                            p_postmark_date               => NULL,
                                            p_global_attribute1           => NULL,
                                            p_global_attribute2           => NULL,
                                            p_global_attribute3           => NULL,
                                            p_global_attribute4           => p_certif_number,
                                            p_global_attribute5           => TO_CHAR(p_certif_date,'YYYY/MM/DD HH24:MI:SS'),
                                            p_global_attribute6           => p_regime_code,
                                            p_global_attribute7           => NULL,
                                            p_global_attribute8           => NULL,
                                            p_global_attribute9           => NULL,
                                            p_global_attribute10          => NULL,
                                            p_global_attribute11          => NULL,
                                            p_global_attribute12          => NULL,
                                            p_global_attribute13          => NULL,
                                            p_global_attribute14          => NULL,
                                            p_global_attribute15          => NULL,
                                            p_global_attribute16          => NULL,
                                            p_global_attribute17          => NULL,
                                            p_global_attribute18          => NULL,
                                            p_global_attribute19          => NULL,
                                            p_global_attribute20          => NULL,
                                            p_global_attribute_category   => 'JL.AR.ARXRWMAI.RGW_FOLDER',
                                            p_issuer_name                 => NULL,
                                            p_issue_date                  => NULL,
                                            p_issuer_bank_branch_id       => NULL,
                                            p_application_notes           => null,
                                            p_cr_id                       => l_cr_id,
                                            p_ps_id                       => l_ps_id,
                                            p_row_id                      => l_row_id,
                                            p_form_name                   => 'RAPI',
                                            p_form_version                => '1.0',
                                            p_called_from                 => NULL
                                           );

     IF l_cr_id IS NULL THEN
      p_status := 'W';
      p_error_message := 'Error al crear recibo. ERROR: '||SQLERRM;
      fnd_file.put_line(fnd_file.log,p_error_message);
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_CASH_RECEIPT (!)');
     ELSE
      p_status := 'S';
      p_cr_id := l_cr_id;
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_CASH_RECEIPT (-)');
     END IF;

EXCEPTION
WHEN OTHERS THEN
p_status := 'W';
p_error_message := 'Error al insertar recibo. ERROR: '||SQLERRM;
fnd_file.put_line(fnd_file.log,p_error_message);
fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_CASH_RECEIPT (!)');
END;

PROCEDURE create_batch (p_batch_source_id   IN NUMBER
                       ,p_batch_name        IN VARCHAR2
                       ,p_currency_code     IN VARCHAR2
                       ,p_amount            IN NUMBER
                       ,p_date              IN DATE
                       ,p_exchange_rate     IN NUMBER
                       ,p_exchange_date     IN DATE
                       ,p_comments          IN VARCHAR2
                       ,p_control_count     IN NUMBER
                       ,p_customer_id       IN NUMBER
                       ,p_site_use_id       IN NUMBER
                       ,p_collector_id      IN NUMBER
                       ,p_batch_id          OUT NUMBER
                       ,p_status            OUT VARCHAR2
                       ,p_error_message     OUT VARCHAR2) IS

  v_batch_id             NUMBER;
  v_batch_name           VARCHAR2(20);
  v_batch_applied_status VARCHAR2(250);
  v_rowid                 VARCHAR2(250);

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_BATCH (+)');

    v_batch_name := p_batch_name;

    ARP_RW_BATCHES_PKG.insert_manual_batch(
                        p_row_id                     => v_rowid,
                        p_batch_type                 => 'MANUAL_REGULAR',
                        p_batch_id                   => v_batch_id,
                        p_batch_source_id            => p_batch_source_id,
                        p_batch_date                 => p_date,
                        p_currency_code              => p_currency_code,
                        p_name                       => v_batch_name,
                        p_comments                   => p_comments,
                        p_control_amount             => p_amount,
                        p_control_count              => p_control_count,
                        p_deposit_date               => p_date,
                        p_exchange_rate_type         => 'User',
                        p_exchange_rate              => p_exchange_rate,
                        p_exchange_date              => p_exchange_date,
                        p_gl_date                    => TRUNC(SYSDATE),
                        p_receipt_class_id           => NULL,
                        p_receipt_method_id          => NULL,
                        p_remittance_bank_account_id => NULL,
                        p_remittance_bank_branch_id  => NULL,
                        p_attribute_category         => 'AR',
                        p_attribute1                 => p_customer_id,
                        p_attribute2                 => p_site_use_id,
                        p_attribute3                 => NULL,
                        p_attribute4                 => NULL,
                        p_attribute5                 => NULL,
                        p_attribute6                 => NULL,
                        p_attribute7                 => NULL,
                        p_attribute8                 => NULL,
                        p_attribute9                 => NULL,
                        p_attribute10                => NULL,
                        p_attribute11                => NULL,
                        p_attribute12                => p_collector_id,
                        p_attribute13                => NULL,
                        p_attribute14                => NULL,
                        p_attribute15                => NULL,
                        p_batch_applied_status       => v_batch_applied_status,
                        p_module_name                => NULL,
                        p_module_version             => NULL);

        p_batch_id := v_batch_id;
        p_status := 'S';

        fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_BATCH (-)');

EXCEPTION
 WHEN OTHERS THEN
  p_status := 'W';
  p_error_message := 'Error al crear Cabecera de Lote. ERROR: '||SQLERRM;
  fnd_file.put_line(fnd_file.log,p_error_message);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.CREATE_BATCH (!)');
END;

FUNCTION check_receipts_status(p_batch_name IN VARCHAR2) RETURN BOOLEAN IS


CURSOR c_receipts IS
select *
from xx_ar_adec_receipts
where status = 'E'
and batch_name = p_batch_name
and request_id = fnd_global.conc_request_id;

v_count NUMBER;

BEGIN

    v_count := 0;

    FOR r_rec IN c_receipts LOOP

        v_count := v_count +1;

    END LOOP;

    IF v_count > 0 THEN
      RETURN (FALSE);
    END IF;

   RETURN (TRUE);
EXCEPTION
 WHEN OTHERS THEN
   RETURN (FALSE);
END;

PROCEDURE process_receipts (p_status         OUT VARCHAR2
                           ,p_error_message  OUT VARCHAR2
                           ,p_batch_source_id IN NUMBER) IS

CURSOR c_headers IS
select *
from bolinf.xx_ar_adec_batches
where status = 'N'
and org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'))
and request_id is null;

Cursor c_applications (p_batch_name VARCHAR2
                      ,p_party_id NUMBER) IS
select xaaa.adec_application_id
,xaaa.batch_name
,xaaa.party_id
,xaaa.trx_number
,xaaa.currency_code
,NVL(xaaa.amount_remaining,amount) amount
,xaaa.payment_schedule_id
,xaaa.comments
from bolinf.xx_ar_adec_applications xaaa
where xaaa.status = 'N'
and xaaa.request_id is null
and xaaa.org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'))
and xaaa.batch_name = p_batch_name
and xaaa.party_id = p_party_id
and xaaa.payment_schedule_id IS NOT NULL
order by amount;

Cursor c_rec (p_batch_name VARCHAR2
             ,p_party_id NUMBER
             ,p_status VARCHAR2) IS
select adec_receipt_id
,batch_name
,party_id
,row_type
,doc_type
,bank_reference
,remit_number
,receipt_number
,receipt_date
,due_date
,receipt_method_id
,bank_account_id
,currency_code
,NVL(amount_remaining,amount) amount
,comments
,certif_number
,certif_date
,regime_code
,cash_receipt_id
from bolinf.xx_ar_adec_receipts
where ((status = p_status and p_status = 'P' and row_type IN ('REC','AWT','DEB') and doc_type != 'ACR') OR (status = p_status and p_status = 'N'))
and batch_name = p_batch_name
and org_id = nvl(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'))
and party_id = p_party_id
order by amount;

v_count NUMBER;
v_batch_exists NUMBER;
v_batch_exists_p NUMBER;
v_cash_receipt_id NUMBER;
v_acr_exists NUMBER;
v_appl_exists NUMBER;

v_customer_id NUMBER;
v_batch_id NUMBER;
l_cr_id NUMBER;
v_remit_bank_acct_use_id NUMBER;


v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);
x_return_status VARCHAR2(100);

e_rec_exception EXCEPTION;
e_batch_exception EXCEPTION;

e_continue exception;

v_exchange_rate_type VARCHAR2(50);
v_exchange_rate NUMBER;
v_exchange_date DATE;

v_customer_site_use_id NUMBER;

v_count_app NUMBER;
v_rec_amount_remaining NUMBER;
v_apply_amount_remaining NUMBER;

v_rec_amount NUMBER;
v_appl_amount NUMBER;
v_rec_qty NUMBER;
v_appl_qty NUMBER;

v_error_flag NUMBER;
v_valid NUMBER;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.PROCESS_RECEIPTS (+)');

    v_count := 0;

    FOR r_header IN c_headers LOOP

        v_error_flag := 0;

        fnd_file.put_line(fnd_file.log,'Lote: '||r_header.batch_name);

        /*Si existen recibos que esten en XX_AR_ADEC_RECEIPTS y no en AR_CASH_RECEIPTS*/
        /*Crear Lote de Recibos*/
        BEGIN
            select count(1)
              into v_count
              from xx_ar_adec_receipts xaar
             where status = 'N'
               and batch_name = r_header.batch_name
               and request_id is null
               and not exists (select 1
                                 from ar_cash_receipts acr
                                 ,hz_cust_accounts hca
                                  where acr.receipt_number = xaar.receipt_number
                                   and acr.pay_from_customer = hca.cust_account_id
                                   and hca.party_id = xaar.party_id
                                   and acr.receipt_date  =  xaar.receipt_date
                                   and acr.amount = xaar.amount);
        EXCEPTION
        WHEN OTHERS THEN
           v_count := 1;
        END;

        /*Se modifica la validacion para permitir levantar correcciones*/

          /*Verifico que el lote cargado no se encuentre confirmado*/
          v_batch_exists := 0;
        BEGIN

            SELECT 1
            INTO v_batch_exists
            FROM xx_ar_adec_batches
            WHERE batch_name = r_header.batch_name
            AND status = 'X'
            AND request_id is not null;
        EXCEPTION
         WHEN NO_DATA_FOUND THEN
           v_batch_exists := 0;
         WHEN TOO_MANY_ROWS THEN
           v_batch_exists := 1;
         WHEN OTHERS THEN
           v_batch_exists := 0;
        END;

        IF v_batch_exists = 0 THEN

            /*Verifico si existe para validar las aplicaciones*/
            BEGIN

                SELECT 1
                INTO v_batch_exists_p
                FROM xx_ar_adec_batches
                WHERE batch_name = r_header.batch_name
                AND status = 'P'
                AND request_id is not null;
            EXCEPTION
             WHEN NO_DATA_FOUND THEN
               v_batch_exists_p := 0;
             WHEN TOO_MANY_ROWS THEN
               v_batch_exists_p := 1;
             WHEN OTHERS THEN
               v_batch_exists_p := 0;
            END;
--


          BEGIN

                     /*Validar Si existe el lote*/
                    BEGIN

                        SELECT batch_id
                        INTO v_batch_id
                        FROM ar_batches
                        where name = r_header.batch_name
                        and batch_source_id = p_batch_source_id;

                    EXCEPTION
                     WHEN OTHERS THEN
                       v_batch_id := null;
                    END;

                    IF r_header.party_id IS NOT NULL THEN

                        BEGIN
                               SELECT hcasu.site_use_id
                                     ,hcas.cust_account_id
                               INTO   v_customer_site_use_id
                                     ,v_customer_id
                               FROM   hz_cust_accounts hca,
                                      hz_cust_acct_sites hcas,
                                      hz_cust_site_uses hcasu,
                                      hz_parties hp
                               WHERE  hca.party_id = hp.party_id
                               and    hp.party_id = r_header.party_id
                               and    hca.cust_account_id = hcas.cust_account_id
                               AND    hcas.cust_acct_site_id = hcasu.cust_acct_site_id
                               AND    hcas.org_id = hcasu.org_id
                               AND    hca.status = 'A'
                               AND    hcas.status = 'A'
                               AND    hcasu.site_use_code = 'BILL_TO'
                               AND    NVL(hcasu.primary_flag,'N') = 'Y'
                               AND    hcasu.status = 'A';

                        EXCEPTION
                         WHEN OTHERS THEN
                             NULL;
                        END;

                    END IF;

                    IF v_batch_id is null THEN


                        create_batch (p_batch_source_id
                                     ,r_header.batch_name
                                     ,r_header.currency_code
                                     ,r_header.total_credit - r_header.total_debit
                                     ,r_header.process_date
                                     ,r_header.exchange_rate
                                     ,r_header.process_date
                                     ,r_header.file_name
                                     ,v_count
                                     ,v_customer_id
                                     ,v_customer_site_use_id
                                     ,g_collector_id
                                     ,v_batch_id
                                     ,v_status
                                     ,v_error_message);

                        IF v_status != 'S' THEN
                            RAISE e_batch_exception;
                        END IF;

                    ELSE

                        IF v_batch_exists = 1 THEN
                            v_error_message := 'El Lote ya existe y esta confirmado.';
                            RAISE e_batch_exception;
                        END IF;
                    END IF;

                        fnd_file.put_line(fnd_file.log,'Batch ID: '||v_batch_id);

                        v_rec_amount := 0;
                        v_rec_qty    := 0;

                        FOR r_rec IN c_rec (r_header.batch_name,r_header.party_id,'N') LOOP

                            l_cr_id := null;
                            --v_customer_id := null;
                            SAVEPOINT S_REC1;

                            /*Validar Si existe el recibo en ar_cash_receipts*/
                            BEGIN
                                select cash_receipt_id
                                  into v_cash_receipt_id
                                  from ar_cash_receipts acr
                                 where acr.receipt_number = r_rec.receipt_number
                                   and pay_from_customer = v_customer_id
                                   and receipt_date  =  r_rec.receipt_date
                                   and amount = r_rec.amount;

                            EXCEPTION
                             WHEN OTHERS THEN
                               v_cash_receipt_id := NULL;
                            END;

                            IF r_rec.row_type IN ('REC','AWT','DEB') and r_rec.doc_type != 'ACR' THEN
                                v_rec_amount := v_rec_amount + r_rec.amount;
                                v_rec_qty    := v_rec_qty + 1;
                                fnd_file.put_line(fnd_file.log,'Cantidad de Recibos: '||v_rec_qty);
                                fnd_file.put_line(fnd_file.log,'Monto de Recibos: '||v_rec_amount);
                            END IF;

                            IF v_cash_receipt_id IS NULL THEN

                               BEGIN

                                IF r_rec.receipt_number is null then
                                 v_error_message := 'El Numero de Recibo esta en blanco.';
                                 raise e_rec_exception;
                                END IF;

                                IF r_rec.currency_code != 'ARS' THEN
                                v_exchange_rate_type := 'User';
                                v_exchange_rate := r_header.exchange_rate;
                                v_exchange_date := r_rec.receipt_date;
                                ELSE
                                v_exchange_rate_type := null;
                                v_exchange_rate := null;
                                v_exchange_date := null;
                                END IF;

                                /*IF r_rec.party_id IS NOT NULL THEN

                                    BEGIN
                                           SELECT hcasu.site_use_id
                                                 ,hcas.cust_account_id
                                           INTO   v_customer_site_use_id
                                                 ,v_customer_id
                                           FROM   hz_cust_accounts hca,
                                                  hz_cust_acct_sites hcas,
                                                  hz_cust_site_uses hcasu,
                                                  hz_parties hp
                                           WHERE  hca.party_id = hp.party_id
                                           and    hp.party_id = r_rec.party_id
                                           and    hca.cust_account_id = hcas.cust_account_id
                                           AND    hcas.cust_acct_site_id = hcasu.cust_acct_site_id
                                           AND    hcas.org_id = hcasu.org_id
                                           AND    hca.status = 'A'
                                           AND    hcas.status = 'A'
                                           AND    hcasu.site_use_code = 'BILL_TO'
                                           AND    NVL(hcasu.primary_flag,'N') = 'Y'
                                           AND    hcasu.status = 'A';

                                    EXCEPTION
                                     WHEN OTHERS THEN
                                         v_error_message := 'Error al obtener datos del cliente. Party_id: '||r_rec.party_id||'. Error: '||SQLERRM;
                                         raise e_rec_exception;
                                    END;

                                END IF;*/

                                BEGIN
                                    select arma.remit_bank_acct_use_id
                                      into v_remit_bank_acct_use_id
                                      from ar_receipt_method_accounts arma
                                          ,ce_bank_acct_uses cbau
                                     where arma.receipt_method_id = r_rec.receipt_method_id
                                       and arma.remit_bank_acct_use_id = cbau.bank_acct_use_id
                                       and cbau.bank_account_id = r_rec.bank_account_id;
                                EXCEPTION
                                 WHEN NO_DATA_FOUND THEN
                                    v_error_message := 'La cuenta bancaria no esta asociada al metodo de recibo.';
                                    raise e_rec_exception;
                                 WHEN OTHERS THEN
                                    v_error_message := 'Error al obtener datos del metodo de recibo. Party_id: '||r_rec.party_id||'. Error: '||SQLERRM;
                                    raise e_rec_exception;
                                END;

                                       Create_cash_receipt (p_currency_code               => r_rec.currency_code,
                                                            p_amount                      => r_rec.amount,
                                                            p_pay_from_customer           => v_customer_id,
                                                            p_receipt_number              => r_rec.receipt_number,
                                                            p_receipt_date                => r_rec.receipt_date,
                                                            p_maturity_date               => NVL(r_rec.due_date,r_rec.receipt_date),
                                                            p_comments                    => r_rec.comments,
                                                            p_exchange_rate_type          => v_exchange_rate_type,
                                                            p_exchange_rate               => v_exchange_rate,
                                                            p_exchange_date               => v_exchange_date,
                                                            p_batch_id                    => v_batch_id,
                                                            p_remittance_bank_account_id  => r_rec.bank_account_id,
                                                            p_remit_bank_acct_use_id      => v_remit_bank_acct_use_id,
                                                            p_customer_site_use_id        => v_customer_site_use_id,
                                                            p_receipt_method_id           => r_rec.receipt_method_id,
                                                            p_certif_number               => r_rec.certif_number,
                                                            p_certif_date                 => r_rec.certif_date,
                                                            p_regime_code                 => r_rec.regime_code,
                                                            p_cr_id                       => l_cr_id,
                                                            p_status                      => v_status,
                                                            p_error_message               => v_error_message);

                                  IF l_cr_id IS NOT NULL THEN


                                    /*Modificado Khronus/E.SLy 20180711: Definicion 20180711 se va a realizar las remesas manualmente*/
                                    /*IF r_rec.remit_number IS NOT NULL THEN
                                        create_remittance(p_status => v_status
                                                         ,p_error_message => v_error_message
                                                         ,p_remit_number => r_rec.remit_number
                                                         ,p_cash_receipt_id => l_cr_id);
                                        IF v_status != 'S' THEN
                                            --p_error_message := v_error_message;
                                            RAISE e_rec_exception;
                                        END IF;
                                    END IF;*/
                                    /*Fin Modificado Khronus/E.SLy 20180711 Definicion 20180711 se va a realizar las remesas manualmente*/

                                    UPDATE xx_ar_adec_receipts
                                    set cash_receipt_id = l_cr_id
                                       ,status = 'P'
                                       ,request_id = fnd_global.conc_request_id
                                       ,last_update_date = sysdate
                                       ,last_updated_by = fnd_global.user_id
                                    where adec_receipt_id = r_rec.adec_receipt_id;

                                    COMMIT;

                                  ELSE
                                   --p_error_message := v_error_message;
                                   RAISE e_rec_exception;
                                  END IF;

                                EXCEPTION
                                 WHEN e_rec_exception THEN
                                   ROLLBACK TO SAVEPOINT S_REC1;
                                   fnd_file.put_line(fnd_file.log,v_error_message);
                                   p_status := 'W';
                                  IF l_cr_id IS NULL THEN

                                    UPDATE xx_ar_adec_receipts
                                    SET status = 'E'
                                       ,error_message = v_error_message
                                       ,request_id = fnd_global.conc_request_id
                                       ,last_update_date = sysdate
                                       ,last_updated_by = fnd_global.user_id
                                    WHERE adec_receipt_id = r_rec.adec_receipt_id;

                                    UPDATE xx_ar_adec_applications
                                    SET status = 'E'
                                       ,error_message = v_error_message
                                       ,request_id = fnd_global.conc_request_id
                                       ,last_update_date = sysdate
                                       ,last_updated_by = fnd_global.user_id
                                    WHERE  batch_name = r_header.batch_name
                                    AND NVL(request_id, fnd_global.conc_request_id) =  fnd_global.conc_request_id;

                                    COMMIT;
                                  ELSE /*Si se creo el recibo pero hubo un error en la remesa*/
                                    UPDATE xx_ar_adec_receipts
                                    SET status = 'E'
                                       ,error_message = v_error_message
                                       ,cash_receipt_id = l_cr_id
                                       ,request_id = fnd_global.conc_request_id
                                       ,last_update_date = sysdate
                                       ,last_updated_by = fnd_global.user_id
                                    WHERE adec_receipt_id = r_rec.adec_receipt_id;

                                         UPDATE xx_ar_adec_applications
                                    SET status = 'E'
                                       ,error_message = v_error_message
                                       ,request_id = fnd_global.conc_request_id
                                       ,last_update_date = sysdate
                                       ,last_updated_by = fnd_global.user_id
                                    WHERE  batch_name = r_header.batch_name
                                    AND NVL(request_id, fnd_global.conc_request_id) =  fnd_global.conc_request_id;

                                    COMMIT;
                                  END IF;

                                  p_error_message := v_error_message;

                               END;

                            ELSE

                                IF v_batch_exists = 1 THEN

                                   v_error_message := 'Ya existe este recibo en el sistema';
                                   fnd_file.put_line(fnd_file.log,v_error_message);

                                  UPDATE xx_ar_adec_receipts
                                     SET status = 'E'
                                        ,error_message = v_error_message
                                        ,request_id = fnd_global.conc_request_id
                                        ,last_update_date = sysdate
                                        ,last_updated_by = fnd_global.user_id
                                   WHERE batch_name = r_header.batch_name
                                     AND status = 'N'
                                     AND adec_receipt_id = r_rec.adec_receipt_id;

                                ELSE

                                     UPDATE xx_ar_adec_receipts
                                     SET status = 'P'
                                        ,cash_receipt_id = v_cash_receipt_id
                                        --,error_message = v_error_message
                                        ,request_id = fnd_global.conc_request_id
                                        ,last_update_date = sysdate
                                        ,last_updated_by = fnd_global.user_id
                                   WHERE batch_name = r_header.batch_name
                                     AND status = 'N'
                                     AND adec_receipt_id = r_rec.adec_receipt_id;

                                END IF;

                                 COMMIT;

                            END IF;

                        END LOOP;

                      UPDATE xx_ar_adec_batches
                         SET status = 'P'
                            ,request_id = fnd_global.conc_request_id
                            ,last_update_date = sysdate
                            ,last_updated_by = fnd_global.user_id
                       WHERE adec_batch_id = r_header.adec_batch_id
                         AND status = 'N';

                    COMMIT;
          EXCEPTION
           WHEN e_batch_exception THEN

              ROLLBACK;

              fnd_file.put_line(fnd_file.log,v_error_message);

              UPDATE XX_AR_ADEC_BATCHES
                 SET status = 'E'
                    ,error_message = v_error_message
                    ,request_id = fnd_global.conc_request_id
                    ,last_update_date = sysdate
                    ,last_updated_by = fnd_global.user_id
               WHERE adec_batch_id = r_header.adec_batch_id
                 AND status = 'N';

               UPDATE xx_ar_adec_applications
                 SET status = 'E'
                    ,error_message = v_error_message
                    ,request_id = fnd_global.conc_request_id
                    ,last_update_date = sysdate
                    ,last_updated_by = fnd_global.user_id
               WHERE batch_name = r_header.batch_name
                 AND status = 'N';

               UPDATE xx_ar_adec_receipts
                 SET status = 'E'
                    ,error_message = v_error_message
                    ,request_id = fnd_global.conc_request_id
                    ,last_update_date = sysdate
                    ,last_updated_by = fnd_global.user_id
               WHERE batch_name = r_header.batch_name
                 AND status = 'N';

                 COMMIT;

                 v_error_flag := 1;

          END;

        ELSE

            UPDATE XX_AR_ADEC_BATCHES
                 SET status = 'E'
                    ,error_message = 'Ya existe este recibo en el sistema'
                    ,request_id = fnd_global.conc_request_id
                    ,last_update_date = sysdate
                    ,last_updated_by = fnd_global.user_id
               WHERE adec_batch_id = r_header.adec_batch_id
                 AND status = 'N';

              UPDATE xx_ar_adec_applications
                 SET status = 'E'
                    ,error_message = 'Ya existe este recibo en el sistema'
                    ,request_id = fnd_global.conc_request_id
                    ,last_update_date = sysdate
                    ,last_updated_by = fnd_global.user_id
               WHERE batch_name = r_header.batch_name
                 AND status = 'N';

              UPDATE xx_ar_adec_receipts
                 SET status = 'E'
                    ,error_message = 'Ya existe este recibo en el sistema'
                    ,request_id = fnd_global.conc_request_id
                    ,last_update_date = sysdate
                    ,last_updated_by = fnd_global.user_id
               WHERE batch_name = r_header.batch_name
                 AND status = 'N';

                 COMMIT;

        END IF;


        IF NOT check_receipts_status (r_header.batch_name) THEN
                v_error_flag := 1;
                check_batch_status (p_status => p_status
                                   ,p_adec_batch_id => r_header.adec_batch_id);
        END IF;

        IF v_error_flag = 0 THEN


            IF v_batch_exists_p = 0 THEN

                v_appl_amount := 0;
                v_appl_qty := 0;

                /*Revisar aplicaciones*/
                FOR r_app IN c_applications(r_header.batch_name,r_header.party_id) LOOP
                    v_appl_amount := v_appl_amount + r_app.amount;
                    v_appl_qty    := v_appl_qty + 1;
                END LOOP;

                fnd_file.put_line(fnd_file.log,'Cantidad de Recibos: '||v_rec_qty);
                fnd_file.put_line(fnd_file.log,'Cantidad de Aplicaciones: '||v_appl_qty);
                fnd_file.put_line(fnd_file.log,'Monto de Recibos: '||v_rec_amount);
                fnd_file.put_line(fnd_file.log,'Monto de Aplicaciones: '||v_appl_amount);


--                IF v_appl_amount = v_rec_amount AND v_rec_amount != 0 AND v_appl_qty = v_rec_qty THEN /*Aplicar todo a recibos*/

--                    SAVEPOINT S_APPL_1;

--                    /*Recorremos los recibos*/
--                    FOR r_rec IN c_rec (r_header.batch_name,r_header.party_id,'P') LOOP

--                        fnd_file.put_line(fnd_file.log,'Adec_receipt_id: '||r_rec.adec_receipt_id);
--                        fnd_file.put_line(fnd_file.log,'Monto: '||r_rec.amount);

--                        FOR r_app IN c_applications(r_header.batch_name,r_header.party_id) LOOP

--                            fnd_file.put_line(fnd_file.log,'adec_application_id: '||r_app.adec_application_id);
--                            fnd_file.put_line(fnd_file.log,'Monto: '||r_app.amount);

--                            IF r_rec.amount = r_app.amount THEN

--                                     apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
--                                                   p_customer_trx_id      => NULL,
--                                                   p_payment_schedule_id  => r_app.payment_schedule_id,
--                                                   p_amount_applied       => r_app.amount,
--                                                   p_comments             => r_app.comments,
--                                                   p_status               => v_status,
--                                                   p_error_message        => v_error_message);

--                                    IF v_status = 'S' THEN

--                                        UPDATE xx_ar_adec_applications
--                                           SET status = 'S'
--                                              ,request_id = fnd_global.conc_request_id
--                                              ,trx_appl_id = r_rec.cash_receipt_id
--                                              ,amount_remaining = 0
--                                              ,last_update_date = sysdate
--                                              ,last_updated_by = fnd_global.user_id
--                                         WHERE adec_application_id = r_app.adec_application_id
--                                           AND status = 'N';

--                                        UPDATE xx_ar_adec_receipts
--                                           SET status = 'S'
--                                              ,amount_remaining = 0
--                                              ,last_update_date = sysdate
--                                              ,last_updated_by = fnd_global.user_id
--                                         WHERE adec_receipt_id = r_rec.adec_receipt_id
--                                           AND status = 'P';

--                                          EXIT;

--                                    ELSE

--                                        ROLLBACK TO S_APPL_1;

--                                        UPDATE xx_ar_adec_applications
--                                           SET status = 'E'
--                                              ,error_message = v_error_message
--                                              ,request_id = fnd_global.conc_request_id
--                                              ,last_update_date = sysdate
--                                              ,last_updated_by = fnd_global.user_id
--                                         WHERE adec_application_id = r_app.adec_application_id
--                                           AND status = 'N';

--                                        UPDATE xx_ar_adec_receipts
--                                           SET status = 'L' --No Aplicado
--                                              ,error_message = v_error_message
--                                              ,last_update_date = sysdate
--                                              ,last_updated_by = fnd_global.user_id
--                                         WHERE adec_receipt_id = r_rec.adec_receipt_id
--                                           AND status = 'P';

--                                          EXIT;

--                                    END IF;

--                            END IF;

--                        END LOOP;

--                    END LOOP;

--                ELS

                IF v_appl_amount < v_rec_amount AND v_appl_amount = 0 THEN /*No hay aplicaciones. Todo a cuenta*/



                    FOR r_rec IN c_rec (r_header.batch_name,r_header.party_id,'P') LOOP

                                --Modificado KHRONUS/MNazarre 20200218: Se comenta la creacion de ND y NC a cuenta
                                --a futuro se va a enviar el saldo en el archivo de transacciones
                                /*apply_onaccount (r_rec.cash_receipt_id,r_rec.amount,v_status,v_error_message);

                                IF v_status = 'S' THEN

                                    UPDATE xx_ar_adec_receipts
                                       SET status = 'S'
                                          ,amount_remaining = 0
                                          ,last_update_date = sysdate
                                          ,last_updated_by = fnd_global.user_id
                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                       AND status = 'P';

                                       COMMIT;

                                ELSE

                                    ROLLBACK;

                                    UPDATE xx_ar_adec_receipts
                                       SET error_message = v_error_message
                                          ,amount_remaining = 0
                                          ,last_update_date = sysdate
                                          ,last_updated_by = fnd_global.user_id
                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                       AND status = 'P';

                                     COMMIT;

                                END IF;*/
                                
                                UPDATE xx_ar_adec_receipts
                                   SET status = 'S'
                                      --,amount_remaining = 0
                                      ,last_update_date = sysdate
                                      ,last_updated_by = fnd_global.user_id
                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                   AND status = 'P';
                                --Fin Modificado KHRONUS/MNazarre 20200218
                                
                    END LOOP;


                ELSIF v_appl_amount <= v_rec_amount AND v_appl_amount != 0 THEN /*Hay aplicaciones. Calcular que va a cuenta*/

                    SAVEPOINT S_APPL_3;
                    v_error_flag := 0;

                    /*Si hay mas recibos que aplicaciones*/
                    IF v_rec_qty >= v_appl_qty THEN

                        /*Recorro los recibos*/
                        FOR r_rec IN c_rec (r_header.batch_name,r_header.party_id,'P') LOOP

                            v_count_app := 0;
                            v_rec_amount_remaining := r_rec.amount;

                            /*Recorro las aplicaciones*/
                            FOR r_app IN c_applications(r_header.batch_name,r_header.party_id) LOOP

                              BEGIN

                                v_count_app := v_count_app + 1;
                                /*Si la aplicacion es igual que el recibo -> Aplico*/
                                IF v_rec_amount_remaining = r_app.amount THEN

                                        apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                                      p_customer_trx_id      => NULL,
                                                      p_payment_schedule_id  => r_app.payment_schedule_id,
                                                      p_amount_applied       => r_app.amount,
                                                      p_comments             => r_app.comments,
                                                      p_status               => v_status,
                                                      p_error_message        => v_error_message);

                                        IF v_status = 'S' THEN



                                            UPDATE xx_ar_adec_applications
                                               SET status = 'S'
                                                  ,request_id = fnd_global.conc_request_id
                                                  ,trx_appl_id = r_rec.cash_receipt_id
                                                  ,amount_remaining = 0
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_application_id = r_app.adec_application_id
                                               AND status = 'N';

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = 0
                                                      ,status = 'S'
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                   AND status = 'P';


                                              v_rec_amount_remaining := 0;

                                        ELSE

                                            UPDATE xx_ar_adec_applications
                                               SET status = 'E'
                                                  ,error_message = 'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                  ,request_id = fnd_global.conc_request_id
                                                  ,trx_appl_id = r_rec.cash_receipt_id
                                                  ,amount_remaining = 0
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_application_id = r_app.adec_application_id
                                               AND status = 'N';

                                                UPDATE xx_ar_adec_receipts
                                                   SET error_message = error_message ||'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                   AND status = 'P';

--                                            ROLLBACK TO S_APPL_3;
                                            fnd_file.put_line(fnd_file.log,'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                            v_error_flag := 1;

                                            v_rec_amount_remaining := 0;
                                        END IF;
                                     EXIT;  /*Paso al proximo recibo*/
                                END IF;

                                /*Si no se aplico todo el recibo*/
                                IF v_rec_amount_remaining != 0 THEN

                                    /*Si el saldo es mayor que la aplicacion*/
                                    IF v_rec_amount_remaining >  r_app.amount THEN

                                        /*Reviso si hay algun recibo pendiente por el monto de la aplicacion*/
                                        BEGIN

                                            SELECT cash_receipt_id
                                              INTO v_acr_exists
                                              FROM xx_ar_adec_receipts
                                             WHERE status = 'P'
                                               AND batch_name = r_rec.batch_name
                                               AND party_id = r_rec.party_id
                                               AND amount = r_app.amount
                                               AND rownum = 1;

                                        EXCEPTION
                                          WHEN OTHERS THEN
                                             v_acr_exists := null;
                                        END;

                                        /*Si no hay, aplico el monto de la cuota al recibo*/
                                        IF v_acr_exists is null THEN

                                            apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => r_app.amount,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                                IF v_status = 'S' THEN



                                                    UPDATE xx_ar_adec_applications
                                                       SET status = 'S'
                                                          ,request_id = fnd_global.conc_request_id
                                                          ,trx_appl_id = r_rec.cash_receipt_id
                                                          ,amount_remaining = 0
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_application_id = r_app.adec_application_id
                                                       AND status = 'N';

                                                    /*resto el saldo*/
                                                    v_rec_amount_remaining := v_rec_amount_remaining - r_app.amount;

                                                ELSE

                                                    UPDATE xx_ar_adec_applications
                                                       SET status = 'E'
                                                          ,error_message = 'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                          ,request_id = fnd_global.conc_request_id
                                                          ,trx_appl_id = r_rec.cash_receipt_id
                                                          ,amount_remaining = 0
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_application_id = r_app.adec_application_id
                                                       AND status = 'N';

                                                     UPDATE xx_ar_adec_receipts
                                                       SET error_message = error_message ||'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                       AND status = 'P';

                                                    v_rec_amount_remaining := v_rec_amount_remaining - r_app.amount;

--                                                    ROLLBACK TO S_APPL_3;
                                                    fnd_file.put_line(fnd_file.log,'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                                    v_error_flag := 1;
                                                END IF;

                                        END IF;

                                        /*Hay algun otra aplicacion libre*/
                                        BEGIN

                                            SELECT count(1)
                                              INTO v_appl_exists
                                              FROM xx_ar_adec_applications
                                             WHERE adec_application_id != r_app.adec_application_id
                                               and batch_name = r_app.batch_name
                                               and party_id = r_app.party_id
                                               and payment_schedule_id Is not null
                                               and status = 'N';

                                        EXCEPTION
                                         WHEN OTHERS THEN
                                         v_appl_exists := 0;
                                        END;

                                        IF v_appl_exists != 0 THEN
                                          raise e_continue; /*Si hay otra aplicacion pendiente sigo el cursor*/
                                        ELSE
                                            --Modificado KHRONUS/MNazarre 20200218: Se comenta la creacion de ND y NC a cuenta
                                            --a futuro se va a enviar el saldo en el archivo de transacciones
                                            /*

                                            --Sino aplico en cuenta
                                            apply_onaccount (r_rec.cash_receipt_id,v_rec_amount_remaining,v_status,v_error_message);

                                            IF v_status = 'S' THEN

                                                v_rec_amount_remaining := 0;

                                                UPDATE xx_ar_adec_receipts
                                                   SET status = 'S'
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                   AND status = 'P';

                                                   COMMIT;

                                            ELSE

                                                UPDATE xx_ar_adec_receipts
                                                   SET error_message = error_message ||'Error al aplicar: '||r_rec.receipt_number||' a cuenta ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                   AND status = 'P';

                                                   v_rec_amount_remaining := 0;

--                                                 ROLLBACK TO S_APPL_3;
                                                 fnd_file.put_line(fnd_file.log,'Error al aplicar: '||r_rec.receipt_number||' a cuenta ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message);
                                                 v_error_flag := 1;
                                            END IF;
                                            
                                            */
                                            
                                            UPDATE xx_ar_adec_receipts
                                               SET status = 'S'
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_receipt_id = r_rec.adec_receipt_id
                                             AND   status = 'P';
                                            
                                            --Fin Modificado KHRONUS/MNazarre 20200218

                                            EXIT;

                                        END IF;

                                    ELSIF v_rec_amount_remaining = r_app.amount THEN

                                            apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => v_rec_amount_remaining,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                                IF v_status = 'S' THEN

                                                    UPDATE xx_ar_adec_applications
                                                       SET status = 'S'
                                                          ,request_id = fnd_global.conc_request_id
                                                          ,trx_appl_id = r_rec.cash_receipt_id
                                                          ,amount_remaining = NVL(amount_remaining,amount) - v_rec_amount_remaining
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_application_id = r_app.adec_application_id
                                                       AND status = 'N';

                                                        UPDATE xx_ar_adec_receipts
                                                           SET status = 'S'
                                                              ,amount_remaining = 0
                                                              ,last_update_date = sysdate
                                                              ,last_updated_by = fnd_global.user_id
                                                         WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                           AND status = 'P';

                                                       COMMIT;
                                                    v_rec_amount_remaining := 0;

                                                ELSE

                                                    UPDATE xx_ar_adec_applications
                                                       SET status = 'E'
                                                          ,error_message = 'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message
                                                          ,request_id = fnd_global.conc_request_id
                                                          ,trx_appl_id = r_rec.cash_receipt_id
                                                          ,amount_remaining = NVL(amount_remaining,amount) - v_rec_amount_remaining
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_application_id = r_app.adec_application_id
                                                       AND status = 'N';

                                                        UPDATE xx_ar_adec_receipts
                                                           SET error_message = error_message || 'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message
                                                              ,last_update_date = sysdate
                                                              ,last_updated_by = fnd_global.user_id
                                                         WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                           AND status = 'P';

--                                                    ROLLBACK TO S_APPL_3;
                                                    fnd_file.put_line(fnd_file.log,'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message);
                                                    v_error_flag := 1;

                                                    v_rec_amount_remaining := 0;

                                                END IF;

                                        EXIT;

                                    ELSE

                                         apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => v_rec_amount_remaining,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                                IF v_status = 'S' THEN

                                                    UPDATE xx_ar_adec_applications
                                                       SET amount_remaining = NVL(amount_remaining,amount) - v_rec_amount_remaining
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_application_id = r_app.adec_application_id
                                                       AND status = 'N';

                                                    UPDATE xx_ar_adec_receipts
                                                       SET status = 'S'
                                                          ,amount_remaining = 0
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                       AND status = 'P';

                                                    COMMIT;
                                                    v_rec_amount_remaining := 0;

                                                ELSE

                                                    UPDATE xx_ar_adec_applications
                                                       SET request_id = fnd_global.conc_request_id
                                                          ,amount_remaining = NVL(amount_remaining,amount) - v_rec_amount_remaining
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_application_id = r_app.adec_application_id
                                                       AND status = 'N';

                                                    UPDATE xx_ar_adec_receipts
                                                       SET error_message = error_message || 'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message
                                                          ,amount_remaining = 0
                                                          ,last_update_date = sysdate
                                                          ,last_updated_by = fnd_global.user_id
                                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                                       AND status = 'P';


--                                                    ROLLBACK TO S_APPL_3;
                                                    fnd_file.put_line(fnd_file.log,'Error al aplicar: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message);
                                                    v_error_flag := 1;

                                                    v_rec_amount_remaining := 0;

                                                END IF;

                                        --EXIT;

                                    END IF;

                                END IF;


                              EXCEPTION
                                WHEN e_continue THEN
                                  NULL;
                                WHEN OTHERS THEN
--                                  ROLLBACK TO S_APPL_3;
                                  v_error_flag := 1;
                              END;

                            END LOOP;

                            IF v_count_app = 0 THEN
                                
                                --Modificado KHRONUS/MNazarre 20200218: Se comenta la creacion de ND y NC a cuenta
                                --a futuro se va a enviar el saldo en el archivo de transacciones
                                /*
                                apply_onaccount (r_rec.cash_receipt_id,v_rec_amount_remaining,v_status,v_error_message);

                                IF v_status = 'S' THEN

                                    v_rec_amount_remaining := 0;

                                    UPDATE xx_ar_adec_receipts
                                       SET status = 'S'
                                          ,last_update_date = sysdate
                                          ,last_updated_by = fnd_global.user_id
                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                       AND status = 'P';

                                       COMMIT;

                                ELSE

                                     UPDATE xx_ar_adec_receipts
                                       SET error_message = error_message ||'Error al aplicar: '||r_rec.receipt_number||' a cuenta ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message
                                          ,last_update_date = sysdate
                                          ,last_updated_by = fnd_global.user_id
                                     WHERE adec_receipt_id = r_rec.adec_receipt_id
                                       AND status = 'P';

--                                     ROLLBACK TO S_APPL_3;
                                     fnd_file.put_line(fnd_file.log,'Error al aplicar: '||r_rec.receipt_number||' a cuenta ('||TRIM(TO_CHAR(v_rec_amount_remaining,'9999999999990D90'))||'): '||v_error_message);
                                     v_error_flag := 1;

                                     v_rec_amount_remaining := 0;

                                END IF;*/
                                
                                v_rec_amount_remaining := 0;

                                UPDATE xx_ar_adec_receipts
                                   SET status = 'S'
                                      ,last_update_date = sysdate
                                      ,last_updated_by = fnd_global.user_id
                                 WHERE adec_receipt_id = r_rec.adec_receipt_id
                                   AND status = 'P';
                                   
                                --Fin Modificado KHRONUS/MNazarre 20200218

                            END IF;

                        END LOOP;

                    ELSE /*Si hay mas aplicaciones qe recibos (Cantidad)*/

                            fnd_file.put_line(fnd_file.log,'Recorro por aplicaciones');
                         /*Recorro las aplicaciones*/
                            FOR r_app IN c_applications(r_header.batch_name,r_header.party_id) LOOP

                              BEGIN

                                fnd_file.put_line(fnd_file.log,'Buscando un recibo con el monto: '||r_app.amount);
                                /*Busco un recibo por ese monto*/
                                BEGIN

                                    SELECT cash_receipt_id
                                      INTO v_acr_exists
                                      FROM xx_ar_adec_receipts
                                     WHERE status = 'P'
                                       AND NVL(amount_remaining,amount) = r_app.amount
                                       AND batch_name = r_app.batch_name
                                       AND party_id = r_app.party_id;
                                EXCEPTION
                                 WHEN OTHERS THEN
                                    v_acr_exists := null;
                                END;

                                IF v_acr_exists IS NOT NULL THEN

                                            apply_receipt(p_cash_receipt_id      => v_acr_exists,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => r_app.amount,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                            IF v_status = 'S' THEN

                                                UPDATE xx_ar_adec_applications
                                                   SET status = 'S'
                                                      ,request_id = fnd_global.conc_request_id
                                                      ,trx_appl_id = v_acr_exists
                                                      ,amount_remaining = 0
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_application_id = r_app.adec_application_id
                                                   AND status = 'N';


                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = NVL(amount_remaining,amount) - r_app.amount
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE cash_receipt_id = v_acr_exists;


                                                 COMMIT;
                                            ELSE

                                                UPDATE xx_ar_adec_applications
                                                   SET status = 'E'
                                                      ,error_message = 'Error al aplicar con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                      ,request_id = fnd_global.conc_request_id
                                                      ,trx_appl_id = v_acr_exists
                                                      ,amount_remaining = 0
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_application_id = r_app.adec_application_id
                                                   AND status = 'N';

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = NVL(amount_remaining,amount) - r_app.amount
                                                      ,error_message = error_message ||'Error al aplicar con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE cash_receipt_id = v_acr_exists;

--                                                ROLLBACK TO S_APPL_3;
                                                v_error_flag := 1;
                                                fnd_file.put_line(fnd_file.log,'Error al aplicar Receipt_id: '||v_acr_exists||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                            END IF;

                                            raise e_continue;

                                END IF;

                                fnd_file.put_line(fnd_file.log,'Buscando un recibo con un monto mayor a: '||r_app.amount);
                                /*Busco un recibo por ese monto*/
                                BEGIN

                                    SELECT cash_receipt_id
                                      INTO v_acr_exists
                                      FROM xx_ar_adec_receipts
                                     WHERE status = 'P'
                                       AND NVL(amount_remaining,amount) > r_app.amount
                                       AND batch_name = r_app.batch_name
                                       AND party_id = r_app.party_id
                                       AND rownum = 1;

                                EXCEPTION
                                 WHEN OTHERS THEN
                                    v_acr_exists := null;
                                END;

                                IF v_acr_exists IS NOT NULL THEN

                                            apply_receipt(p_cash_receipt_id      => v_acr_exists,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => r_app.amount,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                            IF v_status = 'S' THEN

                                                UPDATE xx_ar_adec_applications
                                                   SET status = 'S'
                                                      ,request_id = fnd_global.conc_request_id
                                                      ,trx_appl_id = v_acr_exists
                                                      ,amount_remaining = 0
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_application_id = r_app.adec_application_id
                                                   AND status = 'N';

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = NVL(amount_remaining,amount) - r_app.amount
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE cash_receipt_id = v_acr_exists;

                                                 COMMIT;

                                            ELSE

                                                UPDATE xx_ar_adec_applications
                                                   SET status = 'E'
                                                      ,error_message = 'Error al aplicar con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                      ,request_id = fnd_global.conc_request_id
                                                      ,trx_appl_id = v_acr_exists
                                                      ,amount_remaining = 0
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_application_id = r_app.adec_application_id
                                                   AND status = 'N';

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = NVL(amount_remaining,amount) - r_app.amount
                                                      ,error_message = error_message||'Error al aplicar con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE cash_receipt_id = v_acr_exists;

--                                                ROLLBACK TO S_APPL_3;
                                                fnd_file.put_line(fnd_file.log,'Error al aplicar Receipt_id: '||v_acr_exists||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_app.amount,'9999999999990D90'))||'): '||v_error_message);
                                                v_error_flag := 1;
                                            END IF;

                                            RAISE e_continue;


                                ELSE

                                    v_apply_amount_remaining := r_app.amount;

                                    FOR r_rec IN c_rec (r_header.batch_name,r_header.party_id,'P') LOOP

                                       IF v_apply_amount_remaining = 0 THEN
                                         EXIT;
                                       END IF;

                                        IF r_rec.amount < v_apply_amount_remaining THEN

                                            apply_receipt(p_cash_receipt_id      => r_rec.cash_receipt_id,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => r_rec.amount,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                            IF v_status = 'S' THEN

                                                v_apply_amount_remaining := v_apply_amount_remaining - r_rec.amount;

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = 0
                                                      ,status = 'S'
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id;

                                                 COMMIT;
                                            ELSE

                                                 v_apply_amount_remaining := v_apply_amount_remaining - r_rec.amount;

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = 0
                                                      ,error_message = error_message || 'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_rec.amount,'9999999999990D90'))||'): '||v_error_message
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id;

--                                               ROLLBACK TO S_APPL_3;
                                               fnd_file.put_line(fnd_file.log,'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(r_rec.amount,'9999999999990D90'))||'): '||v_error_message);
                                               v_error_flag := 1;
                                            END IF;

                                            raise e_continue;

                                        ELSE

                                             apply_receipt(p_cash_receipt_id     => r_rec.cash_receipt_id,
                                                          p_customer_trx_id      => NULL,
                                                          p_payment_schedule_id  => r_app.payment_schedule_id,
                                                          p_amount_applied       => v_apply_amount_remaining,
                                                          p_comments             => r_app.comments,
                                                          p_status               => v_status,
                                                          p_error_message        => v_error_message);

                                            IF v_status = 'S' THEN

                                                v_apply_amount_remaining := 0;

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = NVL(amount_remaining,amount) - r_app.amount
                                                      ,status = 'S'
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id;

                                                 COMMIT;
                                            ELSE

                                                v_apply_amount_remaining := 0;

                                                UPDATE xx_ar_adec_receipts
                                                   SET amount_remaining = NVL(amount_remaining,amount) - r_app.amount
                                                      ,error_message = error_message ||'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_apply_amount_remaining,'9999999999990D90'))||'): '||v_error_message
                                                      ,last_update_date = sysdate
                                                      ,last_updated_by = fnd_global.user_id
                                                 WHERE adec_receipt_id = r_rec.adec_receipt_id;

--                                               ROLLBACK TO S_APPL_3;
                                               fnd_file.put_line(fnd_file.log,'Error al aplicar Recibo: '||r_rec.receipt_number||' con '||r_app.trx_number||'.'||r_app.payment_schedule_id||' ('||TRIM(TO_CHAR(v_apply_amount_remaining,'9999999999990D90'))||'): '||v_error_message);
                                               v_error_flag := 1;
                                            END IF;

                                            raise e_continue;

                                        END IF;


                                    END LOOP;

                                END IF;

                              EXCEPTION
                                WHEN e_continue THEN
                                  NULL;
                                WHEN OTHERS THEN
--                                  ROLLBACK TO S_APPL_3;
                                  v_error_flag := 1;
                              END;

                            END LOOP;

                            IF v_error_flag = 0 THEN
                                /*Si todavia hay recibos con saldo*/
                                /*Aplico a cuenta*/
                                FOR r_rec IN c_rec (r_header.batch_name,r_header.party_id,'P') LOOP

                                    IF r_rec.amount != 0 THEN

                                        --Modificado KHRONUS/MNazarre 20200218: Se comenta la creacion de ND y NC a cuenta
                                        --a futuro se va a enviar el saldo en el archivo de transacciones
                                        /*
                                        apply_onaccount (r_rec.cash_receipt_id,r_rec.amount,v_status,v_error_message);

                                        IF v_status = 'S' THEN

                                            UPDATE xx_ar_adec_receipts
                                               SET status = 'S'
                                                  ,amount_remaining  = 0
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_receipt_id = r_rec.adec_receipt_id
                                               AND status = 'P';

                                               COMMIT;

                                        ELSE

                                            UPDATE xx_ar_adec_receipts
                                               SET amount_remaining  = 0
                                                  ,error_message = error_message || 'Error al aplicar Recibo: '||r_rec.receipt_number||' a cuenta ('||TRIM(TO_CHAR(r_rec.amount,'9999999999990D90'))||'): '||v_error_message
                                                  ,last_update_date = sysdate
                                                  ,last_updated_by = fnd_global.user_id
                                             WHERE adec_receipt_id = r_rec.adec_receipt_id
                                               AND status = 'P';

--                                             ROLLBACK TO S_APPL_3;
                                             fnd_file.put_line(fnd_file.log,'Error al aplicar Recibo: '||r_rec.receipt_number||' a cuenta ('||TRIM(TO_CHAR(r_rec.amount,'9999999999990D90'))||'): '||v_error_message);
                                             v_error_flag := 1;
                                        END IF;
                                        */

                                        UPDATE xx_ar_adec_receipts
                                           SET status = 'S'
                                              --,amount_remaining  = 0
                                              ,last_update_date = sysdate
                                              ,last_updated_by = fnd_global.user_id
                                         WHERE adec_receipt_id = r_rec.adec_receipt_id
                                           AND status = 'P';
                                           
                                        --Fin Modificado KHRONUS/MNazarre 20200218

                                    END IF;

                                END LOOP;

                            END IF;

                    END IF;

                END IF;
                /**/

            ELSE

                validate_applications(p_status  => p_status
                                       ,p_error_message  => p_error_message
                                       ,p_batch_name => r_header.batch_name
                                       ,p_party_id => r_header.party_id);

            END IF;

            check_batch_status (p_status => p_status
                                   ,p_adec_batch_id => r_header.adec_batch_id);

        END IF;

    END LOOP;

    IF p_status is null then
     p_status := 'S';
     fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.PROCESS_RECEIPTS (-)');
    ELSE
      fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.PROCESS_RECEIPTS (!)');
    end if;

EXCEPTION
 WHEN OTHERS THEN
   p_status := 'W';
   p_error_message := 'Error en process_receipts. '||SQLERRM;
   fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.PROCESS_RECEIPTS (!)');
END;

PROCEDURE  main_process (retcode          OUT VARCHAR2
                        ,errbuf           OUT VARCHAR2
                        ,p_batch_source_id IN NUMBER
                        ,p_collector_id    IN NUMBER) IS

v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);

e_cust_exception EXCEPTION;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.MAIN_PROCESS (+)');

    g_batch_source_nd := FND_PROFILE.VALUE('XX_AR_ADEC_ND_BATCH_SOURCE');
    g_batch_source_nc := FND_PROFILE.VALUE('XX_AR_ADEC_NC_BATCH_SOURCE');
    g_memo_line       := FND_PROFILE.VALUE('XX_AR_ADEC_MEMO_LINE');
    g_term_id            := FND_PROFILE.VALUE('XX_AR_ADEC_TERMS');

    g_collector_id       := p_collector_id;

    if g_batch_source_nd IS NULL THEN
     v_error_message := 'No se ha configurado el origen de Nota de Debito. Perfil: XX AR Origen Nota de Debito Adecuentas';
    raise e_cust_exception;
    END IF;

    if g_batch_source_nc IS NULL THEN
    v_error_message := 'No se ha configurado el origen de Nota de Credito. Perfil: XX AR Origen Nota de credito Adecuentas';
    raise e_cust_exception;
    END IF;

    if g_memo_line IS NULL THEN
    v_error_message := 'No se ha configurado la Linea de Nota por Defecto. Perfil: XX AR Linea de Nota Adecuentas';
    raise e_cust_exception;
    END IF;

    if g_term_id IS NULL THEN
    v_error_message := 'No se ha configurado la Linea de Nota por Defecto. Perfil: XX AR Termino de Pago Adecuentas';
    raise e_cust_exception;
    END IF;

    if g_collector_id IS NULL THEN
    v_error_message := 'No se ha configurado el cobrador por defecto en el parametro';
    raise e_cust_exception;
    END IF;

    process_receipts (p_status          => v_status
                     ,p_error_message   => v_error_message
                     ,p_batch_source_id => p_batch_source_id);

    IF v_status != 'S' THEN
      RAISE e_cust_exception;
    END IF;

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.MAIN_PROCESS (-)');

EXCEPTION
WHEN e_cust_exception THEN
  retcode := 1;
  errbuf := v_error_message;
  fnd_file.put_line(fnd_file.log,errbuf);
  IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
                FND_FILE.PUT_LINE (FND_FILE.LOG,'Error Seteando Estado De Finalizacion');
  ELSE
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Estado de finalizacion seteado');
  END IF;
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.MAIN_PROCESS (!)');
 WHEN OTHERS THEN
  retcode := 2;
  errbuf := 'Error en main_process. '||SQLERRM;
  fnd_file.put_line(fnd_file.log,errbuf);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.MAIN_PROCESS (!)');
  RAISE_APPLICATION_ERROR(-20000,errbuf);
END;

FUNCTION insert_count (p_counts XX_AR_ADEC_COUNTS%ROWTYPE) RETURN BOOLEAN IS

BEGIN

    INSERT INTO XX_AR_ADEC_COUNTS
     (adec_count_id
     ,count_row2
     ,count_row3
     ,count_row4
     ,count_row5
     ,count_row6
     ,status
     ,creation_date
     ,created_by
     ,last_update_date
     ,last_updated_by
     )
     VALUES
     (p_counts.adec_count_id
     ,p_counts.count_row2
     ,p_counts.count_row3
     ,p_counts.count_row4
     ,p_counts.count_row5
     ,p_counts.count_row6
     ,'N'
     ,SYSDATE
     ,fnd_global.user_id
     ,SYSDATE
     ,fnd_global.user_id
     );

    RETURN (TRUE);

EXCEPTION
 WHEN OTHERS THEN
  RETURN (FALSE);
END;

FUNCTION insert_receipt (p_receipts bolinf.XX_AR_ADEC_RECEIPTS%ROWTYPE) RETURN BOOLEAN IS

BEGIN

    INSERT INTO bolinf.XX_AR_ADEC_RECEIPTS
     (adec_receipt_id
     ,batch_name
     ,party_id
     ,row_type
     ,doc_type
     ,remit_number
     ,receipt_number
     ,receipt_date
     ,due_date
     ,receipt_method_id
     ,bank_account_id
     ,currency_code
     ,amount
     ,comments
     ,certif_number
     ,certif_date
     ,regime_code
     ,status
     ,org_id
     ,creation_date
     ,created_by
     ,last_update_date
     ,last_updated_by
     )
     VALUES
     (p_receipts.adec_receipt_id
     ,p_receipts.batch_name
     ,p_receipts.party_id
     ,p_receipts.row_type
     ,p_receipts.doc_type
     ,p_receipts.remit_number
     ,p_receipts.receipt_number
     ,p_receipts.receipt_date
     ,p_receipts.due_date
     ,p_receipts.receipt_method_id
     ,p_receipts.bank_account_id
     ,p_receipts.currency_code
     ,p_receipts.amount
     ,p_receipts.comments
     ,p_receipts.certif_number
     ,p_receipts.certif_date
     ,p_receipts.regime_code
     ,'N'
     ,p_receipts.org_id
     ,SYSDATE
     ,fnd_global.user_id
     ,SYSDATE
     ,fnd_global.user_id
     );

    RETURN (TRUE);

EXCEPTION
 WHEN OTHERS THEN
  RETURN (FALSE);
END;

FUNCTION insert_application (p_applications bolinf.XX_AR_ADEC_APPLICATIONS%ROWTYPE) RETURN BOOLEAN IS

BEGIN
     INSERT INTO bolinf.XX_AR_ADEC_APPLICATIONS
     (adec_application_id
     ,batch_name
     ,party_id
     ,doc_type
     ,trx_number
     ,trx_date
     ,due_date
     ,currency_code
     ,amount
     ,comments
     ,payment_schedule_id
     ,status
     ,org_id
     ,creation_date
     ,created_by
     ,last_update_date
     ,last_updated_by)
     VALUES
     (p_applications.adec_application_id
     ,p_applications.batch_name
     ,p_applications.party_id
     ,p_applications.doc_type
     ,p_applications.trx_number
     ,p_applications.trx_date
     ,p_applications.due_date
     ,p_applications.currency_code
     ,p_applications.amount
     ,p_applications.comments
     ,p_applications.payment_schedule_id
     ,'N'
     ,p_applications.org_id
     ,SYSDATE
     ,fnd_global.user_id
     ,SYSDATE
     ,fnd_global.user_id
     );

    RETURN (TRUE);

EXCEPTION
 WHEN OTHERS THEN
  RETURN (FALSE);
END;

FUNCTION insert_batch (p_batches bolinf.XX_AR_ADEC_BATCHES%ROWTYPE) RETURN BOOLEAN IS

BEGIN

    INSERT INTO bolinf.XX_AR_ADEC_BATCHES
    ( adec_batch_id
     ,batch_name
     ,party_id
     ,process_date
     ,batch_status
     ,currency_code
     ,total_credit
     ,total_debit
     ,exchange_rate
     ,status
     ,load_request_id
     ,file_name
     ,org_id
     ,creation_date
     ,created_by
     ,last_update_date
     ,last_updated_by
     )
     VALUES
     ( p_batches.adec_batch_id
     ,p_batches.batch_name
     ,p_batches.party_id
     ,p_batches.process_date
     ,p_batches.batch_status
     ,p_batches.currency_code
     ,p_batches.total_credit
     ,p_batches.total_debit
     ,p_batches.exchange_rate
     ,'N'
     ,fnd_global.conc_request_id
     ,p_batches.file_name
     ,p_batches.org_id
     ,SYSDATE
     ,fnd_global.user_id
     ,SYSDATE
     ,fnd_global.user_id
     );

    RETURN (TRUE);

EXCEPTION
 WHEN OTHERS THEN
  RETURN (FALSE);
END;

PROCEDURE get_receipt_info (retcode    OUT VARCHAR2
                           ,errbuf     OUT VARCHAR2
                           ,p_path     IN  VARCHAR2
                           ,p_filename IN  VARCHAR2) IS

v_file_type UTL_FILE.FILE_TYPE;
v_line VARCHAR2(2000);

l_batches bolinf.XX_AR_ADEC_BATCHES%ROWTYPE;
l_applications bolinf.XX_AR_ADEC_APPLICATIONS%ROWTYPE;
l_receipts bolinf.XX_AR_ADEC_RECEIPTS%ROWTYPE;
l_counts XX_AR_ADEC_COUNTS%ROWTYPE;
--Agregado OU
v_org_cuit      VARCHAR2(20);
v_org_name      VARCHAR2(240);
v_org_id        NUMBER;

v_count NUMBER;
v_field VARCHAR2(300);
v_error_message VARCHAR2(2000);
e_cust_exception EXCEPTION;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.GET_RECEIPT_INFO (+)');

    v_field := 'FOPEN';

    v_file_type := UTL_FILE.FOPEN(p_path,p_filename, 'r');

    v_count := 0;

    LOOP
        BEGIN

          utl_file.get_line(v_file_type, v_line);

          IF SUBSTR(v_line,1,1) = '1' THEN
            v_count := v_count +1;
            
            --Agregado OU
            v_field := 'Unidad Operativa';
            IF TRIM(SUBSTR(v_line,2,20)) IS NOT NULL THEN
               v_org_cuit := TO_CHAR(TO_NUMBER(TRIM(SUBSTR(v_line,2,20))));
            ELSE
               v_error_message := 'No se ha informado valor en Campo: '||v_field;
               RAISE e_cust_exception;
            END IF;
            
            BEGIN
                select  haou.name
                       ,haou.organization_id
                into    v_org_name
                       ,v_org_id
                from    hr_locations hl
                       ,hr_all_organization_units haou
                       ,hr_operating_units hou
                where   1=1
                and     haou.location_id = hl.location_id
                and     haou.organization_id = hou.organization_id
                and     hl.global_attribute11||hl.global_attribute12 = v_org_cuit;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    v_error_message := 'No se encontro Unidad Operativa para el CUIT: '||v_org_cuit;
                    raise e_cust_exception;
                WHEN OTHERS THEN
                    v_error_message := 'Error al obtener Unidad Operativa CUIT: '||v_org_cuit||', Error: '||sqlerrm;
                    raise e_cust_exception;
            END;  
            
            
            IF v_org_id != fnd_profile.value('ORG_ID') THEN
                v_error_message := 'El archivo corresponde a otra unidad operativa, Unidad Operativa del archivo: '||v_org_name;
                raise e_cust_exception;
            END IF;
            --Fin Agregado OU
            
          END IF;

          IF SUBSTR(v_line,1,1) = '2' THEN --Orden de Pago (Batch Name)

                fnd_file.put_line(fnd_file.log,'Procesando Registro 2');

                v_count := v_count +1;
                l_batches := null;

                SELECT XX_AR_ADEC_BATCHES_S.NEXTVAL
                into l_batches.adec_batch_id
                from dual;

                v_field := 'Batch Name';
                IF TRIM(SUBSTR(v_line,2,15)) IS NOT NULL THEN
                   l_batches.batch_name := TO_CHAR(TO_NUMBER(TRIM(SUBSTR(v_line,2,15))));
                   l_batches.org_id := v_org_id;
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Party ID';
                IF TRIM(SUBSTR(v_line,17,15)) IS NOT NULL THEN
                   l_batches.party_id := TO_NUMBER(SUBSTR(v_line,17,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Process Date';
                IF TRIM(SUBSTR(v_line,32,8)) IS NOT NULL THEN
                    l_batches.process_date := TO_DATE(SUBSTR(v_line,32,8),'YYYYMMDD');
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Batch Status';
                l_batches.batch_status := TRIM(SUBSTR(v_line,40,6));

                v_field := 'Currency Code';
                l_batches.currency_code := TRIM(SUBSTR(v_line,46,3));

                v_field := 'Total Debit';
                IF TRIM(SUBSTR(v_line,49,15)) IS NOT NULL THEN
                   l_batches.total_credit := TO_NUMBER(SUBSTR(v_line,49,15))/100;
                END IF;

                v_field := 'Total Credit';

                IF TRIM(SUBSTR(v_line,64,15)) IS NOT NULL THEN
                   l_batches.total_debit := TO_NUMBER(SUBSTR(v_line,64,15))/100;
                END IF;

                v_field := 'Exchange Rate';
                IF TRIM(SUBSTR(v_line,79,15)) IS NOT NULL THEN
                   l_batches.exchange_rate := TO_NUMBER(SUBSTR(v_line,79,15))/100;
                END IF;

                v_field := 'File Name';
                l_batches.file_name := p_filename;

                IF NOT insert_batch (l_batches) THEN
                    v_error_message := 'Error al insertar cabecera. Registro Nro: '||v_count||'. Error: '||SQLERRM;
                    RAISE e_cust_exception;
                END IF;

          END IF;

          IF SUBSTR(v_line,1,1) = '3' THEN --Documento Cancelado

                fnd_file.put_line(fnd_file.log,'Procesando Registro 3');

                v_count := v_count +1;
                l_applications := null;

                SELECT XX_AR_ADEC_APPLICATIONS_S.NEXTVAL
                into l_applications.adec_application_id
                from dual;

                v_field := 'Batch Name';
                IF TRIM(SUBSTR(v_line,2,15)) IS NOT NULL THEN
                   l_applications.batch_name := TO_CHAR(TO_NUMBER(TRIM(SUBSTR(v_line,2,15))));
                   l_applications.org_id := v_org_id;
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Party ID';
                IF TRIM(SUBSTR(v_line,17,15)) IS NOT NULL THEN
                   l_applications.party_id := TO_NUMBER(SUBSTR(v_line,17,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Doc Type';
                l_applications.doc_type := TRIM(SUBSTR(v_line,32,5));

                v_field := 'Trx Number';
                l_applications.trx_number := TRIM(SUBSTR(v_line,37,15));

                v_field := 'Trx Date';
                IF TRIM(SUBSTR(v_line,52,8)) IS NOT NULL THEN
                   l_applications.trx_date := TO_DATE(SUBSTR(v_line,52,8),'YYYYMMDD');
                END IF;

                IF TRIM(SUBSTR(v_line,60,8)) IS NOT NULL THEN
                   v_field := 'Due Date';
                   l_applications.due_date := TO_DATE(SUBSTR(v_line,60,8),'YYYYMMDD');
                END IF;

                v_field := 'Currency Code';
                l_applications.currency_code := TRIM(SUBSTR(v_line,68,3));

                v_field := 'Amount';
                IF TRIM(SUBSTR(v_line,71,15)) IS NOT NULL THEN
                    IF SUBSTR(v_line,71,1) = '-' THEN
                       l_applications.amount := (TO_NUMBER(SUBSTR(v_line,72,14))* -1)/100;
                    ELSE
                       l_applications.amount := (TO_NUMBER(SUBSTR(v_line,72,14)))/100;
                    END IF;
                END IF;

                v_field := 'Comments';
                l_applications.comments := TRIM(SUBSTR(v_line,88,50));

                IF TRIM(SUBSTR(v_line,136,15)) IS NOT NULL THEN
                    v_field := 'Payment Schedule ID';
                    l_applications.payment_schedule_id := TO_NUMBER(SUBSTR(v_line,136,15));
                END IF;

                IF NOT insert_application (l_applications) THEN
                    v_error_message := 'Error al insertar Documento Cancelado. Registro Nro: '||v_count||'. Error: '||SQLERRM;
                    RAISE e_cust_exception;
                END IF;

          END IF;

          IF SUBSTR(v_line,1,1) = '4' THEN -- Debitos

                fnd_file.put_line(fnd_file.log,'Procesando Registro 4');

                v_count := v_count +1;
                l_receipts := null;

                SELECT XX_AR_ADEC_RECEIPTS_S.NEXTVAL
                into l_receipts.adec_receipt_id
                from dual;

                v_field := 'Batch name';
                IF TRIM(SUBSTR(v_line,2,15)) IS NOT NULL THEN
                   l_receipts.batch_name := TO_CHAR(TO_NUMBER(TRIM(SUBSTR(v_line,2,15))));
                   l_receipts.org_id := v_org_id;
                END IF;

                v_field := 'Party ID';
                IF TRIM(SUBSTR(v_line,17,15)) IS NOT NULL THEN
                   l_receipts.party_id := TO_NUMBER(SUBSTR(v_line,17,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                l_receipts.row_type := 'DEB';

                v_field := 'Doc Type';
                l_receipts.doc_type := TRIM(SUBSTR(v_line,32,5));

                v_field := 'Receipt Number';
                l_receipts.receipt_number := TRIM(SUBSTR(v_line,37,15));

                v_field := 'Receipt Date';
                IF TRIM(SUBSTR(v_line,52,8)) IS NOT NULL THEN
                  l_receipts.receipt_date := TO_DATE(SUBSTR(v_line,52,8),'YYYYMMDD');
                ELSE
                  v_error_message := 'No se ha informado valor en Campo: '||v_field;
                  RAISE e_cust_exception;
                END IF;

                v_field := 'Receipt Method';
                IF TRIM(SUBSTR(v_line,60,15)) IS NOT NULL THEN
                   l_receipts.receipt_method_id := TO_NUMBER(SUBSTR(v_line,60,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Bank Account ID';
                IF TRIM(SUBSTR(v_line,75,15)) IS NOT NULL THEN
                   l_receipts.bank_account_id := TO_NUMBER(SUBSTR(v_line,75,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Currency Code';
                l_receipts.currency_code := TRIM(SUBSTR(v_line,90,3));

                v_field := 'Amount';
                IF TRIM(SUBSTR(v_line,93,15)) IS NOT NULL THEN
                    IF SUBSTR(v_line,93,1) = '-' THEN
                       --l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,94,14))* -1)/100;
                       l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,94,14)))/100;
                    ELSE
                       l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,94,14)))/100;
                    END IF;
                END IF;

                v_field := 'Comments';
                l_receipts.comments := TRIM(SUBSTR(v_line,108,50));

                IF NOT insert_receipt (l_receipts) THEN
                    v_error_message := 'Error al insertar Debito. Registro Nro: '||v_count||'. Error: '||SQLERRM;
                    RAISE e_cust_exception;
                END IF;

          END IF;

          IF SUBSTR(v_line,1,1) = '5' THEN -- Retenciones

                fnd_file.put_line(fnd_file.log,'Procesando Registro 5');

                v_count := v_count +1;
                l_receipts := null;

                SELECT XX_AR_ADEC_RECEIPTS_S.NEXTVAL
                into l_receipts.adec_receipt_id
                from dual;

                v_field := 'Batch Name';
                IF TRIM(SUBSTR(v_line,2,15)) IS NOT NULL THEN
                   l_receipts.batch_name := TO_CHAR(TO_NUMBER(TRIM(SUBSTR(v_line,2,15))));
                   l_receipts.org_id := v_org_id;
                END IF;

                v_field := 'Party ID';
                IF TRIM(SUBSTR(v_line,17,15)) IS NOT NULL THEN
                   l_receipts.party_id := TO_NUMBER(SUBSTR(v_line,17,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                l_receipts.row_type := 'AWT';

                v_field := 'Doc Type';
                l_receipts.doc_type := TRIM(SUBSTR(v_line,32,5));

                v_field := 'Receipt Number';
                l_receipts.receipt_number := TRIM(SUBSTR(v_line,37,15));

                v_field := 'Receipt Date';
                IF TRIM(SUBSTR(v_line,52,8)) IS NOT NULL THEN
                   l_receipts.receipt_date := TO_DATE(SUBSTR(v_line,52,8),'YYYYMMDD');
                END IF;

                v_field := 'Receipt Method';
                IF TRIM(SUBSTR(v_line,60,15)) IS NOT NULL THEN
                   l_receipts.receipt_method_id := TO_NUMBER(SUBSTR(v_line,60,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Bank Account ID';
                IF TRIM(SUBSTR(v_line,75,15)) IS NOT NULL THEN
                   l_receipts.bank_account_id := TO_NUMBER(SUBSTR(v_line,75,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Currency Code';
                l_receipts.currency_code := TRIM(SUBSTR(v_line,90,3));

                v_field := 'Amount';
                IF TRIM(SUBSTR(v_line,93,15)) IS NOT NULL THEN
                    IF SUBSTR(v_line,93,1) = '-' THEN
                       l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,94,14))* -1)/100;
                    ELSE
                       l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,94,14)))/100;
                    END IF;
                END IF;

                v_field := 'Comments';
                l_receipts.comments := TRIM(SUBSTR(v_line,108,50));

                v_field := 'Certif Number';
                l_receipts.certif_number := TRIM(SUBSTR(v_line,158,20));

                v_field := 'Certif Date';
                IF TRIM(SUBSTR(v_line,178,8)) IS NOT NULL THEN
                   l_receipts.certif_date := TO_DATE(SUBSTR(v_line,178,8),'YYYYMMDD');
                END IF;

                v_field := 'Regime Code';
                l_receipts.regime_code := TRIM(SUBSTR(v_line,186,10));

                IF NOT insert_receipt (l_receipts) THEN
                    v_error_message := 'Error al insertar Retenciones. Registro Nro: '||v_count||'. Error: '||SQLERRM;
                    RAISE e_cust_exception;
                END IF;

          END IF;

          IF SUBSTR(v_line,1,1) = '6' THEN -- instrumentos de Pago

                fnd_file.put_line(fnd_file.log,'Procesando Registro 6');
                v_count := v_count +1;
                l_receipts := null;

                SELECT XX_AR_ADEC_RECEIPTS_S.NEXTVAL
                into l_receipts.adec_receipt_id
                from dual;

                v_field := 'Batch Name';
                IF TRIM(SUBSTR(v_line,2,15)) IS NOT NULL THEN
                   l_receipts.batch_name := TO_CHAR(TO_NUMBER(TRIM(SUBSTR(v_line,2,15))));
                   l_receipts.org_id := v_org_id;
                END IF;

                v_field := 'Party ID';
                IF TRIM(SUBSTR(v_line,17,15)) IS NOT NULL THEN
                   l_receipts.party_id := TO_NUMBER(SUBSTR(v_line,17,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                l_receipts.row_type := 'REC';

                v_field := 'Doc Type';
                l_receipts.doc_type := TRIM(SUBSTR(v_line,32,5));

                v_field := 'Receipt Number';
                l_receipts.receipt_number := TRIM(SUBSTR(v_line,37,15));

                v_field := 'Remit Number';
                l_receipts.remit_number := TRIM(SUBSTR(v_line,52,15));

                v_field := 'Receipt Date';
                IF TRIM(SUBSTR(v_line,67,8)) IS NOT NULL THEN
                   l_receipts.receipt_date := TO_DATE(SUBSTR(v_line,67,8),'YYYYMMDD');
                END IF;

                v_field := 'Due Date';
                IF TRIM(SUBSTR(v_line,75,8)) IS NOT NULL THEN
                   l_receipts.due_date := TO_DATE(SUBSTR(v_line,75,8),'YYYYMMDD');
                END IF;

                v_field := 'Receipt Method ';
                IF TRIM(SUBSTR(v_line,83,15)) IS NOT NULL THEN
                   l_receipts.receipt_method_id := TO_NUMBER(SUBSTR(v_line,83,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Bank Account ID';
                IF TRIM(SUBSTR(v_line,98,15)) IS NOT NULL THEN
                   l_receipts.bank_account_id := TO_NUMBER(SUBSTR(v_line,98,15));
                ELSE
                   v_error_message := 'No se ha informado valor en Campo: '||v_field;
                   RAISE e_cust_exception;
                END IF;

                v_field := 'Currency Code';
                l_receipts.currency_code := TRIM(SUBSTR(v_line,113,3));

                v_field := 'Amount';
                IF TRIM(SUBSTR(v_line,116,15)) IS NOT NULL THEN
                    IF SUBSTR(v_line,116,1) = '-' THEN
                       l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,117,14))* -1)/100;
                    ELSE
                       l_receipts.amount := (TO_NUMBER(SUBSTR(v_line,117,14)))/100;
                    END IF;
                END IF;

                v_field := 'Comments';
                l_receipts.comments := TRIM(SUBSTR(v_line,131,50));

                IF NOT insert_receipt (l_receipts) THEN
                    v_error_message := 'Error al insertar Instrumento de Pago. Registro Nro: '||v_count||'. Error: '||SQLERRM;
                    RAISE e_cust_exception;
                END IF;

          END IF;


          IF SUBSTR(v_line,1,1) = '9' THEN -- control de Cantidad

                fnd_file.put_line(fnd_file.log,'Procesando Registro 9');

                v_count := v_count +1;
                l_counts := null;

                SELECT XX_AR_ADEC_COUNTS_S.NEXTVAL
                  INTO l_counts.adec_count_id
                  FROM dual;

                  v_field := 'Count Row 2';
                  l_counts.count_row2 := TO_NUMBER(SUBSTR(v_line,2,10));
                  v_field := 'Count Row 3';
                  l_counts.count_row3 := TO_NUMBER(SUBSTR(v_line,12,10));
                  v_field := 'Count Row 4';
                  l_counts.count_row4 := TO_NUMBER(SUBSTR(v_line,22,10));
                  v_field := 'Count Row 5';
                  l_counts.count_row5 := TO_NUMBER(SUBSTR(v_line,32,10));
                  v_field := 'Count Row 6';
                  l_counts.count_row6 := TO_NUMBER(SUBSTR(v_line,42,10));

                IF NOT insert_count (l_counts) THEN
                    v_error_message := 'Error al insertar Registro de Cantidad. Registro Nro: '||v_count||'. Error: '||SQLERRM;
                    RAISE e_cust_exception;
                END IF;

          END IF;


        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            EXIT;
        END;
    END LOOP;

    COMMIT;

    fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.GET_RECEIPT_INFO (-)');

EXCEPTION
 WHEN e_cust_exception THEN
  ROLLBACK;
  retcode := 1;
  errbuf := v_error_message;
  fnd_file.put_line(fnd_file.log,errbuf);
  IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
                FND_FILE.PUT_LINE (FND_FILE.LOG,'Error Seteando Estado De Finalizacion');
  ELSE
        FND_FILE.PUT_LINE (FND_FILE.LOG,'Estado de finalizacion seteado');
  END IF;
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.GET_RECEIPT_INFO (!)');
 WHEN OTHERS THEN
  ROLLBACK;
  retcode := 2;
  errbuf := 'Error en get_receipt_info. '||SQLERRM||'. En: '||v_field;
  fnd_file.put_line(fnd_file.log,errbuf);
  fnd_file.put_line(fnd_file.log,'XX_AR_ADECUENTAS_INT_PKG.GET_RECEIPT_INFO (!)');
  RAISE_APPLICATION_ERROR(-20000,errbuf);
END;


END; 
/

exit
