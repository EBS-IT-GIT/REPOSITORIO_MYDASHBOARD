UPDATE apps.oe_order_lines_all ool
SET    unit_selling_price = 2700
     , unit_selling_price_per_pqty = 2700
     , last_update_date = sysdate
     , last_updated_by = 2070
WHERE  header_id = 10499829;
--1 Registro