  set define off;
alter table  bolinf.XX_PO_FLEPASIG_GT modify(TRANSPOR_VENDOR_ID null);

alter table  bolinf.XX_PO_FLEPASIG_GT add(NUMERO_PEDIDO varchar2(20));
alter table  bolinf.XX_PO_ASOCIA_REM_SEL_GT add(NUMERO_PEDIDO varchar2(20)); 
alter table  bolinf.XX_PO_ASOCIA_REMITOS add(NUMERO_PEDIDO varchar2(20));
alter table  bolinf.XX_PO_ASOCIA_REM_GT add(NUMERO_PEDIDO varchar2(20));
alter table  bolinf.XX_PO_ASOCIA_REM_LINEAS add(NUMERO_PEDIDO varchar2(20));

alter table  bolinf.XX_PO_FLEPASIG_GT modify(origen_org_code varchar2(110));
alter table  bolinf.XX_PO_ASOCIA_REM_SEL_GT modify(origen_org_code varchar2(110));
alter table  bolinf.XX_PO_ASOCIA_REMITOS modify(origen_org_code varchar2(110));
alter table  bolinf.XX_PO_ASOCIA_REM_GT modify(origen_org_code varchar2(110));
alter table  bolinf.XX_PO_ASOCIA_REM_LINEAS modify(origen_org_code varchar2(110));

exec ad_zd_table.upgrade('BOLINF', 'XX_PO_ASOCIA_REMITOS');

exit
