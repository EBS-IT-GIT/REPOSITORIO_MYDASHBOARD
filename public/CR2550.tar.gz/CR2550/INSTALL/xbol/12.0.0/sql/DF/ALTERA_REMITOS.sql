  set define off;
alter table bolinf.xx_inv_remitos_impresos add (vendor_id number);
exec ad_zd_table.upgrade('BOLINF', 'XX_INV_REMITOS_IMPRESOS');


exit
