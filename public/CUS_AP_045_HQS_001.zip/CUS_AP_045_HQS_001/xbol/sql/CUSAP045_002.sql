WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

-- $Header: CUSAP045_002.sql 121.1 26/05/2020 12:00:00 appldev ship $
-- +==================================================================+
-- |                      SANTO ANTONIO ENERGIA                       |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   CUSAP045_002.sql                                               |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUS045                                                         |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   Script para Ajustar programar o concurrent de copia de anexos  | 
-- |   para executar a cada dois minutos                              |
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan de Castro Gomes      26/05/2020                          |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--
DECLARE 
  l_conc_id     NUMBER;
  l_boolean     BOOLEAN;
  l_vUserName   apps.fnd_user.user_name%TYPE := 'SUPORTE_EBS';  
  l_nUserId     apps.fnd_user.user_id%TYPE;
  l_vRespApp    apps.fnd_application_vl.application_short_name%TYPE;
  l_vRespKey    apps.fnd_responsibility_vl.responsibility_key%TYPE := 'SAE_EBS_AP_BANCADA';
  l_nRespId     apps.fnd_responsibility_vl.responsibility_id%TYPE;
  l_nRespApplId apps.fnd_responsibility_vl.application_id%TYPE;
  
BEGIN
  -- Id do Usuario
  BEGIN 
    SELECT user_id 
      INTO l_nUserId 
      FROM fnd_user 
      WHERE user_name = l_vUserName;
  EXCEPTION
    WHEN OTHERS THEN 
      l_nUserId := NULL;    
  END;  
  
  -- dados da Responsabilidade
  BEGIN
    SELECT fav.application_short_name
         , frv.responsibility_key
         , frv.responsibility_id
         , frv.application_id
      INTO l_vRespApp
         , l_vRespKey
         , l_nRespId
         , l_nRespApplId
      FROM fnd_responsibility_vl frv
         , fnd_application_vl    fav
     WHERE UPPER(frv.responsibility_key) = UPPER(l_vRespKey)
       AND frv.application_id            = fav.application_id;
  EXCEPTION
    WHEN OTHERS THEN    
      l_vRespApp    := NULL;
      l_nRespId     := NULL;
      l_nRespApplId := NULL;     
    END;

  
  -- liberar acesso a responsabilidade para o usuario
  --
  IF l_vRespApp IS NOT NULL AND l_nUserId IS NOT NULL THEN 
    BEGIN
      fnd_user_pkg.addresp( username       => l_vUserName
                          , resp_app       => l_vRespApp
                          , resp_key       => l_vRespKey
                          , security_group => 'STANDARD'
                          , description    => NULL
                          , start_date     => SYSDATE
                          , end_date       => NULL);
     COMMIT;
    EXCEPTION
      WHEN OTHERS THEN  
        NULL;
    END;

    -- intialize the user.
    fnd_global.apps_initialize(user_id      => l_nUserId
                              ,resp_id      => l_nRespId
                              ,resp_appl_id => l_nRespApplId);   
   
    l_boolean :=fnd_request.set_repeat_options(repeat_time     => NULL     --to_char(sysdate,'hh24:mi:ss'),
                                              ,repeat_interval => 5        --Applies only when releat_time is null
                                              ,repeat_unit     => 'MINUTES'--Applies only when releat_time is null
                                              ,repeat_type     => 'START'  --Applies only when releat_time is null
                                               );
                                 
    IF l_boolean THEN
      l_conc_id := fnd_request.submit_request (application => 'XBOL'
                                              ,program     => 'SAE_AP_COPY_ATTACH_BANC_PAG'
                                              ,start_time  => NULL
                                              ,sub_request => NULL
                           );
    END IF;
 
    IF l_conc_id > 0 then
      dbms_output.put_line('Concurrent Program Id: '||l_conc_id);
    ELSE
      dbms_output.put_line('Error: submit_request');
    END IF;
    COMMIT;
  END IF;
EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line('Error: '||SQLERRM);     
  
END;
/

WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
