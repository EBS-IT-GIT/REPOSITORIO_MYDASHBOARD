WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

-- $Header: CUSAP045_001.sql 121.2 29/05/2020 12:00:00 appldev ship $
-- +==================================================================+
-- |                      SANTO ANTONIO ENERGIA                       |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   CUSAP045_001.sql                                               |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUS004                                                         |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   Script para Ajustar o Flexfield Attribute14 com o id da        |
-- |   invoice do m�dulo do RI.                                       | 
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan de Castro Gomes      25/05/2020                          |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--

DECLARE
BEGIN

  BEGIN 
    UPDATE apps.ap_invoices_all aia
       SET aia.attribute14 = aia.reference_key1
     WHERE UPPER(aia.source) LIKE 'CLL F189 INTEGRATED%'
       AND aia.attribute14 IS NULL;
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;   
  
  BEGIN 
    INSERT INTO apps.fnd_document_categories (CATEGORY_ID, APPLICATION_ID, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, NAME, START_DATE_ACTIVE, END_DATE_ACTIVE, ATTRIBUTE_CATEGORY, ATTRIBUTE1, ATTRIBUTE2, ATTRIBUTE3, ATTRIBUTE4, ATTRIBUTE5, ATTRIBUTE6, ATTRIBUTE7, ATTRIBUTE8, ATTRIBUTE9, ATTRIBUTE10, ATTRIBUTE11, ATTRIBUTE12, ATTRIBUTE13, ATTRIBUTE14, ATTRIBUTE15, DEFAULT_DATATYPE_ID) VALUES (1000689, null, SYSDATE, 37395, SYSDATE, 37395, 19039315, 'CUSTOM1000689', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 6);
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories (CATEGORY_ID, APPLICATION_ID, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, NAME, START_DATE_ACTIVE, END_DATE_ACTIVE, ATTRIBUTE_CATEGORY, ATTRIBUTE1, ATTRIBUTE2, ATTRIBUTE3, ATTRIBUTE4, ATTRIBUTE5, ATTRIBUTE6, ATTRIBUTE7, ATTRIBUTE8, ATTRIBUTE9, ATTRIBUTE10, ATTRIBUTE11, ATTRIBUTE12, ATTRIBUTE13, ATTRIBUTE14, ATTRIBUTE15, DEFAULT_DATATYPE_ID) VALUES (1000690, null, SYSDATE, 37395, SYSDATE, 37395, 19039315, 'CUSTOM1000690', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 6);
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories (CATEGORY_ID, APPLICATION_ID, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, NAME, START_DATE_ACTIVE, END_DATE_ACTIVE, ATTRIBUTE_CATEGORY, ATTRIBUTE1, ATTRIBUTE2, ATTRIBUTE3, ATTRIBUTE4, ATTRIBUTE5, ATTRIBUTE6, ATTRIBUTE7, ATTRIBUTE8, ATTRIBUTE9, ATTRIBUTE10, ATTRIBUTE11, ATTRIBUTE12, ATTRIBUTE13, ATTRIBUTE14, ATTRIBUTE15, DEFAULT_DATATYPE_ID) VALUES (1000691, null, SYSDATE, 37395, SYSDATE, 37395, 19039315, 'CUSTOM1000691', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 6);
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000689, 'US', 'CUSTOM1000689', 'Boleto', SYSDATE  , 37395, SYSDATE , 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000689, 'ESA', 'CUSTOM1000689', 'Boleto', SYSDATE , 37395, SYSDATE , 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000689, 'PTB', 'CUSTOM1000689', 'Boleto', SYSDATE , 37395, SYSDATE , 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000690, 'US', 'CUSTOM1000690', 'Comprovante de Pagamento', SYSDATE, 37395, SYSDATE, 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000690, 'ESA', 'CUSTOM1000690', 'Comprovante de Pagamento', SYSDATE, 37395, SYSDATE, 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000690, 'PTB', 'CUSTOM1000690', 'Comprovante de Pagamento', SYSDATE, 37395, SYSDATE, 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000691, 'US', 'CUSTOM1000691', 'Bancada Pagamento', SYSDATE, 37395, SYSDATE, 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000691, 'ESA', 'CUSTOM1000691', 'Bancada Pagamento', SYSDATE, 37395, SYSDATE, 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;
  BEGIN 
    INSERT INTO apps.fnd_document_categories_tl (CATEGORY_ID, LANGUAGE, NAME, USER_NAME, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, LAST_UPDATE_LOGIN, APP_SOURCE_VERSION, SOURCE_LANG) VALUES (1000691, 'PTB', 'CUSTOM1000691', 'Bancada Pagamento', SYSDATE, 37395, SYSDATE, 37395, 19039315, '<schema><<APPS>>', 'PTB');
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;  
  COMMIT;
END;
/

WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
