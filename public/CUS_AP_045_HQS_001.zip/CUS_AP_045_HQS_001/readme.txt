==============================================================================
CUSAP045_001 : Bancada de Pagamentos e Comprovantes
==============================================================================

Atualiza��o - CUSAP045_001
Produto     - XX Customizaciones
Data        - 02/06/2020 
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSAP045_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

Realizar instru��es descritas no arquivo que est� na pasta docs: "BR100 - SAE -  Custom Anexos v1.xls".
Realizar bounce.


Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: jSAECUSAP045.zip
                               BancadaComprovantePG.xml
                               BancadaPagamentoPG.xml
                               LoteLovRN.xml
                               CnpjLovRN.xml
                               FornecedorLovRN.xml
                               NumNfLovRN.xml
                               NumRiLovRN.xml
                               StatusPagtoLovRN.xml
                               DadosBancariosLovRN.xml
                               RetencaoLovRN.xml
                               SAE_AP_CONTROL_ATTACHAMENTS.tab
                               SAE_AP_CONTROL_ATTACHAMENTS.grt
                               SAE_AP_CONTROL_ATTACHAMENTS.syn
                               SAE_AP_CONTROL_REQUESTS.tab
                               SAE_AP_CONTROL_REQUESTS.grt
                               SAE_AP_CONTROL_REQUESTS.syn
                               SAE_AP_LOG_ALTERATION.tab
                               SAE_AP_LOG_ALTERATION.grt
                               SAE_AP_LOG_ALTERATION.syn
                               SAE_AP_RECOVER_BORDERO_PKS.pls
                               SAE_AP_RECOVER_BORDERO_PKB.pls
                               SAE_AP_RECOVER_BORDERO_PK.grt
                               SAE_AP_RECOVER_BORDERO_PK.syn
                               SAE_FND_CONC_REQUESTS_AIU_TRG.trg
                               SAERECOVERBORDERO_CCR.ldt
                               SAE_AP_BANCADA_RQG.ldt
                               SAE_AP_BANCADA_PAGAMENTOS_FNC.ldt
                               SAE_AP_BANCADA_COMPROVANTES_FNC.ldt
                               SAE_AP_BANCADA_MNU.ldt
                               SAE_EBS_AP_BANCADA_RSP.ldt
                               SAE_EBS_AP_BANCADA_RETENCAO_RSP.ldt
