  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_DM_ADJUST_PK" IS

   TYPE Lineas_Cbte_Rec IS RECORD(
                 tax_precedence                           ra_customer_trx_lines.tax_precedence%TYPE
               , tax_rate                                 ra_customer_trx_lines.tax_rate%TYPE
               , item_exception_rate_id                   ra_customer_trx_lines.item_exception_rate_id%TYPE
               , tax_exemption_id                         ra_customer_trx_lines.tax_exemption_id%TYPE
               , memo_line_id                             ra_customer_trx_lines.memo_line_id%TYPE
               , autorule_duration_processed              ra_customer_trx_lines.autorule_duration_processed%TYPE
               , uom_code                                 ra_customer_trx_lines.uom_code%TYPE
               , default_ussgl_transaction_code           ra_customer_trx_lines.default_ussgl_transaction_code%TYPE
               , default_ussgl_trx_code_context           ra_customer_trx_lines.default_ussgl_trx_code_context%TYPE
               , interface_line_attribute10               ra_customer_trx_lines.interface_line_attribute10%TYPE
               , interface_line_attribute11               ra_customer_trx_lines.interface_line_attribute11%TYPE
               , interface_line_attribute12               ra_customer_trx_lines.interface_line_attribute12%TYPE
               , interface_line_attribute13               ra_customer_trx_lines.interface_line_attribute13%TYPE
               , interface_line_attribute14               ra_customer_trx_lines.interface_line_attribute14%TYPE
               , interface_line_attribute15               ra_customer_trx_lines.interface_line_attribute15%TYPE
               , interface_line_attribute9                ra_customer_trx_lines.interface_line_attribute9%TYPE
               , vat_tax_id                               ra_customer_trx_lines.vat_tax_id%TYPE
               , autotax                                  ra_customer_trx_lines.autotax%TYPE
               , last_period_to_credit                    ra_customer_trx_lines.last_period_to_credit%TYPE
               , item_context                             ra_customer_trx_lines.item_context%TYPE
               , tax_exempt_flag                          ra_customer_trx_lines.tax_exempt_flag%TYPE
               , tax_exempt_number                        ra_customer_trx_lines.tax_exempt_number%TYPE
               , tax_exempt_reason_code                   ra_customer_trx_lines.tax_exempt_reason_code%TYPE
               , tax_vendor_return_code                   ra_customer_trx_lines.tax_vendor_return_code%TYPE
               , sales_tax_id                             ra_customer_trx_lines.sales_tax_id%TYPE
               , location_segment_id                      ra_customer_trx_lines.location_segment_id%TYPE
               , movement_id                              ra_customer_trx_lines.movement_id%TYPE
               , org_id                                   ra_customer_trx_lines.org_id%TYPE
               , attribute5                               ra_customer_trx_lines.attribute5%TYPE
               , attribute6                               ra_customer_trx_lines.attribute6%TYPE
               , attribute7                               ra_customer_trx_lines.attribute7%TYPE
               , attribute8                               ra_customer_trx_lines.attribute8%TYPE
               , attribute9                               ra_customer_trx_lines.attribute9%TYPE
               , attribute10                              ra_customer_trx_lines.attribute10%TYPE
               , request_id                               ra_customer_trx_lines.request_id%TYPE
               , program_application_id                   ra_customer_trx_lines.program_application_id%TYPE
               , program_id                               ra_customer_trx_lines.program_id%TYPE
               , program_update_date                      ra_customer_trx_lines.program_update_date%TYPE
               , rule_start_date                          ra_customer_trx_lines.rule_start_date%TYPE
               , initial_customer_trx_line_id             ra_customer_trx_lines.initial_customer_trx_line_id%TYPE
               , interface_line_context                   ra_customer_trx_lines.interface_line_context%TYPE
               , interface_line_attribute1                ra_customer_trx_lines.interface_line_attribute1%TYPE
               , interface_line_attribute2                ra_customer_trx_lines.interface_line_attribute2%TYPE
               , interface_line_attribute3                ra_customer_trx_lines.interface_line_attribute3%TYPE
               , interface_line_attribute4                ra_customer_trx_lines.interface_line_attribute4%TYPE
               , interface_line_attribute5                ra_customer_trx_lines.interface_line_attribute5%TYPE
               , interface_line_attribute6                ra_customer_trx_lines.interface_line_attribute6%TYPE
               , interface_line_attribute7                ra_customer_trx_lines.interface_line_attribute7%TYPE
               , interface_line_attribute8                ra_customer_trx_lines.interface_line_attribute8%TYPE
               , sales_order_source                       ra_customer_trx_lines.sales_order_source%TYPE
               , taxable_flag                             ra_customer_trx_lines.taxable_flag%TYPE
               , extended_amount                          ra_customer_trx_lines.extended_amount%TYPE
               , revenue_amount                           ra_customer_trx_lines.revenue_amount%TYPE
               , autorule_complete_flag                   ra_customer_trx_lines.autorule_complete_flag%TYPE
               , link_to_cust_trx_line_id                 ra_customer_trx_lines.link_to_cust_trx_line_id%TYPE
               , attribute11                              ra_customer_trx_lines.attribute11%TYPE
               , attribute12                              ra_customer_trx_lines.attribute12%TYPE
               , attribute13                              ra_customer_trx_lines.attribute13%TYPE
               , attribute14                              ra_customer_trx_lines.attribute14%TYPE
               , attribute15                              ra_customer_trx_lines.attribute15%TYPE
               , customer_trx_line_id                     ra_customer_trx_lines.customer_trx_line_id%TYPE
               , customer_trx_id                          ra_customer_trx_lines.customer_trx_id%TYPE
               , line_number                              ra_customer_trx_lines.line_number%TYPE
               , set_of_books_id                          ra_customer_trx_lines.set_of_books_id%TYPE
               , reason_code                              ra_customer_trx_lines.reason_code%TYPE
               , inventory_item_id                        ra_customer_trx_lines.inventory_item_id%TYPE
               , description                              ra_customer_trx_lines.description%TYPE
               , previous_customer_trx_id                 ra_customer_trx_lines.previous_customer_trx_id%TYPE
               , previous_customer_trx_line_id            ra_customer_trx_lines.previous_customer_trx_line_id%TYPE
               , quantity_ordered                         ra_customer_trx_lines.quantity_ordered%TYPE
               , quantity_credited                        ra_customer_trx_lines.quantity_credited%TYPE
               , quantity_invoiced                        ra_customer_trx_lines.quantity_invoiced%TYPE
               , unit_standard_price                      ra_customer_trx_lines.unit_standard_price%TYPE
               , unit_selling_price                       ra_customer_trx_lines.unit_selling_price%TYPE
               , sales_order                              ra_customer_trx_lines.sales_order%TYPE
               , sales_order_revision                     ra_customer_trx_lines.sales_order_revision%TYPE
               , sales_order_line                         ra_customer_trx_lines.sales_order_line%TYPE
               , sales_order_date                         ra_customer_trx_lines.sales_order_date%TYPE
               , accounting_rule_id                       ra_customer_trx_lines.accounting_rule_id%TYPE
               , accounting_rule_duration                 ra_customer_trx_lines.accounting_rule_duration%TYPE
               , line_type                                ra_customer_trx_lines.line_type%TYPE
               , attribute_category                       ra_customer_trx_lines.attribute_category%TYPE
               , attribute1                               ra_customer_trx_lines.attribute1%TYPE
               , attribute2                               ra_customer_trx_lines.attribute2%TYPE
               , attribute3                               ra_customer_trx_lines.attribute3%TYPE
               , attribute4                               ra_customer_trx_lines.attribute4%TYPE
               , global_attribute1                        ra_customer_trx_lines.global_attribute1%TYPE
               , global_attribute2                        ra_customer_trx_lines.global_attribute2%TYPE
               , global_attribute3                        ra_customer_trx_lines.global_attribute3%TYPE
               , global_attribute4                        ra_customer_trx_lines.global_attribute4%TYPE
               , global_attribute5                        ra_customer_trx_lines.global_attribute5%TYPE
               , global_attribute6                        ra_customer_trx_lines.global_attribute6%TYPE
               , global_attribute7                        ra_customer_trx_lines.global_attribute7%TYPE
               , global_attribute8                        ra_customer_trx_lines.global_attribute8%TYPE
               , global_attribute9                        ra_customer_trx_lines.global_attribute9%TYPE
               , global_attribute10                       ra_customer_trx_lines.global_attribute10%TYPE
               , global_attribute11                       ra_customer_trx_lines.global_attribute11%TYPE
               , global_attribute12                       ra_customer_trx_lines.global_attribute12%TYPE
               , global_attribute13                       ra_customer_trx_lines.global_attribute13%TYPE
               , global_attribute14                       ra_customer_trx_lines.global_attribute14%TYPE
               , global_attribute15                       ra_customer_trx_lines.global_attribute15%TYPE
               , global_attribute16                       ra_customer_trx_lines.global_attribute16%TYPE
               , global_attribute17                       ra_customer_trx_lines.global_attribute17%TYPE
               , global_attribute18                       ra_customer_trx_lines.global_attribute18%TYPE
               , global_attribute19                       ra_customer_trx_lines.global_attribute19%TYPE
               , global_attribute20                       ra_customer_trx_lines.global_attribute20%TYPE
               , global_attribute_category                ra_customer_trx_lines.global_attribute_category%TYPE
               , wh_update_date                           ra_customer_trx_lines.wh_update_date%TYPE
               , gross_unit_selling_price                 ra_customer_trx_lines.gross_unit_selling_price%TYPE
               , gross_extended_amount                    ra_customer_trx_lines.gross_extended_amount%TYPE
               , amount_includes_tax_flag                 ra_customer_trx_lines.amount_includes_tax_flag%TYPE
               , taxable_amount                           ra_customer_trx_lines.taxable_amount%TYPE
               , warehouse_id                             ra_customer_trx_lines.warehouse_id%TYPE
               , translated_description                   ra_customer_trx_lines.translated_description%TYPE
               , extended_acctd_amount                    ra_customer_trx_lines.extended_acctd_amount%TYPE
               , br_ref_customer_trx_id                   ra_customer_trx_lines.br_ref_customer_trx_id%TYPE
               , br_ref_payment_schedule_id               ra_customer_trx_lines.br_ref_payment_schedule_id%TYPE
               , br_adjustment_id                         ra_customer_trx_lines.br_adjustment_id%TYPE
               , mrc_extended_acctd_amount                ra_customer_trx_lines.mrc_extended_acctd_amount%TYPE
               , payment_set_id                           ra_customer_trx_lines.payment_set_id%TYPE
               , contract_line_id                         ra_customer_trx_lines.contract_line_id%TYPE
               , source_data_key1                         ra_customer_trx_lines.source_data_key1%TYPE
               , source_data_key2                         ra_customer_trx_lines.source_data_key2%TYPE
               , source_data_key3                         ra_customer_trx_lines.source_data_key3%TYPE
               , source_data_key4                         ra_customer_trx_lines.source_data_key4%TYPE
               , source_data_key5                         ra_customer_trx_lines.source_data_key5%TYPE
               , invoiced_line_acctg_level                ra_customer_trx_lines.invoiced_line_acctg_level%TYPE
               , ccid1                                    gl_code_combinations.code_combination_id%TYPE
               , ccid2                                    gl_code_combinations.code_combination_id%TYPE
               , gl_dist_amount1                          ra_cust_trx_line_gl_dist.amount%TYPE
               , gl_dist_amount2                          ra_cust_trx_line_gl_dist.amount%TYPE);
   TYPE Lineas_Cbte_Tbl IS TABLE OF Lineas_Cbte_Rec
   INDEX BY BINARY_INTEGER;

   TYPE Dist_Cbte_Rec IS RECORD(account_class               ra_cust_trx_line_gl_dist.account_class%TYPE
                               ,account_set_flag            ra_cust_trx_line_gl_dist.account_set_flag%TYPE
                               ,acctd_amount                ra_cust_trx_line_gl_dist.acctd_amount%TYPE
                               ,amount                      ra_cust_trx_line_gl_dist.amount%TYPE
                               ,attribute1                  ra_cust_trx_line_gl_dist.attribute1%TYPE
                               ,attribute10                 ra_cust_trx_line_gl_dist.attribute10%TYPE
                               ,attribute11                 ra_cust_trx_line_gl_dist.attribute11%TYPE
                               ,attribute12                 ra_cust_trx_line_gl_dist.attribute12%TYPE
                               ,attribute13                 ra_cust_trx_line_gl_dist.attribute13%TYPE
                               ,attribute14                 ra_cust_trx_line_gl_dist.attribute14%TYPE
                               ,attribute15                 ra_cust_trx_line_gl_dist.attribute15%TYPE
                               ,attribute2                  ra_cust_trx_line_gl_dist.attribute2%TYPE
                               ,attribute3                  ra_cust_trx_line_gl_dist.attribute3%TYPE
                               ,attribute4                  ra_cust_trx_line_gl_dist.attribute4%TYPE
                               ,attribute5                  ra_cust_trx_line_gl_dist.attribute5%TYPE
                               ,attribute6                  ra_cust_trx_line_gl_dist.attribute6%TYPE
                               ,attribute7                  ra_cust_trx_line_gl_dist.attribute7%TYPE
                               ,attribute8                  ra_cust_trx_line_gl_dist.attribute8%TYPE
                               ,attribute9                  ra_cust_trx_line_gl_dist.attribute9%TYPE
                               ,attribute_category          ra_cust_trx_line_gl_dist.attribute_category%TYPE
                               ,code_combination_id         ra_cust_trx_line_gl_dist.code_combination_id%TYPE
                               ,comments                    ra_cust_trx_line_gl_dist.comments%TYPE
                               ,concatenated_segments       ra_cust_trx_line_gl_dist.concatenated_segments%TYPE
                               ,created_by                  ra_cust_trx_line_gl_dist.created_by%TYPE
                               ,creation_date               ra_cust_trx_line_gl_dist.creation_date%TYPE
                               ,cust_trx_line_gl_dist_id    ra_cust_trx_line_gl_dist.cust_trx_line_gl_dist_id%TYPE
                               ,cust_trx_line_salesrep_id   ra_cust_trx_line_gl_dist.cust_trx_line_salesrep_id%TYPE
                               ,customer_trx_id             ra_cust_trx_line_gl_dist.customer_trx_id%TYPE
                               ,customer_trx_line_id        ra_cust_trx_line_gl_dist.customer_trx_line_id%TYPE
                               ,gl_date                     ra_cust_trx_line_gl_dist.gl_date%TYPE
                               ,gl_posted_date              ra_cust_trx_line_gl_dist.gl_posted_date%TYPE
                               ,last_update_date            ra_cust_trx_line_gl_dist.last_update_date%TYPE
                               ,last_update_login           ra_cust_trx_line_gl_dist.last_update_login%TYPE
                               ,last_updated_by             ra_cust_trx_line_gl_dist.last_updated_by%TYPE
                               ,latest_rec_flag             ra_cust_trx_line_gl_dist.latest_rec_flag%TYPE
                               ,org_id                      ra_cust_trx_line_gl_dist.org_id%TYPE
                               ,original_gl_date            ra_cust_trx_line_gl_dist.original_gl_date%TYPE
                               ,percent                     ra_cust_trx_line_gl_dist.percent%TYPE
                               ,post_request_id             ra_cust_trx_line_gl_dist.post_request_id%TYPE
                               ,posting_control_id          ra_cust_trx_line_gl_dist.posting_control_id%TYPE
                               ,program_application_id      ra_cust_trx_line_gl_dist.program_application_id%TYPE
                               ,program_id                  ra_cust_trx_line_gl_dist.program_id%TYPE
                               ,program_update_date         ra_cust_trx_line_gl_dist.program_update_date%TYPE
                               ,ra_post_loop_number         ra_cust_trx_line_gl_dist.ra_post_loop_number%TYPE
                               ,request_id                  ra_cust_trx_line_gl_dist.request_id%TYPE
                               ,set_of_books_id             ra_cust_trx_line_gl_dist.set_of_books_id%TYPE
                               ,ussgl_transaction_code      ra_cust_trx_line_gl_dist.ussgl_transaction_code%TYPE
                               ,ussgl_transaction_code_context  ra_cust_trx_line_gl_dist.ussgl_transaction_code_context%TYPE);

   TYPE Dist_Cbte_Tbl IS TABLE OF Dist_Cbte_Rec
   INDEX BY BINARY_INTEGER;

    PROCEDURE create_dm (retcode        OUT VARCHAR2
                        ,errbuf         OUT VARCHAR2
                        ,p_cust_account_id  IN  NUMBER
                        ,p_date_from        IN  VARCHAR2
                        ,p_date_to          IN  VARCHAR2
                        ,p_receipt_method_id  IN  NUMBER
                        ,p_number_from        IN  VARCHAR2
                        ,p_number_to          IN  VARCHAR2
--                        ,p_flg_prov           IN  VARCHAR2
                        ,p_days               IN  NUMBER);

END XX_AR_DM_ADJUST_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_DM_ADJUST_PK" IS

  g_user_id         number := fnd_global.user_id;
  g_login_id        number := fnd_global.login_id;
  g_conc_request_id number := fnd_global.conc_request_id;
  g_org_id          number := NVL(mo_global.get_current_org_id,fnd_profile.value('ORG_ID'));
  g_user_name       varchar2(30);

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    print_log                                                             |
|                                                                          |
| Description                                                              |
|    Impresion de log                                                      |
|                                                                          |
|                                                                          |
| Parameters                                                               |
|    p_message                   IN     NUMBER    Mensaje.                 |
|                                                                          |
+=========================================================================*/
    PROCEDURE print_log(p_message IN VARCHAR2) IS
    BEGIN
        fnd_file.put_line(fnd_file.log,p_message);
    END;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    print_output                                                          |
|                                                                          |
| Description                                                              |
|    Impresion de output                                                   |
|                                                                          |
|                                                                          |
| Parameters                                                               |
|    p_message                   IN     NUMBER    Mensaje.                 |
|                                                                          |
+=========================================================================*/

    PROCEDURE print_output(p_message IN VARCHAR2) IS
    BEGIN
        fnd_file.put_line(fnd_file.output,p_message);
    END;


/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Generar_Cabecera                                                      |
|                                                                          |
| Description                                                              |
|    Crea la cabecera de un comprobante en AR, pudiento este ser una ND,   |
|    ND, etc.                                                              |
|                                                                          |
| Parameters                                                               |
|    p_r_trx_header     Registro con datos de la cabecera del comprobante  |
|    p_tipo_cbte        Tipo de comprobante a generar                      |
|    p_gl_date          Fecha de la transaccion                            |
|    p_extended_amount  Extended amount para la Cuenta Contable. Es la suma|
|                       del extended amount de las lineas del comprobante  |
|                       (en negativo)                                      |
|    p_nombre_form      Nombre del form llamador                           |
|    x_customer_trx_id  Id del comprobante generado                        |
|    x_trx_number       Numero de transaccion                              |
|    x_msg_error        Mensaje de error de salida                         |
|                                                                          |
+=========================================================================*/
FUNCTION Generar_cabecera     (  p_r_trx_header     IN OUT NOCOPY ra_customer_trx%ROWTYPE
                               , p_tipo_cbte        IN     ra_cust_trx_types.TYPE%TYPE
                               , p_gl_date          IN     DATE
                               , p_extended_amount  IN     ra_customer_trx_lines.extended_amount%TYPE
                               , p_nombre_form      IN     VARCHAR2
                               , p_receivable_ccid  IN     gl_code_combinations.code_combination_id%TYPE
                               , x_customer_trx_id     OUT ra_customer_trx.customer_trx_id%TYPE
                               , x_trx_number          OUT ra_customer_trx.trx_number%TYPE
                               , p_run_autoacc_flag    IN     VARCHAR2 --Agregado KHRONUS/MNazarre 20141103: Se agrego logica de creacion de distribuciones
                               , p_status_code   OUT VARCHAR2
                               , p_error_message OUT VARCHAR2)
RETURN BOOLEAN
IS
   l_commitment_rec        arp_process_commitment.commitment_rec_type;
   l_customer_trx_line_id  ra_customer_trx_lines.customer_trx_line_id%TYPE;
   l_row_id                ROWID;
   l_status                VARCHAR2(2000);
BEGIN
    p_status_code   := null;
    p_error_message := null;

    print_log('XX_AR_DM_ADJUST_PK_PK.Generar_cabecera (+)');
--    print_log('Tipo cbte ' ||p_tipo_cbte );

   l_commitment_rec.extended_amount := p_extended_amount;

   arp_process_header.insert_header(p_form_name            => p_nombre_form,
                                    p_form_version         => NULL,
                                    p_trx_rec              => p_r_trx_header,
                                    p_trx_class            => p_tipo_cbte,
                                    p_gl_date              => p_gl_date,
                                    p_term_in_use_flag     => NULL,
                                    p_commitment_rec       => l_commitment_rec,
                                    p_trx_number           => x_trx_number,
                                    p_customer_trx_id      => x_customer_trx_id,
                                    p_customer_trx_line_id => l_customer_trx_line_id ,
                                    p_row_id               => l_row_id,
                                    p_status               => l_status,
                                    p_receivable_ccid      => p_receivable_ccid,
                                    p_run_autoacc_flag     => 'Y');

   IF (ltrim(rtrim(l_status)) != 'OK') THEN
      p_error_message := fnd_message.get;
      fnd_message.set_name('XX', 'XX_AR_TRX_ERROR_ALTA_CABECERA');
      fnd_message.set_token('XX_STATUS', l_status);
      fnd_message.set_token('XX_ERROR', p_error_message);
      p_error_message := fnd_message.get;
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_cabecera '|| p_error_message);
      RETURN (FALSE);
   END IF;

  -- print_log('XX_AR_DM_ADJUST_PK_PK.Generar_cabecera: TransacciÃ¿Â³enerada: '||
  --                   x_trx_number||', '||'Transaction customer id: '||x_customer_trx_id);
   print_log('XX_AR_DM_ADJUST_PK_PK.Generar_cabecera (-)');

   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
      fnd_message.set_name('XX', 'XX_AR_TRX_OTHERS_ALTA_CABECERA');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      p_error_message := fnd_message.get;
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_cabecera Other'|| p_error_message);

      RETURN (FALSE);
END Generar_cabecera;

/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Generar_lineas                                                        |
|                                                                          |
| Description                                                              |
|    Crea las lineas de un comprobante en AR, pudiento este ser una ND,    |
|    ND, etc.                                                              |
|                                                                          |
| Parameters                                                               |
|    p_trx_lineas          Tabla con las lineas a insertar en el cpbte     |
|    p_tipo_cbte           Tipo de comprobante a generar                   |
|    p_nombre_form         Nombre del form llamador                        |
|    p_ccid1_par           Cuenta contable 1                               |
|    p_ccid2_par           Cuenta contable 2                               |
|    p_amount1_par         Importe 1                                       |
|    p_amount2_par         Importe 2                                       |
|    p_rule_start_date_par                                                 |
|    p_accounting_rule_dur                                                 |
|    p_gl_date_par         Gl Date                                         |
|    p_trx_date_par        Fecha del comprobante                           |
|    p_hder_currency_code  Codigo de moneda                                |
|    p_hder_exchange_rate  Tipo de cambio                                  |
|    x_msg_error           Mensaje de error de salida                      |
|                                                                          |
+=========================================================================*/
FUNCTION Generar_lineas ( p_trx_lineas          IN OUT NOCOPY Lineas_Cbte_Tbl
                        , p_customer_trx_id     IN     ra_customer_trx.customer_trx_id%TYPE
                        , p_tipo_cbte           IN     ra_cust_trx_types.TYPE%TYPE
                        , p_nombre_form         IN     VARCHAR2
                        , p_gl_date_par         IN OUT NOCOPY ra_cust_trx_line_gl_dist.gl_date%TYPE
                        , p_trx_date_par        IN OUT DATE
                        , p_hder_currency_code  IN     ra_customer_trx.invoice_currency_code%TYPE
                        , p_hder_exchange_rate  IN     ra_customer_trx.exchange_rate%TYPE
                        , p_run_autoacc_flag    IN     VARCHAR2 --Agregado KHRONUS/MNazarre 20141103: Se agrego logica de creacion de distribuciones
                        , p_status_code   OUT VARCHAR2
                        , p_error_message OUT VARCHAR2)

RETURN BOOLEAN
IS
   l_r_trx_linea      ra_customer_trx_lines%ROWTYPE;
   l_r_trx_dist       ra_cust_trx_line_gl_dist%ROWTYPE;
   l_cust_trx_line_id ra_customer_trx_lines.customer_trx_line_id%TYPE;
   l_status           VARCHAR2(2000);

   l_exchange_rate          ra_customer_trx.exchange_rate%TYPE;
   l_invoice_currency_code  ra_customer_trx.invoice_currency_code%TYPE;
   l_cust_trx_line_gl_dist_id   ra_cust_trx_line_gl_dist.cust_trx_line_gl_dist_id%TYPE;

   CURSOR cur_dist  (p_new_customer_trx_id      NUMBER
                    ,p_new_customer_trx_line_id NUMBER
                    ,p_gl_date                  DATE)
    IS
    SELECT   NULL post_request_id,
             NULL posting_control_id,
             'REV' account_class,
             NULL ra_post_loop_number,
             p_new_customer_trx_id customer_trx_id,
             'N' account_set_flag,
             --r.acctd_amount,
             NULL ussgl_transaction_code,
             NULL ussgl_transaction_code_context,
             NULL attribute11,
             NULL attribute12,
             NULL attribute13,
             NULL attribute14,
             NULL attribute15,
             NULL latest_rec_flag,
             null cust_trx_line_gl_dist_id,
             p_new_customer_trx_line_id customer_trx_line_id,
             --4566 code_combination_id,
             sysdate last_update_date,
             g_user_id last_updated_by,
             sysdate creation_date,
             g_user_id created_by,
             g_login_id last_update_login,
             100 percent,
             --r.amount,
             p_gl_date gl_date,
             null gl_posted_date,
             null cust_trx_line_salesrep_id,
             null comments,
             null attribute_category,
             null attribute1,
             null attribute2,
             null attribute3,
             null attribute4,
             null attribute5,
             null attribute6,
             null attribute7,
             null attribute8,
             null attribute9,
             null attribute10,
             null request_id,
             null program_application_id,
             null program_id,
             null program_update_date,
             null concatenated_segments,
             p_gl_date original_gl_date,
             null collected_tax_ccid,
             null collected_tax_concat_seg,
             null revenue_adjustment_id,
             null rev_adj_class_temp,
             null rec_offset_flag
     FROM   dual;

BEGIN
   print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas (+)');


   FOR i IN 1..p_trx_lineas.count LOOP
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas: Antes de armar el registro nro='||i);

      l_r_trx_linea.tax_precedence                 := p_trx_lineas(i).tax_precedence;
      l_r_trx_linea.tax_rate                       := p_trx_lineas(i).tax_rate;
      l_r_trx_linea.item_exception_rate_id         := p_trx_lineas(i).item_exception_rate_id;
      l_r_trx_linea.tax_exemption_id               := p_trx_lineas(i).tax_exemption_id;
      l_r_trx_linea.memo_line_id                   := p_trx_lineas(i).memo_line_id;
      l_r_trx_linea.autorule_duration_processed    := p_trx_lineas(i).autorule_duration_processed;
      l_r_trx_linea.uom_code                       := p_trx_lineas(i).uom_code;
      l_r_trx_linea.default_ussgl_transaction_code := p_trx_lineas(i).default_ussgl_transaction_code;
      l_r_trx_linea.default_ussgl_trx_code_context := p_trx_lineas(i).default_ussgl_trx_code_context;
      l_r_trx_linea.interface_line_attribute10     := p_trx_lineas(i).interface_line_attribute10;
      l_r_trx_linea.interface_line_attribute11     := p_trx_lineas(i).interface_line_attribute11;
      l_r_trx_linea.interface_line_attribute12     := p_trx_lineas(i).interface_line_attribute12;
      l_r_trx_linea.interface_line_attribute13     := p_trx_lineas(i).interface_line_attribute13;
      l_r_trx_linea.interface_line_attribute14     := p_trx_lineas(i).interface_line_attribute14;
      l_r_trx_linea.interface_line_attribute15     := p_trx_lineas(i).interface_line_attribute15;
      l_r_trx_linea.interface_line_attribute9      := p_trx_lineas(i).interface_line_attribute9;
      l_r_trx_linea.vat_tax_id                     := p_trx_lineas(i).vat_tax_id;
      l_r_trx_linea.autotax                        := p_trx_lineas(i).autotax;
      l_r_trx_linea.last_period_to_credit          := p_trx_lineas(i).last_period_to_credit;
      l_r_trx_linea.item_context                   := p_trx_lineas(i).item_context;
      l_r_trx_linea.tax_exempt_flag                := p_trx_lineas(i).tax_exempt_flag;
      l_r_trx_linea.tax_exempt_number              := p_trx_lineas(i).tax_exempt_number;
      l_r_trx_linea.tax_exempt_reason_code         := p_trx_lineas(i).tax_exempt_reason_code;
      l_r_trx_linea.tax_vendor_return_code         := p_trx_lineas(i).tax_vendor_return_code;
      l_r_trx_linea.sales_tax_id                   := p_trx_lineas(i).sales_tax_id;
      l_r_trx_linea.location_segment_id            := p_trx_lineas(i).location_segment_id;
      l_r_trx_linea.movement_id                    := p_trx_lineas(i).movement_id;
      l_r_trx_linea.org_id                         := p_trx_lineas(i).org_id;
      l_r_trx_linea.attribute5                     := p_trx_lineas(i).attribute5;
      l_r_trx_linea.attribute6                     := p_trx_lineas(i).attribute6;
      l_r_trx_linea.attribute7                     := p_trx_lineas(i).attribute7;
      l_r_trx_linea.attribute8                     := p_trx_lineas(i).attribute8;
      l_r_trx_linea.attribute9                     := p_trx_lineas(i).attribute9;
      l_r_trx_linea.attribute10                    := p_trx_lineas(i).attribute10;
      l_r_trx_linea.request_id                     := p_trx_lineas(i).request_id;
      l_r_trx_linea.program_application_id         := p_trx_lineas(i).program_application_id;
      l_r_trx_linea.program_id                     := p_trx_lineas(i).program_id;
      l_r_trx_linea.program_update_date            := p_trx_lineas(i).program_update_date;
      l_r_trx_linea.rule_start_date                := p_trx_lineas(i).rule_start_date;
      l_r_trx_linea.initial_customer_trx_line_id   := p_trx_lineas(i).initial_customer_trx_line_id;
      l_r_trx_linea.interface_line_context         := p_trx_lineas(i).interface_line_context;
      l_r_trx_linea.interface_line_attribute1      := p_trx_lineas(i).interface_line_attribute1;
      l_r_trx_linea.interface_line_attribute2      := p_trx_lineas(i).interface_line_attribute2;
      l_r_trx_linea.interface_line_attribute3      := p_trx_lineas(i).interface_line_attribute3;
      l_r_trx_linea.interface_line_attribute4      := p_trx_lineas(i).interface_line_attribute4;
      l_r_trx_linea.interface_line_attribute5      := p_trx_lineas(i).interface_line_attribute5;
      l_r_trx_linea.interface_line_attribute6      := p_trx_lineas(i).interface_line_attribute6;
      l_r_trx_linea.interface_line_attribute7      := p_trx_lineas(i).interface_line_attribute7;
      l_r_trx_linea.interface_line_attribute8      := p_trx_lineas(i).interface_line_attribute8;
      l_r_trx_linea.sales_order_source             := p_trx_lineas(i).sales_order_source;
      l_r_trx_linea.taxable_flag                   := p_trx_lineas(i).taxable_flag;
      l_r_trx_linea.extended_amount                := p_trx_lineas(i).extended_amount;
      l_r_trx_linea.revenue_amount                 := p_trx_lineas(i).revenue_amount;
      l_r_trx_linea.autorule_complete_flag         := p_trx_lineas(i).autorule_complete_flag;
      l_r_trx_linea.link_to_cust_trx_line_id       := p_trx_lineas(i).link_to_cust_trx_line_id;
      l_r_trx_linea.attribute11                    := p_trx_lineas(i).attribute11;
      l_r_trx_linea.attribute12                    := p_trx_lineas(i).attribute12;
      l_r_trx_linea.attribute13                    := p_trx_lineas(i).attribute13;
      l_r_trx_linea.attribute14                    := p_trx_lineas(i).attribute14;
      l_r_trx_linea.attribute15                    := p_trx_lineas(i).attribute15;
      l_r_trx_linea.customer_trx_line_id           := p_trx_lineas(i).customer_trx_line_id;
      l_r_trx_linea.line_number                    := p_trx_lineas(i).line_number;
      l_r_trx_linea.set_of_books_id                := p_trx_lineas(i).set_of_books_id;
      l_r_trx_linea.reason_code                    := p_trx_lineas(i).reason_code;
      l_r_trx_linea.inventory_item_id              := p_trx_lineas(i).inventory_item_id;
      l_r_trx_linea.description                    := p_trx_lineas(i).description;
      l_r_trx_linea.previous_customer_trx_id       := p_trx_lineas(i).previous_customer_trx_id;
      l_r_trx_linea.previous_customer_trx_line_id  := p_trx_lineas(i).previous_customer_trx_line_id;
      l_r_trx_linea.quantity_ordered               := p_trx_lineas(i).quantity_ordered;
      l_r_trx_linea.quantity_credited              := p_trx_lineas(i).quantity_credited;
      l_r_trx_linea.quantity_invoiced              := p_trx_lineas(i).quantity_invoiced;
      l_r_trx_linea.unit_standard_price            := p_trx_lineas(i).unit_standard_price;
      l_r_trx_linea.unit_selling_price             := p_trx_lineas(i).unit_selling_price;
      l_r_trx_linea.sales_order                    := p_trx_lineas(i).sales_order;
      l_r_trx_linea.sales_order_revision           := p_trx_lineas(i).sales_order_revision;
      l_r_trx_linea.sales_order_line               := p_trx_lineas(i).sales_order_line;
      l_r_trx_linea.sales_order_date               := p_trx_lineas(i).sales_order_date;
      l_r_trx_linea.accounting_rule_id             := p_trx_lineas(i).accounting_rule_id;
      l_r_trx_linea.accounting_rule_duration       := p_trx_lineas(i).accounting_rule_duration;
        print_log('XX DATOS ACCOUNTING '||L_R_TRX_LINEA.ACCOUNTING_RULE_ID||' '||L_R_TRX_LINEA.ACCOUNTING_RULE_DURATION);

      l_r_trx_linea.line_type                      := p_trx_lineas(i).line_type;
      l_r_trx_linea.attribute_category             := p_trx_lineas(i).attribute_category;
      l_r_trx_linea.attribute1                     := p_trx_lineas(i).attribute1;
      l_r_trx_linea.attribute2                     := p_trx_lineas(i).attribute2;
      l_r_trx_linea.attribute3                     := p_trx_lineas(i).attribute3;
      l_r_trx_linea.attribute4                     := p_trx_lineas(i).attribute4;
      l_r_trx_linea.global_attribute1              := p_trx_lineas(i).global_attribute1;
      l_r_trx_linea.global_attribute2              := p_trx_lineas(i).global_attribute2;
      l_r_trx_linea.global_attribute3              := p_trx_lineas(i).global_attribute3;
      l_r_trx_linea.global_attribute4              := p_trx_lineas(i).global_attribute4;
      l_r_trx_linea.global_attribute5              := p_trx_lineas(i).global_attribute5;
      l_r_trx_linea.global_attribute6              := p_trx_lineas(i).global_attribute6;
      l_r_trx_linea.global_attribute7              := p_trx_lineas(i).global_attribute7;
      l_r_trx_linea.global_attribute8              := p_trx_lineas(i).global_attribute8;
      l_r_trx_linea.global_attribute9              := p_trx_lineas(i).global_attribute9;
      l_r_trx_linea.global_attribute10             := p_trx_lineas(i).global_attribute10;
      l_r_trx_linea.global_attribute11             := p_trx_lineas(i).global_attribute11;
      l_r_trx_linea.global_attribute12             := p_trx_lineas(i).global_attribute12;
      l_r_trx_linea.global_attribute13             := p_trx_lineas(i).global_attribute13;
      l_r_trx_linea.global_attribute14             := p_trx_lineas(i).global_attribute14;
      l_r_trx_linea.global_attribute15             := p_trx_lineas(i).global_attribute15;
      l_r_trx_linea.global_attribute16             := p_trx_lineas(i).global_attribute16;
      l_r_trx_linea.global_attribute17             := p_trx_lineas(i).global_attribute17;
      l_r_trx_linea.global_attribute18             := p_trx_lineas(i).global_attribute18;
      l_r_trx_linea.global_attribute19             := p_trx_lineas(i).global_attribute19;
      l_r_trx_linea.global_attribute20             := p_trx_lineas(i).global_attribute20;
      l_r_trx_linea.global_attribute_category      := p_trx_lineas(i).global_attribute_category;
      l_r_trx_linea.wh_update_date                 := p_trx_lineas(i).wh_update_date;
      l_r_trx_linea.gross_unit_selling_price       := p_trx_lineas(i).gross_unit_selling_price;
      l_r_trx_linea.gross_extended_amount          := p_trx_lineas(i).gross_extended_amount;
      l_r_trx_linea.amount_includes_tax_flag       := p_trx_lineas(i).amount_includes_tax_flag;
      l_r_trx_linea.taxable_amount                 := p_trx_lineas(i).taxable_amount;
      l_r_trx_linea.warehouse_id                   := p_trx_lineas(i).warehouse_id;
      l_r_trx_linea.translated_description         := p_trx_lineas(i).translated_description;
      l_r_trx_linea.extended_acctd_amount          := p_trx_lineas(i).extended_acctd_amount;
      l_r_trx_linea.br_ref_customer_trx_id         := p_trx_lineas(i).br_ref_customer_trx_id;
      l_r_trx_linea.br_ref_payment_schedule_id     := p_trx_lineas(i).br_ref_payment_schedule_id;
      l_r_trx_linea.br_adjustment_id               := p_trx_lineas(i).br_adjustment_id;
      l_r_trx_linea.mrc_extended_acctd_amount      := p_trx_lineas(i).mrc_extended_acctd_amount;
      l_r_trx_linea.payment_set_id                 := p_trx_lineas(i).payment_set_id;
      l_r_trx_linea.contract_line_id               := p_trx_lineas(i).contract_line_id;
      l_r_trx_linea.source_data_key1               := p_trx_lineas(i).source_data_key1;
      l_r_trx_linea.source_data_key2               := p_trx_lineas(i).source_data_key2;
      l_r_trx_linea.source_data_key3               := p_trx_lineas(i).source_data_key3;
      l_r_trx_linea.source_data_key4               := p_trx_lineas(i).source_data_key4;
      l_r_trx_linea.source_data_key5               := p_trx_lineas(i).source_data_key5;
      l_r_trx_linea.invoiced_line_acctg_level      := p_trx_lineas(i).invoiced_line_acctg_level;
      l_r_trx_linea.customer_trx_id                := p_customer_trx_id;

      print_log('Code combination id '||p_trx_lineas(i).ccid1||' '||p_trx_lineas(i).ccid2);

      -- --------------------------------------------------------------
      -- Inserto una linea en la nueva transaccion --------------------

      arp_process_line.insert_line( p_form_name                => p_nombre_form
                                  , p_form_version             => NULL
                                  , p_line_rec                 => l_r_trx_linea
                                  , p_memo_line_type           => l_r_trx_linea.line_type
                                  , p_customer_trx_line_id     => l_cust_trx_line_id
                                  , p_trx_class                => p_tipo_cbte
                                  , p_ccid1                    => p_trx_lineas(i).ccid1
                                  , p_ccid2                    => p_trx_lineas(i).ccid2
                                  , p_amount1                  => p_trx_lineas(i).extended_acctd_amount --p_trx_lineas(i).gl_dist_amount1
                                  , p_amount2                  => p_trx_lineas(i).gl_dist_amount2
                                  , p_rule_start_date          => l_r_trx_linea.rule_start_date
                                  , p_accounting_rule_duration => l_r_trx_linea.accounting_rule_duration
                                  , p_gl_date                  => p_gl_date_par
                                  , p_trx_date                 => p_trx_date_par
                                  , p_header_currency_code     => p_hder_currency_code
                                  , p_header_exchange_rate     => p_hder_exchange_rate
                                  , p_status                   => l_status
                                  , p_run_autoacc_flag         => p_run_autoacc_flag --'Y' Modificado KHRONUS/MNazarre 20141103 Se agrego logica de copia de dist
                                  , p_run_tax_flag             => 'Y'
                                  , p_create_salescredits_flag => 'Y');

      IF (l_status != 'OK') THEN
         p_error_message := fnd_message.get;
         fnd_message.set_name('XX', 'XX_AR_TRX_ERROR_ALTA_ITEMS ');
         fnd_message.set_token('XX_STATUS',l_status);
         fnd_message.set_token('XX_ERROR', p_error_message);
         p_error_message := fnd_message.get;
         print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas: '||p_error_message||' Status: '||l_status);

         RETURN (FALSE);
      ELSE
            print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas: Se cargo el item '||l_cust_trx_line_id||' con exito');

            l_exchange_rate := p_hder_exchange_rate;
            l_invoice_currency_code := p_hder_currency_code;

            FOR r_dist IN cur_dist(p_trx_lineas(i).customer_Trx_id
                                  ,p_trx_lineas(i).customer_Trx_line_id
                                  ,p_gl_date_par) LOOP
            BEGIN
                print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas, Armado Distribuciones: Inicio registro nro='||i);

                print_log('p_trx_lineas(i).set_of_books_id '||p_trx_lineas(i).set_of_books_id);
                print_log('p_trx_lineas(i).extended_amount '||p_trx_lineas(i).extended_amount);
                print_log('p_trx_lineas(i).org_id '||p_trx_lineas(i).org_id);
                print_log('p_trx_lineas(i).extended_amount '||p_trx_lineas(i).extended_amount);
                print_log('l_cust_trx_line_id '||l_cust_trx_line_id);
                print_log('p_customer_trx_id '||p_customer_trx_id);

                l_r_trx_dist.post_request_id                        := r_dist.post_request_id;
                l_r_trx_dist.posting_control_id                     := r_dist.posting_control_id;
                l_r_trx_dist.account_class                          := r_dist.account_class;
                l_r_trx_dist.ra_post_loop_number                    := r_dist.ra_post_loop_number;
                l_r_trx_dist.customer_trx_id                        := p_customer_trx_id;
                l_r_trx_dist.account_set_flag                       := r_dist.account_set_flag;
                l_r_trx_dist.acctd_amount                           := p_trx_lineas(i).extended_amount;
                l_r_trx_dist.ussgl_transaction_code                 := r_dist.ussgl_transaction_code;
                l_r_trx_dist.ussgl_transaction_code_context         := r_dist.ussgl_transaction_code_context;
                l_r_trx_dist.attribute11                            := r_dist.attribute11;
                l_r_trx_dist.attribute12                            := r_dist.attribute12;
                l_r_trx_dist.attribute13                            := r_dist.attribute13;
                l_r_trx_dist.attribute14                            := r_dist.attribute14;
                l_r_trx_dist.attribute15                            := r_dist.attribute15;
                l_r_trx_dist.latest_rec_flag                        := r_dist.latest_rec_flag;
                l_r_trx_dist.org_id                                 := g_org_id;
                l_r_trx_dist.cust_trx_line_gl_dist_id               := r_dist.cust_trx_line_gl_dist_id;
                l_r_trx_dist.customer_trx_line_id                   := l_cust_trx_line_id;
                l_r_trx_dist.code_combination_id                    := p_trx_lineas(i).ccid1; --r_dist.code_combination_id;
                l_r_trx_dist.set_of_books_id                        := p_trx_lineas(i).set_of_books_id;
                l_r_trx_dist.last_update_date                       := r_dist.last_update_date;
                l_r_trx_dist.last_updated_by                        := r_dist.last_updated_by;
                l_r_trx_dist.creation_date                          := r_dist.creation_date;
                l_r_trx_dist.created_by                             := r_dist.created_by;
                l_r_trx_dist.last_update_login                      := r_dist.last_update_login;
                l_r_trx_dist.percent                                := r_dist.percent;
                l_r_trx_dist.amount                                 := p_trx_lineas(i).extended_amount;
                l_r_trx_dist.gl_date                                := r_dist.gl_date;
                l_r_trx_dist.gl_posted_date                         := r_dist.gl_posted_date;
                l_r_trx_dist.cust_trx_line_salesrep_id              := r_dist.cust_trx_line_salesrep_id;
                l_r_trx_dist.comments                               := r_dist.comments;
                l_r_trx_dist.attribute_category                     := r_dist.attribute_category;
                l_r_trx_dist.attribute1                             := r_dist.attribute1;
                l_r_trx_dist.attribute2                             := r_dist.attribute2;
                l_r_trx_dist.attribute3                             := r_dist.attribute3;
                l_r_trx_dist.attribute4                             := r_dist.attribute4;
                l_r_trx_dist.attribute5                             := r_dist.attribute5;
                l_r_trx_dist.attribute6                             := r_dist.attribute6;
                l_r_trx_dist.attribute7                             := r_dist.attribute7;
                l_r_trx_dist.attribute8                             := r_dist.attribute8;
                l_r_trx_dist.attribute9                             := r_dist.attribute9;
                l_r_trx_dist.attribute10                            := r_dist.attribute10;
                l_r_trx_dist.request_id                             := r_dist.request_id;
                l_r_trx_dist.program_application_id                 := r_dist.program_application_id;
                l_r_trx_dist.program_id                             := r_dist.program_id;
                l_r_trx_dist.program_update_date                    := r_dist.program_update_date;
                l_r_trx_dist.concatenated_segments                  := r_dist.concatenated_segments;
                l_r_trx_dist.original_gl_date                       := r_dist.original_gl_date;
                l_r_trx_dist.collected_tax_ccid                     := r_dist.collected_tax_ccid;
                l_r_trx_dist.collected_tax_concat_seg               := r_dist.collected_tax_concat_seg;
                l_r_trx_dist.revenue_adjustment_id                  := r_dist.revenue_adjustment_id;
                l_r_trx_dist.rev_adj_class_temp                     := r_dist.rev_adj_class_temp;
                l_r_trx_dist.rec_offset_flag                        := r_dist.rec_offset_flag;

                ARP_PROCESS_DIST.insert_dist(   'ARTPTRXB',
                                                1.0,
                                                l_r_trx_dist,
                                                l_exchange_rate,
                                                l_invoice_currency_code,
                                                NULL,
                                                NULL,
                                                l_cust_trx_line_gl_dist_id);


                print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas, Armado Distribuciones: Fin registro nro='||i);
            END;
            END LOOP;

      END IF;
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas: Finalizado el alta de la linea='||i||
                         ', id generado='||l_cust_trx_line_id);

   END LOOP;
   print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas (-)');

   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
      print_log('Error al generar lineas '||sqlerrm);
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_OTHERS_ALTA_ITEMS');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      p_error_message := fnd_message.get;
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_lineas: Error General='||sqlerrm);

      RETURN (FALSE);
END Generar_lineas;
/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Generar_comprobante_AR                                                |
|                                                                          |
| Description                                                              |
|    Crea un comprobante en AR, pudiento este ser una ND, ND, etc.         |
|                                                                          |
| Parameters                                                               |
|    p_r_trx_header     Registro con datos de la cabecera del comprobante  |
|    p_tipo_cbte        Tipo de comprobante a generar                      |
|    p_gl_date          Fecha de la transaccion                            |
|    p_extended_amount  Extended amount para la Cuenta Contable. Es la suma|
|                       del extended amount de las lineas del comprobante  |
|                       (en negativo)                                      |
|    p_nombre_form      Nombre del form llamador                           |
|    x_customer_trx_id  Id del comprobante generado                        |
|    x_trx_number       Numero de transaccion                              |
|    x_msg_error        Mensaje de error de salida                         |
|                                                                          |
+=========================================================================*/
FUNCTION Generar_comprobante_AR (p_status_code   IN OUT VARCHAR2
                                 , p_error_message IN OUT VARCHAR2
                                 , p_r_trx_header        IN OUT NOCOPY ra_customer_trx%ROWTYPE
                                 , p_trx_lineas          IN OUT NOCOPY Lineas_Cbte_Tbl
                                 , p_tipo_cbte           IN     ra_cust_trx_types.TYPE%TYPE
                                 , p_gl_date             IN OUT NOCOPY DATE
                                 , p_receivable_ccid     IN     gl_code_combinations.code_combination_id%TYPE
                                 , p_hder_currency_code  IN     ra_customer_trx.invoice_currency_code%TYPE
                                 , p_hder_exchange_rate  IN     ra_customer_trx.exchange_rate%TYPE
                                 , p_nombre_form         IN     VARCHAR2
                                 , p_trx_date            IN OUT DATE
                                 , x_customer_trx_id        OUT ra_customer_trx.customer_trx_id%TYPE
                                 , x_trx_number             OUT ra_customer_trx.trx_number%TYPE
                                 , p_run_autoacc_flag    IN     VARCHAR2 --Agregado KHRONUS/MNazarre 20141103: Se agrego logica de creacion de distribuciones
                                 )
RETURN BOOLEAN
IS
   l_extended_amount     ra_customer_trx_lines.extended_amount%TYPE;
BEGIN
   print_log('XX_AR_DM_ADJUST_PK_PK.Generar_comprobante_AR (+)');

   l_extended_amount := 0;
   FOR i IN 1..p_trx_lineas.count LOOP
      l_extended_amount := l_extended_amount + p_trx_lineas(i).extended_amount;
   END LOOP;

   --print_log('XX_AR_DM_ADJUST_PK_PK.Generar_comprobante_AR:<'||p_tipo_cbte||'><'||p_r_trx_header.CUST_TRX_TYPE_ID||'>');

   IF NOT Generar_Cabecera (  p_r_trx_header
                            , p_tipo_cbte
                            , p_gl_date
                            , l_extended_amount
                            , p_nombre_form
                            , p_receivable_ccid
                            , x_customer_trx_id
                            , x_trx_number
                            , 'Y' --p_run_autoacc_flag
                            , p_status_code
                            , p_error_message) THEN
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_comprobante_AR: Error al llamar al '||
                         'procedure Generar_Cabecera');
      RETURN (FALSE);
   END IF;
  -- print_log('XX_AR_DM_ADJUST_PK_PK.Generar_comprobante_AR: Despues de llamar a la '||
  --                    'generacion de la cabecera customer_trx_id='||x_customer_trx_id);

   IF NOT Generar_lineas ( p_trx_lineas
                         , x_customer_trx_id
                         , p_tipo_cbte
                         , p_nombre_form
                         , p_gl_date
                         , p_trx_date
                         , p_hder_currency_code
                         , p_hder_exchange_rate
                         , p_run_autoacc_flag
                         , p_status_code
                         , p_error_message) THEN
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_comprobante_AR: Error al llamar al '||
                         'procedure Generar_Lineas');
      RETURN (FALSE);
   END IF;

   print_log('XX_AR_DM_ADJUST_PK_PK.Generar_comprobante_AR (-)');

   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
   --arp_standard.disable_file_debug ;
      fnd_message.set_name('XX', 'XX_AR_TRX_OTHERS_GENERAR_TRX');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      p_error_message := fnd_message.get;
      print_log('XX_AR_DM_ADJUST_PK_PK.Generar_Comprobante_AR: Error General='||sqlerrm);
      RETURN (FALSE);
END Generar_comprobante_AR;
/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Validar_trx_generada                                                  |
|                                                                          |
| Description                                                              |
|    Valida una transaccion ya generada                                    |
|                                                                          |
| Parameters                                                               |
|   p_nombre_form        Nombre del form llamador                          |
|   p_customer_trx_id    Id de la transaccion                              |
|   p_trx_type           Se deberan pasar los siguientes datos:            |
|                               creation_sign                              |
|                               allow_overapplication_flag                 |
|                               natural_application_only_flag              |
|   x_msg_error          Mensaje de error de salida                        |
|                                                                          |
+=========================================================================*/
FUNCTION Commitear_Validar_trx_generada ( p_nombre_form        IN     VARCHAR2
                                        , p_customer_trx_id           ra_customer_trx.customer_trx_id%TYPE
                                        , p_trx_type                  ra_cust_trx_types%ROWTYPE
                                        , x_msg_error             OUT VARCHAR2)
RETURN BOOLEAN
IS
BEGIN

   print_log('XX_AR_DM_ADJUST_PK_PK.Commitear_Validar_trx_generada (+)');
   arp_process_header.post_commit (  p_nombre_form      -- p_form_name
                                   , NULL               -- p_form_version
                                   , p_customer_trx_id
                                   , NULL               -- previous_customer_trx_id,
                                   , 'Y'                -- p_complete_flag
                                   , NULL               -- p_trx_open_receivables_flag
                                   , NULL               -- p_prev_open_receivables_flag
                                   , p_trx_type.creation_sign
                                   , p_trx_type.allow_overapplication_flag
                                   , p_trx_type.natural_application_only_flag
                                   , NULL); --p_cash_receipt_id
   print_log('XX_AR_DM_ADJUST_PK_PK.Commitear_Validar_trx_generada (-)');

   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_OTHERS_VALIDAR_TRX');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      x_msg_error := fnd_message.get;
      print_log('XX_AR_DM_ADJUST_PK_PK.Commitear_Validar_trx_generada: Error General='||sqlerrm);
      RETURN (FALSE);
END Commitear_Validar_trx_generada;

/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    Completar_generar_nro_trx_arg                                         |
|                                                                          |
| Description                                                              |
|    Completa una transaccion ya generada y validada y genera el numero de |
|    transaccion. Este procedimiento se utiliza para Argentina             |
|                                                                          |
| Parameters                                                               |
|   p_customer_trx_id    Id de la transaccion                              |
|   p_create_trx_number  Flag que indica si se generara el numero o no     |
|                        los valores posibles son Y o N.                   |
|   x_trx_number         Devuelve el numero de transaccion generado        |
|   x_msg_error          Mensaje de error de salida                        |
|                                                                          |
+=========================================================================*/
FUNCTION Completar_generar_nro_trx_arg (  p_customer_trx_id           ra_customer_trx.customer_trx_id%TYPE
                                        , p_create_trx_number         VARCHAR2
                                        , x_trx_number            OUT ra_customer_trx.trx_number%TYPE
                                        , x_msg_error             OUT VARCHAR2)
RETURN BOOLEAN
IS
   CURSOR c_trx (p_cust_trx_id NUMBER) IS
   SELECT rct.*
     FROM ra_customer_trx rct
    WHERE customer_trx_id = p_cust_trx_id;
   CURSOR c_tipo_trx (p_cust_trx_type_id NUMBER) IS
   SELECT rctt.TYPE tipo
     FROM ra_cust_trx_types rctt
    WHERE rctt.cust_trx_type_id = p_cust_trx_type_id;
   CURSOR c_batch (p_batch_source_id NUMBER) IS
   SELECT name                             l_name
        , batch_source_type                l_batch_source_type
        , SUBSTR (a.global_attribute2,1,4) l_branch_number
        , SUBSTR (a.global_attribute3,1,1) l_document_letter
        , a.auto_trx_numbering_flag        l_auto_trx_numbering_flag
     FROM ra_batch_sources a
    WHERE batch_source_id = p_batch_source_id;
   l_batch                   c_batch%ROWTYPE;
   l_trx_class               c_tipo_trx%ROWTYPE;
   r_trx                     c_trx%ROWTYPE;
   l_imp_batch_src           NUMBER (15);
   l_so_org_id               NUMBER (3);
   l_point_of_sale           VARCHAR2 (4)                         := NULL;
   l_return_code             VARCHAR2 (30);
   l_ship_to_address_id      NUMBER;
   l_last_trx_date           DATE; -- Ultima Fecha del Lote
   f_org_id                  NUMBER (3);
   l_prefix                  VARCHAR2 (15);
   l_adv_day                 NUMBER;
   l_adv_days                DATE;
   l_seq_name                VARCHAR2 (30);
   l_seq_no                  NUMBER;
   l_errcode3                VARCHAR2 (30);
   l_trx_number              ra_customer_trx.trx_number%TYPE;
BEGIN
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg (+)');
   /***** Lectura de la cabecera de transacciones, si no existe, es un error *****/
   OPEN c_trx(p_customer_trx_id);
   FETCH c_trx INTO r_trx;
   IF c_trx%NOTFOUND THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                         'El id de transaccion no existe en la tabla de cabeceras: '|| p_customer_trx_id);
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_ID_NO_EXISTE');
      fnd_message.set_token('CUSTOMER_TRX_ID', p_customer_trx_id);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: Se obtuvieron los datos de la cabecera');
   /***** Si la transaccion ya esta completa no se modifica.*****/
   IF r_trx.complete_flag = 'Y' THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                         'Transaccion Completa no se puede modificar:'||
                         ' (customer_trx_id:'|| p_customer_trx_id|| ')');
      FND_MESSAGE.Set_Name('XX', 'XX_AR_TRX_TRX_COMPLETA');
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: La transaccion no estaba completa');
   /***** Lectura del tipo de transaccion, si no existe, es un error *****/
   OPEN c_tipo_trx(r_trx.cust_trx_type_id);
   FETCH c_tipo_trx INTO l_trx_class;
   IF c_tipo_trx%NOTFOUND THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                         'El id del tipo de  transaccion no existe en la tabla de ra_customer_trx_types: '||
                         r_trx.cust_trx_type_id);
      fnd_message.set_name('XX', 'XX_AR_TRX_ID_TRX_TYP_INEX');
      fnd_message.set_token('XX_TRX_TYPE_ID', r_trx.cust_trx_type_id);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                      'El tipo de transaccion existe y es '||l_trx_class.tipo);
   /***** Recupera el batch importado asociado con al Batch manual *****/
   l_imp_batch_src  := NULL;
   l_imp_batch_src  := jl_ar_doc_numbering_pkg.get_imported_batch_source (r_trx.batch_source_id);
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: Despues de obtener el batch_source');
   /***** Obtencion de los datos del Batch Importado *****/
   OPEN c_batch(l_imp_batch_src);
   FETCH c_batch INTO l_batch;
   IF c_batch%NOTFOUND THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: No existe el batch de id='||
                         l_imp_batch_src);
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_INEX');
      fnd_message.set_token('XX_BATCH_ID', l_imp_batch_src);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                      'Despues de Obtener los Datos del Batch l_batch.l_name='||l_batch.l_name);
   /****** INICIO Validaciones relacionadas con el Bacth Source ******/
   IF (l_batch.l_auto_trx_numbering_flag = 'N') THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                         'El Batch: '||l_batch.l_name||
                         ' no esta parametrizado como origen de lote Automatico. Verifique '||
                         ' el seteo del lote');
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_NO_ORI_AUTOM');
      fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   IF (l_batch.l_batch_source_type != 'FOREIGN') THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'El Batch: '|| l_batch.l_name||
                          ' no esta parametrizado como origen de lote Importado. Verifique'||
                          ' el seteo del lote');
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_NO_ORI_IMP');
      fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   IF (l_batch.l_branch_number IS NULL OR l_batch.l_document_letter IS NULL) THEN
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'El Batch: '|| l_batch.l_name||
                          ' tiene en nula la letra o el punto de venta . Verifique el seteo del lote');
      fnd_message.set_name('XX', 'XX_AR_TRX_BATCH_NO_LETRA');
      fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                      'FIN Validaciones relacionadas con el Bacth Source');
   /***** Se recupera el SO_ORGANIZATION_ID *****/
   l_so_org_id            := oe_profile.VALUE ('SO_ORGANIZATION_ID');
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'Recupero el organization_id l_so_org_id='||l_so_org_id);
   /***** Se recupera el la Letra *****/
   l_batch.l_document_letter      := jl_ar_doc_numbering_pkg.get_doc_letter (l_imp_batch_src);
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'Letra recuperada l_batch.l_document_letter='||l_batch.l_document_letter);
   /***** Se recupera el Punto de Venta *****/
   l_point_of_sale        := jl_ar_doc_numbering_pkg.get_branch_number (l_imp_batch_src);
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'Punto de venta l_point_of_sale='||l_point_of_sale);
   /***** Se valida la letra del documento *****/
   l_return_code          := NULL;
   l_return_code          := jl_ar_doc_numbering_pkg.validate_document_letter (l_imp_batch_src
                                                                               ,NULL
                                                                               ,'ARXTWMAI'
                                                                               ,NVL (r_trx.ship_to_site_use_id
                                                                                    ,r_trx.bill_to_site_use_id)
                                                                               ,l_batch.l_document_letter
                                                                               ,l_so_org_id);
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'DEspues de validate_document_letter');
   IF UPPER (l_return_code) != 'SUCCESS' THEN
       print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'Error al validar la letra del documento: '|| l_batch.l_document_letter||
                          ' -Batch:'|| l_imp_batch_src||
                          ' -Ship_to_address_id:'|| l_ship_to_address_id||
                          ' -So_Org_Id:'|| l_so_org_id||
                          '(RETURN_CODE='||l_return_code||')');
       fnd_message.set_name('XX', 'XX_AR_TRX_VALD_LETRA');
       fnd_message.set_token('XX_LETRA', l_batch.l_document_letter);
       fnd_message.set_token('XX_BATCH_ID', l_imp_batch_src);
       fnd_message.set_token('XX_SHIP_TO_ADD_ID', l_ship_to_address_id);
       fnd_message.set_token('XX_SO_ORG_ID', l_so_org_id);
       fnd_message.set_token('XX_RETURN_CODE', l_return_code);
       BEGIN
         SELECT con_tax_attribute_name || ' | ' || con_tax_attribute_value
         INTO   x_msg_error
         FROM   jl_ar_ar_doc_letter
         WHERE  document_letter = 'E'
         AND    rownum = 1
         AND    sysdate between start_date_active and nvl(end_date_active,sysdate);
       EXCEPTION WHEN OTHERS THEN x_msg_error := 'Buscando la letra de la FC con el seteo de la localizacion, error: ' || sqlerrm;
       END;
       --x_msg_error := 'XX_AR_TRX_VALD_LETRA: ' || l_batch.l_document_letter || ' - ' || l_return_code; --fnd_message.get;
       x_msg_error := 'XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg (llamando a jl_ar_doc_numbering_pkg.validate_document_letter): '||
                          'Error al validar la letra del documento: '|| l_batch.l_document_letter||
                          ' -Batch:'|| l_imp_batch_src||
                          ' -Ship_to_address_id:'|| l_ship_to_address_id||
                          ' -So_Org_Id:'|| l_so_org_id||
                          '(RETURN_CODE='||l_return_code||') Falta setear el "Customer Site Tax Profile" del cliente con los siguientes datos: '  || x_msg_error;
       RETURN (FALSE);
   END IF;
   /** Se valida el tipo de transaccion **/
   l_return_code          := NULL;
   l_return_code          := jl_ar_doc_numbering_pkg.validate_trx_type (  l_imp_batch_src
                                                                         , r_trx.cust_trx_type_id
                                                                         , l_trx_class.tipo
                                                                         , l_batch.l_document_letter
                                                                         , NULL
                                                                         , 'ARXTWMAI');
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'Despues de validar el tipo de transaccion');
   IF UPPER (l_return_code) != 'SUCCESS' THEN
       print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'Error al validar el tipo de transaccion: '|| r_trx.cust_trx_type_id||
                          ' -Batch:'|| l_imp_batch_src||
                          ' -Letra del documento: '|| l_batch.l_document_letter||
                          ' -So_Org_Id:'|| l_so_org_id||
                          '(RETURN_CODE='||l_return_code||')');
       fnd_message.set_name('XX', 'XX_AR_TRX_VALD_TIPO_TRX');
       fnd_message.set_token('XX_TIPO_TRX_ID', r_trx.cust_trx_type_id);
       fnd_message.set_token('XX_BATCH_ID', l_imp_batch_src);
       fnd_message.set_token('XX_DOCUMENT_LETTER', l_batch.l_document_letter);
       fnd_message.set_token('XX_SO_ORG_ID', l_so_org_id);
       fnd_message.set_token('XX_RETURN_CODE', l_return_code);
       x_msg_error := fnd_message.get;
       RETURN (FALSE);
   END IF;
   /* Valida ADVANCE DAYS */
   l_return_code          := NULL;
   l_return_code          := jl_ar_doc_numbering_pkg.validate_Transaction_date ( r_trx.trx_date
                                                                                , l_imp_batch_src);
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'Despues de validar los advance days');
   IF UPPER (l_return_code) != 'SUCCESS' THEN
       l_last_trx_date := JL_AR_DOC_NUMBERING_PKG.get_last_trx_date(l_imp_batch_src);
       print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'Despues de get_last_trx_date');
       l_adv_day       := TO_NUMBER(nvl(JL_AR_DOC_NUMBERING_PKG.get_adv_days(l_imp_batch_src),0));
       l_adv_days      := SYSDATE + l_adv_day;
       print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'Ingrese una fecha de transaccion entre '||l_last_trx_date||
                          ' y '|| l_adv_days||
                          ' para el origen de transaccion '|| l_batch.l_name);
       fnd_message.set_name('XX', 'XX_AR_TRX_FECHAS_INVALIDAS');
       fnd_message.set_token('XX_LAST_TRX_DATE', l_last_trx_date);
       fnd_message.set_token('XX_ADV_DAYS', l_adv_days);
       fnd_message.set_token('XX_BATCH_NAME', l_batch.l_name);
       x_msg_error := fnd_message.get;
       RETURN (FALSE);
   END IF;
   /***** Actualizacion de la Ultima Fecha del Batch Source  *****/
   l_last_trx_date        := NULL;
   l_last_trx_date        := jl_ar_doc_numbering_pkg.get_last_trx_date (l_imp_batch_src);
   IF (NVL (l_last_trx_date ,TO_DATE ('01-01-1901','DD-MM-YYYY')) <= r_trx.trx_date) THEN
      UPDATE ra_batch_sources
         SET global_attribute4 = fnd_date.date_to_canonical (r_trx.trx_date)
       WHERE batch_source_id   = TO_CHAR (l_imp_batch_src);
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: Despues del update del batch');
   ELSE
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'La fecha de transaccion: '|| r_trx.trx_date||
                          ' es menor a la ultima fecha registrada en el batch: '||l_last_trx_date||
                          ' verifique el seteo del batch ');
      fnd_message.set_name('XX', 'XX_AR_TRX_FECHA_MENOR_BATCH');
      fnd_message.set_token('XX_TRX_DATE', r_trx.trx_date);
      fnd_message.set_token('XX_LAST_DATE', l_last_trx_date);
      x_msg_error := fnd_message.get;
      RETURN (FALSE);
   END IF;
   /***** Generacion del numero de la transaccion (TRX_NUMBER) *****/
   /***** Se recupera la organnizacion *****/
   fnd_profile.get ( 'ORG_ID' ,f_org_id);
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                      'Organizacion recuperada f_org_id='||f_org_id);
   /* Se arma el nombre de la sequencia relacionada con el Batch*/
   l_seq_name             :=    'JL_ZZ_TRX_NUM_' --'RA_TRX_NUMBER_'
                                  || TO_CHAR (l_imp_batch_src)
                                  || '_'
                                  || f_org_id
                                  || '_S';
   print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                       'Nombre de la secuencia l_seq_name='||l_seq_name);
   IF (NVL (p_create_trx_number,'N') = 'Y') THEN
      /* Se recupera el siguiente numero de la secuencia*/
      jl_zz_ar_library_1_pkg.get_next_seq_number ( l_seq_name
                                                   , l_seq_no
                                                   , 1
                                                   , l_errcode3);
      /* Si no existen errores se formatea.*/
      IF l_errcode3 = 0 THEN
         l_trx_number      :=    l_batch.l_document_letter
                                     || '-'
                                     || l_point_of_sale
                                     || '-'
                                     || LPAD (TO_CHAR (l_seq_no),8,'0');
      ELSE
         print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                             'Error al obtener el proximo numero de la sequencia: '|| l_seq_name);
         fnd_message.set_name('XX', 'XX_AR_TRX_ERR_NEXT_SEQ');
         fnd_message.set_token('XX_L_SEQ_NAME', l_seq_name);
         x_msg_error := fnd_message.get;
         RETURN (FALSE);
      END IF;
      /* Valido el prefijo del numero generado.*/
      l_prefix          := NVL (SUBSTR (l_trx_number,1,6),'000000');
      IF (   NVL ( l_batch.l_document_letter ,'^&*~')|| '-'|| NVL ( l_point_of_sale ,'~')) != l_prefix THEN
         print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                             'Error al validar el prefijo el numero generado: '|| l_trx_number);
         fnd_message.set_name('XX', 'XX_AR_TRX_ERR_PREFIJO');
         fnd_message.set_token('XX_TRX_NUMBER', l_trx_number);
         x_msg_error := fnd_message.get;
         RETURN (FALSE);
      END IF;
      /* Se devuelve el numero generado*/
      print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                          'Numero de transaccion'||l_trx_number);
      x_trx_number := l_trx_number;
      BEGIN
         UPDATE ra_customer_trx
            SET trx_number      = l_trx_number
              , complete_flag   = 'Y'
          WHERE customer_trx_id = p_customer_trx_id;
         UPDATE ar_payment_schedules
            SET trx_number      = l_trx_number
          WHERE customer_trx_id = p_customer_trx_id;
         print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: Realizo los updates');
      EXCEPTION
         WHEN OTHERS THEN
            print_log('XX_AR_DM_ADJUST_PK.Completar_generar_nro_trx_arg: '||
                                'Error al actualizar el numero de la transaccion:'|| l_trx_number||
                                ' para las tablas ra_customer_trx y ar_payment_schedules '||
                                'para el customer_trx_id: '|| p_customer_trx_id||
                                ' ERROR:'|| SQLERRM);
            fnd_message.set_name('XX', 'XX_AR_TRX_ERR_GEN_NRO');
            fnd_message.set_token('XX_TRX_NUMBER', l_trx_number);
            fnd_message.set_token('XX_CUSTOMER_TRX_ID', p_customer_trx_id);
            fnd_message.set_token('XX_SQLERRM', SQLERRM);
            x_msg_error := fnd_message.get;
            RETURN (FALSE);
      END;
   END IF;
   CLOSE c_batch;
   CLOSE c_trx;
   CLOSE c_tipo_trx;
   print_log('XX_AR_DM_ADJUST_PK.Commitear_Validar_trx_generada (-)');
   RETURN (TRUE);
EXCEPTION
   WHEN OTHERS THEN
      IF c_trx%ISOPEN THEN
         CLOSE c_trx;
      END IF;
      IF c_tipo_trx%ISOPEN THEN
         CLOSE c_tipo_trx;
      END IF;
      IF c_batch%ISOPEN THEN
         CLOSE c_batch;
      END IF;
      fnd_message.set_name('XX', 'XX_AR_TRX_OTHERS_GEN_NRO');
      fnd_message.set_token('XX_SQLERRM', sqlerrm);
      x_msg_error := fnd_message.get;
      print_log('XX_AR_DM_ADJUST_PK.Commitear_Validar_trx_generada: Error General='||sqlerrm);
      RETURN (FALSE);
END Completar_generar_nro_trx_arg;

PROCEDURE create_dm (retcode        OUT VARCHAR2
                    ,errbuf         OUT VARCHAR2
                    ,p_cust_account_id  IN  NUMBER
                    ,p_date_from        IN  VARCHAR2
                    ,p_date_to          IN  VARCHAR2
                    ,p_receipt_method_id  IN  NUMBER
                    ,p_number_from        IN  VARCHAR2
                    ,p_number_to          IN  VARCHAR2
--                    ,p_flg_prov           IN  VARCHAR2
                    ,p_days               IN  NUMBER)
IS

    e_cust_exception      EXCEPTION;
    l_trx_header          ra_customer_trx%ROWTYPE;
    l_trx_lineas          XX_AR_DM_ADJUST_PK.Lineas_Cbte_Rec;
    l_batch_source_rec     ar_invoice_api_pub.batch_source_rec_type;
    l_trx_header_tbl       ar_invoice_api_pub.trx_header_tbl_type;
    l_trx_lines_tbl        ar_invoice_api_pub.trx_line_tbl_type;
    l_trx_dist_tbl         ar_invoice_api_pub.trx_dist_tbl_type;
    l_trx_salescredits_tbl ar_invoice_api_pub.trx_salescredits_tbl_type;
    l_return_status        varchar2(1);
l_msg_count            number;
l_msg_data             varchar2(2000);
l_cnt                  number := 0;
    x_customer_trx_id     NUMBER;
    x_trx_number          ra_customer_trx_all.trx_number%TYPE;
    p_mesg_error          VARCHAR2(2000);
    p_program             VARCHAR2(10);
    l_tipo_transaccion    ra_cust_trx_types_all.TYPE%TYPE;
    v_origen              RA_BATCH_SOURCES.NAME%TYPE;
    p_gl_date             DATE;
    p_trx_date            DATE;
    api_trx_number        ra_customer_trx_all.trx_number%TYPE;
    api_msg_error         VARCHAR2(2000);
    v_sob_id              NUMBER;
    v_func_currency       VARCHAR2(40);
    v_coa_id              NUMBER;
    v_ccid                NUMBER;
    v_vat_tax_id          NUMBER;
    l_applied_commitment_amt NUMBER;
    v_proceso             VARCHAR2(200);
    v_output              VARCHAR2(600);
    v_trx_type            ra_cust_trx_types%ROWTYPE;
    v_amount_original     NUMBER;
    v_amount_remaining    NUMBER;
    v_total_amount_nc     NUMBER;
    v_amount              NUMBER;

    v_status_message      VARCHAR2(1000);
    e_maph_exception      EXCEPTION;
    v_customer_name       VARCHAR2(360);
    v_line_number         NUMBER;
    p_flg_prov            VARCHAR2(1);

    CURSOR cur_rah IS
    SELECT   ab.batch_id
            ,ab.name batch_name
            ,ab.batch_date
            ,ab.gl_date
            ,acr.receipt_number
            ,acr.cash_receipt_id
            ,acr.currency_code
            ,acr.exchange_rate_type
            ,acr.exchange_rate
            ,acr.exchange_date
            ,acr.set_of_books_id
            ,acr.customer_site_use_id
            ,acr.receipt_date
            ,acrh.gl_date receipt_gl_date
            ,arm.name
            /*Modificado Khronus/E.Sly R12 Retrofit*/
          --,aba.bank_account_name
            ,cba.bank_account_name
            /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
            ,acr.amount
            ,arma_dfv.xx_ar_nd_batch_source_id origen_nd
            ,arma_dfv.xx_ar_nd_cust_trx_type_id tipo_de_nd
            ,arma_dfv.xx_ar_nd_memo_line_id linea_nota
            /*Modificado Khronus/E.Sly R12 Retrofit*/
            --,arma.bank_account_id
            ,arma.remit_bank_acct_use_id
            /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
            ,arm.receipt_method_id
            ,arm.receipt_class_id
            ,acr.org_id
            ,arma.cash_ccid
            ,hp.party_name
            ,acr.comments
    FROM     ar_receivable_applications ara
            ,ar_cash_receipts acr
            ,ar_cash_receipt_history acrh
            ,ar_batches ab
            ,ar_receipt_methods arm
            ,ar_receipt_method_accounts arma
            /*Modificado Khronus/E.Sly R12 Retrofit*/
            --,ap_bank_accounts aba
            ,ce_bank_accounts cba
            ,ce_bank_acct_uses cbau
            /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
            ,ar_receipt_methods_dfv arm_dfv
            ,ar_receipt_method_accounts_dfv arma_dfv
            ,ar_batches_all_dfv ab_dfv
            ,hz_cust_accounts hca
            ,hz_cust_acct_sites hcas
            ,hz_cust_site_uses hcasu
            ,hz_parties hp
    WHERE   ab.batch_id = acrh.batch_id
    AND     acrh.cash_receipt_id = acr.cash_receipt_id
    AND     ara.application_type = 'CASH'
    AND     NVL (ara.postable, 'Y') = 'Y'
    AND     NVL (ara.confirmed_flag, 'Y') = 'Y'
    AND     acr.cash_receipt_id = ara.cash_receipt_id
    AND     acr.receipt_method_id = arm.receipt_method_id
    AND     acr.pay_from_customer IS NOT NULL
    AND     ara.status = 'APP'
    AND     ara.applied_customer_trx_id is not null --= rct.customer_trx_id
    /*Modificado Khronus/E.Sly R12 Retrofit*/
    --AND     acr.remittance_bank_account_id = aba.bank_account_id
    AND     acr.remit_bank_acct_use_id = cbau.bank_acct_use_id
    AND     cbau.bank_account_id = cba.bank_account_id
    /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
    and     arm.rowid = arm_dfv.row_id
    and     ab.rowid = ab_dfv.row_id(+)
    /*Modificado Khronus/E.Sly R12 Retrofit*/
    --and     acr.remittance_bank_account_id = arma.bank_account_id
    and     acr.remit_bank_acct_use_id = arma.remit_bank_acct_use_id
    /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
    AND     arm.receipt_method_id = arma.receipt_method_id
    and     arma.rowid = arma_dfv.row_id
    --and     ab.batch_id = 290758
    /*CR1649
    and     ab.type = 'REMITTANCE'
    and     ab.batch_applied_status = 'COMPLETED_FORMAT'
    */
    and     nvl(acrh.current_record_flag,'N') = 'Y'
    and     acrh.status = 'CLEARED' --REMITTED
    and     arma_dfv.xx_ar_nd_batch_source_id IS NOT NULL
    and     arma_dfv.xx_ar_nd_cust_trx_type_id IS NOT NULL
    and     arma_dfv.xx_ar_nd_memo_line_id IS NOT NULL
    and     acr.creation_date >= trunc(sysdate-p_days)
    --agregado
    and     acr.customer_site_use_id = hcasu.site_use_id
    and     hcasu.cust_acct_site_id = hcas.cust_acct_site_id
    and     hcas.cust_account_id = hca.cust_account_id
    and     hca.party_id = hp.party_id
    and     hca.cust_account_id = nvl(p_cust_account_id,hca.cust_account_id)
    and     ab.batch_date >= nvl(to_date(p_date_from,'YYYY/MM/DD HH24:MI:SS'),ab.batch_date)
    and     ab.batch_date <= nvl(to_date(p_date_to,'YYYY/MM/DD HH24:MI:SS'),ab.batch_date)
    and     ab.name >= nvl(p_number_from,ab.name)
    and     ab.name <= nvl(p_number_to,ab.name)
    and     acr.receipt_method_id = nvl(p_receipt_method_id,acr.receipt_method_id)
    and     not exists (select  1
                        from    ra_customer_trx rct_ex
                               ,ra_batch_sources rbs_ex
                        where   to_char(rct_ex.cust_trx_type_id) = arma_dfv.xx_ar_nd_cust_trx_type_id ----LBB
                        and     rbs_ex.name = arma_dfv.xx_ar_nd_batch_source_id
                        and     rct_ex.batch_source_id = rbs_ex.batch_source_id
                        and     rct_ex.interface_header_context = 'XX_AR_ND_COBRANZA'
                        and     rct_ex.interface_header_attribute1 = to_char(acr.cash_receipt_id)
                        and     rct_ex.trx_date > trunc(sysdate-p_days))
    group by
           ab.batch_id
          ,ab.name
          ,ab.batch_date
          ,ab.gl_date
          ,acr.receipt_number
          ,acr.cash_receipt_id
          ,acr.currency_code
          ,acr.exchange_rate_type
          ,acr.exchange_rate
          ,acr.exchange_date
          ,acr.set_of_books_id
          ,acr.customer_site_use_id
          ,acr.receipt_date
          ,acrh.gl_date
          ,arm.name
          /*Modificado Khronus/E.Sly R12 Retrofit*/
          --,aba.bank_account_name
          ,cba.bank_account_name
          /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
          ,acr.amount
          ,arma_dfv.xx_ar_nd_batch_source_id
          ,arma_dfv.xx_ar_nd_cust_trx_type_id
          ,arma_dfv.xx_ar_nd_memo_line_id
          /*Modificado Khronus/E.Sly R12 Retrofit*/
          --,arma.bank_account_id
          ,arma.remit_bank_acct_use_id
          /*Fin Modificado Khronus/E.Sly R12 Retrofit*/
          ,arm.receipt_method_id
          ,arm.receipt_class_id
          ,acr.org_id
          ,arma.cash_ccid
          ,hp.party_name
          ,acr.comments;

    CURSOR cur_ral (p_batch_id          NUMBER
                   ,p_cash_receipt_id   NUMBER)
    IS
    SELECT acrh.gl_date receipt_gl_date
          ,aps_rec.due_date
          ,rct.customer_trx_id
          ,rct.trx_number
          ,rct.ct_reference
          ,rct.trx_date
          ,aps.amount_due_original
          ,aps.amount_due_remaining
          ,ara.gl_date
          ,ara.amount_applied
          ,ara.acctd_amount_applied_to
          ,DECODE (ara.posting_control_id, -3, 'N', 'Y') transfer_to_gl
    FROM ar_receivable_applications ara
        ,ar_cash_receipt_history acrh
        ,ra_customer_trx rct
        ,ar_payment_schedules aps
        ,ra_batch_sources rbs
        ,ar_payment_schedules aps_rec
    WHERE acrh.batch_id = p_batch_id
    AND   acrh.cash_receipt_id = p_cash_receipt_id
    AND   acrh.cash_receipt_id = ara.cash_receipt_id
    --AND acrh.first_posted_record_flag = 'Y'
    AND ara.application_type = 'CASH'
    AND NVL (ara.postable, 'Y') = 'Y'
    AND NVL (ara.confirmed_flag, 'Y') = 'Y'
    AND ara.status = 'APP'
    --AND ara.applied_customer_trx_id is not null --= rct.customer_trx_id
    AND ara.applied_customer_trx_id = rct.customer_trx_id
    AND ara.applied_payment_schedule_id = aps.payment_schedule_id
    AND ara.payment_schedule_id = aps_rec.payment_schedule_id
    AND rct.batch_source_id = rbs.batch_source_id
    --AND rct.trx_date > sysdate-300
    --and hca.account_number = '2204'
    and nvl(acrh.current_record_flag,'N') = 'Y'
    and acrh.status = 'CLEARED'; --REMITTED;

  cursor list_errors is
   SELECT trx_header_id, trx_line_id, trx_salescredit_id, trx_dist_id,
          trx_contingency_id, error_message, invalid_value
   FROM   ar_trx_errors_gt;

     cursor list_headers is
   SELECT trx_header_id,
          customer_trx_id
   FROM   ar_trx_header_gt;

BEGIN
    print_log('XX_AR_DM_ADJUST_PK.create_dm (+)');


    print_log('Busqueda de la CABECERA de la transaccion (+)');

    v_output := rpad('Cliente',37,' ')
              ||rpad('Lote Remesa',20,' ')
              ||rpad('Fecha Lote',15,' ')
              ||rpad('Nro Recibo',20,' ')
              ||rpad('Moneda',8,' ')
              ||rpad('Nro ND',17,' ')
              ||rpad('Fecha',17,' ')
              ||lpad('Importe',15,' ');

    print_output(v_output);

    p_flg_prov := 'N';

    FOR r_rec IN cur_rah LOOP
    /*Modificado Khronus/E.SLy 20180706 Retrofit*/
    /*DECLARE
        l_trx_lineas_tbl      XX_AR_DM_ADJUST_PK.Lineas_Cbte_Tbl;*/
        l_trx_header := NULL;
        l_trx_lines_tbl.DELETE;
        l_trx_header_tbl.DELETE;
        l_trx_dist_tbl.DELETE;
    /*Fin Nodificado Khronus/E.SLy 20180706 Retrofit*/
    BEGIN

        p_gl_date := TRUNC(SYSDATE);
        l_trx_lineas := null;
        --r_rec.ct_reference := null;

        print_log('site_use_id (+)');

        --obtengo el invoice_to_org_id
        BEGIN

            SELECT  hcsu.site_use_id
                   ,hca.cust_account_id
                   ,hca.cust_account_id
                   ,hp.party_name
            INTO    l_trx_header.bill_to_site_use_id
                   ,l_trx_header.bill_to_customer_id
                   ,l_trx_header.sold_to_customer_id
                   ,v_customer_name
            FROM    hz_cust_acct_sites hcas,
                    hz_cust_acct_sites_all_dfv hcas_dfv,
                    hz_party_sites hps,
                    hz_cust_site_uses hcsu,
                    hz_parties hp,
                    hz_cust_accounts hca
            WHERE   hcas.party_site_id = hps.party_site_id
            AND   hcas.rowid = hcas_dfv.row_id
            AND   hcsu.cust_acct_site_id = hcas.cust_acct_site_id
            AND   hca.cust_account_id = hcas.cust_account_id
            AND   hcsu.site_use_code = 'BILL_TO'
            AND   hps.party_id = hp.party_id
            AND   hcsu.site_use_id = r_rec.customer_site_use_id --210186
            --AND   hcsu.primary_flag = 'Y'
            AND   hcsu.status = 'A';

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
             v_status_message := 'No se encuentra direccion legal activa para el Customer Site Use ID '||r_rec.customer_site_use_id; -- si no existe
             RAISE e_maph_exception;
          WHEN OTHERS THEN
             v_status_message := 'Error inesperado al obtener la Direccion Legal activa para el Customer Site Use ID '||r_rec.customer_site_use_id||', error: '||sqlerrm; --Si Aparecen Otros Errores
             RAISE e_maph_exception;
        END;

        print_log('ship_to_org_id (+)');


        --obtengo el ship_to_org_id
        BEGIN
            print_log('l_trx_header.bill_to_customer_id '||l_trx_header.bill_to_customer_id);

          SELECT   hcsu.site_use_id
                  ,hca.cust_account_id
            INTO   l_trx_header.ship_to_site_use_id
                  ,l_trx_header.ship_to_customer_id
            FROM   hz_cust_acct_sites hcas,
                   hz_cust_acct_sites_all_dfv hcas_dfv,
                   hz_party_sites hps,
                   hz_cust_site_uses hcsu,
                   hz_parties hp,
                   hz_cust_accounts hca
           WHERE   hcas.party_site_id = hps.party_site_id
             AND   hcsu.cust_acct_site_id = hcas.cust_acct_site_id
             and   hca.cust_account_id = hcas.cust_account_id
             and   hcas.rowid = hcas_dfv.row_id
             AND   hcsu.site_use_code = 'SHIP_TO'
             AND   hps.party_id = hp.party_id
             AND   hca.cust_account_id = l_trx_header.bill_to_customer_id
             AND   hcsu.primary_flag = 'Y'
             AND   hcsu.status = 'A';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
             v_status_message := 'No se encuentra direccion primaria de envio del cliente '||v_customer_name; -- si no existe
             RAISE e_maph_exception;
          WHEN OTHERS THEN
             v_status_message := 'Error inesperado al obtener la Direccion primaria de envio del cliente '||v_customer_name||', error: '||sqlerrm; --Si Aparecen Otros Errores
             RAISE e_maph_exception;
        END;

        --obtengo el hold_id
        -- Inicio CR2411
        /*BEGIN

            SELECT  standard_terms
            INTO    l_trx_header.term_id
            FROM    hz_customer_profiles
            WHERE   site_use_id = l_trx_header.bill_to_site_use_id
            AND     standard_terms is not null;

            print_log('l_trx_header.term_id '||l_trx_header.term_id);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
             BEGIN
                SELECT  standard_terms
                INTO    l_trx_header.term_id
                FROM    hz_customer_profiles
                WHERE   cust_account_id = l_trx_header.bill_to_customer_id
                AND     standard_terms is not null
                AND     site_use_id is null;
             EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    v_status_message := 'No se encuentra Term ID del cliente '||v_customer_name; -- si no existe
                    RAISE e_maph_exception;
             END;
          WHEN OTHERS THEN
             v_status_message := 'Error inesperado al obtener Term ID del cliente '||v_customer_name||', error: '||sqlerrm; --Si Aparecen Otros Errores
             RAISE e_maph_exception;
        END;
        */
        l_trx_header.term_id := 1000;
        --Fin CR2411


        print_log('Completar valores de cabecera (+)');

        /*Nuevos*/

        l_trx_header_tbl(1).trx_header_id       := 101;
        l_trx_header_tbl(1).bill_to_customer_id := l_trx_header.bill_to_customer_id;
        l_trx_header_tbl(1).bill_to_site_use_id := l_trx_header.bill_to_site_use_id;
        l_trx_header_tbl(1).ship_to_customer_id := l_trx_header.ship_to_customer_id;
        l_trx_header_tbl(1).ship_to_site_use_id := l_trx_header.ship_to_site_use_id;
        l_trx_header_tbl(1).term_id             := l_trx_header.term_id;
        l_trx_header_tbl(1).trx_currency        := r_rec.currency_code;

        IF l_trx_header_tbl(1).trx_currency = 'ARS' THEN
        l_trx_header_tbl(1).exchange_date := NULL;
        ELSE
        l_trx_header_tbl(1).exchange_date       := r_rec.exchange_date;
        END IF;
        l_trx_header_tbl(1).exchange_rate_type  := r_rec.exchange_rate_type;
        l_trx_header_tbl(1).exchange_rate       := r_rec.exchange_rate;

        l_trx_header_tbl(1).trx_date            := p_gl_date;
--        l_trx_header_tbl(1).set_of_books_id     := r_rec.set_of_books_id;
        l_trx_header_tbl(1).org_id              := r_rec.org_id;

        l_trx_header_tbl(1).interface_header_context := 'XX_AR_ND_COBRANZA';
        l_trx_header_tbl(1).interface_header_attribute1 := to_char(r_rec.cash_receipt_id);
        l_trx_header_tbl(1).interface_header_attribute2 := to_char(r_rec.receipt_class_id);
        l_trx_header_tbl(1).interface_header_attribute3 := to_char(r_rec.receipt_method_id);
        l_trx_header_tbl(1).interface_header_attribute4 := to_char(trunc(p_gl_date),'YYYY/MM/DD');

        l_trx_header_tbl(1).status_trx                := 'OP';
        l_trx_header_tbl(1).default_tax_exempt_flag   := null; --'S'
        l_trx_header_tbl(1).printing_option           := 'NOT';
        l_trx_header_tbl(1).global_attribute_category := 'JL.AR.ARXTWMAI.TGW_HEADER';

        l_trx_header_tbl(1).comments :=substr(r_rec.comments,1 ,1500);

   /* --    l_trx_header.ct_reference             := r_rec.ct_reference;
        l_trx_header.term_due_date             := p_gl_date; --VER

        l_trx_header.invoice_currency_code     := r_rec.currency_code;
        l_trx_header.exchange_rate_type        := r_rec.exchange_rate_type;
        l_trx_header.exchange_rate             := r_rec.exchange_rate;
        l_trx_header.exchange_date             := r_rec.exchange_date;

        l_trx_header.trx_date                  := p_gl_date;
        l_trx_header.set_of_books_id           := r_rec.set_of_books_id;
        l_trx_header.org_id                    := r_rec.org_id;

        l_trx_header.interface_header_context := 'XX_AR_ND_COBRANZA';
        l_trx_header.interface_header_attribute1 := to_char(r_rec.cash_receipt_id);
        l_trx_header.interface_header_attribute2 := to_char(r_rec.receipt_class_id);
        l_trx_header.interface_header_attribute3 := to_char(r_rec.receipt_method_id);
        l_trx_header.interface_header_attribute4 := to_char(trunc(p_gl_date),'YYYY/MM/DD');

        l_trx_header.complete_flag             := 'N';
        l_trx_header.created_from              := 'ARXTWMAI';
        l_trx_header.status_trx                := 'OP';
        l_trx_header.default_tax_exempt_flag   := null; --'S'
        l_trx_header.printing_option           := 'NOT';
        l_trx_header.global_attribute_category := 'JL.AR.ARXTWMAI.TGW_HEADER';*/

        p_program              := 'ARXTWMAI';
        p_trx_date             := p_gl_date;
    --    v_customer_trx_id      := r_rec.customer_trx_id;

        v_proceso := 'Tipo de Transaccion (+)';
        print_log(v_proceso);

        BEGIN

            SELECT  ctt.cust_trx_type_id
                   ,ctt.type
            --INTO    l_trx_header.cust_trx_type_id  // Modificado Khronus/E.Sly 20180706 Retrofit
            INTO    l_trx_header_tbl(1).cust_trx_type_id
                   ,l_tipo_transaccion
            FROM    ra_cust_trx_types ctt
            WHERE   ctt.cust_trx_type_id = r_rec.tipo_de_nd;

            SELECT  *
            INTO    v_trx_type
            FROM    ra_cust_trx_types
            WHERE   cust_trx_type_id = r_rec.tipo_de_nd;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
              p_mesg_error := 'No se encontro el cust_trx_type_id para el tipo. ID: ' || r_rec.tipo_de_nd;
              raise e_cust_exception;
            WHEN OTHERS THEN
              p_mesg_error := 'Excepcion OTHERS obteniendo cust_trx_type_id para el tipo. ID: ' || r_rec.tipo_de_nd || ' . Codigo de error: ' || SQLERRM;
              raise e_cust_exception;
        END;

        v_proceso := 'Tipo de Transaccion ' || l_tipo_transaccion ||' (-)';
        print_log(v_proceso);


        v_proceso := 'Origen de transaccion a generar (+)';
        print_log(v_proceso);

        BEGIN

            select  rab.batch_source_id
                   ,rab.name
            --into    l_trx_header.batch_source_id Modificado Khronus/E.Sly 20180706 Retrofit
            into    l_batch_source_rec.batch_source_id
                   ,v_origen
            from    ra_batch_sources rab
            where   rab.name = r_rec.origen_nd; --rab.batch_source_id

            print_log('Origen de transaccion: '||v_origen);

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
              p_mesg_error := 'No se encontro el batch_source_id para el origen: ' || r_rec.origen_nd;
              raise e_cust_exception;

            WHEN OTHERS THEN
              p_mesg_error := 'Excepcion OTHERS obteniendo batch_source_id para el origen. ID: ' || r_rec.origen_nd || ' . Codigo de error: ' || SQLERRM;
              raise e_cust_exception;
        END;

        --print_log('Origen de transaccion a generar (id) '|| l_trx_header.batch_source_id ||' (-)');
        print_log('Origen de transaccion a generar (id) '|| l_batch_source_rec.batch_source_id ||' (-)');

--  v_proceso := 'Busqueda de las LINEAS de la transaccion '||v_customer_trx_id||'> (+)';
--  print_log(v_proceso);

        v_line_number := null;
        v_amount := null;

        FOR c_ral IN cur_ral (p_batch_id        => r_rec.batch_id
                             ,p_cash_receipt_id => r_rec.cash_receipt_id) LOOP

           if v_line_number is null then
            v_line_number := 1;
           else
            v_line_number := v_line_number +1;
           end if;

           print_log('Nro Linea '||v_line_number||' (+)');
           print_log('Generando linea de la transaccion '||c_ral.trx_number||' (+)');

           /*VER
           l_trx_lineas.interface_line_context    := c_ral.interface_line_context;
           l_trx_lineas.interface_line_attribute1 := c_ral.interface_line_attribute1;
           l_trx_lineas.interface_line_attribute2 := c_ral.interface_line_attribute2;
           l_trx_lineas.interface_line_attribute3 := c_ral.interface_line_attribute3;
           l_trx_lineas.interface_line_attribute4 := c_ral.interface_line_attribute4;
           l_trx_lineas.interface_line_attribute5 := c_ral.interface_line_attribute5;
           l_trx_lineas.interface_line_attribute6 := c_ral.interface_line_attribute6;
           l_trx_lineas.interface_line_attribute7 := c_ral.interface_line_attribute7;
           l_trx_lineas.interface_line_attribute8 := c_ral.interface_line_attribute8;*/

           l_trx_lines_tbl(v_line_number).trx_header_id := 101;
           l_trx_lines_tbl(v_line_number).line_number   := v_line_number;
           l_trx_lines_tbl(v_line_number).trx_line_id   := 100+l_trx_lines_tbl(v_line_number).line_number;

--           l_trx_lines_tbl(v_line_number).autotax := 'N';
           l_trx_lines_tbl(v_line_number).quantity_invoiced := 1;
           l_trx_lines_tbl(v_line_number).unit_selling_price := c_ral.amount_applied;

--           l_trx_lines_tbl(v_line_number).extended_amount := c_ral.amount_applied;
--           l_trx_lines_tbl(v_line_number).org_id := r_rec.org_id;
--           l_trx_lines_tbl(v_line_number).set_of_books_id := r_rec.set_of_books_id;


            /*Modificado Khronus/E.Sly 20180706 Retrofit*
           /*l_trx_lineas.vat_tax_id           := NULL; --VER
           l_trx_lineas.autotax              := 'N'; --c_ral.autotax; VER
           l_trx_lineas.tax_exempt_flag      := NULL; --VER
           l_trx_lineas.quantity_invoiced    := 1;
           l_trx_lineas.unit_selling_price   := c_ral.amount_applied;
           l_trx_lineas.extended_amount      := c_ral.amount_applied;
           --l_trx_lineas.extended_acctd_amount:= c_ral.amount_applied;
           --l_trx_lineas.revenue_amount       := c_ral.amount_applied;
           l_trx_lineas.org_id               := r_rec.org_id;
           l_trx_lineas.set_of_books_id      := r_rec.set_of_books_id;
           l_trx_lineas.ccid1                := r_rec.cash_ccid;*/
           /*Fin Modificado Khronus/E.Sly 20180706 Retrofit*/

           v_amount := nvl(v_amount,0) + c_ral.amount_applied;

           --v_proceso := 'Valores '||l_trx_lineas.unit_selling_price||'><'||l_trx_lineas.extended_amount||'>';
      --print_log(v_proceso);

           l_trx_lines_tbl(v_line_number).memo_line_id := r_rec.linea_nota;
           l_trx_lines_tbl(v_line_number).description := c_ral.trx_number;
           l_trx_lines_tbl(v_line_number).uom_code     := 'UN';
           l_trx_lines_tbl(v_line_number).line_type    := 'LINE';
           --l_trx_lines_tbl(v_line_number).attribute1   := c_ral.customer_trx_id;
           l_trx_lines_tbl(v_line_number).global_attribute2    := 'DEFAULT';
           l_trx_lines_tbl(v_line_number).global_attribute3    := 'T-NO GRAVADO';

           l_trx_lines_tbl(v_line_number).global_attribute_category := 'JL.AR.ARXTWMAI.LINES'; --c_ral.global_attribute_category;
           l_trx_lines_tbl(v_line_number).amount_includes_tax_flag := 'N';

           /*Modificado Khronus/E.Sly 20180706 Retrofit*/
           /*l_trx_lineas.line_number          := v_line_number;
           l_trx_lineas.inventory_item_id    := null;
           l_trx_lineas.memo_line_id         := r_rec.linea_nota;
           l_trx_lineas.description          := c_ral.trx_number;
           l_trx_lineas.uom_code             := 'UN';
           l_trx_lineas.line_type            := 'LINE';
           l_trx_lineas.attribute1           := c_ral.customer_trx_id;
           l_trx_lineas.attribute2           := null; --c_ral.attribute2;
           l_trx_lineas.attribute3           := null; --c_ral.attribute3;
           l_trx_lineas.attribute7           := null; --c_ral.attribute7;
           l_trx_lineas.attribute_category   := null; --c_ral.attribute_category; VER
           l_trx_lineas.global_attribute1    := NULL; --VERRRR
           l_trx_lineas.global_attribute2    := 'DEFAULT';
           l_trx_lineas.global_attribute3    := 'T-NO GRAVADO';*/
           /*Fin Modificado Khronus/E.Sly 20180706 Retrofit*/

           /*l_trx_lineas.global_attribute4    := c_ral.global_attribute4;
           l_trx_lineas.global_attribute5    := c_ral.global_attribute5;
           l_trx_lineas.global_attribute6    := c_ral.global_attribute6;
           l_trx_lineas.global_attribute7    := c_ral.global_attribute7;
           l_trx_lineas.global_attribute8    := c_ral.global_attribute8;
           l_trx_lineas.global_attribute9    := c_ral.global_attribute9;
           l_trx_lineas.global_attribute10   := c_ral.global_attribute10;
           l_trx_lineas.global_attribute11   := c_ral.global_attribute11;
           l_trx_lineas.global_attribute12   := c_ral.global_attribute12;
           l_trx_lineas.global_attribute13   := c_ral.global_attribute13;
           l_trx_lineas.global_attribute14   := c_ral.global_attribute14;
           l_trx_lineas.global_attribute15   := c_ral.global_attribute15;
           l_trx_lineas.global_attribute16   := c_ral.global_attribute16;
           l_trx_lineas.global_attribute17   := c_ral.global_attribute17;
           l_trx_lineas.global_attribute18   := c_ral.global_attribute18;
           l_trx_lineas.global_attribute19   := c_ral.global_attribute19;
           l_trx_lineas.global_attribute20   := c_ral.global_attribute20;*/
           /*l_trx_lineas.global_attribute_category := 'JL.AR.ARXTWMAI.LINES'; --c_ral.global_attribute_category;
           l_trx_lineas.amount_includes_tax_flag := 'N'; --c_ral.amount_includes_tax_flag;
           l_trx_lineas.warehouse_id             := null; --c_ral.warehouse_id;*/

           /*l_trx_lineas_tbl(cur_ral%rowcount)    := l_trx_lineas;*/
           --l_trx_header.attribute7                := c_ral.cust_po_number; -- Guardo el nro de Licitacion asociada al pedido en la cabecera de la NC

           l_trx_dist_tbl(v_line_number).trx_header_id := 101;
           l_trx_dist_tbl(v_line_number).trx_line_id := l_trx_lines_tbl(v_line_number).trx_line_id;
           l_trx_dist_tbl(v_line_number).trx_dist_id := 1000 + l_trx_lines_tbl(v_line_number).trx_line_id;
           l_trx_dist_tbl(v_line_number).account_class := 'REV';
           l_trx_dist_tbl(v_line_number).percent := 100;
           l_trx_dist_tbl(v_line_number).code_combination_id := r_rec.cash_ccid;

           print_log('Generando linea de la transaccion '||c_ral.trx_number||' (-)');
           print_log('Nro Linea '||v_line_number||' (-)');

        END LOOP; --lines

        print_log('Loop LINEAS (-)');

        -- ----------------------------------------------------------------------------------------
        -- Llama al paquete que genera el comprobante
        -- ----------------------------------------------------------------------------------------

        AR_INVOICE_API_PUB.create_single_invoice( p_api_version          => 1.0,
                                              p_batch_source_rec     => l_batch_source_rec,
                                              p_trx_header_tbl       => l_trx_header_tbl,
                                              p_trx_lines_tbl        => l_trx_lines_tbl,
                                              p_trx_dist_tbl         => l_trx_dist_tbl,
                                              p_trx_salescredits_tbl => l_trx_salescredits_tbl,
                                              x_customer_trx_id      => x_customer_trx_id,
                                              x_return_status        => l_return_status,
                                              x_msg_count            => l_msg_count,
                                              x_msg_data             => l_msg_data);
        print_log(l_return_status);
        SELECT count(*)
          INTO   l_cnt
          FROM   ar_trx_header_gt;

          IF l_cnt != 0 THEN
             FOR i in list_headers LOOP
                 print_log('customer_trx_id: '||i.customer_trx_id);
             END LOOP;
          END IF;

        IF l_return_status = fnd_api.g_ret_sts_error OR
          l_return_status = fnd_api.g_ret_sts_unexp_error THEN

          SELECT count(*)
          INTO   l_cnt
          FROM   ar_trx_errors_gt;

          IF l_cnt != 0 THEN
             FOR i in list_errors LOOP
                 p_mesg_error := p_mesg_error ||' - '||i.error_message;
             END LOOP;
          END IF;

          SELECT count(*)
          INTO   l_cnt
          FROM   ar_trx_header_gt;

          IF l_cnt != 0 THEN
             FOR i in list_headers LOOP
                 print_log('customer_trx_id: '||i.customer_trx_id);
             END LOOP;
          END IF;

          fnd_file.put_line(fnd_file.log,p_mesg_error);
           RAISE e_cust_exception;
         END IF;

         BEGIN

            SELECT trx_number
            INTO api_trx_number
            FROM ra_customer_trx_all
            WHERE customer_trx_id = x_customer_trx_id;

        EXCEPTION
         WHEN OTHERS THEN
           api_trx_number := null;
        END;

        /*IF NOT Generar_comprobante_AR
                                     ( p_status_code         => retcode
                                     , p_error_message       => p_mesg_error
                                     , p_r_trx_header        => l_trx_header
                                     , p_trx_lineas          => l_trx_lineas_tbl
                                     , p_tipo_cbte           => l_tipo_transaccion     -- tipo de docuemento 'CM'
                                     , p_gl_date             => p_gl_date
                                     , p_receivable_ccid     => NULL
                                     , p_hder_currency_code  => l_trx_header.invoice_currency_code --l_moneda_func.moneda
                                     , p_hder_exchange_rate  => l_trx_header.exchange_rate
                                     , p_nombre_form         => p_program
                                     , p_trx_date            => p_trx_date
                                     , x_customer_trx_id     => x_customer_trx_id
                                     , x_trx_number          => x_trx_number
                                     , p_run_autoacc_flag    => 'N'
                                      ) THEN

           p_mesg_error := 'XX_AR_DM_ADJUST_PK_PK.Genera_comprobante_AR: '||p_mesg_error;
           print_log(p_mesg_error);
           RAISE e_cust_exception;

        END IF;


      IF NOT Completar_generar_nro_trx_arg ( x_customer_trx_id
                                           , 'Y'
                                           , api_trx_number
                                           , api_msg_error) THEN
           p_mesg_error := 'ERROR al completar la factura '||api_msg_error;
           print_log(p_mesg_error);
           RAISE e_cust_exception;
      END IF;*/



        /*print_log('Actualizacion del Complete_flag '||x_customer_trx_id);
        print_log(v_proceso);

        BEGIN
        UPDATE ra_customer_trx_all
        SET complete_flag   = 'Y'
        WHERE customer_trx_id = x_customer_trx_id;
        EXCEPTION
          WHEN OTHERS THEN
            p_mesg_error := 'ERROR al marcar el complete_flag de la FC : ' ||SQLERRM;
            print_log(p_mesg_error);
            RAISE e_cust_exception;
        END;*/

      /*  IF NOT Commitear_Validar_trx_generada (  'ARXTWMAI'      -- p_form_name
                                            , x_customer_trx_id
                                            , v_trx_type
                                            , api_msg_error) THEN
           p_mesg_error := 'ERROR al Commitear_Validar la factura '||api_msg_error;
           print_log(p_mesg_error);
           RAISE e_cust_exception;
        END IF;*/


        --VER COMO MARCAR LOS RECIBOS
        BEGIN

          NULL;
        /*
          UPDATE ra_customer_trx
          SET attribute6 = 'Y'
          WHERE customer_trx_id =  v_customer_trx_id;*/
        EXCEPTION
          WHEN OTHERS THEN
            p_mesg_error := 'ERROR al marcar la FC generada:: ' ||SQLERRM;
            print_log(p_mesg_error);
            RAISE e_cust_exception;
        END;

        IF p_flg_prov = 'N' THEN
            print_log('Transaccion Generada: '||api_trx_number);
            /* Completa el output con el numero de NC generada */
            v_output := v_output ||' '|| api_trx_number;
        ELSE  --p_flg_prov = 'Y'
            rollback;
        END IF;


        v_output := rpad(substr(r_rec.party_name,1,35),37,' ')
                  ||rpad(r_rec.batch_name,20,' ')
                  ||rpad(to_date(r_rec.batch_date,'DD/MM/YYYY'),15,' ')
                  ||rpad(r_rec.receipt_number,20,' ')
                  ||rpad(r_rec.currency_code,8,' ')
                  ||rpad(api_trx_number,17,' ')
                  ||rpad(to_date(p_gl_date,'DD/MM/YYYY'),17,' ')
                  ||lpad(v_amount,15,' ');

        print_output(v_output);

    EXCEPTION
        WHEN e_maph_exception THEN
            print_log(v_status_message);
            --Inicio CR2411
            --raise e_cust_exception;
            retcode := 1;
            --Fin CR2411
    END;
    END LOOP;

 v_proceso := 'Busqueda de la CABECERA de la transaccion (-)';
 print_log(v_proceso);

 print_log('XX_AR_DM_ADJUST_PK.create_dm (-)');

EXCEPTION
  WHEN e_cust_exception THEN
     rollback;
     retcode := 2;
     errbuf  := p_mesg_error;
     RAISE_APPLICATION_ERROR(-20000,p_mesg_error);
     print_log ('XX_AR_DM_ADJUST_PK.create_dm (!)');
  WHEN others THEN
     rollback;
     errbuf  := 'Error al Ejecutar el Proceso: '||SQLERRM;
     retcode := 2;
     print_log (errbuf);
     RAISE_APPLICATION_ERROR(-20000,errbuf);
     print_log ('XX_AR_DM_ADJUST_PK.create_dm (!)');
END create_dm;

END XX_AR_DM_ADJUST_PK;
/

exit
