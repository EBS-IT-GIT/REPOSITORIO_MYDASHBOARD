==============================================================================
CUSEAM003_003 : Integra��o EAM
==============================================================================

Atualiza��o - CUSEAM003_003
Produto     - XX Customizaciones
Data        - 09/03/2021 12:00:00
HotPatch    - Sim
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSEAM003_003


Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

1. Realizar um bounce no OACORE
2. Implementar os servi�os soa conforme documento : 
 CUS_EAM_003_DBS_003\docs\PGC-DP-GS-0003.docx
 Servi�os : WorkService  Vers�o 3.0
            AssetService Vers�o 2.0  

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: jSAECUSEAM003.zip
                               SAE_SEND_EMAIL.tab           
                               SAE_SEND_EMAIL.grt           
                               SAE_SEND_EMAIL.syn           
                               SAE_SEND_EMAIL_S.seq         
                               SAE_SEND_EMAIL_S.grt         
                               SAE_SEND_EMAIL_S.syn         
                               SEND_EMAIL_BY_JAVA_PKS.pls   
                               SEND_EMAIL_BY_JAVA_PKB.pls   
                               SEND_EMAIL_BY_JAVA_PK.grt    
                               SEND_EMAIL_BY_JAVA_PK.syn    
                               SAE_EAM_WORK_REQUEST_PKS.pls 
                               SAE_EAM_WORK_REQUEST_PKB.pls 
                               SAE_SEND_EMAIL_CCR.ldt       