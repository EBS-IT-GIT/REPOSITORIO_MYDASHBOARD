UPDATE xla.xla_events
SET    event_status_code = 'U'
WHERE  entity_id = 72694582;
--1 Registro