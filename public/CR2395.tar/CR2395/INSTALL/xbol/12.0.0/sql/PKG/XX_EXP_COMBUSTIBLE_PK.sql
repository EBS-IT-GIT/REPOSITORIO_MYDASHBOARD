  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_EXP_COMBUSTIBLE_PK" AUTHID CURRENT_USER
AS
------------------------------------------------------------------------
-- Funcion que genera un consumo de OPM para R12 con solo id de lectura
------------------------------------------------------------------------
   FUNCTION genera_consumo_opm (
      p_id_lectura_qr            IN       VARCHAR2
    , p_journal_no               OUT      VARCHAR2
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

------------------------------------------------------------------------
-- Funcion que genera un consumo de OPM
------------------------------------------------------------------------
   FUNCTION genera_consumo (
      p_orgn_code                IN       VARCHAR2
    , p_reason_code              IN       VARCHAR2
    , p_item_no                  IN       VARCHAR2
    , p_from_whse_code           IN       VARCHAR2
    , p_from_location            IN       VARCHAR2
    , p_trans_qty                IN       NUMBER
    , p_co_code                  IN       VARCHAR2
    , p_item_um                  IN       VARCHAR2
    , p_org_id                   IN       NUMBER
    , p_trx_date                 IN       DATE
    , p_attribute1               IN       VARCHAR2
    , p_attribute12              IN       VARCHAR2
    , p_attribute13              IN       VARCHAR2
    , p_attribute_category       IN       VARCHAR2
    , p_journal_no               OUT      VARCHAR2
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

------------------------------------------------------------------------
-- Funcion que genera un despacho de OM
------------------------------------------------------------------------
   FUNCTION genera_pedido (
      p_sold_to_org_id           IN       NUMBER
    , p_price_list_id            IN       NUMBER
    , p_sold_from_org_id         IN       NUMBER
    , p_ship_to_org_id           IN       NUMBER
    , p_invoice_to_org_id        IN       NUMBER
    , p_salesrep_id              IN       NUMBER
    , p_order_type_id            IN       NUMBER
    , p_inventory_item_id        IN       NUMBER
    , p_ordered_quantity         IN       NUMBER
    , p_ship_from_org_id         IN       NUMBER
    , p_line_type_id             IN       NUMBER
    , p_subinventory_code        IN       VARCHAR2
    -- amanukyan 20180110 mejora de agregar subinventory a la generacion del pedido
   ,  p_header_id                OUT      NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

   FUNCTION genera_delivery (
      p_organization_id          IN       NUMBER
    , p_initial_pickup_location_id IN     NUMBER
    , p_ultimate_dropoff_location_id IN   NUMBER
    , p_waybill                  IN       VARCHAR
    , p_delivery_id              OUT      NUMBER
    , p_delivery_name            OUT      VARCHAR2
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

   FUNCTION asocia_delivery_detail (
      p_header_id                IN       NUMBER
    , p_delivery_id              IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

   FUNCTION genera_ship_confirm (
      p_delivery_id              IN       NUMBER
    , p_sold_from_org_id         IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

   FUNCTION genera_pick_release (
      p_delivery_id              IN       NUMBER
    , p_sold_from_org_id         IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN;

   PROCEDURE loader (
      p_errbuf                   OUT      VARCHAR2
    , p_retcode                  OUT      NUMBER
   );

   PROCEDURE confirmacion (
      p_errbuf                   OUT      VARCHAR2
    , p_retcode                  OUT      NUMBER
   );

   PROCEDURE lanza_conf;
   --(
   --   p_req_id                   OUT      NUMBER
   --);

   PROCEDURE xx_exp_cuentas (
      p_reason_code              IN       VARCHAR2
    , p_item_id                  IN       NUMBER
    , p_item_no                  IN       NUMBER
    , p_lot_id                   IN       NUMBER
    , p_lot_no                   IN       VARCHAR2
    , p_attribute1               IN       VARCHAR2
    , p_whse_code                IN       VARCHAR2
    , p_orgn_code                IN       VARCHAR2
    , p_co_code                  IN       VARCHAR2
    , p_acct_no                  OUT      VARCHAR2
    , p_acctg_unit_no            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   );
END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_EXP_COMBUSTIBLE_PK" 
AS
   FUNCTION genera_consumo_opm (
      p_id_lectura_qr            IN       VARCHAR2
    , p_journal_no               OUT      VARCHAR2
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      l_transaction_interface_id                        NUMBER (15);
      ln_retcode                                        NUMBER;
      l_return_status                                   VARCHAR2 (250);
      l_msg_count                                       NUMBER;
      l_msg_data                                        VARCHAR2 (250);
      l_trans_count                                     NUMBER;
   BEGIN
      -- borra lo que haya estado y haya tenido error y lo vuelve a insertar corregido
      DELETE FROM mtl_transactions_interface
            WHERE source_line_id = p_id_lectura_qr
              AND source_code = 'Expendio';

-- Get the Interface Transaction ID
      SELECT mtl_material_transactions_s.NEXTVAL
        INTO l_transaction_interface_id
        FROM DUAL;

      INSERT INTO inv.mtl_transactions_interface
                  (transaction_header_id
                 , transaction_interface_id
                 , transaction_type_id
                 , transaction_uom
                 , transaction_date
                 , organization_id
                 , transaction_quantity
                 , last_update_date
                 , last_updated_by
                 , creation_date
                 , created_by
                 , transaction_mode
                 , process_flag
                 , source_header_id
                 , source_line_id
                 , source_code
                 , transaction_source_id
                 , lock_flag
                 , flow_schedule
                 , scheduled_flag
                 , inventory_item_id
                 , subinventory_code
                 , distribution_account_id
                 --,            cost_type_id
      ,            locator_id
                 , pa_expenditure_org_id
                 , source_project_id
                 , source_task_id
                 , expenditure_type
                 , reason_id
                 , attribute_category
                 , attribute1
                 , attribute2
                 , attribute3
                 , attribute4
                 , attribute5
                 , attribute6
                 , attribute7
                 , attribute8
                 , attribute9
                 , attribute10
                 , attribute11
                 , attribute12
                 , attribute13
                 , attribute14
                 , attribute15
                  )
         SELECT l_transaction_interface_id transaction_header_id
              , l_transaction_interface_id transaction_interface_id
              , xec.transaction_type_id transaction_type_id
              , xec.udm_aprobada transaction_uom
              , xec.fecha_trx transaction_date
              , xec.organization_id organization_id
              , DECODE (transaction_action_id
                      , 1, ABS (xec.cantidad_expendida) * -1
                      , ABS (xec.cantidad_expendida)
                       ) transaction_quantity
              , SYSDATE last_update_date
              , fnd_global.user_id last_updated_by
              , SYSDATE creation_date
              , fnd_global.user_id created_by
              , 3 transaction_mode
              , 1 process_flag
              , 1 source_header_id
              , p_id_lectura_qr source_line_id
              , 'Expendio' source_code
              , NVL (xec.transaction_source_id, xec.distribution_account_id) transaction_source_id
              , 2 lock_flag
              , 'Y' flow_schedule
              , 2 scheduled_flag
              , item_id inventory_item_id
              , whse_code subinventory_code
              , distribution_account_id
              , inventory_location_id
              , pa_expenditure_org_id
              , project_id
              , task_id
              , xec.expenditure_type
              , mrsn.reason_id
              , mrsn.reason_id
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE1') attribute1
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE2') attribute2
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE3') attribute3
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE4') attribute4
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE5') attribute5
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE6') attribute6
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE7') attribute7
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE8') attribute8
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE9') attribute9
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE10') attribute10
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE11') attribute11
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE12') attribute12
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE13') attribute13
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE14') attribute14
              , (SELECT DECODE (end_user_column_name
                              , 'XX_OPM_CAMPAÃ?A', campana
                              , 'XX_OPM_PATENTE_VEHICULO', patente_veh_maq
                              , 'XX_OPM_KM_VEHICULO', km_vehiculo
                               )
                   FROM fnd_descr_flex_col_usage_vl dfcol
                  WHERE descriptive_flexfield_name = 'MTL_MATERIAL_TRANSACTIONS'
                    AND descriptive_flex_context_code =    mrsn.reason_id
                                                        || ''
                    AND application_column_name = 'ATTRIBUTE15') attribute15
           FROM xx_exp_combustibles_stg_v xec
              , mtl_transaction_reasons mrsn
          WHERE xec.reason_code = mrsn.reason_name(+)
            AND id_lectura_qr = p_id_lectura_qr;

      INSERT INTO mtl_transaction_lots_interface
                  (transaction_interface_id
                 , lot_number
                 , transaction_quantity
                 , last_update_date
                 , last_updated_by
                 , creation_date
                 , created_by
                 , product_transaction_id
                 , primary_quantity
                  )
         SELECT l_transaction_interface_id transaction_interface_id
              , lot_number
              , DECODE (transaction_action_id
                      , 1, ABS (xec.cantidad_expendida) * -1
                      , ABS (xec.cantidad_expendida)
                       )
              , SYSDATE
              , fnd_global.user_id
              , SYSDATE
              , fnd_global.user_id
              , l_transaction_interface_id
              , DECODE (transaction_action_id
                      , 1, ABS (xec.cantidad_expendida) * -1
                      , ABS (xec.cantidad_expendida)
                       )
           FROM xx_exp_combustibles_stg_v xec
          WHERE id_lectura_qr = p_id_lectura_qr
            AND lot_number IS NOT NULL;

      COMMIT;
      ln_retcode                                     :=
         inv_txn_manager_pub.process_transactions (p_api_version                 => 1.0
                                                 , p_init_msg_list               => fnd_api.g_true
                                                 , x_return_status               => l_return_status
                                                 , x_msg_count                   => l_msg_count
                                                 , x_msg_data                    => l_msg_data
                                                 , x_trans_count                 => l_trans_count
                                                 , p_header_id                   => l_transaction_interface_id
                                                  );
      p_return_status                                := l_return_status;

      IF l_return_status = 'E'
      THEN
         SELECT NVL (error_explanation, ERROR_CODE)
           INTO p_errmsg
           FROM mtl_transactions_interface
          WHERE transaction_interface_id = l_transaction_interface_id;
      END IF;

      IF l_return_status = 'S'
      THEN
         p_journal_no                                   := l_transaction_interface_id;
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   END;

------------------------------------------------------------------------
-- Funcion que genera un consumo de OPM
------------------------------------------------------------------------
   FUNCTION genera_consumo (
      p_orgn_code                IN       VARCHAR2
    , p_reason_code              IN       VARCHAR2
    , p_item_no                  IN       VARCHAR2
    , p_from_whse_code           IN       VARCHAR2
    , p_from_location            IN       VARCHAR2
    , p_trans_qty                IN       NUMBER
    , p_co_code                  IN       VARCHAR2
    , p_item_um                  IN       VARCHAR2
    , p_org_id                   IN       NUMBER
    , p_trx_date                 IN       DATE
    , p_attribute1               IN       VARCHAR2
    , p_attribute12              IN       VARCHAR2
    , p_attribute13              IN       VARCHAR2
    , p_attribute_category       IN       VARCHAR2
    , p_journal_no               OUT      VARCHAR2
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      v_existe                                          NUMBER;
      l_qty_rec                                         gmigapi.qty_rec_typ;
      l_ic_jrnl_mst_row                                 ic_jrnl_mst%ROWTYPE;
      l_ic_adjs_jnl_row1                                ic_adjs_jnl%ROWTYPE;
      l_ic_adjs_jnl_row2                                ic_adjs_jnl%ROWTYPE;
      l_item_id                                         NUMBER;
      l_lot_id                                          NUMBER;
      l_lot_no                                          NUMBER;
      l_return_status                                   VARCHAR2 (3000);
      l_msg_count                                       NUMBER := 0;
      l_msg_data                                        VARCHAR2 (30000);
      l_dummy_cnt                                       NUMBER := 0;
      l_loop_cnt                                        NUMBER := 0;
      return_sts                                        BOOLEAN;
      l_errmsg                                          VARCHAR2 (30000);
   BEGIN
 --gmigutl.api_version := '3.0'; --set serveroutput on size 20000;
 --DBMS_APPLICATION_INFO.set_client_info (p_org_id);
/*L_QTY_REC.trans_type valid values are:1 - create
2 - adjust
3 - move
4 - change lot
5 - change QC grade.
No other values allowed*/
      BEGIN
         /*SELECT DISTINCT i.item_id r11i
         INTO l_item_id
         FROM ic_item_mst_b i
         WHERE i.item_no = p_item_no; */
         SELECT DISTINCT inventory_item_id
                    INTO l_item_id
                    FROM mtl_system_items_b
                   WHERE segment1 = p_item_no;
      EXCEPTION
         WHEN OTHERS
         THEN
            l_item_id                                      := NULL;
      END;

      BEGIN
         /* r11i
         SELECT DISTINCT lot_no, lot_id
         INTO l_lot_no, l_lot_id
         FROM ic_lots_mst
         WHERE item_id = l_item_id
         --AND delete_mark = 0
         --AND lot_id > 0
         ;*/
         SELECT DISTINCT lot_number
                    INTO l_lot_no
                    FROM mtl_lot_numbers
                   WHERE inventory_item_id = l_item_id;
      EXCEPTION
         WHEN OTHERS
         THEN
            l_lot_no                                       := NULL;
            l_lot_id                                       := NULL;
      END;

      BEGIN
         SELECT fv.flex_value_id
           INTO l_qty_rec.attribute1
           FROM fnd_flex_values_vl fv
              , fnd_flex_value_sets fvs
          WHERE 1 = 1
            AND fv.flex_value_set_id = fvs.flex_value_set_id
            AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
            AND fv.flex_value = p_attribute1;
      EXCEPTION
         WHEN OTHERS
         THEN
            l_qty_rec.attribute1                           := NULL;
      END;

      l_qty_rec.trans_type                           := 2;
      l_qty_rec.orgn_code                            := p_orgn_code;
      l_qty_rec.reason_code                          := p_reason_code;
      l_qty_rec.item_no                              := p_item_no;
      l_qty_rec.item_um                              := p_item_um;
      --l_qty_rec.lot_no := NULL;
      --l_qty_rec.l_lot_id := l_lot_id; --NULL;
      l_qty_rec.from_whse_code                       := p_from_whse_code;
      l_qty_rec.from_location                        := p_from_location;
      l_qty_rec.lot_status                           := 'OK';
      l_qty_rec.co_code                              := p_co_code;
      l_qty_rec.trans_qty                            := p_trans_qty * -1;
      l_qty_rec.user_name                            := fnd_global.user_name;
      --l_qty_rec.attribute1 := p_attribute1;
      l_qty_rec.attribute12                          := p_attribute12;
      l_qty_rec.attribute13                          := p_attribute13;
      l_qty_rec.attribute_category                   := p_attribute_category;
------------------------------------------------------------------------------------------------
      xx_exp_combustible_pk.xx_exp_cuentas (p_reason_code
                                          , l_item_id
                                          , p_item_no
                                          , l_lot_id
                                          , l_lot_no
                                          , p_attribute1
                                          , p_from_whse_code
                                          , p_orgn_code
                                          , p_co_code
                                          , l_qty_rec.acct_no
                                          , l_qty_rec.acctg_unit_no
                                          , l_errmsg
                                           );
      l_qty_rec.trans_date                           := p_trx_date;
      return_sts                                     := gmigutl.setup (fnd_global.user_name);
      l_qty_rec.journal_no                           := p_journal_no;
      gmipapi.inventory_posting (p_api_version                 => gmigutl.api_version
                               ,
--3.0,
                                 p_init_msg_list               => fnd_api.g_true
                               , p_commit                      => fnd_api.g_true
                               , p_validation_level            => fnd_api.g_valid_level_full
                               , p_qty_rec                     => l_qty_rec
                               , x_ic_jrnl_mst_row             => l_ic_jrnl_mst_row
                               , x_ic_adjs_jnl_row1            => l_ic_adjs_jnl_row1
                               , x_ic_adjs_jnl_row2            => l_ic_adjs_jnl_row2
                               , x_return_status               => l_return_status
                               , x_msg_count                   => l_msg_count
                               , x_msg_data                    => l_msg_data
                                );

      IF l_msg_count > 0
      THEN
         l_loop_cnt                                     := 1;

         LOOP
            --apps.fnd_msg_pub.get (p_msg_index => l_loop_cnt, r11i
            fnd_msg_pub.get (p_msg_index                   => l_loop_cnt
                           ,                                                                                      -- r12
                             p_data                        => l_msg_data
                           , p_encoded                     => fnd_api.g_false
                           ,                                                                 -- => apps.fnd_api.g_false,
                             p_msg_index_out               => l_dummy_cnt
                            );
            --DBMS_OUTPUT.put_line (l_msg_data);
            l_loop_cnt                                     :=   l_loop_cnt
                                                              + 1;

            IF l_loop_cnt > l_msg_count
            THEN
               EXIT;
            END IF;
         END LOOP;

         p_return_status                                := l_return_status;
         p_errmsg                                       :=    l_errmsg
                                                           || ' X '
                                                           || l_qty_rec.acct_no
                                                           || ' X '
                                                           || l_qty_rec.acctg_unit_no
                                                           || ' X '
                                                           || l_msg_data;
         --p_errmsg := l_msg_data;
         p_journal_no                                   := l_ic_jrnl_mst_row.journal_no;
      ELSE
         p_return_status                                := 'l_msg_count = 0';
      END IF;

      IF l_return_status = 'S'
      THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_errmsg                                       := (l_msg_data);
         RETURN FALSE;
   END genera_consumo;

   ----
   ----
   ----
   ---
   FUNCTION bookear_pedido (
      p_header_id                IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      v_api_version_number                              NUMBER := 1;
      v_return_status                                   VARCHAR2 (2000);
      v_msg_count                                       NUMBER;
      v_msg_data                                        VARCHAR2 (2000);
-- IN Variables --
      v_header_rec                                      oe_order_pub.header_rec_type;
      v_line_tbl                                        oe_order_pub.line_tbl_type;
      v_action_request_tbl                              oe_order_pub.request_tbl_type;
      v_line_adj_tbl                                    oe_order_pub.line_adj_tbl_type;
-- OUT Variables --
      v_header_rec_out                                  oe_order_pub.header_rec_type;
      v_header_val_rec_out                              oe_order_pub.header_val_rec_type;
      v_header_adj_tbl_out                              oe_order_pub.header_adj_tbl_type;
      v_header_adj_val_tbl_out                          oe_order_pub.header_adj_val_tbl_type;
      v_header_price_att_tbl_out                        oe_order_pub.header_price_att_tbl_type;
      v_header_adj_att_tbl_out                          oe_order_pub.header_adj_att_tbl_type;
      v_header_adj_assoc_tbl_out                        oe_order_pub.header_adj_assoc_tbl_type;
      v_header_scredit_tbl_out                          oe_order_pub.header_scredit_tbl_type;
      v_header_scredit_val_tbl_out                      oe_order_pub.header_scredit_val_tbl_type;
      v_line_tbl_out                                    oe_order_pub.line_tbl_type;
      v_line_val_tbl_out                                oe_order_pub.line_val_tbl_type;
      v_line_adj_tbl_out                                oe_order_pub.line_adj_tbl_type;
      v_line_adj_val_tbl_out                            oe_order_pub.line_adj_val_tbl_type;
      v_line_price_att_tbl_out                          oe_order_pub.line_price_att_tbl_type;
      v_line_adj_att_tbl_out                            oe_order_pub.line_adj_att_tbl_type;
      v_line_adj_assoc_tbl_out                          oe_order_pub.line_adj_assoc_tbl_type;
      v_line_scredit_tbl_out                            oe_order_pub.line_scredit_tbl_type;
      v_line_scredit_val_tbl_out                        oe_order_pub.line_scredit_val_tbl_type;
      v_lot_serial_tbl_out                              oe_order_pub.lot_serial_tbl_type;
      v_lot_serial_val_tbl_out                          oe_order_pub.lot_serial_val_tbl_type;
      v_action_request_tbl_out                          oe_order_pub.request_tbl_type;
   BEGIN
      DBMS_OUTPUT.put_line ('Starting of script');
-- Setting the Enviroment --
      v_action_request_tbl (1)                       := oe_order_pub.g_miss_request_rec;
      v_action_request_tbl (1).request_type          := oe_globals.g_book_order;
      v_action_request_tbl (1).entity_code           := oe_globals.g_entity_header;
      v_action_request_tbl (1).entity_id             := p_header_id;
      oe_order_pub.process_order (p_api_version_number          => v_api_version_number
                                , p_header_rec                  => v_header_rec
                                , p_line_tbl                    => v_line_tbl
                                , p_action_request_tbl          => v_action_request_tbl
                                , p_line_adj_tbl                => v_line_adj_tbl
-- OUT variables
      ,                           x_header_rec                  => v_header_rec_out
                                , x_header_val_rec              => v_header_val_rec_out
                                , x_header_adj_tbl              => v_header_adj_tbl_out
                                , x_header_adj_val_tbl          => v_header_adj_val_tbl_out
                                , x_header_price_att_tbl        => v_header_price_att_tbl_out
                                , x_header_adj_att_tbl          => v_header_adj_att_tbl_out
                                , x_header_adj_assoc_tbl        => v_header_adj_assoc_tbl_out
                                , x_header_scredit_tbl          => v_header_scredit_tbl_out
                                , x_header_scredit_val_tbl      => v_header_scredit_val_tbl_out
                                , x_line_tbl                    => v_line_tbl_out
                                , x_line_val_tbl                => v_line_val_tbl_out
                                , x_line_adj_tbl                => v_line_adj_tbl_out
                                , x_line_adj_val_tbl            => v_line_adj_val_tbl_out
                                , x_line_price_att_tbl          => v_line_price_att_tbl_out
                                , x_line_adj_att_tbl            => v_line_adj_att_tbl_out
                                , x_line_adj_assoc_tbl          => v_line_adj_assoc_tbl_out
                                , x_line_scredit_tbl            => v_line_scredit_tbl_out
                                , x_line_scredit_val_tbl        => v_line_scredit_val_tbl_out
                                , x_lot_serial_tbl              => v_lot_serial_tbl_out
                                , x_lot_serial_val_tbl          => v_lot_serial_val_tbl_out
                                , x_action_request_tbl          => v_action_request_tbl_out
                                , x_return_status               => v_return_status
                                , x_msg_count                   => v_msg_count
                                , x_msg_data                    => v_msg_data
                                 );

      IF v_return_status = fnd_api.g_ret_sts_success
      THEN
         COMMIT;
         RETURN TRUE;
      ELSE
         ROLLBACK;

         FOR i IN 1 .. v_msg_count
         LOOP
            v_msg_data                                     := oe_msg_pub.get (p_msg_index                   => i
                                                                            , p_encoded                     => 'F');
         END LOOP;

         p_return_status                                := 'F';
         p_errmsg                                       := v_msg_data;
      END IF;
   END;

   FUNCTION genera_pedido (
      p_sold_to_org_id           IN       NUMBER
    , p_price_list_id            IN       NUMBER
    , p_sold_from_org_id         IN       NUMBER
    , p_ship_to_org_id           IN       NUMBER
    , p_invoice_to_org_id        IN       NUMBER
    , p_salesrep_id              IN       NUMBER
    , p_order_type_id            IN       NUMBER
    , p_inventory_item_id        IN       NUMBER
    , p_ordered_quantity         IN       NUMBER
    , p_ship_from_org_id         IN       NUMBER
    , p_line_type_id             IN       NUMBER
    , p_subinventory_code        IN       VARCHAR2
    -- amanukyan 20180110 mejora de agregar subinventory a la generacion del pedido
   ,  p_header_id                OUT      NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      v_existe                                          NUMBER;
      l_header_rec                                      oe_order_pub.header_rec_type;
      l_line_tbl                                        oe_order_pub.line_tbl_type;
      l_action_request_tbl                              oe_order_pub.request_tbl_type;
      l_header_adj_tbl                                  oe_order_pub.header_adj_tbl_type;
      l_line_adj_tbl                                    oe_order_pub.line_adj_tbl_type;
      l_header_scr_tbl                                  oe_order_pub.header_scredit_tbl_type;
      l_line_scredit_tbl                                oe_order_pub.line_scredit_tbl_type;
      l_request_rec                                     oe_order_pub.request_rec_type;
      l_return_status                                   VARCHAR2 (1000);
      l_msg_count                                       NUMBER;
      l_msg_data                                        VARCHAR2 (1000);
      p_api_version_number                              NUMBER := 1.0;
      p_init_msg_list                                   VARCHAR2 (10) := fnd_api.g_false;
      p_return_values                                   VARCHAR2 (10) := fnd_api.g_false;
      p_action_commit                                   VARCHAR2 (10) := fnd_api.g_false;
      x_return_status                                   VARCHAR2 (1);
      x_msg_count                                       NUMBER;
      x_msg_data                                        VARCHAR2 (100);
      --
      x_header_rec                                      oe_order_pub.header_rec_type := oe_order_pub.g_miss_header_rec;
      p_old_header_rec                                  oe_order_pub.header_rec_type := oe_order_pub.g_miss_header_rec;
      p_header_val_rec                                  oe_order_pub.header_val_rec_type
                                                                                  := oe_order_pub.g_miss_header_val_rec;
      p_old_header_val_rec                              oe_order_pub.header_val_rec_type
                                                                                  := oe_order_pub.g_miss_header_val_rec;
      p_header_adj_tbl                                  oe_order_pub.header_adj_tbl_type
                                                                                  := oe_order_pub.g_miss_header_adj_tbl;
      p_old_header_adj_tbl                              oe_order_pub.header_adj_tbl_type
                                                                                  := oe_order_pub.g_miss_header_adj_tbl;
      p_header_adj_val_tbl                              oe_order_pub.header_adj_val_tbl_type
                                                                              := oe_order_pub.g_miss_header_adj_val_tbl;
      p_old_header_adj_val_tbl                          oe_order_pub.header_adj_val_tbl_type
                                                                              := oe_order_pub.g_miss_header_adj_val_tbl;
      p_header_price_att_tbl                            oe_order_pub.header_price_att_tbl_type
                                                                            := oe_order_pub.g_miss_header_price_att_tbl;
      p_old_header_price_att_tbl                        oe_order_pub.header_price_att_tbl_type
                                                                            := oe_order_pub.g_miss_header_price_att_tbl;
      p_header_adj_att_tbl                              oe_order_pub.header_adj_att_tbl_type
                                                                              := oe_order_pub.g_miss_header_adj_att_tbl;
      p_old_header_adj_att_tbl                          oe_order_pub.header_adj_att_tbl_type
                                                                              := oe_order_pub.g_miss_header_adj_att_tbl;
      p_header_adj_assoc_tbl                            oe_order_pub.header_adj_assoc_tbl_type
                                                                            := oe_order_pub.g_miss_header_adj_assoc_tbl;
      p_old_header_adj_assoc_tbl                        oe_order_pub.header_adj_assoc_tbl_type
                                                                            := oe_order_pub.g_miss_header_adj_assoc_tbl;
      p_header_scredit_tbl                              oe_order_pub.header_scredit_tbl_type
                                                                              := oe_order_pub.g_miss_header_scredit_tbl;
      p_old_header_scredit_tbl                          oe_order_pub.header_scredit_tbl_type
                                                                              := oe_order_pub.g_miss_header_scredit_tbl;
      p_header_scredit_val_tbl                          oe_order_pub.header_scredit_val_tbl_type
                                                                          := oe_order_pub.g_miss_header_scredit_val_tbl;
      p_old_header_scredit_val_tbl                      oe_order_pub.header_scredit_val_tbl_type
                                                                          := oe_order_pub.g_miss_header_scredit_val_tbl;
      p_line_tbl                                        oe_order_pub.line_tbl_type := oe_order_pub.g_miss_line_tbl;
      p_old_line_tbl                                    oe_order_pub.line_tbl_type := oe_order_pub.g_miss_line_tbl;
      p_line_val_tbl                                    oe_order_pub.line_val_tbl_type
                                                                                    := oe_order_pub.g_miss_line_val_tbl;
      p_old_line_val_tbl                                oe_order_pub.line_val_tbl_type
                                                                                    := oe_order_pub.g_miss_line_val_tbl;
      p_line_adj_tbl                                    oe_order_pub.line_adj_tbl_type
                                                                                    := oe_order_pub.g_miss_line_adj_tbl;
      p_old_line_adj_tbl                                oe_order_pub.line_adj_tbl_type
                                                                                    := oe_order_pub.g_miss_line_adj_tbl;
      p_line_adj_val_tbl                                oe_order_pub.line_adj_val_tbl_type
                                                                                := oe_order_pub.g_miss_line_adj_val_tbl;
      p_old_line_adj_val_tbl                            oe_order_pub.line_adj_val_tbl_type
                                                                                := oe_order_pub.g_miss_line_adj_val_tbl;
      p_line_price_att_tbl                              oe_order_pub.line_price_att_tbl_type
                                                                              := oe_order_pub.g_miss_line_price_att_tbl;
      p_old_line_price_att_tbl                          oe_order_pub.line_price_att_tbl_type
                                                                              := oe_order_pub.g_miss_line_price_att_tbl;
      p_line_adj_att_tbl                                oe_order_pub.line_adj_att_tbl_type
                                                                                := oe_order_pub.g_miss_line_adj_att_tbl;
      p_old_line_adj_att_tbl                            oe_order_pub.line_adj_att_tbl_type
                                                                                := oe_order_pub.g_miss_line_adj_att_tbl;
      p_line_adj_assoc_tbl                              oe_order_pub.line_adj_assoc_tbl_type
                                                                              := oe_order_pub.g_miss_line_adj_assoc_tbl;
      p_old_line_adj_assoc_tbl                          oe_order_pub.line_adj_assoc_tbl_type
                                                                              := oe_order_pub.g_miss_line_adj_assoc_tbl;
      p_line_scredit_tbl                                oe_order_pub.line_scredit_tbl_type
                                                                                := oe_order_pub.g_miss_line_scredit_tbl;
      p_old_line_scredit_tbl                            oe_order_pub.line_scredit_tbl_type
                                                                                := oe_order_pub.g_miss_line_scredit_tbl;
      p_line_scredit_val_tbl                            oe_order_pub.line_scredit_val_tbl_type
                                                                            := oe_order_pub.g_miss_line_scredit_val_tbl;
      p_old_line_scredit_val_tbl                        oe_order_pub.line_scredit_val_tbl_type
                                                                            := oe_order_pub.g_miss_line_scredit_val_tbl;
      p_lot_serial_tbl                                  oe_order_pub.lot_serial_tbl_type
                                                                                  := oe_order_pub.g_miss_lot_serial_tbl;
      p_old_lot_serial_tbl                              oe_order_pub.lot_serial_tbl_type
                                                                                  := oe_order_pub.g_miss_lot_serial_tbl;
      p_lot_serial_val_tbl                              oe_order_pub.lot_serial_val_tbl_type
                                                                              := oe_order_pub.g_miss_lot_serial_val_tbl;
      p_old_lot_serial_val_tbl                          oe_order_pub.lot_serial_val_tbl_type
                                                                              := oe_order_pub.g_miss_lot_serial_val_tbl;
      p_action_request_tbl                              oe_order_pub.request_tbl_type
                                                                                     := oe_order_pub.g_miss_request_tbl;
      --
      x_header_val_rec                                  oe_order_pub.header_val_rec_type;
      x_header_adj_tbl                                  oe_order_pub.header_adj_tbl_type;
      x_header_adj_val_tbl                              oe_order_pub.header_adj_val_tbl_type;
      x_header_price_att_tbl                            oe_order_pub.header_price_att_tbl_type;
      x_header_adj_att_tbl                              oe_order_pub.header_adj_att_tbl_type;
      x_header_adj_assoc_tbl                            oe_order_pub.header_adj_assoc_tbl_type;
      x_header_scredit_tbl                              oe_order_pub.header_scredit_tbl_type;
      x_header_scredit_val_tbl                          oe_order_pub.header_scredit_val_tbl_type;
      x_line_val_tbl                                    oe_order_pub.line_val_tbl_type;
      x_line_adj_tbl                                    oe_order_pub.line_adj_tbl_type;
      x_line_adj_val_tbl                                oe_order_pub.line_adj_val_tbl_type;
      x_line_price_att_tbl                              oe_order_pub.line_price_att_tbl_type;
      x_line_adj_att_tbl                                oe_order_pub.line_adj_att_tbl_type;
      x_line_adj_assoc_tbl                              oe_order_pub.line_adj_assoc_tbl_type;
      x_line_scredit_tbl                                oe_order_pub.line_scredit_tbl_type;
      x_line_scredit_val_tbl                            oe_order_pub.line_scredit_val_tbl_type;
      x_lot_serial_tbl                                  oe_order_pub.lot_serial_tbl_type;
      x_lot_serial_val_tbl                              oe_order_pub.lot_serial_val_tbl_type;
      x_action_request_tbl                              oe_order_pub.request_tbl_type;
      x_debug_file                                      VARCHAR2 (100);
      l_line_tbl_index                                  NUMBER;
      l_msg_index_out                                   NUMBER (10);
      --
      l_vlog                                            VARCHAR2 (5000) := '';
      l_errmsg                                          VARCHAR2 (30000);
      l_vtransacao                                      oe_transaction_types_tl.NAME%TYPE;
      -- apps.oe_transaction_types_tl.NAME%TYPE;
      l_vglobal_attribute7                              ra_cust_trx_types.global_attribute7%TYPE;
      -- apps.ra_cust_trx_types.global_attribute7%TYPE;
      l_vglobal_attribute8                              ra_cust_trx_types.global_attribute8%TYPE;
      -- apps.ra_cust_trx_types.global_attribute8%TYPE;
      l_vglobal_attribute9                              ra_cust_trx_types.global_attribute9%TYPE;
      -- apps.ra_cust_trx_types.global_attribute9%TYPE;
      l_vglobal_attribute10                             ra_cust_trx_types.global_attribute10%TYPE;
      -- apps.ra_cust_trx_types.global_attribute10%TYPE;
      l_vcliente                                        hz_parties.party_name%TYPE; -- apps.hz_parties.party_name%TYPE;
      l_vnro_cliente                                    hz_cust_accounts.account_number%TYPE;
      -- apps.hz_cust_accounts.account_number%TYPE;
      l_ntransaction_type_id                            oe_transaction_types_tl.transaction_type_id%TYPE;
                                                              -- apps.oe_transaction_types_tl.transaction_type_id%TYPE;
      --l_vSeparador_log VARCHAR2(100) := NULL;
      l_npreco_fob                                      xx_om_import_ov_lines.preco_fob%TYPE;
      -- apps.xx_om_import_ov_lines.preco_fob%TYPE;
      l_nfrete                                          xx_om_import_ov_lines.frete%TYPE;
      -- apps.xx_om_import_ov_lines.frete%TYPE;
      l_vprazo                                          xx_om_import_ov_lines.prazo%TYPE;
      -- apps.xx_om_import_ov_lines.prazo%TYPE;
      l_nterm_id                                        ra_terms.term_id%TYPE;           -- apps.ra_terms.term_id%TYPE;
      l_nship_to_org_id                                 hz_cust_site_uses_all.site_use_id%TYPE;
      -- apps.hz_cust_site_uses_all.site_use_id%TYPE; -- Entregar para
      l_ninvoice_to_org_id                              hz_cust_site_uses_all.site_use_id%TYPE;
      -- apps.hz_cust_site_uses_all.site_use_id%TYPE; -- Faturar para
      l_nordered_quantity                               oe_order_lines_all.ordered_quantity%TYPE;
      -- apps.oe_order_lines_all.ordered_quantity%TYPE;
      l_salesrep_id                                     NUMBER;
      l_resp_id                                         NUMBER;
      l_line_type_id                                    NUMBER;
   BEGIN
      --fnd_global.apps_initialize(fnd_global.user_id,53031,660);
      l_line_tbl_index                               := 0;
      l_header_rec                                   := oe_order_pub.g_miss_header_rec;
      l_header_rec.transactional_curr_code           := 'ARS';
      l_header_rec.pricing_date                      := SYSDATE;

      --
      /*  CR2395 - Se precisa enviar el org id correcto a la API que genera el pedido
                   caso contrario, la misma toma por defecto MO_Get_Default_Org 
      BEGIN
         SELECT MIN (TO_NUMBER (level_value))
           INTO l_resp_id
           FROM fnd_profile_option_values
          WHERE profile_option_id IN (SELECT profile_option_id
                                        FROM fnd_profile_options
                                       WHERE profile_option_name = 'ORG_ID')
            AND profile_option_value = TO_CHAR (p_sold_from_org_id)
            AND level_value_application_id = 660;

         --DBMS_APPLICATION_INFO.set_client_info (p_sold_from_org_id);
         fnd_global.apps_initialize (fnd_global.user_id
                                   ,                                                                             --7896,
                                     l_resp_id
                                   , 660
                                    );
      EXCEPTION
         WHEN OTHERS
         THEN
            l_resp_id                                      := NULL;
      END;*/
       MO_GLOBAL.set_policy_context('S', p_sold_from_org_id);
       -- fin CR2395
       
------------------------------------------------------------------------------------------------
      l_header_rec.price_list_id                     := p_price_list_id;                                       --434208;
      l_header_rec.ordered_date                      := SYSDATE;
      l_header_rec.shipping_method_code              := NULL;
------------------------------------------------------------------------------------------------
      l_header_rec.sold_from_org_id                  := p_sold_from_org_id;                                       --102;
      l_header_rec.sold_to_org_id                    := p_sold_to_org_id;                         --5110515; customer_id
      l_header_rec.ship_to_org_id                    := p_ship_to_org_id;                                      --172960;
      l_header_rec.invoice_to_org_id                 := p_invoice_to_org_id;                                   --172958;
      --insert into temp values ('SC DESPUES: x_return_status: '||x_return_status || ' x_msg_data: '||x_msg_data); commit;
      --insert into temp values ('p_sold_from_org_id: '||p_sold_from_org_id);
      --insert into temp values ('p_sold_to_org_id: '||p_sold_to_org_id);
      --insert into temp values ('p_ship_to_org_id: '||p_ship_to_org_id);
      --insert into temp values ('p_invoice_to_org_id: '||p_invoice_to_org_id);
      COMMIT;

------------------------------------------------------------------------------------------------

      --Se obtiene el SALESREP ID de la empresa de donde se vende
      BEGIN
         SELECT MAX (salesrep_id)
           INTO l_salesrep_id
-- FROM apps.jtf_rs_salesreps r11i
         FROM   jtf_rs_salesreps                                                                                  -- r12
          WHERE org_id = p_sold_from_org_id
          AND status = 'A' --CR1625
          AND  sysdate BETWEEN nvl(start_date_active,sysdate) AND nvl(end_date_active,sysdate) --CR1625
          AND  name like 'Administracion Central'; --CR1625
      EXCEPTION
         WHEN OTHERS
         THEN
            l_salesrep_id                                  := NULL;
      END;

      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                           , p_message                     =>    'l_salesrep_id: '
                                                              || l_salesrep_id);

      l_header_rec.salesrep_id                       := l_salesrep_id;        --100002088; --p_salesrep_id; --100002049;
      l_header_rec.order_type_id                     := p_order_type_id;                                        --11084;
      l_header_rec.operation                         := oe_globals.g_opr_create;
------------------------------------------------------------------------------------------------

      --l_line_tbl_index := l_line_tbl_index + 1;
      l_line_tbl (1)                                 := oe_order_pub.g_miss_line_rec;

      SELECT MIN (default_outbound_line_type_id)
        INTO l_line_type_id
        -- FROM oe_order_types_v r11i
      FROM   (SELECT s.*
                   , t.NAME
                   , t.description
                FROM oe_transaction_types_tl t
                   , oe_transaction_types_all s
               WHERE s.transaction_type_id = t.transaction_type_id
                 AND t.LANGUAGE = USERENV ('LANG')
                 AND s.transaction_type_code = 'ORDER'
                 AND NVL (s.sales_document_type_code, 'O') <> 'B')
       --WHERE order_type_id = p_order_type_id;
      WHERE  transaction_type_id = p_order_type_id;

      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                           , p_message                     =>    'l_line_type_id: '
                                                              || l_line_type_id);
      --
      -- Line attributes
      l_line_tbl (1).inventory_item_id               := p_inventory_item_id;                                  --3101961;
      l_line_tbl (1).ordered_quantity                := p_ordered_quantity;
      l_line_tbl (1).ship_from_org_id                := p_ship_from_org_id;                                 --397; --151
      l_line_tbl (1).line_type_id                    := l_line_type_id;
      l_line_tbl (1).subinventory                    := p_subinventory_code;
                                                            -- amanukyan 20180110 mejora de generacion con subinventario
      -- p_order_type_id; --4243; --p_line_type_id; --11083;
      l_line_tbl (1).operation                       := oe_globals.g_opr_create;
      l_action_request_tbl (1).request_type          := oe_globals.g_book_order;
      l_action_request_tbl (1).entity_code           := oe_globals.g_entity_header;
      --

      --
      -- CALL TO PROCESS ORDER Check the return status and then commit.
      oe_order_pub.process_order (p_org_id                      => p_sold_from_org_id    -- CR2395
                                , p_api_version_number          => 1.0
                                , p_init_msg_list               => fnd_api.g_false
                                , p_return_values               => fnd_api.g_false
                                , p_action_commit               => fnd_api.g_false
                                , x_return_status               => l_return_status
                                , x_msg_count                   => l_msg_count
                                , x_msg_data                    => l_msg_data
                                , p_header_rec                  => l_header_rec
                                , p_line_tbl                    => l_line_tbl
                                , p_action_request_tbl          => l_action_request_tbl
                                -- OUT PARAMETERS
      ,                           x_header_rec                  => x_header_rec
                                , x_header_val_rec              => x_header_val_rec
                                , x_header_adj_tbl              => x_header_adj_tbl
                                , x_header_adj_val_tbl          => x_header_adj_val_tbl
                                , x_header_price_att_tbl        => x_header_price_att_tbl
                                , x_header_adj_att_tbl          => x_header_adj_att_tbl
                                , x_header_adj_assoc_tbl        => x_header_adj_assoc_tbl
                                , x_header_scredit_tbl          => x_header_scredit_tbl
                                , x_header_scredit_val_tbl      => x_header_scredit_val_tbl
                                , x_line_tbl                    => p_line_tbl
                                , x_line_val_tbl                => x_line_val_tbl
                                , x_line_adj_tbl                => x_line_adj_tbl
                                , x_line_adj_val_tbl            => x_line_adj_val_tbl
                                , x_line_price_att_tbl          => x_line_price_att_tbl
                                , x_line_adj_att_tbl            => x_line_adj_att_tbl
                                , x_line_adj_assoc_tbl          => x_line_adj_assoc_tbl
                                , x_line_scredit_tbl            => x_line_scredit_tbl
                                , x_line_scredit_val_tbl        => x_line_scredit_val_tbl
                                , x_lot_serial_tbl              => x_lot_serial_tbl
                                , x_lot_serial_val_tbl          => x_lot_serial_val_tbl
                                , x_action_request_tbl          => l_action_request_tbl
                                 );

      --
      -- Retrieve messages
      FOR i IN 1 .. l_msg_count
      LOOP
         oe_msg_pub.get (p_msg_index                   => i
                       , p_encoded                     => fnd_api.g_false
                       , p_data                        => l_msg_data
                       , p_msg_index_out               => l_msg_index_out
                        );
      END LOOP;

      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO', p_message => 'Process Order: '
                                                               || l_msg_data);

      -- Check the return status
      IF l_return_status = fnd_api.g_ret_sts_success
      THEN
         p_header_id                                    := x_header_rec.header_id;

         -- amanukyan 20180219 bookea pedido
         IF bookear_pedido (p_header_id                   => x_header_rec.header_id
                          , p_return_status               => p_return_status
                          , p_errmsg                      => p_errmsg
                           )
         THEN
            p_return_status                                := l_return_status;
            p_errmsg                                       :=    x_header_rec.order_number
                                                              || ' '
                                                              || l_msg_data;
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      ELSE
         p_return_status                                := l_return_status;
         p_errmsg                                       :=    'Fallo Pedido: '
                                                           || l_msg_data;
         RETURN FALSE;
      END IF;
   END genera_pedido;

   FUNCTION genera_delivery (
      p_organization_id          IN       NUMBER
    , p_initial_pickup_location_id IN     NUMBER
    , p_ultimate_dropoff_location_id IN   NUMBER
    , p_waybill                  IN       VARCHAR
    , p_delivery_id              OUT      NUMBER
    , p_delivery_name            OUT      VARCHAR2
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      --DECLARE
      p_api_version                                     NUMBER;
      init_msg_list                                     VARCHAR2 (30);
      p_commit                                          VARCHAR2 (30);
      -- Parametros para llamar a la API WSH_DELIVERIES_PUB.create_update_delivery
      p_action_code                                     VARCHAR2 (15);
      delivery_id                                       NUMBER;
      delivery_info                                     wsh_deliveries_pub.delivery_pub_rec_type;
      delivery_name                                     VARCHAR2 (30);
      -- Parametros de Salida
      x_return_status                                   VARCHAR2 (10);
      x_msg_count                                       NUMBER;
      x_msg_data                                        VARCHAR2 (2000);
      x_msg_details                                     VARCHAR2 (3000);
      x_msg_summary                                     VARCHAR2 (3000);
      l_resp_id                                         NUMBER;
      -- Handle exceptions
      fail_api                                          EXCEPTION;
   BEGIN
      -- Initialize return status
      x_return_status                                := wsh_util_core.g_ret_sts_success;
      -- Call this procedure to initialize applications parameters.
      -- fnd_global.apps_initialize (user_id => 7896,
      -- resp_id => 50275,
      -- resp_appl_id => 660
      -- );

      -- Create a new delivery for the following
      delivery_info.NAME                             := NULL;
      --'COMBUS1'; -- Pass delivery name
      delivery_info.organization_id                  := p_organization_id;                      -- Pass Organization ID
      delivery_info.waybill                          := p_waybill;                                   --'0020-00013896';
      delivery_info.initial_pickup_location_id       := p_initial_pickup_location_id;   -- Pass the Pick up location ID
      delivery_info.ultimate_dropoff_location_id     := p_ultimate_dropoff_location_id;
      -- pass the Drop off location ID
      delivery_info.ship_method_code                 := NULL;                                       -- pass Ship Method
      p_action_code                                  := 'CREATE';                                        -- Action Code
      -- Call to WSH_DELIVERIES_PUB.create_update_delivery
      wsh_deliveries_pub.create_update_delivery (p_api_version_number          => 1.0
                                               , p_init_msg_list               => init_msg_list
                                               , x_return_status               => x_return_status
                                               , x_msg_count                   => x_msg_count
                                               , x_msg_data                    => x_msg_data
                                               , p_action_code                 => p_action_code
                                               , p_delivery_info               => delivery_info
                                               , p_delivery_name               => delivery_name
                                               , x_delivery_id                 => delivery_id
                                               , x_name                        => delivery_name
                                                );

      -- If the return status is not success(S) then raise exception
      IF (x_return_status <> wsh_util_core.g_ret_sts_success)
      THEN
         RAISE fail_api;
      ELSE
         p_delivery_id                                  := delivery_id;
         p_delivery_name                                := delivery_name;
         p_return_status                                := x_return_status;
         p_errmsg                                       :=    delivery_name
                                                           || ' '
                                                           || x_msg_data;
         RETURN TRUE;
      END IF;
   EXCEPTION
      WHEN fail_api
      THEN
         wsh_util_core.get_messages ('Y'
                                   , x_msg_summary
                                   , x_msg_details
                                   , x_msg_count
                                    );

         IF x_msg_count > 1
         THEN
            x_msg_data                                     :=    x_msg_summary
                                                              || x_msg_details;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Entrega: '
                                                              || x_msg_data;
            RETURN FALSE;
         ELSE
            x_msg_data                                     := x_msg_summary;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Entrega: '
                                                              || x_msg_data;
            RETURN FALSE;
         END IF;
   END genera_delivery;

   FUNCTION asocia_delivery_detail (
      p_header_id                IN       NUMBER
    , p_delivery_id              IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      -- Standard Parameters.
      p_api_version                                     NUMBER;
      p_init_msg_list                                   VARCHAR2 (30);
      p_commit                                          VARCHAR2 (30);
      -- Parameters for WSH_DELIVERY_DETAILS_PUB.Detail_to_Delivery
      --p_delivery_id NUMBER;
      p_delivery_name                                   VARCHAR2 (30);
      p_tabofdeldet                                     wsh_delivery_details_pub.id_tab_type;
      p_action                                          VARCHAR2 (30);
      -- out parameters
      x_return_status                                   VARCHAR2 (10);
      x_msg_count                                       NUMBER;
      x_msg_data                                        VARCHAR2 (2000);
      x_msg_details                                     VARCHAR2 (3000);
      x_msg_summary                                     VARCHAR2 (3000);
      -- Handle exceptions
      fail_api                                          EXCEPTION;

      CURSOR c_del_det
      IS
         SELECT delivery_detail_id
           FROM wsh_delivery_details
          WHERE source_header_id = p_header_id;
   BEGIN
      -- Initialize return status
      x_return_status                                := wsh_util_core.g_ret_sts_success;

      FOR c_dd IN c_del_det
      LOOP
         -- Values for WSH_DELIVERY_DETAILS_PUB.Detail_to_Delivery
         p_delivery_name                                := TO_CHAR (p_delivery_id);
         p_tabofdeldet (1)                              := c_dd.delivery_detail_id;
         p_action                                       := 'ASSIGN';
         -- Call to WSH_DELIVERY_DETAILS_PUB.Detail_to_Delivery.
         wsh_delivery_details_pub.detail_to_delivery (p_api_version                 => 1.0
                                                    , p_init_msg_list               => p_init_msg_list
                                                    , p_commit                      => p_commit
                                                    , x_return_status               => x_return_status
                                                    , x_msg_count                   => x_msg_count
                                                    , x_msg_data                    => x_msg_data
                                                    , p_tabofdeldets                => p_tabofdeldet
                                                    , p_action                      => p_action
                                                    , p_delivery_id                 => p_delivery_id
                                                    , p_delivery_name               => p_delivery_name
                                                     );
      END LOOP;

      -- If the return status is not success(S) then raise exception
      IF (x_return_status <> wsh_util_core.g_ret_sts_success)
      THEN
         RAISE fail_api;
      ELSE
         --p_delivery_id := delivery_id;
         --p_delivery_name := delivery_name;
         p_return_status                                := x_return_status;
         p_errmsg                                       :=    p_delivery_name
                                                           || ' '
                                                           || x_msg_data;
         RETURN TRUE;
      END IF;
   EXCEPTION
      WHEN fail_api
      THEN
         wsh_util_core.get_messages ('Y'
                                   , x_msg_summary
                                   , x_msg_details
                                   , x_msg_count
                                    );

         IF x_msg_count > 1
         THEN
            x_msg_data                                     :=    x_msg_summary
                                                              || x_msg_details;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Asociacion Entrega '
                                                              || x_msg_data;
            RETURN FALSE;
         ELSE
            x_msg_data                                     := x_msg_summary;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Asociacion Entrega '
                                                              || x_msg_data;
            RETURN FALSE;
         END IF;
   END asocia_delivery_detail;

   FUNCTION genera_pick_release (
      p_delivery_id              IN       NUMBER
    , p_sold_from_org_id         IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
--PICK RELASE SALES DELIVERY

      --DECLARE
      -- Standard Parameters.
      p_api_version                                     NUMBER;
      p_init_msg_list                                   VARCHAR2 (30);
      p_commit                                          VARCHAR2 (30);
      --Parameters for WSH_DELIVERIES_PUB.Delivery_Action.
      p_action_code                                     VARCHAR2 (15);
      --p_delivery_id NUMBER;
      p_delivery_name                                   VARCHAR2 (30);
      p_asg_trip_id                                     NUMBER;
      p_asg_trip_name                                   VARCHAR2 (30);
      p_asg_pickup_stop_id                              NUMBER;
      p_asg_pickup_loc_id                               NUMBER;
      p_asg_pickup_loc_code                             VARCHAR2 (30);
      p_asg_pickup_arr_date                             DATE;
      p_asg_pickup_dep_date                             DATE;
      p_asg_dropoff_stop_id                             NUMBER;
      p_asg_dropoff_loc_id                              NUMBER;
      p_asg_dropoff_loc_code                            VARCHAR2 (30);
      p_asg_dropoff_arr_date                            DATE;
      p_asg_dropoff_dep_date                            DATE;
      p_sc_action_flag                                  VARCHAR2 (10);
      p_sc_close_trip_flag                              VARCHAR2 (10);
      p_sc_create_bol_flag                              VARCHAR2 (10);
      p_sc_stage_del_flag                               VARCHAR2 (10);
      p_sc_trip_ship_method                             VARCHAR2 (30);
      p_sc_actual_dep_date                              VARCHAR2 (30);
      p_sc_report_set_id                                NUMBER;
      p_sc_report_set_name                              VARCHAR2 (60);
      p_wv_override_flag                                VARCHAR2 (10);
      x_trip_id                                         VARCHAR2 (30);
      x_trip_name                                       VARCHAR2 (30);
      -- outparameters
      x_return_status                                   VARCHAR2 (10);
      x_msg_count                                       NUMBER;
      x_msg_data                                        VARCHAR2 (2000);
      x_msg_details                                     VARCHAR2 (3000);
      x_msg_summary                                     VARCHAR2 (3000);
      l_resp_id                                         NUMBER;
      -- Handle exceptions
      fail_api                                          EXCEPTION;
   BEGIN
      -- Initialize return status
      x_return_status                                := wsh_util_core.g_ret_sts_success;

      -- Call this procedure to initialize applications parameters.
      BEGIN
         SELECT MIN (TO_NUMBER (level_value))
           INTO l_resp_id
           FROM fnd_profile_option_values
          WHERE profile_option_id IN (SELECT profile_option_id
                                        FROM fnd_profile_options
                                       WHERE profile_option_name = 'ORG_ID')
            AND profile_option_value = TO_CHAR (p_sold_from_org_id)
            AND level_value_application_id = 660;

         --DBMS_APPLICATION_INFO.set_client_info (p_sold_from_org_id);
         fnd_global.apps_initialize (fnd_global.user_id
                                   ,                                                                             --7896,
                                     l_resp_id
                                   , 660
                                    );
      EXCEPTION
         WHEN OTHERS
         THEN
            l_resp_id                                      := NULL;
      END;

      -- Values for WSH_DELIVERIES_PUB.delivery_action
      p_action_code                                  := 'PICK-RELEASE';          -- Releases Lines related to a delivery
      --p_delivery_id := 32038768; -- delivery ID that action is performed on
      -- Call to WSH_DELIVERIES_PUB.Delivery_Action.
      wsh_deliveries_pub.delivery_action (p_api_version_number          => 1.0
                                        , p_init_msg_list               => p_init_msg_list
                                        , x_return_status               => x_return_status
                                        , x_msg_count                   => x_msg_count
                                        , x_msg_data                    => x_msg_data
                                        , p_action_code                 => p_action_code
                                        , p_delivery_id                 => p_delivery_id
                                        , p_delivery_name               => p_delivery_id
                                        ,                                                             --p_delivery_name,
                                          p_asg_trip_id                 => p_asg_trip_id
                                        , p_asg_trip_name               => p_asg_trip_name
                                        , p_asg_pickup_stop_id          => p_asg_pickup_stop_id
                                        , p_asg_pickup_loc_id           => p_asg_pickup_loc_id
                                        , p_asg_pickup_loc_code         => p_asg_pickup_loc_code
                                        , p_asg_pickup_arr_date         => p_asg_pickup_arr_date
                                        , p_asg_pickup_dep_date         => p_asg_pickup_dep_date
                                        , p_asg_dropoff_stop_id         => p_asg_dropoff_stop_id
                                        , p_asg_dropoff_loc_id          => p_asg_dropoff_loc_id
                                        , p_asg_dropoff_loc_code        => p_asg_dropoff_loc_code
                                        , p_asg_dropoff_arr_date        => p_asg_dropoff_arr_date
                                        , p_asg_dropoff_dep_date        => p_asg_dropoff_dep_date
                                        , p_sc_action_flag              => p_sc_action_flag
                                        , p_sc_close_trip_flag          => p_sc_close_trip_flag
                                        , p_sc_create_bol_flag          => p_sc_create_bol_flag
                                        , p_sc_stage_del_flag           => p_sc_stage_del_flag
                                        , p_sc_trip_ship_method         => p_sc_trip_ship_method
                                        , p_sc_actual_dep_date          => p_sc_actual_dep_date
                                        , p_sc_report_set_id            => p_sc_report_set_id
                                        , p_sc_report_set_name          => p_sc_report_set_name
                                        , p_wv_override_flag            => p_wv_override_flag
                                        , x_trip_id                     => x_trip_id
                                        , x_trip_name                   => x_trip_name
                                         );

      -- If the return status is not success(S) then raise exception
      IF (x_return_status <> wsh_util_core.g_ret_sts_success)
      THEN
         RAISE fail_api;
      ELSE
         p_return_status                                := x_return_status;
         p_errmsg                                       :=    'Entrega Creada: '
                                                           || p_delivery_id;
         -- x_trip_id ||' - ' || x_trip_name ||' - ' ||x_msg_data;
         RETURN TRUE;
      END IF;
   EXCEPTION
      WHEN fail_api
      THEN
         wsh_util_core.get_messages ('Y'
                                   , x_msg_summary
                                   , x_msg_details
                                   , x_msg_count
                                    );

         IF x_msg_count > 1
         THEN
            x_msg_data                                     :=    x_msg_summary
                                                              || x_msg_details;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Despacho: '
                                                              || x_msg_data;
            RETURN FALSE;
         ELSE
            x_msg_data                                     := x_msg_summary;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Despacho: '
                                                              || x_msg_data;
            RETURN FALSE;
         END IF;
   END genera_pick_release;

   FUNCTION genera_ship_confirm (
      p_delivery_id              IN       NUMBER
    , p_sold_from_org_id         IN       NUMBER
    , p_return_status            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      --Standard Parameters.
      p_api_version                                     NUMBER;
      p_init_msg_list                                   VARCHAR2 (30);
      p_commit                                          VARCHAR2 (30);
      --Parameters for WSH_DELIVERIES_PUB.Delivery_Action.
      p_action_code                                     VARCHAR2 (15);
      p_delivery_name                                   VARCHAR2 (30);
      p_asg_trip_id                                     NUMBER;
      p_asg_trip_name                                   VARCHAR2 (30);
      p_asg_pickup_stop_id                              NUMBER;
      p_asg_pickup_loc_id                               NUMBER;
      p_asg_pickup_loc_code                             VARCHAR2 (30);
      p_asg_pickup_arr_date                             DATE;
      p_asg_pickup_dep_date                             DATE;
      p_asg_dropoff_stop_id                             NUMBER;
      p_asg_dropoff_loc_id                              NUMBER;
      p_asg_dropoff_loc_code                            VARCHAR2 (30);
      p_asg_dropoff_arr_date                            DATE;
      p_asg_dropoff_dep_date                            DATE;
      p_sc_action_flag                                  VARCHAR2 (10);
      p_sc_close_trip_flag                              VARCHAR2 (10);
      p_sc_create_bol_flag                              VARCHAR2 (10);
      p_sc_stage_del_flag                               VARCHAR2 (10);
      p_sc_trip_ship_method                             VARCHAR2 (30);
      p_sc_actual_dep_date                              VARCHAR2 (30);
      p_sc_report_set_id                                NUMBER;
      p_sc_report_set_name                              VARCHAR2 (60);
      p_wv_override_flag                                VARCHAR2 (10);
      p_sc_defer_interface_flag                         VARCHAR2 (1);
      x_trip_id                                         VARCHAR2 (30);
      x_trip_name                                       VARCHAR2 (30);
      --out parameters
      x_return_status                                   VARCHAR2 (10);
      x_msg_count                                       NUMBER;
      x_msg_data                                        VARCHAR2 (2000);
      x_msg_details                                     VARCHAR2 (3000);
      x_msg_summary                                     VARCHAR2 (3000);
      l_resp_id                                         NUMBER;
      -- Handle exceptions
      fail_api                                          EXCEPTION;
   BEGIN
      -- Initialize return status
      x_return_status                                := wsh_util_core.g_ret_sts_success;

      -- Call this procedure to initialize applications parameters
      BEGIN
         SELECT MIN (TO_NUMBER (level_value))
           INTO l_resp_id
           FROM fnd_profile_option_values
          WHERE profile_option_id IN (SELECT profile_option_id
                                        FROM fnd_profile_options
                                       WHERE profile_option_name = 'ORG_ID')
            AND profile_option_value = TO_CHAR (p_sold_from_org_id)
            AND level_value_application_id = 660;

         fnd_global.apps_initialize (fnd_global.user_id
                                   ,                                                                             --7896,
                                     l_resp_id
                                   , 660
                                    );
      EXCEPTION
         WHEN OTHERS
         THEN
            l_resp_id                                      := NULL;
      END;

      -- Values for Ship Confirming the delivery
      p_action_code                                  := 'CONFIRM';                   -- The action code for ship confirm
      --p_delivery_id := 32038768; -- The delivery that needs to be confirmed
      p_sc_action_flag                               := 'S';                                   -- Ship entered quantity.
      p_sc_close_trip_flag                           := 'Y';                        -- Close the trip after ship confirm
      p_sc_trip_ship_method                          := NULL;
      p_sc_trip_ship_method                          := '000001_TRANS_AR_T_600';
      -- The ship method code (aca iria el metodo "Puesto en Planta" pero hay que ver si se pasa el codigo o que)
      p_sc_defer_interface_flag                      := 'N';
      -- Call to WSH_DELIVERIES_PUB.Delivery_Action.
      wsh_deliveries_pub.delivery_action (p_api_version_number          => 1.0
                                        , p_init_msg_list               => p_init_msg_list
                                        , x_return_status               => x_return_status
                                        , x_msg_count                   => x_msg_count
                                        , x_msg_data                    => x_msg_data
                                        , p_action_code                 => p_action_code
                                        , p_delivery_id                 => p_delivery_id
                                        , p_delivery_name               => p_delivery_id
                                        ,                                                             --p_delivery_name,
                                          p_asg_trip_id                 => p_asg_trip_id
                                        , p_asg_trip_name               => p_asg_trip_name
                                        , p_asg_pickup_stop_id          => p_asg_pickup_stop_id
                                        , p_asg_pickup_loc_id           => p_asg_pickup_loc_id
                                        , p_asg_pickup_loc_code         => p_asg_pickup_loc_code
                                        , p_asg_pickup_arr_date         => p_asg_pickup_arr_date
                                        , p_asg_pickup_dep_date         => p_asg_pickup_dep_date
                                        , p_asg_dropoff_stop_id         => p_asg_dropoff_stop_id
                                        , p_asg_dropoff_loc_id          => p_asg_dropoff_loc_id
                                        , p_asg_dropoff_loc_code        => p_asg_dropoff_loc_code
                                        , p_asg_dropoff_arr_date        => p_asg_dropoff_arr_date
                                        , p_asg_dropoff_dep_date        => p_asg_dropoff_dep_date
                                        , p_sc_action_flag              => p_sc_action_flag
                                        , p_sc_close_trip_flag          => p_sc_close_trip_flag
                                        , p_sc_create_bol_flag          => p_sc_create_bol_flag
                                        , p_sc_stage_del_flag           => p_sc_stage_del_flag
                                        , p_sc_trip_ship_method         => p_sc_trip_ship_method
                                        , p_sc_actual_dep_date          => p_sc_actual_dep_date
                                        , p_sc_report_set_id            => p_sc_report_set_id
                                        , p_sc_report_set_name          => p_sc_report_set_name
                                        , p_wv_override_flag            => p_wv_override_flag
                                        , p_sc_defer_interface_flag     => p_sc_defer_interface_flag
                                        , x_trip_id                     => x_trip_id
                                        , x_trip_name                   => x_trip_name
                                         );

      --insert into temp values ('SC DESPUES: x_return_status: '||x_return_status || ' x_msg_data: '||x_msg_data); commit;

      -- If the return status is not success(S) then raise exception
      IF (x_return_status <> wsh_util_core.g_ret_sts_success)
      THEN
         RAISE fail_api;
      ELSE
         p_return_status                                := x_return_status;
         p_errmsg                                       := 'Confirmacion OK';
         RETURN TRUE;
      END IF;
   EXCEPTION
      WHEN fail_api
      THEN
         --insert into temp values ('SC EXCP'); commit;
         wsh_util_core.get_messages ('Y'
                                   , x_msg_summary
                                   , x_msg_details
                                   , x_msg_count
                                    );
         COMMIT;

         IF x_msg_count > 1
         THEN
            x_msg_data                                     :=    x_msg_summary
                                                              || x_msg_details;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Confirmacion: '
                                                              || x_msg_data;
            RETURN FALSE;
         ELSE
            x_msg_data                                     := x_msg_summary;
            p_return_status                                := x_return_status;
            p_errmsg                                       :=    'Fallo Confirmacion: '
                                                              || x_msg_data;
            RETURN FALSE;
         END IF;
      WHEN OTHERS
      THEN
         p_return_status                                := x_return_status;
         p_errmsg                                       :=    'SC WO- '
                                                           || x_msg_data;
   END genera_ship_confirm;

   PROCEDURE loader (
      p_errbuf                   OUT      VARCHAR2
    , p_retcode                  OUT      NUMBER
   )
   IS
      l_udm                                             VARCHAR2 (20);
      l_item_id                                         NUMBER;
      l_om_invoice_to_org_id                            NUMBER;
      l_om_ship_to_org_id                               NUMBER;
      l_transaction_type_id                             NUMBER;
      l_org_id                                          NUMBER;
      l_campana                                         VARCHAR2 (20);
      l_whse_code                                       VARCHAR2 (100);
      v_dummy                                           VARCHAR2 (1);
      v_source_code                                     VARCHAR2 (4);
      l_nro_remito_aprobado                             VARCHAR2 (20);
      v_msgerr                                          VARCHAR2 (300);

      CURSOR c_lecturas_qr
      IS
         SELECT id_qr
              , lect.id_lectura_qr
              , EXP.ts fecha_generacion
              ,                                                                                 --lect.fecha_generacion,
                EXP.cantidad cantidad_expendida
              , 0 cantidad_aprobada
              , LPAD (SUBSTR (REPLACE (nro_salida, '-')
                            , 1
                            , 6
                             )
                    , 6
                    , '0'
                     ) nro_salida
              , nro_remito
              , clasificacion
              , vendor_cuit
              , patente_veh_maq
              , customer_id
              , empleado_nombre
              , pro.vendor_id vendor_id_proveedor
              , pla.id_vendor vendor_id_planta
              , id_ubicacion
              , pla.id_planta
              , veh.tipo tipo_vehiculo
              , id_almacen
              , id_usuario
              , kms
/* FROM stg_android.xx_andr_expendio_in EXP, r11i
 stg_android.xx_andr_lectura_qr_in lect, --lee el camion
 stg_android.xx_andr_planta_out pla,
 stg_android.xx_andr_vehiculo_in veh,
 ra_customers c */
         FROM   xx_andr_expendio_in EXP                                                                           -- r12
              , xx_andr_lectura_qr_in lect
              , xx_opm_qr_proveedores_v pro
              , xx_andr_planta_out pla
              , xx_andr_vehiculo_in veh
              , (SELECT hca.cust_account_id customer_id
                      , hp.party_name customer_name
                      , hca.account_number customer_number
                   FROM hz_parties hp
                      , hz_cust_accounts hca
                  WHERE hca.party_id = hp.party_id) c
          WHERE 1 = 1
            AND EXP.id_lectura_qr = lect.id_lectura_qr
            AND lect.id_qr = pro.qr_id
            AND lect.id_planta = pla.id_planta
            AND pro.vehiculo_id = veh.id_vehiculo
            AND lect.id_lectura_qr = veh.id_lectura_qr
            AND c.customer_number(+) = pro.customer_num
            AND lect.id_lectura_qr NOT IN (SELECT id_lectura_qr
-- FROM bolinf.xx_exp_combustibles_stg); r11i
                                           FROM   xx_exp_combustibles_stg);                                       -- r12

      v_destino                                         VARCHAR2 (50);
   BEGIN
      fnd_file.put_line (fnd_file.output, '--- Proceso de Carga de lecturas de expendio de combustibles ---');
      fnd_file.put_line (fnd_file.output, '--- -------------------------------------------------------- ---');
      fnd_file.put_line (fnd_file.output, ' ');

      FOR c_lect IN c_lecturas_qr
      LOOP
         --Si la clasificaciÃ?Â³n del QR leÃ?Â­do es Flota Propia y el despacho de combustible se genera desde la compaÃ?Â±Ã?Â­a titular del vehÃ?Â­culo
         --se ingresarÃ?Â¡ un cosumo, caso contrario despacho.
         --(Si Vendor_id de QR = Vendor_id de la planta de despacho de combustible corresponde consumo, sino despacho)
         IF c_lect.vendor_id_proveedor = c_lect.vendor_id_planta
         THEN
            v_destino                                      := 'Consumo';
         ELSE
            v_destino                                      := 'Despacho';
         END IF;

         fnd_file.put_line (fnd_file.output
                          ,    'Procesando la lectura: '
                            || c_lect.id_lectura_qr
                            || ' del QR: '
                            || c_lect.id_qr
                            || ' con Destino: '
                            || v_destino);
         fnd_file.put_line (fnd_file.LOG
                          ,    'Se cargÃ?Â³ exitosamente la lectura: '
                            || c_lect.id_lectura_qr
                            || ' del QR: '
                            || c_lect.id_qr);

         --Org_id de la planta
         BEGIN
            /* r11i
            SELECT DISTINCT ou.organization_id
            INTO l_org_id
            FROM sy_orgn_mst som
            , ic_whse_mst iwm
            , hr_organization_information oi
            , hr_operating_units ou
            WHERE 1 = 1
            AND iwm.orgn_code = som.orgn_code
            AND oi.organization_id = iwm.mtl_organization_id
            AND ou.organization_id = TO_NUMBER (oi.org_information3)
            AND oi.org_information_context = 'Accounting Information'
            AND som.co_code != som.orgn_code
            AND som.organization_id = c_lect.id_planta; */

            -- SELECT DISTINCT ou.organization_id
-- INTO l_org_id
-- FROM SY_ORGN_MST som
-- , MTL_PARAMETERS mp
-- , MTL_SECONDARY_INVENTORIES msi
-- , HR_ORGANIZATION_INFORMATION oi
-- , HR_OPERATING_UNITS ou
-- WHERE som.organization_id = c_lect.id_planta
-- AND som.co_code != som.orgn_code
-- AND som.orgn_code = mp.process_orgn_code
-- AND mp.organization_code = msi.secondary_inventory_name
-- AND msi.organization_id = oi.organization_id
-- AND oi.org_information_context = 'Accounting Information'
-- AND TO_NUMBER (oi.org_information3) = ou.organization_id;
            SELECT hou.organization_id operating_unit_id
              INTO l_org_id
              FROM hr_operating_units hou
                 , org_organization_definitions ood
             WHERE 1 = 1
               AND hou.organization_id = ood.operating_unit
               AND ood.organization_id = c_lect.id_planta;
         EXCEPTION
            WHEN OTHERS
            THEN
               l_org_id                                       := NULL;
         END;

         fnd_file.put_line (fnd_file.LOG, 'l_org_id: '
                             || l_org_id);

         --Default Value para Item
         BEGIN
            SELECT DISTINCT inventory_item_id
                       INTO l_item_id
                       FROM fnd_profile_option_values pov
                          , fnd_responsibility_tl resp
                          , fnd_application appl
                          , fnd_user u
                          , fnd_profile_options pro
                          ,
                            --ic_item_mst_b i r11i
                            mtl_system_items_b i                                                                  -- r12
                      WHERE 1 = 1
                        AND pro.profile_option_name = 'XX_EXP_ITEM_EXPENDIO'
                        AND pro.profile_option_id = pov.profile_option_id
                        AND resp.responsibility_id = fnd_global.resp_id
                        AND pov.level_value = resp.responsibility_id(+)
                        AND pov.level_value = appl.application_id(+)
                        AND pov.level_value = u.user_id(+)
                        AND resp.LANGUAGE = 'ESA'
                        --AND profile_option_value = i.item_id;
                        AND profile_option_value = i.inventory_item_id;
         EXCEPTION
            WHEN OTHERS
            THEN
               l_item_id                                      := NULL;
         END;

         /* IF v_destino = 'Despacho' THEN r12
         BEGIN
         SELECT DISTINCT inventory_item_id
         INTO l_item_id
         FROM mtl_system_items_b
         WHERE segment1 = (SELECT a.item_no item
         FROM ic_item_mst_b a
         WHERE item_id = l_item_id);
         EXCEPTION
         WHEN OTHERS
         THEN
         l_item_id := NULL;
         END;
         END IF; */
         fnd_file.put_line (fnd_file.LOG, 'l_item_id: '
                             || l_item_id);

         --Default Value para Campana
         BEGIN
            SELECT profile_option_value
              INTO l_campana
              FROM fnd_profile_option_values pov
                 , fnd_responsibility_tl resp
                 , fnd_application appl
                 , fnd_user u
                 , fnd_profile_options pro
             WHERE 1 = 1
               AND pro.profile_option_name = 'XX_EXP_CAMPANIA_VIGENTE'
               AND pro.profile_option_id = pov.profile_option_id
               AND resp.responsibility_id = fnd_global.resp_id
               AND pov.level_value = resp.responsibility_id(+)
               AND pov.level_value = appl.application_id(+)
               AND pov.level_value = u.user_id(+)
               AND resp.LANGUAGE = 'ESA';
         EXCEPTION
            WHEN OTHERS
            THEN
               l_campana                                      := NULL;
         END;

         fnd_file.put_line (fnd_file.LOG, 'l_campana: '
                             || l_campana);

         --obtengo UDM
         --IF v_destino = 'Despacho' THEN r12
         BEGIN
            SELECT DISTINCT primary_uom_code
                       INTO l_udm
                       FROM mtl_system_items
                      WHERE inventory_item_id = l_item_id;
         EXCEPTION
            WHEN OTHERS
            THEN
               l_udm                                          := NULL;
         END;

         /*ELSE r12
         BEGIN
         SELECT item_um
         INTO l_udm
         FROM ic_item_mst_b
         WHERE item_id = l_item_id;
         EXCEPTION
         WHEN OTHERS
         THEN
         l_udm := NULL;
         END;

         END IF; */
         fnd_file.put_line (fnd_file.LOG, 'l_udm: '
                             || l_udm);

         --Default Domicilio Facturacion
         BEGIN
            SELECT site.site_use_id organization_id
              INTO l_om_invoice_to_org_id
              FROM hz_cust_acct_sites_all acct_site
                 , hz_party_sites party_site
                 , hz_locations loc
                 , hz_cust_site_uses_all site
                 , hz_parties party
                 , hz_cust_accounts_all cust_acct
             WHERE site.site_use_code = 'BILL_TO'
               AND site.cust_acct_site_id = acct_site.cust_acct_site_id
               AND acct_site.party_site_id = party_site.party_site_id
               AND party_site.location_id = loc.location_id
               AND acct_site.status = 'A'
               AND acct_site.cust_account_id = cust_acct.cust_account_id
               AND cust_acct.party_id = party.party_id
               AND cust_acct.status = 'A'
               AND site.status = 'A'
               AND cust_acct.cust_account_id = c_lect.customer_id
               AND site.org_id = l_org_id                                                            --fnd_global.org_id
               AND ROWNUM < 2;
         EXCEPTION
            WHEN OTHERS
            THEN
               l_om_invoice_to_org_id                         := NULL;
         END;

         fnd_file.put_line (fnd_file.LOG, 'l_om_invoice_to_org_id: '
                             || l_om_invoice_to_org_id);

         --Default Domicilio Envio
         BEGIN
            SELECT site.site_use_id organization_id
              INTO l_om_ship_to_org_id
              FROM hz_cust_acct_sites_all acct_site
                 , hz_party_sites party_site
                 , hz_locations loc
                 , hz_cust_site_uses_all site
                 , hz_parties party
                 , hz_cust_accounts_all cust_acct
             WHERE site.site_use_code = 'SHIP_TO'
               AND site.cust_acct_site_id = acct_site.cust_acct_site_id
               AND acct_site.party_site_id = party_site.party_site_id
               AND party_site.location_id = loc.location_id
               AND acct_site.status = 'A'
               AND acct_site.cust_account_id = cust_acct.cust_account_id
               AND cust_acct.party_id = party.party_id
               AND cust_acct.status = 'A'
               AND site.status = 'A'
               AND cust_acct.cust_account_id = c_lect.customer_id
               AND site.org_id = l_org_id                                                            --fnd_global.org_id
               AND ROWNUM < 2;
         EXCEPTION
            WHEN OTHERS
            THEN
               l_om_ship_to_org_id                            := NULL;
         END;

         fnd_file.put_line (fnd_file.LOG, 'l_om_ship_to_org_id: '
                             || l_om_ship_to_org_id);

         --Default Transaction Type id
         IF v_destino = 'Despacho'
         THEN
            BEGIN
               SELECT transaction_type_id
                 INTO l_transaction_type_id
                 FROM oe_transaction_types_all
                WHERE warehouse_id = c_lect.id_almacen
                  AND transaction_type_code = 'ORDER';
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_transaction_type_id                          := NULL;
            END;
         ELSE
            BEGIN
               SELECT tt.transaction_type_id
                 INTO l_transaction_type_id
                 FROM fnd_profile_option_values pov
                    , fnd_responsibility_tl resp
                    , fnd_application appl
                    , fnd_user u
                    , fnd_profile_options pro
                    , oe_transaction_types_tl tl
                    , oe_transaction_types_all tt
                WHERE 1 = 1
                  AND pro.profile_option_name = 'XX_EXP_TIPO_NEGOCIO: XX EXP TIPO NEGOCIO'
                  AND pro.profile_option_id = pov.profile_option_id
                  AND resp.responsibility_id = fnd_global.resp_id
                  AND pov.level_value = resp.responsibility_id(+)
                  AND pov.level_value = appl.application_id(+)
                  AND pov.level_value = u.user_id(+)
                  AND resp.LANGUAGE = 'ESA'
                  AND resp.LANGUAGE = tl.LANGUAGE
                  AND profile_option_value = tt.attribute7
                  AND tt.transaction_type_id = tl.transaction_type_id
                  AND NAME LIKE 'Vta/Dev%'
                  AND tt.org_id = l_org_id
                  AND ROWNUM < 2;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_transaction_type_id                          := NULL;
            END;
         END IF;

         fnd_file.put_line (fnd_file.LOG, 'l_transaction_type_id: '
                             || l_transaction_type_id);

         --valida nro de remito

         --Default Dep?sito
         BEGIN
            /* SELECT whse_code r11i
            INTO l_whse_code
            FROM ic_whse_mst
            WHERE mtl_organization_id = c_lect.id_almacen; */
            SELECT secondary_inventory_name                                                                        --r12
              INTO l_whse_code
              FROM mtl_secondary_inventories msi
                 , mtl_secondary_inventories_dfv msid
             WHERE msi.ROWID = msid.row_id
               AND msid.secondary_inventory_id = c_lect.id_almacen;
         EXCEPTION
            WHEN OTHERS
            THEN
               l_whse_code                                    := NULL;
         END;

         fnd_file.put_line (fnd_file.LOG, 'l_whse_code: '
                             || l_whse_code);

         BEGIN
            /* SELECT 'Y' r11i
            INTO v_dummy
            FROM MTL_CATEGORIES_ITEMCAT_KFV mci_kfv
            , gmi_item_categories gic
            , ic_item_mst iim
            WHERE mci_kfv.XX_RUBRO IN ( '04', '40', '35', '36' ) -- Codigo de rubro en produccion
            AND gic.category_id = mci_kfv.category_id
            AND iim.item_id = gic.item_id
            AND iim.item_id = l_item_id
            AND ROWNUM=1; */
            SELECT 'Y'
              INTO v_dummy
              FROM mtl_categories_itemcat_kfv mci_kfv
                 , mtl_item_categories mic
                 , mtl_system_items_b msi
             WHERE mci_kfv.xx_rubro IN ('04', '40', '35', '36')                         -- Codigo de rubro en produccion
               AND mci_kfv.category_id = mic.category_id
               AND mic.organization_id = c_lect.id_almacen
               AND mic.inventory_item_id = msi.inventory_item_id
               AND mic.organization_id = msi.organization_id
               AND msi.inventory_item_id = l_item_id;

            v_source_code                                  := 'REGA';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_source_code                                  := 'RGRL';
            WHEN OTHERS
            THEN
               --message('Fallo al obtener Source code');
               l_nro_remito_aprobado                          := NULL;
         END;

         /* Se comenta en r12 hasta que se defina el procedimiento de confirmar nÃ?Âºmero con la nueva lÃ?Â³gica de organizaciones
         IF NOT xx_opm_admin_talonario_pk.confirma_numero (p_numero => c_lect.nro_remito,
         p_source_code => v_source_code,
         p_orgn_code => NULL,
         p_whse_code => l_whse_code,
         p_source_table => 'WSH_NEW_DELIVERIES',
         p_source_id => NULL,
         p_error => v_msgerr,
         p_inserta => 0
         )
         THEN
         l_nro_remito_aprobado := NULL;
         ELSE
         l_nro_remito_aprobado := c_lect.nro_remito;
         END IF;
         */
         l_nro_remito_aprobado                          := c_lect.nro_remito;                                     -- r12
         fnd_file.put_line (fnd_file.LOG, 'l_nro_remito_aprobado: '
                             || l_nro_remito_aprobado);

         BEGIN
            --INSERT INTO bolinf.xx_exp_combustibles_stg r11i
            INSERT INTO xx_exp_combustibles_stg                                                                  -- r12
                        (id_qr
                       , id_lectura_qr
                       , id_usuario
                       , id_ubicacion
                       , item_id
                       , fecha_trx
                       , cantidad_expendida
                       , cantidad_aprobada
                       , nro_salida
                       , nro_remito
                       , clasificacion
                       , patente_veh_maq
                       , vendor_id_proveedor
                       , vendor_id_planta
                       , id_planta
                       , id_almacen
                       , customer_id
                       , tipo_vehiculo
                       , created_by
                       , creation_date
                       , last_updated_by
                       , last_update_date
                       , destino
                       , om_status
                       , opm_status
                       , udm_expendida
                       , udm_aprobada
                       , om_invoice_to_org_id
                       , om_ship_to_org_id
                       , transaction_type_id
                       , campana
                       , nro_remito_aprobado
                       , km_vehiculo
                        )
                 VALUES (c_lect.id_qr
                       , c_lect.id_lectura_qr
                       , c_lect.id_usuario
                       , c_lect.id_ubicacion
                       , l_item_id
                       , c_lect.fecha_generacion
                       , c_lect.cantidad_expendida
                       , c_lect.cantidad_expendida
                       , c_lect.nro_salida
                       , c_lect.nro_remito
                       , c_lect.clasificacion
                       , c_lect.patente_veh_maq
                       , c_lect.vendor_id_proveedor
                       , c_lect.vendor_id_planta
                       , c_lect.id_planta
                       , c_lect.id_almacen
                       , c_lect.customer_id
                       , c_lect.tipo_vehiculo
                       , fnd_global.user_id
                       , SYSDATE
                       , fnd_global.user_id
                       , SYSDATE
                       , v_destino
                       , 'PENDIENTE'
                       , 'PENDIENTE'
                       , l_udm
                       , l_udm
                       , l_om_invoice_to_org_id
                       , l_om_ship_to_org_id
                       , l_transaction_type_id
                       , l_campana
                       , l_nro_remito_aprobado
                       , c_lect.kms
                        );

            fnd_file.put_line (fnd_file.output
                             ,    'Se cargÃ?Â³ exitosamente la lectura: '
                               || c_lect.id_lectura_qr
                               || ' del QR: '
                               || c_lect.id_qr);
            COMMIT;
         EXCEPTION
            WHEN OTHERS
            THEN
               fnd_file.put_line (fnd_file.output
                                ,    'FallÃ?Â³ la carga de la lectura: '
                                  || c_lect.id_lectura_qr
                                  || ' del QR: '
                                  || c_lect.id_qr);
         END;
      END LOOP;
   END loader;

   PROCEDURE confirmacion (
      p_errbuf                   OUT      VARCHAR2
    , p_retcode                  OUT      NUMBER
   )                                                                            -- Modificado CR2381 - asilva - nov-2016
   IS
      --out parameters
      x_return_status                                   VARCHAR2 (10);
      x_errmsg                                          VARCHAR2 (2000);
      l_sold_from_org_id                                NUMBER;
      eendconf                                          EXCEPTION;

      CURSOR c_deliveries
      IS
         SELECT DISTINCT da.delivery_id
                       , h.order_number pedido
                       , id_planta
                       , nro_remito_aprobado                                                           --Agregado CR3033
                       , organization_id -- amanukyan 20180718 esta haciendo join con id planta en un monton de lugares que ahora no corresponde
                    FROM oe_order_headers h
                       , oe_order_lines l
                       , wsh_delivery_details dd
                       , wsh_delivery_assignments da
                       ,
-- bolinf.xx_exp_combustibles_stg r11i
                         xx_exp_combustibles_stg                                                                  -- r12
                   WHERE 1 = 1
                     AND h.header_id = l.header_id
                     AND order_number = pedido
                     AND om_status = 'EN PROCESO'
                     AND pedido IS NOT NULL
                     AND l.line_id = dd.source_line_id
                     AND dd.delivery_detail_id = da.delivery_detail_id
                     AND da.delivery_id IS NOT NULL;

      CURSOR c_req
      IS
         SELECT MAX (request_id)
           FROM fnd_conc_req_summary_v
          WHERE requested_by = fnd_global.user_id
            AND program_short_name = 'WSHPSGL'
            AND phase_code <> 'C'
            AND status_code <> 'C';
      l_req_id                                          NUMBER;
      l_req_return_status                               BOOLEAN;
      l_req_phase                                       VARCHAR2 (100);
      l_req_status                                      VARCHAR2 (100);
      l_req_dev_phase                                   VARCHAR2 (100);
      l_req_dev_status                                  VARCHAR2 (100);
      l_req_message                                     VARCHAR2 (500);
      eendpocess                                        EXCEPTION;
      l_loop                                            NUMBER := 0;
   BEGIN
       dbms_lock.sleep(90); -- no llega a ejecutarse el Pick Selection List Generation antes de que se ejecute esto
       --Agregado CR2381
      OPEN c_req;

      FETCH c_req
       INTO l_req_id;

      CLOSE c_req;

      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                           , p_message                     =>    'Inicio en Confirmacion - l_req_id: '
                                                              || l_req_id
                                                              || ' '
                                                              || TO_CHAR (SYSDATE, 'DD/MM/RRRR HH24:MI:SS'));

      IF (l_req_id IS NOT NULL)
      THEN
         l_req_return_status                            := fnd_concurrent.wait_for_request (l_req_id
                                                                                          , 3
                                                                                          , 3600
                                                                                          , l_req_phase
                                                                                          , l_req_status
                                                                                          , l_req_dev_phase
                                                                                          , l_req_dev_status
                                                                                          , l_req_message
                                                                                           );
         xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                              , p_message                     =>    'l_loop: '
                                                                 || l_loop
                                                                 || ' - l_req_phase: '
                                                                 || l_req_phase
                                                                 || ' - l_req_status: '
                                                                 || l_req_status
                                                                 || ' - l_req_dev_phase: '
                                                                 || l_req_dev_phase
                                                                 || ' - l_req_dev_status: '
                                                                 || l_req_dev_status
                                                                 || ' - l_req_message: '
                                                                 || l_req_message);

         IF     UPPER (l_req_phase) IN ('COMPLETED', 'FINALIZADO')
            AND UPPER (l_req_status) = 'NORMAL'
         THEN
            NULL;
         --Permitir que llame al mÃ?Â©todo de ConfirmaciÃ?Â³n
         ELSE
            RAISE eendpocess;
         END IF;
      END IF;

      FOR c_del IN c_deliveries
      LOOP
         BEGIN
            /* r11i
            SELECT DISTINCT ou.organization_id
            INTO l_sold_from_org_id
            FROM sy_orgn_mst som
            , ic_whse_mst iwm
            , hr_organization_information oi
            , hr_operating_units ou
            WHERE 1=1
            AND iwm.orgn_code = som.orgn_code
            AND oi.organization_id = iwm.mtl_organization_id
            AND ou.organization_id = TO_NUMBER(oi.org_information3)
            AND oi.org_information_context = 'Accounting Information'
            AND som.co_code != som.orgn_code
            and som.organization_id = c_del.id_planta; */
            SELECT DISTINCT ou.organization_id
                       INTO l_sold_from_org_id
                       FROM sy_orgn_mst som
                          , mtl_parameters mp
                          , mtl_secondary_inventories msi
                          , hr_organization_information oi
                          , hr_operating_units ou
                   --   WHERE som.organization_id = c_del.id_planta  -- amanukyan 20180718 esta haciendo join con id planta en un monton de lugares que ahora no corresponde
                   where som.organization_id = c_del.organization_id -- amanukyan 20180718 esta haciendo join con id planta en un monton de lugares que ahora no corresponde
                        AND som.co_code != som.orgn_code
                        AND som.orgn_code = mp.process_orgn_code
                        AND mp.organization_code = msi.secondary_inventory_name
                        AND msi.organization_id = oi.organization_id
                        AND oi.org_information_context = 'Accounting Information'
                        AND TO_NUMBER (oi.org_information3) = ou.organization_id;

            --DBMS_APPLICATION_INFO.set_client_info (l_sold_from_org_id);
            fnd_file.put_line (fnd_file.LOG, 'l_sold_from_org_id: '
                                || l_sold_from_org_id);
         EXCEPTION
            WHEN OTHERS
            THEN
               l_sold_from_org_id                             := NULL;
         END;

         IF xx_exp_combustible_pk.genera_ship_confirm (c_del.delivery_id
                                                     , l_sold_from_org_id
                                                     , x_return_status
                                                     , x_errmsg
                                                      )
         THEN
            fnd_file.put_line (fnd_file.output, 'Se Confirmo exitosamente la entrega: '
                                || c_del.delivery_id);

            BEGIN
               --UPDATE BOLINF.XX_EXP_COMBUSTIBLES_STG r11i
               UPDATE xx_exp_combustibles_stg                                                                    -- r12
                  SET om_status = 'PROCESADO'
                    , last_update_date = SYSDATE
                    , last_updated_by = fnd_global.user_id
                WHERE 1 = 1
                  AND pedido = c_del.pedido
                  AND om_status = 'EN PROCESO';
            EXCEPTION
               WHEN OTHERS
               THEN
                  x_errmsg                                       :=
                        'No se pudo actualizar la tabla de combustibles para la entrega: '
                     || c_del.delivery_id
                     || ' - '
                     || SQLERRM;
                  RAISE eendconf;
            END;

            --Agregado CR3033
            BEGIN
               --UPDATE bolinf.XX_INV_REMITOS_IMPRESOS r11i
               UPDATE xx_inv_remitos_impresos                                                                    -- r12
                  SET GROUP_ID = c_del.delivery_id
                    , last_update_date = SYSDATE
                    , last_updated_by = fnd_global.user_id
                WHERE 1 = 1
                  AND source_table = 'WSH_NEW_DELIVERIES'
                  AND waybill_airbill = c_del.nro_remito_aprobado;
            EXCEPTION
               WHEN OTHERS
               THEN
                  x_errmsg                                       :=
                        'No se pudo actualizar la tabla de remitos impresos. Nro de remito: '
                     || c_del.nro_remito_aprobado
                     || ' - '
                     || SQLERRM;
                  RAISE eendconf;
            END;
         --fin CR3033
         ELSE
            fnd_file.put_line (fnd_file.output, 'Fallo en la Confirmacion de la entrega: '
                                || c_del.delivery_id);
            fnd_file.put_line (fnd_file.output, 'Error: '
                                || x_errmsg);
            p_retcode                                      := 1;

            BEGIN
               ---UPDATE bolinf.XX_EXP_COMBUSTIBLES_STG r11i
               UPDATE xx_exp_combustibles_stg                                                                    -- r12
                  SET om_status = 'ERROR'
                    , om_status_det =    'Fallo en la Confirmacion de la entrega: '
                                      || c_del.delivery_id
                    , last_update_date = SYSDATE
                    , last_updated_by = fnd_global.user_id
                WHERE 1 = 1
                  AND pedido = c_del.pedido
                  AND om_status = 'EN PROCESO';
            EXCEPTION
               WHEN OTHERS
               THEN
                  x_errmsg                                       :=
                        'No se pudo actualizar con error la tabla de combustibles para la entrega: '
                     || c_del.delivery_id
                     || ' - '
                     || SQLERRM;
                  RAISE eendconf;
            END;
         END IF;
      END LOOP;
   EXCEPTION
      WHEN eendconf
      THEN
         p_errbuf                                       := x_errmsg;
         fnd_file.put_line (fnd_file.LOG, p_errbuf);
         p_retcode                                      := 2;
      WHEN OTHERS
      THEN
         p_errbuf                                       :=    'Error en el procedimiento de Ship Confirm: '
                                                           || SQLERRM;
         fnd_file.put_line (fnd_file.LOG, p_errbuf);
         p_retcode                                      := 2;
   END confirmacion;

   PROCEDURE lanza_conf
   --(
   --   p_req_id                   OUT      NUMBER
   --)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;                       --amanukyan 20180223 el user no puede esperar en la pantalla
      l_req_id                                          NUMBER;
      l_req_return_status                               BOOLEAN;
      l_req_phase                                       VARCHAR2 (100);
      l_req_status                                      VARCHAR2 (100);
      l_req_dev_phase                                   VARCHAR2 (100);
      l_req_dev_status                                  VARCHAR2 (100);
      l_req_message                                     VARCHAR2 (500);
      eendpocess                                        EXCEPTION;
      l_loop                                            NUMBER := 0;

      CURSOR c_req
      IS
         SELECT MAX (request_id)
           FROM fnd_conc_req_summary_v
          WHERE requested_by = fnd_global.user_id
            AND program_short_name = 'WSHPSGL'
            AND phase_code <> 'C'
            AND status_code <> 'C';
   BEGIN
--     -- dbms_lock.sleep(180); -- no llega a ejecutarse el Pick Selection List Generation antes de que se ejecute esto
--      --Agregado CR2381
--      OPEN c_req;

      --      FETCH c_req
--       INTO l_req_id;

      --      CLOSE c_req;

      --      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
--                           , p_message                     =>    'Inicio en Confirmacion - l_req_id: '
--                                                              || l_req_id
--                                                              || ' '
--                                                              || TO_CHAR (SYSDATE, 'DD/MM/RRRR HH24:MI:SS'));

      --      IF (l_req_id IS NOT NULL)
--      THEN
--            l_req_return_status                            :=
--               fnd_concurrent.wait_for_request (l_req_id
--                                              , 3
--                                              , 3600
--                                              , l_req_phase
--                                              , l_req_status
--                                              , l_req_dev_phase
--                                              , l_req_dev_status
--                                              , l_req_message
--                                               );
--
--         xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
--                              , p_message                     =>    'l_loop: '
--                                                                 || l_loop
--                                                                 || ' - l_req_phase: '
--                                                                 || l_req_phase
--                                                                 || ' - l_req_status: '
--                                                                 || l_req_status
--                                                                 || ' - l_req_dev_phase: '
--                                                                 || l_req_dev_phase
--                                                                 || ' - l_req_dev_status: '
--                                                                 || l_req_dev_status
--                                                                 || ' - l_req_message: '
--                                                                 || l_req_message);

      --         IF     UPPER (l_req_phase) IN ('COMPLETED', 'FINALIZADO')
--            AND UPPER (l_req_status) = 'NORMAL'
--         THEN
--            NULL;
--         --Permitir que llame al mÃ?Â©todo de ConfirmaciÃ?Â³n
--         ELSE
--            RAISE eendpocess;
--         END IF;
--      END IF;

      --Llamar al procedimiento de confirmacion
      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                           , p_message                     =>    'Llamada al XXEXCOCONF '
                                                              || TO_CHAR (SYSDATE, 'DD/MM/RRRR HH24:MI:SS'));
      --l_req_id := apps.FND_REQUEST.submit_request( r11i
      l_req_id                                       := fnd_request.submit_request (                              -- r12
                                                                                    'XBOL'
                                                                                  , 'XXEXCOCONF'
                                                                                  , NULL
                                                                                  , NULL
                                                                                  , FALSE
                                                                                   );
      COMMIT;
      xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                           , p_message                     =>    'Fin de llamada al XXEXCOCONF '
                                                              || l_req_id
                                                              || ' '
                                                              || TO_CHAR (SYSDATE, 'DD/MM/RRRR HH24:MI:SS'));
   --p_req_id                                       := l_req_id;
   EXCEPTION
      WHEN eendpocess
      THEN
         xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                              , p_message                     =>    'Lanza_Conf, Error en Concurrente Wait for Request: '
                                                                 || SQLERRM);
      --p_req_id                                       := 0;
      WHEN OTHERS
      THEN
         xx_debug_aux_pk.DEBUG (p_module                      => 'EXPCO'
                              , p_message                     =>    'Lanza_Conf, Error: '
                                                                 || SQLERRM);
   --p_req_id                                       := 0;
   END lanza_conf;

   PROCEDURE xx_exp_cuentas (
      p_reason_code              IN       VARCHAR2
    , p_item_id                  IN       NUMBER
    , p_item_no                  IN       NUMBER
    , p_lot_id                   IN       NUMBER
    , p_lot_no                   IN       VARCHAR2
    , p_attribute1               IN       VARCHAR2
    , p_whse_code                IN       VARCHAR2
    , p_orgn_code                IN       VARCHAR2
    , p_co_code                  IN       VARCHAR2
    , p_acct_no                  OUT      VARCHAR2
    , p_acctg_unit_no            OUT      VARCHAR2
    , p_errmsg                   OUT      VARCHAR2
   )
   IS
      v_mesg_error                                      VARCHAR2 (1000);
      v_reason_code                                     VARCHAR2 (10);
      v_item_type                                       VARCHAR2 (20);
      v_item_id                                         NUMBER;
      v_whse_code                                       VARCHAR2 (10);
      v_orgn_code                                       VARCHAR2 (10);
      v_categ_art                                       VARCHAR2 (150);
      v_gl_class                                        VARCHAR2 (8);
      v_lot_id                                          NUMBER;
      v_country_code                                    VARCHAR2 (10) := fnd_profile.VALUE ('JGZZ_COUNTRY_CODE');
      v_segm_camp                                       VARCHAR2 (240);
      v_co_code                                         VARCHAR2 (10);
      v_acctg_unit_desc                                 VARCHAR2 (240);
      v_acctg_unit_id                                   NUMBER;
      v_acctg_unit_no                                   VARCHAR2 (240);
      v_sub_event_type                                  NUMBER;
      v_acct_ttl_type                                   NUMBER;
      v_acct_id                                         NUMBER;
      v_acct_no                                         VARCHAR2 (240);
      v_result                                          BOOLEAN;
      v_errmsg                                          VARCHAR2 (2000);
      v_org_id                                          NUMBER;
      v_structure_number                                NUMBER;
      v_delimiter                                       VARCHAR2 (1);
      v_segment_count                                   NUMBER;
      v_segment_array                                   fnd_flex_ext.segmentarray;
      v_segment_no                                      NUMBER;
      v_acct_desc                                       VARCHAR2 (70);
      v_excep_msg                                       VARCHAR2 (2000);
      l_clean_acct                                      BOOLEAN;
      l_custom_enabled                                  VARCHAR2 (10);
      e_sbv_error                                       EXCEPTION;
      e_acct_ttl_error                                  EXCEPTION;
      e_get_acct_mapping                                EXCEPTION;
      e_acctg_unit_error                                EXCEPTION;
      e_acct_no_error                                   EXCEPTION;
      e_uoper_error                                     EXCEPTION;
      e_segment_error                                   EXCEPTION;
      e_str_number                                      EXCEPTION;
      e_segment_no_error                                EXCEPTION;
      e_replace_segm_error                              EXCEPTION;
      e_acct_error                                      EXCEPTION;
      e_no_acct                                         EXCEPTION;

      FUNCTION reason_code_gas_oil (
         p_reason_code                       VARCHAR2
      )
         RETURN BOOLEAN
      IS
         l_reason_code                                     VARCHAR2 (200);
      BEGIN
         SELECT reason_code
           INTO l_reason_code
           FROM sy_reas_cds_vl
          WHERE reason_code NOT IN ('CGAC', 'CGAM', 'CGCL', 'CGFE', 'CGRI', 'CGSG')
            AND UPPER (reason_desc1) LIKE '%GAS%OIL%'
            AND reason_code = p_reason_code
            --CR1217
            AND EXISTS (SELECT 'Y'
                          FROM fnd_descr_flex_contexts_vl
                         WHERE 1 = 1
                           AND descriptive_flexfield_name = 'GMI_JOURNAL_MASTER_FLEX'
                           AND enabled_flag = 'Y'
                           AND descriptive_flex_context_code = p_reason_code)
            AND EXISTS (SELECT 'Y'
                          FROM fnd_descr_flex_col_usage_vl
                         WHERE 1 = 1
                           AND descriptive_flexfield_name = 'GMI_JOURNAL_MASTER_FLEX'
                           AND enabled_flag = 'Y'
                           AND form_above_prompt = 'XX_OPM_CAMPAÃ?â??A'
                           AND descriptive_flex_context_code = p_reason_code);

         RETURN TRUE;
      --
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            RETURN FALSE;
         WHEN OTHERS
         THEN
            RETURN FALSE;
      END reason_code_gas_oil;
--Comienzo
   BEGIN
--- ------------------------------------
--- Obtengo categoria de art y gl class
--- ------------------------------------
      BEGIN
         /* SELECT mc_dfv.xx_incluir_reporte_iibb, iimb.gl_class r11i
         INTO v_categ_art, v_gl_class
         FROM ic_item_mst_b iimb,
         gmi_item_categories gic,
         mtl_category_sets_v mcs,
         mtl_categories_b mc,
         mtl_categories_b_dfv mc_dfv
         WHERE iimb.item_id = gic.item_id
         AND gic.category_set_id = mcs.category_set_id
         AND gic.category_id = mc.category_id
         AND mc.ROWID = mc_dfv.row_id
         AND iimb.item_id = p_item_id
         AND mcs.category_set_name = 'Inventory';*/
         SELECT DISTINCT mc_dfv.xx_incluir_reporte_iibb
                       , mcb.segment1 gl_class
                    INTO v_categ_art
                       , v_gl_class
                    FROM mtl_system_items_b msi
                       , mtl_item_categories mic
                       , mtl_categories_b mcb
                       , mtl_category_sets_v mcs
                       , mtl_categories_b_dfv mc_dfv
                   WHERE msi.inventory_item_id = p_item_id
                     AND msi.inventory_item_id = mic.inventory_item_id
                     AND msi.organization_id = mic.organization_id
                     AND mic.category_id = mcb.category_id
                     AND mic.category_set_id = mcs.category_set_id
                     AND mcb.ROWID = mc_dfv.row_id
                     AND mcs.category_set_name = 'Inventory';
      --
      EXCEPTION
         WHEN OTHERS
         THEN
            p_errmsg                                       :=
                                                                'Error al buscar la categorÃ?Â­a del artÃ?Â­culo: '
                                                             || SQLERRM;
      END;

-- ------------------------------------------------
-- CR902 Validaciones particulares por reason code
----------------------------------------------------
      IF p_reason_code = 'ABOL'
      THEN
         IF p_lot_no IS NULL
         THEN
-- -------------------------------------
-- CategorÃ?Â­a del artÃ?Â­culo
-- -------------------------------------
            v_item_type                                    := SUBSTR (p_item_no
                                                                    , 1
                                                                    , 2
                                                                     );

            IF v_item_type <> '02'
            THEN
               NULL;                                                                                 --raise e_no_acct;
            END IF;

-- ----------------------------------------------------
-- 'Segmento Contable CampaÃ?Â±a' a travez del lote
-- ----------------------------------------------------
            BEGIN
               v_lot_id                                       := p_lot_id;

               SELECT xx_aco_segm_campania
                 INTO v_segm_camp
                 FROM ic_lots_mst ilm
                    , ic_lots_mst_dfv ilm_dfv
                WHERE ilm.ROWID = ilm_dfv.row_id
                  AND ilm_dfv.context_value = v_country_code
                  AND ilm.lot_id = v_lot_id
                  AND ilm.item_id = v_item_id;
            --
            EXCEPTION
               WHEN OTHERS
               THEN
                  p_errmsg                                       :=
                                               (   'Error al buscar el Segmento Contable CampaÃ?Â±a del lote: '
                                                || SQLERRM
                                               );
            END;

            --

            -- ---------------------------------------------------------------------
-- Si el codigo de motivo es ABOL y la categoria del articulo es Cereal,
-- el lote debe tener asociado el segmento Contable CampaÃ?Â±a
-- ---------------------------------------------------------------------
            IF                                                                            --(v_reason_code = 'ABOL') AND
               (v_categ_art = 'CEREAL'
               )
            THEN
               IF v_segm_camp IS NULL
               THEN
                  p_errmsg                                       :=
                     (   'El lote '
                      || p_lot_no
                      || ' no tiene configurado '
                      || ' el segmento Contable CampaÃ?Â±a. '
                      || CHR (10)
                      || 'Por favor verificar antes de realizar el ajuste'
                     );
               END IF;
            --
            END IF;
         END IF;
      --
      END IF;

      IF reason_code_gas_oil (p_reason_code)
      THEN
         v_segm_camp                                    := p_attribute1;
      /*
      BEGIN
      SELECT fv.flex_value
      INTO v_segm_camp
      FROM fnd_flex_values_vl fv, fnd_flex_value_sets fvs
      WHERE 1 = 1
      AND fv.flex_value_set_id = fvs.flex_value_set_id
      AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
      AND fv.flex_value_id = v_segm_camp;

      INSERT INTO temp
      VALUES ( 'Consumo cuentas comienzo 3');
      commit;
      --
      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
      p_errmsg := 'Debe completar la campaÃ?Â±a.';
      INSERT INTO temp
      VALUES ( 'Consumo cuentas comienzo 4');
      commit;
      END;*/--
      ELSE
         p_errmsg                                       := 'No genera cuenta contable:';
         p_acct_no                                      := NULL;
         p_acctg_unit_no                                := NULL;
         --INSERT INTO temp VALUES ('No genera cuenta contable:');
         COMMIT;
         GOTO no_genera_cuenta;
      --EXIT; --RAISE e_no_acct;
      END IF;

      --

      --- ----------------------------------------
--- Comienzo proceso de rearmado de cuenta
--- ----------------------------------------
      BEGIN
----------------------------------------------------------------------------
-- Se busca la Unidad Contable Cargo ya que no fue definida por el usuario
----------------------------------------------------------------------------
         BEGIN
            SELECT mst.acctg_unit_no
                 , mst.acctg_unit_desc
                 , mst.acctg_unit_id
              INTO v_acctg_unit_no
                 , v_acctg_unit_desc
                 , v_acctg_unit_id
              FROM gl_accu_mst mst
                 , gl_accu_map MAP
                 , sy_orgn_mst som
                 , ic_whse_mst iwm
             WHERE MAP.co_code = som.co_code
               AND mst.acctg_unit_id = MAP.acctg_unit_id
               AND som.orgn_code = iwm.orgn_code
               AND iwm.whse_code = p_whse_code
               AND MAP.delete_mark = 0
               AND mst.delete_mark = 0;
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_acctg_unit_error;
         END;

------------------------------------------------------------------------------
-- Se busca si en el mapeo de cuentas ya existe la Cuenta Cargo
-- con titulo de cuenta IVA y el segmento7 igual al segmento contable
-- campaÃ?Â±a definido en el lote. Caso contrario se reemplazara dicho segmento
------------------------------------------------------------------------------
         BEGIN
            SELECT sub_event_type
              INTO v_sub_event_type
              FROM gl_sevt_mst
             WHERE sub_event_code = 'IADJ';
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_sbv_error;
         END;

         --
         BEGIN
            SELECT acct_ttl_type
              INTO v_acct_ttl_type
              FROM gl_acct_ttl
             WHERE acct_ttl_code = 'IVA';
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_acct_ttl_error;
         END;

         --
         v_co_code                                      := p_co_code;
         v_orgn_code                                    := p_orgn_code;
         v_whse_code                                    := p_whse_code;
         v_item_id                                      := p_item_id;
         v_reason_code                                  := p_reason_code;
---------------------------------------------
-- BÃ?Âºsqueda de cuenta en Mapeo de OPM
---------------------------------------------
         gmf_get_mappings.get_account_mappings (v_co_code                     => v_co_code
                                              , v_orgn_code                   => v_orgn_code
                                              , v_whse_code                   => v_whse_code
                                              , v_item_id                     => v_item_id
                                              , v_vendor_id                   => NULL
                                              , v_cust_id                     => NULL
                                              , v_reason_code                 => v_reason_code
                                              , v_icgl_class                  => v_gl_class
                                              , v_vendgl_class                => NULL
                                              , v_custgl_class                => NULL
                                              , v_currency_code               => NULL
                                              , v_routing_id                  => NULL
                                              , v_charge_id                   => NULL
                                              , v_taxauth_id                  => NULL
                                              , v_aqui_cost_id                => NULL
                                              , v_resources                   => NULL
                                              , v_cost_cmpntcls_id            => NULL
                                              , v_cost_analysis_code          => NULL
                                              , v_order_type                  => NULL
                                              , v_sub_event_type              => v_sub_event_type
                                              , v_acct_ttl_type               => v_acct_ttl_type
                                              , v_acct_id                     => v_acct_id
                                              , v_acctg_unit_id               => v_acctg_unit_id
                                               );

         IF (   v_acct_id < 0
             OR v_acctg_unit_id < 0)
         THEN
            v_excep_msg                                    := SQLERRM;
            RAISE e_get_acct_mapping;
         END IF;

         --

         ----------------------------
-- Unidad Contable Cargo
----------------------------
         BEGIN
            SELECT acctg_unit_no
              INTO v_acctg_unit_no
              FROM gl_accu_mst
             WHERE acctg_unit_id = v_acctg_unit_id;
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_acctg_unit_error;
         END;

         --

         ----------------------------
-- Cuenta Cargo
----------------------------
         BEGIN
            SELECT acct_no
              INTO v_acct_no
              FROM gl_acct_mst
             WHERE acct_id = v_acct_id;
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_acct_no_error;
         END;

         --

         ------------------------------
-- Unidad operativa
------------------------------
         xx_aco_util_pk.get_org_id (p_co_code                     => v_co_code
                                  , x_result                      => v_result
                                  , x_errmsg                      => v_errmsg
                                  , x_org_id                      => v_org_id
                                   );

         IF (NOT v_result)
         THEN
            v_excep_msg                                    := SQLERRM;
            RAISE e_uoper_error;
         END IF;

         --

         ------------------------------
-- Obtengo la estructura
------------------------------
         BEGIN
            SELECT gsob.chart_of_accounts_id
              INTO v_structure_number
              FROM gl_sets_of_books gsob
                 , financials_system_params_all fsp
             WHERE fsp.set_of_books_id = gsob.set_of_books_id
               AND fsp.org_id = v_org_id;
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_str_number;
         END;

         --

         -----------------------
-- Separador
-----------------------
         v_delimiter                                    :=
            fnd_flex_ext.get_delimiter (application_short_name        => 'SQLGL'
                                      , key_flex_code                 => 'GL#'
                                      , structure_number              => v_structure_number
                                       );

         BEGIN
            v_segment_count                                :=
               fnd_flex_ext.breakup_segments (concatenated_segs             => v_acct_no
                                            , delimiter                     => v_delimiter
                                            , segments                      => v_segment_array
                                             );
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_segment_error;
         END;

         --

         --------------------------------------------------------------
-- Se busca el numero de segmento que representa al proyecto
--------------------------------------------------------------
         BEGIN
            SELECT gps.segment_no
              INTO v_segment_no
              FROM fnd_segment_attribute_values fsav
                 , fnd_id_flex_segments_vl ffs
                 , gl_plcy_seg gps
             WHERE fsav.segment_attribute_type = 'XX_PROJECT'
               AND fsav.id_flex_code = 'GL#'
               AND fsav.id_flex_num = v_structure_number
               AND fsav.attribute_value = 'Y'
               AND fsav.id_flex_code = ffs.id_flex_code
               AND fsav.id_flex_num = ffs.id_flex_num
               AND ffs.application_column_name = fsav.application_column_name
               AND gps.co_code = v_co_code
               AND gps.segment_ref = ffs.segment_num;
         --
         EXCEPTION
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_segment_no_error;
         END;

         --

         ----------------------------------------------------------------------------------------------
 -- Se reemplaza el valor del proyecto por el nuevo obtenido (la posicion es v_segment_no - 1
 -- porque no se esta teniendo en cuenta la primer posicion correspondiente a v_unit_no)
----------------------------------------------------------------------------------------------
         IF (  v_segment_no
             - 1 < 1)
         THEN
            RAISE e_replace_segm_error;
         END IF;

         --
         v_segment_array (  v_segment_no
                          - 1)                          := v_segm_camp;
         v_acct_no                                      :=
            fnd_flex_ext.concatenate_segments (n_segments                    => v_segment_count
                                             , segments                      => v_segment_array
                                             , delimiter                     => v_delimiter
                                              );
         p_acct_no                                      := v_acct_no;
         p_acctg_unit_no                                := v_acctg_unit_no;
         p_errmsg                                       := v_structure_number;

         BEGIN
            SELECT acct_id
                 , acct_desc
              INTO v_acct_id
                 , v_acct_desc
              FROM gl_acct_mst
             WHERE acct_no = v_acct_no
               AND co_code = v_co_code
               AND delete_mark = 0;
         --
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               NULL;                            --La cuenta no existe y sera creada por procedimiento del form standard
            WHEN OTHERS
            THEN
               v_excep_msg                                    := SQLERRM;
               RAISE e_acct_error;
         END;
      --p_errmsg := ('v_acct_id: '||v_acct_id||' v_acct_desc: '|| v_acct_desc||' v_structure_number: ' || v_structure_number);

      --
      EXCEPTION
         WHEN e_no_acct
         THEN
            p_errmsg                                       := 'No genera cuenta contable:';
            p_acct_no                                      := NULL;
            p_acctg_unit_no                                := NULL;
            -- INSERT INTO temp VALUES ('No genera cuenta contable:');
            COMMIT;
         --
         WHEN e_acctg_unit_error
         THEN
            p_errmsg                                       :=
                                                (   'Error al buscar la Unidad Contable Cargo. Detalle: '
                                                 || v_excep_msg
                                                );
         --
         WHEN e_sbv_error
         THEN
            p_errmsg                                       :=
                                            (   'Error al buscar el id para el Subevento IADJ. Detalle: '
                                             || v_excep_msg
                                            );
         --
         WHEN e_acct_ttl_error
         THEN
            p_errmsg                                       :=
                                     (   'Error al buscar el id para el TÃ?Â­tulo de Cuenta IVA. Detalle: '
                                      || v_excep_msg
                                     );
         --
         WHEN e_acct_no_error
         THEN
            p_errmsg                                       :=
                                                         (   'Error al buscar la Cuenta Cargo. Detalle: '
                                                          || v_excep_msg
                                                         );
         --
         WHEN e_get_acct_mapping
         THEN
            p_errmsg                                       :=
                        ('No se encontrÃ?Â³ en el Mapeo de Cuentas de OPM, una cuenta cargo con tÃ?Â­tulo de cuenta IVA.'
                        );
         --
         WHEN e_uoper_error
         THEN
            p_errmsg                                       :=
               (   'No fue posible obtener la unidad operativa para la compania: '
                || v_co_code
                || '. Detalle: '
                || v_errmsg
               );
         --
         WHEN e_str_number
         THEN
            p_errmsg                                       :=
               (   'Error obteniendo la estructura contable para la organizacion: '
                || v_org_id
                || ' Detalle: '
                || v_excep_msg
               );
         --
         WHEN e_segment_error
         THEN
            p_errmsg                                       :=
               (   'Error obteniendo lista de segmentos para la combinaciÃ?Â³n contable: '
                || v_acctg_unit_no
                || v_delimiter
                || v_acct_no
                || '. Detalle: '
                || v_excep_msg
               );
         --
         WHEN e_segment_no_error
         THEN
            p_errmsg                                       :=
               (   'Error obteniendo orden en OPM del segmento calificador '
                || 'contable con el calificador: XX_PROJECT. Detalle: '
                || v_excep_msg
               );
         --
         WHEN e_replace_segm_error
         THEN
            p_errmsg                                       :=
               (   'Error al intentar reemplazar el valor del segmento '
                || 'proyecto por el valor asociado a la campaÃ?Â±a. Se '
                || 'esperaba un numero de segmento positivo. Valor obtenido '
                || (  v_segment_no
                    - 1)
                || '.'
               );
         --
         WHEN e_acct_error
         THEN
            p_errmsg                                       :=
                                                  (   'Error buscando el id de la Cuenta Cargo. Detalle:'
                                                   || v_excep_msg
                                                  );
         --
         WHEN OTHERS
         THEN
            p_errmsg                                       :=
               (   'Error al buscar en el Mapeo de Cuentas de OPM, una cuenta cargo con tÃ?Â­tulo '
                || 'de cuenta IVA y segmento Contable CampaÃ?Â±a '
                || v_segm_camp
                || ' - Detalle: '
                || SQLERRM
               );
      END;

      <<no_genera_cuenta>>
      NULL;
   END xx_exp_cuentas;
END xx_exp_combustible_pk;
/

exit
