==============================================================================
RELRI005_001: Relat�rio RI
==============================================================================

Atualiza��o - RELRI005_003
Produto     - XX Customizaciones
Data        - 25/11/2020 15:00:25
HotPatch    - S
Forncedor   - HQS Plus

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121RELRI005_003.drv

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N�o h� tarefas nesta se��o.

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N�o h� pr�-requisitos para este patch.

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_CLL_F189_VENDORS_V.vw
                               SAE_RI_RECEBI_DIARIO_ITEM_PKB.pls
                               SAE_RI_RECEBI_DIARIO_ITEM_PK.xls
