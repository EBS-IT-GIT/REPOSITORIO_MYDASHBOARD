UPDATE apps.xx_ws_efactura_talonario_all
SET    ultimo_nro = ultimo_nro + 1
WHERE  tipo_cbte = 182
AND    estado = 'A';
--1 Registro