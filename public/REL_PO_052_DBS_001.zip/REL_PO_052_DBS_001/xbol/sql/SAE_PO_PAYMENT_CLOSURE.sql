WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

--
-- $Header: SAE_PO_PAYMENT_CLOSURE.sql 121.1 13/08/2019 13:05:51 appldev ship $
-- +=================================================================+
-- |                            HQS Plus                             |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   SAE_PO_PAYMENT_CLOSURE.sql                                    |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Relatorio de Caucao Encerramento do Contrato.                 |
-- |                                                                 |
-- | [DESCRIPTION]                                                   |
-- |   SQL para alterar o nome do CCR                                |
-- |                                                                 |
-- | CREATED BY                                                      |
-- |   Mariana Andrade Resende             (13/08/2019)              |
-- |                                                                 |
-- +=================================================================+
--
WHENEVER SQLERROR CONTINUE

BEGIN
  fnd_program.delete_program (program_short_name => 'SAE_PO_PAYMENT_CLOSURE'
                             ,application        => 'SAE');
  COMMIT;
END;
-- Indicativo de final de arquivo. Nao deve ser removido.
/
WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
