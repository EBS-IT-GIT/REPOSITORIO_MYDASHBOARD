==============================================================================
RELPO052_001 : Relat�rio de Cau��o para Encerramento do Contrato
==============================================================================

Atualiza��o - RELPO052_001
Produto     - XX Customizaciones
Data        - 15/08/2019 09:46:46
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121RELPO052_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_PO_PAYMENT_CLOSURE.sql
                               SAE_PO_PAYMENT_CLOSURE_PKS.pls
                               SAE_PO_PAYMENT_CLOSURE_PKB.pls
                               SAE_PO_PAYMENT_CLOSURE_PK.grt
                               SAE_PO_PAYMENT_CLOSURE_PK.syn
                               SAE_PO_PAYMENT_CLOSURE_CCR.ldt
                               SAE_PO_PAYMENT_CLOSURE_XDO.ldt
                               SAE_PO_PAYMENT_CLOSURE.rtf
                               SAE_PO_PAYMENT_CLOSURE.xml
                               SAE_PO_EXTENSOES_RQG.ldt
