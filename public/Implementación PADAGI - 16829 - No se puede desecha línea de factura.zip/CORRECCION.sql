UPDATE apps.ap_invoice_lines_all
SET    description = 'JUNTA TERMICA 6-99035344 PARA HOMOGENIZADOR TKA'
WHERE  invoice_id = 6291783
AND    line_number = 1;
--1 Registro