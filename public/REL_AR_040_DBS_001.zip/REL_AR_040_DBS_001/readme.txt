==============================================================================
RELAR040_001 : Relat�rio Aging AR por per�odo informado
==============================================================================

Atualiza��o - RELAR040_001
Produto     - XX Customizaciones
Data        - 26/12/2019 14:58:19
HotPatch    - Sim
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121RELAR040_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_AR_AGING_REPORT_PKS.pls
                               SAE_AR_AGING_REPORT_PKB.pls
                               SAE_AR_AGING_REPORT_PK.grt
                               SAE_AR_AGING_REPORT_PK.syn
                               SAE_AR_AGING_REPORT_CCR.ldt
                               SAE_AR_AGING_REPORT_XDO.ldt
                               SAE_AR_AGING_REPORT_DD.xml
                               SAE_AR_AGING_REPORT_RQG.ldt
