UPDATE apps.ra_customer_trx_all
SET    trx_number = 'A-0001-00002500', last_update_date = sysdate, last_updated_by = 2070
WHERE  trx_number = 'E-0001-00002527';
--2 Registros
