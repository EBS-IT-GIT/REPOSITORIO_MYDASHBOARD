#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2536_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2536
# |
# | HISTORY
# |   22-JUN-20  Torres, Clarisa - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2536_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2536_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2536
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2536/CR2536_20200622"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=CRP3

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/VALSET
mkdir -p xbol/12.0.0/reports/US/
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/VALSET
mkdir -p xbol/12.0.0/reports/US/
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT
svn up /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2536" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2536_9552.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2536"
AddAllLogs $CROUT "FND" "CR2536_9552.ldt"
mv CR2536_9552.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_AR_IIBB_FORMATO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_AR_IIBB_FORMATO.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_AR_IIBB_FORMATO"
AddAllLogs $CROUT "FND" "XX_AR_IIBB_FORMATO.ldt"
mv XX_AR_IIBB_FORMATO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto REPORTS- XXARIBPR " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/reports/US/XXARIBPR.rdf XXARIBPR.rdf
echo `ls -lh XXARIBPR.rdf` >> $CROUT

mv XXARIBPR* $DOWNDBDIR/xbol/12.0.0/reports/US/


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
