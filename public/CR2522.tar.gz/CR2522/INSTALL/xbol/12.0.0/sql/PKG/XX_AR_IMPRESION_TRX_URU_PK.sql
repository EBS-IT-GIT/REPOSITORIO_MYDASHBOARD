  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_IMPRESION_TRX_URU_PK" AS

  PROCEDURE Principal ( errbuf                  OUT VARCHAR2
                      , retcode                 OUT VARCHAR2
                      , p_org_id                IN  VARCHAR2
                      , p_tipo_cbte             IN  VARCHAR2
                      , p_cust_trx_id_desde     IN  VARCHAR2
                      , p_cust_trx_id_hasta     IN  VARCHAR2
                      , p_fecha_trx_desde       IN  VARCHAR2
                      , p_fecha_trx_hasta       IN  VARCHAR2);


  FUNCTION Get_QR_Data ( p_xml_file IN XMLTYPE
                       , p_error OUT VARCHAR2) RETURN VARCHAR2;


  FUNCTION Get_QR_Data ( p_xml_file IN XMLTYPE ) RETURN VARCHAR2;


END XX_AR_IMPRESION_TRX_URU_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_IMPRESION_TRX_URU_PK" AS



  FUNCTION Get_Logo_Path(p_org_id NUMBER) RETURN VARCHAR2
  IS

    v_directorio        VARCHAR2(3000);
    v_logo              VARCHAR2(300);

  BEGIN

     -- recupera directorio del logo
    SELECT fec.value || fnd_profile.VALUE('XX_DIRECTORIO_LOGOS')
      INTO v_directorio
      FROM fnd_env_context fec
     WHERE fec.variable_name         = 'XBOL_TOP'
       AND fec.concurrent_process_id = (SELECT MAX(concurrent_process_id)
                                          FROM fnd_env_context);

    -- recupera informacion del logo
    SELECT attribute1
      INTO v_logo
      FROM HR_ORGANIZATION_INFORMATION
     WHERE attribute_category = 'Operating Unit Information'
       AND organization_id    = p_org_id;

    RETURN (v_directorio||v_logo);

  EXCEPTION
    WHEN others THEN
      RETURN '';

  END Get_Logo_Path;



  PROCEDURE ConvertBlobToClob(p_file_data IN BLOB, p_clob OUT CLOB, p_warning OUT VARCHAR2)
  IS

    v_varchar   VARCHAR2(32767) := NULL;
    v_start     PLS_INTEGER     := 1;
    v_buffer    PLS_INTEGER     := 32767;
    v_clob      CLOB;


  BEGIN

     DBMS_LOB.createtemporary(v_clob, true);

     FOR i IN 1 .. CEIL(DBMS_LOB.getlength(p_file_data) / v_buffer) LOOP

       v_varchar := UTL_RAW.cast_to_varchar2(DBMS_LOB.substr(p_file_data, v_buffer, v_start));

       DBMS_LOB.writeappend(v_clob, LENGTH(v_varchar), v_varchar);

       v_start := v_start + v_buffer;

     END LOOP;

     p_clob := v_clob;

  EXCEPTION
    WHEN others THEN
      p_warning := 'Error en ConvertBlobToClob: '||SQLERRM;

  END ConvertBlobToClob;



  FUNCTION Get_QR_Data(p_xml_file IN XMLTYPE, p_error OUT VARCHAR2) RETURN VARCHAR2
  IS
    v_data      VARCHAR2(3000);

  BEGIN

      v_data := 'https://www.efactura.dgi.gub.uy/consultaQR/cfe?'
                ||      XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'ns0:RUCEmisor')
                ||','|| XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'ns0:TipoCFE')
                ||','|| XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'ns0:Serie')
                ||','|| TO_NUMBER(XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'ns0:Nro'))
                ||','|| TRIM(XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'ns0:MntPagar'))
                ||','|| TO_CHAR(FND_DATE.canonical_to_date(SUBSTR(XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'ns0:TmstFirma'),1,10)),'dd/mm/yyyy')
                ||','|| XX_WS_COMMON_UY_PUB.GetNodeValue(p_xml_file,'DigestValue');

      RETURN v_data;

  EXCEPTION
    WHEN others THEN
      p_error := 'Error en Get_QR_Data: '||SQLERRM;
  END Get_QR_Data;



  FUNCTION Get_QR_Data(p_xml_file IN XMLTYPE) RETURN VARCHAR2
  IS

    v_qr_data      VARCHAR2(3000);
    v_error        VARCHAR2(3000);
    eQRError       EXCEPTION;

  BEGIN

    v_qr_data := Get_QR_Data(p_xml_file, v_error);

    IF (v_error IS NOT NULL) THEN
      RAISE eQRError;
    END IF;

    RETURN v_qr_data;

  EXCEPTION
    WHEN eQRError THEN
      RETURN '';
  END Get_QR_Data;


  PROCEDURE CreateOutput (p_final_file IN BLOB, p_warning OUT VARCHAR2)
  IS

    v_varchar VARCHAR2(32767) := NULL;
    v_start   PLS_INTEGER     := 1;
    v_buffer  PLS_INTEGER     := 32767;

  BEGIN


    FOR i IN 1 .. CEIL(DBMS_LOB.getlength(p_final_file) / v_buffer) LOOP

      v_varchar :=   REPLACE(
                       REPLACE(
                         REPLACE(
                             REPLACE(
                               REPLACE(
                                 REPLACE(UTL_RAW.cast_to_varchar2(DBMS_LOB.substr(p_final_file, v_buffer, v_start))
                                        ,'<?xml version="1.0"?>','')
                                      ,'<ns0:CFE xmlns:ns0="http://cfe.dgi.gub.uy" version="1.0">','<ns0:CFE>')
                                    ,'<ns0:SelloDigital xmlns:ns0="http://cfe.dgi.gub.uy">','<ns0:SelloDigital>')
                                  ,'<ns0:InfoExtra xmlns:ns0="http://cfe.dgi.gub.uy">', '<ns0:InfoExtra>')
                                ,'</ns0:CFE>'||chr(10)||chr(10)||'<ns0:CFE>','</ns0:CFE>'||chr(10)||'<ns0:CFE>' )
                              ,'<ns0:CFE version="1.0" xmlns:ns0="http://cfe.dgi.gub.uy">','<ns0:CFE>')
                          ;


--      FND_FILE.put_line(FND_FILE.output,v_varchar);
        FND_FILE.put(FND_FILE.output,v_varchar);

      v_start := v_start + v_buffer;

    END LOOP;

  EXCEPTION
    WHEN others THEN
      p_warning := 'Error en CreateOutput: '||SQLERRM;
  END CreateOutput;



  PROCEDURE Principal ( errbuf                  OUT VARCHAR2
                      , retcode                 OUT VARCHAR2
                      , p_org_id                IN  VARCHAR2
                      , p_tipo_cbte             IN  VARCHAR2
                      , p_cust_trx_id_desde     IN  VARCHAR2
                      , p_cust_trx_id_hasta     IN  VARCHAR2
                      , p_fecha_trx_desde       IN  VARCHAR2
                      , p_fecha_trx_hasta       IN  VARCHAR2)
  IS



    CURSOR c_trx IS
      SELECT rct.customer_trx_id
           , rct.trx_number
           , NVL(rctd.xx_ar_estado_usr,'ZZ')    xx_ar_estado_usr
           , rcttd.xx_tipo_cbte_uy
           , flv.meaning                        trx_type_name
           --, NVL(rctd.xx_ar_tipo_pedido_om, rct2.interface_header_attribute2)  xx_ar_tipo_pedido_om     CR2522
           , XX_UTIL_PK.xml_accepted_chars(NVL(rctd.xx_ar_tipo_pedido_om, rct2.interface_header_attribute2))  xx_ar_tipo_pedido_om
           , NVL(rctd.xx_ar_nro_pedido_om, rct2.interface_header_attribute1) xx_ar_nro_pedido_om
           , TO_CHAR(rct.term_due_date,'YYYY-MM-DD') term_due_date
           , rctd.xx_ar_cond_pago
           --Agregado CR3253
           , rctd.xx_fe_pais_uy
           --
        FROM RA_CUSTOMER_TRX_ALL        rct
           , RA_CUSTOMER_TRX_ALL_DFV    rctd
           , RA_CUST_TRX_TYPES_ALL      rctt
           , RA_CUST_TRX_TYPES_ALL_DFV  rcttd
           , FND_LOOKUP_VALUES          flv
           , RA_CUSTOMER_TRX_ALL        rct2
           , RA_BATCH_SOURCES_ALL       rbs
           , RA_BATCH_SOURCES_ALL_DFV   rbsd
       WHERE rct.rowid                        = rctd.row_id
         AND rct.cust_trx_type_id             = rctt.cust_trx_type_id
         AND rctt.rowid                       = rcttd.row_id
         AND rcttd.xx_tipo_cbte_uy            = flv.lookup_code
         AND flv.lookup_type                  = 'XX_AR_TIPO_CBTE_UY'
         AND language                         = userenv('LANG')
         AND rct.customer_trx_id              = rct2.customer_trx_id (+)
         AND rct2.interface_header_context(+) = 'ORDER ENTRY'
         AND rbs.rowid                        = rbsd.row_id
         AND rct.batch_source_id              = rbs.batch_source_id
         AND rbsd.xxw_fac_elec                = 'WSURU'
         AND NVL(rctd.xx_ar_estado_usr,'ZZ')  NOT IN ('BE','BS','ES') --,'E')
         AND (p_tipo_cbte                     IS NULL
             OR rcttd.xx_tipo_cbte_uy         = p_tipo_cbte)
         AND rctt.org_id                      = p_org_id
         AND rct.customer_trx_id             >= NVL(p_cust_trx_id_desde, rct.customer_trx_id)
         AND rct.customer_trx_id             <= NVL(p_cust_trx_id_hasta, rct.customer_trx_id)
         AND rct.trx_date               BETWEEN NVL(TO_DATE(p_fecha_trx_desde,'YYYY/MM/DD HH24:MI:SS'), rct.trx_date)
                                            AND NVL(TO_DATE(p_fecha_trx_hasta,'YYYY/MM/DD HH24:MI:SS'), rct.trx_date)
       ORDER BY rctd.xx_ar_estado_usr
           , rcttd.xx_tipo_cbte_uy
           , rct.trx_number;



    CURSOR c_notes (p_customer_trx_id NUMBER) IS
      --SELECT text                                                             CR2522
      SELECT XX_UTIL_PK.xml_accepted_chars(text) text
        FROM AR_NOTES_V
       WHERE customer_trx_id = p_customer_trx_id
       ORDER BY creation_date;


    CURSOR c_order (p_order_number VARCHAR2, p_order_type VARCHAR2) IS
      SELECT XX_UTIL_PK.xml_accepted_chars(flv.description)                     description --flv.description  CR2522
           , oeh.fob_point_code
        FROM OE_ORDER_HEADERS_V   oeh
           , FND_LOOKUP_VALUES_VL flv
       WHERE oeh.order_number                 = p_order_number
         AND oeh.order_type                   = p_order_type
         AND oeh.org_id                       = p_org_id
         AND oeh.context                      = 'AR_TRADE_MARKET'
         AND oeh.attribute8                   = flv.lookup_code
         AND flv.lookup_type                  = 'XX_AR_PAIS_FACTURA_ELECTRONICA'
         AND NVL(start_date_active, SYSDATE) <= SYSDATE
         AND NVL(end_date_active, SYSDATE)   >= SYSDATE
         AND enabled_flag                     = 'Y';


     CURSOR c_paisRecp (p_code VARCHAR2) IS
      SELECT XX_UTIL_PK.xml_accepted_chars(flv.description)                     description --flv.description  CR2522
        FROM FND_LOOKUP_VALUES      flv
           , FND_LOOKUP_VALUES_DFV  flvd
       WHERE flv.rowid                                   = flvd.row_id
         AND flv.lookup_type                             = 'XX_AR_PAIS_FACTURA_ELECTRONICA'
         AND NVL(flv.start_date_active, SYSDATE)        <= SYSDATE
         AND NVL(flv.end_date_active, SYSDATE)          >= SYSDATE
         AND flv.enabled_flag                            = 'Y'
         AND language                                    = userenv('LANG')
         AND NVL(flvd.xx_uy_cod_iso3166,flv.lookup_code) = p_code;


     CURSOR c_paisDest (p_cust_trx_id NUMBER) IS
       SELECT xapfe.description
         FROM HZ_LOCATIONS            hl
            , HZ_CUST_SITE_USES_ALL   hcsua
            , HZ_CUST_ACCT_SITES_ALL  hcasa
            , HZ_PARTY_SITES          hps
            , RA_CUSTOMER_TRX_ALL     rcta
           -- , (SELECT NVL (flvd.xx_uy_cod_iso3166, fl.lookup_code) cod_pais
            , (SELECT fl.lookup_code cod_pais
                    , XX_UTIL_PK.xml_accepted_chars(fl.description)             description --fl.description  CR2522
                    , fl.lookup_code
                 FROM FND_LOOKUPS           fl
                    , FND_LOOKUP_VALUES_DFV flvd
                WHERE lookup_type = 'XX_AR_PAIS_FACTURA_ELECTRONICA'
                  AND flvd.row_id = fl.ROWID
              ) xapfe
            , RA_CUSTOMER_TRX_ALL_DFV    rctd
        WHERE hps.location_id           = hl.location_id
          AND hcsua.cust_acct_site_id = hcasa.cust_acct_site_id
          AND hps.party_site_id          = hcasa.party_site_id
          AND hcsua.site_use_id         = rcta.ship_to_site_use_id
--          AND xapfe.lookup_code       = hl.province
--          AND xapfe.cod_pais          = hl.province  Comentado CR3253
          AND rcta.rowid                      = rctd.row_id
          AND xapfe.cod_pais             = NVL(xx_fe_pais_uy, hl.province)
          --
          AND rcta.customer_trx_id    = p_cust_trx_id;



    v_final_file    BLOB;    /* BLOB_FINAL */
    v_nmspc         VARCHAR2(100) := 'xmlns:ns0="http://cfe.dgi.gub.uy"';
    v_header        VARCHAR2(100) := '<ns0:XXARITURU version="1.0" '||v_nmspc||'>'||chr(10);
    v_footer        VARCHAR2(20)  := '</ns0:XXARITURU>';
    v_clob          CLOB;  /* CLOB_AUX */
    v_file_data     BLOB;
    v_blob_aux      BLOB;    /* BLOB_AUX */
    v_xml           XMLTYPE;
    v_xml_qr        XMLTYPE;
    v_xml_info      XMLTYPE;
    v_QR_str        VARCHAR2(500);
    v_dest_offset   INTEGER := 1;
    v_src_offset    INTEGER := 1;
    v_lang_context  INTEGER := 0;
    eProcessError   EXCEPTION;
    v_doc           DBMS_XMLDOM.domdocument;
    v_result        BOOLEAN;
    v_error         VARCHAR2(3000);
    v_adenda        VARCHAR2(3000);
    v_origen        VARCHAR2(240);
    v_pais_recep    VARCHAR2(240);
    v_pais_dest     VARCHAR2(240);
    v_cond_vta      VARCHAR2(30);


  BEGIN


    FND_FILE.put_line(FND_FILE.log, 'Parametros: ');
    FND_FILE.put_line(FND_FILE.log, 'p_org_id:            '||p_org_id);
    FND_FILE.put_line(FND_FILE.log, 'p_tipo_cbte:         '||p_tipo_cbte);
    FND_FILE.put_line(FND_FILE.log, 'p_cust_trx_id_desde: '||p_cust_trx_id_desde);
    FND_FILE.put_line(FND_FILE.log, 'p_cust_trx_id_hasta: '||p_cust_trx_id_hasta);
    FND_FILE.put_line(FND_FILE.log, 'p_fecha_trx_desde:   '||p_fecha_trx_desde);
    FND_FILE.put_line(FND_FILE.log, 'p_fecha_trx_hasta:   '||p_fecha_trx_hasta);
    FND_FILE.put_line(FND_FILE.log, '');

    --Archivo completo con todas las facturas, inicializacion
    DBMS_LOB.createtemporary(v_final_file, true);

    DBMS_LOB.writeappend(v_final_file, UTL_RAW.length(UTL_RAW.cast_to_raw(v_header)), UTL_RAW.cast_to_raw(v_header));

    DBMS_LOB.writeappend( v_final_file
                            , UTL_RAW.length(UTL_RAW.cast_to_raw('<ns0:LogoPath>'||Get_Logo_Path(p_org_id)||'</ns0:LogoPath>'))
                            , UTL_RAW.cast_to_raw('<ns0:LogoPath>'||Get_Logo_Path(p_org_id)||'</ns0:LogoPath>'));


    FOR rtrx IN c_trx LOOP

      --Modificado CR3253 - Desaparece la impresión por Draft
      --IF (rtrx.xx_ar_estado_usr='AE') THEN


        --=====================================================================
        -- Ya que la trx se encuentra finalizada y en estado AE, se debe Imprimir
        -- el XML Original validado por DGI
        --=====================================================================

        DBMS_LOB.createtemporary(v_clob, true);
        DBMS_LOB.createtemporary(v_file_data, true);
        DBMS_LOB.createtemporary(v_blob_aux,true);


        BEGIN
            SELECT file_data    -- Ultimo xml generado con el que se recibio la aprobacion de DGI
              INTO v_file_data
              FROM FND_ATTACHED_DOCS_FORM_VL   fad
                 , FND_LOBS                    fl
             WHERE fad.media_id         = fl.file_id
               AND function_name         = 'ARXTWMAI'
               AND (pk1_value, seq_num) = (SELECT pk1_value, MAX(seq_num)
                                             FROM FND_ATTACHED_DOCS_FORM_VL
                                            WHERE entity_name          = 'RA_CUSTOMER_TRX'
                                              AND file_name            LIKE '%_REQ_signed.xml'
                                              AND category_description = 'XX AR EFactura UY'
                                              AND to_number(pk1_value) = rtrx.customer_trx_id
                                            GROUP BY pk1_value);

        EXCEPTION
          WHEN no_data_found THEN
            FND_FILE.put_line(FND_FILE.log,'ERROR: Transaccion en estado AE pero sin archivo '||
                                           'REQ Signed XML creado. Customer_trx_id: '||rtrx.customer_trx_id);

            GOTO Next_Trx;
        END;


         ConvertBlobToClob(v_file_data, v_clob, v_error);

         IF (v_error IS NOT NULL) THEN
           RAISE eProcessError;
         END IF;


         --Se convierte a XML
         v_xml      := XMLTYPE.createxml(v_clob);

         v_QR_str := Get_QR_Data(v_xml, v_error);

         IF (v_error IS NOT NULL) THEN
           RAISE eProcessError;
         END IF;


         v_xml_qr := XMLTYPE.createxml( '<ns0:SelloDigital '||v_nmspc||'>'
                                      ||    '<ns0:ShortHash>'||SUBSTR(XX_WS_COMMON_UY_PUB.GetNodeValue(v_xml,'DigestValue'),1,6)||'</ns0:ShortHash>'
                                      ||    '<QRData>'|| v_QR_str||'</QRData>'
                                      ||'</ns0:SelloDigital>'
                                      );


         -- Notas en la Adenda
         v_adenda := NULL;
         FOR rnote IN c_notes (rtrx.customer_trx_id) LOOP
           v_adenda := v_adenda ||rnote.text||chr(10);
         END LOOP;


         -- Pais de Receptor
         v_pais_recep := XX_WS_COMMON_UY_PUB.GetNodeValue(v_xml, 'ns0:CodPaisRecep');
         OPEN c_paisRecp(v_pais_recep);
         FETCH c_paisRecp INTO v_pais_recep;
         CLOSE c_paisRecp;


         -- Pais de Destino
         OPEN c_paisDest (rtrx.customer_trx_id);
         FETCH c_paisDest INTO v_pais_dest;
         CLOSE c_paisDest;


         -- Origen del Pedido de Venta asociado, y condiciones de venta
         v_origen     := NULL;
         v_cond_vta := NULL;
         OPEN c_order (rtrx.xx_ar_nro_pedido_om, rtrx.xx_ar_tipo_pedido_om);
         FETCH c_order INTO v_origen, v_cond_vta;
         CLOSE c_order;


         -- Evaluación Condición de Venta
         IF (v_cond_vta IN ('FCA', 'FAS', 'FOB')) THEN
           v_cond_vta:= v_cond_vta ||' - '||v_origen;
         ELSE  -- 'CFR','CIF','DDP', 'DAP' o cualquier otro
           IF (v_cond_vta IS NULL) THEN
             v_cond_vta := v_pais_dest;
           ELSE
             v_cond_vta := v_cond_vta ||' - '||v_pais_dest;
           END IF;
         END IF;



         v_xml_info := XMLTYPE.createxml( '<ns0:InfoExtra '||v_nmspc||'>'
                                        ||    '<ns0:CustTrxId>'||rtrx.customer_trx_id||'</ns0:CustTrxId>'
                                        ||    '<ns0:Draft>N</ns0:Draft>'
                                        ||    '<ns0:TrxTypeName>'||rtrx.trx_type_name||'</ns0:TrxTypeName>'
                                        ||    '<ns0:Adenda>'||v_adenda||'</ns0:Adenda>'
                                        ||    '<ns0:OrigenPV>'||v_origen||'</ns0:OrigenPV>'
                                        ||    '<ns0:PaisRecep>'||v_pais_recep||'</ns0:PaisRecep>'
                                        ||    '<ns0:PaisDestino>'||v_pais_dest||'</ns0:PaisDestino>'
                                        ||    '<ns0:DueDate>'||rtrx.term_due_date||'</ns0:DueDate>'
                                        ||    '<ns0:CondVenta>'||v_cond_vta||'</ns0:CondVenta>'
                                        ||    '<ns0:CondPago>'||rtrx.xx_ar_cond_pago||'</ns0:CondPago>'
                                        ||'</ns0:InfoExtra>');


         v_xml := v_xml.appendChildXML('/ns0:CFE', v_xml_qr, v_nmspc);
         v_xml := v_xml.appendChildXML('/ns0:CFE', v_xml_info, v_nmspc);

         v_doc := DBMS_XMLDOM.newdomdocument(v_xml);

         XX_WS_COMMON_UY_PUB.updateNodeValue( p_xmldoc    => v_doc
                                             , p_nodename  => 'SignatureValue'
                                             , p_nodevalue => '');


         XX_WS_COMMON_UY_PUB.updateNodeValue( p_xmldoc    => v_doc
                                             , p_nodename  => 'X509Certificate'
                                             , p_nodevalue => '');


         --Se convierte el XML extraido en BLOB y se lo agrega al archivo final
         v_dest_offset := 1;
         v_src_offset  := 1;
         v_lang_context:= 0;

         DBMS_LOB.converttoblob( v_blob_aux
                                   , v_xml.getClobVal()
                                   , DBMS_LOB.getlength(v_xml.getClobVal())
                                   , v_dest_offset
                                   , v_src_offset
                                   , 0
                                   , v_lang_context
                                   , v_error);

          DBMS_LOB.append(v_final_file,v_blob_aux);

          <<Next_Trx>>

          DBMS_LOB.freetemporary (v_clob);
          DBMS_LOB.freetemporary (v_blob_aux);


    /*  ELSE   Comentado CR3253

          -- ===================================================================
          -- La transaccion no se encuentra validada por DGI por lo que se debe
          -- generar un xml Draft e Imprimir el mismo
          -- ==================================================================

          XX_WS_EFACTURAURU_PUB.Genera_Draft( rtrx.customer_trx_id
                                            , v_result
                                            , v_error);

          IF (NOT v_result) THEN
            RAISE eProcessError;
          END IF;

         DBMS_LOB.createtemporary(v_file_data, true);


         BEGIN
            SELECT file_data
              INTO v_file_data
              FROM FND_ATTACHED_DOCS_FORM_VL   fad
                 , FND_LOBS                    fl
             WHERE fad.media_id         = fl.file_id
               AND function_name         = 'ARXTWMAI'
               AND (pk1_value, seq_num) = (SELECT pk1_value, MAX(seq_num)
                                             FROM FND_ATTACHED_DOCS_FORM_VL
                                            WHERE entity_name          = 'RA_CUSTOMER_TRX'
                                              AND file_name            LIKE '%_DRAFT.xml'
                                              AND category_description = 'XX AR EFactura UY'
                                              AND to_number(pk1_value) = rtrx.customer_trx_id
                                            GROUP BY pk1_value);


           DBMS_LOB.append(v_final_file,v_file_data);

         EXCEPTION
           WHEN no_data_found THEN
             FND_FILE.put_line(FND_FILE.log,'ERROR: Transaccion en estado '||rtrx.xx_ar_estado_usr||' pero sin archivo '||
                                            'DRAFT XML creado. Customer_trx_id: '||rtrx.customer_trx_id);

         END;


      END IF;*/

    END LOOP;

    --Agregar el tag de Cierre
    DBMS_LOB.writeappend(v_final_file, UTL_RAW.length(UTL_RAW.cast_to_raw(v_footer)), UTL_RAW.cast_to_raw(v_footer));

    CreateOutput (v_final_file, v_error);

    IF (v_error IS NOT NULL) THEN
      RAISE eProcessError;
    END IF;




  EXCEPTION
    WHEN eProcessError THEN
      retcode := 2;
      errbuf:= v_error;

    WHEN others THEN
      retcode := 2;
      errbuf:= 'Error: '||SQLERRM;

  END Principal;


END XX_AR_IMPRESION_TRX_URU_PK;
/

  CREATE OR REPLACE EDITIONABLE SYNONYM "BOLINF"."XX_AR_IMPRESION_TRX_URU_PK" FOR "APPS"."XX_AR_IMPRESION_TRX_URU_PK";

exit
