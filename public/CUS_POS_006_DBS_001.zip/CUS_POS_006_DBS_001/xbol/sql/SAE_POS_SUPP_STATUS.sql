WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

-- $Header: SAE_POS_SUPP_STATUS.sql 120.1 16/09/2019 12:00:00 appldev ship $
-- +==================================================================+
-- |                            HQS Plus                              |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   SAE_POS_SUPP_STATUS.sql                                        |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUSPOS006                                                      |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   Script para atualizar o status dos documentos                  |
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan Gomes        16/09/2019                                  |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--
DECLARE 
BEGIN 
    -- Script para alterar status de Pendente dos documentos para Em Analise
    UPDATE BOLINF.SAE_AP_SUPPLIER_DOCS
       SET STATUS = '20'
     WHERE STATUS = '10';
     
    -- 
    UPDATE SAE_POS_SUPPLIER_REG_DOCS 
       SET STATUS = '20'
     WHERE STATUS = '10';  

    COMMIT;
EXCEPTION 
   WHEN OTHERS THEN 
    NULL;
END;
/
WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
