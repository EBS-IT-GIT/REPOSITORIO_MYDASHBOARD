==============================================================================
CUSPOS006_001 : Portal de Fornecedores - Cadastro
==============================================================================

Atualiza��o - CUSPOS006_001
Produto     - XX Customizaciones
Data        - 12/09/2019 10:41:50
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch

Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSPOS006_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

� necess�rio aplicar este patch no ambiente de acesso externo.
� necessario realizar um bounce no OACORE

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

Realizar as configura��es do Documento BR100.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: jSAECUSPOS006.zip
                               XXSAE_POS_SupplierPG.xml
