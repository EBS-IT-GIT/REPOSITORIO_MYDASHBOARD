UPDATE apps.wsh_new_deliveries wsh
SET    waybill = decode(delivery_id, 80739120, '0072-00036655', 80745130,'0072-00036656'), last_update_date = sysdate, last_updated_by = 2070
WHERE  delivery_id IN (80739120,80745130);
--2 Registros