UPDATE apps.xx_inv_remitos_impresos xiri
SET    waybill_airbill = decode(group_id, 80739120, '0072-00036655', 80745130,'0072-00036656'), last_update_date = sysdate, last_updated_by = 2070
WHERE  group_id IN (80739120,80745130);
--2 Registross