UPDATE apps.ap_checks_all
SET    attribute10 = null
     , attribute11 = null
     , attribute12 = null
     , attribute13 = null
     , attribute14 = null
     , attribute15 = null
     , last_update_date = sysdate
     , last_updated_by = 2070
WHERE  check_id IN (10267331, 10341372, 10304310);
--3 Registros