  set define off;

  CREATE OR REPLACE EDITIONABLE PACKAGE "APPS"."XX_AP_INVOICES_PER_ORG" AUTHID DEFINER AS
/*************************************************************
 *                                                           *
 * Name    : redefault_invoices                              *
 * Purpose : Realiza el redefault por compania               *
 *                                                           *
 *************************************************************/

  PROCEDURE redefault_invoices (
    p_errbuf                    OUT      VARCHAR2,
    p_retcode                   OUT      VARCHAR2,
    p_vendor_id                          po_vendors.vendor_id%TYPE,
    p_invoice_id                         ap_invoices_all.invoice_id%TYPE
  );
END XX_AP_INVOICES_PER_ORG;
/


  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "APPS"."XX_AP_INVOICES_PER_ORG" 
IS
   PROCEDURE redefault_invoices (
      p_errbuf       OUT VARCHAR2,
      p_retcode      OUT VARCHAR2,
      p_vendor_id        po_vendors.vendor_id%TYPE,
      p_invoice_id       ap_invoices_all.invoice_id%TYPE)
   AS
      CURSOR invs (
         p_vendor_id     po_vendors.vendor_id%TYPE,
         p_invoice_id    ap_invoices_all.invoice_id%TYPE)
      IS
         SELECT ai.invoice_id, ai.invoice_num, ai.vendor_id
           FROM AP_INVOICES ai
          WHERE ai.vendor_id = NVL (p_vendor_id, ai.vendor_id)
            AND ai.invoice_id = NVL (p_invoice_id, ai.invoice_id)
            AND (NVL (ai.payment_status_flag, 'N') = 'N'
                 OR NVL (ai.payment_status_flag, 'N') = 'P')
            AND invoice_Date > '01-MAR-1990'
            AND cancelled_date IS NULL;

   BEGIN
      fnd_file.put_line (fnd_file.LOG, '--o--o--o--o--o--o--o--o--o--');
      fnd_file.put_line (fnd_file.LOG, 'Inicio el Redefault');

      FOR inv IN invs (p_vendor_id, p_invoice_id)
      LOOP
         fnd_file.
         put_line (fnd_file.LOG, '--> Invoice Number = ' || inv.invoice_num);
         jl_zz_ap_awt_default_pkg.
         supp_wh_redefault (inv.invoice_id, inv.vendor_id);
      END LOOP;

      fnd_file.put_line (fnd_file.LOG, 'Fin del Redefault');
      COMMIT;
      fnd_file.put_line (fnd_file.LOG, '--o--o--o--o--o--o--o--o--o--');
   END redefault_invoices;

END XX_AP_INVOICES_PER_ORG;
/

exit
