==============================================================================
CUSAP045_002 : Bancada de Pagamentos e Comprovantes
==============================================================================

Atualiza��o - CUSAP045_002
Produto     - XX Customizaciones
Data        - 08/11/2019 15:33:22
HotPatch    - N�o
Fornecedor  - HQS Plus

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSAP045_002

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

Realizar instru��es descritas no arquivo que est� na pasta docs: "CUS_AP_045_BR100_Bancada_de_Pagamento_e_Comprovante.docx".
Realizar bounce.


Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: jSAECUSAP045.zip
                               BancadaPagamentoPG.xml
                               SAE_AP_STAT_PAY_BENCH.tab
                               SAE_AP_STAT_PAY_BENCH.grt
                               SAE_AP_STAT_PAY_BENCH.syn
                               SAE_AP_RECOVER_BORDERO_PKS.pls
                               SAE_AP_RECOVER_BORDERO_PKB.pls
                               SAERECOVERDANFE_CCR.ldt
                               SAE_AP_COPY_ATTACH_BANC_PAG_CCR.ldt
                               SAE_AP_BANCADA_RQG.ldt
