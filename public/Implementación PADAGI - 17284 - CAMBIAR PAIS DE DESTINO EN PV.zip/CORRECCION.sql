UPDATE apps.oe_order_headers_all ooh
SET    ship_to_org_id = 3330748, last_update_date = sysdate, last_updated_by = 2070
WHERE  header_id = 10407942;
--1 registro
