DECLARE
xamt NUMBER;
CURSOR c_inv IS
    SELECT customer_trx_id
          ,org_id
    FROM   apps.ra_customer_trx_all
    WHERE  customer_trx_id IN (13812380);

BEGIN
    FOR c1 IN c_inv LOOP
        MO_GLOBAL.SET_POLICY_CONTEXT('S',c1.org_id);
        ARP_MAINTAIN_PS.MAINTAIN_PAYMENT_SCHEDULES('U',c1.customer_trx_id,null,null,null,null,null,xamt,null);
        dbms_output.put_line('Actualizacion existosa customer_trx_id: '||c1.customer_trx_id||' - payment_schedule_id: '||xamt);
        COMMIT;
    END LOOP;
   
EXCEPTION
WHEN OTHERS THEN
   dbms_output.put_line('Error: '||sqlerrm);

END;