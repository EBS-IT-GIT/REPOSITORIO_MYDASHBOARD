UPDATE apps.oe_order_lines_all ool
SET    cust_po_number ='0927092700052822', last_update_date = sysdate, last_updated_by = -1
WHERE  header_id = 8715766;
--2 Registros