create or replace TRIGGER "SAU"."ESBR_NOTIFICACAO_OCORR_INTEMP" 
 AFTER
 INSERT OR UPDATE --Chamado 3338 - 31/05/2017 - Solic Sheiliemarcos
 ON SAU.MUDANCA_ESTADO_UNID_GERADORA  REFERENCING OLD AS OLD NEW AS NEW
 FOR EACH ROW
DECLARE
  V_DESCR_ESTADO        VARCHAR2(500);
  V_ESTADO_ant_NEW          VARCHAR2(5);
  V_ESTADO_NEW          VARCHAR2(5);
  V_ESTADO_OLD          VARCHAR2(5);
  V_LOCATION_NEW        VARCHAR2(14);
  V_OCORRENCIA_NEW      NUMBER;
  V_UNIDADE_NEW         VARCHAR2(14);
  V_DATA_OCORRENCIA_NEW DATE;
  V_DATA_OCORRENCIA_OLD DATE;
  V_COMENTARIO_NEW      VARCHAR2(500);
  V_COMENTARIO_OLD      VARCHAR2(500);
  V_INDISP_INT_EXT_NEW  VARCHAR2(30);

  V_TITULO VARCHAR2(100);
  V_CORPO  VARCHAR2(4000);
  

  --Alterado por: Paulo Roberto em 11/04/2014
  --Objetivo: buscar email do remetente das notificações através dos parâmetros gerais do SCTY.
  V_EMAIL_FROM          SCTY_PARAM.VLR_PARAM%TYPE := F_RETORNA_EMAIL_NOTIFICACAO;
  --Fim Alteração.

  CURSOR C_USUARIO IS
  SELECT T.EMAIL     USUARIO,
         T.EMPREGADO NM_USUARIO
    FROM NOTIFICACAO N, USUARIO_NOTIFICACAO UN, TBLE_USUARIOS_SSO_V T
   WHERE N.APLICACAO = 'NOTIFICACAO_OCORRENCIA_INTEMPESTIVA'
     AND :NEW.LOCATION IN
         (SELECT DISTINCT LOCATION
            FROM USINA
           WHERE (LOCATION LIKE DECODE(N.DOMINIO1, 'TD', '%', N.DOMINIO1) OR
                 TIPO_USINA = N.DOMINIO1 OR REGIONAL = N.DOMINIO1))
     AND N.NOTIFICACAO_ID = UN.NOTIFICACAO_ID
     AND T.LOGIN = UN.USR_NAME
     AND T.ATIVO = 'S';

  S_CURSOR_USUARIO C_USUARIO%ROWTYPE;

BEGIN

  --SOLICITACAO EM 14/02/2020, QUANDO O COD_ESTADO_UNIDADE_GERADORA = 'IGI' NÃO DISPARA O EMAIL
  IF RTRIM(LTRIM(:NEW.COD_ESTADO_UNIDADE_GERADORA)) = 'IGI' THEN
     RETURN;
  END IF; 
  --- 
  
  V_ESTADO_NEW          := :NEW.COD_ESTADO_UNIDADE_GERADORA;
  V_ESTADO_OLD          := :OLD.COD_ESTADO_UNIDADE_GERADORA;
  V_ESTADO_ant_NEw      := :NEW.cod_estado_unid_geradora_ant;   
  V_LOCATION_NEW        := :NEW.LOCATION;
  V_OCORRENCIA_NEW      := :NEW.NUM_SEQ_OCORRENCIA;
  V_UNIDADE_NEW         := :NEW.COD_UNIDADE_GERADORA;
  V_DATA_OCORRENCIA_NEW := :NEW.DATA_HORA_OCORRENCIA;
  V_DATA_OCORRENCIA_OLD := :OLD.DATA_HORA_OCORRENCIA;
  V_COMENTARIO_NEW      := :NEW.TXT_COMENTARIO_OCORRENCIA;
  V_COMENTARIO_OLD      := :OLD.TXT_COMENTARIO_OCORRENCIA;

  BEGIN
    SELECT NOME_ESTADO_UNIDADE_GERADORA
      INTO V_DESCR_ESTADO
      FROM ESTADO_UNIDADE_GERADORA
     WHERE COD_ESTADO_UNIDADE_GERADORA = :NEW.COD_ESTADO_UNIDADE_GERADORA;
  EXCEPTION
    WHEN OTHERS THEN
      V_DESCR_ESTADO := '';
  END;

  IF :NEW.COD_INDISP_INTERNA_EXTERNA = 'I' THEN
    V_INDISP_INT_EXT_NEW := 'Interna';
  ELSIF :NEW.COD_INDISP_INTERNA_EXTERNA = 'E' THEN
    V_INDISP_INT_EXT_NEW := 'Externa';
  ELSE
    V_INDISP_INT_EXT_NEW := '';
  END IF;
  
  --Alterado por: Carolina Ladwig de Borba em 16/12/2014
  --Objetivo: Para também enviar notificações quando o número do lote esteja em branco.
  -- E alterar o assunto do e-mail.
  IF INSERTING AND 
     SUBSTR(V_ESTADO_NEW, LENGTH(V_ESTADO_NEW), 1) = 'I' AND 
     SUBSTR(nvl(V_ESTADO_ant_NEw,'XXX'), LENGTH(nvl(V_ESTADO_ant_NEw,'XXX')), 1) <> 'I' AND /*soh notifica se o estado anterior nao for intepestivo*/
     :NEW.NUM_SEQ_OCORR_LOTE IS NULL THEN
    v_titulo := 'Inclusão de Ocorrência Intempestiva ' || '(' ||
  --Fim Alteração.
                v_location_new || ' - ' || v_unidade_new || ')';
    v_corpo  := '<FONT STYLE="font-family:Arial;font-size:9pt;">Prezado usuário,<br><br>';
    v_corpo  := v_corpo ||
                'Foi registrada a inclusão de uma ocorrência Intempestiva no Sistema de Acompanhamento de Usinas. <br><br>';
    v_corpo  := v_corpo ||
                '<FONT STYLE="font-family:Arial;font-size:9pt;"><b>DADOS DA OCORRÊNCIA</b><br>';
    v_corpo  := v_corpo || '<table>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Ocorrência:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_ocorrencia_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Usina:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_location_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Unidade:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_unidade_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Estado:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_estado_new || '  ' || v_descr_estado || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Indisp.:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_indisp_int_ext_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Data:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                to_char(v_data_ocorrencia_new, 'DD/MM/YYYY') ||
                '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Hora:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                to_char(v_data_ocorrencia_new, 'HH24:MI') || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Comentário:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_comentario_new || '</td></tr>';
    v_corpo  := v_corpo || '</table>';
    --Alterado por: Carolina Ladwig de Borba em 16/12/2014
    --Objetivo: Alterar a assinatura do e-mail.
    v_corpo  := v_corpo ||
                '<br><br><FONT STYLE="font-family:Arial;font-size:9pt;">Atenciosamente,' ||
                '<br><FONT STYLE="font-family:Arial;font-size:9pt;">Sistema de Acompanhamento de Usinas' ||
                '<br><FONT STYLE="font-family:Arial;font-size:9pt;">Energia Sustentável do Brasil S.A.';
    --Fim Alteração.

    IF V_DATA_OCORRENCIA_NEW >= SYSDATE - 1 THEN
      OPEN C_USUARIO;
      LOOP
        FETCH C_USUARIO
          INTO S_CURSOR_USUARIO;
        EXIT WHEN C_USUARIO%NOTFOUND;
        BEGIN

          -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
          --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
          --Alterado por: Paulo Roberto em 11/04/2014
          --Objetivo: buscar email do remetente das notificações através dos parâmetros gerais do SCTY.
          
          P_SEND_MAIL_FORMS10G(V_EMAIL_FROM,
                               'Notificacao SAU',
                               S_CURSOR_USUARIO.USUARIO,
                               S_CURSOR_USUARIO.NM_USUARIO,
                               NULL,
                               V_TITULO,
                               V_CORPO,
                               'SAU');
          -- Fim Alteração
        EXCEPTION
          WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        END;
      END LOOP;
      CLOSE C_USUARIO;
    END IF;
  END IF;

  --Alterado por: Carolina Ladwig de Borba em 16/12/2014
  --Objetivo: Para também enviar notificações quando o número do lote esteja em branco.
  -- E alterar o assunto do e-mail.
  IF UPDATING AND
     (V_ESTADO_NEW <> V_ESTADO_OLD OR V_COMENTARIO_NEW <> V_COMENTARIO_OLD) AND
     SUBSTR(V_ESTADO_NEW, LENGTH(V_ESTADO_NEW), 1) = 'I' AND 
    /*Conforme solicitacao em 28/02/202 por carolina, nao testar mais o estado anterior
      apnas <> IGI que está no inicio desta trigger.
     SUBSTR(V_ESTADO_OLD, LENGTH(V_ESTADO_OLD), 1) <> 'I' AND 
     */
     :NEW.NUM_SEQ_OCORR_LOTE IS NULL THEN
     
    v_titulo := 'Alteração de Ocorrência Intempestiva ' || '(' ||
  -- Fim Alteração.
                v_location_new || ' - ' || v_unidade_new || ')';
    v_corpo  := '<FONT STYLE="font-family:Arial;font-size:9pt;">Prezados usuários,<br><br>';
    v_corpo  := v_corpo ||
                'Foi registrada a alteração de uma ocorrência Intempestiva no Sistema de Acompanhamento de Usinas. <br><br>';
    v_corpo  := v_corpo ||
                '<FONT STYLE="font-family:Arial;font-size:9pt;"><b>DADOS DA OCORRÊNCIA</b><br>';
    v_corpo  := v_corpo || '<table>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Ocorrência:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_ocorrencia_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Usina:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_location_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Unidade:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_unidade_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Indisp.:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_indisp_int_ext_new || '</td></tr>';

    IF V_ESTADO_NEW <> V_ESTADO_OLD THEN
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Estado Anterior:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_estado_old || '</td></tr>';
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;"><b>Estado Novo:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;">' ||
                 v_estado_new || '  ' || v_descr_estado || '</td></tr>';
    ELSE
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Estado:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_estado_new || '  ' || v_descr_estado || '</td></tr>';
    END IF;

    v_corpo := v_corpo ||
               '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Data:</b></td>' ||
               '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
               to_char(v_data_ocorrencia_new, 'DD/MM/YYYY') || '</td></tr>';
    v_corpo := v_corpo ||
               '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Hora:</b></td>' ||
               '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
               to_char(v_data_ocorrencia_new, 'HH24:MI') || '</td></tr>';

    IF V_COMENTARIO_NEW <> V_COMENTARIO_OLD THEN
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Comentário Anterior:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_comentario_old || '</td></tr>';
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;"><b>Comentário Novo:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;">' ||
                 v_comentario_new || '</td></tr>';
    ELSE
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Comentário Novo:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_comentario_new || '</td></tr>';
    END IF;

    v_corpo := v_corpo || '</table>';
    --Alterado por: Carolina Ladwig de Borba em 16/12/2014
    --Objetivo: Alterar a assinatura do e-mail.
      v_corpo  := v_corpo ||
                '<br><br><FONT STYLE="font-family:Arial;font-size:9pt;">Atenciosamente,' ||
                '<br><FONT STYLE="font-family:Arial;font-size:9pt;">Sistema de Acompanhamento de Usinas' ||
                '<br><FONT STYLE="font-family:Arial;font-size:9pt;">Energia Sustentável do Brasil S.A.';
     --Fim Alteração.

    IF V_DATA_OCORRENCIA_OLD >= SYSDATE - 1 THEN
      OPEN C_USUARIO;
      LOOP
        FETCH C_USUARIO
          INTO S_CURSOR_USUARIO;
        EXIT WHEN C_USUARIO%NOTFOUND;
        BEGIN
          --Alterado por: Paulo Roberto em 11/04/2014
          --Objetivo: buscar email do remetente das notificações através dos parâmetros gerais do SCTY.
          P_SEND_MAIL_FORMS10G(V_EMAIL_FROM,
                               'Notificacao SAU',
                               S_CURSOR_USUARIO.USUARIO,
                               S_CURSOR_USUARIO.NM_USUARIO,
                               NULL,
                               V_TITULO,
                               V_CORPO,
                               'SAU');
        EXCEPTION
          WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        END;
      END LOOP;
      CLOSE C_USUARIO;
    END IF;
  END IF;
/*EXCEPTION
  WHEN OTHERS THEN
    --NULL;
    raise_application_error(-20002, sqlerrm);*/
END;
