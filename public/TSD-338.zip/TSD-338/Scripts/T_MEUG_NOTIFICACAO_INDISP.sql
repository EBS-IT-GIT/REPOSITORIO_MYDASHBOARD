create or replace TRIGGER "T_MEUG_NOTIFICACAO_INDISP"
AFTER INSERT OR UPDATE
ON SAU.MUDANCA_ESTADO_UNID_GERADORA
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
  v_descr_estado        varchar2(500);
  v_estado_new          varchar2(5);
  v_estado_old          varchar2(5);
  v_location_new        varchar2(14);
  v_location_old        varchar2(14);
  v_ocorrencia_new      number;
  v_ocorrencia_old      number;
  v_unidade_new         varchar2(14);
  v_unidade_old         varchar2(14);
  v_data_ocorrencia_new date;
  v_data_ocorrencia_old date;
  v_comentario_new      varchar2(500);
  v_comentario_old      varchar2(500);
  v_indisp_int_ext_new  varchar2(30);

  v_titulo varchar2(100);
  v_corpo  varchar2(4000);

  cursor c_usuario_dia is
    select --lower(t.login) || '@energiasustentaveldobrasil.com.br' usuario,
           t.email     usuario,
           t.empregado nm_usuario
      from notificacao n, usuario_notificacao un, tble_usuarios_sso_v t
     where n.aplicacao = 'NOTIFICACAO_INDISP_DIARIA'
       and :NEW.LOCATION in
           (select distinct location
              from usina
             where (location like decode(n.dominio1, 'TD', '%', n.dominio1) or
                   tipo_usina = n.dominio1 or regional = n.dominio1))
       and n.notificacao_id = un.notificacao_id
       and t.login = un.usr_name
       and t.ativo = 'S';

  s_cursor_usuario_dia c_usuario_dia%ROWTYPE;

  cursor c_usuario_mes is
    select --lower(t.login) || '@energiasustentaveldobrasil.com.br' usuario,
           t.email     usuario,
           t.empregado nm_usuario
      from notificacao n, usuario_notificacao un, tble_usuarios_sso_v t
     where n.aplicacao = 'NOTIFICACAO_INDISP_MENSAL'
       and :NEW.LOCATION in
           (select distinct location
              from usina
             where (location like decode(n.dominio1, 'TD', '%', n.dominio1) or
                   tipo_usina = n.dominio1 or regional = n.dominio1))
       and n.notificacao_id = un.notificacao_id
       and t.login = un.usr_name
       and t.ativo = 'S';

  s_cursor_usuario_mes c_usuario_mes%ROWTYPE;

  cursor c_usuario_geral is
    select --lower(t.login) || '@energiasustentaveldobrasil.com.br' usuario,
           t.email     usuario,
           t.empregado nm_usuario
      from notificacao n, usuario_notificacao un, tble_usuarios_sso_v t
     where n.aplicacao = 'NOTIFICACAO_INDISP_GERAL'
       and :NEW.LOCATION in
           (select distinct location
              from usina
             where (location like decode(n.dominio1, 'TD', '%', n.dominio1) or
                   tipo_usina = n.dominio1 or regional = n.dominio1))
       and n.notificacao_id = un.notificacao_id
       and t.login = un.usr_name
       and t.ativo = 'S';

  s_cursor_usuario_geral c_usuario_geral%ROWTYPE;
  
  --Objetivo: buscar email do remetente das notificações através dos parâmetros gerais do SCTY.
  V_EMAIL_FROM          SCTY_PARAM.VLR_PARAM%TYPE := F_RETORNA_EMAIL_NOTIFICACAO;
  

BEGIN
  v_estado_new          := :NEW.COD_ESTADO_UNIDADE_GERADORA;
  v_estado_old          := :OLD.COD_ESTADO_UNIDADE_GERADORA;
  v_location_new        := :NEW.LOCATION;
  v_location_old        := :OLD.LOCATION;
  v_ocorrencia_new      := :NEW.NUM_SEQ_OCORRENCIA;
  v_ocorrencia_old      := :OLD.NUM_SEQ_OCORRENCIA;
  v_unidade_new         := :NEW.COD_UNIDADE_GERADORA;
  v_unidade_old         := :OLD.COD_UNIDADE_GERADORA;
  v_data_ocorrencia_new := :NEW.DATA_HORA_OCORRENCIA;
  v_data_ocorrencia_old := :OLD.DATA_HORA_OCORRENCIA;
  v_comentario_new      := :NEW.TXT_COMENTARIO_OCORRENCIA;
  v_comentario_old      := :OLD.TXT_COMENTARIO_OCORRENCIA;


  --SOLICITACAO EM 14/02/2020, QUANDO O COD_ESTADO_UNIDADE_GERADORA = 'IGI' NÃO DISPARA O EMAIL
  IF RTRIM(LTRIM(:NEW.COD_ESTADO_UNIDADE_GERADORA)) = 'IGI' THEN
     RETURN;
  END IF; 
  ---

  begin
    select nome_estado_unidade_geradora
      into v_descr_estado
      from estado_unidade_geradora
     where cod_estado_unidade_geradora = :NEW.COD_ESTADO_UNIDADE_GERADORA;
  exception
    when others then
      v_descr_estado := '';
  end;

  if :NEW.COD_INDISP_INTERNA_EXTERNA = 'I' Then
    v_indisp_int_ext_new := 'Interna';
  elsif :NEW.COD_INDISP_INTERNA_EXTERNA = 'E' Then
    v_indisp_int_ext_new := 'Externa';
  else
    v_indisp_int_ext_new := '';
  end If;

  if INSERTING and substr(v_estado_new, 1, 1) = 'I' then
  
    v_titulo := 'Inclusao Ocorrencia Indisp.' || '(' || v_location_new ||
                ' - ' || v_unidade_new || ')';
    v_corpo  := '<FONT STYLE="font-family:Arial;font-size:9pt;">Prezado usuário,<br><br>';
    v_corpo  := v_corpo ||
                'foi registrada a inclusão de uma ocorrência de Indisponibilidade no Sistema de Acompanhamento de Usinas. <br><br>';
    v_corpo  := v_corpo ||
                '<FONT STYLE="font-family:Arial;font-size:9pt;"><b>DADOS DA OCORRÊNCIA</b><br>';
    v_corpo  := v_corpo || '<table>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Ocorrência:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_ocorrencia_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Usina:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_location_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Unidade:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_unidade_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Estado:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_estado_new || '  ' || v_descr_estado || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Indisp.:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_indisp_int_ext_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Data:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                to_char(v_data_ocorrencia_new, 'DD/MM/YYYY') ||
                '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Hora:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                to_char(v_data_ocorrencia_new, 'HH24:MI') || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Comentário:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_comentario_new || '</td></tr>';
    v_corpo  := v_corpo || '</table>';
    v_corpo  := v_corpo ||
                '<br><br><FONT STYLE="font-family:Arial;font-size:9pt;">Atenciosamente.' ||
                Chr(10);

    if v_data_ocorrencia_new >= sysdate - 1 then
      open c_usuario_dia;
      loop
        fetch c_usuario_dia
          into s_cursor_usuario_dia;
        exit when c_usuario_dia%NOTFOUND;
        begin
          -- Manutencao - 30 / 09 / 2010 - Rodrigo Oliveira - Supero
          -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
          --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
          p_send_mail_Forms10g(V_EMAIL_FROM,
                               'Notificacao SAU',
                               s_cursor_usuario_dia.usuario,
                               s_cursor_usuario_dia.nm_usuario,
                               null,
                               v_titulo,
                               v_corpo,
                               'SAU');
          -- Termino da Manutencao

        exception
          when others then
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        end;
      end loop;
      close c_usuario_dia;
    end if;
    if v_data_ocorrencia_new >= add_months(trunc(sysdate, 'mm'), -1) then
      open c_usuario_mes;
      loop
        fetch c_usuario_mes
          into s_cursor_usuario_mes;
        exit when c_usuario_mes%NOTFOUND;
        begin

          -- Manutencao - 30 / 09 / 2010 - Rodrigo Oliveira - Supero
          -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
          --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
          p_send_mail_Forms10g(V_EMAIL_FROM,
                               'Notificacao SAU',
                               s_cursor_usuario_mes.usuario,
                               s_cursor_usuario_mes.nm_usuario,
                               null,
                               v_titulo,
                               v_corpo,
                               'SAU');
          -- Termino da Manutencao

        exception
          when others then
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        end;
      end loop;
      close c_usuario_mes;
    end if;

    open c_usuario_geral;
    loop
      fetch c_usuario_geral
        into s_cursor_usuario_geral;
      exit when c_usuario_geral%NOTFOUND;
      begin
        -- Manutencao - 30 / 09 / 2010 - Rodrigo Oliveira - Supero
        -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
        --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
        p_send_mail_Forms10g(V_EMAIL_FROM,
                             'Notificacao SAU',
                             s_cursor_usuario_geral.usuario,
                             s_cursor_usuario_geral.nm_usuario,
                             null,
                             v_titulo,
                             v_corpo,
                             'SAU');
        -- Termino da Manutencao
        -- Versao anterior

      exception
        when others then
          DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
      end;
    end loop;
    close c_usuario_geral;
  end if;

  if UPDATING and
     (v_estado_new <> v_estado_old or v_comentario_new <> v_comentario_old) and
     substr(v_estado_new, 1, 1) = 'I' then
     
     
    v_titulo := 'Alteracao Ocorrencia Indisp. ' || '(' || v_location_new ||
                ' - ' || v_unidade_new || ')';
    v_corpo  := 'Prezados usuários,' || Chr(10) || Chr(10);
    v_corpo  := '<FONT STYLE="font-family:Arial;font-size:9pt;">Prezados usuários,<br><br>';
    v_corpo  := v_corpo ||
                'foi registrada a alteração de uma ocorrência de Indisponibilidade no Sistema de Acompanhamento de Usinas. <br><br>';
    v_corpo  := v_corpo ||
                '<FONT STYLE="font-family:Arial;font-size:9pt;"><b>DADOS DA OCORRÊNCIA</b><br>';
    v_corpo  := v_corpo || '<table>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Ocorrência:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_ocorrencia_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Usina:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_location_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Unidade:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_unidade_new || '</td></tr>';
    v_corpo  := v_corpo ||
                '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Indisp.:</b></td>' ||
                '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                v_indisp_int_ext_new || '</td></tr>';

    if v_estado_new <> v_estado_old then
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Estado Anterior:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_estado_old || '</td></tr>';
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;"><b>Estado Novo:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;">' ||
                 v_estado_new || '  ' || v_descr_estado || '</td></tr>';
    else
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Estado:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_estado_new || '  ' || v_descr_estado || '</td></tr>';
    end if;
    v_corpo := v_corpo ||
               '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Data:</b></td>' ||
               '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
               to_char(v_data_ocorrencia_new, 'DD/MM/YYYY') || '</td></tr>';
    v_corpo := v_corpo ||
               '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Hora:</b></td>' ||
      v_corpo := v_corpo ||
               '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
               to_char(v_data_ocorrencia_new, 'HH24:MI') || '</td></tr>';
    if v_comentario_new <> v_comentario_old then
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Comentário Anterior:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_comentario_old || '</td></tr>';
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;"><b>Comentário Novo:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;color:red;">' ||
                 v_comentario_new || '</td></tr>';
    else
      v_corpo := v_corpo ||
                 '<tr><td><FONT STYLE="font-family:Arial;font-size:9pt;"><b>Comentário Novo:</b></td>' ||
                 '<td><FONT STYLE="font-family:Arial;font-size:9pt;">' ||
                 v_comentario_new || '</td></tr>';
    end if;
    v_corpo := v_corpo || '</table>';
    v_corpo := v_corpo ||
               '<br><br><FONT STYLE="font-family:Arial;font-size:9pt;">Atenciosamente.' ||
               Chr(10);

    if v_data_ocorrencia_old >= sysdate - 1 then
      open c_usuario_dia;
      loop
        fetch c_usuario_dia
          into s_cursor_usuario_dia;
        exit when c_usuario_dia%NOTFOUND;
        begin
        
          --Manutencao - 30 / 09 / 2010 - Rodrigo Oliveira - Supero
          -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
          --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
          p_send_mail_Forms10g(V_EMAIL_FROM,
                               'Notificacao SAU',
                               s_cursor_usuario_dia.usuario,
                               s_cursor_usuario_dia.nm_usuario,
                               null,
                               v_titulo,
                               v_corpo,
                               'SAU');
          
          
          -- Termino da Manutencao

        exception
          when others then
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        end;
      end loop;
      close c_usuario_dia;
    end if;
    if v_data_ocorrencia_old >= add_months(trunc(sysdate, 'mm'), -1) then
      open c_usuario_mes;
      loop
        fetch c_usuario_mes
          into s_cursor_usuario_mes;
        exit when c_usuario_mes%NOTFOUND;
        begin
          -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
          --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
          p_send_mail_Forms10g(V_EMAIL_FROM,
                               'Notificacao SAU',
                               s_cursor_usuario_mes.usuario,
                               s_cursor_usuario_mes.nm_usuario,
                               null,
                               v_titulo,
                               v_corpo,
                               'SAU');
          -- Termino da Manutencao

        exception
          when others then
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        end;
      end loop;
      close c_usuario_mes;
    end if;
    open c_usuario_geral;
    loop
      fetch c_usuario_geral
        into s_cursor_usuario_geral;
      exit when c_usuario_geral%NOTFOUND;
      begin
        -- Objetivo: Possibilitar o envio de email via procedimento de inclusa da notificacao em uma tabela, para envio da notifica;áo a partir da trigger.
        --            Pois com na release 11 do banco nao possibilita a chamada de pacotes com a instrucao  AUTHID CURRENT_USER, que eh o caso da TBEL_WEB
        p_send_mail_Forms10g(V_EMAIL_FROM,
                             'Notificacao SAU',
                             s_cursor_usuario_geral.usuario,
                             s_cursor_usuario_geral.nm_usuario,
                             null,
                             v_titulo,
                             v_corpo,
                             'SAU');
        -- Termino da Manutencao

      exception
        when others then
          DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
      end;
    end loop;
    close c_usuario_geral;
  end if;
exception
  when others then
    null;
end;
