@"&DIRETORIO\000_SETUP_SCRIPTS.sql"
--
SPOOL "&DIRETORIO\TSD6915.log";


PROMPT RETORNA_FIM_TURNO.sql
@&DIRETORIO\RETORNA_FIM_TURNO.sql;
PROMPT FIM RETORNA_FIM_TURNO.sql

PROMPT Processo Finalizado! Favor verificar no arquivo de log TSD6915 se O script foi executado com sucesso...
SPOOL OFF;


