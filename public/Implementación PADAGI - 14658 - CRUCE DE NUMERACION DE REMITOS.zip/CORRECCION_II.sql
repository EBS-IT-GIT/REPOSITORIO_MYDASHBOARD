UPDATE xx_inv_remitos_impresos xiri
SET    waybill_airbill = DECODE(waybill_airbill
             ,'0072-00034424','0072-00035091'
             ,'0072-00035091','0072-00034424'
             ,waybill_airbill)
     , group_id = DECODE (group_id
             ,79212078,79376131
             ,79376131,79212078
             ,group_id)
WHERE  waybill_airbill IN ('0072-00034424','0072-00035091');
--2 Registros