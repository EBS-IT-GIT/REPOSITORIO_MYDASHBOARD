UPDATE wsh_new_deliveries
SET    waybill = DECODE(waybill
                       ,'0072-00034424','0072-00035091'
                       ,'0072-00035091','0072-00034424'
                       ,waybill)
WHERE  waybill IN ('0072-00034424','0072-00035091');
--2 Registros