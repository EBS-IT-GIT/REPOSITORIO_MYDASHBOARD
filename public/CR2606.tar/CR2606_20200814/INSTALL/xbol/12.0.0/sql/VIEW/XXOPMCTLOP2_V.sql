  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XXOPMCTLOP2_V" ("PLANT_CODE"
                                                                         , "BATCH_NO"
                                                                         , "BATCH_ID"
                                                                         , "TRANS_ID"
                                                                         , "TURNO"
                                                                         , "MOLINO"
                                                                         , "FORMULA_NO"
                                                                         , "ACTUAL_START_DATE"
                                                                         , "ACTUAL_CMPLT_DATE"
                                                                         , "ESTADO"
                                                                         , "ITEM_ID"
                                                                         , "ITEM_NO"
                                                                         , "ITEM_DESC1"
                                                                         , "WHSE_CODE"
                                                                         , "LOCATION"
                                                                         , "LINE_TYPE"
                                                                         , "LINE_TYPE2"
                                                                         , "LOT_NO"
                                                                         , "TRANS_DATE"
                                                                         , "TRANS_QTY"
                                                                         , "TRANS_UM"
                                                                         , "TRANS_QTY2"
                                                                         , "TRANS_UM2"
                                                                         , "REASON_CODE"
                                                                         , "PARTE_NRO") AS 
  SELECT a.plant_code,
            a.batch_no,
            a.batch_id,
            b.transaction_id trans_id,                                  -- ITC
            a.attribute1 turno,
            a.attribute2 molino,
            e.formula_no,
            a.actual_start_date,
            a.actual_cmplt_date,
            DECODE (a.batch_status,
                    1, 'Pendiente',
                    2, 'WIP',
                    3, 'Finalizado',
                    4, 'Cerrado',
                    'Cancelado')
               estado,
            c.inventory_item_id item_id,                                -- ITC
            c.segment1 item_no,                                         -- ITC
            c.description item_desc1,                                   -- ITC
            mp.organization_code whse_code,                             -- ITC
            hla.segment1 LOCATION,                                      -- ITC
            DECODE (gmd.line_type,
                    1, 'Producto',
                    2, 'Sub-producto',
                    'Ingrediente')
               line_type,
            gmd.line_type line_type2,
            d.lot_number lot_no,                                        -- ITC
            b.transaction_date trans_date,                              -- ITC
            SUM (b.transaction_quantity) trans_qty,                     -- ITC
            b.transaction_uom trans_um,                                 -- ITC
            SUM (NVL (b.secondary_transaction_quantity, 0)) trans_qty2, -- ITC
            b.secondary_uom_code trans_um2,                             -- ITC
            (SELECT mtr.reason_name
               FROM mtl_transaction_reasons mtr
              WHERE 1 = 1 AND mtr.reason_id = b.reason_id               -- ITC
                                                         )
               reason_code,                                             -- ITC
            a.attribute12 parte_nro
       FROM apps.gme_batch_header a,
            gme_material_details gmd,                                   -- ITC
            mtl_material_transactions b,                                -- ITC
            mtl_parameters mp,                                          -- ITC
            mtl_item_locations hla,                                     -- ITC
            mtl_system_items_b c,                                       -- ITC
            mtl_transaction_lot_numbers d,                              -- ITC
            apps.fm_form_mst e
      WHERE     1 = 1
            AND a.batch_id = b.transaction_source_id                    -- ITC
            AND b.trx_source_line_id = gmd.material_detail_id
            AND a.batch_id = gmd.batch_id
            AND b.organization_id = mp.organization_id                  -- ITC
            AND b.locator_id = hla.inventory_location_id(+)             -- ITC
            AND b.inventory_item_id = c.inventory_item_id               -- ITC
            AND b.organization_id = c.organization_id                   -- ITC
            AND b.transaction_id = d.transaction_id(+)                  -- ITC
            AND a.formula_id = e.formula_id
            --AND mp.plant_code   IN ('MSS1', 'MME1', 'MSF1')
            AND mp.organization_code IN ('MSS',           -- Plant_code = MSS1
                                               'MME',     -- Plant_code = MME1
                                                     'MFR') -- Plant_code = MSF1
   GROUP BY a.plant_code,
            a.batch_no,
            a.attribute1,
            a.attribute2,
            e.formula_no,
            a.batch_id,
            b.transaction_id,
            a.actual_start_date,
            a.actual_cmplt_date,
            DECODE (a.batch_status,
                    1, 'Pendiente',
                    2, 'WIP',
                    3, 'Finalizado',
                    4, 'Cerrado',
                    'Cancelado'),
            c.inventory_item_id,                                        -- ITC
            c.segment1,                                                 -- ITC
            c.description,                                              -- ITC
            mp.organization_code,                                       -- ITC
            hla.segment1,                                               -- ITC
            gmd.line_type,                                              -- ITC
            d.lot_number,                                               -- ITC
            b.transaction_date,                                         -- ITC
            b.transaction_uom,                                          -- ITC
            b.secondary_uom_code,                                       -- ITC
            b.reason_id,                                                -- ITC
            a.attribute12
   ORDER BY a.batch_no, gmd.line_type;


  CREATE OR REPLACE SYNONYM "ADECO_BI"."XXOPMCTLOP2_V" FOR "APPS"."XXOPMCTLOP2_V";


exit
