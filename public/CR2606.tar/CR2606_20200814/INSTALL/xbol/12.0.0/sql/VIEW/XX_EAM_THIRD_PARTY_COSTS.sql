  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_EAM_THIRD_PARTY_COSTS" ("WIP_ENTITY_ID"
                                                                         , "ORGANIZATION_ID"
                                                                         , "OPERATION_SEQ_NUM"
                                                                         , "PERIOD_NAME"
                                                                         , "TRC_COST") AS 
  SELECT rt.wip_entity_id
            , rt.organization_id            
            , rt.wip_operation_Seq_num operation_Seq_num
            , rrsl.period_name
            , sum(nvl(rrsl.accounted_dr,0) - nvl(rrsl.accounted_cr,0)) trc_cost
         FROM rcv_transactions  rt
            , rcv_receiving_sub_ledger rrsl
            , po_lines_all pl
            , cst_cat_ele_exp_assocs_v cat
        WHERE rt.wip_entity_id is not null
          AND cat.category_id = pl.category_id 
          AND cat.mfg_cost_element_id = 4 /* outside processing */
          AND cat.mnt_cost_element_id = 2 /* labor */
          AND pl.po_line_id = rt.po_line_id
          AND rt.destination_type_code = 'RECEIVING'
          AND rrsl.rcv_transaction_id = rt.transaction_id  
          AND rrsl.accounting_line_type = 'Receiving Inspection'
        GROUP BY 
              rt.wip_entity_id
            , rt.organization_id 
            , rt.wip_operation_Seq_num
            , rrsl.period_name;


exit
