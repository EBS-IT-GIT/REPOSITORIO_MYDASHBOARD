  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_EAM_USER_ORG_ACCESS" ("OPERATING_UNIT_ID"
                                                                         , "ORGANIZATION_ID"
                                                                         , "USER_ID"
                                                                         , "USER_NAME"
                                                                         , "EMAIL_ADDRESS") AS 
  SELECT iuo.operating_unit_id,
          iuo.organization_id,
          iuo.user_id,
          fu.user_name,
          CASE
             WHEN fu.email_address LIKE 'CLONE%'
             THEN
                SUBSTR (fu.email_address,
                        INSTR (fu.email_address, '.', 1) + 1,
                        LENGTH (fu.email_address))
             ELSE
                fu.email_address
          END
             email_address
     FROM xx_inv_user_org_access iuo, fnd_user fu
    WHERE iuo.user_id = fu.user_id;


exit
