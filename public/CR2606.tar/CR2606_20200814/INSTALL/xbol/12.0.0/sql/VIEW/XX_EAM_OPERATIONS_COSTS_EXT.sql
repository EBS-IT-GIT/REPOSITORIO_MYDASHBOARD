  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_EAM_OPERATIONS_COSTS_EXT" ("CURRENT_ORGANIZATION_ID"
                                                                         , "INV_ORGANIZATION_CODE"
                                                                         , "SERIAL_NUMBER"
                                                                         , "DESCRIPTIVE_TEXT"
                                                                         , "WIP_ACCOUNTING_CLASS_CODE"
                                                                         , "PERIOD_NAME"
                                                                         , "MAINTENANCE_OBJECT_ID"
                                                                         , "COST_TYPE"
                                                                         , "EXTRA_COST"
                                                                         , "ANIO_MES"
                                                                         , "ORGANIZATION_ID"
                                                                         , "START_DATE") AS 
  SELECT mtlea.current_organization_id,
            mtlea.inv_organization_code,
            mtlea.serial_number,
            mtlea.descriptive_text,
            mtlea.wip_accounting_class_code,
            glp.period_name,
            mtlea.maintenance_object_id,
            NVL (rgco.attribute1, 'Varios') AS cost_type,
            SUM(NVL(gll.accounted_dr,0) - NVL(gll.accounted_cr,0)),
            TO_CHAR (glp.start_date, 'YYYY-MM') AS anio_mes,
            mtlea.current_organization_id AS organization_id,
            glp.start_date            
       FROM rg_report_content_overrides rgco,
            rg_report_content_sets rgcs,
            gl_code_combinations_kfv gcc,
            gl_je_lines gll,
            gl_periods glp,
            gl_je_headers glh,
            apps.mtl_eam_asset_numbers_all_v mtlea
      WHERE rgco.content_set_id = rgcs.content_set_id
            AND gcc.segment1 BETWEEN NVL (rgco.segment1_low, gcc.segment1)
                                 AND NVL (rgco.segment1_high, gcc.segment1)
            AND gcc.segment2 BETWEEN NVL (rgco.segment2_low, gcc.segment2)
                                 AND NVL (rgco.segment2_high, gcc.segment2)
            AND gcc.segment3 BETWEEN NVL (rgco.segment3_low, gcc.segment3)
                                 AND NVL (rgco.segment3_high, gcc.segment3)
            AND gcc.segment4 BETWEEN NVL (rgco.segment4_low, gcc.segment4)
                                 AND NVL (rgco.segment4_high, gcc.segment4)
            AND gcc.segment5 BETWEEN NVL (rgco.segment5_low, gcc.segment5)
                                 AND NVL (rgco.segment5_high, gcc.segment5)
            AND gcc.segment6 BETWEEN NVL (rgco.segment6_low, gcc.segment6)
                                 AND NVL (rgco.segment6_high, gcc.segment6)
            AND gcc.segment7 BETWEEN NVL (rgco.segment7_low, gcc.segment7)
                                 AND NVL (rgco.segment7_high, gcc.segment7)
            AND gcc.segment8 BETWEEN NVL (rgco.segment8_low, gcc.segment8)
                                 AND NVL (rgco.segment8_high, gcc.segment8)
            --AND rgco.content_set_id =
            AND rgco.content_set_id = mtlea.attribute2
            AND mtlea.attribute2 IS NOT NULL
            AND gcc.code_combination_id + 0 = gll.code_combination_id
            AND gll.ledger_id = rgco.ledger_id
            AND gll.period_name = glp.period_name
            AND glp.period_year > TO_NUMBER (TO_CHAR (SYSDATE, 'YYYY')) - 4
            --and glp.period_name = 'FEB-20'
            --and mtlea.inv_organization_id = 1494
            AND gll.ledger_id = glh.ledger_id
            AND gll.je_header_id = glh.je_header_id
            AND (glh.je_source ||' - '||glh.je_category <> ('Cost Management - WIP'))
            AND (glh.je_source ||' - '||glh.je_category <> ('Cost Management - Inventory'))
            --AND glh.je_source NOT IN ('Inventory')
            --AND glh.je_category NOT IN ('Inventory')--/*'WIP', */
   GROUP BY mtlea.current_organization_id,
            mtlea.inv_organization_code,
            mtlea.serial_number,
            mtlea.descriptive_text,
            mtlea.wip_accounting_class_code,
            glp.period_name,
            glp.start_date,
            mtlea.current_organization_id,
            mtlea.maintenance_object_id,
            rgco.attribute1,
            glp.start_date;


exit
