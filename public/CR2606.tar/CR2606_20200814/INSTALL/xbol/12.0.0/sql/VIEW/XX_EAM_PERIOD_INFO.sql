  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_EAM_PERIOD_INFO" ("ORGANIZATION_ID"
                                                                         , "PERIOD_NAME"
                                                                         , "TITULO_IDX"
                                                                         , "RATE"
                                                                         , "TON"
                                                                         , "PERIOD_START_DATE"
                                                                         , "SCHEDULE_CLOSE_DATE") AS 
  SELECT oacp.organization_id AS organization_id,
          oacp.period_name AS period_name,
          idx.titulo_idx,
          DECODE (
             idx.titulo_idx,
             'ARS', 1,
             'USD', (SELECT gdr.conversion_rate
                       FROM gl_daily_Rates gdr
                      WHERE     gdr.conversion_type = 'Corporate'
                            AND gdr.from_currency = 'ARS'
                            AND gdr.to_currency = 'USD'
                            AND gdr.conversion_Date =
                                   (SELECT MAX (gdr2.conversion_date)
                                      FROM gl_daily_Rates gdr2
                                     WHERE gdr2.conversion_type =
                                              gdr.conversion_type
                                           AND gdr2.from_currency =
                                                  gdr.from_currency
                                           AND gdr2.to_currency =
                                                  gdr.to_currency
                                           AND gdr2.conversion_Date <=
                                                  oacp.schedule_close_date))) 
              rate,
             /*'USD x TON', ( (SELECT gdr.conversion_rate
                               FROM gl_daily_Rates gdr
                              WHERE     gdr.conversion_type = 'Corporate'
                                    AND gdr.from_currency = 'ARS'
                                    AND gdr.to_currency = 'USD'
                                    AND gdr.conversion_Date =
                                           (SELECT MAX (gdr2.conversion_date)
                                              FROM gl_daily_Rates gdr2
                                             WHERE gdr2.conversion_type =
                                                      gdr.conversion_type
                                                   AND gdr2.from_currency =
                                                          gdr.from_currency
                                                   AND gdr2.to_currency =
                                                          gdr.to_currency
                                                   AND gdr2.conversion_Date <=
                                                          oacp.
                                                          schedule_close_date))
                           / (SELECT ROUND (ABS (SUM (opv.trans_qty) / 1000),
                                            2)
                                FROM xxopmctlop2_v opv
                               WHERE opv.line_type = 'Ingrediente'
                                     AND opv.trans_date BETWEEN oacp.
                                                                period_start_date
                                                            AND oacp.
                                                                schedule_close_date
                                     AND DECODE (opv.whse_code,
                                                 'MSS', 'M01',
                                                 'MME', 'M03',
                                                 'MFR', 'M02') =
                                            mtp.organization_code)))*/
          (SELECT ROUND (ABS (SUM (opv.trans_qty) / 1000),
                                            2)
                                FROM xxopmctlop2_v opv
                               WHERE opv.line_type = 'Ingrediente'
                                     AND opv.trans_date BETWEEN oacp.
                                                                period_start_date
                                                            AND oacp.
                                                                schedule_close_date
                                     AND DECODE (opv.whse_code,
                                                 'MSS', 'M01',
                                                 'MME', 'M03',
                                                 'MFR', 'M02') =
                                            mtp.organization_code) TON,   
          oacp.period_start_date AS period_start_date,
          oacp.schedule_close_date AS schedule_close_date
     FROM org_acct_periods oacp,
          mtl_parameters mtp,
          (SELECT 'ARS' titulo_idx FROM DUAL
           UNION ALL
           SELECT 'USD' titulo_idx FROM DUAL
           /*UNION ALL
           SELECT 'USD x TON' titulo_idx FROM DUAL*/) idx
    WHERE oacp.organization_id = mtp.organization_id
          AND mtp.eam_enabled_flag = 'Y';


exit
