  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_EAM_COSTS_LEVEL" ("NIVEL"
                                                                         , "PARENT_SERIAL_NUMBER"
                                                                         , "SERIAL_NUMBER"
                                                                         , "DESCRIPTIVE_TEXT"
                                                                         , "INV_ORGANIZATION_CODE"
                                                                         , "INV_ORGANIZATION_ID"
                                                                         , "ASEET_CATEGORY_ID"
                                                                         , "ASEET_CATEGORY_NAME"
                                                                         , "OWNING_DEPARTMENT"
                                                                         , "AREA"
                                                                         , "AREA_ID"
                                                                         , "INSTANCE_ID") AS 
  SELECT DISTINCT LEVEL nivel,
                       ean.parent_serial_number,
                       ean.serial_number,
                       ean.descriptive_text,
                       ean.inv_organization_code,
                       ean.inv_organization_id,
                       ean.category_id aseet_category_id,
                       ean.category_name aseet_category_name,
                       ean.owning_department,
                       ean.area,
                       ean.area_id,
                       cii.instance_id
         FROM mtl_eam_asset_numbers_all_v ean, csi_item_instances cii
        WHERE 1 = 1             --AND wewo.wip_entity_id(+) = t1.wip_entity_id
                             --AND m1.lookup_type(+) = 'BOM_EAM_COST_CATEGORY'
                              --AND m1.lookup_code(+) = t1.maint_cost_category
                                     --AND t1.instance_id(+) = cii.instance_id
               AND cii.serial_number = ean.serial_number
   START WITH ean.serial_number IN ('FR', 'SS', 'ME', 'Planta CHS')
   CONNECT BY PRIOR ean.serial_number = ean.parent_serial_number;


exit
