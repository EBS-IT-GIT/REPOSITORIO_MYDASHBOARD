  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_EAM_OPERATIONS_COSTS" ("MAINT_COST_CATEGORY"
                                                                         , "MEANING"
                                                                         , "OPERATION_SEQ_NUM"
                                                                         , "ORGANIZATION_ID"
                                                                         , "ANIO_MES"
                                                                         , "PERIOD_NAME"
                                                                         , "COST_TYPE"
                                                                         , "COST"
                                                                         , "ESTIMATED_COST"
                                                                         , "PERIOD_START_DATE"
                                                                         , "INSTANCE_ID"
                                                                         , "WIP_ENTITY_ID"
                                                                         , "MAINTENANCE_TYPE"
                                                                         , "TITULO_IDX"
                                                                         , "DATA_CONVERTED") AS 
  SELECT bal.maint_cost_category AS maint_cost_category
        , m1.meaning AS meaning
        , bal.operation_Seq_num AS operation_Seq_num
        , wdj.organization_id AS organization_id
        , TO_CHAR(epi.period_start_date,'YYYY-MM') AS anio_mes
        , epi.period_name AS period_name
        , bal.cost_type
        , sum(nvl(bal.cost,0)) cost
        , sum(nvl(bal.estimated_cost,0)) estimated_cost
        , TO_CHAR(epi.period_start_date) AS period_start_date
        , wdj.maintenance_object_id AS instance_id
        , wdj.wip_entity_id AS wip_entity_id
        , NVL(wewo.work_order_type_disp,NVL(wewo.activity_type_disp, 'Correctivo')) AS maintenance_type
        , epi.titulo_idx
        , round(sum(nvl(bal.cost,0) * epi.rate),2) AS data_converted
     FROM (select 'Material' cost_type
                , sum(nvl(bal_mat.actual_mat_cost,0)) cost
                , sum(nvl(bal_mat.system_estimated_mat_cost,0)) estimated_Cost
                , bal_mat.wip_entity_id
                , bal_mat.period_name
                , bal_mat.maint_cost_category 
                , bal_mat.operation_Seq_num 
             from wip_eam_period_balances bal_mat
             group by bal_mat.wip_entity_id
                    , bal_mat.period_name
                    , bal_mat.maint_cost_category 
                    , bal_mat.operation_Seq_num 
            union
           /*select 'Mano de Obra' cost_type
                , sum(nvl(bal_lab.actual_lab_cost,0)) - nvl((select sum(x.trc_cost) 
                                                               from xx_eam_third_party_costs x
                                                              where bal_lab.wip_entity_id = x.wip_entity_id
                                                                and bal_lab.operation_seq_num = x.operation_seq_num
                                                                and bal_lab.period_name = x.period_name),0) cost
                , sum(nvl(bal_lab.system_estimated_lab_cost,0)) estimated_Cost
                , bal_lab.wip_entity_id
                , bal_lab.period_name
                , bal_lab.maint_cost_category 
                , bal_lab.operation_Seq_num 
             from wip_eam_period_balances bal_lab
             group by bal_lab.wip_entity_id
                    , bal_lab.period_name
                    , bal_lab.maint_cost_category 
                    , bal_lab.operation_Seq_num 
             union*/
           select 'Terceros' cost_type
                , sum(nvl(elc.trc_cost,0)) cost
                , 0 estimated_Cost
                , elc.wip_entity_id
                , elc.period_name
                , 1 maint_cost_category 
                , elc.operation_Seq_num 
            from xx_eam_third_party_costs elc
            group by elc.wip_entity_id
                   , elc.period_name
                   , elc.operation_Seq_num 
     /*        union
             select 'Equipos' cost_type
                  , sum(nvl(bal_eqp.actual_eqp_cost,0)) cost
                  , sum(nvl(bal_eqp.system_estimated_eqp_cost,0)) estimated_Cost
                  , bal_eqp.wip_entity_id
                  , bal_eqp.period_name
                  , bal_eqp.maint_cost_category 
                  , bal_eqp.operation_Seq_num 
             from wip_eam_period_balances bal_eqp
             group by  bal_eqp.wip_entity_id
                  , bal_eqp.period_name            
                  , bal_eqp.maint_cost_category 
                  , bal_eqp.operation_Seq_num
                  */
                  ) bal
        , wip_discrete_jobs wdj
        , wip_eam_work_orders_v wewo
        , mfg_lookups m1
        --, org_acct_periods oap
        , xx_eam_period_info epi
    WHERE 1=1
      AND bal.period_name = epi.period_name (+) 
      AND wdj.organization_id = epi.organization_id (+)
      AND bal.wip_entity_id = wdj.wip_entity_id
      AND wdj.maintenance_object_type = 3
      AND m1.lookup_type(+) = 'BOM_EAM_COST_CATEGORY'
      AND wewo.wip_entity_id = bal.wip_entity_id
      AND m1.lookup_code(+) = bal.maint_cost_category
            --and bal.cost_type = 'Third Party' 
            --and wdj.wip_entity_id = 5435008
    GROUP BY bal.maint_cost_category
           , bal.cost_type
           , bal.operation_seq_num
           , epi.period_name
           --, oap.period_set_name
           , epi.period_start_date
           , wdj.wip_entity_id
           , wdj.organization_id
           , wdj.maintenance_object_id
           , m1.meaning
           , wewo.work_order_type_disp
           , wewo.activity_type_disp
           , epi.rate
           , epi.titulo_idx
   UNION ALL
   SELECT 0 AS maint_cost_category
        , 'Accounting' AS meaning 
        , 0 AS operation_Seq_num
        , oce.organization_id AS organization_id
        , oce.anio_mes AS anio_mes
        , epi.period_name AS period_name
        , oce.cost_type AS cost_type
        , oce.extra_cost cost
        , 0 equipment_cost
        , TO_CHAR(oce.start_date) AS period_start_date
        , oce.maintenance_object_id AS instance_id
        , 0 AS wip_entity_id
        , 'Gastos GL' AS maintenance_type
        , epi.titulo_idx
        , round(sum(nvl(oce.extra_cost,0) * epi.rate),2) AS data_converted
     FROM xx_eam_operations_costs_ext oce
        , xx_eam_period_info epi
    WHERE oce.period_name not like 'AJU%'
      AND oce.organization_id = epi.organization_id 
      AND oce.period_name = epi.period_name
    GROUP BY oce.extra_cost
           , oce.maintenance_object_id
           , oce.organization_id
           , oce.anio_mes
           , epi.period_name
           , oce.start_date
           , oce.cost_type
           , epi.titulo_idx
           , epi.rate;


exit
