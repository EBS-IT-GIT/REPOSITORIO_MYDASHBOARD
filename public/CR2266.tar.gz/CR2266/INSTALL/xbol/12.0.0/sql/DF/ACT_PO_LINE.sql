  set define off;
declare
l_lineas number := 0;
l_clave_retoma number;
begin
select max(ult_clave) into l_clave_retoma from apps.xx_df_oc_lineas_control@CR.ADECO.NET.AR ;
for c1 in (select clave_id, uni_neg 
               from apps.XX_DF_OC_LINEAS_UN@CR.ADECO.NET.AR  xdo 
               where clave_id > nvl(l_clave_retoma,0) order by clave_id) loop

            l_lineas := l_lineas  + 1;

            update po_lines_all pla set attribute2 = to_char(c1.uni_neg), attribute_category = 'AR' 
            where pla.po_line_id = c1.clave_id
            and nvl(attribute_category,'AR') = 'AR';

            if mod(l_lineas,1000) = 0 then
                insert into apps.xx_df_oc_lineas_control@CR.ADECO.NET.AR  values (sysdate,l_lineas,c1.clave_id);
                commit;
            end if;
end loop;
  insert into apps.xx_df_oc_lineas_control@CR.ADECO.NET.AR  values (sysdate,l_lineas,9999999);
    commit;
end;
/

exit
