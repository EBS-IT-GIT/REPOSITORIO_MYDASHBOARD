UPDATE apps.ap_invoice_distributions_all aid
SET    attribute2 = 'FC HONOR', last_update_date = sysdate, last_updated_by = 2070
WHERE  attribute4 = '1001-00004084'
AND    attribute2 = 'FC SERVICI'
AND    attribute5 = (SELECT vendor_id
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'TOLEDO MARIANO NESTOR');
--3 Registros