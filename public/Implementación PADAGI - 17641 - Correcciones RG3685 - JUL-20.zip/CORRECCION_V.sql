UPDATE apps.ap_invoices_all
SET    invoice_num = '0002-00008173', last_update_date = sysdate, last_updated_by = 2070
WHERE  invoice_num = '0002--00008173';
--1 Registro