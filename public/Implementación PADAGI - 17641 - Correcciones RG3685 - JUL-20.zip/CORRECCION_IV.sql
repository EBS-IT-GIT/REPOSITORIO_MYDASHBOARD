UPDATE apps.ap_invoices_all
SET    invoice_date = '28-07-2020', last_update_date = sysdate, last_updated_by = 2070
WHERE  invoice_num IN ('5005-00003695')
AND    vendor_id IN (SELECT vendor_id
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'RAIZEN ARGENTINA S.A');
--1 Registro