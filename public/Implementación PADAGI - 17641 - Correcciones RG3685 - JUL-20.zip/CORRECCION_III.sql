UPDATE apps.ap_invoices_all
SET    invoice_date = '08-07-2020', last_update_date = sysdate, last_updated_by = 2070
WHERE  invoice_num IN ('0004-00000288', '0004-00000290', '0004-00000291')
AND    vendor_id IN (SELECT vendor_id
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'HUMBER SA');
--3 Registros