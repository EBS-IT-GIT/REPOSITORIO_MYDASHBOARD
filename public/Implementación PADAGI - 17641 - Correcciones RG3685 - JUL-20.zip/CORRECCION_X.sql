UPDATE apps.ap_invoice_distributions_all aid
SET    attribute6 = '2019/11/27 00:00:00'
WHERE  attribute4 = '0005-00036290'
AND    attribute6 = '2020/11/27 00:00:00'
AND    attribute5 = (SELECT vendor_id
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'RUGGERO VACCARI Y ASOCIADOS S.A');
--3 Registros