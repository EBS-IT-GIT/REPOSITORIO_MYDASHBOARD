UPDATE apps.ap_invoices_all ai
SET    global_attribute11 = 'FC INTERNA', global_attribute12 = 'Y', global_attribute13 = '99'
     , last_update_date = sysdate, last_updated_by = 2070
WHERE  invoice_num = '0007-00034743'
AND    vendor_id = (SELECT vendor_id
                    FROM   apps.ap_suppliers
                    WHERE  vendor_name = 'COMBUSTIBLES ASOCIADOS S.A.');
--1 Registro