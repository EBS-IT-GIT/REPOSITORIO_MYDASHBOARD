UPDATE apps.ap_invoice_distributions_all aid
SET    attribute6 = '2019/08/15 00:00:00', last_update_date = sysdate, last_updated_by = 2070
WHERE  attribute4 LIKE '0051-00025764'
AND    attribute6 = '2020/08/15 00:00:00'
AND    attribute5 = (SELECT vendor_id 
                     FROM   apps.ap_suppliers
                     WHERE  vendor_name = 'EXOLGAN S.A.');
--6 Registros