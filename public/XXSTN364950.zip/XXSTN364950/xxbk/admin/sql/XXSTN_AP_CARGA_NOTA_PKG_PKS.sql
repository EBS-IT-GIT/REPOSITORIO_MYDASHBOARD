WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE APPS.XXSTN_AP_CARGA_NOTA_PKG AUTHID CURRENT_USER IS
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_AP_CARGA_NOTA_PKG.pls                                     |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   AP - Carga de Notas                                           |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S    08/07/2019                  |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- |                                                                 |
-- +=================================================================+
  g_delim         VARCHAR2(1)  := ';';
  G_DT_FMT        VARCHAR2(30) := 'DD/MM/YYYY';
  g_source        Ap_Invoices_Interface.SOURCE%TYPE := 'CARGA NOTAS AP';
  g_currency_Code Varchar2(3) := 'BRL';
  g_EXCLUSIVE_PAYMENT_FLAG varchar2(1) := 'N';
  g_cont_entr NUMBER := 0;
  G_VENDOR_ID XXSTN_AP_INVOICES_INTERFACE.VENDOR_ID%TYPE;
  G_NR_NF     XXSTN_AP_INVOICES_INTERFACE.NR_NF%TYPE;
  G_DT_NF     XXSTN_AP_INVOICES_INTERFACE.DT_NF%TYPE;
  G_ORGANIZ_ID    XXSTN_AP_INVOICES_INTERFACE.ORG_ID%TYPE;
  G_INVOICE_ID NUMBER;

  --

  --
  TYPE ARRAY_CSV   is table of varchar2(32767);
  --
  FUNCTION IS_VALID_GL_SEGMENT_VALUE(P_SEGMENT IN VARCHAR, P_VALUE IN VARCHAR) RETURN BOOLEAN;


  /*
   * Processo que le o arquivo de carga(csv) e insere na tabela base para carga.
   */
  procedure CARGA_ARQ (
     ERRBUF       out varchar2
   , RETCODE      out varchar2
   , P_DIRECTORY   in varchar2
   , P_FILE_NAME   in varchar2
  );
  --
  /*
   * Processo que le a tabela de stagio e popula a open Interface do Payables
   * Este Processo iraa popular a tabela para qualquer ORG_ID Informada.
   */
  procedure CARREGA_DADOS (
     ERRBUF       out varchar2
   , RETCODE      out varchar2
   , P_FILE_NAME   in varchar2
  );
  --
  /*
   * Processo gera relat�rio com erros do processo de carga
   */
  procedure REL_ERROS_CARGA;
  --  
END XXSTN_AP_CARGA_NOTA_PKG;
/

EXIT; 
