WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE
create or replace PACKAGE BODY APPS.XXSTN_AP_CARGA_NOTA_PKG IS
-- +=================================================================+
-- |               Copyright (c) 2019 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_AP_CARGA_NOTA_PKG.pls                                     |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   AP - Carga de Notas                                           |
-- |                                                                 |
-- | CREATED BY   Fernando Pavao - 3S    08/07/2019                  |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- |                                                                 |
-- +=================================================================+
     --
     g_org_id NUMBER;
     --
     PROCEDURE PRINT_O(P_TEXTO IN VARCHAR) IS
     BEGIN
        --IF FND_GLOBAL.CONC_REQUEST_ID <> -1 THEN
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,P_TEXTO);
        --else
        --   DBMS_OUTPUT.PUT_LINE(P_TEXTO);
        --END IF;
     END PRINT_O;
     --
     PROCEDURE PRINT_L(P_TEXTO IN VARCHAR) IS
     BEGIN
        --IF FND_GLOBAL.CONC_REQUEST_ID <> -1 THEN
           FND_FILE.PUT_LINE(FND_FILE.LOG,P_TEXTO);
        --else
        --   DBMS_OUTPUT.PUT_LINE(P_TEXTO);
        --END IF;
     END PRINT_L;
    --
    /* Funcao que retorna a Organizacao */
    Function get_Org_id (
        p_org_name in varchar
       ,r_org_id  out number
    ) RETURN BOOLEAN IS
    BEGIN
         SELECT ORGANIZATION_ID INTO r_org_id
          FROM HR_OPERATING_UNITS
         WHERE NAME LIKE '%'|| p_ORG_NAME
         ;
         --
        RETURN TRUE;
    EXCEPTION WHEN OTHERS THEN
        RETURN FALSE;
    END get_Org_Id;
    --
    --
    /* Funcao que retorna o VendorID/VendorSiteId */
    Function get_Vendor (
      p_documento       in varchar2
     ,p_Org_id          in number
     ,p_vendor_site     in varchar2
     ,r_vendor_id      out number
     ,r_vendor_site_id out number
    ) Return Boolean is
    --
    begin
        -- Verifica se Local do Fornecedor Ja Existe.
        BEGIN
            SELECT PVSA.VENDOR_ID, PVSA.VENDOR_SITE_ID
              INTO r_vendor_id, r_Vendor_Site_id
              FROM AP_SUPPLIER_SITES_ALL PVSA
             WHERE ORG_ID = p_ORG_ID
               AND PVSA.VENDOR_ID IN ( SELECT VENDOR_ID FROM AP_SUPPLIERS WHERE SEGMENT1 = p_documento )
               AND PVSA.VENDOR_SITE_CODE =  p_vendor_site;

            return true;
        EXCEPTION
        WHEN OTHERS THEN
            print_l(p_documento||' - '||p_vendor_site);
            return false;
        END;
        --
    end get_Vendor;

    --
    PROCEDURE SPLIT_L_CSV(
        p_line  IN VARCHAR,
        p_delim IN VARCHAR,
        r_ret  OUT ARRAY_CSV
    ) IS
      --
      v_linha VARCHAR2(4000) := p_line;
      v_cp    varchar2(4000) := '';
      V_loop  BOOLEAN := TRUE;
      --
      v_ret ARRAY_CSV;
      v_ret_p number := 0;
      --
      PROCEDURE add_cp(p_cp in varchar) is
      BEGIN
        v_ret.extend(1);
        v_ret_p := v_ret_p + 1;
        v_ret(v_ret_p) := p_cp;
      END;
      --
    BEGIN
        v_ret := new ARRAY_CSV();
        WHILE( V_LOOP = TRUE ) LOOP

            IF INSTR(V_LINHA,P_DELIM) > 0 THEN
            -- tem divisor
               if substr(v_Linha,0,1) in( '"', '''') then
                    --dbms_output.put_line('comeca com aspas');
                    declare
                     v_pos2 number := instr(v_linha,substr(v_Linha,0,1)||p_delim);
                    Begin
                        v_cp := substr(v_linha,0, v_pos2  );
                        v_linha := substr(v_linha, v_pos2+2, length(v_linha) );
                        --
                        add_cp(v_cp);
                    end;
                    --dbms_output.put_line('cp:' || v_cp);
               else
                   --dbms_output.put_line('n?o comeca com aspas');
                    declare
                     v_pos2 number := instr(v_linha,p_delim);
                    Begin
                        v_cp := substr(v_linha,0, v_pos2 -1 );
                        v_linha := substr(v_linha, v_pos2+1, length(v_linha) );
                        --
                        add_cp(v_cp);
                    end;
                    --dbms_output.put_line('cp:' || v_cp);
               end if;
            else
                --
                --dbms_output.put_line('ultimo campo: ' || v_linha );
                --
                add_cp(v_linha);
                v_loop := false;
            END IF;
        END LOOP;
        --
        R_RET := V_RET;
        --
    END SPLIT_L_CSV;
    --
    --
  --
  FUNCTION IS_VALID_GL_SEGMENT_VALUE(P_SEGMENT IN VARCHAR, P_VALUE IN VARCHAR) RETURN BOOLEAN IS
    l_count number;
  BEGIN
    --FS.APPLICATION_COLUMN_NAME, FS.SEGMENT_NAME, FS.FLEX_VALUE_SET_ID, FV.FLEX_VALUE, FV.FLEX_VALUE_ID
    SELECT distinct 1
      INTO l_count
       FROM FND_ID_FLEX_STRUCTURES_VL FFS
          , FND_ID_FLEX_SEGMENTS_VL FS, FND_FLEX_VALUES_VL FV
     WHERE FFS.APPLICATION_ID         = '101'
       AND FFS.ID_FLEX_CODE           = 'GL#'
       AND FFS.ID_FLEX_NUM =
           (SELECT GLD.CHART_OF_ACCOUNTS_ID
              FROM HR_OPERATING_UNITS HOU
                  ,GL_LEDGERS_V GLD
             WHERE GLD.LEDGER_ID = HOU.SET_OF_BOOKS_ID
               AND HOU.ORGANIZATION_ID = g_org_id)
       AND FS.ID_FLEX_NUM       = FFS.ID_FLEX_NUM
       AND FS.APPLICATION_ID    = FFS.APPLICATION_ID
       AND FS.ID_FLEX_CODE      = FFS.ID_FLEX_CODE
       AND FS.FLEX_VALUE_SET_ID = FV.FLEX_VALUE_SET_ID
       and fv.ENABLED_FLAG      = 'Y'
       AND FS.APPLICATION_COLUMN_NAME = P_SEGMENT
       AND FV.FLEX_VALUE = P_VALUE
    ;
   --
    RETURN true;
  EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;
  END IS_VALID_GL_SEGMENT_VALUE;

  /*
   * Processo que le o arquivo de carga(csv) e insere na tabela base para carga.
   */
  procedure CARGA_ARQ (
     ERRBUF       out varchar2
   , RETCODE      out varchar2
   , P_DIRECTORY   in varchar2
   , P_FILE_NAME   in varchar2
  ) is
      l_arqdir    UTL_FILE.FILE_TYPE;
      l_linha     VARCHAR2(32000);
      l_user_id   NUMBER := fnd_profile.value('USER_ID');
      l_login_id  NUMBER := fnd_profile.value('LOGIN_ID');
      l_error     VARCHAR2(3000);
      l_qtde_sele NUMBER := 0;
      l_qtde_inse NUMBER := 0;
      l_qtde_erro NUMBER := 0;
      --
      R_RET ARRAY_CSV;
      --REG   XXSTN.XXHR_EMPLOYEES_IFACE%ROWTYPE;
      REG   XXSTN_AP_INVOICES_INTERFACE%ROWTYPE;
      --
      l_num_col     number;
      l_location_id number;

      FUNCTION get_col( P_NUMERO_COLUNA IN NUMBER ) RETURN VARCHAR IS
      BEGIN
         RETURN REPLACE(trim(R_RET(P_NUMERO_COLUNA)),CHR(13),'');
      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;
      END get_col;
      --
      FUNCTION get_next_col return varchar is
        l_retorno varchar2(4000);
      BEGIN
        l_retorno:= get_col(l_num_col);
        l_num_col := l_num_col + 1;
        --
--        substituido pelo replace acima
--        IF ascii(substr(l_retorno,length(l_retorno))) = 13 THEN -- chr13 ao fim da linha
--           l_retorno := substr(l_retorno,1,length(l_retorno)-1);
--        END IF;
        --
        RETURN l_retorno;
      END get_next_col;
      --
      FUNCTION get_next_col_dt(p_required in varchar ) return DATE is
        l_retorno    varchar2(4000);
        l_retorno_dt date;
      BEGIN
        l_retorno:= get_col(l_num_col);
        l_num_col := l_num_col + 1;
        if nvl(TRIM(l_RETORNO),'x') ='x' THEN
           if p_required = 'Y' THEN
              l_retorno_dt := to_Date('invalid',G_DT_FMT);
           end if;
        else
           l_retorno_dt := to_date(l_retorno,G_DT_FMT);
        END  IF;
        RETURN l_retorno_dt;
      END get_next_col_dt;
      --
  BEGIN
    --
    PRINT_O('Start of the program at ' || TO_CHAR(SYSDATE,'DD/MM/YYYY HH24:MI:SS'));
    --
    l_user_id  := FND_PROFILE.VALUE('USER_ID');
    l_login_id := FND_PROFILE.VALUE('LOGIN_ID');
    --
    PRINT_O('Directory..................: ' || P_Directory);
    PRINT_O('File Name..................: ' || p_file_name);
    --
    PRINT_O('1 - CHAMADA DO RELATORIO DE ERROS');
    REL_ERROS_CARGA;
    PRINT_O('2 - CHAMADA DO RELATORIO DE ERROS');
    --
    BEGIN
      L_ARQDIR := UTL_FILE.FOPEN(P_Directory,p_file_name,'R',32000);
    EXCEPTION
      WHEN UTL_FILE.INVALID_PATH THEN
        RAISE_APPLICATION_ERROR(-20003,'Invalid file name or directory'||P_Directory);
      WHEN UTL_FILE.INVALID_MODE THEN
       RAISE_APPLICATION_ERROR(-20004,'Invalid parameter mode in FSOPEN');
      WHEN UTL_FILE.INVALID_FILEHANDLE THEN
        RAISE_APPLICATION_ERROR(-20005,'The handle of the file is invalid');
      WHEN UTL_FILE.INVALID_OPERATION THEN
        RAISE_APPLICATION_ERROR(-20006,'The file can not be opened here');
      WHEN UTL_FILE.READ_ERROR THEN
        RAISE_APPLICATION_ERROR(-20007,'Operating system error during reading');
      WHEN UTL_FILE.WRITE_ERROR THEN
        RAISE_APPLICATION_ERROR(-20008,'Operating system error during recording');
      WHEN UTL_FILE.INTERNAL_ERROR THEN
        RAISE_APPLICATION_ERROR(-20009,'An error occurred unidentified');
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20010,'Error opening the file - '||SQLERRM);
    END;
    --
    LOOP
        l_qtde_sele := l_qtde_sele + 1;
        --
        BEGIN
          utl_file.get_line(l_arqdir, l_linha,32000);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
             EXIT;
          WHEN OTHERS THEN
             PRINT_L('l_linha : '||l_linha);
             RAISE_APPLICATION_ERROR(-20011,'Error select the file row - '||SQLERRM);
        END;
        --
        --FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Linha lida'|| l_Linha);
        --
        PRINT_L('l_linha : '||l_linha);
        PRINT_L('AQUI 1');
        --
        IF l_qtde_sele >= 2 AND length(TRIM(l_linha)) > 0 THEN
           PRINT_L('AQUI 1.1');
           --
           declare
              l_campo varchar2(100);
              l_valor varchar2(4000);
           begin
              PRINT_L('AQUI 2');
              l_num_col := 1;
              SPLIT_L_CSV( l_linha, g_delim, R_RET);
              --PRINT_L(l_linha);
              --
              l_campo             := 'UNID_OPER';
              l_valor             := get_next_col;
              reg.UNID_OPER       := l_valor;

              l_campo             := 'NR_FORNECEDOR';
              l_valor             := get_next_col;
              reg.NR_FORNECEDOR   := l_valor;

              l_campo             := 'LOCAL_FORNECEDOR';
              l_valor             := get_next_col;
              reg.LOCAL_FORNECEDOR := l_valor;

              l_campo             := 'TIPO_NF';
              l_valor             := get_next_col;
              reg.TIPO_NF         := l_valor;

              l_campo             := 'NR_NF';
              l_valor             := get_next_col;
              reg.NR_NF           := l_valor;

              l_campo             := 'DT_NF';
              l_valor             := get_next_col_dt('Y');
              reg.DT_NF           := l_valor;

              l_campo             := 'VL_NF';
              l_valor             := get_next_col;
              reg.VL_NF           := l_valor;

              l_campo             := 'MOEDA_NF';
              l_valor             := get_next_col;
              reg.MOEDA_NF        := l_valor;

              l_campo             := 'TAXA';
              l_valor             := get_next_col;
              reg.TAXA            := l_valor;

              l_campo             := 'TIPO_TAXA';
              l_valor             := get_next_col;
              reg.TIPO_TAXA       := l_valor;

              l_campo             := 'DATA_TAXA';
              l_valor             := get_next_col_dt('N');
              reg.DATA_TAXA       := l_valor;

              l_campo             := 'CONDICAO_PAGTO';
              l_valor             := get_next_col;
              reg.CONDICAO_PAGTO  := l_valor;

              l_campo             := 'DESCRICAO_NF';
              l_valor             := get_next_col;
              reg.DESCRICAO_NF    := l_valor;

              l_campo             := 'SOURCE';
              l_valor             := get_next_col;
              reg.SOURCE          := l_valor;

              l_campo             := 'DATA_MERCADORIA_RECEBIDA';
              l_valor             := get_next_col_dt('N');
              reg.DATA_MERCADORIA_RECEBIDA := l_valor;

              l_campo             := 'DATA_NF_RECEBIDA';
              l_valor             := get_next_col_dt('Y');
              reg.DATA_NF_RECEBIDA := l_valor;

              l_campo             := 'GL_DATE';
              l_valor             := get_next_col_dt('Y');
              reg.GL_DATE         := l_valor;

              l_campo             := 'DATA_BASE_VENCIMENTO';
              l_valor             := get_next_col_dt('Y');
              reg.DATA_BASE_VENCIMENTO := l_valor;

              l_campo             := 'NR_LINHA';
              l_valor             := get_next_col;
              reg.NR_LINHA        := l_valor;

              l_campo             := 'TIPO_LINHA';
              l_valor             := get_next_col;
              reg.TIPO_LINHA      := l_valor;

              l_campo             := 'DATA_CONTABIL';
              l_valor             := get_next_col_dt('Y');
              reg.DATA_CONTABIL   := l_valor;

              l_campo             := 'VALOR_CONTABIL';
              l_valor             := get_next_col;
              reg.VALOR_CONTABIL  := l_valor;

              l_campo             := 'DESCRICAO_LINHA_NF';
              l_valor             := get_next_col;
              reg.DESCRICAO_LINHA_NF := l_valor;

              l_campo             := 'COMBINACAO_CONTABIL';
              l_valor             := get_next_col;
              reg.COMBINACAO_CONTABIL := l_valor;

              l_campo             := 'NR_PO';
              l_valor             := get_next_col;
              reg.NR_PO           := l_valor;

              l_campo             := 'NR_LINHA_PO';
              l_valor             := get_next_col;
              reg.NR_LINHA_PO     := l_valor;

              l_campo             := 'NR_ENTREGA';
              l_valor             := get_next_col;
              reg.NR_ENTREGA      := l_valor;

              l_campo             := 'NR_DISTRIBUICAO_PO';
              l_valor             := get_next_col;
              reg.NR_DISTRIBUICAO_PO := l_valor;

              l_campo             := 'NR_RELEASE';
              l_valor             := get_next_col;
              reg.NR_RELEASE      := l_valor;

              --
              REG.FILE_NAME       := P_FILE_NAME;
              REG.STATUS          := 'N';
    --          --
    --          if get_location_id (reg.FILIAL, l_location_id ) then
    --              reg.status  := 'N';
    --              l_qtde_inse := l_qtde_inse + 1;
    --          else
    --              reg.status  := 'E';
    --              reg.message := 'Local Invalido';
    --              l_qtde_erro := l_qtde_erro + 1;
    --              PRINT_O('...Erro ao Processar a Linha['|| l_qtde_sele ||'] - Local Invalido' );
    --              PRINT_L('...Texto da Linha: ' || l_linha);
    --          end if;
    --          --
              REG.CREATION_DATE    := SYSDATE;
              REG.CREATED_BY       := FND_GLOBAL.USER_ID;
              REG.LAST_UPDATED_BY  := FND_GLOBAL.USER_ID;
              REG.LAST_UPDATE_DATE := SYSDATE;
              --
              l_campo := 'Insert ';
              INSERT INTO XXSTN_AP_INVOICES_INTERFACE VALUES REG;
              l_qtde_inse := l_qtde_inse + 1;
              --
              PRINT_L('AQUI 3');
           EXCEPTION
              WHEN OTHERS THEN
                 PRINT_L('...Erro ao Processar a Linha['|| l_qtde_sele ||'] - Campo :' || l_campo ||' Valor Campo: '||l_valor||' - '||SQLERRM);
                 PRINT_L('...Texto da Linha: ' || l_linha);
                 RETCODE := 2;
           END;
        END IF;

    END LOOP;
    --
    UTL_FILE.FCLOSE(L_ARQDIR);
    --
    --
    PRINT_O('Total Records selected .......: '||l_qtde_sele );
    PRINT_O('Total Records inserted .......: '||l_qtde_inse );
    print_O('total Records with errors ....: '||l_qtde_erro );
    --
    IF l_qtde_erro = 0 THEN
      PRINT_O('Successfully completed at ' || TO_CHAR(SYSDATE,'DD/MM/YYYY HH24:MI:SS'));
    ELSE
      PRINT_O('Completed with error, Please, verify the messages above ' || TO_CHAR(SYSDATE,'DD/MM/YYYY HH24:MI:SS'));
    END IF;

    EXCEPTION
     WHEN OTHERS THEN
      PRINT_L('...Erro inesperado no processo CARGA_ARQ: '||SQLERRM);
      RETCODE := 2;

  END CARGA_ARQ;
    --
  /*
   * Processo que le a tabela de stagio e popula a open Interface do Payables
   * Este Processo ira popular a tabela para qualquer ORG_ID Informada.
   */
  Procedure CARREGA_DADOS (
     ERRBUF       out varchar2
   , RETCODE      out varchar2
   , P_FILE_NAME   in varchar2
  ) IS
    --
    l_login_id number := fnd_global.login_id;
    --
    CURSOR C_PEND IS
    SELECT P.*, ROWID AS XID
      FROM XXSTN.XXSTN_AP_INVOICES_INTERFACE P
     WHERE STATUS = 'N'
       AND FILE_NAME = NVL(P_FILE_NAME, FILE_NAME )
  ORDER BY VENDOR_ID,NR_NF,DT_NF,ORG_ID,NR_LINHA
    ;
    --
    Cursor c_sts(p_status varchar) is
    SELECT *
      FROM XXSTN.XXSTN_AP_INVOICES_INTERFACE P
     WHERE STATUS = P_STATUS
       AND LAST_UPDATE_LOGIN = l_login_id
    ;
    --
    L_PEND     C_PEND%ROWTYPE;
    l_sts      C_STS%ROWTYPE;
    l_linha_dup NUMBER;
    l_global_attribute1 ap_supplier_sites_all.global_attribute1%type;
    --
    procedure updst(
        p_status in varchar
      , p_message in varchar
    ) is
    begin
        l_pend.status := p_status;

        if l_pend.mensagem_status is null then
           l_pend.mensagem_status := p_message;
        else
            if p_message is not null then
               l_pend.mensagem_status := l_pend.mensagem_status || ', ' ||p_message;
            end if;
        end if;
    end;
    --
    Function find_ccid return boolean is
        v_op     BOOLEAN;
        v_coa_id NUMBER := 50388;
    Begin
        Select code_combination_id into l_pend.code_combination_id
          from gl_code_combinations_kfv
         where concatenated_Segments = l_pend.combinacao_contabil;
/*                l_pend.seg_empresa  || '.' ||
                l_pend.seg_bandeira || '.' ||
                l_pend.seg_produto  || '.' ||
                l_pend.seg_conta    || '.' ||
                l_pend.seg_cc       || '.' ||
                l_pend.seg_ic       || '.' ||
                l_pend.seg_fut1     || '.' ||
                l_pend.seg_fut2;*/
        return true;
    Exception
       When Others then
            --call the api to create the code combination.
            v_op := fnd_flex_keyval.validate_segs(operation        => 'CREATE_COMBINATION',
                                                  appl_short_name  => 'SQLGL',
                                                  key_flex_code    => 'GL#',
                                                  structure_number => v_coa_id,           --- Pass your chart of accounts id
                                                  concat_segments  => l_pend.combinacao_contabil/*l_pend.seg_empresa  || '.' ||
                                                                      l_pend.seg_bandeira || '.' ||
                                                                      l_pend.seg_produto  || '.' ||
                                                                      l_pend.seg_conta    || '.' ||
                                                                      l_pend.seg_cc       || '.' ||
                                                                      l_pend.seg_ic       || '.' ||
                                                                      l_pend.seg_fut1     || '.' ||
                                                                      l_pend.seg_fut2 */ , --- Pass your account combination string you want to create
                                                  validation_date  => TRUNC ( SYSDATE)  );
            --
            IF NOT V_OP THEN
               return false;
            END IF;
            --
            return true;
    End find_ccid;
    --
    Function find_term_id return boolean is
    Begin
        SELECT distinct term_id into l_pend.term_id
          from APPS.AP_TERMS
         Where name = l_pend.condicao_pagto
         and   nvl(end_date_active,sysdate) >= sysdate;
        return true;
    --
    Exception
    When Others Then
        return false;
    End find_term_Id;
    --
    Procedure carregar_itf as
        x_reg           Ap_Invoices_Interface%ROWTYPE;
        x_reg2          Ap_Invoice_Lines_Interface%ROWTYPE;
        l_ACCOUNTING_DATE date := TO_DATE('30-12-2017','DD-MM-YYYY');
        l_exist number;
        --
    BEGIN
        -- Verifica se ja nao foi inserida ja a nf/linha
        --
        l_exist := 0;
        BEGIN

         SELECT nvl(COUNT(aii.invoice_num),0)
           INTO l_exist
           FROM Ap_Invoices_Interface aii
               ,Ap_Invoice_Lines_Interface aili
          WHERE aii.vendor_id = l_pend.vendor_id
            AND aii.invoice_num = l_pend.NR_NF
            AND aii.invoice_date = l_Pend.dt_nf
            AND aii.org_id     = l_Pend.org_id
            AND aili.line_number = l_Pend.nr_linha
            AND aii.invoice_id = aili.invoice_id;

         EXCEPTION
          WHEN OTHERS THEN
           l_exist := 0;

        END;

        if l_exist > 0 then
           -- NF ja inserida na Interface com este numero de linha
           updst('E','NF ja inserida na interface com este numero de linha');
        end if;


         if l_Pend.status = 'N' then
         --
         g_cont_entr := g_cont_entr + 1;

         IF g_cont_entr = 1 THEN

          SELECT APPS.AP_INVOICES_INTERFACE_S.NEXTVAL
            INTO X_REG.INVOICE_iD
            FROM DUAL;

           G_INVOICE_ID := X_REG.INVOICE_iD;

          X_REG.Invoice_Num    := l_pend.nr_nf; --1

          --X_REG.Invoice_Type_Lookup_Code := 'STANDARD'   ; --2
          X_REG.Invoice_Type_Lookup_Code := l_pend.TIPO_NF ; --'PREPAYMENT'   ; --2
          --
          X_Reg.Invoice_Date   := l_pend.dt_nf    ; --3
          X_REG.Vendor_Id      := l_pend.Vendor_Id       ; --4
          X_REG.Vendor_Site_Id := l_pend.Vendor_Site_Id  ; --5
          X_REG.Invoice_Amount := l_pend.VL_NF; --6
          X_REG.Invoice_Currency_Code := l_pend.moeda_nf ; --7
          X_REG.EXCHANGE_RATE := l_pend.taxa;
          X_REG.EXCHANGE_RATE_TYPE := l_pend.TIPO_TAXA;
          X_REG.EXCHANGE_DATE := l_pend.DATA_TAXA;
          x_reg.terms_id := l_pend.term_id;
          --X_REG.Terms_Id    := l_pend.TERM_ID   ;--11
          --
          X_REG.Description := l_pend.DESCRICAO_NF;--12
          --
          --
          X_Reg.Source                     := l_pend.source ;--45
          --X_Reg.Payment_Method_Lookup_Code := l_inv.Payment_Method_Lookup_Code; --46 ?????
          --X_Reg.Pay_Group_Lookup_Code      := l_inv.Pay_Group_Lookup_Code     ; --47 ?????
          X_Reg.Goods_Received_Date    := l_pend.dt_nf; --48 sysdate definirem ??
          X_Reg.Invoice_Received_Date  := l_pend.dt_nf; --49 sysdate  definirem ??
          X_Reg.Gl_Date                := l_pend.gl_date; --sysdate; --50 sysdate definirem ??
          --X_REG.EXCLUSIVE_PAYMENT_FLAG := g_EXCLUSIVE_PAYMENT_FLAG; --51
          X_Reg.Org_Id      := l_pend.org_id;   --52
          X_REG.TERMS_DATE  := l_pend.DATA_BASE_VENCIMENTO;--53
          -- X_REG.PAYMENT_METHOD_CODE := '';
          --
          X_REG.CREATION_DATE    := SYSDATE; --54
          X_REG.CREATED_BY       := FND_GLOBAL.USER_ID;      --55
          X_REG.LAST_UPDATE_DATE := SYSDATE; --56
          X_REG.LAST_UPDATED_BY  := FND_GLOBAL.USER_ID;      --57
          --
          X_REG.Global_Attribute_Category := 'JL.BR.APXIISIM.INVOICES_FOLDER'; --29

          l_global_attribute1 := NULL;
          BEGIN

           SELECT Global_Attribute1
             INTO l_global_attribute1
             FROM ap_supplier_sites_all
            WHERE vendor_id = l_pend.vendor_id
              AND vendor_site_id = l_pend.vendor_site_id
              AND org_id = l_pend.org_id;

           EXCEPTION
            WHEN OTHERS THEN
             NULL;

          END;

          X_REG.Global_Attribute1  := l_global_attribute1;--'N';--30

          INSERT INTO Apps.Ap_Invoices_Interface VALUES X_Reg;

          G_VENDOR_ID := l_pend.vendor_id;
          G_NR_NF := l_pend.NR_NF;
          G_DT_NF := l_pend.DT_NF;
          G_ORGANIZ_ID := l_pend.ORG_ID;

         ELSE

          IF g_cont_entr > 1 AND (G_VENDOR_ID <> l_pend.vendor_id OR G_NR_NF <> l_pend.NR_NF OR G_DT_NF <> l_pend.DT_NF
            OR G_ORGANIZ_ID <> l_pend.ORG_ID) THEN

             SELECT APPS.AP_INVOICES_INTERFACE_S.NEXTVAL
               INTO X_REG.INVOICE_iD
               FROM DUAL;

              G_INVOICE_ID := X_REG.INVOICE_iD;

             X_REG.Invoice_Num    := l_pend.nr_nf; --1

             --X_REG.Invoice_Type_Lookup_Code := 'STANDARD'   ; --2
             X_REG.Invoice_Type_Lookup_Code := l_pend.TIPO_NF ; --'PREPAYMENT'   ; --2
             --
             X_Reg.Invoice_Date   := l_pend.dt_nf    ; --3
             X_REG.Vendor_Id      := l_pend.Vendor_Id       ; --4
             X_REG.Vendor_Site_Id := l_pend.Vendor_Site_Id  ; --5
             X_REG.Invoice_Amount := l_pend.VL_NF; --6
             X_REG.Invoice_Currency_Code := l_pend.moeda_nf ; --7
             X_REG.EXCHANGE_RATE := l_pend.taxa;
             X_REG.EXCHANGE_RATE_TYPE := l_pend.TIPO_TAXA;
             X_REG.EXCHANGE_DATE := l_pend.DATA_TAXA;
             x_reg.terms_id := l_pend.term_id;
             --X_REG.Terms_Id    := l_pend.TERM_ID   ;--11
             --
             X_REG.Description := l_pend.DESCRICAO_NF;--12
             --
             --
             X_Reg.Source                     := l_pend.source ;--45
             --X_Reg.Payment_Method_Lookup_Code := l_inv.Payment_Method_Lookup_Code; --46 ?????
             --X_Reg.Pay_Group_Lookup_Code      := l_inv.Pay_Group_Lookup_Code     ; --47 ?????
             X_Reg.Goods_Received_Date    := l_pend.dt_nf; --48 sysdate definirem ??
             X_Reg.Invoice_Received_Date  := l_pend.dt_nf; --49 sysdate  definirem ??
             X_Reg.Gl_Date                := l_pend.gl_date; --sysdate; --50 sysdate definirem ??
             --X_REG.EXCLUSIVE_PAYMENT_FLAG := g_EXCLUSIVE_PAYMENT_FLAG; --51
             X_Reg.Org_Id      := l_pend.org_id;   --52
             X_REG.TERMS_DATE  := l_pend.DATA_BASE_VENCIMENTO;--53
             -- X_REG.PAYMENT_METHOD_CODE := '';
             --
             X_REG.CREATION_DATE    := SYSDATE; --54
             X_REG.CREATED_BY       := FND_GLOBAL.USER_ID;      --55
             X_REG.LAST_UPDATE_DATE := SYSDATE; --56
             X_REG.LAST_UPDATED_BY  := FND_GLOBAL.USER_ID;      --57
             --
             X_REG.Global_Attribute_Category := 'JL.BR.APXIISIM.INVOICES_FOLDER'; --29

             l_global_attribute1 := NULL;
             BEGIN

              SELECT Global_Attribute1
                INTO l_global_attribute1
                FROM ap_supplier_sites_all
               WHERE vendor_id = l_pend.vendor_id
                 AND vendor_site_id = l_pend.vendor_site_id
                 AND org_id = l_pend.org_id;

              EXCEPTION
               WHEN OTHERS THEN
                NULL;

             END;

             X_REG.Global_Attribute1  := l_global_attribute1;--'N';--30

             INSERT INTO Apps.Ap_Invoices_Interface VALUES X_Reg;

             G_VENDOR_ID := l_pend.vendor_id;
             G_NR_NF := l_pend.NR_NF;
             G_DT_NF := l_pend.DT_NF;
             G_ORGANIZ_ID := l_pend.ORG_ID;

          END IF;

         END IF; --IF g_cont_entr = 1 THEN

             --
             -- Item line
                 X_REG2.INVOICE_ID := G_INVOICE_ID;--X_REG.INVOICE_iD ; --01
                 --
                 SELECT APPS.AP_INVOICE_LINES_INTERFACE_S.NEXTVAL
                   INTO X_REG2.INVOICE_LINE_ID --02
                   FROM DUAL
                 ;

                X_REG2.LINE_NUMBER            := l_pend.nr_linha   ; --03
                X_REG2.LINE_TYPE_LOOKUP_CODE  := l_pend.tipo_linha; --04
                X_REG2.AMOUNT                 := l_pend.VALOR_CONTABIL; --5
                X_REG2.ACCOUNTING_DATE        := l_pend.data_contabil; -- 6 sysdate definirem
                X_REG2.DESCRIPTION            := l_pend.descricao_linha_nf; --7
--                X_REG2.DIST_CODE_CONCATENATED := l_pend.code_combination_id;  --8
                X_REG2.DIST_CODE_COMBINATION_ID := l_pend.code_combination_id;  --8
                --x_reg2.PAY_AWT_GROUP_NAME     := l_pend.PAY_AWT_GROUP_NAME;
                X_REG2.po_number := l_pend.nr_po;
                X_REG2.po_line_number := l_pend.nr_linha_po;
                X_REG2.po_shipment_num := l_pend.nr_entrega;
                X_REG2.po_distribution_num := l_pend.nr_distribuicao_po;
                X_REG2.release_num := l_pend.nr_release;
                X_REG2.org_id := l_pend.org_id;

                X_REG2.CREATION_DATE          := SYSDATE; --9
                X_REG2.CREATED_BY             := FND_GLOBAL.USER_ID;      --10
                X_REG2.LAST_UPDATE_DATE       := SYSDATE; --11
                X_REG2.LAST_UPDATED_BY        := FND_GLOBAL.USER_ID;      --12
                --
                INSERT INTO Apps.Ap_Invoice_Lines_Interface VALUES X_Reg2;
                --
                -- Tax line
                /*IF nvl(l_pend.imposto,0) <> 0 THEN
                    X_REG2 := null;
                    X_REG2.INVOICE_ID := X_REG.INVOICE_ID ; --01

                    SELECT APPS.AP_INVOICE_LINES_INTERFACE_S.NEXTVAL
                      INTO X_REG2.INVOICE_LINE_ID --02
                      FROM DUAL
                    ;

                    X_REG2.LINE_NUMBER            := '2'   ; --03
                    X_REG2.LINE_TYPE_LOOKUP_CODE  := 'MISCELLANEOUS'; --04
                    X_REG2.AMOUNT                 := -l_pend.imposto; --5
                    X_REG2.ACCOUNTING_DATE        := l_ACCOUNTING_DATE; -- 6 sysdate definirem
                    X_REG2.DESCRIPTION            := 'CARGA'; --7
                    X_REG2.DIST_CODE_COMBINATION_ID := l_pend.code_combination_id;  --8
                    X_REG2.CREATION_DATE    := SYSDATE; --9
                    X_REG2.CREATED_BY       := -1;      --10
                    X_REG2.LAST_UPDATE_DATE := SYSDATE; --11
                    X_REG2.LAST_UPDATED_BY  := -1;      --12
                    --
                    INSERT INTO Apps.Ap_Invoice_Lines_Interface VALUES X_Reg2;
                END IF;*/
                updst('P','Inserido na Open Interface');
         --
         end if;

    END carregar_itf;

    procedure upddb is
    begin
        update xxstn.XXSTN_AP_INVOICES_INTERFACE
           set status  = l_pend.status
              ,mensagem_status = l_pend.mensagem_status
              ,last_update_date = sysdate
              ,last_updated_by  = fnd_global.user_id
              ,vendor_id        = l_pend.vendor_id
              ,vendor_site_id   = l_pend.vendor_site_id
              ,org_id              = l_pend.org_id
              ,code_combination_id = l_pend.code_combination_id
              ,term_id             = l_pend.term_id
              ,last_update_login   = l_login_id
         where rowid = l_pend.xid;
    end upddb;
    --
    procedure print_saida(p_status in varchar ) is
      l_first BOOLEAN := true;
    BEGIN
        PRINT_O(' ');
        OPEN c_sts(p_status);
        LOOP
        FETCH C_STS INTO L_STS;
        EXIT WHEN C_STS%NOTFOUND;
            IF l_first = true THEN
                l_first := false;
                if p_status = 'P' then
                    PRINT_O(' Notas Inseridas na Open Interface do Payables ');
                    PRINT_O(' ============================================= ');
                elsif p_Status = 'E' Then
                    PRINT_O(' Notas Com erro na validacao.');
                    PRINT_O(' ============================================= ');
                end if;
                --
                PRINT_O(rpad('CNPJ' ,15,' ') || ' '
                      ||rpad('NF  ' ,10,' ') || ' '
                      ||rpad('VCTO' ,10,' ') || ' '
                      ||rpad('Valor',10,' ') || ' '
                      ||rpad('Mensagem',50,' ')
                );
                PRINT_O(rpad('-',15,'-') || ' '
                      ||rpad('-',10,'-') || ' '
                      ||rpad('-',10,'-') || ' '
                      ||rpad('-',10,'-') || ' '
                      ||rpad('-',50,'-')
                );
            END IF;
            --
            PRINT_O(rpad(l_sts.CNPJ,15    ,' ') || ' '
                  ||rpad(l_sts.nr_nf,10,' ') || ' '
                  ||rpad(to_char(l_sts.DATA_BASE_VENCIMENTO,G_DT_FMT),10,' ') || ' '
                  --||rpad(l_sts.due_amount,10, ' ') || ' '
                  ||l_sts.mensagem_status
            );
            --
        END LOOP;
        CLOSE C_STS;
    end print_saida;
    --
  BEGIN
    --
    OPEN C_PEND;
    LOOP
    FETCH C_PEND INTO L_PEND;
    EXIT WHEN C_PEND%NOTFOUND;
        --
        IF l_pend.nr_nf IS NULL THEN
         updst('E','Numero Nota Fiscal nao informado');
        END IF;

        IF l_pend.dt_nf IS NULL THEN
         updst('E','Data da Nota Fiscal nao informada');
        END IF;

        IF l_pend.vl_nf IS NULL THEN
         updst('E','Valor da Nota Fiscal nao informada');
        END IF;

        IF l_pend.local_fornecedor IS NULL THEN
         updst('E','Nome do Local Fornecedor nao informado');
        END IF;

        IF l_pend.nr_fornecedor IS NULL THEN
         updst('E','Numero Fornecedor nao informado');
        END IF;

        IF l_pend.condicao_pagto IS NULL THEN
         updst('E','Condicao de Pagamento nao informada');
        END IF;

        IF l_pend.data_base_vencimento IS NULL THEN
         updst('E','Data Base da Nota Fiscal nao informada');
        END IF;

        IF l_pend.nr_linha IS NULL THEN
         updst('E','Nenhuma linha da Nota Fiscal Identificada');
        END IF;

        IF l_pend.tipo_linha IS NULL THEN
         updst('E','Nenhum Tipo de Linha Identificado');
        END IF;

        l_linha_dup := 0;
        BEGIN

         SELECT COUNT(*)
           INTO l_linha_dup
           FROM XXSTN_AP_INVOICES_INTERFACE P
          WHERE STATUS = 'N'
            AND FILE_NAME = l_pend.FILE_NAME
            AND NR_LINHA = l_pend.nr_linha
            AND NR_NF = l_pend.nr_NF;

         EXCEPTION
          WHEN OTHERS THEN
           l_linha_dup := 0;

        END;

        IF l_linha_dup > 1 THEN
         updst('E','Numero de Linha Duplicada. Valores duplicados para um numero de linha de fatura existem para esta Nota Fiscal');
        END IF;

        IF l_pend.data_contabil IS NULL THEN
         updst('E','Data Contabil da Nota Fiscal nao informada');
        END IF;

        IF l_pend.nr_po IS NOT NULL AND (l_pend.nr_linha_po IS NULL OR l_pend.NR_ENTREGA IS NULL OR l_pend.NR_DISTRIBUICAO_PO IS NULL) THEN
         updst('E','Quando da utilizacao da PO, todos campos relacionados(Numero da PO/Numero Linha PO/Numero Entrega/Numero distribuicao contabil) devem ser informados');
        END IF;

        IF l_pend.nr_linha_po IS NOT NULL AND (l_pend.nr_po IS NULL OR l_pend.NR_ENTREGA IS NULL OR l_pend.NR_DISTRIBUICAO_PO IS NULL) THEN
         updst('E','Quando da utilizacao da PO, todos campos relacionados(Numero da PO/Numero Linha PO/Numero Entrega/Numero distribuicao contabil) devem ser informados');
        END IF;

        IF l_pend.NR_ENTREGA IS NOT NULL AND (l_pend.nr_linha_po IS NULL OR l_pend.nr_po IS NULL OR l_pend.NR_DISTRIBUICAO_PO IS NULL) THEN
         updst('E','Quando da utilizacao da PO, todos campos relacionados(Numero da PO/Numero Linha PO/Numero Entrega/Numero distribuicao contabil) devem ser informados');
        END IF;

        IF l_pend.NR_DISTRIBUICAO_PO IS NOT NULL AND (l_pend.nr_linha_po IS NULL OR l_pend.NR_ENTREGA IS NULL OR l_pend.nr_po IS NULL) THEN
         updst('E','Quando da utilizacao da PO, todos campos relacionados(Numero da PO/Numero Linha PO/Numero Entrega/Numero distribuicao contabil) devem ser informados');
        END IF;

        if get_Org_id (l_pend.unid_oper, l_pend.org_id) = false then
            updst('E','Empresa nao encontrada');
        end if;
        --
        g_org_id := l_pend.org_id;
        --
        if get_Vendor ( l_pend.nr_fornecedor ,l_pend.Org_Id,l_pend.local_fornecedor,l_pend.vendor_id ,l_pend.vendor_Site_id ) = false then
           updst('E','Fornecedor nao encontrado');
        end if;
        --
        --
        if l_pend.condicao_pagto is not null then
            if find_term_id = false then
               updst('E','Condicao de Pagamento Nao Encontrada');
            end if;
        end if;

        IF l_pend.nr_po IS NOT NULL AND l_pend.combinacao_contabil IS NOT NULL THEN
         updst('E','Campo Combinacao Contabil nao pode ser informada quando informado dados da PO');
        END IF;

        IF l_pend.nr_po IS NULL AND l_pend.combinacao_contabil IS NULL THEN
         updst('E','Campo Combinacao Contabil nao informado');
        END IF;

        if l_pend.status = 'N' AND l_pend.nr_po IS NULL AND l_pend.combinacao_contabil IS NOT NULL then
            if find_ccid = false then
               updst('E','Combinacao Contabil nao encontrada');
            end if;
        end if;
        -- Atualiza os campos da interface.
        if l_pend.status = 'N' then
            carregar_itf;
        end if;
        upddb;
        --
    END LOOP;
    CLOSE c_pend;
    --
    -- IMPRIME SAIDA
    --
    print_saida('P');-- REGISTROS INSERIDOS NA INTERFACE
    PRINT_SAIDA('E');-- REGISTROS COM ERRO NA INTERFACE
    --
    REL_ERROS_CARGA;
    --
    EXCEPTION
     WHEN OTHERS THEN
      PRINT_L('...Erro inesperado no processo CARREGA_DADOS: '||SQLERRM);
      RETCODE := 2;

  END CARREGA_DADOS;
  --
  PROCEDURE REL_ERROS_CARGA IS
  --
  l_responsibility_id  NUMBER;
  l_application_id     NUMBER;
  l_user_id            NUMBER;
  l_request_id         NUMBER;
  l_layout             BOOLEAN;
  --
  BEGIN
    --
    select distinct fr.responsibility_id
         , frx.application_id
      into l_responsibility_id
         , l_application_id
      from apps.fnd_responsibility frx,
           apps.fnd_responsibility_tl fr
     where 1 = 1
       and frx.responsibility_id = nvl(fnd_profile.value('resp_id'),51339)
       and fr.responsibility_id = frx.responsibility_id;
    --
    --fnd_file.put_line(fnd_file.log,'l_responsibility_id/l_application_id: '||l_responsibility_id||'/'||l_application_id);
    --
     select user_id 
       into l_user_id 
       from apps.fnd_user 
      where user_id = nvl(fnd_profile.value('user_id'),6148);
    --
    --fnd_file.put_line(fnd_file.log,'l_user_id: '||l_user_id);
    --      
    --
    --To set environment context.
    --
    apps.fnd_global.apps_initialize (l_user_id,l_responsibility_id,l_application_id);
    --
    --Setting Layout for the Request
    --
    l_layout := apps.fnd_request.add_layout(
                              template_appl_name => 'XXBK',
                              template_code      => 'XXSTN_AP_CARGA_NOTA_REL',
                              template_language  => 'pt',
                              template_territory => 'BR',
                              output_format      => 'EXCEL');
    --
    --
    --Submitting Concurrent Request
    --
    l_request_id := fnd_request.submit_request (application   => 'XXBK', 
                                                program       => 'XXSTN_AP_CARGA_NOTA_REL', 
                                                description   => 'STONE (BRL) - AP Relatorio de erros carga de arquivo notas fiscais', 
                                                start_time    => sysdate, 
                                                sub_request   => FALSE);
    --
    commit;
    --
    if l_request_id = 0 then
       fnd_file.put_line(fnd_file.log,'Concurrent request failed to submit');
    else
       fnd_file.put_line(fnd_file.log,'Successfully Submitted the Concurrent Request');
    end if;
  --
  exception
    when others then
      fnd_file.put_line(fnd_file.log,'Error While Submitting Concurrent Request '||TO_CHAR(SQLCODE)||'-'||SQLERRM);
   --
  END REL_ERROS_CARGA;
  --  
END XXSTN_AP_CARGA_NOTA_PKG;
/

EXIT; 
