﻿----------------------------------------------------------------------------
-- +====================================================================+ --
-- |                              TRI-CS                                | --
-- |                   Todos os direitos reservados                     | --
-- +====================================================================+ --
-- |  # Codigo:    XXCOC_22583_01                                       | --
-- |  # Descrição: Integração Oracle x Comlink                          | --
-- |  # Versão:    4.0                                                  | --
-- |  # Data:      28/05/2020                                           | --
-- |  # Autor:     Marcelo Pacheco                                      | --
-- +====================================================================+ --

----------------------------------------------------------------------------
###### 1. Pré-Instalação:                                             ######
----------------------------------------------------------------------------

  1.1) Substituir a senha do APPS nos comandos necessários de acordo com o ambiente.

----------------------------------------------------------------------------
###### 2. Instalação:                                                 ######
----------------------------------------------------------------------------
  2.1) Execute os comandos abaixo no UNIX:

     2.1.1) Copie o arquivo XXCOC_22583_01.zip para $APPL_TOP/patches.

     2.1.2) Execute os comandos abaixo para descompactar o patch

        cd $APPL_TOP/patches
        unzip XXCOC_22583_01.zip

     2.1.3) Verifique se os diretorios já estão criados

        $XXCOC_TOP/admin/sql/

     2.1.4) Criar backup

		# Backup Package
			
			cp $XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb       $XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb_20200528
	 
	 2.1.5) Execute os comandos abaixo para copiar os arquivos
		
		# Copia Package
        cd $APPL_TOP/patches/XXCOC_22583_01
		cp -f xxclk/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb $XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb

     2.1.6) Execute os comandos abaixo para compilar os objetos

        # Executando o export da linguagem
        export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"

        # Execucao Package
        sqlplus apps/$appspassword  @$XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb


---------------------------------------------------------------------------
###### 3. Plan action for backup restore (Only perform this step If the above installation causes problems in the production environment.) ######
---------------------------------------------------------------------------
	# Package
		cp -f $XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb_15042020     $XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb
	
	# Executando o export da linguagem
        export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"

	# Execucao Package
	sqlplus apps/$appspassword  @$XXCOC_TOP/admin/sql/XXCLK_PO_INTERFACE_PKG.pkb
