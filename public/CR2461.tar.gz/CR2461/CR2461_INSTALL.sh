#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2461_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2461
# |
# | HISTORY
# |   02-JUN-20  Petrocelli, Ariel Alejandro
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2461_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2461_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2461
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/sql/TRG
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2461" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2461_9494.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2461"
AddAllLogs $CROUT "FND" "CR2461_9494.ldt"
mv CR2461_9494.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AGRONOMO_EAM_INT " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AGRONOMO_EAM_INT','ADECO_BI','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AGRONOMO_EAM_INT* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AGRONOMO_EAM_OC_INT " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AGRONOMO_EAM_OC_INT','ADECO_BI','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AGRONOMO_EAM_OC_INT* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AGRONOMO_EAM_INV_INT " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AGRONOMO_EAM_INV_INT','ADECO_BI','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AGRONOMO_EAM_INV_INT* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AGRONOMO_EAM_OCI_INT " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AGRONOMO_EAM_OCI_INT','ADECO_BI','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AGRONOMO_EAM_OCI_INT* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TRG XX_PO_RECEP_AUTOM_LABORES_TR " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TRG','XX_PO_RECEP_AUTOM_LABORES_TR','APPS','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_PO_RECEP_AUTOM_LABORES_TR* $DOWNDBDIR/xbol/12.0.0/sql/TRG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_AGRONOMO_EAM_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_AGRONOMO_EAM_PKG','APPS','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AGRONOMO_EAM_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_PO_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_PO_REPORTES_PKG','APPS','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_PO_REPORTES_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OPM_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OPM_REPORTES_PKG','APPS','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_REPORTES_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_EAM_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_EAM_REPORTES_PKG','APPS','$PATCHDIR','CR2461');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_EAM_REPORTES_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXEAMAGRONOMO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXEAMAGRONOMO.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXEAMAGRONOMO"
AddAllLogs $CROUT "FND" "XXEAMAGRONOMO.ldt"
mv XXEAMAGRONOMO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXEAMAGRONOMOOCI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXEAMAGRONOMOOCI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXEAMAGRONOMOOCI"
AddAllLogs $CROUT "FND" "XXEAMAGRONOMOOCI.ldt"
mv XXEAMAGRONOMOOCI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXEAMREPOWOAGRO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXEAMREPOWOAGRO.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXEAMREPOWOAGRO"
AddAllLogs $CROUT "FND" "XXEAMREPOWOAGRO.ldt"
mv XXEAMREPOWOAGRO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXINVAGRONOAJU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXINVAGRONOAJU.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXINVAGRONOAJU"
AddAllLogs $CROUT "FND" "XXINVAGRONOAJU.ldt"
mv XXINVAGRONOAJU.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXPOAGRONOOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXPOAGRONOOC.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXPOAGRONOOC"
AddAllLogs $CROUT "FND" "XXPOAGRONOOC.ldt"
mv XXPOAGRONOOC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXPOAGRONOOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXPOAGRONOOC.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXPOAGRONOOC"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXPOAGRONOOC \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXPOAGRONOOC_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXPOAGRONOOC.ldt"
mv XXPOAGRONOOC* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXINVAGRONOAJU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXINVAGRONOAJU.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXINVAGRONOAJU"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXINVAGRONOAJU \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXINVAGRONOAJU_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXINVAGRONOAJU.ldt"
mv XXINVAGRONOAJU* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXEAMREPOWOAGRO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXEAMREPOWOAGRO.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXEAMREPOWOAGRO"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXEAMREPOWOAGRO \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXEAMREPOWOAGRO_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXEAMREPOWOAGRO.ldt"
mv XXEAMREPOWOAGRO* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_AGRONOMO_EAM_INT " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INT >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INT.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INT.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INT.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_AGRONOMO_EAM_OC_INT " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OC_INT >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OC_INT.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OC_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OC_INT.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OC_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OC_INT.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_AGRONOMO_EAM_INV_INT " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INV_INT >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INV_INT.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INV_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INV_INT.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INV_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_INV_INT.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_AGRONOMO_EAM_OCI_INT " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OCI_INT >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OCI_INT.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OCI_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OCI_INT.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OCI_INT.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_AGRONOMO_EAM_OCI_INT.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TRG XX_PO_RECEP_AUTOM_LABORES_TR " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TRG/XX_PO_RECEP_AUTOM_LABORES_TR >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG/XX_PO_RECEP_AUTOM_LABORES_TR.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TRG/XX_PO_RECEP_AUTOM_LABORES_TR.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG/XX_PO_RECEP_AUTOM_LABORES_TR.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TRG/XX_PO_RECEP_AUTOM_LABORES_TR.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG/XX_PO_RECEP_AUTOM_LABORES_TR.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_AGRONOMO_EAM_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_AGRONOMO_EAM_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AGRONOMO_EAM_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_AGRONOMO_EAM_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AGRONOMO_EAM_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_AGRONOMO_EAM_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_AGRONOMO_EAM_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_PO_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_PO_REPORTES_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_PO_REPORTES_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_PO_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_PO_REPORTES_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_PO_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_PO_REPORTES_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_OPM_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_REPORTES_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_REPORTES_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_REPORTES_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_REPORTES_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_EAM_REPORTES_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_EAM_REPORTES_PKG >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_EAM_REPORTES_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_EAM_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_EAM_REPORTES_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_EAM_REPORTES_PKG.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_EAM_REPORTES_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXEAMAGRONOMO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMAGRONOMO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMAGRONOMO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMAGRONOMO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMAGRONOMO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXEAMAGRONOMOOCI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMAGRONOMOOCI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMAGRONOMOOCI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMAGRONOMOOCI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMAGRONOMOOCI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMAGRONOMOOCI.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXEAMREPOWOAGRO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMREPOWOAGRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OPM GMF Request Group' 
              ,group_application   => 'GMF') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMREPOWOAGRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OPM GMF Request Group' 
              ,group_application   => 'GMF'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMREPOWOAGRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMREPOWOAGRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXEAMREPOWOAGRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXEAMREPOWOAGRO' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXEAMREPOWOAGRO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXINVAGRONOAJU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GME' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GME' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR Consulta GMI' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR Consulta GMI' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OPM GMF Request Group' 
              ,group_application   => 'GMF') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OPM GMF Request Group' 
              ,group_application   => 'GMF'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXINVAGRONOAJU' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXINVAGRONOAJU.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXPOAGRONOOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'All Reports' 
              ,group_application   => 'PO') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'All Reports' 
              ,group_application   => 'PO'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OPM GMF Request Group' 
              ,group_application   => 'GMF') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OPM GMF Request Group' 
              ,group_application   => 'GMF'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX TCG Programador' 
              ,group_application   => 'GMA'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPOAGRONOOC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'EAM_REPORTS' 
              ,group_application   => 'EAM'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPOAGRONOOC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXPOAGRONOOC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXPOAGRONOOC \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE XLS \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC_es_AR.xls  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXPOAGRONOOC_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC_es_AR.xls &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC_es_AR.xls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC_es_AR.xls >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC_es_AR.xls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPOAGRONOOC_es_AR.xls -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXINVAGRONOAJU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXINVAGRONOAJU \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE XLS \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU_es_AR.xls  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXINVAGRONOAJU_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU_es_AR.xls &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU_es_AR.xls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU_es_AR.xls >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU_es_AR.xls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXINVAGRONOAJU_es_AR.xls -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXEAMREPOWOAGRO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXEAMREPOWOAGRO \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE XLS \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO_es_AR.xls  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXEAMREPOWOAGRO_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO_es_AR.xls &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO_es_AR.xls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO_es_AR.xls >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO_es_AR.xls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXEAMREPOWOAGRO_es_AR.xls -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch









. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2461" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2461_9494.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2461_9494.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
