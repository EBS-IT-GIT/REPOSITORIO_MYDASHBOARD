  set define off;

  CREATE OR REPLACE TRIGGER "APPS"."XX_PO_RECEP_AUTOM_LABORES_TR" 
/*=======================================================================+
 |  Copyright (c) 2008 Oracle Corporation, Buenos Aires, Argentina       |
 |                         All rights reserved.                          |
 +=======================================================================+
 |                                                                       |
 | FILENAME                                                              |
 |     XX_PO_RECEP_AUTOM_LABORES_TR.sql                                  |
 |                                                                       |
 | DESCRIPTION                                                           |
 |    Verifica si existe aprobador adicional para la OC cuando es        |
 |    aprobada.                                                          |
 |    Si existe, procesa la recepcion automatica de labores.             |
 |                                                                       |
 | SOURCE CONTROL                                                        |
 |     $Author: SBanchieri                                               |
 |     $Revision: 1                                                      |
 |     $Date: 23-May-2012                                                |
 |                                                                       |
 *=======================================================================*/
AFTER UPDATE OF approved_flag ON  PO.PO_HEADERS_ALL#  FOR EACH ROW
  WHEN ( OLD.approved_flag != 'Y' AND
       NEW.approved_flag  = 'Y' AND
       NVL(NEW.cancel_flag,'N') = 'N' AND
       NEW.document_creation_method = 'PDOI'
      ) DECLARE
  v_pkg_name                    VARCHAR2(2000) := 'xx_po_recep_autom_labores_tr';

  v_labores_lines               NUMBER;
  v_pais_po                     VARCHAR2(1);

  v_empleado                    NUMBER;
  v_nombre                      VARCHAR2(4000);
  v_puesto                      NUMBER;
  v_jerarquia                   NUMBER;

  v_grupo_aprobacion            NUMBER;

  v_jerarquia_hab               VARCHAR2(1) := 'N';

  v_control_rule_id             NUMBER;
  v_amount_limit                NUMBER;

  v_segundo_aprobador           VARCHAR2(1) := 'N';
  v_segundo_aprobador_id        NUMBER;

  v_sid                         NUMBER;

  v_initialization              BOOLEAN := TRUE;

  v_default_approval_path_id    NUMBER; --R12

  -- Cursor de empleados que reenviaron la OC (Exceptuando al creador)
  CURSOR c_po_aprobadores ( p_po_header_id  IN  NUMBER,
                            p_revision_num  IN  NUMBER ) IS
    SELECT pah.employee_id AS empleado,
           pah.employee_name AS nombre,
           poeh.employee_position_id AS puesto,
           poeh.position_structure_id AS jerarquia
      FROM po_action_history_v pah,
           po_employee_hierarchies poeh
     WHERE pah.object_id = p_po_header_id
       AND pah.object_type_code = 'PO'
       AND(pah.action_code = 'FORWARD'
       --R12 : start
       OR (pah.action_code IN ( 'APPROVE', 'APPROVE AND FORWARD')
       AND pah.sequence_num < ( SELECT max(pah2.sequence_num)
                                  FROM po_action_history_v pah2
                                 WHERE pah2.object_id = p_po_header_id
                                   AND pah2.object_type_code = 'PO'
                                   AND pah2.object_revision_num = p_revision_num
                                   AND pah2.action_code IN ( 'APPROVE', 'APPROVE AND FORWARD'))))
       --R12 : end
       AND pah.object_revision_num = p_revision_num
       AND pah.employee_id != ( SELECT DISTINCT pah2.employee_id
                                  FROM po_action_history_v pah2
                                 WHERE pah2.object_id = p_po_header_id
                                   AND pah2.object_type_code = 'PO'
                                   AND pah2.object_revision_num = 0
                                   AND(pah2.sequence_num = 0
                                    OR pah2.sequence_num = 1)        --R12
                                   AND pah2.action_code = 'SUBMIT' ) --R12
       AND pah.employee_id = poeh.employee_id
       AND NVL(pah.approval_path_id, v_default_approval_path_id) = poeh.position_structure_id(+) --R12
    GROUP BY pah.employee_id,
             pah.employee_name,
             pah.sequence_num,
             poeh.position_structure_id,
             poeh.employee_position_id
    ORDER BY pah.sequence_num DESC;

  -- Cursor para actualizar la tabla xx_po_aprob_autom_lab con la regla
  -- de aprobacion para cada linea
  CURSOR c_laborales_regla ( p_sid  IN  NUMBER ) IS
    SELECT xpral.sid,
           xpral.po_line_id,
           xpral.line_type,
           xpral.line_total,
           xpral.category
      FROM xx_po_aprob_autom_lab xpral
     WHERE xpral.sid = p_sid;

  -- Variables para la recepcion automatica
  v_request_id                  NUMBER;
  v_user_id                     NUMBER := -1;

  v_headers_interface_s         NUMBER;
  v_interface_groups_s          NUMBER;
  v_transactions_interface_s    NUMBER;


  v_vendor_name                 po_vendors.vendor_name%TYPE;
  v_shipment_num                po_line_locations_all.shipment_num%TYPE;

  v_phase                       VARCHAR2(100);
  v_status                      VARCHAR2(100);
  v_dev_phase                   VARCHAR2(100);
  v_dev_status                  VARCHAR2(100);
  v_cnc_message                 VARCHAR2(100);

  v_boolean                     BOOLEAN;
  v_finished                    BOOLEAN;

  v_roi_error_count             NUMBER;
  v_roi_error_message           VARCHAR2(2000);

  v_lines_exists                VARCHAR2(1) := 'N';

  v_sr_user_id                  NUMBER := 2070;
  v_sr_resp_id                  NUMBER;
  v_sr_resp_appl_id             NUMBER := 201;

  -- Cursor para enviar las lineas laborales a la interface de recepcion de OC
  CURSOR c_po_lines_laborales IS
    SELECT pl.po_header_id,
           pl.item_id,
           pl.category_id,
           pl.po_line_id,
           pll.quantity - pll.quantity_received AS quantity,
           pl.unit_meas_lookup_code,
           muom.uom_code,
           mp.organization_code,
           pll.line_location_id,
           pda.destination_type_code,
           pda.deliver_to_person_id,
           pda.deliver_to_location_id,
           --NVL(pda.destination_subinventory,msi.secondary_inventory_name) AS destination_subinventory,
           ( SELECT DISTINCT ih.subinventario
             FROM xx_agronomo_interface_oc ih
                , xx_agronomo_interface_oc_linea il
             WHERE 1=1
             AND il.orden_trabajo = ih.orden_trabajo
             AND il.po_header_id  = pl.po_header_id
           ) AS destination_subinventory,
           mil.inventory_location_id AS locator_id,
           pda.po_distribution_id
      FROM po_lines_all            pl
         , po_line_locations_all   pll
         , po_distributions_all    pda
         , mtl_categories_b        mc
         , mtl_categories_b_dfv    mc_dfv
         , mtl_parameters          mp
         , mtl_item_locations      mil
         , mtl_units_of_measure_tl muom
     WHERE 1=1
     AND pl.po_header_id = :NEW.po_header_id
     AND pll.po_line_id  = pl.po_line_id
     AND pda.line_location_id = pll.line_location_id
     AND mp.organization_id   = pll.ship_to_organization_id
     AND muom.unit_of_measure = pl.unit_meas_lookup_code
     AND mc.category_id  = pl.category_id
     AND mc_dfv.row_id   = mc.rowid
     AND mil.organization_id(+) = mp.organization_id
     --
     AND NVL(pl.cancel_flag,'N') = 'N'
     AND (pll.quantity - pll.quantity_received) > 0
     AND muom.language = 'US'
     AND mil.attribute_category (+) = 'Recepcion Automatica'
     AND mil.attribute1 (+) = 'Y'
     AND mc_dfv.recepcion_automatica = 'Y'
       ;

  TYPE cabecera IS RECORD ( category_id           po_lines_all.category_id%TYPE,
                            header_interface_id   rcv_headers_interface.header_interface_id%TYPE,
                            group_id              rcv_headers_interface.group_id%TYPE );

  TYPE cabeceras IS TABLE OF cabecera INDEX BY BINARY_INTEGER;

  pl_cabeceras cabeceras;

  PROCEDURE apps_initialize IS PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    fnd_global.apps_initialize(user_id => v_sr_user_id,
                               resp_id => v_sr_resp_id,
                               resp_appl_id => v_sr_resp_appl_id);
    COMMIT;
  END apps_initialize;

BEGIN
  -- Se obtiene el session id de la sesion
  SELECT SYS_CONTEXT('USERENV','SID')
  INTO v_sid
  FROM dual;

  -- Si el pais asociado a la organizacion de la OC es Argentina,
  -- significa que pertenece a Argentina o Uruguay
  SELECT DECODE(hl.address_style,'Argentina (Internacional)','Y', 'Uruguay (Internacional)', 'Y', 'N')
         -- DECODE(hl.address_style,'Argentina (Internacional)','Y','N')
  INTO v_pais_po
  FROM hr_organization_units_v hou,
       -- Comentado SBanchieri 17/07/2012
       -- hr_locations_v hl
       -- Se reemplaza la vista por este query porque la misma usa userenv('LANG')
       -- Fin Comentado SBanchieri 17/07/2012
       ( SELECT l.location_id,
                fnd.descriptive_flex_context_name address_style
         FROM hr_locations_all l,
              fnd_descr_flex_contexts_tl fnd
         WHERE l.style = fnd.descriptive_flex_context_code(+)
         AND fnd.application_id(+) = 800
         AND fnd.descriptive_flexfield_name(+) = 'Address Location'
         AND fnd.LANGUAGE(+) = 'ESA' ) hl
  WHERE hou.organization_id = :NEW.org_id
  AND hou.location_id = hl.location_id;

  -- Se recuperan las lineas de labores de la OC
  -- y se agrega una linea con el calculo del total
  INSERT INTO xx_po_aprob_autom_lab
         (sid,
          po_line_id,
          line_type,
          line_total,
          category)
  SELECT v_sid,
         pl.po_line_id,
         'LINE',
         pl.unit_price * pl.quantity,
         mc.segment1 || '.' || mc.segment2 || '.' || mc.segment3
  FROM po_lines_all          pl
     , mtl_categories_b      mc
     , mtl_categories_b_dfv  mc_dfv
  WHERE pl.po_header_id = :NEW.po_header_id
  AND mc.category_id = pl.category_id
  AND mc_dfv.row_id  = mc.rowid
  AND NVL(pl.cancel_flag,'N') = 'N'
  --AND mc.segment1 = '34'
  AND mc_dfv.recepcion_automatica = 'Y'
  UNION
  SELECT v_sid,
         -1,
         'TOTAL',
         SUM(pl.unit_price * pl.quantity),
         NULL
  FROM po_lines_all          pl
     , mtl_categories_b      mc
     , mtl_categories_b_dfv  mc_dfv
  WHERE pl.po_header_id = :NEW.po_header_id
  AND mc.category_id = pl.category_id
  AND mc_dfv.row_id  = mc.rowid
  AND NVL(pl.cancel_flag,'N') = 'N'
  --AND mc.segment1 = '34'
  AND mc_dfv.recepcion_automatica = 'Y'
  ;

  -- Se obtiene la cantidad de lineas insertadas en la tabla
  SELECT COUNT(1)
  INTO v_labores_lines
  FROM xx_po_aprob_autom_lab;

  -- Si la cantidad es mayor que 1, existe la linea de total y al menos otra linea.
  -- Y si el pais es Argentina o Uruguay.
  -- Se procesa.
  IF ( v_labores_lines > 1 AND v_pais_po = 'Y' ) THEN

    -- Se recupera el resp_id correspondiente al org_id de la oc
    BEGIN

      SELECT meaning
      INTO v_sr_resp_id
      FROM fnd_lookup_values
      WHERE lookup_type = 'XX_ORG_RESP'
      AND language = 'ESA'
      AND NVL(enabled_flag,'N') = 'Y'
      AND lookup_code = :NEW.org_id;
    EXCEPTION
      WHEN OTHERS THEN
        v_initialization := FALSE;

    END;

    -- Si se pudo recuperar la resp_id
    IF ( v_initialization ) THEN

      -- Inicializacion
      BEGIN
        /* Se detect? ORA-04092: no se puede SET NLS en un disparador
        fnd_global.apps_initialize(user_id => v_sr_user_id,
                                   resp_id => v_sr_resp_id,
                                   resp_appl_id => v_sr_resp_appl_id);*/
        apps_initialize;
      END;

      --R12 : start
      BEGIN
        SELECT podt.default_approval_path_id
        INTO v_default_approval_path_id
        FROM po_document_types_all podt
        WHERE podt.document_type_code = DECODE(:NEW.type_lookup_code,
                                               'STANDARD', 'PO',
                                               'PLANNED', 'PO',
                                               'BLANKET', 'PA',
                                               'CONTRACT', 'PA', NULL)
        AND podt.document_subtype = :NEW.type_lookup_code
        AND podt.org_id = :NEW.org_id;
      EXCEPTION
        WHEN OTHERS THEN
          v_default_approval_path_id := NULL;
      END;

      --R12 : end
      -- Se abre el cursor de aprobadores
      OPEN c_po_aprobadores(:NEW.po_header_id,:NEW.revision_num);

      FETCH c_po_aprobadores INTO v_empleado,
                                  v_nombre,
                                  v_puesto,
                                  v_jerarquia;

      WHILE ( c_po_aprobadores%FOUND AND v_segundo_aprobador = 'N' ) LOOP

        -- Se limpian los campos de regla de aprobacion en la tabla
        UPDATE xx_po_aprob_autom_lab xpral
        SET xpral.control_rule_id = NULL,
            xpral.rule_amount_limit = NULL;

        v_grupo_aprobacion := NULL;

        -- Se verifica si la jerarquia de aprobacion esta habilitada para el documento
        -- de orden de compra
        SELECT DECODE(COUNT(1),0,'N','Y')
        INTO v_jerarquia_hab
        FROM po_document_types_v pdt
        WHERE pdt.document_type_code = 'PO'
        AND pdt.document_subtype = 'STANDARD'
        AND pdt.default_approval_path_id = v_jerarquia;

        -- La jerarquia de aprobacion esta habilitada para el documento OC
        IF ( v_jerarquia_hab = 'Y' ) THEN
          BEGIN
            -- Se obtiene el grupo de aprobacion para el puesto del empleado y
            -- el tipo de documento OC
            BEGIN
              SELECT ppc.control_group_id
              INTO v_grupo_aprobacion
              FROM po_position_controls ppc,
                   po_control_functions pcf
              WHERE ppc.position_id = v_puesto
              AND ppc.control_function_id = pcf.control_function_id
              AND pcf.action_type_code = 'APPROVE'
              AND pcf.enabled_flag = 'Y'
              AND pcf.document_subtype = 'STANDARD'
              AND pcf.control_function_name = 'Approve Standard Purchase Orders'
              AND ppc.end_date IS NULL
              GROUP BY ppc.control_group_id;

            EXCEPTION
              WHEN OTHERS THEN
                v_grupo_aprobacion := NULL;
            END;

            IF ( v_grupo_aprobacion IS NOT NULL ) THEN
              -- Se recorre el cursor de Lineas de labores de la OC
              FOR c_lr IN c_laborales_regla ( v_sid ) LOOP
                -- Se distingue el procesamiento entre categorias y el total
                IF ( c_lr.line_type != 'TOTAL' ) THEN
                  -- Se recupera la regla de aprobacion y su limite para la categoria
                  BEGIN
                    SELECT pcr.control_rule_id,
                           pcr.amount_limit
                    INTO v_control_rule_id,
                         v_amount_limit
                    FROM po_control_rules pcr
                    WHERE pcr.control_group_id = v_grupo_aprobacion
                    AND pcr.object_code != 'DOCUMENT_TOTAL'
                    AND c_lr.category BETWEEN pcr.segment1_low || '.' || pcr.segment2_low || '.' || pcr.segment3_low
                                          AND pcr.segment1_high || '.' || pcr.segment2_high || '.' || pcr.segment3_high;
                  EXCEPTION
                    WHEN OTHERS THEN
                      v_control_rule_id := NULL;
                      v_amount_limit    := NULL;
                  END;
                ELSE
                  BEGIN
                    -- Se recupera la regla de aprobacion y su limite para el total
                    SELECT pcr.control_rule_id,
                           pcr.amount_limit
                    INTO v_control_rule_id,
                         v_amount_limit
                    FROM po_control_rules pcr
                    WHERE pcr.control_group_id = v_grupo_aprobacion
                    AND pcr.object_code = 'DOCUMENT_TOTAL';
                  EXCEPTION
                    WHEN OTHERS THEN
                      v_control_rule_id := NULL;
                      v_amount_limit    := NULL;

                  END;
                END IF;

                IF ( v_control_rule_id IS NOT NULL AND v_amount_limit IS NOT NULL ) THEN
                  -- Se le asigna la regla de aprobacion a la categoria
                  UPDATE xx_po_aprob_autom_lab xpral
                  SET xpral.control_rule_id = v_control_rule_id,
                      rule_amount_limit = v_amount_limit
                  WHERE xpral.sid = v_sid
                  AND xpral.po_line_id = c_lr.po_line_id;
                END IF;

              END LOOP;

              SELECT DECODE(COUNT(1),0,'N','Y')
              INTO v_segundo_aprobador
              FROM ( -- Verifica cuantas lineas quedaron bien asociadas a su regla y
                     -- si los limites son mayores a 0
                     SELECT COUNT(1) cantidad
                     FROM xx_po_aprob_autom_lab xpral
                     WHERE xpral.sid = v_sid
                     AND xpral.control_rule_id IS NOT NULL
                     AND NVL(xpral.rule_amount_limit,0) > 0 ) a
              WHERE a.cantidad = v_labores_lines;
              -- Solo se tiene en cuenta si las lineas correctas en cantidad es igual a todas las lineas
              -- Si una linea queda sin regla, no es aprobador

              IF ( v_segundo_aprobador = 'Y' ) THEN
                v_segundo_aprobador_id := v_empleado;
              END IF;

            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;

        END IF;

        IF ( v_segundo_aprobador = 'N' ) THEN
          FETCH c_po_aprobadores INTO v_empleado,
                                      v_nombre,
                                      v_puesto,
                                      v_jerarquia;
        END IF;

      END LOOP;

      -- Se cierra el cursor de aprobadores
      CLOSE c_po_aprobadores;

      -- Se comprueba si existe un segundo aprobador, en tal caso se procede
      -- a la recepcion automatica de la OC
      -- Caso contrario no se hace nada

      --IF ( v_segundo_aprobador = 'Y' ) THEN --SD1721
        -- Se crea una cabecera por cada category de linea,
        -- para permitir la recepci?n de l?as de env?con organizaciones de destino m?ltiples en misma cabecera de recibo
        SELECT DISTINCT pl.category_id,
               NULL,
               NULL
        BULK COLLECT INTO pl_cabeceras
        FROM po_lines_all            pl
           , po_line_locations_all   pll
           , po_distributions_all    pda
           , mtl_categories_b        mc
           , mtl_categories_b_dfv    mc_dfv
           , mtl_parameters          mp
           , mtl_item_locations      mil
           , mtl_units_of_measure_tl muom
           --mtl_secondary_inventories_fk_v msi
        WHERE 1=1
        AND pl.po_header_id = :NEW.po_header_id
        AND pll.po_line_id  = pl.po_line_id
        AND pda.line_location_id = pll.line_location_id
        AND mp.organization_id   = pll.ship_to_organization_id
        AND muom.unit_of_measure = pl.unit_meas_lookup_code
        AND mc.category_id  = pl.category_id
        AND mc_dfv.row_id   = mc.rowid
        AND mil.organization_id(+) = mp.organization_id
        --
        AND NVL(pl.cancel_flag,'N') = 'N'
        AND (pll.quantity - pll.quantity_received) > 0
        --AND mc.segment1 = '34'
        AND muom.language = 'US'
        AND mil.attribute_category (+) = 'Recepcion Automatica'
        AND mil.attribute1 (+) = 'Y'
        AND mc_dfv.recepcion_automatica = 'Y'
        ;

        -- Se crean tantas cabeceras como categorias existan
        FOR i IN pl_cabeceras.FIRST .. pl_cabeceras.LAST LOOP
          -- Se le asignan valores de las secuencias a cada una de las cabeceras
          -- para cada una de las categorias

          SELECT rcv_headers_interface_s.NEXTVAL,
                 rcv_interface_groups_s.NEXTVAL
          INTO pl_cabeceras(i).header_interface_id,
               pl_cabeceras(i).group_id
          FROM DUAL;

          -- Se inserta la cabecera en la tabla de la interface
          INSERT INTO rcv_headers_interface
          (header_interface_id,
           group_id,
           processing_status_code,
           receipt_source_code,
           transaction_type,
           auto_transact_code,
           last_update_date,
           last_updated_by,
           last_update_login,
           creation_date,
           created_by,
           vendor_id,
           expected_receipt_date,
           validation_flag)
          SELECT pl_cabeceras(i).header_interface_id,
                 pl_cabeceras(i).group_id,
                 'PENDING',
                 'VENDOR',
                 'NEW',
                 'RECEIVE',
                 SYSDATE,
                 v_user_id,
                 v_user_id,
                 SYSDATE,
                 v_user_id,
                 :NEW.vendor_id,
                 SYSDATE,
                 'Y'
            FROM DUAL;

        END LOOP;

        -- Se insertan las lineas de labores correspondientes a la OC
        FOR c_lines IN c_po_lines_laborales LOOP
          SELECT rcv_transactions_interface_s.NEXTVAL
          INTO v_transactions_interface_s
          FROM DUAL;

          -- Se recuperan los valores de las secuencias de la cabecera que corresponda a la categoria de la linea
          FOR i IN pl_cabeceras.FIRST .. pl_cabeceras.LAST LOOP

            IF ( c_lines.category_id = pl_cabeceras(i).category_id ) THEN
              v_headers_interface_s := pl_cabeceras(i).header_interface_id;
              v_interface_groups_s  := pl_cabeceras(i).group_id;
            END IF;

          END LOOP;

          INSERT INTO rcv_transactions_interface
          (interface_transaction_id,
           group_id,
           last_update_date,
           last_updated_by,
           creation_date,
           created_by,
           last_update_login,
           transaction_type,
           transaction_date,
           processing_status_code,
           processing_mode_code,
           transaction_status_code,
           po_header_id,
           po_line_id,
           item_id,
           category_id,
           quantity,
           primary_quantity,
           unit_of_measure,
           primary_unit_of_measure,
           uom_code,
           po_line_location_id,
           auto_transact_code,
           receipt_source_code,
           to_organization_code,
           source_document_code,
           document_num,
           destination_type_code,
           deliver_to_person_id,
           deliver_to_location_id,
           subinventory,
           locator_id,
           header_interface_id,
           po_distribution_id,
           validation_flag)
          SELECT v_transactions_interface_s,
                 v_interface_groups_s,
                 SYSDATE,
                 v_user_id,
                 SYSDATE,
                 v_user_id,
                 v_user_id,
                 'RECEIVE',
                 SYSDATE,
                 'PENDING',
                 'BATCH',
                 'PENDING',
                 c_lines.po_header_id,
                 c_lines.po_line_id,
                 c_lines.item_id,
                 c_lines.category_id,
                 c_lines.quantity,
                 c_lines.quantity,
                 c_lines.unit_meas_lookup_code,
                 c_lines.unit_meas_lookup_code,
                 c_lines.uom_code,
                 c_lines.line_location_id,
                 'DELIVER',
                 'VENDOR',
                 c_lines.organization_code,
                 'PO',
                 :NEW.segment1,
                 c_lines.destination_type_code,
                 c_lines.deliver_to_person_id,
                 NVL(c_lines.deliver_to_location_id,:NEW.ship_to_location_id),
                 c_lines.destination_subinventory,
                 c_lines.locator_id,
                 v_headers_interface_s,
                 c_lines.po_distribution_id,
                 'Y'
          FROM dual;

          v_lines_exists := 'Y';

        END LOOP;

        -- Si se recuperan lineas a recibir
        IF ( v_lines_exists = 'Y' ) THEN

          -- Se ejecuta el concurrente de recepcion por cada group id
          FOR i IN pl_cabeceras.FIRST .. pl_cabeceras.LAST LOOP

            -- Se llama a esta funcion debido a que estamos dentro de un trigger
            v_boolean := FND_REQUEST.SET_MODE(TRUE);

            -- Se ejecuta el concurrente de recepcion
            v_request_id := FND_REQUEST.SUBMIT_REQUEST (application => 'PO',
                                                        program     => 'RVCTP',
                                                        description => NULL,
                                                        start_time  => NULL,
                                                        sub_request => FALSE,
                                                        argument1   => 'BATCH',
                                                        argument2   => pl_cabeceras(i).group_id);

          END LOOP;

        END IF;

      --END IF;

      -- Se inserta en el log la OC y su status de aprobacion
      INSERT INTO xx_po_aprob_autom_lab_log
             (po_header_id,
              po_header_number,
              po_revision_num,
              po_approver_id,
              process_date,
              status)
      VALUES (:NEW.po_header_id,
              :NEW.segment1,
              :NEW.revision_num,
              v_segundo_aprobador_id,
              SYSDATE,
              DECODE(v_segundo_aprobador,'Y','APROBADA','NO APROBADA'));

    END IF;

  END IF;

  DELETE xx_po_aprob_autom_lab xpral
  WHERE xpral.sid = v_sid;

  EXCEPTION
    WHEN OTHERS THEN

      -- Si el cursor quedo abierto se cierra
      IF c_po_aprobadores%ISOPEN THEN

        CLOSE c_po_aprobadores;

      END IF;

      xx_debug_aux_pk.debug(NULL,1,'PO',SUBSTRB('XX_PO_RECEP_AUTOM_LABORES_TR [po_header_id:'||:NEW.po_header_id||'] - '||sys.dbms_utility.format_error_stack()||sys.dbms_utility.format_error_backtrace(),1,4000),NULL,NULL,NULL);

      INSERT INTO xx_po_aprob_autom_lab_log
             (po_header_id,
              po_header_number,
              po_revision_num,
              po_approver_id,
              process_date,
              status)
      VALUES (:NEW.po_header_id,
              :NEW.segment1,
              :NEW.revision_num,
              v_segundo_aprobador_id,
              SYSDATE,
              'ERROR');

      DELETE xx_po_aprob_autom_lab xpral
      WHERE xpral.sid = v_sid;

  END xx_po_recep_autom_labores_tr;
/
ALTER TRIGGER "APPS"."XX_PO_RECEP_AUTOM_LABORES_TR" ENABLE;

exit
