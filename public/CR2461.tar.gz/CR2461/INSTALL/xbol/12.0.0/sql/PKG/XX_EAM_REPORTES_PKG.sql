  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_EAM_REPORTES_PKG" AS

  PROCEDURE WO_Agronomo ( errbuf               IN OUT NOCOPY VARCHAR2
                        , retcode              IN OUT NOCOPY VARCHAR2
                        , p_org_id             NUMBER
                        , p_organization_id    NUMBER
                        , p_fecha_desde        VARCHAR2
                        , p_fecha_hasta        VARCHAR2
                        );

END XX_EAM_REPORTES_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_EAM_REPORTES_PKG" AS

  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);


  PROCEDURE WO_Agronomo ( errbuf               IN OUT NOCOPY VARCHAR2
                        , retcode              IN OUT NOCOPY VARCHAR2
                        , p_org_id             NUMBER
                        , p_organization_id    NUMBER
                        , p_fecha_desde        VARCHAR2
                        , p_fecha_hasta        VARCHAR2
                        ) IS
    CURSOR c1 IS

      SELECT DISTINCT
             ai.servicio
           , wo.wip_entity_name
           , ai.identificador         activo
           , ai.fecha_inicio
           , ai.fecha_fin
           , od.operating_unit
           , ou.name                  operating_unit_name
           , od.organization_code     organizacion_codigo
           , ai.importado_flag
           , ai.completado_flag       finalizado_flag
           , ai.mensaje_error
           , ai.creation_date
           , ai.last_update_date
           , (SELECT COUNT(1)
              FROM xx_agronomo_eam_oc_int aoi
              WHERE aoi.servicio = ai.servicio
              AND aoi.importado_flag = 'E'
             ) cantidad_oc_error
           , (SELECT COUNT(1)
              FROM xx_agronomo_eam_inv_int aii
              WHERE aii.servicio = ai.servicio
              AND aii.importado_flag = 'E'
             ) cantidad_inv_error
      FROM xx_agronomo_eam_int          ai
         , eam_work_orders_v            wo
         , org_organization_definitions od
         , hr_operating_units           ou
      WHERE 1=1
      AND wo.wip_entity_id    = ai.wip_entity_id
      AND od.organization_id  = ai.organizacion_id
      AND ou.organization_id  = od.operating_unit
      AND od.operating_unit    = NVL(p_org_id, od.operating_unit)
      AND od.organization_id   = NVL(p_organization_id, od.organization_id)
      AND ( p_fecha_desde IS NULL OR
            TRUNC(ai.fecha_inicio) >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(ai.fecha_inicio) <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      ORDER BY 1
      ;

    l_ou_name             VARCHAR2(250);
    l_organization_name   VARCHAR2(250);
    l_calendar_desc       VARCHAR2(150);
    l_fecha_desde         DATE;
    l_fecha_hasta         DATE;
    l_cantidad            NUMBER;

    l_error_msg           VARCHAR2(2000);
  BEGIN
    FND_FILE.Put_Line(FND_FILE.LOG, '------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_operating_unit:  '||p_org_id);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_organization_id: '||p_organization_id);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_fecha_desde:     '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_fecha_hasta:     '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.LOG, '------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.LOG, ' ');

    BEGIN
      SELECT name
      INTO l_ou_name
      FROM hr_operating_units
      WHERE 1=1
      AND organization_id = p_org_id;
    EXCEPTION
      WHEN OTHERS THEN
        FND_FILE.Put_Line(FND_FILE.LOG, 'Error obteniendo nombre del unidad operativa.');
    END;

    IF p_organization_id IS NOT NULL THEN
      BEGIN
        SELECT organization_name
        INTO l_organization_name
        FROM org_organization_definitions
        WHERE 1=1
        AND organization_id = p_organization_id;
      EXCEPTION
        WHEN OTHERS THEN
          FND_FILE.Put_Line(FND_FILE.LOG, 'Error obteniendo nombre de la organización.');
      END;
    END IF;

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXEAMREPOWOAGRO>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX EAM Reporte Pedidos de Trabajo Interfaz Agronomo</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_OU>'||l_ou_name||'</P_OU>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ORG>'||l_organization_name||'</P_ORG>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>'||TO_CHAR(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FEHCA_HASTA>'||TO_CHAR(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY')||'</P_FEHCA_HASTA>');

    FOR r1 IN c1 LOOP
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <SERVICIO>'||r1.SERVICIO||'</SERVICIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <WIP_ENTITY_NAME>'||r1.WIP_ENTITY_NAME||'</WIP_ENTITY_NAME>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_INICIO>'||TO_CHAR(r1.FECHA_INICIO, 'DD-MM-YYYY')||'</FECHA_INICIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_FIN>'||TO_CHAR(r1.FECHA_FIN, 'DD-MM-YYYY')||'</FECHA_FIN>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <OPERATING_UNIT_NAME>'||r1.OPERATING_UNIT_NAME||'</OPERATING_UNIT_NAME>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORGANIZACION_CODIGO>'||r1.ORGANIZACION_CODIGO||'</ORGANIZACION_CODIGO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ACTIVO>'||XX_UTIL_PK.xml_escape_chars(r1.ACTIVO)||'</ACTIVO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <IMPORTADO_FLAG>'||r1.IMPORTADO_FLAG||'</IMPORTADO_FLAG>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FINALIZADO_FLAG>'||r1.FINALIZADO_FLAG||'</FINALIZADO_FLAG>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <MENSAJE_ERROR>'||r1.MENSAJE_ERROR||'</MENSAJE_ERROR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <QTY_OC_ERROR>'||r1.CANTIDAD_OC_ERROR||'</QTY_OC_ERROR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <QTY_INV_ERROR>'||r1.CANTIDAD_INV_ERROR||'</QTY_INV_ERROR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CREATION_DATE>'||TO_CHAR(r1.CREATION_DATE, 'DD-MM-YYYY HH24:MI')||'</CREATION_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LAST_UPDATE_DATE>'||TO_CHAR(r1.LAST_UPDATE_DATE, 'DD-MM-YYYY HH24:MI')||'</LAST_UPDATE_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXEAMREPOWOAGRO>');

  EXCEPTION
    WHEN OTHERS THEN
      errbuf  := SQLERRM;
      retcode := 2;
  END WO_Agronomo;

END XX_EAM_REPORTES_PKG;
/

exit
