  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_REPORTES_PKG" AS

  PROCEDURE planilla_siglea ( errbuf               IN OUT NOCOPY VARCHAR2
                            , retcode              IN OUT NOCOPY VARCHAR2
                            , p_fecha_desde        IN VARCHAR2
                            , p_fecha_hasta        IN VARCHAR2
                            , p_item_id            IN NUMBER
                            , p_vendor_id          IN NUMBER
                            , p_org_id             IN NUMBER
                            , p_po_header_id       IN NUMBER
                            , p_po_line_id         IN NUMBER
                            , p_ship_header_id     IN NUMBER
                            , p_temperatura_flag   IN VARCHAR2
                            );

  PROCEDURE Agronomo_OC ( errbuf               IN OUT NOCOPY VARCHAR2
                        , retcode              IN OUT NOCOPY VARCHAR2
                        , p_org_id             NUMBER
                        , p_organization_id    NUMBER
                        , p_fecha_desde        VARCHAR2
                        , p_fecha_hasta        VARCHAR2
                        );

END XX_PO_REPORTES_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_REPORTES_PKG" AS

  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);


  FUNCTION xml_escape_chars ( p_data VARCHAR2 ) RETURN VARCHAR IS
    l_data VARCHAR2(32767);
  BEGIN
    l_data := REPLACE(REPLACE(REPLACE(p_data, '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
    RETURN l_data;
  END xml_escape_chars;

  PROCEDURE planilla_siglea ( errbuf               IN OUT NOCOPY VARCHAR2
                            , retcode              IN OUT NOCOPY VARCHAR2
                            , p_fecha_desde        IN VARCHAR2
                            , p_fecha_hasta        IN VARCHAR2
                            , p_item_id            IN NUMBER
                            , p_vendor_id          IN NUMBER
                            , p_org_id             IN NUMBER
                            , p_po_header_id       IN NUMBER
                            , p_po_line_id         IN NUMBER
                            , p_ship_header_id     IN NUMBER
                            , p_temperatura_flag   IN VARCHAR2
                            ) IS
/*
    CURSOR cNoTemp IS

      SELECT ou.organization_id
           , ou.name organization_name
           , ou_dfv.xx_planta_siglea
           , s.vendor_id
           , s.vendor_name
           , ph.po_header_id
           , ph.segment1 oc_number
           , ph.comments
           , pl.po_line_id
           , pl.line_num
           , rsl.item_id
           , rsh.shipment_header_id
           , rsh.receipt_num
           , TRUNC (rsh.shipped_date) transaction_date
           , rsh.shipped_date transaction_datetime
           , rsh.packing_slip
           , TO_NUMBER (REPLACE (REPLACE (rsh.packing_slip, 'R', ''), '-', '') || pl.line_num) constancia
           , SUM(rsl.quantity_received) quantity_received
      FROM rcv_shipment_headers  rsh
         , rcv_shipment_lines    rsl
         , ap_suppliers          s
         , po_lines_all          pl
         , po_headers_all        ph
         , hr_all_organization_units     ou
         , hr_all_organization_units_dfv ou_dfv
      WHERE 1=1
      AND rsl.shipment_header_id = rsh.shipment_header_id
      AND s.vendor_id            = rsh.vendor_id
      AND pl.po_line_id          = rsl.po_line_id
      AND ph.po_header_id        = pl.po_header_id
      AND ou.organization_id     = rsl.to_organization_id
      AND ou_dfv.row_id          = ou.rowid
      AND NOT EXISTS
         (SELECT 1
          FROM  po_asl_attributes asl
          WHERE  1 = 1
          AND asl.vendor_id = ph.vendor_id
          AND asl.vendor_site_id = ph.vendor_site_id
          AND asl.item_id = pl.item_id
          AND asl.item_id = 25231670        -- Leche Cruda
         )
      AND rsh.shipment_header_id = 68204242
      --and TRUNC (rsh.shipped_date) between '05-MAY-19' and '05-MAY-19'
      --and ph.po_header_id = 5313608
      ----and lt.lot_num in (310155, 310168)
      -- PARAMS
      AND TRUNC (rsh.shipped_date) BETWEEN  FND_DATE.CANONICAL_TO_DATE(p_fecha_desde) AND FND_DATE.CANONICAL_TO_DATE(p_fecha_hasta)
      AND rsl.item_id            = NVL(p_item_id, rsl.item_id)
      AND rsh.vendor_id          = NVL(p_vendor_id, rsh.vendor_id)
      AND rsl.to_organization_id = NVL(p_org_id, rsl.to_organization_id)
      AND pl.po_header_id        = NVL(p_po_header_id, pl.po_header_id)
      AND rsl.po_line_id         = NVL(p_po_line_id, rsl.po_line_id)
      AND rsh.shipment_header_id = NVL(p_ship_header_id, rsh.shipment_header_id)
      GROUP BY ou.organization_id
             , ou.name
             , ou_dfv.xx_planta_siglea
             , s.vendor_id
             , s.vendor_name
             , ph.po_header_id
             , ph.segment1
             , ph.comments
             , pl.po_line_id
             , pl.line_num
             , rsl.item_id
             , rsh.shipment_header_id
             , rsh.receipt_num
             , TRUNC (rsh.shipped_date)
             , rsh.shipped_date
             , rsh.packing_slip
             , TO_NUMBER (REPLACE (REPLACE (rsh.packing_slip, 'R', ''), '-', '') || pl.line_num)
      ORDER BY transaction_date
             , oc_number
             , receipt_num
             , packing_slip
             , line_num;
*/
    CURSOR c1 IS

      SELECT ou.organization_id
           , ou.name organization_name
           , ou_dfv.xx_planta_siglea
           , s.vendor_id
           , s.vendor_name
           , ph.po_header_id
           , ph.segment1 oc_number
           , ph.comments
           , pl.po_line_id
           , pl.line_num
           , rsl.item_id
           /* CR1395 Reporte Siglea y Liquidaciones de Leche -- Inicio */
           --, rsh.shipment_header_id
           , LISTAGG(rsl.shipment_line_id, ' - ') WITHIN GROUP (ORDER BY rsl.shipment_line_id) shipment_line_id
           , LISTAGG(rt.transaction_id, ' - ') WITHIN GROUP (ORDER BY rt.transaction_id) transaction_id
           , LISTAGG(rsh.receipt_num, ' - ') WITHIN GROUP (ORDER BY rsh.receipt_num) receipt_num
           , MAX(TRUNC (rt.transaction_date)) transaction_date
           , MAX(rt.transaction_date) transaction_datetime
           /* CR1395 Reporte Siglea y Liquidaciones de Leche -- Fin */
           , rsh.packing_slip
           , TO_NUMBER (REPLACE (REPLACE (rsh.packing_slip, 'R', ''), '-', '') || pl.line_num) constancia
           , SUM(rsl.quantity_received) quantity_received
      FROM rcv_shipment_headers  rsh
         , rcv_shipment_lines    rsl
         , ap_suppliers          s
         , po_lines_all          pl
         , po_headers_all        ph
         , hr_all_organization_units     ou
         , hr_all_organization_units_dfv ou_dfv
         , rcv_transactions      rt
      WHERE 1=1
      AND rsl.shipment_header_id = rsh.shipment_header_id
      AND s.vendor_id            = rsh.vendor_id
      AND pl.po_line_id          = rsl.po_line_id
      AND ph.po_header_id        = pl.po_header_id
      AND ou.organization_id     = rt.organization_id
      AND ou_dfv.row_id          = ou.rowid
      AND rt.shipment_line_id    = rsl.shipment_line_id
      AND rt.transaction_type    = 'RECEIVE'
      AND rsl.quantity_received != 0
      AND NOT EXISTS
         (SELECT 1
          FROM  po_asl_attributes asl
          WHERE  1 = 1
          AND asl.vendor_id = ph.vendor_id
          AND asl.vendor_site_id = ph.vendor_site_id
          AND asl.item_id = pl.item_id
          AND asl.item_id = 25231670        /* Leche Cruda */
         )
      --AND rsh.shipment_header_id = 68204242
      --and TRUNC (rsh.shipped_date) between '05-MAY-19' and '05-MAY-19'
      --and ph.po_header_id = 5313608
      ----and lt.lot_num in (310155, 310168)
      -- PARAMS
      AND TRUNC (rt.transaction_date) BETWEEN  FND_DATE.CANONICAL_TO_DATE(p_fecha_desde) AND FND_DATE.CANONICAL_TO_DATE(p_fecha_hasta)
      AND rsl.item_id            = NVL(p_item_id, rsl.item_id)
      AND rsh.vendor_id          = NVL(p_vendor_id, rsh.vendor_id)
      AND rt.organization_id = NVL(p_org_id, rt.organization_id)
      AND pl.po_header_id        = NVL(p_po_header_id, pl.po_header_id)
      AND rsl.po_line_id         = NVL(p_po_line_id, rsl.po_line_id)
      AND rsh.shipment_header_id = NVL(p_ship_header_id, rsh.shipment_header_id)
      GROUP BY ou.organization_id
             , ou.name
             , ou_dfv.xx_planta_siglea
             , s.vendor_id
             , s.vendor_name
             , ph.po_header_id
             , ph.segment1
             , ph.comments
             , pl.po_line_id
             , pl.line_num
             , rsl.item_id
             /* CR1395 Reporte Siglea y Liquidaciones de Leche -- Inicio */
             --, rsh.shipment_header_id
             --, rsl.shipment_line_id
             --, rt.transaction_id
             --, rsh.receipt_num
             --, TRUNC (rt.transaction_date)
             --, rt.transaction_date
             /* CR1395 Reporte Siglea y Liquidaciones de Leche -- Fin */
             , rsh.packing_slip
             , TO_NUMBER (REPLACE (REPLACE (rsh.packing_slip, 'R', ''), '-', '') || pl.line_num)
      ORDER BY organization_id
             , po_header_id
             --, shipment_header_id
             , transaction_date
             --, oc_number
             --, receipt_num
             --, packing_slip
             --, line_num
             ;

    l_item_desc           VARCHAR2(250);
    l_vendor_desc         VARCHAR2(250);
    l_org_desc            VARCHAR2(250);
    l_oc_desc             VARCHAR2(250);
    l_oc_line_desc        VARCHAR2(250);
    l_ship_header_desc    VARCHAR2(250);
    l_temperatura         NUMBER:=0;

    l_organization_id     NUMBER;
    l_po_header_id        NUMBER;
    l_po_line_id          NUMBER;
    l_shipment_header_id  NUMBER;
    l_shipment_line_id    VARCHAR2(250);
    l_qty_rcv             NUMBER;
    l_rc                  NUMBER;
    l_prom_temp           NUMBER;

    eTemp                 EXCEPTION;
  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '-----------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX PO Papel de Trabajo SIGLEA');
    FND_FILE.Put_Line(FND_FILE.Log, '-----------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_desde:    '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_hasta:    '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_item_id:        '||p_item_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_vendor_id:      '||p_vendor_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_org_id:         '||p_org_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_po_header_id:   '||p_po_header_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_po_line_id:     '||p_po_line_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_ship_header_id: '||p_ship_header_id);

    --Significado Params--
    IF p_item_id IS NOT NULL THEN
      SELECT segment1||' - '||description
      INTO l_item_desc
      FROM mtl_system_items
      WHERE organization_id = 135
      AND inventory_item_id = p_item_id;
    END IF;

    IF p_vendor_id IS NOT NULL THEN
      SELECT vendor_name
      INTO l_vendor_desc
      FROM ap_suppliers
      WHERE vendor_id = p_vendor_id;
    END IF;

    IF p_org_id IS NOT NULL THEN
      SELECT name
      INTO l_org_desc
      FROM hr_all_organization_units
      WHERE organization_id = p_org_id;
    END IF;

    IF p_po_header_id IS NOT NULL THEN
      SELECT segment1
      INTO l_oc_desc
      FROM po_headers_all
      WHERE po_header_id = p_po_header_id;
    END IF;

    IF p_po_line_id IS NOT NULL THEN
      SELECT line_num
      INTO l_oc_line_desc
      FROM po_lines_all
      WHERE po_line_id = p_po_line_id;
    END IF;

    IF p_ship_header_id IS NOT NULL THEN
      SELECT packing_slip
      INTO l_ship_header_desc
      FROM rcv_shipment_headers
      WHERE shipment_header_id = p_ship_header_id;
    END IF;

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXPOPTSIGLEA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX PO Planilla SIGLEA</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||TO_CHAR(SYSDATE, 'RRRR-MM-DD HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>'||REPLACE(SUBSTR(p_fecha_desde,1,10),'/','-')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_HASTA>'||REPLACE(SUBSTR(p_fecha_hasta,1,10),'/','-')||'</P_FECHA_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ITEM_ID>'||l_item_desc||'</P_ITEM_ID>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_VENDOR_ID>'||l_vendor_desc||'</P_VENDOR_ID>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ORG_ID>'||l_org_desc||'</P_ORG_ID>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PO_HEADER_ID>'||l_oc_desc||'</P_PO_HEADER_ID>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PO_LINE_ID>'||l_oc_line_desc||'</P_PO_LINE_ID>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_SHIP_HEADER_ID>'||l_ship_header_desc||'</P_SHIP_HEADER_ID>');


    FOR r1 IN c1 LOOP
      IF p_temperatura_flag = 'Y' THEN
        BEGIN
          SELECT gr.result_value_num
          INTO l_temperatura
          FROM rcv_lot_transactions  lt
             , gmd_samples           gs
             , gmd_results           gr
          WHERE 1=1
          AND lt.shipment_line_id    = r1.shipment_line_id
          AND lt.transaction_id      = r1.transaction_id
          AND gs.lot_number          = lt.lot_num
          AND gs.receipt_line_id     = lt.shipment_line_id
          AND gr.sample_id           = gs.sample_id
          AND gr.test_id             = 43                           -- Temperatura
          AND gr.result_value_num    IS NOT NULL;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            errbuf := 'Se encontraron recepciones sin mediciones de temperatura. OC '||r1.oc_number||' '||'Recepción '||r1.receipt_num||' Constancia '||r1.constancia;
            RAISE eTemp;
          WHEN TOO_MANY_ROWS THEN
            errbuf := 'Se encontraron múltiples lecturas de temperatura. OC '||r1.oc_number||' '||'Recepción '||r1.receipt_num||' Constancia '||r1.constancia;
            RAISE eTemp;
        END;
      ELSE
        l_temperatura := 0;
      END IF;

     --[(Litros 1 * temp 1) + (Litros 2 * temp 2) + (Litros N * temp n)] / cantidad total de litros entregados

      IF c1%ROWCOUNT = 1 THEN
        l_organization_id     := r1.organization_id;
        l_po_header_id        := r1.po_header_id;
        --l_po_line_id          := r1.po_line_id;
        --l_shipment_header_id  := r1.shipment_header_id;
        l_shipment_line_id    := r1.shipment_line_id;
        l_qty_rcv             := r1.quantity_received;
        l_rc                  := 1;
        l_prom_temp           := r1.quantity_received * l_temperatura;

        FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <DEPOSITO_RECEPCION>'||r1.organization_name||'</DEPOSITO_RECEPCION>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <PLANTA_SIGLEA>'||r1.xx_planta_siglea||'</PLANTA_SIGLEA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <PROVEEDOR>'||xml_escape_chars(r1.vendor_name)||'</PROVEEDOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <OC_NUMBER>'||r1.oc_number||'</OC_NUMBER>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <COMMENTS>'||xml_escape_chars(r1.comments)||'</COMMENTS>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <LINE_NUM>'||r1.line_num||'</LINE_NUM>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <RECEIPT_NUM>'||r1.receipt_num||'</RECEIPT_NUM>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSACTION_DATE>'||TO_CHAR(r1.transaction_datetime, 'RRRR-MM-DD')||'</TRANSACTION_DATE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSACTION_TIME>'||TO_CHAR(r1.transaction_datetime, 'HH24:MI:SS')||'</TRANSACTION_TIME>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <REMITO>'||r1.packing_slip||'</REMITO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <CONSTANCIA>'||r1.constancia||'</CONSTANCIA>');

      ELSE
        IF l_organization_id    = r1.organization_id    AND
           l_po_header_id       = r1.po_header_id       AND
           --l_po_line_id         = r1.po_line_id         AND
           --l_shipment_header_id = r1.shipment_header_id AND
           l_shipment_line_id = r1.shipment_line_id   THEN
             l_qty_rcv   := l_qty_rcv + r1.quantity_received;
             l_rc        := l_rc + 1;
             l_prom_temp := l_prom_temp + (r1.quantity_received * l_temperatura);
        ELSE
          FND_FILE.Put_Line(FND_FILE.Output, '    <QUANTITY_RECEIVED>'||l_qty_rcv||'</QUANTITY_RECEIVED>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <TEMPERATURA>'||ROUND(l_prom_temp/l_rc, 2)||'</TEMPERATURA>');
          FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');

          FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <DEPOSITO_RECEPCION>'||r1.organization_name||'</DEPOSITO_RECEPCION>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <PLANTA_SIGLEA>'||r1.xx_planta_siglea||'</PLANTA_SIGLEA>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <PROVEEDOR>'||xml_escape_chars(r1.vendor_name)||'</PROVEEDOR>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <OC_NUMBER>'||r1.oc_number||'</OC_NUMBER>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <COMMENTS>'||xml_escape_chars(r1.comments)||'</COMMENTS>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <LINE_NUM>'||r1.line_num||'</LINE_NUM>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <RECEIPT_NUM>'||r1.receipt_num||'</RECEIPT_NUM>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSACTION_DATE>'||TO_CHAR(r1.transaction_datetime, 'RRRR-MM-DD')||'</TRANSACTION_DATE>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSACTION_TIME>'||TO_CHAR(r1.transaction_datetime, 'HH24:MI:SS')||'</TRANSACTION_TIME>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <REMITO>'||r1.packing_slip||'</REMITO>');
          FND_FILE.Put_Line(FND_FILE.Output, '    <CONSTANCIA>'||r1.constancia||'</CONSTANCIA>');
          --FND_FILE.Put_Line(FND_FILE.Output, '    <QUANTITY_RECEIVED>'||l_qty_rcv||'</QUANTITY_RECEIVED>');
          --FND_FILE.Put_Line(FND_FILE.Output, '    <TEMPERATURA>'||ROUND(l_prom_temp/l_rc, 2)||'</TEMPERATURA>');
          --FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');

          l_organization_id     := r1.organization_id;
          l_po_header_id        := r1.po_header_id;
          --l_po_line_id          := r1.po_line_id;
          --l_shipment_header_id  := r1.shipment_header_id;
          l_shipment_line_id    := r1.shipment_line_id;
          l_qty_rcv             := r1.quantity_received;
          l_rc                  := 1;
          l_prom_temp           := r1.quantity_received * l_temperatura;
        END IF;

      END IF;
/*
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DEPOSITO_RECEPCION>'||r1.organization_name||'</DEPOSITO_RECEPCION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PLANTA_SIGLEA>'||r1.xx_planta_siglea||'</PLANTA_SIGLEA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PROVEEDOR>'||xml_escape_chars(r1.vendor_name)||'</PROVEEDOR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <OC_NUMBER>'||r1.oc_number||'</OC_NUMBER>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <COMMENTS>'||xml_escape_chars(r1.comments)||'</COMMENTS>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LINE_NUM>'||r1.line_num||'</LINE_NUM>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <RECEIPT_NUM>'||r1.receipt_num||'</RECEIPT_NUM>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSACTION_DATE>'||TO_CHAR(r1.transaction_datetime, 'RRRR-MM-DD')||'</TRANSACTION_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TRANSACTION_TIME>'||TO_CHAR(r1.transaction_datetime, 'HH24:MI:SS')||'</TRANSACTION_TIME>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <REMITO>'||r1.packing_slip||'</REMITO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CONSTANCIA>'||r1.constancia||'</CONSTANCIA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <QUANTITY_RECEIVED>'||r1.quantity_received||'</QUANTITY_RECEIVED>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TEMPERATURA>'||l_temperatura||'</TEMPERATURA>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
*/
    END LOOP;

    FND_FILE.Put_Line(FND_FILE.Output, '    <QUANTITY_RECEIVED>'||l_qty_rcv||'</QUANTITY_RECEIVED>');
    FND_FILE.Put_Line(FND_FILE.Output, '    <TEMPERATURA>'||ROUND(l_prom_temp/l_rc, 2)||'</TEMPERATURA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');

    FND_FILE.Put_Line(FND_FILE.Output, '</XXPOPTSIGLEA>');
  EXCEPTION
    WHEN eTemp THEN
      retcode := 2;
  END planilla_siglea;


  PROCEDURE Agronomo_OC ( errbuf               IN OUT NOCOPY VARCHAR2
                        , retcode              IN OUT NOCOPY VARCHAR2
                        , p_org_id             NUMBER
                        , p_organization_id    NUMBER
                        , p_fecha_desde        VARCHAR2
                        , p_fecha_hasta        VARCHAR2
                        ) IS

    CURSOR c1 IS

      SELECT DISTINCT
             'Agricultura' origen
           , ih.orden_trabajo
           , (SELECT DISTINCT ph.segment1
              FROM po_headers_all ph
              WHERE 1=1
              AND ph.po_header_id = il.po_header_id
             ) orden_compra
           , ih.orden_trabajo_fecha
           , il.fecha_labor
           , il.fecha_certificacion fecha_certifica
           , od.operating_unit, ou.name operating_unit_name
           , ih.organizacion_codigo
           , ih.subinventario
           , ih.direccion_envio
           , ih.direccion_facturacion
           , s.vendor_name             proveedor
           , (SELECT DISTINCT p.full_name
              FROM per_all_people_f p
              WHERE p.person_id = ih.comprador_id
             ) comprador
           , il.importado_flag
           , il.mensaje_error
           , il.creation_date
           , il.last_update_date
      FROM xx_agronomo_interface_oc       ih
         , xx_agronomo_interface_oc_linea il
         , org_organization_definitions   od
         , hr_operating_units             ou
         , ap_suppliers                   s
      WHERE 1=1
      AND il.orden_trabajo     = ih.orden_trabajo
      AND s.vendor_id          = ih.proveedor_id
      AND od.organization_code = ih.organizacion_codigo
      AND ou.organization_id   = od.operating_unit
      AND od.operating_unit    = NVL(p_org_id, od.operating_unit)
      AND od.organization_id   = NVL(p_organization_id, od.organization_id)
      AND ( p_fecha_desde IS NULL OR
            TRUNC(NVL(ih.fecha_certificacion, ih.orden_trabajo_fecha)) >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(NVL(ih.fecha_certificacion, ih.orden_trabajo_fecha)) <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      UNION
      SELECT DISTINCT
             'EAM Servicios' origen
           , ih.servicio
           , (SELECT DISTINCT ph.segment1
              FROM po_headers_all ph
              WHERE 1=1
              AND ph.po_header_id = il.po_header_id
             ) orden_compra
           , ih.fecha_inicio
           , NULL fecha_labor
           , NULL fecha_certifica
           , od.operating_unit, ou.name operating_unit_name
           , od.organization_code
           , NULL                      subinventario
           , ih.direccion_envio
           , ih.direccion_facturacion
           , s.vendor_name             proveedor
           , (SELECT DISTINCT p.full_name
              FROM per_all_people_f p
              WHERE p.person_id = ih.comprador_id
             ) comprador
           , il.importado_flag
           , il.mensaje_error
           , il.creation_date
           , il.last_update_date
      FROM xx_agronomo_eam_int            ih
         , xx_agronomo_eam_oc_int         il
         , org_organization_definitions   od
         , hr_operating_units             ou
         , ap_suppliers                   s
      WHERE 1=1
      AND il.servicio        = ih.servicio
      AND s.vendor_id        = il.proveedor_id
      AND od.organization_id = ih.organizacion_id
      AND ou.organization_id = od.operating_unit
      AND od.operating_unit    = NVL(p_org_id, od.operating_unit)
      AND od.organization_id   = NVL(p_organization_id, od.organization_id)
      AND ( p_fecha_desde IS NULL OR
            TRUNC(ih.fecha_inicio) >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(ih.fecha_inicio) <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      UNION
      SELECT DISTINCT
             'EAM Insumos' origen
           , oi.insumo_oc_id
           , (SELECT DISTINCT ph.segment1
              FROM po_headers_all ph
              WHERE 1=1
              AND ph.po_header_id = oi.po_header_id
             ) orden_compra
           , oi.fecha
           , NULL fecha_labor
           , NULL fecha_certifica
           , od.operating_unit, ou.name operating_unit_name
           , od.organization_code
           , NULL                      subinventario
           , oi.direccion_envio
           , oi.direccion_facturacion
           , s.vendor_name             proveedor
           , (SELECT DISTINCT p.full_name
              FROM per_all_people_f p
              WHERE p.person_id = oi.comprador_id
             ) comprador
           , oi.importado_flag
           , oi.mensaje_error
           , oi.creation_date
           , oi.last_update_date
      FROM xx_agronomo_eam_oci_int        oi
         , org_organization_definitions   od
         , hr_operating_units             ou
         , ap_suppliers                   s
      WHERE 1=1
      AND s.vendor_id        = oi.proveedor_id
      AND od.organization_id = oi.organizacion_id
      AND ou.organization_id = od.operating_unit
      AND od.operating_unit    = NVL(p_org_id, od.operating_unit)
      AND od.organization_id   = NVL(p_organization_id, od.organization_id)
      AND ( p_fecha_desde IS NULL OR
            TRUNC(oi.fecha) >= TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'))
          )
      AND ( p_fecha_hasta IS NULL OR
            TRUNC(oi.fecha) <= TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
          )
      ORDER BY 1,2,6
      ;

    l_ou_name             VARCHAR2(250);
    l_organization_name   VARCHAR2(250);
    l_calendar_desc       VARCHAR2(150);
    l_fecha_desde         DATE;
    l_fecha_hasta         DATE;
    l_cantidad            NUMBER;

    l_error_msg           VARCHAR2(2000);
  BEGIN
    FND_FILE.Put_Line(FND_FILE.LOG, '------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_operating_unit:  '||p_org_id);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_organization_id: '||p_organization_id);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_fecha_desde:     '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_fecha_hasta:     '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.LOG, '------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.LOG, ' ');

    BEGIN
      SELECT name
      INTO l_ou_name
      FROM hr_operating_units
      WHERE 1=1
      AND organization_id = p_org_id;
    EXCEPTION
      WHEN OTHERS THEN
        FND_FILE.Put_Line(FND_FILE.LOG, 'Error obteniendo nombre del unidad operativa.');
    END;

    IF p_organization_id IS NOT NULL THEN
      BEGIN
        SELECT organization_name
        INTO l_organization_name
        FROM org_organization_definitions
        WHERE 1=1
        AND organization_id = p_organization_id;
      EXCEPTION
        WHEN OTHERS THEN
          FND_FILE.Put_Line(FND_FILE.LOG, 'Error obteniendo nombre de la organización.');
      END;
    END IF;

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXPOAGRONOOC>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX PO Reporte Interfaz de OCs Agronomo</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_OU>'||l_ou_name||'</P_OU>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_ORG>'||l_organization_name||'</P_ORG>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>'||TO_CHAR(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FEHCA_HASTA>'||TO_CHAR(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY')||'</P_FEHCA_HASTA>');

    FOR r1 IN c1 LOOP
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORIGEN>'||r1.ORIGEN||'</ORIGEN>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORDEN_TRABAJO>'||r1.ORDEN_TRABAJO||'</ORDEN_TRABAJO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORDEN_COMPRA>'||r1.ORDEN_COMPRA||'</ORDEN_COMPRA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORDEN_TRABAJO_FECHA>'||TO_CHAR(r1.ORDEN_TRABAJO_FECHA, 'DD-MM-YYYY')||'</ORDEN_TRABAJO_FECHA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_LABOR>'||TO_CHAR(r1.FECHA_LABOR, 'DD-MM-YYYY')||'</FECHA_LABOR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_CERTIFICACION>'||TO_CHAR(r1.FECHA_CERTIFICA, 'DD-MM-YYYY')||'</FECHA_CERTIFICACION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <OPERATING_UNIT_NAME>'||r1.OPERATING_UNIT_NAME||'</OPERATING_UNIT_NAME>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORGANIZACION_CODIGO>'||r1.ORGANIZACION_CODIGO||'</ORGANIZACION_CODIGO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <SUBINVENTARIO>'||r1.SUBINVENTARIO||'</SUBINVENTARIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DIRECCION_ENVIO>'||XX_UTIL_PK.xml_escape_chars(r1.DIRECCION_ENVIO)||'</DIRECCION_ENVIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DIRECCION_FACTURACION>'||XX_UTIL_PK.xml_escape_chars(r1.DIRECCION_FACTURACION)||'</DIRECCION_FACTURACION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PROVEEDOR>'||XX_UTIL_PK.xml_escape_chars(r1.PROVEEDOR)||'</PROVEEDOR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <COMPRADOR>'||r1.COMPRADOR||'</COMPRADOR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <IMPORTADO_FLAG>'||r1.IMPORTADO_FLAG||'</IMPORTADO_FLAG>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <MENSAJE_ERROR>'||r1.MENSAJE_ERROR||'</MENSAJE_ERROR>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CREATION_DATE>'||TO_CHAR(r1.CREATION_DATE, 'DD-MM-YYYY HH24:MI')||'</CREATION_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LAST_UPDATE_DATE>'||TO_CHAR(r1.LAST_UPDATE_DATE, 'DD-MM-YYYY HH24:MI')||'</LAST_UPDATE_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXPOAGRONOOC>');

  EXCEPTION
    WHEN OTHERS THEN
      errbuf  := SQLERRM;
      retcode := 2;
  END Agronomo_OC;

END XX_PO_REPORTES_PKG;
/

exit
