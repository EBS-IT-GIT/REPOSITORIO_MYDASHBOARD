====================================
- BEGIN - NFE122200413
====================================

Product  - XXSN - Ninecon Solutions
Release  - R12.1 / R12.2
Platform - Generic Platform
Built    - 2020/04/13

====================================
(1) Pre-install Tasks
====================================

 a) If Release 12.1:
  Apply patch 120200316 (NFE120200316)
  
b) If Release 12.2:
 Apply patch 122200316 (NFE122200316)  

====================================
(2) Verify Oracle EBS version
====================================

 a) Execute the following query connect as APPS:

   $ sqlplus apps/<apps_password>

        SELECT substr(release_name, 1, 4)
          FROM applsys.fnd_product_groups;

 b) If the query above return 12.1 then go to step (2.1)
    If the query above return 12.2 then go to step (2.2)

====================================
(2.1) Apply Patch - for EBS releases 12.1 only
====================================

 a) Extract file NFE122200413.zip on your on directory structure for patch application:

   $ cd <directory structure>
   $ unzip NFE122200413.zip
   $ cd NFE122200413

  b) Execute this patch by "adpatch" for the drivers below:

    $ adpatch options=hotpatch driver=uNFE122200413.drv logfile=uNFE122200413.log patchtop=$PWD workers=1

====================================
(2.2) Apply Patch - for EBS releases 12.2 only
====================================

 a) Extract file NFE122200413.zip on $PATCH_TOP

   $ cd $PATCH_TOP
   $ unzip NFE122200413.zip
   $ cd NFE122200413

 b) Execute this patch by "adop" for the drivers below:

   $ adop phase=apply patches=NFE122200413:uNFE122200413.drv workers=1

====================================
(3) Post-install Tasks
====================================

 a) If patch number to Release 12.1 29650863 or 28666005 IS applied, please execute file below:
  
    $ sqlplus apps/<apps_password> @$XXSN_TOP/sql/12NFEE_IMPORT_RI_PKB.pls
  
    else none.
  
 b) If patch number to Release 12.2 28817578 IS applied, please execute file below:
  
    $ sqlplus apps/<apps_password> @$XXSN_TOP/sql/12NFEE_IMPORT_RI_PKB.pls
  
    else none.

 c) IF release 12.2 please:
 
    After applied patch run the command $adop phase=fs_clone, we have to synchronise the technology level between patch and run fc_clone.
    
	else none.
 
====================================
- END OF FILE
====================================
