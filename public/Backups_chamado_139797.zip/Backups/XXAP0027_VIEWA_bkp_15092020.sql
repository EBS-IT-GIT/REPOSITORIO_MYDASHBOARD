--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Setembro-15-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View XXAP0027_VIEWA
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "BOLINF"."XXAP0027_VIEWA" ("EMPRESA", "FORNECEDOR", "CNPJ", "DOCUMENTO", "NUMERO_NFF", "DATA_DOCUMENTO", "ENTRADA_NFF", "DATA_PAGAMENTO", "DIAS", "VALOR_DOCUMENTO", "VALOR_ADIANTAMENTO", "VLR_IMPOSTO_E_DEDUCOES", "RETENCAO_CONT", "VALOR_PAGO", "PAR", "PRI", "METODO", "TIPO_DE_FORNECEDOR", "LOTE", "CONTA_BANCARIA", "DESCRICAO", "FORNECEDOR_ID") AS 
  SELECT DISTINCT
       REPLACE(hou.name,'_UO','')   empresa
	 ,  ai.vendor_name fornecedor
	 ,  SUBSTR(pvsa.global_attribute10, 2, 2) || '.' || SUBSTR(pvsa.global_attribute10, 4, 3) || '.' ||
        SUBSTR(pvsa.global_attribute10, 7, 3) || '/' || pvsa.global_attribute11 || '-' || pvsa.global_attribute12 cnpj
     ,  DECODE (ai.invoice_type_lookup_code, 'STANDARD', 'NFF/FAT/REC/IMP', 'EXPENSE REPORT', 'REL DE DESPESAS','CREDIT', 'AV CREDITO', 'PREPAYMENT', 'ADIANTAMENTO', 'AWT', 'NFF/FAT/REC/IMP', 'RETAINAGE RELEASE', 'CAUCAO PAGO') documento
     ,  ai.invoice_num              numero_nff
	 ,  ai.invoice_date             data_documento
	 ,  ai.gl_date                  entrada_nff
	 ,  ac.check_date               data_pagamento
	 ,  ac.check_date - ai.gl_date  dias
	 ,  (SELECT SUM(amount) FROM ap.ap_invoice_lines_all l1
                          WHERE l1.invoice_id = ai.invoice_id
                            AND (l1.line_type_lookup_code = 'ITEM'
                             OR (l1.line_type_lookup_code = 'MISCELLANEOUS' AND amount >0)  ))  valor_documento
     , (NVL(ai.prepaid_amount,0)*-1)  valor_adiantamento
	 ,	NVL((SELECT SUM(amount) FROM ap.ap_invoice_lines_all aila
                          WHERE aila.invoice_id = ai.invoice_id
                            AND (  (line_type_lookup_code = 'MISCELLANEOUS' AND amount <0)
                                OR line_type_lookup_code = 'AWT')),0)  vlr_imposto_e_deducoes
	 ,  NVL(aia.validated_tax_amount,0)*-1   retencao_cont
	 ,  h.amount                             valor_pago
     ,  h.payment_num                        par
     ,  apsa.payment_priority                pri
	 ,  ai.payment_method_code               metodo
	 ,  pv.vendor_type_lookup_code           tipo_de_fornecedor
	 ,  ac.checkrun_name                     lote
	 ,  ac.current_bank_account_name         conta_bancaria
	 ,  ai.description                       descricao
     ,  ai.vendor_id                         fornecedor_id
  FROM apps.po_vendor_sites_all           pvsa
     , apps.po_vendors                    pv
     , apps.ap_invoices_v                 ai
     , ap.ap_invoices_all                 aia
     , apps.ap_invoice_payments_v         aip
     , apps.ap_checks_v                   ac
     , apps.hr_operating_units            hou
     , apps.ap_payment_schedules_all      apsa
     , apps.ap_invoice_payment_history_v  h
WHERE pv.vendor_id             = pvsa.vendor_id
  AND ai.vendor_site_id        = pvsa.vendor_site_id
  AND ai.vendor_id             = pv.vendor_id
  AND aia.invoice_id           = ai.invoice_id
  AND hou.organization_id      = aia.org_id
  AND aip.invoice_id           = ai.invoice_id
  AND h.invoice_payment_id     = aip.invoice_payment_id
  AND h.invoice_id             = aip.invoice_id
  AND h.check_id               = aip.check_id
  AND ac.check_id              = aip.check_id
  AND ac.status_lookup_code    = 'NEGOTIABLE'
  AND apsa.invoice_id          = h.invoice_id
  AND apsa.payment_num         = h.payment_num
  AND apsa.payment_status_flag = 'Y'
 ORDER BY ai.vendor_name
        , data_pagamento
        , lote
        , valor_pago
        , fornecedor
        , numero_nff
;
REM INSERTING into BOLINF.XXAP0027_VIEWA
SET DEFINE OFF;
