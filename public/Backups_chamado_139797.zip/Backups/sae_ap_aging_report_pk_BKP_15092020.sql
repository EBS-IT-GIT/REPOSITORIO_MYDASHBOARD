--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Setembro-15-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package SAE_AP_AGING_REPORT_PK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "BOLINF"."SAE_AP_AGING_REPORT_PK" AUTHID CURRENT_USER IS
--
-- $Header: SAE_AP_AGING_REPORT_PKS.pls 121.2 30/12/2019 10:00:00 appldev ship $
-- +=================================================================+
-- |                      SANTO ANTONIO ENERGIA                      |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   SAE_AP_AGING_REPORT_PKS.pls                                   |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Relat�rio Aging AP Contas a Pagar                             |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |                                                                 |
-- | CREATED BY  Renan Camarota          - 07/04/2020                |
-- |                                                                 |
-- | UPDATE BY                                                       |
-- |                                                                 |
-- +=================================================================+
--
  PROCEDURE gera_xml_p( errbuf         IN OUT VARCHAR2
                      , retcode        IN OUT VARCHAR2
                      , p_data_aging   IN VARCHAR2 );

  FUNCTION translate_f(p_vstring IN VARCHAR2) RETURN VARCHAR2;

END sae_ap_aging_report_pk;
--Indicativo de Final de Arquivo. N�o deve ser removido.

/
