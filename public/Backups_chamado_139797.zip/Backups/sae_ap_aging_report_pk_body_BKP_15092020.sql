--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Setembro-15-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body SAE_AP_AGING_REPORT_PK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "BOLINF"."SAE_AP_AGING_REPORT_PK" IS
--
-- $Header: SAE_AP_AGING_REPORT_PKB.pls 121.2 30/12/2019 10:00:00 appldev ship $
-- +=================================================================+
-- |                      SANTO ANTONIO ENERGIA                      |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   SAE_AP_AGING_REPORT_PKB.pls                                   |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Relat�rio Aging AP Contas a Pagar                             |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |                                                                 |
-- | CREATED BY  Renan Camarota          - 07/04/2020                |
-- |                                                                 |
-- | UPDATE BY                                                       |
-- |                                                                 |
-- +=================================================================+
--
  PROCEDURE gera_xml_p( errbuf         IN OUT VARCHAR2
                      , retcode        IN OUT VARCHAR2
                      , p_data_aging   IN VARCHAR2) IS

    ld_data_aging    DATE          := TO_DATE(fnd_date.canonical_to_date(p_data_aging), 'DD/MM/RRRR');
    lv_data          VARCHAR2(30)  := TO_CHAR(SYSDATE, 'DD/MM/RRRR HH24:MI:SS');

  BEGIN

    fnd_file.put_line(fnd_file.output,'<?xml version="1.0" encoding="ISO-8859-1"?>');
    fnd_file.put_line(fnd_file.output, '<DADOS>');
    fnd_file.put_line(fnd_file.output, '  <PARAMETERS>');
    fnd_file.put_line(fnd_file.output, '    <P_DATA_AGING>'   ||  ld_data_aging       || '</P_DATA_AGING>');
    fnd_file.put_line(fnd_file.output, '    <DATA_REL>'       ||  lv_data             || '</DATA_REL>');
    fnd_file.put_line(fnd_file.output, '  </PARAMETERS>');
    fnd_file.put_line(fnd_file.output, '  <G_MAIN>');

    FOR r_rec_data IN(SELECT DISTINCT DECODE(aia.org_id,'82','SAE','101','MESA')    empresa
                           , DECODE(aia.invoice_type_lookup_code,
                                   'STANDARD','NFF/FAT/REC/IMP',
                                   'EXPENSE REPORT','REL DE DESPESAS',
                                   'CREDIT','AV CREDITO',
                                   'PREPAYMENT','ADIANTAMENTO',
                                   'AWT','NFF/FAT/REC/IMP',
                                   'RETAINAGE RELEASE','CAUCAO')                    tipo
                           , pv.vendor_name                                         fornecedor
                           ,  DECODE(pvsa.global_attribute9,2,SUBSTR(pvsa.global_attribute10, 2, 2)||'.'||SUBSTR(pvsa.global_attribute10, 4, 3) || '.' ||
                                                              SUBSTR(pvsa.global_attribute10, 7, 3)||'/'||pvsa.global_attribute11 || '-' || pvsa.global_attribute12
                                                           ,1,SUBSTR(pvsa.global_attribute10, 1, 3)||'.'||SUBSTR(pvsa.global_attribute10, 4, 3) || '.' ||
                                                              SUBSTR(pvsa.global_attribute10, 7, 3)||'-'||pvsa.global_attribute12
                                                           ,pvsa.global_attribute10||pvsa.global_attribute11||pvsa.global_attribute12)    CPF_CNPJ
                           , aia.invoice_num                                        numero_nf
                           , aia.invoice_date                                       data_nff
                           , aia.gl_date                                            data_gl
                           , TO_CHAR(aia.gl_date,'MM')                              mes
                           , TO_CHAR(aia.gl_date,'YYYY')                            ano
                           , apsa.payment_num                                       parcela
                           , apsa.due_date                                          vencimento
                           , apsa.due_date - TO_DATE(ld_data_aging)                 dias
                           , (SELECT SUM(amount)
                                FROM ap.ap_invoice_lines_all l1
                               WHERE l1.invoice_id              = aia.invoice_id
                                 AND (l1.line_type_lookup_code  = 'ITEM'
                                  OR (l1.line_type_lookup_code  = 'MISCELLANEOUS'
                                 AND amount > 0)))                                                      valor_documento
                           , (SELECT (NVL(SUM(prepay_amount_applied),0) * -1) adiantamento_aplicado
                                FROM apps.ap_unapply_prepays_v aupv
                               WHERE aupv.invoice_id   = aia.invoice_id
                                 AND accounting_date  <= (TO_DATE(ld_data_aging)+0.99999))              valor_adiantamento
                           , NVL((SELECT SUM(ailax.amount)
                                    FROM ap.ap_invoice_lines_all ailax
                                   WHERE ailax.invoice_id              = aia.invoice_id
                                     AND ((ailax.line_type_lookup_code = 'MISCELLANEOUS'
                                     AND ailax.amount                  < 0)
                                     AND (ailax.accounting_date <= ld_data_aging)
                                        )),0)                                                           vlr_deducoes_NF
                           , NVL(aia.validated_tax_amount,0) * -1                                       retencao_contratual
                           , NVL(apsa.gross_amount,0)                                                   valor_parcela
                           , DECODE( NVL(apsa.payment_status_flag,'N'), 'P',ROUND(( (SELECT (NVL(SUM(prepay_amount_applied),0) * -1) adt_parc
                                                                                       FROM apps.ap_unapply_prepays_v aupv
                                                                                      WHERE aupv.invoice_id   = aia.invoice_id
                                                                                        AND accounting_date  <= (TO_DATE(ld_data_aging)+0.99999))
                                                                                      * (apsa.gross_amount/(SELECT DECODE(SUM(gross_amount),0,1,SUM(gross_amount)) vlr_par
                                                                                                              FROM apps.ap_payment_schedules_all
                                                                                                             WHERE invoice_id = apsa.invoice_id)) ),2),0) Adiant_por_parcela
                            , DECODE( NVL(apsa.payment_status_flag,'N'),'P', ROUND(( (SELECT NVL(SUM(aidv.amount),0) vlr_awt
                                                                                             FROM apps.ap_invoice_distributions_v aidv
                                                                                            WHERE aidv.invoice_id                = apsa.invoice_id
                                                                                              AND aidv.line_type_lookup_code     = 'AWT'
                                                                                              AND aidv.accounting_date          <= ld_data_aging
                                                                                              AND aidv.parent_reversal_id        IS NULL
                                                                                              AND aidv.reversing_distribution_id IS NULL
                                                                                            ) * (apsa.gross_amount/(SELECT DECODE(SUM(gross_amount),0,1,SUM(gross_amount)) vlr_par
                                                                                                                      FROM apps.ap_payment_schedules_all
                                                                                                                      WHERE invoice_id = apsa.invoice_id)) ),2),0) Imp_Retio_Fonte_parcela
                           , (SELECT NVL(SUM(hs.amount),0)
                                FROM apps.ap_invoice_payment_history_v hs
                               WHERE hs.void          = 'N'
                                 AND hs.invoice_id    = apsa.invoice_id
                                 AND hs.payment_num   = apsa.payment_num
                                 AND hs.check_date   <= ld_data_aging)            vlr_pago
                           , CASE WHEN NVL(apsa.payment_status_flag,'N') = 'Y' AND NVL(NVL(NVL(apsa.paid_date,h.check_date),(SELECT accounting_date
                                                                                                                               FROM apps.ap_unapply_prepays_v aupv
                                                                                                                              WHERE aupv.invoice_id  = aia.invoice_id
                                                                                                                                AND accounting_date  <= (TO_DATE(ld_data_aging)+0.99999)
                                                                                                                                AND ROWNUM            = 1
                                                                                                                             )),TO_DATE(ld_data_aging)+2) > (TO_DATE(ld_data_aging)+0.99999) THEN NULL
                             ELSE NVL(apsa.paid_date,ac.check_date)
                             END data_pagamento
                           , CASE WHEN NVL(apsa.payment_status_flag,'N') = 'Y' AND NVL(NVL(apsa.paid_date,h.check_date),TO_DATE(ld_data_aging)+2) > (TO_DATE(ld_data_aging)+0.99999) THEN apsa.gross_amount
                             ELSE apsa.amount_remaining
                             END valor_a_pagar
                           , pv.vendor_type_lookup_code                             tipo_de_fornecedor
                           , apsa.payment_priority                                  prioridade
                           , apsa.hold_flag                                         retencao
                           , apsa.payment_method_code                               metodo_pagamento
                           , aia.pay_group_lookup_code                              grupo_de_pgto
                           , CASE
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) <= 0 THEN
                             'Aging at� 30'  --'0' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 1 AND 30 THEN
                             'Aging at� 30' -- '30' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 31 AND 60 THEN
                             'Aging de 31 at� 60' --'60' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 61 AND 90 THEN
                             'Aging de 61 at� 90'  --'90' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 91 AND 120 THEN
                             'Aging de 91 at� 120' --'120' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 121 AND 150 THEN
                             'Aging de 121 at� 150' --'150' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 151 AND 180 THEN
                             'Aging de 151 at� 180' --'180' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) BETWEEN 181 AND 365 THEN
                             'Aging de 181 at� 365'  --'365' --
                             WHEN (TO_DATE(ld_data_aging) - apsa.due_date) > 365 THEN
                             'Aging maior ou igual 366'  --'>365' --
                             END Aging   --""""Aging Dias em Aberto""""
                           , gcc.segment3                                           conta_contabil
                           , ai.description                                         descricao_nff
                           , ai.invoice_id
                        FROM apps.ap_invoices_all                aia
                           , apps.ap_invoices_v                  ai
                           , apps.ap_payment_schedules_v         apsa
                           , apps.po_vendors                     pv
                           , apps.po_vendor_sites_all            pvsa
                           , apps.ap_invoice_lines_all           aila
                           , apps.ap_system_parameters_all       aspa
                           , apps.po_headers_all                 pha
                           , apps.gl_code_combinations           gcc
                           , apps.ap_invoice_payment_history_v   h
                           , apps.ap_checks_v                    ac
                           , apps.ap_invoice_payments_v          aip
                       WHERE aia.gl_date                 <= ld_data_aging
                         AND aia.cancelled_date          IS NULL
                         AND ai.invoice_id               = aia.invoice_id
                         AND apsa.invoice_id             = aia.invoice_id
                         AND pv.vendor_id                = aia.vendor_id
                         AND pvsa.vendor_site_id         = aia.vendor_site_id
                         AND pvsa.vendor_id              = aia.vendor_id
                         AND aila.invoice_id             = aia.invoice_id
                         AND aila.org_id                 = aia.org_id
                         AND aspa.org_id                 = apsa.org_id
                         AND pha.po_header_id(+)         = aila.po_header_id
                         AND gcc.code_combination_id(+)  = aia.accts_pay_code_combination_id
                         AND h.invoice_id(+)             = apsa.invoice_id
                         AND h.payment_num(+)            = apsa.payment_num
                         AND h.void(+)                   = 'N'
                         AND h.check_date(+)            <= (TO_DATE(ld_data_aging)+0.99999)
                         AND ac.check_id(+)              = h.check_id
                         AND ac.status_lookup_code(+)    = 'NEGOTIABLE'
                         AND aip.invoice_payment_id(+)   = h.invoice_payment_id
                         AND aip.invoice_id(+)           = h.invoice_id
                         AND aip.check_id(+)             = h.check_id
                         AND aip.check_id(+)             = ac.check_id
                         AND ((NVL(apsa.payment_status_flag,'N') = 'Y' AND NVL(NVL(NVL(apsa.paid_date,h.check_date),(SELECT accounting_date
                                                                                                                       FROM apps.ap_unapply_prepays_v aupv
                                                                                                                      WHERE aupv.invoice_id   = aia.invoice_id
                                                                                                                        AND accounting_date   <= (TO_DATE(ld_data_aging)+0.99999)
                                                                                                                        AND ROWNUM = 1)),TO_DATE(ld_data_aging)+2) > (TO_DATE(ld_data_aging)+0.99999))
                         OR NVL(apsa.payment_status_flag,'N') <> 'Y' )
                         AND NVL(apsa.gross_amount,0) <> 0
                        ORDER BY aia.gl_date
                               , apsa.due_date
                               , aia.invoice_num
                               , apsa.payment_num


                      ) LOOP

      fnd_file.put_line(fnd_file.output, '    <G_DADOS>');
      fnd_file.put_line(fnd_file.output, '      <EMPRESA>'                   || r_rec_data.empresa                              || '</EMPRESA>');
      fnd_file.put_line(fnd_file.output, '      <TIPO>'                      || r_rec_data.tipo                                 || '</TIPO>');
      fnd_file.put_line(fnd_file.output, '      <FORNECEDOR>'                || translate_f(r_rec_data.fornecedor)              || '</FORNECEDOR>');
      fnd_file.put_line(fnd_file.output, '      <CNPJ>'                      || r_rec_data.cpf_cnpj                             || '</CNPJ>');
      fnd_file.put_line(fnd_file.output, '      <NUMERO_NF>'                 || translate_f(r_rec_data.numero_nf)               || '</NUMERO_NF>');
      fnd_file.put_line(fnd_file.output, '      <DATA_NFF>'                  || TO_CHAR(r_rec_data.data_nff,'DD/MM/YYYY')       || '</DATA_NFF>');
      fnd_file.put_line(fnd_file.output, '      <DATA_GL>'                   || TO_CHAR(r_rec_data.data_gl,'DD/MM/YYYY')        || '</DATA_GL>');
      fnd_file.put_line(fnd_file.output, '      <MES>'                       || r_rec_data.mes                                  || '</MES>');
      fnd_file.put_line(fnd_file.output, '      <ANO>'                       || r_rec_data.ano                                  || '</ANO>');
      fnd_file.put_line(fnd_file.output, '      <PARCELA>'                   || r_rec_data.parcela                              || '</PARCELA>');
      fnd_file.put_line(fnd_file.output, '      <VENCIMENTO>'                || TO_CHAR(r_rec_data.vencimento,'DD/MM/YYYY')     || '</VENCIMENTO>');
      fnd_file.put_line(fnd_file.output, '      <DIAS>'                      || r_rec_data.dias                                 || '</DIAS>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_DOC>'                 || REPLACE(r_rec_data.valor_documento,',','.')                      || '</VALOR_DOC>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_ADIAN>'               || REPLACE(r_rec_data.valor_adiantamento,',','.')                   || '</VALOR_ADIAN>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_DED_NF>'              || REPLACE(r_rec_data.vlr_deducoes_nf,',','.')                      || '</VALOR_DED_NF>');
      fnd_file.put_line(fnd_file.output, '      <RENT_CONT>'                 || REPLACE(r_rec_data.retencao_contratual,',','.')                  || '</RENT_CONT>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_PARC>'                || REPLACE(r_rec_data.valor_parcela,',','.')                        || '</VALOR_PARC>');
      fnd_file.put_line(fnd_file.output, '      <POR_PARCELA>'               || REPLACE(r_rec_data.Adiant_por_parcela,',','.')                   || '</POR_PARCELA>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_RET_PARCELA>'         || REPLACE(r_rec_data.Imp_Retio_Fonte_parcela,',','.')              || '</VALOR_RET_PARCELA>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_PAGO>'                || REPLACE(r_rec_data.vlr_pago,',','.')                             || '</VALOR_PAGO>');
      fnd_file.put_line(fnd_file.output, '      <DATA_PAGAMENTO>'            || TO_CHAR(r_rec_data.data_pagamento,'DD/MM/YYYY')                  || '</DATA_PAGAMENTO>');
      fnd_file.put_line(fnd_file.output, '      <VALOR_PAGAR>'               || REPLACE(r_rec_data.valor_a_pagar,',','.')                        || '</VALOR_PAGAR>');
      fnd_file.put_line(fnd_file.output, '      <TIPO_FORNECEDOR>'           || r_rec_data.tipo_de_fornecedor                   || '</TIPO_FORNECEDOR>');
      fnd_file.put_line(fnd_file.output, '      <PRIORIDADE>'                || r_rec_data.prioridade                           || '</PRIORIDADE>');
      fnd_file.put_line(fnd_file.output, '      <RETENCAO>'                  || r_rec_data.retencao                             || '</RETENCAO>');
      fnd_file.put_line(fnd_file.output, '      <MET_PAGAMENTO>'             || r_rec_data.metodo_pagamento                     || '</MET_PAGAMENTO>');
      fnd_file.put_line(fnd_file.output, '      <GRUPO_PAGAMENTO>'           || r_rec_data.grupo_de_pgto                        || '</GRUPO_PAGAMENTO>');
      fnd_file.put_line(fnd_file.output, '      <AGING>'                     || r_rec_data.Aging                                || '</AGING>');
      fnd_file.put_line(fnd_file.output, '      <CC>'                        || r_rec_data.conta_contabil                       || '</CC>');
      fnd_file.put_line(fnd_file.output, '      <DESC_NFF>'                  || translate_f(r_rec_data.descricao_nff)           || '</DESC_NFF>');
      fnd_file.put_line(fnd_file.output, '      <ID>'                        || r_rec_data.invoice_id                           || '</ID>');
      fnd_file.put_line(fnd_file.output, '    </G_DADOS>');

    END LOOP;

    fnd_file.put_line(fnd_file.output, '  </G_MAIN>');
    fnd_file.put_line(fnd_file.output, '</DADOS>');

  EXCEPTION
    WHEN OTHERS THEN
      errbuf  := SUBSTR(SQLERRM,1,150);
      retcode := SQLCODE;
      fnd_file.put_line(fnd_file.output, 'Error in Package sae_ap_aging_report_pk : '||errbuf);
      raise_application_error(-20001,'Error '||errbuf);

  END gera_xml_p;

  FUNCTION translate_f(p_vString IN VARCHAR2) RETURN VARCHAR2 IS
    l_vString VARCHAR2(2000);
  BEGIN
    l_vString := UPPER(TRANSLATE(p_vString,'��������������������������&<>','aAoOcCuUaAeEoOaAaAeEiIoOuUe--'));
    RETURN l_vString;
  END translate_f;

END sae_ap_aging_report_pk;
-- Indicativo de final de arquivo. Nao deve ser removido.

/
