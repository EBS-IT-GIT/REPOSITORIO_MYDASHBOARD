--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Setembro-15-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package SAE_AP_REL_BNDES_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "APPS"."SAE_AP_REL_BNDES_PKG" AUTHID CURRENT_USER  IS
--
-- $Header: SAE_AP_REL_BNDES_PKGS.pls 121.5 22/07/2019 10:00:00 appldev ship $
-- +=================================================================+
-- |               Ramac Informatica, Sao Paulo, Brasil              |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   SAE_AP_REL_BNDES_PKGS.pls                                     |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Criacao de processo para carga na temporaria para geracao     |
-- |   de relatorio BNDES                                            |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Criacao de processo para carga na temporaria para gera��o     |
-- |   de relatorio BNDES                                            |
-- |                                                                 |
-- | PARAMETERS                                                      |
-- |                                                                 |
-- | CREATED BY   <Nome do Desenvolvedor> / data                     |
-- |   Andre Assis / 28-abr-2013                                     |
-- |                                                                 |
-- | UPDATED BY   <Nome do Desenvolvedor> / data       Bug numeber   |
-- |              Ivam Cardoso / 15/05/2015             1.0          |
-- |                                                                 |
-- | UPDATED BY   Joao Adami / 11/07/2016                            |
-- |     #120.2 - Inclusao do campo FINAME nas informacoes do rel    |
-- |                                                                 |
-- | UPDATED BY   Giovan Gomes / 14/06/2019                          |
-- |     #120.3 - Inclusao dos campos nas informacoes do relat�rio : |
-- |       * TIPO_FORNECEDOR, CNPJ_CPF, EMPRESA, DESCR_EMPRESA       |
-- |         CONTA, DESCR_CONTA, CENTRO_CUSTO, DESCR_CENTRO_CUSTO    |
-- |         PROGRAMA, DESCR_PROGRAMA                                |
-- |                                                                 |
-- +=================================================================+
--
  p_org_id   number;
  p_data_ini varchar2(20);
  p_data_fim varchar2(20);

  --
  function before_report_f return boolean;
  --
  procedure generation ( p_org_id   in number
                       , p_data_ini in varchar2
                       , p_data_fim in varchar2
                       );
end SAE_AP_REL_BNDES_PKG;
-- Indicativo de final de arquivo. Nao deve ser removido.

/
