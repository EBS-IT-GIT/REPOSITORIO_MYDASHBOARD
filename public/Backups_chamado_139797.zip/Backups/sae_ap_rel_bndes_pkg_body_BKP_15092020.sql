--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Setembro-15-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body SAE_AP_REL_BNDES_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "APPS"."SAE_AP_REL_BNDES_PKG" IS
--
-- $Header: SAE_AP_REL_BNDES_PKGB.pls 121.5 22/07/2019 10:00:00 appldev ship $
-- +=================================================================+
-- |               Ramac Informatica, Sao Paulo, Brasil              |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   SAE_AP_REL_BNDES_PKGB.pls                                     |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Criacao de processo para carga na temporaria para geracao     |
-- |   de relatorio BNDES                                            |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   Criacao de processo para carga na temporaria para geracao     |
-- |   de relatorio BNDES                                            |
-- |                                                                 |
-- | PARAMETERS                                                      |
-- |                                                                 |
-- | CREATED BY   <Nome do Desenvolvedor> / data                     |
-- |   Andre Assis / 28-abr-2013                                     |
-- |                                                                 |
-- | UPDATED BY   <Nome do Desenvolvedor> / data       Bug numeber   |
-- |              Ivam Cardoso / 15/05/2015             1.0          |
-- |                                                                 |
-- | UPDATED BY   Joao Adami / 11/07/2016                            |
-- |     #120.2 - Inclusao do campo FINAME nas informacoes do rel    |
-- |                                                                 |
-- | UPDATED BY   Giovan Gomes / 14/06/2019                          |
-- |     #120.3 - Inclusao dos campos nas informacoes do relat�rio : |
-- |       * TIPO_FORNECEDOR, CNPJ_CPF, EMPRESA, DESCR_EMPRESA       |
-- |         CONTA, DESCR_CONTA, CENTRO_CUSTO, DESCR_CENTRO_CUSTO    |
-- |         PROGRAMA, DESCR_PROGRAMA                                |
-- |                                                                 |
-- +=================================================================+
--
function before_report_f RETURN BOOLEAN IS
  begin
    generation( p_org_id
              , p_data_ini
              , p_data_fim
              ) ;
    return(TRUE);
end before_report_f;
--
procedure generation ( p_org_id   in number
                     , p_data_ini in varchar2
                     , p_data_fim in varchar2
                     ) is
  --
  v_data_ini               date := to_date(p_data_ini, 'RRRR/MM/DD HH24:MI:SS');
  v_data_fim               date := to_date(p_data_fim, 'RRRR/MM/DD HH24:MI:SS');
  v_valor_desconto_rateado number;
  v_valor_pago_rateado     number;
  v_concatenated_segments  varchar2(100);
  v_invoice_id             number;
  v_Step                   varchar2(100);
  --#120.3 - Inicio
  l_vCpf_Cnpj              bolinf.sae_ap_rel_bndes.cnpj_cpf%TYPE;
  l_vTipoFornecedor        bolinf.sae_ap_rel_bndes.tipo_fornecedor%TYPE;
  l_nCodeCombinationId     apps.gl_code_combinations.code_combination_id%TYPE;
  l_vEmpresa               apps.fnd_flex_values_vl.flex_value%TYPE;
  l_vDescEmpresa           apps.fnd_flex_values_vl.description%TYPE;
  l_vConta                 apps.fnd_flex_values_vl.flex_value%TYPE;
  l_vDescConta             apps.fnd_flex_values_vl.description%TYPE;
  l_vCentroCusto           apps.fnd_flex_values_vl.flex_value%TYPE;
  l_vDescCentroCusto       apps.fnd_flex_values_vl.description%TYPE;             
  l_vPrograma              apps.fnd_flex_values_vl.flex_value%TYPE;
  l_vDescPrograma          apps.fnd_flex_values_vl.description%TYPE;  
  --#120.3 - Fim
  ---------
  Cursor c1 ( c_org_id   number
            , c_data_ini date
            , c_data_fim date
            ) is
     Select ai.invoice_type_lookup_code            TIPO_DOCTO
          , ai.vendor_name                         FORNECEDOR
          , aiph.invoice_num                       DOCUMENTO
          , aiph.payment_num                       PARCELA
          , aiph.check_date                        DATA_PAGAMENTO
          , aiph.description                       DESCRICAO_LANCAMENTO
          , aiph.amount                            VALOR_PAGO_RATEADO
          , aiph.amount_paid                       VALOR_PAGO_old
          , aiphsum.amount                         VALOR_PAGO
          , aiph.invoice_amount                    VALOR_A_PAGAR --**
          , nvl(aiph.discount_taken,0)*-1          VALOR_DESCONTO
--          , nvl(aiph.discount_taken,0)          VALOR_DESCONTO
--          , round(aiph.amount/aiph.amount_paid,15) PERC_RATEIO
--          , round(aiph.amount/(aps.GROSS_AMOUNT-nvl(ai.amount_withheld,0)),15) PERC_RATEIO  --
--          , round((aiph.amount+nvl(aiph.discount_taken,0))/(aps.GROSS_AMOUNT-nvl(ai.amount_withheld,0)),15) PERC_RATEIO  --** Bug 1.0
          , round((aiph.amount+nvl(aiph.discount_taken,0))/Decode((aps.GROSS_AMOUNT-nvl(ai.amount_withheld,0)),0,1,(aps.GROSS_AMOUNT-nvl(ai.amount_withheld,0))),15) PERC_RATEIO  --** Bug 1.0
--          , round(aps.PERC_RATEIO,15)              PERC_RATEIO --**
          , ac.currency_code                       MOEDA_UTILIZADA
          , ai.invoice_id
          , aiph.invoice_payment_id
          , ai.vendor_site_id                      --#120.3
          , ac.checkrun_name                       NOME_LOTE_PAGTO --#120.3
          , ac.check_number                        NUM_LOTE_PAGTO  --#120.3
       from ap_checks_v                  ac
          , ap_invoices_v                ai
          , ap_invoice_payment_history_v aiph
          , (Select sum(amount) amount, invoice_id
               From ap_invoice_payment_history_v
              Where check_date      >= trunc(c_data_ini)
                And check_date      <= trunc(c_data_fim)
              Group by  invoice_id) aiphsum
          , (Select invoice_id, sum(GROSS_AMOUNT) GROSS_AMOUNT, SUM(AMOUNT_REMAINING) AMOUNT_REMAINING
               , Decode(sum(abs(GROSS_AMOUNT)),0,1,
                       ((sum(abs(GROSS_AMOUNT))-SUM(abs(AMOUNT_REMAINING)))/SUM(abs(GROSS_AMOUNT))) ) PERC_RATEIO

--                  , ((sum(abs(GROSS_AMOUNT))-SUM(abs(NVL(AMOUNT_REMAINING,0))))/SUM(abs(GROSS_AMOUNT))) PERC_RATEIO
               From ap_payment_schedules_all Group by invoice_id ) aps
      Where aiph.check_date               >= trunc(c_data_ini)
        And aiph.check_date               <= trunc(c_data_fim)
        And aiph.void                     <> 'Y'
        And ai.invoice_id                  = aiph.invoice_id
        And ac.check_id                    = aiph.check_id
        And ac.check_status               <> 'Voided'
        And aiphsum.invoice_id             = aiph.invoice_id
        And aps.invoice_id                 = aiph.invoice_id
        And ai.org_id                      = c_org_id
        --And aiph.invoice_num               = '6984/'
-- and ai.invoice_id = 854003
      Order By ai.invoice_type_lookup_code
             , ai.vendor_name
             , aiph.invoice_num
             , aiph.payment_num;
  ---------
  cursor c2 ( c_invoice_id  number
            , c_perc_rateio number
            , c_vlr_total   number
            ) is
     Select ail.line_number                                                                   LINHA
          , said.sum_amount                                                                   VALOR_TOTAL
          , round(Nvl(aid.amount,0)*c_perc_rateio,2)                                          VALOR_LINHA_RATEIO
          , nvl(aid2.amount,0)                                                                RETENCAO_CONTRATUAL
          , Round(Nvl(aid2.amount,0)*(Round(aid.amount/said.sum_amount,10))*c_perc_rateio,2)  RETENCAO_CONTRATUAL_RATEADO
--          , Round(Nvl(aid2.amount,0)*c_perc_rateio,2)                          RETENCAO_CONTRATUAL_RATEADO
          , Nvl(svd.VLR_DIVERSO,0)                                             VALORES_DIVERSOS
          , Round(Nvl(svd.VLR_DIVERSO,0)
            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio,2)            VALORES_DIVERSOS_RATEADO
          , (nvl(ai.amount_withheld,0)*-1)                                      VALOR_IMPOSTO_RETIDO
          , Round(((nvl(ai.amount_withheld,0)
            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio)*-1),2)       VALOR_IMPOSTO_RETIDO_RATEADO

          , (nvl(prepayd.prepay_amount_applied,0)*-1)                           VALOR_AD_APLICADO
          , Round(((nvl(prepayd.prepay_amount_applied,0)
            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio)*-1),2)       VALOR_AD_APLICADO_RATEADO
--          , (nvl(ai.prepay_amount_applied,0)*-1)                                VALOR_AD_APLICADO
--          , Round(((nvl(ai.prepay_amount_applied,0)
--            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio)*-1),2)       VALOR_AD_APLICADO_RATEADO
          , Decode(NVL(cll1.invoice_line_id,0),0,gcc.concatenated_segments,
                   NVL(gcccll.concatenated_segments,gcc.concatenated_segments)) CONTA_CONTABIL_RATEIO
          , ail.description||'.'||ail.item_description                          HISTORICO_CONCATENADO
          , Decode(rsh.SHIPMENT_NUM,null,'',
                   'BM: '||rsh.SHIPMENT_NUM
                   ||'  PERIODO DE: '||rsh.PERFORMANCE_PERIOD_FROM
                   ||'  ATE: '||rsh.PERFORMANCE_PERIOD_TO)                      BMEDICAO
          --
          , cll1.invoice_line_id
          , ail.reference_key1
          , aid.po_distribution_id
          , aid.amount
          , said.sum_amount
          , ai.attribute9 FINAME --#120.2
          , NVL(gcccll.code_combination_id ,gcc.code_combination_id) code_combination_id  --#120.3
     -------
       from ap_invoices_v                ai
          , ap_invoice_lines_v           ail
          , ap_invoice_distributions_v   aid
          , gl_code_combinations_kfv     gcc
--          , ap_invoice_distributions_v   aid2
          , cll_f189_invoice_lines       cll1
          , gl_code_combinations_kfv     gcccll
          , (Select invoice_id, sum(nvl(amount,0)) prepay_amount_applied From ap_invoice_distributions_v Where line_type_lookup_code = 'PREPAY' Group By invoice_id) prepayd
          , (Select invoice_id, Sum(nvl(Amount,0)) vlr_diverso from ap_invoice_lines_v  Where line_type_lookup_code not in ('ITEM','ACCRUAL','IPV','AWT','RETAINAGE RELEASE') Group by invoice_id) svd
--          , (Select adv.invoice_id, Sum(nvl(adv.Amount,0)) vlr_diverso from ap_invoice_distributions_v adv, ap_invoice_lines_v ail Where ail.invoice_id = adv.invoice_id And ail.line_number = adv.distribution_line_number And ail.line_type_lookup_code not in ('ITEM','AWT') And adv.line_type_lookup_code not in ('ITEM','AWT') Group by adv.invoice_id) svd
--          , (Select invoice_id, sum(nvl(amount,0)) sum_amount From ap_invoice_distributions_v Where line_type_lookup_code in ('ITEM','ACCRUAL','IPV') Group By invoice_id) said
          , (Select invoice_id, Decode(sum(nvl(amount,0)),0,1,sum(nvl(amount,0))) sum_amount From ap_invoice_distributions_v Where line_type_lookup_code in ('ITEM','ACCRUAL','IPV') Group By invoice_id) said
          , cll_f189_work_confs         cfwc
          , rcv_shipment_headers        rsh
--          , (Select invoice_id, invoice_line_number, line_type_lookup_code, sum(amount) amount from ap_invoice_distributions_v Where line_type_lookup_code  = 'RETAINAGE' Group by invoice_id, invoice_line_number, line_type_lookup_code ) aid2
          , (Select invoice_id, line_type_lookup_code, sum(amount) amount from ap_invoice_distributions_v Where line_type_lookup_code  = 'RETAINAGE' Group by invoice_id, line_type_lookup_code ) aid2
     -------
      Where ai.invoice_id                  = ail.invoice_id
        And aid.invoice_id                 = ail.invoice_id
        And aid.invoice_line_number        = ail.line_number
        And aid.line_type_lookup_code      In ('ITEM','ACCRUAL','IPV')
        And gcc.code_combination_id(+)     = aid.dist_code_combination_id
        And aid2.invoice_id(+)             = ail.invoice_id
--        And aid2.invoice_line_number(+)    = ail.line_number
        And aid2.line_type_lookup_code(+)  = 'RETAINAGE'
        And svd.invoice_id(+)              = ai.invoice_id
        And said.invoice_id(+)             = ail.invoice_id
        And prepayd.invoice_id(+)          = ail.invoice_id
        And cll1.invoice_line_id(+)        = ail.reference_key1
        And gcccll.code_combination_id(+)  = cll1.db_code_combination_id
        And cfwc.invoice_id(+)             = cll1.invoice_id
        And cfwc.invoice_line_id(+)        = cll1.invoice_line_id
        And rsh.shipment_header_id(+)      = cfwc.shipment_header_id
        And ai.invoice_id                  = c_invoice_id
Union all
     Select ail.line_number                                                                   LINHA
          , said.sum_amount                                                                   VALOR_TOTAL
          , round(Nvl(aid.amount,0)*c_perc_rateio,2)                                          VALOR_LINHA_RATEIO
          , nvl(aid2.amount,0)                                                                RETENCAO_CONTRATUAL
          , Round(Nvl(aid2.amount,0)*(Round(aid.amount/said.sum_amount,10))*c_perc_rateio,2)  RETENCAO_CONTRATUAL_RATEADO
--          , Round(Nvl(aid2.amount,0)*c_perc_rateio,2)                          RETENCAO_CONTRATUAL_RATEADO
          , Nvl(svd.VLR_DIVERSO,0)                                             VALORES_DIVERSOS
          , Round(Nvl(svd.VLR_DIVERSO,0)
            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio,2)            VALORES_DIVERSOS_RATEADO
          , (nvl(ai.amount_withheld,0)*-1)                                      VALOR_IMPOSTO_RETIDO
          , Round(((nvl(ai.amount_withheld,0)
            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio)*-1),2)       VALOR_IMPOSTO_RETIDO_RATEADO

          , (nvl(prepayd.prepay_amount_applied,0)*-1)                           VALOR_AD_APLICADO
          , Round(((nvl(prepayd.prepay_amount_applied,0)
            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio)*-1),2)       VALOR_AD_APLICADO_RATEADO
--          , (nvl(ai.prepay_amount_applied,0)*-1)                                VALOR_AD_APLICADO
--          , Round(((nvl(ai.prepay_amount_applied,0)
--            *(Round(aid.amount/said.sum_amount,10))*c_perc_rateio)*-1),2)       VALOR_AD_APLICADO_RATEADO
          , Decode(NVL(cll1.invoice_line_id,0),0,gcc.concatenated_segments,
                   NVL(gcccll.concatenated_segments,gcc.concatenated_segments)) CONTA_CONTABIL_RATEIO
          , ail.description||'.'||ail.item_description                          HISTORICO_CONCATENADO
          , Decode(rsh.SHIPMENT_NUM,null,'',
                   'BM: '||rsh.SHIPMENT_NUM
                   ||'  PERIODO DE: '||rsh.PERFORMANCE_PERIOD_FROM
                   ||'  ATE: '||rsh.PERFORMANCE_PERIOD_TO)                      BMEDICAO
          --
          , cll1.invoice_line_id
          , ail.reference_key1
          , aid.po_distribution_id
          , aid.amount
          , said.sum_amount
          , ai.attribute9 FINAME --#120.2
          , NVL(gcccll.code_combination_id ,gcc.code_combination_id) code_combination_id  --#120.3
     -------
       from ap_invoices_v                ai
          , ap_invoice_lines_v           ail
          , ap_invoice_distributions_v   aid
          , gl_code_combinations_kfv     gcc
--          , ap_invoice_distributions_v   aid2
          , cll_f189_invoice_lines       cll1
          , gl_code_combinations_kfv     gcccll
          , (Select invoice_id, sum(nvl(amount,0)) prepay_amount_applied From ap_invoice_distributions_v Where line_type_lookup_code = 'PREPAY' Group By invoice_id) prepayd
          , (Select invoice_id, Sum(nvl(Amount,0)) vlr_diverso from ap_invoice_lines_v  Where line_type_lookup_code not in ('MISCELLANEOUS','AWT','RETAINAGE RELEASE') Group by invoice_id) svd
--          , (Select adv.invoice_id, Sum(nvl(adv.Amount,0)) vlr_diverso from ap_invoice_distributions_v adv, ap_invoice_lines_v ail Where ail.invoice_id = adv.invoice_id And ail.line_number = adv.distribution_line_number And ail.line_type_lookup_code not in ('ITEM','AWT') And adv.line_type_lookup_code not in ('ITEM','AWT') Group by adv.invoice_id) svd
          , (Select invoice_id, Decode(sum(nvl(amount,0)),0,1,sum(nvl(amount,0))) sum_amount From ap_invoice_distributions_v Where line_type_lookup_code in ('MISCELLANEOUS') Group By invoice_id) said
          , cll_f189_work_confs         cfwc
          , rcv_shipment_headers        rsh
--          , (Select invoice_id, invoice_line_number, line_type_lookup_code, sum(amount) amount from ap_invoice_distributions_v Where line_type_lookup_code  = 'RETAINAGE' Group by invoice_id, invoice_line_number, line_type_lookup_code ) aid2
          , (Select invoice_id, line_type_lookup_code, sum(amount) amount from ap_invoice_distributions_v Where line_type_lookup_code  = 'RETAINAGE' Group by invoice_id, line_type_lookup_code ) aid2
     -------
      Where ai.invoice_id                  = ail.invoice_id
        And ail.line_type_lookup_code      = 'MISCELLANEOUS'
        And Not exists  (Select 1 from ap_invoice_lines_all  b
                     Where b.invoice_id = ail.invoice_id
                       And b.line_type_lookup_code  <> 'MISCELLANEOUS')
        And aid.invoice_id                 = ail.invoice_id
        And aid.invoice_line_number        = ail.line_number
        And aid.line_type_lookup_code      = 'MISCELLANEOUS'
        And gcc.code_combination_id(+)     = aid.dist_code_combination_id
        And aid2.invoice_id(+)             = ail.invoice_id
--        And aid2.invoice_line_number(+)    = ail.line_number
        And aid2.line_type_lookup_code(+)  = 'RETAINAGE'
        And svd.invoice_id(+)              = ai.invoice_id
        And said.invoice_id(+)             = ail.invoice_id
        And prepayd.invoice_id(+)          = ail.invoice_id
        And cll1.invoice_line_id(+)        = ail.reference_key1
        And gcccll.code_combination_id(+)  = cll1.db_code_combination_id
        And cfwc.invoice_id(+)             = cll1.invoice_id
        And cfwc.invoice_line_id(+)        = cll1.invoice_line_id
        And rsh.shipment_header_id(+)      = cfwc.shipment_header_id
        And ai.invoice_id                  = c_invoice_id
      Order By 1;
  --
  BEGIN
     --
     FND_FILE.NEW_LINE(FND_FILE.LOG, 1);
     FND_FILE.PUT(FND_FILE.LOG, '***** SAE_AP_REL_BNDES_PRC: OK !!! *****');
v_Step := 'Step 1';
     Delete From SAE_AP_REL_BNDES;
     Commit;
v_Step := 'Step 2';
     --
     for r1 in c1 ( p_org_id
                  , v_data_ini
                  , v_data_fim
                  ) loop

v_Step := 'Step 3';
       v_invoice_id := r1.invoice_id;
--dbms_output.put_line('***Invoice_id = '||r1.invoice_id);

        for r2 in c2 ( r1.invoice_id
                     , r1.perc_rateio
                     , nvl(r1.VALOR_PAGO,0)
                     ) loop
           --
v_Step := 'Step 4';
           Begin
           v_VALOR_DESCONTO_RATEADO := Round(Nvl(r1.VALOR_DESCONTO,0)
                                       *(Round(r2.amount/r2.sum_amount,10))*r1.perc_rateio,2);
v_Step := 'Step 5';
           v_VALOR_PAGO_RATEADO     := Round(Nvl(r1.VALOR_PAGO_RATEADO,0)
                                       *(Round(r2.amount/r2.sum_amount,10)),2);
v_Step := 'Step 6';
           Exception
               When Others Then
                  dbms_output.put_line('Invoice_id = '||v_invoice_id||' - '||r2.amount||'/'||r2.sum_amount);
           End;

           --
           Begin
              v_concatenated_segments := Null;
              l_nCodeCombinationId    := Null;
              If NVL(r2.invoice_line_id,0) <> 0 Then
                 --
v_Step := 'Step 7';
                 select Decode(Nvl(gcccl2.concatenated_segments,'0'),'0',gcccll.concatenated_segments,gcccl2.concatenated_segments)
                      , NVL(gcccll.code_combination_id , gcccl2.code_combination_id) --#120.3
                   into v_concatenated_segments
                      , l_nCodeCombinationId           --#120.3
                   from cll_f189_invoice_lines   cll1
                      , cll_f189_distributions   clld
                      , gl_code_combinations_kfv gcccll
                      , gl_code_combinations_kfv gcccl2
                   where clld.invoice_line_id        = cll1.invoice_line_id
                     And gcccll.code_combination_id  = clld.code_combination_id
                     And gcccl2.code_combination_id(+) = cll1.DB_CODE_COMBINATION_ID
                     And clld.reference             In ('ITEM','ACCRUAL')
                     And clld.po_distribution_id     = NVL(r2.po_distribution_id,clld.po_distribution_id)
                     and cll1.invoice_line_id        = r2.invoice_line_id;
                  --
v_Step := 'Step 8';
              End IF;
           Exception
              When Others Then
                 begin
v_Step := 'Step 9';
                    select gcccll.concatenated_segments 
                         , gcccll.code_combination_id     --#120.3
                      into v_concatenated_segments
                         , l_nCodeCombinationId           --#120.3
                      from cll_f189_invoice_lines   cll1
                         , cll_f189_distributions   clld
                         , gl_code_combinations_kfv gcccll
                     where clld.invoice_line_id(+)        = cll1.invoice_line_id
                       and cll1.invoice_line_id           = r2.invoice_line_id
                       And clld.reference                In ('ITEM','ACCRUAL')
                       And gcccll.code_combination_id(+)  = clld.code_combination_id;
v_Step := 'Step 10';
                 Exception
                    When Others Then
v_Step := 'Step 11';
                       v_concatenated_segments := null;
                 End;
           End;
           --
--#120.3 - Inicio           
v_Step := 'Step 12';
       BEGIN  
         SELECT DECODE(pvs.global_attribute9 ,1, SUBSTR(pvs.global_attribute10,1,3) ||'.'|| SUBSTR(pvs.global_attribute10,4,3) ||'.'|| SUBSTR(pvs.global_attribute10,7,3) || DECODE(pvs.global_attribute11,'0000','',pvs.global_attribute11) ||'-'|| pvs.global_attribute12
                                             ,2, SUBSTR(pvs.global_attribute10,1,3) ||'.'|| SUBSTR(pvs.global_attribute10,4,3) ||'.'|| SUBSTR(pvs.global_attribute10,7,3) ||'/'|| pvs.global_attribute11 ||'-'|| pvs.global_attribute12 , pvs.global_attribute10|| pvs.global_attribute11 || pvs.global_attribute12) CNPJ_CPF
              , flv.description 
           INTO l_vCpf_Cnpj
              , l_vTipoFornecedor
           FROM po_vendor_sites_all  pvs
              , po_vendors           pv 
              , fnd_lookup_values_vl flv
          WHERE vendor_site_id = r1.vendor_site_id
            AND pv.vendor_id = pvs.vendor_id
            AND flv.lookup_type(+) = 'VENDOR TYPE'
            AND flv.lookup_code(+) = pv.vendor_type_lookup_code;           
       EXCEPTION  
         WHEN OTHERS THEN
           l_vCpf_Cnpj       := NULL;
           l_vTipoFornecedor := NULL;
       END;   
       
       -- Segmentos Contabeis
       BEGIN
         SELECT segment1
              , segment3
              , segment2
              , segment4 
           INTO l_vEmpresa
              , l_vConta
              , l_vCentroCusto
              , l_vPrograma
           FROM gl_code_combinations gcc
          WHERE gcc.code_combination_id = NVL(l_nCodeCombinationId,r2.code_combination_id);
       EXCEPTION 
         WHEN OTHERS THEN 
           l_vEmpresa     := NULL;
           l_vConta       := NULL;
           l_vCentroCusto := NULL;
           l_vPrograma    := NULL;    
       END;
       
       -- Empresa
       BEGIN
         SELECT ffvv.flex_value 
              , ffvv.description 
           INTO l_vEmpresa
              , l_vDescEmpresa 
           FROM apps.fnd_flex_values_vl  ffvv
              , apps.fnd_flex_value_sets ffvs
          WHERE ffvv.flex_value_set_id   = ffvs.flex_value_set_id
            AND ffvs.flex_value_set_name = 'SAE_EMPRESA'
            AND ffvv.flex_value          = l_vEmpresa;
       EXCEPTION
         WHEN OTHERS THEN 
           l_vEmpresa     := NULL;
           l_vDescEmpresa := NULL;
       END;
       
       -- Conta
       BEGIN
         SELECT ffvv.flex_value 
              , ffvv.description 
           INTO l_vConta
              , l_vDescConta               
           FROM apps.fnd_flex_values_vl  ffvv
              , apps.fnd_flex_value_sets ffvs
          WHERE ffvv.flex_value_set_id   = ffvs.flex_value_set_id
            AND ffvs.flex_value_set_name = 'SAE_CONTA'
            AND ffvv.flex_value          = l_vConta;
       EXCEPTION
         WHEN OTHERS THEN 
           l_vConta     := NULL;
           l_vDescConta := NULL;
       END;
       
       -- Centro de Custo
       BEGIN
         SELECT ffvv.flex_value 
              , ffvv.description 
           INTO l_vCentroCusto
              , l_vDescCentroCusto              
           FROM apps.fnd_flex_values_vl  ffvv
              , apps.fnd_flex_value_sets ffvs
          WHERE ffvv.flex_value_set_id   = ffvs.flex_value_set_id
            AND ffvs.flex_value_set_name = 'SAE_CENTRO_CUSTO'
            AND ffvv.flex_value          = l_vCentroCusto;
       EXCEPTION
         WHEN OTHERS THEN 
           l_vCentroCusto     := NULL;
           l_vDescCentroCusto := NULL;
       END;
       
       -- Programa
       BEGIN
         SELECT ffvv.flex_value 
              , ffvv.description 
           INTO l_vPrograma
              , l_vDescPrograma
           FROM apps.fnd_flex_values_vl  ffvv
              , apps.fnd_flex_value_sets ffvs
          WHERE ffvv.flex_value_set_id   = ffvs.flex_value_set_id
            AND ffvs.flex_value_set_name = 'SAE_PROGRAMA'
            AND ffvv.flex_value          = l_vPrograma;
       EXCEPTION
         WHEN OTHERS THEN 
           l_vPrograma     := NULL;
           l_vDescPrograma := NULL;
       END;  
        
v_Step := 'Step 13';
--#120.3 - Fim 
           begin
              insert into SAE_AP_REL_BNDES
                        ( SESSIONID
                        , TIPO_DOCTO
                        , FORNECEDOR
                        , DOCUMENTO
                        , DATA_PAGAMENTO
                        , PARCELA
                        , LINHA
                        , DESCRICAO_LANCAMENTO
                        , PARCENT_RATEIO
                        , VALOR_TOTAL
                        , VALOR_LINHA_RATEIO
                        , VALOR_DESCONTO
                        , VALOR_DESCONTO_RATEADO
                        , RETENCAO_CONTRATUAL
                        , RETENCAO_CONTRATUAL_RATEADO
                        , VALORES_DIVERSOS
                        , VALORES_DIVERSOS_RATEADO
                        , VALOR_IMPOSTO_RETIDO
                        , VALOR_IMPOSTO_RETIDO_RATEADO
                        , VALOR_AD_APLICADO
                        , VALOR_AD_APLICADO_RATEADO
                        , VALOR_PAGO_RATEADO
                        , VALOR_PAGO
                        , CONTA_CONTABIL_RATEIO
                        , MOEDA_UTILIZADA
                        , HISTORICO_CONCATENADO
                        , BMEDICAO
                        , INVOICE_ID
                        , LINE_NUMBER
                        , CREATION_DATE
                        , FINAME --#120.2
                        --#120.3 - Inicio
                        , TIPO_FORNECEDOR      
                        , CNPJ_CPF     
                        , EMPRESA      
                        , DESCR_EMPRESA  
                        , CONTA      
                        , DESCR_CONTA    
                        , CENTRO_CUSTO   
                        , DESCR_CENTRO_CUSTO
                        , PROGRAMA     
                        , DESCR_PROGRAMA
                        , NOME_LOTE_PAGTO
                        , NUM_LOTE_PAGTO
                        --#120.3 - Fim
                        )
                   values
                        ( userenv('SESSIONID')
                        , r1.TIPO_DOCTO
                        , r1.FORNECEDOR
                        , r1.DOCUMENTO
                        , trunc(r1.DATA_PAGAMENTO)
                        , r1.PARCELA
                        , r2.LINHA
                        , r1.DESCRICAO_LANCAMENTO
                        , r1.PERC_RATEIO
                        , nvl(r2.VALOR_TOTAL,0) -- r1.VALOR_A_PAGAR--r1.VALOR_PAGO--nvl(r2.VALOR_TOTAL,0) --**
                        , nvl(r2.VALOR_LINHA_RATEIO,0)
                        , nvl(r1.VALOR_DESCONTO,0)
                        , nvl(v_valor_desconto_rateado,0)
                        , nvl(r2.RETENCAO_CONTRATUAL,0)
                        , nvl(r2.RETENCAO_CONTRATUAL_RATEADO,0)
                        , nvl(r2.VALORES_DIVERSOS,0)
                        , nvl(r2.VALORES_DIVERSOS_RATEADO,0)
                        , nvl(r2.VALOR_IMPOSTO_RETIDO,0)
                        , nvl(r2.VALOR_IMPOSTO_RETIDO_RATEADO,0)
                        , nvl(r2.VALOR_AD_APLICADO,0)
                        , nvl(r2.VALOR_AD_APLICADO_RATEADO,0)
                        , nvl(v_VALOR_PAGO_RATEADO,0)
                        , nvl(r1.VALOR_PAGO,0)
                        , nvl(v_concatenated_segments,r2.CONTA_CONTABIL_RATEIO)
                        , r1.MOEDA_UTILIZADA
                        , substr(replace(replace(r2.HISTORICO_CONCATENADO,chr(10),''),chr(13),''),1,500)
                        , substr(r2.BMEDICAO,1,500)
                        , r1.INVOICE_ID
                        , r2.reference_key1
                        , SYSDATE
                        , r2.FINAME --#120.2
                        --#120.3 - Inicio
                        , l_vTipoFornecedor     --TIPO_FORNECEDOR      
                        , l_vCpf_Cnpj           --CNPJ_CPF     
                        , l_vEmpresa            --EMPRESA      
                        , l_vDescEmpresa        --DESCR_EMPRESA  
                        , l_vConta              --CONTA      
                        , l_vDescConta          --DESCR_CONTA    
                        , l_vCentroCusto        --CENTRO_CUSTO   
                        , l_vDescCentroCusto    --DESCR_CENTRO_CUSTO
                        , l_vPrograma           --PROGRAMA     
                        , l_vDescPrograma       --DESCR_PROGRAMA
                        , r1.NOME_LOTE_PAGTO    --NOME_LOTE_PAGTO
                        , r1.NUM_LOTE_PAGTO     --NUM_LOTE_PAGTO                        
                        --#120.3 - Fim                        
                        );
           exception
              when others then
v_Step := 'Step 12.1';
                 FND_FILE.NEW_LINE(FND_FILE.LOG, 1);
                 FND_FILE.PUT(FND_FILE.LOG, 'Invoice: '||r1.documento||' - Parcela: '||r1.parcela||' - Linha: '||r2.linha);
                 FND_FILE.NEW_LINE(FND_FILE.LOG, 1);
                 FND_FILE.PUT(FND_FILE.LOG, 'Erro : ' || sqlerrm);
                 dbms_output.put_line('Erro - Invoice: '||r1.documento||' - Parcela: '||r1.parcela||' - Linha: '||r2.linha||' - '||sqlerrm);
                 RAISE_APPLICATION_ERROR(-20010, 'Problemas ao criar tabela temporaria SAE_AP_REL_BNDES.');
           end;
           --
        end loop;
     end loop;
     --
v_Step := 'Step 13';
     begin
         delete SAE_AP_REL_BNDES where creation_date <= sysdate-1;
     exception
        when others then
           FND_FILE.NEW_LINE(FND_FILE.LOG, 1);
           FND_FILE.PUT(FND_FILE.LOG, 'Erro dele SAE_AP_REL_BNDES: ' || sqlerrm);
           RAISE_APPLICATION_ERROR(-20020, 'Problemas ao excluir tabela temporaria SAE_AP_REL_BNDES.');
     end;
v_Step := 'Step 14';
     --
  exception
     when others then
          rollback;
          FND_FILE.NEW_LINE(FND_FILE.LOG, 1);
          FND_FILE.PUT(FND_FILE.LOG, v_Step||' - Invoice_id = '||v_invoice_id||'Erro Geral: ' || sqlerrm);
          dbms_output.put_line(v_Step||' - Invoice_id = '||v_invoice_id||' - Error Geral:'||sqlerrm);
          raise_application_error(-20001,'Error Geral:'||sqlerrm);
  end generation;
  --
END SAE_AP_REL_BNDES_PKG;
-- Indicativo de final de arquivo. Nao deve ser removido.

/
