UPDATE apps.oe_order_headers_all ooh
SET    fob_point_code = 'FOB'
WHERE  header_id IN (8806788);
--1 Registro