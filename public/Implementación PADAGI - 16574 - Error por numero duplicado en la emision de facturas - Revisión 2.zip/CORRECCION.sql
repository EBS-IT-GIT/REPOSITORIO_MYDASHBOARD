UPDATE apps.ra_customer_trx_all
SET    trx_date = to_date('01-06-2020','DD-MM-RRRR')
WHERE  customer_trx_id IN (14036312, 14480220);
--2 Registros