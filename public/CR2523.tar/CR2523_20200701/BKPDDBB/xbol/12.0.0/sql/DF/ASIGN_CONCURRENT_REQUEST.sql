  set define off;
begin end;

exit
