#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2523_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2523
# |
# | HISTORY
# |   01-JUL-20  Fumasoni, Leandro Gaspar - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2523_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2523_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2523
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/LDR
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/TB
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2523" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2523_10012.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2523"
AddAllLogs $CROUT "FND" "CR2523_10012.ldt"
mv CR2523_10012.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_OM_LIST_PRICE " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXOMPLIN.ctl XXOMPLIN.ctl
echo `ls -lh XXOMPLIN.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_OM_LIST_PRICE','BOLINF','$PATCHDIR','CR2523');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OM_LIST_PRICE* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OM_LIST_PRICES_PKG " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXOMPLIN.ctl XXOMPLIN.ctl
echo `ls -lh XXOMPLIN.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OM_LIST_PRICES_PKG','APPS','$PATCHDIR','CR2523');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OM_LIST_PRICES_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-LDR XXOMPLIN " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXOMPLIN.ctl XXOMPLIN.ctl
echo `ls -lh XXOMPLIN.ctl` >> $CROUT

mv XXOMPLIN* $DOWNDBDIR/xbol/12.0.0/sql/LDR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF ASIGN_CONCURRENT_REQUEST " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','ASIGN_CONCURRENT_REQUEST','','$PATCHDIR','CR2523');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv ASIGN_CONCURRENT_REQUEST* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF CREATE_DIRECTORY " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','CREATE_DIRECTORY','','$PATCHDIR','CR2523');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv CREATE_DIRECTORY* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOMACTLPREC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOMACTLPREC.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOMACTLPREC"
AddAllLogs $CROUT "FND" "XXOMACTLPREC.ldt"
mv XXOMACTLPREC.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXQPPLIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXQPPLIN.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXQPPLIN"
AddAllLogs $CROUT "FND" "XXQPPLIN.ldt"
mv XXQPPLIN.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_OM_LIST_PRICE " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_OM_LIST_PRICE >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_OM_LIST_PRICE.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_OM_LIST_PRICE.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_OM_LIST_PRICE.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_OM_LIST_PRICE.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_OM_LIST_PRICE.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_OM_LIST_PRICES_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_OM_LIST_PRICES_PKG >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OM_LIST_PRICES_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OM_LIST_PRICES_PKG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OM_LIST_PRICES_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OM_LIST_PRICES_PKG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OM_LIST_PRICES_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-LDR XXOMPLIN " >> $CROUT; echo "" >> $CROUT
`cp $INSTDIR/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl $XBOL_TOP/bin`
echo `ls -lh $XBOL_TOP/bin/XXOMPLIN.ctl` >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/LDR >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/LDR >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl -m $CRNUM  >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF ASIGN_CONCURRENT_REQUEST " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/ASIGN_CONCURRENT_REQUEST >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/ASIGN_CONCURRENT_REQUEST.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/ASIGN_CONCURRENT_REQUEST.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/ASIGN_CONCURRENT_REQUEST.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/ASIGN_CONCURRENT_REQUEST.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/ASIGN_CONCURRENT_REQUEST.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF CREATE_DIRECTORY " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/CREATE_DIRECTORY >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/CREATE_DIRECTORY.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXOMACTLPREC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOMACTLPREC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OM Concurrent Programs' 
              ,group_application   => 'ONT') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOMACTLPREC' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OM Concurrent Programs' 
              ,group_application   => 'ONT'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOMACTLPREC.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXQPPLIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXQPPLIN' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OM Concurrent Programs' 
              ,group_application   => 'ONT') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXQPPLIN' 
              ,program_application => 'XBOL' 
              ,request_group       => 'OM Concurrent Programs' 
              ,group_application   => 'ONT'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXQPPLIN.ldt -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch


cp $INSTDIR/xbol/12.0.0/sql/LDR/XXOMPLIN.ctl $XBOL_TOP/bin



. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2523" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2523_10012.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2523_10012.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
