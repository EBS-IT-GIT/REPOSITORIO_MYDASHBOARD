  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OM_LIST_PRICES_PKG" AS

 g_message_length VARCHAR2(32767);
 g_debug_flag     VARCHAR2(2);
 g_debug_mode     VARCHAR2(20);

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    get_data                                                              |
|                                                                          |
| Description                                                              |
|    Funcion privada que obtiene los datos a procesar.                     |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION get_data(p_request_id   IN      NUMBER
                 ,p_mesg_error   OUT     VARCHAR2
                 ) RETURN BOOLEAN;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    update_data                                                           |
|                                                                          |
| Description                                                              |
|    Funcion privada que actualiza los datos segun validaciones            |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_data(p_request_id   IN      NUMBER
                    ,p_mesg_error   OUT     VARCHAR2
                    ) RETURN BOOLEAN;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    update_errors                                                         |
|                                                                          |
| Description                                                              |
|    Funcion privada que actualiza los errores de la importacion.          |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_items(p_request_id   IN      NUMBER
                     ,p_mesg_error   OUT     VARCHAR2
                     ) RETURN BOOLEAN;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    update_processed                                                      |
|                                                                          |
| Description                                                              |
|    Funcion privada que actualiza los registros procesados.               |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_processed(p_request_id   IN      NUMBER
                         ,p_mesg_error   OUT     VARCHAR2
                         ) RETURN BOOLEAN;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    display_data                                                          |
|                                                                          |
| Description                                                              |
|    Funcion privada que despliega los datos de la interface.              |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION display_data(p_request_id   IN      NUMBER
                     ,p_value_char1  IN      VARCHAR2 DEFAULT NULL
                     ,p_mesg_error   OUT     VARCHAR2
                     ) RETURN BOOLEAN;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    delete_processed                                                      |
|                                                                          |
| Description                                                              |
|    Funcion privada que elimina los procesados en la Importacion          |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION delete_processed(p_request_id   IN      NUMBER
                         ,p_mesg_error   OUT     VARCHAR2
                         ) RETURN BOOLEAN;

/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    process_interface                                                     |
|                                                                          |
| Description                                                              |
|    Procedimiento del concurrente que procesa la interface.               |
|                                                                          |
| Parameters                                                               |
|    errbuf              OUT     VARCHAR2 Uso interno del concurrent.      |
|    retcode             OUT     NUMBER   Uso interno del concurrent.      |
|    p_batch_id          IN      NUMBER   Nro. de lote.                    |
|    p_draft_mode        IN      VARCHAR2 Modo draft (Y/N).                |
|    p_display_processed IN      VARCHAR2 Despliega procesados.            |
|    p_submit_interfaces IN      VARCHAR2 Ejecuta interfaces.              |
|    p_delete_processed  IN      VARCHAR2 Elimina procesados.              |
|    p_debug_flag        IN      VARCHAR2 Flag de debug.                   |
|                                                                          |
+=========================================================================*/
PROCEDURE process_interface(errbuf              OUT     VARCHAR2
                           ,retcode             OUT     NUMBER
                           ,p_display_processed IN      VARCHAR2
                           ,p_delete_processed  IN      VARCHAR2
                           ,p_draft_mode        IN      VARCHAR2
                           ,p_debug_flag        IN      VARCHAR2
                           );

END XX_OM_LIST_PRICES_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OM_LIST_PRICES_PKG" AS

/******************************************************************************
  NAME:        xx_om_list_prices_pkg.pkb
  PURPOSE:    Permitir la creación y actualización masiva de listas de precios.

  REVISIONS:
  Ver        Date        Author                Description
  ---------  ----------  -------------------   --------------------------------
  1.0        20/04/2020  LFUMASONI             Created this pkg

 ******************************************************************************/

/*=========================================================================+
|                                                                          |
| Private Procedure                                                        |
|    display_message_split                                                 |
|                                                                          |
| Description                                                              |
|    Procedimiento que despliega un mensaje en varias lineas, de acuerdo   |
|    al largo a la linea.                                                  |
|                                                                          |
| Parameters                                                               |
|    p_output  IN     VARCHAR2 Tipo de salida para desplegar.              |
|    p_message IN     VARCHAR2 Mensaje.                                    |
|                                                                          |
+=========================================================================*/
PROCEDURE display_message_split(p_output  IN      VARCHAR2
                               ,p_message IN      VARCHAR2
                               )
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
  v_cnt              NUMBER;
  v_message_length   NUMBER;
  v_message          VARCHAR2(32767);
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.DISPLAY_MESSAGE_SPLIT';
  -- ---------------------------------------------------------------------------
  -- Obtengo la longitud del mensaje.
  -- ---------------------------------------------------------------------------
  v_message_length := g_message_length;
  
  IF p_output         = 'DBMS' AND
     g_message_length > 255    THEN
     v_message_length := 255;
  END IF;
  -- ---------------------------------------------------------------------------
  -- Despliego el mensaje.
  -- ---------------------------------------------------------------------------
  FOR v_cnt IN 1..40000/v_message_length LOOP
      v_message := NULL;
      IF v_cnt = 1 THEN
         IF LENGTH(p_message) >= v_cnt * v_message_length THEN
            v_message := SUBSTR(p_message
                               ,1
                               ,v_cnt * v_message_length
                               );
         ELSE
            IF LENGTH(p_message) >= 1                        AND
               LENGTH(p_message) <  v_cnt * v_message_length THEN
               v_message := SUBSTR(p_message
                                  ,1
                                  );
            END IF;
         END IF;
      ELSE
         IF LENGTH(p_message) >= v_cnt * v_message_length THEN
            v_message := SUBSTR(p_message
                               ,((v_cnt-1
                                 ) * v_message_length
                                ) + 1
                               ,v_message_length
                               );
         ELSE
            IF LENGTH(p_message) >= ((v_cnt-1) * v_message_length) AND
               LENGTH(p_message) <    v_cnt    * v_message_length  THEN
               v_message := SUBSTR(p_message
                                  ,((v_cnt-1
                                    ) * v_message_length
                                   ) + 1
                                  );
            END IF;
         END IF;
      END IF;
      v_message := LTRIM(RTRIM(v_message));
      IF v_message IS NOT NULL THEN
         IF p_output = 'DBMS' THEN
            DBMS_OUTPUT.PUT_LINE(v_message);
         ELSIF p_output = 'CONC_LOG' THEN
            fnd_file.put(fnd_file.log
                        ,v_message
                        );
            fnd_file.new_line(fnd_file.log
                             ,1
                             );
         END IF;
      END IF;
  END LOOP;
EXCEPTION
  WHEN others THEN
    NULL;
END display_message_split;
/*=========================================================================+
|                                                                          |
| Private Procedure                                                        |
|    debug                                                                 |
|                                                                          |
| Description                                                              |
|    Procedimiento privado que escribe el debug.                           |
|                                                                          |
| Parameters                                                               |
|    p_message IN      VARCHAR2 Mensaje de Debug.                          |
|    p_type    IN      VARCHAR2 Tipo de Mensaje de Debug.                  |
|                                                                          |
+=========================================================================*/
PROCEDURE debug(p_message IN      VARCHAR2
               ,p_type    IN      VARCHAR2 DEFAULT NULL
               )
IS

  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
  v_message          VARCHAR2(32767);
BEGIN

  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.DEBUG';
  -- ---------------------------------------------------------------------------
  -- Realizo el debug.
  -- ---------------------------------------------------------------------------
  
  IF g_debug_flag = 'Y' THEN
     IF p_type IS NULL THEN
        v_message := SUBSTR(p_message
                           ,1
                           ,32767
                           );
     ELSE
        v_message := SUBSTR(TO_CHAR(SYSDATE
                                   ,'DD-MM-YYYY HH24:MI:SS'
                                   )                        ||
                            ' - '                           ||
                            p_message
                           ,1
                           ,32767
                           );
     END IF;
     display_message_split(p_output  => g_debug_mode
                          ,p_message => v_message
                          );
  END IF;
EXCEPTION
  WHEN others THEN
    NULL;
END debug;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    get_data                                                              |
|                                                                          |
| Description                                                              |
|    Funcion privada que obtiene los datos a procesar.                     |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION get_data(p_request_id   IN      NUMBER
                 ,p_mesg_error   OUT     VARCHAR2
                 ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.GET_DATA';
  
  debug(v_calling_sequence            ||
        '. '                          ||
        REPLACE(RPAD(' ',40),' ','-')
       ,'1'
       );
  -- ---------------------------------------------------------------------------
  -- Actualizo el estado de los datos a procesando.
  -- ---------------------------------------------------------------------------
  BEGIN
    UPDATE xx_om_list_price xolp
       SET status                = 'PROCESSING'
          ,last_update_date      = SYSDATE
          ,last_updated_by       = fnd_global.user_id
          ,request_id            = p_request_id
     WHERE xolp.status   = 'NEW';
  EXCEPTION
    WHEN others THEN
      p_mesg_error := 'Error actualizando '            ||
                      'el estado '                     ||
                      'de los datos '                  ||
                      'a Procesando '                  ||
                      'en la tabla de '                ||
                      'Lista de Precios ' ||
                      '(XX_OM_LIST_PRICE).'            ||
                      SQLERRM;
      RETURN (FALSE);
  END;
  -- ---------------------------------------------------------------------------
  -- Verifico si existen datos a procesar.
  -- ---------------------------------------------------------------------------
  IF NVL(SQL%ROWCOUNT,0) = 0 THEN
     p_mesg_error := 'NO_DATA_FOUND';
  END IF;

  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                                  ||
                    '. Error general '                                  ||
                    'obteniendo los datos a procesar. '                 ||
                    SQLERRM;
    RETURN (FALSE);
END get_data;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    update_data                                                           |
|                                                                          |
| Description                                                              |
|    Funcion privada que actualiza los datos segun validaciones            |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_data(p_request_id   IN      NUMBER
                    ,p_mesg_error   OUT     VARCHAR2
                    ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.UPDATE_DATA';

  debug(v_calling_sequence            ||
        '. '                          ||
        REPLACE(RPAD(' ',40),' ','-')
       ,'1'
       );
  -- ---------------------------------------------------------------------------
  --Elimino Registros Duplicados
  -- ---------------------------------------------------------------------------
  BEGIN
  DELETE FROM bolinf.xx_om_list_price xolp 
   WHERE rowid > (SELECT min(rowid) 
                    FROM bolinf.xx_om_list_price xolp2 
                   WHERE xolp.item_code = xolp2.item_code 
                     AND xolp.list_price_name = xolp2.list_price_name 
                     AND xolp.price = xolp2.price);
  COMMIT;
  EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                           ||
                    '. Error general '                           ||
                    'datos duplicados de la Importacion. ' ||
                    SQLERRM;
    RETURN (FALSE);
  END;
  -- ---------------------------------------------------------------------------
  -- Actualizo los datos
  -- ---------------------------------------------------------------------------
  BEGIN
    UPDATE xx_om_list_price xolp
       SET item_exist =
           (SELECT 'Y'
              FROM mtl_system_items_b msi
             WHERE xolp.item_code         = msi.segment1 
               AND ROWNUM                 = 1
           )
          ,list_price_exist   =
           (SELECT 'Y'
              FROM qp_list_headers_vl qpht
             WHERE 1 = 1
               AND xolp.list_price_name = qpht.name 
               AND ROWNUM               = 1
           )
          ,duplicate_line = 
           (SELECT DISTINCT 'Y' 
              FROM xx_om_list_price xolp2
             WHERE xolp2.item_code         = xolp.item_code
               AND xolp2.list_price_name   = xolp.list_price_name
               AND xolp2.price             = xolp.price
               AND xolp2.status            = 'PROCESSING'
               AND xolp2.request_id        = p_request_id
               AND xolp.rowid             != xolp2.rowid
           )
          ,last_update_date  = SYSDATE
          ,last_updated_by   = fnd_global.user_id
     WHERE xolp.status     = 'PROCESSING'
       AND xolp.request_id = p_request_id;
  EXCEPTION
    WHEN others THEN
      p_mesg_error := 'Error actualizando '            ||
                      'los datos (1) '                 ||
                      'en la tabla de '                ||
                      'Interface de Lista de Precios ' ||
                      '(XX_OM_LIST_PRICE).'            ||
                      SQLERRM;
      RETURN (FALSE);
  END;

    debug(v_calling_sequence               ||
          '. Se actualizaron: '            ||
          NVL(SQL%ROWCOUNT,0)              ||
          ' registros '                    ||
          'en la tabla de '                ||
          'Interface de Lista de Precios ' ||
          '(XX_OM_LIST_PRICE)'
         ,'1'
         );

  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                           ||
                    '. Error general '                           ||
                    'actualizando los datos de la Importacion. ' ||
                    SQLERRM;
    RETURN (FALSE);
END update_data;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    insert_interfaces                                                     |
|                                                                          |
| Description                                                              |
|    Funcion privada de actualizacion de item.                             |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_items(p_request_id   IN      NUMBER
                     ,p_mesg_error   OUT     VARCHAR2
                     ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
  v_return_status    VARCHAR2(1);
  v_msg_count        NUMBER(15);
  v_msg_data         VARCHAR2(32767);
  v_msg_index_out    NUMBER(15);
  v_mesg_error       VARCHAR2(32767);
  l_product_value    NUMBER;
  l_new              NUMBER;
  i                  NUMBER := 1;
  -- ---------------------------------------------------------------------------
  -- Registros y Tablas propias de la Api.
  -- ---------------------------------------------------------------------------
  gpr_price_list_rec           qp_price_list_pub.price_list_rec_type;
  gpr_price_list_val_rec       qp_price_list_pub.price_list_val_rec_type;
  gpr_price_list_line_tbl      qp_price_list_pub.price_list_line_tbl_type;
  gpr_price_list_line_val_tbl  qp_price_list_pub.price_list_line_val_tbl_type;
  gpr_qualifiers_tbl           qp_qualifier_rules_pub.qualifiers_tbl_type;
  gpr_qualifiers_val_tbl       qp_qualifier_rules_pub.qualifiers_val_tbl_type;
  gpr_pricing_attr_tbl         qp_price_list_pub.pricing_attr_tbl_type;
  gpr_pricing_attr_val_tbl     qp_price_list_pub.pricing_attr_val_tbl_type;
  ppr_price_list_rec           qp_price_list_pub.price_list_rec_type;
  ppr_price_list_val_rec       qp_price_list_pub.price_list_val_rec_type;
  ppr_price_list_line_tbl      qp_price_list_pub.price_list_line_tbl_type;
  ppr_price_list_line_val_tbl  qp_price_list_pub.price_list_line_val_tbl_type;
  ppr_qualifiers_tbl           qp_qualifier_rules_pub.qualifiers_tbl_type;
  ppr_qualifiers_val_tbl       qp_qualifier_rules_pub.qualifiers_val_tbl_type;
  ppr_pricing_attr_tbl         qp_price_list_pub.pricing_attr_tbl_type;
  ppr_pricing_attr_val_tbl     qp_price_list_pub.pricing_attr_val_tbl_type;

  -- ---------------------------------------------------------------------------
  -- Definicion de Cursores
  -- ---------------------------------------------------------------------------
  -- ---------------------------------------------------------------------------
  -- Cursor cabecera.
  -- ---------------------------------------------------------------------------
  CURSOR data IS
    SELECT qlhb.list_header_id
          ,xolp.list_price_name
          ,xolp.item_code
          ,xolp.item_uom
          ,xolp.price
      FROM xx_om_list_price xolp
         , qp_list_headers_b qlhb
         , qp_list_headers_tl qlht
     WHERE 1 = 1
       AND qlhb.end_date_active IS NULL
       --AND qlhb.orig_org_id = 257
       AND qlht.language = 'ESA'
       AND qlhb.list_header_id = qlht.list_header_id
       AND qlht.name = xolp.list_price_name
       AND xolp.duplicate_line  is null
       AND xolp.status     = 'PROCESSING'
       AND xolp.request_id = p_request_id
     GROUP BY qlhb.list_header_id
          ,xolp.list_price_name
          ,xolp.item_code
          ,xolp.item_uom
          ,xolp.price;
    
    cd   data%ROWTYPE;

  -- ---------------------------------------------------------------------------
  -- Cursor Lineas.
  -- ---------------------------------------------------------------------------

  CURSOR data_line(p_list_header_id number, p_product_attr_value varchar2) IS
    SELECT *
      FROM qp_list_lines_v
     WHERE list_header_id = p_list_header_id
       AND product_attr_value = p_product_attr_value
       AND start_date_active = (SELECT MAX(start_date_active)
                                  FROM qp_list_lines_v
                                 WHERE list_header_id = p_list_header_id
                                   AND product_attr_value = p_product_attr_value);
       --AND end_date_active IS NULL;    
    cdl      data_line%ROWTYPE;
          
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.UPDATE_ITEMS';
  
  debug(v_calling_sequence            ||
        '. '                          ||
        REPLACE(RPAD(' ',40),' ','-')
       ,'1'
       );

  -- ---------------------------------------------------------------------------
  -- Recorro las lineas de la interface.
  -- ---------------------------------------------------------------------------
  debug(v_calling_sequence                          ||
        '. Recorriendo las lineas de la Importacion.'
       ,'1'
       );

  OPEN data;
  LOOP
  FETCH data INTO cd;
  EXIT WHEN data%NOTFOUND;

   v_return_status := NULL;
   v_msg_count     := NULL;
   v_msg_data      := NULL;
   v_mesg_error    := NULL;
   l_new           := 0;    
   
   debug(v_calling_sequence      ||
         '. Cabecera'            ||
         TO_CHAR(v_msg_count)
        ,'1'
         );
   debug(v_calling_sequence      ||
         '. '                    ||
         REPLACE(RPAD(' ',40),' ','-')
        ,'1'
         );
   debug(v_calling_sequence             ||
         '. Id de lista de precio: '    ||
         TO_CHAR(cd.list_header_id)
        ,'1'
         );
   debug(v_calling_sequence             ||
         '. Lista de Precio: '          ||
         cd.list_price_name
        ,'1'
         );
   debug(v_calling_sequence             ||
         '. Item Code: '                ||
         cd.item_code
        ,'1'
         );
   debug(v_calling_sequence             ||
         '. UOM Code: '                 ||
         cd.item_uom
        ,'1'
         );
   debug(v_calling_sequence             ||
         '. Price: '                    ||
         TO_CHAR(cd.price)
        ,'1'
         );    
   debug(v_calling_sequence      ||
         '. '                    ||
         REPLACE(RPAD(' ',40),' ','-')
        ,'1'
         );
         
   BEGIN

      SELECT inventory_item_id
        INTO l_product_value
        FROM inv.mtl_system_items_b
       WHERE segment1 = cd.item_code
         AND rownum=1;

      debug(v_calling_sequence                          ||
            '. Inventory Item ID '                      ||
            l_product_value
           ,'1'
           );

   EXCEPTION
    WHEN others THEN
         v_mesg_error := '. No existe Item ID asociado al articulo '||
                         cd.item_code                               ||
                         ' de la lista de precio '                  ||
                         cd.list_price_name                         ||
                         '.';
   END;

   IF v_mesg_error IS NULL THEN

   OPEN data_line (cd.list_header_id, l_product_value);
   FETCH data_line INTO cdl;

      debug(v_calling_sequence            ||
         '. Linea'
        ,'1'
        );
      debug(v_calling_sequence            ||
        '. '                              ||
        REPLACE(RPAD(' ',40),' ','-')
       );     

    IF data_line%NOTFOUND THEN
      IF v_mesg_error IS NULL THEN

         v_return_status := NULL;
         v_msg_count     := NULL;
         v_msg_data      := NULL;
         v_mesg_error    := NULL;

         gpr_price_list_line_tbl.delete;
         gpr_pricing_attr_tbl.delete;
         oe_msg_pub.initialize;

         gpr_price_list_rec.list_header_id               := cd.list_header_id;
         gpr_price_list_line_tbl(1).list_line_id         := fnd_api.g_miss_num;
         gpr_price_list_line_tbl(1).list_line_type_code  := 'PLL';
         gpr_price_list_line_tbl(1).operation            := qp_globals.g_opr_create;
         gpr_price_list_line_tbl(1).operand              := cd.price;
         gpr_price_list_line_tbl(1).modifier_level_code  := 'LINE';
         gpr_price_list_line_tbl(1).arithmetic_operator  := 'UNIT_PRICE';
         gpr_price_list_line_tbl(1).primary_uom_flag     := 'Y';
         gpr_price_list_line_tbl(1).product_precedence   := 220;
         gpr_price_list_line_tbl(1).start_date_active    := trunc(sysdate);
         gpr_price_list_line_tbl(1).end_date_active      := null;
         gpr_pricing_attr_tbl(1).pricing_attribute_id    := fnd_api.g_miss_num;
         gpr_pricing_attr_tbl(1).list_line_id            := fnd_api.g_miss_num;
         gpr_pricing_attr_tbl(1).product_attribute_context := 'ITEM';
         gpr_pricing_attr_tbl(1).product_attribute       := 'PRICING_ATTRIBUTE1';
         gpr_pricing_attr_tbl(1).product_attr_value      := l_product_value;
         gpr_pricing_attr_tbl(1).product_uom_code        := cd.item_uom;        
         gpr_pricing_attr_tbl(1).excluder_flag           := 'N';
         gpr_pricing_attr_tbl(1).attribute_grouping_no   := 1;
         gpr_pricing_attr_tbl(1).price_list_line_index   := 1;
         gpr_pricing_attr_tbl(1).operation               := qp_globals.g_opr_create;

          debug(v_calling_sequence                                                       ||
             '. Creo Articulo '||l_product_value ||' Para la lista: '||cd.list_price_name
            ,'1'
            );

         BEGIN

           qp_price_list_pub.process_price_list
             (p_api_version_number      => 1
             ,p_init_msg_list           => fnd_api.g_false
             ,p_return_values           => fnd_api.g_false
             ,p_commit                  => fnd_api.g_false
             ,x_return_status           => v_return_status
             ,x_msg_count               => v_msg_count
             ,x_msg_data                => v_msg_data
             ,p_price_list_rec          => gpr_price_list_rec
             ,p_price_list_line_tbl     => gpr_price_list_line_tbl
             ,p_pricing_attr_tbl        => gpr_pricing_attr_tbl
             ,x_price_list_rec          => ppr_price_list_rec
             ,x_price_list_val_rec      => ppr_price_list_val_rec
             ,x_price_list_line_tbl     => ppr_price_list_line_tbl
             ,x_price_list_line_val_tbl => ppr_price_list_line_val_tbl
             ,x_qualifiers_tbl          => ppr_qualifiers_tbl
             ,x_qualifiers_val_tbl      => ppr_qualifiers_val_tbl
             ,x_pricing_attr_tbl        => ppr_pricing_attr_tbl
             ,x_pricing_attr_val_tbl    => ppr_pricing_attr_val_tbl
             );
             
         debug(v_calling_sequence ||
               '. Estado: '       ||
               v_return_status
              ,'1'
              );
         debug(v_calling_sequence      ||
               '. Cant. de mensajes: ' ||
               TO_CHAR(v_msg_count)
              ,'1'
              );
         EXCEPTION
           WHEN others THEN
             p_mesg_error := 'Error llamando al procedimiento '       ||
                             'QP_PRICE_LIST_PUB.PROCESS_PRICE_LIST. ' ||
                             SQLERRM;
         END;

         IF NVL(v_return_status,fnd_api.g_ret_sts_error) != 
            fnd_api.g_ret_sts_success                    THEN
            FOR cnt IN 1 ..v_msg_count LOOP
                oe_msg_pub.get(p_msg_index     => cnt 
                              ,p_encoded       => fnd_api.g_false
                              ,p_data          => v_msg_data
                              ,p_msg_index_out => v_msg_index_out
                              );
            v_mesg_error := v_msg_data; 
            END LOOP;
         END IF;
         
         IF v_mesg_error IS NULL THEN
            l_new:= 1;
         END IF;
      END IF;
    END IF;
     
    IF l_new = 0 THEN

      -- --------------------------------------------------------------------
      -- Verifico fecha desde y fecha hasta que cumplan con la linea de tiempo
      -- -----------------------------------------------------------------------
      IF cdl.end_date_active > TRUNC(sysdate) THEN
         v_mesg_error := 'El articulo posee una fecha de Fin Futura: '   ||
                          cdl.end_date_active                            ||
                          ' Por favor revisar.'; 
      ELSIF cdl.start_date_active > TRUNC(sysdate) THEN
         v_mesg_error := 'El articulo posee una fecha de Inicio Futura: '||
                          cdl.start_date_active                          ||
                          ' Por favor revisar.'; 
      END IF; 

      debug(v_calling_sequence                          ||
            v_mesg_error
           ,'1'
           );
      -- -----------------------------------------------------------------------
      -- Verifico si existe la linea de lista de precio, actualizo la fecha de 
      -- fin de la linea vigente, con la fecha de inicio actual de la interface
      -- menos 1 dia.
      -- -----------------------------------------------------------------------
      IF v_mesg_error IS NULL THEN            

         v_return_status := NULL;
         v_msg_count     := NULL;
         v_msg_data      := NULL;
         v_mesg_error    := NULL;
         
         gpr_price_list_line_tbl.delete;
         gpr_pricing_attr_tbl.delete;
         oe_msg_pub.initialize;
         
         gpr_price_list_rec.list_header_id          := cd.list_header_id;
         gpr_price_list_line_tbl(1).list_line_id    := cdl.list_line_id;
         gpr_price_list_line_tbl(1).operation       := qp_globals.g_opr_update;
         gpr_price_list_line_tbl(1).end_date_active := trunc(sysdate) -1;

          debug(v_calling_sequence                                                       ||
             '. Set Fecha Fin Para el Articulo: '||l_product_value ||' Para la lista: '||cd.list_price_name
            ,'1'
            );

         BEGIN
           qp_price_list_pub.process_price_list
             (p_api_version_number      => 1
             ,p_init_msg_list           => fnd_api.g_true
             ,p_return_values           => fnd_api.g_false
             ,p_commit                  => fnd_api.g_false
             ,x_return_status           => v_return_status
             ,x_msg_count               => v_msg_count
             ,x_msg_data                => v_msg_data
             ,p_price_list_rec          => gpr_price_list_rec
             ,p_price_list_line_tbl     => gpr_price_list_line_tbl
             ,p_pricing_attr_tbl        => gpr_pricing_attr_tbl
             ,x_price_list_rec          => ppr_price_list_rec
             ,x_price_list_val_rec      => ppr_price_list_val_rec
             ,x_price_list_line_tbl     => ppr_price_list_line_tbl
             ,x_price_list_line_val_tbl => ppr_price_list_line_val_tbl
             ,x_qualifiers_tbl          => ppr_qualifiers_tbl
             ,x_qualifiers_val_tbl      => ppr_qualifiers_val_tbl
             ,x_pricing_attr_tbl        => ppr_pricing_attr_tbl
             ,x_pricing_attr_val_tbl    => ppr_pricing_attr_val_tbl
             );
         EXCEPTION
           WHEN others THEN
             p_mesg_error := 'Error llamando al procedimiento '       ||
                             'QP_PRICE_LIST_PUB.PROCESS_PRICE_LIST. ' ||
                             SQLERRM;
         END;

         debug(v_calling_sequence ||
               '. Estado: '       ||
               v_return_status
              ,'1'
              );
         debug(v_calling_sequence      ||
               '. Cant. de mensajes: ' ||
               TO_CHAR(v_msg_count)
              ,'1'
              );

        IF NVL(v_return_status,fnd_api.g_ret_sts_error) != 
            fnd_api.g_ret_sts_success                    THEN
            FOR cnt IN 1 ..v_msg_count LOOP
                oe_msg_pub.get(p_msg_index     => cnt 
                              ,p_encoded       => fnd_api.g_false
                              ,p_data          => v_msg_data
                              ,p_msg_index_out => v_msg_index_out
                              );
                v_mesg_error := v_msg_data; 
            END LOOP;
         END IF;
      END IF;
      -- -----------------------------------------------------------------------
      -- Creo la linea de lista de precio.
      -- -----------------------------------------------------------------------
      IF v_mesg_error IS NULL THEN

          debug(v_calling_sequence                                                       ||
             '. Set Nuevo Precio Para el Articulo: '||l_product_value ||' Para la lista: '||cd.list_price_name
            ,'1'
            );
          debug(v_calling_sequence                   ||
                '. Id de linea de lista de precio: ' ||
                TO_CHAR(cdl.list_line_id)
               ,'1'
               );
          debug(v_calling_sequence           ||
                '. Fecha inicio vigencia: '  ||
                TO_CHAR(trunc(sysdate)
                       ,'DD-MON-YYYY'
                       )
               ,'1'
               );
          debug(v_calling_sequence            ||
                '. '                          ||
                REPLACE(RPAD(' ',40),' ','-')
               ,'1'
               );
         v_return_status := NULL;
         v_msg_count     := NULL;
         v_msg_data      := NULL;
         v_mesg_error    := NULL;
      
         gpr_price_list_line_tbl.delete;
         gpr_pricing_attr_tbl.delete;
         oe_msg_pub.initialize;
      
         gpr_price_list_rec.list_header_id               := cd.list_header_id;
         gpr_price_list_line_tbl(1).list_line_id         := qp_list_lines_s.nextval;
         gpr_price_list_line_tbl(1).list_line_type_code  := 'PLL';
         gpr_price_list_line_tbl(1).operation            := qp_globals.g_opr_create;
         gpr_price_list_line_tbl(1).operand              := cd.price;
         gpr_price_list_line_tbl(1).modifier_level_code  := 'LINE';
         gpr_price_list_line_tbl(1).arithmetic_operator  := 'UNIT_PRICE';
         gpr_price_list_line_tbl(1).primary_uom_flag     := cdl.primary_uom_flag;
         gpr_price_list_line_tbl(1).product_precedence   := cdl.product_precedence;
         gpr_price_list_line_tbl(1).start_date_active    := trunc(sysdate);
         gpr_price_list_line_tbl(1).end_date_active      := null;
         gpr_pricing_attr_tbl(1).pricing_attribute_id    := qp_pricing_attributes_s.nextval;
         gpr_pricing_attr_tbl(1).list_line_id            := qp_list_lines_s.currval;
         gpr_pricing_attr_tbl(1).product_attribute_context := 'ITEM';
         gpr_pricing_attr_tbl(1).product_attribute       := cdl.product_attribute;
         gpr_pricing_attr_tbl(1).product_attr_value      := cdl.product_attr_value;
         gpr_pricing_attr_tbl(1).product_uom_code        := cd.item_uom;
         gpr_pricing_attr_tbl(1).excluder_flag           := 'N';
         gpr_pricing_attr_tbl(1).attribute_grouping_no   := 1;
         gpr_pricing_attr_tbl(1).price_list_line_index   := 1;
         gpr_pricing_attr_tbl(1).operation               := qp_globals.g_opr_create;

         BEGIN
      
           qp_price_list_pub.process_price_list
             (p_api_version_number      => 1
             ,p_init_msg_list           => fnd_api.g_false
             ,p_return_values           => fnd_api.g_false
             ,p_commit                  => fnd_api.g_false
             ,x_return_status           => v_return_status
             ,x_msg_count               => v_msg_count
             ,x_msg_data                => v_msg_data
             ,p_price_list_rec          => gpr_price_list_rec
             ,p_price_list_line_tbl     => gpr_price_list_line_tbl
             ,p_pricing_attr_tbl        => gpr_pricing_attr_tbl
             ,x_price_list_rec          => ppr_price_list_rec
             ,x_price_list_val_rec      => ppr_price_list_val_rec
             ,x_price_list_line_tbl     => ppr_price_list_line_tbl
             ,x_price_list_line_val_tbl => ppr_price_list_line_val_tbl
             ,x_qualifiers_tbl          => ppr_qualifiers_tbl
             ,x_qualifiers_val_tbl      => ppr_qualifiers_val_tbl
             ,x_pricing_attr_tbl        => ppr_pricing_attr_tbl
             ,x_pricing_attr_val_tbl    => ppr_pricing_attr_val_tbl
             );

         debug(v_calling_sequence ||
               '. Estado: '       ||
               v_return_status
              ,'1'
              );
         debug(v_calling_sequence      ||
               '. Cant. de mensajes: ' ||
               TO_CHAR(v_msg_count)
              ,'1'
              );
         EXCEPTION
           WHEN others THEN
             p_mesg_error := 'Error llamando al procedimiento '       ||
                             'QP_PRICE_LIST_PUB.PROCESS_PRICE_LIST. ' ||
                             SQLERRM;
             --EXIT;
         END;
                   
         IF NVL(v_return_status,fnd_api.g_ret_sts_error) != 
            fnd_api.g_ret_sts_success                    THEN
            FOR cnt IN 1 ..v_msg_count LOOP
                oe_msg_pub.get(p_msg_index     => cnt 
                              ,p_encoded       => fnd_api.g_false
                              ,p_data          => v_msg_data
                              ,p_msg_index_out => v_msg_index_out
                              );
            v_mesg_error := v_msg_data; 
            END LOOP;
         END IF;
      END IF;
      -- -----------------------------------------------------------------------
      -- Verifico si se produjo un error.
      -- -----------------------------------------------------------------------
      IF v_mesg_error IS NOT NULL THEN
         BEGIN
            UPDATE xx_om_list_price xolp
               SET error_messages    =
                   SUBSTR(v_mesg_error
                         ,1,4000
                         )
                  ,status            = 'ERROR'
                  ,last_update_date  = SYSDATE
                  ,last_updated_by   = fnd_global.user_id
             WHERE xolp.item_code = cd.item_code;
          EXCEPTION
           WHEN others THEN
             p_mesg_error := 'Error actualizando '            ||
                             'el estado '                     ||
                             'de los datos '                  ||
                             'a Error '                       ||
                             'en la tabla de '                ||
                             'Lista de Precios '              ||
                             '(XX_OM_LIST_PRICE).'            ||
                             SQLERRM;
         END;
      END IF;
    END IF;
   CLOSE data_line;
   END IF;
  END LOOP;
  CLOSE data;

    debug(v_calling_sequence               ||
          '. Se actualizaron: '            ||
          NVL(SQL%ROWCOUNT,0)              ||
          ' registro /s con '              ||
          'el estado '                     ||
          'de los datos '                  ||
          'a Error '                       ||
          'en la tabla de '                ||
          'Interface de Lista de Precios ' ||
          '(XX_OM_LIST_PRICE)'
         ,'1'
         );
      
  -- ---------------------------------------------------------------------------
  -- Verifico si se produjo un error.
  -- ---------------------------------------------------------------------------
  IF p_mesg_error IS NOT NULL THEN
     RETURN (FALSE);
  END IF;
  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                       ||
                    '. Error general '                       ||
                    'actualizando informacion de items '     ||
                    SQLERRM;
    RETURN (FALSE);
END update_items;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    update_processed                                                      |
|                                                                          |
| Description                                                              |
|    Funcion privada que actualiza los registros procesados.               |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_processed(p_request_id   IN      NUMBER
                         ,p_mesg_error   OUT     VARCHAR2
                         ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICE.UPDATE_PROCESSED';

  debug(v_calling_sequence            ||
        '. '                          ||
        REPLACE(RPAD(' ',40),' ','-')
       ,'1'
       );
  debug(v_calling_sequence
       ,'1'
       );

  -- ---------------------------------------------------------------------------
  -- Actualizo el estado de los datos a procesado.
  -- ---------------------------------------------------------------------------
  BEGIN
    UPDATE xx_om_list_price xolp
       SET status            = 'PROCESSED'
          ,last_update_date  = SYSDATE
          ,last_updated_by   = fnd_global.user_id
     WHERE xolp.status       = 'PROCESSING'
       AND xolp.request_id   = p_request_id;
  EXCEPTION
    WHEN others THEN
      p_mesg_error := 'Error actualizando '            ||
                      'el estado '                     ||
                      'de los registros '              ||
                      'a Procesado '                   ||
                      'en la tabla de '                ||
                      'Lista de Precios '              ||
                      'XX_OM_LIST_PRICE.'              ||
                      SQLERRM;
      RETURN (FALSE);
  END;
  debug(v_calling_sequence               ||
        '. Se actualizaron: '            ||
        NVL(SQL%ROWCOUNT,0)              ||
        ' registro /s con '              ||
        'el estado '                     ||
        'de los datos '                  ||
        'a Procesado '                   ||
        'en la tabla de '                ||
        'Interface de Lista de Precios ' ||
        '(XX_OM_LIST_PRICE)'
       ,'1'
       );

  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                                ||
                    '. Error general '                                ||
                    'actualizando los procesados en la Importacion. ' ||
                    SQLERRM;
    RETURN (FALSE);
END update_processed;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    update_errors                                                         |
|                                                                          |
| Description                                                              |
|    Funcion privada que actualiza los errores de la interface.            |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_value_char1..20 IN      VARCHAR2 Datos varios de tipo caracter.     |
|    p_value_num1..20  IN      NUMBER   Datos varios de tipo numerico.     |
|    p_value_date1..20 IN      DATE     Datos varios de tipo fecha.        |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION update_errors(p_request_id   IN      NUMBER
                      ,p_mesg_error   OUT     VARCHAR2
                      ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICE_PKG.UPDATE_ERRORS';
  debug(v_calling_sequence            ||
        '. '                          ||
        REPLACE(RPAD(' ',40),' ','-')
       ,'1'
       );
  debug(v_calling_sequence
       ,'1'
       );
  -- ---------------------------------------------------------------------------
  -- Actualizo los errores de la interface.
  -- ---------------------------------------------------------------------------
  BEGIN
    UPDATE xx_om_list_price xolp
       SET error_messages =
           SUBSTR(xolp.error_messages ||
                  -- item_exist
                  DECODE(xolp.item_exist
                        ,NULL,' - No se encontro ' ||
                              'el item'
                        ) ||
                  -- list_price_exist
                  DECODE(xolp.list_price_exist
                        ,NULL,' - No se encontro '  ||
                              'la lista de precio.'  
                        ) ||
                  -- unit_price
                  DECODE(SIGN(NVL(xolp.price,0))
                        ,'-1',' - Precio unitario invalido.'
                        ,'0' ,' - Precio unitario invalido.'
                        ) ||
                  -- duplicate_item
                  DECODE(xolp.duplicate_line
                        ,'Y',' - Item Duplicado '         ||
                             '- Misma lista de Precio '   ||
                             '- Mismo Precio.'
                        ) ||
                  ''
                 ,2
                 ,4000
                 )
          ,last_update_date  = SYSDATE
     WHERE xolp.status     = 'PROCESSING'
       AND xolp.request_id = p_request_id;
  EXCEPTION
    WHEN others THEN
      p_mesg_error := 'Error actualizando '            ||
                      'los errores '                   ||
                      'en la tabla de '                ||
                      'Interface de Lista de Precios ' ||
                      '(XX_OM_LIST_PRICE). '           ||
                      SQLERRM;
      RETURN (FALSE);
  END;
  debug(v_calling_sequence               ||
        '. Se actualizaron: '            ||
        NVL(SQL%ROWCOUNT,0)              ||
        ' registros '                    ||
        'de los errores '                ||
        'en la tabla de '                ||
        'Interface de Lista de Precios ' ||
        '(XX_OM_LIST_PRICE)'
       ,'1'
       );
  -- ---------------------------------------------------------------------------
  -- Actualizo el estado de los datos a error.
  -- ---------------------------------------------------------------------------
  BEGIN
    UPDATE xx_om_list_price xolp
       SET status            = 'ERROR'
          ,last_update_date  = SYSDATE
     WHERE xolp.status              = 'PROCESSING'
       AND xolp.request_id          = p_request_id
       AND xolp.error_messages IS NOT NULL;
  EXCEPTION
    WHEN others THEN
      p_mesg_error := 'Error actualizando '            ||
                      'el estado '                     ||
                      'de los datos '                  ||
                      'a Error '                       ||
                      'en la tabla de '                ||
                      'Interface de Lista de Precios ' ||
                      'XX_OM_LIST_PRICE. '             ||
                      SQLERRM;
      RETURN (FALSE);
  END;
  debug(v_calling_sequence               ||
        '. Se actualizaron: '            ||
        NVL(SQL%ROWCOUNT,0)              ||
        ' registros con '                ||
        'el estado '                     ||
        'de los datos '                  ||
        'a Error '                       ||
        'en la tabla de '                ||
        'Interface de Lista de Precios ' ||
        '(XX_OM_LIST_PRICE)'
       ,'1'
       );
  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                           ||
                    '. Error general '                           ||
                    'actualizando los errores de la interface. ' ||
                    SQLERRM;
    RETURN (FALSE);
END update_errors;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    display_data                                                          |
|                                                                          |
| Description                                                              |
|    Funcion privada que despliega los datos de la interface.              |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION display_data(p_request_id   IN      NUMBER
                     ,p_value_char1  IN      VARCHAR2 DEFAULT NULL
                     ,p_mesg_error   OUT     VARCHAR2
                     ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
  v_length_line      NUMBER(15);
  v_line_single      VARCHAR2(32767);
  v_line_separator   VARCHAR2(32767);
  v_title1           VARCHAR2(32767);
  v_title2           VARCHAR2(32767);
  v_title3           VARCHAR2(32767);
  v_header           VARCHAR2(32767);
  v_header_separator VARCHAR2(32767);
  v_line             VARCHAR2(32767);
  v_cnt_process      NUMBER(15);
  v_cnt_success      NUMBER(15);
  v_cnt_error        NUMBER(15);
  v_cnt              NUMBER(15);
  v_message_length   NUMBER(15);
  v_message          VARCHAR2(32767);
  v_mesg_error       VARCHAR2(32767);
  TYPE v_rec_messages IS RECORD(message1 VARCHAR2(4000)
                               ,message2 VARCHAR2(4000)
                               );
  TYPE v_type_messages IS TABLE OF v_rec_messages INDEX BY BINARY_INTEGER;
  v_tab_messages v_type_messages;
  -- ---------------------------------------------------------------------------
  -- Declaracion de Cursores.
  -- ---------------------------------------------------------------------------
  -- ---------------------------------------------------------------------------
  -- Cursor de errores de la interface.
  -- ---------------------------------------------------------------------------
  CURSOR errors IS
    SELECT xolp.list_price_name                          list_price_name
          ,xolp.item_code                                item_code
          ,xolp.item_uom
          ,TRIM(TO_CHAR(xolp.price,'999999D99'))         unit_price
          ,xolp.error_messages
      FROM xx_om_list_price  xolp
     WHERE xolp.status              = 'ERROR'
       AND xolp.request_id          = p_request_id
       AND xolp.error_messages IS NOT NULL
     ORDER BY 1;
  -- ---------------------------------------------------------------------------
  -- Cursor de procesados de la interface.
  -- ---------------------------------------------------------------------------
  CURSOR processeds IS
    SELECT xolp.list_price_name                          list_price_name
          ,xolp.item_code                                item_code
          ,xolp.item_uom
          ,TRIM(TO_CHAR(xolp.price,'999999D99'))         unit_price
          ,xolp.error_messages
      FROM xx_om_list_price   xolp
     WHERE xolp.status          = 'PROCESSED'
       AND xolp.request_id = p_request_id
     ORDER BY 1;
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICE_PKG.DISPLAY_DATA';
  v_length_line      := 171;
  -- ---------------------------------------------------------------------------
  -- Inicializo variables de la salida.
  -- ---------------------------------------------------------------------------
  v_line_separator   := REPLACE(RPAD(' ',v_length_line-1),' ','-');
  v_title1           := '| Proceso de Interface de Listas de Precios.';
  v_title1           := v_title1 ||
                        REPLACE(RPAD(' '
                                    ,v_length_line  -
                                     2              -
                                     LENGTH(v_title1)
                                    )
                               ,' '
                               ,' '
                               ) ||
                        '|';
  v_title2           := '| Reporte de Errores.';
  v_title2           := v_title2 ||
                        REPLACE(RPAD(' '
                                    ,v_length_line  -
                                     2              -
                                     LENGTH(v_title2)
                                    )
                               ,' '
                               ,' '
                               ) ||
                        '|';
  v_title3           := '| Reporte de Procesados.';
  v_title3           := v_title3 ||
                        REPLACE(RPAD(' '
                                    ,v_length_line  -
                                     2              -
                                     LENGTH(v_title3)
                                    )
                               ,' '
                               ,' '
                               ) ||
                        '|';
  v_header           := '|' ||
                        RPAD(' Lista'     ,034,' ') || '|' ||
                        RPAD(' Item Code' ,020,' ') || '|' ||
                        RPAD(' Un.Med.'   ,010,' ') || '|' ||
                        RPAD(' P.Unit.'   ,010,' ') || '|' ||
                        RPAD(' Mensajes'  ,090,' ') || '|';
  v_header_separator := '|' ||
                        RPAD('-',034,'-') || '+' ||
                        RPAD('-',020,'-') || '+' ||
                        RPAD('-',010,'-') || '+' ||
                        RPAD('-',010,'-') || '+' ||
                        RPAD('-',090,'-') || '|';
  -- ---------------------------------------------------------------------------
  -- Despliego el titulo general.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_title1
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Despliego el titulo y cabecera.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_title2
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_header
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_header_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Recorro los errores de la Importacion.
  -- ---------------------------------------------------------------------------
  FOR cd IN errors LOOP
      v_mesg_error := NULL;
      BEGIN
        v_tab_messages.DELETE;
      EXCEPTION
        WHEN others THEN
          p_mesg_error := v_calling_sequence             ||
                          '. Error borrando la tabla '   ||
                          'de memoria de los mensajes. ' ||
                          SQLERRM;
          EXIT;
      END;
      v_tab_messages(1).message1 := '';
      v_tab_messages(1).message2 := '';
      -- -----------------------------------------------------------------------
      -- Despliego la linea.
      -- -----------------------------------------------------------------------
      v_line := '|'                                         ||
                RPAD(NVL(cd.list_price_name  ,' '),034,' ') || '|' ||                                                
                RPAD(NVL(cd.item_code        ,' '),020,' ') || '|' ||
                RPAD(NVL(cd.item_uom         ,' '),010,' ') || '|' ||
                RPAD(NVL(cd.unit_price       ,' '),010,' ') || '|' ||
                RPAD(NVL(cd.error_messages   ,' '),090,' ') || '|';
      fnd_file.put(fnd_file.output
                  ,v_line
                  );
      fnd_file.new_line(fnd_file.output,1);
      
      v_message_length := 100;
      
      FOR v_cnt IN 1..4000/100 LOOP
          v_message := NULL;
          IF v_cnt = 1 THEN
             NULL;
          ELSE
             IF LENGTH(cd.error_messages) >= v_cnt * v_message_length THEN
                v_message := SUBSTR(cd.error_messages
                                   ,((v_cnt-1
                                     ) * v_message_length
                                    ) + 1
                                   ,v_message_length
                                   );
             ELSE
                IF LENGTH(cd.error_messages) >= ((v_cnt-1) * v_message_length) AND
                   LENGTH(cd.error_messages) <    v_cnt    * v_message_length  THEN
                   v_message := SUBSTR(cd.error_messages
                                      ,((v_cnt-1
                                        ) * v_message_length
                                       ) + 1
                                      );
                END IF;
             END IF;
          END IF;
          v_message := LTRIM(RTRIM(v_message));
          IF v_message IS NOT NULL THEN
             v_tab_messages(v_cnt).message1 := v_message;
          END IF;
      END LOOP;
      
      IF v_tab_messages.last IS NOT NULL THEN
         FOR v_cnt IN v_tab_messages.first..v_tab_messages.last LOOP
             IF v_cnt = 1 THEN
                NULL;
             ELSE
                v_line := '|'                      ||
                          RPAD(' ',034,' ') || '|' ||                                                
                          RPAD(' ',020,' ') || '|' ||
                          RPAD(' ',010,' ') || '|' ||
                          RPAD(' ',010,' ') || '|' ||
                          RPAD(NVL(v_tab_messages(v_cnt).message1,' '),090,' ') || '|';
                fnd_file.put(fnd_file.output
                            ,v_line
                            );
                fnd_file.new_line(fnd_file.output,1);
             END IF;
         END LOOP;
      END IF;
      v_cnt_process := NVL(v_cnt_process,0) + 1;
      v_cnt_error   := NVL(v_cnt_error,0) + 1;
  END LOOP;
  -- ---------------------------------------------------------------------------
  -- Verifico si se produjo un error.
  -- ---------------------------------------------------------------------------
  IF p_mesg_error IS NOT NULL THEN
     RETURN (FALSE);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Despliego el pie.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Despliego el titulo y cabecera.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL AND
     p_value_char1 = 'Y'  THEN
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_title3
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_header
                 );
     fnd_file.new_line(fnd_file.output,1);
     fnd_file.put(fnd_file.output
                 ,v_header_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Recorro los procesados.
  -- ---------------------------------------------------------------------------
  FOR cd IN processeds LOOP
      IF p_value_char1 = 'Y' THEN
         v_mesg_error := NULL;
         BEGIN
           v_tab_messages.DELETE;
         EXCEPTION
           WHEN others THEN
             p_mesg_error := v_calling_sequence             ||
                             '. Error borrando la tabla '   ||
                             'de memoria de los mensajes. ' ||
                             SQLERRM;
             EXIT;
         END;
         v_tab_messages(1).message1 := '';
         v_tab_messages(1).message2 := '';
         -- -----------------------------------------------------------------------
         -- Despliego la linea.
         -- -----------------------------------------------------------------------
         v_line := '|'                                         ||
                   RPAD(NVL(cd.list_price_name  ,' '),034,' ') || '|' ||
                   RPAD(NVL(cd.item_code        ,' '),020,' ') || '|' ||
                   RPAD(NVL(cd.item_uom         ,' '),010,' ') || '|' ||
                   RPAD(NVL(cd.unit_price       ,' '),010,' ') || '|' ||
                   RPAD(NVL(cd.error_messages   ,' '),090,' ') || '|';
         fnd_file.put(fnd_file.output
                     ,v_line
                     );
         fnd_file.new_line(fnd_file.output,1);
         
         v_message_length := 100;
      
         FOR v_cnt IN 1..4000/100 LOOP
             v_message := NULL;
             IF v_cnt = 1 THEN
                NULL;
             ELSE
                IF LENGTH(cd.error_messages) >= v_cnt * v_message_length THEN
                   v_message := SUBSTR(cd.error_messages
                                      ,((v_cnt-1
                                        ) * v_message_length
                                       ) + 1
                                      ,v_message_length
                                      );
                ELSE
                   IF LENGTH(cd.error_messages) >= ((v_cnt-1) * v_message_length) AND
                      LENGTH(cd.error_messages) <    v_cnt    * v_message_length  THEN
                      v_message := SUBSTR(cd.error_messages
                                         ,((v_cnt-1
                                           ) * v_message_length
                                          ) + 1
                                         );
                   END IF;
                END IF;
             END IF;
             v_message := LTRIM(RTRIM(v_message));
             IF v_message IS NOT NULL THEN
                v_tab_messages(v_cnt).message1 := v_message;
             END IF;
         END LOOP;
        
         IF v_tab_messages.last IS NOT NULL THEN
            FOR v_cnt IN v_tab_messages.first..v_tab_messages.last LOOP
                IF v_cnt = 1 THEN
                   NULL;
                ELSE
                   v_line := '|'                      ||
                             RPAD(' ',034,' ') || '|' ||
                             RPAD(' ',020,' ') || '|' ||
                             RPAD(' ',010,' ') || '|' ||
                             RPAD(' ',010,' ') || '|' ||
                             RPAD(NVL(v_tab_messages(v_cnt).message1,' '),090,' ') || '|';
                   fnd_file.put(fnd_file.output
                               ,v_line
                               );
                   fnd_file.new_line(fnd_file.output,1);
                END IF;
            END LOOP;
         END IF;
      END IF;
      v_cnt_process := NVL(v_cnt_process,0) + 1;
      v_cnt_success := NVL(v_cnt_success,0) + 1;
  END LOOP;
  -- ---------------------------------------------------------------------------
  -- Verifico si se produjo un error.
  -- ---------------------------------------------------------------------------
  IF p_mesg_error IS NOT NULL THEN
     RETURN (FALSE);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Despliego el pie.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL AND
     p_value_char1 = 'Y'  THEN
     fnd_file.put(fnd_file.output
                 ,v_line_separator
                 );
     fnd_file.new_line(fnd_file.output,1);
  END IF;
  -- ---------------------------------------------------------------------------
  -- Despliego contadores de ejecucion.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     FOR cnt IN 1..3 LOOP
         IF cnt = 1 THEN
            v_mesg_error := 'Se procesaron '              ||
                            TO_CHAR(NVL(v_cnt_process,0)) ||
                            ' registros';
         ELSIF cnt = 2 THEN
            v_mesg_error := 'Se procesaron '              ||
                            TO_CHAR(NVL(v_cnt_success,0)) ||
                            ' registros con exito';
         ELSIF cnt = 3 THEN
            v_mesg_error := 'Se procesaron '            ||
                            TO_CHAR(NVL(v_cnt_error,0)) ||
                            ' registros con error';
         END IF;
         fnd_file.put(fnd_file.output
                     ,v_mesg_error
                     );
         fnd_file.new_line(fnd_file.output,1);
         v_mesg_error := NULL;
     END LOOP;
  END IF;
  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                        ||
                    '. Error general '                        ||
                    'desplegando los datos de la Importacion. ' ||
                    SQLERRM;
    RETURN (FALSE);
END display_data;

/*=========================================================================+
|                                                                          |
| Private Function                                                         |
|    delete_processed                                                      |
|                                                                          |
| Description                                                              |
|    Funcion privada que elimina los procesados en la Importacion          |
|                                                                          |
| Parameters                                                               |
|    p_request_id      IN      NUMBER   Id de concurrente.                 |
|    p_mesg_error      OUT     VARCHAR2 Mensaje de error.                  |
|                                                                          |
+=========================================================================*/
FUNCTION delete_processed(p_request_id   IN      NUMBER
                         ,p_mesg_error   OUT     VARCHAR2
                         ) RETURN BOOLEAN
IS
  -- ---------------------------------------------------------------------------
  -- Declaracion de Variables.
  -- ---------------------------------------------------------------------------
  v_calling_sequence VARCHAR2(2000);
BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.DELETE_PROCESSED';

  debug(v_calling_sequence            ||
        '. '                          ||
        REPLACE(RPAD(' ',40),' ','-')
       ,'1'
       );

  -- ---------------------------------------------------------------------------
  -- Elimino los datos de la interface.
  -- ---------------------------------------------------------------------------
  BEGIN
    DELETE
      FROM xx_om_list_price xolp
     WHERE xolp.status     = 'PROCESSED'
       AND xolp.request_id = p_request_id;

  EXCEPTION
    WHEN others THEN
      p_mesg_error := 'Error eliminando '              ||
                      'los datos '                     ||
                      'de la tabla de '                ||
                      'Lista de Precios ' ||
                      '(XX_OM_LIST_PRICE). '           ||
                      SQLERRM;
      RETURN (FALSE);
  END;

  debug(v_calling_sequence               ||
        '. Se eliminaron: '              ||
        NVL(SQL%ROWCOUNT,0)              ||
        ' registros de '                 ||
        'de la tabla de '                ||
        'Interface de Lista de Precios ' ||
        '(XX_OM_LIST_PRICE). '
       ,'1'
       );

  RETURN (TRUE);
EXCEPTION
  WHEN others THEN
    p_mesg_error := v_calling_sequence                            ||
                    '. Error general '                            ||
                    'eliminando los procesados de la Importacion. ' ||
                    SQLERRM;
    RETURN (FALSE);
END delete_processed;

/*=========================================================================+
|                                                                          |
| Public Procedure                                                         |
|    process_interface                                                     |
|                                                                          |
| Description                                                              |
|    Procedimiento del concurrente que procesa la interface.               |
|                                                                          |
| Parameters                                                               |
|    errbuf              OUT     VARCHAR2 Uso interno del concurrent.      |
|    retcode             OUT     NUMBER   Uso interno del concurrent.      |
|    p_batch_id          IN      NUMBER   Nro. de lote.                    |
|    p_draft_mode        IN      VARCHAR2 Modo draft (Y/N).                |
|    p_display_processed IN      VARCHAR2 Despliega procesados.            |
|    p_submit_interfaces IN      VARCHAR2 Ejecuta interfaces.              |
|    p_delete_processed  IN      VARCHAR2 Elimina procesados.              |
|    p_debug_flag        IN      VARCHAR2 Flag de debug.                   |
|                                                                          |
+=========================================================================*/
PROCEDURE process_interface(errbuf              OUT     VARCHAR2
                           ,retcode             OUT     NUMBER
                           ,p_display_processed IN      VARCHAR2
                           ,p_delete_processed  IN      VARCHAR2
                           ,p_draft_mode        IN      VARCHAR2
                           ,p_debug_flag        IN      VARCHAR2
                           )
IS
  -- ---------------------------------------------------------------------------
  -- Definicion de Variables
  -- ---------------------------------------------------------------------------
  v_calling_sequence  VARCHAR2(2000);
  v_request_id        NUMBER(15);
  v_mesg_error        VARCHAR2(32000);
  l_user_id           NUMBER:= 0;
  l_resp_id           NUMBER:= 0;
  l_appl_id           NUMBER:= 0;
  l_load_option       VARCHAR2(200);
  l_status            VARCHAR2 (1);
  l_conc_phase        VARCHAR2 (50);
  l_conc_status       VARCHAR2 (50);
  l_conc_dev_phase    VARCHAR2 (50);
  l_conc_dev_status   VARCHAR2 (50);
  l_conc_message      VARCHAR2 (2000);
  l_req_return_status BOOLEAN;


BEGIN
  -- ---------------------------------------------------------------------------
  -- Inicializo variables Grales de Ejecucion.
  -- ---------------------------------------------------------------------------
  v_calling_sequence := 'XX_OM_LIST_PRICES_PKG.PROCESS_INTERFACE';
  v_request_id       := fnd_global.conc_request_id;
  g_debug_flag       := UPPER(NVL(p_debug_flag,'N'));
  g_debug_mode       := 'CONC_LOG';
  g_message_length   := 4000;

  debug(v_calling_sequence
       ,'1'
       );

    /******************************
    *    P A R A M E T R O S
    ******************************/
    FND_FILE.Put_Line(FND_FILE.OUTPUT, '-----------------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Modo: '||p_draft_mode);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Mostrar Procesados:       '||p_display_processed);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Mostrar Eliminados:       '||p_delete_processed);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, 'Debug:             '||p_debug_flag);
    FND_FILE.Put_Line(FND_FILE.OUTPUT, '-----------------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.OUTPUT, ' ');

  debug(v_calling_sequence         ||
        '. Modo draft: '           ||
        p_draft_mode
       ,'1'
       );
  debug(v_calling_sequence         ||
        '. Despliega procesados: ' ||
        p_display_processed
       ,'1'
       );
  debug(v_calling_sequence        ||
        '. Elimina procesados: '  ||
        p_delete_processed
       ,'1'
       );
  debug(v_calling_sequence        ||
        '. Flag de debug: '       ||
        p_debug_flag
       ,'1'
       );

  BEGIN
  /*  SELECT requested_by, responsibility_application_id, responsibility_id
      INTO l_user_id, l_appl_id, l_resp_id
      FROM fnd_concurrent_requests
     WHERE request_id = v_request_id;

     fnd_global.apps_initialize (l_user_id,           
                                 l_resp_id,                                             
                                 l_appl_id );  
     COMMIT;*/
  -- ---------------------------------------------------------------------------
  -- Recupero parametro de Archivo
  -- ---------------------------------------------------------------------------

    SELECT directory_path||'AdecoAgro'||to_char(sysdate,'yyyymmdd')||'.csv'
      INTO l_load_option
      FROM all_directories
     WHERE directory_name = 'XX_OM_PRICE_LIST_INTERFACE_DIR';  

  END;

  -- ---------------------------------------------------------------------------
  -- Importando Registros Tabla 
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     BEGIN

          v_request_id := FND_REQUEST.SUBMIT_REQUEST(application => 'XBOL'
                                                    ,program     => 'XXQPPLIN'
                                                    ,description => NULL
                                                    ,start_time  => sysdate
                                                    ,sub_request => FALSE
                                                    ,argument1   => l_load_option
                                                    ); 



      IF v_request_id = 0 THEN
        v_mesg_error := 'Error Ejecutando El Concurrente XX OM Loader de Listas de Precios. ' ||
                         SQLERRM;
      END IF;
   
      IF v_request_id > 0 THEN
        COMMIT;
        l_req_return_status:= FND_CONCURRENT.WAIT_FOR_REQUEST(v_request_id
                                                             ,10
                                                             ,180
                                                             ,l_conc_phase
                                                             ,l_conc_status
                                                             ,l_conc_dev_phase
                                                             ,l_conc_dev_status
                                                             ,l_conc_message);
      

      IF l_conc_dev_phase != 'COMPLETE' OR l_conc_dev_status != 'NORMAL' THEN
        v_mesg_error := 'Error En La Ejecucion De La Solicitud ' || TO_CHAR(v_request_id) || '. ' ||SQLERRM;
      END IF;
      END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error en el proceso ' ||
                         'process_interface. '  ||
                         SQLERRM;
     END;
  END IF;   
  -- ---------------------------------------------------------------------------
  -- Obtengo los datos a procesar.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     BEGIN
       IF NOT get_data(p_request_id  => v_request_id
                      ,p_mesg_error  => v_mesg_error
                      ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'GET_DATA. '                   ||
                         SQLERRM;
     END;
  END IF;

  -- ---------------------------------------------------------------------------
  -- Actualizo los datos.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
      BEGIN
       IF NOT update_data(p_request_id  => v_request_id
                         ,p_mesg_error  => v_mesg_error
                         ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'UPDATE_DATA. '                ||
                         SQLERRM;
     END;
  END IF;
  
  -- ---------------------------------------------------------------------------
  -- Actualizo los errores de la interface.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     BEGIN
       IF NOT update_errors(p_request_id => v_request_id
                           ,p_mesg_error => v_mesg_error
                           ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'UPDATE_ERRORS. '              ||
                         SQLERRM;
     END;
  END IF;

  -- ---------------------------------------------------------------------------
  -- Actualizo informacion de acuerdo a la Importacion.
  -- ---------------------------------------------------------------------------
  
  IF v_mesg_error IS NULL THEN
     BEGIN
       IF NOT update_items(p_request_id => v_request_id
                          ,p_mesg_error => v_mesg_error
                          ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'UPDATE_ITEMS. '               ||
                         SQLERRM;
     END;
  END IF;
  
  -- ---------------------------------------------------------------------------
  -- Actualizo los procesados en la interface.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     BEGIN
       IF NOT update_processed(p_request_id => v_request_id
                              ,p_mesg_error => v_mesg_error
                              ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'UPDATE_PROCESSED. '           ||
                         SQLERRM;
     END;
  END IF;

  -- ---------------------------------------------------------------------------
  -- Despliego los datos de la interface.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL THEN
     BEGIN
        IF NOT display_data(p_request_id => v_request_id
                          ,p_value_char1 => p_display_processed
                          ,p_mesg_error  => v_mesg_error
                          ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'DISPLAY_DATA. '               ||
                         SQLERRM;
     END;
  END IF;

  -- ---------------------------------------------------------------------------
  -- Elimino los procesados en la interface.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NULL AND p_delete_processed = 'Y'  THEN

     BEGIN
       IF NOT delete_processed(p_request_id => v_request_id
                              ,p_mesg_error => v_mesg_error
                              ) THEN
          NULL;
       END IF;
     EXCEPTION
       WHEN others THEN
         v_mesg_error := 'Error llamando a la funcion ' ||
                         'DELETE_PROCESSED. '           ||
                         SQLERRM;
     END;

  END IF;

  -- ---------------------------------------------------------------------------
  -- Verifico si se produjo un error.
  -- ---------------------------------------------------------------------------
  IF v_mesg_error IS NOT NULL AND v_mesg_error != 'NO_DATA_FOUND' THEN

     fnd_file.put(fnd_file.log,
                   v_calling_sequence ||
                   '. '               ||
                   v_mesg_error
                  );
     fnd_file.new_line(fnd_file.log,1);

     debug(v_calling_sequence ||
           '. '               ||
           v_mesg_error
          ,'1'
          );
     debug(v_calling_sequence      ||
           '. Realizando rollback'
          ,'1'
          );

     ROLLBACK;
     retcode := '2';
     errbuf  := SUBSTR(v_mesg_error,1,2000);
  ELSE

     IF UPPER(NVL(p_draft_mode,'N')) = 'N' THEN

        debug(v_calling_sequence    ||
              '. Realizando commit'
             ,'1'
             );

        COMMIT;

     ELSE

        debug(v_calling_sequence      ||
              '. Realizando rollback'
             ,'1'
             );

        ROLLBACK;

        BEGIN
         delete bolinf.xx_om_list_price
          where status in ('NEW','PROCESSING');
         COMMIT;
        EXCEPTION 
         WHEN OTHERS THEN
         NULL;
        END;      

     END IF;
     retcode := '0';
  END IF;

  debug(v_calling_sequence ||
        '. Fin de proceso'
       ,'1'
       );

EXCEPTION
  WHEN others THEN
    v_mesg_error := 'Error general procesando la Importacion. ' ||
                    SQLERRM;
    fnd_file.put(fnd_file.log,
                 v_calling_sequence ||
                 '. '               ||
                 v_mesg_error
                );
    fnd_file.new_line(fnd_file.log,1);
    retcode := '2';
    errbuf  := SUBSTR(v_mesg_error,1,2000);
END process_interface;
END XX_OM_LIST_PRICES_PKG;
/

exit
