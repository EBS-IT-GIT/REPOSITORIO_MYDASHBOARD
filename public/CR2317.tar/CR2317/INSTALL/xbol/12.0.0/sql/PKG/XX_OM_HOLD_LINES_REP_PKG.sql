  set define off;

  CREATE OR REPLACE EDITIONABLE PACKAGE "APPS"."XX_OM_HOLD_LINES_REP_PKG" AS

FUNCTION GET_HOLD_DATE (p_header_id IN NUMBER,p_hold_type IN VARCHAR2) RETURN VARCHAR2;
FUNCTION GET_HOLD_RELEASE (p_header_id IN NUMBER,p_hold_type IN VARCHAR2) RETURN VARCHAR2;
FUNCTION GET_HOLD_REL_USER (p_header_id IN NUMBER,p_hold_type IN VARCHAR2) RETURN VARCHAR2;

PROCEDURE PRINT_REPORT (RETCODE OUT NUMBER
                     ,ERRBUF  OUT VARCHAR2
                     ,P_ORG_ID IN NUMBER
                     ,P_CUSTOMER_ID IN NUMBER
                     ,P_START_DATE IN VARCHAR2
                     ,P_END_DATE IN VARCHAR2
                     ,P_ORDER_NUMBER IN NUMBER);
                     
END; 
/


  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "APPS"."XX_OM_HOLD_LINES_REP_PKG" AS

FUNCTION GET_HOLD_DATE (p_header_id IN NUMBER,p_hold_type IN VARCHAR2) RETURN VARCHAR2 IS

v_date DATE;

BEGIN

    select MIN(ooha.creation_date)
      into v_date
      from oe_order_holds_all ooha
          ,oe_hold_sources ohs
          ,oe_hold_definitions oha
     where ooha.header_id = p_header_id
       and ohs.hold_source_id = ooha.hold_source_id
       and ohs.hold_id = oha.hold_id
       and oha.type_code  = p_hold_type;
         
     RETURN TO_CHAR(v_date,'DD/MM/YYYY');
         
EXCEPTION
 WHEN OTHERS THEN 
    RETURN NULL;
END;

FUNCTION GET_HOLD_RELEASE (p_header_id IN NUMBER,p_hold_type IN VARCHAR2) RETURN VARCHAR2 IS

v_exists NUMBER;
v_last_release DATE;

BEGIN

     --Verifico que no tenga un hold de credito sin liberar
        BEGIN
        
            select count(1)
              into v_exists
              from oe_order_holds_all ooha
                  ,oe_hold_sources ohs
                  ,oe_hold_definitions oha
             where ooha.header_id = p_header_id
               and ohs.hold_source_id = ooha.hold_source_id
               and ohs.hold_id = oha.hold_id
               and oha.type_code = p_hold_type
               and NVL(ooha.released_flag,'N') != 'Y';
        EXCEPTION
         WHEN OTHERS THEN 
           v_exists := 0;
        END;
        
        
        IF v_exists > 0 THEN 
          RETURN NULL; --Si hay, devuelvo vacio
        ELSE
          BEGIN
              select max(ohr.creation_date)
                into v_last_release  
                from oe_order_holds_all ooha
                    ,oe_hold_sources ohs
                    ,oe_hold_definitions oha
                    ,oe_hold_releases ohr
               where ooha.header_id = p_header_id
                 and ohs.hold_source_id = ooha.hold_source_id
                 and ohs.hold_id = oha.hold_id
                 and ooha.hold_release_id = ohr.hold_release_id
                 and oha.type_code = p_hold_type;
          EXCEPTION
           WHEN OTHERS THEN 
             v_last_release := null; 
          END;
          RETURN TO_CHAR(v_last_release,'DD/MM/YYYY');
        END IF;

EXCEPTION 
 WHEN OTHERS THEN 
   RETURN NULL;
END;

FUNCTION GET_HOLD_REL_USER (p_header_id IN NUMBER,p_hold_type IN VARCHAR2) RETURN VARCHAR2 IS

v_exists NUMBER;
v_username VARCHAR2(250);

BEGIN

     --Verifico que no tenga un hold de credito sin liberar
        BEGIN
        
            select count(1)
              into v_exists
              from oe_order_holds_all ooha
                  ,oe_hold_sources ohs
                  ,oe_hold_definitions oha
             where ooha.header_id = p_header_id
               and ohs.hold_source_id = ooha.hold_source_id
               and ohs.hold_id = oha.hold_id
               and oha.type_code = p_hold_type
               and NVL(ooha.released_flag,'N') != 'Y';
        EXCEPTION
         WHEN OTHERS THEN 
           v_exists := 0;
        END;
        
        
        IF v_exists > 0 THEN 
          RETURN NULL; --Si hay, devuelvo vacio
        ELSE
          BEGIN
              select fu.user_name
                 into v_username
                 from fnd_user fu
                 ,oe_hold_releases ohr
                 ,oe_hold_sources ohs
                ,oe_hold_definitions oha
                 ,oe_order_holds_all ooha
                where ooha.hold_release_id = ohr.hold_release_id
                  and ooha.header_id = p_header_id
                  and ohs.hold_source_id = ooha.hold_source_id
                  and ohs.hold_id = oha.hold_id
                  and ohr.created_by = fu.user_id
                 and oha.type_code = p_hold_type
                  and ohr.creation_date = (select max(ohr.creation_date)
                                            from oe_order_holds_all ooha
                                                ,oe_hold_sources ohs
                                                ,oe_hold_definitions oha
                                                ,oe_hold_releases ohr
                                           where ooha.header_id = p_header_id
                                             and ohs.hold_source_id = ooha.hold_source_id
                                             and ohs.hold_id = oha.hold_id
                                             and ooha.hold_release_id = ohr.hold_release_id
                                             and oha.type_code = p_hold_type);
          EXCEPTION
           WHEN OTHERS THEN 
             v_username := null; 
          END;
          RETURN v_username;
        END IF;

EXCEPTION 
 WHEN OTHERS THEN 
   RETURN NULL;
END;

PROCEDURE PRINT_REPORT (RETCODE OUT NUMBER
                     ,ERRBUF  OUT VARCHAR2
                     ,P_ORG_ID IN NUMBER
                     ,P_CUSTOMER_ID IN NUMBER
                     ,P_START_DATE IN VARCHAR2
                     ,P_END_DATE IN VARCHAR2
                     ,P_ORDER_NUMBER IN NUMBER) IS
                     
CURSOR c_ord IS
select order_number,REPLACE(hp.party_name,'&',' ') party_name
,msi.description,REPLACE(oola.cust_po_number,'&',' ') cust_po_number
,oola.shipped_quantity
,oola.line_number||'.'||oola.shipment_number line_number
,msi.segment1
,oola.ordered_quantity
,flv_fs.meaning flow_status
,oola.order_quantity_uom
,ROUND(oola.unit_selling_price,2) unit_selling_price
,qlh.name list_price   
,ott.name order_type
,oola.cancelled_quantity
,oola.fulfilled_quantity
,oola.unit_list_price
,round(oola.unit_selling_price*oola.ordered_quantity,2) extended_price
,TO_CHAR(oola.request_date,'DD/MM/YYYY') request_date
,ship_from_org.organization_code ship_from
,ship_su.location ship_to_location
,shipping_quantity2
,bill_su.location invoice_to_location
,flv_fri.meaning freight_terms
,flv_fob.meaning fob
,term.name term
,oola_dfv.xx_om_carta_porte
,oola_dfv.xx_om_lote
,oola_dfv.xx_om_direccion
,oola_dfv.xx_om_aplicacion_contratos_aco
,oola_dfv.xx_om_importe_linea
,oola_dfv.xx_om_imp_descuentos
,oola_dfv.context_value
,oola5_dfv.fiscal_classification_code
,oola5_dfv.transaction_condition_class
,oos.name origen
,ooha.header_id
--,'XX_OM_PRECIO_LISTA' pl_hold_name
,get_hold_date(ooha.header_id,'HOLD') pl_hold_date
,get_hold_release(ooha.header_id,'HOLD') pl_hold_release
,get_hold_rel_user(ooha.header_id,'HOLD') pl_hold_user
--,get_hold_credit_name cr_hold_name
,get_hold_date(ooha.header_id,'CREDIT') cr_hold_date
,get_hold_release(ooha.header_id,'CREDIT') cr_hold_release
,get_hold_rel_user(ooha.header_id,'CREDIT') cr_hold_user
from oe_order_headers_all ooha
,oe_order_sources oos
,oe_order_lines_all oola
,hz_cust_accounts hca
,hz_parties hp
,mtl_system_items msi
,qp_list_headers qlh
,oe_transaction_types_tl ott
,mtl_parameters ship_from_org
, hz_cust_site_uses_all ship_su
, hz_cust_site_uses_all bill_su
,ra_terms term
,oe_order_lines_all_dfv oola_dfv
,oe_order_lines_all5_dfv oola5_dfv
,fnd_lookup_values flv_fob
,fnd_lookup_values flv_fri
,fnd_lookup_values flv_fs
where ooha.order_source_id = oos.order_source_id
and ooha.sold_to_org_id = hca.cust_account_id
and ooha.transaction_phase_code = 'F'
and hca.party_id = hp.party_id
and ooha.header_id = oola.header_id
and oola.inventory_item_id = msi.inventory_item_id
and msi.organization_id = oola.ship_from_org_id
and qlh.list_header_id = ooha.price_list_id
and oola.line_type_id = ott.transaction_type_id
and ott.language = 'ESA'
and oola.ship_from_org_id = ship_from_org.organization_id
and oola.ship_to_org_id = ship_su.site_use_id(+)
and oola.invoice_to_org_id = bill_su.site_use_id(+)
and oola.payment_term_id = term.term_id(+)
and oola.rowid = oola_dfv.row_id
and oola.rowid = oola5_dfv.row_id
and flv_fob.lookup_type(+) = 'FOB'
and flv_fob.lookup_code(+) = oola.fob_point_code
and flv_fob.language(+) = 'ESA'
and flv_fri.lookup_type(+) = 'FREIGHT_TERMS'
and flv_fri.lookup_code(+) = oola.freight_terms_code
and flv_fri.language(+) = 'ESA'
and flv_fs.lookup_type(+) = 'LINE_FLOW_STATUS'
and flv_fs.lookup_code(+) = oola.flow_status_code
and flv_fs.language(+) = 'ESA'
-----------------------------
and ooha.org_id = nvl(p_org_id,ooha.org_id)
and hca.cust_account_id = nvl(p_customer_id,hca.cust_account_id)
and trunc(oola.request_date) >= nvl(trunc(to_date(p_start_date,'YYYY/MM/DD HH24:MI:SS')),trunc(oola.request_date))
and trunc(oola.request_date) <= nvl(trunc(to_date(p_end_date,'YYYY/MM/DD HH24:MI:SS')),trunc(oola.request_date))
and ooha.order_number = nvl(p_order_number,ooha.order_number)
-----------------------------
order by order_number,oola.line_number||'.'||oola.shipment_number;
             
BEGIN

    fnd_file.put_line(fnd_file.log, 'XX_OM_HOLD_LINES_REP_PKG.PRINT_REPORT (+)');

    fnd_file.put_line(fnd_file.output,'<XXOMHLDR>');

    FOR r_ord IN c_ord LOOP
    
        fnd_file.put_line(fnd_file.output,'  <G_HOLD>');
    
        fnd_file.put_line(fnd_file.output,'  <ORDER_NUMBER>'||r_ord.order_number||'</ORDER_NUMBER>');
        fnd_file.put_line(fnd_file.output,'  <PARTY_NAME>'||r_ord.party_name||'</PARTY_NAME>');
        fnd_file.put_line(fnd_file.output,'  <DESCRIPTION>'||r_ord.description||'</DESCRIPTION>');
        fnd_file.put_line(fnd_file.output,'  <CUST_PO_NUMBER>'||r_ord.cust_po_number||'</CUST_PO_NUMBER>');
        fnd_file.put_line(fnd_file.output,'  <SHIPPED_QUANTITY>'||r_ord.shipped_quantity||'</SHIPPED_QUANTITY>');
        fnd_file.put_line(fnd_file.output,'  <LINE_NUMBER>'||r_ord.line_number||'</LINE_NUMBER>');
        fnd_file.put_line(fnd_file.output,'  <SEGMENT1>'||r_ord.segment1||'</SEGMENT1>');
        fnd_file.put_line(fnd_file.output,'  <ORDERED_QUANTITY>'||r_ord.ordered_quantity||'</ORDERED_QUANTITY>');
        fnd_file.put_line(fnd_file.output,'  <FLOW_STATUS>'||r_ord.flow_status||'</FLOW_STATUS>');
        fnd_file.put_line(fnd_file.output,'  <ORDER_QUANTITY_UOM>'||r_ord.order_quantity_uom||'</ORDER_QUANTITY_UOM>');
        fnd_file.put_line(fnd_file.output,'  <UNIT_SELLING_PRICE>'||r_ord.unit_selling_price||'</UNIT_SELLING_PRICE>');
        fnd_file.put_line(fnd_file.output,'  <LIST_PRICE>'||r_ord.list_price||'</LIST_PRICE>');
        fnd_file.put_line(fnd_file.output,'  <ORDER_TYPE>'||r_ord.order_type||'</ORDER_TYPE>');
        fnd_file.put_line(fnd_file.output,'  <CANCELLED_QUANTITY>'||r_ord.cancelled_quantity||'</CANCELLED_QUANTITY>');
        fnd_file.put_line(fnd_file.output,'  <FULFILLED_QUANTITY>'||r_ord.fulfilled_quantity||'</FULFILLED_QUANTITY>');
        fnd_file.put_line(fnd_file.output,'  <UNIT_LIST_PRICE>'||r_ord.unit_list_price||'</UNIT_LIST_PRICE>');
        fnd_file.put_line(fnd_file.output,'  <EXTENDED_PRICE>'||r_ord.extended_price||'</EXTENDED_PRICE>');
        fnd_file.put_line(fnd_file.output,'  <REQUEST_DATE>'||r_ord.request_date||'</REQUEST_DATE>');
        fnd_file.put_line(fnd_file.output,'  <SHIP_FROM>'||r_ord.ship_from||'</SHIP_FROM>');
        fnd_file.put_line(fnd_file.output,'  <SHIP_TO_LOCATION>'||r_ord.ship_to_location||'</SHIP_TO_LOCATION>');
        fnd_file.put_line(fnd_file.output,'  <SHIPPING_QUANTITY2>'||r_ord.shipping_quantity2||'</SHIPPING_QUANTITY2>');
        fnd_file.put_line(fnd_file.output,'  <INVOICE_TO_LOCATION>'||r_ord.invoice_to_location||'</INVOICE_TO_LOCATION>');
        fnd_file.put_line(fnd_file.output,'  <FREIGHT_TERMS>'||r_ord.freight_terms||'</FREIGHT_TERMS>');
        fnd_file.put_line(fnd_file.output,'  <FOB>'||r_ord.fob||'</FOB>');
        fnd_file.put_line(fnd_file.output,'  <TERM>'||r_ord.term||'</TERM>');
        fnd_file.put_line(fnd_file.output,'  <XX_OM_CARTA_PORTE>'||r_ord.xx_om_carta_porte||'</XX_OM_CARTA_PORTE>');
        fnd_file.put_line(fnd_file.output,'  <XX_OM_LOTE>'||r_ord.xx_om_lote||'</XX_OM_LOTE>');
        fnd_file.put_line(fnd_file.output,'  <XX_OM_DIRECCION>'||r_ord.xx_om_direccion||'</XX_OM_DIRECCION>');
        fnd_file.put_line(fnd_file.output,'  <XX_OM_APLICACION_CONTRATOS_ACO>'||r_ord.xx_om_aplicacion_contratos_aco||'</XX_OM_APLICACION_CONTRATOS_ACO>');
        fnd_file.put_line(fnd_file.output,'  <XX_OM_IMPORTE_LINEA>'||r_ord.xx_om_importe_linea||'</XX_OM_IMPORTE_LINEA>');
        fnd_file.put_line(fnd_file.output,'  <XX_OM_IMP_DESCUENTOS>'||r_ord.xx_om_imp_descuentos||'</XX_OM_IMP_DESCUENTOS>');
        fnd_file.put_line(fnd_file.output,'  <FISCAL_CLASSIFICATION_CODE>'||r_ord.fiscal_classification_code||'</FISCAL_CLASSIFICATION_CODE>');
        fnd_file.put_line(fnd_file.output,'  <TRANSACTION_CONDITION_CLASS>'||r_ord.transaction_condition_class||'</TRANSACTION_CONDITION_CLASS>');
        fnd_file.put_line(fnd_file.output,'  <ORIGEN>'||r_ord.origen||'</ORIGEN>');
        /*IF r_ord.pl_hold_date IS NULL THEN
          fnd_file.put_line(fnd_file.output,'  <PL_HOLD_NAME>'||NULL||'</PL_HOLD_NAME>');
        ELSE 
          fnd_file.put_line(fnd_file.output,'  <PL_HOLD_NAME>'||r_ord.pl_hold_name||'</PL_HOLD_NAME>');
        END IF;*/
        fnd_file.put_line(fnd_file.output,'  <PL_HOLD_DATE>'||r_ord.pl_hold_date||'</PL_HOLD_DATE>');
        fnd_file.put_line(fnd_file.output,'  <PL_HOLD_RELEASE>'||r_ord.pl_hold_release||'</PL_HOLD_RELEASE>');
        fnd_file.put_line(fnd_file.output,'  <PL_HOLD_USER>'||r_ord.pl_hold_user||'</PL_HOLD_USER>');
        /*IF r_ord.cr_hold_date IS NULL THEN 
          fnd_file.put_line(fnd_file.output,'  <CR_HOLD_NAME>'||NULL||'</CR_HOLD_NAME>');
        ELSE 
          fnd_file.put_line(fnd_file.output,'  <CR_HOLD_NAME>'||r_ord.cr_hold_name||'</CR_HOLD_NAME>');
        END IF;*/
        fnd_file.put_line(fnd_file.output,'  <CR_HOLD_DATE>'||r_ord.cr_hold_date||'</CR_HOLD_DATE>');
        fnd_file.put_line(fnd_file.output,'  <CR_HOLD_RELEASE>'||r_ord.cr_hold_release||'</CR_HOLD_RELEASE>');
        fnd_file.put_line(fnd_file.output,'  <CR_HOLD_USER>'||r_ord.cr_hold_user||'</CR_HOLD_USER>');

        fnd_file.put_line(fnd_file.output,'  </G_HOLD>');
    
    END LOOP;
    
    fnd_file.put_line(fnd_file.output,'</XXOMHLDR>');
    
    fnd_file.put_line(fnd_file.log, 'XX_OM_HOLD_LINES_REP_PKG.PRINT_REPORT (-)');

EXCEPTION
 WHEN OTHERS THEN 
   fnd_file.put_line(fnd_file.output,'</XXOMHLDR>');
   retcode := 2;
   errbuf := 'Error OTHERS en proceso principal. Error: '||sqlerrm;
   fnd_file.put_line(fnd_file.log,errbuf);
   fnd_file.put_line(fnd_file.log, 'XX_OM_HOLD_LINES_REP_PKG.PRINT_REPORT (!)');
   RAISE_APPLICATION_ERROR(-20001,errbuf);
END;

END; 
/

exit
