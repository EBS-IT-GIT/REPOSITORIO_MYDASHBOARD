Prompt Catalogar Triggers no CSF_OWN


prompt T_A_I_U_NOTA_FISCAL_03.trg
@@T_A_I_U_NOTA_FISCAL_03.trg
show err
/

Prompt Catalogar Objetos Invalidos.trg
@@rec_obj_invalid.sql.






