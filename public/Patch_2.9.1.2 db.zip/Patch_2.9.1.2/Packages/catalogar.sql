prompt -----------------------------------------------------------------------------------

prompt Catalogar Packages

prompt -----------------------------------------------------------------------------------

prompt 30a_CSF_OWN_pk_csf.pks 
@@30a_CSF_OWN_pk_csf.pks
show err
prompt 30b_CSF_OWN_pk_csf.pkb
@@30b_CSF_OWN_pk_csf.pkb
show err

prompt 31a_CSF_OWN_pk_csf_api
@@31a_CSF_OWN_pk_csf_api.pks
show err
prompt 31b_CSF_OWN_pk_csf_api
@@31b_CSF_OWN_pk_csf_api.pkb
show err

prompt 34a_csf_own_pk_integr_view.pks
@@34a_csf_own_pk_integr_view.pks
show err
prompt 34b_csf_own_pk_integr_view.pkb
@@34b_csf_own_pk_integr_view.pkb
show err

prompt 35_pb_gera_danfe_nfe.prc
@@35_pb_gera_danfe_nfe.prc
show err

prompt 40a_CT_CSF_OWN_pk_csf_api_ct
@@40a_CT_CSF_OWN_pk_csf_api_ct.pks
show err
prompt 40b_CT_CSF_OWN_pk_csf_api_ct
@@40b_CT_CSF_OWN_pk_csf_api_ct.pkb
show err

prompt 52a_pk_csf_api_ecd
@@52a_pk_csf_api_ecd.pks
show err
prompt 52b_pk_csf_api_ecd
@@52b_pk_csf_api_ecd.pkb
show err

prompt 65a_pk_csf_api_d100
@@65a_pk_csf_api_d100.pks
show err
prompt 65b_pk_csf_api_d100
@@65b_pk_csf_api_d100.pkb
show err

prompt 66a_pk_int_view_d100
@@66a_pk_int_view_d100.pks
show err
prompt 66b_pk_int_view_d100
@@66b_pk_int_view_d100.pkb
show err

prompt 67a_pk_int_view_sc.pks
@@67a_pk_int_view_sc.pks
show err
prompt 67b_pk_int_view_sc.pkb 
@@67b_pk_int_view_sc.pkb
show err

prompt 72a_pk_csf_api_efd
@@72a_pk_csf_api_efd.pks
show err
prompt 72b_pk_csf_api_efd
@@72b_pk_csf_api_efd.pkb
show err

prompt 73a_pk_gera_arq_efd
@@73a_pk_gera_arq_efd.pks
show err
prompt 73b_pk_gera_arq_efd
@@73b_pk_gera_arq_efd.pkb
show err

prompt 110_pb_rel_resumo_cfop.prc
@@110_pb_rel_resumo_cfop.prc
show err

prompt 111_pb_rel_resumo_cfop_cst.prc
@@111_pb_rel_resumo_cfop_cst.prc
show err

prompt 112_pb_rel_resumo_aliq_imp.prc
@@112_pb_rel_resumo_aliq_imp.prc
show err

prompt 113_pb_rel_resumo_cfop_aliq.prc
@@113_pb_rel_resumo_cfop_aliq.prc
show err

prompt 114_pb_rel_resumo_uf_imp.prc
@@114_pb_rel_resumo_uf_imp.prc
show err

prompt 115_pb_rel_nf
@@115_pb_rel_nf.prc
show err

prompt 116_pb_rel_nf_cfop
@@116_pb_rel_nf_cfop.prc
show err

prompt 118_pb_rel_nf_imp_ret
@@118_pb_rel_nf_imp_ret.prc
show err

prompt 121a_pk_gera_arq_efd_pc
@@121a_pk_gera_arq_efd_pc.pks
show err
prompt 121b_pk_gera_arq_efd_pc
@@121b_pk_gera_arq_efd_pc.pkb
show err

prompt 141a_pk_apur_pis
@@141a_pk_apur_pis.pks
show err
prompt 141b_pk_apur_pis.pkb
@@141b_pk_apur_pis.pkb
show err

prompt 142a_pk_apur_cofins.pks
@@142a_pk_apur_cofins.pks
show err
prompt 142b_pk_apur_cofins.pkb
@@142b_pk_apur_cofins.pkb
show err

prompt 149a_pk_gera_ddof100_nfnd
@@149a_pk_gera_ddof100_nfnd.pks
show err
prompt 149b_pk_gera_ddof100_nfnd
@@149b_pk_gera_ddof100_nfnd.pkb
show err

prompt 171a_pk_vld_amb_sc.pks
@@171a_pk_vld_amb_sc.pks
show err
prompt 171b_pk_vld_amb_sc.pkb
@@171b_pk_vld_amb_sc.pkb
show err

prompt 192a_pk_limpa_open_interf
@@192a_pk_limpa_open_interf.pks
show err
prompt 192b_pk_limpa_open_interf
@@192b_pk_limpa_open_interf.pkb
show err

prompt 212a_pk_arq_nfs_cidade
@@212a_pk_arq_nfs_cidade.pks
show err
prompt 212b_pk_arq_nfs_cidade
@@212b_pk_arq_nfs_cidade.pkb
show err

prompt 221a_csf_own_pk_csf_api_nfs
@@221a_csf_own_pk_csf_api_nfs.pks
show err
prompt 221b_csf_own_pk_csf_api_nfs
@@221b_csf_own_pk_csf_api_nfs.pkb
show err

prompt 225a_pk_emiss_nfse
@@225a_pk_emiss_nfse.pks
show err
prompt 225b_pk_emiss_nfse
@@225b_pk_emiss_nfse.pkb
show err

prompt 227a_pk_monta_xml_nfs_terc.pks
@@227a_pk_monta_xml_nfs_terc.pks
show err
prompt 227b_pk_monta_xml_nfs_terc.pkb
@@227b_pk_monta_xml_nfs_terc.pkb
show err

prompt 251a_pk_gera_arq_gia
@@251a_pk_gera_arq_gia.pks
show err
prompt 251b_pk_gera_arq_gia
@@251b_pk_gera_arq_gia.pkb
show err

prompt 280a_pk_csf_prod_dia_usina.pks
@@280a_pk_csf_prod_dia_usina.pks
show err
prompt 280b_pk_csf_prod_dia_usina.pkb
@@280b_pk_csf_prod_dia_usina.pkb
show err

prompt 281a_pk_csf_api_prod_dia_usina.pks
@@281a_pk_csf_api_prod_dia_usina.pks
show err
prompt 281b_pk_csf_api_prod_dia_usina.pkb
@@281b_pk_csf_api_prod_dia_usina.pkb
show err

prompt 282a_pk_vld_amb_prod_dia_usina.pks 
@@282a_pk_vld_amb_prod_dia_usina.pks
show err
prompt 282b_pk_vld_amb_prod_dia_usina.pkb
@@282b_pk_vld_amb_prod_dia_usina.pkb
show err

prompt 343a_pk_int_view_dirf
@@343a_pk_int_view_dirf.pks
show err
prompt 343b_pk_int_view_dirf
@@343b_pk_int_view_dirf.pkb
show err

prompt 351_pb_rel_resumo_cfop_uf.prc
@@351_pb_rel_resumo_cfop_uf.prc
show err

prompt 356_pb_rel_resumo_tipo_oper.prc
@@356_pb_rel_resumo_tipo_oper.prc
show err

prompt 461a_pk_csf_api_secf
@@461a_pk_csf_api_secf.pks
show err
prompt 461b_pk_csf_api_secf
@@461b_pk_csf_api_secf.pkb
show err

prompt 524a_pk_csf_gera_dados_fci.pks
@@524a_pk_csf_gera_dados_fci.pks
show err
prompt 524b_pk_csf_gera_dados_fci.pkb
@@524b_pk_csf_gera_dados_fci.pkb
show err

prompt 606a_pk_gera_dados_reinf
@@606a_pk_gera_dados_reinf.pks
show err
prompt 606b_pk_gera_dados_reinf
@@606b_pk_gera_dados_reinf.pkb
show err

prompt 608a_pk_apur_cprb_reinf
@@608a_pk_apur_cprb_reinf.pks
show err
prompt 608b_pk_apur_cprb_reinf
@@608b_pk_apur_cprb_reinf.pkb
show err

prompt 610a_pk_rel_apur_irpj_csll_parc
@@610a_pk_rel_apur_irpj_csll_parc.pks
show err
prompt 610b_pk_rel_apur_irpj_csll_parc
@@610b_pk_rel_apur_irpj_csll_parc.pkb
show err

prompt 651a_CSF_OWN_pk_csf_api_nfce.pks 
@@651a_CSF_OWN_pk_csf_api_nfce.pks
show err
prompt 651b_CSF_OWN_pk_csf_api_nfce.pkb
@@651b_CSF_OWN_pk_csf_api_nfce.pkb
show err

prompt 652_pb_gera_nf_base_cupom
@@652_pb_gera_nf_base_cupom.prc
show err

prompt pb_inc
@@pb_inc.prc
show err

Prompt Catalogar Objetos Invalidos
@@rec_obj_invalid.sql