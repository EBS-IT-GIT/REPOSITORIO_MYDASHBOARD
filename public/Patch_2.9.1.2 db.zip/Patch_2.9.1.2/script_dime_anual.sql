--------------------------------------------------------------------------------------
Prompt Inicio Redmine #55401 - DIME - Registros 80 a 84
--------------------------------------------------------------------------------------

Prompt *** INSERT REGISTRO_GIA ***

declare

  cursor c_dados is
    select cd, descr
      from (select '80' cd, 'Resumo do Livro Registro de Invent�rio e Receita Bruta'                              descr from dual union all
            select '81' cd, 'Ativo'                                                                               descr from dual union all
            select '82' cd, 'Passivo'                                                                             descr from dual union all
            select '83' cd, 'Demonstra��o de Resultados'                                                          descr from dual union all
            select '84' cd, 'Detalhamento das Despesas'                                                           descr from dual union all
            select '90' cd, 'Resumo do Livro Registro de Invent�rio e Receita Bruta (Encerramento de Atividades)' descr from dual union all
            select '91' cd, 'Ativo (Encerramento de Atividades)'                                                  descr from dual union all
            select '92' cd, 'Passivo (Encerramento de Atividades)'                                                descr from dual union all
            select '93' cd, 'Demonstra��o de Resultados (Encerramento de Atividades)'                             descr from dual union all
            select '94' cd, 'Detalhamento das Despesas (Encerramento de Atividades)'                              descr from dual);

begin
  --
  for rec_dados in c_dados loop
    exit when c_dados%notfound or(c_dados%notfound) is null;
    --
    begin
      --
      insert into csf_own.registro_gia
        (id, 
         tipocodarq_id, 
         cd, 
         descr)
      values
        (csf_own.registrogia_seq.nextval,
         (select t.id from csf_own.tipo_cod_arq t where t.descr = 'GIA-SC'),
         rec_dados.cd,
         rec_dados.descr);
    exception
      when others then
        update csf_own.registro_gia r
           set r.descr         = rec_dados.descr
         where r.tipocodarq_id = (select t.id from csf_own.tipo_cod_arq t where t.descr = 'GIA-SC')
           and r.cd            = rec_dados.cd;
    end;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT DOMINIO INF_COMP_DIME.DM_TP_INF e INF_COMP_DIME.DM_SITUACAO ***

declare

  cursor c_dados is
    select dominio, vl, descr
      from (select 'INF_COMP_DIME.DM_TP_INF'   dominio, 1 vl, 'Informa��es Complementares'                 descr from dual union all
			select 'INF_COMP_DIME.DM_TP_INF'   dominio, 2 vl, 'Informa��es Complementares de Encerramento' descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 0 vl, 'Criado'                                     descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 1 vl, 'Erro de cria��o de registro'                descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 2 vl, 'Calculado'                                  descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 3 vl, 'Erro de C�lculo'                            descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 4 vl, 'Validado'                                   descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 5 vl, 'Erro de Valida��o'                          descr from dual union all
			select 'INF_COMP_DIME.DM_SITUACAO' dominio, 6 vl, 'Novo'                                       descr from dual);

begin
  --
  for rec_dados in c_dados loop
    exit when c_dados%notfound or(c_dados%notfound) is null;
    --
    begin
      --
      insert into csf_own.dominio
        (dominio, 
         vl, 
         descr, 
         id)
      values
        (rec_dados.dominio,
         rec_dados.vl,
         rec_dados.descr,
         csf_own.dominio_seq.nextval);
    exception
      when others then
        update csf_own.dominio d
           set d.descr   = rec_dados.descr
         where d.dominio = rec_dados.dominio
           and d.vl      = rec_dados.vl;
    end;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT REGISTRO_DIME ***

declare

 cursor c_reg_dime is
  select cod, 
         descr 
    from (select '80' cod, 'Resumo do Livro Registro de Invent�rio e Receita Bruta'                              descr from dual union all
          select '81' cod, 'Ativo'                                                                               descr from dual union all
          select '82' cod, 'Passivo'                                                                             descr from dual union all
          select '83' cod, 'Demonstra��o de Resultados'                                                          descr from dual union all
          select '84' cod, 'Detalhamento das Despesas'                                                           descr from dual union all
          select '90' cod, 'Resumo do Livro Registro de Invent�rio e Receita Bruta (Encerramento de Atividades)' descr from dual union all
          select '91' cod, 'Ativo (Encerramento de Atividades)'                                                  descr from dual union all
          select '92' cod, 'Passivo (Encerramento de Atividades)'                                                descr from dual union all
          select '93' cod, 'Demonstra��o de Resultados (Encerramento de Atividades)'                             descr from dual union all
          select '94' cod, 'Detalhamento das Despesas (Encerramento de Atividades)'                              descr from dual);
begin
  --
  for rec_reg_dime in c_reg_dime loop
    exit when c_reg_dime%notfound or(c_reg_dime%notfound) is null;
    --
    begin
      --
      insert into csf_own.registro_dime
        (id, 
         codigo, 
         descricao)
      values
        (csf_own.registrodime_seq.nextval,
         rec_reg_dime.cod,
         rec_reg_dime.descr);
    exception
      when others then
        update csf_own.registro_dime r
           set r.descricao = rec_reg_dime.descr
         where r.codigo    = rec_reg_dime.cod;
    end;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT QUADRO_DIME ***

declare

 cursor c_quadro_dime is
  select quadro, 
         descr 
    from (select '80' quadro, 'Resumo do Livro Registro de Invent�rio e Receita Bruta' descr from dual union all
          select '81' quadro, 'Ativo'                                                  descr from dual union all
          select '82' quadro, 'Passivo'                                                descr from dual union all
          select '83' quadro, 'Demonstra��o de Resultado'                              descr from dual union all
          select '84' quadro, 'Detalhamento das Despesas'                              descr from dual union all
          select '90' quadro, 'Resumo do Livro Registro de Invent�rio e Receita Bruta' descr from dual union all
          select '91' quadro, 'Ativo'                                                  descr from dual union all
          select '92' quadro, 'Passivo'                                                descr from dual union all
          select '93' quadro, 'Demonstra��o de Resultado'                              descr from dual union all
          select '94' quadro, 'Detalhamento das Despesas'                              descr from dual);
begin
  --
  for rec_quadro_dime in c_quadro_dime loop
    exit when c_quadro_dime%notfound or(c_quadro_dime%notfound) is null;
    --
    begin
      --
      insert 
	    into csf_own.quadro_dime
        (id, 
         registrodime_id, 
         codigo, 
         descricao)
      values
        (csf_own.quadrodime_seq.nextval,
         (select r.id from csf_own.registro_dime r where r.codigo = rec_quadro_dime.quadro),
         rec_quadro_dime.quadro,
         rec_quadro_dime.descr);
    exception
      when others then
        update csf_own.quadro_dime q
           set q.descricao = rec_quadro_dime.descr
         where q.codigo    = rec_quadro_dime.quadro;
    end;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT ITEM_DIME - 80 e 90 ***

declare

  cursor c_quadro_dime is
    select q.id, 
           q.codigo, 
           q.descricao
      from quadro_dime q
     where q.codigo in ('80', '90');

  cursor c_item_dime is
    select item, descr
      from (select '010' item, 'Estoque no in�cio do exerc�cio'     descr from dual union all
            select '020' item, 'Estoque no fim do exerc�cio'        descr from dual union all
            select '030' item, 'Receita bruta de vendas e servi�os' descr from dual);

begin
  --
  for rec_quadro in c_quadro_dime loop
    exit when c_quadro_dime%notfound or(c_quadro_dime%notfound) is null;
    --
    for rec_item in c_item_dime loop
      exit when c_item_dime%notfound or(c_item_dime%notfound) is null;
      --
      begin
        insert into csf_own.item_dime
          (id, 
           quadrodime_id, 
           codigo, 
           descricao)
        values
          (csf_own.itemdime_seq.nextval,
           rec_quadro.id,
           rec_item.item,
           rec_item.descr);
      exception
        when others then
          update csf_own.item_dime i
             set i.descricao     = rec_item.descr
           where i.quadrodime_id = rec_quadro.id
             and i.codigo        = rec_item.item;
      end;
      --
    end loop;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT ITEM_DIME - 81 e 91 ***

declare

  cursor c_quadro_dime is
    select q.id, 
           q.codigo, 
           q.descricao
      from quadro_dime q
     where q.codigo in ('81', '91');

  cursor c_item_dime is
    select item, descr
      from (select '110' item, 'Circulante'                             descr from dual union all
            select '111' item, 'Disponibilidades'                       descr from dual union all
            select '113' item, 'Contas a receber do circulante'         descr from dual union all
            select '121' item, 'Estoque de mercadorias e mat�ria-prima' descr from dual union all
            select '123' item, 'Outros estoques'                        descr from dual union all
            select '128' item, 'Outras contas do ativo circulante'      descr from dual union all
            select '130' item, 'Realiz�vel a longo prazo'               descr from dual union all
            select '131' item, 'Contas a receber do realiz�vel'         descr from dual union all
            select '148' item, 'Outras contas do realiz�vel'            descr from dual union all
            select '150' item, 'Permanente'                             descr from dual union all
            select '151' item, 'Investimentos'                          descr from dual union all
            select '155' item, 'Imobilizado (l�quido)'                  descr from dual union all
            select '157' item, 'Diferido (l�quido)'                     descr from dual union all
            select '159' item, 'Intang�vel'                             descr from dual union all
            select '199' item, 'Total geral do ativo'                   descr from dual);

begin
  --
  for rec_quadro in c_quadro_dime loop
    exit when c_quadro_dime%notfound or(c_quadro_dime%notfound) is null;
    --
    for rec_item in c_item_dime loop
      exit when c_item_dime%notfound or(c_item_dime%notfound) is null;
      --
      begin
        insert into csf_own.item_dime
          (id, 
           quadrodime_id, 
           codigo, 
           descricao)
        values
          (csf_own.itemdime_seq.nextval,
           rec_quadro.id,
           rec_item.item,
           rec_item.descr);
      exception
        when others then
          update csf_own.item_dime i
             set i.descricao     = rec_item.descr
           where i.quadrodime_id = rec_quadro.id
             and i.codigo        = rec_item.item;
      end;
      --
    end loop;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT ITEM_DIME - 82 e 92 ***

declare

  cursor c_quadro_dime is
    select q.id, 
           q.codigo, 
           q.descricao
      from quadro_dime q
     where q.codigo in ('82', '92');

  cursor c_item_dime is
    select item, descr
      from (select '210' item, 'Circulante'                                              descr from dual union all
            select '211' item, 'Fornecedores'                                            descr from dual union all
            select '213' item, 'Empr�stimos e financiamentos'                            descr from dual union all
            select '215' item, 'Outras contas do passivo circulante'                     descr from dual union all
            select '230' item, 'Exig�vel a longo prazo'                                  descr from dual union all
            select '240' item, 'Resultados de exerc�cios futuros'                        descr from dual union all
            select '269' item, 'Passivo a Descoberto'                                    descr from dual union all
            select '270' item, 'Patrim�nio l�quido'                                      descr from dual union all
            select '271' item, 'Capital social'                                          descr from dual union all
            select '278' item, 'Outras contas do patrim�nio l�quido'                     descr from dual union all
            select '279' item, 'Outras contas do patrim�nio l�quido (de valor negativo)' descr from dual union all
            select '299' item, 'Total geral do passivo'                                  descr from dual);

begin
  --
  for rec_quadro in c_quadro_dime loop
    exit when c_quadro_dime%notfound or(c_quadro_dime%notfound) is null;
    --
    for rec_item in c_item_dime loop
      exit when c_item_dime%notfound or(c_item_dime%notfound) is null;
      --
      begin
        insert into csf_own.item_dime
          (id, 
           quadrodime_id, 
           codigo, 
           descricao)
        values
          (csf_own.itemdime_seq.nextval,
           rec_quadro.id,
           rec_item.item,
           rec_item.descr);
      exception
        when others then
          update csf_own.item_dime i
             set i.descricao     = rec_item.descr
           where i.quadrodime_id = rec_quadro.id
             and i.codigo        = rec_item.item;
      end;
      --
    end loop;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT ITEM_DIME - 83 e 93 ***

declare

  cursor c_quadro_dime is
    select q.id, 
           q.codigo, 
           q.descricao
      from quadro_dime q
     where q.codigo in ('83', '93');

  cursor c_item_dime is
    select item, descr
      from (select '310' item, 'Receita bruta vendas/servi�os'                                         descr from dual union all
            select '311' item, 'Dedu��es da receita bruta'                                             descr from dual union all
            select '320' item, 'Receita l�quida vendas/servi�os'                                       descr from dual union all
            select '323' item, 'Custo da mercadoria ou produtos vendida(os) ou dos servi�os prestados' descr from dual union all
            select '330' item, 'Lucro bruto'                                                           descr from dual union all
            select '331' item, 'Preju�zo bruto'                                                        descr from dual union all
            select '333' item, 'Outras receitas operacionais'                                          descr from dual union all
            select '335' item, 'Despesas operacionais'                                                 descr from dual union all
            select '340' item, 'Lucro/operacional'                                                     descr from dual union all
            select '341' item, 'Preju�zo operacional'                                                  descr from dual union all
            select '343' item, 'Receitas n�o operacionais'                                             descr from dual union all
            select '345' item, 'Despesas n�o operacionais'                                             descr from dual union all
            select '350' item, 'Resultado antes do I.R. e da contribui��o social'                      descr from dual union all
            select '351' item, 'Resultado negativo antes do I.R. e da contribui��o social'             descr from dual union all
            select '353' item, 'Provis�o para o IR e para a contribui��o social'                       descr from dual union all
            select '354' item, 'Provis�o para o IR e para contribui��o social '                        descr from dual union all 
            select '360' item, 'Resultado ap�s o I.R. e a contribui��o social'                         descr from dual union all
            select '361' item, 'Resultado negativo ap�s o I.R. e a contribui��o social'                descr from dual union all
            select '363' item, 'Participa��es e contribui��es'                                         descr from dual union all
            select '398' item, 'Preju�zo do exerc�cio'                                                 descr from dual union all
            select '399' item, 'Lucro do exerc�cio'                                                    descr from dual);

begin
  --
  for rec_quadro in c_quadro_dime loop
    exit when c_quadro_dime%notfound or(c_quadro_dime%notfound) is null;
    --
    for rec_item in c_item_dime loop
      exit when c_item_dime%notfound or(c_item_dime%notfound) is null;
      --
      begin
        insert into csf_own.item_dime
          (id, 
           quadrodime_id, 
           codigo, 
           descricao)
        values
          (csf_own.itemdime_seq.nextval,
           rec_quadro.id,
           rec_item.item,
           rec_item.descr);
      exception
        when others then
          update csf_own.item_dime i
             set i.descricao     = rec_item.descr
           where i.quadrodime_id = rec_quadro.id
             and i.codigo        = rec_item.item;
      end;
      --
    end loop;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** INSERT ITEM_DIME - 84 e 94 ***

declare

  cursor c_quadro_dime is
    select q.id, 
           q.codigo, 
           q.descricao
      from quadro_dime q
     where q.codigo in ('84', '94');

  cursor c_item_dime is
    select item, descr
      from (select '411' item, 'Pr�-labore'                     descr from dual union all
            select '412' item, 'Comiss�es, sal�rios, ordenados' descr from dual union all
            select '431' item, 'Combust�veis e lubrificantes'   descr from dual union all
            select '421' item, 'Encargos sociais'               descr from dual union all
            select '422' item, 'Tributos federais'              descr from dual union all
            select '423' item, 'Tributos estaduais'             descr from dual union all
            select '424' item, 'Tributos municipais'            descr from dual union all
            select '432' item, '�gua e telefone'                descr from dual union all
            select '433' item, 'Energia el�trica'               descr from dual union all
            select '441' item, 'Alugu�is'                       descr from dual union all
            select '451' item, 'Servi�os profissionais'         descr from dual union all
            select '442' item, 'Seguros'                        descr from dual union all
            select '443' item, 'Fretes e carretos'              descr from dual union all
            select '461' item, 'Despesas financeiras'           descr from dual union all
            select '498' item, 'Outras despesas'                descr from dual union all
            select '499' item, 'Total'                          descr from dual);

begin
  --
  for rec_quadro in c_quadro_dime loop
    exit when c_quadro_dime%notfound or(c_quadro_dime%notfound) is null;
    --
    for rec_item in c_item_dime loop
      exit when c_item_dime%notfound or(c_item_dime%notfound) is null;
      --
      begin
        insert into csf_own.item_dime
          (id, 
           quadrodime_id, 
           codigo, 
           descricao)
        values
          (csf_own.itemdime_seq.nextval,
           rec_quadro.id,
           rec_item.item,
           rec_item.descr);
      exception
        when others then
          update csf_own.item_dime i
             set i.descricao     = rec_item.descr
           where i.quadrodime_id = rec_quadro.id
             and i.codigo        = rec_item.item;
      end;
      --
    end loop;
    --
  end loop;
  --
  commit;
  --
end;
/

Prompt *** CREATE TABLE INF_COMP_DIME ***

-- Create table
create table csf_own.inf_comp_dime(id              number not null,
                                   empresa_id      number not null, 
                                   dt_ini          date not null,
                                   dt_fin          date not null,
                                   dm_tp_inf       number(2) not null,   
                                   dm_situacao     number(2) not null,
 constraint infcompdime_pk primary key(id) using index tablespace csf_index)
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.inf_comp_dime is 'Tabela de Informa��es Complementares Anuais - DIME'   
/

-- Add comments to the columns
comment on column csf_own.inf_comp_dime.empresa_id is 'ID da empresa (EMPRESA)'
/

comment on column csf_own.inf_comp_dime.dt_ini is 'Data inicial'
/

comment on column csf_own.inf_comp_dime.dt_fin is 'Data final '
/

comment on column csf_own.inf_comp_dime.dm_tp_inf is 'Tipo da informa��o complementar (DOMINIO): 1 - Informa��es Complementares / 2 - Informa��es Complementares de Encerramento'
/

comment on column csf_own.inf_comp_dime.dm_situacao is 'Situa��o dos registros (DOMINIO): 0 - Criado / 1 - Erro de cria��o de registro / 2 - Calculado / 3 - Erro de C�lculo / 4 - Validado / 5 - Erro de Valida��o'
/

-- Create constraint foreign
alter table csf_own.inf_comp_dime
add constraint infcompdime_fk01 foreign key (empresa_id)
references csf_own.empresa(id)
/

-- Create sequence
create sequence csf_own.infcompdime_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

-- grants table and sequence 
grant select, insert, update, delete on csf_own.inf_comp_dime to csf_work
/   

grant select on csf_own.infcompdime_seq to csf_work
/

commit
/

Prompt *** CREATE TABLE DET_INF_COMP_DIME ***

-- Create table
create table csf_own.det_inf_comp_dime(id              number not null,
                                       infcompdime_id  number not null,
                                       registrodime_id number not null,
                                       quadrodime_id   number not null,
                                       itemdime_id     number not null,   
                                       vl             number(15,2) not null,
 constraint detinfcompdime_pk primary key(id) using index tablespace csf_index)
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.det_inf_comp_dime is 'Tabela de Detalhes das Informa��es Complementares Anuais - DIME'   
/

-- Add comments to the columns
comment on column csf_own.det_inf_comp_dime.infcompdime_id is 'ID da abertura Informa��es Complementares Anuais (INF_COMP_DIME)'
/

comment on column csf_own.det_inf_comp_dime.registrodime_id is 'ID do registro (REGISTRO_DIME)'
/

comment on column csf_own.det_inf_comp_dime.quadrodime_id is 'ID do quadro (QUADRO_DIME)'
/

comment on column csf_own.det_inf_comp_dime.itemdime_id is 'ID do item (ITEM_DIME)'
/

comment on column csf_own.det_inf_comp_dime.vl is 'Valor informado pelo usu�rio'
/

-- Create constraint foreign
alter table csf_own.det_inf_comp_dime
add constraint detinfcompdime_fk01 foreign key (infcompdime_id)
references csf_own.inf_comp_dime(id)
/

alter table csf_own.det_inf_comp_dime
add constraint detinfcompdime_fk02 foreign key (registrodime_id)
references csf_own.registro_dime(id)
/

alter table csf_own.det_inf_comp_dime
add constraint detinfcompdime_fk03 foreign key (quadrodime_id)
references csf_own.quadro_dime(id)
/

alter table csf_own.det_inf_comp_dime
add constraint detinfcompdime_fk04 foreign key (itemdime_id)
references csf_own.item_dime(id)
/

-- Create constraint unique
alter table csf_own.det_inf_comp_dime
add constraint detinfcompdime_uk01 unique (infcompdime_id, registrodime_id, quadrodime_id, itemdime_id)
/

-- Create sequence
create sequence csf_own.detinfcompdime_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

-- grants table and sequence 
grant select, insert, update, delete on csf_own.det_inf_comp_dime to csf_work
/   

grant select on csf_own.detinfcompdime_seq to csf_work
/

commit
/

--------------------------------------------------------------------------------------
Prompt Fim Redmine #55401 - DIME - Registros 80 a 84
--------------------------------------------------------------------------------------