------------------------------------------------------------------------------------------
Prompt INI Patch 2.9.1.2 - Alteracoes no CSF_OWN
------------------------------------------------------------------------------------------

insert into csf_own.versao_sistema ( ID
                                   , VERSAO
                                   , DT_VERSAO
                                   )
                            values ( csf_own.versaosistema_seq.nextval -- ID
                                   , '2.9.1.2'                         -- VERSAO
                                   , sysdate                           -- DT_VERSAO
                                   )
/

commit
/


-------------------------------------------------------------------------------------------------------------------------------
Prompt INI Corre��o ANALISE_CONVERSAO_ANP
-------------------------------------------------------------------------------------------------------------------------------

prompt script_ANALISE_CONVERSAO_ANP
@@script_own_ANALISE_CONVERSAO_ANP.sql
show err

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60408 - Incluir mais de um crit�rio de pesquisa para ECF - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

declare
  vn_exist   number := 0;
begin
  ---
  begin
    select count(1) into vn_exist from all_constraints 
    where  owner = 'CSF_OWN' and constraint_name ='CRITPESQLC_UK' ;
  exception
    when others then
      vn_exist := 0;
  end ; 
  ---
  if vn_exist =1 then
    execute immediate 'alter table csf_own.CRIT_PESQ_LC drop constraint CRITPESQLC_UK';
  end if;
end;
/

declare
  vn_exist   number := 0;
begin
  ---
  begin
    select count(1) into vn_exist from all_indexes 
    where  owner = 'CSF_OWN' and index_name  ='CRITPESQLC_UK' ;
  exception
    when others then
      vn_exist := 0;
  end ; 
  ---
  if vn_exist =1 then
    execute immediate 'drop index csf_own.CRITPESQLC_UK';
  end if;
end;
/

declare
  vn_exist   number := 0;
begin
  ---
  begin
    select count(1) into vn_exist from all_constraints 
    where  owner = 'CSF_OWN' and constraint_name ='CRITPESQLC_UK' ;
  exception
    when others then
      vn_exist := 0;
  end ; 
  ---
  if vn_exist =0 then
    execute immediate 'alter table csf_own.CRIT_PESQ_LC add constraint CRITPESQLC_UK unique (CONFDPTBECF_ID, DM_TIPO,crit_pesq ) using index tablespace CSF_DATA';
  end if;
end;
/

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60408 - Incluir mais de um crit�rio de pesquisa para ECF - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60339: GOLIVE USJ - Atividades PL Relacionadas - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------
declare
  vn_existe number := 0;
begin
   --
   begin
      select 1
        into vn_existe
      from csf_own.neo_papel t
      where t.nome = 'gestaopedido';
   exception
      when no_data_found then
         insert into csf_own.neo_papel (ID, DESCR, NOME)
         values (csf_own.neopapel_seq.nextval, 'Gest�o de Pedidos de Compras', 'gestaopedido');
   end;
   --
   begin
      select 1
         into vn_existe
         from csf_own.obj_integr t
      where t.cd = '56';
   exception
      when no_data_found then
         insert into csf_own.obj_integr (ID, CD, DESCR, PRIORID, DM_ATIVO)
         values (csf_own.objintegr_seq.nextval, '56', 'Pedidos', 30, 1);
   end;
   --
   begin
      select 1
        into vn_existe
      from csf_own.tipo_obj_integr t
      where t.objintegr_id in (select id from csf_own.obj_integr where cd = '56')
        and t.cd = '1';
   exception
      when no_data_found then
         insert into csf_own.TIPO_OBJ_INTEGR (ID, OBJINTEGR_ID, CD, DESCR)
         values (csf_own.TIPOOBJINTEGR_SEQ.NEXTVAL
               , (select id from csf_own.obj_integr where cd = '56')
               , '1'
               , 'Pedidos');
   end;   
   --
   begin
      select 1
        into vn_existe
      from csf_own.tipo_obj_integr t
      where t.objintegr_id in (select id from csf_own.obj_integr where cd = '56')
        and t.cd = '2';
   exception
      when no_data_found then
         insert into csf_own.TIPO_OBJ_INTEGR (ID, OBJINTEGR_ID, CD, DESCR)
         values (csf_own.TIPOOBJINTEGR_SEQ.NEXTVAL
               , (select id from csf_own.obj_integr where cd = '56')
               , '2'
               , 'Controle do Retorno da NF para o ERP do Cliente');
   end;    
   --
   commit;
   --
end;
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60339: GOLIVE USJ - Atividades PL Relacionadas - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60325: Erros na gera��o da FCI. - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

alter table CSF_OWN.INF_ITEM_FCI modify coef_import NUMBER(7,2)
/

commit
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60325: Erros na gera��o da FCI. - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60189: Criar estrutura de banco - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

create table csf_own.PARAM_NF_BASE_CUPOM
(
  ID               NUMBER not null,
  CODIGO           VARCHAR2(60) not null,
  EMPRESA_ID       NUMBER not null,
  NATOPER_ID       NUMBER not null,
  SERIE            VARCHAR2(3) not null,
  DM_FIN_NFE       NUMBER(1) not null,
  DM_VL_ITEM       NUMBER(1) not null,
  DM_TIPO_INF_ADIC NUMBER(1) not null,
  INFADIC_TXT      VARCHAR2(4000)
)
tablespace CSF_DATA
/

comment on table csf_own.PARAM_NF_BASE_CUPOM is 'Par�metro para emiss�o de NF-e com Base em Cupom Fiscal Eletr�nico ou NFC-e'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.ID is 'identificador da tabela  de par�metro para emiss�o de NF-e com Base em Cupom Fiscal Eletr�nico ou NFC-e.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.CODIGO is 'C�digo do par�metro que dever� ser �nico por empresa.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.EMPRESA_ID is 'Identificador da empresa do par�metro.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.NATOPER_ID is 'ID da natureza de opera��o relacionada ao par�metro.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.SERIE is 'S�rie da nota fiscal a ser gerada.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.DM_FIN_NFE is 'finalidade da NF-e a ser gerada. Mesmos valores do dom�nio NOTA_FISCAL.DM_FIN_NFE.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.DM_VL_ITEM is 'como deve ser gerado valor dos itens da NF-e: 0: Zerado / 1: Mesmo Doc. Refer.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.DM_TIPO_INF_ADIC is 'valor que ser� utilizado para montar NFINFOR_ADIC.DM_TIPO da NF-e que est� sendo gerada. Possui mesmos valores do dom�nio NFINFOR_ADIC.DM_TIPO.'
/

comment on column csf_own.PARAM_NF_BASE_CUPOM.INFADIC_TXT is 'texto com informa��o adicional que ser� utilizado nota fiscal que est� sendo gerada.'
/

alter table csf_own.PARAM_NF_BASE_CUPOM add constraint PARAMNFBASECUPOM_PK primary key (ID) using index tablespace CSF_DATA
/

alter table csf_own.PARAM_NF_BASE_CUPOM add constraint PARAMNFBASECUPOM_UK unique (CODIGO, EMPRESA_ID) using index tablespace CSF_DATA
/

alter table csf_own.PARAM_NF_BASE_CUPOM add constraint PARAMNFBASECUPOM_NOP_FK foreign key (NATOPER_ID) references csf_own.NAT_OPER (ID)
/

alter table csf_own.PARAM_NF_BASE_CUPOM add constraint PARAMNFBASECUPOM_EMP_FK foreign key (EMPRESA_ID) references csf_own.EMPRESA (ID)
/

grant select, insert, update, delete on csf_own.PARAM_NF_BASE_CUPOM to CSF_WORK
/


declare
cursor cdom is
select vl,descr from csf_own.dominio where dominio ='NOTA_FISCAL.DM_FIN_NFE' order by 1;
begin
  for rec in cdom loop
      exit when cdom%notfound or (cdom%notfound) is null; 
   --- 
   begin
      insert into csf_own.dominio
        (dominio,
         vl,
         descr,
         id)
      values 
      ('PARAM_NF_BASE_CUPOM.DM_FIN_NFE',
       rec.vl,
       rec.descr,
       csf_own.dominio_seq.nextval);
   exception
     when others then
      null;      
   end;
   ---         
  end loop;
  --
  commit;
end;
/


declare
cursor cdom is
select vl,descr from csf_own.dominio where dominio ='NFINFOR_ADIC.DM_TIPO' order by 1;
begin
  for rec in cdom loop
      exit when cdom%notfound or (cdom%notfound) is null; 
   --- 
   begin
      insert into csf_own.dominio
        (dominio,
         vl,
         descr,
         id)
      values 
      ('PARAM_NF_BASE_CUPOM.DM_TIPO_INF_ADIC',
       rec.vl,
       rec.descr,
       csf_own.dominio_seq.nextval);
   exception
     when others then
      null;      
   end;
   ---         
  end loop;
  --
  commit;
end;
/

begin
    insert into csf_own.dominio
      (dominio,
       vl,
       descr,
       id)
    values
      ('PARAM_NF_BASE_CUPOM.DM_VL_ITEM',
       '0',
       'Zerado',
       csf_own.dominio_seq.nextval);
   exception
     when others then
      UPDATE csf_own.dominio
       SET descr = 'Zerado'
      WHERE dominio = 'PARAM_NF_BASE_CUPOM.DM_VL_ITEM'
      and vl = '0';
--
commit;
--     
end;
/

begin
    insert into csf_own.dominio
      (dominio,
       vl,
       descr,
       id)
    values
      ('PARAM_NF_BASE_CUPOM.DM_VL_ITEM',
       '1',
       'Mesmo Doc. Refer.',
       csf_own.dominio_seq.nextval);
   exception
     when others then
      UPDATE csf_own.dominio
       SET descr = 'Mesmo Doc. Refer.'
      WHERE dominio = 'PARAM_NF_BASE_CUPOM.DM_VL_ITEM'
      and vl = '1';
--
commit;
--     
end;
/

create sequence csf_own.PARAMNFBASECUPOM_SEQ minvalue 1 maxvalue 9999999999999999999999999999 start with 1 increment by 1 nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'PARAMNFBASECUPOM_SEQ', 'PARAM_NF_BASE_CUPOM')
/

commit
/

grant select on csf_own.PARAMNFBASECUPOM_SEQ to CSF_WORK
/

begin
   INSERT INTO CSF_OWN.NEO_PAPEL (ID, DESCR, NOME)
   VALUES (CSF_OWN.NEOPAPEL_SEQ.NEXTVAL, 'Gerar NF-e Base Cupom', 'nfbasecupom');
exception   
   when dup_val_on_index then
      null;
end;   
/

commit
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60189: Criar estrutura de banco - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
Prompt INI Redmine #60569 - Debug - DIME - ST - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------
begin
  insert 
    into csf_own.registro_gia
    (id, 
     tipocodarq_id, 
     cd, 
     descr)
  values
    (csf_own.registrogia_seq.nextval,
     7,
     '35',
     'Demonstrativo da Apura��o do Imposto Devido pela Apropria��o de Cr�dito Presumido em Substitui��o aos Cr�ditos pelas Entradas (DAICP)');
exception
  when others then
    update csf_own.registro_gia r
       set r.descr         = 'Demonstrativo da Apura��o do Imposto Devido pela Apropria��o de Cr�dito Presumido em Substitui��o aos Cr�ditos pelas Entradas (DAICP)'
     where r.tipocodarq_id = 7
       and r.cd            = '35';
end;
/

--------------------------------------------------------------------------------------
Prompt FIM Redmine #60569 - Debug - DIME - ST - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------
Prompt INI Redmine #59681 - Tela e Relat�rio CTE de Terceiro - LIBERADO RELEASE_292-3 E PATCH 291-2
------------------------------------------------------------------------------------------------------
Prompt ALTER REL_NF

declare

  vn_exist_column number := 0;

  cursor c_columns is
    select 'NRO_NF_CT' tb_column,
           'NUMBER(9)' tp_column,
           'N�mero da nota fiscal composta na chave NF-e (CT_INF_NFE)' comment_column
      from dual
    union
    select 'SERIE_CT' tb_column,
           'VARCHAR2(3)' tp_column,
           'S�rie da nota fiscal composta na chave NF-e (CT_INF_NFE)' comment_column
      from dual
    union
    select 'NRO_CHAVE_NFE_CT' tb_column,
           'VARCHAR2(50)' tp_column,
           'N�mero da chave NF-e (CT_INF_NFE)' comment_column
      from dual;

begin

  for rec in c_columns loop
    exit when c_columns%notfound or(c_columns%notfound) is null;
  
    begin
      select count(*)
        into vn_exist_column
        from all_tab_columns a
       where a.table_name  = 'REL_NF'
         and a.column_name = rec.tb_column
         and a.owner       = 'CSF_OWN';
    exception
      when others then
        vn_exist_column := 0;
    end;
  
    if vn_exist_column = 0 then
    
      execute immediate 'alter table csf_own.rel_nf add '||rec.tb_column||' '||rec.tp_column||'';
    
      execute immediate 'comment on column csf_own.rel_nf.'||rec.tb_column||' is '''||rec.comment_column||''' ';
    
    end if;
  
    commit;
    
  end loop;

end;
/

Prompt ALTER REL_NF_CFOP

declare

  vn_exist_column number := 0;

  cursor c_columns is
    select 'NRO_NF_CT' tb_column,
           'NUMBER(9)' tp_column,
           'N�mero da nota fiscal composta na chave NF-e (CT_INF_NFE)' comment_column
      from dual
    union
    select 'SERIE_CT' tb_column,
           'VARCHAR2(3)' tp_column,
           'S�rie da nota fiscal composta na chave NF-e (CT_INF_NFE)' comment_column
      from dual
    union
    select 'NRO_CHAVE_NFE_CT' tb_column,
           'VARCHAR2(50)' tp_column,
           'N�mero da chave NF-e (CT_INF_NFE)' comment_column
      from dual;

begin

  for rec in c_columns loop
    exit when c_columns%notfound or(c_columns%notfound) is null;
  
    begin
      select count(*)
        into vn_exist_column
        from all_tab_columns a
       where a.table_name  = 'REL_NF_CFOP'
         and a.column_name = rec.tb_column
         and a.owner       = 'CSF_OWN';
    exception
      when others then
        vn_exist_column := 0;
    end;
  
    if vn_exist_column = 0 then
    
      execute immediate 'alter table csf_own.rel_nf_cfop add '||rec.tb_column||' '||rec.tp_column||'';
    
      execute immediate 'comment on column csf_own.rel_nf_cfop.'||rec.tb_column||' is '''||rec.comment_column||''' ';
    
    end if;
  
    commit;
    
  end loop;

end;
/

------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #59681 - Tela e Relat�rio CTE de Terceiro - LIBERADO RELEASE_292-3 E PATCH 291-2
------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60837 - Cadastramento de Tipo de Servico - LIBERADO RELEASE_292-4 E PATCH 291-2
------------------------------------------------------------------------------------------------------
begin
  insert
    into csf_own.tipo_servico
    (id,
     cod_lst,
     descr)
  values
    (csf_own.tpservico_seq.nextval,
     '1441',
     'SERV. PERICIAS,LAUDOS,EXAMES TECNICOS E ANALISE TECNICA');
exception
  when others then
    update csf_own.tipo_servico t
       set t.descr   = 'SERV. PERICIAS,LAUDOS,EXAMES TECNICOS E ANALISE TECNICA'
     where t.cod_lst = '1441';
end;
/

------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60837 - Cadastramento de Tipo de Servico - LIBERADO RELEASE_292-4 E PATCH 291-2
------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60858 - trigger apagado pois o campo por default � zero. Estava causando conflito com o trigger T_A_I_U_NOTA_FISCAL_03 - LIBERADO RELEASE_292-4 E PATCH 291-2
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
drop trigger T_B_I_U_Nota_Fiscal_04;
/

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60858 - trigger apagado pois o campo por default � zero. Estava causando conflito com o trigger T_A_I_U_NOTA_FISCAL_03 - LIBERADO RELEASE_292-4 E PATCH 291-2
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 59647 - Criar tipos de objetos de integra��o - ANALISE_CONVERSAO_ANP - LIBERADO RELEASE_292-4 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------
alter table csf_own.ANALISE_CONVERSAO_ANP add DM_ST_PROC NUMBER(2)
/

alter table csf_own.ANALISE_CONVERSAO_ANP add constraint ANALISE_CONVERSAO_ANP_DMSTPROC check (DM_ST_PROC in (0, 1, 2))
/

comment on column csf_own.ANALISE_CONVERSAO_ANP.DM_ST_PROC is 'Situa��o de Processo'
/

--------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 59647 - Criar tipos de objetos de integra��o - ANALISE_CONVERSAO_ANP - LIBERADO RELEASE_292-4 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 59647 - Criar tipos de objetos de integra��o - MOVTO_ESTQ - LIBERADO RELEASE_292-4 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------
-- Create table
-- Essa tabela foi criada pelo Armando e ir� sair no mesmo patc, estou liberando novamente o script somente por garantia
create table CSF_OWN.MOVTO_ESTQ
(
  ID                    NUMBER not null,
  EMPRESA_ID            NUMBER not null,
  ITEM_ID_INSUMO        NUMBER not null,
  DT                    DATE not null,
  QTDE                  NUMBER(15,4) not null,
  CUSTO_MERC            NUMBER(15,2) default 0 not null,
  VL_ICMS               NUMBER(15,2) default 0 not null,
  DOCINTERNOACICMSSP_ID NUMBER,
  DM_NATUR              NUMBER(1) not null,
  HIST                  VARCHAR2(255),
  DT_REFER              DATE not null,
  TIPO_MOVTO_ESTOQUE    VARCHAR2(10),
  DOC_INTERNO_CLIENTE   VARCHAR2(60),
  ORDEM                 VARCHAR2(60),
  UNID_MED              VARCHAR2(6),
  DEPOSITO              VARCHAR2(60)
)
tablespace CSF_DATA
/
  
-- Add comments to the table 
comment on table CSF_OWN.MOVTO_ESTQ  is 'Tabela de movimenta��o de produtos em estoque - lan�amentos manuais'

-- Add comments to the columns 
comment on column CSF_OWN.MOVTO_ESTQ.EMPRESA_ID            is 'Identificador da empresa'
/

comment on column CSF_OWN.MOVTO_ESTQ.ITEM_ID_INSUMO        is 'Identificador do item do produto'
/

comment on column CSF_OWN.MOVTO_ESTQ.DT                    is 'Data do movimento'
/

comment on column CSF_OWN.MOVTO_ESTQ.QTDE                  is 'Quantidade do movimento do produto em estoque'
/

comment on column CSF_OWN.MOVTO_ESTQ.CUSTO_MERC            is 'Valor/custo do produto em estoque'
/

comment on column CSF_OWN.MOVTO_ESTQ.VL_ICMS               is 'Valor do icms do movimento do produto em estoque'
/

comment on column CSF_OWN.MOVTO_ESTQ.DOCINTERNOACICMSSP_ID is 'Identificador do documento interno'
/

comment on column CSF_OWN.MOVTO_ESTQ.DM_NATUR              is 'Indicador da natureza: 0-Entrada, 1-Sa�da'
/

comment on column CSF_OWN.MOVTO_ESTQ.HIST                  is 'Hist�rico do movimento'
/

comment on column CSF_OWN.MOVTO_ESTQ.DT_REFER              is 'Data de refer�ncia que indica em qual dia/m�s/ano os dados foram gerados'
/

-- Create/Recreate primary, unique and foreign key constraints 
alter table CSF_OWN.MOVTO_ESTQ  add constraint MOVTOESTQ_PK primary key (ID)
/

alter table CSF_OWN.MOVTO_ESTQ  add constraint MOVTOESTQ_DOCINTERNO_FK foreign key (DOCINTERNOACICMSSP_ID)  references CSF_OWN.DOC_INTERNO_ACICMS_SP (ID)
/

alter table CSF_OWN.MOVTO_ESTQ  add constraint MOVTOESTQ_EMPRESA_FK foreign key (EMPRESA_ID)  references CSF_OWN.EMPRESA (ID)
/

alter table CSF_OWN.MOVTO_ESTQ  add constraint MOVTOESTQ_ITEM_FK foreign key (ITEM_ID_INSUMO)  references CSF_OWN.ITEM (ID)
/

-- Create/Recreate indexes 
create index CSF_OWN.MOVTOESTQ_DOCINTERNO_ID_FK_I on CSF_OWN.MOVTO_ESTQ (DOCINTERNOACICMSSP_ID) tablespace CSF_INDEX

create index CSF_OWN.MOVTOESTQ_EMPRESA_ID_FK_I on CSF_OWN.MOVTO_ESTQ (EMPRESA_ID)  tablespace CSF_INDEX

create index CSF_OWN.MOVTOESTQ_ITEM_ID_INSUMO_FK_I on CSF_OWN.MOVTO_ESTQ (ITEM_ID_INSUMO)  tablespace CSF_INDEX

-- Grant/Revoke object privileges 
grant select, insert, update, delete on CSF_OWN.MOVTO_ESTQ to DESENV_GENERIC_ROLE

-- Alteracao da tabela
-- ===================
alter table csf_own.MOVTO_ESTQ add DM_ST_PROC NUMBER(2)
/

comment on column csf_own.MOVTO_ESTQ.DM_ST_PROC is 'Situa��o de Processo'
/

alter table csf_own.MOVTO_ESTQ add constraint MOVTO_ESTQ_DMSTPROC_CK check (DM_ST_PROC in (0, 1, 2))
/

alter table csf_own.MOVTO_ESTQ add constraint MOVTO_ESTQ_DMNATUR_CK  check (DM_NATUR in (0, 1))
/

--------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 59647 - Criar tipos de objetos de integra��o - MOVTO_ESTQ - LIBERADO RELEASE_292-4 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - 59647	- Criar tipos de objetos de integra��o - R_LOTEINTWS_ANALCONVANP - LIBERADO RELEASE_292-4 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------
-- 01 - Cria��o da tabela
create table csf_own.R_LOTEINTWS_ANALCONVANP
(
  ID                       NUMBER not null,
  LOTEINTWS_ID             NUMBER not null,
  ANALISECONVERSAOANP_ID   NUMBER not null 
)
/

-- 02 - Cria��o dos campos para n�o ter problema com tabela j� criada


-- 03 - Coment�rio da tabela 
comment on table csf_own.R_LOTEINTWS_ANALCONVANP is 'Tabela de Relacionamento entre Lote de Integracao WebService e a Analise de Conversao ANP.'
/

-- 04 - Coment�rios dos campos
comment on column csf_own.R_LOTEINTWS_ANALCONVANP.LOTEINTWS_ID is 'ID de relacionamento com a tabela LOTE_INT_WS'
/

comment on column csf_own.R_LOTEINTWS_ANALCONVANP.ANALISECONVERSAOANP_ID is 'ID de relacionamento com a tabela ANALISE_CONVERSAO_ANP'
/

-- 05 - Cria��o da PK/UK/FK
alter table csf_own.R_LOTEINTWS_ANALCONVANP add constraint RLOTEINTWSANALCONVANP_PK primary key (ID) 
/

alter table csf_own.R_LOTEINTWS_ANALCONVANP add constraint RLOTEINTWSANALCONVANP_UK unique (LOTEINTWS_ID, ANALISECONVERSAOANP_ID)
/

alter table csf_own.R_LOTEINTWS_ANALCONVANP add constraint RLOTEINTWSANALCONVANP_LTINW_FK foreign key (LOTEINTWS_ID) references csf_own.LOTE_INT_WS (ID)
/

alter table csf_own.R_LOTEINTWS_ANALCONVANP add constraint RLOTEINTWSANALCONVANP_ACANP_FK foreign key (ANALISECONVERSAOANP_ID) references csf_own.ANALISE_CONVERSAO_ANP (ID)
/

-- 06 - Cria��o da CK

-- 07 - Cria��o dos �ndices
create index RLOTEINTWSANALCONVANP_LINWFK_I on csf_own.R_LOTEINTWS_ANALCONVANP (LOTEINTWS_ID)
/

create index RLOTEINTWSANALCONVANP_ACANFK_I on csf_own.R_LOTEINTWS_ANALCONVANP (ANALISECONVERSAOANP_ID)
/

-- 08 - Cria��o dos Grants 
grant select, insert, update, delete on csf_own.R_LOTEINTWS_ANALCONVANP to CSF_WORK
/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.RLOTEINTWSANALCONVANP_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'RLOTEINTWSANALCONVANP_SEQ', 'R_LOTEINTWS_ANALCONVANP')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - 59647	- Criar tipos de objetos de integra��o�- R_LOTEINTWS_ANALCONVANP - LIBERADO RELEASE_292-4 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - 59647	- Criar tipos de objetos de integra��o - R_LOTEINTWS_MOVTOESTQ - LIBERADO RELEASE_292-4 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------
-- 01 - Cria��o da tabela
create table csf_own.R_LOTEINTWS_MOVTOESTQ
(
  ID             NUMBER not null,
  LOTEINTWS_ID   NUMBER not null,
  MOVTOESTQ_ID   NUMBER not null 
)
/

-- 02 - Cria��o dos campos para n�o ter problema com tabela j� criada


-- 03 - Coment�rio da tabela 
comment on table csf_own.R_LOTEINTWS_MOVTOESTQ is 'Tabela de Relacionamento entre Lote de Integracao WebService e a Movimenta��o de produtos em estoque - lan�amentos manuais.'
/

-- 04 - Coment�rios dos campos
comment on column csf_own.R_LOTEINTWS_MOVTOESTQ.LOTEINTWS_ID is 'ID de relacionamento com a tabela LOTE_INT_WS'
/

comment on column csf_own.R_LOTEINTWS_MOVTOESTQ.MOVTOESTQ_ID is 'ID de relacionamento com a tabela MOVTO_ESTQ'
/

-- 05 - Cria��o da PK/UK/FK
alter table csf_own.R_LOTEINTWS_MOVTOESTQ add constraint RLOTEINTWSMOVTOESTQ_PK primary key (ID)
/

alter table csf_own.R_LOTEINTWS_MOVTOESTQ add constraint RLOTEINTWSMOVTOESTQ_UK unique (LOTEINTWS_ID, MOVTOESTQ_ID)
/

alter table csf_own.R_LOTEINTWS_MOVTOESTQ add constraint RLOTEINTWSMOVTOESTQ_LTINTWS_FK foreign key (LOTEINTWS_ID) references csf_own.LOTE_INT_WS (ID)
/

alter table csf_own.R_LOTEINTWS_MOVTOESTQ add constraint RLOTEINTWSMOVTOESTQ_MOVTOES_FK foreign key (MOVTOESTQ_ID) references csf_own.MOVTO_ESTQ (ID)
/

-- 06 - Cria��o da CK

-- 07 - Cria��o dos �ndices
create index RLOTEINTWSMOVTOESTQ_LTINTWFK_I on csf_own.R_LOTEINTWS_MOVTOESTQ (LOTEINTWS_ID)
/

create index RLOTEINTWSMOVTOESTQ_MVTESTFK_I on csf_own.R_LOTEINTWS_MOVTOESTQ (MOVTOESTQ_ID)
/

-- 08 - Cria��o dos Grants 
grant select, insert, update, delete on csf_own.R_LOTEINTWS_MOVTOESTQ to CSF_WORK
/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.RLOTEINTWSMOVTOESTQ_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'RLOTEINTWSMOVTOESTQ_SEQ', 'R_LOTEINTWS_MOVTOESTQ')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - 59647	- Criar tipos de objetos de integra��o�- R_LOTEINTWS_MOVTOESTQ - LIBERADO RELEASE_292-4 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 59647 - Criar tipos de objetos de integra��o - tipo_obj_integr - LIBERADO RELEASE_292-4 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------
declare
   --
   vn_id number := null;
   --
begin
   begin
      select id
        into vn_id
        from csf_own.obj_integr
       where cd = 33;
   exception
      when others then
         vn_id := null;
   end;
   --
   if nvl(vn_id,0) > 0 then
      --
      -- 2 - Movimento de Estoque ANP
      begin
         insert into csf_own.tipo_obj_integr b ( id                               
                                               , objintegr_id
                                               , cd
                                               , descr )
                                        values ( csf_own.tipoobjintegr_seq.nextval
                                               , vn_id       
                                               , 2
                                               , 'Movimento de Estoque ANP' );
      exception
         when dup_val_on_index then
            null;
      end;
      --
      -- 3 - Fator de Convers�o ANP
      begin
         insert into csf_own.tipo_obj_integr b ( id                               
                                               , objintegr_id
                                               , cd
                                               , descr )
                                        values ( csf_own.tipoobjintegr_seq.nextval
                                               , vn_id       
                                               , 3
                                               , 'Fator de Convers�o ANP' );
      exception
         when dup_val_on_index then
            null;
      end;
      --
      commit;
      --
   end if;
   --
exception
   when others then
      null;
end;
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 59647 - Criar tipos de objetos de integra��o - tipo_obj_integr - LIBERADO RELEASE_292-4 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #57982 - [PLSQL] Gera��o do M400/800 a partir do F500 - LIBERADO RELEASE_292-5 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------

declare
v_count number;
begin
  --
  v_count:=0;
  select count(1) into v_count from all_tab_columns 
  where owner='CSF_OWN' and table_name ='NAT_REC_PC' and column_name ='PLANOCONTA_ID';
  --
  if v_count = 0 then 
     execute immediate 'alter table csf_own.NAT_REC_PC add planoconta_id number null';
  end if;
  --
end;
/

declare
v_count number;
begin
  --
  v_count:=0;
  select count(1) into v_count from all_constraints where owner='CSF_OWN' and constraint_name ='NATRECPC_PLANOCONTA_FK';
  --
  if v_count =0 then
     execute immediate 'alter table csf_own.NAT_REC_PC add constraint NATRECPC_PLANOCONTA_FK foreign key (PLANOCONTA_ID) references csf_own.PLANO_CONTA (ID)';
  end if; 
  --
end;    
/

declare
v_count number;
begin
  --
  v_count:=0;
  select count(1) into v_count from all_tab_columns 
  where owner='CSF_OWN' and table_name ='NCM_NAT_REC_PC' and column_name ='PLANOCONTA_ID';
  --
  if v_count = 0 then 
     execute immediate 'alter table csf_own.NCM_NAT_REC_PC add planoconta_id number null';
  end if;
  --
end;
/

declare
v_count number;
begin
  --
  v_count:=0;
  select count(1) into v_count from all_constraints where owner='CSF_OWN' and constraint_name ='NCMNATRECPC_PLANOCONTA_FK';
  --
  if v_count =0 then
     execute immediate 'alter table csf_own.NCM_NAT_REC_PC add constraint NCMNATRECPC_PLANOCONTA_FK foreign key (PLANOCONTA_ID) references csf_own.PLANO_CONTA (ID)';
  end if; 
  --
end;    
/

create table csf_own.PLANO_CONTA_NAT_REC_PC
( ID            NUMBER not null,
  NATRECPC_ID   NUMBER not null,
  PLANOCONTA_ID NUMBER not null)
tablespace CSF_DATA
/

comment on table csf_own.PLANO_CONTA_NAT_REC_PC is 'Tabela Natureza de Receita conforme Codigo de Situa��o Tributaria'
/

comment on column csf_own.PLANO_CONTA_NAT_REC_PC.NATRECPC_ID is 'ID relacionado a tabela NAT_REC_PC'
/

comment on column csf_own.PLANO_CONTA_NAT_REC_PC.PLANOCONTA_ID is 'ID relacionado a tabela PLANO_CONTA'
/

alter table csf_own.PLANO_CONTA_NAT_REC_PC add constraint PCNATRECPC_PK primary key (ID) using index tablespace CSF_DATA
/

alter table csf_own.PLANO_CONTA_NAT_REC_PC add constraint PCNATRECPC_NATRECPC_FK foreign key (NATRECPC_ID) references csf_own.NAT_REC_PC (ID)
/

alter table csf_own.PLANO_CONTA_NAT_REC_PC add constraint PCNATRECPC_PLCONTA_FK foreign key (PLANOCONTA_ID) references csf_own.PLANO_CONTA (ID)
/

grant select, insert, update, delete on csf_own.PLANO_CONTA_NAT_REC_PC to CSF_WORK
/

commit
/

create sequence csf_own.PLANOCONTANATRECPC_SEQ minvalue 1 maxvalue 9999999999999999999999999999 start with 1 increment by 1 nocache
/

grant select on csf_own.PLANOCONTANATRECPC_SEQ to CSF_WORK
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'PLANOCONTANATRECPC_SEQ', 'PLANO_CONTA_NAT_REC_PC')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #57982 - [PLSQL] Gera��o do M400/800 a partir do F500 - LIBERADO RELEASE_292-5 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #55401 - DIME - Registros 80 a 84 - LIBERADO RELEASE_292-5 E PATCH 291-2
-------------------------------------------------------------------------------------------------------------------------------

prompt script_dime_anual
@@script_dime_anual.sql
show err




-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #55401 - DIME - Registros 80 a 84 - LIBERADO RELEASE_292-5 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60632: Criar PARAM_GERAL_SISTEMA - RELEASE 292-6 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------
begin
   insert into csf_own.modulo_sistema (id,
                                       cod_modulo,
                                       dsc_modulo,
                                       observacao)
                               values (csf_own.modulosistema_seq.nextval,
                                       'INTEGRACAO',
                                       'INTEGRA��ES DIVERSAS',
                                       'MODULO COM PARAMETROS REFERENTES AOS MODELOS DE INTEGRA��O');
exception
   when dup_val_on_index then
      null;
end;
/

begin
   insert into csf_own.grupo_sistema ( id,
                                       modulo_id,
                                       cod_grupo,
                                       dsc_grupo,
                                       observacao)
                              values ( csf_own.gruposistema_seq.nextval,
                                       csf_own.pk_csf.fkg_ret_id_modulo_sistema('INTEGRACAO'),
                                       'INT_MIDAS',
                                       'GRUPO COM INFORMA��ES DE INTEGRA��O DO PARCEIRO MIDAS',
                                       'GRUPO COM INFORMA��ES DE INTEGRA��O DO PARCEIRO MIDAS');
exception
   when dup_val_on_index then
      null;
end;
/

declare
  vn_usuario_id number := 0;
begin
   -- insere os parametros por mult-org e empesa
   for m in (
      select m1.id multorg_id
        from csf_own.mult_org m1
      where exists(
        select 1
          from csf_own.empresa e
        where e.multorg_id  = m1.id
          and e.dm_situacao = 1))
   loop
      -- Busca um usu?io respons?el pela inser��o do registro
      begin
         select u.id
            into vn_usuario_id
            from csf_own.neo_usuario u
         where upper(u.login) = 'ADMIN';
      exception
         when no_data_found then
            begin
               select min(u.id)
                  into vn_usuario_id
                  from csf_own.neo_usuario u
               where u.multorg_id = m.multorg_id;
            exception
               when no_data_found then
                  begin
                     select min(u.id)
                        into vn_usuario_id
                     from csf_own.neo_usuario u;
                  exception
                     when others then
                        vn_usuario_id := 0;
                  end;
            end;
      end;
      -- Insere o parametro por mult_org
      begin
         insert into csf_own.param_geral_sistema (id,
                                                  multorg_id,
                                                  empresa_id,
                                                  modulo_id,
                                                  grupo_id,
                                                  param_name,
                                                  dsc_param,
                                                  vlr_param,
                                                  usuario_id_alt,
                                                  dt_alteracao)
                                          values (csf_own.paramgeralsistema_seq.nextval,
                                                  m.multorg_id,
                                                  null,
                                                  csf_own.pk_csf.fkg_ret_id_modulo_sistema('INTEGRACAO'),
                                                  csf_own.pk_csf.fkg_ret_id_grupo_sistema('INT_MIDAS'),
                                                  'PADRAO_ARM_NFE_TERC',
                                                  'Padrao de como o campo DM_ARM_NFE_TERC deve ser gravado na tabela NOTA_FISCAL na integra��o de XML de nota de servico no padrao Midas. Esse parametro determina se o documento ser?escriturado e com isso considerado nas obriga��es fiscais ou se apenas fica como armazenamento de XML e nesse caso nao aparece nas obriga��es fiscais. Valores possiveis = 0 (Nota ser?escriturada), 1 (Apenas armazenamento)',
                                                  '1',
                                                  vn_usuario_id,
                                                  sysdate);
      exception
         when others then
            null;
      end;
      --
      -- Varre as Empresas do Mult_org
      for e in (
         select e1.id empresa_id
           from csf_own.empresa e1
         where e1.multorg_id = m.multorg_id)
      loop
         -- Insere o parametro por empresa
         begin
            insert into csf_own.param_geral_sistema (id,
                                                     multorg_id,
                                                     empresa_id,
                                                     modulo_id,
                                                     grupo_id,
                                                     param_name,
                                                     dsc_param,
                                                     vlr_param,
                                                     usuario_id_alt,
                                                     dt_alteracao)
                                             values (csf_own.paramgeralsistema_seq.nextval,
                                                     m.multorg_id,
                                                     e.empresa_id,
                                                     csf_own.pk_csf.fkg_ret_id_modulo_sistema('INTEGRACAO'),
                                                     csf_own.pk_csf.fkg_ret_id_grupo_sistema('INT_MIDAS'),
                                                     'COD_ITEM_PADRAO',
                                                     'Padrao para cria��o do item da nota de servico pela integra��o do XML de nota de servico padrao Midas. Quando nao houver informa��o do COD_ITEM no XML, esse parametro serao considerado para criar o item da nota. O pre requisito que haja um item cadastrado com o mesmo COD_ITEM. Valor valido: qualquer valor ate 60 posi��es que esteja no cadastro de item como COD_ITEM.',
                                                     '0',
                                                     vn_usuario_id,
                                                     sysdate);
         exception
            when others then
               null;
         end;
         --
      end loop;
      --
   end loop;
   --
end;
/

commit
/
--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60632: Criar PARAM_GERAL_SISTEMA - RELEASE 292-6 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60686: Criar tabela - RELEASE 292-6 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

@@67_script_csf_own_PARAM_RECEB_VLD_RET_PES.sql;

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60686: Criar tabela - RELEASE 292-6 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #58163: Parametro de tipo de XML gravado - RELEASE 292-6 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------
begin
    --- 
    begin
       insert into CSF_OWN.modulo_sistema (id,
                                           cod_modulo,
                                           dsc_modulo,
                                           observacao)
                                   values (CSF_OWN.modulosistema_seq.nextval,
                                           'INTEGRACAO',
                                           'Modulo com parametros referentes aos modelos de integra��o',
                                           'Modulo com parametros referentes aos modelos de integra��o');
    exception
       when others then
          update CSF_OWN.modulo_sistema
             set dsc_modulo = 'Modulo com parametros referentes aos modelos de integra��o',
                 observacao = 'Modulo com parametros referentes aos modelos de integra��o'
           where cod_modulo = 'INTEGRACAO'; 
  end;
  ---  
  begin
     insert into CSF_OWN.grupo_sistema (id,
                                        modulo_id,
                                        cod_grupo,
                                        dsc_grupo,
                                        observacao)
                                 values (CSF_OWN.gruposistema_seq.nextval,
                                         (select id from CSF_OWN.modulo_sistema where cod_modulo = 'INTEGRACAO'),
                                         'INT_MIDAS',
                                         'Grupo com informa��es de integra��o do parceiro Midas',
                                         'Grupo com informa��es de integra��o do parceiro Midas');
  exception
     when others then
        update CSF_OWN.grupo_sistema
           set dsc_grupo = 'Grupo com informa��es de integra��o do parceiro Midas',
               observacao = 'Grupo com informa��es de integra��o do parceiro Midas'
         where modulo_id  = (select id from CSF_OWN.modulo_sistema where cod_modulo = 'INTEGRACAO')
           and cod_grupo = 'INT_MIDAS'; 
  end;
  --  
  commit;
  --
end;
/

begin
  --    
  declare
     --   
     cursor c_multorg is
       select m.id
         from CSF_OWN.mult_org m;
     --     
  begin
     for rec in c_multorg loop
        exit when c_multorg%notfound or (c_multorg%notfound) is null;
        --
        begin
           insert into CSF_OWN.param_geral_sistema (id,
                                                    multorg_id,
                                                    empresa_id,
                                                    modulo_id,
                                                    grupo_id,
                                                    param_name,
                                                    dsc_param,
                                                    vlr_param,
                                                    usuario_id_alt,
                                                    dt_alteracao)
                                            values (CSF_OWN.paramgeralsistema_seq.nextval,
                                                    rec.id,
                                                    null,
                                                    (select id from CSF_OWN.modulo_sistema where cod_modulo = 'INTEGRACAO'),
                                                    (select id from CSF_OWN.grupo_sistema where cod_grupo = 'INT_MIDAS' ),
                                                    'MOD_XML_ARM_NFS',   
                                                    'Modelo de XML que deve ser armazenado no campo NOTA_FISCAL.NFE_PROC_XML ao integrar Nota de terceiros pela leitura de XML da Midas. Valores poss�veis: MIDAS, CSF',   
                                                    'CSF',
                                                    3,
                                                    sysdate);
        exception
           when others then
              update CSF_OWN.param_geral_sistema
                 set dsc_param      = 'Modelo de XML que deve ser armazenado no campo NOTA_FISCAL.NFE_PROC_XML ao integrar Nota de terceiros pela leitura de XML da Midas. Valores poss�veis: MIDAS, CSF',
                     vlr_param      = 'CSF',
                     usuario_id_alt = 3,
                     dt_alteracao   = sysdate
               where multorg_id = rec.id
                 and modulo_id  = (select id from CSF_OWN.modulo_sistema where cod_modulo = 'INTEGRACAO')
                 and grupo_id   = (select id from CSF_OWN.grupo_sistema where cod_grupo = 'INT_MIDAS')       
                 and param_name = 'MOD_XML_ARM_NFS'; 
        end;     
        --
     end loop;  
     --
  end;
  --  
  commit;
  --
end;
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #58163: Parametro de tipo de XML gravado - RELEASE 292-6 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------
Prompt FIM Patch 2.9.1.2 - Alteracoes no CSF_OWN
------------------------------------------------------------------------------------------



