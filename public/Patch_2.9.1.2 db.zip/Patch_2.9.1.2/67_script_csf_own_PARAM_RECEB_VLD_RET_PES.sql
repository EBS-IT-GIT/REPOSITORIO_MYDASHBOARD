-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Tabela PARAM_RECEB_VLD_RET_PES
-------------------------------------------------------------------------------------------------------------------------------
create table CSF_OWN.PARAM_RECEB_VLD_RET_PES
(
    ID               NUMBER NOT NULL
  , MULTORG_ID       NUMBER NOT NULL
  , MODFISCAL_ID     NUMBER NOT NULL
  , PESSOA_ID        NUMBER NOT NULL
  , TIPOIMP_ID       NUMBER NOT NULL
  , TIPOSERVICO_ID   NUMBER NULL 
  , CONSTRAINT PARAMRECEBVLDRETPES_PK PRIMARY KEY (ID) USING INDEX TABLESPACE CSF_INDEX
) TABLESPACE CSF_DATA
/

comment on table CSF_OWN.PARAM_RECEB_VLD_RET_PES                 is 'Parametro de valida��o de recebimento de nota com reten��o de impostos para pessoa emitente'
/

comment on column CSF_OWN.PARAM_RECEB_VLD_RET_PES.id             is 'Id Unico da tabela - PARAMRECEBVLDRETPES_SEQ'
/

comment on column CSF_OWN.PARAM_RECEB_VLD_RET_PES.multorg_id     is 'Identificador do Mult_org - Relacionamento: MULT_ORG.ID'
/

comment on column CSF_OWN.PARAM_RECEB_VLD_RET_PES.modfiscal_id   is 'Identificador do Modelo Fiscal - Relacionamento: MOD_FISCAL.ID'
/

comment on column CSF_OWN.PARAM_RECEB_VLD_RET_PES.pessoa_id      is 'Identificador do Participante - Relacionamento: PESSOA.ID'
/

comment on column CSF_OWN.PARAM_RECEB_VLD_RET_PES.tipoimp_id     is 'Identificador do Tipo de Imposto - Relacionamento: TIPO_IMPOSTO.ID'
/

comment on column CSF_OWN.PARAM_RECEB_VLD_RET_PES.tiposervico_id is 'Identificador do Tipo de Servi�o - Relacionamento: TIPO_SERVICO.ID'
/

alter table CSF_OWN.PARAM_RECEB_VLD_RET_PES  add constraint PRECEBVLDRETPES_MULTORG_FK      foreign key (MULTORG_ID)      references CSF_OWN.MULT_ORG (ID)
/

alter table CSF_OWN.PARAM_RECEB_VLD_RET_PES  add constraint PRECEBVLDRETPES_MODFISCAL_FK    foreign key (MODFISCAL_ID)    references CSF_OWN.MOD_FISCAL (ID)
/

alter table CSF_OWN.PARAM_RECEB_VLD_RET_PES  add constraint PRECEBVLDRETPES_PESSOA_FK       foreign key (PESSOA_ID)       references CSF_OWN.PESSOA (ID)
/

alter table CSF_OWN.PARAM_RECEB_VLD_RET_PES  add constraint PRECEBVLDRETPES_TIPOIMP_FK      foreign key (TIPOIMP_ID)      references CSF_OWN.TIPO_IMPOSTO (ID)
/

alter table CSF_OWN.PARAM_RECEB_VLD_RET_PES  add constraint PRECEBVLDRETPES_TIPOSERVICO_FK  foreign key (TIPOSERVICO_ID)  references CSF_OWN.TIPO_SERVICO (ID)
/

alter table CSF_OWN.PARAM_RECEB_VLD_RET_PES  add constraint PARAMRECEBVLDRETPES_UK          unique (MULTORG_ID, MODFISCAL_ID, PESSOA_ID, TIPOIMP_ID, TIPOSERVICO_ID)
/

create index PRECEBVLDRETPES_MULTORG_IX      on CSF_OWN.PARAM_RECEB_VLD_RET_PES (MULTORG_ID) TABLESPACE CSF_INDEX
/

create index PRECEBVLDRETPES_MODFISCAL_IX    on CSF_OWN.PARAM_RECEB_VLD_RET_PES (MODFISCAL_ID) TABLESPACE CSF_INDEX
/
  
create index PRECEBVLDRETPES_PESSOA_IX       on CSF_OWN.PARAM_RECEB_VLD_RET_PES (PESSOA_ID) TABLESPACE CSF_INDEX
/

create index PRECEBVLDRETPES_TIPOIMP_IX      on CSF_OWN.PARAM_RECEB_VLD_RET_PES (TIPOIMP_ID) TABLESPACE CSF_INDEX
/

create index PRECEBVLDRETPES_TIPOSERVICO_IX  on CSF_OWN.PARAM_RECEB_VLD_RET_PES (TIPOSERVICO_ID) TABLESPACE CSF_INDEX
/

BEGIN
   EXECUTE IMMEDIATE '
      CREATE SEQUENCE CSF_OWN.PARAMRECEBVLDRETPES_SEQ
      INCREMENT BY 1
      START WITH   1
      NOMINVALUE
      NOMAXVALUE
      NOCYCLE
      NOCACHE
   ';
EXCEPTION
  WHEN OTHERS THEN
     IF SQLCODE = -955 THEN
        NULL;
     ELSE
       RAISE;
     END IF;
END;          
/

BEGIN
   INSERT INTO CSF_OWN.SEQ_TAB ( id
                               , sequence_name
                               , table_name
                               )
                        values ( CSF_OWN.seqtab_seq.nextval
                               , 'PARAMRECEBVLDRETPES_SEQ'
                               , 'PARAM_RECEB_VLD_RET_PES'
                               );
EXCEPTION
   WHEN DUP_VAL_ON_INDEX THEN
      NULL;
END;                                
/

GRANT SELECT, INSERT, UPDATE, DELETE   ON CSF_OWN.PARAM_RECEB_VLD_RET_PES   TO CSF_WORK
/

GRANT SELECT                           ON CSF_OWN.PARAMRECEBVLDRETPES_SEQ   TO CSF_WORK
/

commit
/
-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Tabela PARAM_RECEB_VLD_RET_PES
-------------------------------------------------------------------------------------------------------------------------------