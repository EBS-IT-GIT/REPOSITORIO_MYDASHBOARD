---------------------------------------------------------------------------------------------
Prompt INI Release 2.9.1.2 - Alteracoes no CSF_WORK
---------------------------------------------------------------------------------------------
SET DEFINE OFF
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #60189: Criar estrutura de banco - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------
create or replace synonym csf_work.PARAM_NF_BASE_CUPOM for csf_own.PARAM_NF_BASE_CUPOM
/

create or replace synonym csf_work.PARAMNFBASECUPOM_SEQ for csf_own.PARAMNFBASECUPOM_SEQ
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #60189: Criar estrutura de banco - LIBERADO RELEASE_292-3 E PATCH 291-2
--------------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - 59647  - Criar tipos de objetos de integra��o - R_LOTEINTWS_MOVTOESTQ - LIBERADO RELEASE_292-4 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------
-- 09 - Cria��o do Sin�nimo
create or replace synonym csf_work.R_LOTEINTWS_MOVTOESTQ for csf_own.R_LOTEINTWS_MOVTOESTQ
/

create or replace synonym csf_work.RLOTEINTWSMOVTOESTQ_SEQ for csf_own.RLOTEINTWSMOVTOESTQ_SEQ
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - 59647  - Criar tipos de objetos de integra��o�- R_LOTEINTWS_MOVTOESTQ - LIBERADO RELEASE_292-4 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - 59647  - Criar tipos de objetos de integra��o - R_LOTEINTWS_ANALCONVANP - LIBERADO RELEASE_292-4 E PATCH 291-2��
-------------------------------------------------------------------------------------------------------------------------------
-- 09 - Cria��o do Sin�nimo
create or replace synonym csf_work.R_LOTEINTWS_ANALCONVANP for csf_own.R_LOTEINTWS_ANALCONVANP
/

create or replace synonym csf_work.RLOTEINTWSANALCONVANP_SEQ for csf_own.RLOTEINTWSANALCONVANP_SEQ
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - 59647  - Criar tipos de objetos de integra��o�- R_LOTEINTWS_ANALCONVANP - LIBERADO RELEASE_292-4 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #57982 - [PLSQL] Gera��o do M400/800 a partir do F500 - LIBERADO RELEASE_292-5 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

create or replace synonym csf_work.PLANO_CONTA_NAT_REC_PC for csf_own.PLANO_CONTA_NAT_REC_PC
/

create or replace synonym csf_work.PLANOCONTANATRECPC_SEQ for csf_own.PLANOCONTANATRECPC_SEQ
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #57982 - [PLSQL] Gera��o do M400/800 a partir do F500 - LIBERADO RELEASE_292-5 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
Prompt INI Redmine #55401 - DIME - Registros 80 a 84 - LIBERADO RELEASE_292-5 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

create synonym csf_work.inf_comp_dime for csf_own.inf_comp_dime
/

create synonym csf_work.infcompdime_seq for csf_own.infcompdime_seq
/

create synonym csf_work.det_inf_comp_dime for csf_own.det_inf_comp_dime
/

create synonym csf_work.detinfcompdime_seq for csf_own.detinfcompdime_seq
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #55401 - DIME - Registros 80 a 84 - LIBERADO RELEASE_292-5 E PATCH 291-2�
-------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------
Prompt FIM Release 2.9.1.2 - Alteracoes no CSF_WORK
---------------------------------------------------------------------------------------------
