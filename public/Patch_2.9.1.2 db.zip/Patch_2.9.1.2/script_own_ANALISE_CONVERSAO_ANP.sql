-- Create table
create table CSF_OWN.ANALISE_CONVERSAO_ANP
(
  ID            NUMBER not null,
  ITEM_ID       NUMBER not null,
  DT_ANALISE    DATE not null,
  VLR_CONVERSAO NUMBER(10,8) not null,
  DEPOSITO      VARCHAR2(60),
  DM_ST_PROC    NUMBER(2)
)
tablespace CSF_DATA
/

-- Add comments to the columns 
comment on column CSF_OWN.ANALISE_CONVERSAO_ANP.DM_ST_PROC  is 'Situa��o de Processo'
/

-- Create/Recreate primary, unique and foreign key constraints 
alter table CSF_OWN.ANALISE_CONVERSAO_ANP  add constraint ANALISE_CONVERSAO_ANP_PK primary key (ID)
/

alter table CSF_OWN.ANALISE_CONVERSAO_ANP  add constraint ANALISE_CONVERSAO_ANP_ITEM_FK foreign key (ITEM_ID) references CSF_OWN.ITEM (ID);
/

-- Create/Recreate check constraints 
alter table CSF_OWN.ANALISE_CONVERSAO_ANP  add constraint ANALISE_CONVERSAO_ANP_DMSTPROC  check (DM_ST_PROC in (0, 1, 2))
/

-- Create/Recreate indexes 
create index CSF_OWN.ANALISECONVERSAOANP_IDX_01 on CSF_OWN.ANALISE_CONVERSAO_ANP (ID) tablespace CSF_DATA
/

create index CSF_OWN.ANALISECONVERSAOANP_IDX02 on CSF_OWN.ANALISE_CONVERSAO_ANP (ITEM_ID, DT_ANALISE) tablespace CSF_DATA

-- Cria��o dos Grants 
grant select, insert, update, delete on csf_own.ANALISE_CONVERSAO_ANP to CSF_WORK
/

-- Cria��o da Sequence
create sequence CSF_OWN.ANALISECONVERSAOANP_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'ANALISECONVERSAOANP_SEQ', 'ANALISE_CONVERSAO_ANP')
/

commit
/
