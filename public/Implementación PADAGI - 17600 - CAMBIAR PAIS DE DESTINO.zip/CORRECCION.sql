UPDATE apps.oe_order_headers_all ooh
SET    ship_to_org_id = 3551747, last_update_sysdate = sysdate, last_updated_by = 2070
WHERE  header_id = 10870853;
--1 Registro