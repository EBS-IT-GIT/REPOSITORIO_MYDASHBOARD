  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_AP_EOAFSLA_PKG" IS

e_exception    EXCEPTION;
e_message      VARCHAR2(1000);
e_retcode      NUMBER;


PROCEDURE main (errbuf           OUT VARCHAR2
               ,retcode          OUT NUMBER
               ,p_country in VARCHAR2
               ,p_fecha_desde     IN VARCHAR2
               ,p_fecha_hasta     IN VARCHAR2
               ,p_coda_id IN VARCHAR2  --> solo para  filtrar cuenta_desde es el chart_of_account
               ,p_cuenta_desde    IN VARCHAR2
               ,p_cuenta_hasta    IN VARCHAR2
               ,p_vendor_type     IN VARCHAR2
               ,p_solo_dist       IN VARCHAR2
               ,p_op              IN NUMBER
               ,p_prorateo_imp    IN VARCHAR2
               ,p_sep             IN VARCHAR2
               ,p_solo_comp       IN VARCHAR2
               ,p_intercompany in varchar2
               ,p_bancos_misce in varchar2
               , p_ctas_cruzadas in varchar2
                , P_UNI_ID01   in VARCHAR2
                ,P_UNI_ID02 in   VARCHAR2
                ,P_UNI_ID03 IN  VARCHAR2
                ,P_UNI_ID04 IN  VARCHAR2
                ,P_UNI_ID05 IN  VARCHAR2
                ,P_UNI_ID06 IN  VARCHAR2
                ,P_UNI_ID07 IN  VARCHAR2
                ,P_UNI_ID08 IN  VARCHAR2
                ,P_UNI_ID09 IN  VARCHAR2
                ,P_UNI_ID10 IN  VARCHAR2
                ,P_UNI_ID11 IN  VARCHAR2
                ,P_UNI_ID12 IN  VARCHAR2
                ,P_UNI_ID13 IN  VARCHAR2
                ,P_UNI_ID14 IN  VARCHAR2
                ,P_UNI_ID15 IN  VARCHAR2
                ,P_UNI_ID16 IN  VARCHAR2);
--Rm ST 20180918
--FUNCTION dist_nueva(p_invoice_dist_id IN NUMBER)
--RETURN NUMBER;

--Add ST 20180918

FUNCTION get_combination_code ( p_prorateo_imp            in varchar2
                    ,p_invoice_dist_id         in ap_invoice_distributions_all.invoice_distribution_id%type
                    ,p_aux_invoice_dist_id     in ap_invoice_distributions_all.invoice_distribution_id%type
                    ,p_code_combination_id     in ap_invoice_distributions_all.dist_code_combination_id%type
                    ,p_po_distribution_id      in ap_invoice_distributions_all.po_distribution_id%type
                    )
                    RETURN NUMBER;


FUNCTION tasa_diaria(p_from_currency   IN VARCHAR2
                    ,p_to_currency     IN VARCHAR2
                    ,p_conversion_date IN DATE
                    ,p_conversion_type IN VARCHAR2)
RETURN NUMBER;

FUNCTION lookup_m(p_security_group_id   IN NUMBER
                 ,p_view_application_id IN NUMBER
                 ,p_lookup_type         IN VARCHAR2
                 ,p_lookup_code         IN VARCHAR2)
RETURN VARCHAR2;

FUNCTION flex_lookup_m(p_flex_value_set_id IN NUMBER
                      ,p_flex_value        IN VARCHAR2)
RETURN VARCHAR2;

END XX_AR_AP_EOAFSLA_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_AP_EOAFSLA_PKG" IS 

/*----------------------------------------------------------------
-- PROCEDURE main                                               --
-- p_fecha_desde     fecha desde la que se consideran los pagos --
-- p_fecha_hasta     fecha hasta la que se consideran los pagos --
-- p_cuenta_desde    Cuenta desde la que se quiere analizar     --
-- p_cuenta_hasta    Cuenta hasta la que se quiere analizar     --
-- p_vendor_type     Tipo de vendedor que se quiere analizar    --
-- p_solo_dist       Flag para no mostrar retenciones           --
-- p_op              Nro OP que se quiere analizar              --
-- p_prorateo_imp    Flag para proratear los TAX en los ITEM    --
-- p_sep             Caracter separador de campos               --
-- p_solo_comp       Flag para analizar solo pagos compensados  --
-----------------------------------------------------------------*/
g_country varchar2(2);
g_fecha_desde     date;
g_fecha_hasta     date;
g_cuenta_desde    VARCHAR2(100);
g_cuenta_hasta    VARCHAR2(100);
g_vendor_type     VARCHAR2(20);
g_solo_dist       VARCHAR2(3);
g_op              NUMBER(10);
g_prorateo_imp    VARCHAR2(3);
g_separador             VARCHAR2(1);
g_solo_comp       VARCHAR2(3);
g_intercompany varchar2(1);
g_bancos_misce varchar2(1);
g_ctas_cruzadas varchar2(1);
G_UNI_ID01 number(5);
G_UNI_ID02 number(5);
G_UNI_ID03 number(5);
G_UNI_ID04 number(5);
G_UNI_ID05 number(5);
G_UNI_ID06 number(5);
G_UNI_ID07 number(5);
G_UNI_ID08 number(5);
G_UNI_ID09 number(5);
G_UNI_ID10 number(5);
G_UNI_ID11 number(5);
G_UNI_ID12 number(5);
G_UNI_ID13 number(5);
G_UNI_ID14 number(5);
G_UNI_ID15 number(5);
G_UNI_ID16 number(5);
g_master_organization number:= 135;

  -- ---------------------------------------------------------------------------
  --
  -- PROCEDURE: DEBUG
  -- DESCRIPCION:
  --
  -- ---------------------------------------------------------------------------
  PROCEDURE debug ( p_message IN VARCHAR2
                  , p_indent  IN NUMBER DEFAULT 2
                  ) IS
    l_blanks  VARCHAR2(250);
    l_indent  NUMBER;
    l_osuser  varchar2(10);
  BEGIN
    l_indent := p_indent;

    IF l_indent > 250 THEN
      l_indent := 250;
    END IF;

    SELECT lpad(' ', l_indent, ' ')
    INTO l_blanks
    FROM DUAL ;

  select osuser into l_osuser from v$session where audsid = userenv('SESSIONID');
  if l_osuser = 'irosas' then
    dbms_output.put_line (l_blanks || p_message);
   else
    fnd_file.put_line(fnd_file.log,l_blanks || p_message);
    end if;

  END;

FUNCTION get_combination_code ( p_prorateo_imp            in varchar2
                    ,p_invoice_dist_id         in ap_invoice_distributions_all.invoice_distribution_id%type  --> id_distribucion movimiento (la usa en prorateo_imp = 'Y')
                    ,p_aux_invoice_dist_id     in ap_invoice_distributions_all.invoice_distribution_id%type --> id_distribucion del item de la factura (la usa en prorateo_imp = 'Y')
                    ,p_code_combination_id     in ap_invoice_distributions_all.dist_code_combination_id%type  --> gcc de la distribucion
                    ,p_po_distribution_id      in ap_invoice_distributions_all.po_distribution_id%type --> id_distribucion de la oc
                    )
                    RETURN NUMBER IS
l_code_combination_id           number;
begin

       if p_prorateo_imp = 'Y'   and p_invoice_dist_id <> p_aux_invoice_dist_id     then         --Prorratear Impuestos, entonces busco la informacion de la distribucion del articulo(Padre)

                        begin
                            select nvl(pd.code_combination_id, aid.dist_code_combination_id)   --Busco la cuenta de la Distribucion de la OC, si no la cuenta de la Distribución de la Factura
                              into l_code_combination_id
                              from ap_invoice_distributions_all   aid
                                     ,po_distributions_all           pd
                             where 1=1
                               and aid.po_distribution_id      = pd.po_distribution_id(+)
                               and aid.invoice_distribution_id =  p_aux_invoice_dist_id;

                         Exception when others then
                            l_code_combination_id := -1;
                        end;

            else

                       --Busco la cuenta de la Distribucion de la OC, si no existe,--busco la cuenta de la Distribución de la Factura
                        if p_po_distribution_id is null        then
                            l_code_combination_id := p_code_combination_id;
                        else
                                    begin
                                        select nvl(pd.code_combination_id,  p_code_combination_id)
                                          into l_code_combination_id
                                          from po_distributions_all    pd
                                         where 1=1
                                           and pd.po_distribution_id   = p_po_distribution_id;

                                     Exception when others then
                                       l_code_combination_id := -1;
                                    end;
                        end if;
            end if;
     return l_code_combination_id;
end get_combination_code;



procedure inserta_temporal  IS

l_concatenated_segments  gl_code_combinations_kfv.concatenated_segments%type;
l_segment2  gl_code_combinations_kfv.segment2%type;
l_segment3  gl_code_combinations_kfv.segment3%type;
l_sla_concatena_segments  gl_code_combinations_kfv.concatenated_segments%type;
l_sla_segment2  gl_code_combinations_kfv.segment2%type;
l_sla_segment3  gl_code_combinations_kfv.segment3%type;
l_sla_gcc_id number;

l_flex_set_gl_cuenta number;
l_excluye varchar2(1);
l_cuenta_cruzada_con_ar varchar2(30);
l_tipo_mov varchar2(10) := null; --'RESTO AA';-- 'RESTO';
l_bank_name  ce_bank_branches_v.bank_name%type;
l_bank_branch_name  ce_bank_branches_v.bank_branch_name%type;
l_lin_update number := 0;
l_lin_delete number := 0;

begin
    DEBUG('p_country: '||g_country);


      SELECT ffvs.flex_value_set_id into l_flex_set_gl_cuenta
     FROM               fnd_flex_value_sets ffvs
    WHERE  ffvs.flex_value_set_name =  'XX_GL_CUENTA' ;

    debug('Por insertar temporal' , null);

if nvl(l_tipo_mov,'ALL') IN ( 'AWT','ALL') THEN
/* Lineas AWT   - No se proratean por el pago son de join directo con el pago*/
insert into xx_AP_EOAF_MOV_GT( SECCION, ORDEN, org_id,  vendor_id, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                 CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                  AMOUNT, DIST_DESC, FUTURE_PAY_DUE_DATE,
                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                  ,CODE_COMBINATION_ID        , po_header_id, po_line_id, item_description, LINE_NUMBER
                                                  , invoice_distribution_id)
SELECT 'AWT'                                     seccion
       , 3                                         orden
      , max(aia.org_id)
      ,max(aia.vendor_id)
     , max(aia.invoice_type_lookup_code)
     , aia.invoice_id
     , ac.check_id
     , max(haou.name)
     , max(pv.vendor_name)
     , max(pv.segment1)
     , max(pv.vendor_type_lookup_code)                tipo_prov
     , max(cbb.bank_name)
     , max(cbb.bank_branch_name)
     , max(ac.bank_account_name)
     , max(ac.doc_sequence_value)
     , max(ac.status_lookup_code)
     , max(ac.check_date)
     , max(ac.payment_method_lookup_code )            pay_method_desc
     , max(ac.currency_code)
     , max(NVL(ac.exchange_rate,1))                   exchange_rate_pago
     , max(NVL(ac.base_amount,ac.amount))             base_amount
     , max(ac.amount)                                 base_amount_ori
     , max(aia.invoice_num)
     , max(aia.invoice_date)
     , max(aia.invoice_currency_code)
     , max(aia.exchange_rate)
     , SUM(NVL(pd.base_amount,pd.amount))*-1     amount
     , max(aia.description)                           dist_desc
     , max(NVL(ac.future_pay_due_date,ac.check_date)) future_pay_due_date
     , max(NVL(xx_ap_libro_iva_distribucion,'N'))     datos_cabecera
     , max(pv1.vendor_name)                           ff_vendor_name
     , max(pv1.segment1)                              ff_segment1
     , max(xx_ap_invoice_num)                         ff_invoice_num
     , max(xx_ap_invoice_date)                        ff_invoice_date
     , gcc.code_combination_id
     , max(nvl(aia.po_header_id, ail.po_header_id))
     , MAX(ail.po_line_id)
     , max(ail.item_description)
     , ail.line_number
      , pd.invoice_distribution_id
  FROM ap_invoice_distributions_all   pd
      ,ap_invoice_distributions_a_dfv pd_dfv
      ,ap_invoice_lines_all           ail --R12
     , ap_invoices_all aia
      ,ap_invoices_all_dfv            aia_dfv
      ,ap_invoice_payments_all            aip
      ,ap_suppliers                   pv
      ,hr_operating_units      haou
      ,ap_checks_all                      ac
      ,ce_bank_accounts               cba
      ,ce_bank_acct_uses_all          cbu
      ,ce_bank_branches_v             cbb
      ,ap_suppliers                   pv1
      , gl_code_combinations gcc
 WHERE NVL(pd_dfv.xx_ap_vendor_id,'-1')                 = pv1.vendor_id (+)
   AND pd.rowid                                         = pd_dfv.row_id
   AND aia.rowid                                       = aia_dfv.row_id
   AND ail.line_type_lookup_code                        = 'AWT'
   AND substr(haou.name,1,2)                            = g_country
   AND haou.organization_id                             = aia.org_id
   AND ac.ce_bank_acct_use_id                           = cbu.bank_acct_use_id
   AND cbu.bank_account_id                              = cba.bank_account_id
   AND cba.bank_branch_id                               = cbb.branch_party_id
   AND pd.awt_invoice_payment_id                        = aip.invoice_payment_id
   AND (NVL(g_solo_comp,'Y') = 'N'
        OR
        NVL(g_solo_comp,'Y')                            = DECODE(ac.status_lookup_code
                                                                ,'CLEARED','Y'
                                                                ,'RECONCILED','Y'
                                                                ,'CLEARED BUT UNACCOUNTED','Y'
                                                                ,'N'))                                            --Pagos compensados
   AND   AP_INVOICES_PKG.GET_APPROVAL_STATUS( AIa.INVOICE_ID,
                                                                               AIa.INVOICE_AMOUNT, AIa.PAYMENT_STATUS_FLAG,
                                                                                AIa.INVOICE_TYPE_LOOKUP_CODE)  != 'CANCELLED' --APPROVAL_STATUS_LOOKUP_CODE  --Facturas no canceladas
   AND aip.check_id                                     = ac.check_id
   AND aia.invoice_id                                   = aip.invoice_id
   AND pv.vendor_id                                     = aia.vendor_id
   AND aia.invoice_id                                   = ail.invoice_id --R12
   AND ail.line_number                                  = pd.invoice_line_number --R12
   AND ail.invoice_id                                   = pd.invoice_id --R12
   --Add ST 20180918
   AND NVL(pd.base_amount,pd.amount)                   <> 0 --R12
   AND NVL(g_solo_dist, 'N')                            = 'Y'
   AND NVL(ac.doc_sequence_value,'-1')                  = NVL(NVL(g_op,ac.doc_sequence_value),'-1')
   AND NVL(pv.vendor_type_lookup_code,'X')              = NVL(NVL(g_vendor_type, pv.vendor_type_lookup_code),'X')
  AND ( (ac.future_pay_due_date is null and ac.check_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) or
           (ac.future_pay_due_date is not null and ac.future_pay_due_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) )
         AND (g_solo_comp = 'N' or ac.status_lookup_code in  ('CLEARED','RECONCILED','CLEARED BUT UNACCOUNTED'))
  AND (aia.org_id  = nvl(g_UNI_ID01,aia.org_id )
            OR
            aia.org_id IN ( g_UNI_ID02,g_UNI_ID03,g_UNI_ID04,g_UNI_ID05,g_UNI_ID06,g_UNI_ID07,g_UNI_ID08,g_UNI_ID09,g_UNI_ID10
                          , g_UNI_ID11,g_UNI_ID12,g_UNI_ID13,g_UNI_ID14,g_UNI_ID15,g_UNI_ID16))
    and not exists (select 1 from bolinf.XX_AR_AP_EOAF_INTERCO  xaei where xaei.vendor_id = aia.vendor_id)
   and (g_bancos_misce =  'Y'  or (select count(1)
                                                         from  CE_BANK_ACCOUNTS aba
                                                                  ,ce_bank_acct_uses_all          buc
                                                                , hz_parties hp
                                                                , hz_parties_dfv hp_dfv
                                                        where  ac.ce_bank_acct_use_id                           = buc.bank_acct_use_id
                                                           AND buc.bank_account_id                                   = aba.bank_account_id
                                                            and hp.party_id                                             = aba.bank_id
                                                            and hp_dfv.row_id                                           = hp.rowid
                                                            and  nvl(xx_ar_bco_miscelaneo,'N') = 'Y') = 0)
     and get_combination_code( 'N'  , null , null
                                         ,pd.dist_code_combination_id
                                         ,pd.po_distribution_id) = gcc.code_combination_id
GROUP BY    aia.invoice_id
                 , ac.check_id
                 , ail.line_number
                  ,gcc.code_combination_id
                  , pd.invoice_distribution_id;

debug(' Lineas populadas por AWT  ' || sql%rowcount , null);
END IF;
if nvl(l_tipo_mov,'ALL') IN ('TAX NO FF','ALL')  THEN
/*Lineas TAX
             - Se busca la linea item que tienen asociada y se prorratea en base a esas lineas
             - No Fondo Fijo */
insert into xx_AP_EOAF_MOV_GT( SECCION, ORDEN, org_id, vendor_id, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                 CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                  AMOUNT, DIST_DESC, FUTURE_PAY_DUE_DATE,
                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                   ,CODE_COMBINATION_ID        , po_header_id, po_line_id,item_description, LINE_NUMBER
                                                    , invoice_distribution_id)
SELECT 'TAX NO FF'                                             seccion
     , 2                                                       orden
          , max(aia.org_id)
                    ,max(aia.vendor_id)
     , max(aia.invoice_type_lookup_code)
     , aia.invoice_id
     , ac.check_id
     , max(haou.name)
     , max(pv.vendor_name)
     , max(pv.segment1)
     , max(pv.vendor_type_lookup_code)                              tipo_prov
     , max(cbb.bank_name)
     , max(cbb.bank_branch_name)
     , max(ac.bank_account_name)
     , max(ac.doc_sequence_value)
     , max(ac.status_lookup_code)
     , max(ac.check_date)
     , max(ac.payment_method_lookup_code)                           pay_method_desc
     , max(ac.currency_code)
     , max(NVL(ac.exchange_rate,1))                                 exchange_rate_pago
     , max(NVL(ac.base_amount,ac.amount))                           base_amount
     , max(ac.amount)                                               base_amount_ori
     , max(aia.invoice_num)
     , max(aia.invoice_date)
     , max(aia.invoice_currency_code)
     , max(nvl(aia.exchange_rate,1))                                exchange_rate
     , round(SUM( NVL(pd.base_amount,pd.amount) )
                     * decode(NVL(aip.payment_base_amount,aip.amount)  ,0,1 ,NVL(aip.payment_base_amount,aip.amount)  ) --Monto alocado a cada l?a de art?lo
                     / decode(NVL(aia.base_amount,aia.invoice_amount) ,0,1 ,NVL(aia.base_amount,aia.invoice_amount))
            ,2) amount
     ,  max(aia.description)                                        dist_desc
     ,  max(NVL(ac.future_pay_due_date,ac.check_date))              future_pay_due_date
     ,  max(NVL(xx_ap_libro_iva_distribucion,'N'))                  datos_cabecera
     ,  max(pv1.vendor_name)                                        ff_vendor_name
     ,  max(pv1.segment1)                                           ff_segment1
     ,  max(xx_ap_invoice_num)                                      ff_invoice_num
     ,  max(xx_ap_invoice_date)                                     ff_invoice_date
     ,  gcc.code_combination_id
     ,  max(nvl(aia.po_header_id, ail.po_header_id))
     ,  max(ail.po_line_id)
     ,  max(ail.item_description)
     , ail.line_number
      , pd.invoice_distribution_id
  FROM ap_invoice_distributions_all   pd
            ,ap_invoice_lines_all           ail --R12
            ,ap_invoices_all                 aia
            ,ap_suppliers                   pv
           ,hr_operating_units      haou
           ,ap_invoice_payments_all            aip
           ,ap_checks_all                      ac
           ,ce_bank_accounts               cba
           ,ce_bank_acct_uses_all          cbu
           ,ce_bank_branches_v             cbb
           ,ap_invoices_all_dfv            aia_dfv
           ,ap_invoice_distributions_a_dfv pd_dfv
           ,ap_suppliers                   pv1
           , gl_code_combinations gcc
 WHERE NVL(xx_ap_libro_iva_distribucion,'N')            = 'N'
   AND NVL(pd_dfv.xx_ap_vendor_id,'-1')                 = pv1.vendor_id (+)
   AND pd.rowid                                         = pd_dfv.row_id
   AND aia.rowid                                       = aia_dfv.row_id
   AND ail.line_type_lookup_code                        = 'TAX' --R12
   AND substr(haou.name,1,2)                            = g_country
   AND haou.organization_id                             = aia.org_id
   AND ac.ce_bank_acct_use_id                           = cbu.bank_acct_use_id
   AND cbu.bank_account_id                              = cba.bank_account_id
   AND cba.bank_branch_id                               = cbb.branch_party_id
   AND (NVL(g_solo_comp,'Y') = 'N'
        OR
        NVL(g_solo_comp,'Y')                            = DECODE(ac.status_lookup_code
                                                                ,'CLEARED','Y'
                                                                ,'RECONCILED','Y'
                                                                ,'CLEARED BUT UNACCOUNTED','Y'
                                                                ,'N'))                                            --Pagos compensados
      AND   AP_INVOICES_PKG.GET_APPROVAL_STATUS( AIa.INVOICE_ID,
                                                                               AIa.INVOICE_AMOUNT, AIa.PAYMENT_STATUS_FLAG,
                                                                                AIa.INVOICE_TYPE_LOOKUP_CODE)  != 'CANCELLED' --APPROVAL_STATUS_LOOKUP_CODE  --Facturas no canceladas
   AND aip.check_id                                     = ac.check_id
   AND aia.invoice_id                                   = aip.invoice_id
   AND pv.vendor_id                                     = aia.vendor_id
   AND aia.invoice_id                                   = ail.invoice_id --R12
   AND ail.line_number                                  = pd.invoice_line_number --R12
   AND ail.invoice_id                                   = pd.invoice_id --R12
   AND NVL(pd.base_amount,pd.amount)                   <> 0 --R12
   AND NVL(ac.doc_sequence_value,'-1')                  = NVL(NVL(g_op,ac.doc_sequence_value),'-1')
   AND NVL(pv.vendor_type_lookup_code,'X')              = NVL(NVL(g_vendor_type, pv.vendor_type_lookup_code),'X')
   AND ( (ac.future_pay_due_date is null and ac.check_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) or
           (ac.future_pay_due_date is not null and ac.future_pay_due_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) )
         AND (g_solo_comp = 'N' or ac.status_lookup_code in  ('CLEARED','RECONCILED','CLEARED BUT UNACCOUNTED'))
   AND (aia.org_id  = nvl(g_UNI_ID01,aia.org_id )
            OR
            aia.org_id IN ( g_UNI_ID02,g_UNI_ID03,g_UNI_ID04,g_UNI_ID05,g_UNI_ID06,g_UNI_ID07,g_UNI_ID08,g_UNI_ID09,g_UNI_ID10
                          , g_UNI_ID11,g_UNI_ID12,g_UNI_ID13,g_UNI_ID14,g_UNI_ID15,g_UNI_ID16))
    and not exists (select 1 from bolinf.XX_AR_AP_EOAF_INTERCO  xaei where xaei.vendor_id = aia.vendor_id)
   and (g_bancos_misce =  'Y'  or (select count(1)
                                                         from  CE_BANK_ACCOUNTS aba
                                                                  ,ce_bank_acct_uses_all          buc
                                                                , hz_parties hp
                                                                , hz_parties_dfv hp_dfv
                                                        where  ac.ce_bank_acct_use_id                           = buc.bank_acct_use_id
                                                           AND buc.bank_account_id                              = aba.bank_account_id
                                                            and hp.party_id                                         = aba.bank_id
                                                            and hp_dfv.row_id = hp.rowid
                                                            and  nvl(xx_ar_bco_miscelaneo,'N') = 'Y') = 0)
 and get_combination_code(g_prorateo_imp
                                          ,pd.invoice_distribution_id
                                           ,nvl(pd.charge_applicable_to_dist_id,pd.invoice_distribution_id)
                                           ,pd.dist_code_combination_id
                                           ,pd.po_distribution_id) = gcc.code_combination_id
GROUP BY       aia.invoice_id
                     , ac.check_id
                     , ail.line_number
                     ,gcc.code_combination_id
                     ,NVL(aip.payment_base_amount,aip.amount)
                     ,NVL(aia.base_amount,aia.invoice_amount)
                   , pd.invoice_distribution_id;
debug(' Lineas populadas por  tax no ff ' || sql%rowcount , null);
END IF;

if nvl(l_tipo_mov,'ALL') IN ('TAX FF','ALL')  THEN
/*Lineas TAX
             - Se busca la linea item que tienen asociada y se prorratea en base a esas lineas
             - Fondo Fijo */
insert into xx_AP_EOAF_MOV_GT( SECCION, ORDEN, org_id, vendor_id, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                 CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                  AMOUNT, DIST_DESC, FUTURE_PAY_DUE_DATE,
                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                   ,CODE_COMBINATION_ID        , po_header_id, po_line_id, item_description, LINE_NUMBER
                                                    , invoice_distribution_id)
SELECT 'TAX FF'                                                seccion
     , 2                                                       orden
     , max(aia.org_id)
     , max(aia.vendor_id)
     , max(aia.invoice_type_lookup_code)
     , aia.invoice_id
     , ac.check_id
     , max(haou.name)
     , max(pv.vendor_name)
     , max(pv.segment1)
     , max(pv.vendor_type_lookup_code)                              tipo_prov
     , max(cbb.bank_name)
     , max(cbb.bank_branch_name)
     , max(ac.bank_account_name)
     , max(ac.doc_sequence_value)
     , max(ac.status_lookup_code)
     , max(ac.check_date)
     , max(ac.payment_method_lookup_code)                           pay_method_desc
     , max(ac.currency_code)
     , max(NVL(ac.exchange_rate,1))                                 exchange_rate_pago
     , max(NVL(ac.base_amount,ac.amount))                           base_amount
     , max(ac.amount)                                               base_amount_ori
     , max(aia.invoice_num)
     , max(aia.invoice_date)
     , max(aia.invoice_currency_code)
     , max(nvl(aia.exchange_rate,1))                                exchange_rate
     , round(SUM(NVL(pd.base_amount,pd.amount))
                 * decode(NVL(aip.payment_base_amount,aip.amount)  ,0,1 ,NVL(aip.payment_base_amount,aip.amount)  ) --Monto alocado a cada línea de artículo
                 / decode(NVL(aia.base_amount,aia.invoice_amount) ,0,1 ,NVL(aia.base_amount,aia.invoice_amount) )
            ,2) amount
     , max(aia.description)                                        dist_desc
     , max(NVL(ac.future_pay_due_date,ac.check_date))              future_pay_due_date
     , max(NVL(xx_ap_libro_iva_distribucion,'N'))                  datos_cabecera
     , max(pv1.vendor_name)                                        ff_vendor_name
     , max(pv1.segment1)                                           ff_segment1
     , max(xx_ap_invoice_num)                                      ff_invoice_num
     , max(xx_ap_invoice_date)                                     ff_invoice_date
     , gcc.code_combination_id
     , max(nvl(aia.po_header_id, ail.po_header_id))
     , max(ail.po_line_id)
     , max(ail.item_description)
     , ail.line_number
      , pd.invoice_distribution_id
  FROM ap_invoice_distributions_all   pd
      ,ap_invoice_lines_all           ail --R12
      ,ap_invoices_all                  aia
      ,ap_suppliers                   pv
      ,hr_operating_units      haou
      ,ap_invoice_payments_all            aip
      ,ap_checks_all                      ac
      ,ce_bank_accounts               cba
      ,ce_bank_acct_uses_all          cbu
      ,ce_bank_branches_v             cbb
      ,ap_invoices_all_dfv            aia_dfv
      ,ap_invoice_distributions_a_dfv pd_dfv
      ,ap_suppliers                   pv1
      ,ap_invoice_distributions_all   pd1
      , gl_code_combinations gcc
 WHERE
  (
        (pd_dfv.xx_old_nro_linea_item IS NOT NULL
          AND pd_dfv.xx_old_nro_linea_item NOT LIKE 'ALQ%'
          AND pd_dfv.xx_old_nro_linea_item                     = NVL(pd1.old_dist_line_number, pd1.distribution_line_number))
    or
        (( pd_dfv.xx_old_nro_linea_item IS  NULL
                OR pd_dfv.xx_old_nro_linea_item  LIKE 'ALQ%' )
            and  pd.detail_tax_dist_id = pd1.invoice_distribution_id
         )
   )
   AND pd.invoice_id                                    = pd1.invoice_id
   AND NVL(xx_ap_libro_iva_distribucion,'N')            = 'Y'
   AND NVL(pd_dfv.xx_ap_vendor_id,'-1')                 = pv1.vendor_id (+)
   AND pd.rowid                                         = pd_dfv.row_id
   AND aia.rowid                                       = aia_dfv.row_id
   AND ail.line_type_lookup_code                        = 'TAX' --R12
   AND substr(haou.name,1,2)                            = g_country
   AND haou.organization_id                             = aia.org_id
   AND ac.ce_bank_acct_use_id                           = cbu.bank_acct_use_id
   AND cbu.bank_account_id                              = cba.bank_account_id
   AND cba.bank_branch_id                               = cbb.branch_party_id
   AND (NVL(g_solo_comp,'Y') = 'N'
        OR
        NVL(g_solo_comp,'Y')                            = DECODE(ac.status_lookup_code
                                                                ,'CLEARED','Y'
                                                                ,'RECONCILED','Y'
                                                                ,'CLEARED BUT UNACCOUNTED','Y'
                                                                ,'N'))                                            --Pagos compensados
   AND   AP_INVOICES_PKG.GET_APPROVAL_STATUS( AIa.INVOICE_ID,
                                                                               AIa.INVOICE_AMOUNT, AIa.PAYMENT_STATUS_FLAG,
                                                                                AIa.INVOICE_TYPE_LOOKUP_CODE)  != 'CANCELLED' --APPROVAL_STATUS_LOOKUP_CODE  --Facturas no canceladas
   AND aip.check_id                                     = ac.check_id
   AND aia.invoice_id                                   = aip.invoice_id
   AND pv.vendor_id                                     = aia.vendor_id
   AND aia.invoice_id                                   = ail.invoice_id --R12
   AND ail.line_number                                  = pd.invoice_line_number --R12
   AND ail.invoice_id                                   = pd.invoice_id --R12
   --Add ST 20180918
   AND NVL(pd.base_amount,pd.amount)                   <> 0 --R12
   AND NVL(ac.doc_sequence_value,'-1')                  = NVL(NVL(g_op,ac.doc_sequence_value),'-1')
   AND NVL(pv.vendor_type_lookup_code,'X')              = NVL(NVL(g_vendor_type, pv.vendor_type_lookup_code),'X')
    AND ( (ac.future_pay_due_date is null and ac.check_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) or
           (ac.future_pay_due_date is not null and ac.future_pay_due_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) )
         AND (g_solo_comp = 'N' or ac.status_lookup_code in  ('CLEARED','RECONCILED','CLEARED BUT UNACCOUNTED'))
    AND (aia.org_id  = nvl(g_UNI_ID01,aia.org_id )
            OR
            aia.org_id IN ( g_UNI_ID02,g_UNI_ID03,g_UNI_ID04,g_UNI_ID05,g_UNI_ID06,g_UNI_ID07,g_UNI_ID08,g_UNI_ID09,g_UNI_ID10
                          , g_UNI_ID11,g_UNI_ID12,g_UNI_ID13,g_UNI_ID14,g_UNI_ID15,g_UNI_ID16))
    and not exists (select 1 from bolinf.XX_AR_AP_EOAF_INTERCO  xaei where xaei.vendor_id = aia.vendor_id)
   and (g_bancos_misce =  'Y'  or (select count(1)
                                                         from  CE_BANK_ACCOUNTS aba
                                                                  ,ce_bank_acct_uses_all          buc
                                                                , hz_parties hp
                                                                , hz_parties_dfv hp_dfv
                                                        where  ac.ce_bank_acct_use_id                           = buc.bank_acct_use_id
                                                           AND buc.bank_account_id                              = aba.bank_account_id
                                                            and hp.party_id                                         = aba.bank_id
                                                            and hp_dfv.row_id = hp.rowid
                                                            and  nvl(xx_ar_bco_miscelaneo,'N') = 'Y') = 0)
and get_combination_code(g_prorateo_imp
                                       ,pd.invoice_distribution_id
                                       ,nvl(pd1.invoice_distribution_id,pd.invoice_distribution_id)
                                       ,pd.dist_code_combination_id
                                       ,pd.po_distribution_id)  = gcc.code_combination_id
GROUP BY       aia.invoice_id
     , ac.check_id
     , ail.line_number
               ,gcc.code_combination_id
          ,NVL(aip.payment_base_amount,aip.amount)
          ,NVL(aia.base_amount,aia.invoice_amount)
           , pd.invoice_distribution_id;
debug(' Lineas populadas portax ff ' || sql%rowcount , null);
END IF;
if nvl(l_tipo_mov,'ALL') IN ('RESTO','ALL')  THEN
/*Resto de las l?as
                      - Se proratea su monto total contra el monto pagado de la factura
                      - No se toman en cuenta las l?as de Anticipo */
-- y anticipos sin aplicar
insert into xx_AP_EOAF_MOV_GT( SECCION, ORDEN, org_id, vendor_id, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                 CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                  AMOUNT, DIST_DESC, FUTURE_PAY_DUE_DATE,
                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                   ,CODE_COMBINATION_ID        , po_header_id, po_line_id, inventory_item_id, item_description, LINE_NUMBER,
                                                    QUANTITY_INVOICED,contrato_id, liquidacion_id,
                                                   invoice_distribution_id)
SELECT 'RESTO'                                                 seccion
     , 1                                                       orden
     , max(aia.org_id)
     , max(aia.vendor_id)
     , max(aia.invoice_type_lookup_code)
     , aia.invoice_id
     , ac.check_id
     , max(haou.name)
     , max(pv.vendor_name)
     , max(pv.segment1)
     , max(pv.vendor_type_lookup_code)                              tipo_prov
     , max(cbb.bank_name)
     , max(cbb.bank_branch_name)
     , max(ac.bank_account_name)
     , max(ac.doc_sequence_value)
     , max(ac.status_lookup_code)
     , max(ac.check_date)
     , max(ac.payment_method_lookup_code)                           pay_method_desc
     , max(ac.currency_code)
     , max(NVL(ac.exchange_rate,1))                                 exchange_rate_pago
     , max(NVL(ac.base_amount,ac.amount))                           base_amount
     , max(ac.amount)                                               base_amount_ori
     , max(aia.invoice_num)
     , max(aia.invoice_date)
     , max(aia.invoice_currency_code)
     , max(nvl(aia.exchange_rate,1))                                exchange_rate
     , round(SUM(NVL(pd.base_amount,pd.amount))*
                 decode(NVL(aip.payment_base_amount,aip.amount) ,0,1 ,NVL(aip.payment_base_amount,aip.amount))
                 / decode(NVL(aia.base_amount,aia.invoice_amount),0,1 ,NVL(aia.base_amount,aia.invoice_amount))
              ,2) amount
     , max(aia.description)                                         dist_desc
     , max(NVL(ac.future_pay_due_date,ac.check_date))               future_pay_due_date
     , max(NVL(xx_ap_libro_iva_distribucion,'N'))                   datos_cabecera
     , max(pv1.vendor_name)                                         ff_vendor_name
     , max(pv1.segment1)                                            ff_segment1
     , max(xx_ap_invoice_num)                                       ff_invoice_num
     , max(xx_ap_invoice_date)                                      ff_invoice_date
    , gcc.code_combination_id
     , max(nvl(aia.po_header_id, ail.po_header_id))
     , max(ail.po_line_id)
     , max(ail.inventory_item_id)
     , max(ail.item_description)
     , ail.line_number
     , max (ail.QUANTITY_INVOICED)
     , MAX(decode(aia.source,'ACOPIO',aia_dfv.xx_acopio_contrato_de_compra, NULL))
     , MAX(decode(aia.source,'ACOPIO',aia_dfv.xx_tcg_doc_id_origen, NULL))
     , pd.invoice_distribution_id
   FROM ap_invoice_distributions_all   pd
      ,ap_invoice_lines_all           ail --R12
      ,ap_invoices_all                  aia
      ,ap_suppliers                   pv
      ,hr_operating_units                haou
      ,ap_invoice_payments_all            aip
      ,ap_checks_all                      ac
      ,ce_bank_accounts               cba
      ,ce_bank_acct_uses_all          cbu
      ,ce_bank_branches_v             cbb
      ,ap_invoices_all_dfv            aia_dfv
      ,ap_invoice_distributions_a_dfv pd_dfv
      ,ap_suppliers                   pv1
      , gl_code_combinations gcc
 WHERE NVL(pd_dfv.xx_ap_vendor_id,-1)                   = pv1.vendor_id (+)
   AND pd.rowid                                         = pd_dfv.row_id
   AND aia.rowid                                       = aia_dfv.row_id
   AND ail.line_type_lookup_code                   NOT IN ('AWT','TAX','PREPAY') --R12
AND ( AIA.INVOICE_TYPE_LOOKUP_CODE <> 'PREPAYMENT'
        OR NOT EXISTS (SELECT 1 FROM  (SELECT   AIL.INVOICE_ID INVOICE_ID,
                                                           AIL.LINE_NUMBER INVOICE_LINE_NUMBER,
                                                           AIL.PREPAY_INVOICE_ID PREPAY_INVOICE_ID,
                                                          AIL.PREPAY_LINE_NUMBER PREPAY_LINE_NUMBER
                                                 FROM AP_INVOICES_ALL AI,
                                                          AP_INVOICE_LINES_ALL AIL
                                                WHERE     AI.INVOICE_ID = AIL.INVOICE_ID
                                                      AND AIL.AMOUNT < 0
                                                      AND NVL (AIL.DISCARDED_FLAG, 'N') <> 'Y'
                                                      AND AIL.LINE_TYPE_LOOKUP_CODE = 'PREPAY'
                                                      AND AI.INVOICE_TYPE_LOOKUP_CODE NOT IN    ('PREPAYMENT', 'CREDIT', 'DEBIT')
                                               ) T_PREPA
                                                    where  T_PREPA.prepay_invoice_id = aia.invoice_id and T_PREPA.PREPAY_LINE_NUMBER = ail.line_number)    -- anticipos sin aplicar
          )
   AND substr(haou.name,1,2)                            = g_country
   AND haou.organization_id                             = aia.org_id
   AND ac.ce_bank_acct_use_id                           = cbu.bank_acct_use_id
   AND cbu.bank_account_id                              = cba.bank_account_id
   AND cba.bank_branch_id                               = cbb.branch_party_id
   AND (NVL(g_solo_comp,'Y') = 'N'
        OR
        NVL(g_solo_comp,'Y')                            = DECODE(ac.status_lookup_code
                                                                ,'CLEARED','Y'
                                                                ,'RECONCILED','Y'
                                                                ,'CLEARED BUT UNACCOUNTED','Y'
                                                                ,'N'))                                            --Pagos compensados
   AND   AP_INVOICES_PKG.GET_APPROVAL_STATUS( AIa.INVOICE_ID,
                                                                               AIa.INVOICE_AMOUNT, AIa.PAYMENT_STATUS_FLAG,
                                                                               AIa.INVOICE_TYPE_LOOKUP_CODE)  != 'CANCELLED' --APPROVAL_STATUS_LOOKUP_CODE  --Facturas no canceladas
   AND aip.check_id                                     = ac.check_id
   AND aia.invoice_id                                   = aip.invoice_id
   AND pv.vendor_id                                     = aia.vendor_id
   AND aia.invoice_id                                   = ail.invoice_id
   AND ail.line_number                                  = pd.invoice_line_number
   AND ail.invoice_id                                   = pd.invoice_id
   AND pd.org_id                                       = aia.org_id ---> #
   AND NVL(pd.base_amount,pd.amount)                   <> 0 --R12
   AND NVL(ac.doc_sequence_value,'-1')                   = NVL(NVL(g_op,ac.doc_sequence_value),'-1')
   AND NVL(pv.vendor_type_lookup_code,'X')             = NVL(NVL(g_vendor_type, pv.vendor_type_lookup_code),'X')
     AND ( (ac.future_pay_due_date is null and ac.check_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) or
           (ac.future_pay_due_date is not null and ac.future_pay_due_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) )
         AND (g_solo_comp = 'N' or ac.status_lookup_code in  ('CLEARED','RECONCILED','CLEARED BUT UNACCOUNTED'))
   AND (aia.org_id  = nvl(g_UNI_ID01,aia.org_id )
            OR
            aia.org_id IN ( g_UNI_ID02,g_UNI_ID03,g_UNI_ID04,g_UNI_ID05,g_UNI_ID06,g_UNI_ID07,g_UNI_ID08,g_UNI_ID09,g_UNI_ID10
                          , g_UNI_ID11,g_UNI_ID12,g_UNI_ID13,g_UNI_ID14,g_UNI_ID15,g_UNI_ID16))
   and not exists (select 1 from bolinf.XX_AR_AP_EOAF_INTERCO  xaei where xaei.vendor_id = aia.vendor_id)
   and (g_bancos_misce =  'Y'  or (select count(1)
                                                         from  CE_BANK_ACCOUNTS aba
                                                                  ,ce_bank_acct_uses_all          buc
                                                                , hz_parties hp
                                                                , hz_parties_dfv hp_dfv
                                                        where  ac.ce_bank_acct_use_id                           = buc.bank_acct_use_id
                                                           AND buc.bank_account_id                                = aba.bank_account_id
                                                            and hp.party_id                                             = aba.bank_id
                                                            and hp_dfv.row_id                                       = hp.rowid
                                                            and  nvl(xx_ar_bco_miscelaneo,'N') = 'Y') = 0)
        and get_combination_code( 'N', null,null
                                       ,pd.dist_code_combination_id
                                       ,pd.po_distribution_id)         = gcc.code_combination_id
GROUP BY       aia.invoice_id
     , ac.check_id
     , ail.line_number
          ,gcc.code_combination_id
          ,NVL(aip.payment_base_amount,aip.amount)
          ,NVL(aia.base_amount,aia.invoice_amount)
           , pd.invoice_distribution_id;
debug(' Lineas populadas por  resto sin anti ' || sql%rowcount , null);
END IF;
-- solo anticipos aplicados
IF  nvl(l_tipo_mov,'ALL') IN ('RESTO AA','ALL')  THEN
                for c_anti in (SELECT   aia.org_id
                                     , aia.vendor_id
                                     , aia.invoice_type_lookup_code
                                     , aia.invoice_id
                                     , ac.check_id
                                     , haou.name
                                     , pv.vendor_name
                                     , pv.segment1
                                     , pv.vendor_type_lookup_code        tipo_prov
                                     , ac.bank_account_name
                                     , ac.doc_sequence_value
                                     , ac.status_lookup_code
                                     , ac.check_date
                                     , ac.payment_method_lookup_code                           pay_method_desc
                                     , ac.currency_code
                                     , NVL(ac.exchange_rate,1)                                 exchange_rate_pago
                                     , NVL(ac.base_amount,ac.amount)                           base_amount
                                     , ac.amount                                               base_amount_ori
                                     , aia.invoice_num
                                     , aia.invoice_date
                                     , aia.invoice_currency_code
                                     , nvl(aia.exchange_rate,1)                                exchange_rate
                                     , aia.description                                         dist_desc
                                     , NVL(ac.future_pay_due_date,ac.check_date)               future_pay_due_date
                                     , NVL(xx_ap_libro_iva_distribucion,'N')                  datos_cabecera
                                     , pv1.vendor_name                                         ff_vendor_name
                                     , pv1.segment1                                            ff_segment1
                                     , xx_ap_invoice_num                                       ff_invoice_num
                                     , xx_ap_invoice_date                                      ff_invoice_date
                                     , nvl(aia.po_header_id, ail.po_header_id) po_header_id
                                     , ail.po_line_id
                                     , ail.inventory_item_id
                                     , ail.item_description
                                     , ail.line_number
                                     , ail.QUANTITY_INVOICED
                                     -- campos para calcular
                                       ,ac.ce_bank_acct_use_id
                                      , aip.payment_base_amount payment_base_amount_calc
                                      , aip.amount amount_calc
                                     , aia.base_amount base_amount_calc
                                     ,aia.invoice_amount invoice_amount_calc
                                     , round((NVL(pd.base_amount,pd.amount))
                                                 * decode(NVL(aip.payment_base_amount,aip.amount) ,0,1 ,NVL(aip.payment_base_amount,aip.amount))
                                                 / decode(NVL(aia.base_amount,aia.invoice_amount) ,0,1  ,NVL(aia.base_amount,aia.invoice_amount))
                                                ,2) amount
                                      FROM ap_invoice_distributions_all   pd
                                          ,ap_invoice_lines_all           ail
                                          ,ap_invoices_all                 aia
                                          ,ap_suppliers                   pv
                                          ,hr_operating_units      haou
                                          ,ap_invoice_payments_all            aip
                                          ,ap_checks_all                      ac
                                          ,ap_invoices_all_dfv            aia_dfv
                                          ,ap_invoice_distributions_a_dfv pd_dfv
                                           ,ap_suppliers                   pv1
                                     WHERE NVL(pd_dfv.xx_ap_vendor_id,'-1')                 = pv1.vendor_id (+)
                                     AND  pd.rowid                                         = pd_dfv.row_id
                                       AND aia.rowid                                       = aia_dfv.row_id
                                       AND ail.line_type_lookup_code                   NOT IN ('AWT','TAX','PREPAY')
                                       AND aia.invoice_id                                   = ail.invoice_id
                                        and AIA.INVOICE_TYPE_LOOKUP_CODE   = 'PREPAYMENT'
                                        and  pd.invoice_id = aia.invoice_id
                                         and pd.invoice_line_number = ail.line_number
                                         and pd.PREPAY_AMOUNT_REMAINING is not null
                                          and pd.PREPAY_AMOUNT_REMAINING <> pd.amount -- anticipos aplicado
                                        AND substr(haou.name,1,2)                            = g_country
                                       AND haou.organization_id                             = aia.org_id
                                       AND (NVL(g_solo_comp,'Y') = 'N'
                                            OR
                                            NVL(g_solo_comp,'Y')                            = DECODE(ac.status_lookup_code
                                                                                                    ,'CLEARED','Y'
                                                                                                    ,'RECONCILED','Y'
                                                                                                    ,'CLEARED BUT UNACCOUNTED','Y'
                                                                                                    ,'N'))                                            --Pagos compensados
                                       AND   AP_INVOICES_PKG.GET_APPROVAL_STATUS( AIa.INVOICE_ID,
                                                                                                                   AIa.INVOICE_AMOUNT, AIa.PAYMENT_STATUS_FLAG,
                                                                                                                    AIa.INVOICE_TYPE_LOOKUP_CODE)  != 'CANCELLED' --APPROVAL_STATUS_LOOKUP_CODE  --Facturas no canceladas
                                       AND aip.check_id                                     = ac.check_id
                                       AND aia.invoice_id                                   = aip.invoice_id
                                       AND pv.vendor_id                                     = aia.vendor_id
                                       AND NVL(ac.doc_sequence_value,'-1')                   = NVL(NVL(g_op,ac.doc_sequence_value),'-1')
                                       AND NVL(pv.vendor_type_lookup_code,'X')             = NVL(NVL(g_vendor_type, pv.vendor_type_lookup_code),'X')
                                           AND ( (ac.future_pay_due_date is null and ac.check_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) or
                                               (ac.future_pay_due_date is not null and ac.future_pay_due_date BETWEEN g_fecha_desde                         AND g_fecha_hasta) )
                                             AND (g_solo_comp = 'N' or ac.status_lookup_code in  ('CLEARED','RECONCILED','CLEARED BUT UNACCOUNTED'))
                                       AND (aia.org_id  = nvl(g_UNI_ID01,aia.org_id )
                                                OR
                                                aia.org_id IN ( g_UNI_ID02,g_UNI_ID03,g_UNI_ID04,g_UNI_ID05,g_UNI_ID06,g_UNI_ID07,g_UNI_ID08,g_UNI_ID09,g_UNI_ID10
                                                              , g_UNI_ID11,g_UNI_ID12,g_UNI_ID13,g_UNI_ID14,g_UNI_ID15,g_UNI_ID16))
                                       and not exists (select 1 from bolinf.XX_AR_AP_EOAF_INTERCO  xaei where xaei.vendor_id = aia.vendor_id)
                                       and (g_bancos_misce =  'Y'  or (select count(1)
                                                                             from  CE_BANK_ACCOUNTS aba
                                                                                      ,ce_bank_acct_uses_all          buc
                                                                                    , hz_parties hp
                                                                                    , hz_parties_dfv hp_dfv
                                                                            where  ac.ce_bank_acct_use_id                           = buc.bank_acct_use_id
                                                                               AND buc.bank_account_id                                = aba.bank_account_id
                                                                                and hp.party_id                                             = aba.bank_id
                                                                                and hp_dfv.row_id                                          = hp.rowid
                                                                                and  nvl(xx_ar_bco_miscelaneo,'N')                  = 'Y') = 0)
                                    ) loop

                -- calculo datos banco
                    begin
                               select  cbb.bank_name,cbb.bank_branch_name
                               into  l_bank_name  , l_bank_branch_name
                               from ce_bank_accounts               cba
                                  ,ce_bank_acct_uses_all          cbu
                                  ,ce_bank_branches_v             cbb
                               where c_anti.ce_bank_acct_use_id                           = cbu.bank_acct_use_id
                               AND cbu.bank_account_id                              = cba.bank_account_id
                             AND cba.bank_branch_id                               = cbb.branch_party_id;
                    exception when others then l_bank_name := null;
                                         l_bank_branch_name := null;
                    end ;

                     FOR c_gcc in (
                        -- BUSCA Distribucion de la factura que se aplicó el anticipo
                      select  gcc.code_combination_id
                               , pd.invoice_distribution_id
                       FROM gl_code_combinations gcc
                               ,  (SELECT   AIL.INVOICE_ID INVOICE_ID,
                                        --           AIL.LINE_NUMBER INVOICE_LINE_NUMBER,
                                                   AIL.PREPAY_INVOICE_ID PREPAY_INVOICE_ID,
                                                  AIL.PREPAY_LINE_NUMBER PREPAY_LINE_NUMBER
                                         FROM AP_INVOICES_ALL AI,
                                                  AP_INVOICE_LINES_ALL AIL
                                        WHERE     AI.INVOICE_ID = AIL.INVOICE_ID
                                              AND AIL.AMOUNT < 0
                                              AND NVL (AIL.DISCARDED_FLAG, 'N') <> 'Y'
                                              AND AIL.LINE_TYPE_LOOKUP_CODE = 'PREPAY'
                                              AND AI.INVOICE_TYPE_LOOKUP_CODE NOT IN    ('PREPAYMENT', 'CREDIT', 'DEBIT')
                                       ) avpp
                               ,   ap_invoice_distributions_all   pd
                       where    avpp.prepay_invoice_id                           = c_anti.invoice_id
                          and     avpp.PREPAY_LINE_NUMBER                   = c_anti.line_number
                   --       AND    avpp.invoice_line_number                   = pd.invoice_line_number  - no toma la línea porque esa es negativa y corresponde a la aplicación
                         AND avpp.invoice_id                                   = pd.invoice_id
                         and pd. line_type_lookup_code = 'ITEM'
                        AND NVL(pd.base_amount,pd.amount)                   <> 0
                           and XX_AR_AP_EOAFSLA_PKG.get_combination_code( 'N', null,null
                                                       ,pd.dist_code_combination_id
                                                       ,pd.po_distribution_id)         = gcc.code_combination_id
                        order by pd.INVOICE_LINE_NUMBER ) loop

                        IF c_gcc.CODE_COMBINATION_ID is not  NULL THEN
                                insert into xx_AP_EOAF_MOV_GT( SECCION, ORDEN, org_id, vendor_id, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                                CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                                  AMOUNT, DIST_DESC, FUTURE_PAY_DUE_DATE,
                                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                                   ,CODE_COMBINATION_ID        , po_header_id, po_line_id, inventory_item_id,item_description, LINE_NUMBER
                                                                   , QUANTITY_INVOICED
                                                                    , invoice_distribution_id)
                            values ('RESTO AA',1, c_anti.org_id ,
                                                            c_anti.vendor_id ,
                                                            c_anti.invoice_type_lookup_code ,
                                                            c_anti.invoice_id ,
                                                            c_anti.check_id ,
                                                            c_anti.name ,
                                                            c_anti.vendor_name ,
                                                            c_anti.segment1 ,
                                                            c_anti.tipo_prov,
                                                             l_bank_name  ,
                                                             l_bank_branch_name ,
                                                            c_anti.bank_account_name ,
                                                            c_anti.doc_sequence_value ,
                                                            c_anti.status_lookup_code ,
                                                            c_anti.check_date ,
                                                            c_anti.pay_method_desc,
                                                            c_anti.currency_code ,
                                                            c_anti.exchange_rate_pago,
                                                            c_anti.base_amount,
                                                            c_anti.base_amount_ori,
                                                            c_anti.invoice_num ,
                                                            c_anti.invoice_date ,
                                                            c_anti.invoice_currency_code ,
                                                            c_anti.exchange_rate,
                                                            c_anti.amount,
                                                            c_anti.dist_desc,
                                                            c_anti.future_pay_due_date,
                                                            c_anti.datos_cabecera,
                                                            c_anti.ff_vendor_name   ,
                                                            c_anti.ff_segment1,
                                                            c_anti.ff_invoice_num,
                                                            c_anti.ff_invoice_date,
                                                            c_gcc.code_combination_id,
                                                            c_anti.po_header_id,
                                                            c_anti.po_line_id ,
                                                            c_anti.inventory_item_id ,
                                                            c_anti.item_description ,
                                                            c_anti.line_number ,
                                                            c_anti.QUANTITY_INVOICED ,
                                                            c_gcc.invoice_distribution_id);
                                    exit;---> toma el primer item solamente
                     END IF;

                     end loop;

                end loop;

     debug(' Lineas populadas por resto anti aplicados ' || sql%rowcount , null);
 END IF;
-- actualiza datos de gcc
for c_upd in (select rowid row_id, seccion , CODE_COMBINATION_ID, invoice_distribution_id from xx_AP_EOAF_MOV_GT) loop

            l_excluye := 'N';

            select gcc_kfv.concatenated_segments
                     , gcc_kfv.segment2
                     , gcc_kfv.segment3
            into l_concatenated_segments, l_segment2, l_segment3
            from gl_code_combinations gcc
                    , gl_code_combinations_kfv       gcc_kfv
            where   gcc.code_combination_id = c_upd.code_combination_id
            and gcc.rowid = gcc_kfv.row_id;

        if c_upd.invoice_distribution_id  is not null then
           l_sla_gcc_id := null;
    --       if c_upd.seccion <> 'RESTO AA' THEN
              SELECT  max(ael.code_combination_id) into l_sla_gcc_id
                FROM  XLA_DISTRIBUTION_LINKS xdl
                          ,xla_ae_headers           aeh
                         , xla_ae_lines             ael
                  WHERE   xdl.source_distribution_type = 'AP_INV_DIST'
                       and source_distribution_id_num_1 =   c_upd.invoice_distribution_id
                       and xdl.application_id = 200
                        and aeh.AE_HEADER_ID = xdl.AE_HEADER_ID
                       and ael.AE_HEADER_ID = xdl.AE_HEADER_ID
                       and ael.ae_line_num = xdl.ae_line_num;
--             end if;
  /*           if l_sla_gcc_id is null then
                      SELECT  max(xal.code_combination_id) into l_sla_gcc_id
                        FROM      XLA_AE_HEADERS               xah
                                    , XLA_AE_LINES                 xal
                                    , ap_invoice_distributions_all AID
                         WHERE 1= 1
                             and aid.invoice_distribution_id = c_upd.invoice_distribution_id
                           AND xah.event_id = aid.ACCOUNTING_EVENT_ID
                           AND xah.ae_header_id    = xal.ae_header_id
                           AND xah.application_id  = xal.application_id
                           --and xal.accounting_class_code = 'PREPAID_EXPENSE'
                          AND  nvl (xal.entered_cr, 0)  =aid.amount*-1
                         and trim(nvl(xal.description,'X')) = trim(nvl(aid.description,'X'));
                         if l_sla_gcc_id is null then   -- si no encontró por crédito, busca por débito
                                  SELECT  max(xal.code_combination_id) into l_sla_gcc_id
                                    FROM      XLA_AE_HEADERS               xah
                                                , XLA_AE_LINES                 xal
                                                , ap_invoice_distributions_all AID
                                     WHERE 1= 1
                                         and aid.invoice_distribution_id = c_upd.invoice_distribution_id
                                       AND xah.event_id = aid.ACCOUNTING_EVENT_ID
                                       AND xah.ae_header_id    = xal.ae_header_id
                                       AND xah.application_id  = xal.application_id
                                       --and xal.accounting_class_code = 'PREPAID_EXPENSE'
                                      AND  nvl (xal.entered_dr, 0)  =aid.amount
                                     and trim(nvl(xal.description,'X')) = trim(nvl(aid.description,'X'));
                         end if;
                         /*
                          FROM xla.XLA_TRANSACTION_ENTITIES xte
                                    , XLA_AE_HEADERS               xah
                                    , XLA_AE_LINES                 xal
                                    , ap_invoice_distributions_all AID
                         WHERE 1= 1
                             and aid.invoice_distribution_id = c_upd.invoice_distribution_id
                           AND xte.entity_id       = xah.entity_id
                           AND xte.application_id  = xah.application_id
                           AND xah.accounting_date between  trunc(aid.accounting_date) and AID.accounting_date
                           AND xah.ae_header_id    = xal.ae_header_id
                           AND xah.application_id  = xal.application_id
                           and entity_code = 'AP_INVOICES'
                           and event_type_code = 'PREPAYMENT APPLIED'
                          and  nvl(xte.source_id_int_1,(-99))  = aid.invoice_id
                          AND  nvl (xal.entered_cr, 0)  =aid.amount*-1
                         and trim(nvl(xal.description,'X')) = trim(nvl(aid.description,'X'));*/
         --   end if;
            begin
                     select gcc_kfv.concatenated_segments
                             , gcc_kfv.segment2
                             , gcc_kfv.segment3
                    into l_sla_concatena_segments, l_sla_segment2, l_sla_segment3
                    from gl_code_combinations gcc
                            , gl_code_combinations_kfv       gcc_kfv
                    where   gcc.code_combination_id = l_sla_gcc_id
                    and gcc.rowid = gcc_kfv.row_id;
            exception when others then
                    l_sla_concatena_segments := null;
                    l_sla_segment2 := null;
                    l_sla_segment3 := null;
            end ;


        else
            l_sla_gcc_id := null;
                    l_sla_concatena_segments := null;
                    l_sla_segment2 := null;
                    l_sla_segment3 := null;
         end if;
            if   l_concatenated_segments                        BETWEEN NVL(g_cuenta_desde, l_concatenated_segments)
                                                                        AND NVL(g_cuenta_hasta, l_concatenated_segments) then

                if g_ctas_cruzadas = 'Y' then
                      l_excluye := 'N';
                else
                         SELECT  max(ffvdfv.XX_CUENTA_CRUZADA_CON_AR) into l_cuenta_cruzada_con_ar
                         FROM fnd_flex_values ffv,
                                  fnd_flex_values_dfv ffvdfv
                        WHERE ffv.ROWID = ffvdfv.ROWID
                            and ffv.flex_value = l_segment2
                             AND ffv.flex_value_set_id =  l_flex_set_gl_cuenta;

                        IF nvl(l_cuenta_cruzada_con_ar,'N') = 'Y' then
                              l_excluye := 'Y';
                        ELSE
                                l_excluye := 'N';
                        END IF;
                end if;
            else
                l_excluye := 'Y';
           end if;

        if   l_excluye = 'N' then
               update xx_AP_EOAF_MOV_GT set
                           (CONCATENATED_SEGMENTS, SEGMENT2, SEGMENT3) = (select l_concatenated_segments, l_segment2, l_segment3 from dual)
                           ,sla_gcc_id =  l_sla_gcc_id
                          ,  (SLA_CONCATENA_SEGMENTS, SLA_SEGMENT2, SLA_SEGMENT3) = (select l_sla_concatena_segments, l_sla_segment2, l_sla_segment3 from dual)
                where rowid = c_upd.row_id;
                l_lin_update := l_lin_update  + 1;

        else
                delete xx_AP_EOAF_MOV_GT where rowid = c_upd.row_id;
                l_lin_delete := l_lin_delete  + 1;
        end if;

end loop;
     debug(' Lineas eliminadas por no corresponder cuenta ' || l_lin_delete , null);
          debug(' Lineas actualizadas a listar ' || l_lin_update , null);

debug(' fin actualiza  ' , null);
exception when others then
        debug('ERRor ' || sqlerrm, null);

end inserta_temporal;


PROCEDURE main (errbuf           OUT VARCHAR2
               ,retcode          OUT NUMBER
               ,p_country in VARCHAR2
               ,p_fecha_desde     IN VARCHAR2
               ,p_fecha_hasta     IN VARCHAR2
               ,p_coda_id IN VARCHAR2  --> solo para  filtrar cuenta_desde es el chart_of_account
               ,p_cuenta_desde    IN VARCHAR2
               ,p_cuenta_hasta    IN VARCHAR2
               ,p_vendor_type     IN VARCHAR2
               ,p_solo_dist       IN VARCHAR2
               ,p_op              IN NUMBER
               ,p_prorateo_imp    IN VARCHAR2
               ,p_sep             IN VARCHAR2
               ,p_solo_comp       IN VARCHAR2
               ,p_intercompany in varchar2
               ,p_bancos_misce in varchar2
               , p_ctas_cruzadas in varchar2
               , P_UNI_ID01   in VARCHAR2
                ,P_UNI_ID02 in   VARCHAR2
                ,P_UNI_ID03 IN  VARCHAR2
                ,P_UNI_ID04 IN  VARCHAR2
                ,P_UNI_ID05 IN  VARCHAR2
                ,P_UNI_ID06 IN  VARCHAR2
                ,P_UNI_ID07 IN  VARCHAR2
                ,P_UNI_ID08 IN  VARCHAR2
                ,P_UNI_ID09 IN  VARCHAR2
                ,P_UNI_ID10 IN  VARCHAR2
                ,P_UNI_ID11 IN  VARCHAR2
                ,P_UNI_ID12 IN  VARCHAR2
                ,P_UNI_ID13 IN  VARCHAR2
                ,P_UNI_ID14 IN  VARCHAR2
                ,P_UNI_ID15 IN  VARCHAR2
                ,P_UNI_ID16 IN  VARCHAR2) is

l_amount_usd           NUMBER;
l_tasa_nueva           ap_checks_all.exchange_rate%TYPE;
l_mon_func             gl_ledgers.currency_code%TYPE;

p_mon_conv                       gl_ledgers.currency_code%TYPE; --Moneda a convertir fijo en USD
l_flex_value_id_cuenta           fnd_id_flex_segments_vl.flex_value_set_id%TYPE;
l_cuenta_desc                       fnd_id_flex_segments_vl.description%TYPE;
l_flex_value_id_uneg             fnd_id_flex_segments_vl.flex_value_set_id%TYPE;
l_uneg_desc                         fnd_id_flex_segments_vl.description%TYPE;
l_tipo_prov                           fnd_lookup_values.meaning%TYPE;
l_status_lookup_code             fnd_lookup_values.meaning%TYPE;
l_pay_method_desc              fnd_lookup_values.meaning%TYPE;
L_SEgment1                         po_headers_all.segment1%type;
l_comprador                         per_all_people_f.full_name%type;
l_xx_gl_unidad_negocios      varchar2(30);
l_item_description_oc            po_lines_all.item_description%type;
l_unit_meas_lookup_code       po_lines_all.unit_meas_lookup_code%type;
l_list_price_per_unit               po_lines_all.list_price_per_unit%type;
l_nro_item                             mtl_system_items_b.segment1%type;
l_descri_item                          mtl_system_items_b.description%type;
l_rubro                              varchar2(400);
l_familia                             varchar2(400);
l_sub_familia                      varchar2(400);
l_inventory_item_id             number;
l_contrato                          varchar2(30);

BEGIN

  e_retcode:= 0;
  DEBUG('Parametros');
    DEBUG('p_country: '||p_country);
  DEBUG('p_fecha_desde: '||p_fecha_desde);
  DEBUG('p_fecha_hasta: '||p_fecha_hasta);
  DEBUG('p_cuenta_desde: '||p_cuenta_desde);
  DEBUG('p_cuenta_hasta: '||p_cuenta_hasta);
  DEBUG('p_vendor_type: '||p_vendor_type);
  DEBUG('p_solo_dist: '||p_solo_dist);
  DEBUG('p_solo_comp: '||p_solo_comp);
  DEBUG('p_op: '||p_op);
  DEBUG('p_prorateo_imp: '||p_prorateo_imp);
  DEBUG('p_sep: '||p_sep);
  DEBUG('p_intercompany: '|| p_intercompany);
  DEBUG('p_bancos_misce: '|| p_bancos_misce);
  DEBUG('p_ctas_cruzadas: '|| p_ctas_cruzadas);

  DEBUG('P_UNI_ID01: '||P_UNI_ID01);
  DEBUG('P_UNI_ID02: '||P_UNI_ID02);
  DEBUG('P_UNI_ID03: '||P_UNI_ID03);
  DEBUG('P_UNI_ID04: '||P_UNI_ID04);
  DEBUG('P_UNI_ID05: '||P_UNI_ID05);
  DEBUG('P_UNI_ID06: '||P_UNI_ID06);
  DEBUG('P_UNI_ID07: '||P_UNI_ID07);
  DEBUG('P_UNI_ID08: '||P_UNI_ID08);
  DEBUG('P_UNI_ID09: '||P_UNI_ID09);
  DEBUG('P_UNI_ID10: '||P_UNI_ID10);
  DEBUG('P_UNI_ID11: '||P_UNI_ID11);
  DEBUG('P_UNI_ID12: '||P_UNI_ID12);
  DEBUG('P_UNI_ID13: '||P_UNI_ID13);
  DEBUG('P_UNI_ID14: '||P_UNI_ID14);
  DEBUG('P_UNI_ID15: '||P_UNI_ID15);
  DEBUG('P_UNI_ID16: '||P_UNI_ID16);

g_country    := P_country;
  g_fecha_desde:= to_date(p_fecha_desde,'RRRR/MM/DD HH24:MI:SS');
  g_fecha_hasta:= to_date(p_fecha_hasta,'RRRR/MM/DD HH24:MI:SS');
  DEBUG ('Fecha desde ' || to_char(g_fecha_desde,'DD-MM-YYYY'));
  DEBUG ('Fecha hasta ' || to_char(g_fecha_hasta,'DD-MM-YYYY'));
g_cuenta_desde    := P_cuenta_desde    ;
g_cuenta_hasta     := P_cuenta_hasta    ;
g_vendor_type      := P_vendor_type     ;
g_solo_dist           := P_solo_dist       ;
g_op                    := P_op              ;
g_prorateo_imp    := P_prorateo_imp    ;
g_separador         := nvl(P_sep, ';')             ;
g_solo_comp        := P_solo_comp       ;
g_intercompany     := nvl(p_intercompany,'Y');
g_bancos_misce    := nvl(p_bancos_misce,'Y');
g_ctas_cruzadas     := nvl(p_ctas_cruzadas,'Y');

G_UNI_ID01          := P_UNI_ID01;   --queda en nulo si ingresó nulo
G_UNI_ID02          := nvl(P_UNI_ID02,0);
G_UNI_ID03          := nvl(P_UNI_ID03,0);
G_UNI_ID04          := nvl(P_UNI_ID04,0);
G_UNI_ID05          := nvl(P_UNI_ID05,0);
G_UNI_ID06          := nvl(P_UNI_ID06,0);
G_UNI_ID07          := nvl(P_UNI_ID07,0);
G_UNI_ID08          := nvl(P_UNI_ID08,0);
G_UNI_ID09          := nvl(P_UNI_ID09,0);
G_UNI_ID10          := nvl(P_UNI_ID10,0);
G_UNI_ID11          := nvl(P_UNI_ID11,0);
G_UNI_ID12          := nvl(P_UNI_ID12,0);
G_UNI_ID13          := nvl(P_UNI_ID13,0);
G_UNI_ID14          := nvl(P_UNI_ID14,0);
G_UNI_ID15          := nvl(P_UNI_ID15,0);
G_UNI_ID16          := nvl(P_UNI_ID16,0);

execute immediate 'truncate table bolinf.xx_AP_EOAF_MOV_GT';

execute immediate 'truncate table bolinf.XX_AR_AP_EOAF_INTERCO';
if g_intercompany = 'N' then
            -- Calcula todas las organizaciones del pais
            insert into bolinf.XX_AR_AP_EOAF_INTERCO
             select ASU.VENDOR_ID, asu.VENDOR_NAME
                                 ,hp.attribute24 GL_SEGMENT1
                                 , (SELECT  fsp.org_id
                                       FROM  GL_LEDGER_SEGMENT_VALUES glsv
                                                , financials_system_params_all fsp
                                     WHERE glsv.SEGMENT_TYPE_CODE = 'B'
                                     and fsp.set_of_books_id = glsv.ledger_id
                                     and glsv.segment_value = hp.attribute24) org_id
                             from ap.ap_suppliers ASU
                                   , HZ_PARTIES hp
                             where vendor_type_lookup_code = 'INTERCOMPANY'
                               and nvl(hp.attribute_category,'AR') = NVL(P_COUNTRY,'AR')
                               and hp.attribute24 is not null
                               and asu.party_id = hp.party_id;
               -- borra las sin organizaciones
                delete  from bolinf.XX_AR_AP_EOAF_INTERCO where org_id is null;
                -- borra las que no pertenecen a las organizaciones ingresada (si se ingresó alguna organización, sino van todas)
            if G_UNI_ID01 is not null then
                             delete  from bolinf.XX_AR_AP_EOAF_INTERCO where org_id not in   (g_UNI_ID01, g_UNI_ID02,g_UNI_ID03,g_UNI_ID04,g_UNI_ID05,g_UNI_ID06,g_UNI_ID07,g_UNI_ID08,g_UNI_ID09,g_UNI_ID10
                                      , g_UNI_ID11,g_UNI_ID12,g_UNI_ID13,g_UNI_ID14,g_UNI_ID15,g_UNI_ID16);
            end if;
  end if;

debug(' genero interco  ' || g_intercompany ,null);


  SELECT flex_value_set_id
    INTO l_flex_value_id_cuenta
    FROM fnd_id_flex_segments_vl
   WHERE id_flex_num =50288
     AND id_flex_code  ='GL#'
     AND application_id=101
     AND segment_name = 'CUENTA';

    fnd_file.put_line(fnd_file.log,'l_flex_value_id_cuenta: '||l_flex_value_id_cuenta);

  SELECT flex_value_set_id
    INTO l_flex_value_id_uneg
    FROM fnd_id_flex_segments_vl
   WHERE id_flex_num =50288
     AND id_flex_code  ='GL#'
     AND application_id=101
     AND segment_name = 'U_NEGOCIOS';

    fnd_file.put_line(fnd_file.log,'l_flex_value_id_uneg: '||l_flex_value_id_uneg);

  fnd_file.put_line(fnd_file.output,'Compania'                    ||g_separador
                                  ||'Proveedor'                   ||g_separador
                                  ||'Nro. Proveedor'              ||g_separador
                                  ||'Tipo Proveedor'              ||g_separador
                                  ||'Banco'                           ||g_separador
                                  ||'Sucursal Bancaria'           ||g_separador
                                  ||'Cuenta Bancaria'             ||g_separador
                                  ||'Nro. OP'                        ||g_separador
                                  ||'Estado OP'                     ||g_separador
                                  ||'Fecha OP'                      ||g_separador
                                  ||'Vencimiento OP'              ||g_separador
                                  ||'Metodo Pago'                  ||g_separador
                                  ||'Tasa de Cambio'              ||g_separador
                                  ||'Monto Pago ARS'              ||g_separador
                                  ||'Monto Pago Orig'             ||g_separador
                                  ||'Nro. Factura'                  ||g_separador
                                  ||'Fecha Factura'               ||g_separador
                                  ||'Moneda Factura'              ||g_separador
                                  ||'TdC Factura'                 ||g_separador
                                  ||'Datos en Dist.'              ||g_separador
                                  ||'Proveedor en Dist.'          ||g_separador
                                  ||'Nro. Proveedor en Dist.'     ||g_separador
                                  ||'Nro. Factura en Dist.'       ||g_separador
                                  ||'Fecha Factura en Dist.'      ||g_separador
                                  ||'Monto Dist. '||l_mon_func    ||g_separador
                                  ||'Tipo de Cambio '||p_mon_conv ||g_separador
                                  ||'Monto Dist. '||p_mon_conv    ||g_separador
                                  ||'Combinacion Contable'        ||g_separador
                                  ||'Cuenta Contable'             ||g_separador
                                  ||'Desc. Cuenta Contable'       ||g_separador
                                  ||'Unidad de Negocios'          ||g_separador
                                  ||'Desc. Unidad de Negocios'    ||g_separador
                                  ||'Descripcion Linea'         || g_separador
                                  || 'Nro de oc ' || g_separador
                                  || 'Comprador' || g_separador
                                  || 'Unidad de negocio ' || g_separador
                                 || 'Código de artículo' || g_separador
                                 || ' Descripción del artículo' || g_separador
                                  || ' Unidad de Medida' || g_separador
                                  || 'Cantidad' || g_separador
                                  || 'Precio Unitario' || g_separador
                                  || 'Rubro' || g_separador
                                  || 'Familia' || g_separador
                                   || 'Subfamilia' || g_separador
                                   || 'Contrato Acopio' || g_separador
                                   || 'Combinacion Contable SLA' || g_separador
                                   || 'Cuenta Contable SLA' || g_separador
                                   || 'Unidad de Negocios SLA' || g_separador
                                  );

  inserta_temporal ;

 for c1 in (select  org_id, SECCION, ORDEN, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                 CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                  sum(AMOUNT) amount,
                                                  CONCATENATED_SEGMENTS, SEGMENT2, SEGMENT3,
                                                  REGEXP_REPLACE(dist_desc,'[^0-9A-Za-z@ .,()-/ÁÉÍÓÚÑ]', '.') dist_desc, FUTURE_PAY_DUE_DATE,
                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                  ,INVENTORY_ITEM_ID, po_header_id, po_line_id,
                                                  REGEXP_REPLACE(item_description,'[^0-9A-Za-z@ .,()-/ÁÉÍÓÚÑ]', '.')  item_description, QUANTITY_INVOICED, liquidacion_id, contrato_id,
                                                  sla_concatena_segments, sla_segment2, sla_segment3
                    from xx_AP_EOAF_MOV_GT
                    group by org_id, SECCION, ORDEN, INVOICE_TYPE_LOOKUP_CODE, INVOICE_ID, CHECK_ID,
                                                 NAME, VENDOR_NAME, SEGMENT1, TIPO_PROV, BANK_NAME,
                                                 BANK_BRANCH_NAME, BANK_ACCOUNT_NAME, DOC_SEQUENCE_VALUE, STATUS_LOOKUP_CODE,
                                                 CHECK_DATE, PAY_METHOD_DESC, CURRENCY_CODE, EXCHANGE_RATE_PAGO, BASE_AMOUNT,
                                                 BASE_AMOUNT_ORI, INVOICE_NUM, INVOICE_DATE, INVOICE_CURRENCY_CODE, EXCHANGE_RATE,
                                                  CONCATENATED_SEGMENTS, SEGMENT2, SEGMENT3,
                                                   REGEXP_REPLACE(dist_desc,'[^0-9A-Za-z@ .,()-/ÁÉÍÓÚÑ]', '.') , FUTURE_PAY_DUE_DATE,
                                                  DATOS_CABECERA, FF_VENDOR_NAME, FF_SEGMENT1, FF_INVOICE_NUM, FF_INVOICE_DATE
                                                  ,INVENTORY_ITEM_ID, po_header_id, po_line_id,
                                                  REGEXP_REPLACE(item_description,'[^0-9A-Za-z@ .,()-/ÁÉÍÓÚÑ]', '.') , QUANTITY_INVOICED, liquidacion_id, contrato_id,
                                                  sla_concatena_segments, sla_segment2, sla_segment3
                    ORDER BY name
                               , check_date
                               , doc_sequence_value
                               , invoice_date
                               , invoice_num
                               , ff_invoice_date
                               , ff_invoice_num
                               , orden
                               , concatenated_segments) loop
        l_inventory_item_id := c1.inventory_item_id;
        if c1.liquidacion_id is not null and l_inventory_item_id is null then
           begin
                 select inventory_item_id into l_inventory_item_id
                 from xx_tcg_liquidaciones xtl
                where xtl.liquidacion_id = c1.liquidacion_id;
           exception when others then l_inventory_item_id :=null;
           end;
        end if;

            if c1.po_header_id is not null then
               begin

                     select  segment1, full_name
                     into l_segment1, l_comprador
                    from po_headers_all  ph, per_all_people_f pap
                    where po_header_id = c1.po_header_id
                    and ph.agent_id = pap.person_id;

               exception when others then l_segment1 := null; l_comprador:= null;
               end;
           else
                l_segment1 := null; l_comprador:= null;
           end if;

            if c1.po_line_id is not null then
               begin

                     select  xx_gl_unidad_negocios, pl.item_description, pl.unit_meas_lookup_code, pl.list_price_per_unit
                     into l_xx_gl_unidad_negocios , l_item_description_oc, l_unit_meas_lookup_code, l_list_price_per_unit
                    from po_lines_all_dfv pl_dfv , po_lines_all pl
                    where pl.po_line_id = c1.po_line_id
                    and pl.rowid = pl_dfv.row_id;
               exception when others then l_xx_gl_unidad_negocios := null;
               end;
           else
                l_xx_gl_unidad_negocios := null;
                 l_item_description_oc     := null;
                 l_unit_meas_lookup_code := null;
                 l_list_price_per_unit  := null;
           end if;

           if l_inventory_item_id is not null then
                    BEGIN
                       SELECT msi.segment1, msi.description
                         INTO l_nro_item, l_descri_item
                         FROM mtl_system_items_b msi
                        WHERE organization_id = g_master_organization
                              AND msi.inventory_item_id = l_inventory_item_id;
                    EXCEPTION
                       WHEN OTHERS
                       THEN
                          l_nro_item := NULL;
                          l_descri_item := NULL;
                    END;
            else
                      l_nro_item := NULL;
                      l_descri_item := NULL;
            end if;

            BEGIN
               SELECT flex_value || '-' || description
                 INTO l_rubro
                 FROM apps.FND_FLEX_VALUES_VL ffv, apps.mtl_item_Categories_V mic
                WHERE     ffv.flex_value_set_id = 1010650
                      AND ffv.flex_value = mic.segment1
                      AND mic.organization_id = g_master_organization
                      AND mic.inventory_item_id = c1.inventory_item_id;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_rubro := NULL;
            END;

            BEGIN
               SELECT flex_value || '-' || description
                 INTO l_familia
                 FROM apps.FND_FLEX_VALUES_VL ffv, apps.mtl_item_Categories_V mic
                WHERE     ffv.flex_value_set_id = 1010651
                      AND ffv.PARENT_FLEX_VALUE_LOW = mic.segment1
                      AND ffv.flex_Value = mic.segment2
                      AND mic.organization_id = g_master_organization
                      AND mic.inventory_item_id = c1.inventory_item_id;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_familia := NULL;
            END;
              begin
                        SELECT flex_value || '-' || description
                          INTO l_sub_familia
                          FROM apps.FND_FLEX_VALUES_VL ffv, apps.mtl_item_Categories_V mic
                         WHERE     ffv.flex_value_set_id = 1010652
                               AND ffv.PARENT_FLEX_VALUE_LOW = mic.segment1
                               AND ffv.flex_Value = mic.segment3
                               AND mic.organization_id = g_master_organization
                               AND mic.inventory_item_id = c1.inventory_item_id;

              EXCEPTION when others then
                        l_sub_familia := null;
              end;

            IF c1.contrato_id is not null then
                begin
                       select numero_contrato into l_contrato
                       from xx_tcg_contratos_compra where contrato_id = c1.contrato_id;
              EXCEPTION when others then
                        l_contrato := null;
              end;
           else
               l_contrato:= null;
           end if;

  SELECT gll.currency_code
     --  , gll.chart_of_accounts_id
    INTO l_mon_func
  --     , l_chart_of_accounts_id
    FROM hr_operating_units hou
       , gl_ledgers         gll
   WHERE hou.set_of_books_id = gll.ledger_id
     AND hou.organization_id = c1.org_id;

   p_mon_conv:= 'USD';

    --Conversion monto distribucion a dolares
    IF c1.currency_code = p_mon_conv THEN
      l_tasa_nueva:= c1.exchange_rate_pago;
    ELSE
      l_tasa_nueva:= tasa_diaria(p_mon_conv,l_mon_func,c1.check_date,'Corporate');
    END IF;

    l_amount_usd := ROUND(c1.amount / l_tasa_nueva,2);

    --Busco meaning para tipo proveedor
    IF c1.tipo_prov IS NOT NULL THEN
      l_tipo_prov := lookup_m(0, 201,'VENDOR TYPE',c1.tipo_prov);
    ELSE
      l_tipo_prov := null;
    END IF;

    --Busco meaning para estado del cheque
    IF c1.status_lookup_code IS NOT NULL THEN
      l_status_lookup_code := lookup_m(0, 200,'CHECK STATE',c1.status_lookup_code);
    ELSE
      l_status_lookup_code := null;
    END IF;

    --Busco meaning para metodo de pago
    IF c1.pay_method_desc IS NOT NULL THEN
      l_pay_method_desc := lookup_m(0, 200,'PAYMENT METHOD',c1.pay_method_desc);
    ELSE
      l_pay_method_desc := null;
    END IF;

    l_cuenta_desc := flex_lookup_m(l_flex_value_id_cuenta, c1.segment2);
    l_uneg_desc := flex_lookup_m(l_flex_value_id_uneg, c1.segment3);


    fnd_file.put_line(fnd_file.output,c1.name                  ||g_separador
                                    ||c1.vendor_name           ||g_separador
                                    ||c1.segment1              ||g_separador
                                    ||l_tipo_prov              ||g_separador
                                    ||c1.bank_name             ||g_separador
                                    ||c1.bank_branch_name      ||g_separador
                                    ||c1.bank_account_name     ||g_separador
                                    ||c1.doc_sequence_value    ||g_separador
                                    ||l_status_lookup_code     ||g_separador
                                    ||c1.check_date            ||g_separador
                                    ||c1.future_pay_due_date   ||g_separador
                                    ||l_pay_method_desc        ||g_separador
                                    ||c1.exchange_rate_pago    ||g_separador
                                    ||c1.base_amount           ||g_separador
                                    ||c1.base_amount_ori       ||g_separador
                                    ||c1.invoice_num           ||g_separador
                                    ||c1.invoice_date          ||g_separador
                                    ||c1.invoice_currency_code ||g_separador
                                    ||c1.exchange_rate         ||g_separador
                                    ||c1.datos_cabecera        ||g_separador
                                    ||c1.ff_vendor_name        ||g_separador
                                    ||c1.ff_segment1           ||g_separador
                                    ||c1.ff_invoice_num        ||g_separador
                                    ||c1.ff_invoice_date       ||g_separador
                                    ||c1.amount                ||g_separador
                                    ||l_tasa_nueva             ||g_separador
                                    ||l_amount_usd             ||g_separador
                                    ||c1.concatenated_segments ||g_separador
                                    ||c1.segment2              ||g_separador
                                    ||l_cuenta_desc            ||g_separador
                                    ||c1.segment3              ||g_separador
                                    ||l_uneg_desc              ||g_separador
                                    ||c1.dist_desc              || g_separador
                                    || l_segment1 || g_separador
                                    || l_comprador || g_separador
                                    || l_xx_gl_unidad_negocios || g_separador
                                    ||l_nro_item || g_separador
                                    ||nvl(l_descri_item,nvl(c1.item_description,l_item_description_oc)) || g_separador
                                    || l_unit_meas_lookup_code || g_separador
                                    || c1.QUANTITY_INVOICED || g_separador
                                    || l_list_price_per_unit || g_separador
                                    || l_rubro|| g_separador
                                    || l_familia || g_separador
                                    || l_Sub_familia || g_separador
                                    || l_contrato || g_separador
                                     || c1.SLA_CONCATENA_SEGMENTS  || g_separador
                                     || c1.SLA_SEGMENT2  || g_separador
                                     || c1.SLA_SEGMENT3  || g_separador
                                    );


  END LOOP;

   retcode:= e_retcode;

EXCEPTION
  WHEN e_exception THEN
    debug(e_message);
    retcode := 2;

  WHEN OTHERS THEN
    Debug('Error General: '||sqlerrm);
    retcode := 2;

END main;



FUNCTION tasa_diaria(p_from_currency   IN VARCHAR2
                    ,p_to_currency     IN VARCHAR2
                    ,p_conversion_date IN DATE
                    ,p_conversion_type IN VARCHAR2)

RETURN NUMBER IS

l_tasa_nueva NUMBER;

BEGIN

  SELECT conversion_rate
    INTO l_tasa_nueva
    FROM gl_daily_rates
   WHERE from_currency   = p_from_currency
     AND to_currency     = p_to_currency
     AND conversion_date = p_conversion_date
     AND conversion_type = p_conversion_type;

     RETURN l_tasa_nueva;

EXCEPTION
WHEN OTHERS THEN

  fnd_file.put_line(fnd_file.log,'');
  fnd_file.put_line(fnd_file.log,'Error buscando tasa de cambio. Parametros:');
  fnd_file.put_line(fnd_file.log,'p_from_currency: '||p_from_currency);
  fnd_file.put_line(fnd_file.log,'p_to_currency: '||p_to_currency);
  fnd_file.put_line(fnd_file.log,'p_conversion_date: '||p_conversion_date);
  fnd_file.put_line(fnd_file.log,'p_conversion_type: '||p_conversion_type);

   e_retcode:= 1;

  RETURN 1;

END tasa_diaria;


FUNCTION lookup_m(p_security_group_id   IN NUMBER
                 ,p_view_application_id IN NUMBER
                 ,p_lookup_type         IN VARCHAR2
                 ,p_lookup_code         IN VARCHAR2)
RETURN VARCHAR2 IS

l_lookup_m fnd_lookup_values.meaning%TYPE;

BEGIN

  SELECT meaning
    INTO l_lookup_m
    FROM fnd_lookup_values
   WHERE language            = userenv('LANG')
     AND lookup_type         = p_lookup_type
     AND view_application_id = p_view_application_id
     AND lookup_code         = p_lookup_code
     AND security_group_id   = p_security_group_id;

  RETURN l_lookup_m;

EXCEPTION
WHEN OTHERS THEN

  fnd_file.put_line(fnd_file.log,'');
  fnd_file.put_line(fnd_file.log,'Error buscando meaning. Parametros:');
  fnd_file.put_line(fnd_file.log,'p_lookup_type: '||p_lookup_type);
  fnd_file.put_line(fnd_file.log,'p_view_application_id: '||p_view_application_id);
  fnd_file.put_line(fnd_file.log,'p_lookup_code: '||p_lookup_code);
  fnd_file.put_line(fnd_file.log,'p_security_group_id: '||p_security_group_id);

   e_retcode:= 1;

  RETURN p_lookup_code;

END lookup_m;

FUNCTION flex_lookup_m(p_flex_value_set_id IN NUMBER
                      ,p_flex_value        IN VARCHAR2)
RETURN VARCHAR2 IS

l_flex_lookup_m fnd_flex_values_vl.description%TYPE;

BEGIN

  SELECT description
    INTO l_flex_lookup_m
    FROM fnd_flex_values_vl
   WHERE flex_value_set_id = p_flex_value_set_id
     AND flex_value        = p_flex_value;

  RETURN l_flex_lookup_m;

EXCEPTION
WHEN OTHERS THEN

  fnd_file.put_line(fnd_file.log,'');
  fnd_file.put_line(fnd_file.log,'Error buscando meaning para el flexfield. Parametros:');
  fnd_file.put_line(fnd_file.log,'p_flex_value_set_id: '||p_flex_value_set_id);
  fnd_file.put_line(fnd_file.log,'p_flex_value: '||p_flex_value);
  e_retcode:= 1;

  RETURN p_flex_value;

END flex_lookup_m;

END XX_AR_AP_EOAFSLA_PKG;
/

exit
