UPDATE apps.oe_order_headers_all ooh
SET    cust_po_number = cust_po_number||'_1'
      ,last_update_date = sysdate
      ,last_updated_by = 2070
WHERE  header_id IN (10543808,10543809,10543807,0543806,10543810);
--20 Registros