UPDATE apps.oe_order_headers_all ooh
SET    cust_po_number = cust_po_number||'_1'
      ,last_update_date = sysdate
      ,last_updated_by = 2070
WHERE  cust_po_number like '%217477%';
--5 Registros