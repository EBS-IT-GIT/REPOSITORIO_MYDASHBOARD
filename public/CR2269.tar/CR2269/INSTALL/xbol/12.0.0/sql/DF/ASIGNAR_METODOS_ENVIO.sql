  set define off;
SET SERVEROUTPUT ON FORMAT WRAPPED
SET VERIFY OFF
SET FEEDBACK OFF
SET TERMOUT OFF
/
DBMS_OUTPUT.ENABLE(1000000);
SPOOL Asignar_Carrier_Svcs_Orgs.log

DECLARE

  l_org_code                  VARCHAR2(5);  
  l_row_id                    ROWID;  
  l_org_carrier_service_id    NUMBER;  
  l_org_carrier_service_info  WSH_ORG_CARRIER_SERVICES_PKG.OCSRECTYPE;  
  l_carrier_info              WSH_ORG_CARRIER_SERVICES_PKG.CarRecType;
  l_CSM_info                  WSH_CARRIER_SHIP_METHODS_PKG.CSMRecType;
  l_exists_csm                NUMBER;
  l_return_status             VARCHAR2(1) := 'S';
  l_csm_rowid                 ROWID;    
  l_carrier_ship_method_id    NUMBER;
  l_procedure                 VARCHAR2(500);
  l_position                  NUMBER;
  l_exception_msg             VARCHAR2(1000);
  l_sqlerr                    VARCHAR2(1000);
  l_sql_code                  NUMBER;
  l_error_msg                 VARCHAR2(3000);
  eCarrierErrors              EXCEPTION;
  
  
  CURSOR c_carriers IS
    SELECT wcv.carrier_id
         , wcv.freight_code
         , wcv.carrier_name
         , wcs.carrier_service_id
         , wcs.ship_method_code
         , wcs.service_level service_level_code
         , wcs.enabled_flag
         , wcs.web_enabled
      FROM WSH_CARRIER_SERVICES wcs
         , WSH_CARRIERS_V       wcv
     WHERE wcs.carrier_id             = wcv.carrier_id
       AND wcv.freight_code           = 'TRANS_AR'
       AND NVL(wcs.enabled_flag, 'N') = 'Y'
       AND carrier_service_id         IN (SELECT DISTINCT woc.carrier_service_id   
                                            FROM WSH_ORG_CARRIER_SERVICES       woc
                                               , ORG_ORGANIZATION_DEFINITIONS   ood
                                           WHERE woc.organization_id   = ood.organization_id
                                             AND ood.organization_code = 'MSS' )
     ORDER BY carrier_service_id;
     
     
  CURSOR c_new_org (p_carrier_svc_id IN NUMBER) IS
    SELECT ood.organization_id
         , ood.organization_code
         , ood.organization_name  
         , wocs.row_id
         , wocs.org_carrier_service_id
      FROM ORG_ORGANIZATION_DEFINITIONS   ood
         , HR_ALL_ORGANIZATION_UNITS      haou
         , HR_ALL_ORGANIZATION_UNITS_DFV  haoud
         , WSH_ORG_CARRIER_SERVICES_V     wocs
     WHERE ood.organization_code   = 'DSS'
       AND ood.organization_id     = haou.organization_id
       AND haou.rowid              = haoud.row_id
       AND haoud.xx_om_asigna_org_a_transp_flag = 'Y'
       AND haoud.context_value     = 'AR' 
       AND wocs.organization_id    = ood.organization_id
       AND ((wocs.carrier_service_id IS NULL 
            AND wocs.organization_id NOT IN (SELECT organization_id
                                               FROM WSH_ORG_CARRIER_SERVICES
                                              WHERE carrier_service_id = p_carrier_svc_id)) 
           OR (wocs.carrier_service_id = p_carrier_svc_id
              AND wocs.organization_id NOT IN (SELECT organization_id
                                                 FROM WSH_ORG_CARRIER_SERVICES
                                                WHERE carrier_service_id = p_carrier_svc_id
                                                  AND enabled_flag = 'Y') ));
       
       
BEGIN  

  DBMS_OUTPUT.put_line('Inicio Cursor '||TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));

  FOR rcs IN  c_carriers LOOP
    
    BEGIN
      
      FOR rorg IN c_new_org(rcs.carrier_service_id) LOOP
             
        l_org_code               := rorg.organization_code;
        l_row_id                 := rorg.row_id;
        l_org_carrier_service_id := rorg.org_carrier_service_id;

             
        l_org_carrier_service_info.carrier_service_id := rcs.carrier_service_id;
        l_org_carrier_service_info.organization_id    := rorg.organization_id;
        l_org_carrier_service_info.enabled_flag       := rcs.enabled_flag;
        l_org_carrier_service_info.creation_date      := SYSDATE;
        l_org_carrier_service_info.created_by         := 2070;
        l_org_carrier_service_info.last_update_date   := SYSDATE;
        l_org_carrier_service_info.last_updated_by    := 2070;
        l_org_carrier_service_info.last_update_login  := 1;
                
        l_carrier_info.p_freight_code    := rcs.freight_code;
        l_carrier_info.p_carrier_name    := rcs.carrier_name;
        l_carrier_info.creation_date     := SYSDATE;
        l_carrier_info.created_by        := 2070;
        l_carrier_info.last_update_date  := SYSDATE;
        l_carrier_info.last_updated_by   := 2070;
        l_carrier_info.last_update_login := 1;
                  
                
        ------------------------------------------------
        -- Initialize all the values for inserting into
        -- the table WSH_CARRIER_SHIP_METHODS
        ------------------------------------------------
                
        l_CSM_info.Carrier_id           := rcs.carrier_id;
        l_CSM_info.ship_method_code     := rcs.ship_method_code;
        l_CSM_info.organization_id      := rorg.organization_id;
        l_CSM_info.carrier_site_id      := NULL;
        l_CSM_info.freight_code         := rcs.freight_code; 
        l_CSM_info.service_level        := rcs.service_level_code; 
        l_CSM_info.Enabled_Flag         := rcs.enabled_flag;
        l_CSM_info.Creation_Date        := SYSDATE;
        l_CSM_info.Created_By           := 2070;
        l_CSM_info.Last_Update_date     := SYSDATE;
        l_CSM_info.Last_Updated_by      := 2070;
        l_CSM_info.Last_Update_Login    := 1;
        l_CSM_info.Web_Enabled          := rcs.web_enabled;

        
        IF (l_org_carrier_service_id IS NOT NULL) THEN
          
          SELECT count(*)
            INTO l_exists_csm
            FROM WSH_CARRIER_SHIP_METHODS
           WHERE organization_id =  rorg.organization_id
             AND ship_method_code = rcs.ship_method_code; 
          
          IF (l_exists_csm = 0) THEN
            
            WSH_CARRIER_SHIP_METHODS_PKG.Create_Carrier_Ship_Method(
                                         p_carrier_ship_method_info    => l_CSM_info,
                                         x_rowid                       => l_csm_rowid,
                                         x_carrier_ship_method_id      => l_carrier_ship_method_id,
                                         x_return_status               => l_return_status);
                                      
            IF (l_return_status <> 'S') THEN
              l_error_msg := 'Error al intentar crear un registro en WSH_CARRIER_SHIP_METHODS '||
                            'para el carrier_service_id '||rcs.carrier_service_id;
                              
              RAISE eCarrierErrors;
 
            END IF;
                    
          END IF;        
          
        END IF;
        
        WSH_ORG_CARRIER_SERVICES_PKG.Assign_Org_Carrier_Service (
                                     p_org_carrier_service_info => l_Org_Carrier_Service_Info
                                   , p_carrier_info             => l_carrier_info
                                   , p_CSM_info                 => l_CSM_info
                                   , p_commit                   => 'F'
                                   , x_Rowid                    => l_row_id
                                   , x_Org_Carrier_Service_Id   => l_org_carrier_service_id
                                   , x_Return_Status            => l_return_status
                                   , x_procedure                => l_procedure
                                   , x_position                 => l_position
                                   , x_sqlerr                   => l_sqlerr
                                   , x_sql_code                 => l_sql_code
                                   , x_exception_msg            => l_exception_msg);
                
                
        IF (l_return_status <> 'S') THEN
          
          l_error_msg := 'Carrier_service_id: '||rcs.carrier_service_id||'Se encontraron Errores Inesperados en posicion ' ||l_position ||' cuando '
                         ||l_procedure||'. Detalles : Mensaje de Excepcion '||l_exception_msg||', Error '||l_sqlerr||', Codigo: '||l_sql_code||'.';
          RAISE eCarrierErrors;
          
        END IF;
             
      END LOOP;     
     
    EXCEPTION
      WHEN eCarrierErrors THEN
        DBMS_OUTPUT.put_line(l_error_msg);
        
    END;
    
  END LOOP;
    
  COMMIT;
  DBMS_OUTPUT.put_line('Fin '||TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));


EXCEPTION  
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line('Error general '||SQLERRM);

END;   
      

/
SHOW ERRORS

SPOOL OFF

SET TERMOUT ON
SET FEEDBACK ON
SET VERIFY ON;

exit
