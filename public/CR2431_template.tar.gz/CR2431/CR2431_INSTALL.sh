#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2431_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2431
# |
# | HISTORY
# |   09-JUN-20  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2431_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2431_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2431
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2431" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2431_9485.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2431"
AddAllLogs $CROUT "FND" "CR2431_9485.ldt"
mv CR2431_9485.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXARITURUIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXARITURUIN.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXARITURUIN"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARITURUIN \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXARITURUIN_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXARITURUIN.ldt"
mv XXARITURUIN* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXARITURUIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARITURUIN \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXARITURUIN_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN_es_AR.rtf /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN_es_AR.rtf /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARITURUIN_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch
. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2431" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2431_9485.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2431_9485.ldt"

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
