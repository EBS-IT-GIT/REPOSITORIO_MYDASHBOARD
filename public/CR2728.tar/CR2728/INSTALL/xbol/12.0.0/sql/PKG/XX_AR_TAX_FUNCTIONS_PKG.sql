  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_TAX_FUNCTIONS_PKG" AS

TYPE xml_type IS RECORD (tax_category      VARCHAR2(90)
                        ,party_name        VARCHAR2(360)
                        ,taxpayer_id       VARCHAR2(20)
                        ,address           VARCHAR2(300)
                        ,province          VARCHAR2(90)
                        ,company           VARCHAR2(120)
                        ,contributor_class VARCHAR2(120)
                        ,new_value         VARCHAR2(150)
                        ,old_value         VARCHAR2(150)
                        ,tax_code          VARCHAr2(150)
                        ,tax_rate          VARCHAR2(90)
                        ,base_Rate         VARCHAR2(90)
                        ,coeficiente       VARCHAR2(90)
                        ,porc_exempt       VARCHAR2(90)
                        ,date_from         VARCHAR2(90)
                        ,date_to           VARCHAR2(90)
                        ,message           VARCHAR2(2000));

PROCEDURE TRANSFER_AR_TAX_TO_JL (retcode             OUT VARCHAR2
                                ,errbuf              OUT VARCHAR2
                                ,p_party_id          IN  NUMBER
                                ,p_contributor_class IN  VARCHAR2);

PROCEDURE TRANSFER_JL_TO_AR_TAX (retcode             OUT VARCHAR2
                                ,errbuf              OUT VARCHAR2
                                ,p_party_id           IN NUMBER
                                ,p_tax_category       IN VARCHAR2);

/*Procedures Used in XXARMAIM*/
PROCEDURE delete_tax_line(x_status_code   OUT VARCHAR2
                         ,x_error_message OUT VARCHAR2
                         ,x_tax_line_id   IN NUMBER);

PROCEDURE delete_tax_line_cm05(x_status_code      OUT VARCHAR2
                              ,x_error_message    OUT VARCHAR2
                              ,x_tax_line_cm05_id  IN NUMBER);

END;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_TAX_FUNCTIONS_PKG" AS

PROCEDURE print_log(p_message IN VARCHAR2) iS
BEGIN
 fnd_file.put_line(fnd_file.log,p_message);
END;

PROCEDURE print_output(p_message IN VARCHAR2) iS
BEGIN
 fnd_file.put_line(fnd_file.output,p_message);
END;

PROCEDURE print_xml(p_type IN VARCHAR2,p_message IN VARCHAR2) IS
BEGIN
 fnd_file.put_line(fnd_file.output,'<'||p_type||'>'||p_message||'</'||p_type||'>');
END;

/*Genero la salida en XML para JL to AR Tax, solo cuando se actualiza*/
PROCEDURE print_xml_jl_output (p_xml IN xml_type) IS

BEGIN

    IF p_xml.contributor_class is not null then
    
        print_output('<G_TAX>');
        
        print_xml('START_DATE',p_xml.date_from);
        print_xml('END_DATE',p_xml.date_to);
        print_xml('CLASS_CODE',p_xml.contributor_class);
        print_xml('TAX_RATE',p_xml.tax_rate);
        print_xml('COEF',p_xml.coeficiente);
        print_xml('PORC_EXEMPT',p_xml.porc_exempt);
        print_xml('BASE_RATE',p_xml.base_rate);
        print_xml('ERROR_MESSAGE',p_xml.message);
        
        print_output('</G_TAX>');
    
    END IF;
    
END;

/*Genero la salida en XML para AR Tax to JL, solo cuando se actualiza*/
PROCEDURE print_xml_ar_output (p_xml IN xml_type) IS

BEGIN

    IF p_xml.party_name is not null then
    
        print_output('<G_PARTY>');
        
        print_xml('TAX_CATEGORY',p_xml.tax_category);
        print_xml('PARTY_NAME',p_xml.party_name);
        print_xml('TAXPAYER_ID',p_xml.taxpayer_id);
        print_xml('ADDRESS',p_xml.address);
        print_xml('PROVINCE',p_xml.province);
        print_xml('COMPANY',p_xml.company);
        print_xml('CONTRIBUTOR_CLASS',p_xml.contributor_class);
        print_xml('OLD_VALUE',p_xml.old_value);
        print_xml('NEW_VALUE',p_xml.new_value);
        print_xml('TAX_CODE',p_xml.tax_code);
        print_xml('TAX_RATE',p_xml.tax_rate);
        print_xml('BASE_RATE',p_xml.base_Rate);
        print_xml('COEF',p_xml.coeficiente);
        print_xml('ERROR_MESSAGE',p_xml.message);
        
        print_output('</G_PARTY>');
    
    END IF; 

END; 

/*Inserto el perifl de sucursal de cliente*/
FUNCTION  INSERT_CUS_CLS(p_error_message     OUT VARCHAR2
                        ,p_address_id        IN  NUMBER
                        ,p_org_id            IN  NUMBER
                        ,p_contributor_class IN  VARCHAR2
                        ,p_tax_category_id   IN  NUMBER
                        ,p_tax_attr_value    IN  VARCHAR2) RETURN BOOLEAN IS

v_cus_tax_attribute jl_zz_ar_tx_categ_all.cus_tax_attribute%type;
v_gdf_attr9 hz_cust_acct_sites_all.global_attribute9%type;
v_cus_class_id NUMBER;
e_cust_exception exception;

BEGIN

        SELECT jl_zz_ar_tx_cus_cls_s.NEXTVAL
          INTO v_cus_class_id
          FROM dual;

        BEGIN

            SELECT cus_tax_attribute
              INTO v_cus_tax_attribute
              FROM jl_zz_ar_tx_categ_all
             WHERE org_Id          = p_org_id
               AND tax_category_Id = p_tax_category_id;

        EXCEPTION
         WHEN OTHERS THEN
           p_error_message := 'Error al obtener cus_tax_attribute para tax_cat_id: '||p_tax_category_id||'. Error: '||SQLERRM;
           RETURN (FALSE);
        END;

        INSERT INTO jl.jl_zz_ar_tx_cus_cls_all
                   (cus_class_id
                   ,address_id
                   ,tax_attr_class_code
                   ,tax_category_id
                   ,tax_attribute_name
                   ,tax_attribute_value
                   ,enabled_flag
                   ,org_id
                   ,creation_date
                   ,created_by
                   ,last_update_date
                   ,last_updated_by
                   ,last_update_login)
                  values
                   (v_cus_class_id
                   ,p_address_id
                   ,p_contributor_class
                   ,p_tax_category_id
                   ,v_cus_tax_attribute
                   ,p_tax_attr_value
                   ,'Y'
                   ,p_org_id
                   ,sysdate
                   ,fnd_global.user_id
                   ,sysdate
                   ,fnd_global.user_id
                   ,fnd_global.login_id);

                   /*print_xml('OLD_VALUE',NULL);

                   print_xml('NEW_VALUE',p_tax_attr_value);*/

       RETURN (TRUE);

EXCEPTION
  WHEN OTHERS THEN
    p_error_message := 'Error OTHERS en XX_AR_TAX_FUNCTIONS_PKG.INSERT_CUS_CLS. Error: '||SQLERRM;
    print_log(p_error_message);
    RETURN (FALSE);
END;

/*Actualizo el perifl de sucursal de cliente*/
FUNCTION update_cus_cls (p_error_message     OUT VARCHAR2
                        ,p_old_value         OUT VARCHAR2    
                        ,p_address_id        IN  NUMBER
                        ,p_org_id            IN  NUMBER
                        ,p_contributor_class IN  VARCHAR2
                        ,p_tax_category_id   IN  NUMBER
                        ,p_tax_attr_value    IN  VARCHAR2) RETURN BOOLEAN IS

v_tax_attr_value jl.jl_zz_ar_tx_cus_cls_all.tax_attribute_value%type;
v_enabled_flag jl.jl_zz_ar_tx_cus_cls_all.enabled_flag%type;

BEGIN

    BEGIN
      SELECT tax_attribute_value,enabled_flag
        into v_tax_attr_value,v_enabled_flag
        from jl.jl_zz_ar_tx_cus_cls_all
       where address_id = p_address_id
         and tax_category_id = p_tax_category_id
         and tax_attr_class_code = p_contributor_class
         and org_id = p_org_id;
   EXCEPTION
    WHEN OTHERS THEN
      v_tax_attr_value := null;
   END;

   --print_xml('OLD_VALUE',v_tax_attr_value);
   p_old_value := v_tax_attr_value;

   IF NVL(v_tax_attr_value,'*') != p_tax_attr_value OR v_enabled_flag = 'N' THEN

        update jl.jl_zz_ar_tx_cus_cls_all
           set tax_attribute_value = p_tax_attr_value
             , enabled_flag = 'Y'
             , last_update_date = sysdate
             , last_updated_by = fnd_global.user_id
             , last_update_login = fnd_global.login_id
         where address_id = p_address_id
           and tax_category_id = p_tax_category_id
           and TAX_ATTR_CLASS_CODE = p_contributor_class
           and org_id = p_org_id;

   END IF;

   --print_xml('NEW_VALUE',p_tax_attr_value);

   RETURN (TRUE);

EXCEPTION
  WHEN OTHERS THEN
    p_error_message := 'Error OTHERS en XX_AR_TAX_FUNCTIONS_PKG.INSERT_CUS_CLS. Error: '||SQLERRM;
    print_log(p_error_message);
    RETURN (FALSE);
END;

/*Inserto CM05*/
FUNCTION insert_cm05 (p_cm05_lines IN XX_AR_TAX_LINES_CM05%ROWTYPE) RETURN BOOLEAN IS

BEGIN


             INSERT INTO XX_AR_TAX_LINES_CM05 (tax_line_cm05_id
                                              ,taxpayer_id
                                              ,party_id
                                              ,province_code
                                              ,start_date
                                              ,end_date
                                              ,coef
                                              ,request_id
                                              ,status
                                              ,creation_date
                                              ,created_by
                                              ,last_update_date
                                              ,last_updated_by
                                              ,last_update_login)
                                       VALUES (p_cm05_lines.tax_line_cm05_id
                                              ,p_cm05_lines.taxpayer_id
                                              ,p_cm05_lines.party_id
                                              ,p_cm05_lines.province_code
                                              ,p_cm05_lines.start_date
                                              ,p_cm05_lines.end_date
                                              ,p_cm05_lines.coef
                                              ,p_cm05_lines.request_id
                                              ,p_cm05_lines.status
                                              ,sysdate
                                              ,fnd_global.user_id
                                              ,sysdate
                                              ,fnd_global.user_id
                                              ,fnd_global.login_id);

                                              commit;
              RETURN TRUE;
EXCEPTION
 WHEN OTHERS THEN
 print_log('Error al insertar en XX_AR_TAX_LINES_CM05. Error: '||SQLERRM);
 RETURN FALSE;
END;

/*Inserto el detalle de Impuesto de AR TAX*/
FUNCTION insert_tax_lines (p_tax_lines IN XX_AR_TAX_LINES%ROWTYPE) RETURN BOOLEAN IS

BEGIN


                  INSERT INTO XX_AR_TAX_LINES (tax_line_id
                                              ,party_id
                                              ,party_name
                                              ,taxpayer_id
                                              ,tax_category
                                              ,start_date
                                              ,end_date
                                              ,classification_code
                                              ,tax_rate
                                              ,coefficient
                                              ,porc_exempt
                                              ,base_rate
                                              ,request_id
                                              ,status
                                              ,creation_date
                                              ,created_by
                                              ,last_update_date
                                              ,last_updated_by
                                              ,last_update_login)
                                       VALUES (p_tax_lines.tax_line_id
                                              ,p_tax_lines.party_id
                                              ,p_tax_lines.party_name
                                              ,p_tax_lines.taxpayer_id
                                              ,p_tax_lines.tax_category
                                              ,p_tax_lines.start_date
                                              ,p_tax_lines.end_date
                                              ,p_tax_lines.classification_code
                                              ,p_tax_lines.tax_rate
                                              ,p_tax_lines.coefficient
                                              ,p_tax_lines.porc_exempt
                                              ,p_tax_lines.base_rate
                                              ,p_tax_lines.request_id
                                              ,p_tax_lines.status
                                              ,sysdate
                                              ,fnd_global.user_id
                                              ,sysdate
                                              ,fnd_global.user_id
                                              ,fnd_global.login_id);

                                              commit;
              RETURN TRUE;
EXCEPTION
 WHEN OTHERS THEN
 print_log('Error al insertar en XX_AR_TAX_LINES. Error: '||SQLERRM);
 RETURN FALSE;
END;

/*Concurrente Transferencia de Localizacion a AR TAX Fase 1*/

/*Proceso de transferencia de JL to AR Tax*/
PROCEDURE transfer_jl_ar(p_status            OUT VARCHAR2
                        ,p_error_message     OUT VARCHAR2
                        ,p_party_id           IN NUMBER
                        ,p_tax_category       IN VARCHAR2) IS

/*Cursor de clientes de companias de Argentina*/
CURSOR c_customers IS
  SELECT hp.jgzz_fiscal_code||hca.global_attribute12 taxpayer_id
        ,hp.party_name
        ,hp.party_id
        ,hca.global_attribute9 origin
    FROM hz_parties hp
        ,hz_cust_accounts hca
   WHERE hp.party_id = hca.party_id
   and hp.party_id = NVL(p_party_id,hp.party_id)
   and hca.status = 'A'
   and hp.status = 'A'
   AND exists (select 1
                 from hz_cust_acct_sites_all hcas
                where hcas.cust_account_id = hca.cust_account_id
                  and hcas.status = 'A'
                  and hcas.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%'))
  GROUP BY hp.jgzz_fiscal_code||hca.global_attribute12
        ,hp.party_name
        ,hp.party_id
        ,hca.global_attribute9
  order by 2,1,3;

/*Cursor de Categorias*/
CURSOR c_tax_category IS
 select tax_category,xx_ar_provincia,xx_ar_coef_cm05
   from xx_ar_tax_categories_v
  where tax_category = NVL(p_tax_category,tax_category);

/*Cursor Perfil de Sucursal de Clientes*/
CURSOR c_taxes (p_party_id NUMBER
               ,p_tax_category VARCHAR2) IS
select party_id
      ,tax_category
      ,tax_attribute_name
      ,tax_attribute_value
      ,xx_ar_exc_calc
      ,xx_ar_use_coef
      ,xx_ar_provincia
      ,DECODE(xx_ar_padron,'Y',to_date(to_char(sysdate,'MM-YYYY'),'MM-YYYY'),trunc(sysdate)) start_date
      ,DECODE(xx_ar_padron,'Y',trunc(last_day(sysdate)),trunc(to_date('4712/12/31','YYYY/MM/DD'))) end_date
  from (select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatcca.tax_attribute_name
            ,DECODE(NVL(flv_dfv2.xx_ar_zf,'N'),'Y',NVL((select lookup_code 
                                                 from fnd_lookup_values_vl 
                                                where description = tax_attribute_value 
                                                  and lookup_type = 'XX_AR_VAT_ZF_CODES'),tax_attribute_value),tax_attribute_value) tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
            ,jzatca_dfv.xx_ar_provincia
        from hz_parties                  hp
            ,hz_cust_accounts            hca
            ,hz_cust_acct_sites_all      hcas
            ,hz_party_sites              hps
            ,hz_locations                hl
            ,jl_zz_ar_tx_categ_all       jzatca
            ,jl_zz_ar_tx_categ_all_dfv   jzatca_dfv
            ,jl_zz_ar_tx_cus_cls_all     jzatcca
            ,fnd_lookup_values_vl        flv
            ,fnd_lookup_values_dfv       flv_dfv
            ,fnd_lookup_values_vl        flv2
            ,fnd_lookup_values_dfv       flv_dfv2
       where hp.party_id               =  hca.party_id
         and hp.party_id               =  NVL(p_party_id,hp.party_id)
         and hca.cust_account_id       =  hcas.cust_account_id
         and hcas.cust_acct_site_id    =  jzatcca.address_id
         and hcas.global_attribute8    =  jzatcca.tax_attr_class_code
         and hcas.org_id               =  jzatcca.org_id
         and jzatcca.tax_category_id   =  jzatca.tax_category_id
         and jzatcca.org_id            =  jzatca.org_id
         and jzatca.rowid              =  jzatca_dfv.row_id 
         and jzatca.tax_category       =  NVL(p_tax_category,jzatca.tax_category)
         AND jzatca.tax_category       =  flv.lookup_code
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
         AND jzatca.tax_rule_set       = 'ARGENTINA'
         and flv.lookup_type(+)        = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid                 =  flv_dfv.row_id(+)
         and flv.start_date_active(+) <=  TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and flv2.lookup_code          =  hl.province(+)
         and flv2.lookup_type(+)       = 'JLZZ_STATE_PROVINCE'
         and flv2.rowid                =  flv_dfv2.row_id(+)
         and flv2.start_date_active(+) <= TRUNC(sysdate)
         and NVL(flv2.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and hca.global_attribute9     = 'DOMESTIC_ORIGIN'
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
     group by hp.party_id
             ,jzatca.tax_category
             ,flv_dfv2.xx_ar_zf
             ,NVL(flv_dfv.xx_ar_exc_calc,'N')
             ,nvl(flv_dfv.xx_ar_use_coef,'N')
             ,nvl(flv_dfv.xx_ar_padron,'N')
             ,jzatcca.tax_attribute_name
             ,jzatcca.tax_attribute_value
             ,jzatca_dfv.xx_ar_provincia
   UNION ALL
             select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatcca.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,jzatca_dfv.xx_ar_provincia
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
        from hz_parties                  hp
            ,hz_cust_accounts            hca
            ,hz_cust_acct_sites_all      hcas
            ,hz_party_sites              hps
            ,hz_locations                hl
            ,jl_zz_ar_tx_categ_all       jzatca
            ,jl_zz_ar_tx_categ_all_dfv   jzatca_dfv
            ,jl_zz_ar_tx_cus_cls_all     jzatcca
            ,fnd_lookup_values_vl        flv
            ,fnd_lookup_values_dfv       flv_dfv
       where hp.party_id               =  hca.party_id
         and hp.party_id               =  NVL(p_party_id,hp.party_id)
         and hca.cust_account_id       =  hcas.cust_account_id
         and hcas.cust_acct_site_id    =  jzatcca.address_id
         and hcas.global_attribute8    =  jzatcca.tax_attr_class_code
         and hcas.org_id               =  jzatcca.org_id
         and jzatcca.tax_category_id   =  jzatca.tax_category_id
         and jzatcca.org_id            =  jzatca.org_id
         and jzatca.rowid              =  jzatca_dfv.row_id 
         and jzatca.tax_category       =  NVL(p_tax_category,jzatca.tax_category)
         AND jzatca.tax_category       =  flv.lookup_code
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
         AND jzatca.tax_rule_set       = 'ARGENTINA'
         and flv.lookup_type(+)        = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid                 =  flv_dfv.row_id(+)
         and flv.start_date_active(+) <=  TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and hca.global_attribute9 = 'FOREIGN_ORIGIN'
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
     group by hp.party_id
             ,jzatca.tax_category
             ,NVL(flv_dfv.xx_ar_exc_calc,'N')
             ,nvl(flv_dfv.xx_ar_use_coef,'N')
             ,nvl(flv_dfv.xx_ar_padron,'N')
             ,jzatcca.tax_attribute_name
             ,jzatcca.tax_attribute_value
             ,jzatca_dfv.xx_ar_provincia
    UNION ALL
     select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
        hp.party_id
            ,jzatca.tax_category
            ,jzatac.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,jzatca_dfv.xx_ar_provincia
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
  from hz_cust_accounts hca
      ,hz_parties hp
      ,hz_cust_acct_sites_all hcas 
      ,jl_zz_ar_tx_att_cls_all jzatac
      ,jl_zz_ar_tx_categ_all jzatca
      ,jl_zz_ar_tx_categ_all_dfv jzatca_dfv
         ,fnd_lookup_values_vl flv
         ,fnd_lookup_values_dfv flv_dfv
 where hca.party_id = hp.party_id
   and hcas.cust_account_id = hca.cust_account_id
   and hcas.org_id = jzatac.org_id
   and hcas.global_attribute8 = jzatac.TAX_ATTR_CLASS_CODE
   and jzatac.TAX_ATTR_CLASS_TYPE = 'CONTRIBUTOR_CLASS'
   and jzatca.tax_rule_set = 'ARGENTINA'
   and hcas.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hcas.status               = 'A'
   and jzatca.tax_category_id = jzatca.tax_category_id
   and jzatac.tax_category_id = jzatca.tax_category_id
   and jzatac.org_id = jzatca.org_id
   and jzatca.tax_category = p_tax_category
   and (hca.global_attribute9 = 'DOMESTIC_ORIGIN'
   OR hca.global_attribute9 != 'DOMESTIC_ORIGIN' AND p_tax_category = 'VAT')
   and jzatca.rowid = jzatca_dfv.row_id
   and jzatca.start_date_active(+) <= TRUNC(sysdate)
   and NVL(jzatca.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   AND jzatca.tax_category = flv.lookup_code
   AND flv.lookup_type(+) = 'XX_AR_TAX_CATEGORIES_AR_TAX'
   AND flv.rowid = flv_dfv.row_id(+)
   AND flv.start_date_active(+) <= TRUNC(sysdate)
   AND NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   AND NVL(hcas.global_attribute9,'N') = 'N'
   and not exists (select 1 
                     from jl_zz_ar_tx_cus_cls_all jzatcca2
                         ,jl_zz_ar_tx_categ_all jzatca2
                         ,hz_cust_acct_sites_all hcas2
                    where hcas2.cust_acct_site_id = jzatcca2.address_id
                      and hcas.cust_account_id = hcas2.cust_account_id
                      and hcas2.global_attribute8 = jzatcca2.TAX_ATTR_CLASS_CODE
                      and hcas2.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
                      and hcas2.status = 'A'
                      AND NVL(hcas2.global_attribute9,'N') = 'N'
                      and jzatca2.tax_category_id = jzatcca2.tax_category_id
                      and jzatca2.tax_category = jzatca.tax_category )
   and hp.party_id = p_party_id
   GROUP BY hp.party_id
            ,jzatca.tax_category
            ,jzatac.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') 
            ,nvl(flv_dfv.xx_ar_use_coef,'N') 
            ,nvl(flv_dfv.xx_ar_padron,'N')
            ,jzatca_dfv.xx_ar_provincia)
             group by party_id
                     ,tax_category
                     ,tax_attribute_name
                     ,tax_attribute_value
                     ,xx_ar_exc_calc
                     ,xx_ar_use_coef
                     ,xx_ar_provincia
                     ,xx_ar_padron;    

/*Cursor Perfil de Sucursal de Clientes de VAT*/
CURSOR c_taxes_vat(p_party_id NUMBER) IS
select tax_attribute_value
  from (select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatcca.tax_attribute_name
            ,DECODE(NVL(flv_dfv2.xx_ar_zf,'N'),'Y',NVL((select lookup_code 
                                                 from fnd_lookup_values_vl 
                                                where description = tax_attribute_value 
                                                  and lookup_type = 'XX_AR_VAT_ZF_CODES'),tax_attribute_value),tax_attribute_value) tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
            ,jzatca_dfv.xx_ar_provincia
        from hz_parties                  hp
            ,hz_cust_accounts            hca
            ,hz_cust_acct_sites_all      hcas
            ,hz_party_sites              hps
            ,hz_locations                hl
            ,jl_zz_ar_tx_categ_all       jzatca
            ,jl_zz_ar_tx_categ_all_dfv   jzatca_dfv
            ,jl_zz_ar_tx_cus_cls_all     jzatcca
            ,fnd_lookup_values_vl        flv
            ,fnd_lookup_values_dfv       flv_dfv
            ,fnd_lookup_values_vl        flv2
            ,fnd_lookup_values_dfv       flv_dfv2
       where hp.party_id               =  hca.party_id
         and hp.party_id               =  NVL(p_party_id,hp.party_id)
         and hca.cust_account_id       =  hcas.cust_account_id
         and hcas.cust_acct_site_id    =  jzatcca.address_id
         and hcas.global_attribute8    =  jzatcca.tax_attr_class_code
         and hcas.org_id               =  jzatcca.org_id
         and jzatcca.tax_category_id   =  jzatca.tax_category_id
         and jzatcca.org_id            =  jzatca.org_id
         and jzatca.rowid              =  jzatca_dfv.row_id 
         and jzatca.tax_category       =  'VAT'
         AND jzatca.tax_category       =  flv.lookup_code
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
         AND jzatca.tax_rule_set       = 'ARGENTINA'
         and flv.lookup_type(+)        = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid                 =  flv_dfv.row_id(+)
         and flv.start_date_active(+) <=  TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and flv2.lookup_code          =  hl.province(+)
         and flv2.lookup_type(+)       = 'JLZZ_STATE_PROVINCE'
         and flv2.rowid                =  flv_dfv2.row_id(+)
         and flv2.start_date_active(+) <= TRUNC(sysdate)
         and NVL(flv2.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and hca.global_attribute9 = 'DOMESTIC_ORIGIN'
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
     group by hp.party_id
             ,jzatca.tax_category
             ,flv_dfv2.xx_ar_zf
             ,NVL(flv_dfv.xx_ar_exc_calc,'N')
             ,nvl(flv_dfv.xx_ar_use_coef,'N')
             ,nvl(flv_dfv.xx_ar_padron,'N')
             ,jzatcca.tax_attribute_name
             ,jzatcca.tax_attribute_value
             ,jzatca_dfv.xx_ar_provincia
   UNION ALL
             select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatcca.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,jzatca_dfv.xx_ar_provincia
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
        from hz_parties                  hp
            ,hz_cust_accounts            hca
            ,hz_cust_acct_sites_all      hcas
            ,hz_party_sites              hps
            ,hz_locations                hl
            ,jl_zz_ar_tx_categ_all       jzatca
            ,jl_zz_ar_tx_categ_all_dfv   jzatca_dfv
            ,jl_zz_ar_tx_cus_cls_all     jzatcca
            ,fnd_lookup_values_vl        flv
            ,fnd_lookup_values_dfv       flv_dfv
       where hp.party_id               =  hca.party_id
         and hp.party_id               =  NVL(p_party_id,hp.party_id)
         and hca.cust_account_id       =  hcas.cust_account_id
         and hcas.cust_acct_site_id    =  jzatcca.address_id
         and hcas.global_attribute8    =  jzatcca.tax_attr_class_code
         and hcas.org_id               =  jzatcca.org_id
         and jzatcca.tax_category_id   =  jzatca.tax_category_id
         and jzatcca.org_id            =  jzatca.org_id
         and jzatca.rowid              =  jzatca_dfv.row_id 
         and jzatca.tax_category       =  'VAT'
         AND jzatca.tax_category       =  flv.lookup_code
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
         AND jzatca.tax_rule_set       = 'ARGENTINA'
         and flv.lookup_type(+)        = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid                 =  flv_dfv.row_id(+)
         and flv.start_date_active(+) <=  TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and hca.global_attribute9 = 'FOREIGN_ORIGIN'
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
     group by hp.party_id
             ,jzatca.tax_category
             ,NVL(flv_dfv.xx_ar_exc_calc,'N')
             ,nvl(flv_dfv.xx_ar_use_coef,'N')
             ,nvl(flv_dfv.xx_ar_padron,'N')
             ,jzatcca.tax_attribute_name
             ,jzatcca.tax_attribute_value
             ,jzatca_dfv.xx_ar_provincia
    UNION ALL
     select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatac.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,jzatca_dfv.xx_ar_provincia
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
  from hz_cust_accounts hca
      ,hz_parties hp
      ,hz_cust_acct_sites_all hcas 
      ,jl_zz_ar_tx_att_cls_all jzatac
      ,jl_zz_ar_tx_categ_all jzatca
      ,jl_zz_ar_tx_categ_all_dfv jzatca_dfv
         ,fnd_lookup_values_vl flv
         ,fnd_lookup_values_dfv flv_dfv
 where hca.party_id = hp.party_id
   and hcas.cust_account_id = hca.cust_account_id
   and hcas.org_id = jzatac.org_id
   and hcas.global_attribute8 = jzatac.TAX_ATTR_CLASS_CODE
   and jzatac.tax_attr_class_type = 'CONTRIBUTOR_CLASS'
   and jzatca.tax_rule_set        = 'ARGENTINA'
   and hcas.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
   and hca.status                = 'A'
   and hp.status                 = 'A'
   and hcas.status               = 'A'
   and jzatca.tax_category_id = jzatca.tax_category_id
   and jzatac.tax_category_id = jzatca.tax_category_id
   and jzatac.org_id = jzatca.org_id
   and jzatca.tax_category = 'VAT'
   and (hca.global_attribute9 != 'DOMESTIC_ORIGIN')
   and jzatca.rowid = jzatca_dfv.row_id
   and jzatca.start_date_active(+) <= TRUNC(sysdate)
   and NVL(jzatca.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   AND jzatca.tax_category = flv.lookup_code
         and flv.lookup_type(+) = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid = flv_dfv.row_id(+)
         and flv.start_date_active(+) <= TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   and not exists (select 1 
                     from jl_zz_ar_tx_cus_cls_all jzatcca2
                         ,jl_zz_ar_tx_categ_all jzatca2
                         ,hz_cust_acct_sites_all hcas2
                    where hcas2.cust_acct_site_id = jzatcca2.address_id
                      and hcas.cust_account_id    = hcas2.cust_account_id
                      and hcas2.global_attribute8 = jzatcca2.tax_attr_class_code
                      and hcas2.org_id IN (select organization_id 
                                             from hr_operating_units hou 
                                            where name like 'AR%')
                      and hcas2.status = 'A'
                      and jzatca2.tax_category_id = jzatcca2.tax_category_id
                      and jzatca2.tax_category = jzatca.tax_category )
   and hp.party_id = p_party_id
   GROUP BY hp.party_id
            ,jzatca.tax_category
            ,jzatac.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') 
            ,nvl(flv_dfv.xx_ar_use_coef,'N') 
            ,nvl(flv_dfv.xx_ar_padron,'N')
            ,jzatca_dfv.xx_ar_provincia)
             group by tax_attribute_value;

/*Cursor Perfil de Sucursal de Clientes para obtener repetidos*/                     
CURSOR c_taxes_suc(p_party_id NUMBER
,p_tax_category VARCHAR2) IS
select party_id
      ,tax_category
      ,tax_attribute_name
      ,tax_attribute_value
      ,xx_ar_exc_calc
      ,xx_ar_use_coef
      ,xx_ar_provincia
      ,DECODE(xx_ar_padron,'Y',to_date(to_char(sysdate,'MM-YYYY'),'MM-YYYY'),trunc(sysdate)) start_date
      ,DECODE(xx_ar_padron,'Y',trunc(last_day(sysdate)),trunc(to_date('4712/12/31','YYYY/MM/DD'))) end_date
      ,address1
      ,org_name
  from (select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatcca.tax_attribute_name
            ,DECODE(NVL(flv_dfv2.xx_ar_zf,'N'),'Y',NVL((select lookup_code 
                                                 from fnd_lookup_values_vl 
                                                where description = tax_attribute_value 
                                                  and lookup_type = 'XX_AR_VAT_ZF_CODES'),tax_attribute_value),tax_attribute_value) tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
            ,jzatca_dfv.xx_ar_provincia
            ,hl.address1
            ,haou.name org_name
        from hz_parties                  hp
            ,hz_cust_accounts            hca
            ,hz_cust_acct_sites_all      hcas
            ,hz_party_sites              hps
            ,hz_locations                hl
            ,jl_zz_ar_tx_categ_all       jzatca
            ,jl_zz_ar_tx_categ_all_dfv   jzatca_dfv
            ,jl_zz_ar_tx_cus_cls_all     jzatcca
            ,fnd_lookup_values_vl        flv
            ,fnd_lookup_values_dfv       flv_dfv
            ,fnd_lookup_values_vl        flv2
            ,fnd_lookup_values_dfv       flv_dfv2
            ,hr_all_organization_units   haou
       where hp.party_id               =  hca.party_id
         and hp.party_id               =  NVL(p_party_id,hp.party_id)
         and hca.cust_account_id       =  hcas.cust_account_id
         and hcas.cust_acct_site_id    =  jzatcca.address_id
         and hcas.global_attribute8    =  jzatcca.tax_attr_class_code
         and hcas.org_id               =  jzatcca.org_id
         and jzatcca.tax_category_id   =  jzatca.tax_category_id
         and jzatcca.org_id            =  jzatca.org_id
         and jzatca.rowid              =  jzatca_dfv.row_id
         and haou.organization_id      =  hcas.org_id
         and jzatca.tax_category       =  NVL(p_tax_category,jzatca.tax_category)
         AND jzatca.tax_category       =  flv.lookup_code
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
         AND jzatca.tax_rule_set       = 'ARGENTINA'
         and flv.lookup_type(+)        = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid                 =  flv_dfv.row_id(+)
         and flv.start_date_active(+) <=  TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and flv2.lookup_code          =  hl.province(+)
         and flv2.lookup_type(+)       = 'JLZZ_STATE_PROVINCE'
         and flv2.rowid                =  flv_dfv2.row_id(+)
         and flv2.start_date_active(+) <= TRUNC(sysdate)
         and NVL(flv2.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and hca.global_attribute9 = 'DOMESTIC_ORIGIN'
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
     group by hp.party_id
             ,jzatca.tax_category
             ,flv_dfv2.xx_ar_zf
             ,NVL(flv_dfv.xx_ar_exc_calc,'N')
             ,nvl(flv_dfv.xx_ar_use_coef,'N')
             ,nvl(flv_dfv.xx_ar_padron,'N')
             ,jzatcca.tax_attribute_name
             ,jzatcca.tax_attribute_value
             ,jzatca_dfv.xx_ar_provincia
            ,hl.address1
            ,haou.name
   UNION ALL
             select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatcca.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,jzatca_dfv.xx_ar_provincia
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
            ,hl.address1
            ,haou.name org_name
        from hz_parties                  hp
            ,hz_cust_accounts            hca
            ,hz_cust_acct_sites_all      hcas
            ,hz_party_sites              hps
            ,hz_locations                hl
            ,jl_zz_ar_tx_categ_all       jzatca
            ,jl_zz_ar_tx_categ_all_dfv   jzatca_dfv
            ,jl_zz_ar_tx_cus_cls_all     jzatcca
            ,fnd_lookup_values_vl        flv
            ,fnd_lookup_values_dfv       flv_dfv
            ,hr_all_organization_units   haou
       where hp.party_id               =  hca.party_id
         and hp.party_id               =  NVL(p_party_id,hp.party_id)
         and hca.cust_account_id       =  hcas.cust_account_id
         and hcas.cust_acct_site_id    =  jzatcca.address_id
         and hcas.global_attribute8    =  jzatcca.tax_attr_class_code
         and hcas.org_id               =  jzatcca.org_id
         and jzatcca.tax_category_id   =  jzatca.tax_category_id
         and jzatcca.org_id            =  jzatca.org_id
         and jzatca.rowid              =  jzatca_dfv.row_id 
         and jzatca.tax_category       =  NVL(p_tax_category,jzatca.tax_category)
         AND jzatca.tax_category       =  flv.lookup_code
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
         and hcas.org_id               =  haou.organization_id
         AND jzatca.tax_rule_set       = 'ARGENTINA'
         and flv.lookup_type(+)        = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid                 =  flv_dfv.row_id(+)
         and flv.start_date_active(+) <=  TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
         and hca.global_attribute9     = 'FOREIGN_ORIGIN'
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
     group by hp.party_id
             ,jzatca.tax_category
             ,NVL(flv_dfv.xx_ar_exc_calc,'N')
             ,nvl(flv_dfv.xx_ar_use_coef,'N')
             ,nvl(flv_dfv.xx_ar_padron,'N')
             ,jzatcca.tax_attribute_name
             ,jzatcca.tax_attribute_value
             ,jzatca_dfv.xx_ar_provincia
             ,hl.address1
             ,haou.name
    UNION ALL
     select /*+ index(jzatca jl_zz_ar_tx_cus_cls_u1) */
             hp.party_id
            ,jzatca.tax_category
            ,jzatac.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') xx_ar_exc_calc
            ,nvl(flv_dfv.xx_ar_use_coef,'N') xx_ar_use_coef
            ,jzatca_dfv.xx_ar_provincia
            ,nvl(flv_dfv.xx_ar_padron,'N') xx_ar_padron
            ,hl.address1
            ,haou.name org_name
      from hz_cust_accounts hca
          ,hz_parties hp
          ,hz_cust_acct_sites_all hcas 
          ,hz_party_sites hps
          ,hz_locations hl
          ,jl_zz_ar_tx_att_cls_all jzatac
          ,jl_zz_ar_tx_categ_all jzatca
          ,jl_zz_ar_tx_categ_all_dfv jzatca_dfv
         ,fnd_lookup_values_vl flv
         ,fnd_lookup_values_dfv flv_dfv
         ,hr_all_organization_units haou
 where hca.party_id = hp.party_id
   and hcas.cust_account_id = hca.cust_account_id
   and hcas.org_id = jzatac.org_id
   and hcas.global_attribute8 = jzatac.TAX_ATTR_CLASS_CODE
   and jzatac.TAX_ATTR_CLASS_TYPE = 'CONTRIBUTOR_CLASS'
   and jzatca.tax_rule_set = 'ARGENTINA'
   and hcas.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
   and hcas.party_site_id = hps.party_site_id
   and hps.location_id = hl.location_id
   and hcas.org_id = haou.organization_id
   and jzatca.tax_category_id = jzatca.tax_category_id
   and jzatac.tax_category_id = jzatca.tax_category_id
   and jzatac.org_id       = jzatca.org_id
   and jzatca.tax_category = p_tax_category
   and (hca.global_attribute9 = 'DOMESTIC_ORIGIN'
   OR hca.global_attribute9  != 'DOMESTIC_ORIGIN' AND p_tax_category = 'VAT')
   and jzatca.rowid = jzatca_dfv.row_id
   and jzatca.start_date_active(+) <= TRUNC(sysdate)
   and NVL(jzatca.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   AND jzatca.tax_category = flv.lookup_code
         and flv.lookup_type(+) = 'XX_AR_TAX_CATEGORIES_AR_TAX'
         and flv.rowid = flv_dfv.row_id(+)
         and flv.start_date_active(+) <= TRUNC(sysdate)
         and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   and not exists (select 1 
                     from jl_zz_ar_tx_cus_cls_all jzatcca2
                         ,jl_zz_ar_tx_categ_all jzatca2
                         ,hz_cust_acct_sites_all hcas2
                    where hcas2.cust_acct_site_id = jzatcca2.address_id
                      and hcas.cust_account_id = hcas2.cust_account_id
                      and hcas2.global_attribute8 = jzatcca2.TAX_ATTR_CLASS_CODE
                      and hcas2.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
                      and hcas2.status = 'A'
                      and jzatca2.tax_category_id = jzatcca2.tax_category_id
                      and jzatca2.tax_category = jzatca.tax_category )
   and hp.party_id = p_party_id
   GROUP BY hp.party_id
            ,jzatca.tax_category
            ,jzatac.tax_attribute_name
            ,tax_attribute_value
            ,NVL(flv_dfv.xx_ar_exc_calc,'N') 
            ,nvl(flv_dfv.xx_ar_use_coef,'N') 
            ,nvl(flv_dfv.xx_ar_padron,'N')
            ,jzatca_dfv.xx_ar_provincia
            ,hl.address1
            ,haou.name)
             group by party_id
                     ,tax_category
                     ,tax_attribute_name
                     ,tax_attribute_value
                     ,xx_ar_exc_calc
                     ,xx_ar_use_coef
                     ,xx_ar_provincia
                     ,xx_ar_padron
            ,address1
            ,org_name;         
               
/*Cursor Exenciones, Q1 no Salta, Q2 y Q3 Salta*/
CURSOR c_excs (p_party_id     NUMBER
              ,p_tax_category VARCHAR2) IS
   select jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         --,NVL(hca_dfv.xx_convenio_mult,'N') xx_convenio_mult
         ,NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate) tax_rate
         ,TO_NUMBER(decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')))) coef
     from hz_parties              hp
         ,hz_cust_accounts        hca
         ,hz_cust_accounts_dfv    hca_dfv
         ,hz_cust_acct_sites_all  hcas
         ,jl_zz_ar_tx_exc_cus_all jzatecc
         ,jl_zz_ar_tx_categ_all   jzatca
         ,fnd_lookup_values_vl    flv
         ,fnd_lookup_values_dfv   flv_dfv
         ,hz_party_sites          hps
         ,hz_locations            hl
         ,ar_vat_tax_all          avt
    where hp.party_id              =  NVL(p_party_id,hp.party_id)
      and jzatca.tax_category      =  NVL(p_tax_category,jzatca.tax_category)
      and hp.party_id              =  hca.party_id
      and hca.rowid                =  hca_dfv.row_id
      and hca.cust_account_id      =  hcas.cust_account_id
      and jzatecc.address_id       =  hcas.cust_acct_site_id
      and jzatecc.org_id           =  hcas.org_id
      and jzatca.tax_category_id   =  jzatecc.tax_category_id
      and jzatca.org_id            =  jzatecc.org_id
      and jzatecc.tax_code         =  avt.tax_code
      and jzatecc.org_id           =  avt.org_id
      and hca.status               = 'A'
      and hp.status                = 'A'
      and hps.status               = 'A'
      and hcas.status              = 'A'
      --and nvl(jzatecc.end_date_active,trunc(sysdate)) >= trunc(sysdate)
      and flv.lookup_type(+)       = 'XX_AR_TAX_CATEGORIES_AR_TAX'
      and flv.lookup_code          = jzatca.tax_category
      and hcas.party_site_id       =  hps.party_site_id
      and hps.location_id          =  hl.location_id
      and flv.start_date_active(+) <=  trunc(sysdate)
      and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
      and flv.rowid                = flv_dfv.row_id  
      and (jzatca.tax_category != 'TOPSA')
      group by jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.'))
         ,decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')))
         ,avt.tax_rate
      UNION ALL
      select jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         --,NVL(hca_dfv.xx_convenio_mult,'N') xx_convenio_mult
         ,NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate) tax_rate
         /*,decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))) coef*/
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')) coef
     from hz_parties              hp
         ,hz_cust_accounts        hca
         ,hz_cust_accounts_dfv    hca_dfv
         ,hz_cust_acct_sites_all  hcas
         ,jl_zz_ar_tx_exc_cus_all jzatecc
         ,jl_zz_ar_tx_categ_all   jzatca
         ,fnd_lookup_values_vl    flv
         ,fnd_lookup_values_dfv   flv_dfv
         ,hz_party_sites          hps
         ,hz_locations            hl
         ,ar_vat_tax_all          avt
    where hp.party_id              =  NVL(p_party_id,hp.party_id)
      and jzatca.tax_category      =  NVL(p_tax_category,jzatca.tax_category)
      and hp.party_id              =  hca.party_id
      and hca.rowid                =  hca_dfv.row_id
      and hca.cust_account_id      =  hcas.cust_account_id
      and jzatecc.address_id       =  hcas.cust_acct_site_id
      and jzatecc.org_id           =  hcas.org_id
      and jzatca.tax_category_id   =  jzatecc.tax_category_id
      and jzatca.org_id            =  jzatecc.org_id
      and jzatecc.tax_code         = avt.tax_code
      and jzatecc.org_id           = avt.org_id
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
      --and nvl(jzatecc.end_date_active,trunc(sysdate)) >= trunc(sysdate)
      and flv.lookup_type(+)       = 'XX_AR_TAX_CATEGORIES_AR_TAX'
      and flv.lookup_code          = jzatca.tax_category
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
      and flv.start_date_active(+) <=  trunc(sysdate)
      and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
      and flv.rowid                = flv_dfv.row_id
      and hca_dfv.xx_convenio_mult = 'Y'  
       AND jzatca.tax_category IN ( 'TOPSA')
       and jzatca.attribute7 != NVL(hl.province,'*')
       and exists (select 1 
                        from hz_cust_acct_sites_all hcas2
                            ,hz_party_sites hps2
                            ,hz_locations hl2
                       where hca.cust_account_id = hcas2.cust_account_id
                         and hcas2.party_site_id = hps2.party_site_id
                         and hps2.location_id = hl2.location_id
                         and jzatca.attribute7 = NVL(hl2.province,'*') )
      group by jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.'))
         /*,decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')))*/
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))
         ,avt.tax_rate
      UNION ALL
       select jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         --,NVL(hca_dfv.xx_convenio_mult,'N') xx_convenio_mult
         ,NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate) tax_rate
         /*,decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))) coef*/
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')) coef
     from hz_parties              hp
         ,hz_cust_accounts        hca
         ,hz_cust_accounts_dfv    hca_dfv
         ,hz_cust_acct_sites_all  hcas
         ,jl_zz_ar_tx_exc_cus_all jzatecc
         ,jl_zz_ar_tx_categ_all   jzatca
         ,fnd_lookup_values_vl    flv
         ,fnd_lookup_values_dfv   flv_dfv
            ,hz_party_sites              hps
            ,hz_locations                hl
         ,ar_vat_tax_all          avt
    where hp.party_id              =  NVL(p_party_id,hp.party_id)
      and jzatca.tax_category      =  NVL(p_tax_category,jzatca.tax_category)
      and hp.party_id              =  hca.party_id
      and hca.rowid                =  hca_dfv.row_id
      and hca.cust_account_id      =  hcas.cust_account_id
      and jzatecc.address_id       =  hcas.cust_acct_site_id
      and jzatecc.org_id           =  hcas.org_id
      and jzatca.tax_category_id   =  jzatecc.tax_category_id
      and jzatca.org_id            =  jzatecc.org_id
      and jzatecc.tax_code         =  avt.tax_code
      and jzatecc.org_id           =  avt.org_id
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
      --and nvl(jzatecc.end_date_active,trunc(sysdate)) >= trunc(sysdate)
      and flv.lookup_type(+)       = 'XX_AR_TAX_CATEGORIES_AR_TAX'
      and flv.lookup_code          = jzatca.tax_category
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
      and flv.start_date_active(+) <=  trunc(sysdate)
      and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
      and flv.rowid                = flv_dfv.row_id
      and hca_dfv.xx_convenio_mult = 'Y'  
       AND jzatca.tax_category IN ( 'TOPSA')
       and not exists (select 1 
                        from hz_cust_acct_sites_all hcas2
                            ,hz_party_sites hps2
                            ,hz_locations hl2
                       where hca.cust_account_id = hcas2.cust_account_id
                         and hcas2.party_site_id = hps2.party_site_id
                         and hps2.location_id = hl2.location_id
                         and jzatca.attribute7 = NVL(hl2.province,'*') )
      group by jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.'))
         --,decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')))
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))
         ,avt.tax_rate
      UNION ALL
       select jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         --,NVL(hca_dfv.xx_convenio_mult,'N') xx_convenio_mult
         ,NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate) tax_rate
         --,decode(nvl(flv_dfv.xx_ar_use_coef,'N'),'N',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))) coef
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')) coef
     from hz_parties              hp
         ,hz_cust_accounts        hca
         ,hz_cust_accounts_dfv    hca_dfv
         ,hz_cust_acct_sites_all  hcas
         ,jl_zz_ar_tx_exc_cus_all jzatecc
         ,jl_zz_ar_tx_categ_all   jzatca
         ,fnd_lookup_values_vl    flv
         ,fnd_lookup_values_dfv   flv_dfv
            ,hz_party_sites              hps
            ,hz_locations                hl
         ,ar_vat_tax_all          avt
    where hp.party_id              =  NVL(p_party_id,hp.party_id)
      and jzatca.tax_category      =  NVL(p_tax_category,jzatca.tax_category)
      and hp.party_id              =  hca.party_id
      and hca.rowid                =  hca_dfv.row_id
      and hca.cust_account_id      =  hcas.cust_account_id
      and jzatecc.address_id       =  hcas.cust_acct_site_id
      and jzatecc.org_id           =  hcas.org_id
      and jzatca.tax_category_id   =  jzatecc.tax_category_id
      and jzatca.org_id            =  jzatecc.org_id
      and jzatecc.tax_code         = avt.tax_code
      and jzatecc.org_id           = avt.org_id
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
      and flv.lookup_type(+)       = 'XX_AR_TAX_CATEGORIES_AR_TAX'
      and flv.lookup_code          = jzatca.tax_category
         AND hcas.party_site_id        =  hps.party_site_id
         and hps.location_id           =  hl.location_id
      and flv.start_date_active(+) <=  trunc(sysdate)
      and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
      and flv.rowid                = flv_dfv.row_id
      and hca_dfv.xx_convenio_mult = 'Y'  
       AND jzatca.tax_category IN ( 'TOPSA')
       and jzatca.attribute7 = NVL(hl.province,'*')
       and not exists (select 1 
                        from hz_cust_acct_sites_all hcas2
                            ,hz_party_sites hps2
                            ,hz_locations hl2
                       where hca.cust_account_id = hcas2.cust_account_id
                         and hcas2.party_site_id = hps2.party_site_id
                         and hps2.location_id = hl2.location_id
                         and jzatca.attribute7 != NVL(hl2.province,'*') )
      group by jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.'))
         --,decode(nvl(flv_dfv.xx_ar_use_coef,'Y'),'Y',null,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')))
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))
         ,avt.tax_rate
      order by 7,3,4;
      
CURSOR c_taxes_sup(p_party_id     NUMBER
                  ,p_tax_category VARCHAR2
                  ,p_from_date    DATE
                  ,p_last_date    DATE
                  ,p_base_rate    NUMBER
                  ,p_tax_rate     NUMBER
                  ,p_coef         NUMBER) IS
select jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         --,NVL(hca_dfv.xx_convenio_mult,'N') xx_convenio_mult
         ,NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate) tax_rate
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')) coef
         ,hl.address1
         ,haou.name org_name
     from hz_parties              hp
         ,hz_cust_accounts        hca
         ,hz_cust_accounts_dfv    hca_dfv
         ,hz_cust_acct_sites_all  hcas
         ,jl_zz_ar_tx_exc_cus_all jzatecc
         ,jl_zz_ar_tx_categ_all   jzatca
         ,fnd_lookup_values_vl    flv
         ,fnd_lookup_values_dfv   flv_dfv
         ,hz_party_sites          hps
         ,hz_locations            hl
         ,ar_vat_tax_all          avt
         ,hr_all_organization_units haou
    where hp.party_id              =  NVL(p_party_id,hp.party_id)
      and jzatca.tax_category      =  NVL(p_tax_category,jzatca.tax_category)
      and hp.party_id              =  hca.party_id
      and hca.rowid                =  hca_dfv.row_id
      and hca.cust_account_id      =  hcas.cust_account_id
      and jzatecc.address_id       =  hcas.cust_acct_site_id
      and jzatecc.org_id           =  hcas.org_id
      and jzatca.tax_category_id   =  jzatecc.tax_category_id
      and hcas.org_id              = haou.organization_id
      and jzatca.org_id            =  jzatecc.org_id
      and jzatecc.tax_code         = avt.tax_code
      and jzatecc.org_id           = avt.org_id
         and hca.status                = 'A'
         and hp.status                 = 'A'
         and hps.status                = 'A'
         and hcas.status               = 'A'
      --and nvl(jzatecc.end_date_active,trunc(sysdate)) >= trunc(sysdate)
      and flv.lookup_type(+)       = 'XX_AR_TAX_CATEGORIES_AR_TAX'
      and flv.lookup_code          = jzatca.tax_category
         AND hcas.party_site_id    =  hps.party_site_id
         and hps.location_id       =  hl.location_id
      and flv.start_date_active(+) <=  trunc(sysdate)
      and NVL(flv.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
      and flv.rowid                = flv_dfv.row_id
      ---
      and (jzatca.tax_category != 'TOPSA'
        OR (jzatca.tax_category IN ( 'TOPSA')
       and jzatca.attribute7 != NVL(hl.province,'*')
       and exists (select 1 
                        from hz_cust_acct_sites_all hcas2
                            ,hz_party_sites hps2
                            ,hz_locations hl2
                       where hca.cust_account_id = hcas2.cust_account_id
                         and hcas2.party_site_id = hps2.party_site_id
                         and hps2.location_id = hl2.location_id
                         and jzatca.attribute7 = NVL(hl2.province,'*') ))
       OR ( jzatca.tax_category IN ( 'TOPSA')
       and not exists (select 1 
                        from hz_cust_acct_sites_all hcas2
                            ,hz_party_sites hps2
                            ,hz_locations hl2
                       where hca.cust_account_id = hcas2.cust_account_id
                         and hcas2.party_site_id = hps2.party_site_id
                         and hps2.location_id = hl2.location_id
                         and jzatca.attribute7 = NVL(hl2.province,'*') ))
      )
      ---
      and  ((jzatecc.start_date_active !=TRUNC(p_from_date) OR jzatecc.end_date_active != TRUNC(p_last_date))
      and ((TRUNC(p_from_date) >= jzatecc.start_date_active and TRUNC(p_last_date) > jzatecc.end_date_active and TRUNC(p_from_date) <= jzatecc.end_date_active)
        OR (TRUNC(p_from_date) < jzatecc.start_date_active  and TRUNC(p_last_date) >= jzatecc.end_date_active)
        OR (TRUNC(p_from_date) <= jzatecc.start_date_active and TRUNC(p_last_date) > jzatecc.end_date_active)
        OR (TRUNC(p_from_date) >= jzatecc.start_date_active and TRUNC(p_last_date) < jzatecc.end_date_active)
        OR (TRUNC(p_from_date) > jzatecc.start_date_active  and TRUNC(p_last_date) <= jzatecc.end_date_active)
        OR (TRUNC(p_from_date) < jzatecc.start_date_active  and TRUNC(p_last_date) < jzatecc.end_date_active and TRUNC(p_last_date) >= jzatecc.start_date_active))
        OR (jzatecc.start_date_active = TRUNC(p_from_date) 
        AND jzatecc.end_date_active = TRUNC(p_last_date) 
        AND (NVL(NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate),-1) != NVL(p_tax_rate,-1)
          OR jzatecc.base_rate != p_base_rate 
          OR NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')),-1) != NVL(p_coef,-1)
          )
           )
        OR (jzatecc.start_date_active > TRUNC(p_from_date) AND jzatecc.end_date_active <= TRUNC(p_last_date))
        )
      group by jzatca.tax_category
         ,jzatca.tax_category_id
         ,jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,jzatecc.tax_code
         ,jzatecc.base_rate
         ,flv_dfv.xx_ar_orden
         ,NVL(hca_dfv.xx_convenio_mult,'N')
         ,NVL(fnd_number.canonical_to_number(replace(jzatecc.attribute1,',','.')),avt.tax_rate)
         ,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.'))
         ,avt.tax_rate
         ,hl.address1
         ,haou.name
         ORDER BY jzatecc.start_date_active
         ,jzatecc.end_date_active
         ,haou.name;
                 
cursor c_no_ins(p_party_id NUMBER) IS
select xatlv.tax_category,jzatac.tax_attribute_name,jzatac.tax_attribute_value
from xx_ar_tax_lines_v xatlv
,(select jzatca.tax_category, jzatac.tax_attribute_name
        ,jzatac.tax_attribute_value
from jl_zz_ar_tx_att_cls_all jzatac
      ,jl_zz_ar_tx_categ_all jzatca
      where 1 = 1 
   and jzatac.tax_category_id = jzatca.tax_category_id
   and jzatac.org_id = jzatca.org_id
   and jzatac.TAX_ATTR_CLASS_CODE = 'IMPUESTOS'
   and jzatac.TAX_ATTR_CLASS_TYPE = 'CONTRIBUTOR_CLASS'
   and jzatca.tax_rule_set = 'ARGENTINA'
   and jzatca.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
   group by jzatca.tax_category, jzatac.tax_attribute_name
           ,jzatac.tax_attribute_value
  UNION ALL  
  select jzatca.tax_category, jzatca.cus_tax_attribute
        ,fnd_profile.value('XX_AR_TAX_LINES_NO_INSC')
from jl_zz_ar_tx_categ_all jzatca
      where 1 = 1 
   and jzatca.tax_rule_set = 'ARGENTINA'
   and jzatca.tax_category IN (select tax_category from xx_ar_tax_categories_v)
   and jzatca.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%')
   and not exists (select 1 from jl_zz_ar_tx_att_cls_all jzatac 
   ,jl_zz_ar_tx_categ_all jzatca2 
   where jzatac.tax_category_id = jzatca2.tax_category_id
   and jzatca.tax_category = jzatca2.tax_category
   and jzatac.TAX_ATTR_CLASS_CODE = 'IMPUESTOS'
   and jzatac.TAX_ATTR_CLASS_TYPE = 'CONTRIBUTOR_CLASS')
   group by jzatca.tax_category, jzatca.cus_tax_attribute) jzatac
where party_id = p_party_id
and classification_code is null
and xatlv.tax_category = jzatac.tax_category
and xatlv.tax_category = NVL(p_tax_category,xatlv.tax_category)
and not exists (select 1 from jl_zz_ar_tx_exc_cus_all jzatecc
                             ,jl_zz_ar_tx_categ_all   jzatca
                             ,hz_cust_acct_sites_all  hcas
                             ,hz_cust_accounts hca
                        where hca.party_id = xatlv.party_id
                          and hca.cust_account_id = hcas.cust_account_id
                          and hcas.cust_acct_site_id = jzatecc.address_id
                          and jzatca.tax_category_id = jzatecc.tax_category_id
                          and jzatca.tax_category = xatlv.tax_category) ;

CURSOR c_cm05(p_party_id NUMBER
             ,p_province_code VARCHAR2) IS
/*SELECT flv2.meaning province_name,xaacc.*
FROM xx_ar_ap_coef_cm05 xaacc
,fnd_lookup_values_vl flv2
WHERE 1 = 1
and xaacc.party_id = p_party_id
and xaacc.province_code = p_province_code
and flv2.lookup_code   = xaacc.province_code(+)
and flv2.lookup_type(+) = 'JLZZ_STATE_PROVINCE'
and flv2.start_date_active(+) <= TRUNC(sysdate)
and NVL(flv2.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
and not exists (select 1
                  from xx_ar_tax_lines_cm05 xatlc
                 where xaacc.start_date_active = xatlc.start_date
                   and xaacc.end_date_active = xatlc.end_date
                   and xaacc.coef = xatlc.coef
                   and xaacc.party_id  = xatlc.party_id)
order by xaacc.party_id,coef_id;*/
select province_code,province_name,coef,min(start_date_active) start_date_active,max(end_date_active) end_date_active
from (
SELECT xaacc.province_code, flv2.meaning province_name,xaacc.coef,xaacc.start_date_active,NVL(xaacc.end_date_active,TO_DATE('31/12/4712','DD/MM/YYYY')) end_date_active
FROM xx_ar_ap_coef_cm05 xaacc
,fnd_lookup_values_vl flv2
WHERE 1 = 1
and xaacc.party_id = p_party_id
and xaacc.province_code = p_province_code
and flv2.lookup_code   = xaacc.province_code(+)
and flv2.lookup_type(+) = 'JLZZ_STATE_PROVINCE'
and flv2.start_date_active(+) <= TRUNC(sysdate)
and NVL(flv2.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
and not exists (select 1
                  from xx_ar_tax_lines_cm05 xatlc
                 where xaacc.start_date_active = xatlc.start_date
                   and xaacc.end_date_active = xatlc.end_date
                   and xaacc.coef = xatlc.coef
                   and xaacc.party_id  = xatlc.party_id)
/*UNION ALL
select jzatca_dfv.XX_AR_PROVINCIA,flv2.meaning,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')) coef,min(jzatecc.start_date_active),MAX(jzatecc.end_date_active)
  from jl_zz_ar_tx_exc_cus_all jzatecc
      ,jl_zz_ar_tx_categ_all   jzatca
      ,jl_zz_ar_tx_categ_all_dfv jzatca_dfv
      ,hz_cust_accounts        hca
      ,hz_cust_acct_sites_all  hcas
      ,fnd_lookup_values_vl flv2
      ,hz_party_sites hps
      ,hz_locations hl
 where jzatecc.tax_category_id = jzatca.tax_category_id
   and jzatecc.org_id          = jzatca.org_id
   and jzatca.rowid            = jzatca_dfv.row_id
   and jzatecc.address_id      = hcas.cust_acct_site_id
   and hcas.cust_account_id    = hca.cust_account_id
   and hcas.party_site_id      = hps.party_site_id
   and hps.location_id         = hl.location_id
   and hca.party_id            = p_party_id
   and jzatca_dfv.XX_AR_PROVINCIA = p_province_code
   and flv2.lookup_code   = jzatca_dfv.XX_AR_PROVINCIA(+)
   and flv2.lookup_type(+) = 'JLZZ_STATE_PROVINCE'
   and ((tax_category = 'TOPSA' and jzatca_dfv.XX_AR_PROVINCIA != hl.province) OR tax_category != 'TOPSA')  
   and flv2.start_date_active(+) <= TRUNC(sysdate)
   and NVL(flv2.end_date_active(+),trunc(sysdate)) >= TRUNC(sysdate)
   and fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')) is not null
   group by jzatca_dfv.XX_AR_PROVINCIA,fnd_number.canonical_to_number(replace(jzatecc.attribute2,',','.')),flv2.meaning*/ 
   )
   group by province_code,province_name,coef
   order by 3;



e_cust_exception     EXCEPTION;
e_category_exception EXCEPTION;
e_customer_exception EXCEPTION;

v_last_class       VARCHAr2(150);
v_tax_rate         NUMBER;
v_tax_rate_tax     NUMBER;
v_porc_exempt      NUMBER;
v_count            NUMBER;
v_base_rate        NUMBER;
v_brate            NUMBER;
v_from_date        DATE;
v_last_date        DATE;
v_exists NUMBER;
v_tax_attribute_value VARCHAR2(120);
v_es_cm VARCHAR2(20);
v_tax_line_id      NUMBER;
v_tax_line_cm05_id NUMBER;
v_class_code VARCHAR2(50);

v_transaction_type VARCHAR2(1);
r_tax_lines XX_AR_TAX_LINES%ROWTYPE;
r_cm05_lines XX_AR_TAX_LINES_CM05%ROWTYPE;

r_xml xml_type;

BEGIN

   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_AR (+)');

   FOR r_cust in c_customers LOOP

    BEGIN
        print_log ('Copiando informacion impositiva del cliente: '||r_cust.party_name);
        
        r_xml := null;
        
        print_output('<G_CUST>');
        
        print_xml('PARTY_NAME',r_cust.party_name);
        print_xml('TAXPAYER_ID',r_cust.taxpayer_id);
        
        FOR r_category IN c_tax_category LOOP
        
            p_error_message := null;
        
         print_output('<G_CATEGORY>');
         
         print_xml('TAX_CATEGORY',r_category.tax_category);
         print_xml('PROVINCE',r_category.xx_ar_provincia);
         print_log('TAX CATEGORY: '||r_category.tax_category);

         BEGIN

            v_count := 0;
            v_last_class := null;
            
            FOR r_tax in c_taxes (r_cust.party_id,r_category.tax_category) LOOP
              IF NVL(v_last_class,'*') != r_tax.tax_attribute_value THEN
                v_count := v_count + 1;
                v_last_class := r_tax.tax_attribute_value;
              END IF;
            END LOOP;

            IF v_count > 1 THEN
              /*Muestro las diferencias*/
                p_error_message := 'Se encontro mas de una clasificacion para la categoria: '||r_category.tax_category||'. Cliente: '||r_cust.party_name;
                print_log('Inconsistencia de datos en el perfil de sucursal de cliente');
                print_log('*  '||RPAD(NVL('Empresa',' '),20,' ')||'  '||RPAD(NVL('Direccion',' '),20,' ')||'  '||'Valor');
                FOR r_tax in c_taxes_suc (r_cust.party_id,r_category.tax_category) LOOP
                  print_log('*  '||RPAD(NVL(r_tax.org_name,' '),20,' ')||'  '||RPAD(NVL(r_tax.address1,' '),20,' ')||'  '||r_tax.tax_attribute_value);
                END LOOP;
                RAISE e_category_exception;
              
            ELSE
            
                v_from_date := null;
                v_last_date := null;
                
                FOR r_exc in c_excs (r_cust.party_id,r_category.tax_category) LOOP
                
                  /*IF v_from_date is not null and v_last_date is not null then
                    IF (r_exc.start_date_active > v_from_date and r_exc.start_date_active <= v_last_date) OR  (r_exc.start_date_active >= v_from_date and r_exc.start_date_active < v_last_date)  THEN
                      p_error_message := 'Hay datos incosistentes en las exclusiones de la categoria';
                      --print_log('Inconsistencia de datos para Fecha inicial: '||to_char(v_from_date,'DD/MM/YYYY')|| ' y Fecha Final: '||to_char(v_last_date,'DD/MM/YYYY'));
                      print_log('Inconsistencia de datos para Fecha inicial: '||to_char(r_exc.start_date_active,'DD/MM/YYYY')|| ' y Fecha Final: '||to_char(v_last_date,'DD/MM/YYYY'));
                      print_log('*  '||RPAD('Empresa',20,' ')||'  '||RPAD('Direccion',20,' ')||'  '||'Desde     '||'  '||'Hasta     '||'  '||LPAD('Tasa Base',10,' ')||'  '||LPAD('Alicuota',10,' ')||'  '||LPAD('Coeficiente',10,' '));
                      FOR r_sup in c_taxes_sup(r_cust.party_id,r_category.tax_category,r_exc.start_date_active,v_last_date) LOOP                        
                        print_log('*  '||RPAD(NVL(r_sup.org_name,' '),20,' ')||'  '||RPAD(NVL(r_sup.address1,' '),20,' ')||'  '||to_char(r_sup.start_date_active,'DD/MM/YYYY')||'  '||to_char(r_sup.end_date_active,'DD/MM/YYYY')||'  '||LPAD(r_sup.base_rate,10,' ')||'  '||LPAD(NVL(r_sup.tax_rate,' '),10,' ')||'  '||LPAD(NVL(TO_CHAR(r_sup.coef),' '),10,' '));
                      END LOOP;
                      print_log('');
                    ELSE
                      v_last_date := r_exc.end_date_active;
                    END IF;
                  ELSE
                     v_from_date := r_exc.start_date_active;
                     v_last_date := r_exc.end_date_active;
                  end if;*/
                  
                  IF v_from_date is null and v_last_date is null then
                     v_from_date := r_exc.start_date_active;
                     v_last_date := r_exc.end_date_active;
                  ELSE
                     v_last_date := r_exc.end_date_active;
                  END IF;
                  
                  v_count := 0;
                  
                  --FOR r_sup in c_taxes_sup(r_cust.party_id,r_category.tax_category,r_exc.start_date_active,v_last_date,r_exc.base_rate,r_exc.tax_rate,r_exc.coef) LOOP
                  FOR r_sup in c_taxes_sup(r_cust.party_id,r_category.tax_category,r_exc.start_date_active,v_last_date,r_exc.base_rate,r_exc.tax_rate,r_exc.coef) LOOP
                      v_count := v_count + 1;
                  END LOOP;
                  
                  IF v_count > 0 THEN
                    p_error_message := 'Hay datos inconsistentes en las exclusiones de la categoria';
                    print_log('Inconsistencia de datos para Fecha inicial: '||to_char(r_exc.start_date_active,'DD/MM/YYYY')|| ', Fecha Final: '||to_char(v_last_date,'DD/MM/YYYY')||' Tasa base: '||r_exc.base_rate||' Alicuota: '||r_exc.tax_rate||' Coeficiente: '||r_exc.coef);
                    print_log('*  '||RPAD('Empresa',20,' ')||'  '||RPAD('Direccion',20,' ')||'  '||'Desde     '||'  '||'Hasta     '||'  '||LPAD('Tasa Base',10,' ')||'  '||LPAD('Alicuota',10,' ')||'  '||LPAD('Coeficiente',10,' '));
                    --FOR r_sup in c_taxes_sup(r_cust.party_id,r_category.tax_category,r_exc.start_date_active,v_last_date,r_exc.base_rate,r_exc.tax_rate,r_exc.coef) LOOP
                    FOR r_sup in c_taxes_sup(r_cust.party_id,r_category.tax_category,r_exc.start_date_active,v_last_date,r_exc.base_rate,r_exc.tax_rate,r_exc.coef) LOOP
                        print_log('*  '||RPAD(NVL(r_sup.org_name,' '),20,' ')||'  '||RPAD(NVL(r_sup.address1,' '),20,' ')||'  '||to_char(r_sup.start_date_active,'DD/MM/YYYY')||'  '||to_char(r_sup.end_date_active,'DD/MM/YYYY')||'  '||LPAD(TO_CHAR(r_sup.base_rate),10,' ')||'  '||LPAD(NVL(TO_CHAR(r_sup.tax_rate),' '),10,' ')||'  '||LPAD(NVL(TO_CHAR(r_sup.coef),' '),10,' '));
                    END LOOP;
                    RAISE e_category_exception;
                  END IF;
                END LOOP;
                /*
                IF p_error_message is not null then
                  RAISE e_category_exception;
                END IF;*/
                
                v_from_date := null;
                v_last_date := null;
                v_tax_attribute_value := NULL;
                
                FOR r_tax in c_taxes (r_cust.party_id,r_category.tax_category) LOOP
                
                  /*Si la categoria VAT es CONS FINAL o EXPORTACION no debe aplicar otra categoria*/
                  IF r_category.tax_category != 'VAT' THEN
                      BEGIN
                        SELECT COUNT(1)
                          INTO v_exists
                          FROM xx_ar_tax_lines
                         where party_id = r_cust.party_id
                           and tax_category = 'VAT'
                           and classification_code IN ('END CONSUMER','EXPORTACION');
                      EXCEPTION
                        WHEN OTHERS THEN 
                         v_exists := 0;
                      END;
                      
                      IF v_exists > 0 THEN
                       r_xml.contributor_class := null;
                       print_log('El cliente es de exportacion o consumidor final');
                       CONTINUE;
                      ELSE
                         FOR r_tax3 in c_taxes_vat (r_cust.party_id) loop
                            if r_tax3.TAX_ATTRIBUTE_VALUE IN ('END CONSUMER','EXPORTACION') THEN
                             v_exists := 1;
                             EXIT;
                            END IF;
                         END LOOP;
                         IF v_exists = 1 THEN
                          r_xml.contributor_class := null;
                          print_log('El cliente es de exportacion o consumidor final');
                          CONTINUE;
                         END IF; 
                      END IF;
                      
                  END IF;
                
                  v_last_date := r_tax.end_date;
                  v_tax_attribute_value := null;
                  
                  IF r_tax.xx_ar_provincia is not null then
                  
                    BEGIN

                         select avt.tax_rate
                           into v_tax_rate_tax
                           from jl_zz_ar_tx_groups_all gr
                               ,jl_zz_ar_tx_categ_all jzatca
                               ,ar_vat_tax_all avt
                          where gr.tax_category_id = jzatca.tax_category_id
                            and gr.org_id = jzatca.org_id
                            and gr.org_id = avt.org_id
                            and gr.tax_code = avt.tax_code
                            and jzatca.tax_category = r_category.tax_category
                            and gr.contributor_type = r_tax.tax_attribute_value
                            and gr.start_date_active <= TRUNC(SYSDATE)
                            and gr.end_date_active >= TRUNC(SYSDATE)
                       group by avt.tax_rate;

                    EXCEPTION
                      WHEN OTHERS THEN
                        print_log('Error al obtener alicuota. Categoria: '||r_category.tax_category||' Error: '||SQLERRM);
                        v_tax_rate_tax := 0;
                    END;
                  ELSE
                     v_tax_rate_tax := null;
                  END IF;
                     
                 FOR r_exc in c_excs (r_cust.party_id,r_category.tax_category) LOOP
                   
                   r_xml := null;
                   
                   /*Obtengo el verdadero tax_attribute_value desde la exencion*/
                   IF r_tax.tax_attribute_value IN ('MONOTRIBUTISTA','MT C/RIESGO') THEN
                     v_tax_attribute_value := r_tax.tax_attribute_value;
                   ELSE
                       BEGIN

                             select gr.contributor_type
                               into v_tax_attribute_value
                               from jl_zz_ar_tx_groups_all gr
                                   ,jl_zz_ar_tx_categ_all jzatca
                                   ,ar_vat_tax_all avt
                              where gr.tax_category_id = jzatca.tax_category_id
                                and gr.org_id = jzatca.org_id
                                and gr.org_id = avt.org_id
                                and gr.tax_code = avt.tax_code
                                and jzatca.tax_category = r_category.tax_category
                                and avt.tax_code = r_exc.tax_code
                                and gr.start_date_active <= TRUNC(SYSDATE)
                                and gr.end_date_active >= TRUNC(SYSDATE)
                                and gr.contributor_type NOT IN ('DEFAULT','MT C/RIESGO','MONOTRIBUTISTA')
                           group by gr.contributor_type;

                        EXCEPTION
                          WHEN TOO_MANY_ROWS THEN
                          
                              BEGIN
                                select NVL(hca_dfv.XX_CONVENIO_MULT,'N')
                                  into v_es_cm
                                  from hz_cust_accounts hca
                                      ,hz_cust_accounts_dfv hca_dfv
                                 where hca.party_id = r_cust.party_id
                                   and hca.rowid = hca_dfv.row_id
                              group by hca_dfv.XX_CONVENIO_MULT;
                              EXCEPTION
                               WHEN OTHERS THEN
                                 v_es_cm := 'N';
                              END;
                              
                              IF v_es_cm = 'Y' THEN
                              
                                    BEGIN
                                          select gr.contributor_type
                                           into v_tax_attribute_value
                                           from jl_zz_ar_tx_groups_all gr
                                               ,jl_zz_ar_tx_categ_all jzatca
                                               ,ar_vat_tax_all avt
                                          where gr.tax_category_id = jzatca.tax_category_id
                                            and gr.org_id = jzatca.org_id
                                            and gr.org_id = avt.org_id
                                            and gr.tax_code = avt.tax_code
                                            and jzatca.tax_category = r_category.tax_category
                                            and avt.tax_code = r_exc.tax_code
                                            and gr.start_date_active <= TRUNC(SYSDATE)
                                            and gr.end_date_active >= TRUNC(SYSDATE)
                                            and gr.contributor_type IN ('CONV MULTILATERAL','CM CON RIESGO')
                                       group by gr.contributor_type;
                                   EXCEPTION
                                   WHEN OTHERS THEN 
                                   v_tax_attribute_value := r_tax.tax_attribute_value;
                                   END;
                              ELSE
                                   BEGIN
                                      select gr.contributor_type
                                       into v_tax_attribute_value
                                       from jl_zz_ar_tx_groups_all gr
                                           ,jl_zz_ar_tx_categ_all jzatca
                                           ,ar_vat_tax_all avt
                                      where gr.tax_category_id = jzatca.tax_category_id
                                        and gr.org_id = jzatca.org_id
                                        and gr.org_id = avt.org_id
                                        and gr.tax_code = avt.tax_code
                                        and jzatca.tax_category = r_category.tax_category
                                        and avt.tax_code = r_exc.tax_code
                                        and gr.start_date_active <= TRUNC(SYSDATE)
                                        and gr.end_date_active >= TRUNC(SYSDATE)
                                        and gr.contributor_type IN ('LOCAL CON RIESGO','LOCAL')
                                   group by gr.contributor_type;
                                   EXCEPTION
                                   WHEN OTHERS THEN 
                                   v_tax_attribute_value := r_tax.tax_attribute_value;
                                   END;
                              
                              END IF;
                               
                          WHEN OTHERS THEN
                            v_tax_attribute_value := r_tax.tax_attribute_value;
                        END;
                        
                        IF v_tax_attribute_value IS NULL THEN
                          v_tax_attribute_value := r_tax.tax_attribute_value;
                        END IF;
                        
                   END IF;
                   
                   IF NVL(v_tax_attribute_value,'*') != NVL(r_tax.tax_attribute_value,'*') THEN
                   
                    IF r_tax.xx_ar_provincia is not null then
                        BEGIN

                             select avt.tax_rate
                               into v_tax_rate
                               from jl_zz_ar_tx_groups_all gr
                                   ,jl_zz_ar_tx_categ_all jzatca
                                   ,ar_vat_tax_all avt
                              where gr.tax_category_id = jzatca.tax_category_id
                                and gr.org_id = jzatca.org_id
                                and gr.org_id = avt.org_id
                                and gr.tax_code = avt.tax_code
                                and jzatca.tax_category = r_category.tax_category
                                and gr.contributor_type = v_tax_attribute_value
                                and gr.start_date_active <= TRUNC(SYSDATE)
                                and gr.end_date_active >= TRUNC(SYSDATE)
                           group by avt.tax_rate;

                        EXCEPTION
                          WHEN OTHERS THEN
                            print_log('Error al obtener alicuota. Categoria: '||r_category.tax_category||' Error: '||SQLERRM);
                            v_tax_rate := 0;
                        END;
                    ELSE
                         v_tax_rate := null;
                    END IF;
                   
                   END IF;
                   
                   v_tax_rate := r_exc.tax_rate;
                   
                   IF v_tax_rate is null then
                      IF r_tax.xx_ar_provincia is null then
                         v_tax_rate := null;
                      else
                         v_tax_rate := v_tax_rate_tax;
                      END IF;
                   END IF;
                   
                   r_xml.tax_rate := replace(to_char(v_tax_rate),',','.');
                   
                    v_base_rate := NVL(r_exc.base_rate,0);
                    
                    IF r_category.tax_category NOT IN ('TOPSA','TOPTU') and NVL(r_exc.base_rate,0) != 0 THEN
                       v_porc_exempt := 100 + NVL(r_exc.base_rate,0);
                    ELSE
                       v_porc_exempt := 0; 
                    END IF;
                    
                    IF r_exc.base_rate = -100 THEN 
                         v_porc_exempt := 100;
                         v_base_rate := -100;
                    END IF;
                    
                   IF NVL(v_from_date+1,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) < r_exc.start_date_active AND v_from_date is not null THEN
                   
                         BEGIN
                          SELECT tax_line_id
                            INTO v_tax_line_id
                            FROM xx_ar_tax_lines
                            where party_id = r_cust.party_id 
                              AND tax_category = r_exc.tax_category
                              AND start_date = NVL(v_from_date+1,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY')))
                              AND end_date = r_exc.end_date_active-1;  
                         EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                             v_tax_line_id := 0;
                           WHEN OTHERS THEN 
                             v_tax_line_id := 0;
                         END;
                         
                         IF v_tax_line_id = 0 THEN 
                   
                              SELECT xx_ar_tax_lines_s.nextval
                                INTO r_tax_lines.tax_line_id
                                FROM dual;

                              r_tax_lines.party_id            := r_cust.party_id;
                              r_tax_lines.party_name          := r_cust.party_name;
                              r_tax_lines.taxpayer_id         := r_cust.taxpayer_id;
                              r_tax_lines.tax_category        := r_category.tax_category;
                              r_tax_lines.start_date          := NVL(v_from_date+1,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY')));
                              r_tax_lines.end_date            := r_exc.start_date_active-1;
                              r_tax_lines.classification_code := v_tax_attribute_value;
                              r_tax_lines.tax_rate            := v_tax_rate;
                              r_tax_lines.coefficient         := null;
                              r_tax_lines.porc_exempt         := 0;
                              r_tax_lines.base_rate           := 0;
                              r_tax_lines.request_id          := fnd_global.conc_request_id;
                              r_tax_lines.status              := 'P';

                              IF NOT insert_tax_lines (r_tax_lines) THEN
                                p_error_message := 'Error al insertar en XX_AR_TAX_LINES.';
                                RAISE e_category_exception;
                              END IF;
                              
                              r_xml.date_from := to_char(NVL(v_from_date+1,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) ,'DD/MM/YYYY');
                              r_xml.date_to := to_char(r_exc.start_date_active-1,'DD/MM/YYYY');
                              r_xml.contributor_class := r_tax_lines.classification_code;
                              r_xml.coeficiente := null;
                              r_xml.porc_exempt := 0;
                              r_xml.base_rate := replace(to_char(0),',','.');
                              r_xml.message := 'Aplicado';
                          
                         END IF;
                          
                          v_from_date := r_exc.start_date_active;
                          
                   END IF;
                   
                   IF v_from_date is null or v_from_date + 1 >= r_exc.start_date_active THEN
                   
                     /*Busco si ya existe en AR Tax este registro*/
                     BEGIN
                      SELECT tax_line_id
                        INTO v_tax_line_id
                        FROM xx_ar_tax_lines
                        where party_id = r_cust.party_id 
                          AND tax_category = r_exc.tax_category
                          AND start_date <= r_exc.start_date_active
                          AND end_date = r_exc.end_date_active
                          AND NVL(tax_rate,0) = NVL(v_tax_rate,0)
                          and NVL(coefficient,0) = NVL(r_exc.coef,0)
                          and NVL(porc_exempt,0) = NVL(v_porc_exempt,0)
                          and NVL(base_rate,0) = NVL(v_base_rate,0);  
                     EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                         v_tax_line_id := 0;
                       WHEN OTHERS THEN 
                         v_tax_line_id := 0;
                     END;
                     
                     IF v_tax_line_id = 0 THEN
                     
                         BEGIN
                          SELECT tax_line_id
                            INTO v_tax_line_id
                            FROM xx_ar_tax_lines
                            where party_id = r_cust.party_id 
                              AND tax_category = r_exc.tax_category
                              AND start_date <= r_exc.start_date_active
                              AND end_date = r_exc.end_date_active
                              AND (NVL(tax_rate,0) != NVL(v_tax_rate,0)
                              OR NVL(coefficient,0) != NVL(r_exc.coef,0)
                              OR NVL(porc_exempt,0) != NVL(v_porc_exempt,0)
                              OR NVL(base_rate,0) != NVL(v_base_rate,0));  
                         EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                             v_tax_line_id := 0;
                           WHEN OTHERS THEN 
                             v_tax_line_id := 0;
                         END;
                         
                         IF v_tax_line_id = 0 THEN
                     
                              SELECT xx_ar_tax_lines_s.nextval
                                INTO r_tax_lines.tax_line_id
                                FROM dual;
                                
                              r_tax_lines.party_id            := r_cust.party_id;
                              r_tax_lines.party_name          := r_cust.party_name;
                              r_tax_lines.taxpayer_id         := r_cust.taxpayer_id;
                              r_tax_lines.tax_category        := r_category.tax_category;
                              r_tax_lines.start_date          := r_exc.start_date_active;
                              r_tax_lines.end_date            := r_exc.end_date_active;
                              r_tax_lines.classification_code := v_tax_attribute_value;
                              r_tax_lines.tax_rate            := v_tax_rate;
                              r_tax_lines.coefficient         := r_exc.coef;
                              r_tax_lines.porc_exempt         := v_porc_exempt;
                              r_tax_lines.base_rate           := v_base_rate;
                              r_tax_lines.request_id          := fnd_global.conc_request_id;
                              r_tax_lines.status              := 'P';
                              
                              IF NOT insert_tax_lines (r_tax_lines) THEN
                                p_error_message := 'Error al insertar en XX_AR_TAX_LINES.';
                                RAISE e_category_exception;
                              END IF;
                          
                         ELSE
                         
                            UPDATE xx_ar_tax_lines
                            SET tax_rate = NVL(v_tax_rate,0)
                            ,coefficient = NVL(r_exc.coef,0)
                            ,porc_exempt = NVL(v_porc_exempt,0)
                            ,base_rate = NVL(v_base_rate,0)
                            where tax_line_id = v_tax_line_id;  
                          
                         END IF;
                          
                           IF r_category.tax_category = 'TOPSA' and NVL(r_exc.coef,-1) = 1 THEN
                              
                                BEGIN
                                  SELECT tax_line_cm05_id
                                    INTO v_tax_line_cm05_id
                                    FROM xx_ar_tax_lines_cm05
                                   WHERE party_id = r_cust.party_id
                                     AND province_code = r_tax.xx_ar_provincia
                                     AND NVL(start_date,TRUNC(SYSDATE)) = r_exc.start_date_active
                                     AND NVL(end_date,to_date('31-12-4712','DD-MM-YYYY')) = r_exc.end_date_active
                                     AND coef = NVL(r_exc.coef,1);
                                EXCEPTION
                                 WHEN OTHERS THEN
                                   v_tax_line_cm05_id := 0;
                                END;
                                
                                IF v_tax_line_cm05_id = 0 THEN
                                   r_cm05_lines := null;

                                   r_cm05_lines.taxpayer_id   := r_cust.taxpayer_id;
                                   r_cm05_lines.party_id      := r_cust.party_id;
                                   r_cm05_lines.province_code := r_tax.xx_ar_provincia;
                                   r_cm05_lines.start_date    := r_exc.start_date_active;
                                   r_cm05_lines.end_date      := r_exc.end_date_active;
                                   r_cm05_lines.coef          := NVL(r_exc.coef,1);
                                   r_cm05_lines.request_id    := fnd_global.conc_request_id;
                                   r_cm05_lines.status        := 'P';

                                   SELECT xx_ar_tax_lines_cm05_s.nextval
                                   INTO r_cm05_lines.tax_line_cm05_id
                                   FROM dual;

                                   IF NOT insert_cm05 (r_cm05_lines) THEN
                                     p_error_message := 'Error al insertar en XX_AR_TAX_LINES_CM05.';
                                     RAISE e_category_exception;
                                   END IF;
                                END IF;
                              
                           END IF;
                          
                          r_xml.date_from := to_char(r_exc.start_date_active,'DD/MM/YYYY');
                          r_xml.date_to := to_char(r_exc.end_date_active,'DD/MM/YYYY');
                          r_xml.contributor_class :=v_tax_attribute_value;
                          r_xml.coeficiente := replace(to_char(r_exc.coef),',','.');
                          r_xml.porc_exempt := replace(to_char(v_porc_exempt),',','.');
                          r_xml.base_rate := replace(to_char(v_base_rate),',','.');
                          r_xml.message := 'Aplicado';

                          v_from_date := r_exc.end_date_active;
                     
                     ELSE
                     
                        BEGIN
                            SELECT *
                              into r_tax_lines
                              from xx_ar_tax_lines
                              where tax_line_id = v_tax_line_id;
                        EXCEPTION
                        WHEN OTHERS THEN
                          p_error_message := 'Error al obtener los datos de AR TAX para actualizar. Tax_line_id: '||v_tax_line_id;
                          RAISE e_category_exception;
                        END;
                        
                        IF  v_tax_attribute_value != r_tax_lines.classification_code
                         OR NVL(v_tax_rate,0) != NVL(r_tax_lines.tax_rate,0)
                         OR NVL(r_exc.coef,0) != NVL(r_tax_lines.coefficient,0)
                         OR NVL(r_exc.base_rate,0) != NVL(r_tax_lines.base_rate,0) THEN
                              --
                               UPDATE xx_ar_tax_lines
                                 SET classification_code = v_tax_attribute_value
                                    ,tax_rate    = v_tax_rate
                                    ,coefficient = r_exc.coef
                                    ,base_rate   = r_exc.base_rate
                                    ,last_update_date = sysdate
                                    ,last_updated_by =  fnd_global.user_id
                                    ,last_update_login = fnd_global.login_id
                                    ,request_id = fnd_global.conc_request_id
                               where tax_line_id = r_tax_lines.tax_line_id;
                               
                               IF r_category.tax_category = 'TOPSA' and NVL(r_exc.coef,-1) = 1 THEN
                                                             
                                BEGIN
                                  SELECT tax_line_cm05_id
                                    INTO v_tax_line_cm05_id
                                    FROM xx_ar_tax_lines_cm05
                                   WHERE party_id = r_cust.party_id
                                     AND province_code = r_tax.xx_ar_provincia
                                     AND NVL(start_date,TRUNC(SYSDATE)) = r_exc.start_date_active
                                     AND NVL(end_date,to_date('31-12-4712','DD-MM-YYYY')) = r_exc.end_date_active
                                     AND coef = NVL(r_exc.coef,1);
                                EXCEPTION
                                 WHEN OTHERS THEN
                                   v_tax_line_cm05_id := 0;
                                END;
                                
                                IF v_tax_line_cm05_id = 0 THEN
                                   r_cm05_lines := null;

                                   r_cm05_lines.taxpayer_id   := r_cust.taxpayer_id;
                                   r_cm05_lines.party_id      := r_cust.party_id;
                                   r_cm05_lines.province_code := r_tax.xx_ar_provincia;
                                   r_cm05_lines.start_date    := r_exc.start_date_active;
                                   r_cm05_lines.end_date      := r_exc.end_date_active;
                                   r_cm05_lines.coef          := NVL(r_exc.coef,1);
                                   r_cm05_lines.request_id    := fnd_global.conc_request_id;
                                   r_cm05_lines.status        := 'P';

                                   SELECT xx_ar_tax_lines_cm05_s.nextval
                                   INTO r_cm05_lines.tax_line_cm05_id
                                   FROM dual;

                                   IF NOT insert_cm05 (r_cm05_lines) THEN
                                     p_error_message := 'Error al insertar en XX_AR_TAX_LINES_CM05.';
                                     RAISE e_category_exception;
                                   END IF;
                                END IF;
                              
                               END IF;
                               
                               r_xml.date_from := to_char(r_exc.start_date_active,'DD/MM/YYYY');
                               r_xml.date_to := to_char(r_exc.end_date_active,'DD/MM/YYYY');
                               r_xml.contributor_class := v_tax_attribute_value;
                               r_xml.coeficiente := replace(to_char(r_exc.coef),',','.');
                               r_xml.porc_exempt := replace(to_char(r_tax_lines.porc_exempt),',','.');
                               r_xml.base_rate := replace(to_char(r_exc.base_rate),',','.');
                               r_xml.message := 'Actualizado';

                        ELSE
                               
                               r_xml.contributor_class := null;
                               print_log('No es Necesario actualizar');
                        END IF;
                        
                        v_from_date := r_exc.end_date_active;
                        
                     END IF;
                     
                   END IF;
                   
                   print_xml_jl_output(r_xml);
                   
                   COMMIT;
                   
                 END LOOP;
                 
                 /*Completo hasta el ultimo dia*/
                 IF NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) < v_last_date and v_last_date is not null and v_from_date is not null THEN                 
                     /*Busco si ya existe en AR Tax este registro*/
                     
                     BEGIN
                      SELECT tax_line_id
                        INTO v_tax_line_id
                        FROM xx_ar_tax_lines
                        where party_id = r_cust.party_id 
                          AND tax_category = r_category.tax_category
                          AND start_date <= NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) +1
                          AND end_date = v_last_date
                          and tax_rate    = v_tax_rate_tax
                          and coefficient = null
                          and porc_exempt = 0
                          and base_rate   = 0;  
                     EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                         v_tax_line_id := 0;
                       WHEN OTHERS THEN 
                         v_tax_line_id := 0;
                     END;
                     
                     IF v_tax_line_id = 0 THEN
                     
                         BEGIN
                          SELECT tax_line_id
                            INTO v_tax_line_id
                            FROM xx_ar_tax_lines
                            where party_id = r_cust.party_id 
                              AND tax_category = r_category.tax_category
                              AND start_date <= NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) +1
                              AND end_date = v_last_date;  
                         EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                             v_tax_line_id := 0;
                           WHEN OTHERS THEN 
                             v_tax_line_id := 0;
                         END;
                     
                         IF v_tax_line_id = 0 THEN
                     
                              SELECT xx_ar_tax_lines_s.nextval
                                INTO r_tax_lines.tax_line_id
                                FROM dual;

                              r_tax_lines.party_id            := r_cust.party_id;
                              r_tax_lines.party_name          := r_cust.party_name;
                              r_tax_lines.taxpayer_id         := r_cust.taxpayer_id;
                              r_tax_lines.tax_category        := r_category.tax_category;
                              r_tax_lines.start_date          := NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) +1;
                              r_tax_lines.end_date            := v_last_date;
                              --r_tax_lines.classification_code := NVL(v_tax_attribute_value,r_tax.tax_attribute_value);
                              r_tax_lines.classification_code := r_tax.tax_attribute_value;
                              r_tax_lines.tax_rate            := v_tax_rate_tax;
                              r_tax_lines.coefficient         := null;
                              r_tax_lines.porc_exempt         := 0;
                              r_tax_lines.base_rate           := 0;
                              r_tax_lines.request_id          := fnd_global.conc_request_id;
                              r_tax_lines.status              := 'P';

                              IF NOT insert_tax_lines (r_tax_lines) THEN
                                p_error_message := 'Error al insertar en XX_AR_TAX_LINES.';
                                RAISE e_category_exception;
                              END IF;
                              
                              r_xml.date_from := to_char(v_from_date+1,'DD/MM/YYYY');
                              r_xml.date_to := to_char(v_last_date,'DD/MM/YYYY');
                              r_xml.contributor_class := r_tax.tax_attribute_value;
                              r_xml.coeficiente := null;
                              r_xml.porc_exempt := 0;
                              r_xml.base_rate := '0';
                              r_xml.message := 'Aplicado';
                              
                              print_xml_jl_output(r_xml);
                        
                              COMMIT;
                         ELSE
                            UPDATE xx_ar_tax_lines
                               set tax_rate    = v_tax_rate_tax
                                  ,coefficient = null
                                  ,porc_exempt = 0
                                  ,base_rate   = 0
                            where tax_line_id = v_tax_line_id;
                            
                              r_xml.date_from := to_char(v_from_date+1,'DD/MM/YYYY');
                              r_xml.date_to := to_char(v_last_date,'DD/MM/YYYY');
                              r_xml.contributor_class := r_tax.tax_attribute_value;
                              r_xml.coeficiente := null;
                              r_xml.porc_exempt := 0;
                              r_xml.base_rate := '0';
                              r_xml.message := 'Actualizado';
                              
                              print_xml_jl_output(r_xml);
                              
                         END IF;
                         
                     END IF;
                          
                 ELSIF NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) >= v_last_date and v_last_date is not null THEN
                    null;
                 ELSE
                    /*Busco si ya existe en AR Tax este registro*/
                     BEGIN
                      SELECT tax_line_id
                        INTO v_tax_line_id
                        FROM xx_ar_tax_lines
                        where party_id = r_cust.party_id 
                          AND tax_category = r_category.tax_category
                          AND start_date <= NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY')))
                          AND end_date = v_last_date;  
                     EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                         v_tax_line_id := 0;
                       WHEN OTHERS THEN 
                         v_tax_line_id := 0;
                     END;
                     
                     IF v_tax_line_id = 0 THEN
                                    
                       SELECT xx_ar_tax_lines_s.nextval
                                INTO r_tax_lines.tax_line_id
                                FROM dual;

                              r_tax_lines.party_id            := r_cust.party_id;
                              r_tax_lines.party_name          := r_cust.party_name;
                              r_tax_lines.taxpayer_id         := r_cust.taxpayer_id;
                              r_tax_lines.tax_category        := r_category.tax_category;
                              r_tax_lines.start_date          := NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) ;
                              r_tax_lines.end_date            := v_last_date;
                              r_tax_lines.classification_code := NVL(v_tax_attribute_value,r_tax.tax_attribute_value);
                              r_tax_lines.tax_rate            := v_tax_rate_tax;
                              r_tax_lines.coefficient         := null;
                              r_tax_lines.porc_exempt         := 0;
                              r_tax_lines.base_rate           := 0;
                              r_tax_lines.request_id          := fnd_global.conc_request_id;
                              r_tax_lines.status              := 'P';

                              IF NOT insert_tax_lines (r_tax_lines) THEN
                                p_error_message := 'Error al insertar en XX_AR_TAX_LINES.';
                                RAISE e_category_exception;
                              END IF;
                              
                              r_xml.date_from := to_char(NVL(v_from_date,TRUNC(TO_DATE(TO_CHAR(trunc(sysdate),'MM/YYYY'),'MM/YYYY'))) ,'DD/MM/YYYY');
                              r_xml.date_to := to_char(v_last_date,'DD/MM/YYYY');
                              r_xml.contributor_class := NVL(v_tax_attribute_value,r_tax.tax_attribute_value);
                              r_xml.coeficiente := null;
                              r_xml.porc_exempt := '0';
                              r_xml.base_rate := '0';
                              r_xml.message := 'Aplicado';
                              
                              print_xml_jl_output(r_xml);
                        
                              COMMIT;
                              
                     END IF;
                     
                 END IF;
                 
                END LOOP;
            
            END IF;
                
            
            IF r_category.XX_AR_COEF_CM05 = 'Y' THEN
            
                print_log('Procesando CM05');

                FOR r_cm05 IN c_cm05(r_cust.party_id,r_category.xx_ar_provincia) LOOP
                
                    print_log('Desde: '||r_cm05.start_date_active);
                    print_log('Hasta: '||r_cm05.end_date_active);
                
                    print_output('<G_CM05>');
                    
                    print_xml('PROVINCE_NAME',r_cm05.province_name);
                    print_xml('PARTY_NAME',r_cust.party_name);   
                    
                    BEGIN
                      SELECT tax_line_cm05_id
                        INTO v_tax_line_cm05_id
                        FROM xx_ar_tax_lines_cm05
                       WHERE party_id = r_cust.party_id
                         AND province_code = r_cm05.province_code
                         AND NVL(start_date,TRUNC(SYSDATE)) = NVL(r_cm05.start_date_active,TRUNC(SYSDATE))
                         AND NVL(end_date,to_date('31/12/4712','DD/MM/YYYY')) = NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY'))                         
                         AND coef = r_cm05.coef;
                    EXCEPTION
                     WHEN OTHERS THEN
                       v_tax_line_cm05_id := 0;
                    END;
                    
                    print_log('v_tax_line_cm05_id: '||v_tax_line_cm05_id);
                    
                    
                    IF v_tax_line_cm05_id = 0 THEN
                    
                        BEGIN
                        
                          SELECT tax_line_cm05_id
                            INTO v_tax_line_cm05_id
                            FROM xx_ar_tax_lines_cm05
                           WHERE party_id = r_cust.party_id
                             AND province_code = r_cm05.province_code
                             AND NVL(start_date,TRUNC(SYSDATE)) = NVL(r_cm05.start_date_active,TRUNC(SYSDATE))
                             AND NVL(end_date,to_date('31/12/4712','DD/MM/YYYY')) = NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY'))
                             AND coef != r_cm05.coef;
                             
                        EXCEPTION
                         WHEN OTHERS THEN
                           v_tax_line_cm05_id := 0;
                        END;
                        
                        IF v_tax_line_cm05_id != 0 THEN
                        
                          UPDATE xx_ar_tax_lines_cm05
                             SET coef = r_cm05.coef
                                ,last_update_date = sysdate
                                ,last_updated_by = fnd_global.user_id
                                ,last_update_login = fnd_global.login_id
                           WHERE party_id = r_cust.party_id
                             AND province_code = r_cm05.province_code
                             AND NVL(start_date,TRUNC(SYSDATE)) = NVL(r_cm05.start_date_active,TRUNC(SYSDATE))
                             AND NVL(end_date,to_date('31/12/4712','DD/MM/YYYY')) = NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY'));
                             
                             print_xml('START_DATE',to_char(NVL(r_cm05.start_date_active,TRUNC(SYSDATE)),'DD/MM/YYYY'));
                             print_xml('END_DATE',to_char(NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY')),'DD/MM/YYYY'));
                             print_xml('COEF',replace(to_char(r_cm05.coef),',','.'));
                             print_xml('ERROR_MESSAGE','Actualizado');
                             
                        ELSE

                           r_cm05_lines := null;

                           r_cm05_lines.taxpayer_id   := r_cust.taxpayer_id;
                           r_cm05_lines.party_id      := r_cust.party_id;
                           r_cm05_lines.province_code := r_cm05.province_code;
                           r_cm05_lines.start_date    := r_cm05.start_date_active;
                           r_cm05_lines.end_date      := NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY'));
                           r_cm05_lines.coef          := r_cm05.coef;
                           r_cm05_lines.request_id    := fnd_global.conc_request_id;
                           r_cm05_lines.status        := 'P';

                           SELECT xx_ar_tax_lines_cm05_s.nextval
                           INTO r_cm05_lines.tax_line_cm05_id
                           FROM dual;

                           IF NOT insert_cm05 (r_cm05_lines) THEN
                             p_error_message := 'Error al insertar en XX_AR_TAX_LINES_CM05.';
                             RAISE e_category_exception;
                           END IF;
                           
                           print_xml('START_DATE',to_char(r_cm05.start_date_active,'DD/MM/YYYY'));
                           print_xml('END_DATE',to_char(NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY')),'DD/MM/YYYY'));
                           print_xml('COEF',replace(to_char(r_cm05.coef),',','.'));
                           print_xml('ERROR_MESSAGE','Aplicado');
                           
                        END IF;
                    ELSE
                      print_xml('START_DATE',to_char(NVL(r_cm05.start_date_active,TRUNC(SYSDATE)),'DD/MM/YYYY'));
                      print_xml('END_DATE',to_char(NVL(r_cm05.end_date_active,to_date('31/12/4712','DD/MM/YYYY')),'DD/MM/YYYY'));
                      print_xml('COEF',replace(to_char(r_cm05.coef),',','.'));
                      print_xml('ERROR_MESSAGE','No es necesario actualizar');
                    END IF;
                    
                    print_output('</G_CM05>');       

                END LOOP;
            
            END IF;

         EXCEPTION
           WHEN e_category_exception THEN
             print_log(p_error_message);
             print_log('');
             print_xml('ERROR_MESSAGE',p_error_message);
             p_status := 'W';
           WHEN OTHERS THEN
             p_error_message := 'Error OTHERS al procesar la categoria: '||r_category.tax_category||'.Error: '||sqlerrm;
             print_log(p_error_message);
             print_log('');
             print_xml('ERROR_MESSAGE',p_error_message);
             p_status := 'W';
         END;
         
         print_output('</G_CATEGORY>');

        END LOOP;
        
        commit;
        
        print_log('Insertando No Inscriptos');
        
        BEGIN
         select CLASSIFICATION_CODE
         into v_class_code
         from xx_ar_tax_lines_v
         where tax_category = 'VAT'
         and party_id = r_cust.party_id;
        EXCEPTION
          WHEN OTHERS THEN
           v_class_code := 'INSCRIPTO';
        END;
        
        --IF r_cust.origin = 'DOMESTIC_ORIGIN' THEN
        IF v_class_code NOT IN('EXPORTACION','END CONSUMER') THEN
        
            FOR r_no_ins IN c_no_ins(r_cust.party_id) LOOP
                
                IF r_no_ins.TAX_ATTRIBUTE_VALUE is not null then
                
                    print_output('<G_CATEGORY>');
                         
                    print_xml('TAX_CATEGORY',r_no_ins.tax_category);
                    print_log('TAX_CATEGORY: '||r_no_ins.tax_category);
                         
                    --print_output('<G_TAX>');
                    r_xml := null;
                
                     r_tax_lines := null;

                     SELECT xx_ar_tax_lines_s.nextval
                      into r_tax_lines.tax_line_id
                      from dual;
                      
                      v_tax_rate:= null;
                      
                      BEGIN

                         select avt.tax_rate
                           into v_tax_rate
                           from jl_zz_ar_tx_groups_all gr
                               ,jl_zz_ar_tx_categ_all jzatca
                               ,ar_vat_tax_all avt
                          where gr.tax_category_id = jzatca.tax_category_id
                            and gr.org_id = jzatca.org_id
                            and gr.org_id = avt.org_id
                            and gr.tax_code = avt.tax_code
                            and jzatca.tax_category = r_no_ins.tax_category
                            and gr.contributor_type = r_no_ins.TAX_ATTRIBUTE_VALUE
                            and gr.start_date_active <= TRUNC(SYSDATE)
                            and gr.end_date_active >= TRUNC(SYSDATE)
                       group by avt.tax_rate;

                     EXCEPTION
                      WHEN OTHERS THEN
                        v_tax_rate := 0;
                     END;

                      r_tax_lines.party_id            := r_cust.party_id;
                      r_tax_lines.party_name          := r_cust.party_name;
                      r_tax_lines.taxpayer_id         := r_cust.taxpayer_id;
                      r_tax_lines.tax_category        := r_no_ins.tax_category;
                      r_tax_lines.start_date          := to_date(to_char(TRUNC(SYSDATE),'MM/YYYY'),'MM/YYYY');
                      r_tax_lines.end_date            := to_date('31/12/4712','DD/MM/YYYY');
                      r_tax_lines.classification_code := r_no_ins.TAX_ATTRIBUTE_VALUE;
                      r_tax_lines.tax_rate            := v_tax_rate;
                      r_tax_lines.coefficient         := null;
                      r_tax_lines.porc_exempt         := 0;
                      r_tax_lines.base_rate           := 0;
                      r_tax_lines.request_id          := fnd_global.conc_request_id;
                      r_tax_lines.status              := 'P';
                         
                      IF NOT insert_tax_lines (r_tax_lines) THEN
                        p_error_message := 'Error al insertar en XX_AR_TAX_LINES.';
                        RAISE e_category_exception;
                      END IF;
                      
                      commit;
                                  
                      /*print_xml('START_DATE',to_char(TRUNC(SYSDATE),'DD/MM/YYYY'));
                      print_xml('END_DATE',to_char(to_date('31-12-4712','DD.MM-YYYY'),'DD/MM/YYYY'));
                      print_xml('CLASS_CODE',r_no_ins.TAX_ATTRIBUTE_VALUE);
                      print_xml('TAX_RATE',REPLACE(TO_CHAR(v_tax_rate),',','.'));
                      print_xml('COEF',NULL);
                      print_xml('PORC_EXEMPT','0');
                      print_xml('BASE_RATE','0.00');
                      print_xml('ERROR_MESSAGE','No Inscripto IIBB');*/
                      
                      r_xml.date_from := to_char(to_date(to_char(TRUNC(SYSDATE),'MM/YYYY'),'MM/YYYY'),'DD/MM/YYYY');
                      r_xml.date_to := to_char(to_date('31/12/4712','DD/MM/YYYY'),'DD/MM/YYYY');
                      r_xml.contributor_class := r_no_ins.TAX_ATTRIBUTE_VALUE;
                      r_xml.tax_rate := REPLACE(TO_CHAR(v_tax_rate),',','.');
                      r_xml.coeficiente := null;
                      r_xml.porc_exempt := '0';
                      r_xml.base_rate := '0.00';
                      r_xml.message := 'No Inscripto IIBB';
                                  
                      --print_output('</G_TAX>');
                      print_xml_jl_output(r_xml);
                      print_output('</G_CATEGORY>');      
                      
                END IF;
                
                
                
            END LOOP;
        
        END IF;

    EXCEPTION
     WHEN e_customer_exception THEN
       p_status := 'W';
       print_log(p_error_message);
     WHEN OTHERS THEN
       p_error_message := 'Error OTHERS al procesar el cliente: '||r_cust.party_name||'. Error: '||SQLERRM;
       print_log(p_error_message);
       p_status := 'W';
    END;
    
    print_output('</G_CUST>');
    
   END LOOP;

   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_AR (-)');

EXCEPTION
 WHEN e_cust_exception THEN
   p_status := 'W';
   print_log(p_error_message);
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_AR (!)');
 WHEN OTHERS THEN
   p_status := 'W';
   p_error_message := 'Error OTHERS en TRANSFER_JL_AR. Error: '||SQLERRM;
   print_log(p_error_message);
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_AR (!)');
END;

/*Concurrente Transferencia de Localizacion a AR TAX  Fase 1*/

PROCEDURE TRANSFER_JL_TO_AR_TAX (retcode             OUT VARCHAR2
                                ,errbuf              OUT VARCHAR2
                                ,p_party_id           IN NUMBER
                                ,p_tax_category       IN VARCHAR2) IS

v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);
e_cust_exception EXCEPTION;

BEGIN

    print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_TO_AR_TAX (+)');

    print_output('<XXARATIT>');

    transfer_jl_ar(p_status             => v_status
                  ,p_error_message      => v_error_message
                  ,p_party_id           => p_party_id
                  ,p_tax_category       => p_tax_category);

    print_output('</XXARATIT>');

    if v_status != 'S' THEN
      RAISE e_cust_exception;
    END IF;

    print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_TO_AR_TAX (-)');

EXCEPTION
 WHEN E_CUST_EXCEPTION THEN
   retcode := 1;
   print_log(errbuf);
   IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
        print_log('Error Seteando Estado De Finalizacion');
   ELSE
        print_log('Estado de finalizacion seteado');
   END IF;
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_TO_AR_TAX (!)');
 WHEN OTHERS THEN
   retcode := 2;
   errbuf := 'Error OTHERS en TRANSFER_JL_TO_AR_TAX. Error: '||SQLERRM;
   print_log(errbuf);
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_TO_AR_TAX (!)');
   RAISE_APPLICATION_ERROR(-20001,'Error Inexperado en el proceso principal');
END;

FUNCTION get_tax_code(p_error_message       OUT VARCHAR2
                     ,p_tax_category_id     IN  NUMBER
                     ,p_org_id              IN  NUMBER
                     ,p_classification_code IN  VARCHAR2) RETURN VARCHAR2 IS

v_tax_code ar_vat_tax_all.tax_code%TYPE;

BEGIN

          select avt.tax_code
            into v_tax_code
            from jl_zz_ar_tx_groups_all gr
                ,ar_vat_tax_all avt
           where gr.tax_category_id = p_tax_category_id
             AND gr.org_id = avt.org_id
             AND gr.tax_code = avt.tax_code
             AND gr.contributor_type = p_classification_code
             AND gr.org_id = p_org_id
             AND gr.start_date_active <= TRUNC(SYSDATE)
             AND gr.end_date_active >= TRUNC(SYSDATE)
             AND NVL(avt.start_date,TRUNC(SYSDATE)) <= TRUNC(SYSDATE)
             AND NVL(avt.end_date,TRUNC(SYSDATE)) >= TRUNC(SYSDATE)
        GROUP BY avt.tax_code;

   RETURN (v_tax_code);

EXCEPTION
  WHEN OTHERS THEN
    p_error_message := 'Error OTHERS en XX_AR_TAX_FUNCTIONS_PKG.GET_TAX_CODE. Error: '||SQLERRM;
    RETURN (NULL);
END;

FUNCTION get_tax_code_cast(p_error_message       OUT VARCHAR2
                          ,p_tax_category_id     IN  NUMBER
                          ,p_org_id              IN  NUMBER
                          ,p_tax_rate            IN  NUMBER) RETURN VARCHAR2 IS

v_tax_code ar_vat_tax_all.tax_code%TYPE;

BEGIN

          SELECT avt.tax_code
            INTO v_tax_code
            FROM ar_vat_tax_all avt
                ,jl_zz_ar_tx_categ_all jzatca
           WHERE NVL(avt.start_date,TRUNC(SYSDATE)) <= TRUNC(SYSDATE)
             AND NVL(avt.end_date,TRUNC(SYSDATE)) >= TRUNC(SYSDATE)
             AND tax_rate = p_tax_rate
             AND avt.org_id = p_org_id
             AND avt.org_id = jzatca.org_id
             AND jzatca.tax_category_id = p_tax_category_id
             AND jzatca.tax_category = avt.tax
        GROUP BY avt.tax_code;

   RETURN (v_tax_code);

EXCEPTION
  WHEN OTHERS THEN
    p_error_message := 'Error OTHERS en XX_AR_TAX_FUNCTIONS_PKG.GET_TAX_CODE_CAST. Error: '||SQLERRM;
    RETURN (NULL);
END;

FUNCTION insert_exc_cus (p_error_message OUT VARCHAR2
                        ,p_exc_cus       IN  jl_zz_ar_tx_exc_cus_all%ROWTYPE) RETURN BOOLEAN IS

BEGIN

            INSERT INTO jl.jl_zz_ar_tx_exc_cus_all
                       (exc_cus_id,
                        address_id,
                        tax_category_id,
                        end_date_active,
                        last_update_date,
                        last_updated_by,
                        tax_code,
                        base_rate,
                        start_date_active,
                        org_id,
                        last_update_login,
                        creation_date,
                        created_by,
                        attribute_category,
                        attribute1,
                        attribute2)
                VALUES (p_exc_cus.exc_cus_id
                       ,p_exc_cus.address_id
                       ,p_exc_cus.tax_category_id
                       ,p_exc_cus.end_date_active
                       ,sysdate
                       ,fnd_global.user_id
                       ,p_exc_cus.tax_code
                       ,p_exc_cus.base_rate
                       ,p_exc_cus.start_date_active
                       ,p_exc_cus.org_id
                       ,fnd_global.login_id
                       ,sysdate
                       ,fnd_global.user_id
                       ,p_exc_cus.attribute_category
                       ,p_exc_cus.attribute1
                       ,p_exc_cus.attribute2);

                      /*print_xml('TAX_CODE',p_exc_cus.tax_code);
                      print_xml('BASE_RATE',p_exc_cus.base_rate);
                      print_xml('TAX_RATE',p_exc_cus.attribute1);
                      print_xml('COEF',p_exc_cus.attribute2);*/
                      
                      print_log('Insertado: '||p_exc_cus.exc_cus_id);

   RETURN (TRUE);

EXCEPTION
  WHEN OTHERS THEN
    p_error_message := 'Error OTHERS en XX_AR_TAX_FUNCTIONS_PKG.INSERT_EXC_CUS. Error: '||SQLERRM;
    RETURN (FALSE);
END;

/*Concurrente Actualizar cliente, copia de AR TAX a Localizacion*/

PROCEDURE transfer_ar_jl(p_status OUT VARCHAR2
                        ,p_error_message OUT VARCHAR2
                        ,p_party_id IN NUMBER
                        ,p_contributor_class IN VARCHAR2) IS

CURSOR c_tax_lines (p_party_id NUMBER) IS
  SELECT *
    FROM xx_ar_tax_lines xatl
   WHERE xatl.party_id = NVL(p_party_id,xatl.party_id)
     --AND NVL(start_date,TRUNC(SYSDATE)) <= TRUNC(SYSDATE)
     --AND NVL(end_date,TRUNC(SYSDATE)) >= TRUNC(SYSDATE)
     ORDER BY decode(tax_category,'VAT',1,'VATPERC',2,'RFOG',3,4),tax_category,start_date;
     
/*Los de Exportacion no tienen todas las categorias completan y deben eliminarse*/
CURSOR c_no_tax_lines (p_party_id NUMBER) IS
SELECT *
    FROM xx_ar_tax_lines_v xatl
   WHERE xatl.party_id = p_party_id
     AND classification_code is null
     ORDER BY tax_category;

CURSOR c_parties (p_party_id NUMBER,p_tax_category VARCHAR2) IS
SELECT hp.party_id
      ,hca.cust_account_id
      ,hcas.cust_acct_site_id
      ,hcas.org_id
      ,hcas_dfv.use_cust_site_prof
      ,hl.province
      ,hl.address1
      ,(select count(1)
          from jl_zz_ar_tx_cus_cls_all jzatcca
              ,jl_zz_ar_tx_categ_all jzatca
         where jzatcca.address_id = hcas.cust_acct_site_id
           and jzatca.tax_category_id = jzatcca.tax_category_id
           and jzatca.org_id = jzatcca.org_id
           and jzatcca.tax_attr_class_code = p_contributor_class
           and jzatca.tax_category = p_tax_category) cant_psc
      ,haou.name org_name
      ,flv_dfv.xx_ar_zf
      ,hca.global_attribute9 dom_for
      ,hcas.global_attribute8 contr_class_old
  FROM hz_parties hp
      ,hz_cust_accounts hca
      ,hz_cust_acct_sites_all hcas
      ,hz_cust_acct_sites_all1_dfv hcas_dfv
      ,hz_party_sites hps
      ,hz_locations hl
      ,hr_all_organization_units haou
      ,fnd_lookup_values_vl flv
      ,fnd_lookup_values_dfv flv_dfv
 WHERE hp.party_id                          = hca.party_id
   and hp.party_id                          = nvl(p_party_id,hp.party_id)
   AND hca.cust_account_id                  = hcas.cust_account_id
   and hcas.party_site_id                   = hps.party_site_id
   and hps.location_id                      = hl.location_id
   and hcas.org_id                          = haou.organization_id
   and (hca.global_attribute9 = 'DOMESTIC_ORIGIN' AND hl.country = 'AR' OR hca.global_attribute9 = 'FOREIGN_ORIGIN')
   and hcas.rowid                           = hcas_dfv.row_id
   and flv.lookup_code(+)                   = hl.province
   and flv.lookup_type(+)                   = 'JLZZ_STATE_PROVINCE'
   and flv.rowid                            = flv_dfv.row_id(+)
   and hcas.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%');
   
CURSOR c_parties_no (p_party_id NUMBER,p_tax_category VARCHAR2) IS
SELECT hp.party_id
      ,hca.cust_account_id
      ,hcas.cust_acct_site_id
      ,hcas.org_id
      ,hcas_dfv.use_cust_site_prof
      ,hl.province
      ,hl.address1
      ,haou.name org_name
      ,flv_dfv.xx_ar_zf
      ,hca.global_attribute9 dom_for
      ,hcas.global_attribute8 contr_class_old
  FROM hz_parties hp
      ,hz_cust_accounts hca
      ,hz_cust_acct_sites_all hcas
      ,hz_cust_acct_sites_all1_dfv hcas_dfv
      ,hz_party_sites hps
      ,hz_locations hl
      ,hr_all_organization_units haou
      ,fnd_lookup_values_vl flv
      ,fnd_lookup_values_dfv flv_dfv
      ,jl_zz_ar_tx_cus_cls_all jzatcca
      ,jl_zz_ar_tx_categ_all jzatca
 WHERE hp.party_id                          = hca.party_id
   and hp.party_id                          = nvl(p_party_id,hp.party_id)
   AND hca.cust_account_id                  = hcas.cust_account_id
   and hcas.party_site_id                   = hps.party_site_id
   and hps.location_id                      = hl.location_id
   and hcas.org_id                          = haou.organization_id
   and hca.global_attribute9                = 'FOREIGN_ORIGIN'
   and hcas.rowid                           = hcas_dfv.row_id
   and flv.lookup_code(+)                   = hl.province
   and flv.lookup_type(+)                   = 'JLZZ_STATE_PROVINCE'
   and flv.rowid                            = flv_dfv.row_id(+)
   and jzatcca.address_id = hcas.cust_acct_site_id
   and jzatca.tax_category_id = jzatcca.tax_category_id
   and jzatca.org_id = jzatcca.org_id
   and jzatcca.tax_attr_class_code = p_contributor_class
   and jzatca.tax_category = p_tax_category
   and hcas.org_id IN (select organization_id from hr_operating_units hou where name like 'AR%');

v_tax_category_id NUMBER;
v_error_message   VARCHAR2(2000);
v_trx             VARCHAR2(1);
v_province        VARCHAR2(30);
v_exc_calc        VARCHAR2(150);
v_total_pais      VARCHAR2(150);
v_tasa_castigo    VARCHAR2(150);
v_replace_value   VARCHAR2(150);
v_class_code      VARCHAR2(150);
v_tax_code        AR_VAT_TAX_ALL.TAX_CODE%TYPE;
v_dft_tax_code    AR_VAT_TAX_ALL.TAX_CODE%TYPE;
v_exc_cus_id      JL_ZZ_AR_TX_EXC_CUS_ALL.EXC_CUS_ID%type;
v_exc_cus_id2      JL_ZZ_AR_TX_EXC_CUS_ALL.EXC_CUS_ID%type;
v_tax_categ_start_date jl_zz_ar_tx_categ_all.start_date_active%type;
v_tax_categ_end_date   jl_zz_ar_tx_categ_all.end_date_active%type;
p_cont_class_no_insc  VARCHAR2(150);

v_qty     NUMBER;
v_qty_upd NUMBER;
v_exists  NUMBER;
v_coef NUMBER;
v_base_rate number;
v_start_date_act DATE;
v_count NUMBER;

p_exc_cus jl_zz_ar_tx_exc_cus_all%ROWTYPE;

e_party_exception EXCEPTION;
e_no_party_exception EXCEPTION;
e_tax_exception EXCEPTION;
e_cust_exception EXCEPTION;

r_xml xml_type;                     

BEGIN

   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_JL (+)');
   
   r_xml := null;
   
   p_cont_class_no_insc := fnd_profile.value('XX_AR_TAX_LINES_NO_INSC');

   FOR r_tax IN c_tax_lines(p_party_id) LOOP

     print_output('<G_TAX_CATEGORY>');

     BEGIN

       print_log ('Cliente: '              ||r_tax.party_name);
       print_log ('Categoria de Impuesto: '||r_tax.tax_category);

       SAVEPOINT s_tax;

       v_qty := 0;
       v_qty_upd := 0;

       FOR r_party IN c_parties (r_tax.party_id,r_tax.tax_category) LOOP
         v_qty := v_qty + 1;
       END LOOP;

       print_log('Cantidad a Actualizar: '||v_qty);

       FOR r_party IN c_parties (r_tax.party_id,r_tax.tax_category) LOOP

         r_xml.tax_category := r_tax.tax_category;
         r_xml.party_name   := r_tax.party_name;
         r_xml.taxpayer_id  := r_tax.taxpayer_id;
         r_xml.address      := r_party.address1;
         r_xml.province     := r_party.province;
         r_xml.company      := r_party.org_name;
         r_xml.contributor_class := p_contributor_class;
         

         print_log('Direccion: '||r_party.address1||', provincia : '||r_party.province);
         print_log('org_id   : '||r_party.org_id  ||', address_id: '||r_party.cust_acct_site_id);
         print_log('org_name : '||r_party.org_name);
         print_log('Contributor Class: '||p_contributor_class);
         
         v_dft_tax_code := null;
         
         BEGIN
                SELECT jzatca.tax_category_id
                      ,jzatca_dfv.xx_ar_provincia
                      ,flv_dfv.xx_ar_exc_calc
                      ,flv_dfv.xx_ar_total_pais
                      ,jzatca_dfv.xx_ar_tasa_castigo
                      ,jzatca.start_date_active
                      ,jzatca.end_date_active
                      ,flv_dfv.xx_ar_replace_zf
                      ,flv_dfv.xx_ar_tax_dft
                  INTO v_tax_category_id
                      ,v_province
                      ,v_exc_calc
                      ,v_total_pais
                      ,v_tasa_castigo
                      ,v_tax_categ_start_date
                      ,v_tax_categ_end_date
                      ,v_replace_value
                      ,v_dft_tax_code
                  FROM jl_zz_ar_tx_categ_all jzatca
                      ,jl_zz_ar_tx_categ_all_dfv jzatca_dfv
                      ,fnd_lookup_values_vl flv
                      ,fnd_lookup_values_dfv flv_dfv
                 WHERE jzatca.rowid        = jzatca_dfv.row_id
                   AND jzatca.org_id       = r_party.org_id
                   AND jzatca.tax_category = r_tax.tax_category
                   AND jzatca.tax_rule_set = 'ARGENTINA'
                   AND jzatca.tax_category = flv.lookup_code
                   and flv.lookup_type = 'XX_AR_TAX_CATEGORIES_AR_TAX'
                   and flv.rowid = flv_dfv.row_id
                   and flv.start_date_active <= TRUNC(sysdate)
                   and NVL(flv.end_date_active,trunc(sysdate)) >= TRUNC(sysdate);
            EXCEPTION
             WHEN NO_DATA_FOUND THEN
                print_log('No esta configurado el tax category: '||r_tax.tax_category||' en org_id: '||r_party.org_id);
                v_qty_upd := v_qty_upd + 1;
                --print_xml('ERROR_MESSAGE','No esta configurado el tax category: '||r_tax.tax_category||' en org_id: '||r_party.org_id);
                r_xml := null;
                CONTINUE;
             WHEN OTHERS THEN
                v_error_message := 'Error al obtener Tax Category ID para: '||r_tax.tax_category||'. Error: '||SQLERRM;
                RAISE e_party_exception;
            END;
            
             IF NVL(v_replace_value,'N') = 'Y' and NVL(r_party.xx_ar_zf,'N') = 'Y' THEN 
                BEGIN
                    SELECT description
                      INTO v_class_code
                      FROM fnd_lookup_values_vl
                     WHERE lookup_code = r_tax.classification_code
                       AND lookup_type = 'XX_AR_VAT_ZF_CODES'
                      GROUP BY description;
                EXCEPTION
                  WHEN OTHERS THEN
                    v_class_code := r_tax.classification_code;
                END;
             ELSE
                v_class_code := r_tax.classification_code;
             END IF;
             
             print_log('Nueva Clase Contribuyente: '||v_class_code);
            
            IF v_province IS NOT NULL THEN
            
                 v_tax_code := NVL(get_tax_code(v_error_message,v_tax_category_id,r_party.org_id,v_class_code),v_dft_tax_code);
                 IF v_tax_code IS NULL THEN
                  print_log(v_error_message);
                  print_log('Esta Categoria no tiene un impuesto asociado en los grupos de Impuestos');
                  v_qty_upd := v_qty_upd + 1;
                  --print_xml('ERROR_MESSAGE','Esta Categoria no tiene un impuesto asociado en los grupos de Impuestos');
                  r_xml := null;
                  --print_output('</G_PARTY>');
                  CONTINUE;
                 ELSE
                  print_log('Codigo de Impuesto: '||v_tax_code);
                 END IF;
            ELSE
                 v_tax_code := v_dft_tax_code;
                 print_log('Codigo de Impuesto: '||v_tax_code);
            END IF;

        BEGIN

            IF r_party.use_cust_site_prof = 'N' THEN --si es una sucursal nueva es N
                UPDATE hz_cust_acct_sites_all
                   SET global_attribute9  = 'Y'
                     , global_attribute8  = p_contributor_class
                     , last_update_date   = sysdate
                     , last_updated_by    = fnd_global.user_id
                     , last_update_login  = fnd_global.login_id
                 WHERE cust_acct_site_id  = r_party.cust_acct_site_id;
            ELSE
            
                IF r_party.contr_class_old != p_contributor_class THEN
                    UPDATE hz_cust_acct_sites_all
                       SET global_attribute8  = p_contributor_class
                         , last_update_date   = sysdate
                         , last_updated_by    = fnd_global.user_id
                         , last_update_login  = fnd_global.login_id
                     WHERE cust_acct_site_id  = r_party.cust_acct_site_id;
                END IF;
            
            END IF;

            IF NVL(v_tax_categ_end_date,TRUNC(SYSDATE)) < TRUNC(SYSDATE)
            OR NVL(v_tax_categ_start_date,TRUNC(SYSDATE)) > TRUNC(SYSDATE) THEN

                delete jl.jl_zz_ar_tx_cus_cls_all
                 where address_id = r_party.cust_acct_site_id
                   and tax_category_id = v_tax_category_id
                   and org_id = r_party.org_id;

                print_log('Categoria de Impuesto Inactivo');

                v_qty_upd := v_qty_upd + 1;
                --print_xml('ERROR_MESSAGE','Categoria de Impuestos Inactiva');
                r_xml := null;
                --print_output('</G_PARTY>');
                CONTINUE;
            END IF;
            
            IF r_tax.classification_code = p_cont_class_no_insc and v_province IS NULL THEN
            
                delete jl.jl_zz_ar_tx_cus_cls_all
                 where address_id = r_party.cust_acct_site_id
                   and tax_category_id = v_tax_category_id
                   and org_id = r_party.org_id;
            
                print_log('No Inscripto IIBB');
                v_qty_upd := v_qty_upd + 1;
                --print_xml('ERROR_MESSAGE','No Inscripto');
                --print_output('</G_PARTY>');
                CONTINUE;
            END IF;
            
            IF NVL(r_party.xx_ar_zf,'N') = 'Y' AND r_tax.tax_category != 'VAT' and v_province IS NULL  THEN
                    
                    delete jl.jl_zz_ar_tx_cus_cls_all
                     where address_id = r_party.cust_acct_site_id
                       and tax_category_id = v_tax_category_id
                       and org_id = r_party.org_id;
                       
                     delete jl_zz_ar_tx_exc_cus_all
                     where address_id = r_party.cust_acct_site_id
                       and tax_category_id = v_tax_category_id
                       and org_id = r_party.org_id;
                   
                     print_log('Zona Franca');
                     v_qty_upd := v_qty_upd + 1;
                     r_xml := null;
               CONTINUE;
            END IF;
                
                IF r_party.cant_psc = 0 THEN
                  v_trx := 'I';
                ELSE
                  v_trx := 'U';
                END IF;
                
                print_log('Insert or Update: '||v_trx);

                IF v_trx = 'I' THEN
                

                  IF  (NVL(v_total_pais,'N') = 'Y' AND r_tax.classification_code != p_cont_class_no_insc AND r_tax.tax_rate != NVL(v_tasa_castigo,-1) and r_tax.tax_category != 'TOPSA')
                    OR NVL(v_province,'*') = r_party.province
                    OR v_province is null
                    OR (r_tax.tax_category = 'TOPSA' AND r_tax.classification_code != p_cont_class_no_insc) THEN
                    
                    print_log('Insertando perfil de sucursal');

                    IF NOT insert_cus_cls(p_error_message     => v_error_message
                                         ,p_address_id        => r_party.cust_acct_site_id
                                         ,p_org_id            => r_party.org_id
                                         ,p_contributor_class => p_contributor_class
                                         ,p_tax_category_id   => v_tax_category_id
                                         ,p_tax_attr_value    => v_class_code) THEN
                         RAISE e_party_exception;
                    ELSE
                      --print_xml('OLD_VALUE',NULL);
                      --print_xml('NEW_VALUE',p_tax_attr_value);
                      r_xml.old_value := null;
                      r_xml.new_Value := v_class_code;
                      
                      print_log('Aplicado');
                    END IF;
                  ELSIF (v_total_pais = 'Y' AND r_tax.classification_code = p_cont_class_no_insc and NVL(v_province,'*') != r_party.province) THEN
                  
                    delete jl.jl_zz_ar_tx_cus_cls_all
                     where address_id = r_party.cust_acct_site_id
                       and tax_category_id = v_tax_category_id
                       and org_id = r_party.org_id;
                       
                     delete jl_zz_ar_tx_exc_cus_all
                     where address_id = r_party.cust_acct_site_id
                       and tax_category_id = v_tax_category_id
                       and org_id = r_party.org_id;
                   
                     print_log('No Inscripto IIBB');
                     v_qty_upd := v_qty_upd + 1;
                     --print_xml('ERROR_MESSAGE','No Inscripto');
                     r_xml := null;
                     --print_output('</G_PARTY>');
                     CONTINUE;
                  END IF;
                ELSE

                   IF  (v_total_pais = 'Y' AND r_tax.classification_code != p_cont_class_no_insc AND r_tax.tax_rate != NVL(v_tasa_castigo,-1) and r_tax.tax_category != 'TOPSA')
                    OR NVL(v_province,'*') = r_party.province
                    OR v_province is null 
                    OR (r_tax.tax_category = 'TOPSA' AND r_tax.classification_code != p_cont_class_no_insc) THEN
                        print_log('Actualizando Perfil de sucursal');
                        IF NOT update_cus_cls(p_error_message     => v_error_message
                                             ,p_old_value         => r_xml.old_value
                                             ,p_address_id        => r_party.cust_acct_site_id
                                             ,p_org_id            => r_party.org_id
                                             ,p_contributor_class => p_contributor_class
                                             ,p_tax_category_id   => v_tax_category_id
                                             ,p_tax_attr_value    => v_class_code) THEN
                             RAISE e_party_exception;
                        ELSE
                          r_xml.new_value := v_class_code;
                          print_log('Actualizado');
                        END IF;
                   ELSE
                        print_log('Inactivando');
                        
                        delete jl.jl_zz_ar_tx_cus_cls_all
                         where address_id = r_party.cust_acct_site_id
                           and tax_category_id = v_tax_category_id
                           and org_id = r_party.org_id;
                       
                         delete jl_zz_ar_tx_exc_cus_all
                         where address_id = r_party.cust_acct_site_id
                           and tax_category_id = v_tax_category_id
                           and org_id = r_party.org_id;

                        print_log('Este Impuesto no aplica en esta sucursal');
                        v_qty_upd := v_qty_upd + 1;
                        r_xml := null;
                        --print_xml('ERROR_MESSAGE','No Inscripto');
                        --print_output('</G_PARTY>');
                        CONTINUE;
                   END IF;
                END IF;

                IF v_province IS NOT NULL OR (v_province IS NULL) THEN --Si es provincial
                
                    print_log('Procesando exencion');
                
                   IF  ((NVL(v_total_pais,'N') = 'Y' AND r_tax.tax_rate != NVL(v_tasa_castigo,-1))
                    OR NVL(v_province,'*') = r_party.province
                    OR (v_province IS NULL and r_tax.tax_category = 'VATPERC')) THEN
                    
                        print_log('Total Pais o misma provincia');
                        print_log('Start_date: '||TO_CHAR(r_tax.start_date,'DD-MM-YYYY'));
                        print_log('End_date: '||TO_CHAR(NVL(r_tax.end_date,trunc(last_day(sysdate))),'DD-MM-YYYY'));

                        p_exc_cus := NULL;

                        BEGIN
                          SELECT exc_cus_id
                          into v_exc_cus_id
                          from jl_zz_ar_tx_exc_cus_all
                          where tax_category_id = v_tax_category_id
                          and address_id = r_party.cust_acct_site_id
                          and org_id = r_party.org_id
                          --and tax_code = v_tax_code
                          and start_date_active <= r_tax.start_date
                          and end_date_active >= NVL(r_tax.end_date,trunc(last_day(sysdate)));
                        EXCEPTION
                          WHEN OTHERS THEN
                            v_exc_cus_id := 0;
                        END;
                        
                        IF v_exc_cus_id = 0 THEN
                        
                             BEGIN
                                  SELECT exc_cus_id,start_date_active
                                  into v_exc_cus_id,v_start_date_act
                                  from jl_zz_ar_tx_exc_cus_all
                                  where tax_category_id = v_tax_category_id
                                  and address_id = r_party.cust_acct_site_id
                                  and org_id = r_party.org_id
                                  and end_date_active >= NVL(r_tax.end_date,trunc(last_day(sysdate)));
                                  
                             EXCEPTION
                               WHEN TOO_MANY_ROWS THEN
                                BEGIN
                                 SELECT exc_cus_id,start_date_active
                                  into v_exc_cus_id,v_start_date_act
                                  from jl_zz_ar_tx_exc_cus_all
                                  where tax_category_id = v_tax_category_id
                                  and address_id = r_party.cust_acct_site_id
                                  and org_id = r_party.org_id
                                  and end_date_active >= NVL(r_tax.end_date,trunc(last_day(sysdate)))
                                  and start_date_active = (select min(start_date_active) from jl_zz_ar_tx_exc_cus_all
                                  where tax_category_id = v_tax_category_id
                                  and address_id = r_party.cust_acct_site_id
                                  and org_id = r_party.org_id
                                  and end_date_active >= NVL(r_tax.end_date,trunc(last_day(sysdate))));
                                  EXCEPTION
                                    WHEN OTHERS THEN
                                       v_exc_cus_id := 0;   
                                  END;
                               WHEN OTHERS THEN
                                 v_exc_cus_id := 0;
                             END;
                             
                            IF v_exc_cus_id != 0 THEN
                             
                             IF v_start_date_act <= r_tax.start_date THEN
                           
                                 IF v_exc_cus_id != 0 THEN
                                 
                                     UPDATE jl_zz_ar_tx_exc_cus_all
                                     SET end_date_active = r_tax.start_date -1
                                     ,last_update_date = sysdate
                                     ,last_updated_by = fnd_global.user_id
                                     where exc_cus_id = v_exc_cus_id;
                                 
                                 END IF;
                                 
                                 v_coef := null;
                                 p_exc_cus := null;

                                p_exc_cus.address_id := r_party.cust_acct_site_id;

                                IF v_tax_code is null then
                                   RAISE e_party_exception;
                                ELSE
                                   p_exc_cus.tax_code := v_tax_code;
                                END IF;

                                p_exc_cus.tax_category_id := v_tax_category_id;
                                p_exc_cus.start_date_active := r_tax.start_date;
                                p_exc_cus.end_date_active := r_tax.end_date;
                                
                                IF r_tax.tax_category = 'TOPSA' THEN
                                
                                   IF v_class_code IN ('CONV MULTILATERAL','CM CON RIESGO') THEN
                                       v_coef := 0.5;
                                       p_exc_cus.base_rate := round(-100 + (100*v_coef), 4);
                                   ELSE
                                     p_exc_cus.base_rate := NVL(r_tax.base_rate,0); 
                                   END IF;
                                   
                                ELSE
                                  p_exc_cus.base_rate := NVL(r_tax.base_rate,0);
                                END IF;
                                
                                p_exc_cus.org_id := r_party.org_id;
                                p_exc_cus.attribute_category := 'AR';

                                IF r_tax.tax_category IN ('TOPSA','TOPTU') THEN
                                  p_exc_cus.attribute1 := replace(to_char(r_tax.tax_rate),',','.');
                                END IF;
                                
                                IF v_exc_calc = 'Y' THEN
                                  p_exc_cus.attribute2 := replace(to_char(r_tax.coefficient),',','.');
                                END IF;
                                IF r_tax.tax_category IN ('TOPSA') THEN
                                  p_exc_cus.attribute2 := replace(to_char(v_coef),',','.');
                                END IF;
                                
                                select jl_zz_ar_tx_exc_cus_s.nextval
                                  into p_exc_cus.exc_cus_id
                                  from dual;

                                IF NOT insert_exc_cus (v_error_message,p_exc_cus) then
                                   RAISE e_party_exception;
                                END IF;
                                
                                r_xml.tax_code     := v_tax_code;
                                r_xml.base_rate    := replace(to_char(p_exc_cus.base_rate),',','.');
                                r_xml.tax_rate     := p_exc_cus.attribute1;
                                r_xml.coeficiente  := p_exc_cus.attribute2;
                                r_xml.message      := 'Actualizado';
                             
                             ELSE
                            
                               BEGIN
                                  SELECT count(1)
                                  into v_count
                                  from jl_zz_ar_tx_exc_cus_all
                                  where tax_category_id = v_tax_category_id
                                  and address_id = r_party.cust_acct_site_id
                                  and org_id = r_party.org_id
                                  and end_date_active <= v_start_date_act
                                  and start_date_active >= NVL(r_tax.start_date,trunc(last_day(sysdate)));
                               EXCEPTION
                                   WHEN OTHERS THEN
                                     v_count := 0;
                               END;
                               
                               IF v_count = 0 THEN
                               
                                update jl_zz_ar_tx_exc_cus_all
                                   set tax_code = v_tax_code
                                      ,attribute1 = replace(to_char(r_tax.tax_rate),',','.')
                                      ,attribute2 = replace(to_char(r_tax.coefficient),',','.')
                                      ,base_rate  = v_base_rate
                                      ,start_date_active =  r_tax.start_date
                                      ,end_date_active = r_tax.end_date
                                     ,last_update_date = sysdate
                                     ,last_updated_by = fnd_global.user_id
                                 where exc_cus_id = v_exc_cus_id;
                                
                                  r_xml.tax_code     := v_tax_code;
                                  r_xml.base_rate    := replace(to_char(v_base_rate),',','.');
                                  r_xml.tax_rate     := replace(to_char(r_tax.tax_rate),',','.');
                                  r_xml.coeficiente  := replace(to_char(r_tax.coefficient),',','.');
                                  r_xml.message      := 'Actualizado';
                                  
                               ELSE
                                  r_xml := null;
                                  print_log('No es necesario actualizar'); 
                               END IF;
                             
                             END IF;
                             
                            ELSE
                            
                               v_coef := null;
                               p_exc_cus := null;
                            
                                p_exc_cus.address_id := r_party.cust_acct_site_id;

                                IF v_tax_code is null then
                                   RAISE e_party_exception;
                                ELSE
                                   p_exc_cus.tax_code := v_tax_code;
                                END IF;

                                p_exc_cus.tax_category_id := v_tax_category_id;
                                p_exc_cus.start_date_active := r_tax.start_date;
                                p_exc_cus.end_date_active := r_tax.end_date;
                                
                                IF r_tax.tax_category = 'TOPSA' THEN
                                
                                   IF v_class_code IN ('CONV MULTILATERAL','CM CON RIESGO') THEN
                                       v_coef := 0.5;
                                       p_exc_cus.base_rate := round(-100 + (100*v_coef), 4);
                                   ELSE
                                     p_exc_cus.base_rate := NVL(r_tax.base_rate,0); 
                                   END IF;
                                   
                                ELSE
                                  p_exc_cus.base_rate := NVL(r_tax.base_rate,0);
                                END IF;
                                
                                p_exc_cus.org_id := r_party.org_id;
                                p_exc_cus.attribute_category := 'AR';

                                IF r_tax.tax_category IN ('TOPSA','TOPTU') THEN
                                  p_exc_cus.attribute1 := replace(to_char(r_tax.tax_rate),',','.');
                                END IF;
                                
                                IF v_exc_calc = 'Y' THEN
                                  p_exc_cus.attribute2 := replace(to_char(r_tax.coefficient),',','.');
                                END IF;
                                IF r_tax.tax_category IN ('TOPSA') THEN
                                  p_exc_cus.attribute2 := replace(to_char(v_coef),',','.');
                                END IF;

                                select jl_zz_ar_tx_exc_cus_s.nextval
                                  into p_exc_cus.exc_cus_id
                                  from dual;

                                IF NOT insert_exc_cus (v_error_message,p_exc_cus) then
                                   RAISE e_party_exception;
                                END IF;
                                
                                r_xml.tax_code     := v_tax_code;
                                r_xml.base_rate    := replace(to_char(p_exc_cus.base_rate),',','.');
                                r_xml.tax_rate     := p_exc_cus.attribute1;
                                r_xml.coeficiente  := p_exc_cus.attribute2;
                                r_xml.message      := 'Aplicado';
                            
                            END IF;
                            
                        ELSE
                        
                            print_log('Mismas fechas');
                            v_coef := null;
                        
                            IF r_tax.tax_category = 'TOPSA' THEN
                                
                                   IF v_class_code IN ('CONV MULTILATERAL','CM CON RIESGO') THEN
                                       IF v_province = r_party.province THEN
                                           v_coef := 0.5;
                                       ELSE
                                           BEGIN
                                             select coef 
                                               into v_coef
                                               from xx_ar_tax_lines_cm05
                                              where party_id = r_party.party_id
                                                and province_code = v_province
                                                and NVL(start_date,TRUNC(SYSDATE)) <= r_tax.start_date
                                                and NVL(end_date,TRUNC(SYSDATE)) >= r_tax.start_date;
                                           EXCEPTION
                                            WHEN OTHERS THEN
                                              v_coef := 1;
                                           END;
                                       END IF;
                                       p_exc_cus.base_rate := round(-100 + (100*v_coef), 4);
                                       v_base_rate := round(-100 + (100*v_coef), 4);
                                   ELSE
                                     p_exc_cus.base_rate := NVL(r_tax.base_rate,0);
                                     v_base_rate  := NVL(r_tax.base_rate,0);
                                   END IF;
                                   
                            ELSE
                              p_exc_cus.base_rate := NVL(r_tax.base_rate,0);
                              v_base_rate := NVL(r_tax.base_rate,0);
                            END IF;
                            
                            print_log('Base_rate: '||v_base_rate);
                            
                            BEGIN
                              SELECT exc_cus_id
                              into v_exc_cus_id2
                              from jl_zz_ar_tx_exc_cus_all
                              where tax_category_id = v_tax_category_id
                              and address_id = r_party.cust_acct_site_id
                              and org_id = r_party.org_id
                              and tax_code = v_tax_code
                              and NVL(attribute1,'*') = NVL(replace(to_char(r_tax.tax_rate),',','.'),'*')
                              and NVL(attribute2,'*') = NVL(replace(to_char(NVL(r_tax.coefficient,v_coef)),',','.'),'*')
                              and base_rate  = v_base_rate
                              and start_date_active = r_tax.start_date
                              and end_date_active >= NVL(r_tax.end_date,trunc(last_day(sysdate)));
                            EXCEPTION
                              WHEN OTHERS THEN
                                v_exc_cus_id2 := 0;
                            END;
                            
                            IF v_exc_cus_id2 = 0 THEN
                        
                                update jl_zz_ar_tx_exc_cus_all
                                   set tax_code = v_tax_code
                                      ,attribute1 = NVL(replace(to_char(r_tax.tax_rate),',','.'),attribute1)
                                      ,attribute2 = NVL(replace(to_char(NVL(r_tax.coefficient,v_coef)),',','.'),attribute2)
                                      ,base_rate  = v_base_rate
                                     ,last_update_date = sysdate
                                     ,last_updated_by = fnd_global.user_id
                                 where exc_cus_id = v_exc_cus_id;

                                  r_xml.tax_code     := v_tax_code;
                                  r_xml.base_rate    := replace(to_char(v_base_rate),',','.');
                                  r_xml.tax_rate     := replace(to_char(r_tax.tax_rate),',','.');
                                  r_xml.coeficiente  := replace(to_char(NVL(r_tax.coefficient,v_coef)),',','.');
                                  r_xml.message      := 'Actualizado';
                            ELSE
                              r_xml := null;
                              print_log('No es necesario actualizar');  
                            END IF;
                        
                        END IF;
                        
                   ELSE
                   
                    IF r_tax.tax_category = 'TOPSA' THEN
                    
                      IF v_class_code  IN ('CONV MULTILATERAL','CM CON RIESGO') THEN
                      
                        print_log('TOPSA CONV MULTILATERAL Distinta provincia');
                      
                          BEGIN

                             select coef
                               into v_coef
                               from xx_ar_tax_lines_cm05 xaacc
                              where xaacc.party_id = r_party.party_id
                                and province_code = v_province
                                and NVL(start_date,trunc(sysdate)) <= r_tax.start_date
                                and NVL(end_date,trunc(sysdate)) >= r_tax.start_date;

                           EXCEPTION
                            WHEN TOO_MANY_ROWS THEN
                             BEGIN
                             select coef
                               into v_coef
                               from xx_ar_tax_lines_cm05 xaacc
                              where xaacc.party_id = r_party.party_id
                                and province_code = v_province
                                and NVL(xaacc.start_date,trunc(sysdate)) <= r_tax.start_date
                                and NVL(xaacc.end_date,trunc(sysdate)) >= r_tax.start_date
                                and TAX_LINE_CM05_ID = (select max(TAX_LINE_CM05_ID)
                                                          from xx_ar_tax_lines_cm05 xaacc2
                                                         where xaacc2.party_id = r_party.party_id
                                                           and NVL(xaacc2.start_date,trunc(sysdate)) <= r_tax.start_date
                                                           and NVL(xaacc2.end_date,trunc(sysdate)) >= r_tax.start_date);
                              EXCEPTION
                               WHEN OTHERS THEN
                                 v_coef := 1; 
                              END;
                            WHEN OTHERS THEN
                              v_coef := 1;
                           END;
                           
                           print_log('COEF: '||v_coef);
                           
                           p_exc_cus := NULL;

                            BEGIN
                              SELECT exc_cus_id
                              into v_exc_cus_id
                              from jl_zz_ar_tx_exc_cus_all
                              where tax_category_id = v_tax_category_id
                              and address_id = r_party.cust_acct_site_id
                              and org_id = r_party.org_id
                              and start_date_active = r_tax.start_date
                              and end_date_active >= NVL(r_tax.end_date,TRUNC(SYSDATE));
                            EXCEPTION
                              WHEN OTHERS THEN
                                v_exc_cus_id := 0;
                            END;
                            
                            print_log('EXC_CUS_ID: '||v_exc_cus_id);

                            IF v_exc_cus_id = 0 THEN


                                 BEGIN
                                      SELECT exc_cus_id
                                      into v_exc_cus_id
                                      from jl_zz_ar_tx_exc_cus_all
                                      where tax_category_id = v_tax_category_id
                                      and address_id = r_party.cust_acct_site_id
                                      and org_id = r_party.org_id
                                      --and tax_code = v_tax_code
                                      and start_date_active <= r_tax.start_date
                                      and end_date_active > NVL(r_tax.end_date,TRUNC(SYSDATE));
                                 EXCEPTION
                                   WHEN OTHERS THEN
                                     v_exc_cus_id := 0;
                                 END;
                                 
                                 print_log('EXC_CUS_ID: '||v_exc_cus_id);

                                 IF v_exc_cus_id != 0 THEN
                                     UPDATE jl_zz_ar_tx_exc_cus_all
                                     SET end_date_active = r_tax.start_date -1
                                     ,last_update_date = sysdate
                                     ,last_updated_by = fnd_global.user_id
                                     where exc_cus_id = v_exc_cus_id;
                                 END IF;

                                p_exc_cus.address_id := r_party.cust_acct_site_id;

                                IF v_tax_code is null then
                                   RAISE e_party_exception;
                                ELSE
                                   p_exc_cus.tax_code := v_tax_code;
                                END IF;

                                p_exc_cus.tax_category_id := v_tax_category_id;
                                p_exc_cus.start_date_active := r_tax.start_date;
                                p_exc_cus.end_date_active := r_tax.end_date;
                                    
                                p_exc_cus.base_rate := round(-100 + (100*v_coef), 4);
                                p_exc_cus.org_id := r_party.org_id;
                                p_exc_cus.attribute_category := 'AR';

                                p_exc_cus.attribute1 := replace(to_char(r_tax.tax_rate),',','.');
                                p_exc_cus.attribute2 := replace(to_char(v_coef),',','.');

                                select jl_zz_ar_tx_exc_cus_s.nextval
                                  into p_exc_cus.exc_cus_id
                                  from dual;
                                  
                                  print_log('Insertando exencion');

                                IF NOT insert_exc_cus (v_error_message,p_exc_cus) then
                                   RAISE e_party_exception;
                                END IF;
                                
                                r_xml.tax_code     := v_tax_code;
                                r_xml.base_rate    := replace(to_char(round(-100 + (100*v_coef), 4)),',','.');
                                r_xml.tax_rate     := replace(to_char(r_tax.tax_rate),',','.');
                                r_xml.coeficiente  := replace(to_char(v_coef),',','.');
                                
                            ELSE
                            
                                BEGIN
                                      SELECT exc_cus_id
                                      into v_exc_cus_id2
                                      from jl_zz_ar_tx_exc_cus_all
                                      where tax_category_id = v_tax_category_id
                                      and address_id = r_party.cust_acct_site_id
                                      and org_id = r_party.org_id
                                      and tax_code = v_tax_code
                                      and NVL(attribute1,'*') = NVL(NVL(replace(to_char(r_tax.tax_rate),',','.'),attribute1),'*')
                                      and NVL(attribute2,'*') = NVL(NVL(replace(to_char(v_coef),',','.'),attribute2),'*')
                                      and base_rate  = round(-100 + (100*v_coef), 4)
                                      and start_date_active = r_tax.start_date
                                      and end_date_active >= NVL(r_tax.end_date,TRUNC(SYSDATE));
                                    EXCEPTION
                                      WHEN OTHERS THEN
                                        v_exc_cus_id2 := 0;
                                    END;
                                    
                                    IF v_exc_cus_id2 = 0 THEN
                            
                                    print_log('Actualizando exencion');
                                
                                    update jl_zz_ar_tx_exc_cus_all
                                    set tax_code = v_tax_code
                                       ,attribute1 = NVL(replace(to_char(r_tax.tax_rate),',','.'),attribute1)
                                       ,attribute2 = NVL(replace(to_char(v_coef),',','.'),attribute2)
                                       ,base_rate  = round(-100 + (100*v_coef), 4)
                                     ,last_update_date = sysdate
                                     ,last_updated_by = fnd_global.user_id
                                    where exc_cus_id = v_exc_cus_id;
                                
                                  --print_xml('TAX_CODE',v_tax_code);
                                  --print_xml('BASE_RATE',replace(to_char(NVL(r_tax.base_rate,0)),',','.'));
                                  --print_xml('TAX_RATE',replace(to_char(r_tax.tax_rate),',','.'));
                                  --print_xml('COEF',replace(to_char(r_tax.coefficient),',','.'));
                                  
                                  r_xml.tax_code     := v_tax_code;
                                  r_xml.base_rate    := replace(to_char(NVL(r_tax.base_rate,0)),',','.');
                                  r_xml.tax_rate     := replace(to_char(r_tax.tax_rate),',','.');
                                  r_xml.coeficiente  := replace(to_char(v_coef),',','.');
                                  
                                  ELSE
                                  
                                     r_xml := null;
                                     print_log('No es necesario actualizar');
                                  
                                  END IF;
                            
                            END IF;
                      ELSE
                        r_xml := null;  --Para no informar en output
                      END IF;
                    ELSE
                      r_xml := null;  --Para no informar en output 
                    END IF;
                   
                   END IF;
                ELSE
                 IF r_xml.old_value = r_xml.new_value THEN
                   r_xml := null; --Si es Impuesto Nacional y no se actualiza no informo
                   print_log('No necesita actualizacion');
                 END IF;
                END IF;

            v_qty_upd := v_qty_upd +1 ;
            
            print_xml_ar_output(r_xml);
            --print_output('</G_PARTY>');

        EXCEPTION
         WHEN e_party_exception THEN
           print_log(v_error_message);
           --print_xml('ERROR_MESSAGE',v_error_message);
           r_xml := null;
           --print_output('</G_PARTY>');
           RAISE e_tax_exception;
         WHEN OTHERS THEN
           v_error_message := 'Error OTHERS: '||SQLERRM;
           print_log(v_error_message);
           --print_xml('ERROR_MESSAGE',v_error_message);
           r_xml := null;
           --print_output('</G_PARTY>');
           RAISE e_tax_exception;
        END;

       END LOOP;

       IF v_qty_upd = v_qty OR v_qty = 0 THEN

           print_log('OK');

           UPDATE xx_ar_tax_lines
                SET status = 'P'
                   ,last_update_date = sysdate
                   ,last_updated_by = fnd_global.user_id
                   ,last_update_login = fnd_global.login_id
                   ,request_id = fnd_global.conc_request_id
              WHERE tax_line_id = r_tax.tax_line_id;

         COMMIT;

       ELSE

        --ROLLBACK TO SAVEPOINT s_tax;
        ROLLBACK;
      
        v_error_message := 'No se actualizaron todos los domicilos';
        p_status := 'W';
        print_log(v_error_message);
        --print_xml('ERROR_MESSAGE',v_error_message);

         UPDATE xx_ar_tax_lines
            SET status = 'E'
               ,error_message = v_error_message
               ,last_update_date = sysdate
               ,last_updated_by = fnd_global.user_id
               ,last_update_login = fnd_global.login_id
               ,request_id = fnd_global.conc_request_id
          WHERE tax_line_id = r_tax.tax_line_id;

        COMMIT;

        p_status := 'W';

       END IF;

     EXCEPTION
      WHEN e_tax_exception THEN

      --ROLLBACK TO SAVEPOINT s_tax;
      ROLLBACK;
      
      print_log (v_error_message);
      --print_xml('ERROR_MESSAGE',v_error_message);

         UPDATE xx_ar_tax_lines
            SET status = 'E'
               ,error_message = v_error_message
               ,last_update_date = sysdate
               ,last_updated_by = fnd_global.user_id
               ,last_update_login = fnd_global.login_id
               ,request_id = fnd_global.conc_request_id
          WHERE tax_line_id = r_tax.tax_line_id;

          COMMIT;

        p_status := 'W';

      WHEN OTHERS THEN

      --ROLLBACK TO SAVEPOINT s_tax;
      ROLLBACK;

      v_error_message := 'Error OTHERS (Tax): '||SQLERRM;
      print_log (v_error_message);
      --print_xml('ERROR_MESSAGE',v_error_message);

         UPDATE xx_ar_tax_lines
            SET status = 'E'
               ,error_message = v_error_message
               ,last_update_date = sysdate
               ,last_updated_by = fnd_global.user_id
               ,last_update_login = fnd_global.login_id
               ,request_id = fnd_global.conc_request_id
          WHERE tax_line_id = r_tax.tax_line_id;

          COMMIT;

        p_status := 'W';

     END;

     print_output('</G_TAX_CATEGORY>');

   END LOOP;
   
   FOR r_no IN c_no_tax_lines(p_party_id) LOOP
   
    FOR r_party IN c_parties_no (r_no.party_id,r_no.tax_category) LOOP
    
     BEGIN
    
      IF r_party.dom_for = 'FOREIGN_ORIGIN' THEN
    
        BEGIN
                SELECT jzatca.tax_category_id
                  INTO v_tax_category_id
                  FROM jl_zz_ar_tx_categ_all jzatca
                      ,jl_zz_ar_tx_categ_all_dfv jzatca_dfv
                 WHERE jzatca.rowid        = jzatca_dfv.row_id
                   AND jzatca.org_id       = r_party.org_id
                   AND jzatca.tax_category = r_no.tax_category
                   AND jzatca.tax_rule_set = 'ARGENTINA';
                   
        EXCEPTION
         WHEN NO_DATA_FOUND THEN
            print_log('No esta configurado el tax category: '||r_no.tax_category||' en org_id: '||r_party.org_id);
            CONTINUE;
         WHEN OTHERS THEN
            v_error_message := 'Error al obtener Tax Category ID para: '||r_no.tax_category||'. Error: '||SQLERRM;
            RAISE e_no_party_exception;
        END;
        
                delete jl.jl_zz_ar_tx_cus_cls_all
                 where address_id = r_party.cust_acct_site_id
                   and tax_category_id = v_tax_category_id
                   and org_id = r_party.org_id;

                print_log('Categoria de Impuesto Inactivo'); 
      END IF;
      
      
      EXCEPTION
      WHEN e_no_party_exception THEN 
      NULL;
      END;
    END LOOP;
   
   END LOOP;

   IF p_status is null then
    p_status := 'S';
   ELSE
    p_error_message := 'No se pudieron procesar todos los impuestos';
    RAISE e_cust_exception;
   END IF;

   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_JL (-)');

EXCEPTION
 WHEN e_cust_exception THEN
   p_status := 'W';
   print_log(p_error_message);
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_JL (!)');
 WHEN OTHERS THEN
   p_status := 'W';
   p_error_message := 'Error OTHERS en TRANSFER_AR_JL. Error: '||SQLERRM;
   print_log(p_error_message);
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_JL_AR (!)');
END;

/*Concurrente Actualizar cliente, copia de AR TAX a Localizacion*/

PROCEDURE TRANSFER_AR_TAX_TO_JL (retcode             OUT VARCHAR2
                                ,errbuf              OUT VARCHAR2
                                ,p_party_id          IN  NUMBER
                                ,p_contributor_class IN  VARCHAR2) IS


v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);
e_cust_exception EXCEPTION;

BEGIN

    print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_TAX_TO_JL (+)');

    print_output('<XXARCTSU>');

    transfer_ar_jl(p_status             => v_status
                  ,p_error_message      => v_error_message
                  ,p_party_id           => p_party_id
                  ,p_contributor_class  => p_contributor_class);

    print_output('</XXARCTSU>');

    IF v_status != 'S' THEN
      RAISE e_cust_exception;
    END IF;

    print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_TAX_TO_JL (-)');

EXCEPTION
 WHEN E_CUST_EXCEPTION THEN
   retcode := 1;
   print_log(errbuf);
   IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
        print_log('Error Seteando Estado De Finalizacion');
   ELSE
        print_log('Estado de finalizacion seteado');
   END IF;
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_TAX_TO_JL (!)');
 WHEN OTHERS THEN
   retcode := 2;
   errbuf := 'Error OTHERS en TRANSFER_AR_TAX_TO_JL. Error: '||SQLERRM;
   print_log(errbuf);
   print_log('XX_AR_TAX_FUNCTIONS_PKG.TRANSFER_AR_TAX_TO_JL (!)');
   RAISE_APPLICATION_ERROR(-20001,'Error Inexperado en el proceso principal');
END;

/*Se usa en Pantalla AR TAX*/

PROCEDURE delete_tax_line(x_status_code   OUT VARCHAR2
                         ,x_error_message OUT VARCHAR2
                         ,x_tax_line_id   IN NUMBER) IS

BEGIN

    DELETE xx_ar_tax_lines
    where tax_line_id = x_tax_line_id;
    
    commit;
    
    x_status_code := 'S';
    
EXCEPTION
WHEN OTHERS THEN
  x_status_code := 'W';
  x_error_message := 'Error al eliminar registro. Error: '||SQLERRM;
END;

/*Se usa en Pantalla AR TAX*/

PROCEDURE delete_tax_line_cm05(x_status_code      OUT VARCHAR2
                              ,x_error_message    OUT VARCHAR2
                              ,x_tax_line_cm05_id  IN NUMBER) IS

BEGIN

    DELETE xx_ar_tax_lines_cm05
    where tax_line_cm05_id = x_tax_line_cm05_id;
    
    commit;
    
    x_status_code := 'S';
    
EXCEPTION
WHEN OTHERS THEN
  x_status_code := 'W';
  x_error_message := 'Error al eliminar registro. Error: '||SQLERRM;
END;


END; 
/

exit
