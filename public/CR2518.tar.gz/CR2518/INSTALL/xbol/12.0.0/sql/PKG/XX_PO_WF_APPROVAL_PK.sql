  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_WF_APPROVAL_PK" AUTHID CURRENT_USER IS
/* $Header: */
	PROCEDURE Set_Startup_Values(itemtype        in varchar2,
    	                         itemkey         in varchar2,
                                 actid           in number,
                                 funcmode        in varchar2,
                                 resultout       out NOCOPY varchar2);
	PROCEDURE get_po_lines_details ( document_id	in	varchar2,
    	                             display_type	in	varchar2,
        	                         document	    in out	NOCOPY varchar2,
            	                     document_type	in out	NOCOPY varchar2);
	FUNCTION Get_Last_PO_Price (p_document_id  IN NUMBER
	                            , p_item_id    IN NUMBER) RETURN NUMBER;
	PROCEDURE get_po_approve_msg (	 document_id	in	varchar2,
    	                             display_type	in	varchar2,
        	                         document	in out	NOCOPY varchar2,
            	                     document_type	in out	NOCOPY varchar2);
END XX_PO_WF_APPROVAL_PK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_WF_APPROVAL_PK" IS
/* $Header: */

  -- Read the profile option that enables/disables the debug log
  g_po_wf_debug VARCHAR2(1) := NVL(FND_PROFILE.VALUE('PO_SET_DEBUG_WORKFLOW_ON'),'N');
  g_document_subtype  PO_HEADERS_ALL.TYPE_LOOKUP_CODE%TYPE;

-- SetStartupValues
--  Iinitialize/assigns startup values to workflow attributes.
--
-- IN
--   itemtype, itemkey, actid, funcmode
-- OUT
--   Resultout
--    - Completed   - Activity was completed without any errors.
--
PROCEDURE Set_Startup_Values
  (
    itemtype IN VARCHAR2,
    itemkey  IN VARCHAR2,
    actid    IN NUMBER,
    funcmode IN VARCHAR2,
    resultout OUT NOCOPY VARCHAR2 )
IS
  l_document_type        VARCHAR2(25);
  l_doc_subtype          VARCHAR2(25);
  l_document_id          NUMBER;
  l_preparer_id          NUMBER;
  x_username             VARCHAR2(100);
  x_user_display_name    VARCHAR2(240);
  x_ff_username          VARCHAR2(100);
  x_ff_user_display_name VARCHAR2(240);
  x_ft_username          VARCHAR2(100);
  x_ft_user_display_name VARCHAR2(240);
  l_forward_to_id        NUMBER;
  l_forward_from_id      NUMBER;
  l_authorization_status VARCHAR2(25);
  l_open_form            VARCHAR2(200);
  l_update_req_url       VARCHAR2(1000);
  l_open_req_url         VARCHAR2(1000);
  l_resubmit_req_url     VARCHAR2(1000); -- Bug 636924, lpo, 03/31/98
  --Bug#3147435
  --Variables for VIEW_REQ_DTLS_URL, EDIT_REQ_URL and RESUBMIT_REQ_URL
  l_view_req_dtls_url  VARCHAR2(1000);
  l_edit_req_url       VARCHAR2(1000);
  l_resubmit_url       VARCHAR2(1000);
  l_error_msg          VARCHAR2(200);
  x_orgid              NUMBER;
  l_doc_string         VARCHAR2(200);
  l_preparer_user_name VARCHAR2(100);
  l_po_revision        NUMBER;
  l_interface_source   VARCHAR2(30);
  l_can_modify_flag    VARCHAR2(1);
  l_view_po_url        VARCHAR2(1000); -- HTML Orders R12
  l_edit_po_url        VARCHAR2(1000); -- HTML Orders R12
  l_style_id po_headers_all.style_id%TYPE;
  l_ga_flag po_headers_all.global_agreement_flag%TYPE;
  /*  Bug 7535468
  Increasing the length of x_progress from 200 to 1200 */
  x_progress VARCHAR2(1200);
  l_draft_id NUMBER:=-1; --Mod Project
  --Context Setting Revamp
  l_printer          VARCHAR2(30);
  l_conc_copies      NUMBER;
  l_conc_save_output VARCHAR2(1);
  --Bug 6164753
  l_external_url VARCHAR2(500);
  --Added by Eric Ma for IL PO Notification on Apr-13,2009,Begin
  ---------------------------------------------------------------------------
  lv_tax_region VARCHAR2(30); --tax region code
  ---------------------------------------------------------------------------
  --Added by Eric Ma for IL PO Notification on Apr-13,2009 ,End
  l_conf_header_id    NUMBER;
  l_imp_amendment_url VARCHAR2(1000);
  is_clm_enabled      VARCHAR2(1);
  l_review_msg varchar2(200); -- PO AME Project

BEGIN
  x_progress       := 'PO_REQAPPROVAL_INIT1.Set_Startup_Values: 01';
  IF (g_po_wf_debug = 'Y') THEN
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
  END IF;
  -- Do nothing in cancel or timeout mode
  --
  IF (funcmode <> wf_engine.eng_run) THEN
    resultout  := wf_engine.eng_null;
    RETURN;
  END IF;
  -- Set the multi-org context
  x_orgid    := wf_engine.GetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'ORG_ID');
  IF x_orgid IS NOT NULL THEN
    PO_MOAC_UTILS_PVT.set_org_context(x_orgid) ; -- <R12 MOAC>
  END IF;
  l_document_type := wf_engine.GetItemAttrText (itemtype => itemtype, itemkey => itemkey, aname => 'DOCUMENT_TYPE');
  l_document_id   := wf_engine.GetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'DOCUMENT_ID');
  l_doc_subtype   := wf_engine.GetItemAttrText (itemtype => itemtype, itemkey => itemkey, aname => 'DOCUMENT_SUBTYPE');
  -- CLM Apprvl
  l_draft_id    := PO_WF_UTIL_PKG.GetItemAttrNumber ( itemtype => itemType, itemkey => itemkey, aname => 'DRAFT_ID');
  IF l_draft_id IS NULL THEN
    l_draft_id  := -1;
  END IF;

  /* Since we are just starting the workflow assign the preparer_id to
  ** variable APPROVER_EMPID. This variable always holds the
  ** employee id of the approver i.e. activity VERIFY AUTHORITY will
  ** always use this employee id to verify authority against.
  ** If the preparer can not approve, then process FIND APPROVER will
  ** find an approver and put his/her employee_id in APPROVER_EMPID
  ** item attribute.
  */

  BEGIN --SD2180
    SELECT DISTINCT oc.comprador_id
    INTO l_preparer_id
    FROM po_headers_all           ph
       , xx_agronomo_interface_oc oc
    WHERE 1=1
    AND oc.orden_trabajo = ph.attribute1
    AND ph.attribute_category = 'AR'
    AND ph.po_header_id  = l_document_id;
  EXCEPTION
    WHEN OTHERS THEN
      l_preparer_id := wf_engine.GetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'PREPARER_ID');
  END;

  /*7125551, including the sql to get the value of l_can_modify_flag here*/
  SELECT CAN_APPROVER_MODIFY_DOC_FLAG
  INTO l_can_modify_flag
  FROM po_document_types
  WHERE DOCUMENT_TYPE_CODE = l_document_type
  AND DOCUMENT_SUBTYPE     = l_doc_subtype;

  PO_WF_UTIL_PKG.SetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'APPROVER_EMPID', avalue => l_preparer_id);
  /* Get the username and display_name of the preparer. This will
  ** be used as the FORWARD-FROM in the notifications.
  ** Initially the preparer is also considered as the approver, so
  ** set the approver_username also.
  */
  PO_REQAPPROVAL_INIT1.get_user_name(l_preparer_id, x_username, x_user_display_name);
  -- Bug 711141 fix (setting process owner here)
  wf_engine.SetItemOwner (itemtype => itemtype, itemkey => itemkey,
  /* { Bug 2148872:          owner    => 'PER:' || l_preparer_id);
  wf_engine.SetItemOwner needs 'owner' parameter to be passed as
  the internal user name of the owner in wf_users. To pass it as
  "PER:person_id" has been disallowed by WF.                    */
  owner => x_username); -- Bug 2148872 }
  -- Context Setting revamp (begin)
  l_printer          := fnd_profile.value('PRINTER');
  l_conc_copies      := to_number(fnd_profile.value('CONC_COPIES'));
  l_conc_save_output := fnd_profile.value('CONC_SAVE_OUTPUT');
  /* changed the call from wf_engine.setiteattrtext to
  po_wf_util_pkg.setitemattrtext because the later handles
  attrbute not found exception. req change order wf also
  uses these procedures and does not have the preparer_printer
  attribute, hence this was required */
  po_wf_util_pkg.SetItemAttrText (itemtype => itemType, itemkey => itemkey, aname => 'PREPARER_PRINTER', avalue => l_printer);
  po_wf_util_pkg.SetItemAttrNumber (itemtype => itemType, itemkey => itemkey, aname => 'PREPARER_CONC_COPIES', avalue => l_conc_copies);
  po_wf_util_pkg.SetItemAttrText (itemtype => itemType, itemkey => itemkey, aname => 'PREPARER_CONC_SAVE_OUTPUT', avalue => l_conc_save_output);
  --Context Setting revamp (end)
  PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'PREPARER_USER_NAME' , avalue => x_username);
  PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'PREPARER_DISPLAY_NAME' , avalue => x_user_display_name);
  PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'APPROVER_USER_NAME' , avalue => x_username);
  PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'APPROVER_DISPLAY_NAME' , avalue => x_user_display_name);
  /* Bug# 2308846: kagarwal
  ** Description: The forward from user was always set to the preparer
  ** in the Approval process. Hence if the forward from user was
  ** different from the preparer, the forward from was showing
  ** wrong information.
  **
  ** Fix Details: Modified the procedure Start_WF_Process() and
  ** Set_Startup_Values() to set the forward from attributes
  ** correctly.
  */
  l_forward_from_id     := PO_WF_UTIL_PKG.GetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'FORWARD_FROM_ID');
  IF (l_forward_from_id <> l_preparer_id) THEN
    PO_REQAPPROVAL_INIT1.get_user_name(l_forward_from_id, x_ff_username, x_ff_user_display_name);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'FORWARD_FROM_USER_NAME' , avalue => x_ff_username);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'FORWARD_FROM_DISP_NAME' , avalue => x_ff_user_display_name);
  ELSE
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'FORWARD_FROM_USER_NAME' , avalue => x_username);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'FORWARD_FROM_DISP_NAME' , avalue => x_user_display_name);
  END IF;
  /* Get the username (this is the name used to forward the notification to)
  ** from the FORWARD_TO_ID. We need to do this here!
  ** Also set the item attribute FORWARD_TO_USERNAME to that username.
  */
  l_forward_to_id    := PO_WF_UTIL_PKG.GetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'FORWARD_TO_ID');
  IF l_forward_to_id IS NOT NULL THEN
    /* kagarwal: Use a diff variable for username and display name
    ** for forward to as later we set the responder attributes to same
    ** as that of preparer using the var x_username and
    ** x_user_display_name
    */
    /* Get the forward-to display name */
    PO_REQAPPROVAL_INIT1.get_user_name(l_forward_to_id, x_ft_username, x_ft_user_display_name);
    /* Set the forward-to display name */
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'FORWARD_TO_USERNAME' , avalue => x_ft_username);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'FORWARD_TO_DISPLAY_NAME' , avalue => x_ft_user_display_name);
  END IF;
  -- Added by Eric Ma for IL PO Notification on Apr-13,2009 ,Begin
  -------------------------------------------------------------------------------------
  lv_tax_region := JAI_PO_WF_UTIL_PUB.Get_Tax_Region (pn_org_id => x_orgid);
  -------------------------------------------------------------------------------------
  -- Added by Eric Ma for IL PO Notification on Apr-13,2009 ,End
  /* Bug 1064651
  ** Init  RESPONDER to PREPARER if document is a requisition.
  */
  IF l_document_type = 'REQUISITION' THEN
    PO_WF_UTIL_PKG.SetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'RESPONDER_ID', avalue => l_preparer_id);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'RESPONDER_USER_NAME' , avalue => x_username);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'RESPONDER_DISPLAY_NAME' , avalue => x_user_display_name);
    /* Bug 3800933
    ** Need to set the preparer's language as worflow attribute for info template attachment of req approval
    */
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemtype, itemkey => itemkey, aname => 'PREPARER_LANGUAGE', avalue => userenv('LANG'));
    -- Added by Eric Ma for IL PO Notification on Apr-13,2009 ,Begin
    -------------------------------------------------------------------------------------
    IF lv_tax_region='JAI' THEN
      --open indian localization form
      l_open_form:=JAI_PO_WF_UTIL_PUB.Get_Jai_Open_Form_Command (pv_document_type => JAI_PO_WF_UTIL_PUB.G_REQ_DOC_TYPE);
      PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'OPEN_FORM_COMMAND' , avalue => l_open_form );
    END IF;
    -------------------------------------------------------------------------------------
    -- Added by Eric Ma for IL PO Notification on Apr-13,2009 ,End
  END IF;
  -- Set the Command for the button that opens the Enter PO/Releases form
  -- Note: the Open Form command for the requisition is hard-coded in the
  --       Requisition approval workflow.
  IF l_document_type IN ('PO', 'PA') THEN
    -- <HTML Orders R12 Start >
    -- Set the URL and form link attributes based on doc style and type
    IF l_doc_subtype IN ('BLANKET', 'CONTRACT') THEN
      l_ga_flag      := PO_WF_UTIL_PKG.GetItemAttrText (itemtype => itemtype, itemkey => itemkey, aname => 'GLOBAL_AGREEMENT_FLAG');
    END IF;
    IF (NVL(l_ga_flag,'N') = 'N' AND (l_doc_subtype = 'BLANKET' OR l_doc_subtype = 'CONTRACT')) OR l_doc_subtype = 'PLANNED' THEN --added the condition to check for contract PO also as part of bug 7125551 fix
      -- HTML Orders R12
      -- The url links are not applicable for local agreements
      l_view_po_url := NULL;
      l_edit_po_url := NULL;
      -- Modified by Eric Ma for IL PO Notification on Apr-13,2009 ,Begin
      -------------------------------------------------------------------------------------
      IF (lv_tax_region='JAI' AND l_doc_subtype = 'PLANNED') THEN
        --open indian localization form
        l_open_form:=JAI_PO_WF_UTIL_PUB.Get_Jai_Open_Form_Command (pv_document_type => JAI_PO_WF_UTIL_PUB.G_PO_DOC_TYPE);
      ELSE
        --Bug 7716930
  --Bug8399676 Removed the double quotes around MODIFY and POXSTNOT
        l_open_form := 'PO_POXPOEPO:PO_HEADER_ID=' || '&' || 'DOCUMENT_ID' || ' ACCESS_LEVEL_CODE=MODIFY' || ' POXPOEPO_CALLING_FORM=POXSTNOT';
      END IF;
      -------------------------------------------------------------------------------------
      -- Modified by Eric Ma for IL PO Notification on Apr-13,2009 ,End
    ELSIF NVL(l_ga_flag,'N') = 'Y' OR l_doc_subtype = 'STANDARD' THEN
      BEGIN
        SELECT style_id
        INTO l_style_id
        FROM po_headers_all
        WHERE po_header_id = l_document_id;
      EXCEPTION
      WHEN OTHERS THEN
        l_style_id := NULL;
      END;
      --CLM Apprvl
      IF l_draft_id   IS NOT NULL AND l_draft_id <> -1 THEN
        l_view_po_url := PO_REQAPPROVAL_INIT1.get_mod_url(p_po_header_id => l_document_id, p_draft_id => l_draft_id, p_doc_subtype => l_doc_subtype, p_mode => 'viewOnly');
      ELSE
        l_view_po_url := PO_REQAPPROVAL_INIT1.get_po_url(p_po_header_id => l_document_id, p_doc_subtype => l_doc_subtype, p_mode => 'viewOnly');
      END IF;
      x_progress       := 'PO_REQAPPROVAL_INIT1.get_po_url viewOnly' || 'l_view_po_url ::'|| l_view_po_url;
      IF (g_po_wf_debug = 'Y') THEN
        PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
      END IF;
      IF NVL(l_can_modify_flag,'N') = 'Y' THEN
        /*Bug 7125551, edit document link should not be available if approver can modify is
        unchecked for the document type.*/
        --CLM Apprvl
        IF l_draft_id   IS NOT NULL AND l_draft_id <> -1 THEN
          l_edit_po_url := PO_REQAPPROVAL_INIT1.get_mod_url(p_po_header_id => l_document_id,p_draft_id => l_draft_id, p_doc_subtype => l_doc_subtype, p_mode => 'update');
        ELSE
          l_edit_po_url := PO_REQAPPROVAL_INIT1.get_po_url(p_po_header_id => l_document_id, p_doc_subtype => l_doc_subtype, p_mode => 'update');
        END IF;
        x_progress       := 'PO_REQAPPROVAL_INIT1.get_po_url update' || 'l_edit_po_url ::'|| l_edit_po_url;
        IF (g_po_wf_debug = 'Y') THEN
          PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
        END IF;
      ELSE
        l_edit_po_url := NULL;
      END IF;
      IF PO_DOC_STYLE_GRP.is_standard_doc_style(l_style_id) = 'Y' THEN
        -- Modified by Eric Ma for IL PO Notification on Apr-13,2009 ,Begin
        -------------------------------------------------------------------------------------
        IF lv_tax_region='JAI' THEN
          --open indian localization form
          l_open_form:=JAI_PO_WF_UTIL_PUB.Get_Jai_Open_Form_Command (pv_document_type => JAI_PO_WF_UTIL_PUB.G_PO_DOC_TYPE);
        ELSE
          --STANDARD PO FORM
          --Bug 7716930
          l_open_form := 'PO_POXPOEPO:PO_HEADER_ID=' || '&' || 'DOCUMENT_ID' || ' ACCESS_LEVEL_CODE=MODIFY' || ' POXPOEPO_CALLING_FORM=POXSTNOT';
        END IF;
        -------------------------------------------------------------------------------------
        -- Modified by Eric Ma for IL PO Notification on Apr-13,2009 ,End
      ELSE
        l_open_form := NULL;
      END IF;
    END IF;
    -- <HTML Orders R12 End >
  ELSIF l_document_type = 'RELEASE' THEN
    -- Added by Eric Ma for IL PO Notification on Apr-13,2009 ,Begin
    -------------------------------------------------------------------------------------
    IF lv_tax_region='JAI' THEN
      --open indian localization form
      l_open_form:=JAI_PO_WF_UTIL_PUB.Get_Jai_Open_Form_Command (pv_document_type => JAI_PO_WF_UTIL_PUB.G_REL_DOC_TYPE);
    ELSE
      --STANDARD RELEASE FORM
      --Bug 7716930
      l_open_form := 'PO_POXPOERL:PO_RELEASE_ID=' || '&' || 'DOCUMENT_ID' || ' ACCESS_LEVEL_CODE=MODIFY' || ' POXPOERL_CALLING_FORM=POXSTNOT';
    END IF;
    -------------------------------------------------------------------------------------
    -- Added by Eric Ma for IL PO Notification on Apr-13,2009 ,End
    -- HTML Orders R12
    -- The url links are not applicable for releases
    l_view_po_url := NULL;
    l_edit_po_url := NULL;
  END IF;
  IF (l_document_type <> 'REQUISITION') THEN
    -- HTML Orders R12
    -- Set the URL and form attributes
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'OPEN_FORM_COMMAND' , avalue => l_open_form);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'VIEW_DOC_URL' , avalue => l_view_po_url);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'EDIT_DOC_URL' , avalue => l_edit_po_url);
  END IF;
  IF (fnd_profile.value('POR_SSP4_INSTALLED') = 'Y' AND l_document_type = 'REQUISITION' AND po_core_s.get_product_install_status('ICX') = 'I') THEN
    --Bug#3147435
    --Set the values for workflow attribute
    --VIEW_REQ_DTLS_URL and EDIT_REQ_URL
    l_view_req_dtls_url := 'JSP:/OA_HTML/OA.jsp?OAFunc=ICX_POR_LAUNCH_IP' || '&' || 'porMode=viewReq' || '&' || 'porReqHeaderId=' || TO_CHAR(l_document_id) || '&' ||
    '_OrgId=' || TO_CHAR(x_orgid) || '&' || 'addBreadCrumb=Y'|| '&' ||   'currNid=-&#NID-' ;
    l_edit_req_url      := 'JSP:/OA_HTML/OA.jsp?OAFunc=ICX_POR_LAUNCH_IP' || '&' || 'porMode=approverCheckout' || '&' || 'porReqHeaderId=' || TO_CHAR(l_document_id) || '&' || '_OrgId=' || TO_CHAR(x_orgid) || '&' || 'currNid=-&#NID-';
    l_resubmit_url      := 'JSP:/OA_HTML/OA.jsp?OAFunc=ICX_POR_LAUNCH_IP' || '&' || 'porMode=resubmitReq' || '&' || 'porReqHeaderId=' || TO_CHAR(l_document_id) || '&' || '_OrgId=' || TO_CHAR(x_orgid);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'VIEW_REQ_DTLS_URL', avalue => l_view_req_dtls_url);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'EDIT_REQ_URL', avalue => l_edit_req_url);
    PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'RESUBMIT_REQ_URL', avalue => l_resubmit_url);
    is_clm_enabled        := NVL(FND_PROFILE.VALUE('POR_IS_CLM_ENABLED'),'N');
    IF is_clm_enabled      = 'Y' THEN
      l_conf_header_id    := PO_WF_UTIL_PKG.GetItemAttrNumber (itemtype => itemtype, itemkey => itemkey, aname => 'CONFORMED_HEADER_ID');
      l_imp_amendment_url := 'JSP:/OA_HTML/OA.jsp?OAFunc=ICX_POR_LAUNCH_IP' || '&' ||
    'porMode=implementAmendment' || '&' || 'porReqHeaderId=' || TO_CHAR(l_document_id) || '&' || '_OrgId=' ||
    TO_CHAR(x_orgid) || '&' || 'porConfHeaderId=' || TO_CHAR(l_conf_header_id) || '&' || 'porCaller=BUYER';
      PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'IMPL_AMENDMENT_BUYER_URL', avalue => l_imp_amendment_url);
      l_imp_amendment_url := 'JSP:/OA_HTML/OA.jsp?OAFunc=ICX_POR_LAUNCH_IP' || '&' || 'porMode=implementAmendment' || '&' ||
    'porReqHeaderId=' || TO_CHAR(l_document_id) || '&' || '_OrgId=' || TO_CHAR(x_orgid) || '&' ||
    'porConfHeaderId=' || TO_CHAR(l_conf_header_id) || '&' || 'porCaller=SOURCING_BUYER';
      PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'IMPL_AMENDMENT_NEG_URL', avalue => l_imp_amendment_url);
    END IF;
    /* Removed call for  jumpIntoFunction() to set the attributes value.
    Instead of that setting the values of l_view_req_dtls_url, l_edit_req_url and l_resubmit_url variables
    into corrosponding attributes */
    l_open_req_url   := l_view_req_dtls_url;
    l_update_req_url := l_edit_req_url;
    -- Bug 636924, lpo, 03/31/98
    -- Added resubmit link.
    l_resubmit_req_url := l_resubmit_url;
    -- End of fix. Bug 636924, lpo, 03/31/98
    wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'REQ_URL' , avalue => l_open_req_url);
    wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'REQ_UPDATE_URL' , avalue => l_update_req_url);
    -- Bug 636924, lpo, 03/31/98
    -- Added resubmit workflow attribute.
    wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'REQ_RESUBMIT_URL' , avalue => l_resubmit_req_url);
    l_interface_source := wf_engine.GetItemAttrText (itemtype => itemtype, itemkey => itemkey, aname => 'INTERFACE_SOURCE_CODE');
    l_doc_subtype      := wf_engine.GetItemAttrText (itemtype => itemtype, itemkey => itemkey, aname => 'DOCUMENT_SUBTYPE');
    -- Not showing the open form icon if this is an IP req and owner can't
    -- modify.
    IF l_can_modify_flag = 'N' AND l_interface_source = 'POR' THEN
      wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'OPEN_FORM_COMMAND' , avalue => '');
    END IF;
  END IF;
  /* Set the Subject of the Approval notification initially to
  ** "requires your approval". If the user enters an invalid forward-to
  ** then this messages gets nulled-out and the "Invalid Forward-to"
  ** message gets a value (see notification: Approve Requisition).
  */
  fnd_message.set_name ('PO','PO_WF_NOTIF_REQUIRES_APPROVAL');
  l_error_msg := fnd_message.get;
  wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'REQUIRES_APPROVAL_MSG' , avalue => l_error_msg);
  wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'WRONG_FORWARD_TO_MSG' , avalue => '');
  /* Get the orignial authorization status from the document
  ** This has to be done here as we set the document status to
  ** IN-PROCESS after this.
  */
  IF l_document_type='REQUISITION' THEN
    SELECT AUTHORIZATION_STATUS
    INTO l_authorization_status
    FROM po_requisition_headers_all
    WHERE REQUISITION_HEADER_ID = l_document_id;
    /* Bug#1810322: kagarwal
    ** Desc: If the original authorization status is IN PROCESS or PRE-APPROVED
    ** for Reqs then we need to store INCOMPLETE as the original authorization
    ** status.
    */
    IF l_authorization_status IN ('IN PROCESS', 'PRE-APPROVED') THEN
      l_authorization_status  := 'INCOMPLETE';
    END IF;
  ELSIF l_document_type IN ('PO','PA') THEN
    -- Mod Project Start
    SELECT DECODE(draft_id, -1, AUTHORIZATION_STATUS, STATUS),
      NVL(REVISION_NUM,0)
    INTO l_authorization_status,
      l_po_revision
    FROM po_headers_merge_v
    WHERE PO_HEADER_ID = l_document_id
    AND draft_id       = l_draft_id;
    --Mod Project end
    /* Bug#1810322: kagarwal
    ** Desc: If the original authorization status is IN PROCESS or PRE-APPROVED
    ** for PO/Releases then we need to store REQUIRES REAPPROVAL as the original
    ** authorization status if the revision number is greater than 0 else
    ** INCOMPLETE.
    */
    IF (l_authorization_status IN ('IN PROCESS', 'PRE-APPROVED') AND l_draft_id =-1) THEN
      IF l_po_revision          > 0 THEN
        l_authorization_status := 'REQUIRES REAPPROVAL';
      ELSE
        l_authorization_status := 'INCOMPLETE';
      END IF;
    ELSIF (l_authorization_status IN ('IN PROCESS', 'PRE-APPROVED') AND l_draft_id <>-1) THEN
      l_authorization_status      := 'DRAFT';
    END IF;
  ELSIF l_document_type = 'RELEASE' THEN
    SELECT AUTHORIZATION_STATUS,
      NVL(REVISION_NUM,0)
    INTO l_authorization_status,
      l_po_revision
    FROM po_releases_all
    WHERE PO_RELEASE_ID         = l_document_id;
    IF l_authorization_status  IN ('IN PROCESS', 'PRE-APPROVED') THEN
      IF l_po_revision          > 0 THEN
        l_authorization_status := 'REQUIRES REAPPROVAL';
      ELSE
        l_authorization_status := 'INCOMPLETE';
      END IF;
    END IF;
  END IF;
  wf_engine.SetItemAttrText ( itemtype => itemType, itemkey => itemkey, aname => 'ORIG_AUTH_STATUS' , avalue => l_authorization_status);
  IF l_document_type='REQUISITION' THEN
    /* bug 2480327 notification UI enhancement
    add  &#NID to PLSQL document attributes
    */
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'PO_REQ_APPROVE_MSG', avalue => 'PLSQL:PO_WF_REQ_NOTIFICATION.GET_PO_REQ_APPROVE_MSG/'|| itemtype||':'|| itemkey||':'|| '&'||'#NID');
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'PO_REQ_APPROVED_MSG', avalue => 'PLSQL:PO_WF_REQ_NOTIFICATION.GET_PO_REQ_APPROVED_MSG/'|| itemtype||':'|| itemkey||':'|| '&'||'#NID');
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'PO_REQ_NO_APPROVER_MSG', avalue => 'PLSQL:PO_WF_REQ_NOTIFICATION.GET_PO_REQ_NO_APPROVER_MSG/'|| itemtype||':'|| itemkey||':'|| '&'||'#NID');
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'PO_REQ_REJECT_MSG', avalue => 'PLSQL:PO_WF_REQ_NOTIFICATION.GET_PO_REQ_REJECT_MSG/'|| itemtype||':'|| itemkey||':'|| '&'||'#NID');
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'REQ_LINES_DETAILS', avalue => 'PLSQL:PO_WF_REQ_NOTIFICATION.GET_REQ_LINES_DETAILS/'|| itemtype||':'|| itemkey);
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'ACTION_HISTORY', avalue => 'PLSQL:PO_WF_REQ_NOTIFICATION.GET_ACTION_HISTORY/'|| itemtype||':'|| itemkey);
  elsif l_document_type IN ('PO', 'PA', 'RELEASE') THEN
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'PO_APPROVE_MSG', avalue => 'PLSQL:XX_PO_WF_PO_NOTIFICATION.GET_PO_APPROVE_MSG/' || itemtype || ':' || itemkey);
    -- <BUG 7006113>
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'PO_LINES_DETAILS', avalue => 'PLSQLCLOB:XX_PO_WF_PO_NOTIFICATION.GET_PO_LINES_DETAILS/'|| itemtype||':'|| itemkey);
    wf_engine.SetItemAttrText(itemtype => itemtype, itemkey => itemkey, aname => 'ACTION_HISTORY', avalue => 'PLSQL:XX_PO_WF_PO_NOTIFICATION.GET_ACTION_HISTORY/'|| itemtype||':'|| itemkey);
  END IF;
  --Bug 6164753
  l_external_url := fnd_profile.value('POS_EXTERNAL_URL');
  PO_WF_UTIL_PKG.SetItemAttrText ( itemtype => itemtype, itemkey => itemkey, aname => '#WFM_HTMLAGENT', avalue => l_external_url);
  --Bug 6164753

   /* PO AME Project :Start
  Setting requires review message */
  fnd_message.set_name ('PO','PO_WF_NOTIF_REQUIRES_REVIEW');
  l_review_msg := fnd_message.get;
  PO_WF_UTIL_PKG.SetItemAttrText( itemtype => itemType, itemkey => itemkey, aname => 'REQUIRES_REVIEW_MSG' , avalue => l_review_msg);
  /* PO AME Project :End */

  resultout := wf_engine.eng_completed || ':' || 'ACTIVITY_PERFORMED';
  --
  x_progress       := 'PO_REQAPPROVAL_INIT1.Set_Startup_Values: 03'|| 'Open Form Command= ' || l_open_form;
  IF (g_po_wf_debug = 'Y') THEN
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
  END IF;
EXCEPTION
WHEN OTHERS THEN
  l_doc_string         := PO_REQAPPROVAL_INIT1.get_error_doc(itemType, itemkey);
  l_preparer_user_name := PO_REQAPPROVAL_INIT1.get_preparer_user_name(itemType, itemkey);
  wf_core.context('PO_REQAPPROVAL_INIT1','Set_Startup_Values',x_progress);
  PO_REQAPPROVAL_INIT1.send_error_notif(itemType, itemkey, l_preparer_user_name, l_doc_string, sqlerrm, 'PO_REQAPPROVAL_INIT1.SET_STARTUP_VALUES');
  raise;
END Set_Startup_Values;


  PROCEDURE get_po_lines_details ( document_id  in  varchar2,
                                   display_type  in  varchar2,
                                   document      in out  NOCOPY varchar2,
                                   document_type  in out  NOCOPY varchar2) IS

    l_item_type    wf_items.item_type%TYPE;
    l_item_key     wf_items.item_key%TYPE;

    l_document_id      po_lines.po_header_id%TYPE;
    l_org_id           po_lines.org_id%TYPE;
    l_document_type    VARCHAR2(25);

    l_document         VARCHAR2(32000) := '';

    l_currency_code    fnd_currencies.currency_code%TYPE;

    -- Bug 3668188: added new local var. note: the length of this
    -- varchar was determined based on the length in POXWPA1B.pls,
    -- which is the other place 'OPEN_FORM_COMMAND' attribute is used
    l_open_form_command VARCHAR2(200);


    NL                  VARCHAR2(1) := fnd_global.newline;

    i               NUMBER := 0;
    max_lines_dsp       NUMBER := 20;
    l_line_count        NUMBER := 0; -- <BUG 3616816> # lines/shipments on document
    l_num_records_to_display NUMBER;      -- <BUG 3616816> actual # of records to be displayed in table
    line_mesg           VARCHAR2(240);
    curr_len            NUMBER := 0;
    prior_len           NUMBER := 0;

    -- po lines cursor

      -- <BUG 3616816 START> Declare TABLEs for each column that is selected
      -- from po_line_csr and po_line_loc_csr.
      --
      TYPE line_num_tbl_type IS TABLE OF PO_LINES.line_num%TYPE;
      TYPE shipment_num_tbl_type IS TABLE OF PO_LINE_LOCATIONS.shipment_num%TYPE;
      TYPE item_num_tbl_type IS TABLE OF MTL_SYSTEM_ITEMS_KFV.concatenated_segments%TYPE;
      TYPE item_revision_tbl_type IS TABLE OF PO_LINES.item_revision%TYPE;
      TYPE item_desc_tbl_type IS TABLE OF PO_LINES.item_description%TYPE;
      TYPE uom_tbl_type IS TABLE OF MTL_UNITS_OF_MEASURE.unit_of_measure_tl%TYPE;
      TYPE quantity_tbl_type IS TABLE OF PO_LINES.quantity%TYPE;
      TYPE unit_price_tbl_type IS TABLE OF PO_LINES.unit_price%TYPE;
      TYPE amount_tbl_type IS TABLE OF PO_LINES.amount%TYPE;
      TYPE location_tbl_type IS TABLE OF HR_LOCATIONS.location_code%TYPE;
      TYPE organization_name_tbl_type IS TABLE OF ORG_ORGANIZATION_DEFINITIONS.organization_name%TYPE;
      TYPE need_by_date_tbl_type IS TABLE OF PO_LINE_LOCATIONS.need_by_date%TYPE;
      TYPE promised_date_tbl_type IS TABLE OF PO_LINE_LOCATIONS.promised_date%TYPE;
      TYPE shipment_type_tbl_type IS TABLE OF PO_LINE_LOCATIONS.shipment_type%TYPE;
      -- Agregado por Quanam 10-12-2010 CGR
      TYPE last_po_price_tbl_type IS TABLE OF PO_LINES.unit_price%TYPE;

      l_line_num_tbl         line_num_tbl_type;
      l_shipment_num_tbl     shipment_num_tbl_type;
      l_item_num_tbl         item_num_tbl_type;
      l_item_revision_tbl    item_revision_tbl_type;
      l_item_desc_tbl        item_desc_tbl_type;
      l_uom_tbl              uom_tbl_type;
      l_quantity_tbl         quantity_tbl_type;
      l_unit_price_tbl       unit_price_tbl_type;
      l_amount_tbl           amount_tbl_type;
      l_location_tbl         location_tbl_type;
      l_org_name_tbl         organization_name_tbl_type;
      l_need_by_date_tbl     need_by_date_tbl_type;
      l_promised_date_tbl    promised_date_tbl_type;
      l_shipment_type_tbl    shipment_type_tbl_type;
      -- Agregado por Quanam 10-12-2010 CGR
      l_last_po_price_tbl    last_po_price_tbl_type;
      --
      -- <BUG 3616816 END>

  /* Bug# 1419139: kagarwal
  ** Desc: The where clause pol.org_id = msi.organization_id(+) in the
  ** PO lines cursor, po_line_csr, is not correct as the pol.org_id
  ** is the operating unit which is not the same as the inventory
  ** organization_id.
  **
  ** We need to use the financials_system_parameter table for the
  ** inventory organization_id.
  **
  ** Also did the similar changes for the Release cursor,po_line_loc_csr.
  */

  /* Bug 2401933: sktiwari
     Modifying cursor po_line_csr to return the translated UOM value
     instead of unit_meas_lookup_code.
  */

  CURSOR po_line_csr(v_document_id NUMBER) IS
  SELECT pol.line_num,
         msi.concatenated_segments,
         pol.item_revision,
         pol.item_description,
  --     pol.unit_meas_lookup_code, -- bug 2401933.remove
         nvl(muom.unit_of_measure_tl, pol.unit_meas_lookup_code), -- bug 2401933.add
         Nvl(pol.quantity,pol.QUANTITY_COMMITTED),
         pol.unit_price,
         Nvl(nvl(pol.amount, pol.quantity * pol.unit_price),pol.COMMITTED_AMOUNT)
         ,XX_PO_WF_APPROVAL_PK.Get_Last_PO_Price(pol.po_header_id,pol.item_id) last_po_price
    FROM po_lines   pol,
         mtl_system_items_kfv   msi,
         mtl_units_of_measure   muom,     -- bug 2401933.add
         financials_system_parameters  fsp
   WHERE pol.po_header_id = v_document_id
     AND pol.item_id = msi.inventory_item_id(+)
     AND NVL(msi.organization_id, fsp.inventory_organization_id) =
            fsp.inventory_organization_id
  /* Bug 2299484 fixed. prevented the canceled lines to be displayed
     in notifications.
  */
     AND NVL(pol.cancel_flag,'N') = 'N'
     AND muom.unit_of_measure (+) = pol.unit_meas_lookup_code  -- bug 2401933.add
   ORDER BY pol.line_num;

  -- release shipments cursor

  /* Bug# 1530303: kagarwal
  ** Desc: We need to change the where clause as the item
  ** may not be an inventory item. For this case we should
  ** have an outer join with the mtl_system_items_kfv.
  **
  ** Changed the condition:
  ** pol.item_id = msi.inventory_item_id
  ** to pol.item_id = msi.inventory_item_id(+)
  **
  */

  /* Bug# 1718725: kagarwal
  ** Desc: The unit of measure may be null at the shipment level
  ** hence in this case we need to get the uom from line level.
  **
  ** Changed nvl(pll.unit_meas_lookup_code, pol.unit_meas_lookup_code)
  */
  /* Bug# 1770951: kagarwal
  ** Desc: For Releases we should consider the price_override on the shipments
  ** and not the price on the Blanket PO line as the shipment price could be
  ** different if the price override is enabled on the Blanket.
  */

  /* Bug 2401933: sktiwari
     Modifying cursor po_line_loc_csr to return the translated UOM value
     instead of unit_meas_lookup_code.
  */

  CURSOR po_line_loc_csr(v_document_id NUMBER) IS
  SELECT pll.shipment_num,
         msi.concatenated_segments,
         pol.item_revision,
         pol.item_description,
  -- Bug 2401933.start
  --     nvl(pll.unit_meas_lookup_code, pol.unit_meas_lookup_code)
  --         unit_meas_lookup_code,
         nvl(muom.unit_of_measure_tl, pol.unit_meas_lookup_code),
  -- Bug 2401933.end
         pll.quantity,
         nvl(pll.price_override, pol.unit_price) unit_price,
         hrl.location_code,
         ood.organization_name,
         pll.need_by_date,
         pll.promised_date,
         pll.shipment_type
         ,XX_PO_WF_APPROVAL_PK.Get_Last_PO_Price(pol.po_header_id,pol.item_id) last_po_price
    FROM po_lines   pol,
         po_line_locations pll,
         mtl_system_items_kfv msi,
         hr_locations_all hrl,
         hz_locations hz,
         org_organization_definitions ood,
         mtl_units_of_measure   muom,     -- Bug 2401933.add
         financials_system_parameters  fsp
    where  PLL.PO_RELEASE_ID = v_document_id
    and    PLL.po_line_id    = POL.po_line_id
    and    PLL.ship_to_location_id = HRL.location_id (+)
    and    PLL.ship_to_location_id = HZ.location_id (+)
    and    PLL.ship_to_organization_id = OOD.organization_id
    and    pol.item_id = msi.inventory_item_id(+)
    and    NVL(msi.organization_id, fsp.inventory_organization_id) =
            fsp.inventory_organization_id
   /* Bug 2299484 fixed. prevented the canceled shipments to be displayed
     in notifications.
  */
     AND NVL(PLL.cancel_flag,'N') = 'N'
     AND muom.unit_of_measure (+) = pol.unit_meas_lookup_code  -- Bug 2401933.add
    order by Shipment_num asc;

  BEGIN

    l_item_type := substr(document_id, 1, instr(document_id, ':') - 1);
    l_item_key := substr(document_id, instr(document_id, ':') + 1,
                         length(document_id) - 2);

    /* Bug# 2353153
    ** Setting application context
    */

    -- bug 4556437 : context setting revamp, ctx setting not required.
    --PO_REQAPPROVAL_INIT1.Set_doc_mgr_context(l_item_type, l_item_key);

    l_document_id := wf_engine.GetItemAttrNumber (itemtype   => l_item_type,
                                               itemkey    => l_item_key,
                                               aname      => 'DOCUMENT_ID');

    l_org_id := wf_engine.GetItemAttrNumber (itemtype   => l_item_type,
                                             itemkey    => l_item_key,
                                             aname      => 'ORG_ID');

    l_document_type := wf_engine.GetItemAttrText (itemtype   => l_item_type,
                                                 itemkey    => l_item_key,
                                                 aname      => 'DOCUMENT_TYPE');

    fnd_client_info.set_org_context(to_char(l_org_id));

    /* Bug# 1686066: kagarwal
    ** Desc: Use the functional currency of the PO for the precision of
    ** line amounts.
    */

    l_currency_code := wf_engine.GetItemAttrText(itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'FUNCTIONAL_CURRENCY');


    -- Bug 3668188
    l_open_form_command := wf_engine.GetItemAttrText(itemtype   => l_item_type,
                                            itemkey    => l_item_key,
                                            aname      => 'OPEN_FORM_COMMAND');


  /* Bug# 2668222: kagarwal
  ** Desc: Using profile PO_NOTIF_LINES_LIMIT to get the maximum
  ** number of PO lines to be displayed in Approval notification.
  ** The same profile is also used for Requisitions.
  */

    max_lines_dsp:= to_number(fnd_profile.value('PO_NOTIF_LINES_LIMIT'));

    if max_lines_dsp is NULL then
       max_lines_dsp := 20;
    end if;

      -- <BUG 3616816 START> Fetch Release Shipments/PO Lines data into Tables.
      --
      IF ( l_document_type = 'RELEASE' ) THEN

          OPEN po_line_loc_csr(l_document_id);

          FETCH po_line_loc_csr BULK COLLECT INTO l_shipment_num_tbl
                                                , l_item_num_tbl
                                                , l_item_revision_tbl
                                                , l_item_desc_tbl
                                                , l_uom_tbl
                                                , l_quantity_tbl
                                                , l_unit_price_tbl
                                                , l_location_tbl
                                                , l_org_name_tbl
                                                , l_need_by_date_tbl
                                                , l_promised_date_tbl
                                                , l_shipment_type_tbl
                                                -- Agregado por Quanam 10-12-2010 CGR
                          , l_last_po_price_tbl;

          l_line_count := po_line_loc_csr%ROWCOUNT; -- Get # of records fetched.

          CLOSE po_line_loc_csr;

      ELSE

          OPEN po_line_csr(l_document_id);

          FETCH po_line_csr BULK COLLECT INTO l_line_num_tbl
                                            , l_item_num_tbl
                                            , l_item_revision_tbl
                                            , l_item_desc_tbl
                                            , l_uom_tbl
                                            , l_quantity_tbl
                                            , l_unit_price_tbl
                                            , l_amount_tbl
                                            -- Agregado por Quanam 10-12-2010 CGR
                        , l_last_po_price_tbl;

          l_line_count := po_line_csr%ROWCOUNT; -- Get # of records fetched.

          CLOSE po_line_csr;

      END IF;
      --
      -- <BUG 3616816 END>

      -- <BUG 3616816 START> Determine the actual number of records to display
      -- in the table.
      --
      IF ( l_line_count > max_lines_dsp ) THEN
          l_num_records_to_display := max_lines_dsp;
      ELSE
          l_num_records_to_display := l_line_count;
      END IF;
      --
      -- <BUG 3616816 END>

    if (display_type = 'text/html') then

      if (nvl(l_document_type, 'PO') <> 'RELEASE') then

        l_document := NL || NL || '<!-- PO_LINE_DETAILS -->'|| NL || NL || '<P><B>';
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_PO_LINE_DETAILS');
        l_document := l_document || '</B>' || NL || '<P>';     -- <BUG 3616816>

          -- <BUG 3616816 START> Only display message if # of actual lines is
          -- greater than maximum limit.
          --
          IF ( l_line_count > max_lines_dsp ) THEN

              -- Bug 3668188: changed the code check (originally created
              -- in bug 3607009) that determines which message to show
              -- based on whether Open Document icon is shown in the notif.
              -- The value of WF attribute 'OPEN_FORM_COMMAND' is set in a
              -- previous node, using the get_po_user_msg_attribute procedure.
              --
              IF  ( l_open_form_command IS NULL ) THEN
                  -- "The first [COUNT] Purchase Order lines are summarized
                  -- below. For information on additional lines, please click
                  -- the Open Document icon."
                  FND_MESSAGE.set_name('PO','PO_WF_NOTIF_PO_LINE_MESG');
              ELSE
                  -- "The first [COUNT] Purchase Order lines are summarized below."
                  FND_MESSAGE.set_name('PO','PO_WF_NOTIF_PO_LINE_MESG_TRUNC');
              END IF;

              FND_MESSAGE.set_token('COUNT',to_char(max_lines_dsp));
              line_mesg := FND_MESSAGE.get;
              l_document := l_document || line_mesg || '<P>';


          END IF;
          --
          -- <BUG 3616816 END>

        l_document := l_document || NL || '<TABLE border=1 cellpadding=2 cellspacing=1 summary="' ||  fnd_message.get_string('ICX','ICX_POR_TBL_PO_TO_APPROVE_SUM') || '"> '|| NL;

        l_document := l_document || '<TR>' || NL;

        l_document := l_document || '<TH  id="lineNum_1">' ||
                        fnd_message.get_string('PO', 'PO_WF_NOTIF_LINE_NUMBER') || '</TH>' || NL;

        l_document := l_document || '<TH  id="itemNum_1">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_NUMBER') || '</TH>' || NL;

         l_document := l_document || '<TH  id="itemRev_1">' ||
                    fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_REVISION') || '</TH>' || NL;

        l_document := l_document || '<TH  id="itemDesc_1">' ||
                         fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_DESC') || '</TH>' || NL;

        l_document := l_document || '<TH  id="uom_1">' ||
                        fnd_message.get_string('PO', 'PO_WF_NOTIF_UOM') || '</TH>' || NL;

        l_document := l_document || '<TH  id="quant_1">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_QUANTITY') || '</TH>' || NL;

        l_document := l_document || '<TH  id="unitPrice_1">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_UNIT_PRICE') || '</TH>' || NL;

        l_document := l_document || '<TH  id="lineAmt_1">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_LINE_AMOUNT') || '</TH>' || NL;

      -- Quanam 07-12-2010 CGR
      -- Agrego titulo columna precio ultima compra
        l_document := l_document || '<TH  id="lastAmt_1">' ||
                      fnd_message.get_string('XBOL', 'XX_PO_WF_NOTIF_LINE_ULTCO') || '</TH>' || NL;
      -- Fin precio ultima compra

        l_document := l_document || '</TR>' || NL;

          curr_len  := lengthb(l_document);
          prior_len := curr_len;

          FOR i IN 1..l_num_records_to_display LOOP              -- <BUG 3616816>

                /* Exit the cursor if the current document length and 2 times the
                ** length added in prior line exceeds 32000 char */

                if (curr_len + (2 * (curr_len - prior_len))) >= 32000 then
                   exit;
                end if;

                prior_len := curr_len;

            l_document := l_document || '<TR>' || NL;

            l_document := l_document || '<TD nowrap align=center headers="lineNum_1">'
                  || nvl(to_char(l_line_num_tbl(i)), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap headers="itemNum_1">'
                  || nvl(l_item_num_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap headers="itemRev_1">'
                  || nvl(l_item_revision_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap headers="itemDesc_1">'
                  || nvl(l_item_desc_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap headers="uom_1">'
                  || nvl(l_uom_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap align=right headers="quant_1">'
                  || nvl(to_char(l_quantity_tbl(i)), '') || '</TD>' || NL;

  /* Bug 2868931: kagarwal
  ** We will not format the unit price on the lines in notifications
  */
                -- Bug 3547777. Added the nvl clauses to unit_price and line_
                -- amount so that box is still displayed even if value is null.
            l_document := l_document || '<TD nowrap align=right headers="unitPrice_1">' ||
                         nvl(TO_CHAR(l_unit_price_tbl(i)),'') || '</TD>' || NL;

            l_document := l_document || '<TD nowrap align=right headers="lineAmt_1">' ||
                        nvl(TO_CHAR(l_amount_tbl(i), FND_CURRENCY.GET_FORMAT_MASK(
                              l_currency_code, 30)),'') || '</TD>' || NL;

        -- Precio ultima compra 10-12-2010 CGR
        l_document := l_document || '<TD nowrap align=right headers="lastAmt_1">' ||
                         nvl(TO_CHAR(l_last_po_price_tbl(i)),'') || '</TD>' || NL;


            l_document := l_document || '</TR>' || NL;

                curr_len  := lengthb(l_document);
        end loop;

      else    -- release

        l_document := NL || NL || '<!-- RELEASE_SHIPMENT_DETAILS -->'|| NL || NL || '<P><B>';
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_SHIP_DETAILS');
        l_document := l_document || '</B>' || NL || '<P>';

          -- <BUG 3616816 START> Only display message if # of actual lines is
          -- greater than maximum limit.
          --
          IF ( l_line_count > max_lines_dsp ) THEN
              FND_MESSAGE.set_name('PO','PO_WF_NOTIF_PO_REL_SHIP_MESG');
              FND_MESSAGE.set_token('COUNT',to_char(max_lines_dsp));
              line_mesg := FND_MESSAGE.get;
              l_document := l_document || line_mesg || '<P>';
          END IF;
          --
          -- <BUG 3616816 END>

        l_document := l_document || '<TABLE border=1 cellpadding=2 cellspacing=1 summary="' ||  fnd_message.get_string('ICX','ICX_POR_TBL_BL_TO_APPROVE_SUM') || '"> '|| NL;

        l_document := l_document || '<TR>' || NL;

        l_document := l_document || '<TH  id="shipNum_2">' ||
                        fnd_message.get_string('PO', 'PO_WF_NOTIF_SHIP_NUMBER') || '</TH>' || NL;

        l_document := l_document || '<TH  id="itemNum_2">' ||
                        fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_NUMBER') || '</TH>' || NL;

         l_document := l_document || '<TH  id="itemRev_2">' ||
                    fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_REVISION') || '</TH>' || NL;

        l_document := l_document || '<TH  id="itemDesc_2">' ||
                        fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_DESC') || '</TH>' || NL;

        l_document := l_document || '<TH  id="uom_2">' ||
                        fnd_message.get_string('PO', 'PO_WF_NOTIF_UOM') || '</TH>' || NL;

        l_document := l_document || '<TH  id="quant_2">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_QUANTITY') || '</TH>' || NL;

        l_document := l_document || '<TH  id="unitPrice_2">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_UNIT_PRICE') || '</TH>' || NL;

        l_document := l_document || '<TH  id="location_2">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_LOCATION') || '</TH>' || NL;

        l_document := l_document || '<TH  id="shipToOrg_2">' ||
                      fnd_message.get_string('PO', 'POA_SHIP_TO_ORG') || '</TH>' || NL;

        l_document := l_document || '<TH  id="needByDate_2">' ||
                      fnd_message.get_string('PO', 'PO_WF_NOTIF_NEED_BY_DATE') || '</TH>' || NL;

      -- Quanam 07-12-2010 CGR
      -- Agrego titulo columna precio ultima compra
        l_document := l_document || '<TH  id="lastAmt_2">' ||
                      fnd_message.get_string('XBOL', 'XX_PO_WF_NOTIF_LINE_ULTCO') || '</TH>' || NL;
      -- Fin precio ultima compra

        l_document := l_document || '</TR>' || NL;

          curr_len  := lengthb(l_document);
          prior_len := curr_len;

          FOR i IN 1..l_num_records_to_display LOOP              -- <BUG 3616816>

                /* Exit the cursor if the current document length and 2 times the
                ** length added in prior line exceeds 32000 char */

                if (curr_len + (2 * (curr_len - prior_len))) >= 32000 then
                   exit;
                end if;

                prior_len := curr_len;

            l_document := l_document || '<TR>' || NL;

        l_document := l_document || '<TD nowrap align=center headers="shipNum_2">'
                || nvl(to_char(l_shipment_num_tbl(i)), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap  headers="itemNum_2">'
                || nvl(l_item_num_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap  headers="itemRev_2">'
                || nvl(l_item_revision_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap  headers="itemDesc_2">'
                || nvl(l_item_desc_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap  headers="uom_2">'
                || nvl(l_uom_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap align=right  headers="quant_2">'
                || nvl(to_char(l_quantity_tbl(i)), '') || '</TD>' || NL;

    /* Bug 2868931: kagarwal
    ** We will not format the unit price on the lines in notifications
    */

            l_document := l_document || '<TD nowrap align=right  headers="unitPrice_2">' ||
                                  TO_CHAR(l_unit_price_tbl(i)) || '</TD>' || NL;

            l_document := l_document || '<TD nowrap  headers="location_2">'
                || nvl(l_location_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap  headers="shipToOrg_2">'
                || nvl(l_org_name_tbl(i), '') || '</TD>' || NL;
            l_document := l_document || '<TD nowrap  headers="needByDate_2">'
                || to_char(l_need_by_date_tbl(i)) || '</TD>' || NL;

        -- Precio ultima compra 10-12-2010 CGR
        l_document := l_document || '<TD nowrap align=right headers="lastAmt_2">' ||
                         nvl(TO_CHAR(l_last_po_price_tbl(i)),'') || '</TD>' || NL;

            l_document := l_document || '</TR>' || NL;

                curr_len  := lengthb(l_document);

        end loop;

      end if;
      l_document := l_document || '</TABLE></P>' || NL;

      document := l_document;

    elsif (display_type = 'text/plain') then

        if (nvl(l_document_type, 'PO') <> 'RELEASE') then

          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_PO_LINE_DETAILS') || NL || NL;

            -- <BUG 3616816 START> Only display message if # of actual lines is
            -- greater than maximum limit.
            --
            IF ( l_line_count > max_lines_dsp ) THEN

                -- Bug 3668188: changed the code check (originally created
                -- in bug 3607009) that determines which message to show
                -- based on whether Open Document icon is shown in then notif.
                -- The value of WF attribute 'OPEN_FORM_COMMAND' is set in a
                 -- previous node, using the get_po_user_msg_attribute procedure.
                --
                IF  ( l_open_form_command IS NULL ) THEN
                -- "The first [COUNT] Purchase Order lines are summarized
                    -- below. For information on additional lines, please click
                     -- the Open Document icon."
                    FND_MESSAGE.set_name('PO','PO_WF_NOTIF_PO_LINE_MESG');
                ELSE
                    -- "The first [COUNT] Purchase Order lines are summarized below."
                    FND_MESSAGE.set_name('PO','PO_WF_NOTIF_PO_LINE_MESG_TRUNC');
              END IF;

                FND_MESSAGE.set_token('COUNT',to_char(max_lines_dsp));
                line_mesg := FND_MESSAGE.get;
                l_document := l_document || line_mesg || NL || NL;

            END IF;
            --
          -- <BUG 3616816 END>

          curr_len  := lengthb(l_document);
          prior_len := curr_len;

          FOR i IN 1..l_num_records_to_display LOOP              -- <BUG 3616816>

                /* Exit the cursor if the current document length and 2 times the
                ** length added in prior line exceeds 32000 char */

                if (curr_len + (2 * (curr_len - prior_len))) >= 32000 then
                   exit;
                end if;

                prior_len := curr_len;

        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_LINE_NUMBER') || ':' || to_char(l_line_num_tbl(i)) || NL;
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_NUMBER') || ': ' || l_item_num_tbl(i) || NL;
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_REVISION') || ': ' || l_item_revision_tbl(i) || NL;
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_DESC') || ': ' || l_item_desc_tbl(i) || NL;
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_UOM') || ': ' || l_uom_tbl(i) || NL;
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_QUANTITY') || ': ' || to_char(l_quantity_tbl(i)) || NL;

    /* Bug 2868931: kagarwal
    ** We will not format the unit price on the lines in notifications
    */

        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_UNIT_PRICE') || ': '
              || to_char(l_unit_price_tbl(i)) || NL;
        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_LINE_AMOUNT') || ' teste 2 : '
              || to_char(l_amount_tbl(i), FND_CURRENCY.GET_FORMAT_MASK(l_currency_code, 30)) || NL || NL;

              curr_len  := lengthb(l_document);

      end loop;

      else   -- release

        l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_SHIP_DETAILS') || NL || NL || NL;

          -- <BUG 3616816 START> Only display message if # of actual lines is
          -- greater than maximum limit.
          --
          IF ( l_line_count > max_lines_dsp )  THEN
              FND_MESSAGE.set_name('PO','PO_WF_NOTIF_PO_REL_SHIP_MESG');
              FND_MESSAGE.set_token('COUNT',to_char(max_lines_dsp));
              line_mesg := FND_MESSAGE.get;
              l_document := l_document || line_mesg || NL || NL;
          END IF;
          --
          -- <BUG 3616816 END>

          curr_len  := lengthb(l_document);
          prior_len := curr_len;

          FOR i IN 1..l_num_records_to_display LOOP              -- <BUG 3616816>

                   /* Exit the cursor if the current document length and 2 times the
                  ** length added in prior line exceeds 32000 char */

                  if (curr_len + (2 * (curr_len - prior_len))) >= 32000 then
                      exit;
                   end if;

                  prior_len := curr_len;

          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_SHIP_NUMBER') || ': ' || to_char(l_shipment_num_tbl(i)) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_NUMBER') || ': ' || l_item_num_tbl(i) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_REVISION') || ': ' || l_item_revision_tbl(i) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_ITEM_DESC') || ': ' || l_item_desc_tbl(i) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_UOM') || ': ' || l_uom_tbl(i) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_QUANTITY') || ': ' || to_char(l_quantity_tbl(i)) || NL;

    /* Bug 2868931: kagarwal
    ** We will not format the unit price on the lines in notifications
    */

          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_UNIT_PRICE') || ': '
                || to_char(l_unit_price_tbl(i)) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_LINE_AMOUNT') || ' teste 3 : '
                || to_char(l_amount_tbl(i), FND_CURRENCY.GET_FORMAT_MASK(l_currency_code, 30)) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_LOCATION') || ': ' || l_location_tbl(i) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'POA_SHIP_TO_ORG') || ': ' || l_org_name_tbl(i) || NL;
          l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_NEED_BY_DATE') || ': ' || to_char(l_need_by_date_tbl(i)) || NL || NL;

                curr_len  := lengthb(l_document);

        end loop;

        end if;
        document := l_document; -- Bug 2462005
      end if;

  END get_po_lines_details;


  FUNCTION Get_Last_PO_Price (p_document_id  IN NUMBER
                              , p_item_id    IN NUMBER) RETURN NUMBER IS
    v_last_price    NUMBER;
  BEGIN
    select pl2.unit_price
    into   v_last_price
    from   po_lines           pl2
           ,po_line_locations pll
           ,mtl_system_items  msi
    where  pl2.po_line_id = (select max(pl.po_line_id)
                             from   po_lines    pl
                                    ,po_headers ph
                             where  pl.po_header_id         = ph.po_header_id
                             and    ph.type_lookup_code    IN ('STANDARD', 'BLANKET')
                             and    ph.authorization_status = 'APPROVED'
                             and    (ph.cancel_flag  = 'N' OR
                                     ph.cancel_flag IS NULL)
                             and    (pl.cancel_flag = 'N' OR
                                     pl.cancel_flag IS NULL)
                             and    ph.po_header_id        != p_document_id
                             and    pl.item_id              = p_item_id
                            )
    and pl2.po_line_id              = pll.po_line_id
    and pll.ship_to_organization_id = msi.organization_id
    and pl2.item_id                 = msi.inventory_item_id
--    and msi.inventory_item_flag     = 'Y'
    and rownum                      = 1;

    RETURN (v_last_price);

  EXCEPTION
    WHEN OTHERS THEN
      RETURN (0);

  END Get_Last_PO_Price;


PROCEDURE get_po_approve_msg (   document_id  in  varchar2,
                                 display_type  in  varchar2,
                                 document  in out  NOCOPY varchar2,
                                 document_type  in out  NOCOPY varchar2) IS

  l_item_type    wf_items.item_type%TYPE;
  l_item_key     wf_items.item_key%TYPE;

  l_document_id      po_headers.po_header_id%TYPE;
  l_org_id           po_headers.org_id%TYPE;
  l_currency_code    fnd_currencies.CURRENCY_CODE%TYPE;
  l_header_msg       VARCHAR2(500);
  l_po_amount        VARCHAR2(30);
  l_tax_amount       VARCHAR2(30);
  l_description      po_headers.comments%TYPE;
  l_forwarded_from   per_all_people_f.full_name%TYPE;
  l_preparer         per_all_people_f.full_name%TYPE;
--<UTF-8 FPI START>
--  l_note             VARCHAR2(480);  /* < UTF8 FPI - changed from VARCHAR2(240) > */
  l_note             po_action_history.note%TYPE;
--<UTF-8 FPI END>
  l_document         VARCHAR2(32000) := '';
  l_tax_amt          NUMBER;

  /* Start Bug# 3972475 */
  X_precision        number;
  X_ext_precision    number;
  X_min_acct_unit    number;
  /* End Bug# 3972475*/
  l_supplier         po_vendors.vendor_name%type; --Bug 4115777
  l_supplier_site    po_vendor_sites_all.vendor_site_code%type; --Bug 4115777
  NL                 VARCHAR2(1) := fnd_global.newline;
  -- Agregado Quanam 15-12-2010 CGR
  l_buyer            fnd_user.user_name%type;

BEGIN

  l_item_type := substr(document_id, 1, instr(document_id, ':') - 1);
  l_item_key := substr(document_id, instr(document_id, ':') + 1, length(document_id) - 2);

  l_document_id := wf_engine.GetItemAttrNumber
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'DOCUMENT_ID');

  l_org_id := wf_engine.GetItemAttrNumber
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'ORG_ID');

  fnd_client_info.set_org_context(to_char(l_org_id));


  l_currency_code := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'FUNCTIONAL_CURRENCY');

  l_po_amount := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'PO_AMOUNT_DSP');

  l_tax_amount := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'TAX_AMOUNT_DSP');

  l_description := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'PO_DESCRIPTION');

  l_forwarded_from := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'FORWARD_FROM_DISP_NAME');

  l_preparer := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'PREPARER_DISPLAY_NAME');

  l_note := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'NOTE');

  -- Agregado Quanam 15-12-2010 CGR
  l_buyer := wf_engine.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'BUYER_USER_NAME');

  --<Bug 4115777 Start> Show supplier and supplier site for
  -- approval notifications
  l_supplier := PO_WF_UTIL_PKG.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'SUPPLIER');

  l_supplier_site := PO_WF_UTIL_PKG.GetItemAttrText
                                        (itemtype   => l_item_type,
                                         itemkey    => l_item_key,
                                         aname      => 'SUPPLIER_SITE');
  --<Bug 4115777 End>

   fnd_currency.get_info( l_currency_code,
                          X_precision,
                          X_ext_precision,
                          X_min_acct_unit);


/*Start Bug# 3972475 - replaced the below sql to get the tax amount
  to account for canceled QTY. Also accounted for new order types introduced
  in 11i10 that use amount instead of quantity (where quantity_ordered is null).

  Since we are performing divide and multiply by operations we need rounding
  logic based on the currency.

  If we are using minimum accountable unit we apply:
   rounded tax = round(tax/mau)*mau, otherwise
   rounded tax = round(tax, precision)

   Old tax select:
  SELECT nvl(sum(nonrecoverable_tax), 0)
    INTO l_tax_amt
    FROM po_lines pol,
         po_distributions pod
   WHERE pol.po_header_id = l_document_id
     AND pod.po_line_id = pol.po_line_id;
*/

  IF (x_min_acct_unit IS NOT NULL) AND
      (x_min_acct_unit <> 0)
  THEN
    SELECT sum( round (POD.nonrecoverable_tax *
                       decode(quantity_ordered,
                              NULL,
                              (nvl(POD.amount_ordered,0) - nvl(POD.amount_cancelled,0)) / nvl(POD.amount_ordered, 1),
                              (nvl(POD.quantity_ordered,0) - nvl(POD.quantity_cancelled,0)) / nvl(POD.quantity_ordered, 1)
                             ) / X_min_acct_unit
                       ) * X_min_acct_unit
              )
    INTO l_tax_amt
    FROM po_lines pol,
         po_distributions pod
   WHERE pol.po_header_id = l_document_id
     AND pod.po_line_id = pol.po_line_id;
  ELSE
    SELECT sum( round (POD.nonrecoverable_tax *
                       decode(quantity_ordered,
                              NULL,
                              (nvl(POD.amount_ordered,0) - nvl(POD.amount_cancelled,0)) / nvl(POD.amount_ordered, 1),
                              (nvl(POD.quantity_ordered,0) - nvl(POD.quantity_cancelled,0)) / nvl(POD.quantity_ordered, 1)
                             ),
                       X_precision
                      )
              )
    INTO l_tax_amt
    FROM po_lines pol,
         po_distributions pod
   WHERE pol.po_header_id = l_document_id
     AND pod.po_line_id = pol.po_line_id;
  END IF;


  if (display_type = 'text/html') then

    l_document := NL || NL || '<!-- PO_APPROVE_MSG -->'|| NL || NL || '<P>';

    l_document := l_document || '</P>' || NL;

    l_document := l_document || '<P><TABLE border=0 cellpadding=0 cellspacing=0 SUMMARY=""><TR><TD align=right >' || NL ||
                  fnd_message.get_string('PO', 'PO_WF_NOTIF_PO_AMOUNT') ||
                  '</TD>' || NL;

    l_document := l_document || '<TD align=left>' || l_currency_code || ' ' || l_po_amount || '</TD></TR>' || NL;

    if l_tax_amt > 0 then

      l_document := l_document || '<TR><TD align=right>' ||
                    fnd_message.get_string('PO', 'PO_WF_NOTIF_TAX_AMOUNT') ||
                    '</TD>' || NL;
      l_document := l_document || '<TD align=left>' || l_currency_code || ' ' || l_tax_amount ||
                    '</TD></TR></TABLE></P>' || NL;

    else

      l_document := l_document || '</TABLE></P>' || NL || NL;

    end if;

    --<Bug 4115777 Start> Show supplier and supplier site for
    -- approval notifications
    l_document := l_document || '<P>' || NL;
    l_document := l_document || fnd_message.get_string('PO', 'PO_FO_VENDOR') ||
                  ' '|| l_supplier || NL;
    l_document := l_document || '<BR>' || NL;
    l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_SUPPLIER_SITE') ||
                  ' '|| l_supplier_site || NL;
    -- Agregado Quanam 15-12-2010 CGR
    l_document := l_document || NL || fnd_message.get_string('XBOL', 'XX_PO_WF_NOTIF_COMPRADOR') ||
                  ' '|| l_buyer || NL;
    l_document := l_document || '</P>' || NL;
    --<Bug 4115777 End>

    if l_description is not null then
      l_document := l_document || '<P>' || NL;
      l_document := l_document || fnd_message.get_string('PO', 'PO_WF_NOTIF_DOC_DESCRIPTION') || NL || '<BR>';
      l_document := l_document || l_description;
      l_document := l_document || '<BR></P>' || NL;
    end if;

  else  -- plain text notification is defined in the WF.

  null;

  end if;

  document := l_document;

END get_po_approve_msg;

END XX_PO_WF_APPROVAL_PK;
/

exit
