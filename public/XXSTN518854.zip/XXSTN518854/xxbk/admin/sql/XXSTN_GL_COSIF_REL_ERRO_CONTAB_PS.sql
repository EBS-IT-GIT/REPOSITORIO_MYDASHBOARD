WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE apps.XXSTN_GL_COSIF_REL_ERRO_CONTAB IS
-- +=======================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                     |
-- |                   All rights reserved.                                |
-- +=======================================================================+
-- | FILENAME                                                              |
-- | XXXSTN_GL_COSIF_REL_ERRO_CONTAB_PS.sql                                |
-- |                                                                       |
-- | PURPOSE                                                               |
-- |                                                                       |
-- | DESCRIPTION                                                           |
-- |   Stone - Relat�rio de Erros - Contabiliza��o dos Lan�amentos - Cosif |
-- |                                                                       |
-- | CREATED BY   Rogerio Farto - Ninecon - 10/06/2020                     |
-- |              SR#518854 - NSD320139                                    |
-- |                                                                       |
-- | UPDATED BY                                                            |
-- |                                                                       |
-- +=======================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;

  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_ledger_id      IN NUMBER
                              ,p_period_name    IN VARCHAR2
                              ,p_je_batch_id    IN NUMBER);

END XXSTN_GL_COSIF_REL_ERRO_CONTAB;
/

EXIT; 