WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY apps.XXSTN_GL_COSIF_REL_ERRO_CONTAB IS
-- +=======================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                     |
-- |                   All rights reserved.                                |
-- +=======================================================================+
-- | FILENAME                                                              |
-- | XXXSTN_GL_COSIF_REL_ERRO_CONTAB_PS.sql                                |
-- |                                                                       |
-- | PURPOSE                                                               |
-- |                                                                       |
-- | DESCRIPTION                                                           |
-- |   Stone - Relat�rio de Erros - Contabiliza��o dos Lan�amentos - Cosif |
-- |                                                                       |
-- | CREATED BY   Rogerio Farto - Ninecon - 10/06/2020                     |
-- |              SR#518854 - NSD320139                                    |
-- |                                                                       |
-- | UPDATED BY                                                            |
-- |                                                                       |
-- +=======================================================================+
  -- Function and procedure implementations
  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_ledger_id      IN NUMBER                           
                              ,p_period_name    IN VARCHAR2
                              ,p_je_batch_id    IN NUMBER) IS
  --
  CURSOR c_lanctos IS
         select distinct
                gl.name                              livro
              , gjb.name                             lote
              , gjh.name                             lancto
              , gjs.user_je_source_name              origem
              , gjc.user_je_category_name            categoria
              , gjh.period_name                      periodo
              , gjh.status                           status_lote
              , flv.description                      erro
              , gcc.concatenated_segments            combinacao
              , gcc.segment4                         cta_no_map
              , ffvv.description                     dsc_cta
           from apps.gl_je_batches            gjb
              , apps.gl_je_headers            gjh
              , apps.gl_je_sources            gjs
              , apps.gl_je_categories         gjc
              , apps.gl_ledgers               gl
              , apps.fnd_lookup_values        flv
              , apps.gl_je_lines              gjl
              , apps.gl_code_combinations_kfv gcc
              , apps.fnd_flex_values_vl       ffvv
          where 1 = 1
            and gjb.je_batch_id = nvl(p_je_batch_id,gjb.je_batch_id)
            and gjb.je_batch_id = gjh.je_batch_id
            and gjh.period_name = p_period_name
            and gjh.status not in ('P','N')
            and gjh.ledger_id = nvl(p_ledger_id,gjh.ledger_id)
            and gjh.je_source = gjs.je_source_name
            and gjh.je_category = gjc.je_category_name
            and gjh.ledger_id = gl.ledger_id
            and flv.lookup_type = 'MJE_BATCH_STATUS'
            and flv.language = 'PTB'
            and gjh.status = flv.lookup_code
            and gjh.je_header_id = gjl.je_header_id
            and gjl.code_combination_id = gcc.code_combination_id
            and ffvv.flex_value_set_id  = 1017355
            and gcc.segment4 = ffvv.flex_value
            and gcc.segment4 not in (select glfv.flex_value
                                        from apps.fnd_flex_values          glfv
                                           , apps.gl_cons_flex_hierarchies cfh
                                           , apps.gl_cons_segment_map      gcsm
                                           , apps.gl_coa_mappings          gcm
                                       where 1 = 1
                                         and ffvv.flex_value                 = glfv.flex_value
                                         and ffvv.flex_value_set_id          = glfv.flex_value_set_id
                                         and gcm.coa_mapping_id              = gcsm.coa_mapping_id
                                         and gcm.name                        = 'STONE COSIF'
                                         and gcsm.coa_mapping_id             = 1380 
                                         and gcsm.to_application_column_name = 'SEGMENT2' 
                                         and gcsm.segment_map_id             = cfh.segment_map_id 
                                         and gcsm.single_value               = cfh.parent_flex_value 
                                         and gcsm.segment_map_type           = 'R' 
                                         and glfv.flex_value_set_id          = gcsm.from_value_set_id 
                                         and glfv.summary_flag               = 'N' 
                                         and glfv.flex_value between cfh.child_flex_value_low 
                                                                 and cfh.child_flex_value_high)
          order 
             by 1,2,3,4,5;
  --
  TYPE t_lanctos IS TABLE OF c_lanctos%ROWTYPE;
  r_lanctos   t_lanctos;
  --
  v_file_name   VARCHAR2(240);
  l_qtde        NUMBER;
  l_vlr         NUMBER;
  l_lin         NUMBER;
  l_count       NUMBER := 2;
  l_nRequest_Id NUMBER;
  l_ledger_name gl_ledgers.name%type;
  l_user        fnd_user.user_name%type;
  --
  BEGIN
     --busca usuario de execucao do relatorio
     BEGIN
      SELECT user_name
        into l_user
        FROM fnd_user
       WHERE user_id = FND_GLOBAL.USER_ID;
      EXCEPTION
       WHEN OTHERS THEN
        l_user := null;
     END;
     --------------------------------------------------------------------------
     --> Printing Parameters
     --------------------------------------------------------------------------
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'STONE PAGAMENTOS S/A               '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'   Stone - GL - Relat�rio de Erros - Contabiliza��o dos Lan�amentos - Cosif  ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Paramters..:');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_ledger_id............: '||p_ledger_id);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_je_batch_id..........: '||p_je_batch_id);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_period_name..........: '||p_period_name); 
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     --
     dbms_output.put_line('Open lan�amentos '||v_file_name);
     OPEN c_lanctos ;
     FETCH c_lanctos BULK COLLECT INTO r_lanctos;
     CLOSE c_lanctos;
     --
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
     --
     as_xlsx.clear_workbook;
     --
     IF r_lanctos.count > 0 THEN
       --
       as_xlsx.new_sheet('Lancamentos');
       as_xlsx.set_row(   1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(  3,  1, 'Stone - GL - Relat�rio de Erros - Contabiliza��o dos Lan�amentos - Cosif', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 14, p_bold =>true) );
       as_xlsx.cell(  1,  2, 'Livro Primario', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  2,  2, 'Lote Contabil', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  3,  2, 'Lancamento', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  4,  2, 'Origem', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  5,  2, 'Categoria', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  6,  2, 'Periodo', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  7,  2, 'Status Lote', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  8,  2, 'Mensagem Erro', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  9,  2, 'Combinacao Contabil', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 10,  2, 'Cta Contabil nao mapeada Cosif', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 11,  2, 'Desc Conta Contabil', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       --
       FOR i IN r_lanctos.first..r_lanctos.last LOOP
         --
         dbms_output.put_line('Lancamentos '||v_file_name);
         as_xlsx.cell(  1, l_count+1, nvl(r_lanctos(i).livro,' '));
         as_xlsx.cell(  2, l_count+1, nvl(r_lanctos(i).lote,' '));
         as_xlsx.cell(  3, l_count+1, nvl(r_lanctos(i).lancto,' '));
         as_xlsx.cell(  4, l_count+1, nvl(r_lanctos(i).origem,' '));
         as_xlsx.cell(  5, l_count+1, nvl(r_lanctos(i).categoria,' '));
         as_xlsx.cell(  6, l_count+1, nvl(r_lanctos(i).periodo,' '));
         as_xlsx.cell(  7, l_count+1, nvl(r_lanctos(i).status_lote,' '));
         as_xlsx.cell(  8, l_count+1, nvl(r_lanctos(i).erro,' '));
         as_xlsx.cell(  9, l_count+1, nvl(r_lanctos(i).combinacao,' '));
         as_xlsx.cell( 10, l_count+1, nvl(r_lanctos(i).cta_no_map,' '));
         as_xlsx.cell( 11, l_count+1, nvl(r_lanctos(i).dsc_cta,' '));
         --
         l_count := l_count + 1;
         --
       END LOOP;
       --
       as_xlsx.freeze_rows( 2 );
       --
     END IF;
     --
     dbms_output.put_line('Parameters '||v_file_name);
     as_xlsx.new_sheet('Parameters');
     as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ) ) ;
     as_xlsx.cell(1 , 1 ,'Parametros');
     as_xlsx.cell(1 , 2 ,'ID raz�o');
     as_xlsx.cell(1 , 3 ,'ID lote');
     as_xlsx.cell(1 , 4 ,'Periodo');
     --
     as_xlsx.cell(2 , 2 ,nvl(to_char(p_ledger_id),' '));
     as_xlsx.cell(2 , 3 ,nvl(to_char(p_je_batch_id),' '));
     as_xlsx.cell(2 , 4 ,nvl(to_char(p_period_name),' '));

     as_xlsx.cell(5 , 7 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS') ||' por '||l_user
                         , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
     --
     v_file_name := 'o'||NVL(TO_CHAR(FND_GLOBAL.CONC_REQUEST_ID),'RelErrContab')||'.xlsx';
     dbms_output.put_line('Arquivo gerado '||v_file_name);
     as_xlsx.save( 'XXSTN_HR_OUT', v_file_name );
     --
     dbms_output.put_line('Arquivo gravado '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'       ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Arquivo Gerado.....: '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Registros Gerados..: '||to_char(l_count-3));
     --
     l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                , argument1   => v_file_name
                                                , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
  EXCEPTION
    --
    WHEN OTHERS THEN
      --------------------------------------------------------------------
      --> Set Errors variables
      --------------------------------------------------------------------
      p_errbuf  := SUBSTR(SQLERRM, 1, 500);
      p_retcode := 2;
      --------------------------------------------------------------------
      --> Print Error Messages
      --------------------------------------------------------------------
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** Unexpected error please contact your system administrator');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_errbuf =  ' || SUBSTR(SQLERRM, 1, 500));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_retcode =  '|| SQLCODE);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
      --
  END generate_report_p;
  --
END XXSTN_GL_COSIF_REL_ERRO_CONTAB;
/

EXIT; 