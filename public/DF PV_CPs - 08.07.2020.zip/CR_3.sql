UPDATE apps.csi_item_instances a
   SET a.last_vld_organization_id = 1516
 WHERE a.instance_number = 'NET-069' AND a.instance_id = 72147;
--1 row

UPDATE apps.csi_item_instances a
   SET a.last_vld_organization_id = 1516
 WHERE a.instance_number = 'NET-118' AND a.instance_id = 72107;
--1 row
