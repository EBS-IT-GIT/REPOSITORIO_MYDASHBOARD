  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_QTY_HOLD_REPORT_PKG" AS

procedure main_process (retcode OUT NUMBER
                       ,errbuf  OUT VARCHAR2
                       ,p_org_id1 IN NUMBER
                       ,p_org_id2 IN NUMBER
                       ,p_org_id3 IN NUMBER
                       ,p_inv_date_from IN VARCHAR2
                       ,p_inv_date_to IN VARCHAR2
                       ,p_due_date_from IN VARCHAR2
                       ,p_due_date_to IN VARCHAR2
                       ,p_sector1 IN VARCHAR2
                       ,p_sector2 IN VARCHAR2
                       ,p_sector3 IN VARCHAR2
                       ,p_vendor_id IN NUMBER);
                       
END; 
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_QTY_HOLD_REPORT_PKG" AS

PROCEDURE print_log (p_message IN VARCHAR2) IS

BEGIN
    fnd_file.put_line(fnd_file.log,p_message);
END;

PROCEDURE print_output (p_message IN VARCHAR2) IS

BEGIN
    fnd_file.put_line(fnd_file.output,p_message);
END;

procedure print_param(p_org_id1 IN NUMBER
                     ,p_org_id2 IN NUMBER
                     ,p_org_id3 IN NUMBER
                     ,p_inv_date_from IN VARCHAR2
                     ,p_inv_date_to IN VARCHAR2
                     ,p_due_date_from IN VARCHAR2
                     ,p_due_date_to IN VARCHAR2
                     ,p_sector1 IN VARCHAR2
                     ,p_sector2 IN VARCHAR2
                     ,p_sector3 IN VARCHAR2
                     ,p_vendor_id IN NUMBER) IS
   
v_org_name    HR_ALL_ORGANIZATION_UNITS.NAME%TYPE;
v_vendor_name PO_VENDORS.VENDOR_NAME%TYPE;

                  
BEGIN

    print_log('XX_PO_QTY_HOLD_REPORT_PKG.PRINT_PARAM (+)');
    
    v_org_name := null;
    v_vendor_name := null;
    
    IF p_org_id1 is not null then 
        BEGIN
            SELECT name 
              INTO v_org_name
              FROM hr_all_organization_units haou
             WHERE organization_id = p_org_id1;
        EXCEPTION
         WHEN OTHERS THEN
           v_org_name := null;
        END; 
    ELSE 
       v_org_name := null;
    END IF;
    
    print_output('<P_ORG_ID1>'||v_org_name||'</P_ORG_ID1>');
    
    IF p_org_id2 is not null then 
        BEGIN
            SELECT name 
              INTO v_org_name
              FROM hr_all_organization_units haou
             WHERE organization_id = p_org_id2;
        EXCEPTION
         WHEN OTHERS THEN
           v_org_name := null;
        END; 
    ELSE 
       v_org_name := null;
    END IF;
    
    print_output('<P_ORG_ID2>'||v_org_name||'</P_ORG_ID2>');
    
    IF p_org_id3 is not null then 
        BEGIN
            SELECT name 
              INTO v_org_name
              FROM hr_all_organization_units haou
             WHERE organization_id = p_org_id3;
        EXCEPTION
         WHEN OTHERS THEN
           v_org_name := null;
        END;
    ELSE 
        v_org_name := null;
    END IF;
    
    print_output('<P_ORG_ID3>'||v_org_name||'</P_ORG_ID3>');
    
    IF p_inv_date_from IS NOT NULL THEN 
       print_output('<P_INV_DATE_FROM>'||TO_CHAR(TO_DATE(p_inv_date_from,'YYYY/MM/DD HH24:MI:SS'),'DD/MM/YYYY')||'</P_INV_DATE_FROM>');
    ELSE
       print_output('<P_INV_DATE_FROM></P_INV_DATE_FROM>');
    END IF;
    
    IF p_inv_date_to IS NOT NULL THEN 
       print_output('<P_INV_DATE_TO>'||TO_CHAR(TO_DATE(p_inv_date_to,'YYYY/MM/DD HH24:MI:SS'),'DD/MM/YYYY')||'</P_INV_DATE_TO>');
    ELSE
       print_output('<P_INV_DATE_TO></P_INV_DATE_TO>');
    END IF;
    
    IF p_due_date_from IS NOT NULL THEN 
       print_output('<P_DUE_DATE_FROM>'||TO_CHAR(TO_DATE(p_due_date_from,'YYYY/MM/DD HH24:MI:SS'),'DD/MM/YYYY')||'</P_DUE_DATE_FROM>');
    ELSE
       print_output('<P_DUE_DATE_FROM></P_DUE_DATE_FROM>');
    END IF;
    
    IF p_due_date_to IS NOT NULL THEN 
       print_output('<P_DUE_DATE_TO>'||TO_CHAR(TO_DATE(p_due_date_from,'YYYY/MM/DD HH24:MI:SS'),'DD/MM/YYYY')||'</P_DUE_DATE_TO>');
    ELSE
       print_output('<P_DUE_DATE_TO></P_DUE_DATE_TO>');
    END IF;
    
    print_output('<P_SECTOR1>'||p_sector1||'</P_SECTOR1>');
    print_output('<P_SECTOR2>'||p_sector2||'</P_SECTOR2>');
    print_output('<P_SECTOR3>'||p_sector3||'</P_SECTOR3>');
    
    IF p_vendor_id is not null then
        BEGIN
            SELECT vendor_name 
              INTO v_vendor_name
              FROM po_vendors pv
             WHERE vendor_id = p_vendor_id;
        EXCEPTION
         WHEN OTHERS THEN
           v_vendor_name := null;
        END;
    ELSE 
        v_vendor_name := null;
    END IF;
    
    print_output('<P_VENDOR_ID>'||v_vendor_name||'</P_VENDOR_ID>');

    print_log('XX_PO_QTY_HOLD_REPORT_PKG.PRINT_PARAM (-)');

EXCEPTION
 WHEN OTHERS THEN 
    print_log('XX_PO_QTY_HOLD_REPORT_PKG.PRINT_PARAM (!)');
END;

procedure show_data (p_status        OUT VARCHAR2
                    ,p_error_message OUT VARCHAR2
                    ,p_org_id1 IN NUMBER
                    ,p_org_id2 IN NUMBER
                    ,p_org_id3 IN NUMBER
                    ,p_inv_date_from IN VARCHAR2
                    ,p_inv_date_to IN VARCHAR2
                    ,p_due_date_from IN VARCHAR2
                    ,p_due_date_to IN VARCHAR2
                    ,p_sector1 IN VARCHAR2
                    ,p_sector2 IN VARCHAR2
                    ,p_sector3 IN VARCHAR2
                    ,p_vendor_id IN NUMBER) IS
                   
CURSOR c_main IS
select hou.name
      ,aia.invoice_id
      ,pha.po_header_id
      ,plla.line_location_id
  from ap_invoices_all aia
      ,ap_invoice_lines_all aila
      ,po_distributions_all pda
      ,po_line_locations_all plla
      ,po_lines_all pla
      ,po_headers_all pha
      ,ap_holds_all aha
      ,po_agents pa
      ,po_agents_dfv pa_dfv
      ,hr_all_organization_units hou
      ,ap_payment_schedules_all aipa
 where aia.invoice_id = aila.invoice_id
   and aia.cancelled_by is null
   and NVL(aila.cancelled_flag,'N') = 'N'
   and aila.line_type_lookup_code = 'ITEM'
   and NVL(aila.discarded_flag,'N') = 'N'
   and aila.po_distribution_id = pda.po_distribution_id
   and pda.line_location_id = plla.line_location_id
   and pla.po_line_id = plla.po_line_id
   and pha.po_header_id = pla.po_header_id
   and aia.org_id = hou.organization_id
   and aia.invoice_id = aha.invoice_id
   and aha.hold_lookup_code IN ('QTY REC','AMT ORD','AMT REC','QTY ORD')
   and aha.release_lookup_code is null
   and pha.agent_id = pa.agent_id
   and pa.rowid = pa_dfv.row_id
   and aia.invoice_id = aipa.invoice_id
   and aia.vendor_id = NVL(p_vendor_id,aia.vendor_id)
   and ((p_sector1 is not null 
     and pa_dfv.XX_CATEGORIA_COMPRADOR = p_sector1)
     or (p_sector2 is not null 
     and pa_dfv.XX_CATEGORIA_COMPRADOR = p_sector2)
     or (p_sector3 is not null 
     and pa_dfv.XX_CATEGORIA_COMPRADOR = p_sector3)
     or (p_sector1 is null and p_sector2 is null and p_sector3 is null
     and pa.agent_id = pa.agent_id )
    )
   and plla.line_location_id = aha.line_location_id
   and TRUNC(aia.creation_date) >= NVL(TRUNC(TO_DATE(p_inv_date_from,'YYYY/MM/DD HH24:MI:SS')),TRUNC(aia.creation_date))
   and TRUNC(aia.creation_date) <= NVL(TRUNC(TO_DATE(p_inv_date_to  ,'YYYY/MM/DD HH24:MI:SS')),TRUNC(aia.creation_date))
   and TRUNC(aipa.due_date) >= TRUNC(TO_DATE(p_due_date_from,'YYYY/MM/DD HH24:MI:SS'))
   and TRUNC(aipa.due_date) <= TRUNC(TO_DATE(p_due_date_to  ,'YYYY/MM/DD HH24:MI:SS'))
   and ((p_org_id1 is not null 
     and aia.org_id = p_org_id1)
     or (p_org_id2 is not null 
     and aia.org_id = p_org_id2)
     or (p_org_id3 is not null 
     and aia.org_id = p_org_id3)
     or (p_org_id1 is null and p_org_id2 is null and p_org_id3 is null
        and aia.org_id = aia.org_id)
    )
    GROUP BY hou.name
      ,aia.invoice_id
      ,pha.po_header_id
      ,plla.line_location_id
    order by 1,2,3,4;

CURSOR c_details (p_invoice_id NUMBER
                 ,p_po_header_id NUMBER
                 ,p_line_location_id NUMBER) IS
select hou.name compania
      ,he.full_name comprador
      ,pa_dfv.xx_categoria_comprador categoria
      ,pa_dfv.xx_subcategoria_comprador subcategoria
      ,pv.vendor_name
      ,pha.segment1 po_number
      ,pla.line_num po_line_num
      ,(select description
          from fnd_flex_values_vl
         where flex_value = mic.segment1
           and flex_value_set_id = 1010650) rubro
      ,(select description
        from fnd_flex_values_vl
        where flex_value = mic.segment2
        and flex_value_set_id = 1010651
        and mic.segment1 between parent_flex_value_low and NVL(parent_flex_value_high,parent_flex_value_low)) familia
      ,(select description
          from fnd_flex_values_vl
         where flex_value = mic.segment3
           and flex_value_set_id = 1010652
           and mic.segment1 between parent_flex_value_low and NVL(parent_flex_value_high,parent_flex_value_low)) subfamilia
      ,NVL(msi.description,pla.item_description) description
      ,NVL(NVL(pla.amount,ROUND(pla.quantity*pla.unit_price,2)),ROUND(plla.quantity*plla.PRICE_OVERRIDE,2)) po_amount
      ,TO_CHAR(plla.promised_date,'DD/MM/YYYY') promised_date
      ,plla.quantity
      ,plla.quantity_received
      ,plla.quantity_billed
      ,aila.amount inv_amount
      ,haou.name almacen
      ,aia.invoice_id 
      ,aia.invoice_num
      ,TO_CHAR(aia.invoice_date,'DD/MM/YYYY') invoice_date
      ,TO_CHAR(aia.creation_date,'DD/MM/YYYY') creation_date
      ,aila.line_number inv_line_num
      ,CASE 
        WHEN aila.rcv_transaction_id IS NULL THEN 0 
        ELSE (select quantity from rcv_transactions rt where rt.transaction_id = aila.rcv_transaction_id)
        END quantity_received_inv
      ,aila.quantity_invoiced
      ,TO_CHAR(aipa.due_date,'DD/MM/YYYY') due_date
      ,flv.meaning hold_name
  from ap_invoices_all aia
      ,ap_invoice_lines_all aila
      ,po_distributions_all pda
      ,po_line_locations_all plla
      ,po_lines_all pla
      ,po_headers_all pha
      ,po_vendors pv
      ,po_agents pa
      ,po_agents_dfv pa_dfv
      ,hr_all_organization_units hou
      ,hr_all_organization_units haou
      ,mtl_system_items msi
      ,ap_holds_all aha
      ,mtl_categories_v mic
      ,fnd_lookup_values flv
      ,ap_payment_schedules_all aipa
      ,hr_employees he
 where aia.invoice_id = aila.invoice_id
   and aia.cancelled_by is null
   and NVL(aila.cancelled_flag,'N') = 'N'
   and aila.line_type_lookup_code = 'ITEM'
   and NVL(aila.discarded_flag,'N') = 'N'
   and pha.agent_id = pa.agent_id
   and pa.rowid = pa_dfv.row_id
   and aila.po_distribution_id = pda.po_distribution_id
   and pda.line_location_id = plla.line_location_id
   and pla.po_line_id = plla.po_line_id
   and pha.po_header_id = pla.po_header_id
   and aia.vendor_id = pv.vendor_id
   and aia.org_id = hou.organization_id
   and plla.ship_to_organization_id = msi.organization_id(+)
   and pla.item_id = msi.inventory_item_id(+)
   and plla.ship_to_organization_id = haou.organization_id
   and aia.invoice_id = aha.invoice_id
   and aha.hold_lookup_code = flv.lookup_code
   and flv.language = 'ESA'
   and flv.lookup_type = 'HOLD CODE'
   and aha.hold_lookup_code IN ('QTY REC','AMT ORD','AMT REC','QTY ORD')
   and aha.release_lookup_code is null
   and pla.category_id = mic.category_id
--   and plla.ship_to_organization_id = mic.organization_id
--   and mic.inventory_item_id = pla.item_id
--   and mic.category_set_id = 1
   and aia.invoice_id = aipa.invoice_id
   and pha.agent_id = he.employee_id
   and plla.line_location_id = aha.line_location_id
   and aia.invoice_id = p_invoice_id
   and pha.po_header_id = p_po_header_id
   and plla.line_location_id = p_line_location_id;
                
BEGIN

    print_log('XX_PO_QTY_HOLD_REPORT_PKG.SHOW_DATA (+)');
    
    print_output('<XXPOQHIR>');
    
    print_param(p_org_id1,p_org_id2,p_org_id3,p_inv_date_from,p_inv_date_to,p_due_date_from,p_due_date_to,p_sector1,p_sector2,p_sector3,p_vendor_id);
    
    FOR r_main in c_main LOOP
    
        print_output('<G_MAIN>');
        
        FOR r_det IN c_details (r_main.invoice_id,r_main.po_header_id,r_main.line_location_id) LOOP
        
            print_output('<EMPRESA>'||XX_UTIL_PK.xml_escape_chars(r_det.compania)||'</EMPRESA>');
            print_output('<COMPRADOR>'||XX_UTIL_PK.xml_escape_chars(r_det.comprador)||'</COMPRADOR>');
            print_output('<CATEGORIA>'||XX_UTIL_PK.xml_escape_chars(r_det.categoria)||'</CATEGORIA>');
            print_output('<SUBCATEGORIA>'||XX_UTIL_PK.xml_escape_chars(r_det.subcategoria)||'</SUBCATEGORIA>');
            print_output('<VENDOR_NAME>'||XX_UTIL_PK.xml_escape_chars(r_det.vendor_name)||'</VENDOR_NAME>');
            print_output('<PO_NUMBER>'||r_det.po_number||'</PO_NUMBER>');
            print_output('<PO_LINE_NUM>'||r_det.po_line_num||'</PO_LINE_NUM>');
            print_output('<RUBRO>'||XX_UTIL_PK.xml_escape_chars(r_det.rubro)||'</RUBRO>');
            print_output('<FAMILIA>'||XX_UTIL_PK.xml_escape_chars(r_det.familia)||'</FAMILIA>');
            print_output('<SUBFAMILIA>'||XX_UTIL_PK.xml_escape_chars(r_det.subfamilia)||'</SUBFAMILIA>');
            print_output('<ITEM_DESC>'||XX_UTIL_PK.xml_escape_chars(r_det.description)||'</ITEM_DESC>');
            print_output('<PO_AMOUNT>'||XX_UTIL_PK.xml_num_display(r_det.po_amount)||'</PO_AMOUNT>');
            print_output('<PROMISE_DATE>'||r_det.promised_date||'</PROMISE_DATE>');
            print_output('<QUANTITY>'||XX_UTIL_PK.xml_num_display(r_det.quantity)||'</QUANTITY>');
            print_output('<QUANTITY_REC>'||XX_UTIL_PK.xml_num_display(r_det.quantity_received)||'</QUANTITY_REC>');
            print_output('<QUANTITY_BILL>'||XX_UTIL_PK.xml_num_display(r_det.quantity_billed)||'</QUANTITY_BILL>');
            print_output('<INV_AMOUNT>'||XX_UTIL_PK.xml_num_display(r_det.inv_amount)||'</INV_AMOUNT>');
            print_output('<ALMACEN>'||XX_UTIL_PK.xml_escape_chars(r_det.almacen)||'</ALMACEN>');
            print_output('<INVOICE_NUM>'||r_det.invoice_num||'</INVOICE_NUM>');
            print_output('<INVOICE_DATE>'||r_det.invoice_date||'</INVOICE_DATE>');
            print_output('<CREATION_DATE>'||r_det.creation_date||'</CREATION_DATE>');
            print_output('<INVOICE_NUM>'||r_det.invoice_num||'</INVOICE_NUM>');
            print_output('<INV_LINE_NUM>'||r_det.inv_line_num||'</INV_LINE_NUM>');
            print_output('<QUANTITY_REC_INV>'||XX_UTIL_PK.xml_num_display(r_det.quantity_received_inv)||'</QUANTITY_REC_INV>');
            print_output('<QUANTITY_BIL_INV>'||XX_UTIL_PK.xml_num_display(r_det.quantity_invoiced)||'</QUANTITY_BIL_INV>');
            print_output('<DUE_DATE>'||r_det.due_date||'</DUE_DATE>');
            print_output('<HOLD_NAME>'||r_det.hold_name||'</HOLD_NAME>');
            
        
        END LOOP;
        
        print_output('</G_MAIN>');
    
    END LOOP;
    
    print_output('</XXPOQHIR>');
    
    print_log('XX_PO_QTY_HOLD_REPORT_PKG.SHOW_DATA (-)');

EXCEPTION
 WHEN OTHERS THEN 
   p_status := 'W';
   p_error_message := 'Error OTHERS en SHOW_DATA. Error: '||SQLERRM;
   print_log (p_error_message);
   print_log('XX_PO_QTY_HOLD_REPORT_PKG.SHOW_DATA (!)');
END;

procedure main_process (retcode OUT NUMBER
                       ,errbuf  OUT VARCHAR2
                       ,p_org_id1 IN NUMBER
                       ,p_org_id2 IN NUMBER
                       ,p_org_id3 IN NUMBER
                       ,p_inv_date_from IN VARCHAR2
                       ,p_inv_date_to IN VARCHAR2
                       ,p_due_date_from IN VARCHAR2
                       ,p_due_date_to IN VARCHAR2
                       ,p_sector1 IN VARCHAR2
                       ,p_sector2 IN VARCHAR2
                       ,p_sector3 IN VARCHAR2
                       ,p_vendor_id IN NUMBER) IS

v_status VARCHAR2(1);
v_error_message VARCHAR2(2000);
e_cust_exception EXCEPTION;
                       
BEGIN
      fnd_file.put_line(fnd_file.log,'XX_PO_QTY_HOLD_REPORT_PKG.MAIN_PROCESS (+)');
      
      print_log('Parametros');
      
      print_log('P_ORG_ID1: '||p_org_id1);
      print_log('P_ORG_ID2: '||p_org_id2);
      print_log('P_ORG_ID3: '||p_org_id3);
      print_log('P_INV_DATE_FROM: '||p_inv_date_from);
      print_log('P_INV_DATE_TO: '||p_inv_date_to);
      print_log('P_DUE_DATE_FROM: '||p_due_date_from);
      print_log('P_DUE_DATE_TO: '||p_due_date_to);
      print_log('P_CATEGORY1: '||p_sector1);
      print_log('P_CATEGORY2: '||p_sector2);
      print_log('P_CATEGORY3: '||p_sector3);
      print_log('P_VENDOR_ID: '||p_vendor_id);

      show_data  (p_status         => v_status
                 ,p_error_message  => v_error_message
                 ,p_org_id1        => p_org_id1
                 ,p_org_id2        => p_org_id2
                 ,p_org_id3        => p_org_id3
                 ,p_inv_date_from  => p_inv_date_from
                 ,p_inv_date_to    => p_inv_date_to
                 ,p_due_date_from  => p_due_date_from
                 ,p_due_date_to    => p_due_date_to
                 ,p_sector1        => p_sector1
                 ,p_sector2        => p_sector2
                 ,p_sector3        => p_sector3
                 ,p_vendor_id      => p_vendor_id);

      IF v_status != 'S' THEN
        RAISE e_cust_exception;
      END IF;

      fnd_file.put_line(fnd_file.log,'XX_PO_QTY_HOLD_REPORT_PKG.MAIN_PROCESS (-)');

EXCEPTION
   WHEN e_cust_exception THEN
       retcode := 1;
       errbuf := v_error_message;
       fnd_file.put_line(fnd_file.log,errbuf);
       fnd_file.put_line(fnd_file.log,'XX_PO_QTY_HOLD_REPORT_PKG.MAIN_PROCESS (!)');
   WHEN OTHERS THEN
       retcode := 2;
       errbuf := 'Error OTHERS en MAIN_PROCESS. Error: '||SQLERRM;
       fnd_file.put_line(fnd_file.log,errbuf);
       fnd_file.put_line(fnd_file.log,'XX_PO_QTY_HOLD_REPORT_PKG.MAIN_PROCESS (!)');
END;
                       
END; 
/

exit
