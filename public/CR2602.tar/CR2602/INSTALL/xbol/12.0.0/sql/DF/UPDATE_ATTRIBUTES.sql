  set define off;
sdasda

exit
