UPDATE apps.XX_TCG_TICKETS_BALANZA x1
SET (x1.TARA_FECHA, x1.PESO_BRUTO_FECHA) = (SELECT x2.PESO_BRUTO_FECHA, x2.PESO_BRUTO_FECHA
                                                                                                  FROM apps.XX_TCG_TICKETS_BALANZA x2
                                                                                                  WHERE x1.CARTA_PORTE_ID = x2.CARTA_PORTE_ID
                                                                                                  AND       x2.TIPO_TICKET = 'SALIDA'
                                                                                                  AND       x2. ESTABLECIMIENTO_ID = 127
                                                                                                  AND       x2.FECHA <= to_date('13-02-2020', 'DD-MM-YYYY')
                                                                                                  AND       x2.FECHA >= to_date('01-01-2020','DD-MM-YYYY'))
WHERE  x1.TIPO_TICKET = 'ENTRADA'
AND x1.FECHA <= to_date('13-02-2020', 'DD-MM-YYYY')
AND x1.FECHA >= to_date('01-01-2020','DD-MM-YYYY')
AND x1.TARA_FECHA IS NULL
AND x1.PESO_BRUTO_FECHA IS NULL
AND x1.ESTABLECIMIENTO_ID = 374
--458