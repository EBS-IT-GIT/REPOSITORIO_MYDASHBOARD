  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_GL_REPORTS_PKG" AS

  PROCEDURE Activacion_Sementera ( errbuf              IN OUT NOCOPY VARCHAR2
                                 , retcode             IN OUT NOCOPY VARCHAR2
                                 --
                                 , p_period_name       IN VARCHAR2
                                 , p_ledger_id         IN NUMBER   -- p_set_of_books_id
                                 );

  PROCEDURE Activacion_Directos ( errbuf              IN OUT NOCOPY VARCHAR2
                                  , retcode             IN OUT NOCOPY VARCHAR2
                                  --
                                  , p_period_name       IN VARCHAR2
                                  , p_ledger_id         IN NUMBER
                                  );

  PROCEDURE Activacion_Indirectos ( errbuf              IN OUT NOCOPY VARCHAR2
                                  , retcode             IN OUT NOCOPY VARCHAR2
                                  --
                                  , p_period_name       IN VARCHAR2
                                  , p_ledger_id         IN NUMBER
                                  );

  PROCEDURE Evolucion_Precios ( errbuf              IN OUT NOCOPY VARCHAR2
                              , retcode             IN OUT NOCOPY VARCHAR2
                              --
                              , p_operating_unit    IN NUMBER
                              , p_period_name       IN VARCHAR2
                              );

  PROCEDURE Alert_Regla_ValCruzada ( errbuf      IN OUT VARCHAR2
                                   , retcode     IN OUT NUMBER
                                   , p_audit_id  IN     NUMBER
                                   );


  PROCEDURE Asocia_CP_FC ( errbuf        IN OUT VARCHAR2
                         , retcode       IN OUT NUMBER
                         , p_org_id      IN NUMBER
                         , p_fecha_desde IN VARCHAR2
                         , p_fecha_hasta IN VARCHAR2
                         , p_cuenta      IN VARCHAR2
                         );

END XX_GL_REPORTS_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_GL_REPORTS_PKG" AS

  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);

  FUNCTION xml_escape_chars ( p_data VARCHAR2 ) RETURN VARCHAR IS
    l_data VARCHAR2(32767);
  BEGIN
    l_data := REPLACE(REPLACE(REPLACE(p_data, '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
    RETURN l_data;
  END xml_escape_chars;


  FUNCTION Get_YesNo ( p_code VARCHAR2 ) RETURN VARCHAR2 IS
  BEGIN
    g_param_desc := NULL;

    SELECT meaning
    INTO g_param_desc
    FROM fnd_lookup_values_vl
    WHERE lookup_type = 'YES_NO'
    AND view_application_id = 0
    AND lookup_code = p_code;

    RETURN g_param_desc;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END Get_YesNo;


  PROCEDURE Activacion_Sementera ( errbuf              IN OUT NOCOPY VARCHAR2
                                 , retcode             IN OUT NOCOPY VARCHAR2
                                 --
                                 , p_period_name       IN VARCHAR2
                                 , p_ledger_id   IN NUMBER   -- p_set_of_books_id
                                 ) IS
    CURSOR c1 IS
      SELECT nom_periodo
           , gastos_directos
           , saldo
           , cuenta_activacion
           , NVL(TO_CHAR(has_sembradas),'N\A') has_sembradas
           , NVL(TO_CHAR(has_cosechadas),'N\A') has_cosechadas
           , DECODE(has_sembradas
                   , NULL, 'N/A'
                   , 0, 'N/A'
                   , ROUND(1 - (has_cosechadas / has_sembradas), 2)
                   ) activacion
           , DECODE(has_sembradas
                   , NULL, 'N/A'
                   , 0, 'N/A'
                   , ROUND(saldo * (1 - (has_cosechadas / has_sembradas)), 2)
                   ) monto_activacion
      FROM (  SELECT gb.period_name NOM_PERIODO
                   , gcc_kfv.concatenated_segments GASTOS_DIRECTOS
                   , ROUND((NVL(gb.period_net_dr,0) + NVL(gb.begin_balance_dr,0)) - NVL(gb.period_net_cr,0) - NVL(gb.begin_balance_cr,0),2) SALDO
                   , ( SELECT gcc_kfva.concatenated_segments
                       FROM gl_code_combinations_kfv gcc_kfva
                       WHERE gcc_kfva.code_combination_id = sem.cc_activacion
                     ) CUENTA_ACTIVACION
                   , ( SELECT ROUND((NVL(gba.period_net_dr,0) + NVL(gba.begin_balance_dr,0)) - NVL(gba.period_net_cr,0) - NVL(gba.begin_balance_cr,0),2) -- ROUND((gba.period_net_dr - gba.period_net_cr), 2)
                       FROM gl_balances              gba
                       WHERE 1=1
                       AND gba.code_combination_id = sem.cc_has_sembradas
                       AND gba.period_name         = gb.period_name
                       --AND gba.set_of_books_id     = gb.set_of_books_id
                       -- ITC
                       AND gba.ledger_id     = gb.ledger_id--gb.set_of_books_id
                     ) HAS_SEMBRADAS
                   , ( SELECT ROUND((NVL(gba.period_net_dr,0) + NVL(gba.begin_balance_dr,0)) - NVL(gba.period_net_cr,0) - NVL(gba.begin_balance_cr,0),2) -- ROUND((gba.period_net_dr - gba.period_net_cr), 2)
                       FROM gl_balances              gba
                       WHERE 1=1
                       AND gba.code_combination_id = sem.cc_has_cosechadas
                       AND gba.period_name         = gb.period_name
                       --AND gba.set_of_books_id     = gb.set_of_books_id
                       -- ITC
                       AND gba.ledger_id     = gb.ledger_id--gb.set_of_books_id
                     ) HAS_COSECHADAS
              FROM gl_balances        gb
                 , gl_ledgers         gl
                 -- ITC
                 --, gl_sets_of_books         sob
                 , gl_code_combinations_kfv gcc_kfv
                 , (  SELECT gcc.code_combination_id cc_gastos_directos, segment1, segment2, segment3, segment4, segment5, segment6, segment7
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = ( SELECT fv.attribute6
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fv.attribute5           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fv.flex_value           = gcc.segment2
                                                 )
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = gcc.segment4
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = gcc.segment6
                               AND cc.segment7 = gcc.segment7
                             ) cc_activacion
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = '950001'
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = gcc.segment4
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = gcc.segment6
                               AND cc.segment7 = gcc.segment7
                             ) cc_has_sembradas
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = '940001'
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = gcc.segment4
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = gcc.segment6
                               AND cc.segment7 = gcc.segment7
                             ) cc_has_cosechadas
                      FROM gl_code_combinations gcc
                      WHERE 1=1
                      AND segment1 IN ( SELECT DISTINCT gle.flex_segment_value FROM hr_operating_units hou, gl_legal_entities_bsvs gle WHERE hou.set_of_books_id = p_ledger_id AND gle.legal_entity_id = hou.default_legal_context_id )
                      --AND chart_of_accounts_id = 50288
                      AND segment2 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute5           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                      )
                      AND segment3 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_UNIDAD_NEGOCIOS'
                                      )
                      AND segment4 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_PRODUCTO'
                                      )
                      AND segment5 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute2           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_UNIDAD_PRODUCTIVA'
                                      )
                      AND segment6 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_CENTRO_COSTO'
                                      )
                      AND segment7 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                      )
                    ) sem
              WHERE 1=1
              --AND sob.set_of_books_id = gb.set_of_books_id
              --AND sob.currency_code   = gb.currency_code
              -- ITC
              AND gl.ledger_id = gb.ledger_id
              AND gl.currency_code   = gb.currency_code
              AND gcc_kfv.code_combination_id = gb.code_combination_id
              AND gcc_kfv.code_combination_id = sem.cc_gastos_directos
              --
              AND gb.actual_flag           = 'A'
              AND gb.period_name           = p_period_name
              AND gb.ledger_id             = p_ledger_id
              -- ITC
              --AND gb.set_of_books_id       = --p_set_of_books_id
              --AND gcc_kfv.chart_of_accounts_id = 50288
              --
              --AND gcc_kfv.code_combination_id = 594637
           ) q;

  BEGIN
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Parametros:');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '-----------');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'PERIOD_NAME: '||p_period_name);
  FND_FILE.PUT_LINE(FND_FILE.LOG, 'LEDGER_ID: '||p_ledger_id);
  --FND_FILE.PUT_LINE(FND_FILE.LOG, 'SET_OF_BOOKS_ID: '||p_set_of_books_id);

  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'PERIODO GASTOS DIRECTOS                              SALDO ACUMULADO   CUENTA ACTIVACION                         HAS SEMBRAHAS      COSECHADAS  % ACTIVA SEMENTERA MONTO A ACTIVAR');

    FOR r1 IN c1 LOOP
      FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(r1.nom_periodo, 8, ' ')
                                       ||RPAD(r1.gastos_directos, 45, ' ')
                                       ||LPAD(r1.saldo, 15, ' ')
                                       ||'   '||RPAD(r1.cuenta_activacion, 45, ' ')
                                       ||LPAD(r1.has_sembradas, 10, ' ')
                                       ||LPAD(r1.has_cosechadas, 16, ' ')
                                       ||LPAD(r1.activacion, 19, ' ')
                                       ||LPAD(r1.monto_activacion, 16, ' ')
                      );
    END LOOP;

  END Activacion_Sementera;

  PROCEDURE Activacion_Directos ( errbuf              IN OUT NOCOPY VARCHAR2
                                 , retcode             IN OUT NOCOPY VARCHAR2
                                 --
                                 , p_period_name       IN VARCHAR2
                                 , p_ledger_id   IN NUMBER
                                 ) IS
    CURSOR c1 IS
      SELECT nom_periodo
           , gastos_directos
           , saldo
           , cuenta_activacion
           , NVL(TO_CHAR(has_sembradas),'N\A') has_sembradas
           , NVL(TO_CHAR(has_cosechadas),'N\A') has_cosechadas
           , DECODE(has_sembradas
                   , NULL, 'N/A'
                   , 0, 'N/A'
                   , ROUND(1 - (has_cosechadas / has_sembradas), 2)
                   ) activacion
           , DECODE(has_sembradas
                   , NULL, 'N/A'
                   , 0, 'N/A'
                   , ROUND(saldo * (1 - (has_cosechadas / has_sembradas)), 2)
                   ) monto_activacion
      FROM (  SELECT gb.period_name NOM_PERIODO
                   , gcc_kfv.concatenated_segments GASTOS_DIRECTOS
                   , ROUND((NVL(gb.period_net_dr,0) + NVL(gb.begin_balance_dr,0)) - NVL(gb.period_net_cr,0) - NVL(gb.begin_balance_cr,0),2) SALDO
                   , ( SELECT gcc_kfva.concatenated_segments
                       FROM gl_code_combinations_kfv gcc_kfva
                       WHERE gcc_kfva.code_combination_id = gdir.cc_activacion
                     ) CUENTA_ACTIVACION
                   , ( SELECT ROUND((NVL(gba.period_net_dr,0) + NVL(gba.begin_balance_dr,0)) - NVL(gba.period_net_cr,0) - NVL(gba.begin_balance_cr,0),2) -- ROUND((gba.period_net_dr - gba.period_net_cr), 2)
                       FROM gl_balances              gba
                       WHERE 1=1
                       AND gba.code_combination_id IN (SELECT cc.code_combination_id
                                                       FROM gl_code_combinations cc
                                                       WHERE 1=1
                                                       AND cc.segment1 = gdir.segment1
                                                       AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute5           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                                           AND fvh.child_flex_value_low = '950001'
                                                                          ) -- ADM en directos
                                                       AND cc.segment3 = 'T' -- ADM
                                                       AND cc.segment4 = gdir.segment4 -- ADM en sementeras
                                                       AND cc.segment5 = gdir.segment5
                                                       AND cc.segment6 = 'T' -- ADM en indirectos
                                                       AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute1           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                                           AND fvh.child_flex_value_low = gdir.segment7 -- ADM en indirectos
                                                                         )
                                                       AND cc.segment8 = 'T' -- ADM
                                                      )
                       AND gba.period_name         = gb.period_name
                       AND gba.ledger_id           = gb.ledger_id
                     ) HAS_SEMBRADAS
                   , ( SELECT ROUND((NVL(gba.period_net_dr,0) + NVL(gba.begin_balance_dr,0)) - NVL(gba.period_net_cr,0) - NVL(gba.begin_balance_cr,0),2) -- ROUND((gba.period_net_dr - gba.period_net_cr), 2)
                       FROM gl_balances              gba
                       WHERE 1=1
                       AND gba.code_combination_id IN (SELECT cc.code_combination_id
                                                       FROM gl_code_combinations cc
                                                       WHERE 1=1
                                                       AND cc.segment1 = gdir.segment1
                                                       AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute5           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                                           AND fvh.child_flex_value_low = '940001'
                                                                          ) -- ADM en directos
                                                       AND cc.segment3 = 'T' -- ADM
                                                       AND cc.segment4 = gdir.segment4 -- ADM en sementeras
                                                       AND cc.segment5 = gdir.segment5
                                                       AND cc.segment6 = 'T' -- ADM en indirectos
                                                       AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute1           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                                           AND fvh.child_flex_value_low = gdir.segment7 -- ADM en indirectos
                                                                         )
                                                       AND cc.segment8 = 'T' -- ADM
                                                      )
                       AND gba.period_name         = gb.period_name
                       AND gba.ledger_id           = gb.ledger_id
                     ) HAS_COSECHADAS
              FROM gl_balances        gb
                 , gl_ledgers         gl
                 , gl_code_combinations_kfv gcc_kfv
                 , (  SELECT gcc.code_combination_id cc_gastos_directos
                           , gcc.segment1, gcc.segment2, gcc.segment3, gcc.segment4, gcc.segment5, gcc.segment6, gcc.segment7, gcc.segment8
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = ( SELECT fv.attribute6 --SELECT fv.attribute7 -- en indirectos
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fv.attribute5           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fv.flex_value           = gcc.segment2
                                                 )
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = gcc.segment4
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = gcc.segment6
                               AND cc.segment7 = gcc.segment7
                               --AND cc.segment8 = gcc.segment8 -- ADM en indirectos, ver si aplica en directos
                             ) cc_activacion
/*                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               --AND cc.segment2 = '950001' -- ADM segun definicion
                               AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute5           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fvh.child_flex_value_low = '950001'
                                                  ) -- ADM en directos
                               AND cc.segment3 = 'T' -- ADM
--                               AND cc.segment3 = gcc.segment3 -- ADM segun documento directos
                               AND cc.segment4 = gcc.segment4 -- ADM en sementeras
--                               AND cc.segment4 = 'T' -- ADM en indirectos
                               AND cc.segment5 = gcc.segment5
                               --AND cc.segment6 = gcc.segment6 -- ADM en sementeras
                               AND cc.segment6 = 'T' -- ADM en indirectos
                               --AND cc.segment7 = gcc.segment7 -- ADM antes
                               AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute1           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                   AND fvh.child_flex_value_low = gcc.segment7 -- ADM en indirectos
                                                 )
                               AND cc.segment8 = 'T' -- ADM
                          ) cc_has_sembradas
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               --AND cc.segment2 = '940001' -- ADM segun definicion
                               AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute5           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fvh.child_flex_value_low = '940001'
                                                  ) -- ADM en directos
--                               AND cc.segment3 = gcc.segment3
                               AND cc.segment3 = 'T' -- ADM
                               AND cc.segment4 = gcc.segment4 -- ADM en sementeras
--                               AND cc.segment4 = 'T' -- ADM en indirectos
                               AND cc.segment5 = gcc.segment5
                               --AND cc.segment6 = gcc.segment6 -- ADM en sementeras
                               AND cc.segment6 = 'T' -- ADM en indirectos
                               --AND cc.segment7 = gcc.segment7 -- ADM antes
                               AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute1           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                   AND fvh.child_flex_value_low = gcc.segment7 -- ADM en indirectos
                                                 )
                               AND cc.segment8 = 'T' -- ADM
                             ) cc_has_cosechadas*/
                      FROM gl_code_combinations gcc
                      WHERE 1=1
                      AND gcc.segment1 IN ( SELECT DISTINCT gle.flex_segment_value FROM hr_operating_units hou, gl_legal_entities_bsvs gle WHERE hou.set_of_books_id = p_ledger_id AND gle.legal_entity_id = hou.default_legal_context_id )
                      AND gcc.segment2 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute5           = 'Y' -- ADM ok
                                        AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                      )
                      AND gcc.segment3 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y' -- ADM ok
                                        AND fvs.flex_value_set_name = 'XX_GL_UNIDAD_NEGOCIOS'
                                      )
                      AND gcc.segment4 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y'-- ADM ok
                                        AND fvs.flex_value_set_name = 'XX_GL_PRODUCTO'
                                      )
                      AND gcc.segment5 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute2           = 'Y' -- ADM ok
                                        AND fvs.flex_value_set_name = 'XX_GL_UNIDAD_PRODUCTIVA'
                                      )
                      AND gcc.segment6 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y' -- ADM ok
                                        AND fvs.flex_value_set_name = 'XX_GL_CENTRO_COSTO'
                                      )
                      AND gcc.segment7 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute1           = 'Y' -- ADM ok
                                        AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                      )
                    ) gdir
              WHERE 1=1
              AND gl.ledger_id = gb.ledger_id
              AND gl.currency_code   = gb.currency_code
              AND gcc_kfv.code_combination_id = gb.code_combination_id
              AND gcc_kfv.code_combination_id = gdir.cc_gastos_directos
              --
              AND gb.actual_flag           = 'A'
              AND gb.period_name           = p_period_name
              AND gb.ledger_id             = p_ledger_id
           ) q;

  BEGIN
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Parametros:');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '-----------');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'PERIOD_NAME: '||p_period_name);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'LEDGER_ID: '||p_ledger_id);

  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'PERIODO GASTOS DIRECTOS                              SALDO ACUMULADO   CUENTA ACTIVACION                         HAS SEMBRAHAS      COSECHADAS  % ACTIVA SEMENTERA MONTO A ACTIVAR');

    FOR r1 IN c1 LOOP
      FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(r1.nom_periodo, 8, ' ')
                                       ||RPAD(r1.gastos_directos, 45, ' ')
                                       ||LPAD(r1.saldo, 15, ' ')
                                       ||'   '
                                       ||RPAD(NVL(r1.cuenta_activacion,' '), 45, ' ')
                                       ||LPAD(NVL(r1.has_sembradas,'N/A'), 10, ' ')
                                       ||LPAD(NVL(r1.has_cosechadas,'N/A'), 16, ' ')
                                       ||LPAD(NVL(r1.activacion,'N/A'), 19, ' ')
                                       ||LPAD(NVL(r1.monto_activacion,'N/A'), 16, ' ')
                      );
    END LOOP;

  END Activacion_Directos;

   PROCEDURE Activacion_Indirectos ( errbuf              IN OUT NOCOPY VARCHAR2
                                  , retcode             IN OUT NOCOPY VARCHAR2
                                  --
                                  , p_period_name       IN VARCHAR2
                                  , p_ledger_id   IN NUMBER
                                  ) IS
    CURSOR c1 IS
      SELECT nom_periodo
           , gastos_indirectos
           , saldo
           , cuenta_activacion_gind
           , NVL(TO_CHAR(has_sembradas),'N\A') has_sembradas
           , NVL(TO_CHAR(has_cosechadas),'N\A') has_cosechadas
           , DECODE(has_sembradas
                   , NULL, 'N/A'
                   , 0, 'N/A'
                   , ROUND(1 - (has_cosechadas / has_sembradas), 4)
                   ) activacion
           , DECODE(has_sembradas
                   , NULL, 'N/A'
                   , 0, 'N/A'
                   , ROUND(saldo * (1 - (has_cosechadas / has_sembradas)), 4)
                   ) monto_activacion
      FROM (  SELECT gb.period_name NOM_PERIODO
                   , gcc_kfv.concatenated_segments GASTOS_INDIRECTOS
                   , ROUND((NVL(gb.period_net_dr,0) + NVL(gb.begin_balance_dr,0)) - NVL(gb.period_net_cr,0) - NVL(gb.begin_balance_cr,0),4) SALDO
                   , ( SELECT gcc_kfva.concatenated_segments
                       FROM gl_code_combinations_kfv gcc_kfva
                       WHERE gcc_kfva.code_combination_id = gind.cc_activacion_indirectos
                     ) CUENTA_ACTIVACION_GIND
                   , ( SELECT (NVL(gba.period_net_dr,0) + NVL(gba.begin_balance_dr,0)) - NVL(gba.period_net_cr,0) - NVL(gba.begin_balance_cr,0) -- ROUND((gba.period_net_dr - gba.period_net_cr), 2)
                       FROM gl_balances              gba
                       WHERE 1=1
                       AND gba.code_combination_id IN (SELECT cc.code_combination_id
                                                       FROM gl_code_combinations cc
                                                       WHERE 1=1
                                                       AND cc.segment1 = gind.segment1
                                                       AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute8           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                                           AND fvh.child_flex_value_low = '950001'
                                                                          )
                                                       AND cc.segment3 = gind.segment3
                                                       AND cc.segment4 = 'T'
                                                       AND cc.segment5 = gind.segment5
                                                       AND cc.segment6 = 'T'
                                                       AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute2           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                                           AND fvh.child_flex_value_low = gind.segment7
                                                                         )
                                                      )
                       AND gba.period_name         = gb.period_name
                       AND gba.ledger_id           = gb.ledger_id
                     ) HAS_SEMBRADAS
                   , ( SELECT (NVL(gba.period_net_dr,0) + NVL(gba.begin_balance_dr,0)) - NVL(gba.period_net_cr,0) - NVL(gba.begin_balance_cr,0) -- ROUND((gba.period_net_dr - gba.period_net_cr), 2)
                       FROM gl_balances              gba
                       WHERE 1=1
                       AND gba.code_combination_id IN (SELECT cc.code_combination_id
                                                       FROM gl_code_combinations cc
                                                       WHERE 1=1
                                                       AND cc.segment1 = gind.segment1
                                                       AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute8           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                                           AND fvh.child_flex_value_low = '940001'
                                                                          )
                                                       AND cc.segment3 = gind.segment3
                                                       AND cc.segment4 = 'T'
                                                       AND cc.segment5 = gind.segment5
                                                       AND cc.segment6 = 'T'
                                                       AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                                           FROM fnd_flex_values      fv
                                                                              , fnd_flex_value_sets  fvs
                                                                              , fnd_flex_value_norm_hierarchy fvh
                                                                           WHERE 1=1
                                                                           AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                                           AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                                           AND fv.attribute2           = 'Y'
                                                                           AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                                           AND fvh.child_flex_value_low = gind.segment7
                                                                         )
                                                      )
                       AND gba.period_name         = gb.period_name
                       AND gba.ledger_id           = gb.ledger_id
                     ) HAS_COSECHADAS
              FROM gl_balances              gb
               --  , gl_sets_of_books         sob
               ,gl_ledgers sob
                 , gl_code_combinations_kfv gcc_kfv
                 , (  SELECT gcc.code_combination_id cc_gastos_indirectos, segment1, segment2, segment3, segment4, segment5, segment6, segment7
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = ( SELECT fv.attribute7
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fv.attribute8           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fv.flex_value           = gcc.segment2
                                                 )
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = gcc.segment4 --'000' --PRODUCTO
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = gcc.segment6 --DECODE(gcc.segment3, '60', '3110', '3001') --CENTRO DE COSTO
                               AND cc.segment7 = gcc.segment7
                               AND cc.segment8 = gcc.segment8 --'0' --INTERCO
                             ) cc_activacion_indirectos
                           /*, ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute8           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fvh.child_flex_value_low = '950001'
                                                  )
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = 'T'
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = 'T'
                               AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute2           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                   AND fvh.child_flex_value_low = gcc.segment7
                                                 )
                             ) cc_has_sembradas
                           , ( SELECT cc.code_combination_id
                               FROM gl_code_combinations cc
                               WHERE 1=1
                               AND cc.segment1 = gcc.segment1
                               AND cc.segment2 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute8           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                                   AND fvh.child_flex_value_low = '940001'
                                                  )
                               AND cc.segment3 = gcc.segment3
                               AND cc.segment4 = 'T'
                               AND cc.segment5 = gcc.segment5
                               AND cc.segment6 = 'T'
                               AND cc.segment7 = ( SELECT DISTINCT fvh.parent_flex_value
                                                   FROM fnd_flex_values      fv
                                                      , fnd_flex_value_sets  fvs
                                                      , fnd_flex_value_norm_hierarchy fvh
                                                   WHERE 1=1
                                                   AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                                   AND fvh.flex_value_set_id   = fvs.flex_value_set_id
                                                   AND fv.attribute2           = 'Y'
                                                   AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                                   AND fvh.child_flex_value_low = gcc.segment7
                                                 )
                             ) cc_has_cosechadas*/
                      FROM gl_code_combinations gcc
                      WHERE 1=1
                      AND segment1 IN ( SELECT distinct gle.flex_segment_value FROM hr_operating_units hou, gl_legal_entities_bsvs gle WHERE hou.set_of_books_id = p_ledger_id AND gle.legal_entity_id = hou.default_legal_context_id )
                      --AND chart_of_accounts_id = 50288
                      AND segment2 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute8           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_CUENTA'
                                      )
                      AND segment3 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute2           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_UNIDAD_NEGOCIOS'
                                      )
                      --AND segment4 = 'T'
                      AND segment4 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute2           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_PRODUCTO'
                                      )
                      AND segment5 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute3           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_UNIDAD_PRODUCTIVA'
                                      )
                      --AND segment6 = 'T'
                      AND segment6 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute2           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_CENTRO_COSTO'
                                      )
                      AND segment7 IN ( SELECT flex_value
                                        FROM fnd_flex_values      fv
                                           , fnd_flex_value_sets  fvs
                                        WHERE 1=1
                                        AND fv.flex_value_set_id    = fvs.flex_value_set_id
                                        AND fv.attribute2           = 'Y'
                                        AND fvs.flex_value_set_name = 'XX_GL_PROYECTO'
                                      )
                    ) gind
              WHERE 1=1
              AND sob.ledger_id = gb.ledger_id
              AND sob.currency_code   = gb.currency_code
              AND gcc_kfv.code_combination_id = gb.code_combination_id
              AND gcc_kfv.code_combination_id = gind.cc_gastos_indirectos
              --
              AND gb.actual_flag           = 'A'
              AND gb.period_name           = p_period_name
              AND gb.ledger_id       = p_ledger_id
              --AND gcc_kfv.chart_of_accounts_id = 50288
              --
              --AND gcc_kfv.code_combination_id = 594637
           ) q;

  BEGIN
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Parametros:');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '-----------');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'PERIOD_NAME: '||p_period_name);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'SET_OF_BOOKS_ID: '||p_ledger_id);

    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'PERIODO GASTOS INDIRECTOS                            SALDO ACUMULADO   CUENTA ACTIVACION GASTOS INDIRECTOS       HAS SEMBRAHAS      COSECHADAS  % ACTIVA GTOS INDI MONTO A ACTIVAR');

    FOR r1 IN c1 LOOP
      FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(r1.nom_periodo, 8, ' ')
                                       ||RPAD(r1.gastos_indirectos, 45, ' ')
                                       ||LPAD(r1.saldo, 15, ' ')
                                       ||'   '||RPAD(r1.cuenta_activacion_gind, 45, ' ')
                                       ||LPAD(r1.has_sembradas, 10, ' ')
                                       ||LPAD(r1.has_cosechadas, 16, ' ')
                                       ||LPAD(r1.activacion, 19, ' ')
                                       ||LPAD(r1.monto_activacion, 16, ' ')
                      );
    END LOOP;

  END Activacion_Indirectos;

  PROCEDURE Evolucion_Precios ( errbuf              IN OUT NOCOPY VARCHAR2
                              , retcode             IN OUT NOCOPY VARCHAR2
                              --
                              , p_operating_unit    IN NUMBER
                              , p_period_name       IN VARCHAR2
                              ) IS

    CURSOR c_ous IS
      SELECT name, organization_id
      FROM hr_operating_units
      WHERE 1=1
      AND (name LIKE 'AR%' OR
           name LIKE 'UR%'
          )
      AND organization_id = NVL(p_operating_unit, organization_id)
      ;

    CURSOR c_stocks ( p_org_id      IN NUMBER
                    , p_period_name IN VARCHAR2
                    ) IS
      SELECT x.unidad_operativa, x.org_id, x.item_id, x.item , x.item_description, x.uom , sum(x.stock) stock
      FROM (SELECT haou.name                unidad_operativa,
                   haou.organization_id     org_id,
                   msib.segment1            item,
                   msib.inventory_item_id   item_id,
                   msib.description         item_description,
                   msib.primary_uom_code    uom,
                   gpb.primary_quantity     stock
            FROM gmf_period_balances          gpb,
                 org_organization_definitions ood,
                 hr_all_organization_units    haou,
                 org_acct_periods             oap,
                 mtl_system_items_b           msib
            WHERE  1 = 1
            AND gpb.organization_id = ood.organization_id
            AND gpb.acct_period_id  = oap.acct_period_id
            AND oap.period_name     = p_period_name --'MAY-18'
            AND ood.operating_unit  = haou.organization_id
            AND ood.operating_unit  = p_org_id
            AND gpb.inventory_item_id = msib.inventory_item_id
            AND gpb.organization_id = msib.organization_id
            UNION ALL
            SELECT haou.name unidad_operativa,
                   haou.organization_id org_id,
                   msib.segment1 item,
                   msib.inventory_item_id item_id,
                   msib.description item_description,
                   msib.primary_uom_code ,
                   gpb.rollback_quantity
            FROM cst_period_close_summary     gpb,
                 org_organization_definitions ood,
                 hr_all_organization_units    haou,
                 org_acct_periods             oap,
                 mtl_system_items_b           msib
            WHERE  1 = 1
            AND gpb.organization_id = ood.organization_id
            AND gpb.acct_period_id = oap.acct_period_id
            AND oap.period_name = p_period_name --'MAY-18'
            AND ood.operating_unit = haou.organization_id
            AND ood.operating_unit = p_org_id
            AND gpb.inventory_item_id = msib.inventory_item_id
            AND gpb.organization_id = msib.organization_id
           ) x
      WHERE x.org_id = p_org_id
      GROUP BY x.unidad_operativa, x.org_id, x.item_id, x.item , x.item_description, x.uom
      HAVING SUM(x.stock) > 0
      ;

    CURSOR c_receipts ( p_org_id  IN NUMBER
                      , p_item_id IN NUMBER
                      , p_to_date IN DATE
                      ) IS
      SELECT rt.transaction_date
           , rsh.receipt_num
           , rt.quantity
           , cod.organization_code
           , (SELECT NVL(SUM(rt_ret.quantity),0) FROM apps.rcv_transactions rt_ret
                                        WHERE rt_ret.shipment_line_id = rsl.shipment_line_id
                                        AND  rt_ret.transaction_type LIKE  'RETURN%'
                                        AND  rt_ret.destination_type_code = 'INVENTORY'
                                        AND  rt_ret.transaction_date  <= TRUNC(p_to_date)+.99
                                       ) q_ret
           , pl.unit_price
           , pv.vendor_name
           , ph.segment1 po_number
           , ph.currency_code
           , NVL(ph.rate,1) po_rate
      FROM po_vendors pv
         , po_headers_all               ph
         , rcv_transactions             rt
         , cst_organization_definitions cod
         , rcv_shipment_headers         rsh
         , rcv_shipment_lines           rsl
         , po_lines_all                 pl
      WHERE 1=1
      AND pv.vendor_id           = ph.vendor_id
      AND ph.po_header_id        = rt.po_header_id
      AND pl.po_line_id          = rt.po_line_id
      AND rt.transaction_date   <= TRUNC(p_to_date)+.99
      AND rt.transaction_type    = 'DELIVER'
      AND rt.destination_type_code = 'INVENTORY'
      AND rt.shipment_line_id    = rsl.shipment_line_id
      AND rsh.shipment_header_id = rsl.shipment_header_id
      AND rsl.item_id            = p_item_id
      AND rsl.to_organization_id = cod.organization_id
      AND cod.operating_unit     = p_org_id
      ORDER BY rt.transaction_date DESC
      ;


    r_ou c_ous%ROWTYPE;
    r_stk c_stocks%ROWTYPE;
    r_rec c_receipts%ROWTYPE;

    c_sep             VARCHAR2(1) := '|';

    v_to_date         DATE;
    v_ou_name         VARCHAR2(250);
    v_stk_remaining   NUMBER;
    v_q_rec           NUMBER;
    v_q_rec_tot       NUMBER;
    v_amount_rec      NUMBER;
    v_amount_rec_tot  NUMBER;
    v_line            VARCHAR2(200);
  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '--------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX GL Evolución de Precios');
    FND_FILE.Put_Line(FND_FILE.Log, '--------------------------'||chr(10));
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_operating_unit: '||p_operating_unit);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_period_name: '||p_period_name);

    SELECT end_date
    INTO v_to_date
    FROM gl_periods
    WHERE period_name = p_period_name;

    BEGIN
      SELECT name
      INTO v_ou_name
      FROM hr_operating_units
      WHERE organization_id = p_operating_unit;
    EXCEPTION
      WHEN OTHERS THEN
        v_ou_name := 'No Informado';
    END;

    /*FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXGLEVOLPRECIOS>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>'||xml_escape_chars('XX GL Evolución de Precios')||'</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||xml_escape_chars('Fecha Emisión|')||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_OPERATING_UNIT>Unidad Operativa'||c_sep||v_ou_name||'</P_OPERATING_UNIT>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_PERIOD_NAME>'||xml_escape_chars('Período')||c_sep||p_period_name||'</P_PERIOD_NAME>');*/

    FND_FILE.Put_Line(FND_FILE.Output, 'XX GL Evolución de Precios');
    FND_FILE.Put_Line(FND_FILE.Output, 'Fecha Emisión|'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.Output, ' ');
    FND_FILE.Put_Line(FND_FILE.Output, 'Unidad Operativa'||c_sep||v_ou_name);
    FND_FILE.Put_Line(FND_FILE.Output, 'Período'||c_sep||p_period_name);

    g_data := 'UO'||c_sep
            ||'Producto'||c_sep
            ||'Descripción'||c_sep
            ||'UOM'||c_sep
            ||'Stock'||c_sep
            ||'Proveedor'||c_sep
            ||'OC' ||c_sep
            ||'Mon'||c_sep
            ||'Rate'||c_sep
            ||'Precio Unitario'||c_sep
            ||'P. Unit F'||c_sep
            ||'Núm Recepción' ||c_sep
            ||'Org' ||c_sep
            ||'Fecha' ||c_sep
            ||'Q Rec' ||c_sep
            ||'Rec amount'
            ;


    --FND_FILE.PUT_LINE(FND_FILE.OUTPUT, '  <TITULO>'||xml_escape_chars(g_data)||'</TITULO>');
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, g_data);


    FOR r_ou IN c_ous LOOP

      FOR r_stk IN c_stocks(r_ou.organization_id,p_period_name) LOOP
        v_q_rec_tot := 0;
        v_amount_rec_tot := 0;
        v_line := r_stk.unidad_operativa||c_sep
                ||r_stk.item||c_sep
                ||r_stk.item_description||c_sep
                || r_stk.uom||c_sep
                ||r_stk.stock;
        --
        FOR r_rec IN c_receipts(r_stk.org_id, r_stk.item_id, v_to_date) LOOP

          IF  r_rec.quantity - r_rec.q_ret >  r_stk.stock - v_q_rec_tot THEN
            v_q_rec := r_stk.stock - v_q_rec_tot;
          ELSE
            v_q_rec := r_rec.quantity - r_rec.q_ret;
          END IF;

          v_q_rec_tot  := v_q_rec_tot + v_q_rec;
          v_amount_rec := v_q_rec * r_rec.unit_price*r_rec.po_rate;
          v_amount_rec_tot := v_amount_rec_tot + v_amount_rec;

          IF v_q_rec_tot >  r_stk.stock THEN
            v_q_rec := v_q_rec - (v_q_rec_tot - r_stk.stock);
          END IF;

          IF r_rec.quantity - r_rec.q_ret != 0 THEN
            --FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
            g_data:= v_line||c_sep
                   ||r_rec.vendor_name||c_sep
                   ||r_rec.po_number||c_sep
                   ||r_rec.currency_code||c_sep
                   ||r_rec.po_rate||c_sep
                   ||r_rec.unit_price||c_sep
                   ||r_rec.unit_price*r_rec.po_rate||c_sep
                   ||r_rec.receipt_num ||c_sep
                   ||r_rec.organization_code ||c_sep
                   ||r_rec.transaction_date||c_sep
                   ||v_q_rec||c_sep
                   ||v_amount_rec
                   ;

            --FND_FILE.Put_Line(FND_FILE.Output, '    <DATA>'||xml_escape_chars(g_data)||'</DATA>');
            --FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
            FND_FILE.Put_Line(FND_FILE.Output, g_data);
          END IF;

          IF v_q_rec_tot >= r_stk.stock THEN
            EXIT;
          END IF;

        END LOOP; -- Recepciones


        /* Subtotal*/
        --FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
        g_data:= v_line||c_sep
               ||''||c_sep
               ||'SubTotal'||c_sep
               ||''||c_sep
               ||''||c_sep
               ||''||c_sep
               ||''||c_sep
               ||''||c_sep
               ||''||c_sep
               ||''||c_sep
               ||v_q_rec_tot||c_sep
               ||v_amount_rec_tot
               ;
        --FND_FILE.Put_Line(FND_FILE.Output, '    <DATA>'||xml_escape_chars(g_data)||'</DATA>');
        --FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
        FND_FILE.Put_Line(FND_FILE.Output, g_data);

      END LOOP;  -- Stocks

    END LOOP;  -- Unidades Operativas

    --FND_FILE.Put_Line(FND_FILE.Output, '</XXGLEVOLPRECIOS>');

  EXCEPTION
    WHEN OTHERS THEN
      errbuf  := SQLERRM;
      retcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, errbuf);
  END Evolucion_Precios;

  PROCEDURE Alert_Regla_ValCruzada ( errbuf      IN OUT VARCHAR2
                                   , retcode     IN OUT NUMBER
                                   , p_audit_id  IN     NUMBER
                                   ) IS
    CURSOR c1 IS

      SELECT r.flex_validation_rule_name
           , r.enabled_flag
           , NVL(TO_CHAR(r.start_date_active, 'YYYY-MM-DD'), '-') start_date_active
           , NVL(TO_CHAR(r.end_date_active, 'YYYY-MM-DD'), '-') end_date_active
           , NVL(rl.error_message_text, '-') error_message_text
           , rl.language
           , '-' include_exclude_indicator
           , '-' concatenated_segments_low
           , '-' concatenated_segments_high
           , r.audit_id
           , r.trg_action
           , TO_CHAR(r.last_update_date, 'YYYY-MM-DD HH24:MI:SS') last_update_date
           , (SELECT user_name
              FROM fnd_user
              WHERE user_id = rl.last_updated_by
             ) last_updated_by
           , TO_CHAR(r.creation_date, 'YYYY-MM-DD HH24:MI:SS') creation_date
           , (SELECT user_name
              FROM fnd_user
              WHERE user_id = r.created_by
             ) created_by
      FROM xx_fndflex_vdation_rules_au    r
         , xx_fndflex_vdation_rules_tl_au rl
      WHERE 1=1
      AND rl.last_update_date = r.last_update_date
      AND r.audit_id          = p_audit_id
      AND rl.language         = 'ESA'
      UNION
      SELECT rl.flex_validation_rule_name
           , rl.enabled_flag
           , '-' start_date_active
           , '-' end_date_active
           , '-' error_message_text
           , '-' language
           , DECODE(rl.include_exclude_indicator, 'I', 'Incluir', 'E', 'Excluir') include_exclude_indicator
           , rl.concatenated_segments_low
           , rl.concatenated_segments_high
           , rl.audit_id
           , rl.trg_action
           , TO_CHAR(rl.last_update_date, 'YYYY-MM-DD HH24:MI:SS') last_update_date
           , (SELECT user_name
              FROM fnd_user
              WHERE user_id = rl.last_updated_by
             ) last_updated_by
           , TO_CHAR(rl.creation_date, 'YYYY-MM-DD HH24:MI:SS') creation_date
           , (SELECT user_name
              FROM fnd_user
              WHERE user_id = rl.created_by
             ) created_by
      FROM xx_fndflex_vdation_rules_ln_au rl
      WHERE 1=1
      AND rl.audit_id = p_audit_id
      ORDER BY 10, 11 desc, 6;

  BEGIN
    FND_FILE.Put_Line(FND_FILE.Output, 'XX GL Alerta de Modificación de Reglas de Validación Cruzada');
    FND_FILE.Put_Line(FND_FILE.Output, 'Fecha Emisión '||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS'));
    FND_FILE.Put_Line(FND_FILE.Output, ' ');
    FND_FILE.Put_Line(FND_FILE.Output, RPAD('Nombre Regla',15, ' ')||
                                       RPAD('Activa', 7, ' ')||
                                       RPAD('Fecha Desde', 13, ' ')||
                                       RPAD('Fecha Hasta', 13, ' ')||
                                       RPAD('Mensaje Error', 190, ' ')||
                                       --RPAD('Lenguaje', 9, ' ')||
                                       RPAD('Tipo', 8, ' ')||
                                       RPAD('CC Desde', 20, ' ')||
                                       RPAD('CC Hasta', 20, ' ')||
                                       RPAD('Creado Por', 20, ' ')||
                                       RPAD('Fecha Creación', 20, ' ')||
                                       RPAD('Modificado Por', 20, ' ')||
                                       RPAD('Fecha Modificación', 20, ' ')||
                                       RPAD('Acción', 13, ' ')
                                     );
    FOR r1 IN c1 LOOP
      FND_FILE.Put_Line(FND_FILE.Output, SUBSTR(RPAD(r1.flex_validation_rule_name, 15, ' '),1, 15)||
                                         SUBSTR(RPAD(Get_YesNo(r1.enabled_flag), 7, ' '),1, 7)||
                                         SUBSTR(RPAD(r1.start_date_active, 13, ' '),1, 13)||
                                         SUBSTR(RPAD(r1.end_date_active, 13, ' '), 1, 13)||
                                         SUBSTR(RPAD(r1.error_message_text, 190, ' '), 1, 190)||
                                         --SUBSTR(RPAD(r1.language, 9, ' '), 1, 9)||
                                         SUBSTR(RPAD(r1.include_exclude_indicator, 8, ' '), 1, 8)||
                                         SUBSTR(RPAD(r1.concatenated_segments_low, 20, ' '), 1, 20)||
                                         SUBSTR(RPAD(r1.concatenated_segments_high, 20, ' '), 1, 20)||
                                         SUBSTR(RPAD(r1.created_by, 20, ' '),1, 20)||
                                         SUBSTR(RPAD(r1.creation_date, 20, ' '),1, 20)||
                                         SUBSTR(RPAD(r1.last_updated_by, 20, ' '),1, 20)||
                                         SUBSTR(RPAD(r1.last_update_date, 20, ' '),1, 20)||
                                         SUBSTR(RPAD(r1.trg_action, 13, ' '),1, 13)
                                       );
    END LOOP;

  END Alert_Regla_ValCruzada;


  PROCEDURE Asocia_CP_FC ( errbuf        IN OUT VARCHAR2
                         , retcode       IN OUT NUMBER
                         , p_org_id      IN NUMBER
                         , p_fecha_desde IN VARCHAR2
                         , p_fecha_hasta IN VARCHAR2
                         , p_cuenta      IN VARCHAR2
                         ) IS
    CURSOR c1 IS
      SELECT s.vendor_name       Nombre_Vendedor
           , ai.invoice_num      Numero_Factura
           , TO_CHAR(ai.invoice_date, 'DD-MM-YYYY')     Fecha_Factura
           , TO_CHAR(aid.accounting_date, 'DD-MM-YYYY') Fecha_Contable
           , SUM(NVL(aid.base_amount, aid.amount)) Monto
           , lv.meaning          Tipo_Linea
           , zls.tax_rate_code   Nombre_Impuesto
           , cp.numero_carta_porte
           , gcc.segment2
      FROM ap.ap_invoice_distributions_all aid
         , ap_invoice_lines_all         ail
         , zx_lines_summary             zls
         , gl_code_combinations         gcc
         , fnd_lookup_values_vl         lv
         , ap_invoices_all              ai
         , xx_tcg_cartas_porte          cp
         , ap_suppliers                 s
      WHERE 1=1
      AND ail.line_number            = aid.invoice_line_number
      AND ail.invoice_id             = aid.invoice_id
      AND ai.invoice_id              = aid.invoice_id
      AND TO_CHAR(cp.carta_porte_id) = aid.attribute10
      AND zls.summary_tax_line_id(+) = aid.summary_tax_line_id
      AND gcc.code_combination_id   = aid.dist_code_combination_id
      AND lv.lookup_type             = 'INVOICE DISTRIBUTION TYPE'
      AND lv.lookup_code             = aid.line_type_lookup_code
      AND s.vendor_id                = ai.vendor_id
      AND aid.amount                 <> 0
      AND TRUNC(aid.accounting_date) BETWEEN TRUNC(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS')) AND TRUNC(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'))
      AND aid.org_id                 = p_org_id 
      GROUP BY s.vendor_name
             , ai.invoice_num
             , ai.invoice_date
             , aid.accounting_date
             , lv.meaning
             , zls.tax_rate_code
             , cp.numero_carta_porte
             , gcc.segment2
      ORDER BY aid.accounting_date;

    l_empresa   VARCHAR2(250);


  BEGIN
    FND_FILE.Put_Line(FND_FILE.Log, '-----------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'XX GL Asociación de CPs a FCs');
    FND_FILE.Put_Line(FND_FILE.Log, '-----------------------------');
    FND_FILE.Put_Line(FND_FILE.Log, 'Parametros');
    FND_FILE.Put_Line(FND_FILE.Log, 'p_org_id: '||p_org_id);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_desde: '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_fecha_hasta: '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.Log, 'p_cuenta: '||p_cuenta);

    BEGIN
      SELECT name
      INTO l_empresa
      FROM hr_operating_units
      WHERE organization_id = p_org_id;
    EXCEPTION
      WHEN OTHERS THEN
        l_empresa := 'No Especificado';
    END;

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXGLASOCPFC>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX GL Asociación de CPs a FCs</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||TO_CHAR(SYSDATE, 'DD-MM-YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_EMPRESA>'||l_empresa||'</P_EMPRESA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>'||TO_CHAR(TO_DATE(p_fecha_desde, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_HASTA>'||TO_CHAR(TO_DATE(p_fecha_hasta, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY')||'</P_FECHA_HASTA>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CUENTA>'||p_cuenta||'</P_CUENTA>');


    FOR r1 IN c1 LOOP
      IF r1.segment2 = p_cuenta THEN
        FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <NOMBRE_VENDEDOR>'||XX_UTIL_PK.xml_escape_chars(r1.NOMBRE_VENDEDOR)||'</NOMBRE_VENDEDOR>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_FACTURA>'||r1.NUMERO_FACTURA||'</NUMERO_FACTURA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_FACTURA>'||r1.FECHA_FACTURA||'</FECHA_FACTURA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_CONTABLE>'||r1.FECHA_CONTABLE||'</FECHA_CONTABLE>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <MONTO>'||r1.MONTO||'</MONTO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <TIPO_LINEA>'||r1.TIPO_LINEA||'</TIPO_LINEA>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <NOMBRE_IMPUESTO>'||r1.NOMBRE_IMPUESTO||'</NOMBRE_IMPUESTO>');
        FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_CARTA_PORTE>'||r1.NUMERO_CARTA_PORTE||'</NUMERO_CARTA_PORTE>');
        FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
      END IF;
    END LOOP;
    
    FND_FILE.Put_Line(FND_FILE.Output, '</XXGLASOCPFC>');

  EXCEPTION
    WHEN OTHERS THEN
      errbuf  := SQLERRM;
      retcode := 2;
      FND_FILE.Put_Line(FND_FILE.Log, errbuf);
  END Asocia_CP_FC;

END XX_GL_REPORTS_PKG;
/

exit
