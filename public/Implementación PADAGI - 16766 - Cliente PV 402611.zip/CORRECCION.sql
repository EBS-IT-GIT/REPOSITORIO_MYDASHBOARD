UPDATE apps.oe_order_headers_all
SET    sold_to_org_id  = 9471519
     , ship_to_org_id  = 281666
     , invoice_to_org_id = 281668
WHERE  org_id = 192
AND    header_id = 9798680;
--1 Registro
