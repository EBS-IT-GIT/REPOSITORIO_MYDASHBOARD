#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2283_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2283
# |
# | HISTORY
# |   22-JAN-20  Gallucci, Pablo Nicolás - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2283_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2283_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2283
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/FUNC
mkdir -p xbol/12.0.0/FNDLOAD/MENU
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/REQGRP
mkdir -p au/12.0.0/forms/US/
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2283" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2283_13787.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2283"
AddAllLogs $CROUT "FND" "CR2283_13787.ldt"
mv CR2283_13787.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_OPM_PROC_GI_PK " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_OPM_PROC_GI_PK','APPS','$PATCHDIR','CR2283');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_OPM_PROC_GI_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXOPMCONFGCOLU.ldt FUNCTION FUNCTION_NAME="XXOPMCONFGCOLU"
AddAllLogs $CROUT "FND" "XXOPMCONFGCOLU.ldt"
mv XXOPMCONFGCOLU.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-FUNC XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XXOPMCONFGILIN.ldt FUNCTION FUNCTION_NAME="XXOPMCONFGILIN"
AddAllLogs $CROUT "FND" "XXOPMCONFGILIN.ldt"
mv XXOPMCONFGILIN.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/FUNC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_OPM_COSTOS_ARG_R12 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_OPM_COSTOS_ARG_R12.ldt MENU MENU_NAME="XX_OPM_COSTOS_ARG_R12"
AddAllLogs $CROUT "FND" "XX_OPM_COSTOS_ARG_R12.ldt"
mv XX_OPM_COSTOS_ARG_R12.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-MENU XX_OPM_SUPERUSER_R12 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afsload.lct XX_OPM_SUPERUSER_R12.ldt MENU MENU_NAME="XX_OPM_SUPERUSER_R12"
AddAllLogs $CROUT "FND" "XX_OPM_SUPERUSER_R12.ldt"
mv XX_OPM_SUPERUSER_R12.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/MENU

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-REQGRP XXOPMAllReports " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpreqg.lct XXOPMAllReports.ldt REQUEST_GROUP REQUEST_GROUP_NAME="XX OPM All Reports" APPLICATION_SHORT_NAME="XBOL"
AddAllLogs $CROUT "FND" "XXOPMAllReports.ldt"
mv XXOPMAllReports.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/REQGRP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-REQGRP XXOPMARGMF " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpreqg.lct XXOPMARGMF.ldt REQUEST_GROUP REQUEST_GROUP_NAME="XX OPM AR GMF" APPLICATION_SHORT_NAME="XBOL"
AddAllLogs $CROUT "FND" "XXOPMARGMF.ldt"
mv XXOPMARGMF.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/REQGRP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOPMPGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOPMPGI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOPMPGI"
AddAllLogs $CROUT "FND" "XXOPMPGI.ldt"
mv XXOPMPGI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOPMRGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOPMRGI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOPMRGI"
AddAllLogs $CROUT "FND" "XXOPMRGI.ldt"
mv XXOPMRGI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXOPMAGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXOPMAGI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXOPMAGI"
AddAllLogs $CROUT "FND" "XXOPMAGI.ldt"
mv XXOPMAGI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PERSO XXOPMCONFGCOLU_10 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct XXOPMCONFGCOLU_10.ldt FND_FORM_CUSTOM_RULES FUNCTION_NAME="XXOPMCONFGCOLU" SEQUENCE="10"
AddAllLogs $CROUT "FND" "XXOPMCONFGCOLU_10.ldt"
mv XXOPMCONFGCOLU_10.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PERSO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PERSO XXOPMCONFGCOLU_20 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct XXOPMCONFGCOLU_20.ldt FND_FORM_CUSTOM_RULES FUNCTION_NAME="XXOPMCONFGCOLU" SEQUENCE="20"
AddAllLogs $CROUT "FND" "XXOPMCONFGCOLU_20.ldt"
mv XXOPMCONFGCOLU_20.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PERSO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb ]; then
  cp $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb XXOPMCONFGCOLU.fmb
  echo `ls -lh XXOPMCONFGCOLU.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXOPMCONFGCOLU.fmb no existe" >> $CROUT
fi
mv XXOPMCONFGCOLU* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FORMS- XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
if [ -r $AU_TOP/forms/US/XXOPMCONFGILIN.fmb ]; then
  cp $AU_TOP/forms/US/XXOPMCONFGILIN.fmb XXOPMCONFGILIN.fmb
  echo `ls -lh XXOPMCONFGILIN.fmb` >> $CROUT
else
 echo " El archivo $AU_TOP/forms/US/XXOPMCONFGILIN.fmb no existe" >> $CROUT
fi
mv XXOPMCONFGILIN* $DOWNDBDIR/au/12.0.0/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXOPMRGI " >> $CROUT; echo "" >> $CROUT

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE DATA_TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXOPMRGI \
-LANGUAGE "00" \
-TERRITORY "00" \
-XDO_FILE_TYPE XML \
-FILE_NAME XXOPMRGI_v02.xml \
-CUSTOM_MODE FORCE \
-LOG_FILE XXOPMRGI_xmldt_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXOPMRGI.ldt"
mv XXOPMRGI* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXOPMRGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXOPMRGI.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXOPMRGI"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXOPMRGI \
-LANGUAGE "en" \
-TERRITORY "00" \
-LOG_FILE XXOPMRGI_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXOPMRGI.ldt"
mv XXOPMRGI* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_OPM_PROC_GI_PK " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_PROC_GI_PK >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_PROC_GI_PK.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_PROC_GI_PK.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_PROC_GI_PK.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_OPM_PROC_GI_PK.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_OPM_PROC_GI_PK.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-FUNC XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGCOLU.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-FUNC XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/FUNC/XXOPMCONFGILIN.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-MENU XX_OPM_COSTOS_ARG_R12 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_COSTOS_ARG_R12.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-MENU XX_OPM_SUPERUSER_R12 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/MENU/XX_OPM_SUPERUSER_R12.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-REQGRP XXOPMAllReports " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpreqg.lct $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMAllReports.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-REQGRP XXOPMARGMF " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpreqg.lct $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/XXOPMARGMF.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXOPMPGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOPMPGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOPMPGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOPMPGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOPMPGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMPGI.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXOPMRGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOPMRGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOPMRGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOPMRGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOPMRGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMRGI.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXOPMAGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOPMAGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOPMAGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM AR GMF' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXOPMAGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXOPMAGI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX OPM All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXOPMAGI.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PERSO XXOPMCONFGCOLU_10 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_10.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PERSO XXOPMCONFGCOLU_20 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/XXOPMCONFGCOLU_20.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXOPMCONFGCOLU.fmb`" >> $CROUT
mv XXOPMCONFGCOLU.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXOPMCONFGCOLU.fmx` >> $CROUT
cd $CURDIR
if ! ls /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
CURDIR=`pwd`
cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb  $AU_TOP/forms/US
cd $AU_TOP/forms/US
echo "`frmcmp_batch userid=apps/$APPS_PWD module=XXOPMCONFGILIN.fmb`" >> $CROUT
mv XXOPMCONFGILIN.fmx $XBOL_TOP/forms/US/
echo `ls -lh $XBOL_TOP/forms/US/XXOPMCONFGILIN.fmx` >> $CROUT
cd $CURDIR
if ! ls /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb &> /dev/null; then 
  cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log  /desa12/svn/XXADECUSTOMS/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXOPMRGI " >> $CROUT; echo "" >> $CROUT

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE DATA_TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXOPMRGI \
-LANGUAGE "00" \
-TERRITORY "00" \
-XDO_FILE_TYPE XML \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_v02.xml \
-CUSTOM_MODE FORCE \
-LOG_FILE XXOPMRGI_xmldt_up.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt"

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_v02.xml &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_v02.xml /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_v02.xml >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_v02.xml /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_v02.xml -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXOPMRGI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXOPMRGI \
-LANGUAGE "en" \
-TERRITORY "00" \
-XDO_FILE_TYPE XSL-XML \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_en.xsl-xml  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXOPMRGI_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_en.xsl-xml &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_en.xsl-xml /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_en.xsl-xml >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_en.xsl-xml /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXOPMRGI_en.xsl-xml -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXOPMCONFGCOLU " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGCOLU.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXOPMCONFGCOLU.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FORMS- XXOPMCONFGILIN " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/au/12.0.0/forms/US/XXOPMCONFGILIN.fmb  $AU_TOP/forms/US
CPFROM=$XBOL_TOP/forms/US/XXOPMCONFGILIN.fmx
CPFROM=${CPFROM/$PATCH_BASE/$RUN_BASE}
cp $CPFROM $XBOL_TOP/forms/US/

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2283" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2283_13787.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2283_13787.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
