  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_FCE_UTILS_PKG" AS

FUNCTION check_apply  (p_customer_id IN NUMBER
                      ,p_trx_date    IN DATE
                      ,p_amount      IN NUMBER) RETURN NUMBER;

PROCEDURE update_batch (retcode  OUT NUMBER
                       ,errbuf   OUT VARCHAR2);

PROCEDURE main_process (retcode OUT NUMBER
                       ,errbuf OUT VARCHAR2);

END;

/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_FCE_UTILS_PKG" AS


FUNCTION check_apply  (p_customer_id IN NUMBER
                      ,p_trx_date    IN DATE
                      ,p_amount      IN NUMBER) RETURN NUMBER IS

v_activity VARCHAR2(150);
v_error_message VARCHAR2(150);
v_update NUMBER;
v_exists NUMBER;
v_cuit VARCHAR2(15);

BEGIN


    /*Obtengo la Actividad del cliente*/
    BEGIN

        SELECT hp_dfv.xx_ap_clae_code,hp.jgzz_fiscal_code||hca.global_attribute12
          INTO v_activity,v_cuit
          FROM hz_cust_accounts hca
              ,hz_parties hp
              ,hz_parties_dfv hp_dfv
         WHERE hp.party_id = hca.party_id
           and hp.rowid = hp_dfv.row_id
           and hca.cust_account_id = p_customer_id;

    EXCEPTION
       WHEN OTHERS THEN
         RETURN (0);
    END;

    /*Valido que la combinacion exista en el padron, por si cargan alguna actividad manualmente*/
    BEGIN

        SELECT 1
          INTO v_exists
          FROM xx_ar_padron_fce
         WHERE cuit = v_cuit
           AND status = 'P' --que ese registro se haya procesado
           AND activity_code = v_activity;

    EXCEPTION
     WHEN OTHERS THEN
       RETURN (0);
    END;

    BEGIN

      SELECT 1
        INTO v_update
        FROM xx_ar_fce_actividades
       WHERE activity_code = v_activity
         AND amount <= p_amount
         AND start_date <= TRUNC(p_trx_date)
         AND NVL(end_date,TRUNC(SYSDATE)) >= TRUNC(p_trx_date);

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       v_update := 0;
       v_error_message := 'No se encontro un cronograma de actividades en tabla XX_AR_FCE_ACTIVIDADES.';
       fnd_file.put_line(fnd_file.log,v_error_message);
     WHEN TOO_MANY_ROWS THEN
       v_update := 0;
       v_error_message := 'Se encontro mas de un cronograma de actividades en tabla XX_AR_FCE_ACTIVIDADES.';
       fnd_file.put_line(fnd_file.log,v_error_message);
     WHEN OTHERS THEN
       v_update := 0;
       v_error_message := 'Error al verificar cronograma de actividades en tabla XX_AR_FCE_ACTIVIDADES. Error: '||SQLERRM;
       fnd_file.put_line(fnd_file.log,v_error_message);
   END;

    RETURN (v_update);
EXCEPTION
  WHEN OTHERS THEN
    RETURN (0);
END;

PROCEDURE update_batch (retcode  OUT NUMBER
                       ,errbuf   OUT VARCHAR2) IS

CURSOR c_order IS
select rila.interface_line_attribute1
      ,rila.interface_line_attribute2
      /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
      ,rila.interface_line_attribute4
      /*Fin Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
      ,orig_system_bill_customer_id
      ,currency_code
      ,batch_source_name
      ,rbs2.name xx_ar_fce_source
      ,rila.org_id
      ,haou.name orG_name
      ,rila.trx_date
      ,hp_dfv.xx_ap_clae_code
      ,count(1) cant_lineas
  from ra_interface_lines_all rila
      ,hr_all_organization_units haou
      ,hr_locations_all hl
      ,hr_locations_all1_dfv hl_dfv
      ,ra_batch_sources_all rbs
      ,ra_batch_sources_all_dfv rbs_dfv
      ,ra_batch_sources_all rbs2
      ,hz_cust_accounts hca
      ,hz_parties hp
      ,hz_parties_dfv hp_dfv
 where NVL(interface_status,'*') != 'P'
   and rila.org_id = haou.organization_id
   and haou.location_id = hl.location_id
   and hp.rowid = hp_dfv.row_id
   and hca.party_id = hp.party_id
   AND hca.cust_account_id = rila.orig_system_bill_customer_id
   and hl.rowid = hl_dfv.row_id
   and rbs.name = rila.batch_source_name
   and rbs.org_id = rila.org_id
   and rbs.rowid = rbs_dfv.row_id
   and rbs_dfv.xx_ar_fce_source is not null
   and rbs_dfv.xx_ar_fce_source = rbs2.batch_source_id
   and hl_dfv.xx_ar_fce_opcional_2101 is not null
group by rila.interface_line_attribute1
        ,rila.interface_line_attribute2
        /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
        ,rila.interface_line_attribute4
        /*Fin Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
        ,orig_system_bill_customer_id
        ,currency_code
        ,batch_source_name
        ,rbs2.name
        ,rila.org_id
        ,rila.trx_date
        ,haou.name
        ,hp_dfv.xx_ap_clae_code;

CURSOR c_lines (p_int_line_attr1      VARCHAR2
               ,p_int_line_attr2      VARCHAR2
               /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
               ,p_int_line_attr4      VARCHAR2
               /*FIn Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
               ,p_bill_to_customer_id NUMBER
               ,p_currency_code       VARCHAR
               ,p_org_id              NUMBER) IS
  select rila.*
    from ra_interface_lines_all rila
   where NVL(interface_status,'*') != 'P'
     and rila.interface_line_attribute1 = p_int_line_attr1
     and rila.interface_line_attribute2 = p_int_line_attr2
     /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
     and rila.interface_line_attribute4 = p_int_line_attr4
     /*Fin Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
     and orig_system_bill_customer_id   = p_bill_to_customer_id
     and currency_code                  = p_currency_code
     and org_id                         = p_org_id;

v_activity VARCHAR2(30);
v_amount   NUMBER;
v_qty      NUMBER;

v_qty_to_upd NUMBER;

v_update         NUMBER;
v_error_message  VARCHAR2(2000);
e_cust_exception EXCEPTION;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_BATCH (+)');


    FOR r_order IN c_order LOOP

        fnd_file.put_line(fnd_file.log,'Organizacion: '||r_order.org_name);
        fnd_file.put_line(fnd_file.log,'Origen: '||r_order.batch_source_name);
        fnd_file.put_line(fnd_file.log,'Pedido: '||r_order.interface_line_attribute1);
        fnd_file.put_line(fnd_file.log,'Tipo Pedido: '||r_order.interface_line_attribute2);
        fnd_file.put_line(fnd_file.log,'Nuevo Origen: '||r_order.xx_ar_fce_source);
        fnd_file.put_line(fnd_file.log,'Cantidad Lineas: '||r_order.cant_lineas);
        fnd_file.put_line(fnd_file.log,'Actividad: '||r_order.xx_ap_clae_code);

        fnd_file.put_line(fnd_file.output,'');
        fnd_file.put_line(fnd_file.output,'---------------------------------');
        fnd_file.put_line(fnd_file.output,'Organizacion: '||r_order.org_name);
        fnd_file.put_line(fnd_file.output,'Origen: '||r_order.batch_source_name);
        fnd_file.put_line(fnd_file.output,'Pedido: '||r_order.interface_line_attribute1);
        fnd_file.put_line(fnd_file.output,'Tipo Pedido: '||r_order.interface_line_attribute2);
        fnd_file.put_line(fnd_file.output,'Cantidad Lineas: '||r_order.cant_lineas);
        fnd_file.put_line(fnd_file.output,'Actividad: '||r_order.xx_ap_clae_code);


        BEGIN

            SELECT SUM(total)
            INTO v_amount
              FROM (SELECT CASE
                           WHEN oola.ordered_quantity = rila.quantity_ordered THEN oola.tax_value + (rila.quantity_ordered * rila.unit_selling_price)
                           ELSE (tax_value/oola.ordered_quantity) * rila.quantity_ordered + (rila.quantity_ordered * rila.unit_selling_price) END total
                           FROM ra_interface_lines_all rila
                               ,oe_ordeR_lines_all oola
                          WHERE NVL(interface_status,'*') != 'P'
                            AND rila.interface_line_attribute1 = r_order.interface_line_attribute1
                            AND rila.interface_line_attribute2 = r_order.interface_line_attribute2
                            /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
                            AND rila.interface_line_attribute4 = r_order.interface_line_attribute4
                            /*Fin Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
                            AND orig_system_bill_customer_id   = r_order.orig_system_bill_customer_id
                            AND currency_code                  = r_order.currency_code
                            AND rila.org_id                    = r_order.org_id
                            AND oola.line_id = TO_NUMBER(rila.interface_line_attribute6)
                            AND TO_NUMBER(rila.interface_line_attribute11) = 0);
        EXCEPTION
          WHEN OTHERS THEN
           v_amount := 0;
        END;

        fnd_file.put_line(fnd_file.log,'Monto articulos  + Impuestos: '||v_amount);
        fnd_file.put_line(fnd_file.output,'Monto Total: '||v_amount);

        IF r_order.xx_ap_clae_code is not null and v_amount != 0 THEN --Requisitos minimos

           v_update := check_apply(r_order.orig_system_bill_customer_id,r_order.trx_date,v_amount);


           v_qty_to_upd := 0;
           FOR r_lines in c_lines (r_order.interface_line_attribute1
                                  ,r_order.interface_line_attribute2
                                  /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
                                  ,r_order.interface_line_attribute4
                                  /*Fin Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
                                  ,r_order.orig_system_bill_customer_id
                                  ,r_order.currency_code
                                  ,r_order.org_id) LOOP
              v_qty_to_upd := v_qty_to_upd + 1; 
           END LOOP;

           /*Si actualiza, debo buscar el origen asociado*/
           IF v_update = 1 THEN

                update ra_interface_lines_all
                   set batch_source_name = r_order.xx_ar_fce_source
                 where interface_line_attribute1 = r_order.interface_line_attribute1
                   and interface_line_attribute2 = r_order.interface_line_attribute2
                   /*Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
                   and interface_line_attribute4 = r_order.interface_line_attribute4 --Se Modifico la regla de agrupacion
                   /*Fin Agregado Khronus E.SLy 20200415 Se agrego attribute4 en regla de agrupacion DEFAULT ARGENTINA*/
                   AND orig_system_bill_customer_id   = r_order.orig_system_bill_customer_id
                   AND currency_code                  = r_order.currency_code
                   AND org_id                         = r_order.org_id
                   AND batch_source_name = r_order.batch_source_name;

                   v_qty := SQL%ROWCOUNT;

                   /*IF v_qty = r_order.cant_lineas THEN*/
                   IF v_qty = v_qty_to_upd THEN
                    COMMIT;
                    fnd_file.put_line(fnd_file.log,'Lineas Actualizadas OK. COMMIT. Actualizadas: '||v_qty||'. A actualizar: '||r_order.cant_lineas);
                    fnd_file.put_line(fnd_file.log,'Estado: Actualizado con Origen: '||r_order.xx_ar_fce_source);
                   ELSE
                    ROLLBACK;
                    errbuf := 'No se actualizaron todas las lineas. ROLLBACK. Actualizadas: '||v_qty||'. A actualizar: '||r_order.cant_lineas;
                    fnd_file.put_line(fnd_file.log,errbuf);
                    retcode := 1;
                   END IF;
           END IF;

        END IF;

        fnd_file.put_line(fnd_file.output,'---------------------------------');

    END LOOP;

    IF retcode  IS NOT NULL THEN
      raise e_cust_exception;
    END IF;

    fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_BATCH (-)');

EXCEPTION
 WHEN e_cust_exception THEN
   retcode := '1';
   fnd_file.put_line(fnd_file.log,errbuf);
   IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
      FND_FILE.PUT_LINE (fnd_file.log,'Error Seteando Estado De Finalizacion');
   ELSE
      FND_FILE.PUT_LINE (fnd_file.log,'Estado de finalizacion seteado');
   END IF;
   fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_BATCH (!)');
 WHEN OTHERS THEN
   retcode := '2';
   errbuf := 'Error OTHERS en UPDATE_BATCH. Error: '||SQLERRM;
   fnd_file.put_line(fnd_file.log,errbuf);
   fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_BATCH (!)');
   RAISE_APPLICATION_ERROR(-20001,errbuf);
END;

PROCEDURE update_customers (p_status        OUT VARCHAR2
                           ,p_error_message OUT VARCHAR2) IS

CURSOR c_cus IS
SELECT *
FROM xx_ar_padron_fce
where status = 'N';

v_party_id   HZ_PARTIES.PARTY_ID%TYPE;
v_party_name HZ_PARTIES.PARTY_NAME%TYPE;

BEGIN

    fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_CUSTOMERS (+)');


    FOR r_cus in c_cus LOOP

        BEGIN

            SELECT hp.party_id,hp.party_name
              INTO v_party_id,v_party_name
              FROM hz_cust_accounts hca
                  ,hz_parties hp
             WHERE hca.party_id = hp.party_id
               AND hp.jgzz_fiscal_code||hca.global_attribute12 = r_cus.cuit;

        EXCEPTION
         WHEN OTHERS THEN
            v_party_id := 0;
        END;

        IF v_party_id != 0 THEN

            UPDATE hz_parties
               SET attribute4 = LPAD(r_cus.activity_code,6,'0')
                  ,attribute_category ='AR'
                  ,last_update_date = SYSDATE
                  ,last_updated_by = fnd_global.user_id
             WHERE party_id = v_party_id;

            IF SQL%ROWCOUNT = 1 THEN

                UPDATE xx_ar_padron_fce
                   SET status = 'P'
                   where cuit = r_cus.cuit
                   and status = 'N';

                fnd_file.put_line(fnd_file.output,'CUIT: '||LPAD(r_cus.cuit,11,'0')||'  Cliente: '||RPAD(v_party_name,30,' ')||' Actualizado con Actividad: '||LPAD(r_cus.activity_code,6,'0'));
            ELSE

                UPDATE xx_ar_padron_fce
                   SET status = 'E'
                   ,error_message = 'Error al actualizar la actividad del cliente'
                   where cuit = r_cus.cuit
                   and status = 'N';
            END IF;

        ELSE

            UPDATE xx_ar_padron_fce
               SET status = 'P'
                  ,error_message = 'No existe el cliente en Oracle'
             where cuit = r_cus.cuit
               and status = 'N';

        END IF;

    END LOOP;

    fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_CUSTOMERS (-)');

EXCEPTION
 WHEN OTHERS THEN
   p_status := 'W';
   p_error_message := 'Error OTHERS en UPDATE_CUSTOMERS. Error: '||SQLERRM;
   fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.UPDATE_CUSTOMERS (!)');
END;

PROCEDURE main_process (retcode OUT NUMBER
                       ,errbuf OUT VARCHAR2) IS

v_status        VARCHAR2(1);
v_error_message VARCHAR2(2000);

e_cust_exception EXCEPTION;

BEGIN

      fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.MAIN_PROCESS (+)');

      update_customers(p_status => v_status
                      ,p_error_message => v_error_message);

      IF v_status != 'S' THEN
        RAISE e_cust_exception;
      END IF;

      fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.MAIN_PROCESS (-)');

EXCEPTION
   WHEN e_cust_exception THEN
       retcode := 1;
       errbuf := v_error_message;
       fnd_file.put_line(fnd_file.log,errbuf);
       fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.MAIN_PROCESS (!)');
   WHEN OTHERS THEN
       retcode := 2;
       errbuf := 'Error OTHERS en MAIN_PROCESS. Error: '||SQLERRM;
       fnd_file.put_line(fnd_file.log,errbuf);
       fnd_file.put_line(fnd_file.log,'XX_AR_FCE_UTILS_PKG.MAIN_PROCESS (!)');
END;

END; 
/

exit
