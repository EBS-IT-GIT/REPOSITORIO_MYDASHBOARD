create or replace TRIGGER TRG_TURNOS_TESTES_INSPECOES
  --
  AFTER INSERT OR DELETE OR UPDATE
  ON SAU.TURNOS REFERENCING OLD AS OLD NEW AS NEW
  FOR EACH ROW
  --
  /*
  Procedimento existente para criação das inspeções padrões que deverão ser
  realizadas na Data e Turno do livro aberto, assim como a exclusão  das inspeções
  caso o livro seja excluído.
  */

  /*
  [13:55:18] Carolina do E. Santo: Quando um novo turno é gerado o programa identificará inicialmente quais são as pendências existentes englobadas pelo prazo setado no setup, depois passa um novo filtro nessas pendências, a saber:
  - Identificar se há no turno aberto inspeções obrigatórias (dentre as parametrizadas) que sejam iguais (código e nome) àquelas que estão na lista de pendências.
  - Quando forem identificadas estas coincidências, a inspeção pendente terá seu status automaticamente alterado para "não realizada", e assim não será mais elegível a aparecer na lista de inspeções pendentes.
  [13:56:35] Carolina do E. Santo: desta forma, respondendo a segunda parte da pergunta...:
  [13:57:32] Carolina do E. Santo: quando for solucionada uma inspeção do turno em questão, somente ela será dada como realizada naquele momento
  [13:58:35] Ana Karina Pereira: a inspeção de mesmo nome do turno anterior que tinha ficado pendente, deixa de ficar com o status de pendente e passa a ficar como não realizada. Indiferente se no turno atual a mesma inspeção é realizada ou deixada pendente
  [13:58:37] Ana Karina Pereira: é isso?
  [13:59:54] Carolina do E. Santo: isso!
  --> O texto acima explica o update das inspeções pendentes do turno imediatamente anterior
  que são iguais as inspeções do novo turno.
  As inspeções pendentes do turno anterior que são iguais as inpeções obrigatórias do turno atual
  ficam como realizado = 'N' e pendente = 'N'.
  */
  --
DECLARE
  --
  cursor c_dados is
  /*select *
    from sau.tipos_testes
  where location = :new.cd_usina
    and fl_ativo = 'S'
    and nvl(cd_turno,:new.cd_turno) = :new.cd_turno
    and (decode(id_domingo,'S',1,0) = to_char(:new.data,'D')
      or decode(id_segunda,'S',2,0) = to_char(:new.data,'D')
      or decode(id_terca  ,'S',3,0) = to_char(:new.data,'D')
      or decode(id_quarta ,'S',4,0) = to_char(:new.data,'D')
      or decode(id_quinta ,'S',5,0) = to_char(:new.data,'D')
      or decode(id_sexta  ,'S',6,0) = to_char(:new.data,'D')
      or decode(id_sabado ,'S',7,0) = to_char(:new.data,'D'));*/
  
  select *
    from sau.tipos_testes
  where location = :new.cd_usina
    and fl_ativo = 'S'
    and nvl(cd_turno,:new.cd_turno) = :new.cd_turno
    and 
    ((FREQUENCIA IN ('SEMANA') 
      AND (decode(id_domingo,'S',1,0) = to_char(:new.data,'D')
      or decode(id_segunda,'S',2,0) = to_char(:new.data,'D')
      or decode(id_terca  ,'S',3,0) = to_char(:new.data,'D')
      or decode(id_quarta ,'S',4,0) = to_char(:new.data,'D')
      or decode(id_quinta ,'S',5,0) = to_char(:new.data,'D')
      or decode(id_sexta  ,'S',6,0) = to_char(:new.data,'D')
      or decode(id_sabado ,'S',7,0) = to_char(:new.data,'D'))
    )  
    OR
     (FREQUENCIA = 'MENSAL' 
        AND (SAU.F_DIA_MES(DECODE(ID_DOMINGO,'S',1,1),0,'M',:new.data) = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEGUNDA,'S',2,1),0,'M',:new.data) = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_TERCA,'S',3,1),0,'M',:new.data)   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUARTA,'S',4,1),0,'M',:new.data)  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUINTA,'S',5,1),0,'M',:new.data)  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEXTA,'S',6,1),0,'M',:new.data)   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SABADO,'S',7,1),0,'M',:new.data)  = :new.data)
     )
    OR
     (FREQUENCIA = 'TRIMES' 
        AND (SAU.F_DIA_MES(DECODE(ID_DOMINGO,'S',1,1),0,'T',:new.data) = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEGUNDA,'S',2,1),0,'T',:new.data) = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_TERCA,'S',3,1),0,'T',:new.data)   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUARTA,'S',4,1),0,'T',:new.data)  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUINTA,'S',5,1),0,'T',:new.data)  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEXTA,'S',6,1),0,'T',:new.data)   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SABADO,'S',7,1),0,'T',:new.data)  = :new.data)
     )
     OR
     (FREQUENCIA = 'SEMEST' 
        AND (SAU.F_DIA_MES(DECODE(ID_DOMINGO,'S',1,1),0,'S') = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEGUNDA,'S',2,1),0,'S') = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_TERCA,'S',3,1),0,'S')   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUARTA,'S',4,1),0,'S')  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUINTA,'S',5,1),0,'S')  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEXTA,'S',6,1),0,'S')   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SABADO,'S',7,1),0,'S')  = :new.data)
     )
     OR
     (FREQUENCIA = 'ANUAL' 
        AND (SAU.F_DIA_MES(DECODE(ID_DOMINGO,'S',1,1),0,'A') = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEGUNDA,'S',2,1),0,'A') = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_TERCA,'S',3,1),0,'A')   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUARTA,'S',4,1),0,'A')  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_QUINTA,'S',5,1),0,'A')  = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SEXTA,'S',6,1),0,'A')   = :new.data
          OR SAU.F_DIA_MES(DECODE(ID_SABADO,'S',7,1),0,'A')  = :new.data)
     ));
      
  --
  wc_user_create     varchar2(30);
  wc_user_update     varchar2(30);
  --
  v_qtd_dias         item_dominio.id_item_dominio%type;
  --
BEGIN
  --
   
  
  -- ANA KARINA - BUSCA SETUP DE DIAS PENDENTES
  begin
    select id_item_dominio
      into v_qtd_dias
      from sau.item_dominio
     where id_dominio = 'PRAZO_INSPECAO_TESTE_PENDENTE'
       and rownum     = 1;
  exception
    when no_data_found then
      v_qtd_dias := 0;
    when others then
      dbms_output.put_line('Erro ao buscar Dias Pendentes. Erro: '||sqlerrm);
  end;
  --
  if inserting then
    --
    wc_user_create := :new.user_create;
    wc_user_update := :new.user_update;
    --
    for r_dados in c_dados loop
      --
      begin
        insert into sau.testes_inspecoes_padrao
          (cd_usina,
           data,
           cd_turno,
           cd_grupo,
           cd_tipo_teste,
           fl_realizado_prazo,
           fl_realizado,
           fl_pendente,
           fl_desconsidera_pend,
           data_realizado,
           cd_turno_realizado,
           cd_grupo_realizado,
           user_create,
           date_create,
           user_update,
           date_update,
           prazo_inspecao_pend)
        values
          (:new.cd_usina,
           :new.data,
           :new.cd_turno,
           :new.cd_grupo,
           r_dados.cd_tipo_teste,
           'N', --fl_realizado_prazo
           'N', --fl_realizado
           'N', --fl_pendente
           'N', -- fl_desconsidera_pend
           null,--data_realizado
           null,--cd_turno_realizado
           null,--cd_grupo_realizado
           nvl(wc_user_create,user),
           to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss'),
           nvl(wc_user_update,user),
           to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss'),
           v_qtd_dias);
      exception
        when others then
          dbms_output.put_line('erro ao inserir testes_inspecoes_padrao. erro: '||sqlerrm);
      end;
      
      dbms_output.put_line('inserido: '||r_dados.cd_tipo_teste );
      
      --
    end loop;
    --
    -- AS INSPEÇÕES PENDENTES QUE SÃO IGUAIS AS INSPEÇÕES DO TURNO E GRUPO ATUAL, FICAM COMO NÃO REALIZADO APENAS E SUA PENDENCIA OU FL_PENDENCIA = S NÃO DEVE SER CONSIDERADO EM TELA E RELATÓRIO
    begin
      update sau.testes_inspecoes_padrao tip
         set tip.FL_DESCONSIDERA_PEND = 'S',
             tip.DT_DESCONSIDERA_PEND = to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss'),
             user_update        = 'TRG_TURNOS_TESTES_INSPECOES',
             date_update        = to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss')
       where tip.cd_usina              = :new.cd_usina
         and (trunc(tip.data) >= trunc(:new.data - tip.prazo_inspecao_pend /*v_qtd_dias*/) and trunc(tip.data) <= trunc(:new.data)
           and to_date(tip.date_create,'dd/mm/yyyy hh24:mi:ss') < to_date(:new.date_create,'dd/mm/yyyy hh24:mi:ss'))
         and tip.fl_realizado  = 'N' -- NÃO REALIZADO
         and tip.fl_pendente   = 'S' -- PENDENTE
         and nvl(tip.FL_DESCONSIDERA_PEND,'N') = 'N'
         -- RETIRAR DA LISTA DE RETORNO AS INSPEÇÕES DO TURNO E GRUPO ATUAL
         /*and tip.cd_turno      <> :new.cd_turno
         and tip.cd_grupo      <> :new.cd_grupo*/
         --
         -- BUSCA AS INSPEÇÕES PENDENTES QUE SEJA IGUAL A INSPEÇÃO DO TURNO ATUAL, VERIFICAR SE TEM QUE CONSIDERAR O GRUPO JUNTO
         and exists (select 1
                      from sau.testes_inspecoes_padrao ti
                     where ti.cd_usina      = :new.cd_usina
                       and trunc(ti.data)   = trunc(:new.data)
                       and ti.cd_turno      = :new.cd_turno
                       and ti.cd_grupo      = :new.cd_grupo
                       and ti.cd_tipo_teste = tip.cd_tipo_teste
                       );
     exception
       when others then
         dbms_output.put_line('Erro ao alterar os registros de testes_inspecoes_padrao para DESCONSIDERAR PENDENTE. Erro: '||sqlerrm);
     end;
    --
  elsif deleting then
    --
    -- AS INSPEÇÕES PENDENTES QUE SÃO IGUAIS AS INSPEÇÕES DO TURNO E GRUPO ATUAL, FICAM COMO NÃO REALIZADO APENAS E SUA PENDENCIA OU FL_PENDENCIA = S NÃO DEVE SER CONSIDERADO EM TELA E RELATÓRIO
    -- AO DELETAR OS REGISTROS DE UM TURNO ATUAL, OS REGISTROS PENDENTES DOS TURNOS ANTERIORES DEVEM SER CONSIDERADOS
    begin
      update sau.testes_inspecoes_padrao tip
         set tip.FL_DESCONSIDERA_PEND = 'N',
             tip.DT_DESCONSIDERA_PEND = NULL,
             user_update        = 'TRG_TURNOS_TESTES_INSPECOES',
             date_update        = to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss')
       where tip.cd_usina              = :old.cd_usina
         and (trunc(tip.data) >= trunc(:old.data - tip.prazo_inspecao_pend/*v_qtd_dias*/) and trunc(tip.data) <= trunc(:old.data)
           and to_date(tip.date_create,'dd/mm/yyyy hh24:mi:ss') < to_date(:old.date_create,'dd/mm/yyyy hh24:mi:ss'))
         and tip.fl_realizado  = 'N' -- NÃO REALIZADO
         and tip.fl_pendente   = 'S' -- PENDENTE
         and nvl(tip.FL_DESCONSIDERA_PEND,'N') = 'S'
         -- RETIRAR DA LISTA DE RETORNO AS INSPEÇÕES DO TURNO E GRUPO ATUAL
         /*and tip.cd_turno      <> :old.cd_turno
         and tip.cd_grupo      <> :old.cd_grupo*/
         --
         -- BUSCA AS INSPEÇÕES PENDENTES QUE SEJA IGUAL A INSPEÇÃO DO TURNO ATUAL, VERIFICAR SE TEM QUE CONSIDERAR O GRUPO JUNTO
         and exists (select 1
                      from sau.testes_inspecoes_padrao ti
                     where ti.cd_usina      = :old.cd_usina
                       and trunc(ti.data)   = trunc(:old.data)
                       and ti.cd_turno      = :old.cd_turno
                       and ti.cd_grupo      = :old.cd_grupo
                       and ti.cd_tipo_teste = tip.cd_tipo_teste
                       );
     exception
       when others then
         dbms_output.put_line('Erro ao alterar os registros de testes_inspecoes_padrao para CONSIDERAR PENDENTES. Erro: '||sqlerrm);
     end;

     begin
      delete sau.testes_inspecoes_padrao
       where cd_usina = :old.cd_usina
         and data     = :old.data
         and cd_turno = :old.cd_turno;
     exception
       when others then
         dbms_output.put_line('Erro ao deletar os registros de testes_inspecoes_padrao. Erro: '||sqlerrm);
     end;
    --
  elsif updating then   -- se o cd_grupo for alterado, altera o grupo das inspeções obrigatórias e tbm das inpeções pendentes e realizadas com atraso por este mesmo turno e grupo
    if :old.cd_grupo <> :new.cd_grupo then
      begin
        update sau.testes_inspecoes_padrao ti
           set ti.cd_grupo      = :new.cd_grupo,
               user_update      = 'TRG_TURNOS_TESTES_INSPECOES'
               --date_update      = to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss') NÃO PODE MODIFICAR O DATE UPDATE SENÃO A TELA SAU6680 SE PERDE
         where ti.cd_usina      = :old.cd_usina
           and trunc(ti.data)   = trunc(:old.data)
           and ti.cd_turno      = :old.cd_turno
           and ti.cd_grupo      = :old.cd_grupo;
        exception
          when others then
            dbms_output.put_line('Erro ao alterar cd_grupo na tabela testes_inspecoes_padrao. Erro: '||sqlerrm);
      end;
      --
      begin
        update sau.testes_inspecoes_padrao ti
           set ti.cd_grupo_realizado = :new.cd_grupo,
               user_update           = 'TRG_TURNOS_TESTES_INSPECOES'
               --date_update           = to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss') NÃO PODE MODIFICAR O DATE UPDATE SENÃO A TELA SAU6680 SE PERDE
         where ti.cd_usina              = :old.cd_usina
           and trunc(ti.data_realizado) = trunc(:old.data)
           and ti.cd_turno_realizado    = :old.cd_turno
           and ti.cd_grupo_realizado    = :old.cd_grupo;
        exception
          when others then
            dbms_output.put_line('Erro ao alterar cd_grupo_realizado na tabela testes_inspecoes_padrao. Erro: '||sqlerrm);
      end;
      --
      begin
        update sau.testes_inspecoes t
           set t.cd_grupo_origem_pend = :new.cd_grupo,
               t.user_update           = 'TRG_TURNOS_TESTES_INSPECOES'
               --t.date_update           = to_char(sysdate, 'dd/mm/yyyy hh24:mi:ss') NÃO PODE MODIFICAR O DATE UPDATE SENÃO A TELA SAU6680 SE PERDE
         where t.cd_usina              = :old.cd_usina
           and t.data_origem_pend = trunc(:old.data)
           and t.cd_turno_origem_pend  = :old.cd_turno
           and t.cd_grupo_origem_pend  = :old.cd_grupo;

      exception
          when others then
            dbms_output.put_line('Erro ao alterar cd_grupo_origem_pend na tabela testes_inspecoes. Erro: '||sqlerrm);
      end;

    end if;
  end if;
  --
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;