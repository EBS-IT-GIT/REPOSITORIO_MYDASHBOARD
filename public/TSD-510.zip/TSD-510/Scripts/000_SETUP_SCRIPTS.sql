﻿/***
# Observações
1) Onde ($SAU_HOME) é a (Variável de Ambiente) no (Linux) que aponta para o Endereço da (Pasta Raiz) da Aplicação (SAU).
--
@"&DIRETORIO\000_SCRIPT_MESTRE.sql"
***/
cl scr
Set PageSize 9999
Set LineSize 0321
DEFINE DIRETORIO='$SAU_HOME_Entrega\Scripts'
PROMPT DIRETORIO [&DIRETORIO]
Select Banner                                            as "Instalação"
   From v$version;
Select     To_Char(SysDate,'dd-mm-yyyy hh24:mi:ss')      as "Data_Horário"
   ,       USER                                          as "Usuário"
   ,       INSTANCE_NAME                                 as "Instância"
   ,       HOST_NAME                                     as "Hospedagem(Host)"
   From V$INSTANCE;
Select To_Char(SysDate,'dd-mm-yyyy hh24:mi:ss') as "Data e Horário"
   From Dual;
