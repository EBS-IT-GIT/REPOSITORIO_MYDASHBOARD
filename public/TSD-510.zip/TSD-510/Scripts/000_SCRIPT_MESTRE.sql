@"&DIRETORIO\000_SETUP_SCRIPTS.sql"
--
SPOOL "&DIRETORIO\tsd510.log";


PROMPT F_DIA_MES.sql
@&DIRETORIO\F_DIA_MES.sql;
PROMPT FIM F_DIA_MES.sql

PROMPT TRG_TURNOS_TESTES_INSPECOES.sql
@&DIRETORIO\TRG_TURNOS_TESTES_INSPECOES.sql;
PROMPT FIM TRG_TURNOS_TESTES_INSPECOES.sql



PROMPT Processo Finalizado! Favor verificar no arquivo de log tsd510 se O script foi executado com sucesso...
SPOOL OFF;


