create or replace FUNCTION F_DIA_MES(PDIA_SEMANA NUMBER,PQTD_MESES NUMBER,PTIPO CHAR,PDATA DATE := SYSDATE) RETURN DATE AS 
   DT_RETORNO DATE; 
BEGIN
  IF PDIA_SEMANA = 0 THEN
     RETURN NULL;
  END IF;   
  
  IF PTIPO = 'M' THEN   --mensal
     BEGIN
        SELECT TRUNC(PDIA)
        INTO   DT_RETORNO
        FROM   (SELECT TRUNC(ADD_MONTHS(PDATA,PQTD_MESES), 'MM') + B.INC PDIA
                FROM   DUAL A,(
                                SELECT LEVEL-1 INC
                                FROM   DUAL
                                CONNECT BY LEVEL <= 7
                               ) B
               )
        WHERE  TO_CHAR(PDIA, 'D') = PDIA_SEMANA;
     EXCEPTION     
         WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,'Erro ao retornar primeiro dia do mes. '||sqlerrm);
     END;
  ELSIF PTIPO = 'T' THEN   --trimestral
     BEGIN
        SELECT TRUNC(PDIA)
        INTO   DT_RETORNO
        FROM   (SELECT TRUNC(ADD_MONTHS(PDATA,PQTD_MESES), 'Q') + B.INC PDIA
                FROM   DUAL A,(
                                SELECT LEVEL-1 INC
                                FROM   DUAL
                                CONNECT BY LEVEL <= 7
                               ) B
               )
        WHERE  TO_CHAR(PDIA, 'D') = PDIA_SEMANA
        and rownum =1; 
     EXCEPTION     
         WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,'Erro ao retornar primeiro dia do trimestre. '||sqlerrm);
     END;
  ELSIF PTIPO = 'S' THEN   --semestral
     BEGIN
        SELECT TRUNC(PDIA)
        INTO   DT_RETORNO
        FROM   (SELECT (CASE 
                         WHEN  CEIL(EXTRACT(MONTH FROM SYSDATE)/6) = 1 THEN  
                               TO_DATE('01/01/'||TO_CHAR(SYSDATE,'YYYY'),'DD/MM/YYYY')
                         WHEN  CEIL(EXTRACT(MONTH FROM SYSDATE)/6) = 2 THEN  
                               TO_DATE('01/07/'||TO_CHAR(SYSDATE,'YYYY'),'DD/MM/YYYY')
                         END) + B.INC PDIA
                FROM   DUAL A,(
                                SELECT LEVEL-1 INC
                                FROM   DUAL
                                CONNECT BY LEVEL <= 7
                               ) B
               )
        WHERE  TO_CHAR(PDIA, 'D') = PDIA_SEMANA
        and rownum =1; 
     EXCEPTION     
         WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,'Erro ao retornar primeiro dia do trimestre. '||sqlerrm);
     END;
  ELSIF PTIPO = 'A' THEN   --anual
     BEGIN
        SELECT TRUNC(PDIA)
        INTO   DT_RETORNO
        FROM   (SELECT TRUNC(ADD_MONTHS(SYSDATE,PQTD_MESES), 'Y') + B.INC PDIA
                FROM   DUAL A,(
                                SELECT LEVEL-1 INC
                                FROM   DUAL
                                CONNECT BY LEVEL <= 7
                               ) B
               )
        WHERE  TO_CHAR(PDIA, 'D') = PDIA_SEMANA
        and rownum =1; 
     EXCEPTION     
         WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001,'Erro ao retornar primeiro dia do trimestre. '||sqlerrm);
     END;
  END IF;  
  RETURN DT_RETORNO;
END;