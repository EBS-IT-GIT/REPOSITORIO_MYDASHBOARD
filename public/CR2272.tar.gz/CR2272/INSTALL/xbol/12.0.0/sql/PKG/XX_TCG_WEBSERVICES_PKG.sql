  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_TCG_WEBSERVICES_PKG" AUTHID CURRENT_USER AS


  C_PACKAGE_NAME  CONSTANT VARCHAR(240) := 'XX_TCG_WEBSERVICES_PKG';

  TYPE p_taxes_liq_rec_tab IS TABLE OF XX_TCG_LIQUIDACION_RETENCIONES%ROWTYPE INDEX BY BINARY_INTEGER;

/*****************************************************************************
 *                                                                           *
 * Name    : Get_Punto_Emision                                               *
 * Purpose : Procedimiento que devuelve el valor del Punto de Emision segun  *
 *          la organización a la cual pertence la liquidación                *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Get_Punto_Emision ( p_liquidacion_id     IN NUMBER
                              , p_tipo_liquidacion   IN VARCHAR2
                              , p_punto_emision     OUT VARCHAR2
                              , p_result            OUT BOOLEAN
                              , p_error_msg         OUT VARCHAR2);




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Nro_Orden_LPG                                               *
 * Purpose : Procedimiento que devuelve el valor del Nro de Orden segun      *
 *          la organización a la cual pertence la liquidación                *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Get_Nro_Orden_LPG ( p_liquidacion_id   IN NUMBER
                              , p_actualizar       IN BOOLEAN
                              , p_numero_orden    OUT NUMBER
                              , p_result          OUT BOOLEAN
                              , p_error_msg       OUT VARCHAR2);




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Nro_Orden_CGRT                                              *
 * Purpose : Procedimiento que devuelve el valor del Nro de Orden segun      *
 *          la organización a la cual pertence la liquidación                *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Get_Nro_Orden_CGRT ( p_liquidacion_id   IN NUMBER
                               , p_tipo_liquidacion IN VARCHAR2
                               , p_actualizar       IN BOOLEAN
                               , p_numero_orden    OUT NUMBER
                               , p_result          OUT BOOLEAN
                               , p_error_msg       OUT VARCHAR2);


 /****************************************************************************
 *                                                                           *
 * Name   : Envia_Archivo                                                    *
 * Purpose: Procedimiento encargado de chequear liquidaciones encoladas por  *
 *          punto de emision y generar el archivo a PlanesWare para que se   *
 *          procese en AFIP                                                  *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Envia_archivo ( p_cant_reg   OUT NUMBER
                          , p_err_msg    OUT VARCHAR2
                          );


 /*****************************************************************************
 *                                                                            *
 * Name    :  Lee_Archivo_CGRT                                                *
 * Purpose : Procedimiento encargado de leer los archivos enviados por        *
 *           PlanexWare. En base a lo informado, continua con la finalizacion *
 *           de la liquidacion A/RT, o informa los errores                    *
 *                                                                            *
 ******************************************************************************/
  PROCEDURE Lee_Archivo_CGRT ( p_fname          VARCHAR2
                             , p_err_msg    OUT VARCHAR2
                             );


 /*****************************************************************************
 *                                                                            *
 * Name: Lee_Archivo                                                          *
 * Purpose: Procedimiento encargado de leer los archivos enviados por         *
 *         PlanexWare. En base a lo informado, continua con la finalizacion   *
 *         de la liquidacion de Granos o informa los errores                  *
 *                                                                            *
 ******************************************************************************/
  PROCEDURE Lee_Archivo ( p_fname          VARCHAR2
                        , p_contingencia   VARCHAR2 DEFAULT 'N'
                        , p_err_msg        OUT VARCHAR2 );




  PROCEDURE Buscar_Datos_CTG(p_user_id             IN NUMBER,
                             p_resp_id             IN NUMBER,
                             p_resp_appl_id        IN NUMBER,
                             p_cuit_representado   IN NUMBER,
                             p_tipo_cert           IN VARCHAR2,
                             p_liquidacion         IN VARCHAR2,
                             p_liquidacion_id      IN NUMBER,
                             p_cuit_depositante    IN NUMBER,
                             p_cod_grano           IN NUMBER,
                             p_lote                IN NUMBER,
                             p_numero_cp           IN NUMBER,
                             p_result             OUT BOOLEAN,
                             p_err_msg            OUT VARCHAR2);

END XX_TCG_WEBSERVICES_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_TCG_WEBSERVICES_PKG" AS


/*****************************************************************************
 *                                                                           *
 * Name    : Get_Punto_Emision                                               *
 * Purpose : Procedimiento que devuelve el valor del Punto de Emision segun  *
 *          la organizacion a la cual pertence la liquidacion                *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Get_Punto_Emision ( p_liquidacion_id     IN NUMBER
                              , p_tipo_liquidacion   IN VARCHAR2
                              , p_punto_emision     OUT VARCHAR2
                              , p_result            OUT BOOLEAN
                              , p_error_msg         OUT VARCHAR2)
  IS

    CURSOR c_dff IS
      SELECT msid.xx_tcg_pto_emision_lpg
        FROM XX_TCG_LIQUIDACIONES_1116A     xtla
           , MTL_SECONDARY_INVENTORIES      msi
           , MTL_SECONDARY_INVENTORIES_DFV  msid
       WHERE xtla.liquidacion_id         = p_liquidacion_id
         AND '1116A'                     = p_tipo_liquidacion
         AND xtla.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.xx_tcg_pto_emision_lpg IS NOT NULL
       UNION
      SELECT msid.xx_tcg_pto_emision_lpg
        FROM XX_TCG_LIQUIDACIONES        xtlb
           , MTL_SECONDARY_INVENTORIES   msi
           , MTL_SECONDARY_INVENTORIES_DFV  msid
       WHERE xtlb.liquidacion_id         = p_liquidacion_id
         AND '1116B'                     = p_tipo_liquidacion
         AND xtlb.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.xx_tcg_pto_emision_lpg IS NOT NULL
      UNION
      SELECT msid.xx_tcg_pto_emision_lpg
        FROM XX_TCG_RT  xtlrt
           , MTL_SECONDARY_INVENTORIES   msi
           , MTL_SECONDARY_INVENTORIES_DFV  msid
       WHERE xtlrt.liquidacion_id         = p_liquidacion_id
         AND '1116RT'                     = p_tipo_liquidacion
         AND xtlrt.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.xx_tcg_pto_emision_lpg IS NOT NULL;



    l_no_data_found_flag    BOOLEAN;
    l_organization          VARCHAR2(240);

  BEGIN

    p_result := TRUE;

    OPEN c_dff;
    FETCH c_dff INTO p_punto_emision;
    l_no_data_found_flag := c_dff%NOTFOUND;
    CLOSE c_dff;


    IF (l_no_data_found_flag) THEN

      p_result := FALSE;

      SELECT od.organization_name ||' ('||xl.organization_id||')'
        INTO l_organization
        FROM (SELECT organization_id
                FROM XX_TCG_LIQUIDACIONES_1116A
               WHERE '1116A'        = p_tipo_liquidacion
                 AND liquidacion_id = p_liquidacion_id
               UNION
              SELECT organization_id
                FROM XX_TCG_LIQUIDACIONES
               WHERE '1116B'        = p_tipo_liquidacion
                 AND liquidacion_id = p_liquidacion_id
              UNION
              SELECT organization_id
                FROM XX_TCG_RT
               WHERE '1116RT'       = p_tipo_liquidacion
                 AND liquidacion_id = p_liquidacion_id
               ) xl
            , ORG_ORGANIZATION_DEFINITIONS od
        WHERE xl.organization_id = od.organization_id;

      p_error_msg := 'No se encuentra configurado el Punto de Emision para ningun '||
                     'Subinventario de la Organizacion '||l_organization;
      RETURN;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error al buscar el Punto de Emision para la liquidacion '||p_tipo_liquidacion
                     ||' id: '||p_liquidacion_id||'. Detalle: '||SQLERRM;

  END Get_Punto_Emision;




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Nro_Orden_CGRT                                              *
 * Purpose : Procedimiento que devuelve el valor del Nro de Orden segun      *
 *          la organizacion a la cual pertence la liquidacion                *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Get_Nro_Orden_CGRT ( p_liquidacion_id   IN NUMBER
                               , p_tipo_liquidacion IN VARCHAR2
                               , p_actualizar       IN BOOLEAN
                               , p_numero_orden    OUT NUMBER
                               , p_result          OUT BOOLEAN
                               , p_error_msg       OUT VARCHAR2)
  IS

    CURSOR c_dff IS
      SELECT msid.xx_aco_nro_orden_cgrt
           , msid.secondary_inventory_id
           , msid.xx_tcg_subinventarios
        FROM XX_TCG_LIQUIDACIONES_1116A     xtla
           , MTL_SECONDARY_INVENTORIES      msi
           , MTL_SECONDARY_INVENTORIES_DFV  msid
       WHERE xtla.liquidacion_id         = p_liquidacion_id
         AND '1116A'                     = p_tipo_liquidacion
         AND xtla.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND ((msid.xx_tcg_subinventarios IS NULL
              AND msid.xx_aco_nro_orden_cgrt  IS NOT NULL)
              OR
              (msid.xx_tcg_subinventarios IS NOT NULL))
       UNION
      SELECT msid.xx_aco_nro_orden_cgrt
           , msid.secondary_inventory_id
           , msid.xx_tcg_subinventarios
        FROM XX_TCG_RT  xtlrt
           , MTL_SECONDARY_INVENTORIES   msi
           , MTL_SECONDARY_INVENTORIES_DFV  msid
       WHERE xtlrt.liquidacion_id         = p_liquidacion_id
         AND '1116RT'                     = p_tipo_liquidacion
         AND xtlrt.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.xx_aco_nro_orden_cgrt  IS NOT NULL;

    l_no_data_found_flag    BOOLEAN;
    l_sec_inventory_id      NUMBER;
    l_organization          VARCHAR2(240);
    l_sec_inv_numeracion    VARCHAR2(10);



  BEGIN

    p_result := TRUE;


    OPEN c_dff;
    FETCH c_dff INTO p_numero_orden
                   , l_sec_inventory_id
                   , l_sec_inv_numeracion;
    l_no_data_found_flag := c_dff%NOTFOUND;
    CLOSE c_dff;


    IF (l_no_data_found_flag) THEN

      p_result := FALSE;

      SELECT od.organization_name||' ('||xl.organization_id||')'
        INTO l_organization
        FROM (SELECT organization_id
                FROM XX_TCG_LIQUIDACIONES_1116A
               WHERE '1116A'        = p_tipo_liquidacion
                 AND liquidacion_id = p_liquidacion_id
               UNION
              SELECT organization_id
                FROM XX_TCG_RT
               WHERE '1116RT'       = p_tipo_liquidacion
                 AND liquidacion_id = p_liquidacion_id
               ) xl
           , ORG_ORGANIZATION_DEFINITIONS od
       WHERE xl.organization_id = od.organization_id;

      p_error_msg := 'No se encuentra configurado el Numero de Orden CGRT para ningun '||
                     'Subinventario de la Organizacion '||l_organization;
      RETURN;

    --ELSE Modificado CR1131
    END IF;

    IF (l_sec_inv_numeracion IS NOT NULL) THEN

      BEGIN
        SELECT xx_aco_nro_orden_cgrt
             , secondary_inventory_id
          INTO p_numero_orden
             , l_sec_inventory_id
          FROM (SELECT msid.xx_aco_nro_orden_cgrt
                     , msid.secondary_inventory_id
                  FROM MTL_SECONDARY_INVENTORIES      msi
                     , MTL_SECONDARY_INVENTORIES_DFV  msid
                 WHERE msi.rowid                    = msid.row_id
                   AND msi.secondary_inventory_name = l_sec_inv_numeracion
                   AND msid.xx_aco_nro_orden_cgrt   IS NOT NULL
                 UNION                                   -- Se agrega la parte de Union porque se actualizo el
                SELECT msid.xx_aco_nro_orden_cgrt        -- Value Set XX_TCG_SUBINVENTARIOS y antes guardaba el secondary inventory name
                     , msid.secondary_inventory_id       -- ahora guarda el secondary inventory id
                  FROM MTL_SECONDARY_INVENTORIES      msi
                     , MTL_SECONDARY_INVENTORIES_DFV  msid
                 WHERE msi.rowid                            = msid.row_id
                   AND TO_CHAR(msid.secondary_inventory_id) = l_sec_inv_numeracion
                   AND msid.xx_aco_nro_orden_cgrt           IS NOT NULL);


        IF (l_sec_inventory_id IS NULL) THEN
          p_result       := FALSE;
          p_numero_orden := NULL;
          p_error_msg    := 'Error al buscar el Numero de Orden CGRT. No se encuentra definido el '
                            ||' secondary_inventory_id para el subinventario '||l_sec_inv_numeracion;
          RETURN;
        END IF;

      EXCEPTION
        WHEN others THEN
          p_result    := FALSE;
          p_error_msg := 'Error al buscar el Numero de Orden CGRT en el subinventario de Numeracion. '||SQLERRM;
          RETURN;
      END;

    END IF;


    IF (p_actualizar) THEN

      UPDATE MTL_SECONDARY_INVENTORIES
         SET attribute8 = NVL(attribute8, 0) + 1    -- xx_aco_nro_orden_cgrt
       WHERE attribute1 = l_sec_inventory_id;

    END IF;


  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error al buscar el Numero de Orden CGRT para la liquidacion '||p_tipo_liquidacion
                     ||' id: '||p_liquidacion_id||'. Detalle: '||SQLERRM;

  END Get_Nro_Orden_CGRT;



/*****************************************************************************
 *                                                                           *
 * Name    : Get_Nro_Orden_LPG                                               *
 * Purpose : Procedimiento que devuelve el valor del Nro de Orden segun      *
 *          la organizacion a la cual pertence la liquidacion                *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Get_Nro_Orden_LPG ( p_liquidacion_id   IN NUMBER
                              , p_actualizar       IN BOOLEAN
                              , p_numero_orden    OUT NUMBER
                              , p_result          OUT BOOLEAN
                              , p_error_msg       OUT VARCHAR2)
  IS

    CURSOR c_dff IS
      SELECT msid.xx_aco_nro_orden_lpg
           , msid.secondary_inventory_id
           , msid.xx_tcg_subinventarios
        FROM XX_TCG_LIQUIDACIONES           xtlb
           , MTL_SECONDARY_INVENTORIES      msi
           , MTL_SECONDARY_INVENTORIES_DFV  msid
       WHERE xtlb.liquidacion_id         = p_liquidacion_id
         AND xtlb.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND ((msid.xx_tcg_subinventarios IS NULL
              AND msid.xx_aco_nro_orden_lpg IS NOT NULL)
              OR
              (msid.xx_tcg_subinventarios IS NOT NULL));


    l_no_data_found_flag    BOOLEAN;
    l_sec_inventory_id      NUMBER;
    l_organization_id       NUMBER;
    l_sec_inv_numeracion    VARCHAR2(10);


  BEGIN

    p_result := TRUE;


    OPEN c_dff;
    FETCH c_dff INTO p_numero_orden
                   , l_sec_inventory_id
                   , l_sec_inv_numeracion;
    l_no_data_found_flag := c_dff%NOTFOUND;
    CLOSE c_dff;


    IF (l_no_data_found_flag) THEN

      p_result := FALSE;

      SELECT organization_id
        INTO l_organization_id
        FROM XX_TCG_LIQUIDACIONES
       WHERE liquidacion_id = p_liquidacion_id;

      p_error_msg := 'No se encuentra configurado el Numero de Orden LPG para ningun '||
                     'Subinventario de la Organizacion '||l_organization_id;
      RETURN;

    --ELSE  Comentado CR1131
    END IF;


    IF (l_sec_inv_numeracion IS NOT NULL) THEN

      BEGIN
        SELECT xx_aco_nro_orden_lpg
             , secondary_inventory_id
          INTO p_numero_orden
             , l_sec_inventory_id
          FROM (SELECT msid.xx_aco_nro_orden_lpg
                     , msid.secondary_inventory_id
                  FROM MTL_SECONDARY_INVENTORIES      msi
                     , MTL_SECONDARY_INVENTORIES_DFV  msid
                 WHERE msi.rowid                    = msid.row_id
                   AND msi.secondary_inventory_name = l_sec_inv_numeracion
                   AND msid.xx_aco_nro_orden_lpg    IS NOT NULL
                 UNION
                SELECT msid.xx_aco_nro_orden_lpg        -- Value Set XX_TCG_SUBINVENTARIOS y antes guardaba el secondary inventory name
                     , msid.secondary_inventory_id       -- ahora guarda el secondary inventory id
                  FROM MTL_SECONDARY_INVENTORIES      msi
                     , MTL_SECONDARY_INVENTORIES_DFV  msid
                 WHERE msi.rowid                            = msid.row_id
                   AND TO_CHAR(msid.secondary_inventory_id) = l_sec_inv_numeracion
                   AND msid.xx_aco_nro_orden_lpg           IS NOT NULL);

        IF (l_sec_inventory_id IS NULL) THEN
          p_result       := FALSE;
          p_numero_orden := NULL;
          p_error_msg    := 'Error al buscar el Numero de Orden LPG. No se encuentra definido el '
                           ||' secondary_inventory_id para el subinventario '||l_sec_inv_numeracion;
          RETURN;
        END IF;

      EXCEPTION
        WHEN others THEN
          p_result    := FALSE;
          p_error_msg := 'Error al buscar el Numero de Orden LPG en el subinventario de Numeracion. '||SQLERRM;
          RETURN;
      END;

    END IF;



    IF (p_actualizar) THEN

      UPDATE MTL_SECONDARY_INVENTORIES
         SET attribute7 = NVL(attribute7, 0) + 1    -- xx_aco_nro_orden_lpg
       WHERE attribute1 = l_sec_inventory_id;

    END IF;


  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error al buscar el Numero de Orden LPG para la liquidacion '||p_liquidacion_id
                     ||'. Detalle: '||SQLERRM;

  END Get_Nro_Orden_LPG;




  FUNCTION Check_Row ( p_tipo_liq     VARCHAR2 DEFAULT '1116B'
                     , p_liq_id       NUMBER
                     , p_err_msg  OUT VARCHAR2
                     ) RETURN BOOLEAN IS


    CURSOR cBusyB ( p_liq_id number ) IS
      SELECT liquidacion_id
        FROM XX_TCG_LIQUIDACIONES
       WHERE liquidacion_id = p_liq_id
         FOR UPDATE NOWAIT;


    CURSOR cBusyA ( p_liq_id number ) IS
      SELECT liquidacion_id
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE liquidacion_id = p_liq_id
         FOR UPDATE NOWAIT;


    CURSOR cBusyRT ( p_liq_id number ) IS
      SELECT liquidacion_id
        FROM XX_TCG_RT
       WHERE liquidacion_id = p_liq_id
         FOR UPDATE NOWAIT;

    l_dummy     NUMBER;
    eROWLOCKED  EXCEPTION;
    PRAGMA      EXCEPTION_INIT(eROWLOCKED, -54);

  BEGIN


    IF (p_tipo_liq = '1116A') THEN

      OPEN cBusyA ( p_liq_id );
      FETCH cBusyA INTO l_dummy;
      CLOSE cBusyA;

    ELSIF (p_tipo_liq = '1116B') THEN

      OPEN cBusyB ( p_liq_id );
      FETCH cBusyB INTO l_dummy;
      CLOSE cBusyB;

    ELSIF (p_tipo_liq = '1116RT') THEN

      OPEN cBusyRT ( p_liq_id );
      FETCH cBusyRT INTO l_dummy;
      CLOSE cBusyRT;

    END IF;

    ROLLBACK;
    RETURN (TRUE);

  EXCEPTION
    WHEN eROWLOCKED THEN
      p_err_msg := SQLERRM||' Liq ID: '||p_liq_id;
      ROLLBACK;
      RETURN (FALSE);
  END Check_Row;




  PROCEDURE Grabar_Error_CGRT ( p_liq_id       NUMBER
                              , p_tipo_liq     VARCHAR2
                              , p_tipo_coe     VARCHAR2
                              , p_ret_val1     VARCHAR2
                              , p_ret_val2     VARCHAR2
                              , p_cancelado    VARCHAR2
                              , p_err_msg  OUT VARCHAR2
                              ) IS
    PRAGMA Autonomous_Transaction;

    CURSOR cLiq IS
      SELECT commit_user_id
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE p_tipo_liq     = '1116A'
         AND liquidacion_id = p_liq_id
       UNION
      SELECT commit_user_id
        FROM XX_TCG_RT
       WHERE p_tipo_liq = '1116RT'
         AND liquidacion_id = p_liq_id
         ;


  BEGIN

    FOR rLiq IN cLiq LOOP


      IF (p_tipo_liq = '1116A') THEN

         INSERT INTO XX_TCG_LIQ1116A_ERRORES_COE
           (LIQUIDACION_ID,
            TIPO_COE,
            CODIGO,
            DESCRIPCION,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            LAST_UPDATE_LOGIN)
         VALUES
           (p_liq_id
           ,p_tipo_coe
           ,p_ret_val1
           ,p_ret_val2
           ,rLiq.commit_user_id
           ,SYSDATE
           ,rLiq.commit_user_id
           ,SYSDATE
           ,-1);

         IF p_cancelado = 'N' THEN

           IF (p_tipo_coe = 'CD') THEN

             UPDATE XX_TCG_LIQUIDACIONES_1116A
                SET liquidado_sin_calidad_flag = 'N'
                  , liquidado_flag             = 'N'
                  , estado_coe                 = 'ERROR'
              WHERE liquidacion_id = p_liq_id;

           --ELSIF  (p_tipo_coe IN ('IC','CE')) THEN
           ELSIF  (p_tipo_coe = 'IC') THEN

             UPDATE XX_TCG_LIQUIDACIONES_1116A
                SET liquidado_flag = 'N'
                  , estado_coe     = 'ERROR'
              WHERE liquidacion_id = p_liq_id;

           ELSIF  (p_tipo_coe = 'CE') THEN

             UPDATE XX_TCG_LIQUIDACIONES_1116A
                SET numero_liquidacion  = DECODE(numero_preexistente,NULL,numero_liquidacion
                                                                    ,numero_preexistente)
                  , numero_preexistente = NULL
                  , estado_coe          = 'ERROR'
              WHERE liquidacion_id = p_liq_id;
           --
           END IF;

         ELSE

           UPDATE XX_TCG_LIQUIDACIONES_1116A
              SET cancelado_flag = DECODE(p_ret_val1, '-1', liquidado_flag, 'N')
                , estado_coe = 'ERROR'
            WHERE liquidacion_id = p_liq_id;

         END IF;


      ELSIF (p_tipo_liq = '1116RT') THEN

          INSERT INTO XX_TCG_RT_ERRORES_COE
           (LIQUIDACION_ID,
            TIPO_COE,
            CODIGO,
            DESCRIPCION,
            CREATED_BY,
            CREATION_DATE,
            LAST_UPDATED_BY,
            LAST_UPDATE_DATE,
            LAST_UPDATE_LOGIN)
          VALUES
           (p_liq_id
           ,p_tipo_coe
           ,p_ret_val1
           ,p_ret_val2
           ,rLiq.commit_user_id
           ,SYSDATE
           ,rLiq.commit_user_id
           ,SYSDATE
           ,-1);


         IF p_cancelado = 'N' THEN

           UPDATE XX_TCG_RT
              SET liquidado_flag = DECODE(p_ret_val1, '-1', liquidado_flag, 'N')
                , estado_coe = 'ERROR'
            WHERE liquidacion_id = p_liq_id;

         ELSE

           UPDATE XX_TCG_RT
              SET cancelado_flag = DECODE(p_ret_val1, '-1', liquidado_flag, 'N')
                , estado_coe = 'ERROR'
            WHERE liquidacion_id = p_liq_id;

         END IF;


      END IF;

    END LOOP;


    COMMIT;

  EXCEPTION
    WHEN Others THEN
      p_err_msg := 'Grabar error CGRT-> '||p_err_msg||' - '||SQLERRM;
  END Grabar_Error_CGRT;




  PROCEDURE Grabar_Error ( p_liq_id       NUMBER
                         , p_tipo_coe     VARCHAR2
                         , p_ret_val1     VARCHAR2
                         , p_ret_val2     VARCHAR2
                         , p_cancelado    VARCHAR2
                         , p_err_msg  OUT VARCHAR2
                         )
  IS

    PRAGMA Autonomous_Transaction;

  BEGIN

    INSERT INTO XX_TCG_LIQUIDACION_ERRORES_COE
      ( LIQUIDACION_ID
      , TIPO_COE
      , CODIGO
      , DESCRIPCION
      , CREATED_BY
      , CREATION_DATE
      , LAST_UPDATED_BY
      , LAST_UPDATE_DATE
      , LAST_UPDATE_LOGIN)
    VALUES
      ( p_liq_id
      , p_tipo_coe
      , p_ret_val1
      , p_ret_val2
      , FND_GLOBAL.user_id
      , SYSDATE
      , FND_GLOBAL.user_id
      , SYSDATE
      , FND_GLOBAL.login_id);


    IF (p_cancelado = 'N') THEN

      UPDATE XX_TCG_LIQUIDACIONES
         SET liquidado_flag = decode(p_ret_val1, '-1', liquidado_flag, 'N')
           , estado_coe     = 'ERROR'
       WHERE liquidacion_id = p_liq_id;

    ELSE

      UPDATE XX_TCG_LIQUIDACIONES
         SET cancelado_flag = decode(p_ret_val1, '-1', liquidado_flag, 'N')
           , estado_coe     = 'ERROR'
       WHERE liquidacion_id = p_liq_id;

    END IF;

    COMMIT;

  EXCEPTION
    WHEN Others THEN
      p_err_msg := 'Grabar error -> '||p_err_msg||' - '||SQLERRM;

  END Grabar_Error;




  PROCEDURE Finalizar_Liquidacion_CGRT ( p_liq_id      NUMBER
                                       , p_tipo_liq    VARCHAR2
                                       , p_coe         VARCHAR2
                                       , p_pto_emision NUMBER
                                       , p_nro_orden   NUMBER
                                       , p_metodo      VARCHAR2
                                       , p_cancelado   VARCHAR2
                                       , p_cond_arch   VARCHAR2
                                       , p_fname       VARCHAR2
                                       , p_err_msg     OUT VARCHAR2
                                       )
  IS

    l_warning               VARCHAR2(2000);
    l_return_status         VARCHAR2(2000);
    l_msg_count             NUMBER;
    l_msg_data              VARCHAR2(2000);
    l_commit_user_id        NUMBER;
    l_resp_id               NUMBER;
    l_resp_appl_id          NUMBER;
    l_boletin_header_id     NUMBER;
    l_tipo_rt               VARCHAR2(30);
    l_result                BOOLEAN;
    l_dummy1                NUMBER;
    l_dummy2                NUMBER;
    eErrNroOrden            EXCEPTION;


  BEGIN

    BEGIN

      SELECT resp_appl_id
           , commit_user_id
           , resp_id
           , boletin_header_id
           , tipo_liquidacion
        INTO l_resp_appl_id
           , l_commit_user_id
           , l_resp_id
           , l_boletin_header_id
           , l_tipo_rt
        FROM (SELECT xla.resp_appl_id
                   , xla.commit_user_id
                   , xla.resp_id
                   , xla.boletin_header_id
                   , NULL   tipo_liquidacion
                FROM XX_TCG_LIQUIDACIONES_1116A xla
               WHERE xla.liquidacion_id = p_liq_id
                 AND p_tipo_liq         = '1116A'
                UNION
              SELECT xrt.resp_appl_id
                   , xrt.commit_user_id
                   , xrt.resp_id
                   , NULL
                   , tipo_liquidacion
                FROM XX_TCG_RT xrt
               WHERE xrt.liquidacion_id = p_liq_id
                 AND p_tipo_liq         = '1116RT'
                 );

      FND_GLOBAL.APPS_INITIALIZE(resp_appl_id => l_resp_appl_id, user_id => l_commit_user_id, resp_id => l_resp_id);
    EXCEPTION
      WHEN No_Data_Found THEN
        NULL;
    END;

    /* Actualizo el nro de orden para el punto de emision dado */
    IF (p_metodo NOT IN ('IC','SX') AND (p_cond_arch = 'O')) THEN

      Get_Nro_Orden_CGRT ( p_liquidacion_id   => p_liq_id
                         , p_tipo_liquidacion => p_tipo_liq
                         , p_actualizar       => TRUE
                         , p_numero_orden     => l_dummy1
                         , p_result           => l_result
                         , p_error_msg        => l_msg_data);
    END IF;

    IF NOT l_result THEN
      RAISE eErrNroOrden;
    END IF;



    /* Finalizo la transaccion */
    IF p_tipo_liq = '1116A' THEN

      IF (p_cancelado = 'N') THEN

        /* Actualizo la liquidacion */
        UPDATE XX_TCG_LIQUIDACIONES_1116A
           SET estado_coe          = 'ASIGNADO'
             , punto_emision_liq   = p_pto_emision
             , numero_orden_liq    = p_nro_orden
             , archivo_coe         = substr(p_fname, 1, instr(p_fname, '.txt')-1)||'.pdf'
             , fecha_liquidacion   = trunc(sysdate)
         WHERE liquidacion_id = p_liq_id;


        COMMIT;

        IF (p_metodo NOT IN ('IC','CE')) OR (p_cond_arch = 'R') THEN

          XX_TCG_LIQUIDACION_1116A_PKG.Liquidar_1116A( p_init_mst_list   => XX_TCG_UTIL_PKG.G_TRUE
                                                     , p_commit          => XX_TCG_UTIL_PKG.G_TRUE
                                                     , p_liquidacion_id  => p_liq_id
                                                     , p_fc_cust_trx_id  => -1
                                                     , x_warning         => l_warning
                                                     , x_return_status   => l_return_status
                                                     , x_msg_count       => l_msg_count
                                                     , x_msg_data        => l_msg_data);
        END IF;

      ELSE

        /* Actualizo la liquidacion */
        UPDATE XX_TCG_LIQUIDACIONES_1116A
           SET estado_coe          = 'ASIGNADO'
             , archivo_coe_anul    = substr(p_fname, 1, instr(p_fname, '.txt')-1)||'.pdf'
         WHERE liquidacion_id = p_liq_id;


        COMMIT;

        XX_TCG_LIQUIDACION_1116A_PKG.Cancelar_1116A( p_init_mst_list     => XX_TCG_UTIL_PKG.G_TRUE
                                                   , p_commit            => XX_TCG_UTIL_PKG.G_TRUE
                                                   , p_liquidacion_id    => p_liq_id
                                                   , p_boletin_header_id => l_boletin_header_id
                                                   , x_warning           => l_warning
                                                   , x_return_status     => l_return_status
                                                   , x_msg_count         => l_msg_count
                                                   , x_msg_data          => l_msg_data);

      END IF;


    ELSE


      IF (p_cancelado = 'N') THEN

        /* Actualizo la liquidacion RT */
        UPDATE XX_TCG_RT
           SET estado_coe          = 'ASIGNADO'
             , punto_emision_liq   = p_pto_emision
             , numero_orden_liq    = p_nro_orden
             , archivo_coe         = substr(p_fname, 1, instr(p_fname, '.txt')-1)||'.pdf'
             , fecha_liquidacion   = trunc(sysdate)
         WHERE liquidacion_id = p_liq_id;


        COMMIT;

        XX_TCG_LIQUIDACION_RT_PKG.Liquidar_1116RT( p_init_mst_list   =>  XX_TCG_UTIL_PKG.G_TRUE
                                              , p_commit          => XX_TCG_UTIL_PKG.G_TRUE
                                              , p_liquidacion_id  => p_liq_id
                                              , x_warning         => l_warning
                                              , x_return_status   => l_return_status
                                              , x_msg_count       => l_msg_count
                                              , x_msg_data        => l_msg_data);


      ELSE


        /* Actualizo la liquidacion RT */
        UPDATE XX_TCG_RT
           SET estado_coe          = 'ASIGNADO'
             , archivo_coe_anul    = substr(p_fname, 1, instr(p_fname, '.txt')-1)||'.pdf'
         WHERE liquidacion_id = p_liq_id;



        COMMIT;

        XX_TCG_LIQUIDACION_RT_PKG.Cancelar_1116RT( p_init_mst_list     =>  XX_TCG_UTIL_PKG.G_TRUE
                                               , p_commit            => XX_TCG_UTIL_PKG.G_TRUE
                                               , p_liquidacion_id    => p_liq_id
                                               , x_warning           => l_warning
                                               , x_return_status     => l_return_status
                                               , x_msg_count         => l_msg_count
                                               , x_msg_data          => l_msg_data);

        IF (l_tipo_rt = 'RETIRO') AND
          (l_return_status = XX_ACO_Util_Pk.G_RET_STS_SUCCESS) THEN

          DELETE FROM XX_TCG_RT_LINES
           WHERE liquidacion_id = p_liq_id;

          COMMIT;

        END IF;

      END IF;

    END IF;

    IF (l_return_status != XX_ACO_Util_Pk.G_RET_STS_SUCCESS) THEN

      ROLLBACK;

      l_msg_data := 'FILEERRR: '||XX_ACO_Util_Pk.Get_Msg(l_msg_count); -- No cambiar mensaje, lo utiliza el RcvCOEDmon
      p_err_msg := substr(l_msg_data,1,60);

      Grabar_Error_CGRT ( p_liq_id     => p_liq_id
                        , p_tipo_liq   => p_tipo_liq
                        , p_tipo_coe   => p_tipo_liq
                        , p_ret_val1   => '-1'
                        , p_ret_val2   => substr(l_msg_data,1,1000)
                        , p_cancelado  => p_cancelado
                        , p_err_msg    => p_err_msg);

      IF (p_tipo_liq='1116A') THEN
        UPDATE XX_TCG_LIQUIDACIONES_1116A
           SET estado_coe     = 'ERROR'
         WHERE liquidacion_id = p_liq_id;
      ELSIF (p_tipo_liq='1116RT') THEN
        UPDATE XX_TCG_RT
           SET estado_coe     = 'ERROR'
         WHERE liquidacion_id = p_liq_id;
      END IF;

    END IF;

    IF (l_warning IS NOT NULL) THEN

      Grabar_Error_CGRT ( p_liq_id     => p_liq_id
                        , p_tipo_liq   => p_tipo_liq
                        , p_tipo_coe   => p_tipo_liq
                        , p_ret_val1   => '-1'
                        , p_ret_val2   => substr(l_warning,1,1000)
                        , p_cancelado  => p_cancelado
                        , p_err_msg    => p_err_msg);

    END IF;


  EXCEPTION
    WHEN eErrNroOrden THEN
      p_err_msg := l_msg_data;
      ROLLBACK;
      Grabar_Error_CGRT ( p_liq_id, p_tipo_liq, p_tipo_liq, '-1', substr(p_err_msg,1,1000), p_cancelado, p_err_msg);

    WHEN Others THEN
      IF p_err_msg IS NULL THEN
        p_err_msg := 'Finalizar Liquidacion CG/RT-> '||SQLERRM;
      END IF;

  END Finalizar_Liquidacion_CGRT;




  PROCEDURE Finalizar_Liquidacion ( p_liq_id      NUMBER
                                  , p_tipo_coe    VARCHAR2
                                  , p_coe         VARCHAR2
                                  , p_pto_emision NUMBER
                                  , p_nro_orden   NUMBER
                                  , p_cancelado   VARCHAR2
                                  , p_cond_arch   VARCHAR2
                                  , p_fname       VARCHAR2
                                  , p_err_msg     OUT VARCHAR2
                                  )
  IS

    l_warning        VARCHAR2(2000);
    l_return_status  VARCHAR2(2000);
    l_msg_count      NUMBER;
    l_msg_data       VARCHAR2(2000);
    l_result         BOOLEAN;
    l_commit_user_id NUMBER;
    l_resp_id        NUMBER;
    l_resp_appl_id   NUMBER;
    l_dummy1         NUMBER;
    l_dummy2         NUMBER;
    l_tipo_origen    VARCHAR2(30);
    l_tipo_liq       VARCHAR2(30);
    eErrNroOrden     EXCEPTION;

  BEGIN

    BEGIN

      SELECT xtl.resp_appl_id
           , xtl.commit_user_id
           , xtl.resp_id
           , DECODE(xtl.contrato_id, NULL, 'PROPIO'
                                   , 'TERCERO') tipo_origen
           , xtl.tipo_liquidacion
        INTO l_resp_appl_id
           , l_commit_user_id
           , l_resp_id
           , l_tipo_origen
           , l_tipo_liq
        FROM XX_TCG_LIQUIDACIONES xtl
       WHERE xtl.liquidacion_id = p_liq_id;

      FND_GLOBAL.apps_initialize( resp_appl_id => l_resp_appl_id
                                , user_id      => l_commit_user_id
                                , resp_id      => l_resp_id);

    EXCEPTION
      WHEN No_Data_Found THEN
        NULL;
    END;


    IF (p_cancelado = 'N') THEN

      /* Actualizo el nro de orden para el punto de emision dado */
      IF ((l_tipo_liq != 'FINAL') AND (p_cond_arch = 'O')) THEN

        Get_Nro_Orden_LPG ( p_liquidacion_id  => p_liq_id
                          , p_actualizar      => TRUE
                          , p_numero_orden    => l_dummy2
                          , p_result          => l_result
                          , p_error_msg       => l_msg_data);

        IF (NOT l_result) THEN
          RAISE eErrNroOrden;
        END IF;

      END IF;


      /* Actualizo la liquidacion */
      UPDATE XX_TCG_LIQUIDACIONES
         SET numero_liquidacion  = p_coe
           , pto_emision_liq_aju = p_pto_emision
           , nro_orden_liq_aju   = p_nro_orden
           , estado_coe          = 'ASIGNADO'
           , fecha_liquidacion   = trunc(sysdate)
           , archivo_coe         = substr(p_fname, 1, instr(p_fname, '.txt')-1)||'.pdf'
       WHERE liquidacion_id      = p_liq_id;

      /* Finalizo la transaccion */
      IF (l_tipo_origen != 'PROPIO') THEN

        COMMIT; -- Como savepoint implicito

        XX_TCG_LIQUIDACION_GRANOS_PKG.Liquidar( p_init_mst_list   => XX_TCG_UTIL_PKG.G_TRUE
                                              , p_commit          => XX_TCG_UTIL_PKG.G_TRUE
                                              , p_liquidacion_id  => p_liq_id
                                              , p_procesamiento   => 'INTERFACE'
                                              , x_warning         => l_warning
                                              , x_return_status   => l_return_status
                                              , x_msg_count       => l_msg_count
                                              , x_msg_data        => l_msg_data);

      END IF;

    ELSE

              /* Actualizo el nro de orden para el punto de emision dado */ -- CR2272 Se agrega actualizacion orden - Dic- 19
      IF ((l_tipo_liq != 'FINAL') AND (p_cond_arch = 'O')) THEN

        Get_Nro_Orden_LPG ( p_liquidacion_id  => p_liq_id
                          , p_actualizar      => TRUE
                          , p_numero_orden    => l_dummy2
                          , p_result          => l_result
                          , p_error_msg       => l_msg_data);

        IF (NOT l_result) THEN
          RAISE eErrNroOrden;
        END IF;

      END IF;
      -- CR2272 Fin  Dic-19

      /* Actualizo la  anulacion liquidacion */
      UPDATE XX_TCG_LIQUIDACIONES
         SET estado_coe          = 'ASIGNADO'
           , archivo_coe_anul    = substr(p_fname, 1, instr(p_fname, '.txt')-1)||'.pdf'
           , NUMERO_ANULACION =   p_coe -- cr2272 Devuelve coe de anulacion  Dic-19
       WHERE liquidacion_id = p_liq_id;

      COMMIT; -- Como savepoint implicito

      /* Finalizo la transaccion */

      XX_TCG_LIQUIDACION_GRANOS_PKG.Cancelar( p_init_mst_list   => XX_TCG_UTIL_PKG.G_TRUE
                                            , p_commit          => XX_TCG_UTIL_PKG.G_TRUE
                                            , p_liquidacion_id  => p_liq_id
                                            , x_warning         => l_warning
                                            , x_return_status   => l_return_status
                                            , x_msg_count       => l_msg_count
                                            , x_msg_data        => l_msg_data);

    END IF;

    IF (l_return_status != XX_ACO_Util_Pk.G_RET_STS_SUCCESS) THEN

      ROLLBACK;

      l_msg_data := 'FILEERRR: '||XX_ACO_Util_Pk.Get_Msg(l_msg_count); -- No cambiar mensaje, lo utiliza el RcvCOEDmon
      p_err_msg  := substr(l_msg_data,1,60);

      Grabar_Error ( p_liq_id, p_tipo_coe, '-1', substr(l_msg_data,1,1000), p_cancelado, p_err_msg);

      UPDATE XX_TCG_LIQUIDACIONES
         SET estado_coe     = 'ASIG_ERROR'
       WHERE liquidacion_id = p_liq_id;

    END IF;

  EXCEPTION
    WHEN eErrNroOrden THEN
      p_err_msg := l_msg_data;
      ROLLBACK;
      Grabar_Error ( p_liq_id, p_tipo_coe, '-1', substr(p_err_msg,1,1000), p_cancelado, p_err_msg);

    WHEN Others THEN
      IF p_err_msg IS NULL THEN
        p_err_msg := 'Finalizar Liquidacion -> '||SQLERRM;
      END IF;

  END Finalizar_Liquidacion;




 /****************************************************************************
 *                                                                           *
 * Name   : Envia_Archivo                                                    *
 * Purpose: Procedimiento encargado de chequear liquidaciones encoladas por  *
 *          punto de emision y generar el archivo a PlanesWare para que se   *
 *          procese en AFIP                                                  *
 *                                                                           *
 *****************************************************************************/
  PROCEDURE Envia_archivo ( p_cant_reg   OUT NUMBER
                          , p_err_msg    OUT VARCHAR2
                          )
  IS

    CURSOR cLiqToSend IS
      SELECT '1116B'                                tipo_liq
           , min(lb.liquidacion_id)                 liquidacion_id
           , lpad(lb.pto_emision_liq_aju,4,0)       pto_emision
           , nvl(lb.liquidado_flag, 'N')            liquidado_flag
           , nvl(lb.cancelado_flag, 'N')            cancelado_flag
           , hoi.org_information3                   operating_unit
        FROM XX_TCG_LIQUIDACIONES         lb
           , HR_ORGANIZATION_INFORMATION  hoi
       WHERE 1             = 1
         AND lb.organization_id    = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND lb.estado_coe = 'SOLICITAR'
         AND NOT EXISTS      (SELECT DISTINCT 1
                                FROM XX_TCG_LIQUIDACIONES         l
                                   , HR_ORGANIZATION_INFORMATION  o
                               WHERE l.organization_id     = o.organization_id
                                 AND l.estado_coe          = 'ESP_RESP'
                                 AND l.pto_emision_liq_aju = lb.pto_emision_liq_aju
                                 AND o.organization_id     = hoi.organization_id
                                 )
       GROUP BY lpad(lb.pto_emision_liq_aju,4,0)
              , nvl(lb.liquidado_flag, 'N')
              , nvl(lb.cancelado_flag, 'N')
              , hoi.org_information3
       UNION
      SELECT '1116A'                                   tipo_liq
           , min(la.liquidacion_id)                    liquidacion_id
           , lpad(la.punto_emision_liq,4,0)            pto_emision
           , NULL                                      liquidado_flag           --nvl(la.liquidado_flag, 'N')
           , nvl(la.cancelado_flag, 'N')               cancelado_flag
           , hoi.org_information3                      operating_unit
        FROM XX_TCG_LIQUIDACIONES_1116A   la
           , HR_ORGANIZATION_INFORMATION  hoi
       WHERE 1                     = 1
         AND la.organization_id    = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND la.estado_coe         = 'SOLICITAR'
         AND NOT EXISTS      (SELECT DISTINCT 1
                                FROM XX_TCG_LIQUIDACIONES_1116A l
                                   , HR_ORGANIZATION_INFORMATION  hoi1
                               WHERE l.organization_id     = hoi1.organization_id
                                 AND l.estado_coe          = 'ESP_RESP'
                                 AND l.punto_emision_liq   = la.punto_emision_liq
                                 AND hoi1.org_information3 = hoi.org_information3)
         AND NOT EXISTS       (SELECT DISTINCT 1
                                 FROM XX_TCG_RT l
                                    , HR_ORGANIZATION_INFORMATION hoi2
                                WHERE l.estado_coe        in ( 'ESP_RESP', 'SOLICITAR')
                                  AND l.punto_emision_liq = la.punto_emision_liq
                                  AND NVL(l.cancelado_flag,'N') = NVL(la.cancelado_flag,'N')
                                  AND l.organization_id = hoi2.organization_id
                                  AND hoi2.org_information3 = hoi.org_information3
                                  )
       GROUP BY lpad(la.punto_emision_liq,4,0)
              , nvl(la.cancelado_flag, 'N')
              , hoi.org_information3
      UNION
      SELECT '1116A_ACO'
           , min(la.liquidacion_id)
           , lpad(la.punto_emision_liq,4,0)
           , NULL
           , nvl(la.cancelado_flag, 'N')
           , XX_ACO_UTIL_PK.get_co_code(la.whse_code) co_code
        FROM XX_ACO_LIQUIDACIONES_1116A la
       WHERE 1                     = 1
         AND la.estado_coe         = 'SOLICITAR'
         AND NOT EXISTS      (SELECT DISTINCT 1
                                FROM XX_ACO_LIQUIDACIONES_1116A l
                               WHERE l.estado_coe        = 'ESP_RESP'
                                 AND l.punto_emision_liq = la.punto_emision_liq
                                 AND XX_ACO_UTIL_PK.get_co_code(l.whse_code) = XX_ACO_UTIL_PK.get_co_code(la.whse_code))
         AND NOT EXISTS       (SELECT DISTINCT 1
                                 FROM XX_ACO_LIQUIDACIONES_1116RT l,
                                      XX_ACO_CONTRATOS            xac
                                WHERE l.estado_coe        in ( 'ESP_RESP', 'SOLICITAR')
                                  AND l.punto_emision_liq = la.punto_emision_liq
                                  AND NVL(l.cancelado_flag,'N') = NVL(la.cancelado_flag,'N')
                                  AND ((l.tipo_liquidacion_relacionada = '1116A'
                                       AND xac.contrato_id = (SELECT contrato_id
                                                                FROM XX_ACO_LIQUIDACIONES_1116A xal
                                                               WHERE xal.liquidacion_id = l.liquidacion_id_relacionada))
                                      OR
                                      (l.tipo_liquidacion_relacionada = '1116RT'
                                       AND xac.contrato_id = (SELECT xal.contrato_id
                                                                FROM XX_ACO_LIQUIDACIONES_1116RT xlrt,
                                                                     XX_ACO_LIQUIDACIONES_1116A  xal
                                                               WHERE xlrt.liquidacion_id_relacionada = xal.liquidacion_id
                                                                 AND xlrt.tipo_liquidacion_relacionada = '1116A'
                                                                 AND xlrt.liquidacion_id = l.liquidacion_id_relacionada)))
                                  AND XX_ACO_UTIL_PK.get_co_code(xac.whse_code_recepcion) = XX_ACO_UTIL_PK.get_co_code(la.whse_code)
                                  )
       GROUP BY lpad(la.punto_emision_liq,4,0)
              , nvl(la.cancelado_flag, 'N')
              , XX_ACO_UTIL_PK.get_co_code(la.whse_code)
       UNION
      SELECT '1116RT'
           , min(lrt.liquidacion_id)
           , lpad(lrt.punto_emision_liq,4,0)
           , nvl(lrt.liquidado_flag, 'N')
           , nvl(lrt.cancelado_flag, 'N')
           , hoi.org_information3                      operating_unit
        FROM XX_TCG_RT    lrt,
                  XX_TCG_LIQUIDACIONES_1116A xal,
            HR_ORGANIZATION_INFORMATION  hoi
       WHERE 1  = 1
         AND xal.liquidacion_id = lrt.liquidacion_id_certificado
         AND lrt.organization_id    = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND lrt.estado_coe  = 'SOLICITAR'
         AND NOT EXISTS       (SELECT DISTINCT 1
                                 FROM XX_TCG_RT l
                                WHERE l.estado_coe        = 'ESP_RESP'
                                  AND l.punto_emision_liq = lrt.punto_emision_liq
                                  AND l.organization_id = lrt.organization_id
                                  )
         AND NOT EXISTS      (SELECT DISTINCT 1
                                FROM XX_TCG_LIQUIDACIONES_1116A l
                               WHERE l.estado_coe        = 'ESP_RESP'
                                 AND l.punto_emision_liq = lrt.punto_emision_liq
                                 AND NVL(l.cancelado_flag,'N') = NVL(lrt.cancelado_flag,'N')
                                 AND l.organization_id = lrt.organization_id
                             )

       GROUP BY lpad(lrt.punto_emision_liq,4,0)
              , nvl(lrt.liquidado_flag, 'N')
              , nvl(lrt.cancelado_flag, 'N')
               , hoi.org_information3
       ORDER BY 1,
                2;



    CURSOR cLiqToSend2 ( p_liq_id NUMBER , p_oper_unit NUMBER) IS
      SELECT lpad(lb.pto_emision_liq_aju,4,0)                                   pto_emision
           , lpad(lb.liquidacion_id,8,0)                                        nro_liq_interno
           , lb.nro_orden_liq_aju                                               nro_orden
           , DECODE((hp.jgzz_fiscal_code||aps.global_attribute12), NULL
                   , (SELECT operating_unit_cuit
                        FROM XX_TCG_PARAMETROS_COMPANIA
                       WHERE operating_unit = p_oper_unit)
                   , (hp.jgzz_fiscal_code||aps.global_attribute12))             CUIT
           , lb.tipo_liquidacion
           , substr(lb.tipo_comprobante, 5, 1)                                  tipo_comprobante
           , lb.liquidado_flag
           , nvl(lb.cancelado_flag, 'N')                                        cancelado_flag
           , replace(lb.numero_liquidacion, '-', '')                            coe
           , lb.precio_oper_conv
           , lb.precio_ref_conv
           , lb.imp_bruto_parcial
           , lb.importe_a_liquidar
           , lb.bonif_descuento
           , lb.acopio_pdte_final
           , DECODE(lb.tipo_liquidacion, 'AJUSTE_UNICO', ( SELECT SUM(lbl.peso_liquidado)
                                                             FROM XX_TCG_LIQUIDACION_LINES   lbl
                                                            WHERE lbl.liquidacion_id = lb.liquidacion_id)
                                       , lb.peso_neto_liquidado)                peso_neto
           , lb.metodo_liq
           , lb.grado
           , lb.factor_grado
           , lb.factor_calidad
           , DECODE(lb.contrato_id, NULL, 'PROPIO', 'TERCERO')                  tipo_origen
        FROM XX_TCG_LIQUIDACIONES lb
           , HZ_PARTIES           hp
           , AP_SUPPLIERS         aps
       WHERE 1=1
         AND lb.empresa_destino_party_id = hp.party_id (+)
         AND hp.party_id                 = aps.party_id (+)
        AND lb.liquidacion_id            = p_liq_id;



    CURSOR cLiqToSendCGRT ( p_liquidacion_id NUMBER
                          , p_tipo_liq       VARCHAR2 )IS
      SELECT xtla.numero_orden_liq             nro_orden
           , nvl(xtla.liquidado_flag, 'N')     liquidado_flag
           , xtla.contrato_id
           , xtla.boletin_header_id
           , DECODE(xtla.cancelado_flag,'Y','SX'
                   , DECODE(xtla.numero_preexistente,NULL,DECODE(xtla.numero_liquidacion, NULL, 'CD'
                                                                                        , DECODE(xtbh.estado,NULL,'CD'
                                                                                                            ,'CONFORMADO','CD'
                                                                                                            ,'ANALIZADO','IC'))
                                                                                                            ,'CE'))      metodo
           , xtla.organization_id
           , DECODE(xtla.contrato_id, NULL, 'PROPIO', 'TERCERO') tipo_origen
           , xbca.merma_header_id
           , xbca.acond_id
           , DECODE(pvd.vat_reg_status_code, '06', 'Y', 'N') es_mtrb
           , cust_trx_id_ficticio
        FROM XX_TCG_LIQUIDACIONES_1116A xtla
           , XX_TCG_BOLETIN_HEADERS     xtbh
           , XX_TCG_CONTRATOS_COMPRA    xtcc
           , (SELECT xtl.boletin_header_id
                   , xtl.carta_porte_id
                   , xtl.merma_header_id
                   , xtga.acond_id
                FROM (SELECT xtbl.boletin_header_id
                           , min(xtcp.carta_porte_id) carta_porte_id
                           , xtcp.merma_header_id
                        FROM XX_TCG_BOLETIN_LINES    xtbl
                           , XX_TCG_CARTAS_PORTE_ALL xtcp
                       WHERE xtbl.carta_porte_id = xtcp.carta_porte_id
                       GROUP BY xtbl.boletin_header_id
                           , xtcp.merma_header_id) xtl
                   , XX_TCG_GASTO_ACONDICIONAMIENTO xtga
               WHERE xtl.carta_porte_id = xtga.carta_porte_id (+)) xbca
           , AP_SUPPLIERS                aps
           , PO_VENDORS1_DFV             pvd
       WHERE 1                            = 1
         AND xtla.boletin_header_id       = xtbh.boletin_header_id
         AND xtla.contrato_id             = xtcc.contrato_id (+)
         AND xtbh.boletin_header_id       = xbca.boletin_header_id
         AND xtla.empresa_origen_party_id = aps.party_id
         AND aps.rowid                    = pvd.row_id
         AND p_tipo_liq                   = '1116A'
         AND xtla.liquidacion_id          = p_liquidacion_id
       UNION
      SELECT lrt.numero_orden_liq nro_orden
           , nvl(lrt.liquidado_flag, 'N') liquidado_flag
           , xal.contrato_id
           , NULL                                                               boletin_header_id
           , DECODE(lrt.cancelado_flag,'Y', 'SX'
                                      ,DECODE(lrt.tipo_liquidacion,'RETIRO','CR'
                                                                  ,'TRANSFERENCIA','CT')) metodo
           , lrt.organization_id
           , DECODE(xal.contrato_id, NULL, 'PROPIO', 'TERCERO') tipo_origen
           , null merma_header_id
           , null acond_id
           , null es_mtrb
           , null cust_trx_id_ficticio
        FROM XX_TCG_RT    lrt,
             XX_TCG_LIQUIDACIONES_1116A xal
       WHERE 1  = 1
        and  xal.liquidacion_id = lrt.liquidacion_id_certificado
         AND p_tipo_liq            = '1116RT'
         AND lrt.liquidacion_id    = p_liquidacion_id
         ;



    CURSOR cRec000 (p_liq_id NUMBER) IS
      SELECT lpad(lb.liquidacion_id,8,0)                               "R00001" -- Nro Interno
           , DECODE(lb.cancelado_flag, 'Y', 'X'
                   , DECODE(lb.tipo_liquidacion, 'AJUSTE_UNICO', 'A'
                           , 'L'))                                     "R00002" -- Tipo Liquidacion
           , lpad(lb.pto_emision_liq_aju,4,0)                          "R00003" -- Punto Emisor
           , null                                                                 "R00004"         -- Nro Orden  --lb.nro_orden_liq_aju             "R00004" -- CR2272 Dic-19 el nro_orden se debe recuperar siempre del subinventario
           , DECODE(lb.metodo_liq, 'L', 'AU'
                                 , 'C', 'AC'
                                 , NULL)                               "R00005" -- Cod Tipo Ajuste
           , xtpc.operating_unit_cuit                                  "R00006" -- CUIT
           , aps.vendor_name                                           "R00007" -- Razon social
           , hlv.address_line_1||' '||
             substr(hlv.address_line_2,1,length(hlv.address_line_2)-3) "R00008" -- Domicilio
           , xtl.loc_nombre                                            "R00009" -- Localidad
           , xtl.pr_dpto_nombre                                        "R00010" -- Provincia
           , xtpc.actividad                                            "R00011" -- Nro Actividad
           , aps.attribute1                                            "R00012" -- Nro Ingresos Brutos
           , DECODE(lb.metodo_liq, 'C',  xtpc.actividad
                                 , NULL )                              "R00013" -- Actividad Emisor Documento
           , NULL                                                      "R00014" -- Tipo Formulario
           , NULL                                                      "R00015" -- Nro Formulario
        FROM XX_TCG_LIQUIDACIONES         lb
           , ORG_ORGANIZATION_DEFINITIONS ood
           , XX_TCG_PARAMETROS_COMPANIA   xtpc
           , AP_SUPPLIERS                 aps
           , HR_ALL_ORGANIZATION_UNITS    haou
           , HR_LOCATIONS_V               hlv
           , XX_TCG_LOCALIDADES           xtl
       WHERE 1=1
         AND lb.organization_id           = ood.organization_id
         AND ood.operating_unit           = xtpc.operating_unit
         AND xtpc.vendor_id               = aps.vendor_id
         AND xtpc.operating_unit          = haou.organization_id
         AND haou.location_id             = hlv.location_id
         AND lpad(hlv.town_or_city,5,'0') = xtl.loc_codigo
         AND hlv.region_2                 = xtl.pr_dpto_codigo
         AND lb.liquidacion_id            = p_liq_id;



    CURSOR cRec010 (p_liq_id NUMBER) IS
      SELECT DECODE(substr(lb.tipo_comprobante,1,5),'1116B',1,2)                "R01001" -- Cod Tipo Operacion
           , DECODE(lb.contrato_id, NULL, 'S' /*PROPIO*/
                                  , 'N'/*TERCERO*/)                            "R01002" -- Liquidacion Propia (S/N)
           , DECODE(atv.attribute1, 'Y', 'T', 'N')                              "R01003" -- Es Canje (N, P parcial, T total)
           , NVL(flld.xx_tcg_puerto_afip, '014')                                "R01004" -- Codigo de Puerto
           , DECODE(flld.xx_tcg_puerto_afip, NULL, 'OTROS'
                                           , '014', 'OTROS', NULL)              "R01005" -- Desc Puerto
           , msid.xx_aco_codigo_oncca                                           "R01006" -- Codigo grano
           , TO_CHAR(sysdate,'YYYYMMDD')                                        "R01007" -- Fecha precio operacion
           , ROUND( lb.precio_ref_conv * 1000
                  , (SELECT pov.profile_option_value
                       FROM FND_PROFILE_OPTIONS_VL        po
                          , FND_PROFILE_OPTION_VALUES     pov
                      WHERE 1=1
                        AND po.profile_option_name = 'XX_ACO_PRECIO_REF_DEC'
                        AND pov.application_id     = po.application_id
                        AND pov.profile_option_id  = po.profile_option_id ) -3
                  )                                                             "R01008" -- Precio Referencia Toneladas
           , (SELECT 'G2'
                FROM MTL_SYSTEM_ITEMS_B msi
                   , MTL_SYSTEM_ITEMS_B_DFV msid
               WHERE msid.xx_aco_control_grado = 'Y'
                 AND msi.rowid= msid.row_id
                 AND msi.inventory_item_id = lb.inventory_item_id
                 AND msi.organization_id = lb.organization_id )                 "R01009" -- Codigo del grano
           , DECODE(lb.metodo_liq, 'C', DECODE(lb.grado, 0, 'G2'
                                                       , 'G'||lb.grado)
                                 , NULL)                                        "R01010" -- Calidad de grano
           , DECODE(lb.metodo_liq, 'C', lb.factor_grado/100
                                 , NULL)                                        "R01011" -- Valor correspondiente al grado del grano entregado
           , DECODE(lb.metodo_liq, 'C', lb.factor_calidad/100
                                 , NULL)                                        "R01012" -- Factor correspondiente al grano entregado
           , lb.precio_flete * 1000                                             "R01013" -- Precio Flete Tonelada
           , NULL                                                               "R01014" -- Cont Proteico
           , XX_TCG_LIQUIDACION_UTIL_PKG.Get_Alicuota_IVA(lb.inventory_item_id
--                                                    , lb.organization_id               CR612 Rvised Jul 2018
                                                    , hoi.org_information3 )    "R01015" -- Alicuota Iva Operacion
           , lb.lot_number                                                      "R01016" -- Codigo de Camapania
--          , DECODE(lb.tipo_liquidacion          --  planta formularios debe seguir existiendo???!!!!!!!!!!!!!!!!!!!!!
--                   , 'AJUSTE_UNICO', TO_NUMBER(pdcia.localidad)
--                   ,  TO_NUMBER(c.localidad_oncca) )                                           "R01017" -- Localidad Procedencia Grano
           , lb.procedencia_localidad                                           "R01017" -- Localidad Procedencia Grano
--           , DECODE(lb.tipo_liquidacion
--                   , 'AJUSTE_UNICO', TO_NUMBER(pdcia.provincia)
--                   , TO_NUMBER(c.procedencia) )                                                "R01018" -- Provincia Procedencia Grano
            , lb.procedencia                                                    "R01018" -- Provincia Procedencia Grano
           , DECODE(lb.tipo_liquidacion, 'AJUSTE_UNICO', 'G'||lb.grado
                                       , NULL )                                 "R01019" -- Codigo grado ajuste
           , NULL                                                               "R01020" -- Valor grado ajuste
           , NULL                                                               "R01021" -- Factor correspondiente al grano ajustado
           , xtcc.reg_afip                                                      "R01022" -- Contrato AFIP
           , atv.name                                                           "R01023" -- Termino de Pago
           , DECODE(lb.tipo_liquidacion,'PARCIAL',lb.peso_neto_liquidado,NULL ) "R01024" -- Peso Nesto Sin Certificado
           , DECODE(lb.tipo_liquidacion, 'PARCIAL'
                            , to_number(lb.procedencia_localidad), NULL )       "R01025" -- Localidad Procedencia Grano
           , DECODE(lb.tipo_liquidacion, 'PARCIAL'
                            , to_number(lb.procedencia), NULL )                 "R01026" -- Provincia Procedencia Grano
           , xtcc.numero_contrato                                               "R01027"
           , lb.tipo_liquidacion
           , lb.metodo_liq
        FROM XX_TCG_LIQUIDACIONES        lb
           , AP_TERMS_VL                 atv
           , MTL_SYSTEM_ITEMS_B          msi
           , MTL_SYSTEM_ITEMS_B_DFV      msid
           , XX_TCG_CONTRATOS_COMPRA     xtcc
           , FND_LOOKUP_VALUES           fll
           , FND_LOOKUP_VALUES_DFV       flld
           , HR_ORGANIZATION_INFORMATION hoi
       WHERE 1                           = 1
         AND atv.term_id                 = lb.ap_term_id
         AND lb.inventory_item_id        = msi.inventory_item_id
         AND lb.organization_id          = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND lb.contrato_id              = xtcc.contrato_id(+) -- CR2272  Si no existe contratro  Dic-19
         AND fll.rowid                   = flld.row_id
         AND fll.lookup_type             = 'XX_ACO_LOCALIDADES_ONCCA'
         AND fll.language                = userenv('LANG')
         --AND fll.lookup_code             = xtcc.localidad_procedencia_code  CR2272
            AND fll.lookup_code             =  nvl(xtcc.localidad_procedencia_code,(SELECT MAX(xtla.LOCALIDAD_ORIGEN_CODE)
                                                                                                            FROM XX_TCG_CERTIFICADOS_LIQUIDADOS  XTCL
                                                                                                                            , XX_TCG_LIQUIDACIONES_1116A xtla
                                                                                                            WHERE XTCL.LIQUIDACION_ID = lb.liquidacion_id
                                                                                                            AND  xtcl.certificado_id     = xTla.liquidacion_id)
                                                                                                            )  -- CR2272 si no tiene contrato busca la inf en certificados - Dic-19
         AND lb.organization_id          = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND lb.liquidacion_id           = p_liq_id;



    CURSOR cRec015 ( p_liq_id NUMBER ) IS
      SELECT DECODE(lb.metodo_liq, 'L', DECODE(SIGN(NVL(lb.peso_diferencia_aju,0))
                                              , -1, ABS(lb.peso_diferencia_aju)
                                              , 0)
                                 , 'C', NULL )                                  "R01501" -- Diferencia Peso Neto
           , DECODE(lb.metodo_liq, 'L', 0, 'C', NULL )                          "R01502" -- Diferencia Precio Operacion
           , DECODE(lb.metodo_liq
                   , 'L', DECODE(SIGN(NVL(lb.bonif_descuento,0))
                                , -1, DECODE(lb.grado, 0, 'G2', 'G'||lb.grado)
                                , 'G2')
                   , 'C', NULL )                                                "R01503" -- Codigo Grado
           , NULL                                                               "R01504" -- Valor Grado
           , DECODE(lb.metodo_liq
                   , 'L', DECODE(SIGN(NVL(lb.bonif_descuento,0))
                                , -1, lb.factor_calidad
                                , 100)
                   , 'C', NULL )                                                "R01505" -- Factor
           , DECODE(lb.metodo_liq, 'L', 0, 'C', NULL )                          "R01506" -- Dif Precio Flete
           , NULL                                                               "R01507" -- Datos Adicionales
           , NULL                                                               "R01508" -- Concepto iva 0%
           , NULL                                                               "R01509" -- Importe iva 0%
           , lb.metodo_liq
           , lb.peso_diferencia_aju
           , lb.bonif_descuento
           , DECODE(lb.metodo_liq, 'L', NULL
                                 , 'C', XX_TCG_LIQUIDACION_UTIL_PKG.Get_Alicuota_IVA
                                         ( lb.inventory_item_id
                                         --, lb.organization_id     CR612 Revised Jul 2018
                                         , hoi.org_information3))               iva_item
          , hoi.org_information3                                                org_id
          , lb.liquidacion_id
      FROM XX_TCG_LIQUIDACIONES        lb
         , HR_ORGANIZATION_INFORMATION hoi
     WHERE lb.organization_id          = hoi.organization_id
       AND hoi.org_information_context = 'Accounting Information'
       AND lb.tipo_liquidacion         = 'AJUSTE_UNICO'
       AND (lb.bonif_descuento < 0
           OR lb.peso_diferencia_aju < 0)
       AND lb.liquidacion_id           = p_liq_id;



    CURSOR cRec016 ( p_liq_id NUMBER ) IS
      SELECT DECODE(lb.metodo_liq
                   , 'L', DECODE(SIGN(NVL(lb.peso_diferencia_aju,0)),-1, 0
                                              , lb.peso_diferencia_aju)
                   , 'C', NULL )                                                "R01601" -- Diferencia Peso Neto
           , DECODE(lb.metodo_liq, 'L', 0
                                 , 'C', NULL )                                  "R01602" -- Diferencia Precio Operacion
           , DECODE(lb.metodo_liq
                   , 'L', DECODE(SIGN(NVL(lb.bonif_descuento,0)), -1, 'G2'
                                , DECODE(lb.grado, 0, 'G2', 'G'||lb.grado))
                   , 'C', NULL )                                                "R01603" -- Codigo Grado
           , NULL                                                               "R01604" -- Valor Grado
           , DECODE(lb.metodo_liq
                   , 'L', DECODE(SIGN(NVL(lb.bonif_descuento,0)), -1, 100
                                , lb.factor_calidad)
                   , 'C', NULL )                                                "R01605" -- Factor
           , DECODE(lb.metodo_liq, 'L', 0
                                 , 'C', NULL )                                  "R01606" -- Dif Precio Flete
           , NULL                                                               "R01607" -- Datos Adicionales
           , (SELECT substr(mml.name,1,30)
                FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
                   , AR_MEMO_LINES_ALL_TL        mml
               WHERE mml.memo_line_id = xtpc.liq_pend_final_memo_line_id
                 AND mml.language     = 'ESA'
                 AND mml.org_id       = hoi.org_information3)                   "R01608" -- Concepto iva 0%
           , lb.acopio_pdte_final                                               "R01609" -- Importe iva 0%
           , lb.metodo_liq
           , lb.peso_diferencia_aju
           , lb.bonif_descuento
           , DECODE(lb.metodo_liq, 'L', NULL
                                 , 'C', XX_TCG_LIQUIDACION_UTIL_PKG.Get_Alicuota_IVA
                                         ( lb.inventory_item_id
                                         --, lb.organization_id  CR612 Revised Jul 2018
                                         , hoi.org_information3))               iva_item
          , hoi.org_information3                                                org_id
          , lb.liquidacion_id
       FROM XX_TCG_LIQUIDACIONES lb
          , HR_ORGANIZATION_INFORMATION hoi
      WHERE lb.organization_id          = hoi.organization_id
        AND hoi.org_information_context = 'Accounting Information'
        AND lb.tipo_liquidacion         = 'AJUSTE_UNICO'
        --AND (lb.bonif_descuento >= 0   -- CR1889  Se eliminan los filtros
        --    OR lb.peso_diferencia_aju >= 0)    -- CR1889  Se eliminan los filtros
        AND lb.liquidacion_id           = p_liq_id;



    CURSOR cRec020 (p_liq_id NUMBER) IS
      SELECT hp.jgzz_fiscal_code||aps.global_attribute12                        "R02001" -- CUIT
           , aps.vendor_name                                                    "R02002" -- Razon social
           , apss.address_line1||' '
           ||substr(apss.address_line2,1,length(apss.address_line2)-3)          "R02003" -- Domicilio
           , NVL(address_line2,apss.city)                                       "R02004" -- Localidad
           , apss.province                                                      "R02005" -- Provincia
           , aps.attribute1                                                     "R02006" -- Nro Ingresos Brutos
           , NULL                                                               "R02007" -- Codigo del Receptor del documento
        FROM XX_TCG_LIQUIDACIONES        lb
           , HZ_PARTIES                  hp
           , AP_SUPPLIERS                aps
           , AP_SUPPLIER_SITES_ALL       apss
           , HR_ORGANIZATION_INFORMATION hoi
       WHERE lb.empresa_origen_party_id     = hp.party_id
         AND hp.party_id                    = aps.party_id
         AND aps.vendor_id                  = apss.vendor_id
         AND lb.organization_id             = hoi.organization_id
         AND hoi.org_information_context    = 'Accounting Information'
         AND apss.org_id                    = hoi.org_information3
         AND apss.global_attribute_category = 'JL.AR.APXVDMVD.SUPPLIER_SITES'
         AND apss.global_attribute17        = 'Y'
         AND lb.liquidacion_id              = p_liq_id;



    CURSOR cRec030 (p_liq_id NUMBER) IS
      SELECT 'N'          "R03001" --  Actua corredor
           , 'N'          "R03002" --  Liquida corredor
           , NULL         "R03003" --  CUIT Corredor
           , NULL         "R03004" --  Comision corredor
           , NULL         "R03005" --  Numero ingresos brutos
           , NULL         "R03006" --  Razon Social Corredor
           , NULL         "R03007" --  Domicilio corredor
        FROM DUAL;



    CURSOR cRec050 (p_liq_id NUMBER) IS
--      SELECT DECODE(lb.tipo_liquidacion_relacionada, '1116A', DECODE(SUBSTR(la.numero_liquidacion,1,2),'33',332
--                                                                                                      ,5)
--                                                   , '1116RT',DECODE(SUBSTR(lrt.numero_liquidacion,1,2),'33',332
--                                                                                                      , 1))              "R05001" -- Tipo Certificado Desposito
--           , DECODE(lb.tipo_liquidacion_relacionada, '1116A', REPLACE(la.numero_liquidacion, '-','')
--                                                   , '1116RT', REPLACE(lrt.numero_liquidacion, '-','')) "R05002" -- Numero Certificado
--           , ( SELECT NVL(SUM(cantidad_a_liquidar),0)
--               FROM xx_aco_carta_porte_liq1116b
--               WHERE 1=1
--               AND liquidacion_1116b = lb.liquidacion_id
--               AND liquidado_flag = 'Y'
--               AND cancelado_flag = 'N' )                                                   "R05003" -- Peso Neto
--            , DECODE(lb.tipo_liquidacion_relacionada, '1116A',  TO_NUMBER(la.procedencia_localidad)
--                                                    , '1116RT', (SELECT procedencia_localidad
--                                                                 FROM xx_aco_liquidaciones_1116a
--                                                                 WHERE liquidacion_id = lrt.liquidacion_id_relacionada)) "R05004" -- Codigo localidad procedencia
--            , DECODE(lb.tipo_liquidacion_relacionada,'1116A', TO_NUMBER(la.procedencia)
--                                                    ,'1116RT', (SELECT procedencia
--                                                                FROM xx_aco_liquidaciones_1116a
--                                                                WHERE liquidacion_id = lrt.liquidacion_id_relacionada)) "R05005" -- Codigo localidad
--           , ( SELECT lot_no
--               FROM ic_lots_mst
--               WHERE lot_id = c.lot_id
--               AND item_id  = c.item_id )                                                   "R05006" -- Codigo de Camapania
--           , DECODE(lb.tipo_liquidacion_relacionada,'1116A',TO_CHAR(la.fecha_liquidacion,'YYYYMMDD')
--                                                   ,'1116RT',TO_CHAR(lrt.fecha_liquidacion,'YYYYMMDD'))  "R05007" -- Fecha Cierre
--           , DECODE(lb.tipo_liquidacion_relacionada,'1116A', (SELECT SUM((xcp.peso_bruto_recepcion - xcp.tara_recepcion)
--                                                                                                 - xcp.merma_humedad
--                                                                                                 - xcp.merma_zaranda
--                                                                                                 - xcp.merma_volatil)
--                                                                                      FROM XX_ACO_CARTAS_PORTE_V      xcp,
--                                                                                               (SELECT xbl.boletin_header_id,
--                                                                                                             xcp.carta_porte_id,
--                                                                                                             'B' tipo_boletin
--                                                                                                   FROM XX_ACO_CARTAS_PORTE_V    xcp,
--                                                                                                             XX_ACO_BOLETIN_HEADERS   xbh,
--                                                                                                             XX_ACO_BOLETIN_LINES         xbl
--                                                                                                 WHERE xcp.carta_porte_id       = xbl.carta_porte_id
--                                                                                                      AND xcp.org_id                  = xcp.org_id_from
--                                                                                                      AND xbh.boletin_header_id = xbl.boletin_header_id
--                                                                                                      AND xbh.anulado_flag        = 'N'
--                                                                                                   UNION ALL
--                                                                                                  SELECT xgbl.grupo_boletin_header_id,
--                                                                                                              xcp.carta_porte_id,
--                                                                                                              'G'  tipo_boletin
--                                                                                                    FROM XX_ACO_CARTAS_PORTE_V           xcp,
--                                                                                                             XX_ACO_GRP_BOLETIN_HEADERS    xgbh,
--                                                                                                             XX_ACO_GRP_BOLETIN_LINES         xgbl,
--                                                                                                             XX_ACO_BOLETIN_LINES                 xbl
--                                                                                                 WHERE xcp.carta_porte_id = xbl.carta_porte_id
--                                                                                                     AND xcp.org_id                             = xcp.org_id_from
--                                                                                                     AND xgbl.boletin_header_id           = xbl.boletin_header_id
--                                                                                                     AND xgbl.grupo_boletin_header_id  = xgbh.grupo_boletin_header_id
--                                                                                                     AND xgbh.anulado_flag                  = 'N' ) xbc
--                                                                                     WHERE 1=1
--                                                                                          AND xbc.boletin_header_id = la.boletin_header_id
--                                                                                          AND xbc.tipo_boletin         = la.tipo_boletin
--                                                                                          AND xbc.carta_porte_id      = xcp.carta_porte_id
--                                                                                          AND xcp.org_id                 = xcp.org_id_to)
--                                                   ,'1116RT',lrt.peso_transferido)          "R05008"
--      FROM xx_aco_liquidaciones_1116b  lb
--         , xx_aco_liquidaciones_1116a  la
--         , xx_aco_liquidaciones_1116rt lrt
--         , xx_aco_contratos            c
--      WHERE 1=1
--      AND c.contrato_id           = lb.contrato_id
--      AND la.liquidacion_id   (+) = lb.liquidacion_id_relacionada
--      AND lrt.liquidacion_id  (+) = lb.liquidacion_id_relacionada
--      AND lb.tipo_liquidacion    <> 'AJUSTE_UNICO'
--      AND lb.liquidacion_id       = p_liq_id
--      UNION
--      SELECT DECODE(SUBSTR(la.numero_liquidacion,1,2),'33',332
--                                                     ,5)                                 "R05001" -- Tipo Certificado Desposito
--           , replace(la.numero_liquidacion, '-','')                                      "R05002" -- Numero Certificado
--           , lc.peso_a_liquidar                                                          "R05003" -- Peso Neto
--           , to_number(la.procedencia_localidad)                                         "R05004" -- Codigo localidad procedencia
--           , to_number(la.procedencia)                                                   "R05005" -- Provincia Procedenci
--           , ( SELECT lot_no
--               FROM ic_lots_mst
--               WHERE lot_id = c.lot_id
--               AND item_id  = c.item_id )                                                "R05006" -- Codigo de Camapania
--           , to_char(la.fecha_liquidacion,'YYYYMMDD')                                    "R05007" -- Fecha Cierre
--           , lc.peso_total_certif                                                        "R05008"
--      FROM xx_aco_liquidaciones_1116b  lb
--         , xx_aco_liq_1116b_certif     lc
--         , xx_aco_liquidaciones_1116a  la
--         , xx_aco_contratos            c
--      WHERE 1=1
--      AND c.contrato_id           = lb.contrato_id
--      AND lc.liquidacion_1116b_id = lb.liquidacion_id
--      AND la.liquidacion_id       = lc.liquidacion_1116a_id
--      AND lb.tipo_liquidacion     = 'AJUSTE_UNICO'
--      AND nvl(lc.peso_a_liquidar, 0) <> 0
--      AND lb.liquidacion_id       = p_liq_id;
      SELECT DECODE(SUBSTR(xc.numero_liquidacion,1,2),'33', 332, 5)             "R05001" -- Tipo Certificado Desposito
           , REPLACE(xc.numero_liquidacion, '-','')                             "R05002" -- Numero Certificado
           , xtcl.peso_a_liquidar                                               "R05003" -- Peso Neto
           , TO_NUMBER(xc.procedencia_localidad)                                "R05004" -- Codigo localidad procedencia
           , TO_NUMBER(xc.procedencia)                                          "R05005" -- Provincia Procedenci
           , xc.lot_no                                                          "R05006" -- Codigo de Camapania
           , TO_CHAR(xc.fecha_liquidacion,'YYYYMMDD')                           "R05007" -- Fecha Cierre
           , xtcl.peso_total_certificado                                        "R05008"
        FROM XX_TCG_LIQUIDACIONES           lb
           , XX_TCG_CERTIFICADOS_LIQUIDADOS xtcl
           , (SELECT xla.liquidacion_id
                   , xla.numero_liquidacion
                   , xla.procedencia_localidad
                   , xla.procedencia
                   , ilm.lot_no
                   , xla.fecha_liquidacion
                FROM XX_ACO_LIQUIDACIONES_1116A xla
                   , XX_ACO_CONTRATOS           xac
                   , IC_LOTS_MST                ilm
               WHERE xla.contrato_id = xac.contrato_id
                 AND xac.item_id     = ilm.item_id
                 AND xac.lot_id      = ilm.lot_id
               UNION
              SELECT xtla.liquidacion_id
                   , xtla.numero_liquidacion
                   , xtla.localidad_origen_code
                   , xtla.provincia_origen_code
                   , xtla.lot_number
                   , xtla.fecha_liquidacion
                FROM XX_TCG_LIQUIDACIONES_1116A xtla)  xc
       WHERE lb.liquidacion_id       = xtcl.liquidacion_id
         AND lb.tipo_liquidacion     IN ( 'UNICA'
                                        , 'AJUSTE_UNICO')
         AND nvl(xtcl.peso_a_liquidar, 0) <> 0
         AND xtcl.certificado_id     = xc.liquidacion_id
         AND lb.liquidacion_id       = p_liq_id;



    CURSOR cRec070 (p_liq_id NUMBER) IS
      SELECT amld.xx_ar_retencion_flag                                          "R07001" -- Codigo Concepto
           , SUBSTR(aml.name,1,30)                                              "R07002" -- Detalle Aclaratorio
           , DECODE(amld.xx_ar_retencion_flag
                   , 'AL', DECODE(lb.dias_almacenaje
                                 , NULL, NULL
                                 , 0, NULL
                                 , lb.dias_almacenaje))                         "R07003" -- Dias Almacenaje
           , DECODE(amld.xx_ar_retencion_flag
                   , 'AL', DECODE(lb.dias_almacenaje
                                 , NULL, NULL
                                 , 0, NULL
                                 , ls.importe / lb.dias_almacenaje))            "R07004" -- Precio por KG diario
           , DECODE(amld.xx_ar_retencion_flag,'CO', ls.coe_porc_servicio,NULL)  "R07005" -- Comision Gastos Administrativos
           , DECODE(amld.xx_ar_retencion_flag,'OD', ls.importe
                                             ,'AL', DECODE(lb.dias_almacenaje
                                                          , NULL, ls.importe
                                                          , 0, ls.importe
                                                          , NULL)
                                             , NULL )                           "R07006" -- Base
           , (SELECT avt.tax_rate
                FROM AR_VAT_TAX_ALL avt
               WHERE avt.tax_code = aml.attribute9
                 AND avt.org_id   = aml.org_id )                                "R07007" -- Alicuota de IVA
           , NULL                                                               "R07008" -- Importe Deduccion
           , NULL                                                               "R07009" -- Importe IVA Deduccion
           , 'D'                                                                "R07010" -- Indica Credito/Debito Ajuste
           , lb.tipo_liquidacion
           , lb.precio_ref_conv
           , amld.xx_ar_retencion_flag                                          codigo_concepto
           , ls.importe
           , lb.peso_neto_liquidado
        FROM XX_TCG_LIQUIDACIONES          lb
           , XX_TCG_LIQUIDACION_SERVICIOS  ls
           , AR_MEMO_LINES_ALL_VL          aml
           , AR_MEMO_LINES_ALL_B_DFV       amld
       WHERE 1=1
         AND ls.liquidacion_id (+)   = lb.liquidacion_id
         AND aml.memo_line_id  (+)   = ls.memo_line_id
         AND aml.row_id              = amld.row_id (+)
         AND nvl(ls.envia_afip,'Y') != 'N'
         AND lb.liquidacion_id       = p_liq_id;



    CURSOR cRec080 (p_liq_id NUMBER) IS
      SELECT DISTINCT DECODE(lr.awt_type_code, 'RIB'  , 'IB'
                                             , 'RIIBB', 'IB'
                                             , 'RIVA' , 'RI'
                                             , 'RGAN' , 'RG'
                                             , 'OG')                            "R08001" -- Codigo concepto
           , SUBSTR(lr.tax_description,1,50)                                    "R08002" -- Detalle aclaratorio
           , lr.monto                                                           "R08003" -- Base Calculo
           , tr.tax_rate                                                        "R08004" -- Alicuota
           , NULL                                                               "R08005" -- Numero certificado retencion
           , NULL                                                               "R08006" -- Fecha certificado retencion
           , NULL                                                               "R08007" -- Importe certificado retencion
           , NULL                                                               "R08008" -- Importe Retencion
           , 'D'                                                                "R08009" -- Indica Credito/Debito Ajuste
           , (lr.monto_retencion * -1)                                          monto_retencion
       FROM XX_TCG_LIQUIDACIONES           lb
          , XX_TCG_LIQUIDACION_RETENCIONES lr
          , AP_AWT_TAX_RATES_ALL           tr
          , HR_ORGANIZATION_INFORMATION    hoi
          , AP_TERMS_TL                    atl
          , AP_TERMS_TL_DFV                atld
      WHERE lb.liquidacion_id             = lr.liquidacion_id
        AND lr.tax_name                   = tr.tax_name
        AND lb.organization_id            = hoi.organization_id
        AND hoi.org_information_context   = 'Accounting Information'
        AND hoi.org_information3          = tr.org_id
        AND atl.rowid                     = atld.row_id
        AND atl.attribute_category        = 'AR'
        AND atl.language                  = userenv('LANG')
        AND atl.term_id                   = lb.ap_term_id
        AND NVL(xx_validacion_canje, 'N') = 'N'
        AND (lr.awt_type_code             IN ('RIVA','RGAN')
            OR (lr.awt_type_code          NOT IN ('RIVA','RGAN')
                AND lr.monto_retencion    <> 0))
        AND lr.envia_afip                 = 'Y'
        AND TRUNC(SYSDATE)                BETWEEN NVL(tr.start_date, TRUNC(SYSDATE))
                                              AND NVL(tr.end_date, TRUNC(SYSDATE))
        AND lb.liquidacion_id             = p_liq_id;



    CURSOR cRec140 (p_liq_id NUMBER) IS
--      SELECT 'ACTIVIDAD'                                                                   "R14001",
--            'Actividad: ' || RPAD(' ', 26) || xap.actividad || ': ' || flv.description    "R14002"
--     FROM xx_aco_parametros_compania  xap,
--          fnd_lookup_values           flv,
--          xx_aco_liquidaciones_1116b  xlb,
--          ic_whse_mst                 iwm,
--          sy_orgn_mst                 som
--     WHERE xap.actividad = flv.lookup_code
--     AND xlb.whse_code   = iwm.whse_code
--     AND iwm.orgn_code   = som.orgn_code
--     AND flv.lookup_type = 'XX_ACO_ACTIVIDAD_ONCCA'
--     AND flv.language    = USERENV('LANG')
--     AND xap.co_code     = som.co_code
--     AND xlb.liquidacion_id = p_liq_id
--     UNION
--     SELECT 'LUGAREMISION'                                                      "R14001",
--            DECODE(NVL(FND_PROFILE.VALUE('XX_ACO_PLANTA_FORMULARIOS'),'N'),
--                   'Y',(SELECT DECODE(flvv.description,
--                                      NULL,(SELECT lc_city.meaning company_city
--                                            FROM ic_whse_mst            iwm,
--                                                 hr_organization_units  hou,
--                                                 hr_locations_all       hlv,
--                                                 hr_locations_all_dfv   hrld,
--                                                 fnd_lookups            lc_city
--                                            WHERE whse_code             = xlb.whse_code
--                                            AND iwm.mtl_organization_id = hou.organization_id
--                                            AND hou.location_id         = hlv.location_id
--                                            AND hlv.rowid               = hrld.row_id
--                                            AND lc_city.lookup_type     = 'JLZZ_CITY'
--                                            AND lc_city.lookup_code(+)  = hrld.city),
--                                      flvv.description)
--                        FROM xx_aco_parametros_compania  xap,
--                             fnd_lookup_values           flv,
--                             xx_aco_liquidaciones_1116b  xlb,
--                             ic_whse_mst                 iwm,
--                             sy_orgn_mst                 som,
--                             sy_orgn_mst_vl              somv,
--                             fnd_lookup_values_vl        flvv
--                        WHERE xap.actividad       = flv.lookup_code
--                        AND xlb.whse_code         = iwm.whse_code
--                        AND iwm.orgn_code         = som.orgn_code
--                        AND flv.lookup_type       = 'XX_ACO_ACTIVIDAD_ONCCA'
--                        AND flv.language          = USERENV('LANG')
--                        AND xap.co_code           = som.co_code
--                        AND somv.orgn_code(+)     = xap.planta_formularios
--                        AND somv.attribute5       = flvv.lookup_code (+)
--                        AND flvv.lookup_type(+)   = 'XX_ACO_LOCALIDADES_ONCCA'
--                        AND NVL(flvv.start_date_active,SYSDATE - 1) <= SYSDATE
--                        AND NVL(flvv.end_date_active,SYSDATE + 1) >= SYSDATE
--                        AND flvv.enabled_flag (+) = 'Y'
--                        AND xlb.liquidacion_id    = xlb2.liquidacion_id)
--                  ,(SELECT lc_city.meaning company_city
--                    FROM ic_whse_mst            iwm,
--                         hr_organization_units  hou,
--                         hr_locations_all       hlv,
--                         hr_locations_all_dfv   hrld,
--                         fnd_lookups            lc_city
--                    WHERE whse_code             = xlb2.whse_code
--                    AND iwm.mtl_organization_id = hou.organization_id
--                    AND hou.location_id         = hlv.location_id
--                    AND hlv.rowid               = hrld.row_id
--                    AND lc_city.lookup_type     = 'JLZZ_CITY'
--                    AND lc_city.lookup_code(+)  = hrld.city))                   "R14002"
--     FROM xx_aco_liquidaciones_1116b xlb2
--     WHERE xlb2.liquidacion_id = p_liq_id;
      SELECT 'ACTIVIDAD'                                                        "R14001"
           , 'Actividad: ' || RPAD(' ', 26) || xpc.actividad || ': '
             || flv.description                                                 "R14002"
        FROM XX_TCG_LIQUIDACIONES        xlb
           , HR_ORGANIZATION_INFORMATION hoi
           , XX_TCG_PARAMETROS_COMPANIA  xpc
           , FND_LOOKUP_VALUES           flv
       WHERE xlb.organization_id         = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND hoi.org_information3        = xpc.operating_unit
         AND xpc.actividad               = flv.lookup_code
         AND flv.lookup_type             = 'XX_ACO_ACTIVIDAD_ONCCA'
         AND flv.language                = USERENV('LANG')
         AND xlb.liquidacion_id          = p_liq_id
       UNION
      SELECT 'LUGAREMISION'                                                     "R14001"
           , DECODE(hld.city, NULL, (SELECT loc_nombre
                                       FROM XX_TCG_LOCALIDADES
                                      WHERE loc_codigo     = hld.localidad
                                        AND pr_dpto_codigo = hld.province)
                            , hld.city)                                         "R14002"
        FROM XX_TCG_LIQUIDACIONES   xlb
           , HR_ORGANIZATION_UNITS  hou
           , HR_LOCATIONS_ALL       hl
           , HR_LOCATIONS_ALL_DFV   hld
       WHERE xlb.organization_id = hou.organization_id
         AND hou.location_id     = hl.location_id
         AND hl.rowid            = hld.row_id
         AND xlb.liquidacion_id  = p_liq_id;



    CURSOR cLines ( p_liq_id NUMBER) IS
      SELECT lb.numero_liquidacion
           , lbl.peso_liquidado
           , lb.precio_operacion_funcional
           , ((lb.peso_neto_liquidado * lb.porcentaje_parcial * lb.precio_operacion_funcional) / 100) as monto_liquidado
           , lb.porcentaje_parcial
           , lb.precio_referencia
        FROM (SELECT liquidacion_id
                   , numero_liquidacion
                   , ROUND(precio_oper_conv, FND_PROFILE.VALUE ('XX_ACO_PRECIO_OPER_DEC'))  precio_operacion_funcional
                   , peso_neto_liquidado
                   , porcentaje_parcial
                   , precio_referencia
                FROM XX_ACO_LIQUIDACIONES_1116B
               UNION
              SELECT liquidacion_id
                   , numero_liquidacion
                   , ROUND(precio_oper_conv, FND_PROFILE.VALUE ('XX_ACO_PRECIO_OPER_DEC'))  precio_operacion_funcional
                   , peso_neto_liquidado
                   , porcentaje_parcial
                   , precio_referencia
                FROM XX_TCG_LIQUIDACIONES)  lb
           , XX_TCG_LIQUIDACION_LINES       lbl
       WHERE lb.liquidacion_id = lbl.liquidacion_id_parcial
         AND lbl.liquidacion_id = p_liq_id;



    rLiqToSend2             cLiqToSend2%RowType;
    l_instance              VARCHAR2(30);
    l_out                   UTL_FILE.file_type;
    l_out_dir               VARCHAR2(500);
    l_out_dir_copy          VARCHAR2(500);
    l_fname                 VARCHAR2(200);
    l_cuit                  VARCHAR2(20);
    l_pto_emision           NUMBER;
    l_nro_orden             NUMBER;
    l_liq_id                NUMBER;
    l_grado                 NUMBER;
    l_grado_cr              VARCHAR2(5);
    l_factor_calidad        NUMBER;
    l_factor_grado          NUMBER;
    l_contenido_proteico    NUMBER;
    l_com_gastos            NUMBER;
    l_cancelado             VARCHAR2(1);
    l_coe                   VARCHAR2(20);
    l_coe_aju               VARCHAR2(20);
    l_result                BOOLEAN;
    l_errmsg                VARCHAR2(2000);
    l_mml_parcial           VARCHAR2(100);
    l_imp_parcial           NUMBER;
    l_cuit_planex           VARCHAR2(30);
    l_cuit_productor        VARCHAR2(30);
    l_certificado           VARCHAR2(30);
    l_completa_reg          VARCHAR2(1) := 'N';
    l_coe_precio_operacion  NUMBER;
    l_coe_subtotal          NUMBER;
    l_bonif_desc            NUMBER;
    l_pendiente             NUMBER;
    l_alicuota_iva          NUMBER;
    l_coe_iva               NUMBER;
    l_coe_operacion_iva     NUMBER;
    l_coe_retencion         NUMBER;
    l_coe_total_retencion   NUMBER;
    l_coe_total_neto        NUMBER;
    l_coe_total_pago        NUMBER;
    l_coe_final_test        VARCHAR2(30);
    l_coe_importe_deduccion NUMBER;
    l_coe_importe_iva_deduccion NUMBER;
    l_coe_total_deduccion   NUMBER;
    l_coe_total_deducciones NUMBER;
    l_err_cod035            NUMBER;
    l_R01006                VARCHAR2(5);
    l_tipo_origen           VARCHAR2(50);
    l_R080_propio           VARCHAR2(100);
    l_calidad               VARCHAR2(200);
    l_concepto_105          VARCHAR2(200);
    l_importe_15_105        NUMBER;
    l_importe_16_105        NUMBER;
    l_concepto_21           VARCHAR2(200);
    l_importe_15_21         NUMBER;
    l_importe_16_21         NUMBER;
    l_coe_iva_chr           VARCHAR2(100);
    l_completa_1516         VARCHAR2(50);
    e_ErrorPtoEmision       EXCEPTION;
    e_Error000              EXCEPTION;
    e_RowLocked             EXCEPTION;
    l_vendor_name           VARCHAR2(240);
    l_codigo_acceso         VARCHAR2(240);
    l_liquidacion_id number;



    CURSOR cRecCGRT000 (p_tipo_liq VARCHAR2, p_liq_id NUMBER) IS
      SELECT LPAD(liquidacion_id,8,0)                        "R00001"          --nroInterno
           , punto_emision_liq                               "R00003"          --ptoEmision
           , numero_orden_liq                                "R00004"           --nroOrden
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE '1116A'        = p_tipo_liq
         AND liquidacion_id = p_liq_id
     UNION
      SELECT LPAD(liquidacion_id,8,0)                        "R00001",
             punto_emision_liq                               "R00003",
             numero_orden_liq                                "R00004"
        FROM XX_TCG_RT
       WHERE '1116RT'       = p_tipo_liq
         AND liquidacion_id = p_liq_id
         ;



    CURSOR cRecCGRT011 (p_org_id NUMBER) IS
      SELECT global_attribute11 || global_attribute12                  "R01101"           --CUIT
        FROM HR_ALL_ORGANIZATION_UNITS haou,
             HR_LOCATIONS_ALL          hl
       WHERE haou.location_id     = hl.location_id
         AND haou.organization_id = p_org_id;



    CURSOR cRecCGRT030 (p_contrato_id NUMBER) IS
      SELECT 'S'                                                     "R03001"   --Actua corredor
           , aps.num_1099 ||aps.global_attribute12                   "R03003"   --CUIT Corredor
           , SUBSTR(aps.vendor_name,1,200)                           "R03006"   -- Razon Social Corredor
        FROM XX_TCG_CONTRATOS_COMPRA xtcc
           , AP_SUPPLIERS            aps
       WHERE xtcc.corredor_id = aps.vendor_id
         AND xtcc.contrato_id = p_contrato_id;


    CURSOR cRecCGRT040 (p_liq_id NUMBER) IS
      SELECT aml.name||': '||xtll.importe                            "R04001"    --Servicios que no sean de Secada o Zaranda
           -- CR1062
           , 1 orden
        FROM XX_TCG_LIQUIDACION_1116A_LINES  xtll
           , AR_MEMO_LINES_ALL_TL            aml
           , XX_TCG_LIQUIDACIONES_1116A      xtla
           , HR_ORGANIZATION_INFORMATION     hoi
       WHERE xtll.memo_line_id           = aml.memo_line_id
         AND aml.language                = USERENV('LANG')
         AND xtll.liquidacion_id         = xtla.liquidacion_id
         AND xtla.organization_id        = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND xtll.importe                > 0                                    -- Agregado CR961
         AND aml.memo_line_id   IN (SELECT amlv.memo_line_id
                                      FROM AR_MEMO_LINES_ALL_VL          amlv
                                         , AR_MEMO_LINES_ALL_B_DFV       amld
                                         , FINANCIALS_SYSTEM_PARAMS_ALL  fsp
                                     WHERE amlv.org_id          = hoi.org_information3
                                       AND fsp.org_id           = amlv.org_id
                                       AND amlv.set_of_books_id = fsp.set_of_books_id
                                       AND amlv.row_id          = amld.row_id
                                       AND NVL(amld.xx_aco_liquidacion_1116a,'N') = 'Y'
                                       AND UPPER(amlv.name)     NOT LIKE '%SECAD%'
                                       AND UPPER(amlv.name)     NOT LIKE '%ZARAND%')
         AND xtla.liquidacion_id         = p_liq_id
       UNION                                                                    --Agregado CR1062
       SELECT NVL(category_descripcion, tax_code) ||': '|| SUM(monto_percepcion) --TK986
            , 2
         FROM XX_TCG_LIQUIDACION1116A_PERCEP
        WHERE liquidacion_id = p_liq_id
          AND tax_category   NOT LIKE 'VAT%'
        GROUP BY NVL(category_descripcion, tax_code)
        ORDER BY 2, 1;



    CURSOR cRecCGRT090 (p_liq_id NUMBER, p_tipo_liq VARCHAR2) IS
      SELECT TO_NUMBER(REPLACE(numero_liquidacion,'-',''))     "R09014"         -- Nro COE
           , TO_CHAR(fecha_liquidacion,'YYYYMMDD')             "R09002"         --Fecha Liquidacion/Certificado
        FROM XX_TCG_LIQUIDACIONES_1116A
       WHERE liquidacion_id = p_liq_id
         AND '1116A'        = p_tipo_liq
       UNION
      SELECT TO_NUMBER(REPLACE(numero_liquidacion,'-',''))
           , TO_CHAR(fecha_liquidacion,'YYYYMMDD')
        FROM XX_TCG_RT
       WHERE liquidacion_id = p_liq_id
         AND '1116RT'       = p_tipo_liq
         ;

    CURSOR cRecCGRT150 (p_organization_id NUMBER) IS
      SELECT SUBSTR(SUBSTR(aps.vendor_name,1,DECODE(INSTR(aps.vendor_name,' '),0,LENGTH(aps.vendor_name)
                   ,INSTR(aps.vendor_name,' ')-1)), 1,20)         "R15001"        -- Codigo clasificatorio del emisor
           , (aps.num_1099 || aps.global_attribute12)                 CUIT_EMISOR
        FROM HR_ORGANIZATION_INFORMATION    hoi
           , XX_TCG_PARAMETROS_COMPANIA     xtpc
           , AP_SUPPLIERS                   aps
       WHERE hoi.organization_id  = p_organization_id
         AND hoi.org_information3 = xtpc.operating_unit
         AND xtpc.vendor_id       = aps.vendor_id;




    CURSOR cRecCGRT200 (p_liq_id NUMBER, p_tipo_liq VARCHAR) IS
      SELECT DISTINCT
             TO_NUMBER(REPLACE(hcdd.xx_ar_nro_ingresos_brutos, '-','')
                      ,'999999999999999')                                          "R20001"     --Numero Ingresos Brutos Depositario
           , DECODE(xtla.contrato_id, NULL, 'P', 'T')                              "R20002"     --Titular Grano
           , SUBSTR(asp.num_1099 || asp.global_attribute12,1,11)                   "R20003"     --Cuit Depositante
           , TO_NUMBER(COALESCE(REPLACE(hcpd.xx_ar_nro_ingresos_brutos, '-', '')
                               ,REPLACE(aspd.xx_ap_numero_iibb, '-', '')
                               ,asp.num_1099||asp.global_attribute12
                               ),'999999999999999')                                "R20004"     --Numero Ingresos Brutos Depositante
           , TO_NUMBER(msid.xx_aco_codigo_oncca,'999')                             "R20005"     --Codigo de Grano
           , TO_NUMBER(xtla.lot_number,'9999')                                     "R20006"     -- Campania
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , XX_TCG_CONTRATOS_COMPRA     xtcc
           , HR_ORGANIZATION_INFORMATION hoi
           , XX_TCG_PARAMETROS_COMPANIA  xtpc
           , HZ_CUST_ACCOUNTS            hcad  -- Depositario
           , HZ_CUST_ACCOUNTS_DFV        hcdd
           , AP_SUPPLIERS                asp
           , PO_VENDORS_DFV              aspd  --dfv que apunta a AP_SUPPLIERS
           , HZ_CUST_ACCOUNTS            hcap
           , HZ_CUST_ACCOUNTS_DFV        hcpd
           , MTL_SYSTEM_ITEMS_B          msi
           , MTL_SYSTEM_ITEMS_B_DFV      msid
       WHERE ((p_tipo_liq <> '1116RT' and xtla.liquidacion_id         = p_liq_id)
                    or
                   (p_tipo_liq =  '1116RT'  and xtla.liquidacion_id  = (select liquidacion_id_certificado from xx_tcg_rt where liquidacion_id = p_liq_id))
                   )
         AND ((xtla.contrato_id            = xtcc.contrato_id
               AND xtcc.productor_id           = asp.party_id)
             OR
              (xtla.contrato_id             IS NULL
               AND xtla.empresa_origen_party_id = asp.party_id ))
         AND xtla.organization_id        = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND hoi.org_information3        = xtpc.operating_unit
         AND xtpc.customer_id            = hcad.cust_account_id
         AND hcad.rowid                  = hcdd.row_id
         AND hcdd.context_value          = 'AR'
         AND asp.party_id                = hcap.party_id
         AND asp.rowid                   = aspd.row_id
         AND hcap.rowid                  = hcpd.row_id
         AND hcpd.context_value          = 'AR'
         AND xtla.inventory_item_id      = msi.inventory_item_id
         AND xtla.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.context                = 'AR'
         AND hcap.status                 = 'A';   -- CR1205

/*      SELECT TO_NUMBER(hcdd.xx_ar_nro_ingresos_brutos,'999999999999999')           "R20001"     --Numero Ingresos Brutos Depositario
           , 'T'                                                                   "R20002"     --Titular Grano
           , SUBSTR(asp.num_1099 || asp.global_attribute12,1,11)                   "R20003"     --Cuit Depositante
           , TO_NUMBER(hcpd.xx_ar_nro_ingresos_brutos,'999999999999999')           "R20004"     --Numero Ingresos Brutos Depositante
           , TO_NUMBER(msid.xx_aco_codigo_oncca,'999')                             "R20005"     --Codigo de Grano
           , TO_NUMBER(xtla.lot_number,'9999')                                     "R20006"     -- Campania
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , XX_TCG_CONTRATOS_COMPRA     xtcc
           , HR_ORGANIZATION_INFORMATION hoi
           , XX_TCG_PARAMETROS_COMPANIA  xtpc
           , HZ_CUST_ACCOUNTS            hcad  -- Depositario
           , HZ_CUST_ACCOUNTS_DFV        hcdd
           , AP_SUPPLIERS                asp
           , HZ_CUST_ACCOUNTS            hcap
           , HZ_CUST_ACCOUNTS_DFV        hcpd
           , MTL_SYSTEM_ITEMS_B          msi
           , MTL_SYSTEM_ITEMS_B_DFV      msid
       WHERE xtla.liquidacion_id         = p_liq_id
         AND xtla.contrato_id            IS NOT NULL
         AND xtla.contrato_id            = xtcc.contrato_id
         AND xtla.organization_id        = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND hoi.org_information3        = xtpc.operating_unit
         AND xtpc.customer_id            = hcad.cust_account_id
         AND hcad.rowid                  = hcdd.row_id
         AND hcdd.context_value          = 'AR'
         AND xtcc.productor_id           = asp.party_id
         AND asp.party_id                = hcap.party_id
         AND hcap.rowid                  = hcpd.row_id
         AND hcpd.context_value          = 'AR'
         AND xtla.inventory_item_id      = msi.inventory_item_id
         AND xtla.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.context                = 'AR'
       UNION
      SELECT TO_NUMBER(hcdd.xx_ar_nro_ingresos_brutos,'999999999999999')           "R20001"     --Numero Ingresos Brutos Depositario
           , 'P'                                                                   "R20002"     --Titular Grano
           , SUBSTR(asp.num_1099 || asp.global_attribute12,1,11)                   "R20003"     --Cuit Depositante
           , TO_NUMBER(hcpd.xx_ar_nro_ingresos_brutos,'999999999999999')           "R20004"     --Numero Ingresos Brutos Depositante
           , TO_NUMBER(msid.xx_aco_codigo_oncca,'999')                             "R20005"     --Codigo de Grano
           , TO_NUMBER(xtla.lot_number,'9999')                                     "R20006"     -- Campania
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , HR_ORGANIZATION_INFORMATION hoi
           , XX_TCG_PARAMETROS_COMPANIA  xtpc
           , HZ_CUST_ACCOUNTS            hcad  -- Depositario
           , HZ_CUST_ACCOUNTS_DFV        hcdd
           , AP_SUPPLIERS                asp
           , HZ_CUST_ACCOUNTS            hcap
           , HZ_CUST_ACCOUNTS_DFV        hcpd
           , MTL_SYSTEM_ITEMS_B          msi
           , MTL_SYSTEM_ITEMS_B_DFV      msid
       WHERE xtla.liquidacion_id          = p_liq_id
         AND xtla.contrato_id             IS NULL
         AND xtla.organization_id         = hoi.organization_id
         AND hoi.org_information_context  = 'Accounting Information'
         AND hoi.org_information3         = xtpc.operating_unit
         AND xtpc.customer_id             = hcad.cust_account_id
         AND hcad.rowid                   = hcdd.row_id
         AND hcdd.context_value           = 'AR'
         AND xtla.empresa_origen_party_id = asp.party_id
         AND asp.party_id                 = hcap.party_id
         AND hcap.rowid                   = hcpd.row_id
         AND hcpd.context_value           = 'AR'
         AND xtla.inventory_item_id       = msi.inventory_item_id
         AND xtla.organization_id         = msi.organization_id
         AND msi.rowid                    = msid.row_id
         AND msid.context                 = 'AR';
*/



    CURSOR cRecCGRT205 (p_liq_id NUMBER) IS
      SELECT TO_NUMBER(xtpc.actividad,'99999')                                  "R20501"   --Numero de Actividad Depositario
           , SUBSTR(flv.description,1,20)                                       "R20502"   --Descripcion del codigo ONCCA
           , TRIM(TO_CHAR(NVL(xtcc.tarifa_almacenaje,0),'99999990D90'))         "R20503"   --Monto Almacenaje
           , TRIM(TO_CHAR(NVL(xtcc.costo_flete,0),'99999990D90'))               "R20504"   --Monto Acarreo
           --, (SELECT TRIM(TO_CHAR(NVL(SUM(NVL(xgg.importe,0)),0),'99999990D90'))
           , (SELECT TRIM(TO_CHAR(NVL(SUM(NVL((xgg.importe/100),0)),0),'99999990D90'))
                FROM XX_TCG_LIQUIDACION_1116A_LINES xgg
               WHERE xgg.liquidacion_id = xtla.liquidacion_id
                 AND xgg.memo_line_id   = xtpc.paritarias_memo_line_id)         "R20505"  -- Monto Gastos Generales
           --, (SELECT TRIM(TO_CHAR(NVL(SUM(NVL(xz.importe,0)),0),'99999990D90'))
           , (SELECT TRIM(TO_CHAR(NVL(SUM(NVL((xz.importe/100),0)),0),'99999990D90'))
                FROM XX_TCG_LIQUIDACION_1116A_LINES xz
               WHERE xz.liquidacion_id = xtla.liquidacion_id
                 AND xz.memo_line_id   = xtpc.zaranda_memo_line_id)             "R20506"   --Monto Zaranda
           , TRIM(TO_CHAR(NVL(xtcc.otros_gastos,0),'99999990D90'))              "R20511"   --Monto Otros
           , (SELECT TRIM(TO_CHAR(SUM(DECODE(kilos_confirmados, NULL, DECODE(NVL(FND_PROFILE.value('XX_ACO_CG_INF_KILOS_BALANZA'),'N'), 'N', 0
                                                                                , 'Y', NVL(merma_volatil,0))
                                                              , DECODE(kilos_confirmados, peso_neto, 0
                                                                      , peso_bruto, NVL(merma_volatil,0)))),'99999990D90'))
                FROM (SELECT xla.liquidacion_id
                           , ctg.kilos_confirmados
                           , XX_TCG_CALIDAD_PKG.Get_merma_volatil (xtbl.carta_porte_id)      as merma_volatil
                           , (xtcp.peso_bruto_recepcion - xtcp.tara_recepcion)                  as peso_bruto
                           , XX_TCG_CALIDAD_PKG.Get_peso_aplicado(xtbl.carta_porte_id) as peso_neto
                        FROM XX_TCG_LIQUIDACIONES_1116A    xla
                           , XX_TCG_BOLETIN_LINES          xtbl
                           , XX_TCG_CARTAS_PORTE_ALL       xtcp
                           , (SELECT  estado                                                                        --CR2272 Se cambia tabla xx_tcg_cartas_porte_ctg por xx_aco_ctgs_b Dic-19
                                      ,  peso_neto_confirmado kilos_confirmados
                                      , nro_carta_porte
                                FROM xx_aco_ctgs_b xctg
                               WHERE estado            = 'CONFIRMACION DEFINITIVA'
                                 )  ctg
                           /* (SELECT DISTINCT carta_porte_id
                                   , accion
                                   , estado
                                   , kilos_confirmados
                                FROM XX_TCG_CARTAS_PORTE_CTG
                               WHERE accion            = 'CONSULTAR_CG'
                                 AND estado            = 'CONFIRMACION DEFINITIVA'
                                 AND kilos_confirmados IS NOT NULL)  ctg*/
                       WHERE xla.boletin_header_id = xtbl.boletin_header_id
                         AND xtbl.carta_porte_id    = xtcp.carta_porte_id
                        AND xtcp.numero_carta_porte    = ctg.nro_carta_porte (+) ) xlcp -- CR2272 Se modifico tabla y join por nro  Dic-19
                       --  AND xtcp.carta_porte_id    = ctg.carta_porte_id (+) ) xlcp           -- CR2272 Se modifico tabla y join por nro Dic-19
               WHERE xlcp.liquidacion_id =  xtla.liquidacion_id)                "R20512"   --Peso neto en kg de merma volatil
           , SUBSTR(rtt.description,1,20)                                       "R20513"   --Forma de pago
           , (SELECT TRIM(TO_CHAR(NVL(SUM(NVL(xso.importe,0)),0),'999990D0'))
                FROM XX_TCG_LIQUIDACION_1116A_LINES    xso
               WHERE xso.liquidacion_id = xtla.liquidacion_id
                 AND xso.memo_line_id NOT IN ( xtpc.secada_memo_line_id
                                             , xtpc.zaranda_memo_line_id))      "R20514"   --Servicios Otros
           , NVL(rtfv.xx_ar_canje,'N') es_canje
           , xtcc.tipo_contrato
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , HR_ORGANIZATION_INFORMATION  hoi
           , XX_TCG_CONTRATOS_COMPRA     xtcc
           , XX_TCG_PARAMETROS_COMPANIA  xtpc
           , RA_TERMS                    rtt
           , RA_TERMS_B_DFV              rtfv
           , MTL_SYSTEM_ITEMS_B          msi
           , MTL_SYSTEM_ITEMS_B_DFV      msid
           , FND_LOOKUP_VALUES           flv
       WHERE xtla.liquidacion_id         = p_liq_id
         AND xtla.contrato_id            = xtcc.contrato_id (+)
         AND xtla.organization_id        = hoi.organization_id
         AND hoi.org_information_context = 'Accounting Information'
         AND hoi.org_information3        = xtpc.operating_unit
         AND xtla.ra_term_id             = rtt.term_id (+)
         AND rtt.row_id                  = rtfv.row_id (+)
         AND xtla.inventory_item_id      = msi.inventory_item_id
         AND xtla.organization_id        = msi.organization_id
         AND msi.rowid                   = msid.row_id
         AND msid.xx_aco_codigo_oncca    = flv.lookup_code
         AND flv.lookup_type             = 'XX_ACO_ESPECIES_ONCCA'
         AND flv.language                = userenv('LANG');




    CURSOR cRecCGRT210 (p_liq_id NUMBER) IS
      SELECT DISTINCT
             numero_ctg                                                        "R21001"           --Numero Codigo de Trazabilidad de Granos
           --, TO_NUMBER(REPLACE(numero_carta_porte,'-',''))                      "R21002"           --Numero Carta de Porte
           , TO_NUMBER(REPLACE(DECODE(SUBSTR(numero_carta_porte,1,4),'9005','0005-'||SUBSTR(numero_carta_porte,6,13)
                                                                    , numero_carta_porte),'-',''))                      "R21002"           --Numero Carta de Porte
           , DECODE(kilos_confirmados, NULL, DECODE(NVL(FND_PROFILE.value('XX_ACO_CG_INF_KILOS_BALANZA'),'N'), 'N', TRIM(TO_CHAR(peso_neto,'99999990D90'))
                                                                                                             , 'Y', TRIM(TO_CHAR(peso_bruto,'99999990D90')))
                                     , kilos_confirmados)                       "R21003"           --Peso Neto Confirmado Definitivo
           , DECODE(kilos_confirmados, NULL, DECODE(NVL(FND_PROFILE.value('XX_ACO_CG_INF_KILOS_BALANZA'),'N'), 'N', TRIM(to_char(0,'990D90'))
                                                                                                             --, 'Y', TRIM(TO_CHAR(porcentaje_humedad,'990D90')))  CR1062
                                                                                                             , 'Y', TRIM(TO_CHAR(NVL(porcentaje_humedad,0),'990D90')))
                                     , DECODE(kilos_confirmados, peso_neto, TRIM(to_char(0,'990D90'))
                                                               , peso_bruto, TRIM(TO_CHAR(porcentaje_humedad,'990D90'))))
                                                                                "R21004"           --Porcentaje Secado humedad
           , DECODE(porcentaje_humedad, 0, TRIM(TO_CHAR(0,'99999990D90'))
                                      --, TRIM(TO_CHAR(peso_bruto * tarifa_secado /100, '99999990D90')))  CR1062
                                      , TRIM(TO_CHAR(peso_bruto * NVL(tarifa_secado,0) /100, '99999990D90')))
                                                                                "R21005"           --Importe Secado
           , DECODE(kilos_confirmados, NULL, DECODE(NVL(FND_PROFILE.value('XX_ACO_CG_INF_KILOS_BALANZA'),'N'), 'N', TRIM(to_char(0,'990D90'))
                                                                                                             --, 'Y', TRIM(TO_CHAR(merma_humedad,'99999990D90'))) CR1062
                                                                                                             , 'Y', TRIM(TO_CHAR(NVL(merma_humedad, 0),'99999990D90')))
                                     , DECODE(kilos_confirmados, peso_neto, TRIM(to_char(0,'990D90'))
                                                               , peso_bruto, TRIM(TO_CHAR(merma_humedad,'99999990D90'))))
                                                                                "R21006"           --Peso neto merma secado
           --, TRIM(TO_CHAR(tarifa_secado,'99999990D90'))                         "R21007"           --Tarifa Secada      CR1062
           , TRIM(TO_CHAR(NVL(tarifa_secado, 0),'99999990D90'))                         "R21007"           --Tarifa Secada
           , DECODE(porcentaje_zaranda, 0, TRIM(TO_CHAR(0,'99999990D90'))
                                      , TRIM(TO_CHAR(peso_bruto * NVL(tarifa_zaranda,0)/100,'99999990D90')))
                                                                                "R21008"          --Importe Zarandeo,
           , DECODE(kilos_confirmados, NULL, DECODE(NVL(FND_PROFILE.value('XX_ACO_CG_INF_KILOS_BALANZA'),'N'), 'N', TRIM(TO_CHAR(0,'990D90'))
                                                                                                             --, 'Y', TRIM(TO_CHAR(merma_zaranda,'99999990D90'))) CR1062
                                                                                                             , 'Y', TRIM(TO_CHAR(NVL(merma_zaranda, 0),'99999990D90')))
                                     , DECODE(kilos_confirmados, peso_neto, TRIM(TO_CHAR(0,'990D90'))
                                                               , peso_bruto, TRIM(TO_CHAR(merma_zaranda,'99999990D90'))))
                                                                                "R21009"           --Peso Neto Merma Zarandeo
           --, TRIM(TO_CHAR(tarifa_zaranda,'99999990D90'))                        "R21010"           --Tarifa Zarandeo    CR1062
           , TRIM(TO_CHAR(NVL(tarifa_zaranda, 0),'99999990D90'))                        "R21010"           --Tarifa Zarandeo
           , DECODE(fecha_confirmacion, NULL, fecha_recepcion
                                      , fecha_confirmacion)                     "R21011"           --Fecha Codigo Trazabilidad de Granos
           , es_canje
        FROM (SELECT DECODE(ctg.ctg_numero,NULL,xtcp.ctg_numero,ctg.ctg_numero)        as numero_ctg
                   , xtcp.numero_carta_porte
                   , (xtcp.peso_bruto_recepcion - xtcp.tara_recepcion)                  as peso_bruto
                   , XX_TCG_CALIDAD_PKG.Get_peso_aplicado(xtbl.carta_porte_id)          as peso_neto
                   , NVL(xtcp.pctaje_humedad_recep,0)                                   as porcentaje_humedad
                   , NVL(xtcp.pctaje_zaranda_recep,0)                                   as porcentaje_zaranda
                   , XX_TCG_CALIDAD_PKG.Get_Merma_Humedad(xtcp.carta_porte_id)          as merma_humedad
                   , xtga.secada_tarifa                                                 as tarifa_secado
                   , XX_TCG_CALIDAD_PKG.Get_Merma_Zaranda(xtcp.carta_porte_id)          as merma_zaranda
                   , xtga.zaranda_tarifa                                                as tarifa_zaranda
                   , TRIM(TO_CHAR(ctg.kilos_confirmados,'99999990D90'))                 as kilos_confirmados
                   , TO_CHAR(ctg.fecha_operacion,'YYYYMMDD')                            as fecha_confirmacion
                   , TO_CHAR(xtcp.fecha_recepcion,'YYYYMMDD')                           as fecha_recepcion
                   , DECODE(xtla.ra_term_id, NULL, NULL
                                           ,(SELECT NVL(rtfv.xx_ar_canje,'N')
                                               FROM RA_TERMS          rt
                                                  , RA_TERMS_B_DFV    rtfv
                                              WHERE rt.row_id   = rtfv.row_id
                                                AND rt.term_id  = xtla.ra_term_id))     as  es_canje
                FROM XX_TCG_LIQUIDACIONES_1116A      xtla
                   , XX_TCG_BOLETIN_LINES            xtbl
                   , XX_TCG_CARTAS_PORTE_ALL         xtcp
                   , XX_TCG_GASTO_ACONDICIONAMIENTO  xtga
                 /*  , (SELECT DISTINCT carta_porte_id   --CR2272 Se cambia tabla xx_tcg_cartas_porte_ctg por xx_aco_ctgs_b Feb-20
                           , kilos_confirmados
                           , fecha_operacion
                           , ctg_numero
                        FROM XX_TCG_CARTAS_PORTE_CTG
                       WHERE accion            = 'CONSULTAR_CG'
                         AND estado            = 'CONFIRMACION DEFINITIVA'
                         AND kilos_confirmados IS NOT NULL )  ctg*/
                      , ( SELECT  peso_neto_confirmado kilos_confirmados
                                      , fecha_confirmacion fecha_operacion
                                      , nro_ctg ctg_numero
                                      , nro_carta_porte                                    
                            FROM xx_aco_ctgs_b xctg
                          WHERE estado            = 'CONFIRMACION DEFINITIVA'                                 
                         )  ctg                       --CR2272 Fin Se cambia tabla xx_tcg_cartas_porte_ctg por xx_aco_ctgs_b Feb-20          
               WHERE xtla.boletin_header_id = xtbl.boletin_header_id
                 AND xtbl.carta_porte_id    = xtcp.carta_porte_id
                 AND xtcp.carta_porte_id    = xtga.carta_porte_id (+)
                 AND xtcp.numero_carta_porte    = ctg.nro_carta_porte (+)  -- CR2272 cambio carta_porte_id por numero Feb-20
                 AND xtla.liquidacion_id     = p_liq_id
               ORDER BY xtcp.carta_porte_id);


    CURSOR cRecCGRT215 (p_liq_id NUMBER) IS
      SELECT xtla.boletin_header_id
           , xtbh.numero_boletin                                                "R21501"          --Analisis de muestra //r12 se reemplaza por el nro de boletin
                                                                                                  -- dado que no se puede enviar nulo
           , xtbh.numero_boletin                                                "R21502"          --Numero de Boletin
           , NULL                                                               "R21503"          --Valor de grado
           , TRIM(TO_CHAR(NVL(XX_TCG_CALIDAD_PKG.get_cont_proteico_boletin(xtbh.boletin_header_id),0),'990D990'))   "R21504"   --Valor del contenido proteico
           , TRIM(TO_CHAR(XX_TCG_CALIDAD_PKG.get_factor_boletin(xtbh.boletin_header_id) ,'990D990'))                "R21505"   --Valor de factor
           , DECODE(xtla.grado_calidad, NULL, NULL
                                     ,'G'||xtla.grado_calidad)                  "R21506"          --Grado entregado
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , XX_TCG_BOLETIN_HEADERS      xtbh
       WHERE 1 = 1
         AND xtla.boletin_header_id = xtbh.boletin_header_id
         AND xtbh.estado            = 'ANALIZADO'
         AND xtla.liquidacion_id    = p_liq_id;



    CURSOR cRecCGRT220 (p_boletin_id NUMBER) IS
      SELECT flv.description                                                    "R22001"           --Descrpcion Rubro
           , DECODE(porcentaje_descuento, NULL, 'B', 'R')                       "R22002"           --Tipo Rubro
           , TRIM(TO_CHAR(DECODE(porcentaje_descuento, NULL
                   , porcentaje_bonificacion
                   , porcentaje_descuento),'999990D90'))                        "R22003"           --Porcentaje
           , TRIM(TO_CHAR(valor,'990D90'))                                      "R22004"           --Valor
        FROM XX_ACO_VALORES_MUESTRA   xvm
           , XX_TCG_BOLETIN_HEADERS   xtbh
           , FND_LOOKUP_VALUES        flv
       WHERE xvm.boletin_header_id = xtbh.boletin_header_id
         AND xvm.boletin_header_id = p_boletin_id
         AND (xvm.porcentaje_descuento IS NOT NULL OR
              xvm.porcentaje_bonificacion IS NOT NULL)
         AND flv.lookup_type       = 'XX_ACO_CONCEPTOS_MUESTRA'
         AND flv.language          = userenv('LANG')
         AND xtbh.estado           = 'ANALIZADO'
         AND flv.lookup_code       = xvm.codigo_concepto;



    CURSOR cRecCGRT230 (p_liq_id NUMBER,
                        p_org_id NUMBER) IS
      SELECT xlr.actividad                                   "R23001"           --Numero de Actividad Depositario
           , null         "R23002"           --Cuit Receptor de granos se comentó ac.taxpayer_id||ac.global_attribute12
           , TO_NUMBER(REPLACE(numero_carta_porte,'-',''))   "R23003"           --Numero de la carta de porte a utilizar
        FROM XX_TCG_RT  xlr
           , XX_TCG_RT_LINES      xll
           , XX_TCG_CARTAS_PORTE       xcp
--           , (SELECT hca.cust_account_id   customer_id
--                   , hp.jgzz_fiscal_code  taxpayer_id
--                   , hca.global_attribute12
--                FROM HZ_PARTIES  hp
--                   , HZ_CUST_ACCOUNTS hca
--               WHERE hca.party_id = hp.party_id)       ac
       WHERE xlr.tipo_liquidacion           = 'RETIRO'
         AND xlr.liquidacion_id             = xll.liquidacion_id
         AND xll.carta_porte_id             = xcp.carta_porte_id
 --        AND xcp.customer_id                = ac.customer_id
         AND xlr.liquidacion_id             = p_liq_id
       UNION
      SELECT xlr.actividad
           , pv.num_1099||pv.global_attribute12
           , NULL
        FROM XX_TCG_RT  xlr
           , AP_SUPPLIERS                 pv
       WHERE xlr.tipo_liquidacion           = 'TRANSFERENCIA'
         AND xlr.receptor_party_id         = pv.party_id
         AND xlr.liquidacion_id             = p_liq_id;



    CURSOR cRecCGRT235 (p_liq_id NUMBER) IS
      SELECT TO_NUMBER(REPLACE(xla.numero_liquidacion,'-',''))   "R23501"           --COE Certificado Deposito
           , DECODE(xlrt.tipo_liquidacion, 'TRANSFERENCIA', xlrt.peso_transferido
                   , 'RETIRO', (SELECT SUM(NVL(peso_retiro,0))
                                  FROM XX_TCG_RT_LINES
                                 WHERE liquidacion_id = xlrt.liquidacion_id  ))
                                                             "R23502"           --Peso Neto
        FROM XX_TCG_RT xlrt
                   , XX_TCG_LIQUIDACIONES_1116A  xla
               WHERE xlrt.liquidacion_id_certificado   = xla.liquidacion_id
                 AND xlrt.liquidacion_id               = p_liq_id
                    ;

    CURSOR cRecCGRT240 (p_liq_id       NUMBER) IS
      SELECT DECODE(xtla.estab_destino_codigo_oncca --TK986
                   , NULL, (SELECT ctg.establecimiento
                            FROM xx_aco_ctgs_b           ctg
                               , (SELECT MIN(cp.ctg_numero) ctg_numero
                                  FROM xx_tcg_boletin_headers  bh
                                     , xx_tcg_boletin_lines    bl
                                     , xx_tcg_cartas_porte_all cp
                                  WHERE 1=1
                                  AND bl.boletin_header_id = bh.boletin_header_id
                                  AND cp.carta_porte_id    = bl.carta_porte_id
                                  AND bh.boletin_header_id = xtla.boletin_header_id
                                 ) cp
                            WHERE ctg.nro_ctg = cp.ctg_numero)
                   , xtla.estab_destino_codigo_oncca
                   )                                                            "R24001"   --Numero Planta
           , 5                                                                  "R24002"   --Tipo Certificado Deposito Preexistente
           , TO_NUMBER(REPLACE(xtla.numero_preexistente,'-',''))                "R24003"   --Numero Certificado Deposito Preexistente
           , xatd.numero_cac                                                    "R24004"   --CEE Certificado Deposito Preexistente
           , TO_CHAR(xtla.fecha_liquidacion,'YYYYMMDD')                         "R24005"   --Fecha Emision Certificado Deposito Preexistente
           , kgs_saldo_preexistente                                             "R24006"   --Peso Neto
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , XX_OPM_ADMIN_TALONARIOS     xat
           , XX_OPM_ADMIN_TALONARIOS_DFV xatd
       WHERE xtla.numero_preexistente IS NOT NULL
         AND xat.source_code         = '1116A'
         AND xat.talonario_nro       = TO_NUMBER(SUBSTR(xtla.numero_preexistente,1,4))
         AND TO_NUMBER(SUBSTR(xtla.numero_preexistente,6,8)) BETWEEN xat.talon_desde
                                                                 AND xat.talon_hasta
         AND xat.rowid               = xatd.row_id
         AND xtla.liquidacion_id      = p_liq_id;



    CURSOR cRecCGRT250 (p_boletin_id NUMBER) IS
      SELECT SUM(xtcp.peso_bruto_recepcion - xtcp.tara_recepcion)               "R25002",   -- peso_bruto,
             SUM(XX_TCG_CALIDAD_PKG.Get_merma_volatil (xtbl.carta_porte_id))    "R25003",   -- peso_merma_volatil
             SUM(XX_TCG_CALIDAD_PKG.Get_Merma_humedad(xtcp.carta_porte_id))     "R25004",   -- peso_merma_humedad
             SUM(XX_TCG_CALIDAD_PKG.Get_Merma_Zaranda(xtcp.carta_porte_id))     "R25005",   -- peso_merma_zaranda
             SUM(XX_TCG_CALIDAD_PKG.Get_peso_aplicado(xtbl.carta_porte_id))     "R25006",   -- peso_neto
             SUM(xtga.secada_importe)                                           "R25007",   -- servicio_secada
             SUM(xtga.zaranda_importe)                                          "R25008",   -- servicio_zarandeo,
             SUM(0)                                                             "R25009"    -- servicio_otros
        FROM XX_TCG_BOLETIN_LINES            xtbl
           , XX_TCG_CARTAS_PORTE_ALL         xtcp
           , XX_TCG_GASTO_ACONDICIONAMIENTO  xtga
       WHERE xtbl.carta_porte_id    = xtcp.carta_porte_id
         AND xtcp.carta_porte_id    = xtga.carta_porte_id
         AND xtbl.boletin_header_id = p_boletin_id;



    l_org_id            NUMBER;
    l_porc_rango_inf    NUMBER;
    l_porc_rango_sup    NUMBER;
    l_tarifa            NUMBER;
    l_tarifa_exceso     NUMBER;
    l_cod_clasif_emisor VARCHAR2(20);
    l_cuit_emisor       VARCHAR2(30);
    l_estado_boletin    VARCHAR2(30);
    l_svcs_adic         VARCHAR2(2000);
    l_user_id           NUMBER;
    l_resp_id           NUMBER;
    l_resp_appl_id      NUMBER;
    l_etapa             VARCHAR2(200);
    e_ErrorCGRT         EXCEPTION;
    l_tipo_liq          VARCHAR2(10);
    l_R09002            VARCHAR2(20);
    l_R09014            VARCHAR2(20);
    l_co_code           VARCHAR2(10);
    l_org_code          VARCHAR2(10);
    l_metodo            VARCHAR2(5);
    rLiqToSendCGRT      cLiqToSendCGRT%ROWTYPE;
    l_procedencia       VARCHAR2(240);
    l_localidad_oncca   VARCHAR2(240);
    e_ErrorCGRT_ACO     EXCEPTION;


    l_percep_iva        NUMBER;
    l_otras_percep      NUMBER;
    l_no_gravados       NUMBER;
    l_cant_fc           NUMBER;
    l_cant_lineas       NUMBER;
    l_merma_header_id   NUMBER;
    l_get_param_secada  BOOLEAN;



  BEGIN

    l_etapa := 'Inicio y perfiles';

    SELECT name
      INTO l_instance
      FROM v$Database;

    BEGIN

      SELECT pov.profile_option_value
        INTO l_cuit_planex
        FROM FND_PROFILE_OPTIONS_VL        po
           , FND_PROFILE_OPTION_VALUES     pov
       WHERE 1=1
         AND po.profile_option_name = 'XX_ACO_COE_CUIT_PLANEX'
         AND pov.application_id     = po.application_id
         AND pov.profile_option_id  = po.profile_option_id;

    EXCEPTION
      WHEN No_Data_Found THEN
        l_cuit_planex := NULL;
    END;


    BEGIN

      SELECT pov.profile_option_value
        INTO l_cuit_productor
        FROM FND_PROFILE_OPTIONS_VL        po
           , FND_PROFILE_OPTION_VALUES     pov
       WHERE 1=1
         AND po.profile_option_name = 'XX_ACO_COE_CUIT_PRODUCTOR'
         AND pov.application_id     = po.application_id
         AND pov.profile_option_id  = po.profile_option_id;

    EXCEPTION
      WHEN No_Data_Found THEN
        l_cuit_productor := NULL;
    END;


    BEGIN

      SELECT pov.profile_option_value
        INTO l_certificado
        FROM FND_PROFILE_OPTIONS_VL        po
           , FND_PROFILE_OPTION_VALUES     pov
       WHERE 1=1
         AND po.profile_option_name = 'XX_ACO_COE_CERTIFICADO'
         AND pov.application_id     = po.application_id
         AND pov.profile_option_id  = po.profile_option_id;

    EXCEPTION
      WHEN No_Data_Found THEN
        l_certificado := NULL;
    END;


    BEGIN

      SELECT pov.profile_option_value
        INTO l_completa_reg
        FROM FND_PROFILE_OPTIONS_VL        po
           , FND_PROFILE_OPTION_VALUES     pov
       WHERE 1=1
         AND po.profile_option_name = 'XX_ACO_COE_COMPLETA_REG'
         AND pov.application_id     = po.application_id
         AND pov.profile_option_id  = po.profile_option_id;

    EXCEPTION
      WHEN No_Data_Found THEN
        l_completa_reg := NULL;
    END;



    p_cant_reg := 0;
    p_err_msg  := NULL;

    FOR rLiqToSend IN cLiqToSend LOOP

      IF (rLiqToSend.tipo_liq='1116A_ACO') THEN

        XX_ACO_WEBSERVICES_PK.Envia_archivo( p_cant_reg  => p_cant_reg
                                           , p_err_msg   => p_err_msg);

        IF (p_err_msg IS NULL) THEN
          GOTO Proxima_liquidacion;
        ELSE
          RAISE e_ErrorCGRT_ACO;
        END IF;

      END IF;

      SELECT DECODE(rLiqToSend.tipo_liq,'1116B',DECODE(name,'PADAGI','/ua1001/fs_ne/ADECO/interface/outgoing/XX_ACO_COE/BKP'
                                                                    ,'/ua1001/fs_ne/ADECO/interface/incoming/XX_ACO_COE/BKP')
                                       ,DECODE(name,'PADAGI','/ua1001/fs_ne/ADECO/interface/outgoing/XX_ACO_CG/BKP'
                                                            ,'/ua1001/fs_ne/ADECO/interface/incoming/XX_ACO_CG/BKP'))
--                                                   , DECODE(l_completa_reg,'N','/interface/infadagi/'||name||'/outgoing/XX_ACO_CG/BKP'
--                                                                          ,'Y','/interface/infadagi/'||name||'/incoming/XX_ACO_CG/BKP')))
--                                                   , DECODE(l_completa_reg,'N',SUBSTR(FND_PROFILE.value('XX_ACO_PATH_CG_SND'),1,LENGTH(FND_PROFILE.value('XX_ACO_PATH_CG_SND'))-4)||'/BKP'
--                                                                          ,'Y',SUBSTR(FND_PROFILE.value('XX_ACO_PATH_CG_RCV'),1,LENGTH(FND_PROFILE.value('XX_ACO_PATH_CG_RCV'))-4)||'/BKP')))
      INTO l_out_dir_copy
      FROM v$Database;


      SELECT commit_user_id
           , resp_id
           , resp_appl_id
        INTO l_user_id
           , l_resp_id
           , l_resp_appl_id
        FROM (SELECT commit_user_id
                   , resp_id
                   , resp_appl_id
                FROM XX_TCG_LIQUIDACIONES
               WHERE liquidacion_id      = rLiqToSend.liquidacion_id
                 AND rLiqToSend.tipo_liq = '1116B'
               UNION
              SELECT commit_user_id
                   , resp_id
                   , resp_appl_id
                FROM XX_TCG_LIQUIDACIONES_1116A
               WHERE liquidacion_id      = rLiqToSend.liquidacion_id
                 AND rLiqToSend.tipo_liq = '1116A'
               UNION
              SELECT commit_user_id
                   , resp_id
                   , resp_appl_id
                FROM XX_TCG_RT
               WHERE liquidacion_id      = rLiqToSend.liquidacion_id
                 AND rLiqToSend.tipo_liq = '1116RT');


      IF Check_Row ( p_tipo_liq => rLiqToSend.tipo_liq
                   , p_liq_id   => rLiqToSend.liquidacion_id
                   , p_err_msg  => p_err_msg ) THEN

        -- Punto de Emision
        Get_Punto_Emision ( p_liquidacion_id    => rLiqToSend.liquidacion_id
                          , p_tipo_liquidacion  => rLiqToSend.tipo_liq
                          , p_punto_emision     => l_pto_emision
                          , p_result            => l_result
                          , p_error_msg         => l_errmsg);

        IF (NOT l_result) OR
          (l_pto_emision IS NULL) THEN

          IF (NOT l_result) THEN
            p_err_msg := 'Get_Punto_Emision -> Error obteniendo el punto de emision. '||l_errmsg;
          ELSIF (l_pto_emision IS NULL) THEN
            p_err_msg := 'Get_Punto_Emision -> No se encuentra el punto de emision.';
          END IF;

          IF (rLiqToSend.tipo_liq = '1116B') THEN

            Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                         , p_tipo_coe  => ''
                         , p_ret_val1  => 'SND 20001'
                         , p_ret_val2  => p_err_msg
                         , p_cancelado => 'N'
                         , p_err_msg   => l_errmsg
                         );
            RAISE e_ErrorPtoEmision;

          ELSIF (rLiqToSend.tipo_liq IN ('1116A','1116RT')) THEN

            OPEN cLiqToSendCGRT ( rLiqToSend.liquidacion_id
                                , rLiqToSend.tipo_liq);
            FETCH cLiqToSendCGRT INTO rLiqToSendCGRT;
            CLOSE cLiqToSendCGRT;

            Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                              , p_tipo_liq  => rLiqToSend.tipo_liq
                              , p_tipo_coe  => rLiqToSendCGRT.metodo
                              , p_ret_val1  => 'CGRT'
                              , p_ret_val2  => p_err_msg
                              , p_cancelado => rLiqToSend.cancelado_flag
                              , p_err_msg   => l_errmsg);

            RAISE e_ErrorCGRT;

          END IF;

        END IF;


       --Numero de Orden
        IF (rLiqToSend.tipo_liq = '1116B') THEN

          Get_Nro_Orden_LPG ( p_liquidacion_id  => rLiqToSend.liquidacion_id
                            , p_actualizar      => FALSE
                            , p_numero_orden    => l_nro_orden
                            , p_result          => l_result
                            , p_error_msg       => l_errmsg);

          IF (NOT l_result)
            OR (l_nro_orden IS NULL) THEN

            IF (NOT l_result) THEN
              p_err_msg := 'Get_Nro_Orden_LPG -> Error obteniendo el nro de orden. '||l_errmsg;
            ELSIF (l_nro_orden IS NULL) THEN
              p_err_msg := 'Get_Nro_Orden_LPG -> No es posible encontrar el siguiente numero de orden.';
            END IF;

            Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                         , p_tipo_coe  => ''
                         , p_ret_val1  => 'SND 20001'
                         , p_ret_val2  => p_err_msg
                         , p_cancelado => 'N'
                         , p_err_msg   => l_errmsg
                         );
            RAISE e_ErrorPtoEmision;
          END IF;

        ELSE

          Get_Nro_Orden_CGRT ( p_liquidacion_id   => rLiqToSend.liquidacion_id
                             , p_tipo_liquidacion => rLiqToSend.tipo_liq
                             , p_actualizar       => FALSE
                             , p_numero_orden     => l_nro_orden
                             , p_result           => l_result
                             , p_error_msg        => l_errmsg);


          IF (NOT l_result) OR
            (l_nro_orden IS NULL) THEN

            IF (NOT l_result) THEN
              p_err_msg := 'Get_Nro_Orden_CGRT -> Error obteniendo el nro de orden. '||l_errmsg;
            ELSIF (l_nro_orden IS NULL) THEN
              p_err_msg := 'Get_Nro_Orden_CGRT -> No es posible encontrar el siguiente numero de orden.';
            END IF;

            Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                              , p_tipo_liq  => rLiqToSend.tipo_liq
                              , p_tipo_coe  => rLiqToSendCGRT.metodo
                              , p_ret_val1  => 'CGRT'
                              , p_ret_val2  => p_err_msg
                              , p_cancelado => rLiqToSend.cancelado_flag
                              , p_err_msg   => l_errmsg);

            RAISE e_ErrorCGRT;

          END IF;

        END IF;



        IF (rLiqToSend.tipo_liq = '1116B') THEN


          SELECT pov.profile_option_value
            INTO l_out_dir
            FROM FND_PROFILE_OPTIONS_VL        po
               , FND_PROFILE_OPTION_VALUES     pov
           WHERE 1=1
             AND po.profile_option_name = 'XX_ACO_PATH_COE_SND'
             AND pov.application_id     = po.application_id
             AND pov.profile_option_id  = po.profile_option_id;



          OPEN cLiqToSend2 ( rLiqToSend.liquidacion_id
                           , rLiqToSend.operating_unit);
          FETCH cLiqToSend2 INTO rLiqToSend2;
          CLOSE cLiqToSend2;


          l_cancelado := rLiqToSend2.cancelado_flag;
          l_coe       := rLiqToSend2.coe;

          IF (l_completa_reg = 'Y') THEN

            SELECT '/ua1001/fs_ne/ADECO/interface/incoming/XX_ACO_COE/RCV'
              INTO l_out_dir
              FROM v$Database;

            l_coe_total_deducciones := 0;
            l_coe_total_retencion   := 0;

            IF (l_cancelado = 'N') THEN
              l_fname := rLiqToSend2.cuit||'_'||l_pto_emision||'_'||l_nro_orden||'_'||rLiqToSend2.nro_liq_interno||'_9999.txt';
            ELSE
              l_fname := rLiqToSend2.cuit||'_'||rLiqToSend2.pto_emision||'_'||rLiqToSend2.nro_orden||'_'||rLiqToSend2.nro_liq_interno||'_9999.txt';
            END IF;

          ELSE

            IF (l_cancelado = 'N') THEN
              l_fname := rLiqToSend2.cuit||'_'||l_pto_emision||'_'||l_nro_orden||'_'||rLiqToSend2.nro_liq_interno||'.txt';
            ELSE
              l_fname := rLiqToSend2.cuit||'_'||rLiqToSend2.pto_emision||'_'||rLiqToSend2.nro_orden||'_'||rLiqToSend2.nro_liq_interno||'.txt';
            END IF;

          END IF;


          l_out := UTL_FILE.Fopen_Nchar (l_out_dir, l_fname, 'W', 32767);

          IF (l_cancelado = 'N') THEN

            FOR rRec000 IN cRec000 (rLiqToSend.liquidacion_id) LOOP

              IF (rRec000.R00006  IS NULL) OR
                (rRec000.R00007  IS NULL) OR
                (rRec000.R00008  IS NULL) OR
                (rRec000.R00009  IS NULL) OR
                (rRec000.R00010  IS NULL) OR
                (rRec000.R00012  IS NULL) THEN

                UTL_FILE.fclose (l_out);
                UTL_FILE.fremove(l_out_dir, l_fname);

                p_err_msg := l_fname||' -> Rec000 -> Los datos del comprador no pueden estar incompletos.';

                Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                             , p_tipo_coe  => ''
                             , p_ret_val1  => 'Rec000'
                             , p_ret_val2  => p_err_msg
                             , p_cancelado => 'N'
                             , p_err_msg   => l_errmsg
                             );

                RAISE e_Error000;

              END IF;


              IF (l_instance = 'PADAGI' OR
                 l_cuit_planex IS NULL) THEN
                 l_cuit_planex := rRec000.R00006;
              END IF;

              UTL_FILE.Put_Line_Nchar (l_out, '000'
                                      ||';'|| rRec000.R00001
                                      ||';'|| rRec000.R00002
                                      ||';'|| lpad(l_pto_emision, 4, 0)
                                      ||';'|| l_nro_orden
                                      ||';'|| rRec000.R00005
                                      ||';'|| l_cuit_planex               -- rRec000.R00006    -- CUIT Comprador
                                      ||';'|| rRec000.R00007
                                      ||';'|| rRec000.R00008
                                      ||';'|| rRec000.R00009
                                      ||';'|| rRec000.R00010
                                      ||';'|| rRec000.R00011
                                      ||';'|| rRec000.R00012
                                      ||';'|| rRec000.R00013
                                      ||';'|| rRec000.R00014
                                      ||';'|| rRec000.R00015
                                       );

              l_vendor_name := rRec000.R00007;


            END LOOP;

            FOR rRec010 IN cRec010 (rLiqToSend.liquidacion_id) LOOP

              l_grado          := rLiqToSend2.grado;
              l_factor_grado   := rLiqToSend2.factor_grado;
              l_factor_calidad := rLiqToSend2.factor_calidad;

              SELECT DECODE(to_char(l_grado), NULL, NULL, 0, NULL, 'G'||l_grado)
                INTO l_grado_cr
                FROM DUAL;

              IF (rLiqToSend2.tipo_liquidacion = 'PARCIAL') THEN
                l_factor_calidad := 100;
              END IF;

              l_alicuota_iva := rRec010.R01015;

              -- Para salvar el error al enviar liquidaciones con codigo de grano 035
              BEGIN

                SELECT count(1)
                  INTO l_err_cod035
                  FROM (SELECT xtcl.liquidacion_id
                          FROM XX_TCG_CERTIFICADOS_LIQUIDADOS  xtcl
                             , XX_TCG_LIQUIDACION_ERRORES_COE  xtle
                         WHERE xtcl.liquidacion_id <> rLiqToSend.liquidacion_id
                           AND xtcl.liquidacion_id = xtle.liquidacion_id
                           AND xtle.codigo         = '1404'
                           AND xtcl.certificado_id IN (SELECT certificado_id
                                                         FROM XX_TCG_CERTIFICADOS_LIQUIDADOS   -- Certificados no usado en su totalidad que pueden
                                                        WHERE peso_a_liquidar        > 0       -- existir en otra liquidacion de Granos
                                                          AND peso_total_certificado <> peso_a_liquidar
                                                          AND liquidacion_id         = rLiqToSend.liquidacion_id)
                         UNION
                        SELECT xalc.liquidacion_1116b_id
                          FROM XX_ACO_LIQ_1116B_CERTIF       xalc
                             , XX_ACO_LIQ_1116B_COE_ERRORES  xale
                         WHERE xalc.liquidacion_1116b_id <> rLiqToSend.liquidacion_id
                           AND xalc.liquidacion_1116b_id = xale.liquidacion_id
                           AND xale.codigo               = '1404'
                           AND xalc.liquidacion_1116a_id IN (SELECT certificado_id
                                                               FROM XX_TCG_CERTIFICADOS_LIQUIDADOS   -- Certificados no usado en su totalidad que pueden
                                                              WHERE peso_a_liquidar        > 0       -- existir en otra liquidacion de Granos
                                                                AND peso_total_certificado <> peso_a_liquidar
                                                                AND liquidacion_id         = rLiqToSend.liquidacion_id)
                         UNION
                        SELECT xalb.liquidacion_id
                          FROM XX_ACO_LIQUIDACIONES_1116B    xalb
                             , XX_ACO_LIQ_1116B_COE_ERRORES  xale
                         WHERE xalb.tipo_liquidacion_relacionada = '1116A'
                           AND xalb.liquidacion_id               <> rLiqToSend.liquidacion_id
                           AND xalb.liquidacion_id               = xale.liquidacion_id
                           AND xale.codigo                       = '1404'
                           AND xalb.liquidacion_id_relacionada   IN (SELECT certificado_id
                                                                       FROM XX_TCG_CERTIFICADOS_LIQUIDADOS   -- Certificados no usado en su totalidad que pueden
                                                                      WHERE peso_a_liquidar        > 0       -- existir en otra liquidacion de Granos
                                                                        AND peso_total_certificado <> peso_a_liquidar
                                                                        AND liquidacion_id         = rLiqToSend.liquidacion_id)
                       );

              EXCEPTION
                WHEN Others THEN
                  l_err_cod035 := 0;
              END;

              IF (l_err_cod035 > 0) THEN
                l_R01006 := '035';
              ELSE
                l_R01006 := rRec010.R01006;
              END IF;


              l_localidad_oncca := rRec010.R01017;
              l_procedencia     := rRec010.R01018;


              IF (rRec010.tipo_liquidacion = 'UNICA'  -- Puede suceder que la unica no este asociada a un Contrato
                AND (l_localidad_oncca IS NULL
                     OR l_procedencia IS NULL)) THEN
                BEGIN

                  SELECT xla.provincia_origen_code
                       , xla.localidad_origen_code
                    INTO l_procedencia
                       , l_localidad_oncca
                    FROM (SELECT liquidacion_id
                               , provincia_origen_code
                               , localidad_origen_code
                            FROM XX_TCG_LIQUIDACIONES_1116A
                           UNION
                          SELECT liquidacion_id
                               , procedencia
                               , procedencia_localidad
                            FROM XX_ACO_LIQUIDACIONES_1116A) xla
                   WHERE xla.liquidacion_id = (SELECT MIN(xtcl.certificado_id)
                                                 FROM XX_TCG_CERTIFICADOS_LIQUIDADOS xtcl
                                                WHERE xtcl.liquidacion_id = rLiqToSend.liquidacion_id);

                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;

              END IF;


              IF (rRec010.tipo_liquidacion = 'AJUSTE_UNICO') THEN

                IF (rRec010.metodo_liq = 'L') THEN

                  UTL_FILE.Put_Line_Nchar (l_out, '010'
                                          ||';'                                 --rRec010.R01001
                                          ||';'                                 --rRec010.R01002
                                          ||';'                                 --rRec010.R01003
                                          ||';'                                 --rRec010.R01004
                                          ||';'                                 --rRec010.R01005
                                          ||';'|| l_R01006                      --rRec010.R01006
                                          ||';'                                 --rRec010.R01007
                                          ||';'                                 --rRec010.R01008
                                          ||';'                                 --rRec010.R01009
                                          ||';'                                 --l_grado_cr
                                          ||';'                                 --rRec010.R01011
                                          ||';'                                 --round(l_factor_calidad,3)
                                          ||';'                                 --rRec010.R01013
                                          ||';'                                 --nvl(l_contenido_proteico, 0)
                                          ||';'                                 --rRec010.R01015
                                          ||';'                                 --rRec010.R01016
                                          ||';'|| l_localidad_oncca             --rRec010.R01017
                                          ||';'|| l_procedencia                 --rRec010.R01018
                                          ||';'                                 --rRec010.R01019
                                          ||';'                                 --rRec010.R01020
                                          ||';'                                 --rRec010.R01021
                                          ||';'                                 --rRec010.R01022
                                          ||';'                                 --rRec010.R01023
                                          ||';'                                 --rRec010.R01024
                                          ||';'                                 --rRec010.R01025
                                          ||';'                                 --rRec010.R01026
                                          ||';'                                --|| rRec010.R01027
                                          );

                ELSIF (rRec010.metodo_liq = 'C') THEN

                  UTL_FILE.Put_Line_Nchar (l_out, '010'
                                          ||';'                                 --rRec010.R01001
                                          ||';'                                 --rRec010.R01002
                                          ||';'                                 --rRec010.R01003
                                          ||';'|| rRec010.R01004
                                          ||';'|| rRec010.R01005
                                          ||';'|| l_R01006                      -- rRec010.R01006
                                          ||';'                                 --rRec010.R01007
                                          ||';'|| rRec010.R01008
                                          ||';'                                 --rRec010.R01009
                                          ||';'|| rRec010.R01010
                                          ||';'|| rRec010.R01011
                                          ||';'|| rRec010.R01012
                                          ||';'|| rRec010.R01013
                                          ||';'                                 --nvl(l_contenido_proteico, 0)
                                          ||';'                                 --rRec010.R01015
                                          ||';'                                 --rRec010.R01016
                                          ||';'|| l_localidad_oncca             -- rRec010.R01017
                                          ||';'|| l_procedencia                 -- rRec010.R01018
                                          ||';'                                 --rRec010.R01019
                                          ||';'                                 --rRec010.R01020
                                          ||';'                                 --rRec010.R01021
                                          ||';'|| rRec010.R01022
                                          ||';'                                 --rRec010.R01023
                                          ||';'                                 --rRec010.R01024
                                          ||';'                                 --rRec010.R01025
                                          ||';'                                 --rRec010.R01026
                                          ||';'                                 --|| rRec010.R01027
                                           );
                END IF;

              ELSE  -- Unicas, Parciales

                UTL_FILE.Put_Line_Nchar (l_out, '010'
                                        ||';'|| rRec010.R01001
                                        ||';'|| rRec010.R01002
                                        ||';'|| rRec010.R01003
                                        ||';'|| rRec010.R01004
                                        ||';'|| rRec010.R01005
                                        ||';'|| l_R01006                        -- rRec010.R01006
                                        ||';'|| rRec010.R01007
                                        ||';'|| rRec010.R01008
                                        ||';'|| rRec010.R01009
                                        ||';'|| l_grado_cr                      /*"R01010" -- Calidad de grano*/
                                        ||';'|| rRec010.R01011
                                        ||';'|| round(l_factor_calidad,3)       /*"R01012" -- Factor correspondiente al grano entregado*/
                                        ||';'|| rRec010.R01013
                                        ||';'|| nvl(l_contenido_proteico, 0)    /*"R01014" -- Cont Proteico*/
                                        ||';'|| rRec010.R01015
                                        ||';'|| rRec010.R01016
                                        ||';'|| l_localidad_oncca
                                        ||';'|| l_procedencia
                                        ||';'|| rRec010.R01019
                                        ||';'|| rRec010.R01020
                                        ||';'|| rRec010.R01021
                                        ||';'|| rRec010.R01022
                                        ||';'|| rRec010.R01023
                                        ||';'|| rRec010.R01024
                                        ||';'|| rRec010.R01025
                                        ||';'|| rRec010.R01026
                                        ||';'|| rRec010.R01027
                                        );
              END IF;

            END LOOP;



            FOR rRec015 IN cRec015 (rLiqToSend.liquidacion_id) LOOP

              IF (rRec015.metodo_liq = 'L') THEN

                l_concepto_105   := NULL;
                l_importe_15_105 := NULL;
                l_concepto_21    := NULL;
                l_importe_16_21  := NULL;

              ELSIF (rRec015.metodo_liq = 'C') THEN

                IF (rRec015.iva_item = 10.5) THEN

                  SELECT substr(mml.name,1,200) mml
                    INTO l_concepto_105
                    FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
                       , AR_MEMO_LINES_ALL_TL        mml
                   WHERE 1=1
                     AND mml.memo_line_id = xtpc.liq_desc_memo_line_id
                     AND mml.language     = 'ESA'
                     AND mml.org_id       = xtpc.operating_unit
                     AND mml.org_id       = rRec015.org_id;

                  l_importe_15_105 := rRec015.bonif_descuento;
                  l_concepto_21    := NULL;
                  l_importe_15_21  := NULL;

                ELSIF (rRec015.iva_item = 21) THEN

                  SELECT substr(mml.name,1,200) mml
                    INTO l_concepto_21
                    FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
                       , AR_MEMO_LINES_ALL_TL        mml
                   WHERE 1=1
                     AND mml.memo_line_id = xtpc.liq_desc_memo_line2_id
                     AND mml.language     = 'ESA'
                     AND mml.org_id       = rRec015.org_id;

                  l_importe_15_21  := rRec015.bonif_descuento;
                  l_concepto_105   := NULL;
                  l_importe_15_105 := NULL;

                ELSE

                  UTL_FILE.fclose (l_out);
                  UTL_FILE.fremove(l_out_dir, l_fname);

                  p_err_msg := l_fname||' -> Rec015 -> No fue posible evaluar la alicuota.';

                  Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                               , p_tipo_coe  => ''
                               , p_ret_val1  => 'Rec015'
                               , p_ret_val2  => p_err_msg
                               , p_cancelado => 'N'
                               , p_err_msg   => l_errmsg);

                  RAISE e_Error000;

                END IF;

              END IF;


              IF (l_completa_reg = 'Y')
                AND (l_instance <> 'PADAGI') THEN

                l_completa_1516 := ';0;0;0;0;0;0;0;0;0;0;0;0;0;0';

              ELSE
                l_completa_1516 := ';;;;;;;;;;;;;;';

              END IF;

              UTL_FILE.Put_Line_Nchar (l_out, '015'
                                      ||';'|| rRec015.R01501
                                      ||';'|| rRec015.R01502
                                      ||';'|| rRec015.R01503
                                      ||';'|| rRec015.R01504
                                      ||';'|| rRec015.R01505
                                      ||';'|| rRec015.R01506
                                      ||';'|| rRec015.R01507
                                      ||';'|| rRec015.R01508
                                      ||';'|| ABS(rRec015.R01509)
                                      ||';'|| l_concepto_105                    --rRec015.R01510
                                      ||';'|| ABS(l_importe_15_105)             --rRec015.R01511
                                      ||';'|| l_concepto_21                     --rRec015.R01512
                                      ||';'|| ABS(l_importe_15_21)              --rRec015.R01513
                                      ||l_completa_1516);                       --rRec015.R01514-27
            END LOOP;


            FOR rRec016 IN cRec016 (rLiqToSend.liquidacion_id) LOOP

              IF (rRec016.metodo_liq = 'L') THEN

                l_concepto_105   := NULL;
                l_importe_16_105 := NULL;
                l_concepto_21    := NULL;
                l_importe_16_21  := NULL;

              ELSIF (rRec016.metodo_liq = 'C') THEN

                IF (rRec016.iva_item = 10.5) THEN

                  SELECT substr(mml.name,1,200) mml
                    INTO l_concepto_105
                    FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
                       , AR_MEMO_LINES_ALL_TL        mml
                   WHERE 1=1
                     AND mml.memo_line_id = xtpc.liq_bonif_memo_line_id
                     AND mml.language     = 'ESA'
                     AND mml.org_id       = rRec016.org_id;

                  l_importe_16_105 := rRec016.bonif_descuento;
                  l_concepto_21    := NULL;
                  l_importe_16_21  := NULL;

                ELSIF (rRec016.iva_item = 21) THEN

                  SELECT substr(mml.name,1,200) mml
                    INTO l_concepto_21
                    FROM XX_TCG_PARAMETROS_COMPANIA  xtpc
                       , AR_MEMO_LINES_ALL_TL        mml
                   WHERE 1=1
                     AND mml.memo_line_id = xtpc.liq_bonif_memo_line2_id
                     AND mml.language     = 'ESA'
                     AND mml.org_id       = rRec016.org_id;

                  l_importe_16_21  := rRec016.bonif_descuento;
                  l_concepto_105   := NULL;
                  l_importe_16_105 := NULL;

                ELSE

                  UTL_FILE.fclose (l_out);
                  UTL_FILE.fremove(l_out_dir, l_fname);

                  p_err_msg := l_fname||' -> Rec016 -> No fue posible evaluar la alicuota.';

                  Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                               , p_tipo_coe  => ''
                               , p_ret_val1  => 'Rec016'
                               , p_ret_val2  => p_err_msg
                               , p_cancelado => 'N'
                               , p_err_msg   => l_errmsg);

                  RAISE e_Error000;

                END IF;

              END IF;


              IF (l_completa_reg = 'Y')
                AND (l_instance <> 'PADAGI') THEN

                l_completa_1516 := ';0;0;0;0;0;0;0;0;0;0;0;0;0;0';

              ELSE

                l_completa_1516 := ';;;;;;;;;;;;;;';

              END IF;

              UTL_FILE.Put_Line_Nchar (l_out, '016'
                                      ||';'|| rRec016.R01601
                                      ||';'|| rRec016.R01602
                                      ||';'|| rRec016.R01603
                                      ||';'|| rRec016.R01604
                                      ||';'|| rRec016.R01605
                                      ||';'|| rRec016.R01606
                                      ||';'|| rRec016.R01607
                                      ||';'|| rRec016.R01608
                                      ||';'|| rRec016.R01609
                                      ||';'|| l_concepto_105                    --rRec016.R01610
                                      ||';'|| l_importe_16_105                  --rRec016.R01611
                                      ||';'|| l_concepto_21                     --rRec016.R01612
                                      ||';'|| l_importe_16_21                   --rRec016.R01613
                                      ||l_completa_1516);                       --rRec016.R01614-27
            END LOOP;



            FOR rRec020 IN cRec020 (rLiqToSend.liquidacion_id) LOOP

              IF (rRec020.R02001  IS NULL)
                OR (rRec020.R02002  IS NULL)
                OR (rRec020.R02003  IS NULL)
                OR (rRec020.R02004  IS NULL)
                OR (rRec020.R02005  IS NULL)
                OR (rRec020.R02006  IS NULL) THEN

                UTL_FILE.fclose (l_out);
                UTL_FILE.fremove(l_out_dir, l_fname);

                p_err_msg := l_fname||' -> Rec020 -> No fue posible evaluar los datos del vendedor.';

                Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                             , p_tipo_coe  => ''
                             , p_ret_val1  => 'Rec020'
                             , p_ret_val2  => p_err_msg
                             , p_cancelado => 'N'
                             , p_err_msg   => l_errmsg);


                RAISE e_Error000;

              END IF;

              IF (l_instance = 'PADAGI')
                OR (l_cuit_productor IS NULL) THEN
                l_cuit_productor := rRec020.R02001;
              END IF;

              UTL_FILE.Put_Line_Nchar (l_out, '020'
                                      ||';'|| l_cuit_productor                  -- rRec020.R02001  -- cuit productor
                                      ||';'|| rRec020.R02002
                                      ||';'|| rRec020.R02003
                                      ||';'|| rRec020.R02004
                                      ||';'|| rRec020.R02005
                                      ||';'|| rRec020.R02006
                                      ||';'|| rRec020.R02007);
            END LOOP;



            FOR rRec030 IN cRec030 (rLiqToSend.liquidacion_id) LOOP

              UTL_FILE.Put_Line_Nchar (l_out, '030'
                                      ||';'|| rRec030.R03001
                                      ||';'|| rRec030.R03002
                                      ||';'|| rRec030.R03003
                                      ||';'|| rRec030.R03004
                                      ||';'|| rRec030.R03005
                                      ||';'|| rRec030.R03006
                                      ||';'|| rRec030.R03007);
            END LOOP;


            IF (rLiqToSend2.tipo_liquidacion != 'PARCIAL') THEN

              FOR rRec050 IN cRec050 (rLiqToSend.liquidacion_id) LOOP

                UTL_FILE.Put_Line_Nchar (l_out, '050'
                                        ||';'|| rRec050.R05001
                                        ||';'|| rRec050.R05002
                                        ||';'|| rRec050.R05003
                                        ||';'|| rRec050.R05004
                                        ||';'|| rRec050.R05005
                                        ||';'|| rRec050.R05006
                                        ||';'|| rRec050.R05007
                                        ||';'|| rRec050.R05008
                                        );
              END LOOP;

            END IF;


            FOR rRec070 IN cRec070 (rLiqToSend.liquidacion_id) LOOP

              IF (l_completa_reg = 'Y') THEN

                l_coe_importe_deduccion     := rRec070.importe;
                l_coe_importe_iva_deduccion := round(l_coe_importe_deduccion * (rRec070.R07007 / 100), 2); -- imp_deduccon * alicuota iva
                l_coe_total_deduccion       := l_coe_importe_deduccion + l_coe_importe_iva_deduccion;
                l_coe_total_deducciones     := l_coe_total_deducciones + l_coe_total_deduccion;

              ELSE

                l_coe_importe_deduccion     := rRec070.R07006;
                l_coe_total_deduccion       := rRec070.R07008;
                l_coe_importe_iva_deduccion := rRec070.R07009;

              END IF;


              IF (rRec070.R07001 IS NOT NULL) THEN

                UTL_FILE.Put_Line_Nchar (l_out, '070'
                                        ||';'|| rRec070.R07001
                                        ||';'|| rRec070.R07002
                                        ||';'|| rRec070.R07003
                                        ||';'|| rRec070.R07004
                                        ||';'|| rRec070.R07005
                                        ||';'|| l_coe_importe_deduccion         -- rRec070.R07006
                                        ||';'|| rRec070.R07007                  -- Alicuota
                                        ||';'|| l_coe_total_deduccion           -- rRec070.R07008
                                        ||';'|| l_coe_importe_iva_deduccion     --rRec070.R07009);
                                        ||';'|| rRec070.R07010
                                        );
              END IF;

            END LOOP;


            IF (rLiqToSend2.tipo_liquidacion = 'PARCIAL') THEN

              SELECT substr(mml.name,1,30) mml
                INTO l_mml_parcial
                FROM XX_TCG_PARAMETROS_COMPANIA  apc
                   , AR_MEMO_LINES_ALL_TL        mml
               WHERE mml.memo_line_id = apc.liq_pend_final_memo_line_id
                 AND mml.language     = 'ESA'
                 AND mml.org_id       = rLiqToSend.operating_unit;


              l_imp_parcial := rLiqToSend2.imp_bruto_parcial - rLiqToSend2.importe_a_liquidar;

              UTL_FILE.Put_Line_Nchar (l_out, '070;OD;'
                                      || l_mml_parcial
                                      ||';;;;'
                                      || l_imp_parcial
                                      ||';0;;;D');
            END IF;



            FOR rRec080 IN cRec080 (rLiqToSend.liquidacion_id) LOOP

              IF (l_completa_reg = 'Y') THEN
                l_coe_total_retencion := l_coe_total_retencion + rRec080.monto_retencion;
                l_coe_retencion       := rRec080.monto_retencion;
              ELSE
                l_coe_retencion       := rRec080.R08008;
              END IF;


              UTL_FILE.Put_Line_Nchar (l_out, '080'
                                      ||';'|| rRec080.R08001
                                      ||';'|| rRec080.R08002
                                      ||';'|| rRec080.R08003
                                      ||';'|| rRec080.R08004
                                      ||';'|| rRec080.R08005
                                      ||';'|| rRec080.R08006
                                      ||';'|| rRec080.R08007
                                      ||';'|| l_coe_retencion                   -- rRec080.R08008);
                                      ||';'|| rRec080.R08009
                                      );
            END LOOP;



            FOR rRec140 IN cRec140 (rLiqToSend.liquidacion_id) LOOP

              UTL_FILE.Put_Line_Nchar (l_out, '140'
                                      ||';'|| rRec140.R14001
                                      ||';'|| rRec140.R14002
                                      );

            END LOOP;



            BEGIN

              SELECT SUBSTR(SUBSTR(l_vendor_name,1, DECODE(INSTR(l_vendor_name,' '),0,LENGTH(l_vendor_name)
                                                          , INSTR(l_vendor_name,' ')-1))
                           , 1,20)
                INTO l_codigo_acceso
                FROM DUAL;

              UTL_FILE.Put_Line_Nchar (l_out, '150;' ||SUBSTR(l_codigo_acceso,1,20) ||';' );

            EXCEPTION
              WHEN OTHERS THEN
                NULL;

            END;



            BEGIN

              IF (rLiqToSend2.tipo_origen = 'PROPIO') THEN

                l_R080_propio := '080;RG;Ganancias 0%;0;0;;;;;D';
                UTL_FILE.Put_Line_Nchar (l_out, l_R080_propio);

                IF (l_alicuota_iva = 10.5) THEN

                  l_R080_propio := '080;RI;Ret IVA RG SISA Alicuota 5%;0;5;;;;;D';
                  UTL_FILE.Put_Line_Nchar (l_out, l_R080_propio);

                ELSIF (l_alicuota_iva = 21) THEN

                  l_R080_propio := '080;RI;Ret IVA RG SISA Arroz Alicuota 10%;0;10;;;;;';
                  UTL_FILE.Put_Line_Nchar (l_out, l_R080_propio);

                END IF;

              END IF;

            EXCEPTION
              WHEN Others THEN
                NULL;
            END;


            IF (l_completa_reg = 'Y')
              OR (rLiqToSend2.tipo_liquidacion IN ('AJUSTE_UNICO')) THEN

              l_coe_precio_operacion := ROUND(rLiqToSend2.precio_oper_conv, 3);
              l_coe_subtotal         := 0;

              IF (rLiqToSend2.tipo_liquidacion NOT IN ('AJUSTE_UNICO')) THEN

                l_coe_subtotal       := rLiqToSend2.imp_bruto_parcial;
                l_coe_iva            := round(l_coe_subtotal * (l_alicuota_iva / 100), 2);
                l_coe_operacion_iva  := l_coe_iva + l_coe_subtotal;
                l_coe_total_neto     := l_coe_operacion_iva - l_coe_total_deducciones;
                l_coe_total_pago     := l_coe_operacion_iva - l_coe_total_retencion*-1 - l_coe_total_deducciones;

              ELSE

                l_coe_subtotal       := round(rLiqToSend2.bonif_descuento + rLiqToSend2.acopio_pdte_final, 2);
                l_coe_iva            := NULL;
                l_coe_operacion_iva  := NULL;
                l_coe_total_neto     := NULL;
                l_coe_total_pago     := NULL;

              END IF;


              IF (l_coe IS NULL) THEN

                        IF (rLiqToSend2.tipo_comprobante = 'B') THEN
                          l_coe := '3301'||lpad(rLiqToSend2.nro_liq_interno,8,0);
                        ELSE
                          l_coe := '3302'||lpad(rLiqToSend2.nro_liq_interno,8,0);
                        END IF;
              END IF;

              IF (rLiqToSend2.tipo_liquidacion = 'AJUSTE_UNICO') THEN

                l_coe_aju := NULL;

                IF (rLiqToSend2.metodo_liq = 'L') THEN

                  SELECT REPLACE(lb_p.numero_liquidacion,'-','') coe_aju
                    INTO l_coe_aju
                    FROM XX_TCG_LIQUIDACION_LINES     lbl
                       , (SELECT liquidacion_id
                               , numero_liquidacion
                            FROM XX_ACO_LIQUIDACIONES_1116B
                           UNION
                          SELECT liquidacion_id
                               , numero_liquidacion
                            FROM XX_TCG_LIQUIDACIONES ) lb_p
                   WHERE 1=1
                     AND lb_p.liquidacion_id = lbl.liquidacion_id_parcial
                     AND lbl.liquidacion_id  = rLiqToSend.liquidacion_id;

                END IF;

                IF l_completa_reg = 'Y' THEN

                  UTL_FILE.Put_Line_Nchar (l_out, '090'
                                          ||';;;;;;;;;;;;;' -- R09001 - 13
                                          ||';'|| l_coe     -- R09014
                                          ||';'|| l_coe_aju -- R09015
                                          ||';'
                                          ||';'
                                          );
                ELSE

                  UTL_FILE.Put_Line_Nchar (l_out, '090'
                                          ||';;;;;;;;;;;;;' -- R09001 - 13
                                          ||';'             -- R09014
                                          ||';'|| l_coe_aju -- R09015
                                          ||';'
                                          ||';'
                                          );
                END IF;

              ELSIF (rLiqToSend2.tipo_liquidacion != 'AJUSTE_UNICO') THEN

                UTL_FILE.Put_Line_Nchar (l_out, '090'
                                        ||';'|| 0
                                        ||';'
                                        ||';'|| l_coe_precio_operacion
                                        ||';'|| l_coe_subtotal
                                        ||';'|| l_coe_iva
                                        ||';'|| l_coe_operacion_iva
                                        ||';'|| rLiqToSend2.peso_neto
                                        ||';'|| l_coe_total_retencion
                                        ||';'|| l_coe_total_retencion          --  _afip
                                        ||';'|| 0
                                        ||';'|| l_coe_total_neto
                                        ||';'|| 0
                                        ||';'|| l_coe_total_pago
                                        ||';'|| l_coe
                                        ||';'
                                        ||';'|| REPLACE(REPLACE(l_cancelado, 'Y', 'A'), 'N', '')
                                        ||';'|| l_coe_total_deducciones
                                        );

              END IF;

            END IF;


            IF (l_completa_reg = 'Y')
              AND (l_instance <> 'PADAGI') THEN

              l_coe_precio_operacion  := ROUND(rLiqToSend2.precio_oper_conv, 3);
              l_coe_subtotal          := 0;
              l_coe_subtotal          := ROUND(rLiqToSend2.importe_a_liquidar, 2);
              l_coe_iva               := ROUND(l_coe_subtotal * (l_alicuota_iva / 100), 2);

              IF (l_alicuota_iva = 10.5) THEN

                l_coe_iva_chr := l_coe_iva||';';

              ELSIF (l_alicuota_iva = 21) THEN

                l_coe_iva_chr := ';'||l_coe_iva;

              END IF;

              l_coe_operacion_iva     := l_coe_iva + l_coe_subtotal;
              l_coe_total_neto        := l_coe_operacion_iva - l_coe_total_deducciones;
              l_coe_total_pago        := l_coe_operacion_iva - l_coe_total_retencion*-1 - l_coe_total_deducciones;

              UTL_FILE.Put_Line_Nchar (l_out, '095'
                                      ||';'|| l_coe_subtotal
                                      ||';'|| l_coe_iva_chr
                                      ||';'|| 0
                                      ||';'|| l_coe_total_retencion
                                      ||';'|| l_coe_total_neto
                                      ||';'|| 0
                                      ||';'|| l_coe_total_pago
                                      ||';'
                                      ||';'|| l_coe_subtotal
                                      ||';'|| l_coe_total_deducciones
                                      ||';'|| l_coe_importe_iva_deduccion
                                      ||';'|| 0
                                      );

            END IF;



            UTL_FILE.FFlush (l_out);
            UTL_FILE.FCopy (l_out_dir, l_fname, l_out_dir_copy, l_fname);
            UTL_FILE.fclose (l_out);

          ELSE  --Cancelado = Y

            FOR rRec000 IN cRec000 (rLiqToSend.liquidacion_id) LOOP

              IF (rRec000.R00006 IS NULL) THEN

                UTL_FILE.fclose (l_out);
                UTL_FILE.fremove(l_out_dir, l_fname);

                p_err_msg := l_fname||' -> Rec020 -> Los datos del comprador no pueden estar incompletos.';

                Grabar_Error ( p_liq_id    => rLiqToSend.liquidacion_id
                             , p_tipo_coe  => ''
                             , p_ret_val1  => 'Rec020'
                             , p_ret_val2  => p_err_msg
                             , p_cancelado => 'N'
                             , p_err_msg   => l_errmsg);

                RAISE e_Error000;

              END IF;

              IF (l_instance = 'PADAGI')
                OR (l_cuit_planex IS NULL) THEN
                l_cuit_planex := rRec000.R00006;
              END IF;

              UTL_FILE.Put_Line_Nchar (l_out, '000'
                                      ||';'|| rRec000.R00001
                                      ||';'|| rRec000.R00002
                                      ||';'|| rRec000.R00003
                                      ||';'|| l_nro_orden -- rRec000.R00004   CR2272 Dic-19 en la anulaciones tambien debe viajar el último numero de orden
                                      ||';'
                                      ||';'|| l_cuit_planex    --rRec000.R00006
                                      ||';'
                                      ||';'
                                      ||';'
                                      ||';'
                                      ||';'
                                      ||';'
                                      );


              l_vendor_name := rRec000.R00007;


            END LOOP;

            -- CR2272  calcula coe de anualción distinto Dic-19
            if (l_completa_reg = 'Y') then
                    l_coe := '3309'||lpad(rLiqToSend2.nro_liq_interno,8,0);
            end if; -- fin CR2272  Dic-19
            UTL_FILE.Put_Line_Nchar (l_out, '090'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';'
                                    ||';' || l_coe
                                    ||';'
                                    ||';'
                                    ||';'
                                    );


            BEGIN

              SELECT SUBSTR(SUBSTR(l_vendor_name,1,DECODE(INSTR(l_vendor_name,' '),0,LENGTH(l_vendor_name)
                                                         ,INSTR(l_vendor_name,' ')-1))
                           , 1,20)
                INTO l_codigo_acceso
                FROM DUAL;

              UTL_FILE.Put_Line_Nchar (l_out, '150;' ||SUBSTR(l_codigo_acceso,1,20) ||';' );

            EXCEPTION
              WHEN OTHERS THEN
                NULL;

            END;



            UTL_FILE.FFlush (l_out);
            UTL_FILE.FCopy (l_out_dir, l_fname, l_out_dir_copy, l_fname);
            UTL_FILE.fclose (l_out);

          END IF;


          IF (l_completa_reg = 'Y')
            AND (l_instance <> 'PADAGI') THEN

            UPDATE XX_TCG_LIQUIDACIONES
               SET estado_coe             = 'ESP_RESP'
                 , coe_iva_no_gravado     = 0
                 , coe_iva_gravado        = ROUND(l_importe_16_21 * 0.21,2)
                 , coe_iva_diferencial    = ROUND(l_importe_16_105 * 0.105,2)
                 , coe_iva_no_gravado_cr  = 0
                 , coe_iva_gravado_cr     = ROUND(l_importe_15_21 * 0.21,2)
                 , coe_iva_diferencial_cr = ROUND(l_importe_15_105 * 0.105,2)
             WHERE liquidacion_id = rLiqToSend.liquidacion_id;

          ELSE

             UPDATE XX_TCG_LIQUIDACIONES
                SET estado_coe = 'ESP_RESP'
              WHERE liquidacion_id = rLiqToSend.liquidacion_id;

          END IF;


          p_cant_reg := p_cant_reg + 1;

          COMMIT;



        ELSIF (rLiqToSend.tipo_liq IN ('1116A','1116RT')) THEN   -- Certificados CGRT

          l_etapa := 'Inicializacion';

          FND_GLOBAL.Apps_Initialize(l_user_id, l_resp_id, l_resp_appl_id);

          l_etapa := 'Datos comunes';

          OPEN cLiqToSendCGRT ( rLiqToSend.liquidacion_id,
                                rLiqToSend.tipo_liq);
          FETCH cLiqToSendCGRT INTO rLiqToSendCGRT;
          CLOSE cLiqToSendCGRT;

          l_tipo_liq := rLiqToSend.tipo_liq;
          l_liq_id   := rLiqToSend.liquidacion_id;
          l_metodo   := rLiqToSendCGRT.metodo;


          l_etapa := 'cRecCGRT150';

          OPEN cRecCGRT150 (rLiqToSendCGRT.organization_id);
          FETCH cRecCGRT150 INTO l_cod_clasif_emisor
                               , l_cuit_emisor;
          CLOSE cRecCGRT150;


          l_pto_emision := NVL(rLiqToSend.pto_emision,l_pto_emision);
          l_nro_orden   := NVL(rLiqToSendCGRT.nro_orden,l_nro_orden);

          l_etapa := 'Paths de escritura';

          IF (l_completa_reg = 'Y') THEN

            SELECT FND_PROFILE.value('XX_ACO_PATH_CG_RCV')
              INTO l_out_dir
              FROM DUAL;

            l_fname := 'CERT_'||l_cuit_emisor||'_'||l_pto_emision||'_'||l_nro_orden||'_'||rLiqToSend.liquidacion_id||'_9999.txt';

          ELSE

            SELECT FND_PROFILE.value('XX_ACO_PATH_CG_SND')
              INTO l_out_dir
              FROM DUAL;

            l_fname := 'CERT_'||l_cuit_emisor||'_'||l_pto_emision||'_'||l_nro_orden||'_'||rLiqToSend.liquidacion_id||'.txt';


          END IF;


          l_out := UTL_FILE.Fopen_Nchar (l_out_dir, l_fname, 'W', 32767);

          l_etapa := 'rRecCGRT000';

          FOR rRecCGRT000 IN cRecCGRT000  (rLiqToSend.tipo_liq, rLiqToSend.liquidacion_id) LOOP


            IF (l_completa_reg = 'Y') AND (l_instance <> 'PADAGI') AND (rLiqToSendCGRT.metodo<>'IC') THEN


              IF (rLiqToSend.cancelado_flag = 'N') THEN

                UTL_FILE.put_line_nchar (l_out, '000'
                                       ||';'||''
                                       ||';'||''
                                       ||';'|| NVL(rRecCGRT000.R00003,l_pto_emision)
                                       ||';'|| NVL(rRecCGRT000.R00004,l_nro_orden)
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       ||';'||''
                                       );

              ELSE

                UTL_FILE.put_line_nchar (l_out, '000'
                                         ||';'||''
                                         ||';'|| rLiqToSendCGRT.metodo
                                         ||';'|| NVL(rRecCGRT000.R00003,l_pto_emision)
                                         ||';'|| NVL(rRecCGRT000.R00004,l_nro_orden)
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         ||';'||''
                                         );


              END IF;

            ELSIF (l_completa_reg = 'N') THEN

              IF (rLiqToSendCGRT.metodo IS NOT NULL AND
                NVL(rRecCGRT000.R00003,l_pto_emision) IS NOT NULL AND
                NVL(rRecCGRT000.R00004,l_nro_orden) IS NOT NULL) THEN



                UTL_FILE.put_line_nchar (l_out, '000'
                                        ||';'|| rRecCGRT000.R00001
                                        ||';'|| rLiqToSendCGRT.metodo
                                        ||';'|| NVL(rRecCGRT000.R00003,l_pto_emision)
                                        ||';'|| NVL(rRecCGRT000.R00004,l_nro_orden)
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        ||';'||''
                                        );

              ELSE

                UTL_FILE.fclose (l_out);
                UTL_FILE.fremove(l_out_dir, l_fname);

                p_err_msg := l_fname||' -> RecCGRT000 -> Los datos del comprador no pueden estar incompletos.';

                Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                  , p_tipo_liq  => rLiqToSend.tipo_liq
                                  , p_tipo_coe  => ''
                                  , p_ret_val1  => 'RecCGRT000'
                                  , p_ret_val2  => p_err_msg
                                  , p_cancelado => rLiqToSend.cancelado_flag
                                  , p_err_msg   => l_errmsg);

                RAISE e_ErrorCGRT;

              END IF;

            END IF;

          END LOOP;  -- End FOR rRecCGRT000


          l_org_id := rLiqToSend.operating_unit;

          l_etapa := 'rRecCGRT011';

          FOR rRecCGRT011 IN cRecCGRT011 (l_org_id)  LOOP

            IF (l_completa_reg = 'Y') AND (l_instance <> 'PADAGI') AND (rLiqToSendCGRT.metodo='SX') THEN


              UTL_FILE.Put_Line_Nchar (l_out, '011'
                                      ||';'|| rRecCGRT011.R01101
                                      );
            END IF;

            IF (l_completa_reg = 'N') THEN

              UTL_FILE.Put_Line_Nchar (l_out, '011'
                                      ||';'|| rRecCGRT011.R01101
                                      );
            END IF;

          END LOOP;  -- End FOR rRecCGRT011


          l_etapa := 'rRecCGRT030';

          FOR rRecCGRT030 IN cRecCGRT030 (rLiqToSendCGRT.contrato_id) LOOP

            IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo NOT IN ('IC','SX')) THEN

              UTL_FILE.Put_Line_Nchar (l_out, '030'
                                      ||';'|| rRecCGRT030.R03001
                                      ||';'||''
                                      ||';'|| rRecCGRT030.R03003
                                      ||';'||''
                                      ||';'||''
                                      ||';'|| rRecCGRT030.R03006
                                      ||';'||''
                                      );
            END IF;

          END LOOP; -- End FOR rRecCGRT030

          IF (rLiqToSendCGRT.metodo NOT IN ('CR','CT','CE')) THEN

            l_svcs_adic := NULL;

            l_etapa := 'rRecCGRT040';

            FOR rRecCGRT040 IN cRecCGRT040 (rLiqToSend.liquidacion_id) LOOP

              IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo NOT IN ('IC','SX')) THEN

                IF (l_svcs_adic IS NOT NULL) THEN
                  l_svcs_adic := rRecCGRT040.R04001 ||' - '||l_svcs_adic;
                ELSE
                  l_svcs_adic := rRecCGRT040.R04001;
                END IF;

              END IF;

            END LOOP;

            IF (l_svcs_adic IS NOT NULL) THEN

              l_svcs_adic := SUBSTR(l_svcs_adic,1,400);

              UTL_FILE.Put_Line_Nchar (l_out, '040'
                                      ||';'|| l_svcs_adic);

            END IF;

          END IF;

          l_etapa := 'rRecCGRT090';

          FOR rRecCGRT090 IN cRecCGRT090 (rLiqToSend.liquidacion_id,
                                          rLiqToSend.tipo_liq) LOOP

            IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo IN ('SX','IC')) THEN

              UTL_FILE.Put_Line_Nchar (l_out, '090'
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'|| rRecCGRT090.R09014
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      );

            END IF;

            IF (l_completa_reg = 'Y') AND (l_instance <> 'PADAGI') AND
              (rLiqToSendCGRT.metodo NOT IN ('SX','IC')) THEN

              IF (rRecCGRT090.R09002 IS NULL) THEN
                l_R09002 := TO_CHAR(SYSDATE,'YYYYMMDD');
              ELSE
                l_R09002 := rRecCGRT090.R09002;
              END IF;

              IF (rRecCGRT090.R09014 IS NULL) THEN
                IF (rLiqToSendCGRT.metodo IN ('CR','CT')) THEN
                  l_R09014 := '3320'||LPAD(rLiqToSend.liquidacion_id,8,0);
                ELSE
                  l_R09014 := '3300'||LPAD(rLiqToSend.liquidacion_id,8,0);
                END IF;
              ELSE
                l_R09014 := rRecCGRT090.R09014;
              END IF;


              UTL_FILE.Put_Line_Nchar (l_out, '090'
                                      ||';'||''
                                      ||';'|| l_R09002
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'|| l_R09014
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      ||';'||''
                                      );

            END IF;

          END LOOP;


          l_etapa := 'rRecCGRT100';

          IF (l_completa_reg = 'Y') AND (l_instance <> 'PADAGI')
            AND (rLiqToSendCGRT.metodo <>'IC') THEN

            -- Agregar errores para probar
            /*UTL_FILE.Put_Line_Nchar (l_out, '100'
                                     ||';'
                                     ||';'
                                     );
            */
            NULL;

          END IF;


          l_etapa := 'rRecCGRT110';

          IF (l_completa_reg = 'Y') AND (l_instance <> 'PADAGI')
            AND (rLiqToSendCGRT.metodo <>'IC') THEN

            /* Agregar errores para probar
            UTL_FILE.Put_Line_Nchar (l_out, '110'
                                     ||';'
                                     ||';'
                                     );
           */
           NULL;

          END IF;

          l_etapa := 'rRecCGRT150';

          IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo <> 'IC') THEN

            UTL_FILE.Put_Line_Nchar (l_out, '150'
                                    ||';'|| l_cod_clasif_emisor
                                    ||';'||'');

          END IF;



          l_etapa := 'rRecCGRT200';

          FOR rRecCGRT200 IN cRecCGRT200 ( rLiqToSend.liquidacion_id, rLiqToSend.tipo_liq) LOOP

            IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo NOT IN ('IC','SX')) THEN

              IF (rRecCGRT200.R20002 = 'T' AND (rRecCGRT200.R20003 IS NULL OR
                                                rRecCGRT200.R20004 IS NULL)) THEN

                UTL_FILE.fclose (l_out);
                UTL_FILE.fremove(l_out_dir, l_fname);

                p_err_msg := l_fname||' -> RecCGRT200 -> Si el titular de granos es un Tercero, su CUIT o IIBB no pueden ser nulos.';

                Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                  , p_tipo_liq  => rLiqToSend.tipo_liq
                                  , p_tipo_coe  => ''
                                  , p_ret_val1  => 'RecCGRT200'
                                  , p_ret_val2  => p_err_msg
                                  , p_cancelado => rLiqToSend.cancelado_flag
                                  , p_err_msg   => l_errmsg);

                RAISE e_ErrorCGRT;

              ELSIF (rRecCGRT200.R20001 IS NULL OR
                     rRecCGRT200.R20002 IS NULL OR
                     rRecCGRT200.R20005 IS NULL OR
                     rRecCGRT200.R20006 IS NULL ) THEN


                UTL_FILE.fclose (l_out);
                UTL_FILE.fremove(l_out_dir, l_fname);

                p_err_msg := l_fname||' -> RecCGRT200 -> Los datos comunes del Certificado no pueden estar incompletos.';

                Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                  , p_tipo_liq  => rLiqToSend.tipo_liq
                                  , p_tipo_coe  => ''
                                  , p_ret_val1  => 'RecCGRT200'
                                  , p_ret_val2  => p_err_msg
                                  , p_cancelado => rLiqToSend.cancelado_flag
                                  , p_err_msg   => l_errmsg);

                RAISE e_ErrorCGRT;

              ELSE

                UTL_FILE.Put_Line_Nchar (l_out, '200'
                                        ||';'|| rRecCGRT200.R20001
                                        ||';'|| rRecCGRT200.R20002
                                        ||';'|| rRecCGRT200.R20003
                                        ||';'|| rRecCGRT200.R20004
                                        ||';'|| rRecCGRT200.R20005
                                        ||';'|| rRecCGRT200.R20006
                                        );

              END IF; -- IF (rRecCGRT200.R20004 = 'T' ...

            END IF; -- IF (l_completa_reg = 'N') THEN


            IF (rLiqToSend.tipo_liq = '1116A') THEN

              l_etapa := 'rRecCGRT205';

              FOR rRecCGRT205 IN cRecCGRT205 (rLiqToSend.liquidacion_id) LOOP


                --IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo = 'CD') THEN
                IF (rLiqToSendCGRT.metodo = 'CD') THEN

                  l_get_param_secada := TRUE;  --CR1205

                  /*IF (rRecCGRT200.R20002 = 'T' AND (rRecCGRT205.R20513 IS NULL               Comentado por CR2579
                                                   OR rRecCGRT205.R20514 IS NULL)) THEN */
                  IF rRecCGRT200.R20002 = 'T' AND
                     rRecCGRT205.tipo_contrato != 'ACONDICIONAMIENTO' AND
                     ( ( rRecCGRT205.R20513 IS NULL OR
                         rRecCGRT205.R20514 IS NULL
                       ) AND
                       rLiqToSendCGRT.es_mtrb = 'N'
                     ) THEN

                    UTL_FILE.fclose (l_out);
                    UTL_FILE.fremove(l_out_dir, l_fname);

                    p_err_msg := l_fname||' -> RecCGRT205 -> Si el titular del grano es Tercero, el termino de pago '||
                                              'y/o Servicios Otros, no pueden estar incompletos.';

                    Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                      , p_tipo_liq  => rLiqToSend.tipo_liq
                                      , p_tipo_coe  => ''
                                      , p_ret_val1  => 'RecCGRT205'
                                      , p_ret_val2  => p_err_msg
                                      , p_cancelado => rLiqToSend.cancelado_flag
                                      , p_err_msg   => l_errmsg);

                    RAISE e_ErrorCGRT;


                  ELSE

                    -- CR1205
                    IF (rLiqToSendCGRT.merma_header_id IS NULL) THEN

                      BEGIN

                        SELECT DISTINCT xtcp.merma_header_id
                          INTO l_merma_header_id
                          FROM XX_TCG_BOLETIN_LINES    xtbl
                             , XX_TCG_CARTAS_PORTE_ALL xtcp
                         WHERE xtbl.carta_porte_id    = xtcp.carta_porte_id
                           AND xtbl.boletin_header_id = rLiqToSendCGRT.boletin_header_id
                           AND xtcp.merma_header_id   IS NOT NULL;

                      EXCEPTION
                        WHEN TOO_MANY_ROWS THEN

                          SELECT xtcp.merma_header_id
                            INTO l_merma_header_id
                            FROM XX_TCG_CARTAS_PORTE_ALL xtcp
                           WHERE xtcp.carta_porte_id = (SELECT min(xtcp.carta_porte_id) carta_porte_id
                                                          FROM XX_TCG_BOLETIN_LINES    xtbl
                                                             , XX_TCG_CARTAS_PORTE_ALL xtcp
                                                         WHERE xtbl.carta_porte_id = xtcp.carta_porte_id
                                                           AND xtbl.boletin_header_id = rLiqToSendCGRT.boletin_header_id);


                        WHEN NO_DATA_FOUND THEN
                          l_porc_rango_inf   := 0;
                          l_porc_rango_sup   := 100;
                          l_tarifa           := 0;
                          l_tarifa_exceso    := 0;
                          l_get_param_secada := FALSE;



                        WHEN OTHERS THEN
                          UTL_FILE.fclose (l_out);
                          UTL_FILE.fremove(l_out_dir, l_fname);

                          p_err_msg := l_fname||' -> RecCGRT205 -> Error al intentar obtener el valor de merma header id. '||SQLERRM;

                          Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                            , p_tipo_liq  => rLiqToSend.tipo_liq
                                            , p_tipo_coe  => ''
                                            , p_ret_val1  => 'RecCGRT205'
                                            , p_ret_val2  => p_err_msg
                                            , p_cancelado => rLiqToSend.cancelado_flag
                                            , p_err_msg   => p_err_msg);

                          RAISE e_ErrorCGRT;

                      END;

                    ELSE

                      l_merma_header_id := rLiqToSendCGRT.merma_header_id;

                    END IF;


                    IF (l_get_param_secada) THEN

                      XX_TCG_ACONDICIONAMIENTO_PKG.Get_Parametros_Secada
                                                   ( p_acond_id             => rLiqToSendCGRT.acond_id
                                                   , p_merma_header_id      => l_merma_header_id --rLiqToSendCGRT.merma_header_id  CR1205
                                                   , p_porc_rango_inferior  => l_porc_rango_inf
                                                   , p_porc_rango_superior  => l_porc_rango_sup
                                                   , p_tarifa               => l_tarifa
                                                   , p_tarifa_exceso        => l_tarifa_exceso
                                                   , p_result               => l_result
                                                   , p_error_msg            => l_errmsg);

                      IF (NOT l_result) THEN

                        UTL_FILE.fclose (l_out);
                        UTL_FILE.fremove(l_out_dir, l_fname);

                        p_err_msg := l_fname||' -> RecCGRT205 -> Error al intentar obtener los parametros de secada. '||l_errmsg;

                        Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                          , p_tipo_liq  => rLiqToSend.tipo_liq
                                          , p_tipo_coe  => ''
                                          , p_ret_val1  => 'RecCGRT205'
                                          , p_ret_val2  => p_err_msg
                                          , p_cancelado => rLiqToSend.cancelado_flag
                                          , p_err_msg   => l_errmsg);

                        RAISE e_ErrorCGRT;

                      END IF;

                    END IF;

                    --ELSE   Comentado CR1205

                      IF (rRecCGRT205.R20501 IS NOT NULL AND
                          rRecCGRT205.R20502 IS NOT NULL AND
                          rRecCGRT205.R20503 IS NOT NULL AND
                          rRecCGRT205.R20504 IS NOT NULL AND
                          rRecCGRT205.R20505 IS NOT NULL AND
                          rRecCGRT205.R20506 IS NOT NULL AND
                          NVL(l_porc_rango_sup,0) IS NOT NULL AND
                          NVL(l_porc_rango_inf,0) IS NOT NULL AND
                          NVL(l_tarifa,0) IS NOT NULL AND
                          NVL(l_tarifa_exceso,0) IS NOT NULL AND
                          rRecCGRT205.R20511 IS NOT NULL AND
                          rRecCGRT205.R20512 IS NOT NULL )   THEN


                        IF (rRecCGRT200.R20002 = 'T') THEN

                          IF (rLiqToSendCGRT.es_mtrb = 'N') THEN

                            SELECT count(*)
                              INTO l_cant_lineas
                              FROM XX_TCG_LIQUIDACION_1116A_LINES
                             WHERE liquidacion_id = rLiqToSend.liquidacion_id
                               AND importe        > 0;

                            IF (l_cant_lineas > 0) THEN

                              SELECT count(*)
                                INTO l_cant_fc
                                FROM RA_CUSTOMER_TRX_ALL
                               WHERE customer_trx_id = rLiqToSendCGRT.cust_trx_id_ficticio
                                 AND trx_number      = rLiqToSend.liquidacion_id;
                            ELSE
                              l_cant_fc := 1; -- Para que no falle el proceso, no hay líneas, entonces no se creó ficticia
                            END IF;


                            l_percep_iva   := 0;
                            l_otras_percep := 0;
                            l_no_gravados  := 0;

                            XX_TCG_LIQUIDACION_1116A_PKG.Obtener_Percepciones_AR_1116A
                                                        ( p_liquidacion_id   => rLiqToSend.liquidacion_id
                                                        , x_percep_iva       => l_percep_iva
                                                        , x_otras_percep     => l_otras_percep
                                                        , x_no_gravados      => l_no_gravados
                                                        , x_resultado        => l_result
                                                        , x_error            => l_errmsg);



                            IF (NOT l_result) OR (l_cant_fc=0) THEN

                              UTL_FILE.fclose (l_out);
                              UTL_FILE.fremove(l_out_dir, l_fname);

                              IF (l_cant_fc = 0) THEN
                                p_err_msg := l_fname||' -> RecCGRT205 -> No se encuentra la factura ficticia '||rLiqToSendCGRT.cust_trx_id_ficticio;
                              ELSE
                                p_err_msg := l_fname||' -> RecCGRT205 -> '||l_errmsg;
                              END IF;

                              Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                                , p_tipo_liq  => rLiqToSend.tipo_liq
                                                , p_tipo_coe  => ''
                                                , p_ret_val1  => 'RecCGRT205'
                                                , p_ret_val2  => p_err_msg
                                                , p_cancelado => rLiqToSend.cancelado_flag
                                                , p_err_msg   => l_errmsg);

                              RAISE e_ErrorCGRT;

                            ELSE

                              UTL_FILE.put_line_nchar (l_out, '205'
                                                      ||';'|| rRecCGRT205.R20501
                                                      ||';'|| rRecCGRT205.R20502
                                                      ||';'|| rRecCGRT205.R20503
                                                      ||';'|| rRecCGRT205.R20504
                                                      ||';'|| rRecCGRT205.R20505
                                                      ||';'|| rRecCGRT205.R20506
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_sup,0),'990D90'))
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_inf,0),'990D90'))
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_tarifa,0),'99999990D90'))
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_tarifa_exceso,0),'99999990D90'))
                                                      ||';'|| rRecCGRT205.R20511
                                                      ||';'|| rRecCGRT205.R20512
                                                      ||';'|| rRecCGRT205.R20513
                                                      ||';'|| rRecCGRT205.R20514
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_no_gravados,0),'99999990D90'))
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_percep_iva,0),'99999990D90'))
                                                      ||';'|| TRIM(TO_CHAR(NVL(l_otras_percep,0),'99999990D90'))
                                                      );

                            END IF;

                          ELSE  --Para Clientes Monotributistas

                            UTL_FILE.put_line_nchar (l_out, '205'
                                                     ||';'|| rRecCGRT205.R20501
                                                     ||';'|| rRecCGRT205.R20502
                                                     ||';'|| rRecCGRT205.R20503
                                                     ||';'|| rRecCGRT205.R20504
                                                     ||';'|| rRecCGRT205.R20505
                                                     ||';'|| rRecCGRT205.R20506
                                                     ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_sup,0),'990D90'))
                                                     ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_inf,0),'990D90'))
                                                     ||';'|| TRIM(TO_CHAR(NVL(l_tarifa,0),'99999990D90'))
                                                     ||';'|| TRIM(TO_CHAR(NVL(l_tarifa_exceso,0),'99999990D90'))
                                                     ||';'|| rRecCGRT205.R20511
                                                     ||';'|| rRecCGRT205.R20512
                                                     ||';'|| ''
                                                     ||';'|| ''
                                                     ||';'|| ''
                                                     ||';'|| ''
                                                     ||';'|| ''
                                                     );

                          END IF; -- IF (rLiqToSendCGRT.es_mtrb = 'N') THEN

                        ELSE

                          IF (rLiqToSendCGRT.tipo_origen = 'PROPIO') THEN

                            UTL_FILE.put_line_nchar (l_out, '205'
                                                    ||';'|| rRecCGRT205.R20501
                                                    ||';'|| rRecCGRT205.R20502
                                                    ||';'|| '0.00'
                                                    ||';'|| '0.00'
                                                    ||';'|| '0.00'
                                                    ||';'|| '0.00'
                                                    ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_sup,0),'990D90'))
                                                    ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_inf,0),'990D90'))
                                                    ||';'|| '0.00'
                                                    ||';'|| '0.00'
                                                    ||';'|| '0.00'
                                                    ||';'|| rRecCGRT205.R20512
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    );

                          ELSE -- Se deja preparada esta condicion aunque por el momento no es factible


                            UTL_FILE.put_line_nchar (l_out, '205'
                                                    ||';'|| rRecCGRT205.R20501
                                                    ||';'|| rRecCGRT205.R20502
                                                    ||';'|| rRecCGRT205.R20503
                                                    ||';'|| rRecCGRT205.R20504
                                                    ||';'|| rRecCGRT205.R20505
                                                    ||';'|| rRecCGRT205.R20506
                                                    ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_sup,0),'990D90'))
                                                    ||';'|| TRIM(TO_CHAR(NVL(l_porc_rango_inf,0),'990D90'))
                                                    ||';'|| TRIM(TO_CHAR(NVL(l_tarifa,0),'99999990D90'))
                                                    ||';'|| TRIM(TO_CHAR(NVL(l_tarifa_exceso,0),'99999990D90'))
                                                    ||';'|| rRecCGRT205.R20511
                                                    ||';'|| rRecCGRT205.R20512
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    ||';'|| ''
                                                    );

                          END IF;

                        END IF; --END IF (rRecCGRT200.R20002 = 'T') THEN

                      ELSE

                        UTL_FILE.fclose (l_out);
                        UTL_FILE.fremove(l_out_dir, l_fname);

                        p_err_msg := l_fname||' -> RecCGRT205 -> Los datos del Certificado no pueden estar nulos.';

                        Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                          , p_tipo_liq  => rLiqToSend.tipo_liq
                                          , p_tipo_coe  => ''
                                          , p_ret_val1  => 'RecCGRT205'
                                          , p_ret_val2  => p_err_msg
                                          , p_cancelado => rLiqToSend.cancelado_flag
                                          , p_err_msg   => l_errmsg);

                        RAISE e_ErrorCGRT;


                      END IF;  -- Campos no nulos

--                    END IF; -- End IF (NOT l_result)   Comentado CR1205


                  END IF; -- End IF (rRecCGRT200.R20004 = 'T' AND rRecCGRT205.R20520 IS NULL)

                END IF; -- END IF metodo = CD

              END LOOP; -- End FOR rRecCGRT205


              l_etapa := 'rRecCGRT210';

              FOR rRecCGRT210 IN cRecCGRT210 (rLiqToSend.liquidacion_id) LOOP

                IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo = 'CD') THEN

                  IF (rLiqToSendCGRT.tipo_origen = 'PROPIO') THEN

                    IF (rRecCGRT210.R21001 IS NOT NULL AND
                        rRecCGRT210.R21002 IS NOT NULL AND
                        rRecCGRT210.R21003 IS NOT NULL AND
                        rRecCGRT210.R21004 IS NOT NULL AND
                        rRecCGRT210.R21006 IS NOT NULL AND
                        rRecCGRT210.R21009 IS NOT NULL ) THEN

                      UTL_FILE.put_line_nchar (l_out, '210'
                                              ||';'|| rRecCGRT210.R21001
                                              ||';'|| rRecCGRT210.R21002
                                              ||';'|| rRecCGRT210.R21003
                                              ||';'|| rRecCGRT210.R21004
                                              ||';'|| '0.00'
                                              ||';'|| rRecCGRT210.R21006
                                              ||';'|| '0.00'
                                              ||';'|| '0.00'
                                              ||';'|| rRecCGRT210.R21009
                                              ||';'|| '0.00'
                                              ||';'|| rRecCGRT210.R21011);

                    ELSE

                      UTL_FILE.fclose (l_out);
                      UTL_FILE.fremove(l_out_dir, l_fname);

                      p_err_msg := l_fname||' -> RecCGRT210 -> Los datos del registro de Codigo de Trazabilidad de Granos, '
                                          ||'no pueden estar incompletos para Certificados con contrato de origen Propio.';

                      Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                        , p_tipo_liq  => rLiqToSend.tipo_liq
                                        , p_tipo_coe  => ''
                                        , p_ret_val1  => 'RecCGRT210'
                                        , p_ret_val2  => p_err_msg
                                        , p_cancelado => rLiqToSend.cancelado_flag
                                        , p_err_msg   => l_errmsg);

                      RAISE e_ErrorCGRT;

                    END IF;


                  ELSIF (rLiqToSendCGRT.tipo_origen = 'TERCERO' AND
                    rLiqToSendCGRT.es_mtrb = 'N') THEN

                    IF (rRecCGRT210.R21001 IS NOT NULL AND
                        rRecCGRT210.R21002 IS NOT NULL AND
                        rRecCGRT210.R21003 IS NOT NULL AND
                        rRecCGRT210.R21004 IS NOT NULL AND
                        rRecCGRT210.R21005 IS NOT NULL AND
                        rRecCGRT210.R21006 IS NOT NULL AND
                        rRecCGRT210.R21007 IS NOT NULL AND
                        rRecCGRT210.R21008 IS NOT NULL AND
                        rRecCGRT210.R21009 IS NOT NULL AND
                        rRecCGRT210.R21010 IS NOT NULL ) THEN


                      UTL_FILE.put_line_nchar (l_out, '210'
                                               ||';'|| rRecCGRT210.R21001
                                               ||';'|| rRecCGRT210.R21002
                                               ||';'|| rRecCGRT210.R21003
                                               ||';'|| rRecCGRT210.R21004
                                               ||';'|| rRecCGRT210.R21005
                                               ||';'|| rRecCGRT210.R21006
                                               ||';'|| rRecCGRT210.R21007
                                               ||';'|| rRecCGRT210.R21008
                                               ||';'|| rRecCGRT210.R21009
                                               ||';'|| rRecCGRT210.R21010
                                               ||';'|| rRecCGRT210.R21011);


                    ELSE

                      UTL_FILE.fclose (l_out);
                      UTL_FILE.fremove(l_out_dir, l_fname);

                      p_err_msg := l_fname||' -> RecCGRT210 -> Los datos del registro de Codigo de Trazabilidad de Granos, '
                                          ||'no pueden estar incompletos.';

                      Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                        , p_tipo_liq  => rLiqToSend.tipo_liq
                                        , p_tipo_coe  => ''
                                        , p_ret_val1  => 'RecCGRT210'
                                        , p_ret_val2  => p_err_msg
                                        , p_cancelado => rLiqToSend.cancelado_flag
                                        , p_err_msg   => l_errmsg);


                      RAISE e_ErrorCGRT;

                    END IF;

                  ELSIF (rLiqToSendCGRT.tipo_origen = 'TERCERO' AND
                    rLiqToSendCGRT.es_mtrb = 'Y') THEN


                    IF (rRecCGRT210.R21001 IS NOT NULL AND
                        rRecCGRT210.R21002 IS NOT NULL AND
                        rRecCGRT210.R21003 IS NOT NULL AND
                        rRecCGRT210.R21004 IS NOT NULL AND
                        rRecCGRT210.R21006 IS NOT NULL AND
                        rRecCGRT210.R21009 IS NOT NULL ) THEN


                       UTL_FILE.put_line_nchar (l_out, '210'
                                               ||';'|| rRecCGRT210.R21001
                                               ||';'|| rRecCGRT210.R21002
                                               ||';'|| rRecCGRT210.R21003
                                               ||';'|| rRecCGRT210.R21004
                                               ||';'|| '0.00'
                                               ||';'|| rRecCGRT210.R21006
                                               ||';'|| '0.00'
                                               ||';'|| '0.00'
                                               ||';'|| rRecCGRT210.R21009
                                               ||';'|| '0.00'
                                               ||';'|| rRecCGRT210.R21011);

                    ELSE

                        UTL_FILE.fclose (l_out);
                        UTL_FILE.fremove(l_out_dir, l_fname);

                        p_err_msg := l_fname||' -> RecCGRT210 -> Los datos del registro de Codigo de Trazabilidad de Granos, '
                                            ||'no pueden estar incompletos para el Monotributista.';

                        Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                          , p_tipo_liq  => rLiqToSend.tipo_liq
                                          , p_tipo_coe  => ''
                                          , p_ret_val1  => 'RecCGRT210'
                                          , p_ret_val2  => p_err_msg
                                          , p_cancelado => rLiqToSend.cancelado_flag
                                          , p_err_msg   => l_errmsg);


                        RAISE e_ErrorCGRT;

                    END IF;


                  END IF; --END IF (rLiqToSend.tipo_certificado = 'OFICIAL' AND rLiqToSend.tipo_origen = 'PROPIO') THEN

                END IF; -- End IF (l_completa_reg = 'N') THEN

              END LOOP; -- End FOR rRecCGRT210

              l_etapa := 'rRecCGRT215';

              FOR rRecCGRT215 IN cRecCGRT215 (rLiqToSend.liquidacion_id) LOOP

                IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo IN ('CD','IC')) THEN


                  IF (rLiqToSendCGRT.metodo = 'IC' AND
                    rRecCGRT215.R21501 IS NOT NULL AND
                    rRecCGRT215.R21502 IS NOT NULL AND
                    rRecCGRT215.R21504 IS NOT NULL)
                    OR (rLiqToSendCGRT.metodo <> 'IC' AND
                       rRecCGRT215.R21501 IS NOT NULL AND
                       rRecCGRT215.R21502 IS NOT NULL) THEN


                    UTL_FILE.put_line_nchar (l_out, '215'
                                            ||';'|| rRecCGRT215.R21501
                                            ||';'|| TO_NUMBER(rRecCGRT215.R21502)    -- se corta el proceso de generacion de archivo
                                            ||';'|| rRecCGRT215.R21503
                                            ||';'|| rRecCGRT215.R21504
                                            ||';'|| rRecCGRT215.R21505
                                            ||';'|| rRecCGRT215.R21506);

                  ELSE

                    UTL_FILE.fclose (l_out);
                    UTL_FILE.fremove(l_out_dir, l_fname);

                    p_err_msg := l_fname||' -> RecCGRT215 -> Los datos de Calidad no pueden estar incompletos.';

                    Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                      , p_tipo_liq  => rLiqToSend.tipo_liq
                                      , p_tipo_coe  => ''
                                      , p_ret_val1  => 'RecCGRT215'
                                      , p_ret_val2  => p_err_msg
                                      , p_cancelado => rLiqToSend.cancelado_flag
                                      , p_err_msg   => l_errmsg);

                    RAISE e_ErrorCGRT;

                  END IF;

                END IF;  -- End IF (l_completa_reg = 'N') THEN


                l_etapa := 'rRecCGRT220';

                FOR rRecCGRT220 IN  cRecCGRT220 (rRecCGRT215.boletin_header_id ) LOOP

                  IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo IN ('CD','IC')) THEN

                    IF (rRecCGRT220.R22001 IS NOT NULL AND
                      rRecCGRT220.R22002 IS NOT NULL AND
                      rRecCGRT220.R22003 IS NOT NULL AND
                      rRecCGRT220.R22004 IS NOT NULL) THEN

                      UTL_FILE.put_line_nchar (l_out, '220'
                                              ||';'|| rRecCGRT220.R22001
                                              ||';'|| rRecCGRT220.R22002
                                              ||';'|| rRecCGRT220.R22003
                                              ||';'|| rRecCGRT220.R22004);
                    ELSE

                      UTL_FILE.fclose (l_out);
                      UTL_FILE.fremove(l_out_dir, l_fname);

                      p_err_msg := l_fname||' -> RecCGRT220 -> Los datos de Analisis de muestra no pueden estar incompletos.';

                      Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                        , p_tipo_liq  => rLiqToSend.tipo_liq
                                        , p_tipo_coe  => ''
                                        , p_ret_val1  => 'RecCGRT220'
                                        , p_ret_val2  => p_err_msg
                                        , p_cancelado => rLiqToSend.cancelado_flag
                                        , p_err_msg   => l_errmsg);

                      RAISE e_ErrorCGRT;

                    END IF;

                  END IF; --End IF (l_completa_reg = 'N') THEN

                END LOOP; -- End FOR rRecCGRT220

              END LOOP; -- End FOR rRecCGRT215


              l_etapa := 'rRecCGRT240';

              FOR rRecCGRT240 IN cRecCGRT240 (rLiqToSend.liquidacion_id) LOOP

                IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo = 'CE') THEN

                  IF (rRecCGRT240.R24001 IS NOT NULL AND
                    rRecCGRT240.R24002 IS NOT NULL AND
                    rRecCGRT240.R24003 IS NOT NULL AND
                    rRecCGRT240.R24004 IS NOT NULL AND
                    rRecCGRT240.R24005 IS NOT NULL AND
                    rRecCGRT240.R24006 IS NOT NULL) THEN

                    UTL_FILE.put_line_nchar (l_out, '240'
                                            ||';'|| rRecCGRT240.R24001
                                            ||';'|| rRecCGRT240.R24002
                                            ||';'|| rRecCGRT240.R24003
                                            ||';'|| rRecCGRT240.R24004
                                            ||';'|| rRecCGRT240.R24005
                                            ||';'|| rRecCGRT240.R24006);
                  ELSE

                    UTL_FILE.fclose (l_out);
                    UTL_FILE.fremove(l_out_dir, l_fname);

                    p_err_msg := l_fname||' -> RecCGRT240 -> Los datos a informar de Certificados Preexistentes '
                                        ||'no pueden estar incompletos.';

                    Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                      , p_tipo_liq  => rLiqToSend.tipo_liq
                                      , p_tipo_coe  => ''
                                      , p_ret_val1  => 'RecCGRT240'
                                      , p_ret_val2  => p_err_msg
                                      , p_cancelado => rLiqToSend.cancelado_flag
                                      , p_err_msg   => l_errmsg);

                    RAISE e_ErrorCGRT;

                  END IF;

                END IF; -- END IF (l_completa_reg = 'N') AND (rLiqToSend.metodo NOT IN ('SX','IC')) THEN

              END LOOP; -- FOR rRecCGRT240 IN cRecCGRT240 (rLiqToSend.liquidacion_id) LOOP


              IF (l_completa_reg = 'Y') AND (l_instance <> 'PADAGI')
                AND (rLiqToSendCGRT.metodo NOT IN ('IC','SX')) THEN

                l_etapa := 'rRecCGRT250';

                FOR rRecCGRT250 IN cRecCGRT250 (rLiqToSendCGRT.boletin_header_id) LOOP

                  UTL_FILE.put_line_nchar (l_out, '250'
                                          ||';'|| ' '
                                          ||';'|| rRecCGRT250.R25002
                                          ||';'|| rRecCGRT250.R25003
                                          ||';'|| rRecCGRT250.R25004
                                          ||';'|| rRecCGRT250.R25005
                                          ||';'|| rRecCGRT250.R25006
                                          ||';'|| rRecCGRT250.R25007
                                          ||';'|| rRecCGRT250.R25008
                                          ||';'|| rRecCGRT250.R25009
                                          ||';'|| '0'
                                          ||';'|| '0'
                                          ||';'|| '0'
                                          ||';'|| '0'
                                          ||';'|| '11111111111'
                                          ||';'|| '  '
                                          ||';'|| '12121212121'
                                          ||';'|| '0'
                                          ||';'|| '0'
                                          ||';'|| '0'
                                           );

                END LOOP;

              END IF;

            ELSIF (rLiqToSend.tipo_liq = '1116RT') THEN
              l_etapa := 'rRecCGRT230';

              FOR rRecCGRT230 IN cRecCGRT230 (rLiqToSend.liquidacion_id,
                                              l_org_id ) LOOP

                IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo NOT IN ('SX','IC')) THEN


                  IF (rRecCGRT230.R23001 IS NOT NULL) THEN

                    IF (rRecCGRT200.R20002 = 'T') THEN

                      UTL_FILE.put_line_nchar (l_out, '230'
                                               ||';'|| rRecCGRT230.R23001
                                               ||';'|| rRecCGRT230.R23002
                                               ||';'|| rRecCGRT230.R23003);
                    ELSE

                      UTL_FILE.put_line_nchar (l_out, '230'
                                               ||';'|| rRecCGRT230.R23001
                                               ||';'|| ''
                                               ||';'|| rRecCGRT230.R23003);
                    END IF;

                  ELSE

                    UTL_FILE.fclose (l_out);
                    UTL_FILE.fremove(l_out_dir, l_fname);

                    p_err_msg := l_fname||' -> RecCGRT230 -> El numero de actividad del Depositario en el certificado de Retiro/Transferencia '
                                        ||'no puede estar incompleto.';

                    Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                      , p_tipo_liq  => rLiqToSend.tipo_liq
                                      , p_tipo_coe  => ''
                                      , p_ret_val1  => 'RecCGRT230'
                                      , p_ret_val2  => p_err_msg
                                      , p_cancelado => rLiqToSend.cancelado_flag
                                      , p_err_msg   => l_errmsg);


                    RAISE e_ErrorCGRT;

                  END IF;

                END IF; --End IF (l_completa_reg = 'N') THEN


              END LOOP; -- End rRecCGRT230

              l_etapa := 'rRecCGRT235';

              FOR rRecCGRT235 IN cRecCGRT235 (rLiqToSend.liquidacion_id ) LOOP

                IF (l_completa_reg = 'N') AND (rLiqToSendCGRT.metodo IN ('CR','CT')) THEN

                  IF (rRecCGRT235.R23501 IS NOT NULL AND
                      rRecCGRT235.R23502 IS NOT NULL) THEN

                    UTL_FILE.put_line_nchar (l_out, '235'
                                           ||';'|| rRecCGRT235.R23501
                                           ||';'|| rRecCGRT235.R23502);
                  ELSE

                    UTL_FILE.fclose (l_out);
                    UTL_FILE.fremove(l_out_dir, l_fname);

                    p_err_msg := l_fname||' -> RecCGRT235 -> Los datos del Certificado de Deposito para Certificados de Retiro/Transferencia '
                                        ||'no pueden estar incompletos.';

                    Grabar_Error_CGRT ( p_liq_id    => rLiqToSend.liquidacion_id
                                      , p_tipo_liq  => rLiqToSend.tipo_liq
                                      , p_tipo_coe  => ''
                                      , p_ret_val1  => 'RecCGRT235'
                                      , p_ret_val2  => p_err_msg
                                      , p_cancelado => rLiqToSend.cancelado_flag
                                      , p_err_msg   => l_errmsg);

                    RAISE e_ErrorCGRT;

                  END IF;

                END IF; --End IF (l_completa_reg = 'N') THEN

              END LOOP;  --End rRecCGRT235

            END IF;  --IF (rLiqToSend.tipo_liq = '1116A') THEN

          END LOOP; -- End FOR rRecCGRT200


          l_etapa := 'UTL_FILE.fflush';

          UTL_FILE.fflush (l_out);
          UTL_FILE.fcopy (l_out_dir, l_fname, l_out_dir_copy, l_fname);
          UTL_FILE.fclose (l_out);


          l_etapa := 'UPDATE estado_coe';

          IF ( l_completa_reg = 'Y') AND
            (l_instance <> 'PADAGI') THEN

            IF (rLiqToSend.tipo_liq = '1116A') THEN

              UPDATE XX_TCG_LIQUIDACIONES_1116A
                 SET estado_coe = 'ESP_RESP'
               WHERE liquidacion_id = rLiqToSend.liquidacion_id;

            ELSIF (rLiqToSend.tipo_liq = '1116RT') THEN

              UPDATE XX_TCG_RT
                 SET estado_coe = 'ESP_RESP'
               WHERE liquidacion_id = rLiqToSend.liquidacion_id;

            END IF;

          ELSE

            IF (rLiqToSend.tipo_liq = '1116A') THEN

              UPDATE XX_TCG_LIQUIDACIONES_1116A
                 SET estado_coe        = 'ESP_RESP'
               WHERE liquidacion_id = rLiqToSend.liquidacion_id;

            ELSIF (rLiqToSend.tipo_liq = '1116RT') THEN

              UPDATE XX_TCG_RT
                 SET estado_coe        = 'ESP_RESP'
               WHERE liquidacion_id = rLiqToSend.liquidacion_id;

            END IF;

          END IF;

          p_cant_reg := p_cant_reg + 1;
          COMMIT;

        END IF; -- End IF (rLiqToSend.tipo_liq = '1116B')

      END IF;  --End IF Check_Row

      <<Proxima_liquidacion>>
      NULL;

    END LOOP; -- End FOR cLiqToSend

  EXCEPTION
    WHEN e_ErrorPtoEmision THEN
      NULL;

    WHEN e_Error000 THEN
      xx_debug_aux_pk.debug(p_module => 'CGRT'
                     , p_message => 'Error: '||p_err_msg);


    WHEN e_ErrorCGRT THEN
      BEGIN

        IF (l_tipo_liq = '1116A') THEN

          IF (l_metodo='CE') THEN

            UPDATE XX_TCG_LIQUIDACIONES_1116A
               SET estado_coe     = 'ERROR'
                 , numero_liquidacion = numero_preexistente
                 , numero_preexistente = NULL
             WHERE liquidacion_id = l_liq_id;

          ELSE

            UPDATE XX_TCG_LIQUIDACIONES_1116A
               SET estado_coe     = 'ERROR'
                 , liquidado_flag = DECODE(liquidado_flag,'Y','N'
                                                         ,liquidado_flag)
                 , liquidado_sin_calidad_flag = DECODE(liquidado_sin_calidad_flag,'Y','N'
                                                                                 ,liquidado_sin_calidad_flag)
             WHERE liquidacion_id = l_liq_id;

          END IF;

        ELSIF (l_tipo_liq = '1116RT') THEN

            UPDATE XX_TCG_RT
               SET estado_coe     = 'ERROR'
                 , liquidado_flag = DECODE(liquidado_flag,'Y','N'
                                                         ,liquidado_flag)
             WHERE liquidacion_id = l_liq_id;

        END IF;

        COMMIT;

      EXCEPTION
        WHEN others THEN
          p_err_msg := l_fname||' -> Error al intentar actualizar la liquidacion '
                       ||l_tipo_liq||' '||l_liq_id||' con el estado ERROR. Detalle: '||SQLERRM;

      END;

    WHEN e_ErrorCGRT_ACO THEN
      NULL;

    WHEN Others THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_out) THEN
        UTL_FILE.Fclose (l_out);
      END IF;

      UTL_FILE.fremove(l_out_dir, l_fname);

      p_err_msg := l_fname||' -> '||l_etapa||' '||substr(SQLERRM,1,200);

      BEGIN

        IF (l_tipo_liq = '1116A') THEN


         Grabar_Error_CGRT ( p_liq_id    => l_liq_id
                           , p_tipo_liq  => l_tipo_liq
                           , p_tipo_coe  => l_metodo
                           , p_ret_val1  => l_etapa
                           , p_ret_val2  => p_err_msg
                           , p_cancelado => ''
                           , p_err_msg   => l_errmsg);

          IF (l_metodo='CE') THEN

            UPDATE XX_TCG_LIQUIDACIONES_1116A
               SET estado_coe     = 'ERROR'
                 , numero_liquidacion = numero_preexistente
                 , numero_preexistente = NULL
             WHERE liquidacion_id = l_liq_id;

          ELSE

            UPDATE XX_TCG_LIQUIDACIONES_1116A
               SET estado_coe     = 'ERROR'
                 , liquidado_flag = DECODE(liquidado_flag,'Y','N'
                                                         ,liquidado_flag)
                 , liquidado_sin_calidad_flag = DECODE(liquidado_sin_calidad_flag,'Y','N'
                                                                                 ,liquidado_sin_calidad_flag)
             WHERE liquidacion_id = l_liq_id;

          END IF;

          COMMIT;

        ELSIF (l_tipo_liq = '1116RT') THEN

            UPDATE XX_TCG_RT
               SET estado_coe     = 'ERROR'
                 , liquidado_flag = DECODE(liquidado_flag,'Y','N'
                                                         ,liquidado_flag)
             WHERE liquidacion_id = l_liq_id;

          COMMIT;

        END IF;

      EXCEPTION
        WHEN others THEN
          p_err_msg := l_fname||' -> Error al intentar actualizar la liquidacion '
                       ||l_tipo_liq||' '||l_liq_id||' con el estado ERROR. Detalle: '||SQLERRM;

      END;

  END Envia_archivo;




 /*****************************************************************************
 *                                                                            *
 * Name    :  Lee_Archivo_CGRT                                                *
 * Purpose : Procedimiento encargado de leer los archivos enviados por        *
 *           PlanexWare. En base a lo informado, continua con la finalizacion *
 *           de la liquidacion A/RT, o informa los errores                    *
 *                                                                            *
 ******************************************************************************/
  PROCEDURE lee_archivo_CGRT ( p_fname          VARCHAR2
                             , p_err_msg    OUT VARCHAR2
                             )
  IS

    l_in                UTL_FILE.file_type;
    l_in_dir            VARCHAR2(100) ;
    l_fname             VARCHAR2(200) := p_fname;
    l_line              VARCHAR2(1000);
    l_pto_emision       NUMBER;
    l_nro_orden         NUMBER;
    l_liq_id            NUMBER;
    l_coe               VARCHAR2(30) := NULL;
    l_ret_val1          VARCHAR2(1000) := NULL;
    l_ret_val2          VARCHAR2(1000) := NULL;
    l_error_flag        VARCHAR2(1) := 'N';
    l_error_afip        VARCHAR2(1) := 'N';
    l_liquidado         VARCHAR2(1);
    l_cancelado         VARCHAR2(1);
    eROWLOCKED          EXCEPTION;
    eREPROC             EXCEPTION;
    eGETLINE            EXCEPTION;
    eAFIP               EXCEPTION;
    l_tipo_liq          VARCHAR2(10);
    l_liq_sin_cal       VARCHAR2(1);
    l_num_liq           VARCHAR2(40);
    l_num_pre           VARCHAR2(40);
    l_metodo_cert       VARCHAR2(5);
    --l_err_msg           VARCHAR2(3000);
    l_estado_boletin    VARCHAR2(20);
    l_found             BOOLEAN;
    eNoEspResp          EXCEPTION;
    l_afip_10001        VARCHAR2(30)   := NULL;
    l_afip_10002        VARCHAR2(1000) := NULL;
    l_afip_11001        VARCHAR2(30)   := NULL;
    l_afip_11002        VARCHAR2(1000) := NULL;
    l_cond_arch         VARCHAR2(1);


    CURSOR c_liq ( p_liq_id      NUMBER) IS
      SELECT '1116A'                tipo_liq
           , xtla.numero_liquidacion
           , xtla.numero_preexistente
           , xtla.liquidado_flag
           , xtla.cancelado_flag
           , xtla.liquidado_sin_calidad_flag
           , xtbh.estado
        FROM XX_TCG_LIQUIDACIONES_1116A  xtla
           , XX_TCG_BOLETIN_HEADERS      xtbh
       WHERE xtla.liquidacion_id    = p_liq_id
         AND xtla.estado_coe        IN ( 'ESP_RESP'
                                       , 'ERROR' )
         AND xtla.boletin_header_id = xtbh.boletin_header_id
       UNION ALL
      SELECT '1116A_ACO'            tipo_liq
           , xla.numero_liquidacion
           , xla.numero_preexistente
           , xla.liquidado_flag
           , xla.cancelado_flag
           , xla.liquidado_sin_calidad_flag
           , xbh.estado
        FROM XX_ACO_LIQUIDACIONES_1116A  xla
           , XX_ACO_BOLETIN_HEADERS      xbh
       WHERE xla.liquidacion_id    = p_liq_id
         AND xla.estado_coe        IN ( 'ESP_RESP'
                                      , 'ERROR' )
         AND xla.boletin_header_id = xbh.boletin_header_id
         AND xla.tipo_boletin      = 'B'
     UNION ALL
      SELECT '1116RT'
           , numero_liquidacion
           , NULL
           , liquidado_flag
           , cancelado_flag
           , NULL
           , NULL
        FROM XX_TCG_RT
       WHERE liquidacion_id    = p_liq_id
         AND estado_coe        = 'ESP_RESP'
         ;



    FUNCTION Get_metodo_certificado( p_tipo_liq     VARCHAR2
                                   , p_liq_id       NUMBER
                                   , p_num_liq      VARCHAR2
                                   , p_cancelado    VARCHAR2
                                   , p_liquidado    VARCHAR2
                                   , p_liq_sin_cal  VARCHAR2
                                   , p_num_pre      VARCHAR2)
    RETURN VARCHAR2 IS

      l_tipo_liq        VARCHAR2(30);
      l_estado          VARCHAR2(30) := NULL;


      CURSOR c_rt IS
        SELECT tipo_liquidacion
          FROM XX_TCG_RT
         WHERE liquidacion_id = p_liq_id;

      CURSOR c_boletin IS
        SELECT xtbh.estado
          FROM XX_TCG_BOLETIN_HEADERS      xtbh
             , XX_TCG_LIQUIDACIONES_1116A  xtla
         WHERE xtbh.boletin_header_id = xtla.boletin_header_id
           AND xtla.liquidacion_id    = p_liq_id;



    BEGIN

      IF (NVL(p_cancelado,'N')='Y') THEN

        RETURN 'SX';

      ELSIF (p_tipo_liq = '1116A') THEN

        IF (NVL(p_liquidado,'N') = 'Y' AND p_num_liq IS NULL
          AND p_num_pre IS NOT NULL) THEN

          RETURN 'CE';

        ELSE

          IF (p_num_liq IS NULL) THEN

            RETURN 'CD';

          ELSE

            OPEN c_boletin;
            FETCH c_boletin INTO l_estado;
            CLOSE c_boletin;

            IF (l_estado IS NULL) THEN
              RETURN 'CD';
            ELSIF (l_estado='CONFORMADO') THEN
              RETURN 'CD';
            ELSIF (l_estado='ANALIZADO') THEN
              RETURN 'IC';
            END IF;

          END IF;

        END IF;

      ELSIF (p_tipo_liq = '1116RT') THEN

        OPEN c_rt;
        FETCH c_rt INTO l_tipo_liq;
        CLOSE c_rt;

        IF (l_tipo_liq = 'RETIRO') THEN
          RETURN 'CR';
        ELSIF (l_tipo_liq = 'TRANSFERENCIA') THEN
          RETURN 'CT';
        END IF;

      END IF;

    END Get_metodo_certificado;



    FUNCTION Get_Fields_CGRT ( p_line           VARCHAR2
                             , p_reg_type       NUMBER
                             , p_liq_id         NUMBER
                             , p_metodo_cert    VARCHAR2
                             , p_ret_val1  OUT  VARCHAR2
                             , p_ret_val2  OUT  VARCHAR2
                             )
    RETURN BOOLEAN IS

      l_line_tmp    VARCHAR2(3000) := p_line;
      l_existe      VARCHAR2(20);
      l_R00003      NUMBER;                     --Pto Emision
      l_R00004      NUMBER;                     --Nro de Orden
      l_R09002      VARCHAR2(20);               --Fecha Liquidacion/Certificado
      l_R09014      NUMBER;                     --COE
      l_R10001      VARCHAR2(30);               --Codigo Errores Estructura
      l_R10002      VARCHAR2(1000);              --Descripcion Errores Estructura
      l_R11001      VARCHAR2(30);               --Codigo Errores AFIP
      l_R11002      VARCHAR2(1000);              --Descripcion Errores AFIP
      l_R25001      VARCHAR2(2);                --Estado
      l_R25002      NUMBER;                     --Peso Bruto Certificado
      l_R25003      NUMBER;                     --Peso Merma Volatil
      l_R25004      NUMBER;                     --Peso Merma Secado
      l_R25005      NUMBER;                     --Peso Merma Zarandeo
      l_R25006      NUMBER;                     --Peso Neto Certificado
      l_R25007      NUMBER;                     --Servicio Secado
      l_R25008      NUMBER;                     --Servicio Zarandeo
      l_R25009      NUMBER;                     --Servicios Otros
      l_R25010      NUMBER;                     --Servicios Gastos Genrales
      l_R25011      NUMBER;                     --Importe IVA
      l_R25012      NUMBER;                     --Servicios Total
      l_R25013      NUMBER;                     --Numero de Planta
      l_R25014      NUMBER;                     --CUIT Titular Planta
      l_R25015      VARCHAR2(200);              --Razon Social Titular Planta
      l_R25016      NUMBER;                     --Cuit Depositario
      l_R25017      NUMBER;                     --Alicuota IVA
      l_R25018      NUMBER;                     --Codigo Localidad
      l_R25019      NUMBER;                     --Codigo Provincia
      l_field       VARCHAR2(20);
      l_posicion    NUMBER;



    BEGIN

      l_line_tmp := l_line_tmp ||';';


      IF (p_reg_type = 90) THEN

        FOR i IN 1..18 LOOP

          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (i=2) THEN
            l_field  := 'R09002';
            l_R09002 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (i=14) THEN
            l_field  := 'R09014';
            l_R09014 := TO_NUMBER(REPLACE(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1),'-',''));
          END IF;

        END LOOP;

        p_ret_val1 := l_R09014;

        IF (p_metodo_cert IN ('CR','CT')) THEN

          UPDATE XX_TCG_RT
             SET numero_liquidacion = SUBSTR(l_R09014,1,4)||'-'||SUBSTR(l_R09014,5,8)
               , fecha_liquidacion  = TO_DATE(l_R09002,'RRRRMMDD')
           WHERE liquidacion_id     = p_liq_id;

        ELSE

          UPDATE XX_TCG_LIQUIDACIONES_1116A
             SET numero_liquidacion = SUBSTR(l_R09014,1,4)||'-'||SUBSTR(l_R09014,5,8)
               , fecha_liquidacion  = TO_DATE(l_R09002,'RRRRMMDD')
           WHERE liquidacion_id     = p_liq_id;

        END IF;


      ELSIF (p_reg_type = 100) THEN

        FOR i IN 1..2 LOOP

          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (i=1) THEN
            l_field  := 'R10001';
            l_R10001 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (i=2) THEN
            l_field  := 'R10002';
            l_R10002 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          END IF;

        END LOOP;

        IF (l_R10001 IS NOT NULL) OR
          (l_R10002 IS NOT NULL) THEN

          p_ret_val1 := l_R10001;
          p_ret_val2 := l_R10002;

        END IF;

      ELSIF (p_reg_type = 110) THEN

        FOR i IN 1..2 LOOP

          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (i=1) THEN
            l_field  := 'R11001';
            l_R11001 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (i=2) THEN
            l_field  := 'R11002';
            l_R11002 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          END IF;

        END LOOP;

        IF (l_R11001 IS NOT NULL) OR
          (l_R11002 IS NOT NULL) THEN

          p_ret_val1 := l_R11001;
          p_ret_val2 := l_R11002;

        END IF;


      ELSIF (p_reg_type = 250) THEN


        FOR i IN 1..19 LOOP

          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));
          l_field  := 'R250'||LPAD(i,2,0);

          IF (i=1) THEN
            l_R25001 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (i=2) THEN
            l_R25002 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=3) THEN
            l_R25003 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=4) THEN
            l_R25004 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=5) THEN
            l_R25005 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=6) THEN
            l_R25006 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=7) THEN
            l_R25007 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=8) THEN
            l_R25008 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=9) THEN
            l_R25009 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=10) THEN
            l_R25010 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=11) THEN
            l_R25011 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=12) THEN
            l_R25012 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=13) THEN
            l_R25013 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=14) THEN
            l_R25014 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=15) THEN
            l_R25015 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (i=16) THEN
            l_R25016 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=17) THEN
            l_R25017 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=18) THEN
            l_R25018 := TO_NUMBER(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (i=19) THEN

            SELECT INSTR(l_line_tmp,chr(13),1,1) --Se determina la existencia de retorno de carro
              INTO l_posicion
              FROM DUAL;

            IF (l_posicion = 0 OR l_posicion IS NULL) THEN
              l_R25019 := TO_NUMBER(TRIM(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1)));
            ELSE
              l_R25019 := TO_NUMBER(TRIM(substr(l_line_tmp, 1, (l_posicion-1))));
            END IF;

          END IF;

        END LOOP;

        IF (p_metodo_cert IN ('CR','CT')) THEN

          UPDATE XX_TCG_RT
             SET cgrt_cuit_depositario = l_R25016
               , cgrt_alicuota_iva     = l_R25017
               , cgrt_codigo_localidad = l_R25018
               , cgrt_codigo_provincia = l_R25019
           WHERE liquidacion_id = p_liq_id;

        ELSE

          UPDATE XX_TCG_LIQUIDACIONES_1116A
             SET cgrt_estado                   = l_R25001
               , cgrt_peso_bruto_certificado   = l_R25002
               , cgrt_peso_merma_volatil       = l_R25003
               , cgrt_peso_merma_secado        = l_R25004
               , cgrt_peso_merma_zarandeo      = l_R25005
               , cgrt_peso_neto_certificado    = l_R25006
               , cgrt_servicio_secado          = l_R25007
               , cgrt_servicio_zarandeo        = l_R25008
               , cgrt_servicios_otros          = l_R25009
               , cgrt_servicios_gastos_grales  = l_R25010
               , cgrt_importe_iva              = l_R25011
               , cgrt_servicio_total           = l_R25012
               , cgrt_numero_planta            = l_R25013
               , cgrt_cuit_titular_planta      = l_R25014
               , cgrt_razon_social_tit_planta  = l_R25015
               , cgrt_cuit_depositario         = l_R25016
               , cgrt_alicuota_iva             = l_R25017
               , cgrt_codigo_localidad         = l_R25018
               , cgrt_codigo_provincia         = l_R25019
           WHERE liquidacion_id = p_liq_id;

        END IF;


      END IF;

      RETURN (TRUE);

    EXCEPTION
      WHEN others THEN
        p_ret_val1 := p_metodo_cert;
        p_ret_val2 := 'Error en registro '||p_reg_type||' - Campo: '||l_field||'. Detalle: '||SQLERRM;

        RETURN (FALSE);

    END Get_Fields_CGRT;


  BEGIN

--    XX_DEBUG_AUX_PK.debug( p_module => 'XXTCGLIA'
--                         , p_message => 'Inicio Lee_archivo_CGRT');

    SELECT FND_PROFILE.value('XX_ACO_PATH_CG_RCV')
      INTO l_in_dir
      FROM DUAL;

    l_in := UTL_FILE.Fopen_nchar (l_in_dir, l_fname, 'R', 32767);

    FOR I IN 1..5 LOOP

      l_fname := substr(l_fname, instr(l_fname, '_')+1, length(l_fname));

      IF I = 2 THEN
        l_pto_emision := substr(l_fname, 1, instr(l_fname, '_')-1);

--        XX_DEBUG_AUX_PK.debug( p_module => 'XXTCGLIA'
--                             , p_message => 'l_pto_emision: '||l_pto_emision);

      ELSIF I = 3 THEN
        l_nro_orden := substr(l_fname, 1, instr(l_fname, '_')-1);

--        XX_DEBUG_AUX_PK.debug( p_module => 'XXTCGLIA'
--                         , p_message => 'l_nro_orden: '||l_nro_orden);

      ELSIF I = 4 THEN
        l_liq_id := to_number(substr(l_fname, 1, instr(l_fname, '_')-1));

--        XX_DEBUG_AUX_PK.debug( p_module => 'XXTCGLIA'
--                         , p_message => 'l_liq_id: '||l_liq_id);

      ELSIF I = 5 THEN
        SELECT DECODE(substr(l_fname, 1, 1), 'R', 'R'       -- Archivo reprocesado
                                           , 'r', 'R'
                                           , 'O')           -- Original
          INTO l_cond_arch
          FROM DUAL;

--        XX_DEBUG_AUX_PK.debug( p_module => 'XXTCGLIA'
--                         , p_message => 'l_cond_arch: '||l_cond_arch);

      END IF;

    END LOOP;


    OPEN c_liq (l_liq_id);
    FETCH c_liq INTO l_tipo_liq
                   , l_num_liq
                   , l_num_pre
                   , l_liquidado
                   , l_cancelado
                   , l_liq_sin_cal
                   , l_estado_boletin;
    l_found := c_liq%FOUND;
    CLOSE c_liq;

    IF (NOT l_found) THEN
      RAISE eNoEspResp;
    END IF;


    IF (l_tipo_liq = '1116A_ACO') THEN

      UTL_FILE.fclose (l_in);

      XX_ACO_WEBSERVICES_PK.lee_archivo_CGRT ( p_fname    => p_fname
                                             , p_err_msg  => p_err_msg
                                             );
      GOTO Fin_leer_archivo;

    END IF;


    IF NOT Check_Row ( p_tipo_liq => l_tipo_liq
                     , p_liq_id   => l_liq_id
                     , p_err_msg  => p_err_msg ) THEN

      RAISE eROWLOCKED;
    END IF;


    l_metodo_cert := Get_metodo_certificado( l_tipo_liq
                                           , l_liq_id
                                           , l_num_liq
                                           , l_cancelado
                                           , l_liquidado
                                           , l_liq_sin_cal
                                           , l_num_pre);



    IF ((l_tipo_liq='1116A' AND ((l_num_liq IS NULL AND l_num_pre IS NOT NULL AND l_liquidado = 'Y')                -- Liquidacion preexistente
                                 OR (l_estado_boletin = 'GRUPO')                                                    -- Liquidacion preexistente con grupo de boletines
                                 OR (l_num_liq IS NULL AND l_estado_boletin = 'CONFORMADO' AND l_liq_sin_cal = 'Y') -- Certif sin calidad
                                 OR (l_estado_boletin = 'ANALIZADO' AND l_liquidado = 'Y')                          -- Certif con calidad
                                 OR (l_num_liq IS NOT NULL AND l_cancelado = 'Y')))                                 -- 1116A Anulada
      OR (l_tipo_liq='1116RT' AND ((l_num_liq IS NULL AND l_liquidado='Y')                                           -- Liq RT
                                   OR (l_num_liq IS NOT NULL AND l_cancelado='Y')))) THEN                            -- 1116RT Anulada

      BEGIN

        LOOP

          UTL_FILE.get_line_nchar (l_in, l_line);


          IF (substr(l_line,1,instr(l_line,';')-1) = '090')  AND
             (NVL(l_error_flag, 'N')               = 'N')    AND
             (l_metodo_cert NOT IN ('IC','SX'))              THEN


            IF Get_Fields_CGRT ( p_line        => l_line
                               , p_reg_type    => 90
                               , p_liq_id      => l_liq_id
                               , p_metodo_cert => l_metodo_cert
                               , p_ret_val1    => l_ret_val1
                               , p_ret_val2    => l_ret_val2
                               )
            THEN
              IF (SUBSTR(l_ret_val1,1,2)='33') THEN
                l_coe := l_ret_val1;
                l_error_flag := 'N';
              ELSE
                l_error_flag := 'Y';
              END IF;
            ELSE
              l_error_flag := 'Y';
            END IF;


          ELSIF (substr(l_line,1,instr(l_line,';')-1) IN ('100','110'))  AND
             (NVL(l_error_flag, 'N')               = 'N')       AND
             (l_metodo_cert <> 'IC')                            THEN

            IF Get_Fields_CGRT ( p_line        => l_line
                               , p_reg_type    => substr(l_line,1,instr(l_line,';')-1)
                               , p_liq_id      => l_liq_id
                               , p_metodo_cert => l_metodo_cert
                               , p_ret_val1    => l_ret_val1
                               , p_ret_val2    => l_ret_val2
                               )
            THEN
              l_error_afip := 'Y';

              IF (substr(l_line,1,instr(l_line,';')-1)='100') THEN
                l_afip_10001 := SUBSTR(l_ret_val1,1,30);
                l_afip_10002 := l_ret_val2;
              ELSIF (substr(l_line,1,instr(l_line,';')-1)='110') THEN
                l_afip_11001 := SUBSTR(l_ret_val1,1,30);
                l_afip_11002 := l_ret_val2;
              END IF;
                --
            ELSE
              l_error_flag := 'Y';
            END IF;



          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '250')    AND
              (NVL(l_error_flag, 'N')                 = 'N')      AND
              (l_metodo_cert NOT IN ('IC','SX'))                  THEN

            IF Get_Fields_CGRT ( p_line        => l_line
                               , p_reg_type    => 250
                               , p_liq_id      => l_liq_id
                               , p_metodo_cert => l_metodo_cert
                               , p_ret_val1    => l_ret_val1
                               , p_ret_val2    => l_ret_val2
                               )
            THEN
              l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';
            END IF;

          END IF;

        END LOOP;

      EXCEPTION
        WHEN no_data_found THEN
          UTL_FILE.fclose (l_in);
      END;

    ELSE
      RAISE eREPROC;
    END IF;


    IF NVL(l_error_flag,'N') = 'N'   AND
       NVL(l_error_afip,'N') = 'N'   THEN

      Finalizar_Liquidacion_CGRT (l_liq_id, l_tipo_liq, l_coe, l_pto_emision, l_nro_orden
                                 , l_metodo_cert, l_cancelado, l_cond_arch, p_fname, p_err_msg);

    ELSIF l_error_flag = 'Y' THEN

      RAISE eGETLINE;

    ELSIF l_error_afip = 'Y' THEN

      RAISE eAFIP;

    END IF;

    <<Fin_leer_archivo>>
    NULL;

  EXCEPTION
    WHEN eROWLOCKED THEN
      ROLLBACK;

    WHEN eREPROC THEN
      ROLLBACK;
      p_err_msg := 'FILEERRR: El archivo '||p_fname||' ya fue procesado'; -- No cambiar mensaje, lo utiliza el RcvCOEDmon

    WHEN eGETLINE THEN
      ROLLBACK;
      Grabar_Error_CGRT ( p_liq_id     => l_liq_id
                        , p_tipo_liq   => l_tipo_liq
                        , p_tipo_coe   => l_metodo_cert
                        , p_ret_val1   => l_ret_val1
                        , p_ret_val2   => l_ret_val2
                        , p_cancelado  => l_cancelado
                        , p_err_msg    => p_err_msg);


    WHEN eAFIP THEN
      ROLLBACK;

      IF (l_afip_10001 IS NOT NULL OR
         l_afip_10002 IS NOT NULL) THEN

         Grabar_Error_CGRT ( p_liq_id     => l_liq_id
                           , p_tipo_liq   => l_tipo_liq
                           , p_tipo_coe   => l_metodo_cert
                           , p_ret_val1   => l_afip_10001
                           , p_ret_val2   => l_afip_10002
                           , p_cancelado  => l_cancelado
                           , p_err_msg    => p_err_msg);
      END IF;

      IF (l_afip_11001 IS NOT NULL OR
         l_afip_11002 IS NOT NULL) THEN

        Grabar_Error_CGRT ( p_liq_id     => l_liq_id
                          , p_tipo_liq   => l_tipo_liq
                          , p_tipo_coe   => l_metodo_cert
                          , p_ret_val1   => l_afip_11001
                          , p_ret_val2   => l_afip_11002
                          , p_cancelado  => l_cancelado
                          , p_err_msg    => p_err_msg);
      END IF;

    WHEN eNoEspResp THEN
      p_err_msg := 'Lee archivo CG/RT-> Existe archivo en carpeta pero la liquidacion '||l_liq_id||' no se encuentra en ESP_RESP';

    WHEN UTL_FILE.INVALID_PATH THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo CG/RT-> Invalid path '||SQLERRM;

    WHEN UTL_FILE.INVALID_MODE THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo CG/RT-> Invalid Mode '||SQLERRM;

    WHEN UTL_FILE.INVALID_OPERATION THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo CG/RT-> Invalid Operations '||SQLERRM;

    WHEN UTL_FILE.READ_ERROR THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo CG/RT-> Read Error '||SQLERRM;

    WHEN UTL_FILE.WRITE_ERROR THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo CG/RT-> Write Error '||SQLERRM;

    WHEN Others THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo CG/RT-> '||SQLERRM;

  END lee_archivo_CGRT;




 /*****************************************************************************
 *                                                                            *
 * Name: Lee_Archivo                                                          *
 * Purpose: Procedimiento encargado de leer los archivos enviados por         *
 *         PlanexWare. En base a lo informado, continua con la finalizacion   *
 *         de la liquidacion de Granos o informa los errores                  *
 *                                                                            *
 ******************************************************************************/
  PROCEDURE lee_archivo ( p_fname          VARCHAR2
                        , p_contingencia   VARCHAR2 DEFAULT 'N'
                        , p_err_msg    OUT VARCHAR2
                        ) IS


    l_in           UTL_FILE.file_type;
    l_in_dir       VARCHAR2(100) ;
    l_fname        VARCHAR2(200) := p_fname;
    l_line         VARCHAR2(1000);
    l_pto_emision  NUMBER;
    l_nro_orden    NUMBER;
    l_liq_id       NUMBER;
    l_tipo_coe     VARCHAR2(10);
    l_coe          VARCHAR2(30) := NULL;
    l_ret_val1     VARCHAR2(1000) := NULL;
    l_ret_val2     VARCHAR2(1000) := NULL;
    l_error_flag   VARCHAR2(1);
    l_error_afip   VARCHAR2(1);
    l_liquidado    VARCHAR2(1);
    l_cancelado    VARCHAR2(1);
    l_tipo_origen  VARCHAR2(50);
    eUPDRET        EXCEPTION;
    eROWLOCKED     EXCEPTION;
    eREPROC        EXCEPTION;
    eGETLINE       EXCEPTION;
    eAFIP          EXCEPTION;
    l_cond_arch    VARCHAR2(1);
    l_estado_coe   VARCHAR2(30);



    FUNCTION Get_Fields ( p_line           VARCHAR2
                        , p_reg_type       NUMBER
                        , p_liq_id         NUMBER
                        , p_cancelado      VARCHAR2
                        , p_contingencia   VARCHAR2
                        , p_tipo_coe       VARCHAR2
                        , p_ret_val1  OUT  VARCHAR2
                        , p_ret_val2  OUT  VARCHAR2 )
    RETURN BOOLEAN
    IS

      l_line_tmp                  VARCHAR2(3000) := replace(replace(p_line, chr(10),';'), chr(13), ';');
      l_coe                       VARCHAR2(30);
      l_R07002                    VARCHAR2(50);                                 -- detalle aclaratorio
      l_R07006                    NUMBER;                                       -- coe_importe_deduccion
      l_R07008                    NUMBER;                                       -- coe_total_deduccion
      l_R07009                    NUMBER;                                       -- coe_importe_iva_deduccion
      l_coe_nro_op_comercial      NUMBER;                                       --l_R09001    NUMBER;     -- coe_nro_op_comercial
      l_coe_precio_operacion      NUMBER;                                       --l_R09003    NUMBER;     -- coe_precio_operacion
      l_coe_subtotal              NUMBER;                                       --l_R09004    NUMBER;     -- coe_subtotal
      l_coe_iva                   NUMBER;                                       --l_R09005    NUMBER;     -- coe_iva
      l_coe_operacion_iva         NUMBER;                                       --l_R09006    NUMBER;     -- coe_operacion_iva
      l_coe_tot_peso_neto         NUMBER;                                       --l_R09007    NUMBER;     -- coe_tot_peso_neto
      l_coe_total_retencion       NUMBER;                                       --l_R09008    NUMBER;     -- coe_total_retencion
      l_coe_total_retencion_afip  NUMBER;                                       --l_R09009    NUMBER;     -- coe_total_retencion_afip
      l_coe_total_retencion_otras NUMBER;                                       --l_R09010    NUMBER;     -- coe_total_retencion_otras
      l_coe_total_neto            NUMBER;                                       --l_R09011    NUMBER;     -- coe_total_neto
      l_coe_total_iva_rg2300_07   NUMBER;                                       --l_R09012    NUMBER;     -- coe_total_iva_rg2300_07
      l_coe_total_pago            NUMBER;                                       --l_R09013    NUMBER;     -- coe_total_pago
      l_coe_anul_flag             VARCHAR2(2);                                  --l_R09016    VARCHAR2(2); -- coe_anul_flag
      l_coe_total_deducciones     NUMBER;                                       --l_R09017    NUMBER;     -- coe_total_deducciones
      l_R01701                    VARCHAR2(5);
      l_R01704                    NUMBER;
      l_R01705                    NUMBER;
      l_R09501                    NUMBER;                                       -- Sub Total Gral
      l_R09502                    NUMBER;                                       -- iva 10%
      l_R09503                    NUMBER;                                       -- iva 21%
      l_R09504                    NUMBER;                                       -- Retencion Ganancias
      l_R09505                    NUMBER;                                       -- Retencion IVA
      l_R09506                    NUMBER;                                       -- Importe Neto
      l_R09507                    NUMBER;                                       -- Iva RG2300/2007
      l_R09508                    NUMBER;                                       -- Pago Segun Condicion
      l_R09510                    NUMBER;                                       -- Sub Total DebitoCredito
      l_R09511                    NUMBER;                                       -- Total Base Deducciones
      l_R09512                    NUMBER;                                       -- Iva Deducciones
      l_R09513                    NUMBER;                                       -- Importe Otras Retenciones

    BEGIN

      l_line_tmp := l_line_tmp || ';';


      IF (p_reg_type = 15)
        AND (p_tipo_coe = 'AJU') THEN

        FOR I IN 1..27 LOOP

          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 14) THEN
            l_coe_nro_op_comercial := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 16) THEN
            l_coe_precio_operacion := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 17) THEN
            l_coe_subtotal := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 18) THEN
            l_coe_iva := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 19) THEN
            l_coe_operacion_iva := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 20) THEN
            l_coe_tot_peso_neto := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 21) THEN
            l_coe_total_deducciones := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 22) THEN
            l_coe_total_retencion := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 23) THEN
            l_coe_total_retencion_afip := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 24) THEN
            l_coe_total_retencion_otras := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 25) THEN
            l_coe_total_neto := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 26) THEN
            l_coe_total_iva_rg2300_07 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 27) THEN
            l_coe_total_pago := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          END IF;

        END LOOP;

        IF (p_cancelado = 'N')
          OR (p_contingencia = 'Y') THEN

          UPDATE XX_TCG_LIQUIDACIONES
             SET coe_nro_op_comercial_cr      = l_coe_nro_op_comercial
               , coe_precio_operacion_cr      = l_coe_precio_operacion
               , coe_subtotal_cr              = l_coe_subtotal
               , coe_iva_cr                   = l_coe_iva
               , coe_operacion_iva_cr         = l_coe_operacion_iva
               , coe_tot_peso_neto_cr         = l_coe_tot_peso_neto
               , coe_total_retencion_cr       = l_coe_total_retencion
               , coe_total_retencion_afip_cr  = l_coe_total_retencion_afip
               , coe_total_retencion_otras_cr = l_coe_total_retencion_otras
               , coe_total_neto_cr            = l_coe_total_neto
               , coe_total_iva_rg2300_07_cr   = l_coe_total_iva_rg2300_07
               , coe_total_pago_cr            = l_coe_total_pago
               , coe_total_deducciones_cr     = l_coe_total_deducciones
           WHERE liquidacion_id               = p_liq_id;

        END IF;

      ELSIF (p_reg_type = 16)
        AND (p_tipo_coe = 'AJU') THEN

        FOR I IN 1..27 LOOP
          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 14) THEN
            l_coe_nro_op_comercial := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 16) THEN
            l_coe_precio_operacion := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 17) THEN
            l_coe_subtotal := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 18) THEN
            l_coe_iva := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 19) THEN
            l_coe_operacion_iva := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 20) THEN
            l_coe_tot_peso_neto := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 21) THEN
            l_coe_total_deducciones := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 22) THEN
            l_coe_total_retencion := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 23) THEN
            l_coe_total_retencion_afip := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 24) THEN
            l_coe_total_retencion_otras := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 25) THEN
            l_coe_total_neto := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 26) THEN
            l_coe_total_iva_rg2300_07 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 27) THEN
            l_coe_total_pago := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          END IF;

        END LOOP;

        IF (p_cancelado = 'N')
          OR (p_contingencia = 'Y') THEN

          UPDATE XX_TCG_LIQUIDACIONES
            SET coe_nro_op_comercial      = l_coe_nro_op_comercial
              , coe_precio_operacion      = l_coe_precio_operacion
              , coe_subtotal              = l_coe_subtotal
              , coe_iva                   = l_coe_iva
              , coe_operacion_iva         = l_coe_operacion_iva
              , coe_tot_peso_neto         = l_coe_tot_peso_neto
              , coe_total_retencion       = l_coe_total_retencion
              , coe_total_retencion_afip  = l_coe_total_retencion_afip
              , coe_total_retencion_otras = l_coe_total_retencion_otras
              , coe_total_neto            = l_coe_total_neto
              , coe_total_iva_rg2300_07   = l_coe_total_iva_rg2300_07
              , coe_total_pago            = l_coe_total_pago
              , coe_total_deducciones     = l_coe_total_deducciones
          WHERE liquidacion_id            = p_liq_id;

        END IF;
        --
      ELSIF (p_reg_type = 17) THEN

        FOR I IN 1..5 LOOP
          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 1) THEN
            l_R01701 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (I = 4) THEN
            l_R01704 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 5) THEN
            l_R01705 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          END IF;

        END LOOP;

        IF (p_cancelado = 'N')
          OR (p_contingencia = 'Y') THEN

          IF (l_R01701 = 'D') THEN

            IF (l_R01704 = 0) THEN

              UPDATE XX_TCG_LIQUIDACIONES
                 SET coe_iva_no_gravado = coe_iva_no_gravado + l_R01705
               WHERE liquidacion_id     = p_liq_id;

            ELSIF (l_R01704 = 10.5) THEN

              UPDATE XX_TCG_LIQUIDACIONES
                 SET coe_iva_diferencial = coe_iva_diferencial + l_R01705
               WHERE liquidacion_id      = p_liq_id;

            ELSIF (l_R01704 = 21) THEN

              UPDATE XX_TCG_LIQUIDACIONES
                 SET coe_iva_gravado = coe_iva_gravado + l_R01705
               WHERE liquidacion_id  = p_liq_id;

            END IF;

          ELSIF (l_R01701 = 'C') THEN

            IF (l_R01704 = 0) THEN

              UPDATE XX_TCG_LIQUIDACIONES
                 SET coe_iva_no_gravado_cr = coe_iva_no_gravado_cr + l_R01705
               WHERE liquidacion_id        = p_liq_id;

            ELSIF (l_R01704 = 10.5) THEN

              UPDATE XX_TCG_LIQUIDACIONES
                 SET coe_iva_diferencial_cr = coe_iva_diferencial_cr + l_R01705
               WHERE liquidacion_id         = p_liq_id;

            ELSIF (l_R01704 = 21) THEN

              UPDATE XX_TCG_LIQUIDACIONES
                 SET coe_iva_gravado_cr = coe_iva_gravado_cr + l_R01705
               WHERE liquidacion_id     = p_liq_id;

            END IF;

          END IF;

        END IF;

      ELSIF (p_reg_type = 70) THEN

        IF (substr(l_line_tmp, 1, instr(l_line_tmp, 'Final')+4) != '070;OD;Acopio Pendiente de Final') THEN

          FOR I IN 1..9 LOOP

            l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

            IF (I = 2) THEN
              l_R07002 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
            ELSIF (I = 6) THEN
              l_R07006 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
            ELSIF (I = 8) THEN
              l_R07008 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
            ELSIF (I = 9) THEN
              l_R07009 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
            END IF;

          END LOOP;

          IF (p_cancelado = 'N')
            OR (p_contingencia = 'Y') THEN

            UPDATE XX_TCG_LIQUIDACION_SERVICIOS
               SET coe_importe_deduccion     = l_R07006
                 , coe_total_deduccion       = l_R07008
                 , coe_importe_iva_deduccion = l_R07009
             WHERE liquidacion_id = p_liq_id
               AND memo_line_id   = ( SELECT ls.memo_line_id
                                        FROM XX_TCG_LIQUIDACIONES         lb
                                           , XX_TCG_LIQUIDACION_SERVICIOS ls
                                           , AR_MEMO_LINES_ALL_VL         aml
                                           , AR_MEMO_LINES_ALL_B_DFV      amld
                                       WHERE 1=1
                                         AND ls.liquidacion_id (+) = lb.liquidacion_id
                                         AND aml.memo_line_id  (+) = ls.memo_line_id
                                         AND aml.row_id            = amld.row_id (+)
                                         AND lb.liquidacion_id     = p_liq_id
                                         AND substr(aml.name,1,30) = l_R07002);

          END IF;

        END IF;

      ELSIF (p_reg_type = 80) THEN

        FOR I IN 1..8 LOOP

          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 2) THEN
            p_ret_val1 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (I = 8) THEN
            p_ret_val2 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          END IF;

        END LOOP;

      ELSIF (p_reg_type = 90) THEN

        FOR I IN 1..17 LOOP
          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 1) THEN
            l_coe_nro_op_comercial := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 3) THEN
            l_coe_precio_operacion := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 4) THEN
            l_coe_subtotal := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 5) THEN
            l_coe_iva := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 6) THEN
            l_coe_operacion_iva := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 7) THEN
            l_coe_tot_peso_neto := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 8) THEN
            l_coe_total_retencion := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 9) THEN
            l_coe_total_retencion_afip := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 10) THEN
            l_coe_total_retencion_otras := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 11) THEN
            l_coe_total_neto := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 12) THEN
            l_coe_total_iva_rg2300_07 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 13) THEN
            l_coe_total_pago := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 14) THEN
            p_ret_val1 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);

            SELECT substr(lpad(p_ret_val1,12,0),1,4)||'-'||substr(lpad(p_ret_val1,12,0),5,8)
              INTO p_ret_val1
              FROM DUAL;

          ELSIF (I = 16) THEN
            l_coe_anul_flag := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
            p_ret_val2 := l_coe_anul_flag;
          ELSIF (I = 17) THEN
            l_coe_total_deducciones := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          END IF;

        END LOOP;

        IF (p_cancelado = 'N')
          OR (p_contingencia = 'Y') THEN

          IF (p_tipo_coe != 'AJU') THEN

            UPDATE XX_TCG_LIQUIDACIONES
               SET coe_nro_op_comercial      = l_coe_nro_op_comercial
                 , coe_precio_operacion      = l_coe_precio_operacion
                 , coe_subtotal              = l_coe_subtotal
                 , coe_iva                   = l_coe_iva
                 , coe_operacion_iva         = l_coe_operacion_iva
                 , coe_tot_peso_neto         = l_coe_tot_peso_neto
                 , coe_total_retencion       = l_coe_total_retencion
                 , coe_total_retencion_afip  = l_coe_total_retencion_afip
                 , coe_total_retencion_otras = l_coe_total_retencion_otras
                 , coe_total_neto            = l_coe_total_neto
                 , coe_total_iva_rg2300_07   = l_coe_total_iva_rg2300_07
                 , coe_total_pago            = l_coe_total_pago
                 , coe_total_deducciones     = l_coe_total_deducciones
             WHERE liquidacion_id            = p_liq_id;

            UPDATE XX_TCG_LIQUIDACION_RETENCIONES
               SET monto_ret_afip = l_coe_total_iva_rg2300_07 * -1
             WHERE liquidacion_id = l_liq_id
               AND tax_description LIKE 'IVA%CBU%';

          END IF;

        END IF;

      ELSIF (p_reg_type = 95) THEN

        FOR I IN 1..13 LOOP
          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 1) THEN
            l_R09501 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 2) THEN
            l_R09502 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 3) THEN
            l_R09503 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 4) THEN
            l_R09504 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 5) THEN
            l_R09505 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 6) THEN
            l_R09506 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 7) THEN
            l_R09507 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 8) THEN
            l_R09508 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 10) THEN
            l_R09510 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 11) THEN
            l_R09511 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 12) THEN
            l_R09512 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          ELSIF (I = 13) THEN
            l_R09513 := to_number(substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1));
          END IF;

        END LOOP;

        IF (p_cancelado = 'N')
          OR (p_contingencia = 'Y') THEN

          UPDATE XX_TCG_LIQUIDACIONES
             SET coe_subtotal_ajto             = l_R09501
               , coe_iva_diferencial_ajto      = l_R09502
               , coe_iva_gravado_ajto          = l_R09503
               , coe_ret_gcias_ajto            = l_R09504
               , coe_ret_iva_ajto              = l_R09505
               , coe_importe_neto_ajto         = l_R09506
               , coe_total_iva_rg2300_07_ajto  = l_R09507
               , coe_total_pago_ajto           = l_R09508
               , coe_subtotal_deb_cre_ajto     = l_R09510
               , coe_tot_base_deduc_ajto       = l_R09511
               , coe_iva_deducciones_ajto      = l_R09512
               , coe_total_reten_otras_ajto    = l_R09513
           WHERE liquidacion_id                = p_liq_id;

          UPDATE XX_TCG_LIQUIDACION_RETENCIONES
             SET monto_ret_afip = l_R09507 * -1
           WHERE liquidacion_id = l_liq_id
             AND tax_description LIKE 'IVA%CBU%';

        END IF;

      ELSIF (p_reg_type IN (100, 110)) THEN

        FOR I IN 1..2 LOOP
          l_line_tmp := substr(l_line_tmp, instr(l_line_tmp, ';')+1, length(l_line_tmp));

          IF (I = 1) THEN
            p_ret_val1 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          ELSIF (I = 2) THEN
            p_ret_val2 := substr(l_line_tmp, 1, instr(l_line_tmp, ';')-1);
          END IF;

        END LOOP;

      END IF;


      RETURN (TRUE);

    EXCEPTION
      WHEN Others THEN
        p_ret_val1 := '-1';
        p_ret_val2 := 'Error completando reg '||p_reg_type||' -> '||SQLERRM;
        RETURN (FALSE);
    END;


  /* Main Process */
  BEGIN

    IF (NVL(p_contingencia, 'N') = 'N') THEN

      SELECT DISTINCT value||'/ADECO/interface/incoming/XX_ACO_COE/RCV'
        INTO l_in_dir
        FROM FND_ENV_CONTEXT
       WHERE variable_name = 'NE_BASE';

    ELSIF (NVL(p_contingencia, 'N') = 'Y') THEN

      SELECT DISTINCT value||'/ADECO/interface/incoming/XX_ACO_COE/CONTINGENCIA'
        INTO l_in_dir
        FROM FND_ENV_CONTEXT
       WHERE variable_name = 'NE_BASE';

    END IF;

    l_in := UTL_FILE.Fopen_Nchar (l_in_dir, p_fname, 'R', 32767);

    FOR I IN 1..4 LOOP
      l_fname := substr(l_fname, instr(l_fname, '_')+1, length(l_fname));

      IF (I = 1) THEN
        l_pto_emision := substr(l_fname, 1, instr(l_fname, '_')-1);
      ELSIF (I = 2) THEN
        l_nro_orden := substr(l_fname, 1, instr(l_fname, '_')-1);
      ELSIF (I = 3) THEN
        l_liq_id := to_number(substr(l_fname, 1, instr(l_fname, '_')-1));
      ELSIF (I = 4) THEN
        SELECT DECODE(substr(l_fname, 1, 1), 'R', 'R'       -- Archivo reprocesado
                                           , 'r', 'R'
                                           , 'O')           -- Original
          INTO l_cond_arch
          FROM DUAL;
      END IF;

    END LOOP;

    IF (NOT Check_Row ( p_liq_id  => l_liq_id
                     , p_err_msg  => p_err_msg )) THEN
      RAISE eROWLOCKED;
    END IF;

    SELECT nvl(xtl.liquidado_flag,'N')                         liquidado_flag
         , nvl(xtl.cancelado_flag,'N')                         cancelado_flag
         , xtl.numero_liquidacion
         , DECODE(xtl.tipo_liquidacion, 'AJUSTE_UNICO', 'AJU'
                                      , 'FINAL', 'AJU'
                                      , 'LIQ')                 tipo_coe
         , DECODE(xtl.contrato_id, NULL, 'PROPIO', 'TERCERO')  tipo_origen
         , estado_coe
      INTO l_liquidado
         , l_cancelado
         , l_coe
         , l_tipo_coe
         , l_tipo_origen
         , l_estado_coe
      FROM XX_TCG_LIQUIDACIONES xtl
     WHERE 1=1
       AND xtl.liquidacion_id = l_liq_id;

    IF (l_liquidado = 'Y'
       AND l_coe IS NULL)
       OR
       (l_cancelado = 'Y')
       OR
       (l_estado_coe = 'ASIG_ERROR') THEN

      BEGIN

        LOOP

          UTL_FILE.Get_Line_Nchar (l_in, l_line);

          IF (substr(l_line,1,instr(l_line,';')-1) = '015')
            AND (NVL(l_error_flag,'N') = 'N')
            AND (l_cancelado = 'N' OR p_contingencia = 'Y') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 15
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

              l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';

            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '016')
            AND (NVL(l_error_flag,'N') = 'N')
            AND (l_cancelado = 'N' OR p_contingencia = 'Y') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 16
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

              l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';

            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '017')
            AND (NVL(l_error_flag,'N') = 'N')
            AND (l_cancelado = 'N' OR p_contingencia = 'Y') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 17
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

              l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';

            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '070')
            AND (NVL(l_error_flag,'N') = 'N')
            AND (l_cancelado = 'N' OR p_contingencia = 'Y') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 70
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

                l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';

            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '080')
            AND (NVL(l_error_flag,'N') = 'N')
            AND (l_tipo_origen <> 'PROPIO')
            AND (l_cancelado = 'N' OR p_contingencia = 'Y') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 80
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

              BEGIN
                UPDATE XX_TCG_LIQUIDACION_RETENCIONES
                   SET monto_ret_afip  = to_number(l_ret_val2)*-1
                 WHERE liquidacion_id  = l_liq_id
                   AND tax_description = l_ret_val1;
              EXCEPTION
                WHEN Others THEN
                  p_err_msg := 'Actualiza RET -> '||SQLERRM;
                  RAISE eUPDRET;
              END;

              l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';

            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '090')
            AND (NVL(l_error_flag,'N') = 'N') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 90
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_coe
                          , p_ret_val2     => l_ret_val2 ) THEN

              IF (l_coe IS NOT NULL) THEN

                l_error_flag := 'N';

                IF (l_ret_val2 = 'R') THEN
                  l_error_flag := 'Y';
                  l_ret_val1   := '-1';
                  l_ret_val2   := 'Anulacion rechazada por AFIP';
                END IF;

              ELSE
                l_error_flag := 'Y';
              END IF;

            ELSE
              l_error_flag := 'Y';
            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) = '095')
            AND (NVL(l_error_flag,'N') = 'N')
            AND (l_cancelado = 'N' OR p_contingencia = 'Y') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => 95
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

              l_error_flag := 'N';
            ELSE
              l_error_flag := 'Y';

            END IF;

          ELSIF (substr(l_line,1,instr(l_line,';')-1) IN ('100', '110'))
            AND (NVL(l_error_flag,'N') = 'N') THEN

            IF Get_Fields ( p_line         => l_line
                          , p_reg_type     => to_number(substr(l_line,1,instr(l_line,';')-1))
                          , p_liq_id       => l_liq_id
                          , p_cancelado    => l_cancelado
                          , p_contingencia => p_contingencia
                          , p_tipo_coe     => l_tipo_coe
                          , p_ret_val1     => l_ret_val1
                          , p_ret_val2     => l_ret_val2 ) THEN

              l_error_afip := 'Y';
            ELSE
              l_error_flag := 'Y';
            END IF;

          END IF;

        END LOOP;

      EXCEPTION
        WHEN No_Data_Found THEN
          UTL_FILE.Fclose (l_in);
      END;


      IF (NVL(l_error_flag,'N') = 'N')
        AND (NVL(l_error_afip,'N') = 'N')
        AND (NVL(p_contingencia,'N') = 'N') THEN

        Finalizar_Liquidacion (l_liq_id, l_tipo_coe, l_coe, l_pto_emision, l_nro_orden
                              , l_cancelado, l_cond_arch, p_fname, p_err_msg);

      ELSIF (NVL(l_error_flag,'N') = 'N')
        AND (NVL(l_error_afip,'N') = 'N')
        AND (NVL(p_contingencia,'N') = 'Y') THEN

        COMMIT;

      ELSIF (l_error_flag = 'Y') THEN

        RAISE eGETLINE;

      ELSIF (l_error_afip = 'Y') THEN

        RAISE eAFIP;

      END IF;

    ELSE

      RAISE eREPROC;

    END IF;

  EXCEPTION
    WHEN eROWLOCKED THEN
      ROLLBACK;

    WHEN eREPROC THEN
      ROLLBACK;
      p_err_msg := 'FILEERRR: El archivo '||p_fname||' ya fue procesado'; -- No cambiar mensaje, lo utiliza el RcvCOEDmon

    WHEN eUPDRET THEN
      ROLLBACK;
      Grabar_Error (l_liq_id, l_tipo_coe, -1, p_err_msg, l_cancelado, p_err_msg);

    WHEN eGETLINE THEN
      ROLLBACK;
      Grabar_Error (l_liq_id, l_tipo_coe, l_ret_val1, l_ret_val2, l_cancelado, p_err_msg);

    WHEN eAFIP THEN
      ROLLBACK;
      Grabar_Error (l_liq_id, l_tipo_coe, l_ret_val1, l_ret_val2, l_cancelado, p_err_msg);

    WHEN Others THEN
      ROLLBACK;
      IF UTL_FILE.Is_Open (l_in) THEN
        UTL_FILE.Fclose (l_in);
      END IF;
      p_err_msg := 'Lee archivo -> '||SQLERRM;

  END Lee_Archivo;




  PROCEDURE Buscar_Datos_CTG (p_user_id             IN NUMBER,
                              p_resp_id             IN NUMBER,
                              p_resp_appl_id        IN NUMBER,
                              p_cuit_representado   IN NUMBER,
                              p_tipo_cert           IN VARCHAR2, -- P Primaria, E Preexistente, R Retiro, T Transferencia
                              p_liquidacion         IN VARCHAR2,
                              p_liquidacion_id      IN NUMBER,
                              p_cuit_depositante    IN NUMBER,
                              p_cod_grano           IN NUMBER,
                              p_lote                IN NUMBER,
                              p_numero_cp           IN NUMBER,
                              p_result             OUT BOOLEAN,
                              p_err_msg            OUT VARCHAR2) IS


    l_response            XX_WSLPG_BUSCARCTG_RESP;
    l_ctg_accion_id       NUMBER;
    l_index               NUMBER;
    l_cp_id               NUMBER;
    l_reg                 NUMBER;
    eCTGNextId            EXCEPTION;
    eCPid                 EXCEPTION;
    eInsertCTG            EXCEPTION;
    eInsertError          EXCEPTION;
    eInsertEvent          EXCEPTION;
    --Agregado CR2122
    l_insert              BOOLEAN := FALSE;
    l_nro_cp              VARCHAR2(40);
    --

  BEGIN


      XX_ACO_WSLPG_PUB.CG_Buscar_CTG( p_cuit_representado    => p_cuit_representado
                                    , p_tipo_certificado     => p_tipo_cert
                                    , p_cuit_depositante     => p_cuit_depositante
                                    , p_nro_planta           => NULL
                                    , p_cod_grano            => p_cod_grano
                                    , p_campania             => p_lote
                                    , p_nro_ctg              => NULL
                                    , p_tipo_ctg             => NULL
                                    , p_numero_carta_porte   => p_numero_cp
                                    , p_fecha_confirma_desde => NULL
                                    , p_fecha_confirma_hasta => NULL
                                    , x_response_object      => l_response
                                    , x_result               => p_result
                                    , x_error_message        => p_err_msg
                                   );

      IF (NOT p_result) THEN

        RETURN;

      ELSE

        IF (l_response.arrayDatos IS NOT NULL AND l_response.arrayDatos.COUNT > 0) THEN


          FOR l_index IN 1 .. l_response.arrayDatos.COUNT LOOP

            IF (l_response.arrayDatos(l_index).nroCtg IS NOT NULL) AND
            -- Modificao CR2122
            (l_response.arrayDatos(l_index).kilosConfirmados IS NOT NULL) THEN
            --

              BEGIN

                SELECT carta_porte_id
                  INTO l_cp_id
                  FROM XX_TCG_CARTAS_PORTE_ALL
                 WHERE numero_carta_porte = SUBSTR(LPAD(p_numero_cp,12,0),1,4)||'-'||SUBSTR(LPAD(p_numero_cp,12,0),5,LENGTH(LPAD(p_numero_cp,12,0)));
              EXCEPTION
                WHEN others THEN
                  RAISE eCPid;
              END;


              SELECT count(*)
                INTO l_reg
                FROM XX_TCG_CARTAS_PORTE_CTG
               WHERE carta_porte_id = l_cp_id
               -- Modificado CR2314
                 --AND ctg            =  l_response.arrayDatos(l_index).nroCtg
                 AND ctg_numero            =  l_response.arrayDatos(l_index).nroCtg
              --Modificado CR2168
--                 AND accion         IN ('CONSULTAR_CG', 'CONSULTAR', 'SOLICITAR')
--                 AND estado_ctg     IN ('CONFIRMACION DEFINITIVA', 'OTORGADO');
                 AND accion         = 'CONSULTAR_CG'
              --Modificado CR2314
                 --AND estado_ctg     = 'CONFIRMACION DEFINITIVA';
                 AND estado         = 'CONFIRMACION DEFINITIVA';
              --

              IF (l_reg = 0) THEN

                  BEGIN
                    SELECT XX_ACO_CARTAS_PORTE_CTG_ACC_S.nextval
                      INTO l_ctg_accion_id
                      FROM DUAL;
                  EXCEPTION
                    WHEN others THEN
                      RAISE eCTGNextId;
                  END;

                  --Agregado CR2122
                  IF (l_response.arrayDatos(l_index).NroCartaPorte IS NULL) THEN

                    l_nro_cp := SUBSTR(LPAD(p_numero_cp,12,0),1,4)||'-'||SUBSTR(LPAD(p_numero_cp,12,0),5,LENGTH(LPAD(p_numero_cp,12,0)));

                  ELSE

                    l_nro_cp := SUBSTR(LPAD(l_response.arrayDatos(l_index).NroCartaPorte,12,0),1,4) ||'-'||
                                SUBSTR(LPAD(l_response.arrayDatos(l_index).NroCartaPorte,12,0),5,
                                LENGTH(LPAD(l_response.arrayDatos(l_index).NroCartaPorte,12,0)));

                  END IF;

                  BEGIN

                    INSERT INTO XX_TCG_CARTAS_PORTE_CTG
                      (CTG_ACCION_ID,
                       CARTA_PORTE_ID,
                       --CTG, CR2314
                       CTG_NUMERO,
                       ACCION,
                       --ESTADO_CTG, CR2314
                       ESTADO,
                       --Modificado CR2168
                       --FECHA,
                       --FECHA_EMISION,
                       FECHA_OPERACION,
                       --
                       --TITULAR_CP_CUIT, CR2314
                       CUIT_REPRESENTADO,
                       NUMERO_CARTA_PORTE,
                       --COD_ONCCA, CR2314
                       ITEM_ONCCA_CODE,
                       --LOT_NO, CR2314
                       LOT_NO,
                       CREATED_BY,
                       CREATION_DATE,
                       LAST_UPDATED_BY,
                       LAST_UPDATE_DATE,
                       LAST_UPDATE_LOGIN,
                       --TIPO_CTG, CR2314
                       KILOS_CONFIRMADOS,
                       --REMITENTE_COMERCIAL_CUIT, CR2314
                       CUIT_REMITENTE_COMERCIAL,
                       --LIQUIDA_CUIT, CR2314
                       CUIT_LIQUIDA,
                       --CERTIFICA_CUIT CR2314
                       CUIT_CERTIFICA
                       )
                    VALUES
                      (l_ctg_accion_id,
                       l_cp_id,
                       l_response.arrayDatos(l_index).nroCtg,
                       'CONSULTAR_CG',
                       'CONFIRMACION DEFINITIVA',
                       TO_DATE(l_response.arrayDatos(l_index).fechaConfirmacionCtg,'RRRR-MM-DD'),
                       --Modifciado CR2168
                       --SYSDATE,
                       --
                       p_cuit_representado,
                       --v_response.arrayDatos(l_index).NroCartaPorte,
                       --Modificado CR2122
                       --SUBSTR(LPAD(l_response.arrayDatos(l_index).NroCartaPorte,12,0),1,4)
                       --||'-'||
                       --SUBSTR(LPAD(l_response.arrayDatos(l_index).NroCartaPorte,12,0),5,
                       --       LENGTH(LPAD(l_response.arrayDatos(l_index).NroCartaPorte,12,0))),
                       l_nro_cp,
                       --
                       l_response.arrayDatos(l_index).CodGrano,
                       l_response.arrayDatos(l_index).Campania,
                       p_user_id,
                       SYSDATE,
                       p_user_id,
                       SYSDATE,
                       1,
                       --v_response.arrayDatos(l_index).TipoCtg, CR2314
                       l_response.arrayDatos(l_index).KilosConfirmados,
                       l_response.arrayDatos(l_index).CuitRemitenteComercial,
                       l_response.arrayDatos(l_index).CuitLiquida,
                       l_response.arrayDatos(l_index).CuitCertifica
                       );

                       --Agregado CR2122
                       l_insert := TRUE;
                       --

                  EXCEPTION
                    WHEN others THEN
                      RAISE eInsertCTG;
                  END;

              END IF;

            END IF;

          END LOOP;

          COMMIT;

        END IF;


        IF (NVL(FND_PROFILE.value('XX_ACO_CG_VALIDA_KILOS_CONF'),'Y')='Y') AND
        -- Agregado CR2122
          (l_insert) THEN

          IF (p_liquidacion = '1116A') THEN


            IF (l_response.arrayErroresFormato IS NOT NULL AND l_response.arrayErroresFormato.COUNT > 0) THEN

              FOR l_index IN 1 .. l_response.arrayErroresFormato.COUNT LOOP

                BEGIN
                  INSERT INTO XX_TCG_LIQ1116A_ERRORES_COE
                    (LIQUIDACION_ID,
                     TIPO_COE,
                     CODIGO,
                     DESCRIPCION,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE,
                     LAST_UPDATE_LOGIN)
                  VALUES
                    (p_liquidacion_id,
                     p_liquidacion,
                     'Error Formato',
                     SUBSTR(l_response.arrayErroresFormato(l_index),1,1000),
                     p_user_id,
                     SYSDATE,
                     p_user_id,
                     SYSDATE,
                     1);
                EXCEPTION
                  WHEN others THEN
                    RAISE eInsertError;
                END;
              END LOOP;

            END IF;


            IF (l_response.arrayEventos IS NOT NULL AND l_response.arrayEventos.COUNT > 0) THEN

              FOR l_index IN 1 .. l_response.arrayEventos.COUNT LOOP

                BEGIN
                  INSERT INTO XX_TCG_LIQ1116A_ERRORES_COE
                    (LIQUIDACION_ID,
                     TIPO_COE,
                     CODIGO,
                     DESCRIPCION,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE,
                     LAST_UPDATE_LOGIN)
                  VALUES
                    (p_liquidacion_id,
                     p_liquidacion,
                     'Eventos',
                     SUBSTR(l_response.arrayEventos(l_index),1,1000),
                     p_user_id,
                     SYSDATE,
                     p_user_id,
                     SYSDATE,
                     1);
                EXCEPTION
                  WHEN others THEN
                    RAISE eInsertEvent;
                END;
              END LOOP;

            END IF;

          ELSIF (p_liquidacion = '1116RT') THEN

            IF (l_response.arrayErroresFormato IS NOT NULL AND l_response.arrayErroresFormato.COUNT > 0) THEN

              FOR l_index IN 1 .. l_response.arrayErroresFormato.COUNT LOOP

                BEGIN
                  INSERT INTO XX_TCG_RT_ERRORES_COE
                    (LIQUIDACION_ID,
                     TIPO_COE,
                     CODIGO,
                     DESCRIPCION,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE,
                     LAST_UPDATE_LOGIN)
                  VALUES
                    (p_liquidacion_id,
                     p_liquidacion,
                     'Errores Formato',
                     SUBSTR(l_response.arrayErroresFormato(l_index),1,1000),
                     p_user_id,
                     SYSDATE,
                     p_user_id,
                     SYSDATE,
                     1);
                EXCEPTION
                  WHEN others THEN
                    RAISE eInsertError;
                END;

              END LOOP;

            END IF;


            IF (l_response.arrayEventos IS NOT NULL AND l_response.arrayEventos.COUNT > 0) THEN

              FOR l_index IN 1 .. l_response.arrayEventos.COUNT LOOP

                BEGIN
                  INSERT INTO XX_TCG_RT_ERRORES_COE
                    (LIQUIDACION_ID,
                     TIPO_COE,
                     CODIGO,
                     DESCRIPCION,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE,
                     LAST_UPDATE_LOGIN)
                  VALUES
                    (p_liquidacion_id,
                     p_liquidacion,
                     'Eventos',
                     SUBSTR(l_response.arrayEventos(l_index),1,1000),
                     p_user_id,
                     SYSDATE,
                     p_user_id,
                     SYSDATE,
                     1);
                EXCEPTION
                  WHEN others THEN
                    RAISE eInsertEvent;
                END;

              END LOOP;

            END IF;


          END IF;

          COMMIT;

        END IF;

      END IF;



  EXCEPTION
    WHEN eCTGNextId THEN
      p_err_msg  := 'Error al intentar buscar el nuevo valor de CTG_ACCION_ID. '||SQLERRM;
      p_result   := FALSE;
      RETURN;

    WHEN eCPid THEN
      p_err_msg  := 'Error al intentar buscar el ID de Carta de Porte. '||SQLERRM;
      p_result   := FALSE;
      RETURN;

    WHEN eInsertCTG THEN
      p_err_msg  := 'Error al intentar insertar el registro en XX_TCG_CARTAS_PORTE_CTG para la CP: '
                    ||p_numero_cp||'. Detalle: '||SQLERRM;
      p_result   := FALSE;
      RETURN;

    WHEN eInsertError THEN
      p_err_msg  := 'Error al insertar en la tabla de errores de '||p_liquidacion||'. '||SQLERRM;
      p_result   := FALSE;
      RETURN;

    WHEN eInsertEvent THEN
      p_err_msg  := 'Error al insertar Eventos en la tabla de errores de '||p_liquidacion||'. '||SQLERRM;
      p_result   := FALSE;
      RETURN;

    WHEN others THEN
      p_err_msg  := 'Error en XX_TCG_WEBSERVICES_PKG.Buscar_Datos_CTG: '||SQLERRM;
      p_result   := FALSE;
      RETURN;

  END Buscar_Datos_CTG;





END XX_TCG_WEBSERVICES_PKG;
/

exit
