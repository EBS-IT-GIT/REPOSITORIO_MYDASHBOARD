WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

-- +=======================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                     |
-- |                   All rights reserved.                                |
-- +=======================================================================+
-- | FILENAME                                                              |
-- | XXSTN_GL_CAD_TAXA_DIA_N_UTIL.sql                                      |
-- |                                                                       |
-- | PURPOSE                                                               |
-- |                                                                       |
-- | DESCRIPTION                                                           |
-- |   Cadastro de taxa em dias em dias n�o util, utilizando-se do         |
-- |   calend�rio de dias uteis. Dia n�o util recebe taxa do dia util      |
-- |   anterior (Exemplo: sabado e domingo recebe a taxa da sexta-feira)   |
-- |                                                                       |
-- | CREATED BY   Rogerio Farto - Ninecon - 26/06/2020                     |
-- |              #SR-428258 - NSD-320694                                  |
-- |                                                                       |
-- | UPDATED BY                                                            |
-- |                                                                       |
-- +=======================================================================+
create or replace trigger XXSTN_GL_CAD_TAXA_DIA_N_UTIL
  after insert on xxstn.xxstn_gl_daily_rates_bacen
  for each row
declare
   pragma autonomous_transaction;
begin
  for r_cdu in (select trunc(to_date(fcd.calendar_date)) data
                  from apps.bom_calendar_dates fcd
                 where 1 = 1
                   and fcd.calendar_code = 'DLP_CALEND'
                   and trunc(to_date(fcd.prior_date)) = trunc(to_date(:new.data_cotacao))
                   and trunc(to_date(fcd.calendar_date)) <> trunc(to_date(:new.data_cotacao))
                 order 
                    by fcd.calendar_date) loop
    --
    begin
      insert into xxstn.xxstn_gl_daily_rates_bacen (moeda
                                                   ,data_cotacao
                                                   ,cotacao_compra
                                                   ,cotacao_venda
                                                   ,data_criacao
                                                   ,paridade_compra
                                                   ,paridade_venda
                                                   ,data_hora_cotacao
                                                   ,tipo_boletim
                                                   ,status)
                                            values (:new.moeda
                                                   ,r_cdu.data
                                                   ,:new.cotacao_compra
                                                   ,:new.cotacao_venda
                                                   ,:new.data_criacao
                                                   ,:new.paridade_compra
                                                   ,:new.paridade_venda
                                                   ,:new.data_hora_cotacao
                                                   ,:new.tipo_boletim
                                                   ,:new.status);
      commit;
    exception
      when others then
        null;
    end;
    --
  end loop;
exception
  when others then 
    null;
end;
/

EXIT;