UPDATE xla.xla_events
SET    event_status_code = 'U'
WHERE  event_id IN (78566012, 78448899, 78704603);
--3 Registros