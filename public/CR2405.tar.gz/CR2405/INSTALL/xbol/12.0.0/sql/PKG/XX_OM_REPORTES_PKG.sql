  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OM_REPORTES_PKG" AS

  PROCEDURE Customer_Service ( errbuf               IN OUT NOCOPY VARCHAR2
                             , retcode              IN OUT NOCOPY VARCHAR2
                             , p_operating_unit     NUMBER
                             , p_customer_id        NUMBER
                             , p_fecha_desde        VARCHAR2
                             , p_fecha_hasta        VARCHAR2
                             );

END XX_OM_REPORTES_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OM_REPORTES_PKG" AS

  g_xml_hdr     VARCHAR2(250) := '<?xml version="1.0" encoding="UTF-8"?>';
  g_data        VARCHAR2(32767);
  g_yes_no      VARCHAR2(20);
  g_param_desc  VARCHAR2(500);


  FUNCTION xml_escape_chars ( p_data VARCHAR2 ) RETURN VARCHAR IS
    l_data VARCHAR2(32767);
  BEGIN
    l_data := REPLACE(REPLACE(REPLACE(p_data, '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
    RETURN l_data;
  END xml_escape_chars;


  PROCEDURE Customer_Service ( errbuf               IN OUT NOCOPY VARCHAR2
                             , retcode              IN OUT NOCOPY VARCHAR2
                             , p_operating_unit     NUMBER
                             , p_customer_id        NUMBER
                             , p_fecha_desde        VARCHAR2
                             , p_fecha_hasta        VARCHAR2
                             ) IS

    CURSOR cMain IS

      SELECT oh.order_number        pedido_venta, oh.header_id, ol.line_id
           , ca.account_number      codigo_cuenta
           , ca.cust_account_id
           , hp.party_name          cliente
           , oh.ordered_date        fecha_solicitud
           , oh.creation_date       fecha_creacion
           , ol_dfv.xx_om_ship_date fecha_entrega_krikos
           , ol.schedule_ship_date  fecha_programada
           , ol_dfv.xx_om_due_date  fecha_vencimiento_krikos
           , ol.line_number||'.'||ol.shipment_number numero_linea
           , msi.segment1           articulo
           , msi.description        articulo_desc
           , lvs.meaning            estado
           , ol.order_quantity_uom  um
           , ot.name                tipo_pedido
           , REPLACE(ol.cust_po_number,'&',' ') orden_compra
           , (ol.ordered_quantity + ol.cancelled_quantity)    cantidad_original
           , dlt.shipped_quantity   cantidad_entregada
           --, ct.quantity_invoiced   cantidad_facturada
           , ol.cancelled_quantity  cantidad_cancelada
           , ret.ordered_quantity   cantidad_devuelta
           , lh.name                lista_precio
           , ol.unit_list_price     precio_lista
           , ol.unit_selling_price  precio_venta
           , ROUND((ol.ordered_quantity + ol.cancelled_quantity) * ol.unit_selling_price, 2) importe_linea
           , od.organization_code   almacen
           , ps.party_site_number   nro_sucursal
           , cas_dfv.xx_om_cm_cliente_planex    gln
           , hl.address1            direccion
           , (SELECT DISTINCT pr_dpto_nombre
              FROM xx_tcg_localidades2 lp
              WHERE 1=1
              AND lp.pais_codigo    = hl.country
              AND lp.pr_dpto_codigo = hl.province
             ) provincia
           , (SELECT DISTINCT pr_dpto_nombre
              FROM xx_tcg_localidades2 l
              WHERE 1=1
              AND l.pais_codigo    = hl.country
              AND l.pr_dpto_codigo = hl.province
              AND l.loc_codigo     = hl.county
             ) localidad
           , dlt.lot_number         lote
           , os.name                origen
           , XX_OM_HOLD_LINES_REP_PKG.get_hold_date(oh.header_id,'HOLD')       pl_hold_date
           , XX_OM_HOLD_LINES_REP_PKG.get_hold_release(oh.header_id,'HOLD')    pl_hold_release
           , XX_OM_HOLD_LINES_REP_PKG.get_hold_rel_user(oh.header_id,'HOLD')   pl_hold_user
           , XX_OM_HOLD_LINES_REP_PKG.get_hold_date(oh.header_id,'CREDIT')     cr_hold_date
           , XX_OM_HOLD_LINES_REP_PKG.get_hold_release(oh.header_id,'CREDIT')  cr_hold_release
           , XX_OM_HOLD_LINES_REP_PKG.get_hold_rel_user(oh.header_id,'CREDIT') cr_hold_user
           , dlt.delivery_name      numero_entrega
           , dlt.name               numero_viaje
           --, ct.trx_number          numero_factura
           , dlt.date_shipped       fecha_entrega
           --, ct.trx_date            fecha_factura
           , ret.return_reason      motivo_devolucion
           , canc.hist_creation_date fecha_cancela
           , canc.meaning           motivo_cancela
      FROM oe_order_headers_all       oh
         , hz_cust_accounts_all       ca
         , hz_parties                 hp
         , oe_transaction_types_tl    ot
         , qp_list_headers            lh
         , hz_cust_site_uses_all      csu
         , hz_cust_acct_sites_all     cas
         , hz_cust_acct_sites_all_dfv cas_dfv
         , hz_party_sites             ps
         , hz_locations               hl
         , oe_order_sources           os
         --
         , oe_order_lines_all         ol
         , oe_order_lines_all_dfv     ol_dfv
         , mtl_system_items           msi
         , fnd_lookup_values_vl       lvs
         , org_organization_definitions od
         , (SELECT dl.source_header_id, dl.source_line_id, dl.delivery_name, dl.date_shipped, dl.lot_number, wdt.name, SUM(dl.shipped_quantity) shipped_quantity
            FROM wsh_delivery_line_status_v dl
               , wsh_deliverables_v         wd
               , wsh_deliverable_trips_v    wdt
            WHERE 1=1
            AND wd.source_header_id(+) = dl.source_header_id
            AND wd.source_line_id(+)   = dl.source_line_id
            AND wd.lot_number(+)       = dl.lot_number
            AND wdt.delivery_detail_id(+) = wd.delivery_detail_id
            GROUP BY dl.source_header_id, dl.source_line_id, dl.delivery_name, dl.date_shipped, dl.lot_number, wdt.name
           )                          dlt
         /*, (SELECT rctl.interface_line_attribute1
                 , rctl.interface_line_attribute2
                 , rctl.interface_line_attribute6
                 , rct.customer_trx_id
                 , rct.trx_number
                 , rct.trx_date
                 , rctl.quantity_invoiced
            FROM ra_customer_trx_all       rct
               , ra_batch_sources_all      rbs
               , ra_customer_trx_lines_all rctl
            WHERE 1=1
            AND rbs.batch_source_id(+) = rct.batch_source_id
            AND rbs.org_id(+)          = rct.org_id
            AND rctl.customer_trx_id   = rct.customer_trx_id
            AND rctl.interface_line_context = 'ORDER ENTRY'
            AND rctl.line_type <> 'TAX'
           )                          ct*/
         , (SELECT  l.line_id
                  , l.header_id
                  , l.ordered_quantity
                  , al.meaning  return_reason
            FROM oe_order_lines_all l
               , ar_lookups         al
               , ra_customer_trx_lines_all rctl
               , ra_customer_trx_all rct
            WHERE 1=1
            AND rctl.customer_trx_line_id = l.credit_invoice_line_id
            AND rct.customer_trx_id = rctl.customer_trx_id
            AND al.lookup_code = l.return_reason_code
            AND al.lookup_type = 'CREDIT_MEMO_REASON'
           )                          ret
         , (SELECT lh.header_id, lh.line_id, lh.hist_creation_date, lv.meaning
            FROM oe_order_lines_history lh
               , fnd_lookup_values_vl   lv
            WHERE 1=1
            AND lh.hist_type_code = 'CANCELLATION'
            AND lv.lookup_code = lh.reason_code
            AND lv.lookup_type = 'CANCEL_CODE'
           )                          canc
      WHERE 1=1
      AND ca.cust_account_id    = oh.sold_to_org_id
      AND hp.party_id           = ca.party_id
      AND ot.transaction_type_id = oh.order_type_id
      AND ot.language           = 'ESA'
      AND lh.list_header_id     = oh.price_list_id
      AND csu.site_use_id       = oh.ship_to_org_id
      AND cas.cust_acct_site_id = csu.cust_acct_site_id
      AND ps.party_site_id      = cas.party_site_id
      AND hl.location_id        = ps.location_id
      AND cas_dfv.row_id        = cas.rowid
      AND os.order_source_id    = oh.order_source_id
      --
      AND ol.header_id          = oh.header_id
      AND ol_dfv.row_id(+)      = ol.rowid
      AND ol_dfv.context_value(+) = ol.context
      AND msi.organization_id   = ol.ship_from_org_id
      AND msi.inventory_item_id = ol.inventory_item_id
      AND lvs.lookup_code(+)    = ol.flow_status_code
      AND lvs.lookup_type(+)    = 'LINE_FLOW_STATUS'
      AND od.organization_id    = ol.ship_from_org_id
      AND dlt.source_header_id(+)= ol.header_id
      AND dlt.source_line_id(+)  = ol.line_id
      --AND ct.interface_line_attribute1(+) = oh.order_number
      --AND ct.interface_line_attribute2(+) = ot.name
      --AND ct.interface_line_attribute6(+) = ol.line_id
      AND ret.header_id(+)      = ol.header_id
      AND ret.line_id(+)        = ol.line_id
      AND canc.header_id(+)     = ol.header_id
      AND canc.line_id(+)       = ol.line_id
      --
      --AND oh.header_id    IN (8151613, 8288749, 8201643, 8201643, 8514612)
      --and ol.line_id = 8997460
      -- Parametros
      AND ( p_operating_unit IS NULL OR
            p_operating_unit = oh.org_id
          )
      AND ( p_customer_id IS NULL OR
            p_customer_id = ca.cust_account_id
          )
      AND TRUNC(oh.creation_date) BETWEEN FND_DATE.CANONICAL_TO_DATE(p_fecha_desde) AND FND_DATE.CANONICAL_TO_DATE(p_fecha_hasta)
      ORDER BY oh.header_id, ol.line_id
      ;

    CURSOR cTrx ( p_order_number VARCHAR2
                , p_order_type   VARCHAR2
                , p_line_id      VARCHAR2
                ) IS
      SELECT rctl.interface_line_attribute1
           , rctl.interface_line_attribute2
           , rctl.interface_line_attribute6
           , rct.customer_trx_id
           , rct.trx_number          numero_factura
           , rct.trx_date            fecha_factura
           , rctl.quantity_invoiced  cantidad_facturada
      FROM ra_customer_trx_all       rct
         , ra_batch_sources_all      rbs
         , ra_customer_trx_lines_all rctl
      WHERE 1=1
      AND rbs.batch_source_id(+) = rct.batch_source_id
      AND rbs.org_id(+)          = rct.org_id
      AND rctl.customer_trx_id   = rct.customer_trx_id
      AND rctl.interface_line_context = 'ORDER ENTRY'
      AND rctl.line_type <> 'TAX'
      AND rctl.interface_line_attribute1(+) = p_order_number
      AND rctl.interface_line_attribute2(+) = p_order_type
      AND rctl.interface_line_attribute6(+) = p_line_id
      ;

    rTrx                  cTrx%ROWTYPE;
    l_p_ou                VARCHAR2(250);
    l_p_customer          VARCHAR2(250);
  BEGIN
    FND_FILE.Put_Line(FND_FILE.LOG, '------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_operating_unit:  '||p_operating_unit);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_customer_id:     '||p_customer_id);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_fecha_desde:     '||p_fecha_desde);
    FND_FILE.Put_Line(FND_FILE.LOG, 'p_fecha_hasta:     '||p_fecha_hasta);
    FND_FILE.Put_Line(FND_FILE.LOG, '------------------------------------------');
    FND_FILE.Put_Line(FND_FILE.LOG, ' ');

    BEGIN
      SELECT name
      INTO l_p_ou
      FROM hr_operating_units
      WHERE 1=1
      AND organization_id = p_operating_unit;
    EXCEPTION
      WHEN OTHERS THEN
        l_p_ou := 'No Especificado';
    END;

    BEGIN
      SELECT hp.party_name
      INTO l_p_customer
      FROM hz_cust_accounts_all ca
         , hz_parties           hp
      WHERE 1=1
      AND hp.party_id = ca.party_id
      AND ca.cust_account_id = p_customer_id;
    EXCEPTION
      WHEN OTHERS THEN
        l_p_customer := 'No Especificado';
    END;

    FND_FILE.Put_Line(FND_FILE.Output,  g_xml_hdr);
    FND_FILE.Put_Line(FND_FILE.Output, '<XXOMREPCS>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <REPORT_NAME>XX OM Reporte Customer Service</REPORT_NAME>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <FECHA_EMISION>'||TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS')||'</FECHA_EMISION>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_OU>'||l_p_ou||'</P_OU>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_CLIENTE>'||l_p_customer||'</P_CLIENTE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FECHA_DESDE>'||TO_CHAR(FND_DATE.CANONICAL_TO_DATE(p_fecha_desde), 'DD/MM/YYYY')||'</P_FECHA_DESDE>');
    FND_FILE.Put_Line(FND_FILE.Output, '  <P_FEHCA_HASTA>'||TO_CHAR(FND_DATE.CANONICAL_TO_DATE(p_fecha_hasta), 'DD/MM/YYYY')||'</P_FEHCA_HASTA>');

    FOR r1 IN cMain LOOP
      FND_FILE.Put_Line(FND_FILE.Output, '  <G_DATA>');

      rTrx := NULL;
      OPEN cTrx (r1.PEDIDO_VENTA, r1.TIPO_PEDIDO, r1.LINE_ID);
      FETCH cTrx INTO rTrx;
      CLOSE cTrx;

      FND_FILE.Put_Line(FND_FILE.Output, '    <PEDIDO_VENTA>'||r1.PEDIDO_VENTA||'</PEDIDO_VENTA>');
      --FND_FILE.Put_Line(FND_FILE.Output, '    <HEADER_ID>'||r1.HEADER_ID||'<HEADER_ID>');
      --FND_FILE.Put_Line(FND_FILE.Output, '    <LINE_ID>'||r1.LINE_ID||'<LINE_ID>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CODIGO_CUENTA>'||r1.CODIGO_CUENTA||'</CODIGO_CUENTA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CUST_ACCOUNT_ID>'||r1.CUST_ACCOUNT_ID||'</CUST_ACCOUNT_ID>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CLIENTE>'||XX_UTIL_PK.xml_escape_chars(r1.CLIENTE)||'</CLIENTE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_SOLICITUD>'||TO_CHAR(r1.FECHA_SOLICITUD, 'DD/MM/YYYY')||'</FECHA_SOLICITUD>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_CREACION>'||TO_CHAR(r1.FECHA_CREACION, 'DD/MM/YYYY')||'</FECHA_CREACION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_ENTREGA_KRIKOS>'||TO_CHAR(r1.FECHA_ENTREGA_KRIKOS, 'DD/MM/YYYY')||'</FECHA_ENTREGA_KRIKOS>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_PROGRAMADA>'||TO_CHAR(r1.FECHA_PROGRAMADA, 'DD/MM/YYYY')||'</FECHA_PROGRAMADA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_VENCIMIENTO_KRIKOS>'||TO_CHAR(r1.FECHA_VENCIMIENTO_KRIKOS, 'DD/MM/YYYY')||'</FECHA_VENCIMIENTO_KRIKOS>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_LINEA>'||r1.NUMERO_LINEA||'</NUMERO_LINEA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ARTICULO>'||r1.ARTICULO||'</ARTICULO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ARTICULO_DESC>'||XX_UTIL_PK.xml_escape_chars(r1.ARTICULO_DESC)||'</ARTICULO_DESC>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ESTADO>'||r1.ESTADO||'</ESTADO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <UM>'||r1.UM||'</UM>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <TIPO_PEDIDO>'||r1.TIPO_PEDIDO||'</TIPO_PEDIDO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORDEN_COMPRA>'||r1.ORDEN_COMPRA||'</ORDEN_COMPRA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CANTIDAD_ORIGINAL>'||XX_UTIL_PK.xml_num_display(r1.CANTIDAD_ORIGINAL, NULL, 'N')||'</CANTIDAD_ORIGINAL>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CANTIDAD_ENTREGADA>'||XX_UTIL_PK.xml_num_display(r1.CANTIDAD_ENTREGADA, NULL, 'N')||'</CANTIDAD_ENTREGADA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CANTIDAD_FACTURADA>'||XX_UTIL_PK.xml_num_display(rTrx.CANTIDAD_FACTURADA, NULL, 'N')||'</CANTIDAD_FACTURADA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CANTIDAD_CANCELADA>'||XX_UTIL_PK.xml_num_display(r1.CANTIDAD_CANCELADA, NULL, 'N')||'</CANTIDAD_CANCELADA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CANTIDAD_DEVUELTA>'||XX_UTIL_PK.xml_num_display(r1.CANTIDAD_DEVUELTA, NULL, 'N')||'</CANTIDAD_DEVUELTA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LISTA_PRECIO>'||r1.LISTA_PRECIO||'</LISTA_PRECIO>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PRECIO_LISTA>'||XX_UTIL_PK.xml_num_display(r1.PRECIO_LISTA, NULL, 'N')||'</PRECIO_LISTA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PRECIO_VENTA>'||XX_UTIL_PK.xml_num_display(r1.PRECIO_VENTA, NULL, 'N')||'</PRECIO_VENTA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <IMPORTE_LINEA>'||XX_UTIL_PK.xml_num_display(r1.IMPORTE_LINEA, NULL, 'N')||'</IMPORTE_LINEA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ALMACEN>'||r1.ALMACEN||'</ALMACEN>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <NRO_SUCURSAL>'||r1.NRO_SUCURSAL||'</NRO_SUCURSAL>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <GLN>'||r1.GLN||'</GLN>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <DIRECCION>'||XX_UTIL_PK.xml_escape_chars(r1.DIRECCION)||'</DIRECCION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PROVINCIA>'||r1.PROVINCIA||'</PROVINCIA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LOCALIDAD>'||r1.LOCALIDAD||'</LOCALIDAD>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <LOTE>'||r1.LOTE||'</LOTE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <ORIGEN>'||r1.ORIGEN||'</ORIGEN>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PL_HOLD_DATE>'||r1.PL_HOLD_DATE||'</PL_HOLD_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PL_HOLD_RELEASE>'||r1.PL_HOLD_RELEASE||'</PL_HOLD_RELEASE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <PL_HOLD_USER>'||r1.PL_HOLD_USER||'</PL_HOLD_USER>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CR_HOLD_DATE>'||r1.CR_HOLD_DATE||'</CR_HOLD_DATE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CR_HOLD_RELEASE>'||r1.CR_HOLD_RELEASE||'</CR_HOLD_RELEASE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <CR_HOLD_USER>'||r1.CR_HOLD_USER||'</CR_HOLD_USER>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_ENTREGA>'||r1.NUMERO_ENTREGA||'</NUMERO_ENTREGA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_VIAJE>'||r1.NUMERO_VIAJE||'</NUMERO_VIAJE>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <NUMERO_FACTURA>'||rTrx.NUMERO_FACTURA||'</NUMERO_FACTURA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_ENTREGA>'||TO_CHAR(r1.FECHA_ENTREGA, 'DD/MM/YYYY')||'</FECHA_ENTREGA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_FACTURA>'||TO_CHAR(rTrx.FECHA_FACTURA, 'DD/MM/YYYY')||'</FECHA_FACTURA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <MOTIVO_DEVOLUCION>'||r1.MOTIVO_DEVOLUCION||'</MOTIVO_DEVOLUCION>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <FECHA_CANCELA>'||TO_CHAR(r1.FECHA_CANCELA, 'DD/MM/YYYY')||'</FECHA_CANCELA>');
      FND_FILE.Put_Line(FND_FILE.Output, '    <MOTIVO_CANCELA>'||r1.MOTIVO_CANCELA||'</MOTIVO_CANCELA>');


      FND_FILE.Put_Line(FND_FILE.Output, '  </G_DATA>');
    END LOOP;
    FND_FILE.Put_Line(FND_FILE.Output, '</XXOMREPCS>');

  EXCEPTION
    WHEN OTHERS THEN
      errbuf  := SQLERRM;
      retcode := 2;
  END Customer_Service;


END XX_OM_REPORTES_PKG;
/

exit
