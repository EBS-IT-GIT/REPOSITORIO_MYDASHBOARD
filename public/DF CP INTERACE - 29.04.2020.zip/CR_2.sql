UPDATE apps.XX_TCG_CARTAS_PORTE_ALL
   SET TRANSFERIDO_FLAG = 'N', LAST_UPDATE_DATE = SYSDATE
 WHERE CARTA_PORTE_ID IN
          (427522,
           427523,
           427529,
           427531,
           427645,
           427532,
           427534,
           427536,
           427538,
           427539,
           427542,
           427544,
           427939,
           427941,
           428999)
--15