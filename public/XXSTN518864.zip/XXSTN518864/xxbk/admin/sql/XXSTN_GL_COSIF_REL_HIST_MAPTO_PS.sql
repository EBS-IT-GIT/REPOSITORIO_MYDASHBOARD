WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE apps.XXSTN_GL_COSIF_REL_HIST_MAPTO IS
-- +==========================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                        |
-- |                   All rights reserved.                                   |
-- +==========================================================================+
-- | FILENAME                                                                 |
-- | XXSTN_GL_COSIF_REL_HIST_MAPTO_PS.sql                                     |
-- |                                                                          |
-- | PURPOSE                                                                  |
-- |                                                                          |
-- | DESCRIPTION                                                              |
-- |   Stone - Relat�rio de Hist�rico da Regra de Mapeamento Cont�bil - COSIF |
-- |                                                                          |
-- | CREATED BY   Rogerio Farto - Ninecon - 11/06/2020                        |
-- |              SR#518864 - NSD320703                                       |
-- |                                                                          |
-- | UPDATED BY                                                               |
-- |                                                                          |
-- +==========================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;

  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_mapeamento     IN NUMBER);

END XXSTN_GL_COSIF_REL_HIST_MAPTO;
/

EXIT; 