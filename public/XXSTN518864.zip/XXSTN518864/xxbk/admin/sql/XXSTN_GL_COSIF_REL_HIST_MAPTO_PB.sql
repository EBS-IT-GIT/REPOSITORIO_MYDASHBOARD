WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY apps.XXSTN_GL_COSIF_REL_HIST_MAPTO IS
-- +==========================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos                        |
-- |                   All rights reserved.                                   |
-- +==========================================================================+
-- | FILENAME                                                                 |
-- | XXSTN_GL_COSIF_REL_HIST_MAPTO_PB.sql                                     |
-- |                                                                          |
-- | PURPOSE                                                                  |
-- |                                                                          |
-- | DESCRIPTION                                                              |
-- |   Stone - Relat�rio de Hist�rico da Regra de Mapeamento Cont�bil - COSIF |
-- |                                                                          |
-- | CREATED BY   Rogerio Farto - Ninecon - 11/06/2020                        |
-- |              SR#518864 - NSD320703                                       |
-- |                                                                          |
-- | UPDATED BY                                                               |
-- |                                                                          |
-- +==========================================================================+
  -- Function and procedure implementations
  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_mapeamento     IN NUMBER) IS
  --
  CURSOR c_maptos IS
         select distinct 
                glfv.flex_value         cta_livro_prim
              , ffvebs.description      dsc_cta_livro_prim
              , gcsm.single_value       cta_cosif
              , ffvcos.description      dsc_cta_cosif
              , glfv.attribute1         cosif_realiz_em
              , ffvcos.attribute1       cosif_sinal
              , ffvcos.attribute2       dr_cr_cosif
              , gcsm.creation_date      dt_crt_mapto
              , fu_crt.user_name        usr_crt
              , gcsm.last_update_date   dt_lst_upd_mapto
              , fu_upd.user_name        usr_lst_upd
           from apps.fnd_flex_values          glfv
              , apps.gl_cons_flex_hierarchies cfh
              , apps.gl_cons_segment_map      gcsm
              , apps.gl_coa_mappings          gcm
              , apps.fnd_flex_values_vl       ffvebs
              , apps.fnd_flex_values_vl       ffvcos
              , apps.fnd_user                 fu_crt
              , apps.fnd_user                 fu_upd
          where 1 = 1
            and gcm.coa_mapping_id              = gcsm.coa_mapping_id 
            and gcsm.coa_mapping_id             = p_mapeamento
            and gcsm.to_application_column_name = 'SEGMENT2' 
            and gcsm.segment_map_id             = cfh.segment_map_id 
            and gcsm.single_value               = cfh.parent_flex_value 
            and gcsm.segment_map_type           = 'R' 
            and glfv.flex_value_set_id          = gcsm.from_value_set_id 
            and glfv.summary_flag               = 'N' 
            and glfv.flex_value           between cfh.child_flex_value_low 
                                              and Cfh.child_flex_value_high
            and glfv.flex_value                 = ffvebs.flex_value
            and glfv.flex_value_set_id          = ffvebs.flex_value_set_id
            and gcsm.single_value               = ffvcos.flex_value
            and gcsm.to_value_set_id            = ffvcos.flex_value_set_id
            and gcsm.created_by                 = fu_crt.user_id
            and gcsm.last_updated_by            = fu_upd.user_id
          union all
         select distinct 
                glfva.flex_value     cta_livro_prim
              , ffvebsa.description  dsc_cta_livro_prim
              , null                 cta_cosif
              , null                 dsc_cta_cosif
              , glfva.attribute1     cosif_realiz_em
              , null                 cosif_sinal
              , null                 dr_cr_cosif
              , null                 dt_crt_mapto
              , null                 usr_crt
              , null                 dt_lst_upd_mapto
              , null                 usr_lst_upd              
           from apps.fnd_flex_values          glfva
              , apps.fnd_flex_values_vl       ffvebsa
          where 1 = 1
            and glfva.flex_value        = ffvebsa.flex_value
            and glfva.flex_value_set_id = ffvebsa.flex_value_set_id
            and glfva.flex_value_set_id = 1017355
            and glfva.summary_flag      = 'N'
            and (glfva.end_date_active is null 
             or  glfva.end_date_active  > sysdate)
            and (glfva.flex_value  not in (select cfh.child_flex_value_low
                                             from apps.gl_cons_flex_hierarchies cfh
                                                , apps.gl_cons_segment_map      gcsm
                                            where 1 = 1
                                              and cfh.child_flex_value_low = glfva.flex_value
                                              and glfva.flex_value_set_id  = gcsm.from_value_set_id
                                              and gcsm.segment_map_id      = cfh.segment_map_id)
             or  glfva.flex_value  not in (select cfh.child_flex_value_high
                                             from apps.gl_cons_flex_hierarchies cfh
                                                , apps.gl_cons_segment_map      gcsm
                                            where 1 = 1
                                              and cfh.child_flex_value_high = glfva.flex_value
                                              and glfva.flex_value_set_id   = gcsm.from_value_set_id
                                              and gcsm.segment_map_id       = cfh.segment_map_id))
          order 
             by 1,3;
  --
  TYPE t_maptos IS TABLE OF c_maptos%ROWTYPE;
  r_maptos   t_maptos;
  --
  v_file_name   VARCHAR2(240);
  l_qtde        NUMBER;
  l_vlr         NUMBER;
  l_lin         NUMBER;
  l_count       NUMBER := 2;
  l_nRequest_Id NUMBER;
  l_ledger_name gl_ledgers.name%type;
  l_user        fnd_user.user_name%type;
  --
  BEGIN
     --busca usuario de execucao do relatorio
     BEGIN
      SELECT user_name
        into l_user
        FROM fnd_user
       WHERE user_id = FND_GLOBAL.USER_ID;
      EXCEPTION
       WHEN OTHERS THEN
        l_user := null;
     END;
     --------------------------------------------------------------------------
     --> Printing Parameters
     --------------------------------------------------------------------------
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'STONE PAGAMENTOS S/A               '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'             Stone - GL - Relat�rio Regras de Mapeamento de Plano de Contas  ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Paramters..:');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_mapeamento..........: '||p_mapeamento);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                             ');
     --
     dbms_output.put_line('Open mapeamentos '||v_file_name);
     OPEN c_maptos ;
     FETCH c_maptos BULK COLLECT INTO r_maptos;
     CLOSE c_maptos;
     --
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
     --
     as_xlsx.clear_workbook;
     --
     IF r_maptos.count > 0 THEN
       --
       as_xlsx.new_sheet('Mapeamentos');
       as_xlsx.set_row(   1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(  3,  1, 'Stone - GL - Relat�rio Regras de Mapeamento de Plano de Contas', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 14, p_bold =>true) );
       as_xlsx.cell(  1,  2, 'Cta Contabil Livro Primario', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  2,  2, 'Descricao Cta Livro Prim', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  3,  2, 'Cta COSIF', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  4,  2, 'Descricao Cta Cosif', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  5,  2, 'COSIF - Realizavel em', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  6,  2, 'Sinal Cosif', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  7,  2, 'DR CR Cosif', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  8,  2, 'Dt Criacao Mapto', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  9,  2, 'User Criacao Mapto', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 10,  2, 'Dt Ult. Atual. Mapto', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell( 11,  2, 'User Ult. Atual. Mapto', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       
       --
       FOR i IN r_maptos.first..r_maptos.last LOOP
         --
         dbms_output.put_line('Mapeamentos '||v_file_name);
         as_xlsx.cell(  1, l_count+1, nvl(r_maptos(i).cta_livro_prim,' '));
         as_xlsx.cell(  2, l_count+1, nvl(r_maptos(i).dsc_cta_livro_prim,' '));
         as_xlsx.cell(  3, l_count+1, nvl(r_maptos(i).cta_cosif,' '));
         as_xlsx.cell(  4, l_count+1, nvl(r_maptos(i).dsc_cta_cosif,' '));
         as_xlsx.cell(  5, l_count+1, nvl(r_maptos(i).cosif_realiz_em,' '));
         as_xlsx.cell(  6, l_count+1, nvl(r_maptos(i).cosif_sinal,' '));
         as_xlsx.cell(  7, l_count+1, nvl(r_maptos(i).dr_cr_cosif,' '));
         as_xlsx.cell(  8, l_count+1, r_maptos(i).dt_crt_mapto);
         as_xlsx.cell(  9, l_count+1, nvl(r_maptos(i).usr_crt,' '));
         as_xlsx.cell( 10, l_count+1, r_maptos(i).dt_lst_upd_mapto);
         as_xlsx.cell( 11, l_count+1, nvl(r_maptos(i).usr_lst_upd,' '));  
         --
         l_count := l_count + 1;
         --
       END LOOP;
       --
       as_xlsx.freeze_rows( 2 );
       --
     END IF;
     --
     dbms_output.put_line('Parameters '||v_file_name);
     as_xlsx.new_sheet('Parameters');
     as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ) ) ;
     as_xlsx.cell(1 , 1 ,'Parametros');
     as_xlsx.cell(1 , 2 ,'Mapeamento');
     --
     as_xlsx.cell(2 , 2 ,nvl(to_char(p_mapeamento),' '));

     as_xlsx.cell(5 , 7 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS') ||' por '||l_user
                         , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
     --
     v_file_name := 'HIST_COSIF_'||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS')||'.xlsx';
     dbms_output.put_line('Arquivo gerado '||v_file_name);
     as_xlsx.save( 'XXSTN_GL_OUT', v_file_name );
     --
     dbms_output.put_line('Arquivo gravado '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'       ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Arquivo Gerado.....: '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Registros Gerados..: '||to_char(l_count-3));
     --
     l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                , argument1   => v_file_name
                                                , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
  EXCEPTION
    --
    WHEN OTHERS THEN
      --------------------------------------------------------------------
      --> Set Errors variables
      --------------------------------------------------------------------
      p_errbuf  := SUBSTR(SQLERRM, 1, 500);
      p_retcode := 2;
      --------------------------------------------------------------------
      --> Print Error Messages
      --------------------------------------------------------------------
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** Unexpected error please contact your system administrator');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_errbuf =  ' || SUBSTR(SQLERRM, 1, 500));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_retcode =  '|| SQLCODE);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
      --
  END generate_report_p;
  --
END XXSTN_GL_COSIF_REL_HIST_MAPTO;
/

EXIT; 