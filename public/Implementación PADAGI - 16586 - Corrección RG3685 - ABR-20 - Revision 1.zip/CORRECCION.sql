UPDATE apps.ap_invoice_distributions_all aid
SET    attribute6 = decode(attribute4 , '0002-00025955', '2020/04/21 00:00:00' , '0051-00018935', '2019/05/03 00:00:00')
WHERE  (attribute4 = '0002-00025955'
        AND attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'JUAN JOSE WILLINER'))
     OR (attribute4 = '0051-00018935'
        AND attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'EXOLGAN S.A.'));
--8 Registros