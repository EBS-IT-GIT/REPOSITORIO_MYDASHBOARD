  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_INV_AGRONOMO_PKG" AS

  PROCEDURE Interfaz_Insumos ( errbuf           IN OUT VARCHAR2
                             , retcode          IN OUT VARCHAR2
                             , p_org_code       IN VARCHAR2
                             , p_fecha_desde    IN VARCHAR2
                             , p_fecha_hasta    IN VARCHAR2
                             , p_modo_ejecucion IN VARCHAR2
                             );


  PROCEDURE Interfaz_OC ( errbuf           IN OUT VARCHAR2
                        , retcode          IN OUT VARCHAR2
                        , p_org_code       IN VARCHAR2
                        , p_fecha_desde    IN VARCHAR2
                        , p_fecha_hasta    IN VARCHAR2
                        , p_modo_ejecucion IN VARCHAR2
                        );


END XX_INV_AGRONOMO_PKG
;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_INV_AGRONOMO_PKG" AS

  TYPE tTrxType IS RECORD
  ( transaction_source_type_id      NUMBER
  , transaction_source_type_name    VARCHAR2(250)
  , transaction_type_id             NUMBER
  , transaction_type_name           VARCHAR2(250)
  , transaction_action_id           NUMBER
  , transaction_action_name         VARCHAR2(250)
  );

  c_trx_type_cursor VARCHAR2(4000) :=
  'SELECT mst.transaction_source_type_id '||chr(10)
||'     , mst.transaction_source_type_name '||chr(10)
||'     , mtt.transaction_type_id '||chr(10)
||'     , mtt.transaction_type_name '||chr(10)
||'     , mtt.transaction_action_id '||chr(10)
||'     , lv.meaning  transaction_action_name '||chr(10)
||'FROM mtl_txn_source_types  mst '||chr(10)
||'   , mtl_transaction_types mtt '||chr(10)
||'   , fnd_lookup_values     lv '||chr(10)
||'WHERE 1=1 '||chr(10)
||'AND mtt.transaction_source_type_id = mst.transaction_source_type_id '||chr(10)
||'AND lv.lookup_code  = mtt.transaction_action_id '||chr(10)
||'AND lv.lookup_type  = ''MTL_TRANSACTION_ACTION'' '||chr(10)
||'AND mst.transaction_source_type_name = ''Inventory'' '||chr(10)
||'AND lv.language     = ''ESA'' '||chr(10)
||'AND TRUNC(NVL(mtt.disable_date, SYSDATE+1)) > TRUNC(SYSDATE) '||chr(10);


  l_main_cursor_stmt    VARCHAR2(4000);

  PROCEDURE Interfaz_Insumos ( errbuf           IN OUT VARCHAR2
                             , retcode          IN OUT VARCHAR2
                             , p_org_code       IN VARCHAR2
                             , p_fecha_desde    IN VARCHAR2
                             , p_fecha_hasta    IN VARCHAR2
                             , p_modo_ejecucion IN VARCHAR2
                             ) IS

    l_request_id          NUMBER := FND_GLOBAL.CONC_REQUEST_ID;

    CURSOR c1 IS

      SELECT *
      FROM XX_AGRONOMO_INTERFACE
      WHERE 1=1
      AND importado_flag IN ('N', 'P', 'R')
      AND request_id     = l_request_id
      ORDER BY orden_trabajo, mov_fecha, mov_id
      FOR UPDATE OF importado_flag, mensaje_error NOWAIT
      ;

    CURSOR c2 IS

      SELECT *
      FROM XX_AGRONOMO_INTERFACE
      WHERE 1=1
      AND importado_flag = 'E'
      AND request_id     = l_request_id
      ORDER BY orden_trabajo, mov_fecha, mov_id
      ;

    rMTI                  MTL_TRANSACTIONS_INTERFACE%ROWTYPE;
    rMTLI                 MTL_TRANSACTION_LOTS_INTERFACE%ROWTYPE;
    l_trx_int_id          NUMBER;

    TYPE mainCurTyp       IS REF CURSOR;
    l_main_cursor         mainCurTyp;
    rTrxType              tTrxType;

    l_fecha_desde         VARCHAR(20);
    l_fecha_hasta         VARCHAR(20);

    l_tt_name             VARCHAR2(50);
    l_trx_source_type_id  NUMBER;
    l_trx_type_id         NUMBER;
    l_trx_action_id       NUMBER;
    l_reason_id           NUMBER;

    l_item_id             NUMBER;
    l_lot_ctrl            NUMBER;
    l_uom                 VARCHAR2(10);
    l_org_id              NUMBER;
    l_locator_id          NUMBER;
    l_peso_neto           NUMBER;
    l_project_id          NUMBER;
    l_task_id             NUMBER;
    l_tipo_producto       VARCHAR2(150);
    l_ship_to_loc_id      NUMBER;

    l_dummy_chr           VARCHAR2(500);
    l_dummy_num           NUMBER;

    l_output              DBMSOUTPUT_LINESARRAY;
    l_linecount           NUMBER;
    l_rc                  NUMBER := 0;

    l_error_message       VARCHAR2(2000);
    eLineError            EXCEPTION;
  BEGIN

    l_fecha_desde := NVL(TO_CHAR(TO_DATE(p_fecha_desde,'RRRR-MM-DD HH24:MI:SS'),'RRRR-MM-DD'), TO_CHAR(SYSDATE-60, 'RRRR-MM-DD'));
    l_fecha_hasta := NVL(TO_CHAR(TO_DATE(p_fecha_hasta,'RRRR-MM-DD HH24:MI:SS'),'RRRR-MM-DD'), TO_CHAR(SYSDATE, 'RRRR-MM-DD'));

    FND_FILE.PUT_LINE(FND_FILE.LOG, 'XX Interfaz Agronomo');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Parámetros:');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_org_code    '||p_org_code);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_fecha_desde '||p_fecha_desde);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_fecha_hasta '||p_fecha_hasta);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_modo_ejecucion '||p_modo_ejecucion);
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');

    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'XX Interfaz Agronomo');
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Parámetros:');
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_org_code    '||p_org_code);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_fecha_desde '||p_fecha_desde);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_fecha_hasta '||p_fecha_hasta);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_modo_ejecucion '||p_modo_ejecucion);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, ' ');

    FND_FILE.PUT_LINE(FND_FILE.LOG, '+ Ejecutando Interfaz Java...');
    --FND_FILE.PUT_LINE(FND_FILE.LOG, 'cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||chr(10));
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface PROCESS_NEWS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion||chr(10));
    dbms_output.disable;
    dbms_output.enable;
    dbms_java.set_output(1023);
    --host_command ('cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta);
    host_command ('cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface PROCESS_NEWS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion);
    dbms_output.get_lines(l_output, l_linecount);
    IF l_output.COUNT > l_linecount THEN
      -- Remove the final empty line above l_linecount
      l_output.TRIM;

      FOR r1 IN (SELECT column_value FROM TABLE(l_output)) LOOP
        FND_FILE.PUT_LINE(FND_FILE.LOG, r1.column_value);
      END LOOP;
    END IF;
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '- Ejecutando Interfaz Java...');

    FND_FILE.PUT_LINE(FND_FILE.LOG, '+ Generando movimientos de INV');

    UPDATE XX_AGRONOMO_INTERFACE
    SET alquilado_direccion = REPLACE(alquilado_direccion, 'null', NULL)
      , producto_lote       = REPLACE(producto_lote, 'null', NULL)
    WHERE request_id = l_request_id;

    FOR r1 IN c1 LOOP
      l_error_message  := NULL;
      l_ship_to_loc_id := NULL;
      rTrxType := NULL;
      rMTI     := NULL;
      rMTLI    := NULL;
      BEGIN
        BEGIN
          SELECT organization_id
          INTO l_org_id
          FROM org_organization_definitions
          WHERE organization_code = r1.organizacion_codigo
          ;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar organization_id ('||r1.organizacion_codigo||').';
            RAISE eLineError;
        END;

        BEGIN
          SELECT inventory_item_id, primary_uom_code, lot_control_code
          INTO l_item_id, l_uom, l_lot_ctrl
          FROM mtl_system_items
          WHERE 1=1
          AND organization_id = l_org_id
          AND segment1        = r1.producto_numero
          ;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar el producto ('||r1.producto_numero||') en la organización ('||l_org_id||').';
            RAISE eLineError;
        END;

        IF l_lot_ctrl = 2 AND
           r1.producto_lote IS NULL THEN
          l_error_message := 'El producto ('||r1.producto_numero||') controla lote y el mismo no fue informado.';
          RAISE eLineError;
        END IF;

        BEGIN
          SELECT inventory_location_id
          INTO l_locator_id
          FROM mtl_item_locations
          WHERE segment1      = r1.localizador
          AND organization_id = l_org_id;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar localizador ('||r1.localizador||').';
            RAISE eLineError;
        END;

        BEGIN
          SELECT project_id
          INTO l_project_id
          FROM pa_projects_all
          WHERE 1=1
          AND project_status_code NOT IN ('CLOSED', 'REJECTED')
          AND TRUNC(NVL(completion_date, SYSDATE+1)) > TRUNC(SYSDATE)
          AND segment1 = r1.proyecto;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar proyecto ('||r1.proyecto||').';
            RAISE eLineError;
        END;

        BEGIN
          SELECT t.task_id, UPPER(vsv.description) tipo_producto
          INTO l_task_id, l_tipo_producto
          FROM pa_tasks            t
             , pa_tasks            tt
             , pa_tasks_dfv        tt_dfv
             , fnd_flex_value_sets vs
             , fnd_flex_values_vl  vsv
          WHERE 1=1
          AND tt.task_id             = t.top_task_id
          AND tt_dfv.row_id(+)       = tt.rowid
          AND vsv.flex_value_set_id(+)  = vs.flex_value_set_id
          AND vs.flex_value_set_name = 'XX_GL_PRODUCTO'
          AND vsv.flex_value(+)      = tt_dfv.xx_pa_product
          AND TRUNC(NVL(t.completion_date, SYSDATE+1)) > TRUNC(SYSDATE)
          AND t.project_id           = l_project_id
          AND t.task_number          = r1.tarea
          ;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar tarea ('||r1.proyecto||' || '||r1.tarea||').';
            RAISE eLineError;
        END;

        BEGIN
          SELECT pet.expenditure_type
          INTO l_dummy_chr
          FROM pa_transaction_controls  ptc
             , pa_expenditure_types     pet
          WHERE 1=1
          AND pet.expenditure_category = ptc.expenditure_category
          AND TRUNC(NVL(pet.end_date_active, SYSDATE+1)) > TRUNC(SYSDATE)
          AND ptc.project_id = l_project_id
          AND ptc.task_id    = l_task_id
          AND pet.expenditure_type = r1.tipo_erogacion
          ;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar tipo erogacion ('||r1.proyecto||' || '||r1.tarea||' || '||r1.tipo_erogacion||').';
            RAISE eLineError;
        END;
       --entregas
       --'Baja Rice (PA)'
       -- devoluciones
       --'Alta Rice (PA)'

        IF r1.mov_tipo = 'ENTREGAS' THEN
          IF l_tipo_producto = 'ARROZ' THEN
            l_tt_name  := 'Baja Rice (PA)';
          ELSE
            l_tt_name  := 'Baja Crops (PA)';
          END IF;
          l_peso_neto := ABS(r1.mov_cantidad) * -1;
        ELSE
          IF l_tipo_producto = 'ARROZ' THEN
            l_tt_name  := 'Alta Rice (PA)';
          ELSE
            l_tt_name  := 'Alta Crops (PA)';
          END IF;
          l_peso_neto := ABS(r1.mov_cantidad);
        END IF;

        l_main_cursor_stmt := c_trx_type_cursor
        ||'AND mtt.transaction_type_name = '''||l_tt_name||''' ';

        OPEN l_main_cursor FOR l_main_cursor_stmt;
        FETCH l_main_cursor INTO rTrxType;
        l_trx_source_type_id := rTrxType.transaction_source_type_id;
        l_trx_type_id   := rTrxType.transaction_type_id;
        l_trx_action_id := rTrxType.transaction_action_id;
        CLOSE l_main_cursor;

        BEGIN
          SELECT reason_id
          INTO l_reason_id
          FROM mtl_transaction_reasons
          WHERE reason_name = 'CPRO';
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar motivo CPRO.';
            RAISE eLineError;
        END;

        IF l_trx_type_id IS NULL THEN
          l_error_message := 'No fue posible encontrar tipo de transaccion ('||l_tt_name||').';
          RAISE eLineError;
        END IF;

        IF p_modo_ejecucion = 'F' THEN
          SELECT mtl_material_transactions_s.NEXTVAL
          INTO l_trx_int_id
          FROM DUAL;

          --MTL_TRANSACTIONS_INTERFACE
          rMTI.transaction_interface_id := l_trx_int_id;
          rMTI.source_line_id           := -1;
          rMTI.source_header_id         := -1;
          --
          rMTI.source_code              := 'Inventory';
          rMTI.transaction_source_type_id := l_trx_source_type_id;
          rMTI.transaction_type_id      := l_trx_type_id;
          rMTI.transaction_action_id    := l_trx_action_id;
          rMTI.reason_id                := l_reason_id;
          rMTI.attribute_category       := l_reason_id;
          rMTI.attribute3               := r1.orden_trabajo;   --OT
          --rMTI.attribute4               := r1.superficie;    --Superficie Aplicada
          rMTI.attribute5               := TO_CHAR(r1.mov_fecha, 'YYYY-MM-DD');       --Fecha de Aplicacion
          --rMTI.attribute7               := r1.orden_trabajo; --Vale de Consumo
          rMTI.attribute8               := r1.lote;            --Lote
          rMTI.attribute11              := r1.mov_tipo||'_'||r1.mov_id;       --Origen Movimiento
          --
          rMTI.transaction_mode         := 3; --Background
          rMTI.lock_flag                := 2; --NO
          rMTI.process_flag             := 1; --YES
          --
          rMTI.transaction_uom          := l_uom;
          rMTI.transaction_date         := r1.fecha_certifica;
          rMTI.inventory_item_id        := l_item_id;
          rMTI.transaction_quantity     := l_peso_neto;
          --Desde
          rMTI.organization_id          := l_org_id;
          rMTI.subinventory_code        := r1.sub_inventario_codigo;
          rMTI.locator_id               := l_locator_id;
          rMTI.transaction_reference    := r1.mov_referencia;

          IF NVL(r1.alquilado_direccion, '<<NULL>>') != '<<NULL>>' THEN
            BEGIN
              SELECT location_id
              INTO l_ship_to_loc_id
              FROM hr_locations
              WHERE location_code = r1.alquilado_direccion;

              rMTI.ship_to_location_id := l_ship_to_loc_id;
            EXCEPTION
              WHEN OTHERS THEN
                l_error_message := 'No fue posible encontrar direccion para el alquilado ('||r1.alquilado_direccion||').';
                RAISE eLineError;
            END;
          END IF;

          --Proyecto
          rMTI.source_project_id        := l_project_id;
          rMTI.source_task_id           := l_task_id;
          rMTI.expenditure_type         := r1.tipo_erogacion;
          rMTI.pa_expenditure_org_id    := l_org_id;

          SELECT cc.chart_of_accounts_id
          INTO l_dummy_num
          FROM mtl_parameters mp, gl_code_combinations cc
          WHERE cc.code_combination_id = mp.material_account
          AND mp.organization_id = rMTI.pa_expenditure_org_id;

          rMTI.distribution_account_id :=
          FND_FLEX_EXT.get_ccid( application_short_name  => 'SQLGL'
                               , key_flex_code           => 'GL#'
                               , structure_number        => l_dummy_num
                               , validation_date         => TO_CHAR(r1.mov_fecha, 'DD-MON-YYYY')
                               , concatenated_segments   => XX_PROJECT_PKG.Get_Account
                                                            ( p_project_id         => l_project_id
                                                            , p_task_id            => l_task_id
                                                            , p_expenditure_type   => r1.tipo_erogacion
                                                            , p_expenditure_org_id => l_org_id
                                                            )
                               );

          rMTI.created_by       := FND_GLOBAL.User_ID;
          rMTI.creation_date    := SYSDATE;
          rMTI.last_updated_by  := FND_GLOBAL.User_ID;
          rMTI.last_update_date := SYSDATE;

          INSERT INTO MTL_TRANSACTIONS_INTERFACE VALUES rMTI;

          --MTL_TRANSACTION_LOTS_INTERFACE
          IF NVL(r1.producto_lote, '<<NULL>>') != '<<NULL>>' THEN
            rMTLI.transaction_interface_id := l_trx_int_id;
            rMTLI.source_line_id           := -1;
            rMTLI.lot_number               := r1.producto_lote;
            rMTLI.transaction_quantity     := l_peso_neto;
            --
            rMTLI.created_by       := FND_GLOBAL.User_ID;
            rMTLI.creation_date    := SYSDATE;
            rMTLI.last_updated_by  := FND_GLOBAL.User_ID;
            rMTLI.last_update_date := SYSDATE;

            INSERT INTO MTL_TRANSACTION_LOTS_INTERFACE VALUES rMTLI;
          END IF;

        END IF;

        UPDATE XX_AGRONOMO_INTERFACE
        SET importado_flag = DECODE(p_modo_ejecucion, 'F', 'Y', p_modo_ejecucion)
          , mensaje_error  = NULL
        WHERE CURRENT OF c1;

        l_rc := c1%ROWCOUNT;
      --
      EXCEPTION
        WHEN eLineError THEN
          UPDATE XX_AGRONOMO_INTERFACE
          SET importado_flag  = 'E'
            , mensaje_error = l_error_message
          WHERE CURRENT OF c1;
      END;

    END LOOP;

    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Se insertaron '||l_rc||' registros.');
    COMMIT;

    FND_FILE.PUT_LINE(FND_FILE.LOG, '- Generando movimientos de INV');
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '+ Ejecutando Interfaz Java para actualizar errores en Argonomo...');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface PROCESS_ERRORS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion||chr(10));
    l_output := NULL;
    l_linecount := NULL;
    dbms_output.disable;
    dbms_output.enable;
    dbms_java.set_output(1023);
    host_command ('cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface PROCESS_ERRORS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion);
    dbms_output.get_lines(l_output, l_linecount);
    IF l_output.COUNT > l_linecount THEN
      -- Remove the final empty line above l_linecount
      l_output.TRIM;

      FOR r1 IN (SELECT column_value FROM TABLE(l_output)) LOOP
        FND_FILE.PUT_LINE(FND_FILE.LOG, r1.column_value);
      END LOOP;
    END IF;
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '- Ejecutando Interfaz Java para actualizar errores en Argonomo...');

    l_rc := 0;
    FOR r2 IN c2 LOOP
      l_rc := c2%ROWCOUNT;
    END LOOP;
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Se encontraron '||l_rc||' registros con error.');

    FOR r2 IN c2 LOOP
      IF c2%ROWCOUNT = 1 THEN
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT, ' ');
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'A continuación se detallan los registros con error:');
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Orden Trabajo | Tipo Mov     | ID Mov     | Error');
      END IF;

      FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(r2.orden_trabajo, 13, ' ')||' - '||RPAD(r2.mov_tipo,12,' ')||' - '||RPAD(r2.mov_id,10,' ')||' - '||r2.mensaje_error);
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,  SQLERRM);
      ROLLBACK;
  END Interfaz_Insumos;



  FUNCTION Run_API ( p_int_header_id            NUMBER
                   , p_operating_unit           NUMBER
                   , p_commit                   VARCHAR2
                   , x_po_header_id      IN OUT NUMBER
                   , x_po_header_number  IN OUT VARCHAR2
                   , x_error_msg         IN OUT VARCHAR2
                   ) RETURN BOOLEAN IS

    CURSOR cIError IS
      SELECT error_message
      FROM po_interface_errors
      WHERE interface_header_id = p_int_header_id;

    d_pkg_name CONSTANT VARCHAR2(255) := 'po.plsql.PO_PDOI_Concurrent.';
    d_api_name CONSTANT VARCHAR2(255) :=  'POXPDOI';
    d_position                  NUMBER;

    l_selected_batch_id         NUMBER;
    l_buyer_id                  NUMBER;
    l_document_type             VARCHAR2(25);
    l_document_subtype          VARCHAR2(25);
    l_create_items              VARCHAR2(1);
    l_create_source_rules_flag  VARCHAR2(1);
    l_approval_status           VARCHAR2(25);
    l_rel_gen_method            VARCHAR2(25);
    l_org_id                    NUMBER := NULL;
    l_ga_flag                   VARCHAR2(1) := NULL;

    --<LOCAL SR/ASL PROJECT START>
    l_sourcing_level            VARCHAR2(50) := NULL;
    l_sourcing_inv_org_id       HR_ALL_ORGANIZATION_UNITS.organization_id%type;
    --<LOCAL SR/ASL PROJECT END>

    --Bug 13343886
    l_batch_size                NUMBER;
    l_gather_stats              VARCHAR2(1);
    --Bug 13343886

    l_return_status             VARCHAR2(1);
    l_msg                       VARCHAR2(2000);
    --CLM PDOI Integration
    l_clm_flag                  VARCHAR2(1) := 'N';
    eError                      EXCEPTION;
  BEGIN
    --FND_GLOBAL.apps_initialize(FND_GLOBAL.User_ID, FND_GLOBAL.Resp_ID, FND_GLOBAL.Resp_appl_ID);
    --FND_GLOBAL.apps_initialize(25677, 50267, 201);

    --FND_CLIENT_INFO.set_org_context(p_operating_unit);

    d_position := 0;

    l_buyer_id           := NULL;
    l_document_type      := 'STANDARD';
    l_document_subtype   := NULL;
    l_create_items       := 'N';
    l_create_source_rules_flag := 'N';

    d_position := 20;

    l_approval_status    := 'INITIATE APPROVAL';
    l_rel_gen_method     := NULL;
    l_selected_batch_id  := NULL;
    l_org_id             := p_operating_unit;
    l_ga_flag            := NULL; --'10';  -- FPI GA

    --<LOCAL SR/ASL PROJECT  START>
    l_sourcing_level      := NULL; --'12';
    l_sourcing_inv_org_id := NULL; --XX_TCG_FUNCTIONS_PKG.getMasterOrg;--'ITEM-ORGANIZATION'; --'14';
    --<LOCAL SR/ASL PROJECT  END>

    --Bug 13343886
    PO_PDOI_CONSTANTS.g_DEF_BATCH_SIZE := 5000;
    PO_PDOI_CONSTANTS.g_GATHER_STATS   := 'N';
    --Bug 13343886

    --CLM PDOI Integration
    --For CLM requests CLM Flag(15) is always going to be 'Y'
    --For Commercial requests (15) is going to fetch some random value
    l_clm_flag := 'N';

    d_position := 30;

    PO_PDOI_GRP.start_process
               ( p_api_version          => 1.0
               , p_init_msg_list        => FND_API.G_TRUE
               , p_validation_level     => FND_API.G_VALID_LEVEL_FULL
               , p_commit               => FND_API.G_FALSE
               , x_return_status        => l_return_status
               , p_gather_intf_tbl_stat => FND_API.G_FALSE
               , p_calling_module       => PO_PDOI_CONSTANTS.g_CALL_MOD_CONCURRENT_PRGM
               , p_selected_batch_id    => l_selected_batch_id
               , p_batch_size           => PO_PDOI_CONSTANTS.g_DEF_BATCH_SIZE
               , p_buyer_id             => l_buyer_id
               , p_document_type        => l_document_type
               , p_document_subtype     => l_document_subtype
               , p_create_items         => l_create_items
               , p_create_sourcing_rules_flag => l_create_source_rules_flag
               , p_rel_gen_method       => l_rel_gen_method
               , p_sourcing_level       => l_sourcing_level
               , p_sourcing_inv_org_id  => l_sourcing_inv_org_id
               , p_approved_status      => l_approval_status
               , p_process_code         => PO_PDOI_CONSTANTS.g_process_code_PENDING
               , p_interface_header_id  => p_int_header_id -- Interface Header ID generado previamente
               , p_org_id               => p_operating_unit
               , p_ga_flag              => l_ga_flag
               , p_clm_flag             => l_clm_flag
               );

    IF l_return_status != FND_API.G_RET_STS_SUCCESS THEN
      RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
    END IF;


    BEGIN
      SELECT ph.po_header_id, ph.segment1
      INTO x_po_header_id, x_po_header_number
      FROM po_headers_interface hi
         , po_headers_all       ph
      WHERE 1=1
      AND ph.po_header_id = hi.po_header_id
      AND hi.interface_header_id = p_int_header_id
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        FOR r IN cIError LOOP
          x_error_msg := x_error_msg||' '||r.error_message;
        END LOOP;

        RETURN FALSE;
    END;

    RETURN TRUE;
    DBMS_OUTPUT.PUT_LINE('Proceso finalizado OK. hdr_id:'||x_po_header_id||' OC Number: '||x_po_header_number);

  EXCEPTION
    WHEN OTHERS THEN
      PO_MESSAGE_S.add_exc_msg
      ( p_pkg_name => d_pkg_name,
        p_procedure_name => d_api_name || '.' || d_position
      );

      FOR i IN 1..FND_MSG_PUB.COUNT_MSG LOOP
        l_msg := FND_MSG_PUB.get
                 ( p_msg_index => i,
                   p_encoded => FND_API.G_FALSE
                 );

        DBMS_OUTPUT.PUT_LINE('Error: '||l_msg);
        x_error_msg := x_error_msg || l_msg ||' ';
      END LOOP;
      RETURN FALSE;
  END;



  PROCEDURE Interfaz_OC ( errbuf            IN OUT VARCHAR2
                        , retcode           IN OUT VARCHAR2
                        , p_org_code        IN VARCHAR2
                        , p_fecha_desde     IN VARCHAR2
                        , p_fecha_hasta     IN VARCHAR2
                        , p_modo_ejecucion  IN VARCHAR2
                        ) IS

    l_request_id          NUMBER := FND_GLOBAL.CONC_REQUEST_ID;

    CURSOR cOCh IS

      SELECT ih.*
           , (SELECT DISTINCT il.po_header_id
              FROM xx_agronomo_interface_oc_linea il
              WHERE il.orden_trabajo = ih.orden_trabajo
             ) po_header_id
           , sob.currency_code moneda_func
      FROM xx_agronomo_interface_oc     ih
         , org_organization_definitions od
         , gl_sets_of_books             sob
      WHERE 1=1
      AND od.organization_id(+)  = ih.organizacion_id
      AND sob.set_of_books_id = od.set_of_books_id  
      AND ih.importado_flag   IN ('N', 'P', 'R')
      AND ih.request_id       = l_request_id
      ORDER BY ih.unidad_operativa, ih.orden_trabajo
      --FOR UPDATE OF importado_flag, mensaje_error NOWAIT
      ;

    CURSOR cOCl ( p_orden_trabajo NUMBER ) IS
      SELECT *
      FROM xx_agronomo_interface_oc_linea
      WHERE 1=1
      AND importado_flag IN ('N', 'P', 'R')
      AND orden_trabajo  = p_orden_trabajo
      AND request_id     = l_request_id
      ORDER BY certificado_id
      --FOR UPDATE OF po_header_id, importado_flag, mensaje_error NOWAIT
      ;

    CURSOR cVS ( p_operating_unit  NUMBER
               , p_productor_id    NUMBER
               ) IS

      SELECT vs.vendor_site_id, vs.terms_id
      FROM ap_suppliers        s
         , po_vendor_sites_all vs
         , hz_party_site_uses hpsu
      WHERE 1=1
      AND vs.vendor_id = s.vendor_id
      AND NVL(vs.inactive_date, SYSDATE+1) > TRUNC(SYSDATE)
      AND vs.org_id    = p_operating_unit
      AND s.vendor_id  = p_productor_id
      AND hpsu.site_use_type = 'PURCHASING'
      AND hpsu.status = 'A'
      AND nvl(vs.purchasing_site_flag,'X') = 'Y'
      AND vs.party_site_id = hpsu.party_site_id
      ORDER BY vs.terms_id
      ;

    CURSOR c2 IS
      SELECT orden_trabajo, NULL certificado, mensaje_error
      FROM xx_agronomo_interface_oc
      WHERE 1=1
      AND importado_flag = 'E'
      AND request_id     = l_request_id
      UNION
      SELECT orden_trabajo, certificado_id certificado, mensaje_error
      FROM xx_agronomo_interface_oc_linea
      WHERE 1=1
      AND importado_flag = 'E'
      AND request_id     = l_request_id
      ;


    l_fecha_desde         VARCHAR(20);
    l_fecha_hasta         VARCHAR(20);

    l_dummy_chr           VARCHAR2(500);
    l_dummy_num           NUMBER;

    l_progress           VARCHAR2(10);
    l_int_header_id      NUMBER;
    l_int_line_id        NUMBER;
    l_batch_id           NUMBER;

    --Campos comunes
    l_attribute_category  VARCHAR2(5) := 'AR';

    --Campos para la cabecera
    l_organization_id     NUMBER;
    l_agent_id            NUMBER;
    l_doc_type            VARCHAR2(10)  := 'STANDARD';
    l_comments            VARCHAR2(150) := 'PRUEBA OC AGRONOMO';
    -- Proveedor
    l_vendor_id           NUMBER;
    l_vendor_site_id      NUMBER;
    l_terms_id            NUMBER;
    l_ship_to_location_id NUMBER;
    l_bill_to_location_id NUMBER;
    -- Moneda
    l_rate_type           VARCHAR2(20);
    l_exchange_date       DATE;
    l_exchange_rate       NUMBER;

    --Campos para las lineas
    l_line_type_id        NUMBER := 1020; --Servicios GOODS QUANTITY
    l_category_id         NUMBER;
    l_uom_code            VARCHAR2(10);

    --Campos para las distribuciones
    l_project_id          NUMBER;
    l_project_start_date  DATE;
    l_task_id             NUMBER;
    l_expenditure_type    VARCHAR2(200);
    l_cc_id               NUMBER;
    l_segment_un          VARCHAR2(50);

    l_po_header_id        NUMBER;
    l_po_header_number    VARCHAR2(50);

    l_output              DBMSOUTPUT_LINESARRAY;
    l_linecount           NUMBER;
    l_rc                  NUMBER := 0;
    l_ou                  NUMBER;
    l_resp_id             NUMBER;
    l_resp_appl_id        NUMBER;

    l_error_message       VARCHAR2(2000);
    eHeaderError          EXCEPTION;
    eLineError            EXCEPTION;
  BEGIN
    l_fecha_desde := NVL(TO_CHAR(TO_DATE(p_fecha_desde,'RRRR-MM-DD HH24:MI:SS'),'RRRR-MM-DD'), TO_CHAR(SYSDATE, 'RRRR-MM-DD'));
    l_fecha_hasta := NVL(TO_CHAR(TO_DATE(p_fecha_hasta,'RRRR-MM-DD HH24:MI:SS'),'RRRR-MM-DD'), TO_CHAR(SYSDATE, 'RRRR-MM-DD'));

    FND_FILE.PUT_LINE(FND_FILE.LOG, 'XX Interfaz Agronomo OC');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Parámetros:');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_org_code    '||p_org_code);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_fecha_desde '||p_fecha_desde);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_fecha_hasta '||p_fecha_hasta);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'p_modo_ejecucion '||p_modo_ejecucion);
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');

    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'XX Interfaz Agronomo OC');
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Parámetros:');
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_org_code    '||p_org_code);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_fecha_desde '||p_fecha_desde);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_fecha_hasta '||p_fecha_hasta);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'p_modo_ejecucion '||p_modo_ejecucion);
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, ' ');

    FND_FILE.PUT_LINE(FND_FILE.LOG, '+ Ejecutando Interfaz Java...');
    --FND_FILE.PUT_LINE(FND_FILE.LOG, 'cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||chr(10));
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterfaceOC PROCESS_NEWS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion||chr(10));
    dbms_output.disable;
    dbms_output.enable;
    dbms_java.set_output(1023);
    --host_command ('cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterface '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta);
    host_command ('cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterfaceOC PROCESS_NEWS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion);
    dbms_output.get_lines(l_output, l_linecount);
    IF l_output.COUNT > l_linecount THEN
      -- Remove the final empty line above l_linecount
      l_output.TRIM;

      FOR r1 IN (SELECT column_value FROM TABLE(l_output)) LOOP
        FND_FILE.PUT_LINE(FND_FILE.LOG, r1.column_value);
      END LOOP;
    END IF;
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '- Ejecutando Interfaz Java...');

    FND_FILE.PUT_LINE(FND_FILE.LOG, '+ Generando OCs');

    FOR rOCh IN cOCh LOOP
      l_error_message  := NULL;
      l_terms_id := NULL;

      BEGIN
        BEGIN
          /*IF cOCh%ROWCOUNT = 1 THEN
            l_ou := rOCh.unidad_operativa;

            SELECT r.responsibility_id, r.application_id
            INTO l_resp_id, l_resp_appl_id
            FROM fnd_profile_option_values pov
               , fnd_profile_options_vl    po
               , fnd_responsibility_vl     r
            WHERE 1=1
            AND po.profile_option_id = pov.profile_option_id
            AND po.application_id    = pov.application_id
            AND po.profile_option_name = 'ORG_ID'
            AND pov.level_value      = r.responsibility_id
            AND UPPER(r.responsibility_name) like UPPER('% PO Super User %')
            AND TO_NUMBER(pov.profile_option_value) = l_ou;

            FND_GLOBAL.apps_initialize(FND_GLOBAL.User_ID, l_resp_id, l_resp_appl_id);

            FND_CLIENT_INFO.set_org_context(l_ou);
          ELSIF l_ou != rOCh.unidad_operativa THEN*/
          IF NVL(l_ou, -99) != rOCh.unidad_operativa THEN
            l_ou := rOCh.unidad_operativa;

            SELECT r.responsibility_id, r.application_id
            INTO l_resp_id, l_resp_appl_id
            FROM fnd_profile_option_values pov
               , fnd_profile_options_vl    po
               , fnd_responsibility_vl     r
            WHERE 1=1
            AND po.profile_option_id = pov.profile_option_id
            AND po.application_id    = pov.application_id
            AND po.profile_option_name = 'ORG_ID'
            AND pov.level_value      = r.responsibility_id
            AND UPPER(r.responsibility_name) like UPPER('% PO Super User %')
            AND TO_NUMBER(pov.profile_option_value) = l_ou;

            FND_GLOBAL.apps_initialize(FND_GLOBAL.User_ID, l_resp_id, l_resp_appl_id);

            FND_CLIENT_INFO.set_org_context(l_ou);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'El usuario no cuenta con la responsabilidad asociada para la unidad operativa ('||l_ou||').';
            RAISE eHeaderError;
        END;

        BEGIN
          SELECT cancel_flag
          INTO l_dummy_chr 
          FROM po_headers_all ph 
          WHERE ph.po_header_id = rOCh.po_header_id
          ;

          IF l_dummy_chr != 'Y' THEN
            l_error_message := 'Existe una OC generada para la OT ('||rOCh.orden_trabajo||') y la misma no ha sido cancelada.';
            RAISE eHeaderError;          
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
          WHEN OTHERS THEN
            l_error_message := 'No fue posible validar estado de la OT ('||rOCh.orden_trabajo||').';
            RAISE eHeaderError;
        END;

        BEGIN
          SELECT organization_id
          INTO l_organization_id
          FROM org_organization_definitions
          WHERE organization_code = rOCh.organizacion_codigo
          ;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar organization_id ('||rOCh.organizacion_codigo||').';
            RAISE eHeaderError;
        END;

        BEGIN
          SELECT secondary_inventory_name
          INTO l_dummy_chr
          FROM mtl_secondary_inventories
          WHERE 1=1
          AND secondary_inventory_name = rOCh.subinventario
          AND organization_id = l_organization_id
          ;

        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar subinventario ('||rOCh.subinventario||').';
            RAISE eHeaderError;
        END;

        -- Comprador
        BEGIN

          /*SELECT DISTINCT a.agent_id
          INTO l_dummy_num
          FROM per_all_people_f p
             , fnd_user         u
             , po_agents        a
          WHERE 1=1
          AND p.party_id = u.person_party_id
          AND a.agent_id = p.person_id
          --AND u.user_id  = p_user_id;
          AND u.user_name = 'CSCHIAVONE'
          ;*/

          SELECT agent_id
          INTO l_dummy_num
          FROM po_agents
          WHERE agent_id = rOCh.comprador_id
          ;

          l_agent_id := l_dummy_num;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_error_message := 'No fue posible obtener comprador ('||rOCh.comprador_id||').';
            RAISE eHeaderError;
        END;

        -- Productor
        BEGIN
          SELECT vendor_id
          INTO l_vendor_id
          FROM ap_suppliers
          WHERE 1=1
          AND NVL(end_date_active, SYSDATE+1) > TRUNC(SYSDATE)
          AND vendor_id = rOCh.proveedor_id
          ;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_error_message := 'El proveedor se encuentra deshabilitado.';
            RAISE eHeaderError;
        END;

        OPEN cVS (rOCh.unidad_operativa, rOCh.proveedor_id);
        FETCH cVS INTO l_vendor_site_id, l_terms_id;
        IF cVS%NOTFOUND THEN
          CLOSE cVS;
          l_error_message := 'No se encontró Sucursal de compra activa del Depositante para la Unidad Operativa '||rOCh.unidad_operativa; -- CR1991 - Validaciones previas a la generación de la OC
          RAISE eHeaderError;
        END IF;
        CLOSE cVS;

        IF l_terms_id IS NULL THEN
          l_error_message := 'No se encontró Término de Pago en la Sucursal de compra activa del Depositante para la Unidad Operativa '||rOCh.unidad_operativa; -- CR1991 - Validaciones previas a la generación de la OC
          RAISE eHeaderError;        
        END IF;

        BEGIN
          SELECT location_id
          INTO l_ship_to_location_id
          FROM hr_locations
          WHERE location_code = rOCh.direccion_envio;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar dirección de envío ('||rOCh.direccion_envio||').';
            RAISE eHeaderError;
        END;

        /*BEGIN
          SELECT location_id
          INTO l_bill_to_location_id
          FROM hr_locations
          WHERE location_code = rOCh.direccion_facturacion;
        EXCEPTION
          WHEN OTHERS THEN
            l_error_message := 'No fue posible encontrar dirección de envío ('||rOCh.direccion_facturacion||').';
            RAISE eHeaderError;
        END;*/

        IF rOCh.moneda_func != rOCh.moneda THEN
          BEGIN
            SELECT conversion_rate
            INTO l_exchange_rate 
            FROM gl_daily_rates
            WHERE 1=1
            AND conversion_type = 'Corporate'
            AND conversion_date = TRUNC(SYSDATE)
            AND from_currency   = rOCh.moneda 
            AND to_currency     = rOCh.moneda_func
            ;

            l_rate_type      := 'Corporate';
            l_exchange_date  := SYSDATE;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              l_rate_type      := NULL;
              l_exchange_date  := NULL;
              l_exchange_rate  := NULL;
          END;
        ELSE
          l_rate_type      := NULL;
          l_exchange_date  := NULL;
          l_exchange_rate  := NULL;
        END IF;


        IF p_modo_ejecucion = 'F' THEN
          l_progress := 'IDs';
          SELECT NVL(MAX(batch_id),0)+1
          INTO l_batch_id
          FROM po_headers_interface;
          --DBMS_OUTPUT.PUT_LINE('Batch ID: '||l_batch_id);

          SELECT po_headers_interface_s.NEXTVAL
          INTO l_int_header_id
          FROM DUAL;
          --DBMS_OUTPUT.PUT_LINE('Interface Header ID: '||l_int_header_id);

          l_progress := 'intHeader';
          INSERT INTO PO.PO_HEADERS_INTERFACE
          ( INTERFACE_HEADER_ID
          , BATCH_ID
          , PROCESS_CODE
          , ACTION
          , ATTRIBUTE_CATEGORY
          , ATTRIBUTE1
          , ORG_ID
          , COMMENTS
          , DOCUMENT_TYPE_CODE
          , CURRENCY_CODE
          , RATE_TYPE
          , RATE_DATE
          , RATE
          , AGENT_ID
          , VENDOR_ID
          , VENDOR_SITE_ID
          , SHIP_TO_LOCATION_ID
          --, BILL_TO_LOCATION_ID
          , APPROVAL_REQUIRED_FLAG
          , APPROVAL_STATUS
          --, APPROVED_DATE
          , CREATION_DATE
          )
          VALUES
          ( l_int_header_id --  INTERFACE_HEADER_ID
          , l_batch_id
          , 'PENDING'  --  PROCESS_CODE
          , 'ORIGINAL' --  ACTION
          , l_attribute_category
          , rOCh.orden_trabajo
          , rOCh.unidad_operativa
          , SUBSTR(rOCh.referencia, 1, 239)
          , l_doc_type
          , rOCh.moneda  -- CURRENCY_CODE,
          , l_rate_type
          , l_exchange_date
          , l_exchange_rate
          , l_agent_id
          , l_vendor_id
          , l_vendor_site_id
          , l_ship_to_location_id
          --, l_bill_to_location_id
          , 'Y'        -- APPROVAL_REQUIRED_FLAG
          , 'INCOMPLETE' -- APPROVAL_STATUS
          --, SYSDATE    -- APPROVED_DATE
          , SYSDATE    --  CREATION_DATE
          );

        END IF;

        FOR rOCl IN cOCl (rOCh.orden_trabajo) LOOP
          l_rc := cOCl%ROWCOUNT;

          BEGIN

            BEGIN
              SELECT project_id
              INTO l_project_id
              FROM pa_projects_all
              WHERE 1=1
              AND project_status_code NOT IN ('CLOSED', 'REJECTED')
              AND TRUNC(NVL(completion_date, SYSDATE+1)) > TRUNC(SYSDATE)
              AND segment1 = rOCl.proyecto
              ;
            EXCEPTION
              WHEN OTHERS THEN
                l_error_message := 'No fue posible encontrar proyecto ('||rOCl.proyecto||').';
                RAISE eLineError;
            END;

            BEGIN
              SELECT task_id
              INTO l_task_id
              FROM pa_tasks
              WHERE 1=1
              AND TRUNC(NVL(completion_date, SYSDATE+1)) > TRUNC(SYSDATE)
              AND project_id  = l_project_id
              AND task_number = rOCl.tarea
              ;
            EXCEPTION
              WHEN OTHERS THEN
                l_error_message := 'No fue posible encontrar tarea ('||rOCl.proyecto||' || '||rOCl.tarea||').';
                RAISE eLineError;
            END;

            BEGIN
              SELECT pet.expenditure_type
              INTO l_dummy_chr
              FROM pa_transaction_controls  ptc
                 , pa_expenditure_types     pet
              WHERE 1=1
              AND pet.expenditure_category = ptc.expenditure_category
              AND TRUNC(NVL(pet.end_date_active, SYSDATE+1)) > TRUNC(SYSDATE)
              AND ptc.project_id = l_project_id
              AND ptc.task_id    = l_task_id
              AND pet.expenditure_type = rOCl.tipo_erogacion
              ;
            EXCEPTION
              WHEN OTHERS THEN
                l_error_message := 'No fue posible encontrar tipo erogacion ('||rOCl.proyecto||' || '||rOCl.tarea||' || '||rOCl.tipo_erogacion||').';
                RAISE eLineError;
            END;

            BEGIN
              SELECT DISTINCT uom_code
              INTO l_uom_code
              FROM mtl_uom_conversions
              WHERE unit_of_measure = rOCl.uom;
            EXCEPTION
              WHEN OTHERS THEN
                l_error_message := 'No fue posible encontrar unidad de medida ('||rOCl.uom||').';
                RAISE eLineError;
            END;

            BEGIN
              SELECT category_id
              INTO l_category_id
              FROM mtl_categories
              WHERE segment1||'.'||segment2||'.'||segment3 = rOCl.categoria;
            EXCEPTION
              WHEN OTHERS THEN
                l_error_message := 'No fue posible encontrar la categoria ('||rOCl.categoria||').';
                RAISE eLineError;
            END;

            IF p_modo_ejecucion = 'F' THEN
              SELECT cc.chart_of_accounts_id
              INTO l_dummy_num
              FROM mtl_parameters mp, gl_code_combinations cc
              WHERE cc.code_combination_id = mp.material_account
              AND mp.organization_id = rOCh.organizacion_id;

              l_cc_id :=
              FND_FLEX_EXT.get_ccid( application_short_name  => 'SQLGL'
                                   , key_flex_code           => 'GL#'
                                   , structure_number        => l_dummy_num
                                   , validation_date         => TO_CHAR(sysdate, 'DD-MON-YYYY')
                                   , concatenated_segments   => XX_PROJECT_PKG.Get_Account
                                                                ( p_project_id         => l_project_id
                                                                , p_task_id            => l_task_id
                                                                , p_expenditure_type   => rOCl.tipo_erogacion
                                                                , p_expenditure_org_id => rOCh.organizacion_id
                                                                )
                                   );

              BEGIN
                SELECT segment3
                INTO l_segment_un
                FROM gl_code_combinations
                WHERE code_combination_id = l_cc_id;
              EXCEPTION
                WHEN OTHERS THEN
                  l_segment_un := NULL;
              END;

              l_progress := 'intLines';
              l_int_line_id := po_lines_interface_s.nextval;
              INSERT INTO PO.PO_LINES_INTERFACE
              ( INTERFACE_HEADER_ID
              , INTERFACE_LINE_ID
              , ACTION
              , LINE_NUM
              , LINE_TYPE_ID
              , CATEGORY_ID
              , ITEM_DESCRIPTION
              , UOM_CODE
              , QUANTITY
              , UNIT_PRICE
              , ORGANIZATION_ID
              , SHIP_TO_ORGANIZATION_ID
              , SHIP_TO_LOCATION_ID
              , PROMISED_DATE
              , NEED_BY_DATE
              , LINE_ATTRIBUTE_CATEGORY_LINES
              , LINE_ATTRIBUTE2
              , CREATION_DATE
              ) VALUES
              ( l_int_header_id -- INTERFACE_HEADER_ID
              , l_int_line_id   -- INTERFACE_LINE_ID
              , 'ADD'           --  ACTION
              , l_rc            -- LINE_NUM
              , l_line_type_id
              , l_category_id
              , SUBSTR(rOCl.referencia, 1, 239)
              , l_uom_code
              , rOCl.cantidad
              , rOCl.precio
              , l_organization_id
              , l_organization_id
              , l_ship_to_location_id
              , TRUNC(SYSDATE)
              , TRUNC(SYSDATE)
              , 'AR'
              , l_segment_un
              , SYSDATE -- CREATION_DATE,
              );

              l_progress := 'intDistrib';
              INSERT INTO PO.PO_DISTRIBUTIONS_INTERFACE
              ( INTERFACE_HEADER_ID
              , INTERFACE_LINE_ID
              , INTERFACE_DISTRIBUTION_ID
              , DISTRIBUTION_NUM
              , PROJECT_ID
              , TASK_ID
              , EXPENDITURE_TYPE
              , EXPENDITURE_ORGANIZATION_ID
              , EXPENDITURE_ITEM_DATE
              , QUANTITY_ORDERED
              , CHARGE_ACCOUNT_ID
              , ATTRIBUTE_CATEGORY
              , ATTRIBUTE5
              , ATTRIBUTE6
              , ATTRIBUTE13
              , ATTRIBUTE15
              , CREATION_DATE
              ) VALUES
              ( l_int_header_id     -- INTERFACE_HEADER_ID
              , l_int_line_id       -- INTERFACE_LINE_ID
              , po_distributions_interface_s.NEXTVAL
              , l_rc                -- DISTRIBUTION_NUM
              , l_project_id        --PROJECT_ID
              , l_task_id           --TASK_ID
              , rOCl.tipo_erogacion --EXPENDITURE_TYPE
              , rOCh.organizacion_id
              , SYSDATE --rOCh.orden_trabajo_fecha
              , rOCl.cantidad
              , l_cc_id
              , 'AR'
              , TO_CHAR(rOCl.fecha_labor, 'YYYY-MM-DD')
              , TO_CHAR(rOCl.fecha_certificacion, 'YYYY-MM-DD')
              , rOCl.establecimiento_id
              , rOCl.lote
              , SYSDATE -- CREATION_DATE,
              );
            END IF;
          EXCEPTION
            WHEN eLineError THEN

              UPDATE XX_AGRONOMO_INTERFACE_OC_LINEA
              SET importado_flag  = 'E'
                , mensaje_error = l_error_message
              WHERE certificado_id = rOCl.certificado_id;

              RAISE eHeaderError;
          END;
        END LOOP;

        IF p_modo_ejecucion = 'F' THEN
          BEGIN
            IF NOT Run_API ( p_int_header_id     => l_int_header_id
                           , p_operating_unit    => rOCh.unidad_operativa
                           , p_commit            => FND_API.G_TRUE
                           , x_po_header_id      => l_po_header_id
                           , x_po_header_number  => l_po_header_number
                           , x_error_msg         => l_error_message
                           ) THEN
              l_po_header_id  := NULL;
              l_po_header_number := NULL;

              DELETE po_headers_interface WHERE interface_header_id = l_int_header_id;
              DELETE po_lines_interface WHERE interface_header_id = l_int_header_id;
              DELETE po_distributions_interface WHERE interface_header_id = l_int_header_id;
              DELETE po_interface_errors WHERE interface_header_id = l_int_header_id;

              RAISE eLineError;
            END IF;

          EXCEPTION
            WHEN eLineError THEN
              UPDATE XX_AGRONOMO_INTERFACE_OC_LINEA
              SET importado_flag  = 'E'
                , mensaje_error = l_error_message
              WHERE orden_trabajo = rOCh.orden_trabajo;

              RAISE eHeaderError;
          END;
        END IF;

        UPDATE XX_AGRONOMO_INTERFACE_OC
        SET importado_flag = DECODE(p_modo_ejecucion, 'F', 'Y', p_modo_ejecucion)
          , mensaje_error  = NULL
        WHERE orden_trabajo = rOCh.orden_trabajo;

        UPDATE XX_AGRONOMO_INTERFACE_OC_LINEA
        SET importado_flag = DECODE(p_modo_ejecucion, 'F', 'Y', p_modo_ejecucion)
          , po_header_id   = l_po_header_id
          , mensaje_error  = NULL
        WHERE orden_trabajo = rOCh.orden_trabajo;

      EXCEPTION
        WHEN eHeaderError THEN
          UPDATE XX_AGRONOMO_INTERFACE_OC
          SET importado_flag  = 'E'
            , mensaje_error = l_error_message
          WHERE orden_trabajo = rOCh.orden_trabajo;

          UPDATE XX_AGRONOMO_INTERFACE_OC_LINEA
          SET importado_flag  = 'E'
            , mensaje_error = l_error_message
          WHERE orden_trabajo = rOCh.orden_trabajo;

      END;

      l_rc := cOCh%ROWCOUNT;

    END LOOP;

    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Se insertaron '||l_rc||' registros.');
    COMMIT;

    FND_FILE.PUT_LINE(FND_FILE.LOG, '- Generando OCs');
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '+ Ejecutando Interfaz Java para actualizar errores en Argonomo...');
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterfaceOC PROCESS_ERRORS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion||chr(10));
    l_output := NULL;
    l_linecount := NULL;
    dbms_output.disable;
    dbms_output.enable;
    dbms_java.set_output(1023);
    host_command ('cd /ua1001/fs_ne/ADECO/agronomo;/usr/bin/java -cp ''.:/ua1001/fs_ne/ADECO/agronomo/*'' AgronomoInterfaceOC PROCESS_ERRORS '||NVL(p_org_code,'null')||' '||l_fecha_desde||' '||l_fecha_hasta||' '||l_request_id||' '||p_modo_ejecucion);
    dbms_output.get_lines(l_output, l_linecount);
    IF l_output.COUNT > l_linecount THEN
      -- Remove the final empty line above l_linecount
      l_output.TRIM;

      FOR r1 IN (SELECT column_value FROM TABLE(l_output)) LOOP
        FND_FILE.PUT_LINE(FND_FILE.LOG, r1.column_value);
      END LOOP;
    END IF;
    FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');
    FND_FILE.PUT_LINE(FND_FILE.LOG, '- Ejecutando Interfaz Java para actualizar errores en Argonomo...');

    l_rc := 0;
    FOR r2 IN c2 LOOP
      l_rc := c2%ROWCOUNT;
    END LOOP;
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Se encontraron '||l_rc||' registros con error.');

    FOR r2 IN c2 LOOP
      IF c2%ROWCOUNT = 1 THEN
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT, ' ');
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'A continuación se detallan los registros con error:');
        FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Orden Trabajo | Certificado  | Error');
      END IF;

      FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(r2.orden_trabajo, 13, ' ')||' - '||RPAD(r2.certificado,12,' ')||' - '||r2.mensaje_error);
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,  SQLERRM);
      ROLLBACK;
  END Interfaz_OC;


END XX_INV_AGRONOMO_PKG;
/

exit
