WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE XXFA0001_PKGA AUTHID CURRENT_USER AS

  --------------------------------------------------------------------------------
  --
  -- $Header.............: XXFA0001_PKGA_PKS.sql
  --
  -- Copyright (c) 2018, by Stone Inc., All Rights Reserved
  --
  -- Author..............: pontes, paulo, Brazil IT
  -- Component Id........: XXFA0001
  -- Script Location.....: $XXBK_TOP/sql
  -- Description.........:
  -- Package Usage.......: This package will be called from Concurrent manager
  -- Name                  Type         Purpose
  -- --------------------  -----------  ---------------------------------------------------------------------------------------------
  -- LOAD_FILE_P           Procedure    Procedure that loads flat file into stage table
  -- PRINT_REP_P           Procedure    Procedure that display summary information of what has been interfaced
  -- GET_STRING_F          Function     Function that Get string value by position
  --
  -- Notes...............: Need to login into the APPS schema
  -- History:
  -- Name          Date                   Version     Description
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------
  -- pontes, paulo    24-07-2018              1.0      Original Creation
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------------------------------------
  -- ROGERIO FARTO    01-05-2021              1.0      Tratamento data de coloca��o em servi�o permitindo informar periodo anterior ao aberto
  --                                                   Inclus�o de nova coluna com informa��o de ativo ja existente
  --                                                   Tratamento de informa��o para inclus�o (ADDITION) ou ajuste (ADJUSTMENT)              
  --                                                   SR#719513 (NSD338553) 
  -------------------------------------------------------------------------------------------------------------------

  TYPE v_lin_file IS TABLE OF VARCHAR2(32000) INDEX BY BINARY_INTEGER;
  --
  TYPE rec_type IS RECORD (r_descr             VARCHAR2(240)
                         , r_categ_Maior       VARCHAR2(240)
                         , r_categ_Menor       VARCHAR2(240)
                         , r_units             VARCHAR2(240)
                         , r_cost              VARCHAR2(240)
                         , r_company           VARCHAR2(240)
                         , r_cost_center       VARCHAR2(240)
                         , r_bus_unit          VARCHAR2(240)
                         , r_dt_place          VARCHAR2(240)
                         , r_asset_number      VARCHAR2(240)
                         , r_serial_number     VARCHAR2(240)
                         , r_tag_number        VARCHAR2(240)
                         , r_manufat_name      VARCHAR2(240)
                         , r_model_num         VARCHAR2(240)
                         , r_invoice_num       VARCHAR2(240)
                         , r_depreciation      VARCHAR2(240)
                         , r_ytd_deprec        VARCHAR2(240)
                         , r_asset_type        VARCHAR2(240)
                         , r_type              VARCHAR2(240)
                         , r_book_type         VARCHAR2(240)
                         , r_set_of_books      NUMBER
                         , r_add_to_asset      VARCHAR2(240) -- SR#719513 (NSD338553)
                         );
  --
  TYPE rec_tp IS TABLE OF rec_type;
  --
  l_data               rec_tp := rec_tp(); --> Array to Data load
  l_data_ag            rec_tp := rec_tp(); --> Array to Data load
  l_data_e             rec_tp := rec_tp(); --> Array to Data load
  l_data_s             rec_tp := rec_tp(); --> Array to Data load
  vl_org_id            NUMBER := fnd_profile.value('ORG_ID');

 lv_descr             VARCHAR2(240);
 lv_categ_Maior       VARCHAR2(240);
 lv_categ_Menor       VARCHAR2(240);
 lv_units             VARCHAR2(240);
 lv_cost              VARCHAR2(240);
 lv_company           VARCHAR2(240);
 lv_cost_center       VARCHAR2(240);
 lv_bus_unit          VARCHAR2(240);
 lv_dt_place          VARCHAR2(240);
 lv_asset_number      VARCHAR2(240);
 lv_serial_number     VARCHAR2(240);
 lv_tag_number        VARCHAR2(240);
 lv_manufat_name      VARCHAR2(240);
 lv_model_num         VARCHAR2(240);
 lv_invoice_num       VARCHAR2(240);
 lv_depreciation      VARCHAR2(240);
 lv_ytd_deprec        VARCHAR2(240);
 lv_asset_type        VARCHAR2(240);
 lv_type              VARCHAR2(240);
 lv_book_type         VARCHAR2(240);
 lv_book_type_code    VARCHAR2(240);
 lv_set_of_books      NUMBER;
 lv_add_to_asset      VARCHAR2(240); -- SR#719513 (NSD338553)

  PROCEDURE transfer_file ( p_filename_orig  IN VARCHAR2
                            , p_directory     IN VARCHAR2
                            , p_filename_dst  IN VARCHAR2
                            , p_operation     IN VARCHAR2);
  --
  PROCEDURE load_file_p( p_errbuf    OUT VARCHAR2
                        ,p_retcode   OUT NUMBER
                        ,p_location  IN VARCHAR2
                        ,p_filename  IN VARCHAR2
                        ,p_delimiter IN NUMBER DEFAULT NULL);
  --
  FUNCTION get_string_f(p_lin IN VARCHAR2,
                        p_del IN VARCHAR2,
                        p_pos IN NUMBER) RETURN VARCHAR2;
  --
  PROCEDURE print_rep_p(p_line          IN rec_tp
                      , p_line_e        IN rec_tp
                      , p_diretory      IN VARCHAR2
                      , p_filename      IN VARCHAR2
                      , p_header        IN VARCHAR2);
  --
  FUNCTION check_company_f(p_company  IN VARCHAR2
                         , p_book_type_code OUT VARCHAR2
                         , p_set_of_books   OUT NUMBER) RETURN BOOLEAN;
  --
  FUNCTION load_asset(p_asset IN rec_tp) RETURN BOOLEAN;
  --
END XXFA0001_PKGA;
/

EXIT; 