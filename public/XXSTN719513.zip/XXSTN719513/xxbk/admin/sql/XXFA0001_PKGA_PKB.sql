WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY      XXFA0001_PKGA IS
  --------------------------------------------------------------------------------
  --
  -- $Header.............: XXFA0001_PKGA_PKB.sql
  --
  -- Copyright (c) 2018, by Stone Inc., All Rights Reserved
  --
  -- Author..............: pontes, paulo, Brazil IT
  -- Component Id........: XXFA0001_PKGA
  -- Script Location.....: $XXBK_TOP/sql
  -- Description.........:
  -- Package Usage.......: This package will be called from Concurrent manager
  -- Name                  Type         Purpose
  -- --------------------  -----------  ---------------------------------------------------------------------------------------------
  -- LOAD_FILE_P           Procedure    Procedure that Load Asset
  -- PRINT_REP_P           Procedure    Procedure that display summary information of what has been interfaced
  -- GET_STRING_F          Function     Function that Get string value by position
  --
  -- Notes...............: Need to login into the APPS schema
  -- History:
  -- Name          Date                   Version     Description
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------------------------------------
  -- pontes, paulo    24-07-2018              1.0      Original Creation
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------------------------------------
  -- ROGERIO FARTO    26-03-2020              1.0      Tratamento para busca de informa��es de vida util e percentual sucata por livro
  --                                                   SR#492739 (NSD317164)
  -- ------------  ---------------------  ----------  ---------------------------------------------------------------------------------------------
  -- ROGERIO FARTO    01-05-2021              1.0      Tratamento data de coloca��o em servi�o permitindo informar periodo anterior ao aberto
  --                                                   Inclus�o de nova coluna com informa��o de ativo ja existente
  --                                                   Tratamento de informa��o para inclus�o (ADDITION) ou ajuste (ADJUSTMENT)              
  --                                                   SR#719513 (NSD338553)
  -------------------------------------------------------------------------------------------------------------------------------------------------

  -------------------------------------------------------------------------------------------------------------------------------------------------
   v_status    BOOLEAN;                           --> Execution status
   --
  PROCEDURE transfer_file ( p_filename_orig  IN VARCHAR2
                            , p_directory     IN VARCHAR2
                            , p_filename_dst  IN VARCHAR2
                            , p_operation     IN VARCHAR2)
   IS
   /*
   --
   -- $Header.............: XXCUST_FA0002_PKGA.sql
   --
   -- Copyright (c) 2018, by Stone Inc., All Rights Reserved
   --
   -- Author..............: Paulo Pontes
   -- Component Id........: XXFA0002
   -- Script Location.....: $XXBK_TOP/sql
   -- Description.........: Package that will get file and sent to another directory
   -- Package Usage.......:
   -- Name                        Type         Purpose
   -- --------------------        -----------  ------------------------------------------------
   -- transfer_file               Procedure    Procedure that transfer files
  -- Parameters:
  --              Name:   p_filename_orig
  --              Type: IN
  --              Datatype: VARCHAR2
  --              Required: NO
  --              Format: N/A
  --              Purpose:  File Name that will be Removed/Renamed
  --
  --              Name:   p_directory
  --              Type: IN
  --              Datatype: Varchar2
  --              Required: No
  --              Format: N/A
  --              Purpose:  Directory Name where file is
  --
  --              Name:   p_filename_dst
  --              Type: IN
  --              Datatype: VARCHAR2
  --              Required: NO
  --              Format: N/A
  --              Purpose:  New File Name that will be Removed/Renamed
  --
  --              Name:   p_operation
  --              Type: IN
  --              Datatype: Varchar2
  --              Required: No
  --              Format: N/A
  --              Purpose:  Oparation that will be made, Remove ou Rename

   -- History:
   -- Name                 Date          Version    Description
   -- ------------------   -----------   --------   --------------------------------------------
   -- Paulo Pontes          16-NOV-2017   1.0        Original Creation
   --
   */

   l_message        VARCHAR2(500);
   vl_filename_xml  VARCHAR2(200) := p_filename_orig;
   vl_filename_dst  VARCHAR2(200) := p_filename_dst;
   l_file           UTL_FILE.FILE_TYPE;
   --
   BEGIN
     --
     --
          IF p_filename_orig IS NOT NULL THEN
       --
        BEGIN
          --
          l_file := UTL_FILE.FOPEN(p_directory, vl_filename_xml,'R');
          --
          IF UTL_FILE.IS_OPEN(l_file) THEN
            --
            UTL_FILE.FCLOSE(l_file);
            -- rename the file
            BEGIN
              --
              --
              IF p_operation = 'R' THEN
                --
                --null;
                utl_file.frename (src_location  => p_directory
                                 ,src_filename  => vl_filename_xml
                                 ,dest_location => p_directory
                                 ,dest_filename => vl_filename_dst
                                 ,overwrite     => TRUE);
                --
              ELSIF p_operation = 'D' THEN
                --
                null;
                utl_file.fremove (location  => p_directory
                                 ,filename  => vl_filename_xml);
                --
              END IF;
              --
            EXCEPTION
              WHEN OTHERS THEN
                --
                l_message := SQLERRM;
                fnd_file.put_line(fnd_file.log, 'WARNING: File not renamed/removed. - '||l_message);
                --
            END;

          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            --
            --
            BEGIN
              --
              l_file := UTL_FILE.FOPEN(p_directory,vl_filename_xml,'R');
              --
              IF UTL_FILE.IS_OPEN(l_file) THEN
                UTL_FILE.FCLOSE(l_file);
                --
              END IF;
              --
            EXCEPTION
              WHEN OTHERS THEN
                --
                fnd_file.put_line(fnd_file.log, 'WARNING: File not found.');
                --
            END;
        END;
        --
        fnd_file.put_line(fnd_file.output, '---');
        fnd_file.put_line(fnd_file.output, 'File Removed: ' || vl_filename_xml);
        fnd_file.put_line(fnd_file.output, '---');
        fnd_file.put_line(fnd_file.output, ' ');
        --
     END IF;
     --
   EXCEPTION
      WHEN OTHERS THEN
        --
        l_message := SQLERRM;
        fnd_file.put_line(fnd_file.log, 'ERROR: ' || l_message);
        --
   END transfer_file;
   --
  FUNCTION load_asset(p_asset IN rec_tp) RETURN BOOLEAN IS
  --
   l_trans_rec                FA_API_TYPES.trans_rec_type;
   l_trans_rec1               FA_API_TYPES.trans_rec_type;
   l_dist_trans_rec           FA_API_TYPES.trans_rec_type;
   l_dist_trans_rec1           FA_API_TYPES.trans_rec_type;
   l_asset_hdr_rec            FA_API_TYPES.asset_hdr_rec_type;
   l_asset_hdr_rec1            FA_API_TYPES.asset_hdr_rec_type;
   l_asset_desc_rec           FA_API_TYPES.asset_desc_rec_type;
   l_asset_desc_rec1           FA_API_TYPES.asset_desc_rec_type;
   l_asset_cat_rec            FA_API_TYPES.asset_cat_rec_type;
   l_asset_cat_rec1            FA_API_TYPES.asset_cat_rec_type;
   l_asset_type_rec           FA_API_TYPES.asset_type_rec_type;
   l_asset_type_rec1           FA_API_TYPES.asset_type_rec_type;
   l_asset_hierarchy_rec      FA_API_TYPES.asset_hierarchy_rec_type;
   l_asset_hierarchy_rec1      FA_API_TYPES.asset_hierarchy_rec_type;
   l_asset_fin_rec            FA_API_TYPES.asset_fin_rec_type;
   l_asset_fin_rec1            FA_API_TYPES.asset_fin_rec_type;
   l_asset_deprn_rec          FA_API_TYPES.asset_deprn_rec_type;
   l_asset_deprn_rec1          FA_API_TYPES.asset_deprn_rec_type;
   l_asset_dist_rec           FA_API_TYPES.asset_dist_rec_type;
   l_asset_dist_rec1           FA_API_TYPES.asset_dist_rec_type;
   l_asset_dist_tbl           FA_API_TYPES.asset_dist_tbl_type;
   l_inv_tbl                  FA_API_TYPES.inv_tbl_type;
   l_inv_rate_tbl             FA_API_TYPES.inv_rate_tbl_type;
   -- api adjustment
   ladj_trans_rec                 FA_API_TYPES.trans_rec_type;
   ladj_asset_hdr_rec             FA_API_TYPES.asset_hdr_rec_type;
   ladj_asset_fin_rec_adj         FA_API_TYPES.asset_fin_rec_type;
   ladj_asset_fin_rec_new         FA_API_TYPES.asset_fin_rec_type;
   ladj_asset_fin_mrc_tbl_new     FA_API_TYPES.asset_fin_tbl_type; 
   ladj_inv_trans_rec             FA_API_TYPES.inv_trans_rec_type;
   ladj_inv_tbl                   FA_API_TYPES.inv_tbl_type;
   ladj_inv_rate_tbl              FA_API_TYPES.inv_rate_tbl_type;
   ladj_asset_deprn_rec_adj       FA_API_TYPES.asset_deprn_rec_type;
   ladj_asset_deprn_rec_new       FA_API_TYPES.asset_deprn_rec_type;
   ladj_asset_deprn_mrc_tbl_new   FA_API_TYPES.asset_deprn_tbl_type;
   ladj_inv_rec                   FA_API_TYPES.inv_rec_type;
   ladj_group_reclass_options_rec FA_API_TYPES.group_reclass_options_rec_type;

   l_return_status            VARCHAR2(1);
   l_mesg_count               NUMBER;
   l_mesg                     VARCHAR2(4000);
   vl_category_id             fa_categories_b.category_id%TYPE;
   vl_life_in_months          fa_category_book_defaults.life_in_months%TYPE;
   vl_prorate_convention_code fa_category_book_defaults.prorate_convention_code%TYPE;
   vl_depreciate_flag         fa_category_book_defaults.depreciate_flag%TYPE;
   vl_percent_salvage_value   fa_category_book_defaults.percent_salvage_value%TYPE;
   vl_expense_account_ccid    fa_category_books.deprn_expense_account_ccid%TYPE;
   vl_deprn_method            fa_category_book_defaults.deprn_method%TYPE;
   vl_location_id             NUMBER;
   vl_asset_key_ccid          fa_asset_keywords.code_combination_id%TYPE;
   vl_expense_acct_ccid       fa_category_books.deprn_expense_account_ccid%TYPE;
   vl_ccontab                 VARCHAR2(240);
   l_period_aberto            NUMBER; --alt fpavao 23/07/2019 - SR#333868
   l_period_anterior          NUMBER; 
   e_exit                     EXCEPTION; --alt fpavao 23/07/2019 - SR#333868
   --
   v_add_to_asset_id          number;
   v_depreciate_flag          varchar2(50);
   --
  BEGIN
   --
   IF p_asset.count > 0 THEN
     --
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records ==> '||p_asset.count);
     DBMS_OUTPUT.PUT_LINE('Total Records ==> '||p_asset.count);
     --
     FOR i IN p_asset.first..p_asset.last LOOP

      BEGIN --alt fpavao 23/07/2019 - SR#333868 end

       -- desc info
       FND_FILE.PUT_LINE(FND_FILE.LOG,'Processando Asset ==> '||p_asset(i).r_asset_number);
       DBMS_OUTPUT.PUT_LINE('Processando Asset ==> '||p_asset(i).r_asset_number);
       FND_FILE.PUT_LINE(FND_FILE.LOG,'Processando Serial ==> '||p_asset(i).r_serial_number);
       DBMS_OUTPUT.PUT_LINE('Processando Serial ==> '||p_asset(i).r_serial_number);
       FND_FILE.PUT_LINE(FND_FILE.LOG,'Processando Tag ==> '||p_asset(i).r_tag_number);
       DBMS_OUTPUT.PUT_LINE('Processando Tag ==> '||p_asset(i).r_tag_number);

   l_trans_rec                := l_trans_rec1;
   l_dist_trans_rec           := l_dist_trans_rec1;
   l_asset_hdr_rec            := l_asset_hdr_rec1;
   l_asset_desc_rec           := l_asset_desc_rec1;
   l_asset_cat_rec            := l_asset_cat_rec1;
   l_asset_type_rec           := l_asset_type_rec1;
   l_asset_hierarchy_rec      := l_asset_hierarchy_rec1;
   l_asset_fin_rec            := l_asset_fin_rec1;
   l_asset_deprn_rec          := l_asset_deprn_rec1;
   l_asset_dist_rec           := l_asset_dist_rec1;

       l_asset_dist_tbl.delete;
       l_inv_tbl.delete;
       l_inv_rate_tbl.delete;

       Begin
         select code_combination_id
           into vl_asset_key_ccid
           from FA.fa_asset_keywords
          where segment1 = 'N/A';
       End;

       l_asset_desc_rec.asset_number                 := p_asset(i).r_asset_number;
       l_asset_desc_rec.tag_number                   := p_asset(i).r_tag_number;
       l_asset_desc_rec.serial_number                := p_asset(i).r_serial_number;
       l_asset_desc_rec.in_use_flag                  := 'YES';
       l_asset_desc_rec.new_used                     := 'NEW';
       l_asset_desc_rec.owned_leased                 := 'OWNED';
       l_asset_desc_rec.current_units                := 1;--p_asset.r_units;
       l_asset_desc_rec.description                  := p_asset(i).r_descr;
       l_asset_desc_rec.asset_key_ccid               := vl_asset_key_ccid;
       l_asset_desc_rec.manufacturer_name            := p_asset(i).r_manufat_name;

       -- cat info
       -- Valid Value in FA_CATEGORIES

       BEGIN
         --
         DBMS_OUTPUT.PUT_LINE('Executando API para '||p_asset(i).r_descr);
         --
          SELECT DISTINCT fc.category_id
               , fcd.life_in_months
               , fcd.prorate_convention_code
               , fcd.depreciate_flag
               -- 'PCT' salvage_type,
               , NVL(fcd.percent_salvage_value, 0)
               , fcb.deprn_expense_account_ccid
               , fcd.deprn_method
            INTO
                 vl_category_id
               , vl_life_in_months
               , vl_prorate_convention_code
               , vl_depreciate_flag
               , vl_percent_salvage_value
               , vl_expense_account_ccid
               , vl_deprn_method
            FROM fa.fa_categories_b           fc,
                 fa.fa_category_books         fcb,
                 fa.fa_category_book_defaults fcd
           WHERE 1 = 1
             AND fc.category_id = fcb.category_id
             AND fcd.category_id = fcb.category_id
             AND fc.segment1 = NVL(p_asset(i).r_categ_Maior, fc.segment1)
             AND fc.segment2 = NVL(p_asset(i).r_categ_Menor, fc.segment2)
             AND fcb.book_type_code = p_asset(i).r_book_type
             AND fcb.book_type_code = fcd.book_type_code; -- SR#492739 - ROGERIO FARTO - NINECON - 23/03/2020
--             AND ROWNUM = 1;
        EXCEPTION
          WHEN OTHERS THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Exception no Select FA_CATEGORIES');
            DBMS_OUTPUT.PUT_LINE('Exception no Select FA_CATEGORIES');
         --
       END;
       --

       l_asset_cat_rec.category_id                   := vl_category_id;
       --

       --type info
       l_asset_type_rec.asset_type                   := UPPER(p_asset(i).r_asset_type);

       -- Asset Financial Information --
       l_asset_fin_rec.set_of_books_id               := p_asset(i).r_set_of_books;

       l_asset_fin_rec.date_placed_in_service        := TO_DATE(p_asset(i).r_dt_place,'DD/MM/RRRR');

       --alt fpavao 23/07/2019 - SR#333868 begin
       l_period_aberto := 0;
       BEGIN

        SELECT COUNT(*)
          INTO l_period_aberto
          FROM fa_deprn_periods
         WHERE book_type_code = p_asset(i).r_book_type
           AND period_close_date is null
           AND period_name = to_char(to_date(p_asset(i).r_dt_place,'DD/MM/RRRR'),'MON-RR');

        EXCEPTION
         WHEN OTHERS THEN
          FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro ao verificar se o periodo esta aberto ou fechado, valor campo p_asset(i).r_dt_place: '||p_asset(i).r_dt_place||' - '||SQLERRM);
          raise e_exit;

       END;

       IF l_period_aberto = 0 THEN
         l_period_anterior := 0;
         BEGIN
           select count(*)
             into l_period_anterior
             from apps.fa_deprn_periods fdp
                , apps.fa_book_controls fbc
            where 1 = 1
              and fdp.book_type_code = 'STONE_CORP' 
              and fdp.book_type_code = fbc.book_type_code
              and fdp.period_counter = fbc.last_period_counter
              and fdp.period_name = to_char(to_date(p_asset(i).r_dt_place,'DD/MM/RRRR'),'MON-RR');       
         EXCEPTION
           WHEN OTHERS THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro ao verificar se o periodo esta aberto ou fechado (periodo anterior), valor campo p_asset(i).r_dt_place: '||p_asset(i).r_dt_place||' - '||SQLERRM);
            raise e_exit;         
         END;         
         --
         if l_period_anterior = 0 then
           FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
           FND_FILE.PUT_LINE(FND_FILE.LOG,'De acordo com a data informado no campo date_placed_in_service: '||p_asset(i).r_dt_place||' o periodo esta fechado e n�o esta no ultimo per�odo fechado!');
           raise e_exit;
         end if;
         --
       END IF;
       --alt fpavao 23/07/2019 - SR#333868 end

       l_asset_fin_rec.deprn_start_date              := NULL;
       l_asset_fin_rec.deprn_method_code             := vl_deprn_method;--p_asset(i).r_depreciation;
       l_asset_fin_rec.life_in_months                := vl_life_in_months;
       l_asset_fin_rec.original_cost                 := p_asset(i).r_cost;
       l_asset_fin_rec.cost                          := p_asset(i).r_cost;
       l_asset_fin_rec.prorate_convention_code       := vl_prorate_convention_code;
       l_asset_fin_rec.salvage_type                  := 'PCT';  --'AMT'; -- PCT - for Percentage
       l_asset_fin_rec.salvage_value                 := NULL;
       l_asset_fin_rec.percent_salvage_value         := vl_percent_salvage_value;
       l_asset_fin_rec.depreciate_flag               := vl_depreciate_flag;
       l_asset_fin_rec.orig_deprn_start_date         := NULL;

       -- deprn info
       l_asset_deprn_rec.set_of_books_id             := p_asset(i).r_set_of_books;
       l_asset_deprn_rec.ytd_deprn                   := NULL;--TO_DATE(p_asset(i).r_ytd_deprec,'DD-MON-RRRR');
       l_asset_deprn_rec.deprn_reserve               := NULL;
       l_asset_deprn_rec.bonus_ytd_deprn             := 0;
       l_asset_deprn_rec.bonus_deprn_reserve         := 0;

       -- book / trans info
       -- Valid value in FA_BOOK_CONTROLS
       l_asset_hdr_rec.book_type_code                := p_asset(i).r_book_type;
       --
       BEGIN
         --
        SELECT gcce.code_combination_id
             , gcce.segment1
               ||'.'|| gcce.segment2
               ||'.'|| gcce.segment3
               ||'.'|| gcce.segment4
               ||'.'|| gcce.segment5
               ||'.'|| gcce.segment6
               ||'.'|| gcce.segment7
               ||'.'|| gcce.segment8
          INTO vl_expense_acct_ccid
             , vl_ccontab
          FROM gl_code_combinations gccd
             , gl_code_combinations gcce
         WHERE 1 = 1
           AND gccd.code_combination_id = vl_expense_account_ccid
           AND gcce.segment1 = gccd.segment1
           AND gcce.segment2 = gccd.segment2
           AND gcce.segment3 = gccd.segment3
           AND gcce.segment4 = gccd.segment4
           AND gcce.segment5 = p_asset(i).r_cost_center
           AND gcce.segment6 = gccd.segment6
           AND gcce.segment7 = NVL(p_asset(i).r_bus_unit,'00000000')
           AND gcce.segment8 = gccd.segment8;

       EXCEPTION
         WHEN OTHERS THEN
           vl_expense_acct_ccid := NULL;
       END;

       -- distribution info
       l_asset_dist_rec.units_assigned               := 1;
       -- Valid Record from GL Code cominations with record type = 'E' (Expense)
       l_asset_dist_rec.expense_ccid                 := vl_expense_acct_ccid;
       -- Valid Value in FA Locations
       BEGIN
         --
         SELECT location_id
           INTO
               vl_location_id
           FROM fa.fa_locations
          WHERE 1=1
            AND segment1 = 'DEFAULT'
            AND segment2 = 'DEFAULT';

         --
       END;
       l_asset_dist_rec.location_ccid                := vl_location_id;
       l_asset_dist_rec.assigned_to                  := NULL;
       l_asset_dist_rec.transaction_units            := l_asset_dist_rec.units_assigned;
       l_asset_dist_tbl(1)                           := l_asset_dist_rec;
       --
       l_inv_tbl(1).invoice_number                   := p_asset(i).r_invoice_num;
       --
       l_return_status := NULL;
       l_mesg_count    := NULL;
       l_mesg          := NULL;
       --
       IF p_asset(i).r_type = 'ADDITION' THEN 
         -- call the api
         fa_addition_pub.do_addition(
                 -- std parameters
                 p_api_version             => 1.0,
                 p_init_msg_list           => FND_API.G_TRUE,--G_FALSE,
                 p_commit                  => FND_API.G_FALSE,
                 p_validation_level        => FND_API.G_VALID_LEVEL_FULL,
                 p_calling_fn              => null,
                 x_return_status           => l_return_status,
                 x_msg_count               => l_mesg_count,
                 x_msg_data                => l_mesg,
                 -- api parameters
                 px_trans_rec              => l_trans_rec,
                 px_dist_trans_rec         => l_dist_trans_rec,
                 px_asset_hdr_rec          => l_asset_hdr_rec,
                 px_asset_desc_rec         => l_asset_desc_rec,
                 px_asset_type_rec         => l_asset_type_rec,
                 px_asset_cat_rec          => l_asset_cat_rec,
                 px_asset_hierarchy_rec    => l_asset_hierarchy_rec,
                 px_asset_fin_rec          => l_asset_fin_rec,
                 px_asset_deprn_rec        => l_asset_deprn_rec,
                 px_asset_dist_tbl         => l_asset_dist_tbl,
                 px_inv_tbl                => l_inv_tbl
                );
         --
         COMMIT;
         --dump messages
         l_mesg_count := fnd_msg_pub.count_msg;

         IF l_mesg_count > 0 THEN
            l_mesg := chr(10) || substr(fnd_msg_pub.get
                                      (fnd_msg_pub.G_FIRST, fnd_api.G_FALSE),
                                           1, 250);
            FND_FILE.PUT_LINE(FND_FILE.LOG,l_mesg);
            DBMS_OUTPUT.PUT_LINE(l_mesg);
            FOR i IN 1..(l_mesg_count - 1) LOOP
               l_mesg :=
                           substr(fnd_msg_pub.get
                                  (fnd_msg_pub.G_NEXT,
                                   fnd_api.G_FALSE), 1, 250);
               FND_FILE.PUT_LINE(FND_FILE.LOG,l_mesg);
               DBMS_OUTPUT.PUT_LINE(l_mesg);
            END LOOP;
            fnd_msg_pub.delete_msg();
         END IF;

         IF (l_return_status <> FND_API.G_RET_STS_SUCCESS) THEN
           FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
           DBMS_OUTPUT.PUT_LINE('FAILURE -- > '||l_return_status);
           --
           l_data_e.extend;
           l_data_e(l_data_e.last).r_asset_type     := UPPER(p_asset(i).r_asset_type);
           l_data_e(l_data_e.last).r_asset_number   := p_asset(i).r_asset_number;
           l_data_e(l_data_e.last).r_serial_number  := p_asset(i).r_serial_number;
           l_data_e(l_data_e.last).r_tag_number     := p_asset(i).r_tag_number;
           l_data_e(l_data_e.last).r_book_type      := p_asset(i).r_book_type;
           l_data_e(l_data_e.last).r_descr          := vl_ccontab; --substr(l_mesg,1,239);
           l_data_e(l_data_e.last).r_descr          := vl_ccontab; --substr(l_mesg,1,239);
           l_data_e(l_data_e.last).r_type           := p_asset(i).r_type; -- SR#719513 (NSD338553)
           l_data_e(l_data_e.last).r_add_to_asset   := p_asset(i).r_add_to_asset; -- SR#719513 (NSD338553)
           
           --
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Ativo...............:'||p_asset(i).r_asset_number);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Conta da Categoria..:'||vl_expense_account_ccid);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Centro de Custos....:'||p_asset(i).r_cost_center);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Unidade de Neg�?³cio..:'||NVL(p_asset(i).r_bus_unit,'00000000'));
         ELSE
           FND_FILE.PUT_LINE(FND_FILE.LOG,'SUCCESS');
           DBMS_OUTPUT.PUT_LINE('SUCCESS --> '||l_return_status);
           --
           l_data_s.extend;
           l_data_s(l_data_s.last).r_asset_type     := UPPER(p_asset(i).r_asset_type);
           l_data_s(l_data_s.last).r_asset_number   := p_asset(i).r_asset_number;
           l_data_s(l_data_s.last).r_serial_number  := p_asset(i).r_serial_number;
           l_data_s(l_data_s.last).r_tag_number     := p_asset(i).r_tag_number;
           l_data_s(l_data_s.last).r_book_type      := p_asset(i).r_book_type;
           l_data_s(l_data_s.last).r_descr          := vl_ccontab;  --to_char(l_asset_hdr_rec.asset_id);
           l_data_s(l_data_s.last).r_type           := p_asset(i).r_type; -- SR#719513 (NSD338553)
           l_data_s(l_data_s.last).r_add_to_asset   := p_asset(i).r_add_to_asset; -- SR#719513 (NSD338553)
           --
           FND_FILE.PUT_LINE(FND_FILE.LOG,'ASSET_ID :' || to_char(l_asset_hdr_rec.asset_id));
           FND_FILE.PUT_LINE(FND_FILE.LOG,'ASSET_NUMBER :' || l_asset_desc_rec.asset_number);
           DBMS_OUTPUT.PUT_LINE('ASSET_NUMBER :' || l_asset_desc_rec.asset_number);
         END IF;
       END IF; --TYPE = ADDITION
       --
       IF p_asset(i).r_type = 'ADJUSTMENT' THEN
         --
         if p_asset(i).r_add_to_asset is null then 
           FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Obrigatorio informar ativo a ser ajustado (ADD TO ASSET) para transacao tipo ADJUSTMENT');
           raise e_exit;  
         else
           begin
             select fa.asset_id
                  , fb.depreciate_flag
               into v_add_to_asset_id
                  , v_depreciate_flag
               from apps.fa_additions fa
                  , apps.fa_books     fb
              where 1 = 1
                and fa.asset_number = p_asset(i).r_add_to_asset
                and fa.asset_id = fb.asset_id
                and fb.book_type_code = p_asset(i).r_book_type
                and fb.date_ineffective is null;
           exception
             when no_data_found then
               FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Ativo informado para ajuste '||p_asset(i).r_add_to_asset||' n�o exsite ou nao pertence ao livro '||p_asset(i).r_book_type);
               raise e_exit;
             when others then
               FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Ativo informado para ajuste '||p_asset(i).r_add_to_asset||' n�o exsite ou nao pertence ao livro '||p_asset(i).r_book_type);
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro: '||sqlerrm);
               raise e_exit;            
           end;
         end if;
         -- asset header info
         ladj_asset_hdr_rec.asset_id       := v_add_to_asset_id;
         ladj_asset_hdr_rec.book_type_code := p_asset(i).r_book_type;

         -- invoice trans
         ladj_inv_trans_rec.transaction_type           := 'INVOICE ADDITION';

         -- invoice info
         if v_depreciate_flag = 'YES' then         
           ladj_trans_rec.transaction_subtype := 'AMORTIZED';
         else 
           ladj_trans_rec.transaction_subtype := 'EXPENSED';
         end if;
         --
         ladj_inv_rec.fixed_assets_cost                := p_asset(i).r_cost;
         ladj_inv_rec.description                      := p_asset(i).r_descr;
         ladj_inv_rec.payables_units                   := 1;
         ladj_inv_rec.inv_indicator                    := 1;
         ladj_inv_rec.invoice_number                   := p_asset(i).r_invoice_num;
         ladj_inv_tbl (1)                              := ladj_inv_rec;
         -- call API
         FA_ADJUSTMENT_PUB.do_adjustment(-- std parameters
                                         p_api_version               => 1.0,
                                         p_init_msg_list             => FND_API.G_FALSE,
                                         p_commit                    => FND_API.G_FALSE,
                                         p_validation_level          => FND_API.G_VALID_LEVEL_FULL,
                                         p_calling_fn                => null,
                                         x_return_status             => l_return_status,
                                         x_msg_count                 => l_mesg_count,
                                         x_msg_data                  => l_mesg,
                                         -- api parameters
                                         px_trans_rec                => ladj_trans_rec,
                                         px_asset_hdr_rec            => ladj_asset_hdr_rec,
                                         p_asset_fin_rec_adj         => ladj_asset_fin_rec_adj,
                                         x_asset_fin_rec_new         => ladj_asset_fin_rec_new,
                                         x_asset_fin_mrc_tbl_new     => ladj_asset_fin_mrc_tbl_new,
                                         px_inv_trans_rec            => ladj_inv_trans_rec,
                                         px_inv_tbl                  => ladj_inv_tbl,
                                         p_asset_deprn_rec_adj       => ladj_asset_deprn_rec_adj,
                                         x_asset_deprn_rec_new       => ladj_asset_deprn_rec_new,
                                         x_asset_deprn_mrc_tbl_new   => ladj_asset_deprn_mrc_tbl_new,
                                         p_group_reclass_options_rec => ladj_group_reclass_options_rec);
         --
         COMMIT;
         --dump messages
         l_mesg_count := fnd_msg_pub.count_msg;

         IF l_mesg_count > 0 THEN
            l_mesg := chr(10) || substr(fnd_msg_pub.get
                                      (fnd_msg_pub.G_FIRST, fnd_api.G_FALSE),
                                           1, 250);
            FND_FILE.PUT_LINE(FND_FILE.LOG,l_mesg);
            DBMS_OUTPUT.PUT_LINE(l_mesg);
            FOR i IN 1..(l_mesg_count - 1) LOOP
               l_mesg :=
                           substr(fnd_msg_pub.get
                                  (fnd_msg_pub.G_NEXT,
                                   fnd_api.G_FALSE), 1, 250);
               FND_FILE.PUT_LINE(FND_FILE.LOG,l_mesg);
               DBMS_OUTPUT.PUT_LINE(l_mesg);
            END LOOP;
            fnd_msg_pub.delete_msg();
         END IF;

         IF (l_return_status <> FND_API.G_RET_STS_SUCCESS) THEN
           FND_FILE.PUT_LINE(FND_FILE.LOG,'FAILURE');
           DBMS_OUTPUT.PUT_LINE('FAILURE -- > '||l_return_status);
           --
           l_data_e.extend;
           l_data_e(l_data_e.last).r_asset_type     := UPPER(p_asset(i).r_asset_type);
           l_data_e(l_data_e.last).r_asset_number   := p_asset(i).r_asset_number;
           l_data_e(l_data_e.last).r_serial_number  := p_asset(i).r_serial_number;
           l_data_e(l_data_e.last).r_tag_number     := p_asset(i).r_tag_number;
           l_data_e(l_data_e.last).r_book_type      := p_asset(i).r_book_type;
           l_data_e(l_data_e.last).r_descr          := vl_ccontab; --substr(l_mesg,1,239);
           l_data_e(l_data_e.last).r_descr          := vl_ccontab; --substr(l_mesg,1,239);
           l_data_e(l_data_e.last).r_type           := p_asset(i).r_type; -- SR#719513 (NSD338553)
           l_data_e(l_data_e.last).r_add_to_asset   := p_asset(i).r_add_to_asset; -- SR#719513 (NSD338553)
           
           --
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Ativo...............:'||p_asset(i).r_asset_number);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Conta da Categoria..:'||vl_expense_account_ccid);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Centro de Custos....:'||p_asset(i).r_cost_center);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Unidade de Negocio..:'||NVL(p_asset(i).r_bus_unit,'00000000'));
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Tipo................:'||p_asset(i).r_type);
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Add to Asset........:'||p_asset(i).r_add_to_asset);
         ELSE
           FND_FILE.PUT_LINE(FND_FILE.LOG,'SUCCESS');
           DBMS_OUTPUT.PUT_LINE('SUCCESS --> '||l_return_status);
           --
           l_data_s.extend;
           l_data_s(l_data_s.last).r_asset_type     := UPPER(p_asset(i).r_asset_type);
           l_data_s(l_data_s.last).r_asset_number   := p_asset(i).r_asset_number;
           l_data_s(l_data_s.last).r_serial_number  := p_asset(i).r_serial_number;
           l_data_s(l_data_s.last).r_tag_number     := p_asset(i).r_tag_number;
           l_data_s(l_data_s.last).r_book_type      := p_asset(i).r_book_type;
           l_data_s(l_data_s.last).r_descr          := vl_ccontab;  --to_char(l_asset_hdr_rec.asset_id);
           l_data_s(l_data_s.last).r_type           := p_asset(i).r_type; -- SR#719513 (NSD338553)
           l_data_s(l_data_s.last).r_add_to_asset   := p_asset(i).r_add_to_asset; -- SR#719513 (NSD338553)
           --
           FND_FILE.PUT_LINE(FND_FILE.LOG,'Add to Asset :' || p_asset(i).r_add_to_asset);
           --
         END IF;                                         
       END IF; --TYPE = ADJUSTMENT
        --alt fpavao 23/07/2019 - SR#333868 begin
        EXCEPTION
         WHEN e_exit THEN
          l_data_e.extend;
          l_data_e(l_data_e.last).r_asset_type     := UPPER(p_asset(i).r_asset_type);
          l_data_e(l_data_e.last).r_asset_number   := p_asset(i).r_asset_number;
          l_data_e(l_data_e.last).r_serial_number  := p_asset(i).r_serial_number;
          l_data_e(l_data_e.last).r_tag_number     := p_asset(i).r_tag_number;
          l_data_e(l_data_e.last).r_book_type      := p_asset(i).r_book_type;
          l_data_e(l_data_e.last).r_descr          := ''; --substr(l_mesg,1,239);
          l_data_e(l_data_e.last).r_type           := p_asset(i).r_type; -- SR#719513 (NSD338553)
          l_data_e(l_data_e.last).r_add_to_asset   := p_asset(i).r_add_to_asset; -- SR#719513 (NSD338553)          
          --
       END;
       --alt fpavao 23/07/2019 - SR#333868 end

     END LOOP;
     --
   END IF;
   --
   IF (l_return_status <> FND_API.G_RET_STS_SUCCESS) then
     --
     RETURN(FALSE);
     --
   ELSE
     --
     RETURN(TRUE);
     --
   END IF;
   --
  EXCEPTION
    WHEN OTHERS THEN
      --
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro: '||SQLERRM);
      DBMS_OUTPUT.PUT_LINE('Erro: '||SQLERRM);
      RETURN(FALSE);
  END load_asset;
   --
   FUNCTION check_company_f(p_company        IN VARCHAR2
                          , p_book_type_code OUT VARCHAR2
                          , p_set_of_books   OUT NUMBER) RETURN BOOLEAN IS
   --
   vl_book_type_code   fa_book_controls.book_type_code%TYPE;
   vl_found            BOOLEAN;
   vl_set_of_books_id  fa_book_controls.set_of_books_id%TYPE;
   --
   BEGIN
     --
     BEGIN
       --
       SELECT fbc.book_type_code
            , fbc.set_of_books_id
         INTO vl_book_type_code
            , vl_set_of_books_id
         FROM fa_book_controls fbc
            , gl_code_combinations gcc
        WHERE fbc.flexbuilder_defaults_ccid = gcc.code_combination_id
          AND gcc.segment1 = p_company
          ;
        --
     EXCEPTION
       WHEN OTHERS THEN
         --
         vl_found := FALSE;
         --
     END;
     --
     IF vl_book_type_code IS NOT NULL THEN
       --
       vl_found := TRUE;
       --
     ELSE
       --
       vl_found := FALSE;
       --
     END IF;
     --
     p_book_type_code := vl_book_type_code;
     p_set_of_books   := vl_set_of_books_id;
     --
     RETURN(vl_found);
     --
   EXCEPTION
     WHEN OTHERS THEN
       --
       RETURN(FALSE);
       --
   END check_company_f;
   --



   FUNCTION get_string_f (p_lin      IN VARCHAR2
                         ,p_del      IN VARCHAR2
                         ,p_pos      IN NUMBER) RETURN VARCHAR2 IS
   -----------------------------------------------------------------------------
   -- Developer......: ribas, paulo, Brazil IT
   -- Date Created...: 24-07-2018
   -- Component Id...: XXFA0001
   -- Purpose........: Get string value by position
   -- Parameters.....: <Enter these details for each parameter>
   --
   --                  Name        : p_lin
   --                  Type        : in
   --                  Datatype    : VARCHAR2
   --                  Required    : Yes
   --                  Format      : N/A
   --                  Purpose     : Delimited Line to be broken
   --
   --                  Name        : p_del
   --                  Type        : in
   --                  Datatype    : VARCHAR2
   --                  Required    : Yes
   --                  Format      : N/A
   --                  Purpose     : Delimiter character
   --
   --                  Name        : p_pos
   --                  Type        : in
   --                  Datatype    : VARCHAR2
   --                  Required    : Yes
   --                  Format      : N/A
   --                  Purpose     : Desired Position
   -- Procedure Usage: This procedure will be called from Concurrent manager
   -- Other Remarks..: none
   -- Modification History
   -- Person        Date       Version Comments and changes made
   -- ------------- ---------- ------- -----------------------------------------
   -- ribas, paulo  24-01-2018 1.0     Original Creation
   -----------------------------------------------------------------------------
   v_aux  VARCHAR2(4000);
   BEGIN
      -----------------------------------------------------------------------------
      --> Filling temporary processing variable
      -----------------------------------------------------------------------------
      --v_aux := p_del||p_lin||p_del;                                   -- 3S - TRAMOS - 02/05/2019
      v_aux := p_del||REGEXP_REPLACE(p_lin,'[^[:print:]]',null)||p_del; -- 3S - TRAMOS - 02/05/2019
      RETURN(SUBSTR(v_aux,INSTR(v_aux, p_del, 1, p_pos) + 1
                         ,INSTR(v_aux, p_del, 1, p_pos+1) -
                          INSTR(v_aux, p_del, 1, p_pos)-1));
   END get_string_f;

   PROCEDURE load_file_p(p_errbuf    OUT VARCHAR2
                        ,p_retcode   OUT NUMBER
                        ,p_location  IN VARCHAR2
                        ,p_filename  IN VARCHAR2
                        ,p_delimiter IN NUMBER DEFAULT NULL) IS
     -----------------------------------------------------------------------------
     -- Developer......: pontes, paulo, Brazil IT
     -- Date Created...: 24-07-2018
     -- Component Id...: XXFA0001
     -- Purpose........: Load flat file to check Supplier and Branches
     -- Parameters.....: <Enter these details for each parameter>
     --
     --                  Name        : P_ERRBUF
     --                  Type        : OUT
     --                  Datatype    : VARCHAR2
     --                  Required    : Yes
     --                  Format      : N/A
     --                  Purpose     : Error buffer exit.
     --
     --                  Name        : P_RETCODE
     --                  Type        : OUT
     --                  Datatype    : NUMBER
     --                  Required    : Yes
     --                  Format      : N/A
     --                  Purpose     : Error code exit.
     --
     -- Procedure Usage: This procedure will be called from Concurrent manager
     -- Other Remarks..: none
     -- Modification History
     -- Person        Date        Version Comments and changes made
     -- ------------- ----------  ------- -----------------------------------------
     -- pontes, paulo  24-07-2018  1.0     Original Creation

     -----------------------------------------------------------------------------
   BEGIN
     DECLARE
       -----------------------------------------------------------------------
       --> Data variable
       -----------------------------------------------------------------------
       TYPE v_error_type IS TABLE OF VARCHAR2(4000) INDEX BY BINARY_INTEGER;

       v_error              v_error_type; --> Error Description
       v_line               v_lin_file;
       lv_seg_type          VARCHAR2(5);
       vl_nls               VARCHAR2(2000);
       vl_header            VARCHAR2(2000);
       vl_load              BOOLEAN;

       -----------------------------------------------------------------------
       --> File Treatment variable
       -----------------------------------------------------------------------
       v_arq_id       UTL_FILE.file_type; --> ID for file
       v_del_fl       VARCHAR2(1) := ';';--p_delimiter;--chr(p_delimiter); --> File Delimiter
       v_arq_dr       VARCHAR2(30) := p_location;--'XXSTN_FA_STN_IN'; --> Source Directory
       v_arq_er       VARCHAR2(4000); --> File opening error
       v_lin_ds       VARCHAR2(4000); --> File Line
       v_cnt_rg       NUMBER := 0; --> Index array
       v_rcount       NUMBER := 0; --> Record Counter
       v_ecount       NUMBER := 0; --> Error Counter
       v_org_id       VARCHAR2(15); --> Org Id
       v_dummy        VARCHAR2(1); --> Auxiliar Variable
       lv_nls              VARCHAR2(50);
       l_qtd_erro_warning NUMBER := 0; --alt fpavao 20/08/2019 - SR#333868
       -----------------------------------------------------------------------
       --> Exceptions
       -----------------------------------------------------------------------
       e_validation_org_id EXCEPTION;

     BEGIN
       --
       lv_nls := 'alter session set nls_language=''AMERICAN''';
       --
       Execute Immediate lv_nls;
       --
       --------------------------------------------------------------------
       --> printing File Name
       --------------------------------------------------------------------
       FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'** ');
       FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'** Loading File : ' || p_filename || '...');
       FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'** ');
       DBMS_OUTPUT.PUT_LINE('** Loading File : ' || p_filename || '...');
       -----------------------------------------------------------------------
       --> Opening the file
       -----------------------------------------------------------------------
       BEGIN
         --
         v_arq_id := UTL_FILE.fopen(v_arq_dr, p_filename, 'R');
         --
       EXCEPTION
         WHEN UTL_FILE.invalid_path THEN
           v_arq_er := 'ORA 29280 - Specified path does not exist or is not visible to Oracle';
         WHEN UTL_FILE.access_denied THEN
           v_arq_er := 'ORA 29289 - Access to the file has been denied by the operating system';
         WHEN UTL_FILE.internal_error THEN
           v_arq_er := 'ORA 29286 - Unhandled internal error in the UTL_FILE package';
         WHEN UTL_FILE.invalid_filehandle THEN
           v_arq_er := 'ORA 29282 - File handle does not exist';
         WHEN UTL_FILE.invalid_filename THEN
           v_arq_er := 'ORA 29288 - A file with the specified name does not exist in the path';
         WHEN UTL_FILE.invalid_operation THEN
           v_arq_er := 'ORA 29283 - File could not be opened or operated on as requested';
         WHEN UTL_FILE.read_error THEN
           v_arq_er := 'ORA 29284 - Unable to read file';
         WHEN OTHERS THEN
           v_arq_er := SQLERRM;
       END;
       --
       --DBMS_OUTPUT.PUT_LINE(v_arq_er);
       --
       -----------------------------------------------------------------------
       --> Processing File
       -----------------------------------------------------------------------
       IF v_arq_er IS NOT NULL THEN
         --------------------------------------------------------------------
         --> printing Error Message on file processing
         --------------------------------------------------------------------
         FND_FILE.PUT_LINE(FND_FILE.LOG,'** Error --> ' || v_arq_er);
         FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
         p_errbuf  := v_arq_er;
         p_retcode := 2;
         --
       ELSE
         --------------------------------------------------------------------------
         --> Validate Parameters: Org_id
         --------------------------------------------------------------------------
         BEGIN
           v_org_id := fnd_profile.value('ORG_ID');
           v_org_id := 82;
           SELECT 1
             INTO v_dummy
             FROM hr_all_organization_units
            WHERE organization_id = v_org_id
              AND (date_to IS NULL OR trunc(date_to) >= trunc(SYSDATE));
         EXCEPTION
           WHEN OTHERS THEN
             RAISE e_validation_org_id;
         END;
         --
         vl_nls := 'alter session set nls_numeric_characters='',.''';
         EXECUTE IMMEDIATE vl_nls;
         --------------------------------------------------------------------
         --> Processing file data
         --------------------------------------------------------------------
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'                                                                    ');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'STONE PAGAMENTOS S/A                                     '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'           Stone Pagamentos Carga de Ativos               ');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'                                                                    ');
         -----------------------------------------------------------------------
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'');
         --
         l_data.delete;
         --
         LOOP
           BEGIN
             --
             --DBMS_OUTPUT.PUT_LINE(' No Loop');
             --
             --------------------------------------------------------------
             --> Getting data from file
             --------------------------------------------------------------
             UTL_FILE.get_line(v_arq_id, v_lin_ds);
             --------------------------------------------------------------
             --> Counting processed records
             --------------------------------------------------------------
             BEGIN
               --
               lv_seg_type         := SUBSTR(v_lin_ds,1,1);
               --
                v_rcount := v_rcount + 1;
                --
               IF  v_rcount != 1 AND lv_seg_type IS NOT NULL THEN
                 --
                 v_cnt_rg := v_cnt_rg + 1;
                 --
                 lv_descr             := GET_STRING_F(v_lin_ds, v_del_fl,01);
                 lv_categ_Maior       := GET_STRING_F(v_lin_ds, v_del_fl,02);
                 lv_categ_Menor       := GET_STRING_F(v_lin_ds, v_del_fl,03);
                 lv_units             := GET_STRING_F(v_lin_ds, v_del_fl,04);
                 lv_cost              := GET_STRING_F(v_lin_ds, v_del_fl,05);
                 lv_company           := GET_STRING_F(v_lin_ds, v_del_fl,06);
                 lv_cost_center       := GET_STRING_F(v_lin_ds, v_del_fl,07);
                 lv_bus_unit          := GET_STRING_F(v_lin_ds, v_del_fl,08);
                 lv_dt_place          := GET_STRING_F(v_lin_ds, v_del_fl,09);
                 lv_asset_number      := GET_STRING_F(v_lin_ds, v_del_fl,10);
                 lv_serial_number     := GET_STRING_F(v_lin_ds, v_del_fl,11);
                 lv_tag_number        := GET_STRING_F(v_lin_ds, v_del_fl,12);
                 lv_manufat_name      := GET_STRING_F(v_lin_ds, v_del_fl,13);
                 lv_model_num         := GET_STRING_F(v_lin_ds, v_del_fl,14);
                 lv_invoice_num       := GET_STRING_F(v_lin_ds, v_del_fl,15);
                 lv_depreciation      := GET_STRING_F(v_lin_ds, v_del_fl,16);
                 lv_ytd_deprec        := GET_STRING_F(v_lin_ds, v_del_fl,17);
                 lv_asset_type        := GET_STRING_F(v_lin_ds, v_del_fl,18);
                 lv_type              := GET_STRING_F(v_lin_ds, v_del_fl,19);
                 lv_add_to_asset      := GET_STRING_F(v_lin_ds, v_del_fl,20);  -- SR#719513 (NSD338553)
                 --
                 --DBMS_OUTPUT.PUT_LINE('Check_Company_f');
                 IF Check_Company_f(p_company        => lv_company
                                  , p_book_type_code => lv_book_type_code
                                  , p_set_of_books   => lv_set_of_books) THEN
                   --
                    --DBMS_OUTPUT.PUT_LINE('IF Check_Company_f');
                   --
                   l_data.extend;
                   l_data(l_data.last).r_descr             := lv_descr;
                   l_data(l_data.last).r_categ_Maior       := lv_categ_Maior;
                   l_data(l_data.last).r_categ_Menor       := lv_categ_Menor;
                   l_data(l_data.last).r_units             := lv_units;
                   l_data(l_data.last).r_cost              := lv_cost;
                   l_data(l_data.last).r_company           := lv_company;
                   l_data(l_data.last).r_cost_center       := lv_cost_center;
                   l_data(l_data.last).r_bus_unit          := lv_bus_unit;
                   l_data(l_data.last).r_dt_place          := lv_dt_place;
                   l_data(l_data.last).r_asset_number      := lv_asset_number;
                   l_data(l_data.last).r_serial_number     := lv_serial_number;
                   l_data(l_data.last).r_tag_number        := lv_tag_number;
                   l_data(l_data.last).r_manufat_name      := lv_manufat_name;
                   l_data(l_data.last).r_model_num         := lv_model_num;
                   l_data(l_data.last).r_invoice_num       := lv_invoice_num;
                   l_data(l_data.last).r_depreciation      := lv_depreciation;
                   l_data(l_data.last).r_ytd_deprec        := lv_ytd_deprec;
                   l_data(l_data.last).r_asset_type        := lv_asset_type;
                   l_data(l_data.last).r_type              := lv_type;
                   l_data(l_data.last).r_book_type         := lv_book_type_code;
                   l_data(l_data.last).r_set_of_books      := lv_set_of_books;
                   l_data(l_data.last).r_add_to_asset      := lv_add_to_asset; -- SR#719513 (NSD338553)
                   --
                   begin
                     insert into apps.xxstn_crtl_xxfa0001 (description                    -- 01
                                                          ,categoria_maior                -- 02
                                                          ,categoria_menor                -- 03
                                                          ,units                          -- 04
                                                          ,cost                           -- 05
                                                          ,company                        -- 06
                                                          ,cost_center                    -- 07
                                                          ,business_unit                  -- 08
                                                          ,date_placed_in_service         -- 09
                                                          ,asset_number                   -- 10
                                                          ,serial_number                  -- 11
                                                          ,tag_number                     -- 12
                                                          ,manufacturer_name              -- 13
                                                          ,model_number                   -- 14
                                                          ,invoice_number                 -- 15
                                                          ,depreciation_reserve           -- 16
                                                          ,ytd_depreciation               -- 17
                                                          ,asset_type                     -- 18
                                                          ,action_type                    -- 19 
                                                          ,book_type_code                 -- 20
                                                          ,set_of_books                   -- 21
                                                          ,add_to_asset                   -- 22
                                                          ,created_by                     -- 23
                                                          ,creation_date                  -- 24
                                                          ,request_id                     -- 25
                                                          ,file_name)                     -- 26
                                                   values (lv_descr                       -- 01
                                                          ,lv_categ_Maior                 -- 02
                                                          ,lv_categ_Menor                 -- 03
                                                          ,lv_units                       -- 04
                                                          ,lv_cost                        -- 05
                                                          ,lv_company                     -- 06
                                                          ,lv_cost_center                 -- 07
                                                          ,lv_bus_unit                    -- 08
                                                          ,lv_dt_place                    -- 09
                                                          ,lv_asset_number                -- 10
                                                          ,lv_serial_number               -- 11
                                                          ,lv_tag_number                  -- 12
                                                          ,lv_manufat_name                -- 13
                                                          ,lv_model_num                   -- 14
                                                          ,lv_invoice_num                 -- 15
                                                          ,lv_depreciation                -- 16
                                                          ,lv_ytd_deprec                  -- 17
                                                          ,lv_asset_type                  -- 18
                                                          ,lv_type                        -- 19 
                                                          ,lv_book_type_code              -- 20
                                                          ,lv_set_of_books                -- 21
                                                          ,lv_add_to_asset                -- 22
                                                          ,fnd_profile.value('USER_ID')   -- 23
                                                          ,sysdate                        -- 24
                                                          ,fnd_global.conc_request_id     -- 25
                                                          ,p_filename);                   -- 26                                                          
                     commit;
                   exception
                     when others then
                       fnd_file.put_line(fnd_file.log,'Erro ao gravar registro de rastreamento. ');
                       fnd_file.put_line(fnd_file.log,'  >> '||sqlerrm);
                   end;
                   --
                 ELSE
                   --
                   --v_rcount := v_rcount + 1;
                   --
                   l_data_ag.extend;
                   l_data_ag(l_data_ag.last).r_descr             := lv_descr;
                   l_data_ag(l_data_ag.last).r_categ_Maior       := lv_categ_Maior;
                   l_data_ag(l_data_ag.last).r_categ_Menor       := lv_categ_Menor;
                   l_data_ag(l_data_ag.last).r_units             := lv_units;
                   l_data_ag(l_data_ag.last).r_cost              := lv_cost;
                   l_data_ag(l_data_ag.last).r_company           := lv_company;
                   l_data_ag(l_data_ag.last).r_cost_center       := lv_cost_center;
                   l_data_ag(l_data_ag.last).r_bus_unit          := lv_bus_unit;
                   l_data_ag(l_data_ag.last).r_dt_place          := lv_dt_place;
                   l_data_ag(l_data_ag.last).r_asset_number      := lv_asset_number;
                   l_data_ag(l_data_ag.last).r_serial_number     := lv_serial_number;
                   l_data_ag(l_data_ag.last).r_tag_number        := lv_tag_number;
                   l_data_ag(l_data_ag.last).r_manufat_name      := lv_manufat_name;
                   l_data_ag(l_data_ag.last).r_model_num         := lv_model_num;
                   l_data_ag(l_data_ag.last).r_invoice_num       := lv_invoice_num;
                   l_data_ag(l_data_ag.last).r_depreciation      := lv_depreciation;
                   l_data_ag(l_data_ag.last).r_ytd_deprec        := lv_ytd_deprec;
                   l_data_ag(l_data_ag.last).r_asset_type        := lv_asset_type;
                   l_data_ag(l_data_ag.last).r_type              := lv_type;
                   l_data_ag(l_data_ag.last).r_book_type         := lv_book_type_code;
                   l_data_ag(l_data_ag.last).r_add_to_asset      := lv_add_to_asset; -- SR#719513 (NSD338553)
                   --
                 END IF;
                 --
               END IF;
               --------------------------------------------------------------
               --> Filling array variables
               --------------------------------------------------------------

             EXCEPTION
               WHEN OTHERS THEN
                FND_FILE.PUT_LINE(FND_FILE.LOG,'Erro '||SQLERRM);
                 v_cnt_rg := v_cnt_rg - 1;
                 v_ecount := v_ecount + 1;
                 v_error(v_ecount) := SUBSTR('Error Reading Line ' ||
                                             v_rcount || ' (' ||
                                             GET_STRING_F(v_lin_ds,
                                                          v_del_fl,
                                                          04) || '): ' ||
                                             SQLERRM,
                                             1,
                                             4000);
             END;
             --------------------------------------------------------------
             --> Insert records into table
             --------------------------------------------------------------
           EXCEPTION
             WHEN no_data_found THEN
               IF v_cnt_rg >= 1 THEN
                 -----------------------------------------------------------
                 --> Calling procedure to insert data
                 -----------------------------------------------------------
               NULL;
                 --
               END IF;
               -----------------------------------------------------------
               --> Exiting Loop
               -----------------------------------------------------------
               EXIT;
             WHEN OTHERS THEN
               v_ecount := v_ecount + 1;
               v_error(v_ecount) := SUBSTR('Error Reading Line ' ||
                                           v_rcount || ' (' ||
                                           GET_STRING_F(v_lin_ds,
                                                        v_del_fl,
                                                        01) || '): ' ||
                                           SQLERRM,
                                           1,
                                           4000);
           END;
           --
           v_line(v_cnt_rg) := v_lin_ds;
           --
         END LOOP;
         --
         UTL_FILE.FCLOSE(v_arq_id);
         --
         IF l_data.COUNT > 0 THEN
           --
           vl_load := load_asset(p_asset => l_data);
           --
           --
           IF l_data_s.count > 0 OR l_data_e.count > 0 THEN
             --
             print_rep_p (p_line     => l_data_s
                         ,p_line_e   => l_data_e
                         ,p_diretory => p_location
                         ,p_filename => p_filename
                         ,p_header   => 'F');
             --
           END IF;
           --
           --
         END IF;
         --
         --------------------------------------------------------------------
         --> Rename file
         --------------------------------------------------------------------
         transfer_file ( p_filename_orig  => p_filename
                       , p_directory      => p_location
                       , p_filename_dst   => p_filename||'.processado_'||to_char(sysdate,'DDMMYYYYHH24MISS')
                       , p_operation      => 'R');

         --
         --
         --------------------------------------------------------------------
         --> Printing errors if happens
         --------------------------------------------------------------------
         IF v_error.COUNT <> 0 THEN
           -----------------------------------------------------------------
           --> Printing errors
           -----------------------------------------------------------------
           FND_FILE.PUT_LINE(FND_FILE.LOG,'');
           FND_FILE.PUT_LINE(FND_FILE.LOG,'');
           FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
           FND_FILE.PUT_LINE(FND_FILE.LOG,'** There are Records cannot be processed :');
           FND_FILE.PUT_LINE(FND_FILE.LOG,'** ' || lpad('-', 77, '-'));
           FOR x IN 1 .. v_error.COUNT LOOP
             FND_FILE.PUT_LINE(FND_FILE.LOG,'** ' || substr(v_error(X), 1, 115));
           END LOOP;
           FND_FILE.PUT_LINE(FND_FILE.LOG,'** ' || lpad('-', 77, '-'));
           --
           p_errbuf  := 'Execution Critical error. Please check execution log';
           p_retcode := 1;
           --
         END IF;
         --
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
         DBMS_OUTPUT.PUT_LINE(' ');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,' ');
         DBMS_OUTPUT.PUT_LINE(' ');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'** Total: ');
         DBMS_OUTPUT.PUT_LINE('** Total: ');
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'** Records Read: ' || TO_CHAR(v_rcount-1));
         DBMS_OUTPUT.PUT_LINE('** Records Read: ' || TO_CHAR(v_rcount-1));
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'** Records Error: ' || to_CHAR(v_ecount + l_data_e.count));
         DBMS_OUTPUT.PUT_LINE('** Records Error: ' || to_CHAR(v_ecount + l_data_e.count));
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
         DBMS_OUTPUT.PUT_LINE('*****************************************************************************');

         --alt fpavao 20/08/2019 - SR#333868 begin
         l_qtd_erro_warning := NVL(v_ecount,0) + NVL(l_data_e.count,0);

         IF NVL(l_qtd_erro_warning,0) > 0 THEN

          p_retcode := 1;

         END IF;
         --alt fpavao 20/08/2019 - SR#333868 end

         --
       END IF;
       --
     EXCEPTION
       WHEN e_validation_org_id THEN
         --------------------------------------------------------------------
         --> printing Error Message for Invalid Org_Id
         --------------------------------------------------------------------
         FND_FILE.PUT_LINE(FND_FILE.LOG,'** Error --> Org Id "' || v_org_id ||
                              '"  is Invalid or Deactivate.');
         FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
         --
         p_errbuf  := 'Execution Critical error. Please check execution log';
         p_retcode := 2;
         --
       WHEN OTHERS THEN
         --------------------------------------------------------------------
         --> Rollback All Data
         --------------------------------------------------------------------
         ROLLBACK;
         --------------------------------------------------------------------
         --> Set Errors variables
         --------------------------------------------------------------------
         p_errbuf  := SUBSTR(SQLERRM, 1, 500);
         p_retcode := 2;
         --------------------------------------------------------------------
         --> Print Error Messages
         --------------------------------------------------------------------
         FND_FILE.PUT_LINE(FND_FILE.LOG,'** Unexpected error please contact your system administrator');
         FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_errbuf =  ' ||
                              SUBSTR(SQLERRM, 1, 500));
         FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_retcode =  ' ||
                              SQLCODE);
         FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
         --
     END;
   END load_file_p;

   --
   /*=======================================================================*/
   --

   PROCEDURE print_rep_p (p_line       IN  rec_tp
                        , p_line_e     IN rec_tp
                        , p_diretory   IN VARCHAR2
                        , p_filename   IN VARCHAR2
                        , p_header     IN VARCHAR2)      IS
   -----------------------------------------------------------------------------
   -- Developer......: pontes, paulo, Brazil IT
   -- Date Created...: 24-07-2018
   -- Component Id...: XXFA0001
   -- Purpose........: Display summary information of what has been interfaced
   -- Parameters.....: <Enter these details for each parameter>
   --
   --                  Name        : P_ERRBUF
   --                  Type        : OUT
   --                  Datatype    : VARCHAR2
   --                  Required    : Yes
   --                  Format      : N/A
   --                  Purpose     : Error buffer exit.
   --
   --                  Name        : P_RETCODE
   --                  Type        : OUT
   --                  Datatype    : NUMBER
   --                  Required    : Yes
   --                  Format      : N/A
   --                  Purpose     : Error code exit.
   --
   --                  Name        : p_line
   --                  Type        : IN
   --                  Datatype    : v_lin_file
   --                  Required    : Yes
   --                  Format      : N/A
   --                  Purpose     : Collection with the data of the file
   --
   -- Procedure Usage: This procedure will be called from Concurrent manager
   -- Other Remarks..: none
   -- Modification History
   -- Person            Date        Version   Comments and changes made
   -- -------------   ----------    -------   -----------------------------------------
   -- pontes, paulo    24-07-2018    1.0       Original Creation

   -----------------------------------------------------------------------------
   BEGIN
      DECLARE
         -----------------------------------------------------------------------
         --> Auxiliary variables
         -----------------------------------------------------------------------
         v_print             VARCHAR2(32000);           --> Auxiliary variable to print record
         v_print_header      VARCHAR2(32000);            --> Auxiliary variable to print record
         v_count             NUMBER(15) := 0;           --> Counter
         lv_dat_fl           UTL_FILE.file_type;        --> File
         lv_filename         VARCHAR2(240);             --> File Name
         lv_file_extension   VARCHAR2(25)   := '.csv';  --> File Extension
         lv_data_file        VARCHAR2(32000);           --> File data
         lv_buffer           RAW(32000);                --> Binary file data
         --
      BEGIN
         --
         v_print_header := 'Type'||';'||
                           'Asset Number'||';'||
                           'Serial Number'||';'||
                           'Tag Number'||';'||
                           'Book'||';'||
                           'Conta Despesa'||';'||
                           'Tipo a��o'||';'||    -- SR#719513 (NSD338553)
                           'Add do Asset'||';'|| -- SR#719513 (NSD338553)
                           'Status';            
         --
         IF p_line.count > 0 THEN
           --
           --------------------------------------------------------------------------
           --> Printing Header
           --------------------------------------------------------------------------
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'                                                                    ');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'STONE PAGAMENTOS S/A                                                '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'           Stone Pagamentos Ativos Carregados             ');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'                                                                    ');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,v_print_header);
           DBMS_OUTPUT.PUT_LINE(v_print_header);
           --
           FOR x IN p_line.first..p_line.last LOOP
              --
              v_count := v_count + 1;
              --
              v_print := p_line(x).r_asset_type      ||';'||
                         p_line(x).r_asset_number    ||';'||
                         p_line(x).r_serial_number   ||';'||
                         p_line(x).r_tag_number      ||';'||
                         p_line(x).r_book_type       ||';'||
                         p_line(x).r_descr           ||';'||
                         p_line(x).r_type            ||';'|| -- SR#719513 (NSD338553)
                         p_line(x).r_add_to_asset    ||';'|| -- SR#719513 (NSD338553)
                         'S';
              --
              FND_FILE.PUT_LINE(FND_FILE.OUTPUT,v_print);
              dbms_output.PUT_LINE(v_print);
              --
            END LOOP;
         END IF;
         --
         IF p_line_e.count > 0 THEN
           --------------------------------------------------------------------------
           --> Printing Header
           --------------------------------------------------------------------------
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'                                                                    ');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'STONE PAGAMENTOS S/A                                                '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'           Stone Pagamentos Ativos com Erro             ');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'                                                                    ');
           --
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,v_print_header);
           DBMS_OUTPUT.PUT_LINE(v_print_header);
           --
           FOR x IN p_line_e.first..p_line_e.last LOOP
              --
              v_count := v_count + 1;
              --
              v_print := p_line_e(x).r_asset_type      ||';'||
                         p_line_e(x).r_asset_number    ||';'||
                         p_line_e(x).r_serial_number   ||';'||
                         p_line_e(x).r_tag_number      ||';'||
                         p_line_e(x).r_book_type       ||';'||
                         p_line_e(x).r_descr           ||';'||
                         p_line_e(x).r_type            ||';'|| -- SR#719513 (NSD338553)
                         p_line_e(x).r_add_to_asset    ||';'|| -- SR#719513 (NSD338553)                        
                         'E';
              --
              FND_FILE.PUT_LINE(FND_FILE.OUTPUT,v_print);
              dbms_output.PUT_LINE(v_print);
              --
            END LOOP;
         END IF;
         --
         IF UTL_FILE.is_open(lv_dat_fl) THEN
           -----------------------------------------------------------------------
           --> Closing Files for data transfer
           -----------------------------------------------------------------------
           UTL_FILE.fclose(lv_dat_fl);
         END IF;
         --
         lv_filename := p_filename||'_'||
                        'out_'||
                        to_char(SYSDATE, 'yyyymmddhh24miss')||lv_file_extension; --> 3.1
         --
         lv_dat_fl   := UTL_FILE.fopen(p_diretory, lv_filename, 'WB', 32000);
         --
         v_print_header := v_print_header || chr(13) || chr(10);
         lv_buffer    := utl_raw.cast_to_raw(v_print_header);
         UTL_FILE.put_raw(lv_dat_fl, lv_buffer);
         -----------------------------------------------------------------------
         --> Processing data
         -----------------------------------------------------------------------
         IF p_line.count > 0 THEN
           FOR x IN p_line.first..p_line.last LOOP
             --
             v_count := v_count + 1;
             --
               v_print := p_line(x).r_asset_type      ||';'||
                          p_line(x).r_asset_number    ||';'||
                          p_line(x).r_serial_number   ||';'||
                          p_line(x).r_tag_number      ||';'||
                          p_line(x).r_book_type       ||';'||
                          p_line(x).r_descr           ||';'||
                          p_line(x).r_type            ||';'|| -- SR#719513 (NSD338553)
                          p_line(x).r_add_to_asset    ||';'|| -- SR#719513 (NSD338553)                          
                          'S';
             --
             dbms_output.PUT_LINE(v_print);
             --
             v_print := v_print || chr(13) || chr(10);
             lv_buffer    := utl_raw.cast_to_raw(v_print);
             UTL_FILE.put_raw(lv_dat_fl, lv_buffer);
             --
           END LOOP;
         END IF;
         --
         IF p_line_e.count > 0 THEN
           FOR x IN p_line_e.first..p_line_e.last LOOP
             --
             v_count := v_count + 1;
             --
               v_print := p_line_e(x).r_asset_type      ||';'||
                          p_line_e(x).r_asset_number    ||';'||
                          p_line_e(x).r_serial_number   ||';'||
                          p_line_e(x).r_tag_number      ||';'||
                          p_line_e(x).r_book_type       ||';'||
                          p_line_e(x).r_descr           ||';'||
                          p_line_e(x).r_type            ||';'|| -- SR#719513 (NSD338553)
                          p_line_e(x).r_add_to_asset    ||';'|| -- SR#719513 (NSD338553)                          
                          'E';
             --
             dbms_output.PUT_LINE(v_print);
             --
             v_print := v_print || chr(13) || chr(10);
             lv_buffer    := utl_raw.cast_to_raw(v_print);
             UTL_FILE.put_raw(lv_dat_fl, lv_buffer);
             --
           END LOOP;
         END IF;
         --
         UTL_FILE.fclose(lv_dat_fl);
         --
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'*****************************************************************************');
         --------------------------------------------------------------------
         -->
         --------------------------------------------------------------------
         --
     EXCEPTION
       WHEN OTHERS THEN
         --------------------------------------------------------------------
         --> Print Error Messages
         --------------------------------------------------------------------
         fnd_file.put_line(fnd_file.log,'** Unexpected error in PRINT_REP_P');
         fnd_file.put_line(fnd_file.log,'** UNHANDLED EXCEPTION/p_errbuf =  ' || SUBSTR(SQLERRM, 1, 150));
         fnd_file.put_line(fnd_file.log,'** UNHANDLED EXCEPTION/p_retcode =  ' || SQLCODE);
         --------------------------------------------------------------------
      END;
   END print_rep_p;
  --
END XXFA0001_PKGA;
/

EXIT; 