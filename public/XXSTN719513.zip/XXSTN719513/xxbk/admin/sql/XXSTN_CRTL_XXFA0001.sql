WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

CREATE TABLE APPS.XXSTN_CRTL_XXFA0001 (DESCRIPTION            VARCHAR2(240)
                                      ,CATEGORIA_MAIOR        VARCHAR2(240)
                                      ,CATEGORIA_MENOR        VARCHAR2(240)
                                      ,UNITS                  VARCHAR2(240)
                                      ,COST                   VARCHAR2(240)
                                      ,COMPANY                VARCHAR2(240)
                                      ,COST_CENTER            VARCHAR2(240)
                                      ,BUSINESS_UNIT          VARCHAR2(240)
                                      ,DATE_PLACED_IN_SERVICE VARCHAR2(240)
                                      ,ASSET_NUMBER           VARCHAR2(240)
                                      ,SERIAL_NUMBER          VARCHAR2(240)
                                      ,TAG_NUMBER             VARCHAR2(240)
                                      ,MANUFACTURER_NAME      VARCHAR2(240)
                                      ,MODEL_NUMBER           VARCHAR2(240)
                                      ,INVOICE_NUMBER         VARCHAR2(240)
                                      ,DEPRECIATION_RESERVE   VARCHAR2(240)
                                      ,YTD_DEPRECIATION       VARCHAR2(240)
                                      ,ASSET_TYPE             VARCHAR2(240)
                                      ,ACTION_TYPE            VARCHAR2(240)
                                      ,BOOK_TYPE_CODE         VARCHAR2(240)
                                      ,SET_OF_BOOKS           VARCHAR2(240)
                                      ,ADD_TO_ASSET           VARCHAR2(240)
                                      ,CREATED_BY             VARCHAR2(240)
                                      ,CREATION_DATE          DATE
                                      ,REQUEST_ID             VARCHAR2(240)
                                      ,FILE_NAME              VARCHAR2(240));
/

EXIT; 