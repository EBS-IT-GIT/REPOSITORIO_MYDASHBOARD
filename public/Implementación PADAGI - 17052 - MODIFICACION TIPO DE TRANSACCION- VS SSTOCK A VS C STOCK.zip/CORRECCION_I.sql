UPDATE apps.ra_customer_trx_all rct
SET    cust_trx_type_id = 147327, last_updated_by = 2070, last_update_date = sysdate
WHERE  trx_number IN ('B-0037-00000212', 'B-0037-00000213', 'B-0037-00000216', 'B-0037-00000217', 'B-0037-00000226');
--5 Registros