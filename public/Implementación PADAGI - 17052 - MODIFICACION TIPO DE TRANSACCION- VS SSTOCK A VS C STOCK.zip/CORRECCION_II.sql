UPDATE apps.ra_customer_trx_lines_all rct
SET    interface_line_attribute4 = DECODE(customer_trx_id,
              15199374, '0005-00005129',
              15199375, '0005-00005130',
              15255452, '0005-00005132',
              15255454, '0005-00005133',
              15279421, '0005-00005137',
              interface_line_attribute4),
       interface_line_attribute3 = DECODE(customer_trx_id,
              15199374, 81011183,
              15199375, 81011187,
              15255452, 81020197,
              15255454, 81042175,
              15279421, 81054233,
              interface_line_attribute3), last_updated_by = 2070, last_update_date = sysdate
WHERE  line_type = 'LINE'
AND    customer_trx_id IN (SELECT customer_trx_id
                           FROM   apps.ra_customer_trx_all rct
                           WHERE  trx_number IN ('B-0037-00000212', 'B-0037-00000213', 
                                                 'B-0037-00000216', 'B-0037-00000217', 
                                                 'B-0037-00000226'));
--5 Registros