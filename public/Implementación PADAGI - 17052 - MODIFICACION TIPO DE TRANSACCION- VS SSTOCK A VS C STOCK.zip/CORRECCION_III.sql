UPDATE apps.ra_customer_trx_all
SET    complete_flag = 'Y', last_updated_by = 2070, last_update_date = sysdate
WHERE  customer_trx_id = 15320376;
--1 Registro