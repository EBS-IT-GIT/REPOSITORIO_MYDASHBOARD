SET SERVEROUTPUT on SIZE 1000000
SET LINESIZE 500

--
-- Custom : XX AP Lineas de Distribucion
--
-- inputs parameters   p_num_org_id             NUMBER      : ID Organización
--                     p_num_proveedor          NUMBER      : ID Proveedor
--                     p_chr_tipo_proveedor     VARCHAR2    : Clasificación del proveedor
--                     p_date_contable_desde    VARCHAR2    : Fecha contable desde
--                     p_date_contable_hasta    VARCHAR2    : Fecha contable hasta
--                     p_chr_incluir_retencion  VARCHAR2    : Si/No incluir retenciones
--
--
-- Consultora     : Quanam
-- Técnico        : Sergio Romero
-- Fecha Creación : 17-FEB-2011
--
-- Fecha Mod.     : 26-JUL-2012
-- Técnico        : Ariel Petrocelli
-- Empresa        : Adecoagro
-- Descripción    : Se agregan los campos Fecha de OP y Nro de OP

-- Fecha Mod.     : 27-SEP-2012
-- Técnico        : Alejandra Silva
-- Empresa        : Adecoagro
-- Descripción    : CR475 Se agregan los campos Patente y KM de Vehiculos y los
--                  parametros de Cuenta Contable Desde y Hasta

-- Fecha Mod.     : 25-SEP-2012
-- Técnico        : Santiago Banchieri
-- Empresa        : Adecoagro
-- Descripción    : CR1522
                    -- Se modifica la lógica del campo Cuenta
                    -- No se traen los pagos revertidos
                    -- Se incluyen las líneas con contexto incompleto

-- Fecha Mod.     : 29-AUG-2017
-- Técnico        : Junio Vitor
-- Empresa        : TRI CS / IT Convergence
-- Descripción    : Alteracoes Projeto Upgrade R12:
--                  - Eliminación de usuarios de las tablas core/custom.
--                  - Cambios de tablas/vistas obsoletas por las correspondientes en la R12

DECLARE

  -- Parámetros
  p_num_org_id               NUMBER:='&1';
  p_num_proveedor            NUMBER:='&2';
  p_chr_tipo_proveedor       po_lookup_codes.lookup_code%TYPE:='&3';
  p_date_contable_desde      VARCHAR2(40):='&4';
  p_date_contable_hasta      VARCHAR2(40):='&5';
  p_chr_incluir_retencion    VARCHAR2(20):='&6';
  p_cta_desde                VARCHAR2(20):='&7'; -- Segmento cuenta contable desde
  p_cta_hasta                VARCHAR2(20):='&8'; -- Segmento cuenta contable hasta

  CURSOR facturas IS
   SELECT invoice_id,
          ap_invoices_pkg.get_approval_status(ai.invoice_id,
                                              ai.invoice_amount,
                                              ai.payment_status_flag,
                                              ai.invoice_type_lookup_code) Estado_Factura,
          (SELECT NVL(aidfv.Xx_ap_libro_iva_distribucion, 'N')
             FROM ap_invoices_all_dfv aidfv
            WHERE ai.rowid = aidfv.row_id) fondo_fijo,
          aiad.XX_AP_LIBRO_IVA_DISTRIBUCION,
          pv.vendor_type_lookup_code clasif
     FROM ap_invoices_all ai,
          -- po_vendors       pv, -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
          ap_suppliers        pv, -- Upgrade R12 - ITC BR | 22/08/2017 | JVP
          AP_INVOICES_ALL_DFV aiad
    WHERE org_id = p_num_org_id
      AND ai.rowid = aiad.row_id
      AND TRUNC(gl_date) BETWEEN
          TRUNC(TO_DATE(p_date_contable_desde, 'RRRR/MM/DD HH24:MI:SS')) AND
          TRUNC(TO_DATE(p_date_contable_hasta, 'RRRR/MM/DD HH24:MI:SS'))
      AND ai.vendor_id = NVL(p_num_proveedor, ai.vendor_id)
      AND ai.vendor_id = pv.vendor_id
      AND NVL(pv.vendor_type_lookup_code, ' ') =
          NVL(p_chr_tipo_proveedor, NVL(pv.vendor_type_lookup_code, ' '));

  CURSOR c_anticipos(p_invoice_id NUMBER) IS
    SELECT distinct AP_INVOICES_UTILITY_PKG.GET_PREPAY_NUMBER(AID.PREPAY_DISTRIBUTION_ID) anticipo
      FROM ap_invoice_distributions_all AID
         , AP_INVOICES_ALL AI
     WHERE AI.INVOICE_ID = AID.INVOICE_ID
       AND LINE_TYPE_LOOKUP_CODE = 'PREPAY'
       AND AI.INVOICE_ID = p_invoice_id;

  CURSOR main ( p_num_invoice_id  NUMBER) IS
   /*SELECT ai.invoice_type_lookup_code Tipo_Factura,
          pv.vendor_name Proveedor,
          ai.invoice_num Numero_Factura,
          ai.invoice_amount Total_Factura,
          ai.gl_date Fecha_Contable,
          aid.accounting_date Fecha_Contable_distri,
          aip.check_date Fecha_OP,
          aip.voucher_num Numero_OP,
          DECODE(ap_invoices_pkg.get_posting_status(ai.invoice_id),
                 'Y',
                 'Si',
                 'N',
                 'No',
                 'No') Contabilizado,
          ai.amount_paid Importe_Pagado,
          ap_invoices_pkg.get_amount_withheld(ai.invoice_id) Importe_Retenido,
          aid.distribution_line_number Linea_de_Distribucion,
          (SELECT alc.displayed_field
             FROM ap_lookup_codes alc
            WHERE alc.lookup_type = 'INVOICE DISTRIBUTION TYPE'
              AND alc.lookup_code = aid.line_type_lookup_code) tipo_de_linea,
          aid.amount importe,
          atc.name Codigo_Impuesto,
          -- Inicio Modificado CR1522
          -- gcc.segment1||'-'||gcc.segment2||'-'||gcc.segment3||'-'||gcc.segment4||'-'||
          -- gcc.segment4||'-'||gcc.segment5||'-'||gcc.segment6||'-'||gcc.segment7  Cuenta,
          CASE NVL(aidv.po_number, 'Y')
             WHEN 'Y' THEN
              gcc.concatenated_segments
             ELSE
              gcc2.concatenated_segments
          END AS Cuenta,
          -- Fin Modificado CR1522
          xx_aco_cartas_porte_pk.Devolver_descrip_provincia(aid_dfv.xx_ap_origen_prod) Origen_Produccion,
          (SELECT numero_carta_porte
             FROM xx_aco_cartas_porte_b
            WHERE carta_porte_id = TO_NUMBER(aid_dfv.xx_aco_carta_porte)
              AND ROWNUM = 1) Carta_de_Porte_Transportista,
          aid_dfv.xx_aco_cp_liquidacion Carta_de_Porte_Liquidacion,
          decode(aid_dfv.XX_AP_INVOICE_DATE,
                 null,
                 null,
                 to_char(aid_dfv.XX_AP_INVOICE_DATE, 'dd/mm/yyyy')) XX_AP_INVOICE_DATE,
          (SELECT location_code
             FROM hr_locations
            WHERE location_id = aid.global_attribute3) Direccion_de_Envio,
          DECODE(aid.reversal_flag, 'Y', 'Si', 'No') flag_reversado,
          SUBSTR(jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aid_dfv.xx_ap_invoice_num), -- Upgrade R12 - Guilherme Marques - IT Convergence - 01/11/2017
                 1,
                 4) || '-' || SUBSTR(jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aid_dfv.xx_ap_invoice_num), -- Upgrade R12 - Guilherme Marques - IT Convergence - 01/11/2017
                                     17,
                                     8) xx_ap_invoice_num,
          (SELECT vendor_name
             FROM -- po_vendors -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
                  ap_suppliers -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
            WHERE vendor_id = to_number(aid_dfv.xx_ap_vendor_id)) xx_ap_vendor_name,
          DECODE((SELECT xx_trx_type_percep_iibb_iva
                   FROM fnd_lookups fl, fnd_lookup_values_dfv fl_dfv
                  WHERE fl.lookup_type = 'JLAR_LEGAL_TRX_CATEGORY'
                    AND NVL(fl.start_date_active, SYSDATE) <= SYSDATE
                    AND NVL(fl.end_date_active, SYSDATE) >= SYSDATE
                    AND fl.enabled_flag = 'Y'
                    AND fl.rowid = fl_dfv.row_id
                    AND lookup_code = 'FC BIENES'),
                 'F',
                 'STANDARD',
                 'C',
                 'CREDIT',
                 'D',
                 'DEBIT',
                 'OTROS') xx_ap_tipo_trans,
          (SELECT DESCRIPTION
             FROM FND_LOOKUP_VALUES_VL
            WHERE lookup_type = 'JLAR_LEGAL_TRX_CATEGORY'
              AND NVL(start_date_active, SYSDATE) <= SYSDATE
              AND NVL(end_date_active, SYSDATE) >= SYSDATE
              AND enabled_flag = 'Y'
              AND LOOKUP_CODE NOT LIKE 'AN%'
              AND LOOKUP_CODE = aid_dfv.XX_AP_LEGAL_TRANS_CATEGORY) xx_jlar_legal_trx_cate,
          (SELECT DESCRIPTION
             FROM FND_LOOKUP_VALUES_VL
            WHERE lookup_type = 'JLAR_DOCUMENT_LETTER'
              AND NVL(start_date_active, SYSDATE) <= SYSDATE
              AND NVL(end_date_active, SYSDATE) >= SYSDATE
              AND enabled_flag = 'Y'
              AND LOOKUP_CODE = aid_dfv.XX_AP_TRANSACTION_LETTER) xx_jlar_legal_trx_letter,
          SUBSTR(TRIM(aid_dfv.xx_ap_patente_vehiculo), 1, 7) patente,
          aid_dfv.xx_ap_km_vehiculo km_vehiculo,
          aidv.po_number numero_OC,
          ai.description descripcion,
          aidv.description desc_dist
     FROM (SELECT * FROM ap_invoices_all WHERE invoice_id = p_num_invoice_id) ai,
          (SELECT *
             FROM ap_invoice_distributions_all
            WHERE org_id = p_num_org_id) aid,
          (SELECT ac.check_date,
                  ac.doc_sequence_value voucher_num,
                  ai.invoice_id
             FROM ap_invoice_payments_ALL aip, -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
                  ap_invoices_ALL ai,          -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
                  ap_checks_ALL           ac   -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
            WHERE aip.invoice_id = ai.invoice_id
              AND aip.check_id = ac.check_id
                 -- Inicio Agregado CR1522
              AND NVL(aip.reversal_flag, 'N') != 'Y'
                 -- Fin Agregado CR1522
              AND ai.invoice_id = p_num_invoice_id) aip,
          --po_vendors
          ap_suppliers     pv, -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
          ap_tax_codes_all atc,
          -- Inicio Modificado CR1522
          -- gl_code_combinations            gcc,
          gl_code_combinations_kfv gcc,
          -- Fin Modificado CR1522
          ap_invoice_distributions_a_dfv aid_dfv,
          (SELECT *
             FROM ap_invoice_distributions_v
            WHERE org_id = p_num_org_id) aidv,
          -- Inicio Modificado CR1522
          -- gl_code_combinations            gcc2
          gl_code_combinations_kfv gcc2
   -- Fin Modificado CR1522
    WHERE ai.invoice_id = aid.invoice_id
      AND ai.invoice_id = aip.invoice_id(+)
      AND ai.vendor_id = pv.vendor_id
      AND aid.tax_code_id = atc.tax_id(+)
      AND aid.dist_code_combination_id = gcc.code_combination_id
      AND aid.rowid = aid_dfv.row_id
         -- Inicio Modificado CR1522
         -- AND aid_dfv.context = 'AR'
      AND NVL(aid_dfv.context, 'AR') = 'AR'
         -- Fin Modificado CR1522
      AND aid.amount <> 0
         --
      --AND aid.invoice_id = aidv.invoice_id -- Upgrade R12 - Guilherme Marques - IT Convergence - 01/11/2017
      --AND aidv.distribution_line_number = aid.distribution_line_number -- Upgrade R12 - Guilherme Marques - IT Convergence - 01/11/2017

      AND aidv.invoice_distribution_id = aid.invoice_distribution_id -- Upgrade R12 - Guilherme Marques - IT Convergence - 01/11/2017
      AND aidv.po_code_combination_id = gcc2.code_combination_id(+)
         --
         -- Parámetros
      AND (p_chr_incluir_retencion = 'Y' OR
          (p_chr_incluir_retencion = 'N' AND
          aid.line_type_lookup_code <> 'AWT'))
      AND (gcc.segment2 BETWEEN NVL(p_cta_desde, gcc.segment2) AND
          NVL(p_cta_hasta, gcc.segment2) OR
          gcc2.segment2 BETWEEN NVL(p_cta_desde, gcc2.segment2) AND
          NVL(p_cta_hasta, gcc2.segment2))
    ORDER BY pv.vendor_name, ai.invoice_num, aid.distribution_line_number;*/
    -- Start Upgrade R12.2 - Guilherme Marques - IT Convergence - 30/11/2017
    SELECT ai.invoice_type_lookup_code tipo_factura
          ,aps.vendor_name             proveedor
          ,ai.invoice_num              numero_factura
          ,ai.invoice_amount           total_factura
          ,ai.gl_date                  fecha_contable
          ,aila.accounting_date         fecha_contable_distri
          ,ac.check_date               fecha_op
          ,ac.doc_sequence_value       numero_op
          ,DECODE( ap_invoices_pkg.get_posting_status(ai.invoice_id)
                  ,'Y','Si'
                  ,'N','No'
                  ,'No')               contabilizado
          ,ai.amount_paid              importe_pagado
          ,ap_invoices_pkg.get_amount_withheld(ai.invoice_id) importe_retenido
          ,aida.distribution_line_number     linea_de_distribucion
          ,aida.invoice_line_number          linea_de_factura
          ,flv.meaning  tipo_de_linea
          ,aida.amount  importe
          --,atc.name codigo_impuesto
          ,NVL(atc.tax_code
              ,DECODE(aila.line_type_lookup_code, 'TAX', aila.tax_rate_code, aila.tax_classification_code)
              ) codigo_impuesto --R12
          ,gcc.concatenated_segments cuenta
          ,xx_aco_cartas_porte_pk.Devolver_descrip_provincia(aida.attribute7) origen_produccion
          ,xacpb.numero_carta_porte    carta_de_porte_transportista
          ,aida.attribute8             carta_de_porte_liquidacion
          ,TO_CHAR(TO_DATE(aida.attribute6, 'YYYY/MM/DD HH24:MI:SS'),'dd/mm/yyyy')  xx_ap_invoice_date
          ,hl.location_code direccion_de_envio
          ,DECODE(aida.reversal_flag, 'Y', 'Si', 'No') flag_reversado
          ,SUBSTR(jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aida.attribute4)
                  ,1
                  ,4) || '-' ||
                  SUBSTR( jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aida.attribute4)
                         ,17
                         ,8) xx_ap_invoice_num
          ,aps2.vendor_name xx_ap_vendor_name
          ,decode( flv2.attribute10
                  ,'F'
                  ,'STANDARD'
                  ,'C'
                  ,'CREDIT'
                  ,'D'
                  ,'DEBIT'
                  ,'OTROS') xx_ap_tipo_trans
          ,CASE WHEN ai_dfv.xx_ap_libro_iva_distribucion = 'Y' THEN aida_dfv.xx_ap_legal_trans_category ELSE flv3.description END trx_category  --TK1859
          ,CASE WHEN ai_dfv.xx_ap_libro_iva_distribucion = 'Y' THEN aida_dfv.xx_ap_transaction_letter ELSE flv4.description END trx_letter  --TK1859
          ,flv3.description xx_jlar_legal_trx_cate
          ,flv4.description xx_jlar_legal_trx_letter
          ,aida_dfv.xx_ap_legal_trans_category  --TK1859
          ,aida_dfv.xx_ap_transaction_letter  --TK1859
          ,SUBSTR(TRIM(aida.attribute12), 1, 7) patente
          ,aida.attribute13                     km_vehiculo
          ,/*NVL(pha.clm_document_number, pha.segment1)*/NULL numero_oc
          ,ai.description                       descripcion
          ,aida.description                     desc_dist
    FROM ap_invoices_all              ai
        ,ap_invoices_all_dfv          ai_dfv  --TK1859
		,ap_invoices_all2_dfv         ai_dfv2
        ,ap_invoice_lines_all         aila
        ,ap_invoice_distributions_all aida
		,ap_invoice_distributions_a_dfv aida_dfv  --TK1859
        ,ap_suppliers                 aps
        ,ap_suppliers                 aps2
        ,ap_invoice_payments_all      aip
        ,ap_checks_all                ac
        --,ap_tax_codes_all             atc
        ,xx_zx_tax_codes_v            atc --R12
        ,gl_code_combinations_kfv     gcc
        --,po_distributions_all         pda
        --,po_headers_all               pha
        ,hr_locations                 hl
        ,xx_aco_cartas_porte_b        xacpb
        --
        ,fnd_lookup_values            flv
        ,fnd_lookup_values            flv2
        ,fnd_lookup_values            flv3
        ,fnd_lookup_values            flv4
  --SLA:start
        ,xla.xla_transaction_entities xte
        ,xla_events             xev
        ,xla_ae_headers         xah
        ,xla_ae_lines           xal
        ,xla_distribution_links xdl
    --SLA:end
    WHERE 1=1
    AND ai_dfv.row_id               = ai.rowid  --TK1859
	AND ai_dfv2.row_id              = ai.rowid
    AND ai_dfv2.context_value       = ai.global_attribute_category
    AND ai.invoice_id               = p_num_invoice_id
    AND ai.org_id                   = p_num_org_id
    AND ai.vendor_id                = aps.vendor_id
    AND aip.invoice_id    (+)       = ai.invoice_id
    AND ai.invoice_id               = aila.invoice_id
    AND aip.check_id                = ac.check_id (+)
    AND aida.invoice_id             = ai.invoice_id
	AND aida_dfv.row_id             = aida.rowid  --TK1859
    AND aida.invoice_line_number    = aila.line_number
    AND NVL(aip.reversal_flag, 'N') != 'Y'
    AND aida.tax_code_id            = atc.tax_id(+)
    AND aida.org_id                 = atc.org_id(+)
    AND NVL(atc.tax_class(+), 'INPUT') = 'INPUT'
    AND aida.amount                 <> 0
   /*AND aida.po_distribution_id     = pda.po_distribution_id (+)
   AND ((NVL(to_char(aila.po_header_id), 'Y') = 'Y' AND aida.dist_code_combination_id = gcc.code_combination_id)
    OR (NVL(to_char(aila.po_header_id), 'Y') <> 'Y' AND pda.code_combination_id = gcc.code_combination_id))*/
    AND aida.po_distribution_id    IS NULL
    AND xacpb.carta_porte_id (+)    = TO_NUMBER(aida.attribute10)
    AND hl.location_id (+)          = aida.global_attribute3
    AND aps2.vendor_id (+)          = aida.attribute5
    --AND pda.po_header_id            = pha.po_header_id (+)
    AND NVL(aida.attribute_category, 'AR') = 'AR'
    AND (aida.line_type_lookup_code <> 'AWT')
    AND gcc.segment2 BETWEEN NVL(p_cta_desde, gcc.segment2) AND NVL(p_cta_hasta, gcc.segment2)
    --
    AND flv.lookup_type             = 'INVOICE LINE TYPE'
    AND flv.language                = USERENV('LANG')
    AND flv.lookup_code             = aila.line_type_lookup_code
    --
    AND flv2.lookup_type            = 'JLAR_LEGAL_TRX_CATEGORY'
    AND NVL(flv2.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv2.end_date_active, SYSDATE)   >= SYSDATE
    AND flv2.enabled_flag           = 'Y'
    AND flv2.lookup_code            = 'FC BIENES'
    AND flv2.language               = USERENV('LANG')
    --
    AND flv3.lookup_type     (+)    = 'JLAR_LEGAL_TRX_CATEGORY'
    AND NVL(flv3.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv3.end_date_active, SYSDATE)   >= SYSDATE
    AND flv3.enabled_flag    (+)    = 'Y'
    AND flv3.lookup_code     (+)    NOT LIKE 'AN%'
    AND flv3.lookup_code     (+)    = ai_dfv2.legal_transaction_category --aida.attribute2 TK1859
    AND flv3.language        (+)    = USERENV('LANG')
    --
    AND flv4.lookup_type     (+)    = 'JLAR_DOCUMENT_LETTER'
    AND NVL(flv4.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv4.end_date_active, SYSDATE)   >= SYSDATE
    AND flv4.enabled_flag    (+)    = 'Y'
    AND flv4.lookup_code     (+)    NOT LIKE 'AN%'
    AND flv4.lookup_code     (+)    = ai_dfv2.transaction_letter --aida.attribute3 TK1859
    AND flv4.language        (+)    = USERENV('LANG')
    --SLA:start
    and    xte.entity_code       = 'AP_INVOICES'
    and    xte.application_id    = 200
    --and    nvl(xte.source_id_int_1,(-99)) = ai.invoice_id
    and    xev.entity_id         = xte.entity_id
    and    xev.application_id    = 200
    and    xah.application_id    = 200
    and    xah.event_id          = xev.event_id
    and    xal.application_id    = 200
    and    xal.ae_header_id      = xah.ae_header_id
    and    xal.accounting_class_code <> 'LIABILITY'
    and    xdl.application_id    = 200
    and    xdl.ae_header_id      = xal.ae_header_id
    and    xdl.ae_line_num       = xal.ae_line_num
    and    xdl.source_distribution_type     = 'AP_INV_DIST'
    and    xdl.source_distribution_id_num_1 = aida.invoice_distribution_id
    and    nvl(xdl.source_distribution_id_num_2,(-99)) = (-99)
    and    xal.code_combination_id          = gcc.code_combination_id
    --SLA:end
    UNION -- retenciones
    SELECT ai.invoice_type_lookup_code tipo_factura
          ,aps.vendor_name             proveedor
          ,ai.invoice_num              numero_factura
          ,ai.invoice_amount           total_factura
          ,ai.gl_date                  fecha_contable
          ,aila.accounting_date         fecha_contable_distri
          ,ac.check_date               fecha_op
          ,ac.doc_sequence_value       numero_op
          ,DECODE( ap_invoices_pkg.get_posting_status(ai.invoice_id)
                  ,'Y','Si'
                  ,'N','No'
                  ,'No')               contabilizado
          ,ai.amount_paid              importe_pagado
          ,ap_invoices_pkg.get_amount_withheld(ai.invoice_id) importe_retenido
          ,aida.distribution_line_number     linea_de_distribucion
          ,aida.invoice_line_number          linea_de_factura
          ,flv.meaning  tipo_de_linea
          ,aida.amount  importe
          ,atc.name codigo_impuesto
          ,gcc.concatenated_segments cuenta
          ,xx_aco_cartas_porte_pk.Devolver_descrip_provincia(aida.attribute7) origen_produccion
          ,xacpb.numero_carta_porte    carta_de_porte_transportista
          ,aida.attribute8             carta_de_porte_liquidacion
          ,TO_CHAR(TO_DATE(aida.attribute6, 'YYYY/MM/DD HH24:MI:SS'),'dd/mm/yyyy')  xx_ap_invoice_date
          ,hl.location_code direccion_de_envio
          ,DECODE(aida.reversal_flag, 'Y', 'Si', 'No') flag_reversado
          ,SUBSTR(jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aida.attribute4)
                  ,1
                  ,4) || '-' ||
                  SUBSTR( jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aida.attribute4)
                         ,17
                         ,8) xx_ap_invoice_num
          ,aps2.vendor_name xx_ap_vendor_name
          ,decode( flv2.attribute10
                  ,'F'
                  ,'STANDARD'
                  ,'C'
                  ,'CREDIT'
                  ,'D'
                  ,'DEBIT'
                  ,'OTROS') xx_ap_tipo_trans
          ,CASE WHEN ai_dfv.xx_ap_libro_iva_distribucion = 'Y' THEN aida_dfv.xx_ap_legal_trans_category ELSE flv3.description END trx_category  --TK1859
          ,CASE WHEN ai_dfv.xx_ap_libro_iva_distribucion = 'Y' THEN aida_dfv.xx_ap_transaction_letter ELSE flv4.description END trx_letter  --TK1859
          ,flv3.description xx_jlar_legal_trx_cate
          ,flv4.description xx_jlar_legal_trx_letter
          ,aida_dfv.xx_ap_legal_trans_category  --TK1859
          ,aida_dfv.xx_ap_transaction_letter  --TK1859
          ,SUBSTR(TRIM(aida.attribute12), 1, 7) patente
          ,aida.attribute13                     km_vehiculo
          ,/*NVL(pha.clm_document_number, pha.segment1)*/NULL numero_oc
          ,ai.description                       descripcion
          ,aida.description                     desc_dist
    FROM ap_invoices_all              ai
        ,ap_invoices_all_dfv          ai_dfv  --TK1859
		,ap_invoices_all2_dfv         ai_dfv2
        ,ap_invoice_lines_all         aila
        ,ap_invoice_distributions_all aida
		,ap_invoice_distributions_a_dfv aida_dfv  --TK1859
        ,ap_suppliers                 aps
        ,ap_suppliers                 aps2
        ,ap_invoice_payments_all      aip
        ,ap_checks_all                ac
        ,ap_tax_codes_all             atc
        ,gl_code_combinations_kfv     gcc
        --,po_distributions_all         pda
        --,po_headers_all               pha
        ,hr_locations                 hl
        ,xx_aco_cartas_porte_b        xacpb
        --
        ,fnd_lookup_values            flv
        ,fnd_lookup_values            flv2
        ,fnd_lookup_values            flv3
        ,fnd_lookup_values            flv4
    --SLA:start
        ,ap_payment_hist_dists  apd
        ,xla.xla_transaction_entities xte
        ,xla_events             xev
        ,xla_ae_headers         xah
        ,xla_ae_lines           xal
        ,xla_distribution_links xdl
    --SLA:end
    WHERE 1=1
    AND ai_dfv.row_id               = ai.rowid  --TK1859
	AND ai_dfv2.row_id              = ai.rowid
    AND ai_dfv2.context_value       = ai.global_attribute_category
    AND ai.invoice_id               = p_num_invoice_id
    AND ai.org_id                   = p_num_org_id
    AND ai.vendor_id                = aps.vendor_id
    AND aip.invoice_id    (+)       = ai.invoice_id
    AND ai.invoice_id               = aila.invoice_id
    AND aip.check_id                = ac.check_id (+)
    AND aida.invoice_id             = ai.invoice_id
	AND aida_dfv.row_id             = aida.rowid  --TK1859
    AND aida.invoice_line_number    = aila.line_number
    AND NVL(aip.reversal_flag, 'N') != 'Y'
    AND aida.withholding_tax_code_id = atc.tax_id(+)
    AND aida.amount                 <> 0
    /*AND aida.po_distribution_id     = pda.po_distribution_id (+)
    AND ((NVL(to_char(aila.po_header_id), 'Y') = 'Y' AND aida.dist_code_combination_id = gcc.code_combination_id)
     OR (NVL(to_char(aila.po_header_id), 'Y') <> 'Y' AND pda.code_combination_id = gcc.code_combination_id))*/
    AND aida.po_distribution_id    IS NULL
    AND xacpb.carta_porte_id (+)    = TO_NUMBER(aida.attribute10)
    AND hl.location_id (+)          = aida.global_attribute3
    AND aps2.vendor_id (+)          = aida.attribute5
    --AND pda.po_header_id            = pha.po_header_id (+)
    AND NVL(aida.attribute_category, 'AR') = 'AR'
    AND (p_chr_incluir_retencion = 'Y' AND
         aida.line_type_lookup_code = 'AWT')
    AND gcc.segment2 BETWEEN NVL(p_cta_desde, gcc.segment2) AND NVL(p_cta_hasta, gcc.segment2)
    --
    AND flv.lookup_type             = 'INVOICE LINE TYPE'
    AND flv.language                = USERENV('LANG')
    AND flv.lookup_code             = aila.line_type_lookup_code
    --
    AND flv2.lookup_type            = 'JLAR_LEGAL_TRX_CATEGORY'
    AND NVL(flv2.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv2.end_date_active, SYSDATE)   >= SYSDATE
    AND flv2.enabled_flag           = 'Y'
    AND flv2.lookup_code            = 'FC BIENES'
    AND flv2.language               = USERENV('LANG')
    --
    AND flv3.lookup_type     (+)    = 'JLAR_LEGAL_TRX_CATEGORY'
    AND NVL(flv3.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv3.end_date_active, SYSDATE)   >= SYSDATE
    AND flv3.enabled_flag    (+)    = 'Y'
    AND flv3.lookup_code     (+)    NOT LIKE 'AN%'
    AND flv3.lookup_code     (+)    = ai_dfv2.legal_transaction_category --aida.attribute2 TK1859
    AND flv3.language        (+)    = USERENV('LANG')
    --
    AND flv4.lookup_type     (+)    = 'JLAR_DOCUMENT_LETTER'
    AND NVL(flv4.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv4.end_date_active, SYSDATE)   >= SYSDATE
    AND flv4.enabled_flag    (+)    = 'Y'
    AND flv4.lookup_code     (+)    NOT LIKE 'AN%'
    AND flv4.lookup_code     (+)    = ai_dfv2.transaction_letter --aida.attribute3 TK1859
    AND flv4.language        (+)    = USERENV('LANG')
    --SLA:start
    and    xte.entity_code       = 'AP_PAYMENTS'
    and    xte.application_id    = 200
    --and    nvl(xte.source_id_int_1,(-99)) = ai.invoice_id
    and    xev.entity_id         = xte.entity_id
    and    xev.application_id    = 200
    and    xah.application_id    = 200
    and    xah.event_id          = xev.event_id
    and    xal.application_id    = 200
    and    xal.ae_header_id      = xah.ae_header_id
    and    xal.accounting_class_code <> 'LIABILITY'
    and    xdl.application_id    = 200
    and    xdl.ae_header_id      = xal.ae_header_id
    and    xdl.ae_line_num       = xal.ae_line_num
    and    xdl.source_distribution_type     = 'AP_PMT_DIST'
    and    xdl.source_distribution_id_num_1 = apd.payment_hist_dist_id
    and    nvl(xdl.source_distribution_id_num_2,(-99)) = (-99)
    and    xal.code_combination_id          = gcc.code_combination_id
    and    apd.invoice_distribution_id = aida.invoice_distribution_id
    --SLA:end
    UNION -- no contabilizadas
    SELECT ai.invoice_type_lookup_code tipo_factura
          ,aps.vendor_name             proveedor
          ,ai.invoice_num              numero_factura
          ,ai.invoice_amount           total_factura
          ,ai.gl_date                  fecha_contable
          ,aila.accounting_date         fecha_contable_distri
          ,ac.check_date               fecha_op
          ,ac.doc_sequence_value       numero_op
          ,DECODE( ap_invoices_pkg.get_posting_status(ai.invoice_id)
                  ,'Y','Si'
                  ,'N','No'
                  ,'No')               contabilizado
          ,ai.amount_paid              importe_pagado
          ,ap_invoices_pkg.get_amount_withheld(ai.invoice_id) importe_retenido
          ,aida.distribution_line_number     linea_de_distribucion
          ,aida.invoice_line_number          linea_de_factura
          ,flv.meaning  tipo_de_linea
          ,aida.amount  importe
          --,atc.name codigo_impuesto
          ,NVL(atc.tax_code
              ,DECODE(aila.line_type_lookup_code, 'TAX', aila.tax_rate_code, aila.tax_classification_code)
              ) codigo_impuesto --R12
          ,gcc.concatenated_segments cuenta
          ,xx_aco_cartas_porte_pk.Devolver_descrip_provincia(aida.attribute7) origen_produccion
          ,xacpb.numero_carta_porte    carta_de_porte_transportista
          ,aida.attribute8             carta_de_porte_liquidacion
          ,TO_CHAR(TO_DATE(aida.attribute6, 'YYYY/MM/DD HH24:MI:SS'),'dd/mm/yyyy')  xx_ap_invoice_date
          ,hl.location_code direccion_de_envio
          ,DECODE(aida.reversal_flag, 'Y', 'Si', 'No') flag_reversado
          ,SUBSTR(jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aida.attribute4)
                  ,1
                  ,4) || '-' ||
                  SUBSTR( jl_jlarpptf_xmlp_pkg.get_formatted_docnum(aida.attribute4)
                         ,17
                         ,8) xx_ap_invoice_num
          ,aps2.vendor_name xx_ap_vendor_name
          ,decode( flv2.attribute10
                  ,'F'
                  ,'STANDARD'
                  ,'C'
                  ,'CREDIT'
                  ,'D'
                  ,'DEBIT'
                  ,'OTROS') xx_ap_tipo_trans
          ,CASE WHEN ai_dfv.xx_ap_libro_iva_distribucion = 'Y' THEN aida_dfv.xx_ap_legal_trans_category ELSE flv3.description END trx_category  --TK1859
          ,CASE WHEN ai_dfv.xx_ap_libro_iva_distribucion = 'Y' THEN aida_dfv.xx_ap_transaction_letter ELSE flv4.description END trx_letter  --TK1859
          ,flv3.description xx_jlar_legal_trx_cate
          ,flv4.description xx_jlar_legal_trx_letter
          ,aida_dfv.xx_ap_legal_trans_category  --TK1859
          ,aida_dfv.xx_ap_transaction_letter  --TK1859
          ,SUBSTR(TRIM(aida.attribute12), 1, 7) patente
          ,aida.attribute13                     km_vehiculo
          ,NVL(pha.clm_document_number, pha.segment1) numero_oc
          ,ai.description                       descripcion
          ,aida.description                     desc_dist
    FROM ap_invoices_all              ai
        ,ap_invoices_all_dfv          ai_dfv  --TK1859
		,ap_invoices_all2_dfv         ai_dfv2
        ,ap_invoice_lines_all         aila
        ,ap_invoice_distributions_all aida
		,ap_invoice_distributions_a_dfv aida_dfv  --TK1859
        ,ap_suppliers                 aps
        ,ap_suppliers                 aps2
        ,ap_invoice_payments_all      aip
        ,ap_checks_all                ac
        --,ap_tax_codes_all             atc
        ,xx_zx_tax_codes_v            atc --R12
        ,gl_code_combinations_kfv     gcc
        ,po_distributions_all         pda
        ,po_headers_all               pha
        ,hr_locations                 hl
        ,xx_aco_cartas_porte_b        xacpb
        --
        ,fnd_lookup_values            flv
        ,fnd_lookup_values            flv2
        ,fnd_lookup_values            flv3
        ,fnd_lookup_values            flv4
    WHERE 1=1
    AND ai_dfv.row_id               = ai.rowid  --TK1859
	AND ai_dfv2.row_id              = ai.rowid
    AND ai_dfv2.context_value       = ai.global_attribute_category
    AND ai.invoice_id               = p_num_invoice_id
    AND ai.org_id                   = p_num_org_id
    AND ai.vendor_id                = aps.vendor_id
    AND aip.invoice_id    (+)       = ai.invoice_id
    AND ai.invoice_id               = aila.invoice_id
    AND aip.check_id                = ac.check_id (+)
    AND aida.invoice_id             = ai.invoice_id
	AND aida_dfv.row_id             = aida.rowid  --TK1859
    AND aida.invoice_line_number    = aila.line_number
    AND NVL(aip.reversal_flag, 'N') != 'Y'
    AND aida.tax_code_id            = atc.tax_id(+)
    AND aida.org_id                 = atc.org_id(+)
    AND NVL(atc.tax_class(+), 'INPUT') = 'INPUT'
    AND aida.amount                 <> 0
    /*AND aida.po_distribution_id     = pda.po_distribution_id (+)
    AND ((NVL(to_char(aila.po_header_id), 'Y') = 'Y' AND aida.dist_code_combination_id = gcc.code_combination_id)
    OR (NVL(to_char(aila.po_header_id), 'Y') <> 'Y' AND pda.code_combination_id = gcc.code_combination_id))*/
    AND aida.po_distribution_id    IS NOT NULL
    AND aida.po_distribution_id     = pda.po_distribution_id
    AND pda.code_combination_id     = gcc.code_combination_id
    AND xacpb.carta_porte_id (+)    = TO_NUMBER(aida.attribute10)
    AND hl.location_id (+)          = aida.global_attribute3
    AND aps2.vendor_id (+)          = aida.attribute5
    AND pda.po_header_id            = pha.po_header_id (+)
    AND NVL(aida.attribute_category, 'AR') = 'AR'
    AND (aida.line_type_lookup_code <> 'AWT')
    AND gcc.segment2 BETWEEN NVL(p_cta_desde, gcc.segment2) AND NVL(p_cta_hasta, gcc.segment2)
    --
    AND flv.lookup_type             = 'INVOICE LINE TYPE'
    AND flv.language                = USERENV('LANG')
    AND flv.lookup_code             = aila.line_type_lookup_code
    --
    AND flv2.lookup_type            = 'JLAR_LEGAL_TRX_CATEGORY'
    AND NVL(flv2.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv2.end_date_active, SYSDATE)   >= SYSDATE
    AND flv2.enabled_flag           = 'Y'
    AND flv2.lookup_code            = 'FC BIENES'
    AND flv2.language               = USERENV('LANG')
    --
    AND flv3.lookup_type     (+)    = 'JLAR_LEGAL_TRX_CATEGORY'
    AND NVL(flv3.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv3.end_date_active, SYSDATE)   >= SYSDATE
    AND flv3.enabled_flag    (+)    = 'Y'
    AND flv3.lookup_code     (+)    NOT LIKE 'AN%'
    AND flv3.lookup_code     (+)    = ai_dfv2.legal_transaction_category --aida.attribute2 TK1859
    AND flv3.language        (+)    = USERENV('LANG')
    --
    AND flv4.lookup_type     (+)    = 'JLAR_DOCUMENT_LETTER'
    AND NVL(flv4.start_date_active, SYSDATE) <= SYSDATE
    AND NVL(flv4.end_date_active, SYSDATE)   >= SYSDATE
    AND flv4.enabled_flag    (+)    = 'Y'
    AND flv4.lookup_code     (+)    NOT LIKE 'AN%'
    AND flv4.lookup_code     (+)    = ai_dfv2.transaction_letter --aida.attribute3 TK1859
    AND flv4.language        (+)    = USERENV('LANG')
    ORDER BY proveedor
            ,numero_factura
            ,linea_de_factura;
    -- End Upgrade R12.2 - Guilherme Marques - IT Convergence - 30/11/2017

   v_chr_vendor_name      /*po_vendors*/ap_suppliers.vendor_name%TYPE; -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
   v_chr_org_name         hr_organization_units.name%TYPE;
   v_chr_estado_factura   VARCHAR2(240);
   v_chr_Tipo_Factura     ap_invoices_all.invoice_type_lookup_code%TYPE;
   v_chr_Proveedor        /*po_vendors*/ap_suppliers.vendor_name%TYPE;
   v_chr_Numero_Factura   ap_invoices_all.invoice_num%TYPE;
   l_anticipo       varchar2(240);

BEGIN

   fnd_file.put_line(fnd_file.output,'Reporte de;XX AP Lineas de Distribucion');
   fnd_file.new_line(fnd_file.output,1);
   fnd_file.put_line(fnd_file.output,'Parametros');
   fnd_file.new_line(fnd_file.output,1);

   ----------------------
   ---- Organización ----
   ----------------------
   SELECT name
     INTO v_chr_org_name
     FROM hr_organization_units
    WHERE organization_id = p_num_org_id;

   fnd_file.put_line(fnd_file.output,'Organizacion;'||v_chr_org_name);

   -------------------
   ---- Proveedor ----
   -------------------
   IF p_num_proveedor IS NOT NULL THEN
     SELECT vendor_name
       INTO v_chr_vendor_name
       FROM /*po_vendors*/ ap_suppliers  -- Upgrade R12 - ITC BR | 29/08/2017 | JVP
      WHERE vendor_id = p_num_proveedor;
   ELSE
      v_chr_vendor_name := 'No fue especificado';
   END IF;

   fnd_file.put_line(fnd_file.output,'Proveedor;'||v_chr_vendor_name);

   ---------------------------
   ---- Clasif. Proveedor ----
   ---------------------------
   IF p_chr_tipo_proveedor IS NOT NULL THEN
      fnd_file.put_line(fnd_file.output,'Tipo de Proveedor;'||p_chr_tipo_proveedor);
   ELSE
      fnd_file.put_line(fnd_file.output,'Tipo de Proveedor;No fue especificado');
   END IF;

   ------------------------------------
   ---- Fecha Contable Desde/Hasta ----
   ------------------------------------
   fnd_file.put_line(fnd_file.output,'Fecha contable desde;'||TO_CHAR(TO_DATE(p_date_contable_desde,'RRRR/MM/DD HH24:MI:SS'),'DD-MON-YYYY'));
   fnd_file.put_line(fnd_file.output,'Fecha contable Hasta;'||TO_CHAR(TO_DATE(p_date_contable_hasta,'RRRR/MM/DD HH24:MI:SS'),'DD-MON-YYYY'));

   -----------------------------------
   ---- Si/No incluir retenciones ----
   -----------------------------------
   IF p_chr_incluir_retencion = 'Y' THEN
      fnd_file.put_line(fnd_file.output,'Incluir Retenciones;Si');
   ELSE
      fnd_file.put_line(fnd_file.output,'Incluir Retenciones;No');
   END IF;

   ---------------------------
   ---- Cuentas Contables ----
   ---------------------------
   IF p_cta_desde IS NOT NULL THEN
      fnd_file.put_line(fnd_file.output,'Cuenta Contable Desde;'||p_cta_desde);
   ELSE
      fnd_file.put_line(fnd_file.output,'Cuenta Contable Desde;No fue especificada');
   END IF;


   IF p_cta_hasta IS NOT NULL THEN
      fnd_file.put_line(fnd_file.output,'Cuenta Contable Hasta;'||p_cta_hasta);
   ELSE
      fnd_file.put_line(fnd_file.output,'Cuenta Contable Hasta;No fue especificada');
   END IF;


   -- Encabezado
   fnd_file.new_line(fnd_file.output,1);
   fnd_file.put_line(fnd_file.output,'Tipo Factura;'                       ||
                                     'Proveedor;'                          ||
                                     'Clasificacion Proveedor;'            ||
                                     'Numero Factura;'                     ||
                                     'Libro Iva Compras Por Distribucion;' ||
                                     'Total Factura;'                      ||
                                     'Fecha Contable Cabecera;'            ||
                                     'Fecha Contable Distribucion;'        ||
                                     'Fecha de OP;'                        ||
                                     'Numero de OP;'                       ||
                                     'Estado Factura;'                     ||
                                     'Contabilizado;'                      ||
                                     'Importe Pagado;'                     ||
                                     'Importe Retenido;'                   ||
                                     'Descripcion Cabecera;'               ||
                                     'Linea de Factura;'                   ||
                                     'Linea de Distribucion;'              ||
                                     'Tipo de Linea;'                      ||
                                     'Importe;'                            ||
                                     'Codigo Impuesto;'                    ||
                                     'Cuenta;'                             ||
                                     'Numero Anticipo Aplicado;'           ||
                                     'Descripcion Distribucion;'           ||
                                     'Categoria Transaccion Legal;'        ||
                                     'Letra de Transaccion;'               ||
                                     'Numero de Factura Por Distribucion;' ||
                                     'Proveedor Por Distribucion;'         ||
                                     'Fecha de Factura Por Distribucion;'  ||
                                     'Patente de Vehiculo;'                ||
                                     'Km de Vehiculo;'                     ||
                                     'Origen Produccion;'                  ||
                                     'Carta de Porte Transportista;'       ||
                                     'Carta de Porte Liquidacion;'         ||
                                     'Direccion de Envio;'                 ||
                                     'Flag de reversado;'                  ||
                                     'Numero de OC;'


         );


   FOR cur_fact IN facturas LOOP
      -- Estado de la factura
      v_chr_estado_factura := NULL;

      BEGIN
        SELECT displayed_field
        INTO v_chr_estado_factura
        FROM
            (
        SELECT displayed_field
                   FROM ap_lookup_codes
                  WHERE lookup_type  = 'NLS TRANSLATION'
                    AND enabled_flag = 'Y'
                    AND lookup_code  = cur_fact.Estado_Factura
              UNION ALL
                 SELECT displayed_field
                   FROM ap_lookup_codes
                  WHERE lookup_type  = 'AP_WFAPPROVAL_STATUS'
                    AND enabled_flag = 'Y'
                    AND lookup_code  = cur_fact.Estado_Factura
              UNION ALL
                 SELECT displayed_field
                   FROM ap_lookup_codes
                  WHERE lookup_type  = 'PREPAY STATUS'
                    AND enabled_flag = 'Y'
                    AND lookup_code  = cur_fact.Estado_Factura
                  )
         WHERE ROWNUM=1;
       EXCEPTION
        WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Error Obteniendo Estado Factura:'||sqlerrm);
             v_chr_estado_factura := NULL;
       END;

     l_anticipo :=NULL;
     
     FOR l_anticipos IN c_anticipos(cur_fact.invoice_id ) LOOP
       IF l_anticipo IS NULL THEN
         l_anticipo := l_anticipos.anticipo;
       ELSE
         l_anticipo := l_anticipos.anticipo||'-'||l_anticipo;
       END IF;
     END LOOP;

     FOR cur IN MAIN(cur_fact.invoice_id ) LOOP
         -- Lógica para fondo fijo
        v_chr_Tipo_Factura   := NULL;
        v_chr_Proveedor      := NULL;
        v_chr_Numero_Factura := NULL;

        /*
        IF cur_fact.fondo_fijo = 'Y' AND cur.xx_ap_vendor_name IS NOT NULL
        THEN
           v_chr_Tipo_Factura   := cur.xx_ap_tipo_trans;
             v_chr_Proveedor      := cur.xx_ap_vendor_name;
             v_chr_Numero_Factura := cur.xx_ap_invoice_num;
        ELSE
        */
          v_chr_Tipo_Factura   := cur.tipo_factura;
          v_chr_Proveedor      := cur.proveedor;
          v_chr_Numero_Factura := cur.numero_factura;
        -- END IF;

        fnd_file.put_line(fnd_file.output,v_chr_Tipo_Factura                    ||';'||
                                          v_chr_Proveedor                       ||';'||
                                          cur_fact.clasif                       ||';'||
                                          v_chr_Numero_Factura                  ||';'||
                                          cur_fact.xx_ap_libro_iva_distribucion ||';'||
                                          cur.total_factura                     ||';'||
                                          cur.fecha_contable                    ||';'||
                                          cur.fecha_contable_distri             ||';'||
                                          cur.fecha_op                          ||';'||
                                          cur.numero_op                         ||';'||
                                          v_chr_estado_factura                  ||';'||
                                          cur.contabilizado                     ||';'||
                                          cur.importe_pagado                    ||';'||
                                          cur.importe_retenido                  ||';'||
                                          cur.descripcion                       ||';'||
                                          cur.linea_de_factura                  ||';'||
                                          cur.linea_de_distribucion             ||';'||
                                          cur.tipo_de_linea                     ||';'||
                                          cur.importe                           ||';'||
                                          cur.codigo_impuesto                   ||';'||
                                          cur.cuenta                            ||';'||
                                          l_anticipo                            ||';'||
                                          cur.desc_dist                         ||';'||
                                          cur.trx_category                      ||';'||
                                          cur.trx_letter                        ||';'||
                                          cur.xx_ap_invoice_num                 ||';'||
                                          cur.xx_ap_vendor_name                 ||';'||
                                          cur.xx_ap_invoice_date                ||';'||
                                          cur.patente                           ||';'||
                                          cur.km_vehiculo                       ||';'||
                                          cur.origen_produccion                 ||';'||
                                          cur.carta_de_porte_transportista      ||';'||
                                          cur.carta_de_porte_liquidacion        ||';'||
                                          cur.direccion_de_envio                ||';'||
                                          cur.flag_reversado                    ||';'||
                                          cur.numero_oc                         ||';');
     END LOOP;
   END LOOP;

EXCEPTION
WHEN OTHERS THEN
   fnd_file.put_line(fnd_file.output,'Error XX AP Lineas de Distribucion : '||SUBSTR(SQLERRM,1,100));
END;
/
