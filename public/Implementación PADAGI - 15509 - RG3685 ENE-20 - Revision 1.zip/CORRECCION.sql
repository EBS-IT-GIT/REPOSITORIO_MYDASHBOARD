UPDATE apps.ap_invoices_all ai
SET    global_attribute12 = 'Y', global_attribute13 = '99', global_attribute11 = 'FC INTERNA'
WHERE  ai.invoice_num IN ('0029-00000024', '0003-00034673');
--2 Registros