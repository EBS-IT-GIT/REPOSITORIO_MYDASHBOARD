==============================================================================
CUSAP051_001 : Criacao concurrent retencao no AP de Reversao proveniente do RI
==============================================================================

Atualiza��o - CUSAP051_001
Produto     - XX Customizaciones
Data        - 07/08/2020 08:00:53
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSAP051_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_AP_CUSTOM_UTIL_PKS.pls
                               SAE_AP_CUSTOM_UTIL_PKB.pls
                               SAE_AP_CUSTOM_UTIL_PK.grt
                               SAE_AP_CUSTOM_UTIL_PK.syn
                               SAE_AP_CUSTOM_UTIL_PK_CCR.ldt
                               SAE_AP_CUSTOM_UTIL_RQG.ldt
