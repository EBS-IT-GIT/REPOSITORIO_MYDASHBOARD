UPDATE apps.ra_customer_trx_lines_all rctl
SET    interface_line_attribute4 = '0005-00003668'
WHERE  interface_line_attribute1 IS NOT NULL
AND    customer_trx_id IN (SELECT customer_trx_id
                           FROM   apps.ra_customer_trx_all
                           WHERE   trx_number IN ('A-0038-00001982'));
--1 Registro