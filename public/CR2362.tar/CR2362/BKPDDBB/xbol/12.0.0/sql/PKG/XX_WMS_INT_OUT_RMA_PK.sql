  set define off;

  CREATE OR REPLACE EDITIONABLE PACKAGE "APPS"."XX_WMS_INT_OUT_RMA_PK" as
/* $Header: $ */
/*#
* This interface returns RMA Information
* @rep:scope public
* @rep:product XBOL
* @rep:displayname xx_wms_int_out_rma_pk
* @rep:lifecycle active
* @rep:compatibility S
* @rep:category BUSINESS_ENTITY OE_ORDER_LINES_ALL
*/
	/*#
	* get_inegration_data
	* @param I_INT_TYPE Tipo Integracion
	* @param X_XML_RMA XML con informacion de ordenes de devolucion
	* @param X_XML_APPOINTMENT XML con informacion de citas
	* @param X_REQUEST_ID Identificador de procesamiento
	* @param X_RETURN_STATUS Return status indicating success or failure
	* @param X_MSG_DATA Return error message
	* @rep:scope public
	* @rep:lifecycle active
	* @rep:displayname WMS RMA Integration OUT
	*/

	procedure get_integration_data (
		 i_int_type			in  varchar2
		,x_xml_rma			out nocopy clob
		,x_xml_appointment	out nocopy clob
		,x_request_id		out number
		,x_return_status	out varchar2
		,x_msg_data			out varchar2
	);

	/*#
	* update_response_integration
	* @param I_INT_TYPE Tipo Integracion
	* @param I_REQUEST_ID Identificador de procesamiento
	* @param I_RETURN_STATUS Return status indicating success or failure
	* @param I_MSG_DATA Return error message
	* @rep:scope public
	* @rep:lifecycle active
	* @rep:displayname WMS RMA Integration Update Response
	*/

	procedure update_response_integration(
		 i_int_type			in  varchar2
		,i_request_id		in  number
		,i_return_status	in  varchar2
		,i_msg_data			in  varchar2
	);

end xx_wms_int_out_rma_pk;
/


  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "APPS"."XX_WMS_INT_OUT_RMA_PK" 
as
/* $Header: $ Mlaudati Version 1.0 20200205	*/
-- --------------------------------------------------------------------------
--  1.0  20-11-2019  MLaudati   Version Original

    g_pkg_name			constant varchar2(30) := 'XX_WMS_INT_OUT_RMA_PK';
	g_do_debug			constant boolean := case when(nvl(fnd_profile.value('XX_DEBUG_ENABLED'), 'N') = 'Y')then true else false end;

    --//-----------------------------------------------------------
	--//-----------------------------------------------------------
	procedure debug(
		i_message	in varchar2
	)
	is
		pragma autonomous_transaction;
	begin
		if(g_do_debug)then
			insert into xx_debug_messages(
				session_id, debug_sequence, debug_level, created_by, creation_date, last_updated_by, last_update_date, module, message
			) values (
				dbms_session.unique_session_id,
				xx_debug_messages_s.nextval, 1,	fnd_global.user_id, sysdate, fnd_global.user_id, sysdate,
				g_pkg_name, i_message
			);

			commit;
		end if;
	exception
		when others then
			rollback;
	end debug;

    --//-----------------------------------------------------------
	--//-----------------------------------------------------------	
	procedure get_integration_data(
		 i_int_type			in  varchar2
		,x_xml_rma			out nocopy clob
		,x_xml_appointment	out nocopy clob
		,x_request_id		out number
		,x_return_status	out varchar2
		,x_msg_data			out varchar2
	)
	is
	
		--//--------------------------------------------------------
		l_request_id    NUMBER := to_char(sysdate,'YYYYMMDDHH24MI');
		l_rows          NUMBER;
		e_error         EXCEPTION;
		l_xml			XMLTYPE;
		l_proc			VARCHAR2(30) := 'get_integration_data: ';
		--//--------------------------------------------------------
	
	begin
		
		debug(l_proc || 'Init => ' || i_int_type || ' Request_Id => ' || l_request_id);
		
		--
		-- Actualizo en la tabla los registros con error para volver a enviar a WMS
		--
		begin
		
			update xx_wms_int_out_rma xx
			set xx.status = 'NEW', xx.error_mesg = null, xx.request_id = l_request_id, xx.last_update_date = sysdate
			where 1=1
			and xx.status != 'OK'
			and xx.request_id != l_request_id
			;
			
			debug(l_proc || 'Actualizar en la tabla los registros con error para volver a enviar a WMS => ' || sql%rowcount);
		
		exception
			when others then
				x_msg_data := 'Error al actualizar registros con error: ' || sqlerrm;
				raise e_error;
		end;
		
		--
		-- Inserto en la tabla las novedades de RMA para enviar a WMS
		--
		begin
			insert into xx_wms_int_out_rma (
				request_id, 
				header_id, 
				line_id, 
				inventory_item_id, 
				order_number, 
				line_number, 
				organization_code, 
				xx_estado_devoluciones, 
				ordered_item, 
				ordered_quantity, 
				order_quantity_uom, 
				wms_quantity,
				wms_uom, 
				exceso_op, 
				ordered_date, 
				status, 
				error_mesg, 
				creation_date, 
				created_by, 
				last_update_date, 
				last_updated_by
			)
			select
			 l_request_id
			,ooh.header_id
			,ool.line_id
			,ool.inventory_item_id
			,ooh.order_number
			,ool.line_number
			,ood.organization_code
			,flv_dfv.xx_estado_devoluciones
			,ool.ordered_item
			,ool.ordered_quantity
			,ool.order_quantity_uom
			,inv_convert.inv_um_convert(
				ool.inventory_item_id,
				NULL,
				ool.ordered_quantity,
				ool.order_quantity_uom,
				mcr_dfv.xx_uom_wms,
				NULL,
				NULL
			) wms_quantity
			,mcr_dfv.xx_uom_wms wms_uom
			,flv_dfv.xx_exceso_op exceso_op
			,ooh.ordered_date
			,'NEW' status
			,NULL  error_mesg
			,sysdate creation_date
			,fnd_global.user_id created_by
			,sysdate last_update_date
			,fnd_global.user_id last_updated_by	
			from 
			 oe_order_headers_all ooh
			,oe_order_lines_all ool
			,oe_transaction_types_all ott 
			,org_organization_definitions ood
			,fnd_lookup_values_vl flv
			,fnd_lookup_values_dfv flv_dfv
			,mtl_cross_references mcr
			,mtl_cross_references_dfv mcr_dfv
			where 1=1
			and ool.line_type_id = ott.transaction_type_id
			and ott.order_category_code = 'RETURN'
			and ooh.header_id = ool.header_id
			and flv.rowid = flv_dfv.row_id
			and flv.lookup_type = 'XX_MAPEO_EBS_WMS'
			and flv_dfv.xx_org_confirmacion_despacho = ood.organization_code
			and ool.ship_from_org_id = ood.organization_id
			and ool.cancelled_flag = 'N' 
			and ool.booked_flag = 'Y'
			and ool.open_flag = 'Y'
			and NVL(flv.enabled_flag,'N') = 'Y'
			and trunc(SYSDATE) between trunc(flv.start_date_active) and trunc(NVL(flv.end_date_active, SYSDATE))
			and mcr.inventory_item_id = ool.inventory_item_id
			and nvl(mcr.organization_id, ood.organization_id) = ood.organization_id
			and mcr.cross_reference_type = 'DUN14'
			and mcr.rowid = mcr_dfv.row_id
			and not exists(
				select 1
				from xx_wms_int_out_rma xx
				where 1=1
				and xx.header_id = ool.header_id
				and xx.line_id = ool.line_id
			)
			;
		
			debug(l_proc || 'Insertar en la tabla las novedades de RMA para enviar a WMS => ' || sql%rowcount);
		
		exception
			when others then
				x_msg_data := 'Error al insertar en xx_wms_int_out_rma: ' || sqlerrm;
				raise e_error;
		end;
		
		--//------------------------------------------------------
		begin
		
			select count(1)
			into l_rows
			from xx_wms_int_out_rma
			where 1=1
			and status != 'ERROR'
			and request_id = l_request_id;
		
		exception
			when others then
				l_rows := 0;
		end;
		
		debug(l_proc || 'Registros a procesar => ' || l_rows);
		
		if(l_rows > 0)then
		
			--
			-- Armo XML de RMA para enviar a WMS
			--
			begin
			
				select
					XMLELEMENT("LgfData",
						XMLELEMENT("Header",
							XMLELEMENT("DocumentVersion", '9.0.1'),
							XMLELEMENT("OriginSystem", 'Host'),
							XMLELEMENT("ClientEnvCode", l_request_id),
							XMLELEMENT("ParentCompanyCode", 'ADECO'),
							XMLELEMENT("Entity", 'ib_shipment'),
							XMLELEMENT("TimeStamp", to_char(sysdate,'YYYY-mm-dd hh24:mi:ss')),
							XMLELEMENT("MessageId", l_request_id)
						)
						,
						XMLELEMENT("ListOfIbShipments",
							(
								select XMLAGG(
									XMLELEMENT("ib_shipment",
										XMLELEMENT("ib_shipment_hdr",
											XMLFOREST(
												 hdr.order_number "shipment_nbr"
												,hdr.organization_code "facility_code"
												,'ADECO' "company_code"
												,'CREATE' "action_code"
												,hdr.order_number "load_nbr"
												,hdr.shipped_date "shipped_date"
												,hdr.xx_estado_devoluciones "lock_code"
												,'DEV' "shipment_type"
											)
										)
										,
										--//DETALE
										(
											select XMLAGG(
												XMLELEMENT("ib_shipment_dtl",
													XMLFOREST(
														 dtl.line_number "seq_nbr"
														,'CREATE' "action_code"
														,dtl.ordered_item "item_alternate_code"
														,dtl.wms_quantity "shipped_qty"
														,dtl.header_id "cust_field_1"
														--,dtl.line_id "invn_attr_a"
														,dtl.header_id "invn_attr_a"
													)
												)
											)
											from (
												select distinct
												 line_number,
												 ordered_item,
												 wms_quantity,
												 line_id,
												 header_id
												from xx_wms_int_out_rma
												where 1=1
												and request_id = l_request_id
												and status != 'ERROR'
												--//RELACION CON HEADER-------------
												and header_id = hdr.header_id
												------------------------------------
											) dtl
										)
										--//FIN DETALLE
									)
								)
								from (
									select distinct
									 header_id,
									 order_number,
									 organization_code,
									 to_char(ordered_date, 'yyyy-mm-dd') shipped_date,
									 xx_estado_devoluciones
									from xx_wms_int_out_rma
									where 1=1
									and request_id = l_request_id
									and status != 'ERROR'
								) hdr
							)
						)
					)
				xmltext
				into l_xml
				from dual
				;
			
				x_xml_rma := l_xml.getClobVal();
				
				debug(l_proc || 'X_Xml_Rma Length => ' || DBMS_LOB.GETLENGTH(x_xml_rma));
			
			exception
				when others then
					x_msg_data := 'Error al armar x_xml_rma: ' || sqlerrm;
					raise e_error;
			end;
			
			--
			-- Armo XML de APPOINTMENT para enviar a WMS
			--			
			begin
			
				select
				XMLELEMENT("LgfData",
					XMLELEMENT("Header",
						XMLELEMENT("DocumentVersion", '9.0.1'),
						XMLELEMENT("OriginSystem", 'Host'),
						XMLELEMENT("ClientEnvCode", l_request_id),
						XMLELEMENT("ParentCompanyCode", 'ADECO'),
						XMLELEMENT("Entity", 'appointment'),
						XMLELEMENT("TimeStamp", to_char(sysdate,'YYYY-mm-dd hh24:mi:ss')),
						XMLELEMENT("MessageId", l_request_id)
					),
					XMLELEMENT ("ListOfAppointments",
						(
							select XMLAGG(
								XMLELEMENT("appointment",
									XMLFOREST(
										organization_code "facility_code"
										,'ADECO' "company_code"
										,order_number "appt_nbr"
										,order_number "load_nbr"
										,'ENT' "dock_type"
										,'CREATE' "action_code"
										,'' "preferred_dock_nbr"
										,to_char(sysdate + 1/(24*60),'YYYY-mm-dd hh24:mi:ss') "planned_start_ts"
										,'' "duration"
										,'' "estimated_units"
										,'' "carrier_info"
										,'' "trailer_nbr"
										,'' "load_type"
									)
								)
							)
							from (
								select distinct
								organization_code, order_number
								from xx_wms_int_out_rma
								where 1=1
								and request_id = l_request_id
								and status != 'ERROR'					  
							)
						) "ListOfAppointments"
					)
				)
				xmltext
				into l_xml
				from dual
				;
			
				x_xml_appointment := l_xml.getClobVal();
			
				debug(l_proc || 'X_Xml_Appointment Length => ' || DBMS_LOB.GETLENGTH(x_xml_appointment));
			
			exception
				when others then
					x_msg_data := 'Error al armar x_xml_appointment: ' || sqlerrm;
					raise e_error;
			end;
			
			x_return_status := 'S';
			x_request_id := l_request_id;
		
		else
		
			x_return_status := 'X'; -- Indica que no se encontraron novedades
			x_request_id := l_request_id;		
		
		end if;
		--//------------------------------------------------------
		
		debug(l_proc || 'End => ' || i_int_type || ' => ' || x_return_status);		
		
	exception

		when e_error then
		
			x_return_status := 'E';
			x_request_id := l_request_id;
			
			update xx_wms_int_out_rma xx
			set xx.status = 'ERROR', xx.error_mesg = case when(xx.error_mesg is null)then '' else '. ' end || x_msg_data, xx.last_update_date = sysdate
			where xx.status = 'NEW'
			and xx.request_id = l_request_id
			;
			
			debug(l_proc || x_msg_data);
		
		when others then
		
			x_return_status := 'E';
			x_request_id := l_request_id;
			x_msg_data := 'Error: ' || sqlerrm;
			
			update xx_wms_int_out_rma xx
			set xx.status = 'ERROR', xx.error_mesg = case when(xx.error_mesg is null)then '' else '. ' end || x_msg_data, xx.last_update_date = sysdate
			where xx.status = 'NEW'
			and xx.request_id = l_request_id
			;
			
			debug(l_proc || x_msg_data);

	end get_integration_data;

    --//-----------------------------------------------------------
	--//-----------------------------------------------------------	
	procedure update_response_integration(
		 i_int_type			in  varchar2
		,i_request_id		in  number
		,i_return_status	in  varchar2
		,i_msg_data			in  varchar2
	)
	is
		l_proc varchar2(50) := 'update_response_integration: ';
	begin
		debug(l_proc || 'I_Int_Type => ' || i_int_type || ' I_Request_Id => ' || i_request_id || ' I_Return_Status => ' || i_return_status || ' I_Msg_Data => ' || i_msg_data);
		
		update xx_wms_int_out_rma
		set 
		 status = decode(i_return_status, 'True', 'OK', 'ERROR')
		,error_mesg = decode(i_return_status, 'True', '', i_msg_data)
		,last_update_date = sysdate
		,last_updated_by = fnd_global.user_id
		where 1=1
		and request_id = i_request_id
		and status != 'ERROR';
		
		debug(l_proc || 'Update Xx_Wms_Int_Asn_Orders => ' || sql%rowcount);
	exception
		when others then
			debug(l_proc || 'Update_Response_Integration(OTHERS) => ' || sqlerrm);
	end update_response_integration;

end xx_wms_int_out_rma_pk;
/

exit
