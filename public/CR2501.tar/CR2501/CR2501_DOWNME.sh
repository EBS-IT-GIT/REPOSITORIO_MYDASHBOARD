#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2501_DOWNME.sh
# |
# | DESCRIPTION
# |   Script para descarga de los objetos a desarrollar en el requerimiento CR2501
# |
# | HISTORY
# |   27-MAY-20  Torres, Clarisa - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2501_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2501_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 



# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2501
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
APPS_PWD=$1
CRDIR="/ua1001/fs_ne/ADECO/patch/CR2501/CR2501_20200527"
PATCHDIR="/ua1001/fs_ne/ADECO/patch"
DDBB=CRP3

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/LDR
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
mkdir -p $INSTDIR
cd $INSTDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/LDR
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT
svn up /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2501" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2501_9499.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2501"
AddAllLogs $CROUT "FND" "CR2501_9499.ldt"
mv CR2501_9499.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AR_PADRON_IIBB_SALTA_AE " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AR_PADRON_IIBB_SALTA_AE','BOLINF','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_PADRON_IIBB_SALTA_AE* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AR_PADRON_IIBB_SALTA_RF " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AR_PADRON_IIBB_SALTA_RF','BOLINF','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_PADRON_IIBB_SALTA_RF* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TB XX_AR_AP_COEF_CM05 " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TB','XX_AR_AP_COEF_CM05','BOLINF','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_AP_COEF_CM05* $DOWNDBDIR/xbol/12.0.0/sql/TB

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_AR_PADRON_SALTA_RF_S " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_AR_PADRON_SALTA_RF_S','BOLINF','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_PADRON_SALTA_RF_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_AR_PADRON_SALTA_AE_S " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_AR_PADRON_SALTA_AE_S','BOLINF','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_PADRON_SALTA_AE_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ XX_AR_AP_COEF_CM05_S " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','XX_AR_AP_COEF_CM05_S','BOLINF','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_AP_COEF_CM05_S* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-LDR XXARPSAE " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSAE.ctl XXARPSAE.ctl
echo `ls -lh XXARPSAE.ctl` >> $CROUT

mv XXARPSAE* $DOWNDBDIR/xbol/12.0.0/sql/LDR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-LDR XXARPSRF " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

mv XXARPSRF* $DOWNDBDIR/xbol/12.0.0/sql/LDR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_AR_AP_PADRON_IIBB_SALTA_PK " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_AR_AP_PADRON_IIBB_SALTA_PK','APPS','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_AP_PADRON_IIBB_SALTA_PK* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_AR_IIBB_PADRON_PKG " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/bin/XXARPSRF.ctl XXARPSRF.ctl
echo `ls -lh XXARPSRF.ctl` >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_AR_IIBB_PADRON_PKG','APPS','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_IIBB_PADRON_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF INSERT_CM05 " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','INSERT_CM05','','$PATCHDIR','CR2501');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv INSERT_CM05* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXARPSAE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXARPSAE.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXARPSAE"
AddAllLogs $CROUT "FND" "XXARPSAE.ldt"
mv XXARPSAE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXARPSRF " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXARPSRF.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXARPSRF"
AddAllLogs $CROUT "FND" "XXARPSRF.ldt"
mv XXARPSRF.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXARPCPS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXARPCPS.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXARPCPS"
AddAllLogs $CROUT "FND" "XXARPCPS.ldt"
mv XXARPCPS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXARPPIS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXARPPIS.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXARPPIS"
AddAllLogs $CROUT "FND" "XXARPPIS.ldt"
mv XXARPPIS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF JL_ZZ_AR_TX_EXC_CUS_AR_XXALICUOTA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct JL_ZZ_AR_TX_EXC_CUS_AR_XXALICUOTA.ldt DESC_FLEX APPLICATION_SHORT_NAME="JL" DESCRIPTIVE_FLEXFIELD_NAME="JL_ZZ_AR_TX_EXC_CUS" DESCRIPTIVE_FLEX_CONTEXT_CODE="AR" END_USER_COLUMN_NAME="XX_ALICUOTA"
AddAllLogs $CROUT "FND" "JL_ZZ_AR_TX_EXC_CUS_AR_XXALICUOTA.ldt"
mv JL_ZZ_AR_TX_EXC_CUS_AR_XXALICUOTA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF JL_ZZ_AR_TX_EXC_CUS_AR_XXCOEFICIENTE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct JL_ZZ_AR_TX_EXC_CUS_AR_XXCOEFICIENTE.ldt DESC_FLEX APPLICATION_SHORT_NAME="JL" DESCRIPTIVE_FLEXFIELD_NAME="JL_ZZ_AR_TX_EXC_CUS" DESCRIPTIVE_FLEX_CONTEXT_CODE="AR" END_USER_COLUMN_NAME="XX_COEFICIENTE"
AddAllLogs $CROUT "FND" "JL_ZZ_AR_TX_EXC_CUS_AR_XXCOEFICIENTE.ldt"
mv JL_ZZ_AR_TX_EXC_CUS_AR_XXCOEFICIENTE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXARPPIS " >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "XML" "XXARPPIS.ldt"
mv XXARPPIS* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXARPPIS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXARPPIS.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXARPPIS"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARPPIS \
-LANGUAGE "es" \
-TERRITORY "00" \
-LOG_FILE XXARPPIS_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXARPPIS.ldt"
mv XXARPPIS* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT

cp -rf $DOWNDBDIR/* $INSTDIR
mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
