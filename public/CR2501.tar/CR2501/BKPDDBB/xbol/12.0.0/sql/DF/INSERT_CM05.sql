  set define off;
ORA-01403: no data found

exit
