  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_IIBB_PADRON_PKG" AS

  /*=============================================================+
  |  package para la carga de datos y actualizacion del padron   |
  |  LBAYER / SLOPEZ                                             |
  |  08/2017                                                     |
  +=============================================================*/

  e_error  EXCEPTION;
  e_retcode NUMBER := 1;
  e_message VARCHAR2(1000);

  FUNCTION insertar_iibb_site( p_address_id            IN jl_zz_ar_tx_cus_cls_all.address_id%TYPE
                             , p_org_id                IN jl_zz_ar_tx_cus_cls_all.org_id%TYPE
                             , p_contributor_class     IN jl_zz_ar_tx_att_cls_all.tax_attr_class_code%TYPE
                             , p_tax_category_id       IN jl_zz_ar_tx_att_cls_all.tax_category_id%TYPE       DEFAULT NULL
                             , p_tax_attribute_value   IN jl_zz_ar_tx_cus_cls_all.tax_attribute_value%TYPE   DEFAULT NULL
                             ) RETURN BOOLEAN;

  PROCEDURE main2 ( errbuf              OUT  VARCHAR2
                  , retcode             OUT  VARCHAR2
                  , p_grupo_emp         IN   VARCHAR2
                  , p_org               IN   NUMBER
                  , p_period            IN   VARCHAR2
                  , p_tipo_perc         IN   VARCHAR2
                  , p_cust              IN   NUMBER
                  , p_draft             IN   VARCHAR2) ;

  PROCEDURE carga_padron ( errbuf        OUT  VARCHAR2,
                           retcode       OUT  VARCHAR2,
                           p_tipo_imp    IN   VARCHAR2,
                           p_fecha       IN   DATE,
                           p_draft       IN   VARCHAR2,
                           p_existe      OUT  VARCHAR2);

  FUNCTION trae_location ( p_address_id    IN hz_cust_acct_sites_all.cust_acct_site_id%type,
                           pc_cust         IN hz_cust_acct_sites_all.cust_account_id%type,
                           pc_org          IN jl_zz_ar_tx_cus_cls_all.org_id%TYPE
                          ) RETURN VARCHAR2;

END XX_AR_IIBB_PADRON_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_IIBB_PADRON_PKG" AS

  /*=====================================================================================+
  |                                                                                      |
  | Public Function                                                                      |
  |    insertar_iibb_site                                                                |
  |                                                                                      |
  | Description                                                                          |
  |    Funcion publica que inserta las tasas correspondientes al contributor class y al  |
  |    padron                                                                            |
  +=====================================================================================*/

  FUNCTION INSERTAR_IIBB_SITE( p_address_id          IN jl_zz_ar_tx_cus_cls_all.address_id%TYPE
                             , p_org_id              IN jl_zz_ar_tx_cus_cls_all.org_id%TYPE
                             , p_contributor_class   IN jl_zz_ar_tx_att_cls_all.tax_attr_class_code%TYPE
                             , p_tax_category_id     IN jl_zz_ar_tx_att_cls_all.tax_category_id%TYPE       DEFAULT NULL
                             , p_tax_attribute_value IN jl_zz_ar_tx_cus_cls_all.tax_attribute_value%TYPE   DEFAULT NULL
                             ) RETURN BOOLEAN IS

    r_iibb_padron_pkg    jl_zz_ar_tx_cus_cls_all%ROWTYPE;

    CURSOR c_tax_vals ( c_org_id                 jl_zz_ar_tx_att_cls_all.org_id%TYPE
                      , c_tax_attr_class_code    jl_zz_ar_tx_att_cls_all.tax_attr_class_code%TYPE
                      , c_address_id             jl_zz_ar_tx_cus_cls_all.address_id%TYPE
                      , c_tax_category_id        jl_zz_ar_tx_att_cls_all.tax_category_id%TYPE
                      , c_tax_attribute_value    jl_zz_ar_tx_att_cls_all.tax_attribute_value%TYPE
                      ) IS
      SELECT jzataca.tax_attr_class_code
           , jzataca.tax_category_id
           , jzataca.tax_attribute_name
           , jzataca.tax_attribute_value
        FROM jl_zz_ar_tx_att_cls_all jzataca
       WHERE jzataca.tax_attr_class_code = c_tax_attr_class_code
         AND jzataca.org_id              = c_org_id
         AND jzataca.tax_category_id    != c_tax_category_id
         AND NOT EXISTS (SELECT 1
                           FROM jl_zz_ar_tx_cus_cls_all  jzatcca
                          WHERE jzatcca.tax_category_id     = jzataca.tax_category_id
                            AND jzatcca.org_id              = jzataca.org_id
                            AND jzatcca.tax_attribute_name  = jzataca.tax_attribute_name --R12
                            AND jzatcca.tax_attr_class_code = c_tax_attr_class_code
                            AND jzatcca.address_id          = c_address_id)
      UNION
      SELECT c_tax_attr_class_code
           , to_number(c_tax_category_id)
           , cus_tax_attribute
           , c_tax_attribute_value
        FROM JL_ZZ_AR_TX_CATEG_ALL
       WHERE org_Id          = c_org_id
         AND tax_category_Id = c_tax_category_id
--R12: start
         AND NOT EXISTS (SELECT 1
                           FROM APPS.jl_zz_ar_tx_cus_cls_all  jzatcca
                          WHERE jzatcca.tax_category_id     = c_tax_category_id
                            AND jzatcca.org_id              = c_org_id
                            AND jzatcca.tax_attribute_name  = cus_tax_attribute
                            AND jzatcca.tax_attr_class_code = c_tax_attr_class_code
                            AND jzatcca.address_id          = c_address_id);
--R12: end

    r_tax_vals      c_tax_vals%rowtype;

  BEGIN
    --
    OPEN c_tax_vals ( c_org_id              => p_org_id
                    , c_tax_attr_class_code => p_contributor_class
                    , c_address_id          => p_address_id
                    , c_tax_category_id     => p_tax_category_id
                    , c_tax_attribute_value => p_tax_attribute_value);

    LOOP
      FETCH c_tax_vals INTO r_tax_vals;
      EXIT WHEN c_tax_vals%NOTFOUND;

      -- valores comunes para todos
      r_iibb_padron_pkg.address_id       := p_address_id;
      r_iibb_padron_pkg.enabled_flag     := 'Y';
      r_iibb_padron_pkg.last_update_date := sysdate;
      r_iibb_padron_pkg.last_updated_by  := fnd_profile.value('USER_ID');
      r_iibb_padron_pkg.org_id           := p_org_id;
      r_iibb_padron_pkg.creation_date    := sysdate;
      r_iibb_padron_pkg.created_by       := fnd_profile.value('USER_ID');

      -- valores propios del cursor
      r_iibb_padron_pkg.tax_attr_class_code  := r_tax_vals.tax_attr_class_code;
      r_iibb_padron_pkg.tax_category_id        := r_tax_vals.tax_category_id ;
      r_iibb_padron_pkg.tax_attribute_name   := r_tax_vals.tax_attribute_name;
      r_iibb_padron_pkg.tax_attribute_value   := r_tax_vals.tax_attribute_value;

      BEGIN
        SELECT jl_zz_ar_tx_cus_cls_s.NEXTVAL
          INTO r_iibb_padron_pkg.cus_class_id
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          e_message:= 'Error al buscar secuencia para r_iibb_padron_pkg';
          fnd_file.put_line(fnd_file.log, e_message);
          RETURN FALSE;
      END;

      IF r_iibb_padron_pkg.TAX_ATTRIBUTE_VALUE is null THEN
         e_message:= 'Error al buscar tax_attribute_value de address_id: '||p_address_id;
         fnd_file.put_line(fnd_file.log, e_message);
         RETURN FALSE;
      END IF;

      IF r_iibb_padron_pkg.CUS_CLASS_ID is not null and
         r_iibb_padron_pkg.ADDRESS_ID is not null and
         r_iibb_padron_pkg.TAX_ATTR_CLASS_CODE is not null and
         r_iibb_padron_pkg.TAX_CATEGORY_ID is not null and
         r_iibb_padron_pkg.TAX_ATTRIBUTE_NAME is not null and
         r_iibb_padron_pkg.TAX_ATTRIBUTE_VALUE is not null and
         r_iibb_padron_pkg.ENABLED_FLAG is not null THEN

         fnd_file.put_line(fnd_file.log, 'inserta ='||
                                         r_iibb_padron_pkg.CUS_CLASS_ID||'-'||
                                         r_iibb_padron_pkg.ADDRESS_ID||'-'||
                                         r_iibb_padron_pkg.TAX_ATTR_CLASS_CODE||'-'||
                                         r_iibb_padron_pkg.TAX_CATEGORY_ID||'-'||
                                         r_iibb_padron_pkg.TAX_ATTRIBUTE_NAME||'-'||
                                         r_iibb_padron_pkg.TAX_ATTRIBUTE_VALUE||'-'||
                                         r_iibb_padron_pkg.ENABLED_FLAG);

      INSERT INTO jl_zz_ar_tx_cus_cls_all
           VALUES r_iibb_padron_pkg;

      r_iibb_padron_pkg := null;

      ELSE
        e_message := 'no inserta por nulos ='||
                     r_iibb_padron_pkg.CUS_CLASS_ID||'-'||
                     r_iibb_padron_pkg.ADDRESS_ID||'-'||
                     r_iibb_padron_pkg.TAX_ATTR_CLASS_CODE||'-'||
                     r_iibb_padron_pkg.TAX_CATEGORY_ID||'-'||
                     r_iibb_padron_pkg.TAX_ATTRIBUTE_NAME||'-'||
                     r_iibb_padron_pkg.TAX_ATTRIBUTE_VALUE||'-'||
                     r_iibb_padron_pkg.ENABLED_FLAG;
        fnd_file.put_line(fnd_file.log, e_message);
        RETURN FALSE;
      END IF;

    END LOOP;
    CLOSE c_tax_vals;

    UPDATE hz_cust_acct_sites_all
       SET global_attribute9 = 'Y'
         , last_update_date  = sysdate
         , last_updated_by   =fnd_profile.value('USER_ID')
         , last_update_login = fnd_profile.value('LOGIN_ID')
     WHERE cust_acct_site_id  = p_address_id;

   RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      e_message := 'Error general insertar_iibb_site, sqlerrm: '||sqlerrm;
      fnd_file.put_line(fnd_file.log, e_message);
      RETURN FALSE;

  END INSERTAR_IIBB_SITE;


  /*===========================================================================+
  |                                                                            |
  | Public Function                                                            |
  |    main                                                                    |
  |                                                                            |
  | Description                                                                |
  |    Funcion publica que compara y actualiza los clientes con el padron de   |
  |    contribuyentes de Ingresos Brutos de CABA.                              |
  |                                                                            |
  | Parameters                                                                 |
  |    errbuf                  OUT     VARCHAR2  Parametro interno             |
  |    retcode                OUT     VARCHAR2  Parametro interno              |
  |    p_grupo_emp       IN        VARCHAR2  Grupo de Empresa.                 |
  |    p_org                  IN         NUMBER    Org Id.                     |
  |    p_perc_castigo     IN        VARCHAR2  Percepcion Castigo               |
  |    p_cust                 IN        NUMBER    Cliente                      |
  +===========================================================================*/
  PROCEDURE main2 ( errbuf           OUT VARCHAR2,
                    retcode          OUT VARCHAR2,
                    p_grupo_emp      IN  VARCHAR2,
                    p_org            IN  NUMBER,
                    p_period         IN  VARCHAR2,
                    p_tipo_perc      IN  VARCHAR2,
                    p_cust           IN  NUMBER,
                    p_draft          IN  VARCHAR2)
  IS
    CURSOR c_org_errors ( pc_grupo_emp   IN VARCHAR2,
                          pc_org         IN NUMBER,
                          pc_cat_imp     IN NUMBER)
    IS
      SELECT hla1d.xx_grupo_emp,
             hla2d.establishment_type,
             haou.organization_id,
             haou.name,
             jzatc.tax_category,
             jzatc.tax_category_id,
             jzatc_dfv.xx_ar_tasa_castigo
        FROM hr_locations_all2_dfv        hla2d,
             hr_locations_all             hla,
             hr_all_organization_units    haou,
             hr_locations_all1_dfv        hla1d,
             hr_organization_information  hoi,
             jl_zz_ar_tx_att_cls_all      jzataca,
             jl_zz_ar_tx_categ_all        jzatc,
             jl_zz_ar_tx_categ_all_dfv    jzatc_dfv
       WHERE hla.ROWID                    = hla2d.row_id
         AND hla.ROWID                    = hla1d.row_id
         AND jzatc.ROWID                  = jzatc_dfv.row_id
         AND haou.organization_id         = hoi.organization_id
         AND hoi.org_information1         = 'OPERATING_UNIT'
         AND haou.location_id             = hla.location_id
         AND hla1d.xx_grupo_emp           = NVL (pc_grupo_emp, hla1d.xx_grupo_emp)
         AND haou.organization_id         = NVL (pc_org, haou.organization_id)
         AND jzataca.org_id               = haou.organization_id
         AND jzatc.org_id                 = haou.organization_id
         AND jzataca.tax_attr_class_code  = hla2d.establishment_type
         AND jzataca.tax_category_id      = jzatc.tax_category_id
         AND jzataca.tax_attribute_value  = 'APPLICABLE'
         AND jzatc.tax_category_id        = NVL (pc_cat_imp, jzatc.tax_category_id)
         AND jzatc_dfv.xx_ar_tasa_castigo IS NOT NULL
         /*Agregado Khronus/E.Sly 20190320 Se agregan mas categorias con tasa castigo que no deben ser incluidas aca*/
         AND jzatc_dfv.XX_AR_INC_ALIC_PROCESS = 'Y'
         /*Fin Agregado Khronus/E.Sly 20190320*/
         AND NOT EXISTS --sl. agruegue not para probar
                        ( SELECT 1
                            FROM xx_ar_iibb_padron
                           WHERE categoria_imp = jzatc.tax_category);

    CURSOR c_orgs ( pc_grupo_emp   IN VARCHAR2,
                    pc_org         IN NUMBER,
                    pc_cat_imp     IN NUMBER)
    IS
      SELECT hla1d.xx_grupo_emp,
             hla2d.establishment_type,
             haou.organization_id,
             haou.name,
             jzatc.tax_category,
             jzatc.tax_category_id,
             jzatc_dfv.xx_ar_tasa_castigo
        FROM hr_locations_all2_dfv        hla2d,
             hr_locations_all             hla,
             hr_all_organization_units    haou,
             hr_locations_all1_dfv        hla1d,
             hr_organization_information  hoi,
             jl_zz_ar_tx_att_cls_all      jzataca,
             jl_zz_ar_tx_categ_all        jzatc,
             jl_zz_ar_tx_categ_all_dfv    jzatc_dfv
       WHERE hla.ROWID                    = hla2d.row_id
         AND hla.ROWID                    = hla1d.row_id
         AND jzatc.ROWID                  = jzatc_dfv.row_id
         AND haou.organization_id         = hoi.organization_id
         AND hoi.org_information1         = 'OPERATING_UNIT'
         AND haou.location_id             = hla.location_id
         AND hla1d.xx_grupo_emp           = NVL (pc_grupo_emp, hla1d.xx_grupo_emp)
         AND haou.organization_id         = NVL (pc_org, haou.organization_id)
         AND jzataca.org_id               = haou.organization_id
         AND jzatc.org_id                 = haou.organization_id
         AND jzataca.tax_attr_class_code  = hla2d.establishment_type
         AND jzataca.tax_category_id      = jzatc.tax_category_id
         AND jzataca.tax_attribute_value  = 'APPLICABLE'
         /*Agregado Khronus/E.Sly 20190320 Se agregan mas categorias con tasa castigo que no deben ser incluidas aca*/
         AND jzatc_dfv.XX_AR_INC_ALIC_PROCESS = 'Y'
         /*Fin Agregado Khronus/E.Sly 20190320*/
         AND jzatc.tax_category_id        = NVL (pc_cat_imp, jzatc.tax_category_id);

    CURSOR c_sites ( pc_org_id          hr_operating_units.organization_id%TYPE,
                     pc_customer_id     ra_customers.customer_id%TYPE,
                     pc_tax_category    jl_zz_ar_tx_categ_all.TAX_CATEGORY%TYPE)

    IS
      SELECT customer_name,
             customer_number,
             cuit,
             address_id,
             contributor_class,
             (SELECT DISTINCT 'Y'
                FROM jl_zz_ar_tx_cus_cls_all jzatcc
               WHERE jzatcc.tax_attr_class_code = q.contributor_class
                 AND jzatcc.org_id = q.org_id
                 AND jzatcc.tax_category_id = q.tax_category_id
                 AND address_id = q.address_id --sl
             )
             existe_perfiles,
             (SELECT tax_code
                FROM ar_vat_tax_all avt, ar_vat_tax_all_b1_dfv avt_dfv
               WHERE avt.ROWID = avt_dfv.row_id
                 AND avt.org_id = q.org_id
                 AND avt_dfv.tax_category = q.tax_category_id
                 AND avt.tax_rate = q.tax_rate
                 AND enabled_flag = 'Y'
                 -- sl
                 AND SYSDATE BETWEEN start_date AND NVL(end_date, SYSDATE + 1)
             )
             tax_code,
             customer_id
        -- ver si esta activo
        FROM (SELECT jzatc.org_id
                   , substrb(hp.party_name,1,50)              customer_name
                   , hca.account_number                       customer_number
                   , jzatc.tax_category
                   , hca.cust_account_id                      customer_id
                   , hcas.cust_acct_site_id                   address_id
                   /*Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                   --, hl.address4
                   , hl.province
                   /*Fin Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                   , TO_NUMBER (jzatc_dfv.xx_ar_tasa_castigo) tax_rate
                   , hcas.global_attribute8                   contributor_class
                   , jzatc.tax_category_id
                   , SUBSTR (hp.jgzz_fiscal_code, 1, 10)      cuit
                FROM hz_parties                 hp     -- Upgrate R12
                   , hz_cust_accounts           hca    -- Upgrate R12
                   , hz_party_sites             hps    -- Upgrate R12
                   , hz_cust_acct_sites_all     hcas   -- Upgrate R12
                   , hz_locations               hl     -- Upgrate R12
                   , jl_zz_ar_tx_categ_all      jzatc
                   , jl_zz_ar_tx_categ_all_dfv  jzatc_dfv
               WHERE hp.party_id               = hca.party_id
                 AND hp.party_id               = hps.party_id
                 AND hps.party_site_id         = hcas.party_site_id
                 AND hps.location_id           = hl.location_id
                 AND jzatc.ROWID               = jzatc_dfv.row_id
                 AND jzatc.org_id              = hcas.org_id
                 /*Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                 --AND jzatc_dfv.xx_ar_provincia = hl.address4
                 AND jzatc_dfv.xx_ar_provincia = hl.province
                 AND hl.country = fnd_profile.value('XX_AR_IIBB_COUNTRY') --Se agrega para no tomar otros paises que usan el province
                 /*Fin Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                 AND jzatc_dfv.xx_ar_tasa_castigo IS NOT NULL -- Upgrade R12.2 - Guilherme Marques - IT Convergence - 29/01/2018
                 AND NOT EXISTS ( SELECT 1
                                    FROM xx_ar_iibb_padron xaip
                                   WHERE hp.jgzz_fiscal_code = substr( xaip.cuit,1,10)
                                     AND xaip.categoria_imp = jzatc.tax_category )
              UNION ALL
              SELECT jzatc.org_id
                   , SUBSTRB(hp.party_name,1,50)      customer_name
                   , hca.account_number               customer_number
                   , jzatc.tax_category
                   , hca.cust_account_id              customer_id
                   , hcas.cust_acct_site_id           address_id
                   /*Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                   --, hl.address4
                   , hl.province
                   /*Fin Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                   , xaip.percep_rate
                   , hcas.global_attribute8           contributor_class
                   , jzatc.tax_category_id
                   , xaip.cuit                        cuit
                FROM xx_ar_iibb_padron          xaip
                   , hz_parties                 hp    -- Upgrate R12
                   , hz_cust_accounts           hca   -- Upgrate R12
                   , hz_party_sites             hps   -- Upgrate R12
                   , hz_cust_acct_sites_all     hcas  -- Upgrate R12
                   , hz_locations               hl    -- Upgrate R12
                   , jl_zz_ar_tx_categ_all      jzatc
                   , jl_zz_ar_tx_categ_all_dfv  jzatc_dfv
               WHERE hp.party_id            = hca.party_id
                 AND hp.party_id            = hps.party_id
                 AND hps.party_site_id      = hcas.party_site_id
                 AND hps.location_id        = hl.location_id
                 AND jzatc.ROWID            = jzatc_dfv.row_id
                 AND jzatc.org_id           = hcas.org_id
                 AND xaip.categoria_imp     = jzatc.tax_category
                 AND substr(xaip.cuit,1,10) = SUBSTR (hp.jgzz_fiscal_code, 1, 10)
                 AND hl.country = fnd_profile.value('XX_AR_IIBB_COUNTRY') --Se agrega para no tomar otros paises que usan el province
                 /*Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                 --AND ( (jzatc_dfv.xx_ar_tasa_castigo IS NULL AND hl.address4 = jzatc_dfv.xx_ar_provincia)
                 AND ( (jzatc_dfv.xx_ar_tasa_castigo IS NULL AND hl.province = jzatc_dfv.xx_ar_provincia)
                 /*Modificado Khronus/E.Sly 20190107 Bug nuevas sucursales en R12*/
                       OR jzatc_dfv.xx_ar_tasa_castigo IS NOT NULL)
              ) q
        WHERE q.customer_id  = NVL (pc_customer_id, q.customer_id)
          AND q.org_id       = NVL (pc_org_id, q.org_id)
          AND q.tax_category = NVL (pc_tax_category, q.tax_category);

    CURSOR c_cat_imp (p_cat IN VARCHAR2) IS
      SELECT jzat.tax_category_id tax_cat_id, tax_category
        FROM jl_zz_ar_tx_categry_v jzat;

    r_orgs                 c_orgs%ROWTYPE;
    r_org_errors           c_org_errors%ROWTYPE;
    r_sites                c_sites%ROWTYPE;
    r_cat_imp              c_cat_imp%rowtype;

    l_existe_error          BOOLEAN := FALSE;
    l_categoria_imp         VARCHAR2 (100);
    l_tax_cat_id            VARCHAR2(100);
    l_tax_cat               VARCHAR2(100);
    l_set_of_bks_id         VARCHAR2(10);
    l_fecha                 DATE;
    l_existe_datos_padron   VARCHAR2(1) := 'S';
    l_tax_anterior          VARCHAR2(100);
    l_location              VARCHAR2(200);

  BEGIN
    --
    SELECT fnd_profile.value('GL_SET_OF_BKS_ID')
      INTO l_set_of_bks_id
      FROM dual;

    SELECT start_date
      INTO l_fecha
      FROM gl_period_statuses
     WHERE APPLICATION_ID = 101
       AND SET_OF_BOOKS_ID  = L_SET_OF_BKS_ID
       AND period_name = p_period;

    fnd_file.put_line (fnd_file.LOG, 'carga_padron ');

    carga_padron ( errbuf       => errbuf,
                   retcode      => retcode,
                   p_tipo_imp   => p_tipo_perc, --l_categoria_imp,
                   p_fecha      => l_fecha, -- ver,
                   p_draft      => p_draft,
                   p_existe     => l_existe_datos_padron);


    IF l_existe_datos_padron = 'N' THEN
      fnd_file.put_line (fnd_file.log, 'No existen datos en el padron para el periodo dado. Se frena la ejecucion del concurrente');
      e_retcode := 1;
      RAISE e_error;
    ELSE

      /* Cambio: TK1332 */
      IF NVL (p_draft,'N') = 'N' THEN
        DELETE jl_zz_ar_tx_cus_cls_all jz
        WHERE ( jz.cus_class_id, jz.address_id, jz.tax_category_id) IN
        (
          SELECT tcc.cus_class_id
               , tcc.address_id
               , tcc.tax_category_id
          FROM hz_parties                 hp
             , hz_cust_accounts           ca
             , hz_cust_acct_sites_all     cas
             , jl_zz_ar_tx_cus_cls_all    tcc
          WHERE 1=1
          AND ca.party_id          = hp.party_id
          AND cas.cust_account_id  = ca.cust_account_id
          AND tcc.address_id       = cas.cust_acct_site_id
          AND tcc.tax_category_id = (SELECT DISTINCT tax_category_id FROM jl_zz_ar_tx_categ_all WHERE tax_category = 'TOPCF')
          AND ca.attribute_category = 'AR'
          AND ca.cust_account_id    = NVL(p_cust, ca.cust_account_id)
          AND tcc.org_id            = NVL(p_org, tcc.org_id)
          AND NOT EXISTS ( SELECT cuit
                           FROM xx_ar_iibb_padron ip
                           WHERE 1=1
                           AND ip.categoria_imp     = 'TOPCF'
                           AND SUBSTR(ip.cuit,1,10) = SUBSTR(hp.jgzz_fiscal_code,1,10)
                         )
        )
        ;
      END IF;

      OPEN c_cat_imp (p_tipo_perc);
      LOOP
        FETCH c_cat_imp INTO  l_categoria_imp, l_tax_cat;
        EXIT WHEN c_cat_imp%notfound;
        fnd_file.put_line (fnd_file.LOG, 'l_Tax_cat_id= '|| l_categoria_imp||' - '||l_tax_cat);
        fnd_file.put_line (fnd_file.LOG, 'OPEN c_org_errors para '||p_grupo_emp||'-'||p_org||'-'|| l_categoria_imp);

        OPEN c_org_errors (p_grupo_emp, p_org, l_categoria_imp);
        LOOP
          FETCH c_org_errors INTO r_org_errors;
          EXIT WHEN c_org_errors%NOTFOUND;

          IF NOT l_existe_error THEN
            fnd_file.put_line(fnd_file.log, 'Existen las siguientes empresas con tasas de castigo definidas pero sin valores en el padron:');
          END IF;

          l_existe_error := TRUE;
          fnd_file.put_line(fnd_file.log,r_org_errors.name||';'||r_org_errors.xx_ar_tasa_castigo);
        END LOOP;
        CLOSE c_org_errors;

        IF l_existe_error THEN
          fnd_file.put_line (fnd_file.LOG, 'Existen empresas con tasa de castigo que no tienen valores cargados en el padron. Se frena la ejecucion del concurrente');
          e_retcode := 1;
          RAISE e_error;
        END IF;

        fnd_file.put_line(fnd_file.output,'Categoria Impuesto ='||l_tax_cat);
        fnd_file.put_line(fnd_file.output,'EMPRESA;CLIENTE;NRO CLIENTE;CUIT;SUCURSAL;IMPUESTO ANTERIOR;IMPUESTO NUEVO');

        OPEN c_orgs (p_grupo_emp, p_org, l_categoria_imp);
        LOOP
          FETCH c_orgs INTO r_orgs;
          EXIT WHEN c_orgs%NOTFOUND;
          fnd_file.put_line (fnd_file.log,  'OPEN c_sites ' ||'-'|| r_orgs.organization_id ||'-'|| p_cust ||'-'|| r_orgs.tax_category||'-'|| l_categoria_imp);

          OPEN c_sites (r_orgs.organization_id, p_cust, r_orgs.tax_category);
          LOOP
            FETCH c_sites INTO r_sites;
            fnd_file.put_line (fnd_file.log,  '  c_sites para r_orgs.organization_id='||r_orgs.organization_id||' hay='||c_sites%rowcount);
            EXIT WHEN c_sites%NOTFOUND;

            BEGIN
              l_tax_anterior := '';

              SELECT tax_attribute_value
                INTO l_tax_anterior
                FROM jl_zz_ar_tx_cus_cls_all
               WHERE tax_attr_class_code = r_sites.contributor_class
                 AND address_id = r_sites.address_id
                 AND tax_category_id = l_categoria_imp ;
            EXCEPTION
              WHEN OTHERS THEN
                l_tax_anterior := '-';
            END;

            IF NVL (r_sites.existe_perfiles, 'N') = 'N' THEN
              fnd_file.put_line (fnd_file.LOG, 'r_sites.customer_name='
                                             || r_sites.customer_name
                                             || ' r_sites.address_id = '
                                             || r_sites.address_id
                                             || ' r_orgs.tax_category_id ='
                                             || r_orgs.tax_category_id
                                             || ' r_sites.contributor_class ='
                                             || r_sites.contributor_class
                                             || '  r_orgs.organization_id ='
                                             || r_orgs.organization_id
                                             || 'r_sites.existe_perfiles='
                                             || r_sites.existe_perfiles);
              IF NVL (p_draft,'N') = 'N' THEN

                IF NOT insertar_iibb_site (r_sites.address_id ,
                                           r_orgs.organization_id ,
                                           r_sites.contributor_class ,
                                           r_orgs.tax_category_id,
                                           r_sites.tax_code) THEN
                  RAISE e_error;
                END IF;
              END IF;
            ELSE
              fnd_file.put_line (fnd_file.LOG, '*********** r_sites.tax_code='
                                            || r_sites.tax_code
                                            || ' -r_sites.contributor_class='
                                            || r_sites.contributor_class
                                            || ' -r_sites.address_id='
                                            || r_sites.address_id );
              IF NVL (p_draft,'N') = 'N' THEN
                UPDATE jl_zz_ar_tx_cus_cls_all
                   SET tax_attribute_value = r_sites.tax_code,
                       last_update_date    = SYSDATE,
                       last_updated_by     = fnd_profile.value('USER_ID')  ,
                       last_update_login   = fnd_profile.value('LOGIN_ID')
                 WHERE tax_attr_class_code = r_sites.contributor_class
                   AND tax_attribute_value != r_sites.tax_code
                   AND address_id = r_sites.address_id
                   --sl
                   AND tax_category_id = l_categoria_imp ;
              END IF;
            END IF;

            l_location  :=  trae_location (r_sites.address_id, r_sites.customer_id, r_orgs.organization_id);

            fnd_file.put_line (fnd_file.output, r_orgs.name||';'||r_sites.customer_name||';'||r_sites.customer_number||';'||r_sites.cuit||';'||l_location||';'|| l_tax_anterior||';'||r_sites.tax_code);

            fnd_file.put_line (fnd_file.log,  '     r_sites.existe_perfiles= ' ||r_sites.existe_perfiles);

          END LOOP;
          fnd_file.put_line (fnd_file.log,  '     CLOSE c_sites ' ||'-'|| r_orgs.organization_id ||'-'|| p_cust ||'-'|| r_orgs.tax_category);
          CLOSE c_sites;
        END LOOP;
        CLOSE c_orgs;
      END LOOP;
      CLOSE c_cat_imp;
    END IF;

    COMMIT;  /* Cambio: TK1332 */
  EXCEPTION
    WHEN e_error THEN
      fnd_file.put_line(fnd_file.log, e_message);
      retcode := e_retcode;
      errbuf  := e_message;
      ROLLBACK;

    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,  ' Error de sistema : '|| substr(sqlerrm,1,255));
      retcode := '2';
      errbuf  := substr(sqlerrm,1,255);
      ROLLBACK;
  END main2;

  /*===================================================================================+
  |                                                                                    |
  | Public Function                                                                    |
  |   carga_padron                                                                     |
  |                                                                                    |
  | Description                                                                        |
  |    Procedimiento que carga los datos de los padrones habilitados en la tabla unica |
  |                                                                                    |
  +===================================================================================*/
  PROCEDURE carga_padron ( errbuf       OUT VARCHAR2,
                           retcode      OUT VARCHAR2,
                           p_tipo_imp   IN  VARCHAR2,
                           p_fecha      IN  DATE,
                           p_draft      IN  VARCHAR2,
                           p_existe     OUT VARCHAR2)
  IS
    existe      NUMBER := 0;
    l_tipo_imp  VARCHAR2(100);
  BEGIN
    -- recibe el tipo de impuesto
    -- segun sea el tipo de impuesto, usa la tabla
    fnd_file.put_line (fnd_file.LOG, 'carga para: ' || p_tipo_imp);

    IF p_tipo_imp is null then
      l_tipo_imp := 'TOPBA';
    ELSE
      l_tipo_imp := p_tipo_imp;
    END IF;


    IF l_tipo_imp = 'TOPBA' THEN
      BEGIN
        -- valida que haya data
        existe := 0;

        SELECT 1
          INTO existe
          FROM DUAL
         WHERE EXISTS ( SELECT 1
                          FROM XX_JL_AP_AR_IBBA_CONT_TMP
                         WHERE p_fecha BETWEEN start_date AND end_date);
      EXCEPTION
        WHEN OTHERS THEN
          existe := 0;                                                  ---
      END;

      IF existe != 1 THEN
        fnd_file.put_line (fnd_file.LOG, 'no hay registros para TOPBA para la fecha dada: ' || p_fecha);
        p_existe := 'N';
      ELSE
        fnd_file.put_line (fnd_file.LOG,     'PADRON TOPBA OK para la fecha dada: ' || p_fecha);
        existe := 0;

        IF p_draft = 'N'  THEN
          BEGIN
            -- depura los datos que no corresponden al periodo
            fnd_file.put_line (fnd_file.LOG, 'borra '||L_TIPO_IMP);

            DELETE xx_ar_iibb_padron
             WHERE categoria_imp = l_tipo_imp;

            -- inserta los registros  que no existan en la tabla de padron
            fnd_file.put_line (fnd_file.LOG, 'inserta '||L_TIPO_IMP);
            INSERT INTO xx_ar_iibb_padron ( CATEGORIA_IMP,
                                            CUIT,
                                            PERCEP_RATE,
                                            EX_DATE_FROM,
                                            EX_DATE_TO,
                                            EX_RATE,
                                            EX_BASE_AMOUNT)
                                          ( SELECT l_tipo_imp categoria_imp,
                                                   ibba.cuit,
                                                   ibba.rate_per_awt percep_rate,
                                                   ibba.start_date ex_date_from,
                                                   ibba.end_date ex_date_to,
                                                   NULL EX_RATE,
                                                   NULL EX_BASE_AMOUNT
                                              FROM XX_JL_AP_AR_IBBA_CONT_TMP ibba
                                             WHERE rec_type = 'P'
                                               AND p_fecha BETWEEN start_date AND end_date);

          EXCEPTION
            WHEN OTHERS THEN
              raise e_error;
          END;
        END IF;
      END IF;
    END IF;

    IF p_tipo_imp IS NULL THEN
      l_tipo_imp := 'TOPCF';
    ELSE
      l_tipo_imp := p_tipo_imp;
    END IF;

   IF l_tipo_imp = 'TOPCF' THEN
     BEGIN
       -- valida que haya data
       existe := 0;
       SELECT 1
         INTO existe
         FROM DUAL
        WHERE EXISTS ( SELECT 1
                         FROM xx_ar_padron_riesgo_iibb_caba
                        WHERE p_fecha BETWEEN fecha_vig_desde
                          AND fecha_vig_hasta);
     EXCEPTION
       WHEN OTHERS THEN
         existe := 0;
     END;

    IF existe != 1 THEN
      fnd_file.put_line (fnd_file.LOG, 'no hay registros para TOPCF para la fecha dada: ' || p_fecha);
      p_existe := 'N';
    ELSE
      fnd_file.put_line (fnd_file.LOG, 'Padron TOPCF OK para la fecha dada: ' || p_fecha);
      existe := 0;

      IF p_draft = 'N' THEN
        BEGIN
          fnd_file.put_line (fnd_file.LOG,'borra '||L_TIPO_IMP);

          DELETE xx_ar_iibb_padron
           WHERE categoria_imp = l_tipo_imp;

          fnd_file.put_line (fnd_file.LOG,'inserta '||L_TIPO_IMP);
          -- inserta los registros  que no existan en la tabla de padron
          INSERT INTO xx_ar_iibb_padron ( CATEGORIA_IMP,
                                          CUIT,
                                          PERCEP_RATE,
                                          EX_DATE_FROM,
                                          EX_DATE_TO,
                                          EX_RATE,
                                          EX_BASE_AMOUNT)
                                        ( SELECT l_tipo_imp categoria_imp,
                                                 caba.cuit,
                                                 caba.percep_rate percep_rate,
                                                 caba.fecha_vig_desde ex_date_from,
                                                 caba.fecha_vig_hasta ex_date_to,
                                                 NULL EX_RATE,
                                                 NULL EX_BASE_AMOUNT
                                            FROM xx_ar_padron_riesgo_iibb_caba caba
                                           WHERE p_fecha BETWEEN caba.fecha_vig_desde AND caba.fecha_vig_hasta ) ;
        EXCEPTION
          WHEN OTHERS THEN
            raise e_error;                                                       ---
        END;
      END IF;
    END IF;

   ELSE
     --otras categorias de impuestos aun no definidas
     NULL;
   END IF;
 EXCEPTION
   WHEN OTHERS THEN
     fnd_file.put_line(fnd_file.log,  ' Error de sistema : '|| substr(sqlerrm,1,255));
     retcode := '2';
     errbuf  := substr(sqlerrm,1,255);
   ROLLBACK;
  END;
  --
  --
  --
  FUNCTION trae_location ( p_address_id  IN hz_cust_acct_sites_all.cust_acct_site_id%type,
                           pc_cust       IN hz_cust_acct_sites_all.cust_account_id%type,
                           pc_org        IN jl_zz_ar_tx_cus_cls_all.org_id%TYPE ) RETURN VARCHAR2
    IS
    l_retorna   varchar2(200);
  BEGIN
    BEGIN
      SELECT SUBSTR(NVL (arp_addr_pkg.format_address(hl.address_style
           , hl.address1
           , hl.address2
           , hl.address3
           , hl.address4
           , hl.city
           , hl.county
           , hl.state
           , hl.province
           , hl.postal_code
           , ftv.territory_short_name ), 'N/A') ,1,199)
        INTO l_retorna
        FROM hz_locations hl,
             fnd_territories_vl  ftv,
             hz_cust_acct_sites_all hcasa,
             hz_party_sites hps
       WHERE hcasa.cust_acct_site_id  = p_address_id
         AND hl.country               = ftv.territory_code(+)
         AND hps.location_id          = hl.location_id
         AND hcasa.party_site_id      = hps.party_site_id
         AND hcasa.cust_account_id    = pc_cust
         AND hcasa.org_id             = pc_org;
    EXCEPTION
      WHEN OTHERS THEN
        l_retorna :='N/D';
    END;
    RETURN SUBSTR(l_retorna,1,199);
  END;
  --
  --
END XX_AR_IIBB_PADRON_PKG; 
/

exit
