  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_CALCULOS_PKG" AS
 /*
 +=======================================================================+
 |           Copyright 2011 Adecoagro, Buenos Aires, Argentina           |
 |                        All rights reserved.                           |
 +=======================================================================+
 |
 | FILENAME
 |              xx_po_calculos_pkg.sql
 |
 | DESCRIPTION
 |              Especificación del paquete xx_po_calculos_pkg
 |
 | LANGUAGE
 |              PL/SQL
 |
 | PRODUCT
 |              Oracle Financials
 |
 | HISTORY
 |  10-JUN-15   Creado SBANCHIERI
 |
 +*=======================================================================
 */

  FUNCTION cf_cantidad_despachada ( p_po_header_id   NUMBER,
                                    p_po_line_id     NUMBER ) RETURN NUMBER;
                                   
  --CR2347
  FUNCTION Get_ga_ln_qty_rlsd ( p_po_header_id   NUMBER
                              , p_po_line_id     NUMBER ) RETURN NUMBER;
                              
  --CR2347
  FUNCTION Get_no_ga_ln_qty_rlsd ( p_po_header_id   NUMBER
                                 , p_po_line_id     NUMBER ) RETURN NUMBER;                              
                              

END xx_po_calculos_pkg;

--
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_CALCULOS_PKG" AS
 /*
 +=======================================================================+
 |           Copyright 2011 Adecoagro, Buenos Aires, Argentina           |
 |                        All rights reserved.                           |
 +=======================================================================+
 |
 | FILENAME
 |              xx_po_calculos_pkg.sql
 |
 | DESCRIPTION
 |              Cuerpo del paquete xx_po_calculos_pkg
 |
 | LANGUAGE
 |              PL/SQL
 |
 | PRODUCT
 |              Oracle Financials
 |
 | HISTORY
 |  10-JUN-15   Creado SBANCHIERI
 |
 +*=======================================================================
 */

  FUNCTION cf_cantidad_despachada ( p_po_header_id   NUMBER,
                                    p_po_line_id     NUMBER ) RETURN NUMBER IS

    v_cantidad_despachada   NUMBER;

  BEGIN

    SELECT -- Inicio CR2228
           -- SUM(quantity)
           SUM(quantity_received)
           -- Fin CR2228
      INTO v_cantidad_despachada
      FROM po_headers_all pha,
           po_line_locations_all plla
     WHERE plla.po_header_id = pha.po_header_id
       AND plla.po_release_id IS NOT NULL
       AND pha.po_header_id = p_po_header_id
       AND plla.po_line_id = p_po_line_id;

    RETURN NVL(v_cantidad_despachada,0);

  EXCEPTION
   WHEN OTHERS THEN
     RETURN 0;

  END;



  --CR2347
  FUNCTION Get_ga_ln_qty_rlsd ( p_po_header_id   NUMBER
                              , p_po_line_id     NUMBER ) RETURN NUMBER
  IS                            
    l_qty_released NUMBER;
    l_amnt_released NUMBER;
    
  BEGIN
   
    PO_CORE_S.get_ga_line_amount_released( p_po_line_id        => p_po_line_id
                                         , p_po_header_id      => p_po_header_id
                                         , x_quantity_released => l_qty_released
                                         , x_amount_released   => l_amnt_released);
    
    RETURN NVL(l_qty_released, 0);
    
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 0;
      
  END Get_ga_ln_qty_rlsd;    
  

  --CR2347
  FUNCTION Get_no_ga_ln_qty_rlsd ( p_po_header_id   NUMBER
                                 , p_po_line_id     NUMBER ) RETURN NUMBER
  IS
  
    l_qty_released  NUMBER;
  
  BEGIN  
    
    SELECT NVL(SUM(NVL(pll.quantity, 0) - NVL(pll.quantity_cancelled, 0)), 0)
      INTO l_qty_released
      FROM PO_LINE_LOCATIONS_ALL    pll
     WHERE pll.po_header_id         = p_po_header_id
       AND pll.po_line_id           = p_po_line_id
       AND shipment_type            = 'BLANKET' 
       AND NVL(consigned_flag, 'N') <> 'Y';
       
    RETURN l_qty_released;
    
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 0;
    
  END ;         

END xx_po_calculos_pkg;
/

exit
