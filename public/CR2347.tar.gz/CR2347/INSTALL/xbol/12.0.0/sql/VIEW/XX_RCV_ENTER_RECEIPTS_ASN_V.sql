  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_RCV_ENTER_RECEIPTS_ASN_V" ("LINE_CHKBOX"
                                                                         , "SOURCE_TYPE_CODE"
                                                                         , "RECEIPT_SOURCE_CODE"
                                                                         , "ORDER_TYPE_CODE"
                                                                         , "ORDER_TYPE"
                                                                         , "PO_HEADER_ID"
                                                                         , "PO_NUMBER"
                                                                         , "PO_LINE_ID"
                                                                         , "PO_LINE_NUMBER"
                                                                         , "PO_LINE_LOCATION_ID"
                                                                         , "PO_SHIPMENT_NUMBER"
                                                                         , "PO_RELEASE_ID"
                                                                         , "PO_RELEASE_NUMBER"
                                                                         , "REQ_HEADER_ID"
                                                                         , "REQ_NUMBER"
                                                                         , "REQ_LINE_ID"
                                                                         , "REQ_LINE"
                                                                         , "REQ_DISTRIBUTION_ID"
                                                                         , "RCV_SHIPMENT_HEADER_ID"
                                                                         , "RCV_SHIPMENT_NUMBER"
                                                                         , "RCV_SHIPMENT_LINE_ID"
                                                                         , "RCV_LINE_NUMBER"
                                                                         , "FROM_ORGANIZATION_ID"
                                                                         , "TO_ORGANIZATION_ID"
                                                                         , "VENDOR_ID"
                                                                         , "SOURCE"
                                                                         , "VENDOR_SITE_ID"
                                                                         , "OUTSIDE_OPERATION_FLAG"
                                                                         , "ITEM_ID"
                                                                         , "PRIMARY_UOM"
                                                                         , "PRIMARY_UOM_CLASS"
                                                                         , "ITEM_ALLOWED_UNITS_LOOKUP_CODE"
                                                                         , "ITEM_LOCATOR_CONTROL"
                                                                         , "RESTRICT_LOCATORS_CODE"
                                                                         , "RESTRICT_SUBINVENTORIES_CODE"
                                                                         , "SHELF_LIFE_CODE"
                                                                         , "SHELF_LIFE_DAYS"
                                                                         , "SERIAL_NUMBER_CONTROL_CODE"
                                                                         , "LOT_CONTROL_CODE"
                                                                         , "ITEM_REV_CONTROL_FLAG_TO"
                                                                         , "ITEM_REV_CONTROL_FLAG_FROM"
                                                                         , "ITEM_NUMBER"
                                                                         , "ITEM_REVISION"
                                                                         , "ITEM_DESCRIPTION"
                                                                         , "ITEM_CATEGORY_ID"
                                                                         , "HAZARD_CLASS"
                                                                         , "UN_NUMBER"
                                                                         , "VENDOR_ITEM_NUMBER"
                                                                         , "SHIP_TO_LOCATION_ID"
                                                                         , "SHIP_TO_LOCATION"
                                                                         , "PACKING_SLIP"
                                                                         , "ROUTING_ID"
                                                                         , "ROUTING_NAME"
                                                                         , "NEED_BY_DATE"
                                                                         , "EXPECTED_RECEIPT_DATE"
                                                                         , "ORDERED_QTY"
                                                                         , "ORDERED_UOM"
                                                                         , "USSGL_TRANSACTION_CODE"
                                                                         , "GOVERNMENT_CONTEXT"
                                                                         , "INSPECTION_REQUIRED_FLAG"
                                                                         , "RECEIPT_REQUIRED_FLAG"
                                                                         , "ENFORCE_SHIP_TO_LOCATION_CODE"
                                                                         , "UNIT_PRICE"
                                                                         , "CURRENCY_CODE"
                                                                         , "CURRENCY_CONVERSION_TYPE"
                                                                         , "CURRENCY_CONVERSION_DATE"
                                                                         , "CURRENCY_CONVERSION_RATE"
                                                                         , "NOTE_TO_RECEIVER"
                                                                         , "DESTINATION_TYPE_CODE"
                                                                         , "DELIVER_TO_PERSON_ID"
                                                                         , "DELIVER_TO_LOCATION_ID"
                                                                         , "DESTINATION_SUBINVENTORY"
                                                                         , "ATTRIBUTE_CATEGORY"
                                                                         , "ATTRIBUTE1"
                                                                         , "ATTRIBUTE2"
                                                                         , "ATTRIBUTE3"
                                                                         , "ATTRIBUTE4"
                                                                         , "ATTRIBUTE5"
                                                                         , "ATTRIBUTE6"
                                                                         , "ATTRIBUTE7"
                                                                         , "ATTRIBUTE8"
                                                                         , "ATTRIBUTE9"
                                                                         , "ATTRIBUTE10"
                                                                         , "ATTRIBUTE11"
                                                                         , "ATTRIBUTE12"
                                                                         , "ATTRIBUTE13"
                                                                         , "ATTRIBUTE14"
                                                                         , "ATTRIBUTE15"
                                                                         , "CLOSED_CODE"
                                                                         , "ASN_TYPE"
                                                                         , "BILL_OF_LADING"
                                                                         , "SHIPPED_DATE"
                                                                         , "FREIGHT_CARRIER_CODE"
                                                                         , "WAYBILL_AIRBILL_NUM"
                                                                         , "FREIGHT_BILL_NUM"
                                                                         , "VENDOR_LOT_NUM"
                                                                         , "CONTAINER_NUM"
                                                                         , "TRUCK_NUM"
                                                                         , "BAR_CODE_LABEL"
                                                                         , "RATE_TYPE_DISPLAY"
                                                                         , "MATCH_OPTION"
                                                                         , "COUNTRY_OF_ORIGIN_CODE"
                                                                         , "OE_ORDER_HEADER_ID"
                                                                         , "OE_ORDER_NUM"
                                                                         , "OE_ORDER_LINE_ID"
                                                                         , "OE_ORDER_LINE_NUM"
                                                                         , "CUSTOMER_ID"
                                                                         , "CUSTOMER_SITE_ID"
                                                                         , "CUSTOMER_ITEM_NUM"
                                                                         , "PLL_NOTE_TO_RECEIVER"
                                                                         , "SECONDARY_ORDERED_QTY"
                                                                         , "SECONDARY_ORDERED_UOM"
                                                                         , "QC_GRADE"
                                                                         , "LPN_ID"
                                                                         , "SECONDARY_DEFAULT_IND"
                                                                         , "ORG_ID"
                                                                         , "OE_ORDER_SHIP_NUM"
                                                                         , "LCM_SHIPMENT_LINE_ID"
                                                                         , "UNIT_LANDED_COST"
                                                                         , "LCM_SHIPMENT_FLAG") AS 
  SELECT 'N',
          'ASN',
          'VENDOR',
          'PO',
          POH.TYPE_LOOKUP_CODE,
          POLL.PO_HEADER_ID,
          POH.SEGMENT1,
          POLL.PO_LINE_ID,
          POL.LINE_NUM,
          POLL.LINE_LOCATION_ID,
          POLL.SHIPMENT_NUM,
          POLL.PO_RELEASE_ID,
          POR.RELEASE_NUM,
          TO_NUMBER (NULL),
          NULL,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          RSH.SHIPMENT_HEADER_ID,
          RSH.SHIPMENT_NUM,
          RSL.SHIPMENT_LINE_ID,
          RSL.LINE_NUM,
          NVL (RSL.FROM_ORGANIZATION_ID, POH.PO_HEADER_ID),
          RSL.TO_ORGANIZATION_ID,
          RSH.VENDOR_ID,
          POV.VENDOR_NAME,
          POH.VENDOR_SITE_ID,
          NVL (POLT.OUTSIDE_OPERATION_FLAG, 'N'),
          RSL.ITEM_ID,
          RSL.UNIT_OF_MEASURE,
          MUM.UOM_CLASS,
          NVL (MSI.ALLOWED_UNITS_LOOKUP_CODE, 2),
          NVL (MSI.LOCATION_CONTROL_CODE, 1),
          DECODE (MSI.RESTRICT_LOCATORS_CODE, 1, 'Y', 'N'),
          DECODE (MSI.RESTRICT_SUBINVENTORIES_CODE, 1, 'Y', 'N'),
          NVL (MSI.SHELF_LIFE_CODE, 1),
          NVL (MSI.SHELF_LIFE_DAYS, 0),
          MSI.SERIAL_NUMBER_CONTROL_CODE,
          MSI.LOT_CONTROL_CODE,
          DECODE (MSI.REVISION_QTY_CONTROL_CODE,  1, 'N',  2, 'Y',  'N'),
          NULL,
          NULL ITEM_NUMBER,
          RSL.ITEM_REVISION,
          DECODE (MSI.ALLOW_ITEM_DESC_UPDATE_FLAG,
                  'Y', POL.ITEM_DESCRIPTION,
                  NVL (MSIT.DESCRIPTION, POL.ITEM_DESCRIPTION))
             ITEM_DESCRIPTION,
          RSL.CATEGORY_ID,
          POHC.HAZARD_CLASS,
          POUN.UN_NUMBER,
          RSL.VENDOR_ITEM_NUM,
          RSL.SHIP_TO_LOCATION_ID,
          HL.LOCATION_CODE,
          RSL.PACKING_SLIP,
          RSL.ROUTING_HEADER_ID,
          RCVRH.ROUTING_NAME,
          POLL.NEED_BY_DATE,
          RSH.EXPECTED_RECEIPT_DATE,
          POLL.QUANTITY,
          POL.UNIT_MEAS_LOOKUP_CODE,
          RSL.USSGL_TRANSACTION_CODE,
          RSL.GOVERNMENT_CONTEXT,
          POLL.INSPECTION_REQUIRED_FLAG,
          POLL.RECEIPT_REQUIRED_FLAG,
          POLL.ENFORCE_SHIP_TO_LOCATION_CODE,
          NVL (POLL.PRICE_OVERRIDE, POL.UNIT_PRICE),
          POH.CURRENCY_CODE,
          POH.RATE_TYPE,
          POH.RATE_DATE,
          POH.RATE,
          POH.NOTE_TO_RECEIVER,
          RSL.DESTINATION_TYPE_CODE,
          RSL.DELIVER_TO_PERSON_ID,
          RSL.DELIVER_TO_LOCATION_ID,
          RSL.TO_SUBINVENTORY,
          RSL.ATTRIBUTE_CATEGORY,
          RSL.ATTRIBUTE1,
          RSL.ATTRIBUTE2,
          RSL.ATTRIBUTE3,
          RSL.ATTRIBUTE4,
          RSL.ATTRIBUTE5,
          RSL.ATTRIBUTE6,
          RSL.ATTRIBUTE7,
          RSL.ATTRIBUTE8,
          RSL.ATTRIBUTE9,
          RSL.ATTRIBUTE10,
          RSL.ATTRIBUTE11,
          RSL.ATTRIBUTE12,
          RSL.ATTRIBUTE13,
          RSL.ATTRIBUTE14,
          RSL.ATTRIBUTE15,
          POLL.CLOSED_CODE,
          RSH.ASN_TYPE,
          RSH.BILL_OF_LADING,
          RSH.SHIPPED_DATE,
          RSH.FREIGHT_CARRIER_CODE,
          RSH.WAYBILL_AIRBILL_NUM,
          RSH.FREIGHT_BILL_NUMBER,
          RSL.VENDOR_LOT_NUM,
          RSL.CONTAINER_NUM,
          RSL.TRUCK_NUM,
          RSL.BAR_CODE_LABEL,
          DCT.USER_CONVERSION_TYPE,
          POLL.MATCH_OPTION,
          RSL.COUNTRY_OF_ORIGIN_CODE,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          NULL,
          POLL.NOTE_TO_RECEIVER PLL_NOTE_TO_RECEIVER,
          POLL.SECONDARY_QUANTITY SECONDARY_ORDERED_QTY,
          POLL.SECONDARY_UNIT_OF_MEASURE SECONDARY_ORDERED_UOM,
          POLL.PREFERRED_GRADE QC_GRADE,
          RSL.ASN_LPN_ID,
          DECODE (MSI.TRACKING_QUANTITY_IND,
                  'PS', MSI.SECONDARY_DEFAULT_IND,
                  NULL),
          POLL.ORG_ID,
          TO_NUMBER (NULL),
          RSL.LCM_SHIPMENT_LINE_ID,
          RSL.UNIT_LANDED_COST,
          POLL.LCM_FLAG
     FROM RCV_SHIPMENT_LINES RSL,
          RCV_SHIPMENT_HEADERS RSH,
          PO_HEADERS_ALL         POH,                                           --PO_HEADERS_TRX_V POH,
          PO_LINE_LOCATIONS_TRX_V POLL,
          PO_LINES_TRX_V POL,
          PO_RELEASES_ALL POR,
          PO_VENDORS POV,
          PO_HAZARD_CLASSES_TL POHC,
          PO_UN_NUMBERS_TL POUN,
          RCV_ROUTING_HEADERS RCVRH,
          HR_LOCATIONS_ALL_TL HL,
          MTL_SYSTEM_ITEMS MSI,
          MTL_UNITS_OF_MEASURE MUM,
          PO_LINE_TYPES_B POLT,
          GL_DAILY_CONVERSION_TYPES DCT,
          RCV_PARAMETERS RP,
          MTL_SYSTEM_ITEMS_TL MSIT
    WHERE NVL (POLL.APPROVED_FLAG, 'N') = 'Y'
          AND NVL (POLL.CANCEL_FLAG, 'N') = 'N'
          AND NVL (POLL.CLOSED_CODE, 'OPEN') != 'FINALLY CLOSED'
          AND POLL.SHIPMENT_TYPE IN ('STANDARD', 'BLANKET', 'SCHEDULED')
          AND POH.PO_HEADER_ID = POLL.PO_HEADER_ID
          AND POL.PO_LINE_ID = POLL.PO_LINE_ID
          AND POL.HAZARD_CLASS_ID = POHC.HAZARD_CLASS_ID(+)
          AND POHC.LANGUAGE(+) = USERENV ('LANG')
          AND POL.UN_NUMBER_ID = POUN.UN_NUMBER_ID(+)
          AND POUN.LANGUAGE(+) = USERENV ('LANG')
          AND POLL.PO_RELEASE_ID = POR.PO_RELEASE_ID(+)
          AND RSL.SHIP_TO_LOCATION_ID = HL.LOCATION_ID(+)
          AND HL.LANGUAGE(+) = USERENV ('LANG')
          AND RSH.VENDOR_ID = POV.VENDOR_ID(+)
          AND POL.LINE_TYPE_ID = POLT.LINE_TYPE_ID(+)
          AND RSL.ROUTING_HEADER_ID = RCVRH.ROUTING_HEADER_ID(+)
          AND MUM.UNIT_OF_MEASURE(+) = RSL.UNIT_OF_MEASURE
          AND NVL (MSI.ORGANIZATION_ID, RSL.TO_ORGANIZATION_ID) =
                 RSL.TO_ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID(+) = RSL.ITEM_ID
          AND POLL.LINE_LOCATION_ID = RSL.PO_LINE_LOCATION_ID
          AND RSL.SHIPMENT_HEADER_ID = RSH.SHIPMENT_HEADER_ID
          AND RSH.ASN_TYPE IN ('ASN', 'ASBN')
          AND RSL.SHIPMENT_LINE_STATUS_CODE NOT IN
                 ('CANCELLED', 'FULLY RECEIVED')
          AND DCT.CONVERSION_TYPE(+) = POH.RATE_TYPE
          AND NVL (POH.CONSIGNED_CONSUMPTION_FLAG, 'N') = 'N'
          AND NVL (POR.CONSIGNED_CONSUMPTION_FLAG, 'N') = 'N'
          AND NOT EXISTS
                     (SELECT 1
                        FROM rcv_transactions_interface RT
                       WHERE RT.SHIPMENT_LINE_ID = RSL.SHIPMENT_LINE_ID
                             AND NVL (RT.TRANSACTION_TYPE, 'SHIP') = 'CANCEL'
                             AND NVL (RT.TRANSACTION_STATUS_CODE, 'PENDING') =
                                    'PENDING'
                             AND RT.PO_LINE_LOCATION_ID =
                                    RSL.PO_LINE_LOCATION_ID)
          AND NVL (POLL.MATCHING_BASIS, 'QUANTITY') != 'AMOUNT'
          AND POLL.PAYMENT_TYPE IS NULL
          AND RP.ORGANIZATION_ID = POLL.SHIP_TO_ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID = MSIT.INVENTORY_ITEM_ID(+)
          AND MSI.ORGANIZATION_ID = MSIT.ORGANIZATION_ID(+)
          AND USERENV ('LANG') = MSIT.LANGUAGE(+)
          AND (NVL (RP.PRE_RECEIVE, 'N') = 'N'
               OR (NVL (RP.PRE_RECEIVE, 'N') = 'Y'
                   AND NVL (POLL.LCM_FLAG, 'N') = 'N'));


exit
