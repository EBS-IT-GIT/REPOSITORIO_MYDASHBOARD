  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_RCV_ENTER_RECEIPTS_PO_V" ("LINE_CHKBOX"
                                                                         , "SOURCE_TYPE_CODE"
                                                                         , "RECEIPT_SOURCE_CODE"
                                                                         , "ORDER_TYPE_CODE"
                                                                         , "ORDER_TYPE"
                                                                         , "PO_HEADER_ID"
                                                                         , "PO_NUMBER"
                                                                         , "PO_LINE_ID"
                                                                         , "PO_LINE_NUMBER"
                                                                         , "PO_LINE_LOCATION_ID"
                                                                         , "PO_SHIPMENT_NUMBER"
                                                                         , "PO_RELEASE_ID"
                                                                         , "PO_RELEASE_NUMBER"
                                                                         , "REQ_HEADER_ID"
                                                                         , "REQ_NUMBER"
                                                                         , "REQ_LINE_ID"
                                                                         , "REQ_LINE"
                                                                         , "REQ_DISTRIBUTION_ID"
                                                                         , "RCV_SHIPMENT_HEADER_ID"
                                                                         , "RCV_SHIPMENT_NUMBER"
                                                                         , "RCV_SHIPMENT_LINE_ID"
                                                                         , "RCV_LINE_NUMBER"
                                                                         , "FROM_ORGANIZATION_ID"
                                                                         , "TO_ORGANIZATION_ID"
                                                                         , "VENDOR_ID"
                                                                         , "SOURCE"
                                                                         , "VENDOR_SITE_ID"
                                                                         , "OUTSIDE_OPERATION_FLAG"
                                                                         , "ITEM_ID"
                                                                         , "PRIMARY_UOM"
                                                                         , "PRIMARY_UOM_CLASS"
                                                                         , "ITEM_ALLOWED_UNITS_LOOKUP_CODE"
                                                                         , "ITEM_LOCATOR_CONTROL"
                                                                         , "RESTRICT_LOCATORS_CODE"
                                                                         , "RESTRICT_SUBINVENTORIES_CODE"
                                                                         , "SHELF_LIFE_CODE"
                                                                         , "SHELF_LIFE_DAYS"
                                                                         , "SERIAL_NUMBER_CONTROL_CODE"
                                                                         , "LOT_CONTROL_CODE"
                                                                         , "ITEM_REV_CONTROL_FLAG_TO"
                                                                         , "ITEM_REV_CONTROL_FLAG_FROM"
                                                                         , "ITEM_NUMBER"
                                                                         , "ITEM_REVISION"
                                                                         , "ITEM_DESCRIPTION"
                                                                         , "ITEM_CATEGORY_ID"
                                                                         , "HAZARD_CLASS"
                                                                         , "UN_NUMBER"
                                                                         , "VENDOR_ITEM_NUMBER"
                                                                         , "SHIP_TO_LOCATION_ID"
                                                                         , "SHIP_TO_LOCATION"
                                                                         , "PACKING_SLIP"
                                                                         , "ROUTING_ID"
                                                                         , "ROUTING_NAME"
                                                                         , "NEED_BY_DATE"
                                                                         , "EXPECTED_RECEIPT_DATE"
                                                                         , "ORDERED_QTY"
                                                                         , "ORDERED_UOM"
                                                                         , "USSGL_TRANSACTION_CODE"
                                                                         , "GOVERNMENT_CONTEXT"
                                                                         , "INSPECTION_REQUIRED_FLAG"
                                                                         , "RECEIPT_REQUIRED_FLAG"
                                                                         , "ENFORCE_SHIP_TO_LOCATION_CODE"
                                                                         , "UNIT_PRICE"
                                                                         , "CURRENCY_CODE"
                                                                         , "CURRENCY_CONVERSION_TYPE"
                                                                         , "CURRENCY_CONVERSION_DATE"
                                                                         , "CURRENCY_CONVERSION_RATE"
                                                                         , "NOTE_TO_RECEIVER"
                                                                         , "DESTINATION_TYPE_CODE"
                                                                         , "DELIVER_TO_PERSON_ID"
                                                                         , "DELIVER_TO_LOCATION_ID"
                                                                         , "DESTINATION_SUBINVENTORY"
                                                                         , "ATTRIBUTE_CATEGORY"
                                                                         , "ATTRIBUTE1"
                                                                         , "ATTRIBUTE2"
                                                                         , "ATTRIBUTE3"
                                                                         , "ATTRIBUTE4"
                                                                         , "ATTRIBUTE5"
                                                                         , "ATTRIBUTE6"
                                                                         , "ATTRIBUTE7"
                                                                         , "ATTRIBUTE8"
                                                                         , "ATTRIBUTE9"
                                                                         , "ATTRIBUTE10"
                                                                         , "ATTRIBUTE11"
                                                                         , "ATTRIBUTE12"
                                                                         , "ATTRIBUTE13"
                                                                         , "ATTRIBUTE14"
                                                                         , "ATTRIBUTE15"
                                                                         , "CLOSED_CODE"
                                                                         , "ASN_TYPE"
                                                                         , "BILL_OF_LADING"
                                                                         , "SHIPPED_DATE"
                                                                         , "FREIGHT_CARRIER_CODE"
                                                                         , "WAYBILL_AIRBILL_NUM"
                                                                         , "FREIGHT_BILL_NUM"
                                                                         , "VENDOR_LOT_NUM"
                                                                         , "CONTAINER_NUM"
                                                                         , "TRUCK_NUM"
                                                                         , "BAR_CODE_LABEL"
                                                                         , "RATE_TYPE_DISPLAY"
                                                                         , "MATCH_OPTION"
                                                                         , "COUNTRY_OF_ORIGIN_CODE"
                                                                         , "OE_ORDER_HEADER_ID"
                                                                         , "OE_ORDER_NUM"
                                                                         , "OE_ORDER_LINE_ID"
                                                                         , "OE_ORDER_LINE_NUM"
                                                                         , "CUSTOMER_ID"
                                                                         , "CUSTOMER_SITE_ID"
                                                                         , "CUSTOMER_ITEM_NUM"
                                                                         , "PLL_NOTE_TO_RECEIVER"
                                                                         , "SECONDARY_ORDERED_QTY"
                                                                         , "SECONDARY_ORDERED_UOM"
                                                                         , "QC_GRADE"
                                                                         , "LPN_ID"
                                                                         , "SECONDARY_DEFAULT_IND"
                                                                         , "ORG_ID"
                                                                         , "OE_ORDER_SHIP_NUM"
                                                                         , "LCM_SHIPMENT_LINE_ID"
                                                                         , "UNIT_LANDED_COST"
                                                                         , "LCM_SHIPMENT_FLAG") AS 
  SELECT 'N',
          'VENDOR',
          'VENDOR',
          'PO',
          POH.TYPE_LOOKUP_CODE,
          POLL.PO_HEADER_ID,
          POH.SEGMENT1,
          POLL.PO_LINE_ID,
          POL.LINE_NUM,
          POLL.LINE_LOCATION_ID,
          POLL.SHIPMENT_NUM,
          POLL.PO_RELEASE_ID,
          POR.RELEASE_NUM,
          TO_NUMBER (NULL),
          NULL,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          NULL,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          POH.PO_HEADER_ID,
          POLL.SHIP_TO_ORGANIZATION_ID,
          POH.VENDOR_ID,
          POV.VENDOR_NAME,
          POH.VENDOR_SITE_ID,
          NVL (POLT.OUTSIDE_OPERATION_FLAG, 'N'),
          POL.ITEM_ID,
          POL.UNIT_MEAS_LOOKUP_CODE,
          MUM.UOM_CLASS,
          NVL (MSI.ALLOWED_UNITS_LOOKUP_CODE, 2),
          NVL (MSI.LOCATION_CONTROL_CODE, 1),
          DECODE (MSI.RESTRICT_LOCATORS_CODE, 1, 'Y', 'N'),
          DECODE (MSI.RESTRICT_SUBINVENTORIES_CODE, 1, 'Y', 'N'),
          NVL (MSI.SHELF_LIFE_CODE, 1),
          NVL (MSI.SHELF_LIFE_DAYS, 0),
          MSI.SERIAL_NUMBER_CONTROL_CODE,
          MSI.LOT_CONTROL_CODE,
          DECODE (MSI.REVISION_QTY_CONTROL_CODE,  1, 'N',  2, 'Y',  'N'),
          NULL,
          NULL ITEM_NUMBER,
          POL.ITEM_REVISION,
          DECODE (MSI.ALLOW_ITEM_DESC_UPDATE_FLAG,
                  'Y', POL.ITEM_DESCRIPTION,
                  NVL (MSIT.DESCRIPTION, POL.ITEM_DESCRIPTION))
             ITEM_DESCRIPTION,
          POL.CATEGORY_ID,
          POHC.HAZARD_CLASS,
          POUN.UN_NUMBER,
          POL.VENDOR_PRODUCT_NUM,
          POLL.SHIP_TO_LOCATION_ID,
          HL.LOCATION_CODE,
          NULL,
          POLL.RECEIVING_ROUTING_ID,
          RCVRH.ROUTING_NAME,
          POLL.NEED_BY_DATE,
          NVL (POLL.PROMISED_DATE, POLL.NEED_BY_DATE),
          POLL.QUANTITY,
          POL.UNIT_MEAS_LOOKUP_CODE,
          NULL,
          POLL.GOVERNMENT_CONTEXT,
          POLL.INSPECTION_REQUIRED_FLAG,
          POLL.RECEIPT_REQUIRED_FLAG,
          POLL.ENFORCE_SHIP_TO_LOCATION_CODE,
          NVL (POLL.PRICE_OVERRIDE, POL.UNIT_PRICE),
          POH.CURRENCY_CODE,
          POH.RATE_TYPE,
          POH.RATE_DATE,
          POH.RATE,
          POH.NOTE_TO_RECEIVER,
          NULL,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          NULL,
          POLL.ATTRIBUTE_CATEGORY,
          POLL.ATTRIBUTE1,
          POLL.ATTRIBUTE2,
          POLL.ATTRIBUTE3,
          POLL.ATTRIBUTE4,
          POLL.ATTRIBUTE5,
          POLL.ATTRIBUTE6,
          POLL.ATTRIBUTE7,
          POLL.ATTRIBUTE8,
          POLL.ATTRIBUTE9,
          POLL.ATTRIBUTE10,
          POLL.ATTRIBUTE11,
          POLL.ATTRIBUTE12,
          POLL.ATTRIBUTE13,
          POLL.ATTRIBUTE14,
          POLL.ATTRIBUTE15,
          POLL.CLOSED_CODE,
          NULL,
          NULL,
          TO_DATE (NULL),
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          DCT.USER_CONVERSION_TYPE,
          POLL.MATCH_OPTION,
          POLL.COUNTRY_OF_ORIGIN_CODE,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          NULL,
          POLL.NOTE_TO_RECEIVER PLL_NOTE_TO_RECEIVER,
          POLL.SECONDARY_QUANTITY SECONDARY_ORDERED_QTY,
          POLL.SECONDARY_UNIT_OF_MEASURE SECONDARY_ORDERED_UOM,
          POLL.PREFERRED_GRADE QC_GRADE,
          TO_NUMBER (NULL),
          DECODE (MSI.TRACKING_QUANTITY_IND,
                  'PS', MSI.SECONDARY_DEFAULT_IND,
                  NULL),
          POLL.ORG_ID,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          POLL.LCM_FLAG
     FROM PO_HEADERS_ALL           POH,                                         --PO_HEADERS_TRX_V POH,
          PO_LINE_LOCATIONS_TRX_V POLL,
          PO_LINES_TRX_V POL,
          PO_RELEASES_ALL POR,
          PO_VENDORS POV,
          PO_HAZARD_CLASSES_TL POHC,
          PO_UN_NUMBERS_TL POUN,
          RCV_ROUTING_HEADERS RCVRH,
          HR_LOCATIONS_ALL_TL HL,
          MTL_SYSTEM_ITEMS MSI,
          MTL_UNITS_OF_MEASURE MUM,
          PO_LINE_TYPES_B POLT,
          GL_DAILY_CONVERSION_TYPES DCT,
          RCV_PARAMETERS RP,
          MTL_SYSTEM_ITEMS_TL MSIT
    WHERE     NVL (POLL.APPROVED_FLAG, 'N') = 'Y'
          AND NVL (POLL.CANCEL_FLAG, 'N') = 'N'
          AND NVL (POLL.CLOSED_CODE, 'OPEN') != 'FINALLY CLOSED'
          AND POLL.SHIPMENT_TYPE IN ('STANDARD', 'BLANKET', 'SCHEDULED')
          AND POH.PO_HEADER_ID = POLL.PO_HEADER_ID
          AND POL.PO_LINE_ID = POLL.PO_LINE_ID
          AND POL.HAZARD_CLASS_ID = POHC.HAZARD_CLASS_ID(+)
          AND POHC.LANGUAGE(+) = USERENV ('LANG')
          AND POL.UN_NUMBER_ID = POUN.UN_NUMBER_ID(+)
          AND POUN.LANGUAGE(+) = USERENV ('LANG')
          AND POLL.PO_RELEASE_ID = POR.PO_RELEASE_ID(+)
          AND POLL.SHIP_TO_LOCATION_ID = HL.LOCATION_ID(+)
          AND HL.LANGUAGE(+) = USERENV ('LANG')
          AND POH.VENDOR_ID = POV.VENDOR_ID(+)
          AND POL.LINE_TYPE_ID = POLT.LINE_TYPE_ID(+)
          AND POLL.RECEIVING_ROUTING_ID = RCVRH.ROUTING_HEADER_ID(+)
          AND MUM.UNIT_OF_MEASURE(+) = POL.UNIT_MEAS_LOOKUP_CODE
          AND NVL (MSI.ORGANIZATION_ID, POLL.SHIP_TO_ORGANIZATION_ID) =
                 POLL.SHIP_TO_ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID(+) = POL.ITEM_ID
          AND DCT.CONVERSION_TYPE(+) = POH.RATE_TYPE
          AND NVL (POH.CONSIGNED_CONSUMPTION_FLAG, 'N') = 'N'
          AND NVL (POR.CONSIGNED_CONSUMPTION_FLAG, 'N') = 'N'
          AND NVL (POLL.MATCHING_BASIS, 'QUANTITY') != 'AMOUNT'
          AND POLL.PAYMENT_TYPE IS NULL
          AND RP.ORGANIZATION_ID = POLL.SHIP_TO_ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID = MSIT.INVENTORY_ITEM_ID(+)
          AND MSI.ORGANIZATION_ID = MSIT.ORGANIZATION_ID(+)
          AND USERENV ('LANG') = MSIT.LANGUAGE(+)
          AND (NVL (RP.PRE_RECEIVE, 'N') = 'N'
               OR (NVL (RP.PRE_RECEIVE, 'N') = 'Y'
                   AND NVL (POLL.LCM_FLAG, 'N') = 'N'))
          AND (EXISTS
                  (SELECT 'Not associated to WIP Job'
                     FROM PO_DISTRIBUTIONS_TRX_V POD
                    WHERE POD.LINE_LOCATION_ID = POLL.LINE_LOCATION_ID
                          AND POD.wip_entity_id IS NULL)
               OR EXISTS
                     (SELECT 'Jobs not related to EAM WO/WIP OSP PO'
                        FROM PO_DISTRIBUTIONS_TRX_V POD, WIP_ENTITIES WE
                       WHERE     POD.LINE_LOCATION_ID = POLL.LINE_LOCATION_ID
                             AND POD.WIP_ENTITY_ID = WE.WIP_ENTITY_ID
                             AND WE.ENTITY_TYPE NOT IN (10, 6, 7, 3, 1))
               OR EXISTS
                     (SELECT 'Open EAM WO/WIP OSP Receipts'
                        FROM PO_DISTRIBUTIONS_TRX_V POD,
                             WIP_ENTITIES WE,
                             WIP_DISCRETE_JOBS WDJ
                       WHERE     POD.LINE_LOCATION_ID = POLL.LINE_LOCATION_ID
                             AND POD.WIP_ENTITY_ID = WE.WIP_ENTITY_ID
                             AND WE.WIP_ENTITY_ID = WDJ.WIP_ENTITY_ID
                             AND WE.ENTITY_TYPE IN (6, 1)
                             AND WDJ.STATUS_TYPE IN (3, 4))
               OR EXISTS
                     (SELECT 'Open Process batch Steps'
                        FROM po_distributions_trx_v pod,
                             gme_batch_header gbh,
                             gme_batch_steps gbs
                       WHERE     pod.line_location_id = poll.line_location_id
                             AND pod.wip_entity_id = gbh.batch_id
                             AND pod.WIP_ENTITY_ID = gbs.batch_id
                             AND gbh.batch_id = gbs.batch_id
                             AND pod.WIP_OPERATION_SEQ_NUM = gbs.batchstep_id
                             AND gbs.step_status IN (2, 3)
                             AND NVL (gbh.terminated_ind, 0) <> 1));


exit
