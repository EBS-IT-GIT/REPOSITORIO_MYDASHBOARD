  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_RCV_ENTER_RECEIPTS_INTREQ_V" ("LINE_CHKBOX"
                                                                         , "SOURCE_TYPE_CODE"
                                                                         , "RECEIPT_SOURCE_CODE"
                                                                         , "ORDER_TYPE_CODE"
                                                                         , "ORDER_TYPE"
                                                                         , "PO_HEADER_ID"
                                                                         , "PO_NUMBER"
                                                                         , "PO_LINE_ID"
                                                                         , "PO_LINE_NUMBER"
                                                                         , "PO_LINE_LOCATION_ID"
                                                                         , "PO_SHIPMENT_NUMBER"
                                                                         , "PO_RELEASE_ID"
                                                                         , "PO_RELEASE_NUMBER"
                                                                         , "REQ_HEADER_ID"
                                                                         , "REQ_NUMBER"
                                                                         , "REQ_LINE_ID"
                                                                         , "REQ_LINE"
                                                                         , "REQ_DISTRIBUTION_ID"
                                                                         , "RCV_SHIPMENT_HEADER_ID"
                                                                         , "RCV_SHIPMENT_NUMBER"
                                                                         , "RCV_SHIPMENT_LINE_ID"
                                                                         , "RCV_LINE_NUMBER"
                                                                         , "FROM_ORGANIZATION_ID"
                                                                         , "TO_ORGANIZATION_ID"
                                                                         , "VENDOR_ID"
                                                                         , "SOURCE"
                                                                         , "VENDOR_SITE_ID"
                                                                         , "OUTSIDE_OPERATION_FLAG"
                                                                         , "ITEM_ID"
                                                                         , "PRIMARY_UOM"
                                                                         , "PRIMARY_UOM_CLASS"
                                                                         , "ITEM_ALLOWED_UNITS_LOOKUP_CODE"
                                                                         , "ITEM_LOCATOR_CONTROL"
                                                                         , "RESTRICT_LOCATORS_CODE"
                                                                         , "RESTRICT_SUBINVENTORIES_CODE"
                                                                         , "SHELF_LIFE_CODE"
                                                                         , "SHELF_LIFE_DAYS"
                                                                         , "SERIAL_NUMBER_CONTROL_CODE"
                                                                         , "LOT_CONTROL_CODE"
                                                                         , "ITEM_REV_CONTROL_FLAG_TO"
                                                                         , "ITEM_REV_CONTROL_FLAG_FROM"
                                                                         , "ITEM_NUMBER"
                                                                         , "ITEM_REVISION"
                                                                         , "ITEM_DESCRIPTION"
                                                                         , "ITEM_CATEGORY_ID"
                                                                         , "HAZARD_CLASS"
                                                                         , "UN_NUMBER"
                                                                         , "VENDOR_ITEM_NUMBER"
                                                                         , "SHIP_TO_LOCATION_ID"
                                                                         , "SHIP_TO_LOCATION"
                                                                         , "PACKING_SLIP"
                                                                         , "ROUTING_ID"
                                                                         , "ROUTING_NAME"
                                                                         , "NEED_BY_DATE"
                                                                         , "EXPECTED_RECEIPT_DATE"
                                                                         , "ORDERED_QTY"
                                                                         , "ORDERED_UOM"
                                                                         , "USSGL_TRANSACTION_CODE"
                                                                         , "GOVERNMENT_CONTEXT"
                                                                         , "INSPECTION_REQUIRED_FLAG"
                                                                         , "RECEIPT_REQUIRED_FLAG"
                                                                         , "ENFORCE_SHIP_TO_LOCATION_CODE"
                                                                         , "UNIT_PRICE"
                                                                         , "CURRENCY_CODE"
                                                                         , "CURRENCY_CONVERSION_TYPE"
                                                                         , "CURRENCY_CONVERSION_DATE"
                                                                         , "CURRENCY_CONVERSION_RATE"
                                                                         , "NOTE_TO_RECEIVER"
                                                                         , "DESTINATION_TYPE_CODE"
                                                                         , "DELIVER_TO_PERSON_ID"
                                                                         , "DELIVER_TO_LOCATION_ID"
                                                                         , "DESTINATION_SUBINVENTORY"
                                                                         , "ATTRIBUTE_CATEGORY"
                                                                         , "ATTRIBUTE1"
                                                                         , "ATTRIBUTE2"
                                                                         , "ATTRIBUTE3"
                                                                         , "ATTRIBUTE4"
                                                                         , "ATTRIBUTE5"
                                                                         , "ATTRIBUTE6"
                                                                         , "ATTRIBUTE7"
                                                                         , "ATTRIBUTE8"
                                                                         , "ATTRIBUTE9"
                                                                         , "ATTRIBUTE10"
                                                                         , "ATTRIBUTE11"
                                                                         , "ATTRIBUTE12"
                                                                         , "ATTRIBUTE13"
                                                                         , "ATTRIBUTE14"
                                                                         , "ATTRIBUTE15"
                                                                         , "CLOSED_CODE"
                                                                         , "ASN_TYPE"
                                                                         , "BILL_OF_LADING"
                                                                         , "SHIPPED_DATE"
                                                                         , "FREIGHT_CARRIER_CODE"
                                                                         , "WAYBILL_AIRBILL_NUM"
                                                                         , "FREIGHT_BILL_NUM"
                                                                         , "VENDOR_LOT_NUM"
                                                                         , "CONTAINER_NUM"
                                                                         , "TRUCK_NUM"
                                                                         , "BAR_CODE_LABEL"
                                                                         , "RATE_TYPE_DISPLAY"
                                                                         , "MATCH_OPTION"
                                                                         , "COUNTRY_OF_ORIGIN_CODE"
                                                                         , "OE_ORDER_HEADER_ID"
                                                                         , "OE_ORDER_NUM"
                                                                         , "OE_ORDER_LINE_ID"
                                                                         , "OE_ORDER_LINE_NUM"
                                                                         , "CUSTOMER_ID"
                                                                         , "CUSTOMER_SITE_ID"
                                                                         , "CUSTOMER_ITEM_NUM"
                                                                         , "PLL_NOTE_TO_RECEIVER"
                                                                         , "SECONDARY_ORDERED_QTY"
                                                                         , "SECONDARY_ORDERED_UOM"
                                                                         , "QC_GRADE"
                                                                         , "LPN_ID"
                                                                         , "SECONDARY_DEFAULT_IND"
                                                                         , "ORG_ID"
                                                                         , "OE_ORDER_SHIP_NUM"
                                                                         , "LCM_SHIPMENT_LINE_ID"
                                                                         , "UNIT_LANDED_COST"
                                                                         , "LCM_SHIPMENT_FLAG") AS 
  SELECT 'N',
          'INTERNAL',
          DECODE (RSL.SOURCE_DOCUMENT_CODE, 'REQ', 'INTERNAL ORDER'),
          RSL.SOURCE_DOCUMENT_CODE,
          RSH.RECEIPT_SOURCE_CODE,
          TO_NUMBER (NULL),
          NULL,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          PORH.REQUISITION_HEADER_ID,
          PORH.SEGMENT1,
          PORL.REQUISITION_LINE_ID,
          PORL.LINE_NUM,
          RSL.REQ_DISTRIBUTION_ID,
          RSL.SHIPMENT_HEADER_ID,
          RSH.SHIPMENT_NUM,
          RSL.SHIPMENT_LINE_ID,
          RSL.LINE_NUM,
          RSL.FROM_ORGANIZATION_ID,
          RSL.TO_ORGANIZATION_ID,
          RSL.SHIPMENT_LINE_ID,
          OOD.ORGANIZATION_NAME,
          TO_NUMBER (NULL),
          'N',
          RSL.ITEM_ID,
          RSL.UNIT_OF_MEASURE,
          MUM.UOM_CLASS,
          NVL (MSI.ALLOWED_UNITS_LOOKUP_CODE, 2),
          NVL (MSI.LOCATION_CONTROL_CODE, 1),
          DECODE (MSI.RESTRICT_LOCATORS_CODE, 1, 'Y', 'N'),
          DECODE (MSI.RESTRICT_SUBINVENTORIES_CODE, 1, 'Y', 'N'),
          NVL (MSI.SHELF_LIFE_CODE, 1),
          NVL (MSI.SHELF_LIFE_DAYS, 0),
          MSI.SERIAL_NUMBER_CONTROL_CODE,
          MSI.LOT_CONTROL_CODE,
          DECODE (MSI.REVISION_QTY_CONTROL_CODE,  1, 'N',  2, 'Y',  'N'),
          DECODE (MSI1.REVISION_QTY_CONTROL_CODE,  1, 'N',  2, 'Y',  'N'),
          NULL ITEM_NUMBER,
          RSL.ITEM_REVISION,
          RSL.ITEM_DESCRIPTION,
          RSL.CATEGORY_ID,
          POHC.HAZARD_CLASS,
          POUN.UN_NUMBER,
          RSL.VENDOR_ITEM_NUM,
          RSH.SHIP_TO_LOCATION_ID,
          HL.LOCATION_CODE,
          RSH.PACKING_SLIP,
          RSL.ROUTING_HEADER_ID,
          RCVRH.ROUTING_NAME,
          PORL.NEED_BY_DATE,
          RSH.EXPECTED_RECEIPT_DATE,
          RSL.QUANTITY_SHIPPED,
          RSL.UNIT_OF_MEASURE,
          RSH.USSGL_TRANSACTION_CODE,
          RSH.GOVERNMENT_CONTEXT,
          NULL,
          NULL,
          NULL,
          TO_NUMBER (NULL),
          NULL,
          NULL,
          TO_DATE (NULL),
          TO_NUMBER (NULL),
          PORL.NOTE_TO_RECEIVER,
          RSL.DESTINATION_TYPE_CODE,
          RSL.DELIVER_TO_PERSON_ID,
          RSL.DELIVER_TO_LOCATION_ID,
          RSL.TO_SUBINVENTORY,
          RSL.ATTRIBUTE_CATEGORY,
          RSL.ATTRIBUTE1,
          RSL.ATTRIBUTE2,
          RSL.ATTRIBUTE3,
          RSL.ATTRIBUTE4,
          RSL.ATTRIBUTE5,
          RSL.ATTRIBUTE6,
          RSL.ATTRIBUTE7,
          RSL.ATTRIBUTE8,
          RSL.ATTRIBUTE9,
          RSL.ATTRIBUTE10,
          RSL.ATTRIBUTE11,
          RSL.ATTRIBUTE12,
          RSL.ATTRIBUTE13,
          RSL.ATTRIBUTE14,
          RSL.ATTRIBUTE15,
          'OPEN',
          NULL,
          rsh.bill_of_lading,
          rsh.shipped_date,
          rsh.freight_carrier_code,
          rsh.waybill_airbill_num,
          rsh.freight_bill_number,
          rsl.vendor_lot_num,
          rsl.container_num,
          rsl.truck_num,
          rsl.bar_code_label,
          NULL,
          'P',
          NULL,
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          TO_NUMBER (NULL),
          NULL,
          PORL.NOTE_TO_RECEIVER PLL_NOTE_TO_RECEIVER,
          RSL.SECONDARY_QUANTITY_SHIPPED SECONDARY_ORDERED_QTY,
          RSL.SECONDARY_UNIT_OF_MEASURE SECONDARY_ORDERED_UOM,
          RSL.QC_GRADE QC_GRADE,
          ASN_LPN_ID,
          DECODE (MSI.TRACKING_QUANTITY_IND,
                  'PS', MSI.SECONDARY_DEFAULT_IND,
                  NULL),
          PORL.ORG_ID,
          TO_NUMBER (NULL),
          RSL.LCM_SHIPMENT_LINE_ID,
          RSL.UNIT_LANDED_COST,
          NULL
     FROM RCV_SHIPMENT_HEADERS RSH,
          RCV_SHIPMENT_LINES RSL,
          MTL_SUPPLY MS,
          PO_REQUISITION_HEADERS_ALL PORH,
          PO_REQUISITION_LINES_ALL   PORL,
          PO_HAZARD_CLASSES_TL POHC,
          PO_UN_NUMBERS_TL POUN,
          RCV_ROUTING_HEADERS RCVRH,
          HR_LOCATIONS_ALL_TL HL,
          MTL_SYSTEM_ITEMS MSI,
          MTL_SYSTEM_ITEMS MSI1,
          MTL_UNITS_OF_MEASURE MUM,
          ORG_ORGANIZATION_DEFINITIONS OOD
    WHERE RSH.RECEIPT_SOURCE_CODE = 'INTERNAL ORDER'
          AND RSL.REQUISITION_LINE_ID = PORL.REQUISITION_LINE_ID
          AND PORL.REQUISITION_HEADER_ID = PORH.REQUISITION_HEADER_ID
          AND MS.SUPPLY_TYPE_CODE = 'SHIPMENT'
          AND MS.SHIPMENT_HEADER_ID = RSH.SHIPMENT_HEADER_ID
          AND RSH.SHIPMENT_HEADER_ID = RSL.SHIPMENT_HEADER_ID
          AND RSH.SHIP_TO_LOCATION_ID = HL.LOCATION_ID(+)
          AND HL.LANGUAGE(+) = USERENV ('LANG')
          AND PORL.HAZARD_CLASS_ID = POHC.HAZARD_CLASS_ID(+)
          AND POHC.LANGUAGE(+) = USERENV ('LANG')
          AND PORL.UN_NUMBER_ID = POUN.UN_NUMBER_ID(+)
          AND POUN.LANGUAGE(+) = USERENV ('LANG')
          AND RSL.ROUTING_HEADER_ID = RCVRH.ROUTING_HEADER_ID(+)
          AND MUM.UNIT_OF_MEASURE(+) = RSL.UNIT_OF_MEASURE
          AND MSI.ORGANIZATION_ID(+) = RSL.TO_ORGANIZATION_ID
          AND MSI.INVENTORY_ITEM_ID(+) = RSL.ITEM_ID
          AND MSI1.ORGANIZATION_ID(+) = RSL.FROM_ORGANIZATION_ID
          AND MSI1.INVENTORY_ITEM_ID(+) = RSL.ITEM_ID
          AND OOD.ORGANIZATION_ID = RSL.FROM_ORGANIZATION_ID
          AND MS.SHIPMENT_LINE_ID = RSL.SHIPMENT_LINE_ID;


exit
