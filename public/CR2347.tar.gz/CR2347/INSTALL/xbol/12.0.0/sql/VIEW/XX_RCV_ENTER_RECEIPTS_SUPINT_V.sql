  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_RCV_ENTER_RECEIPTS_SUPINT_V" ("LINE_CHKBOX"
                                                                         , "SOURCE_TYPE_CODE"
                                                                         , "RECEIPT_SOURCE_CODE"
                                                                         , "ORDER_TYPE_CODE"
                                                                         , "ORDER_TYPE"
                                                                         , "PO_HEADER_ID"
                                                                         , "PO_NUMBER"
                                                                         , "PO_LINE_ID"
                                                                         , "PO_LINE_NUMBER"
                                                                         , "PO_LINE_LOCATION_ID"
                                                                         , "PO_SHIPMENT_NUMBER"
                                                                         , "PO_RELEASE_ID"
                                                                         , "PO_RELEASE_NUMBER"
                                                                         , "REQ_HEADER_ID"
                                                                         , "REQ_NUMBER"
                                                                         , "REQ_LINE_ID"
                                                                         , "REQ_LINE"
                                                                         , "REQ_DISTRIBUTION_ID"
                                                                         , "RCV_SHIPMENT_HEADER_ID"
                                                                         , "RCV_SHIPMENT_NUMBER"
                                                                         , "RCV_SHIPMENT_LINE_ID"
                                                                         , "RCV_LINE_NUMBER"
                                                                         , "FROM_ORGANIZATION_ID"
                                                                         , "TO_ORGANIZATION_ID"
                                                                         , "VENDOR_ID"
                                                                         , "SOURCE"
                                                                         , "VENDOR_SITE_ID"
                                                                         , "OUTSIDE_OPERATION_FLAG"
                                                                         , "ITEM_ID"
                                                                         , "PRIMARY_UOM"
                                                                         , "PRIMARY_UOM_CLASS"
                                                                         , "ITEM_ALLOWED_UNITS_LOOKUP_CODE"
                                                                         , "ITEM_LOCATOR_CONTROL"
                                                                         , "RESTRICT_LOCATORS_CODE"
                                                                         , "RESTRICT_SUBINVENTORIES_CODE"
                                                                         , "SHELF_LIFE_CODE"
                                                                         , "SHELF_LIFE_DAYS"
                                                                         , "SERIAL_NUMBER_CONTROL_CODE"
                                                                         , "LOT_CONTROL_CODE"
                                                                         , "ITEM_REV_CONTROL_FLAG_TO"
                                                                         , "ITEM_REV_CONTROL_FLAG_FROM"
                                                                         , "ITEM_NUMBER"
                                                                         , "ITEM_REVISION"
                                                                         , "ITEM_DESCRIPTION"
                                                                         , "ITEM_CATEGORY_ID"
                                                                         , "HAZARD_CLASS"
                                                                         , "UN_NUMBER"
                                                                         , "VENDOR_ITEM_NUMBER"
                                                                         , "SHIP_TO_LOCATION_ID"
                                                                         , "SHIP_TO_LOCATION"
                                                                         , "PACKING_SLIP"
                                                                         , "ROUTING_ID"
                                                                         , "ROUTING_NAME"
                                                                         , "NEED_BY_DATE"
                                                                         , "EXPECTED_RECEIPT_DATE"
                                                                         , "ORDERED_QTY"
                                                                         , "ORDERED_UOM"
                                                                         , "USSGL_TRANSACTION_CODE"
                                                                         , "GOVERNMENT_CONTEXT"
                                                                         , "INSPECTION_REQUIRED_FLAG"
                                                                         , "RECEIPT_REQUIRED_FLAG"
                                                                         , "ENFORCE_SHIP_TO_LOCATION_CODE"
                                                                         , "UNIT_PRICE"
                                                                         , "CURRENCY_CODE"
                                                                         , "CURRENCY_CONVERSION_TYPE"
                                                                         , "CURRENCY_CONVERSION_DATE"
                                                                         , "CURRENCY_CONVERSION_RATE"
                                                                         , "NOTE_TO_RECEIVER"
                                                                         , "DESTINATION_TYPE_CODE"
                                                                         , "DELIVER_TO_PERSON_ID"
                                                                         , "DELIVER_TO_LOCATION_ID"
                                                                         , "DESTINATION_SUBINVENTORY"
                                                                         , "ATTRIBUTE_CATEGORY"
                                                                         , "ATTRIBUTE1"
                                                                         , "ATTRIBUTE2"
                                                                         , "ATTRIBUTE3"
                                                                         , "ATTRIBUTE4"
                                                                         , "ATTRIBUTE5"
                                                                         , "ATTRIBUTE6"
                                                                         , "ATTRIBUTE7"
                                                                         , "ATTRIBUTE8"
                                                                         , "ATTRIBUTE9"
                                                                         , "ATTRIBUTE10"
                                                                         , "ATTRIBUTE11"
                                                                         , "ATTRIBUTE12"
                                                                         , "ATTRIBUTE13"
                                                                         , "ATTRIBUTE14"
                                                                         , "ATTRIBUTE15"
                                                                         , "CLOSED_CODE"
                                                                         , "ASN_TYPE"
                                                                         , "BILL_OF_LADING"
                                                                         , "SHIPPED_DATE"
                                                                         , "FREIGHT_CARRIER_CODE"
                                                                         , "WAYBILL_AIRBILL_NUM"
                                                                         , "FREIGHT_BILL_NUM"
                                                                         , "VENDOR_LOT_NUM"
                                                                         , "CONTAINER_NUM"
                                                                         , "TRUCK_NUM"
                                                                         , "BAR_CODE_LABEL"
                                                                         , "RATE_TYPE_DISPLAY"
                                                                         , "MATCH_OPTION"
                                                                         , "COUNTRY_OF_ORIGIN_CODE"
                                                                         , "OE_ORDER_HEADER_ID"
                                                                         , "OE_ORDER_NUM"
                                                                         , "OE_ORDER_LINE_ID"
                                                                         , "OE_ORDER_LINE_NUM"
                                                                         , "CUSTOMER_ID"
                                                                         , "CUSTOMER_SITE_ID"
                                                                         , "CUSTOMER_ITEM_NUM"
                                                                         , "PLL_NOTE_TO_RECEIVER"
                                                                         , "SECONDARY_ORDERED_QTY"
                                                                         , "SECONDARY_ORDERED_UOM"
                                                                         , "QC_GRADE"
                                                                         , "LPN_ID"
                                                                         , "SECONDARY_DEFAULT_IND"
                                                                         , "ORG_ID"
                                                                         , "OE_ORDER_SHIP_NUM"
                                                                         , "LCM_SHIPMENT_LINE_ID"
                                                                         , "UNIT_LANDED_COST"
                                                                         , "LCM_SHIPMENT_FLAG") AS 
  SELECT       /*+ opt_param('_optimizer_cost_based_transformation','off') */
         LINE_CHKBOX,
          SOURCE_TYPE_CODE,
          RECEIPT_SOURCE_CODE,
          ORDER_TYPE_CODE,
          ORDER_TYPE,
          PO_HEADER_ID,
          PO_NUMBER,
          PO_LINE_ID,
          PO_LINE_NUMBER,
          PO_LINE_LOCATION_ID,
          PO_SHIPMENT_NUMBER,
          PO_RELEASE_ID,
          PO_RELEASE_NUMBER,
          REQ_HEADER_ID,
          REQ_NUMBER,
          REQ_LINE_ID,
          REQ_LINE,
          REQ_DISTRIBUTION_ID,
          RCV_SHIPMENT_HEADER_ID,
          RCV_SHIPMENT_NUMBER,
          RCV_SHIPMENT_LINE_ID,
          RCV_LINE_NUMBER,
          FROM_ORGANIZATION_ID,
          TO_ORGANIZATION_ID,
          VENDOR_ID,
          SOURCE,
          VENDOR_SITE_ID,
          OUTSIDE_OPERATION_FLAG,
          ITEM_ID,
          PRIMARY_UOM,
          PRIMARY_UOM_CLASS,
          ITEM_ALLOWED_UNITS_LOOKUP_CODE,
          ITEM_LOCATOR_CONTROL,
          RESTRICT_LOCATORS_CODE,
          RESTRICT_SUBINVENTORIES_CODE,
          SHELF_LIFE_CODE,
          SHELF_LIFE_DAYS,
          SERIAL_NUMBER_CONTROL_CODE,
          LOT_CONTROL_CODE,
          ITEM_REV_CONTROL_FLAG_TO,
          ITEM_REV_CONTROL_FLAG_FROM,
          ITEM_NUMBER,
          ITEM_REVISION,
          ITEM_DESCRIPTION,
          ITEM_CATEGORY_ID,
          HAZARD_CLASS,
          UN_NUMBER,
          VENDOR_ITEM_NUMBER,
          SHIP_TO_LOCATION_ID,
          SHIP_TO_LOCATION,
          PACKING_SLIP,
          ROUTING_ID,
          ROUTING_NAME,
          NEED_BY_DATE,
          EXPECTED_RECEIPT_DATE,
          ORDERED_QTY,
          ORDERED_UOM,
          USSGL_TRANSACTION_CODE,
          GOVERNMENT_CONTEXT,
          INSPECTION_REQUIRED_FLAG,
          RECEIPT_REQUIRED_FLAG,
          ENFORCE_SHIP_TO_LOCATION_CODE,
          UNIT_PRICE,
          CURRENCY_CODE,
          CURRENCY_CONVERSION_TYPE,
          CURRENCY_CONVERSION_DATE,
          CURRENCY_CONVERSION_RATE,
          NOTE_TO_RECEIVER,
          DESTINATION_TYPE_CODE,
          DELIVER_TO_PERSON_ID,
          DELIVER_TO_LOCATION_ID,
          DESTINATION_SUBINVENTORY,
          ATTRIBUTE_CATEGORY,
          ATTRIBUTE1,
          ATTRIBUTE2,
          ATTRIBUTE3,
          ATTRIBUTE4,
          ATTRIBUTE5,
          ATTRIBUTE6,
          ATTRIBUTE7,
          ATTRIBUTE8,
          ATTRIBUTE9,
          ATTRIBUTE10,
          ATTRIBUTE11,
          ATTRIBUTE12,
          ATTRIBUTE13,
          ATTRIBUTE14,
          ATTRIBUTE15,
          CLOSED_CODE,
          ASN_TYPE,
          BILL_OF_LADING,
          SHIPPED_DATE,
          FREIGHT_CARRIER_CODE,
          WAYBILL_AIRBILL_NUM,
          FREIGHT_BILL_NUM,
          VENDOR_LOT_NUM,
          CONTAINER_NUM,
          TRUCK_NUM,
          BAR_CODE_LABEL,
          RATE_TYPE_DISPLAY,
          MATCH_OPTION,
          COUNTRY_OF_ORIGIN_CODE,
          OE_ORDER_HEADER_ID,
          OE_ORDER_NUM,
          OE_ORDER_LINE_ID,
          OE_ORDER_LINE_NUM,
          CUSTOMER_ID,
          CUSTOMER_SITE_ID,
          CUSTOMER_ITEM_NUM,
          PLL_NOTE_TO_RECEIVER,
          SECONDARY_ORDERED_QTY,
          SECONDARY_ORDERED_UOM,
          QC_GRADE,
          LPN_ID,
          SECONDARY_DEFAULT_IND,
          ORG_ID,
          OE_ORDER_SHIP_NUM,
          LCM_SHIPMENT_LINE_ID,
          UNIT_LANDED_COST,
          LCM_SHIPMENT_FLAG
     FROM XX_RCV_ENTER_RECEIPTS_PO_V                                            -- RCV_ENTER_RECEIPTS_PO_V
   UNION ALL
   SELECT LINE_CHKBOX,
          SOURCE_TYPE_CODE,
          RECEIPT_SOURCE_CODE,
          ORDER_TYPE_CODE,
          ORDER_TYPE,
          PO_HEADER_ID,
          PO_NUMBER,
          PO_LINE_ID,
          PO_LINE_NUMBER,
          PO_LINE_LOCATION_ID,
          PO_SHIPMENT_NUMBER,
          PO_RELEASE_ID,
          PO_RELEASE_NUMBER,
          REQ_HEADER_ID,
          REQ_NUMBER,
          REQ_LINE_ID,
          REQ_LINE,
          REQ_DISTRIBUTION_ID,
          RCV_SHIPMENT_HEADER_ID,
          RCV_SHIPMENT_NUMBER,
          RCV_SHIPMENT_LINE_ID,
          RCV_LINE_NUMBER,
          FROM_ORGANIZATION_ID,
          TO_ORGANIZATION_ID,
          VENDOR_ID,
          SOURCE,
          VENDOR_SITE_ID,
          OUTSIDE_OPERATION_FLAG,
          ITEM_ID,
          PRIMARY_UOM,
          PRIMARY_UOM_CLASS,
          ITEM_ALLOWED_UNITS_LOOKUP_CODE,
          ITEM_LOCATOR_CONTROL,
          RESTRICT_LOCATORS_CODE,
          RESTRICT_SUBINVENTORIES_CODE,
          SHELF_LIFE_CODE,
          SHELF_LIFE_DAYS,
          SERIAL_NUMBER_CONTROL_CODE,
          LOT_CONTROL_CODE,
          ITEM_REV_CONTROL_FLAG_TO,
          ITEM_REV_CONTROL_FLAG_FROM,
          ITEM_NUMBER,
          ITEM_REVISION,
          ITEM_DESCRIPTION,
          ITEM_CATEGORY_ID,
          HAZARD_CLASS,
          UN_NUMBER,
          VENDOR_ITEM_NUMBER,
          SHIP_TO_LOCATION_ID,
          SHIP_TO_LOCATION,
          PACKING_SLIP,
          ROUTING_ID,
          ROUTING_NAME,
          NEED_BY_DATE,
          EXPECTED_RECEIPT_DATE,
          ORDERED_QTY,
          ORDERED_UOM,
          USSGL_TRANSACTION_CODE,
          GOVERNMENT_CONTEXT,
          INSPECTION_REQUIRED_FLAG,
          RECEIPT_REQUIRED_FLAG,
          ENFORCE_SHIP_TO_LOCATION_CODE,
          UNIT_PRICE,
          CURRENCY_CODE,
          CURRENCY_CONVERSION_TYPE,
          CURRENCY_CONVERSION_DATE,
          CURRENCY_CONVERSION_RATE,
          NOTE_TO_RECEIVER,
          DESTINATION_TYPE_CODE,
          DELIVER_TO_PERSON_ID,
          DELIVER_TO_LOCATION_ID,
          DESTINATION_SUBINVENTORY,
          ATTRIBUTE_CATEGORY,
          ATTRIBUTE1,
          ATTRIBUTE2,
          ATTRIBUTE3,
          ATTRIBUTE4,
          ATTRIBUTE5,
          ATTRIBUTE6,
          ATTRIBUTE7,
          ATTRIBUTE8,
          ATTRIBUTE9,
          ATTRIBUTE10,
          ATTRIBUTE11,
          ATTRIBUTE12,
          ATTRIBUTE13,
          ATTRIBUTE14,
          ATTRIBUTE15,
          CLOSED_CODE,
          ASN_TYPE,
          BILL_OF_LADING,
          SHIPPED_DATE,
          FREIGHT_CARRIER_CODE,
          WAYBILL_AIRBILL_NUM,
          FREIGHT_BILL_NUM,
          VENDOR_LOT_NUM,
          CONTAINER_NUM,
          TRUCK_NUM,
          BAR_CODE_LABEL,
          RATE_TYPE_DISPLAY,
          MATCH_OPTION,
          COUNTRY_OF_ORIGIN_CODE,
          OE_ORDER_HEADER_ID,
          OE_ORDER_NUM,
          OE_ORDER_LINE_ID,
          OE_ORDER_LINE_NUM,
          CUSTOMER_ID,
          CUSTOMER_SITE_ID,
          CUSTOMER_ITEM_NUM,
          PLL_NOTE_TO_RECEIVER,
          SECONDARY_ORDERED_QTY,
          SECONDARY_ORDERED_UOM,
          QC_GRADE,
          LPN_ID,
          SECONDARY_DEFAULT_IND,
          ORG_ID,
          OE_ORDER_SHIP_NUM,
          LCM_SHIPMENT_LINE_ID,
          UNIT_LANDED_COST,
          LCM_SHIPMENT_FLAG
     FROM XX_RCV_ENTER_RECEIPTS_INTREQ_V                                        --RCV_ENTER_RECEIPTS_INT_REQ_V
   UNION ALL
   SELECT LINE_CHKBOX,
          SOURCE_TYPE_CODE,
          RECEIPT_SOURCE_CODE,
          ORDER_TYPE_CODE,
          ORDER_TYPE,
          PO_HEADER_ID,
          PO_NUMBER,
          PO_LINE_ID,
          PO_LINE_NUMBER,
          PO_LINE_LOCATION_ID,
          PO_SHIPMENT_NUMBER,
          PO_RELEASE_ID,
          PO_RELEASE_NUMBER,
          REQ_HEADER_ID,
          REQ_NUMBER,
          REQ_LINE_ID,
          REQ_LINE,
          REQ_DISTRIBUTION_ID,
          RCV_SHIPMENT_HEADER_ID,
          RCV_SHIPMENT_NUMBER,
          RCV_SHIPMENT_LINE_ID,
          RCV_LINE_NUMBER,
          FROM_ORGANIZATION_ID,
          TO_ORGANIZATION_ID,
          VENDOR_ID,
          SOURCE,
          VENDOR_SITE_ID,
          OUTSIDE_OPERATION_FLAG,
          ITEM_ID,
          PRIMARY_UOM,
          PRIMARY_UOM_CLASS,
          ITEM_ALLOWED_UNITS_LOOKUP_CODE,
          ITEM_LOCATOR_CONTROL,
          RESTRICT_LOCATORS_CODE,
          RESTRICT_SUBINVENTORIES_CODE,
          SHELF_LIFE_CODE,
          SHELF_LIFE_DAYS,
          SERIAL_NUMBER_CONTROL_CODE,
          LOT_CONTROL_CODE,
          ITEM_REV_CONTROL_FLAG_TO,
          ITEM_REV_CONTROL_FLAG_FROM,
          ITEM_NUMBER,
          ITEM_REVISION,
          ITEM_DESCRIPTION,
          ITEM_CATEGORY_ID,
          HAZARD_CLASS,
          UN_NUMBER,
          VENDOR_ITEM_NUMBER,
          SHIP_TO_LOCATION_ID,
          SHIP_TO_LOCATION,
          PACKING_SLIP,
          ROUTING_ID,
          ROUTING_NAME,
          NEED_BY_DATE,
          EXPECTED_RECEIPT_DATE,
          ORDERED_QTY,
          ORDERED_UOM,
          USSGL_TRANSACTION_CODE,
          GOVERNMENT_CONTEXT,
          INSPECTION_REQUIRED_FLAG,
          RECEIPT_REQUIRED_FLAG,
          ENFORCE_SHIP_TO_LOCATION_CODE,
          UNIT_PRICE,
          CURRENCY_CODE,
          CURRENCY_CONVERSION_TYPE,
          CURRENCY_CONVERSION_DATE,
          CURRENCY_CONVERSION_RATE,
          NOTE_TO_RECEIVER,
          DESTINATION_TYPE_CODE,
          DELIVER_TO_PERSON_ID,
          DELIVER_TO_LOCATION_ID,
          DESTINATION_SUBINVENTORY,
          ATTRIBUTE_CATEGORY,
          ATTRIBUTE1,
          ATTRIBUTE2,
          ATTRIBUTE3,
          ATTRIBUTE4,
          ATTRIBUTE5,
          ATTRIBUTE6,
          ATTRIBUTE7,
          ATTRIBUTE8,
          ATTRIBUTE9,
          ATTRIBUTE10,
          ATTRIBUTE11,
          ATTRIBUTE12,
          ATTRIBUTE13,
          ATTRIBUTE14,
          ATTRIBUTE15,
          CLOSED_CODE,
          ASN_TYPE,
          BILL_OF_LADING,
          SHIPPED_DATE,
          FREIGHT_CARRIER_CODE,
          WAYBILL_AIRBILL_NUM,
          FREIGHT_BILL_NUM,
          VENDOR_LOT_NUM,
          CONTAINER_NUM,
          TRUCK_NUM,
          BAR_CODE_LABEL,
          RATE_TYPE_DISPLAY,
          MATCH_OPTION,
          COUNTRY_OF_ORIGIN_CODE,
          OE_ORDER_HEADER_ID,
          OE_ORDER_NUM,
          OE_ORDER_LINE_ID,
          OE_ORDER_LINE_NUM,
          CUSTOMER_ID,
          CUSTOMER_SITE_ID,
          CUSTOMER_ITEM_NUM,
          PLL_NOTE_TO_RECEIVER,
          SECONDARY_ORDERED_QTY,
          SECONDARY_ORDERED_UOM,
          QC_GRADE,
          LPN_ID,
          SECONDARY_DEFAULT_IND,
          ORG_ID,
          OE_ORDER_SHIP_NUM,
          LCM_SHIPMENT_LINE_ID,
          UNIT_LANDED_COST,
          LCM_SHIPMENT_FLAG
     FROM RCV_ENTER_RECEIPTS_INVENTORY_V
   UNION ALL
   SELECT LINE_CHKBOX,
          SOURCE_TYPE_CODE,
          RECEIPT_SOURCE_CODE,
          ORDER_TYPE_CODE,
          ORDER_TYPE,
          PO_HEADER_ID,
          PO_NUMBER,
          PO_LINE_ID,
          PO_LINE_NUMBER,
          PO_LINE_LOCATION_ID,
          PO_SHIPMENT_NUMBER,
          PO_RELEASE_ID,
          PO_RELEASE_NUMBER,
          REQ_HEADER_ID,
          REQ_NUMBER,
          REQ_LINE_ID,
          REQ_LINE,
          REQ_DISTRIBUTION_ID,
          RCV_SHIPMENT_HEADER_ID,
          RCV_SHIPMENT_NUMBER,
          RCV_SHIPMENT_LINE_ID,
          RCV_LINE_NUMBER,
          FROM_ORGANIZATION_ID,
          TO_ORGANIZATION_ID,
          VENDOR_ID,
          SOURCE,
          VENDOR_SITE_ID,
          OUTSIDE_OPERATION_FLAG,
          ITEM_ID,
          PRIMARY_UOM,
          PRIMARY_UOM_CLASS,
          ITEM_ALLOWED_UNITS_LOOKUP_CODE,
          ITEM_LOCATOR_CONTROL,
          RESTRICT_LOCATORS_CODE,
          RESTRICT_SUBINVENTORIES_CODE,
          SHELF_LIFE_CODE,
          SHELF_LIFE_DAYS,
          SERIAL_NUMBER_CONTROL_CODE,
          LOT_CONTROL_CODE,
          ITEM_REV_CONTROL_FLAG_TO,
          ITEM_REV_CONTROL_FLAG_FROM,
          ITEM_NUMBER,
          ITEM_REVISION,
          ITEM_DESCRIPTION,
          ITEM_CATEGORY_ID,
          HAZARD_CLASS,
          UN_NUMBER,
          VENDOR_ITEM_NUMBER,
          SHIP_TO_LOCATION_ID,
          SHIP_TO_LOCATION,
          PACKING_SLIP,
          ROUTING_ID,
          ROUTING_NAME,
          NEED_BY_DATE,
          EXPECTED_RECEIPT_DATE,
          ORDERED_QTY,
          ORDERED_UOM,
          USSGL_TRANSACTION_CODE,
          GOVERNMENT_CONTEXT,
          INSPECTION_REQUIRED_FLAG,
          RECEIPT_REQUIRED_FLAG,
          ENFORCE_SHIP_TO_LOCATION_CODE,
          UNIT_PRICE,
          CURRENCY_CODE,
          CURRENCY_CONVERSION_TYPE,
          CURRENCY_CONVERSION_DATE,
          CURRENCY_CONVERSION_RATE,
          NOTE_TO_RECEIVER,
          DESTINATION_TYPE_CODE,
          DELIVER_TO_PERSON_ID,
          DELIVER_TO_LOCATION_ID,
          DESTINATION_SUBINVENTORY,
          ATTRIBUTE_CATEGORY,
          ATTRIBUTE1,
          ATTRIBUTE2,
          ATTRIBUTE3,
          ATTRIBUTE4,
          ATTRIBUTE5,
          ATTRIBUTE6,
          ATTRIBUTE7,
          ATTRIBUTE8,
          ATTRIBUTE9,
          ATTRIBUTE10,
          ATTRIBUTE11,
          ATTRIBUTE12,
          ATTRIBUTE13,
          ATTRIBUTE14,
          ATTRIBUTE15,
          CLOSED_CODE,
          ASN_TYPE,
          BILL_OF_LADING,
          SHIPPED_DATE,
          FREIGHT_CARRIER_CODE,
          WAYBILL_AIRBILL_NUM,
          FREIGHT_BILL_NUM,
          VENDOR_LOT_NUM,
          CONTAINER_NUM,
          TRUCK_NUM,
          BAR_CODE_LABEL,
          RATE_TYPE_DISPLAY,
          MATCH_OPTION,
          COUNTRY_OF_ORIGIN_CODE,
          OE_ORDER_HEADER_ID,
          OE_ORDER_NUM,
          OE_ORDER_LINE_ID,
          OE_ORDER_LINE_NUM,
          CUSTOMER_ID,
          CUSTOMER_SITE_ID,
          CUSTOMER_ITEM_NUM,
          PLL_NOTE_TO_RECEIVER,
          SECONDARY_ORDERED_QTY,
          SECONDARY_ORDERED_UOM,
          QC_GRADE,
          LPN_ID,
          SECONDARY_DEFAULT_IND,
          ORG_ID,
          OE_ORDER_SHIP_NUM,
          LCM_SHIPMENT_LINE_ID,
          UNIT_LANDED_COST,
          LCM_SHIPMENT_FLAG
     FROM XX_RCV_ENTER_RECEIPTS_ASN_V;


exit
