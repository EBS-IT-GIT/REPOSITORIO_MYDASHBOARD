#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2347_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2347
# |
# | HISTORY
# |   08-JUN-20  Silva, Alejandra - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2347_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2347_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2347
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/VALSET
mkdir -p xbol/12.0.0/reports/US/
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/VIEW
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT



echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_PO_CALCULOS_PKG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_PO_CALCULOS_PKG','APPS','$PATCHDIR','CR2347');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_PO_CALCULOS_PKG* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_HR_UNIDADES_OPERATIVAS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_HR_UNIDADES_OPERATIVAS.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_HR_UNIDADES_OPERATIVAS"
AddAllLogs $CROUT "FND" "XX_HR_UNIDADES_OPERATIVAS.ldt"
mv XX_HR_UNIDADES_OPERATIVAS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_ORGANIZATION_DEFINITIONS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_ORGANIZATION_DEFINITIONS.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_ORGANIZATION_DEFINITIONS"
AddAllLogs $CROUT "FND" "XX_ORGANIZATION_DEFINITIONS.ldt"
mv XX_ORGANIZATION_DEFINITIONS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XXPORPSI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XXPORPSI.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XXPORPSI"
AddAllLogs $CROUT "FND" "XXPORPSI.ldt"
mv XXPORPSI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXPORPSI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXPORPSI.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXPORPSI"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXPORPSI \
-LANGUAGE "es" \
-TERRITORY "00" \
-LOG_FILE XXPORPSI_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXPORPSI.ldt"
mv XXPORPSI* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto REPORTS- XXPORPSI " >> $CROUT; echo "" >> $CROUT
cp $XBOL_TOP/reports/US/XXPORPSI.rdf XXPORPSI.rdf
echo `ls -lh XXPORPSI.rdf` >> $CROUT

mv XXPORPSI* $DOWNDBDIR/xbol/12.0.0/reports/US/


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_RCV_ENTER_RECEIPTS_PO_V " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_PO_V >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_PO_V.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_PO_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_PO_V.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_PO_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_PO_V.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_RCV_ENTER_RECEIPTS_INTREQ_V " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_INTREQ_V >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_INTREQ_V.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_INTREQ_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_INTREQ_V.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_INTREQ_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_INTREQ_V.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_RCV_ENTER_RECEIPTS_ASN_V " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_ASN_V >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_ASN_V.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_ASN_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_ASN_V.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_ASN_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_ASN_V.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_RCV_ENTER_RECEIPTS_SUPINT_V " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_SUPINT_V >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_SUPINT_V.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_SUPINT_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_SUPINT_V.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_SUPINT_V.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_RCV_ENTER_RECEIPTS_SUPINT_V.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_PO_CALCULOS_PKG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_PO_CALCULOS_PKG >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_PO_CALCULOS_PKG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_PO_CALCULOS_PKG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_PO_CALCULOS_PKG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_PO_CALCULOS_PKG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_PO_CALCULOS_PKG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_HR_UNIDADES_OPERATIVAS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_HR_UNIDADES_OPERATIVAS.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_ORGANIZATION_DEFINITIONS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_ORGANIZATION_DEFINITIONS.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XXPORPSI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt CUSTOM_MODE=FORCE


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO Reports CHS' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO Reports CHS' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO All Reports Corp' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO All Reports Corp' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO All Reports ADU' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO All Reports ADU' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XXPORPSI' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX PO All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XXPORPSI.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXPORPSI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXPORPSI \
-LANGUAGE "es" \
-TERRITORY "00" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI_es.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXPORPSI_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI_es.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI_es.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI_es.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI_es.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXPORPSI_es.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto REPORTS- XXPORPSI " >> $CROUT; echo "" >> $CROUT
`cp $INSTDIR/xbol/12.0.0/reports/US/XXPORPSI.rdf $XBOL_TOP/reports/US`
echo `ls -lh $XBOL_TOP/reports/US/XXPORPSI.rdf` >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/XXPORPSI.rdf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/reports/US/XXPORPSI.rdf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/XXPORPSI.rdf  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/reports/US/XXPORPSI.rdf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/reports/US/XXPORPSI.rdf -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto REPORTS- XXPORPSI " >> $CROUT; echo "" >> $CROUT
cp $INSTDIR/xbol/12.0.0/reports/US/XXPORPSI.rdf $XBOL_TOP/reports/US

. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2347" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2347_9407.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2347_9407.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
