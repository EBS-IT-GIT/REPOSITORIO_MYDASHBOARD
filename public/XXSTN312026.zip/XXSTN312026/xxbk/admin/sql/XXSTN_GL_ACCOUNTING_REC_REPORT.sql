-- $Header: XXSTN_GL_ACCOUNTING_REC_REPORT.pkg 120.1 2020/04/13 19:55:08 ninecon noship $
create or replace procedure      XXSTN_GL_ACCOUNTING_REC_REPORT (errbuf             out varchar2,
                                                                 retcode            out varchar2,
                                                                 p_livro             in number,
                                                                 p_organization_id   in number,
                                                                 p_period_name       in varchar2,
                                                                 p_operation_id_ini  in number,
                                                                 p_operation_id_fin  in number) is
--
--
--+=================================================================+
--|               NINECON, SAO PAULO, BRASIL                        |
--|                  ALL RIGHTS RESERVED                            |
--+=================================================================+
--| FILENAME                                                        |
--|  XXSTN_GL_ACCOUNTING_REC_REPORT.sql                             |
--| PURPOSE                                                         |
--|  SCRIPT DE CRIACAO DA PROCEDURE XXSTN_GL_ACCOUNTING_REC_REPORT  |
--|                                                                 |
--| DESCRIPTION                                                     |
--|       Geração de relatório contábil dos lançamentos de notas    |
--|   fiscais registrados no módulo RI.                             |
--|                                                                 |
--| PARAMETERS                                                      |
--|                                                                 |
--| CREATED BY    Ademir Castilho     30/12/2019                    |
--| UPDATED BY                                                      |
--|                                                                 |
--+=================================================================+
--
--
  cursor account is
    select gb.name                                                                nome_lote,
           gh.name                                                                nome_lancamento,
           mtl.organization_code||'-'||hr.name                                    organizacao,
           gl.reference_2                                                         nr_ri,
           gl.je_line_num                                                         nr_linha,
           led.name                                                               livro_contabil,
           gcc.segment1||'.'||gcc.segment2||'.'||gcc.segment3||'.'||gcc.segment4||'.'||gcc.segment5||'.'||gcc.segment6||'.'||gcc.segment7||'.'||gcc.segment8 combinacao_contabil,
           gh.period_name                                                         periodo,
           gl.effective_date                                                      data_contabil,
           decode(gl.status,'P','Contabilizado','U','Nao Contabilizado')          status,
           gl.accounted_dr                                                        vl_debito_contabilizado,
           gl.accounted_cr                                                        vl_cred_contabilizado,
           gl.description                                                         descricao_lancamento    
    from apps.gl_je_lines               gl,
         apps.gl_code_combinations      gcc,
         apps.gl_je_headers             gh,
         apps.gl_je_sources             gs,
         apps.gl_je_categories          gc,
         apps.gl_ledgers                led,
         apps.gl_je_batches             gb,
         apps.mtl_parameters            mtl,
         apps.hr_all_organization_units hr
    where gb.je_batch_id            = gh.je_batch_id
    and   gl.je_header_id           = gh.je_header_id
    and   gh.je_source              = gs.je_source_name
    and   gh.je_category            = gc.je_category_name
    and   gcc.code_combination_id   = gl.code_combination_id
    and   gl.ledger_id              = p_livro
    and   gl.ledger_id              = led.ledger_id
    and   gl.reference_1            = mtl.organization_id
    and   mtl.organization_id       = hr.organization_id
    and   gh.je_source              = '2'
    and   gh.actual_flag            = 'A'
    and   gl.reference_1            = p_organization_id
    and   to_number(gl.reference_2) between nvl(p_operation_id_ini, 0) and nvl(p_operation_id_fin, 9999999999)
    and   gh.period_name            = nvl(p_period_name, gh.period_name)
    order by led.name                           ,
             gb.name                            ,
             mtl.organization_code||'-'||hr.name, 
             gl.reference_2,
             gl.je_line_num;
  --
  l_rec_count              number  := 0;
  l_org_code               apps.mtl_parameters.organization_code%type;
  --
begin
  select organization_code
  into l_org_code
  from apps.mtl_parameters
  where organization_id = p_organization_id;
  --
  fnd_file.put_line(fnd_file.log, 'Parâmetros:');
  fnd_file.put_line(fnd_file.log, 'Org. Inventário : '||l_org_code);
  fnd_file.put_line(fnd_file.log, 'Período         : '||p_period_name);
  fnd_file.put_line(fnd_file.log, 'Núm. RI - De    : '||p_operation_id_ini);
  fnd_file.put_line(fnd_file.log, 'Núm. RI - Até   : '||p_operation_id_fin);
  --
  fnd_file.put_line(fnd_file.output, '<?xml version = ''1.0'' encoding = ''ISO-8859-1''?>');
  fnd_file.put_line(fnd_file.output, '<REPORT>');
  --
  for c_account in account loop
    fnd_file.put_line(fnd_file.output, '<LINE>');
    --
    fnd_file.put_line(fnd_file.output, '<NOME_LOTE>'||DBMS_XMLGEN.CONVERT(c_account.nome_lote, DBMS_XMLGEN.ENTITY_ENCODE)||'</NOME_LOTE>');
    fnd_file.put_line(fnd_file.output, '<NOME_LANCAMENTO>'||DBMS_XMLGEN.CONVERT(c_account.nome_lancamento, DBMS_XMLGEN.ENTITY_ENCODE)||'</NOME_LANCAMENTO>');
    fnd_file.put_line(fnd_file.output, '<ORGANIZACAO>'||DBMS_XMLGEN.CONVERT(c_account.organizacao, DBMS_XMLGEN.ENTITY_ENCODE)||'</ORGANIZACAO>');
    fnd_file.put_line(fnd_file.output, '<NR_RI>'||c_account.nr_ri||'</NR_RI>');
    fnd_file.put_line(fnd_file.output, '<NR_LINHA>'||c_account.nr_linha||'</NR_LINHA>');
    fnd_file.put_line(fnd_file.output, '<LIVRO_CONTABIL>'||c_account.livro_contabil||'</LIVRO_CONTABIL>');
    fnd_file.put_line(fnd_file.output, '<COMBINACAO_CONTABIL>'||DBMS_XMLGEN.CONVERT(c_account.combinacao_contabil, DBMS_XMLGEN.ENTITY_ENCODE)||'</COMBINACAO_CONTABIL>');
    fnd_file.put_line(fnd_file.output, '<PERIODO>'||c_account.periodo||'</PERIODO>');
    fnd_file.put_line(fnd_file.output, '<DATA_CONTABIL>'||to_char(c_account.data_contabil,'dd/mm/rrrr')||'</DATA_CONTABIL>');
    fnd_file.put_line(fnd_file.output, '<STATUS>'||c_account.status||'</STATUS>');
    fnd_file.put_line(fnd_file.output, '<VL_DEBITO_CONTABILIZADO>'||trim(to_char(c_account.vl_debito_contabilizado, '999999999999D99', 'NLS_NUMERIC_CHARACTERS = '',.'''))||'</VL_DEBITO_CONTABILIZADO>');
    fnd_file.put_line(fnd_file.output, '<VL_CRED_CONTABILIZADO>'||trim(to_char(c_account.vl_cred_contabilizado, '999999999999D99', 'NLS_NUMERIC_CHARACTERS = '',.'''))||'</VL_CRED_CONTABILIZADO>');
    fnd_file.put_line(fnd_file.output, '<DESCRICAO_LANCAMENTO>'||DBMS_XMLGEN.CONVERT(c_account.descricao_lancamento, DBMS_XMLGEN.ENTITY_ENCODE)||'</DESCRICAO_LANCAMENTO>');
    --
    fnd_file.put_line(fnd_file.output, '</LINE>');
    --
    l_rec_count := l_rec_count + 1;
  end loop;
  if l_rec_count = 0 then
    fnd_file.put_line(fnd_file.output, '<REC_COUNT>Não foram localizados registros para os parametros informados.</REC_COUNT>');
  else
    fnd_file.put_line(fnd_file.output, '<REC_COUNT> </REC_COUNT>');
  end if;
  --
  fnd_file.put_line(fnd_file.output, '</REPORT>');
end XXSTN_GL_ACCOUNTING_REC_REPORT;
/
