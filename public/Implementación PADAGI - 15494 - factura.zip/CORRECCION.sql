UPDATE apps.hz_parties hp
SET    tax_reference = DECODE(party_name
                            , 'CB Agro SRL','180224090016'
                            , 'Marcelo Gustavo Vico Ferrando', '180104670015'
                            ,  tax_reference)
WHERE  party_name IN ('CB Agro SRL', 'Marcelo Gustavo Vico Ferrando')
AND    status = 'A';
--2 Registros