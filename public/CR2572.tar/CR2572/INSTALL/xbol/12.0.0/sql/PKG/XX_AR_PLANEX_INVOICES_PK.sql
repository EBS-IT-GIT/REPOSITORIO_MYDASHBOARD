  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_PLANEX_INVOICES_PK" AS
/* ----------------------------------------------------------------------------------------------|
| Historial                                                                                      |
|   Fecha     Version  Modifico             Detalle                                              |
|   --------- -------  --------             -----------------------------------------------------|
|   06-NOV-17    1     KHRONUS/MNazarre     Creacion                                             |
|   24-ABR-20    1.1   KHRONUS/E.Sly        Modificacion                                         |
|   19-JUN-20    1.2   KHRONUS/E.Sly        Ejecucion desde FEAR                                 |
|------------------------------------------------------------------------------------------------*/

---------------------------------------------------------------------------------------------
    Procedure main(   retcode            OUT NUMBER
                    , errbuf             OUT VARCHAR2
                    , p_date_from        IN  VARCHAR2
                    , p_date_to          IN  VARCHAR2
                    , p_batch_source_id  IN  NUMBER
                    , p_trx_number_from  IN  VARCHAR2
                    , p_trx_number_to    IN  VARCHAR2
                    , p_cust_account_id  IN  VARCHAR2
                    , p_path             IN  VARCHAR2
                    , p_customer_trx_id  IN  NUMBER DEFAULT NULL);

---------------------------------------------------------------------------------------------
function get_bul_conversion (p_uom_code IN VARCHAR2
                            ,p_inventory_item_id IN NUMBER
                            ,p_organization_id IN NUMBER) RETURN NUMBER;


END XX_AR_PLANEX_INVOICES_PK; 
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_PLANEX_INVOICES_PK" AS
/* ----------------------------------------------------------------------------------------------|
| Historial                                                                                      |
|   Fecha     Version  Modifico             Detalle                                              |
|   --------- -------  --------             -----------------------------------------------------|
|   06-NOV-17    1     KHRONUS/MNazarre     Creacion                                             |
|   24-ABR-20    1.1   KHRONUS/E.Sly        Modificacion                                         |
|   19-JUN-20    1.2   KHRONUS/E.Sly        Ejecucion desde FEAR                                 |
|------------------------------------------------------------------------------------------------*/

    g_user_id    NUMBER := fnd_global.user_id;
    g_login_id   NUMBER := fnd_global.login_id;
    g_request_id NUMBER := fnd_global.conc_request_id;
    g_org_id     NUMBER := fnd_profile.value('ORG_ID');

    g_field0    VARCHAR2(1000);
    g_field1    VARCHAR2(1000);
    g_field2    VARCHAR2(1000);
    g_field3    VARCHAR2(1000);
    g_field4    VARCHAR2(1000);
    g_field5    VARCHAR2(1000);
    g_field6    VARCHAR2(1000);
    g_field7    VARCHAR2(1000);
    g_field8    VARCHAR2(1000);
    g_field9    VARCHAR2(1000);
    g_field10   VARCHAR2(1000);
    g_field11   VARCHAR2(1000);
    g_field12   VARCHAR2(1000);
    g_field13   VARCHAR2(1000);
    g_field14   VARCHAR2(1000);
    g_field15   VARCHAR2(1000);
    g_field16   VARCHAR2(1000);
    g_field17   VARCHAR2(1000);
    g_field18   VARCHAR2(1000);
    g_field19   VARCHAR2(1000);
    g_field20   VARCHAR2(1000);
    g_field21   VARCHAR2(1000);
    g_field22   VARCHAR2(1000);
    g_field23   VARCHAR2(1000);
    g_field24   VARCHAR2(1000);
    g_field25   VARCHAR2(1000);
    g_field26   VARCHAR2(1000);
    g_field27   VARCHAR2(1000);
    g_field28   VARCHAR2(1000);
    g_field29   VARCHAR2(1000);
    g_field30   VARCHAR2(1000);
    g_FileHandle   utl_file.file_type;

---------------------------------------------------------------------------------------------
    procedure print_log(p_message in varchar2) is
    begin
        fnd_file.put_line(fnd_file.log,p_message);
    end;

---------------------------------------------------------------------------------------------
    procedure clear_fields
    is
    begin
        g_field0 := null;
        g_field1 := null;
        g_field2 := null;
        g_field3 := null;
        g_field4 := null;
        g_field5 := null;
        g_field6 := null;
        g_field7 := null;
        g_field8 := null;
        g_field9 := null;
        g_field10 := null;
        g_field11 := null;
        g_field12 := null;
        g_field13 := null;
        g_field14 := null;
        g_field15 := null;
        g_field16 := null;
        g_field17 := null;
        g_field18 := null;
        g_field19 := null;
        g_field20 := null;
        g_field21 := null;
        g_field22 := null;
        g_field23 := null;
        g_field24 := null;
        g_field25 := null;
        g_field26 := null;
        g_field27 := null;
        g_field28 := null;
        g_field29 := null;
        g_field30 := null;

    end;

---------------------------------------------------------------------------------------------
    procedure print_out(p_fields number)
    is
        v_text varchar2(4000);

        v_NewLine      varchar2(2000);
        v_date         varchar2(30);

    begin

        v_date := to_char(sysdate,'YYYYMMDDHH24MMSS');

        v_NewLine :=g_field0  ||';'||
                    g_field1  ||';'||
                    g_field2  ||';'||
                    g_field3  ||';'||
                    g_field4  ||';'||
                    g_field5  ||';'||
                    g_field6  ||';'||
                    g_field7  ||';'||
                    g_field8  ||';'||
                    g_field9  ||';'||
                    g_field10 ||';'||
                    g_field11 ||';'||
                    g_field12 ||';'||
                    g_field13 ||';'||
                    g_field14 ||';'||
                    g_field15 ||';'||
                    g_field16 ||';'||
                    g_field17 ||';'||
                    g_field18 ||';'||
                    g_field19 ||';'||
                    g_field20 ||';'||
                    g_field21 ||';'||
                    g_field22 ||';'||
                    g_field23 ||';'||
                    g_field24 ||';'||
                    g_field25 ||';'||
                    g_field26 ||';'||
                    g_field27 ||';'||
                    g_field28 ||';'||
                    g_field29 ||';'||
                    g_field30;

        v_NewLine := substr(v_NewLine,1,length(v_NewLine)-(30-p_fields));
        fnd_file.put_line(fnd_file.output,v_NewLine);
        utl_file.put_line(g_FileHandle,v_NewLine);

    end;


---------------------------------------------------------------------------------------------
    procedure insert_rec
    is
    begin
        null; --crear el isnert XX_AR_PLANEX_TRX_ALL
    end insert_rec;

    /*Agregado KHRONUS/E.Sly 20200422 Obtengo la conversion de Unidad de Factura a unidad primaria para informar unidad por bultos*/
    function get_bul_conversion (p_uom_code IN VARCHAR2,p_inventory_item_id IN NUMBER,p_organization_id IN NUMBER) RETURN NUMBER IS

    v_primary_uom_code mtl_system_items.primary_uom_code%type;
    v_conv NUMBER;

    BEGIN

        select primary_uom_code
          into v_primary_uom_code
          from apps.mtl_system_items msi
         where inventory_item_id = p_inventory_item_id
           and organization_id = p_organization_id;


           SELECT apps.inv_convert.inv_um_convert (p_inventory_item_id,  --Inventory Item Id
                                       NULL,                   --Precision
                                       1,     --Quantity
                                       p_uom_code,           --From UOM
                                       v_primary_uom_code,                --To UOM
                                       NULL,               --From UOM Name
                                       NULL                 -- To UOM Name
                                      ) ff
                 INTO v_conv
                 FROM DUAL;

         IF v_conv = -9999 THEN
            RETURN NULL;
         ELSE
            RETURN v_conv;
         END IF;

    EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;
    END;
   /*Fin Agregado KHRONUS/E.Sly 20200422 Obtengo la conversion de Unidad de Factura a unidad primaria para informar unidad por bultos*/

    procedure main   (retcode            OUT NUMBER
                    , errbuf             OUT VARCHAR2
                    , p_date_from        IN  VARCHAR2
                    , p_date_to          IN  VARCHAR2
                    , p_batch_source_id  IN  NUMBER
                    , p_trx_number_from  IN  VARCHAR2
                    , p_trx_number_to    IN  VARCHAR2
                    , p_cust_account_id  IN  VARCHAR2
                    , p_path             IN  VARCHAR2
                    , p_customer_trx_id  IN  NUMBER DEFAULT NULL)
    IS

    --Cursor de Facturas
        CURSOR c_invoices
        IS
        SELECT  rct.customer_trx_id
               ,nvl(hca_dfv.xx_ar_planex_codigo,'-1') xx_ar_planex_codigo
        FROM    ra_customer_trx rct
               ,xxw_mtxca_comprobantes xmc
               ,xxw_fac_tmp xct
               --Agregado KHRONUS/MNazarre 20180608: Se agrego dato de cliente
               ,hz_cust_accounts hca
               ,hz_cust_accounts_dfv hca_dfv
        WHERE   1 = 1
        /* Modificado por fecha de envio de CAE LBB 20191008
        AND     rct.trx_date BETWEEN trunc(to_date(p_date_from,'YYYY/MM/DD HH24:MI:SS'))

                                 AND trunc(to_date(p_date_to,'YYYY/MM/DD HH24:MI:SS'))*/
        /*Modificado KHRONUS/E.Sly 20200717 Correccion de comparacion de fechas*/
        /*AND     xct.fecha_env_comprobante BETWEEN trunc(to_date(p_date_from,'YYYY/MM/DD HH24:MI:SS'))
                                          AND trunc(to_date(p_date_to,'YYYY/MM/DD HH24:MI:SS'))+1*/
        AND     TRUNC(xct.fecha_env_comprobante) >= TRUNC(to_date(p_date_from,'YYYY/MM/DD HH24:MI:SS'))
        AND     TRUNC(xct.fecha_env_comprobante) <= trunc(to_date(p_date_to,'YYYY/MM/DD HH24:MI:SS'))+1
        /*Fin Modificado KHRONUS/E.Sly 20200717 Correccion de comparacion de fechas*/
        AND     rct.batch_source_id = nvl(p_batch_source_id,rct.batch_source_id)
        AND     rct.trx_number >= NVL(p_trx_number_from,rct.trx_number)
        AND     rct.trx_number <= NVL(p_trx_number_to,rct.trx_number)
        AND     nvl(rct.bill_to_customer_id,rct.ship_to_customer_id) = nvl(p_cust_account_id,nvl(rct.bill_to_customer_id,rct.ship_to_customer_id))
        AND     rct.customer_trx_id = xmc.customer_trx_id
        and     xmc.customer_trx_id = xct.id
        and     xct.resultado = 'P'
        and     nvl(rct.bill_to_customer_id,rct.ship_to_customer_id) = hca.cust_account_id
        and     hca.rowid = hca_dfv.row_id
        /*Agregado LBB 20181008*/
        and     hca_dfv.xx_ar_planex_codigo IS NOT NULL
        /*Agregado KHRONUS/E.Sly 20200603 Ejecucion de Planex desde FEAR*/
        and     rct.customer_trx_id = NVL(p_customer_trx_id,rct.customer_trx_id)
        /*Fin Agregado KHRONUS/E.Sly 20200603 Ejecucion de Planex desde FEAR*/
        /*Agregado Khronus/E.Sly 20190513 Ordenado */
        ORDER BY rct.customer_trx_id;


        CURSOR c_rec_0 (p_customer_trx_id   number)
        IS
        SELECT   '000' rec_type
                ,'01' column1
                ,SUBSTR(hl.global_attribute11 || hl.global_attribute12,
                    1,
                    2) || SUBSTR(hl.global_attribute11 || hl.global_attribute12,
                    3,
                    8) || SUBSTR(hl.global_attribute11 || hl.global_attribute12,
                    11,
                    1) column2
                ,xmc.codigo_tipo_doc column3
                ,xmc.nro_doc column4
                ,xmc.nro_pto_vta column5
                --Inicio CR2233
                --,xmc.codigo_tipo_cbte column6
                ,nvl((SELECT rbs_dfv.xx_ar_tipo_compr_3685
                  FROM   ra_customer_trx_all rct
                        ,ra_batch_sources_all rbs
                        ,ra_batch_sources_all_dfv rbs_dfv
                  WHERE  rbs.rowid = rbs_dfv.row_id
                  AND    rct.batch_source_id = rbs.batch_source_id
                  AND    rct.customer_trx_id = p_customer_trx_id),xmc.codigo_tipo_cbte) column6
                --Fin CR2233
                ,xmc.nro_cbte column7
                ,xmc.importe_total column8
                ,xmc.importe_exento+xmc.importe_no_gravado column9
                ,xmc.importe_gravado column10
                --,ABS(FLOOR(SUM(DECODE(a.tax_category,'VAT',NVL(a.tax_extended_amount,0),0))*100)) column11 --importe impuesto IVA
                ,nvl((select sum(importe)
                     from   xxw_mtxca_iva
                     where  customer_trx_id = xmc.customer_trx_id
                     and    codigo != '3'),0) column11
                ,0 column12
                ,nvl((select sum(importe)
                     from   xxw_mtxca_iva
                     where  customer_trx_id = xmc.customer_trx_id
                     and    codigo = '3'),0) column13
                --,ABS(FLOOR(SUM(DECODE(a.tax_category||'-'||a.tax_rate,'VAT-0',DECODE(a.vat_flag_mlng, 'EXENTO', NVL(a.line_extended_amount_vat,0), 0),0))*100)) column13 --importe impuesto IVA EXENTO
                ,xmc.fecha_emision column14
                ,nvl(xmc.fecha_servicio_desde,xmc.fecha_emision) column15
                ,nvl(xmc.fecha_servicio_hasta,xmc.fecha_emision) column16
                /*Modificado Khronus/E.Sly 20190506 Debe tomar la primer fecha de vencimiento cuando la vista no es nula*/
                --,nvl(xmc.fecha_vencimiento,xmc.fecha_emision) column17
                , NVL(xmc.fecha_vencimiento,nvl((select  to_char(min(due_date),'YYYYMMDD')
                      from    apps.ar_payment_schedules aps
                      where   aps.customer_trx_id = xmc.customer_trx_id),xmc.fecha_emision)) column17
                /*Modificado Khronus/E.Sly 20190506 Debe tomar la primer fecha de vencimiento cuando la vista no es nula*/
                ,0 column18
        from     xxw_mtxca_comprobantes xmc
                ,hr_operating_units hou
                ,hr_all_organization_units haou
                ,hr_locations hl
        where   xmc.customer_trx_id = p_customer_trx_id
        AND     hou.organization_id = g_org_id
        AND     hou.organization_id = haou.organization_id
        and     haou.location_id = hl.location_id;

        CURSOR c_rec_1 (p_customer_trx_id   number)
        IS
        SELECT   '010' rec_type
                --Inicio CR2233
                --,xmc.codigo_tipo_cbte column1
                ,nvl((SELECT rbs_dfv.xx_ar_tipo_compr_3685
                  FROM   ra_customer_trx_all rct
                        ,ra_batch_sources_all rbs
                        ,ra_batch_sources_all_dfv rbs_dfv
                  WHERE  rbs.rowid = rbs_dfv.row_id
                  AND    rct.batch_source_id = rbs.batch_source_id
                  AND    rct.customer_trx_id = p_customer_trx_id),xmc.codigo_tipo_cbte) column1
                --Fin CR2233
                ,xmc.nro_cbte column2
                ,xmc.nro_cbte column3
                ,xmc.nro_pto_vta column4
                ,xmc.fecha_emision column5
                --KHRONUS/MNazarre 20180312: Se modifico para que obtener la fecha de vencimiento
                --,nvl(xmc.fecha_vencimiento,xmc.fecha_emision) column6
                ,nvl((select  to_char(min(due_date),'YYYYMMDD')
                      from    apps.ar_payment_schedules aps
                      where   aps.customer_trx_id = p_customer_trx_id),xmc.fecha_emision) column6
                ,null column7
                ,null column8
                ,NVL((select substr(rt.description,1,100)
                      from ra_terms rt
                      where rt.term_id = rct.term_id),NULL) column9
                ,xct.cae column10
                ,to_char(to_date(xct.fecha_vto_cae,'DD-MON-YY'),'YYYYMMDD') column11
                ,null column12
                ,null column13
                ,null column14 --capaz que se puede poner nro de pedido
                ,null column15
                ,null column16
                ,null column17
                ,null column18
                ,'1' column19
                ,null column20
                ,null column21
                ,null column22
                ,null column23
                ,to_char(nvl(rct.ship_date_actual,rct.trx_date),'YYYYMMDD') column24
                ,null column25
        from     xxw_mtxca_comprobantes xmc
                ,hr_operating_units hou
                ,hr_all_organization_units haou
                ,hr_locations hl
                ,xxw_fac_tmp xct
                ,ra_customer_trx rct
        where   xmc.customer_trx_id = p_customer_trx_id
        AND     hou.organization_id = g_org_id
        AND     hou.organization_id = haou.organization_id
        and     haou.location_id = hl.location_id
        and     xmc.customer_trx_id = xct.id
        and     xct.resultado = 'P'
        and     xmc.customer_trx_id = rct.customer_trx_id;

        CURSOR c_rec_2 (p_customer_trx_id   number)
        IS
        SELECT  '020' rec_type
               ,'PC' column1
               ,null column2
               ,substr(rctl.interface_line_attribute1,1,20) column3
               ,to_char(ooh.ordered_date, 'YYYYMMDD') column4
        FROM    ra_customer_trx_lines_all rctl
               ,oe_order_headers_all ooh
               ,oe_transaction_types ott
        WHERE   rctl.customer_trx_id = p_customer_trx_id
        AND     rctl.interface_line_context = 'ORDER ENTRY'
        AND     rctl.interface_line_attribute1 is not null
        AND     rctl.interface_line_attribute1 = ooh.order_number
        AND     rctl.org_id = ooh.org_id
        AND     rctl.interface_line_attribute2 = ott.name
        AND     ott.transaction_type_id = ooh.order_type_id
        GROUP BY
                substr(rctl.interface_line_attribute1,1,20)
               ,to_char(ooh.ordered_date,'YYYYMMDD')
        UNION ALL
        SELECT  '020' rec_type
               ,'RE' column1
               ,substr(wnd.waybill,1,4) column2
               ,substr(wnd.waybill,6,26) column3
               ,to_char(wnd.confirm_date, 'YYYYMMDD') column4
        FROM    ra_customer_trx_lines_all rctl
               ,wsh_new_deliveries wnd
        WHERE   rctl.customer_trx_id = p_customer_trx_id
        AND     rctl.interface_line_context = 'ORDER ENTRY'
        AND     rctl.interface_line_attribute3 is not null
        /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
        --AND     rctl.interface_line_attribute3 = wnd.delivery_id
        AND     rctl.interface_line_attribute3 = TO_CHAR(wnd.delivery_id)
        /*Fin Modificado Numero no valido*/
        GROUP BY
                substr(wnd.waybill,1,4)
               ,substr(wnd.waybill,6,26)
               ,to_char(wnd.confirm_date,'YYYYMMDD');

        CURSOR c_rec_2_inc (p_customer_trx_id   number)
        IS
        SELECT  '020' rec_type
               ,'RE' column1
               /*CR2297
               ,substr(wnd.waybill,1,4) column2
               ,substr(wnd.waybill,6,26) column3*/
               ,substr(nvl(wnd.waybill,rctl.interface_line_attribute4),1,4) column2
               ,substr(nvl(wnd.waybill,rctl.interface_line_attribute4),6,26) column3
               ,to_char(wnd.confirm_date, 'YYYYMMDD') column4
        FROM    ra_customer_trx_lines_all rctl
               ,wsh_new_deliveries wnd
        WHERE   rctl.customer_trx_id = p_customer_trx_id
        AND     rctl.interface_line_context = 'ORDER ENTRY'
        --AND     rctl.interface_line_attribute3 is not null CR2297
        AND     (rctl.interface_line_attribute3 is not null OR rctl.interface_line_attribute4 is not null)
        /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
        --AND     rctl.interface_line_attribute3 = wnd.delivery_id (+)
        AND     rctl.interface_line_attribute3 = TO_CHAR(wnd.delivery_id (+))
        /*Fin Modificado Numero no valido*/
        GROUP BY
                substr(nvl(wnd.waybill,rctl.interface_line_attribute4),1,4)
               ,substr(nvl(wnd.waybill,rctl.interface_line_attribute4),6,26)
               ,to_char(wnd.confirm_date,'YYYYMMDD')
        UNION ALL
        SELECT  '020' rec_type
               ,'PC' column1
               ,null column2
               ,substr(ooh.cust_po_number,1,20) column3
               ,to_char(ooh.ordered_date, 'YYYYMMDD') column4
        FROM    ra_customer_trx_lines_all rctl
               ,oe_order_headers_all ooh
               ,oe_transaction_types ott
        WHERE   rctl.customer_trx_id = p_customer_trx_id
        AND     rctl.interface_line_context = 'ORDER ENTRY'
        AND     rctl.interface_line_attribute1 is not null
        /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
        --AND     rctl.interface_line_attribute1 = ooh.order_number
        AND     rctl.interface_line_attribute1 = TO_CHAR(ooh.order_number)
        /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
        AND     rctl.org_id = ooh.org_id
        AND     rctl.interface_line_attribute2 = ott.name
        AND     ott.transaction_type_id = ooh.order_type_id
        GROUP BY
                substr(ooh.cust_po_number,1,20)
               ,to_char(ooh.ordered_date,'YYYYMMDD');

        CURSOR c_rec_3 (p_customer_trx_id   number)
        IS
       SELECT   '030' rec_type
                ,hl.global_attribute8 column1
                ,haou_dfv.xx_gln column2
                ,'01' column3 --SUBSTR(flvi.tag,1,2)  vat_cond
                --KHRONUS/MNazarre 20180312: Se modifico para informar el nro inscripto IIBB
                --,hl.global_attribute1 column4
                ,hl.attribute2 column4
                --,SUBSTR(flvi.tag,1,2) column11
                --,hl.global_attribute15 column5
                ,TO_CHAR(TO_DATE(hl.global_attribute14,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD') column5
                ,NULL column6
                ,hl.address_line_1 column7
                ,NULL column8
                ,NULL column9
                ,NULL column10
                ,NULL column11
                ,NULL column12
                ,NULL column13
                /*Modificado Khronus/E.Sly 20190503 Ajustes Retrofit L3N*/
                --KHRONUS/MNazarre 20180312: Se modifico para la Ciudad y no el codigo.
                --,hl.town_or_city column14
                --,fl_city.meaning column14
                ,hg.GEOGRAPHY_NAME column14
                /*Fin Modificado Khronus/E.Sly 20190503 Ajustes Retrofit L3N*/
                ,flvp.meaning column15
                ,hl.postal_code column16
                ,NULL column17
                ,hl.telephone_number_1 column18
                ,SUBSTR(hl.global_attribute11 || hl.global_attribute12,1,2) ||
                 SUBSTR(hl.global_attribute11 || hl.global_attribute12,3,8) ||
                 SUBSTR(hl.global_attribute11 || hl.global_attribute12,11,1) column19
                ,NULL column20
                ,NULL column21
                ,NULL column22
                ,NULL column23
                ,hl.telephone_number_2 column24
                ,NULL column25
        from     xxw_mtxca_comprobantes xmc
                ,hr_operating_units hou
                ,hr_all_organization_units haou
                ,hr_all_organization_units_dfv haou_dfv
                ,hr_locations hl
                ,xxw_fac_tmp xct
                ,ra_customer_trx rct
                ,fnd_lookup_values_vl flvp
                ,fnd_lookup_values_vl flvi
                /*Modificado Khronus/E.Sly 20190503 Ajustes Retrofit L3N*/
                --,apps.fnd_lookups fl_city
                ,apps.hz_geographies hg
                /*Fin Modificado Khronus/E.Sly 20190503 Ajustes Retrofit L3N*/
        where   xmc.customer_trx_id = p_customer_trx_id
        AND     hou.organization_id = g_org_id
        AND     hou.organization_id = haou.organization_id
        AND     haou.rowid = haou_dfv.row_id
        and     haou.location_id = hl.location_id
        and     xmc.customer_trx_id = xct.id
        and     xct.resultado = 'P'
        and     xmc.customer_trx_id = rct.customer_trx_id
        AND     hl.global_attribute1 = flvi.lookup_code(+)
        AND     flvi.lookup_type(+) = 'ORGANIZATION_CLASS'
        AND     hl.region_2 = flvp.lookup_code(+)
        AND     flvp.lookup_type(+) = 'JLZZ_STATE_PROVINCE'
        /*Modificado Khronus/E.Sly 20190503 Ajustes Retrofit L3N*/
--        AND     fl_city.lookup_type(+) = 'JLZZ_CITY'
--        AND     NVL(fl_city.start_date_active(+), SYSDATE) <= SYSDATE
--        AND     NVL(fl_city.end_date_active(+), SYSDATE) >= SYSDATE
--        AND     fl_city.enabled_flag(+) = 'Y'
--        AND     fl_city.lookup_code = hl.town_or_city(+)
        AND     hg.geography_type = 'CITY'
        and     hg.geography_code = hl.loc_information16
        and     NVL(TRUNC(hg.start_date),TRUNC(SYSDATE)) <= TRUNC(SYSDATE)
        and     NVL(TRUNC(hg.end_date),TRUNC(SYSDATE)) >= TRUNC(SYSDATE);
        /*Fin Modificado Khronus/E.Sly 20190503 Ajustes Retrofit L3N*/

        CURSOR c_rec_4 (p_customer_trx_id   number)
        IS
        SELECT   '040' rec_type
                ,substr(hp.party_name,1,200) column1
                ,hca_dfv.xx_ar_planex_gln column2 -- xx_ar_planex_cliente
                ,hca.account_number column3
                ,hcas.global_attribute8 column4
                ,replace(hl.province,'25','00') column5
                ,NULL column6
                ,NULL column7
                ,hl.address1 column8
                ,NULL column9
                ,NULL column10
                ,NULL column11
                ,NULL column12
                ,NULL column13
                ,NULL column14
                ,hl.city column15
                ,NULL column16
                ,hl.postal_code column17
                ,NULL column18
                ,NULL column19
                ,hca.global_attribute10 column20
                ,hp.jgzz_fiscal_code || hca.global_attribute12 column21
                ,NULL column22
                ,NULL column23
                ,NULL column24
                ,NULL column25
                ,NULL column26
                ,NULL column27
                ,rct.ship_to_site_use_id
        FROM    fnd_lookup_values_vl flvi
               ,fnd_lookup_values_vl flvc
               ,hz_locations hl
               ,hz_party_sites hps
               ,hz_cust_acct_sites_all hcas
               ,hz_cust_acct_sites_all_dfv hcas_dfv
               ,hz_cust_site_uses_all hcsu
               ,hz_parties hp
               ,hz_cust_accounts hca
               ,hz_cust_accounts_dfv hca_dfv
               ,ra_customer_trx_all rct
        WHERE   1=1
        AND     rct.customer_trx_id      = p_customer_trx_id
        AND     rct.bill_to_customer_id  = hca.cust_account_id
        AND     hca.party_id             = hp.party_id
        AND     rct.bill_to_site_use_id  = hcsu.site_use_id
        AND     hcsu.cust_acct_site_id   = hcas.cust_acct_site_id(+)
        AND     hcas.party_site_id       = hps.party_site_id(+)
        AND     hps.location_id          = hl.location_id(+)
        AND     hl.country               = flvc.lookup_code(+)
        AND     flvc.lookup_type(+)      = 'XX_AR_FE_COUNTRIES'
        AND     hcas.global_attribute8   = flvi.lookup_code(+)
        AND     flvi.lookup_type(+)      = 'CONTRIBUTOR_CLASS'
        AND     hcas.rowid               = hcas_dfv.row_id(+)
        AND     hca.rowid                = hca_dfv.row_id(+);

        CURSOR c_rec_45 (p_customer_trx_id   number)
        IS
        SELECT
                 '045' rec_type
                ,hp.party_name column1
        --        ,hl.global_attribute8 column1
                ,hcas_dfv.xx_om_cm_cliente_planex column2 -- xx_ar_planex_cliente
                ,hps.party_site_number column3
                ,hcas.global_attribute8 column4
                ,NULL column5
                ,NULL column6
                ,NULL column7
                ,hl.address1 column8
                ,NULL column9
                ,NULL column10
                ,NULL column11
                ,NULL column12
                ,NULL column13
                ,NULL column14
                ,hl.city column15
                ,hl.province column16
                ,hl.postal_code column17
                ,NULL column18
                ,NULL column19
                ,DECODE(hl.country,'AR',hca.global_attribute10,'80') column20
                ,DECODE(hl.country,'AR',hp.jgzz_fiscal_code||hca.global_attribute12,flvc.description) column21
                ,NULL column22
                ,NULL column23
                ,NULL column24
                ,NULL column25
                ,NULL column26
                ,NULL column27
        --FROM
        FROM     dual
                ,fnd_lookup_values_vl        flvi
                ,fnd_lookup_values_vl        flvc
                ,hz_locations                hl
                ,hz_party_sites              hps
                ,hz_cust_acct_sites_all      hcas
                ,hz_cust_acct_sites_all_dfv  hcas_dfv
                ,hz_cust_site_uses_all       hcsu
                ,hz_parties                  hp
                ,hz_cust_accounts            hca
                ,ra_customer_trx_all         rct
        WHERE   1=1
        AND     rct.customer_trx_id      = p_customer_trx_id
        AND     rct.ship_to_customer_id  = hca.cust_account_id
        AND     hca.party_id             = hp.party_id
        AND     rct.ship_to_site_use_id  = hcsu.site_use_id
        AND     hcsu.cust_acct_site_id   = hcas.cust_acct_site_id(+)
        AND     hcas.party_site_id       = hps.party_site_id(+)
        AND     hps.location_id          = hl.location_id(+)
        AND     hl.country               = flvc.lookup_code(+)
        AND     flvc.lookup_type(+)      = 'XX_AR_PAIS_FACTURA_ELECTRONICA'
        AND     hcas.global_attribute8   = flvi.lookup_code(+)
        AND     flvi.lookup_type(+)      = 'CONTRIBUTOR_CLASS'
        AND     hcas.rowid               = hcas_dfv.row_id(+);


        CURSOR c_rec_5 (p_customer_trx_id   number)
        IS
        SELECT   '050' rec_type
                ,null column1
                ,xmc.importe_gravado +xmc.importe_exento+xmc.importe_no_gravado column2 --validar FC B
                ,xmc.importe_gravado +xmc.importe_exento+xmc.importe_no_gravado column3 --VER importe_subtotal de los 2
                ,xmc.importe_total column4
                ,xmc.importe_exento+xmc.importe_no_gravado column5
                ,xmc.importe_gravado column6
                ,nvl((select sum(importe)
                     from   xxw_mtxca_iva
                     where  customer_trx_id = xmc.customer_trx_id),0) column7
                --,ABS(FLOOR(SUM(DECODE(a.tax_category,'VAT',NVL(a.tax_extended_amount,0),0))*100)) column7 --importe impuesto IVA
                ,'000000000000000' column8
                ,xmc.importe_exento column9
                ,nvl((select sum(importe)
                     from   xxw_mtxca_tributos
                     where  customer_trx_id = xmc.customer_trx_id
                     and    codigo = 1),0) column10--Modificado KHRONUS/MNazarre 20180312: Se cambio para que informe la perc IVA
                ,nvl((select sum(importe)
                     from   xxw_mtxca_tributos
                     where  customer_trx_id = xmc.customer_trx_id
                     and    codigo = 2),0) column11
                ,0 column12 --Modificado KHRONUS/MNazarre 20180312: se informa 0 en perc. impuestos municipales
                --,(FLOOR(SUM(DECODE(substr(a.tax_category, 1, 7),'VATPERC',NVL(a.line_extended_amount,0),0))*100)) column10 Ver vista de perc.
                --,(FLOOR(SUM(DECODE(substr(a.tax_category, 1, 7),'VATPERC',NVL(a.line_extended_amount,0),0))*100)) column11 Ver vista de perc.
                --,(FLOOR(SUM(DECODE(substr(a.tax_category, 1, 7),'VATPERC',NVL(a.line_extended_amount,0),0))*100)) column12 Ver vista de perc.
                ,0 column13 --Modificado KHRONUS/MNazarre 20180312: se informa 0 en impuestos internos
                ,'000000000000000' column14
                ,xmc.codigo_moneda column15
                ,xmc.cotizacion_moneda column16
                ,nvl((select count(1) from xxw_mtxca_iva where customer_trx_id = xmc.customer_trx_id),0) column17
                ,null column18
                ,substr(rct.comments, 1, 1000)     column19
                ,NULL column20
                ,TO_CHAR(rct.exchange_date,'YYYYMMDD') column21
                ,NULL column22
                ,NULL column23
                ,NULL column24
                ,xmc.importe_otros_tributos column25
        from    xxw_mtxca_comprobantes xmc
               ,ra_customer_trx rct
        where   xmc.customer_trx_id = p_customer_trx_id
        and     xmc.customer_trx_id = rct.customer_trx_id;

        CURSOR c_rec_6 (p_customer_trx_id   number)
        IS
        SELECT   '060' rec_type
             ,vat.tax_rate column1
             ,ROUND (
                 ABS (NVL (SUM (ctl.extended_amount)
                           * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                     'N',
                                     1,
                                     'Y',
                                     NVL (ct.exchange_rate, 1)), 0)),
                 2
              ) column2
             ,ROUND (
                 ABS (NVL (SUM (ctl.taxable_amount)
                           * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                     'N',
                                     1,
                                     'Y',
                                     NVL (ct.exchange_rate, 1)), 0)),
                 2
              ) column3
             ,0 column4
        FROM   ar_vat_tax_all_b_dfv vat_dfv,
              ar_vat_tax_all_b vat,
              ra_customer_trx_lines_all ctl,
              ra_customer_trx_all ct,
              ra_batch_sources_all_dfv bs_dfv,
              ra_batch_sources_all bs
        WHERE       1 = 1
              --and     xxw_mtxca_pkg.Codigo_Tipo_Cbte( ct.customer_trx_id ) in ('01','02','03')
              AND bs.batch_source_id = ct.batch_source_id
              AND bs_dfv.row_id = bs.ROWID
              AND bs_dfv.xxw_fac_elec IS NOT NULL
              AND ctl.customer_trx_id = ct.customer_trx_id
              AND ctl.line_type = 'TAX'
              AND vat.vat_tax_id = ctl.vat_tax_id
              AND vat_dfv.row_id = vat.ROWID
              --and     vat_dfv.context_value = 'AFIP'
              AND vat_dfv.xxw_cod_iva IS NOT NULL
              AND vat_dfv.xxw_cod_iva != 3 /* 0% no se incluye en este array */
              and ctl.customer_trx_id = p_customer_trx_id
        GROUP BY   ctl.customer_trx_id,
              vat.tax_rate,
              bs_dfv.xxw_valores_en_mon_func,
              ct.exchange_rate;

        CURSOR c_rec_7 (p_customer_trx_id   number)
        IS
         SELECT   '070' rec_type,
                  xmt.customer_trx_id,
                  xmt.codigo  column1,
                  ABS (SUM (xmt.importe)) column2, --KHRONUS/MNazarre 20180312: Se dio vuelta los importes
                  null  column3,
                  0  column4,
                  substr(xmt.descripcion,1,50)  column5,
                  xmt.tasa  column6,
                  ABS (SUM (xmt.base_imponible)) column7, --KHRONUS/MNazarre 20180312: Se dio vuelta los importes
                  0  column8,
                  0  column9
           FROM     (SELECT   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib codigo,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0') codigo,
                              --lpad(fl_jurisd.meaning,2,'0') codigo,
                              vat_tl.printed_tax_name descripcion,    /* o vat.description */
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_line.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                                /*)  20171106 */
                                  ,
                                 2
                              )
                                 base_imponible,
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_tax.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                               /* )  20171106 */
                                  ,
                                 2
                              )
                                 importe,
                              /*Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              --vat.tax_Rate tasa
                              CASE
                               WHEN vat.tax = 'TOPTU' THEN
                                 ROUND((ctl_tax.extended_amount*100)/NVL((select extended_amount
                                                                            from ra_customer_trx_lines_all
                                                                           where customer_trx_line_id = ctl_tax.link_to_cust_trx_line_id),1),2)
                              ELSE
                                vat.tax_Rate
                              END tasa
                              /*FIn Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                       FROM   ar_vat_tax_all_b_dfv vat_dfv,
                              ar_vat_tax_all_b vat,
                              ar_vat_tax_all_vl vat_tl,
                              --Agregado 20180105
                              jl_zz_ar_tx_categ jzatc,
                              jl_zz_ar_tx_categ_all_dfv jzatc_dfv,
                              --Fin Agregado 20180105
                              ra_customer_trx_lines_all ctl_tax,
                              ra_customer_trx_lines_all ctl_line,
                              ra_customer_trx_all ct,
                              ra_batch_sources_all_dfv bs_dfv,
                              ra_batch_sources_all bs
                              --apps.fnd_lookups fl_jurisd
                      WHERE       bs.batch_source_id = ct.batch_source_id
                              AND bs_dfv.row_id = bs.ROWID
                              AND bs_dfv.xxw_fac_elec IS NOT NULL
                              AND ctl_tax.customer_trx_id = ct.customer_trx_id
                              AND ctl_tax.line_type = 'TAX'
                              AND ctl_tax.extended_amount != 0
                              AND ctl_line.customer_trx_line_id =
                                    ctl_tax.link_to_cust_trx_line_id
                              AND ctl_line.extended_amount != 0 /* no es factura de impuestos, existe importe de la linea */
                              AND vat.vat_tax_id = ctl_tax.vat_tax_id
                              AND vat_dfv.row_id = vat.ROWID
                              --and     vat_dfv.context_value = 'AFIP'
                              AND vat_dfv.xxw_cod_iva IS NULL
                              AND vat_dfv.xxw_cod_trib IS NOT NULL
                              AND vat.vat_tax_id = vat_tl.vat_tax_id
                              AND ctl_tax.customer_trx_id = p_customer_trx_id
                              and vat.vat_tax_id = vat_tl.vat_Tax_id
                              --Agregado 20180105
                              and vat.global_attribute1 = jzatc.tax_category_id
                              and jzatc.rowid = jzatc_dfv.row_id
                              and jzatc_dfv.xx_ar_provincia is not null
                              and nvl(vat_dfv.xxw_cod_trib,'0') != '1'
                              --agregado
                              --and jzatc_dfv.xx_ar_provincia = lpad(fl_jurisd.lookup_code(+),2,'0')
                              --and fl_jurisd.lookup_type(+) = 'XX_AR_PLANEX_IIBB_JURISDICCION'
                   GROUP BY   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0'),
                              --lpad(fl_jurisd.meaning,2,'0'),
                              vat_tl.printed_tax_name,
                              bs_dfv.xxw_valores_en_mon_func,
                              ct.exchange_rate,
                              ctl_tax.extended_amount,
                              vat.tax_Rate,
                              /*Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              vat.tax,
                              ctl_tax.link_to_cust_trx_line_id
                              /*Fin Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                   UNION ALL
                     /* tributos en facturas de impuestos */
                     SELECT   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib codigo,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0') codigo,
                              --lpad(fl_jurisd.meaning,2,'0') codigo,
                              vat_tl.printed_tax_name descripcion,    /* o vat.description */
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_line.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                            /*ABS )  20171106 */
                                  ,
                                 2
                              )
                                 base_imponible,
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_tax.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                               /* )  20171106 */
                                  ,
                                 2
                              )
                                 importe,
                              /*Modificado Khronus/E.Sly 20190902 Se calcula el impuesto por Tucuman*/
                              --vat.tax_Rate tasa
                              CASE
                               WHEN vat.tax = 'TOPTU' THEN
                                 ROUND((ctl_tax.extended_amount*100)/NVL((select extended_amount
                                                                            from ra_customer_trx_lines_all
                                                                           where customer_trx_line_id = ctl_tax.link_to_cust_trx_line_id),1),2)
                              ELSE
                                vat.tax_Rate
                              END tasa
                              /*FIn Modificado Khronus/E.Sly 20190902 Se calcula el impuesto por Tucuman*/
                       FROM   ar_vat_tax_all_b_dfv vat_dfv,
                              ar_vat_tax_all_b vat,
                              ar_vat_tax_all_vl vat_tl,
                              --Agregado 20180105
                              jl_zz_ar_tx_categ jzatc,
                              jl_zz_ar_tx_categ_all_dfv jzatc_dfv,
                              --Fin Agregado 20180105
                              ra_customer_trx_lines_all ctl_tax,
                              ra_customer_trx_lines_all ctl_line,
                              ra_customer_trx_all ct,
                              ra_batch_sources_all_dfv bs_dfv,
                              ra_batch_sources_all bs
                              --apps.fnd_lookups fl_jurisd
                      WHERE       bs.batch_source_id = ct.batch_source_id
                              AND bs_dfv.row_id = bs.ROWID
                              AND bs_dfv.xxw_fac_elec IS NOT NULL
                              AND ctl_tax.customer_trx_id = ct.customer_trx_id
                              AND ctl_tax.line_type = 'TAX'
                              AND ctl_tax.extended_amount != 0
                              AND ctl_line.customer_trx_line_id =
                                    ctl_tax.link_to_cust_trx_line_id
                              AND ctl_line.extended_amount = 0 /* facturas de impuestos el importe de la linea estn cero */
                              AND vat.vat_tax_id = ctl_tax.vat_tax_id
                              AND vat_dfv.row_id = vat.ROWID
                              --and     vat_dfv.context_value = 'AFIP'
                              AND vat_dfv.xxw_cod_iva IS NULL
                              AND vat_dfv.xxw_cod_trib IS NOT NULL
                              AND ctl_tax.customer_trx_id = p_customer_trx_id
                              and vat.vat_tax_id = vat_tl.vat_Tax_id
                              --Agregado 20180105
                              and vat.global_attribute1 = jzatc.tax_category_id
                              and jzatc.rowid = jzatc_dfv.row_id
                              and jzatc_dfv.xx_ar_provincia is not null
                              and nvl(vat_dfv.xxw_cod_trib,'0') != '1'
                              --agregado
                              --and jzatc_dfv.xx_ar_provincia = lpad(fl_jurisd.lookup_code(+),2,'0')
                              --and fl_jurisd.lookup_type(+) = 'XX_AR_PLANEX_IIBB_JURISDICCION'
                   GROUP BY   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0'),
                              --lpad(fl_jurisd.meaning,2,'0'),
                              vat_tl.printed_tax_name,
                              bs_dfv.xxw_valores_en_mon_func,
                              ct.exchange_rate,
                              ctl_tax.extended_amount,
                              vat.tax_Rate,
                              /*Agregado Khronus/E.Sly 20190902 Se calcula el impuesto por Tucuman*/
                              vat.tax,
                              ctl_tax.link_to_cust_trx_line_id
                              /*Fin Agregado Khronus/E.Sly 20190902 Se calcula el impuesto por Tucuman*/
                              ) xmt
       GROUP BY   xmt.customer_trx_id, xmt.codigo, substr(xmt.descripcion,1,50),  xmt.tasa;

        CURSOR c_rec_8 (p_customer_trx_id   number)
        IS
        SELECT  '080' rec_type
               ,'Descuento' column1
               ,null column2 --Ver
               ,ROUND(sum(xmi.cantidad*xmi.precio_unitario),2) column3
               ,ROUND(sum(xmi.importe_bonificacion),2) column4
               ,'D' column5
        FROM    xxw_mtxca_items xmi
        WHERE   customer_trx_id = p_customer_trx_id;

        /*CURSOR c_rec_9 (p_customer_trx_id   number)
        IS
        SELECT  '090' rec_type
               ,xmt.descripcion column1
               ,null column2
               ,xmt.base_imponible column3
               ,xmt.importe column4
               ,'C05' column5
               ,null column6
        FROM    xxw_mtxca_tributos xmt
        WHERE   customer_trx_id = p_customer_trx_id
        AND     codigo = '1';*/

        CURSOR c_rec_9 (p_customer_trx_id   number)
        IS
        SELECT  '090' rec_type
               ,substr(xmt.descripcion,1,30) column1
               --,null column2 CR2359
               ,CASE
               WHEN tasa = 100 THEN
                    ROUND((SUM (xmt.importe) / SUM (xmt.base_imponible))*100,2)
               ELSE tasa
               END column2
               ,ABS (ROUND(SUM (xmt.base_imponible),2)) column3
               ,ABS (ROUND(SUM (xmt.importe),2)) column4
               ,'C05' column5
               ,null column6
           FROM     (SELECT   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib codigo,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0') codigo,
                              vat_tl.printed_tax_name descripcion,    /* o vat.description */
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_line.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                                /*)  20171106 */
                                  ,
                                 2
                              )
                                 base_imponible,
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_tax.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                               /* )  20171106 */
                                  ,
                                 2
                              )
                                 importe,
                              vat.tax_Rate tasa
                       FROM   ar_vat_tax_all_b_dfv vat_dfv,
                              ar_vat_tax_all_b vat,
                              ar_vat_tax_all_vl vat_tl,
                              --Agregado 20180105
                              jl_zz_ar_tx_categ jzatc,
                              jl_zz_ar_tx_categ_all_dfv jzatc_dfv,
                              --Fin Agregado 20180105
                              ra_customer_trx_lines_all ctl_tax,
                              ra_customer_trx_lines_all ctl_line,
                              ra_customer_trx_all ct,
                              ra_batch_sources_all_dfv bs_dfv,
                              ra_batch_sources_all bs
                      WHERE       bs.batch_source_id = ct.batch_source_id
                              AND bs_dfv.row_id = bs.ROWID
                              AND bs_dfv.xxw_fac_elec IS NOT NULL
                              AND ctl_tax.customer_trx_id = ct.customer_trx_id
                              AND ctl_tax.line_type = 'TAX'
                              AND ctl_tax.extended_amount != 0
                              AND ctl_line.customer_trx_line_id =
                                    ctl_tax.link_to_cust_trx_line_id
                              AND ctl_line.extended_amount != 0 /* no es factura de impuestos, existe importe de la linea */
                              AND vat.vat_tax_id = ctl_tax.vat_tax_id
                              AND vat_dfv.row_id = vat.ROWID
                              --and     vat_dfv.context_value = 'AFIP'
                              AND vat_dfv.xxw_cod_iva IS NULL
                              AND vat_dfv.xxw_cod_trib IS NOT NULL
                              AND vat.vat_tax_id = vat_tl.vat_tax_id
                              AND ctl_tax.customer_trx_id = p_customer_trx_id
                              and vat.vat_tax_id = vat_tl.vat_Tax_id
                              --Agregado 20180105
                              and vat.global_attribute1 = jzatc.tax_category_id
                              and jzatc.rowid = jzatc_dfv.row_id
                              and jzatc_dfv.xx_ar_provincia is null
                              and vat_dfv.xxw_cod_trib = '1'
                   GROUP BY   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0'),
                              vat_tl.printed_tax_name,
                              bs_dfv.xxw_valores_en_mon_func,
                              ct.exchange_rate,
                              ctl_tax.extended_amount,
                              vat.tax_Rate
                   UNION ALL
                     /* tributos en facturas de impuestos */
                     SELECT   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib codigo,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0') codigo,
                              vat_tl.printed_tax_name descripcion,    /* o vat.description */
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_line.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                            /*ABS )  20171106 */
                                  ,
                                 2
                              )
                                 base_imponible,
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_tax.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                               /* )  20171106 */
                                  ,
                                 2
                              )
                                 importe,
                              vat.tax_Rate tasa
                       FROM   ar_vat_tax_all_b_dfv vat_dfv,
                              ar_vat_tax_all_b vat,
                              ar_vat_tax_all_vl vat_tl,
                              --Agregado 20180105
                              jl_zz_ar_tx_categ jzatc,
                              jl_zz_ar_tx_categ_all_dfv jzatc_dfv,
                              --Fin Agregado 20180105
                              ra_customer_trx_lines_all ctl_tax,
                              ra_customer_trx_lines_all ctl_line,
                              ra_customer_trx_all ct,
                              ra_batch_sources_all_dfv bs_dfv,
                              ra_batch_sources_all bs
                      WHERE       bs.batch_source_id = ct.batch_source_id
                              AND bs_dfv.row_id = bs.ROWID
                              AND bs_dfv.xxw_fac_elec IS NOT NULL
                              AND ctl_tax.customer_trx_id = ct.customer_trx_id
                              AND ctl_tax.line_type = 'TAX'
                              AND ctl_tax.extended_amount != 0
                              AND ctl_line.customer_trx_line_id =
                                    ctl_tax.link_to_cust_trx_line_id
                              AND ctl_line.extended_amount = 0 /* facturas de impuestos el importe de la linea estn cero */
                              AND vat.vat_tax_id = ctl_tax.vat_tax_id
                              AND vat_dfv.row_id = vat.ROWID
                              --and     vat_dfv.context_value = 'AFIP'
                              AND vat_dfv.xxw_cod_iva IS NULL
                              AND vat_dfv.xxw_cod_trib IS NOT NULL
                              AND ctl_tax.customer_trx_id = p_customer_trx_id
                              and vat.vat_tax_id = vat_tl.vat_Tax_id
                              --Agregado 20180105
                              and vat.global_attribute1 = jzatc.tax_category_id
                              and jzatc.rowid = jzatc_dfv.row_id
                              and jzatc_dfv.xx_ar_provincia is null
                              and vat_dfv.xxw_cod_trib = '1'
                   GROUP BY   ct.customer_trx_id,
                              --vat_dfv.xxw_cod_trib,
                              replace(jzatc_dfv.xx_ar_provincia,'25','0'),
                              vat_tl.printed_tax_name,
                              bs_dfv.xxw_valores_en_mon_func,
                              ct.exchange_rate,
                              ctl_tax.extended_amount,
                              vat.tax_Rate) xmt
       GROUP BY   substr(xmt.descripcion,1,30), tasa;


        CURSOR c_rec_10 (p_customer_trx_id number)
        IS
        SELECT '100' rec_type,
               customer_trx_id,
               customer_trx_line_id,
               interface_line_context,
               interface_line_attribute6,
               line_number column1,
               codigo       column2,
               null         column3, --ver codigo producto de cliente
               descripcion  column4,
               cantidad     column5,
               codigo_unidad_medida column6,
               precio_unitario      column7, --precio unitario debe incluir el iva (ver de usar la tasa iva)
               tasa_iva             column8,
               importe_iva          column9,
               importe - nvl(importe_iva,0) column10,
               importe_bonificacion column11,
               null column12,
               decode(codigo_condicion_iva,'3','E','G') column13,
               null         column14,
               /*Modificado KHRONUS/E.Sly 20200422 Se corrigen las unidades por bulto*/
               --unidad_mtx   column15,
               unidad_bulto column15,
               /*FIn Modificado KHRONUS/E.Sly 20200422 Se corrigen las unidades por bulto*/
               null         column16,
               null         column17,
               'DU'         column18,
               round(precio_unitario-(nvl(importe_bonificacion,0)/cantidad),3) column19,
               codigo_mtx   column20, --ean13
               null         column21, --dun14
               null         column22,
               unidad_mtx   column23,
               codigo_mtx   column24,
               null         column25
        FROM
            (
           SELECT   ct.customer_trx_id,
                    ctl_line.customer_trx_line_id,
                    ctl_line.interface_line_context,
                    ctl_line.interface_line_attribute6,
                    ctl_line.line_number,
                    /*Agregado KHRONUS/E.Sly 20200422*/
                    NVL(xx_ar_planex_invoices_pk.get_bul_conversion(ctl_line.uom_code,ctl_line.inventory_item_id,ctl_line.warehouse_id)
                     ,DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       --xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))
                       xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code)
                       * (DECODE (mcrd.xx_unidad_mtx, NULL, 1, mcrd.xx_unidad_mtx))
                    )) unidad_bulto,
                    /*FIn Agregado KHRONUS/E.Sly 20200422*/
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       --xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))
                       xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code)
                       * (DECODE (mcrd.xx_unidad_mtx, NULL, 1, mcrd.xx_unidad_mtx))
                    )
                       unidad_mtx,
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   , '97', '', '99', '', cr.cross_reference) codigo_mtx,
                    si.segment1 codigo,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          (ABS(ctl_line.extended_amount
                               + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                    ctl_line.customer_trx_line_id,
                                    ctl_line.extended_amount
                                 )
                               + NVL (
                                    xxw_mtxca_pkg.Importe_IVA (
                                       ctl_line.customer_trx_line_id,
                                       ctl_line.extended_amount
                                    ),
                                    0
                                 ))
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Recargo (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_Recargo (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_Bonificacion (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1)),
                          ABS(ABS(ctl_line.extended_amount
                                  + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                       ctl_line.customer_trx_line_id,
                                       ctl_line.extended_amount
                                    )
                                  + NVL (
                                       xxw_mtxca_pkg.Importe_IVA (
                                          ctl_line.customer_trx_line_id,
                                          ctl_line.extended_amount
                                       ),
                                       0
                                    ))
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Recargo (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_Recargo (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_Bonificacion (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1))
                       ),
                       2
                    )
                       importe,
                    sitl.description descripcion,
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       ABS(NVL (ctl_line.quantity_invoiced,
                                ctl_line.quantity_credited))
                    )
                       cantidad,
                    flv.tag codigo_unidad_medida              /*wum.afip_lookup_code*/
                                                ,
                    CASE
                       WHEN DECODE (
                               oola.line_id,
                               NULL,
                               0,
                               xxw_mtxca_pkg.Importe_Recargo (
                                  ctl_line.customer_trx_id,
                                  oola.line_id
                               )
                            ) > 0
                       THEN
                          DECODE (
                             oola.line_id,
                             NULL,
                             0,
                             xxw_mtxca_pkg.PrecioUnitario_Recargo (
                                ctl_line.customer_trx_id,
                                oola.line_id
                             )
                          )
                          + xxw_mtxca_pkg.PrecioUnitario (
                               ctl_line.customer_trx_line_id
                            )
                       ELSE
                          xxw_mtxca_pkg.PrecioUnitario (
                             ctl_line.customer_trx_line_id
                          )
                    END
                       precio_unitario,
                    /* DECODE (flv.tag                             /*wum.afip_lookup_code * /
                                   ,  '97', TO_NUMBER (NULL),  '99', TO_NUMBER (NULL),  0)
                       importe_bonificacion, */
                    DECODE (
                       oola.line_id,
                       NULL,
                       0,
                       ABS(xxw_mtxca_pkg.Importe_Bonificacion (
                              ctl_line.customer_trx_id,
                              oola.line_id
                           ))
                    )
                       importe_bonificacion,
                    xxw_mtxca_pkg.Condicion_IVA (ctl_line.customer_trx_line_id) codigo_condicion_iva,
                   (select vat.tax_rate
                    from  ar_vat_tax_all_b           vat,
                          ar_vat_tax_all_b_dfv       vat_dfv,
                          ra_customer_trx_lines_all  ctl_tax
                    where ctl_tax.link_to_cust_trx_line_id = ctl_line.customer_trx_line_id
                    and   ctl_tax.line_type =  'TAX'
                    and   vat.vat_tax_id = ctl_tax.vat_tax_id
                    and   vat_dfv.row_id = vat.rowid
                    and   vat_dfv.xxw_cod_iva is not null) tasa_iva,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          (ABS(xxw_mtxca_pkg.Importe_IVA (
                                  ctl_line.customer_trx_line_id,
                                  ctl_line.extended_amount
                               ))
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Recargo (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1)),
                          ABS(ABS(xxw_mtxca_pkg.Importe_IVA (
                                     ctl_line.customer_trx_line_id,
                                     ctl_line.extended_amount
                                  ))
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Recargo (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1))
                       ),
                       2
                    )
                       importe_iva
             FROM   apps.mtl_cross_references cr,
                    mtl_system_items_tl sitl,
                    mtl_system_items_b si,
                    ra_customer_trx_lines_all ctl_line,
                    ra_customer_trx_all ct,
                    ra_batch_sources_all_dfv bs_dfv,
                    ra_batch_sources_all bs,
                    xxw_fe_param fp,
                    fnd_lookup_values flv,
                    oe_order_lines_all oola,
                    mtl_cross_references_dfv mcrd
            WHERE       1 = 1
                    AND bs.batch_source_id = ct.batch_source_id
                    AND bs_dfv.row_id = bs.ROWID
                    AND bs_dfv.xxw_fac_elec IS NOT NULL
                    AND ct.customer_trx_id = p_customer_trx_id
                    AND ctl_line.customer_trx_id = ct.customer_trx_id
                    AND ctl_line.line_type = 'LINE'
                    AND ctl_line.inventory_item_id IS NOT NULL
                    AND si.inventory_item_id = ctl_line.inventory_item_id
                    AND si.organization_id = ctl_line.warehouse_id
                    AND sitl.inventory_item_id = si.inventory_item_id
                    AND sitl.organization_id = si.organization_id
                    AND sitl.language = USERENV ('LANG')
                    AND flv.lookup_type = 'XX_AR_FC_ELECTRO_UDM'
                    /* 23-Mar-2011 MG: 'XXW_FE_UNIT_OF_MEASURE' */
                    AND UPPER (flv.lookup_code) =
                          NVL (UPPER (ctl_line.uom_code), 'UN')
                    /* 30-Mar-2011 MG: flv.lookup_code*/
                    /* 18-Feb-2014 EDP: flv.meaning*/
                    /* 04-abr-2011 MG: agregado nvl(,'UN') */
                    AND flv.language = 'ESA'
                    /* 04-abr-2011 MG: agregado */
                    AND fp.org_id(+) = ct.org_id
                    AND fp.parameter_code(+) = 'CROSS_REF_GTIN_TYPE'
                    AND cr.inventory_item_id(+) = si.inventory_item_id
                    AND cr.cross_reference_type = NVL (fp.VALUE, 'GTIN')
                    AND mcrd.row_id = cr.ROWID
                    /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                    --AND oola.line_id(+) = ctl_line.interface_line_attribute6
                    AND TO_CHAR(oola.line_id(+)) = ctl_line.interface_line_attribute6
                    /*FIn Modificado Numero no valido*/
                    AND ( (ctl_line.interface_line_attribute6 IS NOT NULL
                           /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                           --AND ctl_line.interface_line_attribute11 = 0)
                           AND ctl_line.interface_line_attribute11 = '0')
                           /*Fin Modificado Numero no valido*/
                         OR ctl_line.interface_line_attribute6 IS NULL)
           UNION ALL
           /* Lineas Memo */
           SELECT   ct.customer_trx_id,
                    ctl_line.customer_trx_line_id,
                    ctl_line.interface_line_context,
                    ctl_line.interface_line_attribute6,
                    ctl_line.line_number,
                    /*Agregado KHRONUS/E.Sly 20200422*/
                    NVL(xx_ar_planex_invoices_pk.get_bul_conversion(ctl_line.uom_code,ctl_line.inventory_item_id,ctl_line.warehouse_id)
                     ,DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   ,
                            '97', TO_NUMBER (NULL),
                            '99', TO_NUMBER (NULL),
                            xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))) unidad_bulto,
                    /*FIn Agregado KHRONUS/E.Sly 20200422*/
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   ,
                            '97', TO_NUMBER (NULL),
                            '99', TO_NUMBER (NULL),
                            xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))
                       unidad_mtx,
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   , '97', '', '99', '', xaml.cod_mtxca /*ml_dfv.xxw_cod_generico*/
                                                                       ) codigo_mtx,
                    mltl.name codigo,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          (ctl_line.extended_amount
                           * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                     'N', 1,
                                     NVL (ct.exchange_rate, 1)))
                          + xxw_mtxca_pkg.Importe_IVA_Incluido (
                               ctl_line.customer_trx_line_id,
                               (ctl_line.extended_amount
                                * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                          'N', 1,
                                          NVL (ct.exchange_rate, 1)))
                            )
                          + NVL (
                               xxw_mtxca_pkg.Importe_IVA (
                                  ctl_line.customer_trx_line_id,
                                  (ctl_line.extended_amount
                                   * DECODE (
                                        NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                        'N',
                                        1,
                                        NVL (ct.exchange_rate, 1)
                                     ))
                               ),
                               0
                            ),
                          ABS( (ctl_line.extended_amount
                                * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                          'N', 1,
                                          NVL (ct.exchange_rate, 1)))
                              + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                   ctl_line.customer_trx_line_id,
                                   (ctl_line.extended_amount
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         NVL (ct.exchange_rate, 1)
                                      ))
                                )
                              + NVL (
                                   xxw_mtxca_pkg.Importe_IVA (
                                      ctl_line.customer_trx_line_id,
                                      (ctl_line.extended_amount
                                       * DECODE (
                                            NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                            'N',
                                            1,
                                            NVL (ct.exchange_rate, 1)
                                         ))
                                   ),
                                   0
                                ))
                       ),
                       2
                    )
                       importe,
                    mltl.description descripcion,
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       ABS(NVL (ctl_line.quantity_invoiced,
                                ctl_line.quantity_credited))
                    )
                       cantidad,
                    flv.tag codigo_unidad_medida              /*wum.afip_lookup_code*/
                                                ,
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       TRUNC (
                          DECODE (
                             ct.invoice_currency_code,
                             'ARS',
                             ABS(ctl_line.unit_selling_price
                                 + (xxw_mtxca_pkg.Importe_IVA_Incluido (
                                       ctl_line.customer_trx_line_id,
                                       ctl_line.extended_amount
                                    )
                                    / NVL (ctl_line.quantity_invoiced,
                                           ctl_line.quantity_credited))),
                             ABS( ( (ctl_line.extended_amount
                                     * DECODE (
                                          NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                          'N',
                                          1,
                                          NVL (ct.exchange_rate, 1)
                                       ))
                                   + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                        ctl_line.customer_trx_line_id,
                                        (ctl_line.extended_amount
                                         * DECODE (
                                              NVL (bs_dfv.xxw_valores_en_mon_func,
                                                   'N'),
                                              'N',
                                              1,
                                              NVL (ct.exchange_rate, 1)
                                           ))
                                     ))
                                 / NVL (ctl_line.quantity_invoiced,
                                        ctl_line.quantity_credited))
                          ),
                          6
                       )
                    )
                       precio_unitario,
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   , '97', TO_NUMBER (NULL), '99', TO_NUMBER (NULL), 0)
                       importe_bonificacion,
                    xxw_mtxca_pkg.Condicion_IVA (ctl_line.customer_trx_line_id) codigo_condicion_iva,
                   (select vat.tax_rate
                    from  ar_vat_tax_all_b           vat,
                          ar_vat_tax_all_b_dfv       vat_dfv,
                          ra_customer_trx_lines_all  ctl_tax
                    where ctl_tax.link_to_cust_trx_line_id = ctl_line.customer_trx_line_id
                    and   ctl_tax.line_type =  'TAX'
                    and   vat.vat_tax_id = ctl_tax.vat_tax_id
                    and   vat_dfv.row_id = vat.rowid
                    and   vat_dfv.xxw_cod_iva is not null) tasa_iva,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          xxw_mtxca_pkg.Importe_IVA (
                             ctl_line.customer_trx_line_id,
                             (ctl_line.extended_amount
                              * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                        'N', 1,
                                        NVL (ct.exchange_rate, 1)))
                          ),
                          ABS(xxw_mtxca_pkg.Importe_IVA (
                                 ctl_line.customer_trx_line_id,
                                 (ctl_line.extended_amount
                                  * DECODE (
                                       NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                       'N',
                                       1,
                                       NVL (ct.exchange_rate, 1)
                                    ))
                              ))
                       ),
                       2
                    )
                       importe_iva
             FROM   ar.ar_memo_lines_all_tl mltl,
                    ar.ar_memo_lines_all_b ml,
                    ra_customer_trx_lines_all ctl_line,
                    ra_customer_trx_all ct,
                    ra_batch_sources_all_dfv bs_dfv,
                    ra_batch_sources_all bs,
                    fnd_lookup_values flv,
                    xx_ar_memo_lines xaml
            WHERE       1 = 1
                    AND bs.batch_source_id = ct.batch_source_id
                    AND bs_dfv.row_id = bs.ROWID
                    AND bs_dfv.xxw_fac_elec IS NOT NULL
                    AND ct.customer_trx_id = p_customer_trx_id
                    AND ctl_line.customer_trx_id = ct.customer_trx_id
                    AND ctl_line.line_type = 'LINE'
                    AND ctl_line.memo_line_id IS NOT NULL
                    AND ml.memo_line_id = ctl_line.memo_line_id
                    AND ml.org_id = ctl_line.org_id
                    AND mltl.memo_line_id = ml.memo_line_id
                    AND mltl.language = USERENV ('LANG')
                    AND mltl.org_id = ml.org_id
                    AND flv.lookup_type = 'XX_AR_FC_ELECTRO_UDM'
                    /* 23-Mar-2011 MG: 'XXW_FE_UNIT_OF_MEASURE' */
                    AND UPPER (flv.lookup_code) =
                          NVL (UPPER (ctl_line.uom_code), 'UN')
                    /* 30-Mar-2011 MG: flv.lookup_code*/
                    /* 18-Feb-2014 EDP: flv.meaning*/
                    /* 04-abr-2011 MG: agregado nvl(,'UN') */
                    AND flv.language = 'ESA'
                    /* 04-abr-2011 MG: agregado */
                    AND ML.MEMO_LINE_ID = XAML.MEMO_LINE_ID);



        CURSOR c_rec_10_inc (p_customer_trx_id number)
        IS
        SELECT '100' rec_type,
               customer_trx_id,
               customer_trx_line_id,
               interface_line_context,
               interface_line_attribute6,
               line_number column1,
               codigo       column2,
               null         column3, --ver codigo producto de cliente
               descripcion  column4,
               cantidad,
               codigo_unidad_medida column6,
               precio_unitario, --precio unitario debe incluir el iva (ver de usar la tasa iva)
               tasa_iva             column8,
               importe_iva          column9,
               importe - nvl(importe_iva,0) column10,
               importe_bonificacion column11,
               null column12,
               decode(codigo_condicion_iva,'3','E','G') column13,
               null         column14,
               /*Modificado KHRONUS/E.Sly 20200422 Se corrigen las unidades por bulto*/
               --unidad_mtx   column15,
               unidad_bulto column15,
               /*FIn Modificado KHRONUS/E.Sly 20200422 Se corrigen las unidades por bulto*/
               null         column16,
               null         column17,
               'CU'         column18,
               codigo_mtx   column20, --ean13
               null         column21, --dun14
               null         column22,
               unidad_mtx   column23,
               codigo_mtx   column24,
               null         column25,
               uom_code,
               organization_id,
               inventory_item_id
        FROM
            (
           SELECT   ct.customer_trx_id,
                    ctl_line.customer_trx_line_id,
                    ctl_line.interface_line_context,
                    ctl_line.interface_line_attribute6,
                    ctl_line.line_number,
                    /*Agregado KHRONUS/E.Sly 20200422*/
                    NVL(xx_ar_planex_invoices_pk.get_bul_conversion(ctl_line.uom_code,ctl_line.inventory_item_id,ctl_line.warehouse_id)
                     ,DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       --xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))
                       xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code)
                       * (DECODE (mcrd.xx_unidad_mtx, NULL, 1, mcrd.xx_unidad_mtx))
                    )) unidad_bulto,
                    /*FIn Agregado KHRONUS/E.Sly 20200422*/
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       --xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))
                       xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code)
                       * (DECODE (mcrd.xx_unidad_mtx, NULL, 1, mcrd.xx_unidad_mtx))
                    )
                       unidad_mtx,
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   , '97', '', '99', '', cr.cross_reference) codigo_mtx,
                    si.segment1 codigo,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          (ABS(ctl_line.extended_amount
                               + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                    ctl_line.customer_trx_line_id,
                                    ctl_line.extended_amount
                                 )
                               + NVL (
                                    xxw_mtxca_pkg.Importe_IVA (
                                       ctl_line.customer_trx_line_id,
                                       ctl_line.extended_amount
                                    ),
                                    0
                                 ))
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Recargo (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_Recargo (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_Bonificacion (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1)),
                          ABS(ABS(ctl_line.extended_amount
                                  + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                       ctl_line.customer_trx_line_id,
                                       ctl_line.extended_amount
                                    )
                                  + NVL (
                                       xxw_mtxca_pkg.Importe_IVA (
                                          ctl_line.customer_trx_line_id,
                                          ctl_line.extended_amount
                                       ),
                                       0
                                    ))
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Recargo (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_Recargo (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_Bonificacion (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1))
                       ),
                       2
                    )
                       importe,
                    sitl.description descripcion,
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       ABS(NVL (ctl_line.quantity_invoiced,
                                ctl_line.quantity_credited))
                    )
                       cantidad,
                    flv.tag codigo_unidad_medida              /*wum.afip_lookup_code*/
                                                ,
                    CASE
                       WHEN DECODE (
                               oola.line_id,
                               NULL,
                               0,
                               xxw_mtxca_pkg.Importe_Recargo (
                                  ctl_line.customer_trx_id,
                                  oola.line_id
                               )
                            ) > 0
                       THEN
                          DECODE (
                             oola.line_id,
                             NULL,
                             0,
                             xxw_mtxca_pkg.PrecioUnitario_Recargo (
                                ctl_line.customer_trx_id,
                                oola.line_id
                             )
                          )
                          + xxw_mtxca_pkg.PrecioUnitario (
                               ctl_line.customer_trx_line_id
                            )
                       ELSE
                          xxw_mtxca_pkg.PrecioUnitario (
                             ctl_line.customer_trx_line_id
                          )
                    END
                       precio_unitario,
                    /* DECODE (flv.tag                             /*wum.afip_lookup_code * /
                                   ,  '97', TO_NUMBER (NULL),  '99', TO_NUMBER (NULL),  0)
                       importe_bonificacion, */
                    DECODE (
                       oola.line_id,
                       NULL,
                       0,
                       ABS(xxw_mtxca_pkg.Importe_Bonificacion (
                              ctl_line.customer_trx_id,
                              oola.line_id
                           ))
                    )
                       importe_bonificacion,
                    xxw_mtxca_pkg.Condicion_IVA (ctl_line.customer_trx_line_id) codigo_condicion_iva,
                   (select vat.tax_rate
                    from  ar_vat_tax_all_b           vat,
                          ar_vat_tax_all_b_dfv       vat_dfv,
                          ra_customer_trx_lines_all  ctl_tax
                    where ctl_tax.link_to_cust_trx_line_id = ctl_line.customer_trx_line_id
                    and   ctl_tax.line_type =  'TAX'
                    and   vat.vat_tax_id = ctl_tax.vat_tax_id
                    and   vat_dfv.row_id = vat.rowid
                    and   vat_dfv.xxw_cod_iva is not null) tasa_iva,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          (ABS(xxw_mtxca_pkg.Importe_IVA (
                                  ctl_line.customer_trx_line_id,
                                  ctl_line.extended_amount
                               ))
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             )
                           + DECODE (
                                oola.line_id,
                                NULL,
                                0,
                                xxw_mtxca_pkg.Importe_IVA_Recargo (
                                   ctl_line.customer_trx_id,
                                   oola.line_id
                                )
                             ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1)),
                          ABS(ABS(xxw_mtxca_pkg.Importe_IVA (
                                     ctl_line.customer_trx_line_id,
                                     ctl_line.extended_amount
                                  ))
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Bonificacion (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                )
                              + DECODE (
                                   oola.line_id,
                                   NULL,
                                   0,
                                   xxw_mtxca_pkg.Importe_IVA_Recargo (
                                      ctl_line.customer_trx_id,
                                      oola.line_id
                                   )
                                ))
                          * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                    'N', 1,
                                    NVL (ct.exchange_rate, 1))
                       ),
                       2
                    )
                       importe_iva,
                    NVL (UPPER (ctl_line.uom_code), 'UN') uom_code,
                    si.organization_id,
                    si.inventory_item_id
             FROM   apps.mtl_cross_references cr,
                    mtl_system_items_tl sitl,
                    mtl_system_items_b si,
                    ra_customer_trx_lines_all ctl_line,
                    ra_customer_trx_all ct,
                    ra_batch_sources_all_dfv bs_dfv,
                    ra_batch_sources_all bs,
                    xxw_fe_param fp,
                    fnd_lookup_values flv,
                    oe_order_lines_all oola,
                    mtl_cross_references_dfv mcrd
            WHERE       1 = 1
                    AND bs.batch_source_id = ct.batch_source_id
                    AND bs_dfv.row_id = bs.ROWID
                    AND bs_dfv.xxw_fac_elec IS NOT NULL
                    AND ct.customer_trx_id = p_customer_trx_id
                    AND ctl_line.customer_trx_id = ct.customer_trx_id
                    AND ctl_line.line_type = 'LINE'
                    AND ctl_line.inventory_item_id IS NOT NULL
                    AND si.inventory_item_id = ctl_line.inventory_item_id
                    AND si.organization_id = ctl_line.warehouse_id
                    AND sitl.inventory_item_id = si.inventory_item_id
                    AND sitl.organization_id = si.organization_id
                    AND sitl.language = USERENV ('LANG')
                    AND flv.lookup_type = 'XX_AR_FC_ELECTRO_UDM'
                    /* 23-Mar-2011 MG: 'XXW_FE_UNIT_OF_MEASURE' */
                    AND UPPER (flv.lookup_code) = 'BOL' --NVL (UPPER (ctl_line.uom_code), 'UN')
                    /* 30-Mar-2011 MG: flv.lookup_code*/
                    /* 18-Feb-2014 EDP: flv.meaning*/
                    /* 04-abr-2011 MG: agregado nvl(,'UN') */
                    AND flv.language = 'ESA'
                    /* 04-abr-2011 MG: agregado */
                    AND fp.org_id(+) = ct.org_id
                    AND fp.parameter_code(+) = 'CROSS_REF_GTIN_TYPE'
                    AND cr.inventory_item_id(+) = si.inventory_item_id
                    AND cr.cross_reference_type = NVL (fp.VALUE, 'GTIN')
                    AND mcrd.row_id = cr.ROWID
                    /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                    --AND oola.line_id(+) = ctl_line.interface_line_attribute6
                    AND TO_CHAR(oola.line_id(+)) = ctl_line.interface_line_attribute6
                    /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                    AND ( (ctl_line.interface_line_attribute6 IS NOT NULL
                    /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                           --AND ctl_line.interface_line_attribute11 = 0)
                           AND ctl_line.interface_line_attribute11 = '0')
                           /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                         OR ctl_line.interface_line_attribute6 IS NULL)
           UNION ALL
           /* Lineas Memo */
           SELECT   ct.customer_trx_id,
                    ctl_line.customer_trx_line_id,
                    ctl_line.interface_line_context,
                    ctl_line.interface_line_attribute6,
                    ctl_line.line_number,
                    /*Agregado KHRONUS/E.Sly 20200422*/
                    NVL(xx_ar_planex_invoices_pk.get_bul_conversion(ctl_line.uom_code,ctl_line.inventory_item_id,ctl_line.warehouse_id)
                     ,DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   ,
                            '97', TO_NUMBER (NULL),
                            '99', TO_NUMBER (NULL),
                            xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))) unidad_bulto,
                    /*FIn Agregado KHRONUS/E.Sly 20200422*/
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   ,
                            '97', TO_NUMBER (NULL),
                            '99', TO_NUMBER (NULL),
                            xxw_mtxca_pkg.Unidad_MTX (ctl_line.uom_code))
                       unidad_mtx,
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   , '97', '', '99', '', xaml.cod_mtxca /*ml_dfv.xxw_cod_generico*/
                                                                       ) codigo_mtx,
                    mltl.name codigo,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          (ctl_line.extended_amount
                           * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                     'N', 1,
                                     NVL (ct.exchange_rate, 1)))
                          + xxw_mtxca_pkg.Importe_IVA_Incluido (
                               ctl_line.customer_trx_line_id,
                               (ctl_line.extended_amount
                                * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                          'N', 1,
                                          NVL (ct.exchange_rate, 1)))
                            )
                          + NVL (
                               xxw_mtxca_pkg.Importe_IVA (
                                  ctl_line.customer_trx_line_id,
                                  (ctl_line.extended_amount
                                   * DECODE (
                                        NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                        'N',
                                        1,
                                        NVL (ct.exchange_rate, 1)
                                     ))
                               ),
                               0
                            ),
                          ABS( (ctl_line.extended_amount
                                * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                          'N', 1,
                                          NVL (ct.exchange_rate, 1)))
                              + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                   ctl_line.customer_trx_line_id,
                                   (ctl_line.extended_amount
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         NVL (ct.exchange_rate, 1)
                                      ))
                                )
                              + NVL (
                                   xxw_mtxca_pkg.Importe_IVA (
                                      ctl_line.customer_trx_line_id,
                                      (ctl_line.extended_amount
                                       * DECODE (
                                            NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                            'N',
                                            1,
                                            NVL (ct.exchange_rate, 1)
                                         ))
                                   ),
                                   0
                                ))
                       ),
                       2
                    )
                       importe,
                    mltl.description descripcion,
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       ABS(NVL (ctl_line.quantity_invoiced,
                                ctl_line.quantity_credited))
                    )
                       cantidad,
                    flv.tag codigo_unidad_medida              /*wum.afip_lookup_code*/
                                                ,
                    DECODE (
                       flv.tag                                /*wum.afip_lookup_code*/
                              ,
                       '97',
                       TO_NUMBER (NULL),
                       '99',
                       TO_NUMBER (NULL),
                       TRUNC (
                          DECODE (
                             ct.invoice_currency_code,
                             'ARS',
                             ABS(ctl_line.unit_selling_price
                                 + (xxw_mtxca_pkg.Importe_IVA_Incluido (
                                       ctl_line.customer_trx_line_id,
                                       ctl_line.extended_amount
                                    )
                                    / NVL (ctl_line.quantity_invoiced,
                                           ctl_line.quantity_credited))),
                             ABS( ( (ctl_line.extended_amount
                                     * DECODE (
                                          NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                          'N',
                                          1,
                                          NVL (ct.exchange_rate, 1)
                                       ))
                                   + xxw_mtxca_pkg.Importe_IVA_Incluido (
                                        ctl_line.customer_trx_line_id,
                                        (ctl_line.extended_amount
                                         * DECODE (
                                              NVL (bs_dfv.xxw_valores_en_mon_func,
                                                   'N'),
                                              'N',
                                              1,
                                              NVL (ct.exchange_rate, 1)
                                           ))
                                     ))
                                 / NVL (ctl_line.quantity_invoiced,
                                        ctl_line.quantity_credited))
                          ),
                          6
                       )
                    )
                       precio_unitario,
                    DECODE (flv.tag                           /*wum.afip_lookup_code*/
                                   , '97', TO_NUMBER (NULL), '99', TO_NUMBER (NULL), 0)
                       importe_bonificacion,
                    xxw_mtxca_pkg.Condicion_IVA (ctl_line.customer_trx_line_id) codigo_condicion_iva,
                   (select vat.tax_rate
                    from  ar_vat_tax_all_b           vat,
                          ar_vat_tax_all_b_dfv       vat_dfv,
                          ra_customer_trx_lines_all  ctl_tax
                    where ctl_tax.link_to_cust_trx_line_id = ctl_line.customer_trx_line_id
                    and   ctl_tax.line_type =  'TAX'
                    and   vat.vat_tax_id = ctl_tax.vat_tax_id
                    and   vat_dfv.row_id = vat.rowid
                    and   vat_dfv.xxw_cod_iva is not null) tasa_iva,
                    ROUND (
                       DECODE (
                          flv.tag                             /*wum.afip_lookup_code*/
                                 ,
                          '99',
                          xxw_mtxca_pkg.Importe_IVA (
                             ctl_line.customer_trx_line_id,
                             (ctl_line.extended_amount
                              * DECODE (NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                        'N', 1,
                                        NVL (ct.exchange_rate, 1)))
                          ),
                          ABS(xxw_mtxca_pkg.Importe_IVA (
                                 ctl_line.customer_trx_line_id,
                                 (ctl_line.extended_amount
                                  * DECODE (
                                       NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                       'N',
                                       1,
                                       NVL (ct.exchange_rate, 1)
                                    ))
                              ))
                       ),
                       2
                    )
                       importe_iva,
                    NVL (UPPER (ctl_line.uom_code), 'UN') uom_code,
                    to_number(null) organization_id,
                    to_number(null) inventory_item_id
             FROM   ar.ar_memo_lines_all_tl mltl,
                    ar.ar_memo_lines_all_b ml,
                    ra_customer_trx_lines_all ctl_line,
                    ra_customer_trx_all ct,
                    ra_batch_sources_all_dfv bs_dfv,
                    ra_batch_sources_all bs,
                    fnd_lookup_values flv,
                    xx_ar_memo_lines xaml
            WHERE       1 = 1
                    AND bs.batch_source_id = ct.batch_source_id
                    AND bs_dfv.row_id = bs.ROWID
                    AND bs_dfv.xxw_fac_elec IS NOT NULL
                    AND ct.customer_trx_id = p_customer_trx_id
                    AND ctl_line.customer_trx_id = ct.customer_trx_id
                    AND ctl_line.line_type = 'LINE'
                    AND ctl_line.memo_line_id IS NOT NULL
                    AND ml.memo_line_id = ctl_line.memo_line_id
                    AND ml.org_id = ctl_line.org_id
                    AND mltl.memo_line_id = ml.memo_line_id
                    AND mltl.language = USERENV ('LANG')
                    AND mltl.org_id = ml.org_id
                    AND flv.lookup_type = 'XX_AR_FC_ELECTRO_UDM'
                    /* 23-Mar-2011 MG: 'XXW_FE_UNIT_OF_MEASURE' */
                    AND UPPER (flv.lookup_code) = 'BOL'--NVL (UPPER (ctl_line.uom_code), 'UN')
                    /* 30-Mar-2011 MG: flv.lookup_code*/
                    /* 18-Feb-2014 EDP: flv.meaning*/
                    /* 04-abr-2011 MG: agregado nvl(,'UN') */
                    AND flv.language = 'ESA'
                    /* 04-abr-2011 MG: agregado */
                    AND ML.MEMO_LINE_ID = XAML.MEMO_LINE_ID);

        CURSOR c_rec_12 (p_customer_trx_id number
                        ,p_oe_line_id varchar2)
        IS
        SELECT  '120' rec_type,
                xmt.customer_trx_id,
                xmt.interface_line_attribute6,
                xmt.codigo,
                xmt.descripcion,
                --'C06' column2,
                xmt.xx_ar_planex_code column2,
                xmt.tasa column3,
                ABS (SUM (xmt.base_imponible)) column4,
                ABS (SUM (xmt.importe)) column5
           FROM   (  SELECT   ct.customer_trx_id,
                              ctl_line.interface_line_attribute6,
                              vat_dfv.xxw_cod_trib codigo,
                              jzatc_dfv.xx_ar_planex_code,
                              vat.tax_code descripcion,    /* o vat.description */
                              /*Modificado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              --vat.tax_Rate tasa
                              CASE
                               WHEN vat.tax = 'TOPTU' THEN
                                 ROUND((ctl_tax.extended_amount*100)/NVL((select extended_amount
                                                                            from ra_customer_trx_lines_all
                                                                           where customer_trx_line_id = ctl_tax.link_to_cust_trx_line_id),1),2)
                              ELSE
                                vat.tax_Rate
                              END tasa,
                              /*Fin Modificado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_line.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                                /*)  20171106 */
                                  ,
                                 2
                              )
                                 base_imponible,
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_tax.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                               /* )  20171106 */
                                  ,
                                 2
                              )
                                 importe
                       FROM   ar_vat_tax_all_b_dfv vat_dfv,
                              ar_vat_tax_all_b vat,
                              ra_customer_trx_lines_all ctl_tax,
                              ra_customer_trx_lines_all ctl_line,
                              ra_customer_trx_all ct,
                              ra_batch_sources_all_dfv bs_dfv,
                              ra_batch_sources_all bs,
                              jl_zz_ar_tx_categ_all jzatc,
                              jl_zz_ar_tx_categ_all_dfv jzatc_dfv
                      WHERE       bs.batch_source_id = ct.batch_source_id
                              AND bs_dfv.row_id = bs.ROWID
                              AND bs_dfv.xxw_fac_elec IS NOT NULL
                              AND ctl_tax.customer_trx_id = ct.customer_trx_id
                              AND ctl_tax.line_type = 'TAX'
                              AND ctl_tax.extended_amount != 0
                              AND ctl_line.customer_trx_line_id =
                                    ctl_tax.link_to_cust_trx_line_id
                              AND ctl_line.extended_amount != 0 /* no es factura de impuestos, existe importe de la linea */
                              AND vat.vat_tax_id = ctl_tax.vat_tax_id
                              AND vat_dfv.row_id = vat.ROWID
                              --and     vat_dfv.context_value = 'AFIP'
                              AND vat_dfv.xxw_cod_iva IS NULL
                              AND vat_dfv.xxw_cod_trib IS NOT NULL
                              AND ctl_line.interface_line_context = 'ORDER ENTRY'
                              /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                              --AND ctl_line.interface_line_attribute6 = p_oe_line_id
                              AND ctl_line.interface_line_attribute6 = TO_CHAR(p_oe_line_id)
                              /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                              AND ctl_line.customer_trx_id = p_customer_trx_id
                              AND vat.global_attribute1 = jzatc.tax_category_id (+)
                              AND vat.org_id = jzatc.org_id (+)
                              AND jzatc.rowid = jzatc_dfv.row_id (+)
                   GROUP BY   ct.customer_trx_id,
                              ctl_line.interface_line_attribute6,
                              vat_dfv.xxw_cod_trib,
                              jzatc_dfv.xx_ar_planex_code,
                              vat.tax_code,
                              vat.tax_rate,
                              /*Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              vat.tax,
                              ctl_tax.link_to_cust_trx_line_id,
                              /*Fin Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              bs_dfv.xxw_valores_en_mon_func,
                              ct.exchange_rate,
                              ctl_tax.extended_amount
                   UNION ALL
                     /* tributos en facturas de impuestos */
                     SELECT   ct.customer_trx_id,
                              ctl_line.interface_line_attribute6,
                              vat_dfv.xxw_cod_trib codigo,
                              jzatc_dfv.xx_ar_planex_code,
                              vat.tax_code descripcion,    /* o vat.description */
                              /*Modificado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              --vat.tax_rate tasa
                              CASE
                               WHEN vat.tax = 'TOPTU' THEN
                                 ROUND((ctl_tax.extended_amount*100)/NVL((select extended_amount
                                                                            from ra_customer_trx_lines_all
                                                                           where customer_trx_line_id = ctl_tax.link_to_cust_trx_line_id),1),2)
                              ELSE
                                vat.tax_Rate
                              END tasa,
                              /*Fin Modificado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_line.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                            /*ABS )  20171106 */
                                  ,
                                 2
                              )
                                 base_imponible,
                              ROUND (
                                 /* ABS (  20171106 */
                                 NVL (
                                    SUM (ctl_tax.extended_amount)
                                    * DECODE (
                                         NVL (bs_dfv.xxw_valores_en_mon_func, 'N'),
                                         'N',
                                         1,
                                         'Y',
                                         NVL (ct.exchange_rate, 1)
                                      ),
                                    0
                                 )                               /* )  20171106 */
                                  ,
                                 2
                              )
                                 importe
                       FROM   ar_vat_tax_all_b_dfv vat_dfv,
                              ar_vat_tax_all_b vat,
                              ra_customer_trx_lines_all ctl_tax,
                              ra_customer_trx_lines_all ctl_line,
                              ra_customer_trx_all ct,
                              ra_batch_sources_all_dfv bs_dfv,
                              ra_batch_sources_all bs,
                              jl_zz_ar_tx_categ_all jzatc,
                              jl_zz_ar_tx_categ_all_dfv jzatc_dfv
                      WHERE       bs.batch_source_id = ct.batch_source_id
                              AND bs_dfv.row_id = bs.ROWID
                              AND bs_dfv.xxw_fac_elec IS NOT NULL
                              AND ctl_tax.customer_trx_id = ct.customer_trx_id
                              AND ctl_tax.line_type = 'TAX'
                              AND ctl_tax.extended_amount != 0
                              AND ctl_line.customer_trx_line_id =
                                    ctl_tax.link_to_cust_trx_line_id
                              AND ctl_line.extended_amount = 0 /* facturas de impuestos el importe de la linea estn cero */
                              AND vat.vat_tax_id = ctl_tax.vat_tax_id
                              AND vat_dfv.row_id = vat.ROWID
                              --and     vat_dfv.context_value = 'AFIP'
                              AND vat_dfv.xxw_cod_iva IS NULL
                              AND vat_dfv.xxw_cod_trib IS NOT NULL
                              AND ctl_line.interface_line_context = 'ORDER ENTRY'
                              /*Modificado KHRONUS/E.Sly 20200424 Convertido a CHAR por Error Numero no valido*/
                              --AND ctl_line.interface_line_attribute6 = p_oe_line_id
                              AND ctl_line.interface_line_attribute6 = TO_CHAR(p_oe_line_id)
                              /*Fin Modificado Numero no Valido*/
                              AND ctl_line.customer_trx_id = p_customer_trx_id
                              AND vat.global_attribute1 = jzatc.tax_category_id (+)
                              AND vat.org_id = jzatc.org_id (+)
                              AND jzatc.rowid = jzatc_dfv.row_id (+)
                   GROUP BY   ct.customer_trx_id,
                              ctl_line.interface_line_attribute6,
                              vat_dfv.xxw_cod_trib,
                              jzatc_dfv.xx_ar_planex_code,
                              vat.tax_code,
                              vat.tax_rate,
                              /*Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              vat.tax,
                              ctl_tax.link_to_cust_trx_line_id,
                              /*Fin Agregado Khronus/E.Sly 20190902 Se calcula el impuesto para Tucuman*/
                              bs_dfv.xxw_valores_en_mon_func,
                              ct.exchange_rate,
                              ctl_tax.extended_amount) xmt
       GROUP BY   xmt.customer_trx_id,
                  xmt.interface_line_attribute6,
                  xmt.codigo,
                  xmt.tasa,
                  xmt.descripcion,
                  xmt.xx_ar_planex_code;

        e_cust_exception      EXCEPTION;
        v_error_message          VARCHAR2(2000);
        v_status                VARCHAR2(2);
        v_Fact_exportadas      VARCHAR2(10):=NULL;
        v_Fact_mapeadas          VARCHAR2(10):=NULL;
        Xml_Batch              VARCHAR2(4000);
        Xml_Invoice              VARCHAR2(8000);
        Xml_Line              VARCHAR2(4000);
        Xml_Tax                  VARCHAR2(4000);

        v_total_neto_grav_orig          VARCHAR2(100);
        v_total_concepto_no_grav_orig   VARCHAR2(100);
        v_tot_oper_exent                NUMBER;
        v_tot_oper_exent_orig           NUMBER;
        v_impuesto_liq_orig             VARCHAR2(100);
        v_total_neto_grav               VARCHAR2(100);
        v_total_concepto_no_grav        VARCHAR2(100);
        v_impuesto_liq                  VARCHAR2(100);
        v_precio_unitario               NUMBER;
        v_precio_unitario_orig          NUMBER;
        v_numero_linea          NUMBER;
        v_buque_dato            VARCHAR2(500);
        v_puerto_dato           VARCHAR2(500);
        v_cond_iva_org          VARCHAR2(20);
        v_cuit_receptor         VARCHAR2(20);

        v_suma_total            NUMBER := 0;
        v_moneda_funcional      VARCHAR2(10);

        v_line_context          VARCHAR2(30);
        v_count                 NUMBER := 0;
        v_date                  VARCHAR2(30);
        v_situacion_iva         NUMBER;
        v_cantidad              NUMBER;
        v_precio_sin_imp        NUMBER;
        v_conv                  NUMBER;

        /*Modificado Khronus/E.Sly 20190503 Se Modifica nombre de archivo segun la compa?ia que lo ejecuta*/
        v_prefile_name          VARCHAR2(10);
        /*Fin Modificado Khronus/E.Sly 20190503 Se Modifica nombre de archivo segun la compa?ia que lo ejecuta*/

    BEGIN

        fnd_file.put_line(fnd_file.LOG,'XX_AR_PLANEX_INVOICES_PK.main (+)');

        print_log('p_date_from: '||p_date_from);
        print_log('p_date_to: '||p_date_to);
        print_log('p_batch_source_id: '||p_batch_source_id);
        print_log('p_trx_number_from: '||p_trx_number_from);
        print_log('p_trx_number_to: '||p_trx_number_to);
        print_log('p_cust_account_id: '||p_cust_account_id);
        print_log('p_path:'||p_path);

        IF p_path IS NULL THEN
            errbuf := 'El Parametro P_PATH esta nulo';
            raise e_cust_exception;
        END IF;

        BEGIN
          SELECT   currency_code
            INTO   v_moneda_funcional
            FROM   gl_sets_of_books gsob
                  ,hr_operating_units hou
           WHERE   gsob.set_of_books_id = hou.set_of_books_id
             AND   hou.organization_id = g_org_id;
        EXCEPTION
          WHEN OTHERS THEN
             v_moneda_funcional := NULL;
        END;

        /*Modificado Khronus/E.Sly 20190503 Se Modifica nombre de archivo segun la compa?ia que lo ejecuta*/
        select decode(g_org_id,104,'PILAGA',2235,'L3N',g_org_id)
        into v_prefile_name
        from dual;
        /*Fin Modificado Khronus/E.Sly 20190503 Se Modifica nombre de archivo segun la compa?ia que lo ejecuta*/

        v_date := to_char(sysdate,'YYYYMMDDHH24MMSS');
        /*Modificado Khronus/E.Sly 20190503 Se Modifica nombre de archivo segun la compa?ia que lo ejecuta*/
        --g_FileHandle := utl_file.fopen(p_path,'PILAGA_'||v_date||'.plx','w');
        /*Modificado KHRONUS/E.Sly 20200603 Se modifica nombre por ejecucion desde FEAR*/
        --g_FileHandle := utl_file.fopen(p_path,v_prefile_name||'_'||v_date||'.plx','w');
        g_FileHandle := utl_file.fopen(p_path,v_prefile_name||'_'||fnd_global.conc_request_id||'.plx','w');

        fnd_file.put_line(fnd_file.log,'Generando Archivo '||v_prefile_name||'_'||fnd_global.conc_request_id||'.plx');
        /*Fin Modificado KHRONUS/E.Sly 20200603 Se modifica nombre por ejecucion desde FEAR*/
        /*Fin Modificado Khronus/E.Sly 20190503 Se Modifica nombre de archivo segun la compa?ia que lo ejecuta*/

        FOR r_inv IN c_invoices LOOP

            print_log('XX_AR_PLANEX_INVOICES_PK.main Invoice:'||to_char(r_inv.customer_trx_id)||' (+)');

            /*
            BEGIN
                        SELECT SUBSTR (attr_val_desc, 0, 2)
                          INTO v_cond_iva_org
                          FROM jl_zz_ar_tx_att_val_v
                         WHERE (tax_category_id = p_vat_category_id)
                           AND (tax_attribute_type LIKE 'ORGANIZATION_ATTRIBUTE')
                           AND (tax_attribute_name = 'VAT REGISTERED')
                           AND SUBSTR (attr_val_desc, 0, 1) = '0';
            EXCEPTION
             WHEN OTHERS THEN
               p_error_message := 'Error al obtener la condicion de IVA de la Empresa';
               RAISE e_cust_exception;
            END;*/

                FOR r_rec IN c_rec_0 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 000 (+)');

                    clear_fields;

                    v_cuit_receptor := LPAD(TO_CHAR(r_rec.column2),11,'0');

                    g_field0    := r_rec.rec_type;
                    g_field1    := LPAD(r_rec.column1,2,' ');
                    g_field2    := LPAD(TO_CHAR(r_rec.column2),11,'0');
                    g_field3    := LPAD(r_rec.column3,2,' ');
                    g_field4    := LPAD(r_rec.column4,11,'0');
                    g_field5    := LPAD(TO_CHAR(r_rec.column5),4,'0');
                    g_field6    := LPAD(TO_CHAR(r_rec.column6),3,'0');
                    g_field7    := LPAD(TO_CHAR(r_rec.column7),8,'0');
                    g_field8    := LPAD(TO_CHAR(r_rec.column8*100),15,'0');
                    g_field9    := LPAD(TO_CHAR(r_rec.column9*100),15,'0');
                    g_field10   := LPAD(TO_CHAR(r_rec.column10*100),15,'0');
                    g_field11   := LPAD(TO_CHAR(r_rec.column11*100),15,'0');
                    g_field12   := LPAD(TO_CHAR(r_rec.column12*100),15,'0');
                    g_field13   := LPAD(TO_CHAR(r_rec.column13*100),15,'0');
                    g_field14   := r_rec.column14;
                    g_field15   := r_rec.column15;
                    g_field16   := r_rec.column16;
                    g_field17   := r_rec.column17;
                    g_field18   := r_rec.column18;

                    print_out(18);

                    insert_rec;

                    print_log('Registro Rec 000 (-)');
                END;
                END LOOP;


                FOR r_rec IN c_rec_1 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 010 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := LPAD(TO_CHAR(r_rec.column1),3,'0');
                    g_field2    := LPAD(TO_CHAR(r_rec.column2),8,'0');
                    g_field3    := LPAD(TO_CHAR(r_rec.column3),8,'0');
                    g_field4    := LPAD(TO_CHAR(r_rec.column4),4,'0');
                    g_field5    := r_rec.column5;
                    g_field6    := r_rec.column6;
                    g_field7    := r_rec.column7;
                    g_field8    := r_rec.column8;
                    g_field9    := r_rec.column9;
                    g_field10   := r_rec.column10;
                    g_field11   := r_rec.column11;
                    g_field12   := r_rec.column12;
                    g_field13   := r_rec.column13;
                    g_field14   := r_rec.column14;
                    g_field15   := r_rec.column15;
                    g_field16   := r_rec.column16;
                    g_field17   := r_rec.column17;
                    g_field18   := r_rec.column18;
                    g_field19   := r_rec.column19;
                    g_field20   := r_rec.column20;
                    g_field21   := r_rec.column21;
                    g_field22   := r_rec.column22;
                    g_field23   := r_rec.column23;
                    g_field24   := r_rec.column24;
                    g_field25   := r_rec.column25;

                    print_out(25);
                    insert_rec;

                    print_log('Registro Rec 010 (-)');
                END;
                END LOOP;

                --Registro 012: Hay que crearlo, es crear un registro al cual se le pasa el ID de la factura
                --Agregado KHRONUS/MNazarre 20180608: Se agrego logica para casos especificos de clientes
                IF r_inv.xx_ar_planex_codigo = 'INC' THEN

                    print_log('Registro Rec 012 (+)');

                    clear_fields;

                    g_field0    := '012';
                    g_field1    := TO_CHAR(r_inv.customer_trx_id);

                    print_out(1);
                    insert_rec;

                    print_log('Registro Rec 012 (-)');

                END IF;
                --Fin Agregado KHRONUS/MNazarre 20180608: Se agrego logica para casos especificos de clientes


                --Agregado KHRONUS/MNazarre 20180608: Se agrego logica para casos especificos de clientes
                --IF r_inv.xx_ar_planex_codigo = 'INC' THEN
                IF r_inv.xx_ar_planex_codigo IN ('INC','WM') THEN

                    FOR r_rec IN c_rec_2_inc (r_inv.customer_trx_id) LOOP
                    BEGIN
                        print_log('Registro Rec 020 INC(+)');

                        clear_fields;

                        g_field0    := r_rec.rec_type;
                        g_field1    := r_rec.column1;
                        g_field2    := r_rec.column2;
                        g_field3    := r_rec.column3;
                        g_field4    := r_rec.column4;
                        g_field5    := null; --v_cuit_receptor;

                        print_out(5);
                        insert_rec;

                        print_log('Registro Rec 020 INC(-)');
                    END;
                    END LOOP;

                ELSE
                    FOR r_rec IN c_rec_2 (r_inv.customer_trx_id) LOOP
                    BEGIN
                        print_log('Registro Rec 020 (+)');

                        clear_fields;

                        g_field0    := r_rec.rec_type;
                        g_field1    := r_rec.column1;
                        g_field2    := r_rec.column2;
                        g_field3    := r_rec.column3;
                        g_field4    := r_rec.column4;
                        g_field5    := null; --v_cuit_receptor;

                        print_out(5);
                        insert_rec;

                        print_log('Registro Rec 020 (-)');
                    END;
                    END LOOP;
                END IF;

                FOR r_rec IN c_rec_3 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 030 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := r_rec.column1;
                    g_field2    := r_rec.column2;
                    g_field3    := LPAD(TO_CHAR(r_rec.column3),2,' ');
                    g_field4    := r_rec.column4;
                    g_field5    := r_rec.column5;
                    g_field6    := r_rec.column6;
                    g_field7    := r_rec.column7;
                    g_field8    := r_rec.column8;
                    g_field9    := r_rec.column9;
                    g_field10   := r_rec.column10;
                    g_field11   := r_rec.column11;
                    g_field12   := r_rec.column12;
                    g_field13   := r_rec.column13;
                    g_field14   := r_rec.column14;
                    g_field15   := r_rec.column15;
                    g_field16   := r_rec.column16;
                    g_field17   := r_rec.column17;
                    g_field18   := r_rec.column18;
                    g_field19   := LPAD(TO_CHAR(r_rec.column19),11,'0');
                    g_field20   := r_rec.column20;
                    g_field21   := r_rec.column21;
                    g_field22   := r_rec.column22;
                    g_field23   := r_rec.column23;
                    g_field24   := r_rec.column24;
                    g_field25   := r_rec.column25;

                    print_out(25);
                    insert_rec;

                    print_log('Registro Rec 030 (-)');
                END;
                END LOOP;

                FOR r_rec IN c_rec_4 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 040 (+)');

                    clear_fields;

                    BEGIN
                        SELECT  DECODE(tax_attribute_value, 'INSCRIPTO', 1, 'MONOTRIBUTISTA', 4, 'EXEMPT', 3, ' ') situacion_iva
                        INTO    v_situacion_iva
                        FROM    jl_zz_ar_tx_att_cls
                        WHERE   tax_category_id = 51
                        AND     NVL(enabled_flag, 'N') = 'Y'
                        AND     tax_attr_class_type    = 'CONTRIBUTOR_CLASS'
                        AND     tax_attr_class_code    = (SELECT a.global_attribute8
                                                          /*Modificado Khronus/E.Sly 20180516 Mig R12*/
                                                          --FROM   ra_site_uses hz,
                                                          --       ra_addresses a
                                                          FROM   hz_cust_site_uses hz,
                                                                 hz_cust_acct_sites a
                                                          --WHERE  hz.address_id  = a.address_id
                                                          WHERE hz.cust_acct_site_id = a.cust_acct_site_id
                                                          /*Fin Modificado Khronus/E.Sly 20180516 Mig R12*/
                                                          AND    a.global_attribute9 = 'N'  --CR3668
                                                         -- AND hz.status      = 'A'
                                                          AND   hz.site_use_id = r_rec.ship_to_site_use_id)
                        UNION
                        SELECT DECODE(tax_attribute_value, 'INSCRIPTO', 1, 'MONOTRIBUTISTA', 4, 'EXEMPT', 3, ' ') situacion_iva
                        FROM   apps.jl_zz_ar_tx_cus_cls_v jzat
                              ,apps.hz_cust_site_uses_all hcsu
                              ,apps.hz_cust_acct_sites_all hcsa
                        WHERE  NVL(jzat.enabled_flag, 'N') = 'Y'
                        AND    jzat.tax_category_id = 51
                        AND    hcsa.global_attribute9 = 'Y'
                        AND    hcsa.global_attribute8 = jzat.tax_attr_class_code
                        AND    hcsa.cust_acct_site_id = jzat.address_id
                        AND    hcsu.cust_acct_site_id = hcsa.cust_acct_site_id
                        AND    hcsu.site_use_id       = r_rec.ship_to_site_use_id;
                    EXCEPTION
                        WHEN OTHERS THEN
                            print_log('Error al obtener condicion de IVA del cliente, Error: '||sqlerrm);
                            v_situacion_iva := 1;
                    END;

                    g_field0    := r_rec.rec_type;
                    g_field1    := r_rec.column1;
                    g_field2    := r_rec.column2;
                    g_field3    := r_rec.column3;
                    g_field4    := LPAD(TO_CHAR(v_situacion_iva),2,'0');
                    g_field5    := r_rec.column5;
                    g_field6    := r_rec.column6;
                    g_field7    := r_rec.column7;
                    g_field8    := r_rec.column8;
                    g_field9    := r_rec.column9;
                    g_field10   := r_rec.column10;
                    g_field11   := r_rec.column11;
                    g_field12   := r_rec.column12;
                    g_field13   := r_rec.column13;
                    g_field14   := r_rec.column14;
                    g_field15   := r_rec.column15;
                    g_field16   := r_rec.column16;
                    g_field17   := r_rec.column17;
                    g_field18   := r_rec.column18;
                    g_field19   := r_rec.column19;
                    g_field20   := r_rec.column20;
                    g_field21   := r_rec.column21;
                    g_field22   := r_rec.column22;
                    g_field23   := r_rec.column23;
                    g_field24   := r_rec.column24;
                    g_field25   := r_rec.column25;
                    g_field26   := r_rec.column26;

                    print_out(26);
                    insert_rec;

                    print_log('Registro Rec 040 (-)');
                END;
                END LOOP;


                FOR r_rec IN c_rec_45 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 045 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := r_rec.column1;
                    g_field2    := r_rec.column2;
                    g_field3    := r_rec.column3;
                    g_field4    := LPAD(TO_CHAR(r_rec.column4),2,'0');
                    g_field5    := r_rec.column5;
                    g_field6    := r_rec.column6;
                    g_field7    := r_rec.column7;
                    g_field8    := r_rec.column8;
                    g_field9    := r_rec.column9;
                    g_field10   := r_rec.column10;
                    g_field11   := r_rec.column11;
                    g_field12   := r_rec.column12;
                    g_field13   := r_rec.column13;
                    g_field14   := r_rec.column14;
                    g_field15   := r_rec.column15;
                    g_field16   := r_rec.column16;
                    g_field17   := r_rec.column17;
                    g_field18   := r_rec.column18;
                    g_field19   := r_rec.column19;
                    g_field20   := r_rec.column20;
                    g_field21   := r_rec.column21;
                    g_field22   := r_rec.column22;
                    g_field23   := r_rec.column23;
                    g_field24   := r_rec.column24;
                    g_field25   := r_rec.column25;
                    g_field26   := r_rec.column26;
                    g_field27   := r_rec.column27;

                    print_out(27);
                    insert_rec;

                    print_log('Registro Rec 045 (-)');
                END;
                END LOOP;


                FOR r_rec IN c_rec_5 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 050 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := LPAD(TO_CHAR(r_rec.column1*100),15,'0');
                    g_field2    := LPAD(TO_CHAR(r_rec.column2*100),15,'0');
                    g_field3    := LPAD(TO_CHAR(r_rec.column3*100),15,'0');
                    g_field4    := LPAD(TO_CHAR(r_rec.column4*100),15,'0');
                    g_field5    := LPAD(TO_CHAR(r_rec.column5*100),15,'0');
                    g_field6    := LPAD(TO_CHAR(r_rec.column6*100),15,'0');
                    g_field7    := LPAD(TO_CHAR(r_rec.column7*100),15,'0');
                    g_field8    := LPAD(TO_CHAR(r_rec.column8*100),15,'0');
                    g_field9    := LPAD(TO_CHAR(r_rec.column9*100),15,'0');
                    g_field10   := LPAD(TO_CHAR(r_rec.column10*100),15,'0');
                    g_field11   := LPAD(TO_CHAR(r_rec.column11*100),15,'0');
                    g_field12   := LPAD(TO_CHAR(r_rec.column12*100),15,'0');
                    g_field13   := LPAD(TO_CHAR(r_rec.column13*100),15,'0');
                    g_field14   := LPAD(TO_CHAR(r_rec.column14*100),15,'0');
                    g_field15   := r_rec.column15;
                    g_field16   := LPAD(TO_CHAR(r_rec.column16*1000000),11,'0');
                    g_field17   := r_rec.column17;
                    g_field18   := LPAD(TO_CHAR(r_rec.column18*100),15,'0');
                    g_field19   := r_rec.column19;
                    g_field20   := r_rec.column20;
                    g_field21   := r_rec.column21;
                    g_field22   := r_rec.column22;
                    g_field23   := LPAD(TO_CHAR(r_rec.column23*1000000),11,'0');
                    g_field24   := r_rec.column24;
                    g_field25   := LPAD(TO_CHAR(r_rec.column25*100),15,'0');

                    print_out(25);
                    insert_rec;

                    print_log('Registro Rec 050 (-)');
                END;
                END LOOP;


                FOR r_rec IN c_rec_6 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 060 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := LPAD(TO_CHAR(r_rec.column1*100),5,'0');
                    g_field2    := LPAD(TO_CHAR(r_rec.column2*100),15,'0');
                    g_field3    := LPAD(TO_CHAR(r_rec.column3*100),15,'0');
                    g_field4    := LPAD(TO_CHAR(r_rec.column4*100),15,'0');

                    print_out(4);
                    insert_rec;

                    print_log('Registro Rec 060 (-)');
                END;
                END LOOP;


                FOR r_rec IN c_rec_7 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 070 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := LPAD(TO_CHAR(r_rec.column1),2,'0');
                    g_field2    := LPAD(TO_CHAR(r_rec.column2*100),15,'0');
                    g_field3    := LPAD(TO_CHAR(r_rec.column3),2,'0');
                    g_field4    := LPAD(TO_CHAR(r_rec.column4*100),15,'0');
                    g_field5    := r_rec.column5;
                    g_field6    := LPAD(TO_CHAR(r_rec.column6*100),5,'0');
                    g_field7    := LPAD(TO_CHAR(r_rec.column7*100),15,'0');
                    g_field8    := LPAD(TO_CHAR(r_rec.column8*100),5,'0');
                    g_field9    := LPAD(TO_CHAR(r_rec.column9*100),15,'0');

                    print_out(9);
                    insert_rec;

                    print_log('Registro Rec 070 (-)');
                END;
                END LOOP;

                FOR r_rec IN c_rec_8 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 080 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := r_rec.column1;
                    g_field2    := LPAD(TO_CHAR(r_rec.column2*100),5,'0');
                    g_field3    := LPAD(TO_CHAR(r_rec.column3*100),15,'0');
                    g_field4    := LPAD(TO_CHAR(r_rec.column4*100),15,'0');
                    g_field5    := r_rec.column5;

                    print_out(5);
                    insert_rec;

                    print_log('Registro Rec 080 (-)');
                END;
                END LOOP;


                FOR r_rec IN c_rec_9 (r_inv.customer_trx_id) LOOP
                BEGIN
                    print_log('Registro Rec 090 (+)');

                    clear_fields;

                    g_field0    := r_rec.rec_type;
                    g_field1    := r_rec.column1;
                    g_field2    := LPAD(TO_CHAR(r_rec.column2*100),5,'0');
                    g_field3    := LPAD(TO_CHAR(r_rec.column3*100),15,'0');
                    g_field4    := LPAD(TO_CHAR(r_rec.column4*100),15,'0');
                    g_field5    := r_rec.column5;
                    g_field6    := r_rec.column6;

                    print_out(6);
                    insert_rec;

                    print_log('Registro Rec 090 (-)');
                END;
                END LOOP;

                --Agregado KHRONUS/MNazarre 20180608: Se agrego logica para casos especificos de clientes
                IF r_inv.xx_ar_planex_codigo = 'INC' THEN

                    FOR r_rec IN c_rec_10_inc (r_inv.customer_trx_id) LOOP
                    BEGIN
                        print_log('Registro Rec 100 INC(+)');

                        clear_fields;

                        IF r_rec.uom_code != 'BOL' THEN

                            BEGIN


                                v_cantidad :=  inv_convert.inv_um_convert
                                                                (item_id           => r_rec.inventory_item_id,
                                                                 PRECISION         => 2,
                                                                 from_quantity     => r_rec.cantidad,
                                                                 from_unit         => r_rec.uom_code,
                                                                 to_unit           => 'BOL',
                                                                 from_name         => NULL,
                                                                 to_name           => NULL);

                                v_conv :=  inv_convert.inv_um_convert
                                                                (item_id           => r_rec.inventory_item_id,
                                                                 PRECISION         => 2,
                                                                 from_quantity     => 1,
                                                                 from_unit         => r_rec.uom_code,
                                                                 to_unit           => 'BOL',
                                                                 from_name         => NULL,
                                                                 to_name           => NULL);

                                IF v_cantidad = -99999 THEN
                                    print_log('No se encontro conversion de '||r_rec.uom_code||' a BOL');
                                    RAISE e_cust_exception;
                                END IF;

                                v_precio_unitario := r_rec.precio_unitario / nvl(v_conv,1);

                            EXCEPTION
                              WHEN NO_DATA_FOUND THEN
                                    print_log('No se encontro conversion de '||r_rec.uom_code||' a BOL');
                                RAISE e_cust_exception;
                              WHEN OTHERS THEN
                                    print_log('No se encontro conversion de '||r_rec.uom_code||' a BOL,'||' Error: '||sqlerrm);
                                RAISE e_cust_exception;
                            END;
                        ELSE
                            v_cantidad := r_rec.cantidad;
                            v_precio_unitario := r_rec.precio_unitario / nvl(v_conv,1);
                        END IF;



                        v_precio_sin_imp := round(v_precio_unitario-(nvl(r_rec.column11,0)/nvl(v_cantidad,1)),3);

                        g_field0    := r_rec.rec_type;
                        g_field1    := r_rec.column1;
                        g_field2    := r_rec.column2;
                        g_field3    := r_rec.column3;
                        g_field4    := r_rec.column4;
                        g_field5    := LPAD(TO_CHAR(v_cantidad*100000),15,'0'); --Cambiar
                        g_field6    := LPAD(TO_CHAR(r_rec.column6),2,'0');
                        g_field7    := LPAD(TO_CHAR(v_precio_unitario*1000),15,'0'); --Cambiar
                        g_field8    := LPAD(TO_CHAR(r_rec.column8*100),5,'0');
                        g_field9    := LPAD(TO_CHAR(r_rec.column9*100),15,'0');
                        g_field10   := LPAD(TO_CHAR(r_rec.column10*100),15,'0');
                        g_field11   := LPAD(TO_CHAR(r_rec.column11*100),15,'0');
                        g_field12   := LPAD(TO_CHAR(r_rec.column12*100),15,'0');
                        g_field13   := r_rec.column13;
                        g_field14   := r_rec.column14;
                        g_field15   := LPAD(TO_CHAR(r_rec.column15*100),15,'0');
                        g_field16   := r_rec.column16;
                        g_field17   := r_rec.column17;
                        g_field18   := r_rec.column18;
                        g_field19   := LPAD(TO_CHAR(v_precio_sin_imp*1000),15,'0'); --Cambiar
                        g_field20   := r_rec.column20;
                        g_field21   := r_rec.column21;
                        g_field22   := r_rec.column22;
                        g_field23   := r_rec.column23;
                        g_field24   := r_rec.column24;
                        g_field25   := r_rec.column25;

                        print_log('Cantidad:'||to_char(v_cantidad));
                        print_log('Precio:'||to_char(v_precio_unitario));
                        print_log('Precio sin Imp:'||to_char(v_precio_sin_imp));


                        print_out(25);
                        insert_rec;

                        --Inserto Linea Bonificacion
                        IF nvl(r_rec.column11,0) != 0 THEN
                            print_log('Registro Rec 110 INC(+)');

                            clear_fields;

                            g_field0    := '110';
                            g_field1    := r_rec.column1;
                            g_field2    := 'Descuento';
                            --g_field3    := '00000';
                            g_field3    := LPAD(TO_CHAR(ROUND(((r_rec.column11*100)/(r_rec.column10+r_rec.column11)),2)*100),5,'0');
                            g_field4    := LPAD(TO_CHAR((r_rec.column10+r_rec.column11)*100),15,'0');
                            g_field5    := LPAD(TO_CHAR(r_rec.column11*100),15,'0');

                            print_out(5);
                            insert_rec;

                        print_log('Registro Rec 100 INC(-)');
                        END IF;


                        /*IF r_rec.interface_line_context = 'ORDER ENTRY' THEN

                            FOR r_rec2 IN c_rec_12 (r_inv.customer_trx_id
                                                   ,r_rec.interface_line_attribute6) LOOP
                            BEGIN
                                print_log('Registro Rec 120 INC(+)');

                                clear_fields;

                                g_field0    := r_rec2.rec_type;
                                g_field1    := r_rec.column1;
                                g_field2    := r_rec2.column2;
                                g_field3    := LPAD(TO_CHAR(r_rec2.column3*100),5,'0');
                                g_field4    := LPAD(TO_CHAR(r_rec2.column4*100),15,'0');
                                g_field5    := LPAD(TO_CHAR(r_rec2.column5*100),15,'0');

                                print_out(5);
                                insert_rec;

                                print_log('Registro Rec 120 INC(-)');
                            END;
                            END LOOP;

                        END IF;*/

                        print_log('Registro Rec 100 INC(-)');
                    END;
                    END LOOP;


                ELSE

                    FOR r_rec IN c_rec_10 (r_inv.customer_trx_id) LOOP
                    BEGIN
                        print_log('Registro Rec 100 (+)');

                        clear_fields;

                        g_field0    := r_rec.rec_type;
                        g_field1    := r_rec.column1;
                        g_field2    := r_rec.column2;
                        g_field3    := r_rec.column3;
                        g_field4    := r_rec.column4;
                        g_field5    := LPAD(TO_CHAR(r_rec.column5*100000),15,'0');
                        g_field6    := LPAD(TO_CHAR(r_rec.column6),2,'0');
                        g_field7    := LPAD(TO_CHAR(r_rec.column7*1000),15,'0');
                        g_field8    := LPAD(TO_CHAR(r_rec.column8*100),5,'0');
                        g_field9    := LPAD(TO_CHAR(r_rec.column9*100),15,'0');
                        g_field10   := LPAD(TO_CHAR(r_rec.column10*100),15,'0');
                        g_field11   := LPAD(TO_CHAR(r_rec.column11*100),15,'0');
                        g_field12   := LPAD(TO_CHAR(r_rec.column12*100),15,'0');
                        g_field13   := r_rec.column13;
                        g_field14   := r_rec.column14;
                        g_field15   := LPAD(TO_CHAR(r_rec.column15*100),15,'0');
                        g_field16   := r_rec.column16;
                        g_field17   := r_rec.column17;
                        g_field18   := r_rec.column18;
                        g_field19   := LPAD(TO_CHAR(r_rec.column19*1000),15,'0');
                        g_field20   := r_rec.column20;
                        g_field21   := r_rec.column21;
                        g_field22   := r_rec.column22;
                        g_field23   := r_rec.column23;
                        g_field24   := r_rec.column24;
                        g_field25   := r_rec.column25;


                        print_out(25);
                        insert_rec;

                        --Inserto Linea Bonificacion
                        IF nvl(r_rec.column11,0) != 0 THEN
                            print_log('Registro Rec 110 (+)');

                            clear_fields;

                            g_field0    := '110';
                            g_field1    := r_rec.column1;
                            g_field2    := 'Descuento';
                            --g_field3    := '00000';
                            g_field3    := LPAD(TO_CHAR(ROUND(((r_rec.column11*100)/(r_rec.column10+r_rec.column11)),2)*100),5,'0');
                            g_field4    := LPAD(TO_CHAR((r_rec.column10+r_rec.column11)*100),15,'0');
                            g_field5    := LPAD(TO_CHAR(r_rec.column11*100),15,'0');

                            print_out(5);
                            insert_rec;

                        print_log('Registro Rec 100 (-)');
                        END IF;


                        IF r_rec.interface_line_context = 'ORDER ENTRY' THEN

                            FOR r_rec2 IN c_rec_12 (r_inv.customer_trx_id
                                                   ,r_rec.interface_line_attribute6) LOOP
                            BEGIN
                                print_log('Registro Rec 120 (+)');

                                clear_fields;

                                g_field0    := r_rec2.rec_type;
                                g_field1    := r_rec.column1;
                                g_field2    := r_rec2.column2;
                                g_field3    := LPAD(TO_CHAR(r_rec2.column3*100),5,'0');
                                g_field4    := LPAD(TO_CHAR(r_rec2.column4*100),15,'0');
                                g_field5    := LPAD(TO_CHAR(r_rec2.column5*100),15,'0');

                                print_out(5);
                                insert_rec;

                                print_log('Registro Rec 120 (-)');
                            END;
                            END LOOP;

                        END IF;

                        print_log('Registro Rec 100 (-)');
                    END;
                    END LOOP;


                END IF;
        END LOOP;


        utl_file.fclose(g_FileHandle);

        IF retcode IS NULL THEN
            retcode := 0;
        ELSE
            errbuf := 'Algunas Cabeceras de facturas no pudieron ser insertadas.';
        END IF;

       fnd_file.put_line(fnd_file.LOG,'XX_AR_PLANEX_INVOICES_PK.main (-)');

    EXCEPTION
    WHEN e_cust_exception THEN
       print_log(errbuf);
       utl_file.fclose(g_FileHandle);
       retcode := 1;
       fnd_file.put_line(fnd_file.LOG,'XX_AR_PLANEX_INVOICES_PK.main (!)');
         IF NOT FND_CONCURRENT.set_completion_status('Warning',errbuf) THEN
                print_log('Error Seteando Estado De Finalizacion');
         ELSE
                print_log('Estado de finalizacion seteado');
         END IF;
    WHEN OTHERS THEN
       utl_file.fclose(g_FileHandle);
       retcode := 2;
       errbuf := 'Error al generar salida de facturas en XML. Error: '|| SQLERRM;
       print_log(errbuf);
       fnd_file.put_line(fnd_file.LOG,'XX_AR_PLANEX_INVOICES_PK.main (!)');
         RAISE_APPLICATION_ERROR(-20001,'Error Inexperado en el proceso principal');

    END main;


END XX_AR_PLANEX_INVOICES_PK; 
/

exit
