  set define off;
DECLARE BEGIN END;/

exit
