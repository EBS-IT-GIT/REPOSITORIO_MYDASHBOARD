CREATE OR REPLACE  PACKAGE "APPS"."XXW_EXPO_FE_PUB_PKG" IS
/* $Id: XXW_EXPO_FE_PUB_PKS.sql 97 2010-06-16 19:45:34Z fmartinez $ */
FUNCTION Permiso_Existente(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION Tipo_expo(p_customer_trx_id IN NUMBER) RETURN NUMBER;
FUNCTION FORMA_PAGO(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION INCOTERMS_P(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION INCOTERMS(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION INCOTERMS_SP(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION INCOTERMS_DS RETURN VARCHAR2;
FUNCTION OBS_CCIALES RETURN VARCHAR2;
FUNCTION OBSERVACIONES RETURN VARCHAR2;
FUNCTION CUIT_PAIS_CLIENTE(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION ID_PERMISO(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
FUNCTION EXCHANGE_RATE(p_customer_trx_id IN NUMBER) RETURN VARCHAR2;
END	XXW_EXPO_FE_PUB_PKG;
/
CREATE OR REPLACE  PACKAGE BODY "APPS"."XXW_EXPO_FE_PUB_PKG" IS
/* $Id: xxw_expo_fe_pub_pkb .sql -1   $ */
FUNCTION es_importada (p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_es_importada VARCHAR2(1) := 'N';
BEGIN
SELECT DECODE(MAX (ooh.header_id), NULL, 'N', 'Y') INTO l_es_importada
FROM oe_order_headers_all ooh,
oe_order_lines_all ool,
ra_customer_trx_all rcta,
ra_customer_trx_lines_all rctl
WHERE ooh.header_id = ool.header_id
AND rcta.interface_header_context = 'ORDER ENTRY'
AND rctl.interface_line_context = 'ORDER ENTRY'
AND rctl.interface_line_attribute1 = TO_CHAR (ooh.order_number)
AND rctl.interface_line_attribute6 = TO_CHAR (ool.line_id)
AND rctl.customer_trx_id = rcta.customer_trx_id
AND rcta.customer_trx_id = p_customer_trx_id;
RETURN l_es_importada;
END;
FUNCTION Permiso_Existente(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_permiso_existente RA_CUSTOMER_TRX_ALL.attribute9%type := 'N';
BEGIN
IF XXW_EXPO_FE_PUB_PKG.Tipo_expo (p_customer_trx_id) = 1 THEN
BEGIN
SELECT decode(type,'CM',NULL,'DM',NULL,
decode(/* 23-Mar-2011 MG - rcta.attribute11 */ rctad.XX_AR_EMBARQUE, NULL, 'N','S'))
INTO l_permiso_existente
FROM ra_cust_trx_types_all rctta
,ra_customer_trx_all_dfv rctad  /* 23-Mar-2011 MG */
,ra_customer_trx_all rcta
WHERE 1=1
AND rcta.customer_trx_id=p_customer_trx_id
and rctad.row_id = rcta.rowid   /* 23-Mar-2011 MG */
AND rcta.cust_trx_type_id=rctta.cust_trx_type_id;
EXCEPTION
WHEN OTHERS THEN
l_permiso_existente := 'N';
END;
ELSE
l_permiso_existente := NULL;
END IF;
RETURN l_permiso_existente;
END Permiso_Existente;
FUNCTION Tipo_expo (p_customer_trx_id IN NUMBER)  RETURN NUMBER
IS
l_tipo_expo VARCHAR2 (255);
l_tipo_expon NUMBER;
BEGIN
SELECT
NVL (MAX (amlabd.xx_concepto_me), 1) INTO l_tipo_expo
FROM
ar_memo_lines_all_b amlab
, ar_memo_lines_all_b_dfv amlabd
, ra_customer_trx_all rcta
, ra_customer_trx_lines_all rctla
WHERE
amlab.rowid = amlabd.row_id
AND amlab.memo_line_id = rctla.memo_line_id
AND rcta.customer_trx_id = rctla.customer_trx_id
AND rcta.customer_trx_id = p_customer_trx_id
AND NOT EXISTS
(
SELECT 1
FROM
ra_customer_trx_lines_all rcta2
WHERE
rcta2.customer_Trx_id = rcta.customer_Trx_id AND rcta2.line_type = 'LINE'
AND rcta2.memo_line_id IS NULL
);
BEGIN
l_tipo_expon := to_number (l_tipo_expo);
EXCEPTION
WHEN OTHERS THEN
l_tipo_expon := 1;
END;
RETURN l_tipo_expon;
--RETURN 1 ; sd906
END Tipo_expo;
FUNCTION FORMA_PAGO(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_forma_pago VARCHAR2(50);
BEGIN
BEGIN
SELECT rtt.DESCRIPTION
INTO l_forma_pago
--FROM RA_TERMS_TL rtt             r11i
FROM RA_TERMS rtt                   --r12
,RA_CUSTOMER_TRX_ALL rcta
WHERE rtt.TERM_ID = rcta.TERM_ID
--          AND  rtt.LANGUAGE = userenv('LANG')
AND  rcta.customer_trx_id=p_customer_trx_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_forma_pago := null;
WHEN TOO_MANY_ROWS THEN
l_forma_pago := null;
WHEN OTHERS THEN
l_forma_pago := null;
END;
RETURN l_forma_pago;
END FORMA_PAGO;
FUNCTION INCOTERMS_P(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_fob_point_code RA_CUSTOMER_TRX_ALL.fob_point%type;
BEGIN
BEGIN
SELECT fob_point
INTO l_fob_point_code
FROM ra_customer_trx_all_dfv rctad, /* 23-Mar-2011 MG */
RA_CUSTOMER_TRX_ALL rcta
WHERE /* 23-Mar-2011 MG - rcta.ATTRIBUTE11 */
rctad.XX_AR_EMBARQUE = XXW_EXPO_FE_PUB_PKG.ID_PERMISO(p_customer_trx_id)
AND rcta.customer_trx_id=p_customer_trx_id
and rctad.row_id = rcta.rowid /* 23-Mar-2011 MG */
;
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_fob_point_code := null;
WHEN TOO_MANY_ROWS THEN
l_fob_point_code := null;
WHEN OTHERS THEN
l_fob_point_code := null;
END;
RETURN l_fob_point_code;
END INCOTERMS_P;
FUNCTION INCOTERMS_SP(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_fob_point_code varchar2(20);
BEGIN
BEGIN
SELECT ooh.fob_point_code
INTO l_fob_point_code
FROM OE_ORDER_HEADERS_ALL ooh
WHERE ooh.sold_to_org_id=p_customer_trx_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_fob_point_code := null;
WHEN TOO_MANY_ROWS THEN
l_fob_point_code := null;
WHEN OTHERS THEN
l_fob_point_code := null;
END;
RETURN l_fob_point_code;
END INCOTERMS_SP;
FUNCTION INCOTERMS(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_fob_point_code varchar2(20);
BEGIN
IF XXW_EXPO_FE_PUB_PKG.es_importada (p_customer_trx_id) = 'Y' THEN
SELECT MAX( ooh.fob_point_code) INTO l_fob_point_code
FROM oe_order_headers_all ooh,
oe_order_lines_all ool,
ra_customer_trx_all rcta,
ra_customer_trx_lines_all rctl
WHERE ooh.header_id = ool.header_id
AND rcta.interface_header_context = 'ORDER ENTRY'
AND rctl.interface_line_context = 'ORDER ENTRY'
AND rctl.interface_line_attribute1 = TO_CHAR (ooh.order_number)
AND rctl.interface_line_attribute6 = TO_CHAR (ool.line_id)
AND rctl.customer_trx_id = rcta.customer_trx_id
AND rcta.customer_trx_id = p_customer_trx_id
;
ELSE
BEGIN
SELECT /* 28-Mar-2011 MGalindez : rctad.xxw_incoterms */
ooh.fob_point_code
INTO l_fob_point_code
FROM RA_CUSTOMER_TRX_ALL rcta
,ra_customer_trx_all_dfv rctad
,oe_order_headers_all ooh  /* 28-mar-2011 MG: agregado */
,oe_transaction_types_tl ottl /* 28-mar-2011 MG: agregado */
WHERE rcta.customer_trx_id=p_customer_trx_id
AND  rcta.rowid=rctad.row_id
/* 28-mar-2011 MG: agregado - inicio */
and  ooh.order_number = rctad.XX_AR_NRO_PEDIDO_OM
and  ooh.org_id = rcta.org_id
and  ottl.transaction_type_id = ooh.order_type_id
and  ottl.name = rctad.XX_AR_TIPO_PEDIDO_OM
and  ottl.language = 'ESA'
/* 28-mar-2011 MG: agregado - fin */
;
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_fob_point_code := null;
WHEN TOO_MANY_ROWS THEN
l_fob_point_code := null;
WHEN OTHERS THEN
l_fob_point_code := null;
END;
END IF;
RETURN l_fob_point_code;
END;
FUNCTION INCOTERMS_DS RETURN VARCHAR2
IS
BEGIN
RETURN NULL;
END INCOTERMS_DS;
FUNCTION ID_PERMISO(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_nro_embarque RA_CUSTOMER_TRX_ALL.attribute9%type;
BEGIN
BEGIN
SELECT decode(Permiso_Existente(p_customer_trx_id),
'S', /* 23-Mar-2011 MG -  attribute9 */ rctad.XX_AR_EMBARQUE,null)
INTO l_nro_embarque
FROM ra_customer_trx_all_dfv rctad, /* 23-Mar-2011 MG */
RA_CUSTOMER_TRX_ALL rcta
WHERE rcta.customer_trx_id=p_customer_trx_id
and   rctad.row_id = rcta.rowid
;
EXCEPTION
WHEN OTHERS THEN
l_nro_embarque := null;
END;
RETURN l_nro_embarque;
END ID_PERMISO;
FUNCTION EXCHANGE_RATE(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_exchange_rate GL_DAILY_RATES_V.conversion_rate%type := 1;
BEGIN
BEGIN
/* --- FIX BUG MULTI-EXCHANGE RATES ---
SELECT gdrv.conversion_rate
INTO l_exchange_rate
FROM ra_customer_trx_all rcta
,GL_DAILY_RATES_V  gdrv
WHERE rcta.customer_trx_id=p_customer_trx_id
AND gdrv.from_currency=rcta.invoice_currency_code
AND gdrv.conversion_date=rcta.trx_date
AND gdrv.to_currency = 'ARS';
*/
SELECT 	nvl(rcta.exchange_rate,1) --CR1994
INTO	l_exchange_rate
FROM 	ra_customer_trx_all rcta
WHERE	rcta.customer_trx_id = p_customer_trx_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_exchange_rate:=1;
WHEN OTHERS THEN
l_exchange_rate:=1;
END;
RETURN l_exchange_rate;
END EXCHANGE_RATE;
FUNCTION OBS_CCIALES RETURN VARCHAR2
IS
BEGIN
RETURN NULL;
END OBS_CCIALES;
FUNCTION OBSERVACIONES RETURN VARCHAR2
IS
BEGIN
RETURN NULL;
END OBSERVACIONES;
FUNCTION CUIT_PAIS_CLIENTE(p_customer_trx_id IN NUMBER) RETURN VARCHAR2
IS
l_xxw_cuit_pais_cliente  /* 28-mar-2011 MG: hz_cust_SITE_USES_all_dfv.xxw_cuit_pais_cliente */
varchar2(20);
BEGIN
BEGIN
SELECT /* 23-Mar-2011 MG - hcsud.xxw_cuit_pais_cliente */
rc.TAXPAYER_ID || rc.global_attribute12
INTO l_xxw_cuit_pais_cliente
FROM ra_customer_trx_all rct
/* 23-Mar-2011 MG - inicio */
--,hz_cust_SITE_USES hcsu
--,hz_cust_SITE_USES_all_dfv hcsud
,ar_customers rc
/* 23-Mar-2011 MG - fin */
WHERE  CUSTOMER_TRX_ID=p_customer_trx_id
--and hcsu.SITE_USE_ID = rct.BILL_TO_SITE_USE_ID
--AND hcsu.site_use_code='BILL_TO'
--AND hcsu.rowid=hcsud.row_id
/* 23-Mar-2011 MG - inicio */
and rc.customer_id = rct.bill_to_customer_id
/* 23-Mar-2011 MG - fin */
;
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_xxw_cuit_pais_cliente:= null;
WHEN OTHERS THEN
l_xxw_cuit_pais_cliente:= null;
END;
RETURN l_xxw_cuit_pais_cliente;
END CUIT_PAIS_CLIENTE;
END XXW_EXPO_FE_PUB_PKG;

/
exit
