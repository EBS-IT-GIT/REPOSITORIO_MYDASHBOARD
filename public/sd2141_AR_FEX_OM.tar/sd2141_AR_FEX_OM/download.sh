# | $Header: install_apps.sh 1.0  07/07/2020  M. Di Francesco             |
# *=======================================================================+
# |                2014 Ancap IT SRL, Buenos Aires, Argentina             |
# |                         All rights reserved.                          |
# +=======================================================================+
# | FILENAME                                                              |
# |          download.sh - Driver de Instalacion                          |
# |                                                                       |
# | SOURCE CONTROL                                                        |
# |    Version: 1.0                                                       |
# |    Fecha  : 07/07/2020                                                |
# |    Descripcion: XXXX                                                  |
# |                                                                       |
# | HISTORY                                                               |
# |    07/07/2020       M. Di Francesco/Ancap IT   Version Inicial        |
# |                                                                       |
# |                                                                       |
# |                                                                       |
# +=======================================================================+

DIRECTORIO_PARCHE=`pwd`
ARCHIVO_LOG=$DIRECTORIO_PARCHE/download.log
ARCHIVO_ERR=$DIRECTORIO_PARCHE/download.err
sendLog()
{
  echo $1
  echo $1 >> $ARCHIVO_LOG
}

##################################################################################
# CHK_PASSWORD                                                                   #
# Descripcion: Funcion que comprueba que el usuario y la password sean correctos #
##################################################################################
chk_password()
{
sqlplus -s /nolog > /dev/null 2>&1 <<EOF
whenever sqlerror exit failure
connect $1/$2@$3
exit success
EOF

if [ $? -ne 0 ]; then
  echo Wrong Username or Password.
  exit 1
fi
}

sendLog '====================================' 
sendLog 'Shell install.sh ' 
sendLog '====================================' 

sendLog 'Please, enter the APPS USER: '
APPS_USER=APPS
sendLog 'Please, enter the APPS PASSWORD: '
read -s APPS 
sendLog 'Please, enter the DATABASE HOST: '
#HOST=host
read HOST
sendLog 'Please, enter the DATABASE PORT: '
#PORT=1521
read PORT 
sendLog 'Please, enter the DATABASE name: '
#BASE=DESA 
read BASE
sendLog 'Conectandose con ' $APPS_USER 
sendLog 'Base ' $BASE 

chk_password $APPS_USER $APPS $BASE

sendLog '=============================================================================='
sendLog 'Downloading SQL objects' 
sendLog '=============================================================================='
XXW_EXPO_FE_PUB_PKG_PACKAGE=`sqlplus -s APPS/$APPS <<EOF
SET HEADING OFF
SET PAGESIZE 0
SET LONG 1000000
SET LONGCHUNKSIZE 32000
SET LINESIZE 32000
SET TRIMSPOOL ON
SET NEWPAGE NONE
SET EMBEDDED ON
SET TAB OFF
SET FEEDBACK OFF
SET ECHO OFF
SET SQLBLANKLINES ON
SPOOL ./DOWNLOAD/sql/XXW_EXPO_FE_PUB_PKG_PACKAGE.sql
SELECT regexp_replace(REPLACE (dbms_metadata.get_ddl('PACKAGE', 'XXW_EXPO_FE_PUB_PKG', 'APPS'), 'EDITIONABLE', ''), '^\s*', null, 1, 0, 'm') FROM dual;
SELECT '/' FROM dual;
SELECT 'exit' FROM dual;
SPOOL OFF
exit
EOF` >> $ARCHIVO_LOG 2>> $ARCHIVO_ERR

sendLog '=============================================================================='
sendLog 'Downloading FILE objects' 
sendLog '=============================================================================='

sendLog '=============================================================================='
sendLog 'Downloading OAF objects' 
sendLog '=============================================================================='

sendLog '=============================================================================='
sendLog 'Downloading AOL objects' 
sendLog '=============================================================================='
