********************************************************************************
* BEGIN - 120xscn9055_001
********************************************************************************
* ====================================
* DESCRIPTION
* ====================================
*
* SCN - Solucoes Complementares Ninecon
* => 9055 - Solicitacao de Adiantamentos e Pagamentos Padrao
*
* ====================================
* Pre-install Tasks
* ====================================
*
* 1. Please connect with owner sys and run the command below:
*
*  $ GRANT ALL ON apps.gl_code_combinations_kfv TO xxsn;
*
* ====================================
* Apply The Patch
* ====================================
*
* 1. Copy File 120xscn9055_001.zip to $APPL_TOP/patches. Please create the directory if doesnt exists
*
* 2. Execute the following commands
*
*    $ cd $APPL_TOP/patches
*    $ unzip 120xscn9055_001.zip
*    $ cd 120xscn9055_001
*
* 3. Containing drivers
*
*    - u120xscn9055_001.drv
*
* 4. Execute this patch by "adpatch" for the drivers below:
*
*    $ adpatch options=hotpatch driver=u120xscn9055_001.drv logfile=u120xscn9055_001.log patchtop=$PWD workers=1
*
* ====================================
* Post-install Tasks
* ====================================
*
* 1. Adicionar Menu XSCN_AP a responsabilidade desejada
*
* ====================================
* Additional Information
* ====================================
*
* 1. N/A
*
* ====================================
* Successful patch installation checks
* ====================================
*
* 1. EXAMPLE: Make sure the version of files
*
*
********************************************************************************
* END OF FILE
********************************************************************************
