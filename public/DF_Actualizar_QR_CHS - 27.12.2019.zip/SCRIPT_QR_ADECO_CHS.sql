DELETE
  FROM BOLINF.XX_OPM_QR_PROVEEDORES
 WHERE (qr_id, carrier_service_id ) IN (
SELECT qr_id, carrier_service_id 
  FROM (
SELECT x3.grupo_control, x1.carrier_service_id, min(x1.qr_id) qr_id , count(1) cantidad -- * -- DISTINCT  x1.ADM_VENDOR_ID, x1.QR_ID, x1.CARRIER_SERVICE_ID, x3.GRUPO_CONTROL, x2.ADM_VENDOR_ID,x2.QR_ID, x2.CARRIER_SERVICE_ID, x4.GRUPO_CONTROL
FROM apps.XX_OPM_QR_PROVEEDORES    x1,
     apps.XX_OPM_ADMIN_PROVEEDORES x3
WHERE x3.ADM_VENDOR_ID = x1.ADM_VENDOR_ID
  AND x1.carrier_service_id IS NOT NULL
GROUP BY x3.grupo_control, x1.carrier_service_id
HAVING COUNT (1) > 1 ) 
)