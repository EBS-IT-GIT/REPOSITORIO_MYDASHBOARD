delete xx_ar_adec_batches
where batch_name IN (1660,1659);
--236 rows
/

EXIT