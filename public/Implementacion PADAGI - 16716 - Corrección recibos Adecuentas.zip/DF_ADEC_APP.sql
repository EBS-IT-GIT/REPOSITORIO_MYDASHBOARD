delete xx_ar_adec_applications
where batch_name IN (1660,1659);
--1652 rows