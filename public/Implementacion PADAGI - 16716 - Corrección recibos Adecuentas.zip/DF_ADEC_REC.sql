delete xx_ar_adec_receipts
where batch_name IN (1660,1659);
--1770 rows
/

EXIT