  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_CUSTOM_SUBMISSION_CHECK" AUTHID CURRENT_USER
AS

--*************************************************************************************
-- PROCEDURE NAME: Main
--
-- DESCRIPTION    : Proceso llamado por el package PO_CUSTOM_SUBMISSION_CHECK_PVT
--                  para validaciones custom de �rdenes de compra
-- PARAMETERS     : p_document_id - Id of the document to validate
--                  p_online_report_id - Id to be used when inserting records into
--                                       PO_ONLINE_REPORT_TEXT_GT table
--                  p_sequence - Sequence number of last reported error
--
-- CHANGE REQUEST:
--
--   PROGRAMMER       UPDATE_DATE     DESCRIPTION
--   -------------    -----------     ------------
--   ITC              20/09/2017      Initial version
--
--************************************************************************************/
PROCEDURE Main (p_document_id        IN            NUMBER,
                p_document_type      IN            VARCHAR2,
                p_online_report_id   IN            NUMBER,
                p_sequence           IN OUT NOCOPY NUMBER);

END XX_PO_CUSTOM_SUBMISSION_CHECK;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_CUSTOM_SUBMISSION_CHECK" 
AS

--*************************************************************************************
-- PROCEDURE NAME: Inserta_Error
--
-- DESCRIPTION    : Proceso de Insercion de mensajes al log standard del proceso de
--                  Control Custom
-- PARAMETERS     :
--
-- CHANGE REQUEST:
--
--   PROGRAMMER       UPDATE_DATE     DESCRIPTION
--   -------------    -----------     ------------
--   ITC              04/09/2017      Initial version
--
--************************************************************************************/
PROCEDURE Inserta_Error (p_document_id        IN            NUMBER,
                         p_line_num           IN            NUMBER,
                         p_shipment_num       IN            NUMBER,
                         p_distribution_num   IN            NUMBER,
                         p_online_report_id   IN            NUMBER,
                         p_sequence           IN OUT NOCOPY NUMBER,
                         p_message_type       IN            VARCHAR2,
                         p_mensaje_error      IN            VARCHAR2)
   IS

      r_error          po_online_report_text_gt%ROWTYPE;
      d_fecha_hoy      po_online_report_text_gt.creation_date%TYPE := SYSDATE;
      v_message_name   po_online_report_text_gt.message_name%TYPE := 'POS_ERROR';

   BEGIN
      --xx_debug_pkg.save_table ('2T - PO_CUSTOM_SUBMISSION_CHECK_PVT.XXInsertarError - p_sequence: ' || p_sequence);

      p_sequence                 := p_sequence + 1;

      r_error.online_report_id   := p_online_report_id;
      r_error.last_update_login  := FND_GLOBAL.user_id;
      r_error.last_updated_by    := FND_GLOBAL.user_id;
      r_error.last_update_date   := d_fecha_hoy;
      r_error.created_by         := FND_GLOBAL.user_id;
      r_error.creation_date      := d_fecha_hoy;
      r_error.line_num           := p_line_num;
      r_error.shipment_num       := p_shipment_num;
      r_error.distribution_num   := p_distribution_num;
      r_error.SEQUENCE           := p_sequence;
      r_error.text_line          := p_mensaje_error;
      r_error.message_name       := v_message_name;
      r_error.MESSAGE_TYPE       := p_message_type;

      INSERT INTO po_online_report_text_gt
           VALUES r_error;
   EXCEPTION
      WHEN OTHERS
      THEN
         --xx_debug_pkg.save_table ('2T - PO_CUSTOM_SUBMISSION_CHECK_PVT.XXInsertarError - MSG: ' || SQLERRM);
         ROLLBACK;
END;

--*************************************************************************************
-- PROCEDURE NAME: Valida_Item_Flete
--
-- DESCRIPTION    : Proceso que muestra error si se cumplen estas condiciones:
--                  Si la OC es de Argentina, de cualquier unidad operativa excepto CHS
--                  y alguna l?a (no cancelada) tiene n?m con categor?de inventario
--                  Rubro=06 , Familia=117 y el ATTRIBUTE1 de cualquier env?(no cancelado)
--                  no est?ompleto, se debe mostrar el error
-- PARAMETERS     : p_document_id - Id of the document to validate
--                  p_online_report_id - Id to be used when inserting records into
--                                       PO_ONLINE_REPORT_TEXT_GT table
--                  p_sequence - Sequence number of last reported error
--
-- CHANGE REQUEST:
--
--   PROGRAMMER       UPDATE_DATE     DESCRIPTION
--   -------------    -----------     ------------
--   ITC              04/09/2017      Initial version
--
--************************************************************************************/
PROCEDURE Valida_Item_Flete (p_document_id        IN            NUMBER,
                             p_online_report_id   IN            NUMBER,
                             p_sequence           IN OUT NOCOPY NUMBER)
   IS
      r_error          po_online_report_text_gt%ROWTYPE;
      d_fecha_hoy      po_online_report_text_gt.creation_date%TYPE := SYSDATE;
      v_message_name   po_online_report_text_gt.message_name%TYPE := 'POS_ERROR';

      CURSOR c_Item_Flete IS
             SELECT l.line_num
                   ,ll.shipment_num
                   ,p_sequence + ROWNUM sequence
             FROM po_lines_all l
                  ,mtl_categories_b c
                  ,po_line_locations_v ll
             WHERE l.po_header_id = p_document_id
             AND nvl(l.cancel_flag,'N') = 'N'
             AND nvl(l.closed_code,'OPEN') != 'FINALLY CLOSED'
             -- Valido organizacion
             AND  l.org_id != ( SELECT organization_id
                                FROM hr_operating_units
                                WHERE name = 'AR CHS UO')
             -- Valido Categoria
             AND  c.category_id = l.category_id
             AND c.segment1 = '06'
             AND c.segment2 = '117'
             AND l.attribute6 is null -- CR2364 Proforma no debe tener el remito
             -- Valido Envios
             AND (ll.cancel_flag is null or ll.cancel_flag != 'Y')
             AND (ll.closed_code is null or ll.closed_code != 'FINALLY CLOSED')
             AND ll.PO_LINE_ID=l.PO_LINE_ID
             AND ll.attribute1 IS NULL;

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_FLET_INSUMOS'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

      --xx_debug_pkg.save_table ('2T - PO_CUSTOM_SUBMISSION_CHECK_PVT.XXInsertarError - p_sequence: ' || p_sequence);
      FOR r_Item_Flete IN c_Item_Flete LOOP
        Inserta_Error (p_document_id,
                       r_Item_Flete.line_num,
                       0,
                       0,
                       p_online_report_id,
                       r_Item_Flete.sequence,
                       'E',
                       'Linea '|| r_Item_Flete.line_num ||', Envio'|| r_Item_Flete.shipment_num|| ': Debe asociar un remito en el flexfield de envio');
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         --xx_debug_pkg.save_table ('2T - PO_CUSTOM_SUBMISSION_CHECK_PVT.XXInsertarError - MSG: ' || SQLERRM);
         ROLLBACK;
   END Valida_Item_Flete;

--*************************************************************************************
-- PROCEDURE NAME: Valida_Remito_Asociado
--
-- DESCRIPTION    : Proceso que muestra error si se cumplen estas condiciones:
--                  Si la OC es de Argentina, de cualquier unidad operativa excepto CHS
--                  y alguna l?a (no cancelada) tiene n?m con categor?de inventario
--                  Rubro=06 , Familia=117 y el ATTRIBUTE1 de cualquier env?(no cancelado)
--                  no est?ompleto, se debe mostrar el error
-- PARAMETERS     : p_document_id - Id of the document to validate
--                  p_online_report_id - Id to be used when inserting records into
--                                       PO_ONLINE_REPORT_TEXT_GT table
--                  p_sequence - Sequence number of last reported error
--
-- CHANGE REQUEST:
--
--   PROGRAMMER       UPDATE_DATE     DESCRIPTION
--   -------------    -----------     ------------
--   ITC              04/09/2017      Initial version
--
--************************************************************************************/
PROCEDURE Valida_Remito_Asociado (p_document_id        IN            NUMBER,
                                  p_online_report_id   IN            NUMBER,
                                  p_sequence           IN OUT NOCOPY NUMBER)
   IS
      r_error          po_online_report_text_gt%ROWTYPE;
      d_fecha_hoy      po_online_report_text_gt.creation_date%TYPE := SYSDATE;
      v_message_name   po_online_report_text_gt.message_name%TYPE := 'POS_ERROR';

      -- Validar con Guille mas de un envio con error como deberia salir el mensaje
      CURSOR c_Item_Flete IS
             SELECT l.line_num
                   ,ll.shipment_num
                   ,p_sequence + ROWNUM sequence
                   ,xx_plantas_por_usuario_pkg.xx_oc_remito_asociado_f(FND_PROFILE.VALUE('ORG_ID'), ll.attribute1, l.po_header_id, l.po_line_id) OC_asociada
             FROM po_lines_all l
                 ,mtl_categories_b c
                 ,po_line_locations_v ll
             WHERE l.po_header_id = p_document_id
             AND nvl(l.cancel_flag,'N') = 'N'
             AND nvl(l.closed_code,'OPEN') != 'FINALLY CLOSED'
             -- Valido organizacion
             AND  l.org_id != ( SELECT organization_id
                                FROM hr_operating_units
                                WHERE name = 'AR CHS UO')
             -- Valido Categoria
             AND  c.category_id = l.category_id
             AND c.segment1 = '06'
             AND c.segment2 = '117'
             -- Valido Envios
             AND (ll.cancel_flag is null or ll.cancel_flag != 'Y')
             AND (ll.closed_code is null or ll.closed_code != 'FINALLY CLOSED')
             AND ll.PO_LINE_ID=l.PO_LINE_ID
             AND trim(ll.attribute1) IS NOT NULL
             AND trim(ll.attribute1) IN (SELECT trim(ll2.attribute1)
                                   FROM po_line_locations_all ll2
                                   WHERE trim(ll2.attribute1) is not null
                                   AND ll2.attribute_category = 'AR'
                                   AND (ll2.cancel_flag is null or ll2.cancel_flag != 'Y')
                                   AND (ll2.closed_code is null or ll2.closed_code != 'FINALLY CLOSED')
                                   AND ( ( ll2.po_header_id != ll.po_header_id AND ll2.po_line_id != ll.po_line_id ) OR
                                       ( ll2.po_header_id = ll.po_header_id AND ll2.po_line_id != ll.po_line_id ) )
                   );

   BEGIN
      --xx_debug_pkg.save_table ('2T - PO_CUSTOM_SUBMISSION_CHECK_PVT.XXInsertarError - p_sequence: ' || p_sequence);
      FOR r_Item_Flete IN c_Item_Flete LOOP
        Inserta_Error (p_document_id,
                       r_Item_Flete.line_num,
                       0,
                       0,
                       p_online_report_id,
                       r_Item_Flete.sequence,
                       'E',
                       'Linea '|| r_Item_Flete.line_num ||', Envio '|| r_Item_Flete.shipment_num|| ': El remito seleccionado se encuentra asociado a la OC '||r_Item_Flete.OC_asociada ||'.');
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         --xx_debug_pkg.save_table ('2T - PO_CUSTOM_SUBMISSION_CHECK_PVT.XXInsertarError - MSG: ' || SQLERRM);
         ROLLBACK;
   END;

  --*************************************************************************************
  -- PROCEDURE NAME: Precio_Retroactivo
  --
  -- DESCRIPTION    : Contiene la funcionalidad de validaci?n del precio retroactivo de
  -- una OC.
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              26/12/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE Valida_Precio_Retroactivo (p_document_id        IN            NUMBER,
                                       p_online_report_id   IN            NUMBER,
                                       p_sequence           IN OUT NOCOPY NUMBER)
  IS

    CURSOR c_lineas_error
    IS SELECT pla.line_num,
    pla.unit_price new_price,
    plaa.unit_price old_price,
    p_sequence + ROWNUM sequence
    FROM po_headers_all pha,
    po_lines_all pla,
    po_lines_archive_all plaa
    WHERE pha.type_lookup_code = 'STANDARD'
    AND pha.po_header_id = pla.po_header_id
    AND pla.po_line_id = plaa.po_line_id
    AND plaa.revision_num = (SELECT Max(plaa1.revision_num)
                             FROM po_lines_archive_all plaa1
                             WHERE plaa1.po_line_id = plaa.po_line_id)
    AND pla.unit_price != plaa.unit_price
    AND EXISTS (SELECT 1
                FROM po_line_locations_all plla,
                po_distributions_all pda
                WHERE pda.quantity_billed > 0
                AND pha.po_header_id = plla.po_header_id
                AND pha.po_header_id = pda.po_header_id
                AND pla.po_line_id = plla.po_line_id
                AND pla.po_line_id = pda.po_line_id
                AND plla.line_location_id = pda.line_location_id)
    AND pha.po_header_id = p_document_id;

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_VAL_PRECIO_RETRO'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

    FOR r_linea_error IN c_lineas_error
    LOOP

      Inserta_Error (p_document_id,
                     r_linea_error.line_num,
                     NULL,
                     NULL,
                     p_online_report_id,
                     r_linea_error.sequence,
                     'E',
                     'Error. Linea ' || r_linea_error.line_num ||
                     ', tiene facturas asociadas. El precio de la actual (' || r_linea_error.new_price ||
                     ') no puede diferir del ?ltimo precio aprobado (' || r_linea_error.old_price ||
                     ').');

    END LOOP;

  EXCEPTION

    WHEN OTHERS
    THEN

      ROLLBACK;

  END Valida_Precio_Retroactivo;


  --*************************************************************************************
  -- PROCEDURE NAME: Valida_Fecha_Art_Erogacion
  --
  -- DESCRIPTION    : Contiene la funcionalidad de la personalizaci?n CR2552 -
  -- Validaci?n de Fecha de Art?lo de Erogaci?n
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              20/09/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE  Valida_Fecha_Art_Erogacion (p_document_id        IN            NUMBER,
                                         p_online_report_id   IN            NUMBER,
                                         p_sequence           IN OUT NOCOPY NUMBER)
  IS

    CURSOR c_distribuciones_error
    IS SELECT pla.line_num,
    plla.shipment_num,
    pda.distribution_num,
    p_sequence + ROWNUM sequence
    FROM po_headers_all pha,
    po_lines_all pla,
    po_line_locations_all plla,
    po_distributions_all pda
    WHERE pha.type_lookup_code = 'STANDARD'
    AND pda.task_id IS NOT NULL
    AND pda.project_id IS NOT NULL
    AND pda.expenditure_type IS NOT NULL
    AND pha.po_header_id = pla.po_header_id
    AND pha.po_header_id = plla.po_header_id
    AND pha.po_header_id = pda.po_header_id
    AND pla.po_line_id = plla.po_line_id
    AND pla.po_line_id = pda.po_line_id
    AND plla.line_location_id = pda.line_location_id
    AND NOT EXISTS (SELECT 1
                    FROM pa_periods_v ppv
                    WHERE TRUNC(pda.expenditure_item_date) BETWEEN ppv.pa_start_date AND ppv.pa_end_date --SD2268 se agrega TRUNC
                    AND ppv.status = 'O')
    AND pha.po_header_id = p_document_id;

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_VAL_PA'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N') THEN

      RETURN;

    END IF;

    FOR r_distribucion_error IN c_distribuciones_error LOOP

      Inserta_Error (p_document_id,
                     r_distribucion_error.line_num,
                     r_distribucion_error.shipment_num,
                     r_distribucion_error.distribution_num,
                     p_online_report_id,
                     r_distribucion_error.sequence,
                     'E',
                     'Error. Linea ' || r_distribucion_error.line_num ||
                     ', Envio' || r_distribucion_error.shipment_num ||
                     ', Distribucion ' || r_distribucion_error.distribution_num ||
                     '. La fecha de erogacion ingresada no se encuentra dentro de un periodo abierto de PA. Por favor, modificar para continuar.');

    END LOOP;

  EXCEPTION

    WHEN OTHERS
    THEN

      ROLLBACK;

  END Valida_Fecha_Art_Erogacion;

  --*************************************************************************************
  -- PROCEDURE NAME: Valida_Org_Erog_Proy_Tarea
  --
  -- DESCRIPTION    : Contiene la funcionalidad de la personalizaci?n Validar Organizacion
  -- de Erogacion de Proyecto-Tarea
  -- Validaci?n de Fecha de Art?lo de Erogaci?n
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              20/09/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE Valida_Org_Erog_Proy_Tarea (p_document_id        IN            NUMBER,
                                        p_online_report_id   IN            NUMBER,
                                        p_sequence           IN OUT NOCOPY NUMBER)
  IS

    CURSOR c_distribuciones_error
    IS SELECT pla.line_num,
    plla.shipment_num,
    pda.distribution_num,
    p_sequence + ROWNUM sequence
    FROM po_headers_all pha,
    po_lines_all pla,
    po_line_locations_all plla,
    po_distributions_all pda,
    pa_tasks pt
    WHERE pha.type_lookup_code = 'STANDARD'
    AND pda.task_id IS NOT NULL
    AND pda.project_id IS NOT NULL
    AND pda.expenditure_type IS NOT NULL
    AND pha.po_header_id = pla.po_header_id
    AND pha.po_header_id = plla.po_header_id
    AND pha.po_header_id = pda.po_header_id
    AND pla.po_line_id = plla.po_line_id
    AND pla.po_line_id = pda.po_line_id
    AND plla.line_location_id = pda.line_location_id
    AND pt.task_id = pda.task_id
    AND pt.carrying_out_organization_id != pda.expenditure_organization_id
    AND pha.po_header_id = p_document_id;

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_VAL_PA'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

    FOR r_distribucion_error IN c_distribuciones_error
    LOOP

      Inserta_Error (p_document_id,
                     r_distribucion_error.line_num,
                     r_distribucion_error.shipment_num,
                     r_distribucion_error.distribution_num,
                     p_online_report_id,
                     r_distribucion_error.sequence,
                     'E',
                     'Error. Linea ' || r_distribucion_error.line_num ||
                     ', Envio' || r_distribucion_error.shipment_num ||
                     ', Distribucion ' || r_distribucion_error.distribution_num ||
                     '. La Organizacion de Erogacion seleccionada no se corresponde con la Organizacion de la Tarea.' ||
                     ' Por Favor seleccione la Organizacion Correcta.');

    END LOOP;

  EXCEPTION

    WHEN OTHERS
    THEN

      ROLLBACK;

  END Valida_Org_Erog_Proy_Tarea;

  --*************************************************************************************
  -- PROCEDURE NAME: Valida_Fecha_Pactada_Envios
  --
  -- DESCRIPTION    : Contiene la funcionalidad de la personalizaci?n Campo Requerido
  -- 'Fecha pactada' para ARG en ENVIOS
  -- Validaci?n de Fecha de Art?lo de Erogaci?n
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              20/09/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE Valida_Fecha_Pactada_Envios (p_document_id        IN            NUMBER,
                                         p_online_report_id   IN            NUMBER,
                                         p_sequence           IN OUT NOCOPY NUMBER)
  IS

    CURSOR c_lineas_error
    IS SELECT pla.line_num,
    plla.shipment_num,
    p_sequence + ROWNUM sequence
    FROM po_headers_all pha,
    po_lines_all pla,
    po_line_locations_all plla
    WHERE pha.type_lookup_code = 'STANDARD'
    AND pha.po_header_id = pla.po_header_id
    AND pha.po_header_id = plla.po_header_id
    AND pla.po_line_id = plla.po_line_id
    AND plla.promised_date IS NULL
    AND pha.po_header_id = p_document_id;

      l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_VAL_PROM_DATE'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

    FOR r_linea_error IN c_lineas_error
    LOOP

      Inserta_Error (p_document_id,
                     r_linea_error.line_num,
                     r_linea_error.shipment_num,
                     0,
                     p_online_report_id,
                     r_linea_error.sequence,
                     'E',
                     'Error. L?a ' || r_linea_error.line_num ||
                     ', Envio' || r_linea_error.shipment_num ||
                     '. Debe ingresar la Fecha Pactada.');

    END LOOP;

  EXCEPTION

    WHEN OTHERS
    THEN

      ROLLBACK;

  END Valida_Fecha_Pactada_Envios;

  --*************************************************************************************
  -- PROCEDURE NAME: Valida_Art_Inv_Expense
  --
  -- DESCRIPTION    : Contiene la funcionalidad de la personalizaci?n Validacion de
  -- articulos inventariables en ARG
  -- Validaci?n de Fecha de Art?lo de Erogaci?n
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              20/09/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE Valida_Art_Inv_Expense (p_document_id        IN            NUMBER,
                                    p_online_report_id   IN            NUMBER,
                                    p_sequence           IN OUT NOCOPY NUMBER)
  IS

    CURSOR c_distribuciones_error
    IS SELECT pla.line_num,
    plla.shipment_num,
    pda.distribution_num,
    p_sequence + ROWNUM sequence
    FROM po_headers_all pha,
    po_lines_all pla,
    po_line_locations_all plla,
    po_distributions_all pda,
    mtl_system_items_b msib
    WHERE pha.type_lookup_code = 'STANDARD'
    AND pha.po_header_id = pla.po_header_id
    AND pha.po_header_id = plla.po_header_id
    AND pha.po_header_id = pda.po_header_id
    AND pla.po_line_id = plla.po_line_id
    AND pla.po_line_id = pda.po_line_id
    AND plla.line_location_id = pda.line_location_id
    AND pda.destination_type_code = 'EXPENSE'
    AND pla.item_id = msib.inventory_item_id
    AND plla.ship_to_organization_id = msib.organization_id
    AND Nvl(msib.inventory_item_flag, 'N') = 'Y'
    AND pha.po_header_id = p_document_id;

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_INV_ITEM'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

    FOR r_distribucion_error IN c_distribuciones_error
    LOOP

      Inserta_Error (p_document_id,
                     r_distribucion_error.line_num,
                     r_distribucion_error.shipment_num,
                     r_distribucion_error.distribution_num,
                     p_online_report_id,
                     r_distribucion_error.sequence,
                     'E',
                     'Error. Linea ' || r_distribucion_error.line_num ||
                     ', Envio' || r_distribucion_error.shipment_num ||
                     ', Distribucion ' || r_distribucion_error.distribution_num ||
                     '. No es posible elegir una distribucion de tipo Gasto para lineas con articulos inventariables.');

    END LOOP;

  EXCEPTION

    WHEN OTHERS
    THEN

      ROLLBACK;

  END Valida_Art_Inv_Expense;

  --*************************************************************************************
  -- PROCEDURE NAME: Valida_Atributos_Flexfield
  --
  -- DESCRIPTION    : Contiene la funcionalidad de la personalizaci?n XX Valida atributos
  -- flexfield
  -- Validaci?n de Fecha de Art?lo de Erogaci?n
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              20/09/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE Valida_Atributos_Flexfield (p_document_id        IN            NUMBER,
                                        p_online_report_id   IN            NUMBER,
                                        p_sequence           IN OUT NOCOPY NUMBER)
  IS

    CURSOR c_lineas_error
    IS SELECT pla.line_num,
    p_sequence + ROWNUM sequence
    FROM po_headers_all pha,
    po_lines_all pla,
    financials_system_parameters fsp,
    po_lines_all_dfv plad,
    mtl_system_items_b msib,
    mtl_categories mc,
    mtl_category_sets mcs,
    mtl_item_categories mic
    WHERE pha.type_lookup_code = 'STANDARD'
    AND pha.po_header_id = pla.po_header_id
    AND pla.rowid = plad.row_id
    AND ((plad.xx_po_capacidad_cont_en_pico IS NULL)
      OR (plad.xx_po_capacidad_cont_fuer_pico IS NULL)
      OR (plad.xx_po_capacidad_reg_en_pico IS NULL)
      OR (plad.xx_po_capacidad_reg_fuera_pico IS NULL))
    AND fsp.inventory_organization_id = msib.organization_id
    -- AND Nvl(msib.inventory_item_flag, 'N') = 'Y'
    AND pla.item_id = msib.inventory_item_id
    AND mc.segment1 = 'XXPOFLXNRG'
    AND mc.structure_id = mcs.structure_id
    AND mcs.category_set_name = 'XX_CUSTOM_USE'
    AND mic.category_id = mc.category_id
    AND mic.category_set_id = mcs.category_set_id
    AND msib.inventory_item_id = mic.inventory_item_id
    AND msib.organization_id = mic.organization_id
    AND pha.po_header_id = p_document_id;

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_FLEX_ENERGY'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

    FOR r_linea_error IN c_lineas_error
    LOOP

      Inserta_Error (p_document_id,
                     r_linea_error.line_num,
                     0,
                     0,
                     p_online_report_id,
                     r_linea_error.sequence,
                     'E',
                     'Error. Linea ' || r_linea_error.line_num ||
                     '. Debe completar los valores de capacidad.');

    END LOOP;

  EXCEPTION

    WHEN OTHERS
    THEN

      ROLLBACK;

  END Valida_Atributos_Flexfield;

  --*************************************************************************************
  -- PROCEDURE NAME: Main
  --
  -- DESCRIPTION    : Proceso llamado por el package PO_CUSTOM_SUBMISSION_CHECK_PVT
  --                  para validaciones custom de ?rdenes de compra
  -- PARAMETERS     : p_document_id - Id of the document to validate
  --                  p_online_report_id - Id to be used when inserting records into
  --                                       PO_ONLINE_REPORT_TEXT_GT table
  --                  p_sequence - Sequence number of last reported error
  --
  -- CHANGE REQUEST:
  --
  --   PROGRAMMER       UPDATE_DATE     DESCRIPTION
  --   -------------    -----------     ------------
  --   ITC              20/09/2017      Initial version
  --
  --************************************************************************************/
  PROCEDURE Main (p_document_id        IN            NUMBER,
                  p_document_type      IN            VARCHAR2,
                  p_online_report_id   IN            NUMBER,
                  p_sequence           IN OUT NOCOPY NUMBER)
  IS

    l_custom_habilitada VARCHAR2(1) := 'N';

  BEGIN

    SELECT Nvl(Fnd_Profile.Value('XX_PO_HOOK'), 'N')
    INTO l_custom_habilitada
    FROM DUAL;

    IF(l_custom_habilitada = 'N')
    THEN

      RETURN;

    END IF;

    IF(p_document_type != 'PO')
    THEN

      RETURN;

    END IF;

    IF (Xx_Jg_Zz_Shared_Pkg.Get_Country(p_org_id => Mo_Global.Get_Current_Org_Id,
                                       p_ledger_id => NULL,
                                       p_inv_org_id => NULL) = 'AR')
    THEN

      -- Valida Fletes Insumos
      Valida_Item_Flete (p_document_id,
                         p_online_report_id,
                         p_sequence);

      -- Valida Remito ya Asociado
      Valida_Remito_Asociado (p_document_id,
                              p_online_report_id,
                              p_sequence);

      -- Validaciones del modulo de PA
      Valida_Fecha_Art_Erogacion (p_document_id,
                                  p_online_report_id,
                                  p_sequence);
      Valida_Org_Erog_Proy_Tarea (p_document_id,
                                  p_online_report_id,
                                  p_sequence);

      -- Validaciones de datos obligatorios
      Valida_Fecha_Pactada_Envios (p_document_id,
                                   p_online_report_id,
                                   p_sequence);

      --Validacion de articulos inventariables
      Valida_Art_Inv_Expense (p_document_id,
                              p_online_report_id,
                              p_sequence);

      --Validacion de atributos de dff
      Valida_Atributos_Flexfield (p_document_id,
                                  p_online_report_id,
                                  p_sequence);

      --Validacion de precio retroactivo
      Valida_Precio_Retroactivo  (p_document_id,
                                  p_online_report_id,
                                  p_sequence);

    END IF;

    IF (Xx_Jg_Zz_Shared_Pkg.Get_Country(p_org_id => Mo_Global.Get_Current_Org_Id,
                                       p_ledger_id => NULL,
                                       p_inv_org_id => NULL) = 'UY')
    THEN

      --Validacion de precio retroactivo
      Valida_Precio_Retroactivo  (p_document_id,
                                  p_online_report_id,
                                  p_sequence);

    END IF;

  END Main;

END XX_PO_CUSTOM_SUBMISSION_CHECK;
/

exit
