#!/bin/sh
# Descri��o do GAP: ESBR - Raz�o Cont�bil (com Item)
# Versao:           1.0
# Data:             25-Mar-2020
#
#
cp ESBR_GL_RAZAO_ITEM.rdf           $ESBR_TOP/reports/PTB/ESBR_GL_RAZAO_ITEM.rdf
cp ESBR_GL_RAZAO_ITEM.rdf           $ESBR_TOP/reports/US/ESBR_GL_RAZAO_ITEM.rdf
#
# Limpar a vari�vel com a senha do apps.
unset apps_pass
#
echo "Verifique os logs de execu��o para confirmar a instala��o"
# Fim do script