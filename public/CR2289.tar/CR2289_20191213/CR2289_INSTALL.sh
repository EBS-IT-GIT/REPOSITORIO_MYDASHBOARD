#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2289_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2289
# |
# | HISTORY
# |   13-DEC-19  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2289_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2289_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2289
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/TEMPLATES/
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2289" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2289_13802.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2289"
AddAllLogs $CROUT "FND" "CR2289_13802.ldt"
mv CR2289_13802.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXAPPVBRXML " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXAPPVBRXML.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXAPPVBRXML"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPPVBRXML \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXAPPVBRXML_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXAPPVBRXML.ldt"
mv XXAPPVBRXML* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXARCIRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXARCIRE.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXARCIRE"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARCIRE \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXARCIRE_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXARCIRE.ldt"
mv XXARCIRE* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXARTRXIMP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXARTRXIMP.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXARTRXIMP"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARTRXIMP \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXARTRXIMP_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXARTRXIMP.ldt"
mv XXARTRXIMP* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXARSUBCAN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXARSUBCAN.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXARSUBCAN"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARSUBCAN \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXARSUBCAN_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXARSUBCAN.ldt"
mv XXARSUBCAN* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXAPAUDFAC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXAPAUDFAC.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXAPAUDFAC"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPAUDFAC \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXAPAUDFAC_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXAPAUDFAC.ldt"
mv XXAPAUDFAC* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXAPRETPARR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXAPRETPARR.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXAPRETPARR"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPRETPARR \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXAPRETPARR_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXAPRETPARR.ldt"
mv XXAPRETPARR* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXAPLIARRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXAPLIARRE.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXAPLIARRE"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPLIARRE \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXAPLIARRE_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXAPLIARRE.ldt"
mv XXAPLIARRE* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto XML- XXAPRG2549 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $XDO_TOP/patch/115/import/xdotmpl.lct XXAPRG2549.ldt XDO_DS_DEFINITIONS APPLICATION_SHORT_NAME="XBOL" DATA_SOURCE_CODE="XXAPRG2549"

java oracle.apps.xdo.oa.util.XDOLoader DOWNLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPRG2549 \
-LANGUAGE "es" \
-TERRITORY "AR" \
-LOG_FILE XXAPRG2549_xml_down.log \
-lct_FILE $XDO_TOP/patch/115/import/xdotmpl.lct

AddAllLogs $CROUT "XML" "XXAPRG2549.ldt"
mv XXAPRG2549* $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename DATA_TEMPLATE_XBOL_ "" *.xml
mv *.xml $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_SOURCE_XBOL_ "" *.rtf
mv *.rtf $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rename TEMPLATE_XBOL_ "" *.xls
mv *.xls $DOWNDBDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/
rm -f *.xsl


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXAPPVBRXML " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPPVBRXML \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXAPPVBRXML_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPPVBRXML_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXARCIRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARCIRE \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXARCIRE_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARCIRE_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXARTRXIMP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARTRXIMP \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXARTRXIMP_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARTRXIMP_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXARSUBCAN " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXARSUBCAN \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXARSUBCAN_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXARSUBCAN_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXAPAUDFAC " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPAUDFAC \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXAPAUDFAC_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPAUDFAC_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXAPRETPARR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPRETPARR \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXAPRETPARR_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRETPARR_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXAPLIARRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPLIARRE \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXAPLIARRE_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPLIARRE_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto XML- XXAPRG2549 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $XDO_TOP/patch/115/import/xdotmpl.lct $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt CUSTOM_MODE=FORCE

java oracle.apps.xdo.oa.util.XDOLoader UPLOAD \
-DB_USERNAME apps \
-DB_PASSWORD $APPS_PWD \
-JDBC_CONNECTION $HOST:$PORT:$DDBB \
-LOB_TYPE TEMPLATE \
-APPS_SHORT_NAME XBOL \
-LOB_CODE XXAPRG2549 \
-LANGUAGE "es" \
-TERRITORY "AR" \
-XDO_FILE_TYPE RTF \
-FILE_CONTENT_TYPE application/pdf \
-FILE_NAME $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549_es_AR.rtf  \
-CUSTOM_MODE FORCE \
-LOG_FILE XXAPRG2549_up.log

AddAllLogs $CROUT "XML" "$INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549.ldt -m $CRNUM >> $CROUT 2>> $CRERR
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549_es_AR.rtf &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549_es_AR.rtf >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549_es_AR.rtf /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/TEMPLATES/XXAPRG2549_es_AR.rtf -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch
. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2289" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2289_13802.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2289_13802.ldt"

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
