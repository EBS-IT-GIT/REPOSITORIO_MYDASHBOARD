UPDATE apps.ra_customer_trx_all
SET    trx_number = 'A-0001-00002582', last_update_date = sysdate, last_updated_by = 2070
WHERE  customer_trx_id = 16005374;
--1 Registro