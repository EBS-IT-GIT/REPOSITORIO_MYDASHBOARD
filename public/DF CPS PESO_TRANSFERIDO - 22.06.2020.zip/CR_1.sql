UPDATE apps.XX_TCG_CARTAS_PORTE_ALL x1
SET PESO_TRANSFERIDO = ( SELECT  TRANSACTION_QUANTITY
                                                        FROM apps.XX_TCG_MOVIMIENTO_INVENTARIO_V  x2
                                                        WHERE x2.REASON_CODE = 'TRNI'
                                                        AND x2.TRANSACTION_QUANTITY > 0
                                                        AND x2.TIPO_MOVIMIENTO = 'T'
                                                        AND x2.CARTA_PORTE_ID = x1.CARTA_PORTE_ID),
 LAST_UPDATE_DATE = sysdate,
 LAST_UPDATED_BY = 2070
WHERE x1.ANULADO_FLAG = 'N'
AND ((NOT x1.RTTE_COMERCIAL IS NULL AND x1.RTTE_COMERCIAL_RETIRO = 'Y') OR (NOT x1.INTERMEDIARIO IS NULL AND x1.INTERMEDIARIO_RETIRO = 'Y'))
AND x1.TRANSFERIDO_FLAG=  'Y'
AND x1.RECIBIDO_FLAG = 'Y'
AND x1.PESO_TRANSFERIDO IS NULL   
AND x1.CREATION_DATE > sysdate - 60                                                                           
--47