UPDATE ap_payment_schedules_all aps
SET    amount_remaining = 0
      ,last_updated_by = -1
      ,last_update_login = -1
      ,last_update_date = sysdate
WHERE  invoice_id = (SELECT invoice_id 
                     FROM    ap_invoices_all
                     WHERE   invoice_num = '0237-00002724');
--1 Registro