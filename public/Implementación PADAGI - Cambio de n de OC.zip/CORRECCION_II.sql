UPDATE apps.oe_order_lines_all ool
SET    cust_po_number = cust_po_number||'_1'
WHERE  header_id IN (SELECT header_id
                     FROM   apps.oe_order_headers_all ooh
                     WHERE  cust_po_number iN ('1841781','1930638','1930653','1930655','1930657','1930680',
                                               '1930697','1930699','1930708','1930709','1930710','1930714',
                                               '1930715','1930717','1930718','1930720','1930721','1930722',
                                               '1953266'));
--19 Registros