#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2506_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2506
# |
# | HISTORY
# |   22-JUL-20  Silva, Alejandra - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2506_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2506_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2506
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/TB
mkdir -p xbol/12.0.0/sql/VIEW
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT


echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-VIEW XX_PO_VALIDA_OC " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('VIEW','XX_PO_VALIDA_OC','APPS','$PATCHDIR','CR2506');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_PO_VALIDA_OC* $DOWNDBDIR/xbol/12.0.0/sql/VIEW

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-VIEW XX_AP_VALIDA_PROVEEDORES " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('VIEW','XX_AP_VALIDA_PROVEEDORES','APPS','$PATCHDIR','CR2506');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AP_VALIDA_PROVEEDORES* $DOWNDBDIR/xbol/12.0.0/sql/VIEW

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-VIEW XX_AP_VALIDA_CUENTA_BANCARIA " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('VIEW','XX_AP_VALIDA_CUENTA_BANCARIA','APPS','$PATCHDIR','CR2506');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AP_VALIDA_CUENTA_BANCARIA* $DOWNDBDIR/xbol/12.0.0/sql/VIEW



more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TB XX_ABBYY_TRAZABILIDAD_LOTES " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TB/XX_ABBYY_TRAZABILIDAD_LOTES >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_ABBYY_TRAZABILIDAD_LOTES.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_ABBYY_TRAZABILIDAD_LOTES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_ABBYY_TRAZABILIDAD_LOTES.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TB/XX_ABBYY_TRAZABILIDAD_LOTES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/TB/XX_ABBYY_TRAZABILIDAD_LOTES.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_PO_VALIDA_OC " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_PO_VALIDA_OC.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_AP_VALIDA_PROVEEDORES " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_PROVEEDORES.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-VIEW XX_AP_VALIDA_CUENTA_BANCARIA " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/VIEW/XX_AP_VALIDA_CUENTA_BANCARIA.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF GRANT_INDEX " >> $CROUT; echo "" >> $CROUT
sqlplus -s bolinf/$BOLINF_PWD @$INSTDIR/xbol/12.0.0/sql/DF/GRANT_INDEX >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/GRANT_INDEX.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/GRANT_INDEX.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/GRANT_INDEX.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/GRANT_INDEX.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/GRANT_INDEX.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF SYNONYM " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/SYNONYM >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYNONYM.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/SYNONYM.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYNONYM.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/SYNONYM.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/SYNONYM.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF EDIT_VIEW " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/EDIT_VIEW >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/EDIT_VIEW.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/EDIT_VIEW.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/EDIT_VIEW.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/EDIT_VIEW.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/EDIT_VIEW.sql -m $CRNUM >> $CROUT 2>> $CRERR


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2506" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2506_9555.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2506_9555.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
