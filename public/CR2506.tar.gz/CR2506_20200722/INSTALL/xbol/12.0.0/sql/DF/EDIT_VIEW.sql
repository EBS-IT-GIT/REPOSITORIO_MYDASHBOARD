  set define off;
BEGIN ad_zd_table.upgrade('BOLINF', 'XX_ABBYY_TRAZABILIDAD_LOTES'); END;
/
exit
