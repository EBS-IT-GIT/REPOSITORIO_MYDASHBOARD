  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_PO_VALIDA_OC" ("CUIT_EMPRESA"
                                                                         , "CUIT_PROVEEDOR"
                                                                         , "ORDEN_COMPRA"
                                                                         , "MONEDA_ORDEN_COMPRA"
                                                                         , "MONTO_TOTAL"
                                                                         , "TERMINO_PAGO"
                                                                         , "DIAS_VTO_PAGO"
                                                                         , "NOMBRE_SUCURSAL"
                                                                         , "COMPRADOR") AS 
  SELECT hld.primary_id_number || hld.primary_id_valid_digit__ar_
             cuit_empresa,
          aps.num_1099 || pvd.taxpayer_id_validation_digit cuit_proveedor,
          ph.segment1 orden_compra,
          ph.currency_code moneda_orden_compra,
          COALESCE (ph.amount_limit,
                    (SELECT SUM (pl.unit_price * pl.quantity)
                       FROM PO_LINES_ALL pl
                      WHERE pl.po_header_id = ph.po_header_id),
                    0)
             monto_total,
          apt.name termino_pago,
          aptl.due_days dias_vto_pago,
          apss.vendor_site_code nombre_sucursal,
          ppf.full_name comprador
     FROM PO_HEADERS_ALL ph,
          HR_ORGANIZATION_UNITS hou,
          HR_LOCATIONS_ALL hl,
          HR_LOCATIONS_ALL2_DFV hld,
          AP_SUPPLIERS aps,
          PO_VENDORS1_DFV pvd,
          AP_TERMS apt,
          AP_TERMS_LINES aptl,
          AP_SUPPLIER_SITES_ALL apss,
          PER_PEOPLE_F ppf
    WHERE NVL (ph.authorization_status, 'INCOMPLETE') = 'APPROVED'
          AND NVL (ph.closed_code, 'X') <> 'FINALLY CLOSED'
          AND NVL (ph.cancel_flag, 'N') = 'N'
          AND ph.org_id = hou.organization_id
          AND hou.name LIKE 'AR %'
          AND hou.location_id = hl.location_id
          AND hl.ROWID = hld.row_id
          AND hl.global_attribute_category = 'JL.AR.PERWSLOC.LOC'
          AND ph.vendor_id = aps.vendor_id
          AND aps.ROWID = pvd.row_id
          AND aps.global_attribute_category = 'JL.AR.APXVDMVD.SUPPLIERS'
          AND aps.num_1099 IS NOT NULL
          AND TRUNC (SYSDATE) BETWEEN NVL (aps.start_date_active,
                                           TRUNC (SYSDATE))
                                  AND NVL (aps.end_date_active,
                                           TRUNC (SYSDATE))
          AND ph.terms_id = apt.term_id(+)
          AND apt.term_id = aptl.term_id(+)
          AND ph.vendor_site_id = apss.vendor_site_id
          AND ph.agent_id = ppf.person_id
          AND TRUNC (SYSDATE) BETWEEN NVL (ppf.effective_start_date,
                                           TRUNC (SYSDATE))
                                  AND NVL (ppf.effective_end_date,
                                           TRUNC (SYSDATE));


exit
