  set define off;
SET line 4000


  CREATE OR REPLACE VIEW "APPS"."XX_AP_VALIDA_PROVEEDORES" ("CUIT_EMPRESA"
                                                                         , "CUIT_PROVEEDOR"
                                                                         , "NOMBRE_PROVEEDOR"
                                                                         , "CODIGO_ESTRUCTURA_LEGAL"
                                                                         , "ESTRUCTURA_LEGAL"
                                                                         , "ORIGEN"
                                                                         , "NOMBRE_SUCURSAL"
                                                                         , "TERMINO_PAGO"
                                                                         , "DIAS_VTO_PAGO"
                                                                         , "PRIORIDAD_PAGO") AS 
  SELECT hld.primary_id_number || hld.primary_id_valid_digit__ar_                 cuit_empresa
     , aps.num_1099 || pvd.taxpayer_id_validation_digit                         cuit_proveedor
     , aps.vendor_name                                                          nombre_proveedor
     , hop.legal_status                                                         codigo_estructura_legal
     , (SELECT meaning
          FROM AR_LOOKUPS
         WHERE lookup_type = 'LEGAL_STATUS'
           AND lookup_code = hop.legal_status)                                  estructura_legal
     , DECODE (aps.global_attribute9, 'DOMESTIC_ORIGIN', 'Nacional'
                                    , 'FOREIGN_ORIGIN', 'Extranjero')           origen
     , apss.vendor_site_code                                                    nombre_sucursal
     , apt.name                                                                 termino_pago
     , aptl.due_days                                                            dias_vto_pago
     , aps.payment_priority                                                     prioridad_pago
  FROM AP_SUPPLIERS             aps
     , PO_VENDORS1_DFV          pvd
     , AP_SUPPLIER_SITES_ALL    apss
     , HR_ORGANIZATION_UNITS    hou
     , HR_LOCATIONS_ALL         hl
     , HR_LOCATIONS_ALL2_DFV    hld
     , HZ_ORGANIZATION_PROFILES hop
     , AP_TERMS                 apt
     , AP_TERMS_LINES           aptl
 WHERE aps.rowid                     = pvd.row_id
   AND aps.global_attribute_category = 'JL.AR.APXVDMVD.SUPPLIERS'
   AND aps.num_1099                  IS NOT NULL
   AND TRUNC(SYSDATE)                BETWEEN NVL (aps.start_date_active, TRUNC(SYSDATE))
                                         AND NVL (aps.end_date_active, TRUNC(SYSDATE))
   AND aps.vendor_id                 = apss.vendor_id
   AND apss.inactive_date            IS NULL
   AND apss.org_id                   = hou.organization_id
   AND hou.location_id               = hl.location_id
   AND hl.rowid                      = hld.row_id
   AND hl.global_attribute_category  = 'JL.AR.PERWSLOC.LOC'
   AND hou.name                      LIKE 'AR %'
   AND hld.primary_id_number         IS NOT NULL
   AND aps.party_id                  = hop.party_id (+)
   AND hop.effective_end_date        IS NULL
   AND aps.terms_id                  = apt.term_id (+)
   AND apt.term_id                   = aptl.term_id (+);


exit
