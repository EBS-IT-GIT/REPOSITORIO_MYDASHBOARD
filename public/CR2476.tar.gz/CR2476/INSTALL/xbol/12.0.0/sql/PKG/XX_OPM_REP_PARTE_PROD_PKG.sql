  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OPM_REP_PARTE_PROD_PKG" as

 function escala_a_real   (   p_batch_status in number
                                    ,   p_header_org_id in number
                                    ,    p_batch_id in number
                                    , p_line_no in number
                                    , p_line_type in number) return number;

end  XX_OPM_REP_PARTE_PROD_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OPM_REP_PARTE_PROD_PKG" AS

 function escala_a_real   (   p_batch_status in number
                                    ,   p_header_org_id in number
                                    ,    p_batch_id in number
                                    , p_line_no in number
                                    , p_line_type in number) return number is

    l_scale_tab                   gmd_common_scale.scale_tab;
    x_scale_tab                   gmd_common_scale.scale_tab;
    x_return_status varchar2(500);
    l_coef_escala number;

begin
  if nvl(p_batch_status,0) not  in (3,4) then
     return null;
  end if;

  SELECT  --decode(nvl(WIP_PLAN_QTY,0),0,1,nvl(ACTUAL_QTY,0) / WIP_PLAN_QTY)
            decode(nvl(PLAN_QTY,0),0,1,nvl(ACTUAL_QTY,0) / PLAN_QTY) -- CR2476 Se cambia el wip por el planificado
     INTO l_coef_escala
   FROM gme_material_details a
  WHERE batch_id = p_batch_id
      AND line_type = 1
      AND LINE_NO = 1 ;

  for c1 in (  SELECT  dtl_um, scale_type,contribute_yield_ind,scale_multiple,  scale_rounding_variance , rounding_direction, line_no,  line_type, inventory_item_id, plan_qty, wip_plan_qty
             FROM gme_material_details a
            WHERE batch_id = p_batch_id and line_type = p_line_type AND LINE_NO = p_line_no
         ORDER BY Line_no, inventory_item_id) loop

            l_scale_tab (1).qty                                      := c1.plan_qty; -- CR2476 Se cambia el wip por el planificado c1.wip_plan_qty; 
            l_scale_tab (1).detail_uom                          := c1.dtl_um;
            l_scale_tab (1).scale_type                           := c1.scale_type;
            l_scale_tab (1).contribute_yield_ind              :=  c1.contribute_yield_ind;
            l_scale_tab (1).scale_multiple                      :=  c1.scale_multiple;
            l_scale_tab (1).scale_rounding_variance       :=  c1.scale_rounding_variance;
            IF c1.rounding_direction is not null and
                c1.rounding_direction = 0 then -- Cuando tiene ambas direcciones de redondeo se debe asumir que el redondeo es para arriba
                 l_scale_tab (1).rounding_direction         := 1;
            else
                l_scale_tab (1).rounding_direction          := c1.rounding_direction;
             end if;
            l_scale_tab (1).line_no                             := c1.line_no;
            l_scale_tab (1).line_type                           := c1.line_type;
            l_scale_tab (1).inventory_item_id               :=  c1.inventory_item_id;
      END LOOP;

     gmd_common_scale.scale (p_scale_tab          => l_scale_tab
                             ,p_orgn_id            => p_header_org_id
                             ,p_scale_factor       => l_coef_escala
                             ,p_primaries          => 'INPUT'
                             ,x_scale_tab          => x_scale_tab
                             ,x_return_status      => x_return_status);

      return abs(ROUND(x_scale_tab (1).qty,5)) * (case  when p_line_type = -1  then -1 else 1 end);

end escala_a_real;

end XX_OPM_REP_PARTE_PROD_PKG;
/

exit
