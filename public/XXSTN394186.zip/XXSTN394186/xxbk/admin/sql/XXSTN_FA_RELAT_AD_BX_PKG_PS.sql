WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE apps.XXSTN_FA_RELAT_AD_BX_PKG IS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_FA_RELAT_AD_BX_PKG_PS.sql                                 |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   FA - Relatorio de Adicao e Baixa do ativo                     |
-- |                                                                 |
-- | CREATED BY   Rogerio Farto - Ninecon - 17/01/2020               |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+

  gn_xml_tag_start CONSTANT NUMBER := 0;
  gn_xml_tag_end   CONSTANT NUMBER := 1;
  gn_xml_tag_full  CONSTANT NUMBER := 2;

  PROCEDURE generate_report_p(p_errbuf        OUT VARCHAR2
                             ,p_retcode       OUT NUMBER
                             ,p_book_type_code IN VARCHAR2
                             ,p_start_period   IN VARCHAR2
                             ,p_end_period     IN VARCHAR2
                             ,p_category       IN NUMBER
                             );

END XXSTN_FA_RELAT_AD_BX_PKG;
/

EXIT; 