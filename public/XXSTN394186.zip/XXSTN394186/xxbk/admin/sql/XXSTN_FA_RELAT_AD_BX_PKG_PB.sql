WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

create or replace PACKAGE BODY apps.XXSTN_FA_RELAT_AD_BX_PKG IS
-- +=================================================================+
-- |               Copyright (c) 2018 STONE Pagamentos               |
-- |                   All rights reserved.                          |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_FA_RELAT_AD_BX_PKG_PB.sql                                 |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |   FA - Relatorio de Adicao e Baixa do ativo                     |
-- |                                                                 |
-- | CREATED BY   Rogerio Farto - Ninecon - 17/01/2020               |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |                                                                 |
-- +=================================================================+
  -- Function and procedure implementations
  PROCEDURE generate_report_p (p_errbuf        OUT VARCHAR2
                              ,p_retcode       OUT NUMBER
                              ,p_book_type_code IN VARCHAR2
                              ,p_start_period   IN VARCHAR2
                              ,p_end_period     IN VARCHAR2
                              ,p_category       IN NUMBER) IS
  --
  CURSOR c_adbx (pc_start_period   VARCHAR2
                ,pc_end_period     VARCHAR2
                ,pc_book_type_code VARCHAR2
                ,pc_category       NUMBER ) IS
         -- ******************************************************
         -- QUERY ADI��ES
         -- ******************************************************
         SELECT 'ADICAO' tipo,
                xep.name empresa,
                fac.description categoria,
                ad.asset_number numero_de_ativo,
                ad.serial_number serial,
                nfs.nf,
                ad.description historico,
                ad.model_number modelo,
                SUM(nvl(DECODE(adj1.debit_credit_flag, 'DR', 1, -1) *
                        adj1.adjustment_amount,
                        dd.addition_cost_to_clear)) custo,
                ad.current_units quantidade,
                DECODE(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct) gl_account,
                dhcc.segment5 cost_center,
                bks.date_placed_in_service data_de_entrada,
                null data_de_retirada,
                null meses_depreciados,
                null depreciacao_acumulada,
                null valor_residual,
                null venda
           FROM apps.fa_lookups falu,
                apps.fa_additions ad,
                apps.fa_asset_history ah,
                apps.fa_transaction_headers th,
                apps.fa_category_books cb,
                apps.fa_distribution_history dh,
                apps.gl_code_combinations dhcc,
                apps.fa_adjustments adj1,
                apps.fa_books bks,
                apps.fa_deprn_detail dd,
                apps.fa_deprn_periods fdp,
                apps.fa_categories fac,
                apps.hr_operating_units hou,
                apps.xle_entity_profiles xep,
                apps.fa_book_controls fbc,
                (SELECT fai.asset_id,
                        LISTAGG(fai.invoice_number, ';') WITHIN GROUP(ORDER BY fai.invoice_number) nf
                   FROM apps.fa_asset_invoices fai
                  GROUP BY fai.asset_id) nfs
          WHERE 1 = 1
            AND adj1.book_type_code   = th.book_type_code
            AND adj1.transaction_header_id = th.transaction_header_id
            AND dh.distribution_id    = adj1.distribution_id
            AND dhcc.code_combination_id = dh.code_combination_id
            AND ah.asset_type         = falu.lookup_code
            AND ad.asset_id           = th.asset_id
            AND ah.asset_id           = th.asset_id
            AND bks.transaction_header_id_in = th.transaction_header_id
            AND cb.book_type_code     = th.book_type_code
            AND cb.category_id        = ah.category_id
            AND dd.book_type_code(+)  = adj1.book_type_code
            AND dd.distribution_id(+) = adj1.distribution_id
            AND ad.asset_category_id  = fac.category_id
            AND ad.asset_id           = nfs.asset_id(+)
            AND ((adj1.source_type_code = 'CIP ADDITION'
            AND   adj1.adjustment_type = 'CIP COST')
             OR  (adj1.source_type_code = 'ADDITION'
            AND   adj1.adjustment_type = 'COST'))
            AND dd.deprn_source_code(+) = 'B'
            AND falu.lookup_type      = 'ASSET TYPE'
            AND th.date_effective     >= ah.date_effective
            AND th.date_effective     < nvl(ah.date_ineffective, SYSDATE)
            AND th.book_type_code     = fdp.book_type_code
            AND th.date_effective BETWEEN fdp.period_open_date
                                      AND nvl(fdp.period_close_date, SYSDATE)
            AND bks.book_type_code    = fbc.book_type_code
            AND hou.organization_id   = fbc.org_id
            AND hou.default_legal_context_id = xep.legal_entity_id
            AND fdp.period_counter >= (SELECT MIN(period_counter)
                                         FROM apps.fa_deprn_periods
                                        WHERE period_name IN (pc_start_period)
                                          AND book_type_code    = nvl(pc_book_type_code, bks.book_type_code))
            AND fdp.period_counter <= (SELECT MAX(period_counter)
                                         FROM apps.fa_deprn_periods
                                        WHERE period_name IN (pc_end_period)
                                          AND book_type_code    = nvl(pc_book_type_code, bks.book_type_code))
            AND ad.asset_category_id  = NVL(pc_category,ad.asset_category_id)
            AND bks.book_type_code    = nvl(pc_book_type_code, bks.book_type_code)
          GROUP 
             BY 'ADICAO',
                xep.name,
                fac.description,
                ad.asset_number,
                nfs.nf,
                ad.serial_number,
                bks.date_placed_in_service,
                ad.description,
                ad.model_number,
                ad.current_units,
                fdp.period_name,
                DECODE(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct),
                dhcc.segment5,
                falu.meaning
         UNION
         SELECT 'ADICAO' tipo,
                xep.name empresa,
                fac.description categoria,
                ad.asset_number numero_de_ativo,
                ad.serial_number serial,
                nfs.nf,
                ad.description historico,
                ad.model_number modelo,
                0 custo,                           
                ad.current_units quantidade,
                DECODE(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct) gl_account,
                dhcc.segment5 cost_center,
                bks.date_placed_in_service data_de_entrada,
                null data_de_retirada,
                null meses_depreciados,
                null depreciacao_acumulada,
                null valor_residual,
                null venda
           FROM apps.fa_lookups falu,
                apps.fa_additions ad,
                apps.fa_asset_history ah,
                apps.fa_category_books cb,
                apps.gl_code_combinations dhcc,
                apps.fa_distribution_history dh,
                apps.fa_books bks,
                apps.fa_deprn_periods fdp,
                apps.fa_categories fac,
                apps.fa_asset_invoices fai,
                apps.hr_operating_units hou,
                apps.xle_entity_profiles xep,
                apps.fa_book_controls fbc,
                (SELECT th.book_type_code,
                        th.transaction_header_id,
                        th.asset_id,
                        th.date_effective,
                        dp.period_counter,
                        dp.period_name
                   FROM apps.fa_transaction_headers th
                      , apps.fa_deprn_periods dp
                  WHERE th.book_type_code = dp.book_type_code
                    AND th.transaction_type_code IN ('ADDITION', 'CIP ADDITION')
                    AND th.date_effective BETWEEN dp.period_open_date AND
                        nvl(dp.period_close_date, SYSDATE)) th,
                (SELECT fai.asset_id,
                        LISTAGG(fai.invoice_number, ';') WITHIN GROUP(ORDER BY fai.invoice_number) nf
                   FROM apps.fa_asset_invoices fai
                  GROUP BY fai.asset_id) nfs
          WHERE 1 = 1
            AND dh.asset_id           = th.asset_id
            AND th.date_effective     >= dh.date_effective
            AND th.date_effective     < nvl(dh.date_ineffective, SYSDATE)
            AND dhcc.code_combination_id = dh.code_combination_id
            AND falu.lookup_type      = 'ASSET TYPE'
            AND ah.asset_type         = falu.lookup_code
            AND ad.asset_id           = th.asset_id
            AND ah.asset_id           = th.asset_id
            AND th.date_effective     >= ah.date_effective
            AND th.date_effective     < nvl(ah.date_ineffective, SYSDATE)
            AND ah.asset_type         <> 'EXPENSED'
            AND bks.transaction_header_id_in = th.transaction_header_id
            AND bks.cost              = 0
            AND cb.book_type_code     = th.book_type_code
            AND cb.category_id        = ah.category_id
            AND ad.asset_category_id  = fac.category_id
            AND ad.asset_id           = fai.asset_id
            AND th.book_type_code     = fdp.book_type_code
            AND th.date_effective BETWEEN fdp.period_open_date
                                      AND nvl(fdp.period_close_date, SYSDATE)
            AND ad.asset_id           = nfs.asset_id(+)
            AND bks.book_type_code    = fbc.book_type_code
            AND hou.organization_id   = fbc.org_id
            AND hou.default_legal_context_id = xep.legal_entity_id
            AND th.period_counter >= (SELECT MIN(period_counter)
                                         FROM apps.fa_deprn_periods
                                        WHERE period_name IN (pc_start_period)
                                          AND book_type_code    = nvl(pc_book_type_code, bks.book_type_code))
            AND th.period_counter <= (SELECT MAX(period_counter)
                                         FROM apps.fa_deprn_periods
                                        WHERE period_name IN (pc_end_period)
                                          AND book_type_code    = nvl(pc_book_type_code, bks.book_type_code))
            AND ad.asset_category_id  = NVL(pc_category,ad.asset_category_id)
            AND bks.book_type_code    = nvl(pc_book_type_code, bks.book_type_code)
         -- ******************************************************
         -- QUERY BAIXAS
         -- ******************************************************                       
         UNION
         SELECT /*+ ordered */
                'BAIXA' tipo,
                fdp.book_type_code Empresa,
                fac.description Categoria,
                ad.asset_number Numero_de_Ativo,
                ad.serial_number Serial,
                fai.invoice_number nf,
                ad.description Historico,
                null Modelo, --voltar Farto 
                sum(decode(aj.adjustment_type, 'COST', 1, 'CIP COST', 1, 0) *
                    decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                    aj.adjustment_amount) Custo,
                null Quantidade, --voltar Farto 
                decode(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct) gl_account,
                gcc.segment5 cost_center,
                books.date_placed_in_service Data_de_Entrada,
                ret.date_retired Data_de_Retirada,
                LEAST(TRUNC(MONTHS_BETWEEN(ret.date_retired, books.date_placed_in_service)),books.life_in_months) Meses_Depreciados,
                sum(decode(aj.adjustment_type, 'COST', 1, 'CIP COST', 1, 0) *
                    decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                    aj.adjustment_amount) -
                    sum(decode(aj.adjustment_type, 'NBV RETIRED', -1, 0) *
                        decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                        aj.adjustment_amount) Depreciacao_Acumulada,
                sum(decode(aj.adjustment_type, 'NBV RETIRED', -1, 0) *
                    decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                    aj.adjustment_amount) Valor_Residual,
                    sum(decode(aj.adjustment_type, 'PROCEEDS CLR', 1, 'PROCEEDS', 1, 0) *
                        decode(aj.debit_credit_flag, 'DR', 1, 'CR', -1, 0) *
                        aj.adjustment_amount) Venda
           FROM apps.fa_transaction_headers th,
                apps.fa_additions ad,
                apps.fa_books books,
                apps.fa_retirements ret,
                apps.fa_adjustments aj,
                apps.fa_distribution_history dh,
                apps.gl_code_combinations dhcc,
                apps.fa_asset_history ah,
                apps.fa_category_books cb,
                apps.fa_lookups falu,
                apps.fa_deprn_periods fdp,
                apps.fa_categories fac,
                apps.fa_lookups fl,
                apps.gl_code_combinations gcc,
                (SELECT asset_id, LISTAGG(invoice_number, '; ') WITHIN
                  GROUP(
                  ORDER 
                     BY invoice_number) invoice_number
                  FROM apps.fa_asset_invoices
                  GROUP 
                     BY asset_id) fai
          WHERE 1 = 1
            AND ret.asset_id = books.asset_id
            AND ad.asset_id = th.asset_id
            AND aj.asset_id = ret.asset_id
            AND aj.transaction_header_id = th.transaction_header_id
            AND ah.asset_id = ad.asset_id
            AND falu.lookup_code = ah.asset_type
            AND books.transaction_header_id_out = th.transaction_header_id
            AND books.asset_id = ad.asset_id
            AND cb.category_id = ah.category_id
            AND dh.distribution_id = aj.distribution_id
            AND th.asset_id = dh.asset_id
            AND dhcc.code_combination_id = dh.code_combination_id
            AND ad.asset_category_id = fac.category_id
            AND ad.asset_id = fai.asset_id
            AND ret.retirement_type_code = fl.lookup_code(+)
            AND gcc.code_combination_id = dh.code_combination_id
            AND decode(th.transaction_type_code,
                       'REINSTATEMENT',
                       ret.transaction_header_id_out,
                       ret.transaction_header_id_in) = th.transaction_header_id

            AND ah.date_effective <= th.date_effective
            AND nvl(ah.date_ineffective, th.date_effective + 1) > th.date_effective
            AND th.transaction_key = 'R'
            AND falu.lookup_type = 'ASSET TYPE'
            and aj.adjustment_type not in
                (select 'PROCEEDS'
                   from apps.fa_adjustments aj1
                  where aj1.book_type_code = aj.book_type_code
                    and aj1.asset_id = aj.asset_id
                    and aj1.transaction_header_id = aj.transaction_header_id
                    and aj1.adjustment_type = 'PROCEEDS CLR')
            AND th.date_effective >= fdp.period_open_date
            AND th.date_effective <= fdp.period_close_date
            AND th.book_type_code = ret.book_type_code
            AND th.book_type_code = aj.book_type_code
            AND th.book_type_code = books.book_type_code
            AND th.book_type_code = cb.book_type_code
            AND th.book_type_code = fdp.book_type_code
            AND fdp.period_counter >= (SELECT MIN(period_counter)
                                         FROM apps.fa_deprn_periods
                                        WHERE period_name IN (pc_start_period)
                                          AND book_type_code    = nvl(pc_book_type_code, books.book_type_code))
            AND fdp.period_counter <= (SELECT MAX(period_counter)
                                         FROM apps.fa_deprn_periods
                                        WHERE period_name IN (pc_end_period)
                                          AND book_type_code    = nvl(pc_book_type_code, books.book_type_code))
            AND ad.asset_category_id  = NVL(pc_category,ad.asset_category_id)
            AND books.book_type_code    = nvl(pc_book_type_code, books.book_type_code)
          GROUP 
             BY 'BAIXA',
                fdp.book_type_code,
                fdp.period_name,
                falu.meaning,
                th.transaction_type_code,
                decode(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct),
                ah.asset_type,
                cb.cip_cost_acct,
                cb.asset_cost_acct,
                th.asset_id,
                ret.date_retired,
                LEAST(TRUNC(MONTHS_BETWEEN(ret.date_retired, books.date_placed_in_service)),books.life_in_months),
                cb.asset_cost_acct,
                cb.cip_cost_acct,
                ad.asset_number,
                ad.serial_number,
                ad.description,
                books.date_placed_in_service,
                ad.asset_number,
                th.transaction_header_id,
                ah.asset_type,
                ret.gain_loss_amount,
                decode(th.transaction_type_code,
                       'REINSTATEMENT',
                       '*',
                       'PARTIAL RETIREMENT',
                       'P',
                       to_char(null)),
                th.transaction_type_code,
                fai.invoice_number,
                fac.description,
                fl.description,
                gcc.segment5
         UNION
         SELECT /*+ ordered */
                'BAIXA' tipo,
                fdp.book_type_code Empresa,
                fac.description Categoria,
                ad.asset_number Numero_de_Ativo,
                ad.serial_number Serial,
                fai.invoice_number nf,
                ad.description Historico,
                null Modelo, --voltar Farto 
                sum(decode(aj.adjustment_type, 'COST', 1, 'CIP COST', 1, 0) *
                    decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                    aj.adjustment_amount) Custo,
                null Quantidade, -- voltar Farto 
                decode(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct) gl_account,
                gcc.segment5 cost_center,
                books.date_placed_in_service Data_de_Entrada,
                ret.date_retired Data_de_Retirada,
                LEAST(TRUNC(MONTHS_BETWEEN(ret.date_retired, books.date_placed_in_service)),books.life_in_months) Meses_Depreciados,
                sum(decode(aj.adjustment_type, 'COST', 1, 'CIP COST', 1, 0) *
                    decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                    aj.adjustment_amount) -
                    sum(decode(aj.adjustment_type, 'NBV RETIRED', -1, 0) *
                        decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                        aj.adjustment_amount) Depreciacao_Acumulada,
                sum(decode(aj.adjustment_type, 'NBV RETIRED', -1, 0) *
                    decode(aj.debit_credit_flag, 'DR', -1, 'CR', 1, 0) *
                    aj.adjustment_amount) Valor_Residual,
                sum(decode(aj.adjustment_type, 'PROCEEDS CLR', 1, 'PROCEEDS', 1, 0) *
                    decode(aj.debit_credit_flag, 'DR', 1, 'CR', -1, 0) *
                    aj.adjustment_amount) Venda
           FROM apps.fa_transaction_headers th,
                apps.fa_additions ad,
                apps.fa_books books,
                apps.fa_retirements RET,
                (SELECT DH.*
                   FROM apps.FA_TRANSACTION_HEADERS  TH1,
                        apps.FA_DISTRIBUTION_HISTORY DH,
                        apps.FA_BOOK_CONTROLS        BC,
                        apps.FA_TRANSACTION_HEADERS  TH2
                  WHERE TH1.TRANSACTION_TYPE_CODE = 'FULL RETIREMENT'
                    AND TH1.ASSET_ID = DH.ASSET_ID
                    AND BC.BOOK_TYPE_CODE = th1.BOOK_TYPE_CODE
                    AND bC.DISTRIBUTION_SOURCE_BOOK = DH.BOOK_TYPE_CODE
                    AND TH1.DATE_EFFECTIVE <=
                        NVL(DH.DATE_INEFFECTIVE, TH1.DATE_EFFECTIVE)
                    AND TH1.ASSET_ID = TH2.ASSET_ID
                    AND th2.TRANSACTION_TYPE_CODE = 'REINSTATEMENT'
                    AND th2.date_effective >= dh.DATE_EFFECTIVE) dh,
                apps.gl_code_combinations dhcc,
                apps.fa_asset_history ah,
                apps.fa_category_books cb,
                apps.fa_lookups falu,
                apps.gl_code_combinations gcc,
                apps.fa_lookups fl,
                apps.fa_categories fac,
                (SELECT asset_id, LISTAGG(invoice_number, '; ') WITHIN
                 GROUP(
                 ORDER 
                    BY invoice_number) invoice_number
                  FROM apps.fa_asset_invoices
                 GROUP 
                    BY asset_id) fai,
                apps.fa_deprn_periods fdp,
                apps.fa_adjustments aj
          WHERE th.transaction_key = 'R'
            AND ret.asset_id = books.asset_id
            AND ret.transaction_header_id_out = th.transaction_header_id
            AND ad.asset_id = th.asset_id
            AND ah.asset_id = ad.asset_id
            AND ah.date_effective <= th.date_effective
            AND nvl(ah.date_ineffective, th.date_effective + 1) > th.date_effective
            AND falu.lookup_code = ah.asset_type
            AND falu.lookup_type = 'ASSET TYPE'
            AND books.transaction_header_id_out = th.transaction_header_id
            AND books.asset_id = ad.asset_id
            AND cb.category_id = ah.category_id
            AND th.asset_id = dh.asset_id
            AND DHCC.CODE_COMBINATION_ID = DH.CODE_COMBINATION_ID
            AND TH.TRANSACTION_TYPE_CODE = 'REINSTATEMENT'
            AND RET.COST_RETIRED = 0
            and ret.cost_of_removal = 0
            and ret.proceeds_of_sale = 0
            AND gcc.code_combination_id = dh.code_combination_id
            AND ret.retirement_type_code = fl.lookup_code(+)
            AND ad.asset_category_id = fac.category_id
            AND ad.asset_id = fai.asset_id
            AND th.date_effective >= fdp.period_open_date
            AND th.date_effective <= fdp.period_close_date
            AND th.book_type_code = fdp.book_type_code
            AND fdp.period_counter >=
           (SELECT MIN(period_counter)
              FROM apps.fa_deprn_periods
             WHERE period_name IN (pc_start_period)
               AND book_type_code = nvl(pc_book_type_code, books.book_type_code))
               AND fdp.period_counter <=
           (SELECT MAX(period_counter)
              FROM apps.fa_deprn_periods
             WHERE period_name IN (pc_end_period)
               AND book_type_code = nvl(pc_book_type_code, books.book_type_code))
            AND ad.asset_category_id  = NVL(pc_category,ad.asset_category_id)
            AND books.book_type_code    = nvl(pc_book_type_code, books.book_type_code)
            AND aj.asset_id = ret.asset_id
            AND aj.transaction_header_id = th.transaction_header_id
            AND dh.distribution_id = aj.distribution_id
            AND aj.adjustment_type not in (select 'PROCEEDS'
                                            from apps.fa_adjustments aj1
                                           where aj1.book_type_code = aj.book_type_code
                                             and aj1.asset_id = aj.asset_id
                                             and aj1.transaction_header_id = aj.transaction_header_id
                                             and aj1.adjustment_type = 'PROCEEDS CLR')
                                             and th.book_type_code = aj.book_type_code
          GROUP 
             BY 'BAIXA',
                fdp.book_type_code,
                fdp.period_name,
                falu.meaning,
                th.transaction_type_code,
                decode(ah.asset_type, 'CIP', cb.cip_cost_acct, cb.asset_cost_acct),
                ah.asset_type,
                cb.cip_cost_acct,
                cb.asset_cost_acct,
                th.asset_id,
                ret.date_retired,
                LEAST(TRUNC(MONTHS_BETWEEN(ret.date_retired, books.date_placed_in_service)),books.life_in_months),
                cb.asset_cost_acct,
                cb.cip_cost_acct,
                ad.asset_number,
                ad.serial_number,
                ad.description,
                books.date_placed_in_service,
                ad.asset_number,
                th.transaction_header_id,
                ah.asset_type,
                ret.gain_loss_amount,
                decode(th.transaction_type_code,
                       'REINSTATEMENT',
                       '*',
                       'PARTIAL RETIREMENT',
                       'P',
                       to_char(null)),
                th.transaction_type_code,
                fai.invoice_number,
                fac.description,
                fl.description,
                gcc.segment5;
  --
  TYPE t_adbx IS TABLE OF c_adbx%ROWTYPE;
  r_adbx   t_adbx;
  --
  v_file_name   VARCHAR2(240);
  l_qtde        NUMBER;
  l_vlr         NUMBER;
  l_lin         NUMBER;
  l_count       NUMBER := 2;
  l_nRequest_Id NUMBER;
  l_categoria   fa_categories.description%type;
  l_user        fnd_user.user_name%type;
  --
  BEGIN
     --busca nome da categoria do parametro quando informado
     BEGIN
      SELECT description
        into l_categoria
        FROM fa_categories
       WHERE category_id = p_category;
      EXCEPTION
       WHEN OTHERS THEN
        l_categoria := null;
     END;
     --busca usuario de execucao do relatorio
     BEGIN
      SELECT user_name
        into l_user
        FROM fnd_user
       WHERE user_id = FND_GLOBAL.USER_ID;
      EXCEPTION
       WHEN OTHERS THEN
        l_user := null;
     END;
     --------------------------------------------------------------------------
     --> Printing Parameters
     --------------------------------------------------------------------------
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                    ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'STONE PAGAMENTOS S/A                                                '||to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'           Stone - Relatorio Adi��es e Baixas do FA             ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                    ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Paramters..:');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_start_period....: '||p_start_period);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_end_period......: '||p_end_period);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_category........: '||l_categoria);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'p_book_type_code..: '||p_book_type_code);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                                    ');
     --
     dbms_output.put_line('Open adi��es e baixas '||v_file_name);
     OPEN c_adbx (p_start_period
                 ,p_end_period
                 ,p_book_type_code
                 ,p_category);
     FETCH c_adbx BULK COLLECT INTO r_adbx;
     CLOSE c_adbx;
     --
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_start, 0);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_start, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(to_char(SYSDATE, 'DD-Mon-YYYY'), 'CURRENT_DATE'   , gn_xml_tag_full, 2);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_DATA', gn_xml_tag_end, 1);
     xxstn_gl_razao_report_pkg.print_xml_tag(NULL, 'REP_LIST', gn_xml_tag_end, 0);
     --
     as_xlsx.clear_workbook;
     --
     --
     IF r_adbx.count > 0 THEN
       --
       as_xlsx.new_sheet('Adicoes e Baixas');
       as_xlsx.set_row(   1, p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize =>11, p_bold =>true ));
       as_xlsx.cell(  3,  1, 'Relatorio de Adi��es e Baixas', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 14, p_bold =>true) );
       as_xlsx.cell(  1,  2, 'Empresa', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  2,  2, 'Categoria', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  3,  2, 'Numero de Ativo', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  4,  2, 'Serial', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  5,  2, 'Nota Fiscal', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  6,  2, 'Historico', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  7,  2, 'Modelo', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  8,  2, 'Valor do Custo', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  9,  2, 'Quantidade', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  10, 2, 'Conta de Ativo', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  11, 2, 'Centro de Custos', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  12, 2, 'Data de Entrada', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  13, 2, 'Data de Retirada', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  14, 2, 'Meses Depreciados', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  15, 2, 'Depreciacao Acumulada', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  16, 2, 'Valor Residual', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  17, 2, 'Venda', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       as_xlsx.cell(  18, 2, 'Tipo Transacao', p_fontId => as_xlsx.get_font( 'Calibri', p_fontsize  => 11, p_bold =>true));
       --
       FOR i IN r_adbx.first..r_adbx.last LOOP
         --
         dbms_output.put_line('Adi��es e Baixas '||v_file_name);
         as_xlsx.cell(  1, l_count+1, r_adbx(i).Empresa);
         as_xlsx.cell(  2, l_count+1, r_adbx(i).Categoria);
         as_xlsx.cell(  3, l_count+1, r_adbx(i).Numero_de_Ativo);
         as_xlsx.cell(  4, l_count+1, nvl(r_adbx(i).Serial,' '));
         as_xlsx.cell(  5, l_count+1, nvl(r_adbx(i).nf,' '));
         as_xlsx.cell(  6, l_count+1, r_adbx(i).Historico);
         as_xlsx.cell(  7, l_count+1, nvl(r_adbx(i).Modelo,' '));
         as_xlsx.cell(  8, l_count+1, r_adbx(i).Custo);
         as_xlsx.cell(  9, l_count+1, r_adbx(i).Quantidade);
         as_xlsx.cell( 10, l_count+1, r_adbx(i).gl_account);
         as_xlsx.cell( 11, l_count+1, r_adbx(i).cost_center);
         as_xlsx.cell( 12, l_count+1, r_adbx(i).Data_de_Entrada);
         as_xlsx.cell( 13, l_count+1, r_adbx(i).Data_de_Retirada);
         as_xlsx.cell( 14, l_count+1, r_adbx(i).Meses_Depreciados);
         as_xlsx.cell( 15, l_count+1, r_adbx(i).Depreciacao_Acumulada);
         as_xlsx.cell( 16, l_count+1, r_adbx(i).Valor_Residual);
         as_xlsx.cell( 17, l_count+1, r_adbx(i).Venda);
         as_xlsx.cell( 18, l_count+1, r_adbx(i).tipo);
         --
         l_count := l_count + 1;
         --
       END LOOP;
       --
       as_xlsx.freeze_rows( 2 );
       --
     END IF;
     --
     dbms_output.put_line('Parameters '||v_file_name);
     as_xlsx.new_sheet('Parameters');
     as_xlsx.set_row( 1, p_fillId => as_xlsx.get_fill( 'solid', 'AAE9F2' ) ) ;
     as_xlsx.cell(1 , 1 ,'Parametros');
     as_xlsx.cell(1 , 2 ,'Livro do FA');
     as_xlsx.cell(1 , 3 ,'Categoria') ;
     as_xlsx.cell(1 , 4 ,'Perido Inicial');
     as_xlsx.cell(1 , 5 ,'Periodo Final');
     --
     as_xlsx.cell(2 , 2 ,nvl(p_book_type_code,' '));
     as_xlsx.cell(2 , 3 ,nvl(to_char(l_categoria),' '));
     as_xlsx.cell(2 , 4 ,nvl(p_start_period,' '));
     as_xlsx.cell(2 , 5 ,nvl(p_end_period,' '));

     as_xlsx.cell(5 , 7 ,'Relatorio extraido em '||to_char(CAST((FROM_TZ(CAST(sysdate AS TIMESTAMP),'+00:00') AT TIME ZONE 'Brazil/East') AS DATE),'DD-MON-YYYY HH24:MI:SS') ||' por '||l_user
                         , p_fontId => as_xlsx.get_font( 'Calibri', p_rgb => 'FFFF0000' ) );
     --
     v_file_name := 'o'||NVL(TO_CHAR(FND_GLOBAL.CONC_REQUEST_ID),'TesteAdBxFA')||'.xlsx';
     dbms_output.put_line('Arquivo gerado '||v_file_name);
     as_xlsx.save( 'XXSTN_HR_OUT', v_file_name );
     --
     dbms_output.put_line('Arquivo gravado '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'       ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Arquivo Gerado.....: '||v_file_name);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Registros Gerados..: '||to_char(l_count-3));
     --
     l_nRequest_Id := FND_REQUEST.submit_request( application => 'SQLGL'
                                                , program     => 'XXSTN_GL_UPDATE_OUTPUT'
                                                , start_time  => TO_CHAR( SYSDATE, 'DD-MON-YYYY' )
                                                , argument1   => v_file_name
                                                , argument2   => FND_GLOBAL.CONC_REQUEST_ID );
  EXCEPTION
    --
    WHEN OTHERS THEN
      --------------------------------------------------------------------
      --> Set Errors variables
      --------------------------------------------------------------------
      p_errbuf  := SUBSTR(SQLERRM, 1, 500);
      p_retcode := 2;
      --------------------------------------------------------------------
      --> Print Error Messages
      --------------------------------------------------------------------
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** Unexpected error please contact your system administrator');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_errbuf =  ' || SUBSTR(SQLERRM, 1, 500));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'** UNHANDLED EXCEPTION/p_retcode =  '|| SQLCODE);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*****************************************************************************');
      --
  END generate_report_p;
  --
END XXSTN_FA_RELAT_AD_BX_PKG;
/

EXIT; 