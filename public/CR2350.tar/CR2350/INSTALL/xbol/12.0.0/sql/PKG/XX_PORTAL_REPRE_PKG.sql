  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PORTAL_REPRE_PKG" IS
--
-- $Header: %f% %v% %d% %u% ship $
-- $Id: XX_PORTAL_REPRE_PKG.txt 12.2.6 2018-04-05 12:00:00 rsnunes $
-- +=================================================================+
-- |       Copyright (c) 2018 Adecoagro , Sao Paulo , Brasil         |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   XX_PORTAL_REPRES_PKG.txt                                      |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Oracle Applications Rel 12.2.6                                |
-- |   Produto.: Oracle                                              |
-- |   Objetivo: Procedure INSERE dados do Portal de Representantes  |
-- |             para o Oracle.                                      |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |                                                                 |
-- | CREATED BY                                                      |
-- |   Adecoagro - Douglas Sousa: 09/10/2013                         |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |   26/06/2015   DSOUSA          CRIACAO DE NOVOS ITENS           |
-- |                                                                 |
-- |   Jun/2017     Rafael S. Nunes (Ninecon) - Chamado: 75171       |
-- |     Tratamento para insercao de 1 ou mais itens por Pedido e    |
-- |     Cliente (Raiz do CNPJ e Filial).                            |
-- |                                                                 |
-- |   14/08/2017   Rafael S. Nunes (Ninecon) - Chamado: 75259       |
-- |     Unidade de medida do item sera enviada do Portal.           |
-- |                                                                 |
-- |   05/04/2018   Rafael S. Nunes (Ninecon) - Projeto CRECER R12   |
-- |     Convertida a antiga procedure XX_PORTAL_REPRE_PKG nesta     |
-- |     package para padronizacao do Oracle EBS, a adequacao e      |
-- |     necessaria pois o patch nao estava criando o objeto como    |
-- |     "Procedure", a antiga procedure como objeto unico sera      |
-- |     descontinuada.                                              |
-- |                                                                 |
-- |   24/05/2018  Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018      |
-- |     Ajustes diversos R12.                                       |
-- |                                                                 |
-- |   Rafael S. Nunes (Ninecon) -- 07/08/2018 -- Chamado 90987      |
-- |     Vendas de Arroz para ACO no Portal de Representantes.       |
-- |                                                                 |
-- |   Rafael S. Nunes (Ninecon) -- SD 105749 -- Fev/2020            |
-- |     Alterado o valor inicial do flag STATUS na tabela           |
-- |     XX_OM_IMPORT_OV_HEADER de N (novo) para R (reservado),      |
-- |     o flag sera modificado para N na procedure XX_ENVIA_ORACLE  |
-- |     no Apex, que faz a chamada desta package.                   |
-- |                                                                 |
-- |     Essa alteracao foi necessaria para evitar que os registros  |
-- |     comecem a ser processados pelo concurrent                   |     
-- |     XX OM CRIA OV PORTAL DE REPRESENTANTES antes de terem sidos | 
-- |     todos enviados dentro de um mesmo pedido, evitando que o    |
-- |     HEADER comece a ser processado antes que todas as LINES     |
-- |     tenham sido enviadas.                                       |
-- |                                                                 |
-- +=================================================================+
--
  PROCEDURE xx_prc_portal_repre (P_NUM_CLI            IN VARCHAR2,
                                 P_RAIZ               IN VARCHAR2,
                                 --P_NUM_PEDIDO         IN VARCHAR2,
                                 P_ID_CARGA           IN VARCHAR2, -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                 P_ITEM               IN VARCHAR2,
                                 P_QTDE               IN NUMBER,
                                 P_UDM                IN VARCHAR2, -- Rafael S. Nunes (Ninecon) -- 75259 -- Ago/2017
                                 P_REPRESENTANTE      IN VARCHAR2,
                                 P_PRECO_FOB          IN NUMBER,
                                 P_FRETE              IN NUMBER,
                                 P_PRAZO              IN VARCHAR2,
                                 P_ID_PAI             IN NUMBER,  -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                 P_SALESREP_ID        IN NUMBER,  -- Rafael S. Nunes (Ninecon) -- 976 -- Jun/2018
                                 P_ORG_ID             IN NUMBER,  -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
                                 P_PRICE_LIST_ID      IN NUMBER); -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
END xx_portal_repre_pkg;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PORTAL_REPRE_PKG" IS
--
-- $Header: %f% %v% %d% %u% ship $
-- $Id: XX_PORTAL_REPRE_PKG.txt 12.2.6 2018-04-05 12:00:00 rsnunes $
-- +=================================================================+
-- |       Copyright (c) 2018 Adecoagro , Sao Paulo , Brasil         |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   XX_PORTAL_REPREB_PKG.txt                                      |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Oracle Applications Rel 12.2.6                                |
-- |   Produto.: Oracle                                              |
-- |   Objetivo: Procedure INSERE dados do Portal de Representantes  |
-- |             para o Oracle.                                      |
-- |                                                                 |
-- | DESCRIPTION                                                     |
-- |                                                                 |
-- | CREATED BY                                                      |
-- |   Adecoagro - Douglas Sousa: 09/10/2013                         |
-- |                                                                 |
-- | UPDATED BY                                                      |
-- |   26/06/2015   DSOUSA          CRIACAO DE NOVOS ITENS           |
-- |                                                                 |
-- |   Jun/2017     Rafael S. Nunes (Ninecon) - Chamado: 75171       |
-- |     Tratamento para insercao de 1 ou mais itens por Pedido e    |
-- |     Cliente (Raiz do CNPJ e Filial).                            |
-- |                                                                 |
-- |   14/08/2017   Rafael S. Nunes (Ninecon) - Chamado: 75259       |
-- |     Unidade de medida do item sera enviada do Portal.           |
-- |                                                                 |
-- |   05/04/2018   Rafael S. Nunes (Ninecon) - Projeto CRECER R12   |
-- |     Convertida a antiga procedure XX_PORTAL_REPRE_PKG nesta     |
-- |     package para padronizacao do Oracle EBS, a adequacao e      |
-- |     necessaria pois o patch nao estava criando o objeto como    |
-- |     "Procedure", a antiga procedure como objeto unico sera      |
-- |     descontinuada.                                              |
-- |                                                                 |
-- |   24/05/2018  Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018      |
-- |     Ajustes diversos R12.                                       |
-- |                                                                 |
-- |   Rafael S. Nunes (Ninecon) -- 07/08/2018 -- Chamado 90987      |
-- |     Vendas de Arroz para ACO no Portal de Representantes.       |
-- |                                                                 |
-- |   Rafael S. Nunes (Ninecon) -- SD 105749 -- Fev/2020            |
-- |     Alterado o valor inicial do flag STATUS na tabela           |
-- |     XX_OM_IMPORT_OV_HEADER de N (novo) para R (reservado),      |
-- |     o flag sera modificado para N na procedure XX_ENVIA_ORACLE  |
-- |     no Apex, que faz a chamada desta package.                   |
-- |                                                                 |
-- |     Essa alteracao foi necessaria para evitar que os registros  |
-- |     comecem a ser processados pelo concurrent                   |     
-- |     XX OM CRIA OV PORTAL DE REPRESENTANTES antes de terem sidos | 
-- |     todos enviados dentro de um mesmo pedido, evitando que o    |
-- |     HEADER comece a ser processado antes que todas as LINES     |
-- |     tenham sido enviadas.                                       |
-- |                                                                 |
-- +=================================================================+
--
  PROCEDURE xx_prc_portal_repre (P_NUM_CLI            IN VARCHAR2,
                                 P_RAIZ               IN VARCHAR2,
                                 --P_NUM_PEDIDO         IN VARCHAR2,
                                 P_ID_CARGA           IN VARCHAR2, -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                 P_ITEM               IN VARCHAR2,
                                 P_QTDE               IN NUMBER,
                                 P_UDM                IN VARCHAR2, -- Rafael S. Nunes (Ninecon) -- 75259 -- Ago/2017
                                 P_REPRESENTANTE      IN VARCHAR2,
                                 P_PRECO_FOB          IN NUMBER,
                                 P_FRETE              IN NUMBER,
                                 P_PRAZO              IN VARCHAR2,
                                 P_ID_PAI             IN NUMBER,    -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                 P_SALESREP_ID        IN NUMBER,    -- Rafael S. Nunes (Ninecon) -- 976 -- Jun/2018
                                 P_ORG_ID             IN NUMBER,    -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
                                 P_PRICE_LIST_ID      IN NUMBER) AS -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
    --
    l_nCod_carreg        apps.xx_om_import_ov_header.cod_carreg%TYPE;
    l_nInventory_Item_id apps.xx_om_import_ov_lines.inventory_item_id%TYPE;
    l_nShip_From_Org_id  apps.xx_om_import_ov_lines.ship_from_org_id%TYPE;
    l_vLog               VARCHAR2(5000);
    l_nHeader_id         NUMBER;
    l_nCtHdr             NUMBER := 0; -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
  BEGIN
    -- ---------------------------------------------- --
    -- Rafael S. Nunes (Ninecon) -- 75259 -- Ago/2017 --
    -- ---------------------------------------------- --
    BEGIN
      SELECT msib.inventory_item_id
        INTO l_nInventory_Item_id
        FROM apps.mtl_system_items_b msib
       WHERE msib.segment1        = P_ITEM
         AND msib.organization_id = 135;
    EXCEPTION
      WHEN no_data_found THEN
        l_nInventory_Item_id := 0;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20005, 'Erro ao consultar o ID do item ' || P_ITEM || ' na tabela APPS.MTL_SYSTEM_ITEMS_B - ' || SQLERRM);
    END;

    --> DOUGLAS SOUSA - 23/03/2018 - INICIO.....
    BEGIN
    --> PEGA ORGANIZATION_ID
          select ood.organization_id
           INTO l_nShip_From_Org_id
            from apps.org_organization_definitions ood
          --where organization_code = 'UMA';
          where ood.organization_code = DECODE(P_ORG_ID,110,'UMA',1446,'ACO'); -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
    EXCEPTION
      WHEN OTHERS THEN
       ---  l_nShip_From_Org_id  := 1751;
        RAISE_APPLICATION_ERROR(-20010, 'Erro ao consultar ORGANIZATION_ID - ' || SQLERRM);
    END;
    -- --------------------------------------------------------------------------- --
    -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017                              --
    -- Verificar se o Header do Pedido ja foi inserido anteriormente, se ja tiver  --
    -- sido inserido anteriormente, nao devera inserir o Header novamente, somente --
    -- as Linhas.                                                                  --
    -- --------------------------------------------------------------------------- --
    BEGIN
      SELECT COUNT(1)
        INTO l_nCtHdr
        FROM bolinf.xx_om_import_ov_header h
       WHERE h.num_pedido      = P_ID_PAI
         AND h.customer_number = P_NUM_CLI -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
         AND h.raiz_cnpj       = P_RAIZ    -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
         AND h.org_id          = P_ORG_ID; -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20010, 'Erro ao consultar dados na tabela APPS.XX_OM_IMPORT_OV_HEADER - ' || SQLERRM);
    END;
    -- ---------------------------------------------------------------------------- --
    -- HEADER                                                                       --
    -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017                               --
    -- Insere a linha HEADER somente uma vez para cada Pedido, CNPJ (Raiz e Filial) --
    -- de cada Cliente. Se a combinacao Pedido/Cliente ainda nao foi inserida no    --
    -- cabecalho, entao insere.                                                     --
    -- ---------------------------------------------------------------------------- --
    IF l_nCtHdr < 1 THEN
      BEGIN
        INSERT
          INTO bolinf.xx_om_import_ov_header ( price_list_id        -- 1 Lista de Precos
                                              ,shipping_method_code -- 2 Metodo de Entrega
                                              ,sold_from_org_id     -- 3 Organizacao
                                              ,salesrep_id          -- 4 Vendedor/Representante
                                              ,order_type_id        -- 5 Tipo da Ordem
                                              ,created_by           -- 6
                                              ,creation_date        -- 7
                                              ,last_updated_by      -- 8
                                              ,last_update_date     -- 9
                                              ,last_update_login    -- 10
                                              ,cod_carreg           -- 11
                                              ,org_id               -- 12
                                              ,oe_header_id_ebs     -- 13
                                              ,status               -- 14
                                              ,log                  -- 15
                                              ,order_number         -- 16
                                              ,customer_number      -- 17
                                              ,invoice_to_org_id    -- 18
                                              ,num_pedido           -- 19 -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                              ,raiz_cnpj)           -- 20 -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
                                      --VALUES ( 10014                -- 1 (Tabela de Lista de Precos (UMA))
                                      VALUES ( P_PRICE_LIST_ID      -- 1 -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
                                              ,NULL                 -- 2
                                              --,110                  -- 3 (BR UMA UO)
                                              ,P_ORG_ID             -- 3 -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
                                              --,v_id_represent       -- 4
                                              ,P_SALESREP_ID        -- 4 -- Rafael S. Nunes (Ninecon) -- 976 -- Jun/2018
                                              ,null                 -- 5
                                              ,-1                   -- 6
                                              ,SYSDATE              -- 7
                                              ,-1                   -- 8
                                              ,SYSDATE              -- 9
                                              ,NULL                 -- 10
                                              ,P_ID_CARGA           -- 11
                                              --,110                  -- 12
                                              ,P_ORG_ID             -- 12 -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
                                              ,NULL                 -- 13
                                              --,'N'                  -- 14 (Novo)
                                              ,'R'                  -- 14 (Reservado) -- Rafael S. Nunes (Ninecon) -- SD 105749 -- Fev/2020
                                              ,NULL                 -- 15
                                              ,NULL                 -- 16
                                              ,P_NUM_CLI            -- 17 --> colocar o codigo do cliente
                                              ,NULL                 -- 18
                                              ,P_ID_PAI             -- 19 -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                              ,P_RAIZ);             -- 20 -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
        commit work;
      EXCEPTION
        WHEN OTHERS THEN
          dbms_output.put_line('Erro ao insetir registro na tabela XX_OM_IMPORT_OV_HEADER - ' || SQLERRM);
      END;
    END IF; -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
    --
    BEGIN
      INSERT
        INTO bolinf.xx_om_import_ov_lines ( id_pai               -- 1
                                           ,inventory_item_id    -- 2 Id do Item
                                           ,ordered_quantity     -- 3 Quantidade
                                           ,ship_from_org_id     -- 4
                                           --,line_type_id         -- 5 Tipo da Linha -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018 -- comentado, nao sera mais necessario. A API criara como tipo padrÃÂ£o.
                                           ,created_by           -- 6
                                           ,creation_date        -- 7
                                           ,LAST_UPDATED_BY      -- 8
                                           ,LAST_UPDATE_DATE     -- 9
                                           ,LAST_UPDATE_LOGIN    -- 10
                                           ,PRECO_FOB            -- 11
                                           ,FRETE                -- 12
                                           ,prazo                -- 13
                                           ,num_pedido           -- 14 -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                           ,order_quantity_uom   -- 15 -- Rafael S. Nunes (Ninecon) -- 75259 -- Ago/2017
                                           ,customer_number      -- 16 -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
                                           ,raiz_cnpj            -- 17 -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
                                           ,org_id)              -- 18 -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
                                   VALUES ( P_ID_CARGA           -- 1
                                           ,l_nInventory_Item_id -- 2
                                           ,P_QTDE               -- 3
                                           ,l_nShip_From_Org_id  -- 4 (2U8) informar id do deposito, ex: 520 => 2U8
                                           --,1751                 -- 5 (PADRAO) -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018 -- comentado, nao sera mais necessario. A API criara como tipo padrÃÂ£o.
                                           ,-1                   -- 6
                                           ,SYSDATE              -- 7
                                           ,NULL                 -- 8
                                           ,NULL                 -- 9
                                           ,NULL                 -- 10
                                           ,P_PRECO_FOB          -- 11
                                           ,P_FRETE              -- 12
                                           ,P_PRAZO              -- 13
                                           ,p_id_pai             -- 14 -- Rafael S. Nunes (Ninecon) -- 75171 -- Jun/2017
                                           ,P_UDM                -- 15 -- Rafael S. Nunes (Ninecon) -- 75259 -- Ago/2017
                                           ,P_NUM_CLI            -- 16 -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
                                           ,P_RAIZ               -- 17 -- Rafael S. Nunes (Ninecon) -- 976 -- Mai/2018
                                           ,P_ORG_ID);           -- 16 -- Rafael S. Nunes (Ninecon) -- 91505 -- Ago/2018
      commit work;
    EXCEPTION
      WHEN OTHERS THEN
        dbms_output.put_line('Erro ao insetir registro na tabela XX_OM_IMPORT_OV_HEADER - ' || SQLERRM);
    END;
  END xx_prc_portal_repre;
END xx_portal_repre_pkg;
/

exit
