#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2485_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2485
# |
# | HISTORY
# |   14-MAY-20  Silva, Alejandra - IT Arg
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2485_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2485_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2485
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/PROF
mkdir -p xbol/12.0.0/FNDLOAD/RESPO
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT



echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-RESPO XX_AR_FA_SUPERVISOR_ENT_ARG " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscursp.lct $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_ARG.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-RESPO XX_AR_FA_SUPERVISOR_ENT_URU " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscursp.lct $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/RESPO/XX_AR_FA_SUPERVISOR_ENT_URU.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_PRINT_DEBUG_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_PRINT_DEBUG_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_HR_USER_TYPE_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_HR_USER_TYPE_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF AR_DEFAULT_COUNTRY_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/AR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_PRINT_DEBUG_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_PRINT_DEBUG_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR


echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_GL_ACCESS_SET_ID_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_PER_BUSINESS_GROUP_ID_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_HR_USER_TYPE_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_HR_USER_TYPE_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_APPL_SHORT_NAME_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_PRODUCT_CODE_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUPERV " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JGZZ_COUNTRY_CODE_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_JL_ZZ_RUN_INFL_ADJ_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_XLA_MO_SECURITY_PROFILE_L_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PROF UR_DEFAULT_COUNTRY_XX_AR_FA_SUP " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afscprof.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PROF/UR_DEFAULT_COUNTRY_XX_AR_FA_SUP.ldt -m $CRNUM >> $CROUT 2>> $CRERR


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2485" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2485_13917.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2485_13917.ldt"

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
