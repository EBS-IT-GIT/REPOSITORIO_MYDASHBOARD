create or replace package body                          XXSTN_BUYER_CUSTOM_PKG is
-- $Header: XXSTN_BUYER_CUSTOM_PKB.sql 120.0 2020/03/27 12:00:00 ninecon ship $
-- +=================================================================+
-- |       Copyright (c) 2019 Stone                                  |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_BUYER_CUSTOM_PKG                                          |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Package criada para validar direcionar requisiçoes de compra  |
-- |    com valor menor igual R$ 1.00,00 para comprador que está     |
-- |    cadastrado na lookup XXSTN_BUYER_CUSTOM.
-- |   Regras                                                        |
-- |   Se a requisição for de valor menor igual a R$ 1.000,00        |
-- |   verificar se há comprador cadastrado e ativo na lookup        |
-- |   XXSTN_BUYER_CUSTOM, se tiver, setar esse comprador, se não, o |
-- |   o fluxo core deverá ser seguido.                              |
-- |                                                                 |
-- | CREATED BY                                                      |
-- |   cbergamaschi             14/12/2019                           |
-- +=================================================================+
--
procedure xxstn_checa_valor_req (p_requisition_header_id in number,
                                 p_category_id           in number,
                                 p_item_id               in number,
                                 p_deliver_to_org_id     in number,
                                 x_suggested_buyer_id    out number ) is
--
   cursor req (p_requisition_header_id in number) is
      select sum(prla.quantity * prla.unit_price) category_amount,
             prla.category_id
      from po_requisition_lines_all prla
      where 1 = 1
        and prla.requisition_header_id = p_requisition_header_id
        and nvl(prla.cancel_flag, 'N') = 'N'
      group by prla.category_id;
---
l_valor_req          number := 0;
l_suggested_buyer_id number := 0;
l_amount             number := 0;
l_valor              number := 0;
l_category_amount    number := 0;

begin
   --
   --Verificar valor requisição
   --se valor total da requiscao for menor igual ao valor da lookup, direcionar para comprador lookup
   begin
      select sum(prla.quantity * prla.unit_price)
      into l_valor_req
      from po_requisition_lines_all prla
      where 1 = 1
        and prla.requisition_header_id = p_requisition_header_id
        and nvl(prla.cancel_flag, 'N') = 'N';
   end;
   --
   --
   --recupera comprador e valor
   begin
      select flv.attribute14 valor,
             flv.attribute15 agent_id
      into l_valor,
           l_suggested_buyer_id
      from apps.fnd_lookup_values_vl flv,
           apps.fnd_lookup_types_vl flt
      where 1 = 1
        and flt.lookup_type = 'XXSTN_BUYER_CUSTOM'
        and flt.meaning = 'XXSTN_BUYER_CUSTOM'
        and flt.lookup_type = flv.lookup_type
        and flv.enabled_flag = 'Y'
        and nvl(flv.end_date_active,trunc(sysdate)) >= trunc(sysdate)
      ;
   exception
      when others then
          null;
   end;
   --
   if l_valor_req <= l_valor then
      --
      x_suggested_buyer_id := l_suggested_buyer_id;
      --
   else
      --
      --somar linhas da requis'cao agrupando por categoria
      --
      for x in req (p_requisition_header_id) loop
         --
         l_suggested_buyer_id := null;
         --
         begin
            select agent_id,
                   amount
            into l_suggested_buyer_id,
                 l_category_amount
            from apps.xxstn_buyer_categ_v
            where 1 = 1
              and category_id = x.category_id
              and nvl(end_date_active,trunc(sysdate)) >= trunc(sysdate)
              ;
         exception
            when others then
              raise_application_error(-20001,'Erro ap pesquisar comprador xxstn_buyer_categ_v '||' - '|| x.category_id||' - '||sqlerrm);
         end;
         --
         --if x.category_amount >= l_category_amount then
         if x.category_amount >= l_category_amount and x.category_id = p_category_id then
            --
            x_suggested_buyer_id := l_suggested_buyer_id;
            --
         --end if;

         elsif x.category_amount < l_category_amount and x.category_id = p_category_id then
            --
            begin
              select flv.attribute15 agent_id
              into l_suggested_buyer_id
              from apps.fnd_lookup_values_vl flv,
                   apps.fnd_lookup_types_vl flt
              where 1 = 1
                and flt.lookup_type = 'XXSTN_BUYER_CUSTOM'
                and flt.meaning = 'XXSTN_BUYER_CUSTOM'
                and flt.lookup_type = flv.lookup_type
                and flv.enabled_flag = 'Y'
                and nvl(flv.end_date_active,trunc(sysdate)) >= trunc(sysdate)
              ;
            exception
              when others then
                  --caso não haja categoria/comprador na tela, recuperar comprador do item
                  begin
                     select msib.buyer_id
                     into l_suggested_buyer_id
                     from apps.mtl_system_items_b msib
                     where 1 = 1
                      and msib.inventory_item_id = p_item_id
                      and msib.organization_id   = p_deliver_to_org_id;
                  exception
                      when others then
                       null;
                 end;
                 --
                 x_suggested_buyer_id := l_suggested_buyer_id;
                 --
            end;
            --
            x_suggested_buyer_id := l_suggested_buyer_id;
            --
         end if;

         --
      end loop;
      --
   end if;
   /*
   --verificar se categoria da requisição existe na tela custom
   begin
      select agent_id,
             amount
      into l_suggested_buyer_id,
           l_amount
      from apps.xxstn_buyer_categ_v
      where 1 = 1
        and category_id = p_category_id;
   exception
      when no_data_found then
         --caso não haja comprador na tela, recuperar comprador do item
         begin
            select msib.buyer_id
            into l_suggested_buyer_id
            from apps.mtl_system_items_b msib
            where 1 = 1
             and msib.inventory_item_id = p_item_id
             and msib.organization_id   = p_deliver_to_org_id;
         exception
            when others then
               null;
         end;
         --
   end;
   --
   if l_valor_req <= l_amount then
      --
      x_suggested_buyer_id := l_suggested_buyer_id;
      --
   end if;
   --
   */
end xxstn_checa_valor_req;
--
end XXSTN_BUYER_CUSTOM_PKG;
/