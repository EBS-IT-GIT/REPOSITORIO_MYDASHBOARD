WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
--
-- $Header: XXSTN_SQL_ADD.sql 120.0 2020-02-22 15:00:00  ninecon noship  $
-- +=================================================================+
-- |                 Ninecon, Sao Paulo, Brasil                      |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- |   XXSTN_SQL_ADD.sql                                             |
-- | PURPOSE                                                         |
-- |   Table                                                         |
-- | DESCRIPTION                                                     |
-- |   Table                                                         |
-- |                                                                 |
-- |                                                                 |
-- | CREATED BY   <Nome do Desenvolvedor> / data                     |
-- | UPDATED BY   <Nome do Desenvolvedor> / data                     |
-- |                                                                 |
-- +=================================================================+
--
WHENEVER SQLERROR CONTINUE

create table apps.xxstn_buyer_categ(id number,  
                               user_id number,
                               creation_date date,
                               created_by number,
                               last_update_date date,
                               last_updated_by number,
                               last_updated_login number,
                               category_id number,
                               agent_id number,
                               amount number,
                               end_date_active date,
                               attribute1 varchar2(250),
                               attribute2 varchar2(250),
                               attribute3 varchar2(250),
                               attribute4 varchar2(250),
                               attribute5 varchar2(250),
                               attribute6 varchar2(250),
                               attribute7 varchar2(250),
                               attribute8 varchar2(250),
                               attribute9 varchar2(250),
                               attribute10 varchar2(250)
                               );
create unique index xxstn_id_idx on apps.xxstn_buyer_categ (id);

create sequence xxstn_id_sq start with 1 increment by 1 nocache nocycle;
 
create index xxstn_category_id_idx on apps.xxstn_buyer_categ (category_id);

create index xxstn_agent_id_idx on apps.xxstn_buyer_categ (agent_id);

CREATE OR REPLACE FORCE EDITIONABLE VIEW "APPS"."XXSTN_BUYER_CATEG_V" ("ID", "USER_ID", "CREATION_DATE", "CREATED_BY", "LAST_UPDATE_DATE", "LAST_UPDATED_BY", "CATEGORY_ID", "AGENT_ID", "AMOUNT", "CATEGORY_CONCAT_SEGS", "BUYER", "END_DATE_ACTIVE") AS 
  select bc.id,
       bc.user_id,
       bc.creation_date,
       bc.created_by,
       bc.last_update_date,
       bc.last_updated_by,
       bc.category_id,
       bc.agent_id,
       bc.amount,
       mc.segment1 category_concat_segs,
       (select full_name
        from apps.per_all_people_f
        where 1 = 1
          and person_id = bc.agent_id
          and nvl(effective_end_date,trunc(sysdate)) >= trunc(sysdate)
          and rownum = 1 --possíveis dados duplicados HR
          ) buyer ,
	   bc.end_date_active
from  
      apps.mtl_categories mc,
      apps.xxstn_buyer_categ bc
where 1 = 1
  --and mc.structure_name = 'PO Item Category'
  and mc.structure_id = 201
  and mc.category_id = bc.category_id
  and nvl(mc.end_date_active,trunc(sysdate)) >= trunc(sysdate);                               
/
EXIT;

