create or replace package                      XXSTN_BUYER_CUSTOM_PKG is
-- $Header: %M% %I% %E% %U% appldev ship $
-- +=================================================================+
-- |       Copyright (c) 2019 Stone                                  |
-- |                       All rights reserved.                      |
-- +=================================================================+
-- | FILENAME                                                        |
-- | XXSTN_BUYER_CUSTOM_PKG                                          |
-- |                                                                 |
-- | PURPOSE                                                         |
-- |   Package criada para validar direcionar requisiçoes de compra  |
-- |    com valor menor igual R$ 1.00,00 para comprador que está     |
-- |    cadastrado na lookup XXSTN_BUYER_CUSTOM.
-- |   Regras                                                        |
-- |   Se a requisição for de valor menor igual a R$ 1.000,00        |
-- |   verificar se há comprador cadastrado e ativo na lookup        |
-- |   XXSTN_BUYER_CUSTOM, se tiver, setar esse comprador, se não, o |
-- |   o fluxo core deverá ser seguido.                              |
-- |                                                                 |
-- | CREATED BY                                                      |
-- |   cbergamaschi             14/12/2019                           |
-- +=================================================================+
--
procedure xxstn_checa_valor_req (p_requisition_header_id in number,
                                 p_category_id           in number,
                                 p_item_id               in number,
                                 p_deliver_to_org_id     in number,
                                 x_suggested_buyer_id    out number);

end XXSTN_BUYER_CUSTOM_PKG;
/