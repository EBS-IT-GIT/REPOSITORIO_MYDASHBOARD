==============================================================================
CUSGL040_001 : Relat�rio Cau��o Cont�bil
==============================================================================

Atualiza��o - CUSGL040_001
Produto     - XX Customizaciones
Data        - 14/10/2020 11:04:30
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSGL040_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

N/A

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_GL_REL_CAUCAO_CONT_PKS.pls
                               SAE_GL_REL_CAUCAO_CONT_PKB.pls
                               SAE_GL_REL_CAUCAO_CONT_PK.grt
                               SAE_GL_REL_CAUCAO_CONT_PK.syn
                               SAE_GL_REL_CAUCAO_CONT_XDO.ldt
                               SAE_GL_REL_CAUCAO_CONT.rtf
                               SAE_GL_REL_CAUCAO_CONT_CCR.ldt
                               SAE_GL_CONTA_REL_CAUCAO_LKP.ldt
                               SAE_GL_CONTA_REL_CAUCAO_VST.ldt
                               SAE_GL_REL_CAUCAO_CONT_GL_RQG.ldt
                               SAE_GL_REL_CAUCAO_CONT_AP_RQG.ldt
