UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID         = 438265,
        PESO_RETIRO                  = 28940,
        LAST_UPDATE_DATE  = sysdate,
        LAST_UPDATED_BY     = 2070
WHERE LIQUIDACION_ID = 11958
--1


UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID         = 438232,
         PESO_RETIRO                 = 30540,
         LAST_UPDATE_DATE  = sysdate,
         LAST_UPDATED_BY    = 2070
WHERE LIQUIDACION_ID = 11959
--1