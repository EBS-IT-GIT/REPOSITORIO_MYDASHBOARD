UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID         = 438230,
        PESO_RETIRO                  = 29440,
        LAST_UPDATE_DATE  = sysdate,
        LAST_UPDATED_BY     = 2070
WHERE LIQUIDACION_ID = 11955
--1

UPDATE apps.XX_TCG_RT_LINES
SET CARTA_PORTE_ID         = 438229,
         PESO_RETIRO                 = 29480,
         LAST_UPDATE_DATE  = sysdate,
         LAST_UPDATED_BY    = 2070
WHERE LIQUIDACION_ID = 11956
--1