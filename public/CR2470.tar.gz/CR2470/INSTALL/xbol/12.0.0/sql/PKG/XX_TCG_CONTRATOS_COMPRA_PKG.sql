  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_TCG_CONTRATOS_COMPRA_PKG" AS

  FUNCTION Genera_OC_Abierta ( p_operating_unit          NUMBER
                             , p_productor_id            NUMBER
                             , p_item_id                 NUMBER
                             , p_user_id                 NUMBER
                             , x_po_header_id     IN OUT NUMBER
                             , x_po_header_number IN OUT VARCHAR2
                             , x_error_msg        IN OUT VARCHAR2
                             ) RETURN BOOLEAN;

  PROCEDURE UPD_ASL_Att_Consigned ( p_po_header_id          NUMBER
                                  , p_item_id               NUMBER
                                  , p_party_id              NUMBER
                                  , x_msg           IN OUT  VARCHAR2
                                  );


   -------------------
   -- Peso Aplicado --
   -------------------
   FUNCTION Get_Peso_Aplicado ( p_contrato_id     NUMBER
                              , p_carta_porte_id  NUMBER DEFAULT NULL
                              ) RETURN NUMBER;

   --------------------
   -- Peso pendiente --
   --------------------
   FUNCTION Get_Peso_Pendiente ( p_contrato_id     NUMBER
                               , p_carta_porte_id  NUMBER DEFAULT NULL
                               ) RETURN NUMBER;

   -----------------------
   -- Peso recepcionado --
   -----------------------
   FUNCTION Get_Kilos_Recepcionados ( p_contrato_id     NUMBER
                                    , p_carta_porte_id  NUMBER DEFAULT NULL
                                    ) RETURN NUMBER;


   ----------------------------------
   -- Peso Recepcionad Disponibleo --
   ----------------------------------
   FUNCTION Get_Kilos_Recep_Disponibles ( p_contrato_id     NUMBER
                                        , p_carta_porte_id  NUMBER DEFAULT NULL
                                        ) RETURN NUMBER;


   -------------------
   -- Peso retirado --
   -------------------
   FUNCTION Get_Kilos_Retirados ( p_contrato_id  NUMBER ) RETURN NUMBER;

   --------------------
   -- Peso liquidado --
   --------------------
   FUNCTION Get_Peso_Liq_Parcial ( p_contrato_id  NUMBER ) RETURN NUMBER;

   -----------------
   -- Peso Liq Única
   -----------------
   FUNCTION Get_Peso_Liq_Unica ( p_contrato_id  NUMBER ) RETURN NUMBER;

   -----------------
   -- Peso Liq Final
   -----------------
   FUNCTION Get_Peso_Liq_Final ( p_contrato_id  NUMBER ) RETURN NUMBER;

   --------------
   -- Peso Liq RT
   --------------
   FUNCTION Get_Peso_Liq_RT ( p_contrato_id  NUMBER ) RETURN NUMBER;

   -----------------
   -- Peso Liquidado
   -----------------
   FUNCTION Get_Peso_Liquidado ( p_contrato_id  NUMBER ) RETURN NUMBER;

   -----------------
   -- Certificado --
   -----------------
   PROCEDURE Get_Peso_Cert ( p_contrato_id         IN  NUMBER
                           , x_peso_bruto_cert     OUT NUMBER
                           , x_peso_neto_cert      OUT NUMBER
                           , x_merma_humedad_cert  OUT NUMBER
                           , x_merma_zaranda_cert  OUT NUMBER
                           , x_merma_volatil_cert  OUT NUMBER
                           );




END XX_TCG_CONTRATOS_COMPRA_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_TCG_CONTRATOS_COMPRA_PKG" AS

  FUNCTION Get_Operating_Unit ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_ou  NUMBER;
  BEGIN
    SELECT od.operating_unit
    INTO l_ou
    FROM xx_tcg_contratos_compra      cc
       , org_organization_definitions od
    WHERE 1=1
    AND od.organization_id = cc.organization_id
    AND cc.contrato_id     = p_contrato_id
    ;

    RETURN l_ou;
  END Get_Operating_Unit;


  FUNCTION Get_Peso_Contrato ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_total_contrato  NUMBER;
  BEGIN
    SELECT peso_contrato
    INTO l_total_contrato
    FROM xx_tcg_contratos_compra
    WHERE contrato_id = p_contrato_id;

    RETURN l_total_contrato;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 0;
  END Get_Peso_Contrato;


  FUNCTION Run_API ( p_int_header_id            NUMBER
                   , p_operating_unit           NUMBER
                   , p_commit                   VARCHAR2
                   , x_po_header_id      IN OUT NUMBER
                   , x_po_header_number  IN OUT VARCHAR2
                   , x_error_msg         IN OUT VARCHAR2
                   ) RETURN BOOLEAN IS

    CURSOR cIError IS
      SELECT error_message
      FROM po_interface_errors
      WHERE interface_header_id = p_int_header_id;

    d_pkg_name CONSTANT VARCHAR2(255) := 'po.plsql.PO_PDOI_Concurrent.';
    d_api_name CONSTANT VARCHAR2(255) :=  'POXPDOI';
    d_position                  NUMBER;

    l_selected_batch_id         NUMBER;
    l_buyer_id                  NUMBER;
    l_document_type             VARCHAR2(25);
    l_document_subtype          VARCHAR2(25);
    l_create_items              VARCHAR2(1);
    l_create_source_rules_flag  VARCHAR2(1);
    l_approval_status           VARCHAR2(25);
    l_rel_gen_method            VARCHAR2(25);
    l_org_id                    NUMBER := NULL;
    l_ga_flag                   VARCHAR2(1) := NULL;

    --<LOCAL SR/ASL PROJECT START>
    l_sourcing_level            VARCHAR2(50) := NULL;
    l_sourcing_inv_org_id       HR_ALL_ORGANIZATION_UNITS.organization_id%type;
    --<LOCAL SR/ASL PROJECT END>

    --Bug 13343886
    l_batch_size                NUMBER;
    l_gather_stats              VARCHAR2(1);
    --Bug 13343886

    l_return_status             VARCHAR2(1);
    l_msg                       VARCHAR2(2000);
    --CLM PDOI Integration
    l_clm_flag                  VARCHAR2(1) := 'N';
  BEGIN
    FND_GLOBAL.apps_initialize(FND_GLOBAL.User_ID, FND_GLOBAL.Resp_ID, FND_GLOBAL.Resp_appl_ID);
    FND_CLIENT_INFO.set_org_context(p_operating_unit);

    d_position := 0;

    l_buyer_id           := NULL;
    l_document_type      := 'BLANKET';
    l_document_subtype   := NULL;
    l_create_items       := 'N';
    l_create_source_rules_flag := 'Y';

    d_position := 20;

    l_approval_status    := 'APPROVED';
    l_rel_gen_method     := NULL;
    l_selected_batch_id  := NULL;
    l_org_id             := p_operating_unit;
    l_ga_flag            := 'Y'; --'10';  -- FPI GA

    --<LOCAL SR/ASL PROJECT  START>
    l_sourcing_level      := 'Y'; --'12';
    l_sourcing_inv_org_id := XX_TCG_FUNCTIONS_PKG.getMasterOrg;--'ITEM-ORGANIZATION'; --'14';
    --<LOCAL SR/ASL PROJECT  END>

    --Bug 13343886
    PO_PDOI_CONSTANTS.g_DEF_BATCH_SIZE := 5000;
    PO_PDOI_CONSTANTS.g_GATHER_STATS   := 'N';
    --Bug 13343886

    --CLM PDOI Integration
    --For CLM requests CLM Flag(15) is always going to be 'Y'
    --For Commercial requests (15) is going to fetch some random value
    l_clm_flag := 'N';

    d_position := 30;

    PO_PDOI_GRP.start_process
               ( p_api_version          => 1.0
               , p_init_msg_list        => FND_API.G_TRUE
               , p_validation_level     => FND_API.G_VALID_LEVEL_FULL
               , p_commit               => FND_API.G_FALSE
               , x_return_status        => l_return_status
               , p_gather_intf_tbl_stat => FND_API.G_FALSE
               , p_calling_module       => PO_PDOI_CONSTANTS.g_CALL_MOD_CONCURRENT_PRGM
               , p_selected_batch_id    => l_selected_batch_id
               , p_batch_size           => PO_PDOI_CONSTANTS.g_DEF_BATCH_SIZE
               , p_buyer_id             => l_buyer_id
               , p_document_type        => l_document_type
               , p_document_subtype     => l_document_subtype
               , p_create_items         => l_create_items
               , p_create_sourcing_rules_flag => l_create_source_rules_flag
               , p_rel_gen_method       => l_rel_gen_method
               , p_sourcing_level       => l_sourcing_level
               , p_sourcing_inv_org_id  => l_sourcing_inv_org_id
               , p_approved_status      => l_approval_status
               , p_process_code         => PO_PDOI_CONSTANTS.g_process_code_PENDING
               , p_interface_header_id  => p_int_header_id -- Interface Header ID generado previamente
               , p_org_id               => p_operating_unit
               , p_ga_flag              => l_ga_flag
               , p_clm_flag             => l_clm_flag
               );

    IF l_return_status != FND_API.G_RET_STS_SUCCESS THEN
      RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
    END IF;


    BEGIN
      SELECT ph.po_header_id, ph.segment1
      INTO x_po_header_id, x_po_header_number
      FROM po_headers_interface hi
         , po_headers_all       ph
      WHERE 1=1
      AND ph.po_header_id = hi.po_header_id
      AND hi.interface_header_id = p_int_header_id
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        FOR r IN cIError LOOP
          x_error_msg := x_error_msg||' '||r.error_message;
        END LOOP;

        RETURN FALSE;
    END;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      PO_MESSAGE_S.add_exc_msg
      ( p_pkg_name => d_pkg_name,
        p_procedure_name => d_api_name || '.' || d_position
      );

      FOR i IN 1..FND_MSG_PUB.COUNT_MSG LOOP
        l_msg := FND_MSG_PUB.get
                 ( p_msg_index => i,
                   p_encoded => FND_API.G_FALSE
                 );

        --DBMS_OUTPUT.PUT_LINE('Error: '||l_msg);
        x_error_msg := x_error_msg || l_msg ||' ';
      END LOOP;
      RETURN FALSE;
  END Run_API;


  FUNCTION Genera_OC_Abierta ( p_operating_unit          NUMBER
                             , p_productor_id            NUMBER
                             , p_item_id                 NUMBER
                             , p_user_id                 NUMBER
                             , x_po_header_id     IN OUT NUMBER
                             , x_po_header_number IN OUT VARCHAR2
                             , x_error_msg        IN OUT VARCHAR2
                             ) RETURN BOOLEAN IS

    CURSOR cVS IS
      SELECT vs.vendor_site_id
      FROM ap_suppliers        s
         , po_vendor_sites_all vs
          , hz_party_site_uses hpsu
      WHERE 1=1
      AND vs.vendor_id = s.vendor_id
      AND NVL(vs.inactive_date, SYSDATE+1) > TRUNC(SYSDATE)
      AND vs.org_id    = p_operating_unit
      AND s.party_id   = p_productor_id
      AND hpsu.site_use_type = 'PURCHASING'
      AND hpsu.status = 'A'
     AND nvl(vs.PURCHASING_SITE_FLAG,'X') = 'Y'
      and vs.party_site_id = hpsu.party_site_id
      ;


    l_progress           VARCHAR2(10);
    l_dummy_num          NUMBER;
    l_int_header_id      NUMBER;
    l_batch_id           NUMBER;

    --Campos comunes
    l_attribute_category VARCHAR2(5) := 'AR';

    --Campos para la cabecera
    l_agent_id           NUMBER := 5047; --FBARCA
    l_doc_type           VARCHAR2(10)  := 'BLANKET';
    l_comments           VARCHAR2(150) := 'OC ACOPIO - CIRCUITO CONSIGNACION';
    -- Proveedor
    l_vendor_id          NUMBER;
    l_vendor_site_id     NUMBER;

    --Campos para las lineas
    l_line_type_id       NUMBER := 1;
    l_unit_price         NUMBER := 0.1;

    l_asl_id             NUMBER;

    eCustError           EXCEPTION;
  BEGIN
    x_error_msg := null;
    l_progress := 'IDs';
    SELECT NVL(MAX(batch_id),0)+1
    INTO l_batch_id
    FROM po_headers_interface;
    --DBMS_OUTPUT.PUT_LINE('Batch ID: '||l_batch_id);

    SELECT po_headers_interface_s.NEXTVAL
    INTO l_int_header_id
    FROM DUAL;
    --DBMS_OUTPUT.PUT_LINE('Interface Header ID: '||l_int_header_id);

    -- Comprador
    BEGIN
      SELECT DISTINCT agent_id
      INTO l_dummy_num
      FROM per_all_people_f p
         , fnd_user         u
         , po_agents        a
      WHERE 1=1
      AND p.party_id = u.person_party_id
      AND a.agent_id = p.person_id
      AND u.user_id  = p_user_id;

      l_agent_id := l_dummy_num;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    -- Productor
    BEGIN
      SELECT vendor_id
      INTO l_vendor_id
      FROM ap_suppliers
      WHERE 1=1
      AND NVL(end_date_active, SYSDATE+1) > TRUNC(SYSDATE)
      AND party_id = p_productor_id
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        x_error_msg := 'El proveedor se encuentra deshabilitado.';
        RAISE eCustError;
    END;

    OPEN cVS;
    FETCH cVS INTO l_vendor_site_id;
    IF cVS%NOTFOUND THEN
      CLOSE cVS;
      x_error_msg := 'No se encontró Sucursal de compra activa del Depositante para la Unidad operativa'; -- CR1991 - Validaciones previas a la generación de la OC
      RAISE eCustError;
    END IF;
    CLOSE cVS;

    l_progress := 'intHeader';
    INSERT INTO PO.PO_HEADERS_INTERFACE
    ( INTERFACE_HEADER_ID
    , BATCH_ID
    , PROCESS_CODE
    , ACTION
    , ATTRIBUTE_CATEGORY
    , ORG_ID
    , COMMENTS
    , DOCUMENT_TYPE_CODE
    , CURRENCY_CODE
    , AGENT_ID
    , VENDOR_ID
    , VENDOR_SITE_ID
    , APPROVAL_REQUIRED_FLAG
    , APPROVAL_STATUS
    , APPROVED_DATE
    , CREATION_DATE
    )
    VALUES
    ( l_int_header_id --  INTERFACE_HEADER_ID
    , l_batch_id
    , 'PENDING'  --  PROCESS_CODE
    , 'ORIGINAL' --  ACTION
    , l_attribute_category
    , p_operating_unit
    , l_comments
    , l_doc_type
    , 'ARS'      -- CURRENCY_CODE,
    , l_agent_id
    , l_vendor_id
    , l_vendor_site_id
    , 'N'        -- APPROVAL_REQUIRED_FLAG
    , 'APPROVED' -- APPROVAL_STATUS
    , SYSDATE    -- APPROVED_DATE
    , SYSDATE    --  CREATION_DATE
    );

    l_progress := 'intLines';
    INSERT INTO PO.PO_LINES_INTERFACE
    ( INTERFACE_LINE_ID
    , INTERFACE_HEADER_ID
    , ACTION
    , LINE_NUM
    , LINE_TYPE_ID
    , ITEM_ID
    , UOM_CODE
    , UNIT_PRICE
    , CREATION_DATE
    ) VALUES
    ( po_lines_interface_s.nextval -- INTERFACE_LINE_ID
    , l_int_header_id -- INTERFACE_HEADER_ID
    , 'ADD' --  ACTION
    , 1     -- LINE_NUM
    , l_line_type_id
    , p_item_id
    , 'KG'  -- UOM_CODE
    , l_unit_price
    , SYSDATE -- CREATION_DATE,
    );


    IF NOT Run_API ( p_int_header_id     => l_int_header_id
                   , p_operating_unit    => p_operating_unit
                   , p_commit            => FND_API.G_TRUE
                   , x_po_header_id      => x_po_header_id
                   , x_po_header_number  => x_po_header_number
                   , x_error_msg         => x_error_msg
                   ) THEN
      x_po_header_id := null;
      x_po_header_number := null;
      ROLLBACK;
      RETURN FALSE;
    END IF;


    RETURN TRUE;
  EXCEPTION
    WHEN eCustError THEN
      ROLLBACK;
      RETURN FALSE;

  END Genera_OC_Abierta;


  PROCEDURE UPD_ASL_Att_Consigned ( p_po_header_id          NUMBER
                                  , p_item_id               NUMBER
                                  , p_party_id              NUMBER
                                  , x_msg           IN OUT  VARCHAR2
                                  ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;

    l_vendor_id  NUMBER;
    l_asl_id     NUMBER;
  BEGIN
    BEGIN
      SELECT vendor_id
      INTO l_vendor_id
      FROM ap_suppliers
      WHERE 1=1
      AND party_id = p_party_id
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        x_msg := 'No se encontro vendor_id';
    END;

    BEGIN
      SELECT asl_id
      INTO l_asl_id
      FROM po_asl_documents
      WHERE 1=1
      AND document_header_id = p_po_header_id;
    EXCEPTION
      WHEN OTHERS THEN
        x_msg := x_msg||' No se encontro asl_id';
    END;

    UPDATE po_asl_attributes
    SET consigned_from_supplier_flag = 'Y'
    WHERE 1=1
    AND item_id   = p_item_id
    AND vendor_id = l_vendor_id
    AND asl_id    = l_asl_id
    ;

    COMMIT;
  END UPD_ASL_Att_Consigned;


  -------------------
  -- Peso Aplicado --
  -------------------
  FUNCTION Get_Peso_Aplicado ( p_contrato_id     NUMBER
                            , p_carta_porte_id   NUMBER DEFAULT NULL
                            ) RETURN NUMBER IS
    CURSOR c_cps IS
      SELECT carta_porte_id
           , NVL(peso_bruto_recepcion,0)         peso_bruto_recepcion
           , NVL(tara_recepcion,0)               tara_recepcion
      FROM xx_tcg_cartas_porte_all
      WHERE p_contrato_id IN ( titular_cp_contrato_id
                             , intermediario_contrato_id
                             , rtte_comercial_contrato_id
                             , destinatario_contrato_id)
      AND ( p_carta_porte_id IS NULL OR
            ( p_carta_porte_id IS NOT NULL AND
              p_carta_porte_id != carta_porte_id
            )
          )
      AND NVL(anulado_flag, 'N') = 'N'
      ;

    l_cc_ou            NUMBER;
    l_peso_aplicado    NUMBER := 0;
    l_peso_aplicado11  NUMBER := 0;

    l_peso_cp              NUMBER := 0;
    l_merma_humedad_cp     NUMBER := 0;
    l_merma_zaranda_cp     NUMBER := 0;
    l_merma_volatil_cp     NUMBER := 0;
    l_num_merma_humedad    NUMBER := 0;
    l_num_merma_zaranda    NUMBER := 0;
    l_num_merma_volatil    NUMBER := 0;
    l_total_peso           NUMBER := 0;

  BEGIN
    l_cc_ou := Get_Operating_Unit (p_contrato_id);

   --R11
    BEGIN
      SELECT NVL(((sum(peso_bruto_recepcion - tara_recepcion)) - nvl(sum(merma_humedad),0) - nvl(sum(merma_zaranda),0) - nvl(sum(merma_volatil),0) ),0) peso_neto
      INTO l_peso_aplicado11
      FROM xx_aco_cartas_porte_v
      WHERE 1=1
      AND contrato_id   = p_contrato_id
      AND org_id        = l_cc_ou
      AND anulado_flag   = 'N'
      ;
    EXCEPTION
      WHEN OTHERS THEN
        l_peso_aplicado11 := 0;
    END;


    FOR rcp IN c_cps LOOP
      l_peso_cp          := 0;
      l_merma_humedad_cp := 0;
      l_merma_zaranda_cp := 0;
      l_merma_volatil_cp := 0;

      l_peso_cp := rcp.peso_bruto_recepcion - rcp.tara_recepcion;

      l_total_peso := l_total_peso + l_peso_cp;

      --Peso Humedad
      l_merma_humedad_cp := XX_TCG_CALIDAD_PKG.Get_Merma_Humedad( p_carta_porte_id  => rcp.carta_porte_id );

      l_num_merma_humedad := l_num_merma_humedad + NVL(l_merma_humedad_cp, 0);

      --Peso Zaranda
      l_merma_zaranda_cp := XX_TCG_CALIDAD_PKG.Get_Merma_Zaranda( p_carta_porte_id  => rcp.carta_porte_id );

      l_num_merma_zaranda := l_num_merma_zaranda + NVL(l_merma_zaranda_cp, 0);

      --Peso Volatil
      l_merma_volatil_cp := XX_TCG_CALIDAD_PKG.Get_Merma_Volatil( p_carta_porte_id  => rcp.carta_porte_id );

      l_num_merma_volatil := l_num_merma_volatil + NVL(l_merma_volatil_cp, 0);
    END LOOP;

    l_peso_aplicado := l_total_peso - l_num_merma_humedad - l_num_merma_zaranda - l_num_merma_volatil + l_peso_aplicado11;

    RETURN l_peso_aplicado;
  END Get_Peso_Aplicado;

   --------------------
   -- Peso pendiente --
   --------------------
  FUNCTION Get_Peso_Pendiente ( p_contrato_id     NUMBER
                              , p_carta_porte_id  NUMBER DEFAULT NULL
                              ) RETURN NUMBER IS
    l_peso_pendiente  NUMBER := 0;
  BEGIN
    l_peso_pendiente := Get_Peso_Contrato ( p_contrato_id ) -  Get_Peso_Aplicado ( p_contrato_id, p_carta_porte_id );

    RETURN l_peso_pendiente;
  END Get_Peso_Pendiente;

  -----------------------
  -- Peso recepcionado --
  -----------------------
  FUNCTION Get_Kilos_Recepcionados ( p_contrato_id     NUMBER
                                   , p_carta_porte_id  NUMBER DEFAULT NULL
                                   ) RETURN NUMBER IS

    CURSOR c_rec_cps IS
      SELECT carta_porte_id
           , NVL(peso_bruto_recepcion,0)         peso_bruto_recepcion
           , NVL(tara_recepcion,0)               tara_recepcion
      FROM xx_tcg_cartas_porte_all
      WHERE p_contrato_id IN ( titular_cp_contrato_id
                             , intermediario_contrato_id
                             , rtte_comercial_contrato_id
                             , destinatario_contrato_id)
      AND ( p_carta_porte_id IS NULL OR
            ( p_carta_porte_id IS NOT NULL AND
              p_carta_porte_id != carta_porte_id
            )
          )
      AND NVL(anulado_flag,'N')  = 'N'
      AND NVL(recibido_flag,'N') = 'Y';

    l_kilos_recepcionados  NUMBER := 0;
    l_peso_recep11         NUMBER := 0;
    l_cc_ou                NUMBER;

    l_peso_cp              NUMBER := 0;
    l_merma_humedad_cp     NUMBER := 0;
    l_merma_zaranda_cp     NUMBER := 0;
    l_merma_volatil_cp     NUMBER := 0;
    l_num_merma_humedad    NUMBER := 0;
    l_num_merma_zaranda    NUMBER := 0;
    l_num_merma_volatil    NUMBER := 0;
    l_total_peso           NUMBER := 0;

  BEGIN
    l_cc_ou := Get_Operating_Unit (p_contrato_id);

    --R11
    BEGIN
      SELECT NVL((sum(peso_bruto_recepcion - tara_recepcion)),0) - NVL(SUM(merma_humedad),0) -  NVL(SUM(merma_zaranda),0) -  NVL(SUM(merma_volatil),0)
      INTO l_peso_recep11
      FROM xx_aco_cartas_porte_v
      WHERE 1=1
      AND recibido_flag  = 'Y'
      AND anulado_flag   = 'N'
      AND org_id         = l_cc_ou
      AND contrato_id    = p_contrato_id;
    EXCEPTION
      WHEN OTHERS THEN
        l_peso_recep11 := 0;
    END;

    l_total_peso := 0;
    l_num_merma_humedad :=0;
    l_num_merma_zaranda :=0;
    l_num_merma_volatil :=0;

    FOR reccp IN c_rec_cps LOOP
      l_peso_cp          := 0;
      l_merma_humedad_cp := 0;
      l_merma_zaranda_cp := 0;
      l_merma_volatil_cp := 0;

      l_peso_cp := reccp.peso_bruto_recepcion - reccp.tara_recepcion;

      l_total_peso := l_total_peso + l_peso_cp;

      --Peso Humedad
      l_merma_humedad_cp := XX_TCG_CALIDAD_PKG.Get_Merma_Humedad( p_carta_porte_id  => reccp.carta_porte_id );

      l_num_merma_humedad := l_num_merma_humedad + NVL(l_merma_humedad_cp, 0);

      --Peso Zaranda
      l_merma_zaranda_cp := XX_TCG_CALIDAD_PKG.Get_Merma_Zaranda( p_carta_porte_id  => reccp.carta_porte_id );

      l_num_merma_zaranda := l_num_merma_zaranda + NVL(l_merma_zaranda_cp, 0);

      --Peso Volatil
      l_merma_volatil_cp := XX_TCG_CALIDAD_PKG.Get_Merma_Volatil( p_carta_porte_id  => reccp.carta_porte_id );

      l_num_merma_volatil := l_num_merma_volatil + NVL(l_merma_volatil_cp, 0);

    END LOOP;

    l_kilos_recepcionados := l_total_peso - l_num_merma_humedad - l_num_merma_zaranda - l_num_merma_volatil + l_peso_recep11;

    RETURN l_kilos_recepcionados;
  END Get_Kilos_Recepcionados;


  ----------------------------------
  -- Peso Recepcionad Disponibleo --
  ----------------------------------
  FUNCTION Get_Kilos_Recep_Disponibles ( p_contrato_id     NUMBER
                                       , p_carta_porte_id  NUMBER DEFAULT NULL
                                       ) RETURN NUMBER IS
    l_peso_pendiente  NUMBER := 0;
  BEGIN
    l_peso_pendiente := Get_Peso_Contrato ( p_contrato_id ) -  Get_Kilos_Recepcionados ( p_contrato_id, p_carta_porte_id );

    RETURN l_peso_pendiente;
  END Get_Kilos_Recep_Disponibles;


   -------------------
   -- Peso retirado --
   -------------------
  FUNCTION Get_Kilos_Retirados ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_kilos_retirados  NUMBER := 0;
  BEGIN
    BEGIN
      SELECT SUM (NVL (peso, 0))
      INTO l_kilos_retirados
      FROM (SELECT NVL (SUM (rtl.peso_retiro), 0) PESO
            FROM xx_aco_liquidaciones_1116a rta,
                 xx_aco_contratos aco,
                 xx_aco_liquidaciones_1116rt rt,
                 xx_aco_liq_1116rt_lines rtl,
                 xx_aco_cartas_porte_v cp
            WHERE 1=1
            AND aco.contrato_id = p_contrato_id
            AND rta.contrato_id = aco.contrato_id
            AND rta.liquidacion_id = rt.liquidacion_id_relacionada
            AND rt.liquidacion_id  = rtl.liquidacion_id
            AND rtl.carta_porte_id = cp.carta_porte_id
            AND cp.anulado_flag    = 'N'
            AND rt.cancelado_flag  = 'N'
            AND rt.liquidado_flag  = 'Y'
            AND rta.liquidado_flag = 'Y'
            AND rta.cancelado_flag = 'N'
            UNION ALL
            SELECT SUM (peso_transferido) PESO
            FROM apps.xx_tcg_cartas_porte_all xcp
            WHERE 1=1
            AND titular_cp_contrato_id = p_contrato_id
            AND transferido_flag = 'Y'
            AND anulado_flag = 'N'
            AND (intermediario_retiro = 'Y' OR rtte_comercial_retiro = 'Y')
           );

    EXCEPTION
      WHEN OTHERS THEN
        l_kilos_retirados := 0;
    END;

    RETURN l_kilos_retirados;
  END Get_Kilos_Retirados;

  --------------------
  -- Peso liquidado --
  --------------------
  FUNCTION Get_Peso_Liq_Parcial ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_peso_liq_parcial  NUMBER := 0;
  BEGIN
    BEGIN
      SELECT NVL(sum(peso_neto_liquidado),0)
      INTO l_peso_liq_parcial
      FROM (SELECT liquidacion_id
                 , tipo_liquidacion
                 , contrato_id
                 , cancelado_flag
                 , liquidado_flag
                 , peso_neto_liquidado
            FROM xx_aco_liquidaciones_1116b
            UNION ALL
            SELECT liquidacion_id
                 , tipo_liquidacion
                 , contrato_id
                 , cancelado_flag
                 , liquidado_flag
                 , peso_neto_liquidado
            FROM xx_tcg_liquidaciones
           )
      WHERE 1=1
      AND tipo_liquidacion = 'PARCIAL'
      AND cancelado_flag   = 'N'
      AND liquidado_flag   = 'Y'
      AND contrato_id      = p_contrato_id;

    EXCEPTION
      WHEN OTHERS THEN
        l_peso_liq_parcial := 0;
    END;

    RETURN l_peso_liq_parcial;
  END Get_Peso_Liq_Parcial;

  -----------------
  -- Peso Liq Única
  -----------------
  FUNCTION Get_Peso_Liq_Unica ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_peso_liq_unica  NUMBER := 0;
  BEGIN
    BEGIN
      SELECT NVL(sum(peso_neto_liquidado),0) AS peso
      INTO l_peso_liq_unica
      FROM (SELECT liquidacion_id
                 , tipo_liquidacion
                 , contrato_id
                 , cancelado_flag
                 , liquidado_flag
                 , peso_neto_liquidado
            FROM xx_aco_liquidaciones_1116b
            UNION ALL
            SELECT liquidacion_id
                 , tipo_liquidacion
                 , contrato_id
                 , cancelado_flag
                 , liquidado_flag
                 , peso_neto_liquidado
            FROM xx_tcg_liquidaciones
           )   liqb
      WHERE 1=1
      AND tipo_liquidacion = 'UNICA'
      AND cancelado_flag = 'N'
      AND liquidado_flag = 'Y'
      AND contrato_id    = p_contrato_id;

    EXCEPTION
    WHEN OTHERS THEN
      l_peso_liq_unica := 0;
    END;

    RETURN l_peso_liq_unica;
  END Get_Peso_Liq_Unica;

  -----------------
  -- Peso Liq Final
  -----------------
  FUNCTION Get_Peso_Liq_Final ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_peso_liq_final  NUMBER := 0;
  BEGIN

    BEGIN
      SELECT NVL(sum(peso_liquidado),0)  AS PESO
      INTO l_peso_liq_final
      FROM (SELECT peso_liquidado
            FROM xx_aco_liquidaciones_1116b_v  liqb,
                 xx_aco_liq_1116b_lines        liql
            WHERE 1=1
            AND tipo_liquidacion IN ('FINAL','AJUSTE_UNICO')
            AND cancelado_flag   = 'N'
            AND liquidado_flag   = 'Y'
            AND liqb.liquidacion_id = liql.liquidacion_id
            AND contrato_id      = p_contrato_id
            UNION ALL
            SELECT peso_liquidado
            FROM xx_tcg_liquidaciones      liqb,
                 xx_tcg_liquidacion_lines  liql
            WHERE 1=1
            AND tipo_liquidacion = 'AJUSTE_UNICO'
            AND cancelado_flag   = 'N'
            AND liquidado_flag   = 'Y'
            AND liqb.liquidacion_id = liql.liquidacion_id
            AND contrato_id      = p_contrato_id
           );

    EXCEPTION
      WHEN OTHERS THEN
        l_peso_liq_final := 0;
    END;

    RETURN l_peso_liq_final;
  END Get_Peso_Liq_Final;

  --------------
  -- Peso Liq RT
  --------------
  FUNCTION Get_Peso_Liq_RT ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_peso_liq_rt  NUMBER := 0;
  BEGIN
    BEGIN
      SELECT SUM (nvl(peso,0))
      INTO l_peso_liq_rt
      FROM (SELECT NVL (SUM (liqrtl.peso_retiro), 0) peso    -- Peso Liq RT ( 11 )
            FROM xx_aco_liquidaciones_1116rt liqrt,
                 xx_aco_liq_1116rt_lines liqrtl,
                 xx_aco_liquidaciones_1116a liqa
            WHERE 1=1
            AND liqrt.tipo_liquidacion = 'RETIRO'
            AND liqrt.cancelado_flag = 'N'
            AND liqrt.liquidado_flag = 'Y'
            AND liqrt.liquidacion_id_relacionada   = liqa.liquidacion_id
            AND liqrt.tipo_liquidacion_relacionada = '1116A'
            AND liqrt.liquidacion_id = liqrtl.liquidacion_id
            AND liqa.contrato_id     = p_contrato_id
            UNION ALL
            SELECT SUM (PESO_RETIRO) peso                    -- Peso Liq RT ( 12 )
            FROM xx_tcg_rt       xrt
               , xx_tcg_rt_lines xrtl
            WHERE 1=1
            AND xrtl.liquidacion_id  = xrt.liquidacion_id
            AND NVL (XRT.cancelado_flag, 'N') = 'N'
            AND xrt.tipo_liquidacion = 'RETIRO'
            AND NVL (xrt.liquidado_flag, 'N') = 'Y'
            AND xrt.contrato_id      = p_contrato_id
           );

    EXCEPTION
      WHEN OTHERS THEN
        l_peso_liq_rt := 0;
    END;

    RETURN l_peso_liq_rt;
  END Get_Peso_Liq_RT;

  -----------------
  -- Peso Liquidado
  -----------------
  FUNCTION Get_Peso_Liquidado ( p_contrato_id  NUMBER ) RETURN NUMBER IS
    l_peso_liquidado  NUMBER := 0;
  BEGIN
    l_peso_liquidado := Get_Peso_Liq_Parcial ( p_contrato_id ) + Get_Peso_Liq_Unica ( p_contrato_id );

    RETURN l_peso_liquidado;
  END Get_Peso_Liquidado;

  -----------------
  -- Certificado --
  -----------------
  PROCEDURE Get_Peso_Cert ( p_contrato_id         IN  NUMBER
                          , x_peso_bruto_cert     OUT NUMBER
                          , x_peso_neto_cert      OUT NUMBER
                          , x_merma_humedad_cert  OUT NUMBER
                          , x_merma_zaranda_cert  OUT NUMBER
                          , x_merma_volatil_cert  OUT NUMBER
                          ) IS
    l_cc_ou                 NUMBER;
    l_peso_bruto_cert11     NUMBER := 0;
    l_peso_bruto_cert       NUMBER := 0;
    l_peso_neto_cert11      NUMBER := 0;
    l_peso_neto_cert        NUMBER := 0;
    l_merma_humedad_cert11  NUMBER := 0;
    l_merma_humedad_cert    NUMBER := 0;
    l_merma_zaranda_cert11  NUMBER := 0;
    l_merma_zaranda_cert    NUMBER := 0;
    l_merma_volatil_cert11  NUMBER := 0;
    l_merma_volatil_cert    NUMBER := 0;
  BEGIN
    l_cc_ou := Get_Operating_Unit (p_contrato_id);

    --R11
    BEGIN
      SELECT ROUND(NVL(SUM(xcp.peso_bruto_recepcion - xcp.tara_recepcion),0))   pbruto,
             NVL(SUM(xcp.merma_humedad),0),
             NVL(SUM(xcp.merma_zaranda),0),
             NVL(SUM(xcp.merma_volatil),0),
             NVL(( ROUND(NVL(SUM(xcp.peso_bruto_recepcion - xcp.tara_recepcion),0))
             - SUM(xcp.merma_humedad) - SUM(xcp.merma_zaranda) - SUM(xcp.merma_volatil)),0)  peso_neto
      INTO l_peso_bruto_cert11,
           l_merma_humedad_cert11,
           l_merma_zaranda_cert11,
           l_merma_volatil_cert11,
           l_peso_neto_cert11
      FROM xx_aco_liq_1116a_cp_v       xlcv,
           xx_aco_cartas_porte_v       xcp,
           xx_aco_liquidaciones_1116a  xala
      WHERE 1=1
      AND xcp.carta_porte_id  = xlcv.carta_porte_id
      AND xcp.org_id          = l_cc_ou
      AND xala.cancelado_flag = 'N'
      AND xlcv.Liquidacion_ID = xala.Liquidacion_ID
      AND xcp.anulado_flag    = 'N'
      AND xcp.contrato_id     = p_contrato_id
      AND NVL(xala.liquidado_flag,'N') = 'Y'
      ;

    EXCEPTION
      WHEN OTHERS THEN
        l_peso_bruto_cert11    :=0;
        l_merma_humedad_cert11 :=0;
        l_merma_zaranda_cert11 :=0;
        l_merma_volatil_cert11 :=0;
        l_peso_neto_cert11     :=0;
    END;


    BEGIN
      SELECT ROUND(SUM(xtcp.peso_bruto),0) peso_bruto
           , ROUND(SUM(xtcp.merma_secada),0) merma_secada
           , ROUND(SUM(xtcp.merma_zaranda),0) merma_zaranda
           , ROUND(SUM(xtcp.merma_volatil),0) merma_volatil
           , ROUND(SUM((xtcp.peso_bruto - xtcp.merma_secada - xtcp.merma_zaranda - xtcp.merma_volatil)),0) peso_neto
      INTO l_peso_bruto_cert
         , l_merma_humedad_cert
         , l_merma_zaranda_cert
         , l_merma_volatil_cert
         , l_peso_neto_cert
      FROM (SELECT xcpa.carta_porte_id
                 , (NVL(xcpa.peso_bruto_recepcion,0) - NVL(xcpa.tara_recepcion,0)) peso_bruto
                 , NVL(XX_TCG_CALIDAD_PKG.Get_Merma_Humedad(xcpa.carta_porte_id),0) merma_secada
                 , NVL(XX_TCG_CALIDAD_PKG.Get_Merma_Zaranda(xcpa.carta_porte_id),0) merma_zaranda
                 , NVL(XX_TCG_CALIDAD_PKG.Get_Merma_Volatil(xcpa.carta_porte_id),0) merma_volatil
                 , anulado_flag
            FROM xx_tcg_cartas_porte_all  xcpa) xtcp
         , xx_tcg_boletin_lines           xtbl
         , xx_tcg_boletin_headers         xtbh
         , xx_tcg_liquidaciones_1116a     xtla
      WHERE 1=1
      AND xtcp.carta_porte_id           = xtbl.carta_porte_id
      AND xtbl.boletin_header_id        = xtbh.boletin_header_id
      AND xtbh.boletin_header_id        = xtla.boletin_header_id
      AND NVL(xtbh.anulado_flag, 'N')   = 'N'
      AND NVL(xtcp.anulado_flag, 'N')   = 'N'
      AND NVL(xtla.cancelado_flag, 'N') = 'N'
      AND xtbh.contrato_id              = p_contrato_id;


    EXCEPTION
      WHEN OTHERS THEN
        l_peso_bruto_cert    := 0;
        l_merma_humedad_cert := 0;
        l_merma_zaranda_cert := 0;
        l_merma_volatil_cert := 0;
        l_peso_neto_cert     := 0;
    END;
    --

    x_peso_bruto_cert    := NVL(l_peso_bruto_cert,0) + NVL(l_peso_bruto_cert11,0);
    x_peso_neto_cert     := NVL(l_peso_neto_cert,0) + NVL(l_peso_neto_cert11,0);
    x_merma_humedad_cert := NVL(l_merma_humedad_cert,0) + NVL(l_merma_humedad_cert11,0);
    x_merma_zaranda_cert := NVL(l_merma_zaranda_cert,0) + NVL(l_merma_zaranda_cert11,0);
    x_merma_volatil_cert := NVL(l_merma_volatil_cert,0) + NVL(l_merma_volatil_cert11,0);

  END Get_Peso_Cert;

END XX_TCG_CONTRATOS_COMPRA_PKG;
/

exit
