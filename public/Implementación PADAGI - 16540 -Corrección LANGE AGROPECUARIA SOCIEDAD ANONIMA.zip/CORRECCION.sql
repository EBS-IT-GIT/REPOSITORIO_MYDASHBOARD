UPDATE apps.hz_cust_accounts
SET    party_id = party_id * -1, last_update_date = sysdate, last_updated_by = 2070
WHERE  party_id = (SELECT party_id
                   FROM   apps.hz_parties
                   WHERE  party_name = 'LANGE AGROPECUARIA SOCIEDAD ANONIMA')
AND    status = 'I';
--1 Registro