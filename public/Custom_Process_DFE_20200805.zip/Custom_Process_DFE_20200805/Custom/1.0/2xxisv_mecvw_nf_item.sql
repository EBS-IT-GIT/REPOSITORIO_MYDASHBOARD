create or replace view xxisv_mecvw_nf_item as
select
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_MEFVW_NF_ITEM
--NOME FISICO.........: XXISV_MEFVW_NF_ITEM.SQL
--TIPO_OBJETO.........: VIEW
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--CUSTOMIZACOES.......:
--                    : JVP003 - 05/08/2020 - TRATAMENTO VLR_SERVICO QUE ESTVAM RETORNANDO "0"
------------------------------------------------------------------------------------------------------------------------
      a.customer_trx_id                                                    as CUSTOMER_TRX_ID            ,
      a.org_id                                                             as ORG_ID                     ,
      a.line_number                                                        as N_NITEM                    ,
      a.customer_trx_line_id                                               as CUSTOMER_TRX_LINE_ID       ,
      b.segment1 || b.segment2  ||
      b.segment3 || b.segment4  ||
      b.segment5 || b.segment6  ||
      b.segment7 || b.segment8  ||
      b.segment9 || b.segment10 ||
      b.segment11|| b.segment12 ||
      b.segment13|| b.segment14 ||
      b.segment15|| b.segment16 ||
      b.segment17|| b.segment18 ||
      b.segment19|| b.segment20                                            as S_CPROD                    ,
      a.description                                                        as S_XPROD                    ,
      a.code_nbm                                                           as S_NCM                      ,
      a.code_cfo                                                           as N_CFOP                     ,
      a.uom_code                                                           as S_UCOM                     ,
      (select mum.unit_of_measure_tl
         from apps.MTL_UNITS_OF_MEASURE_TL mum
        where mum.uom_code = a.uom_code
          and mum.language = 'PTB')                                        as S_UCOM_PTB                 , -- 10278/2014
      a.quantity_invoiced                                                  as N_QCOM                     ,
      a.unit_price                                                         as N_VUNCOM                   ,
      a.quantity_invoiced * a.unit_price                                   as N_VALTOTAL                 , -- JVP003
      a.vl_item                                                            as N_VPROD                    ,
      a.uom_code                                                           as S_UTRIB                    ,
            (select mum.unit_of_measure_tl
         from apps.MTL_UNITS_OF_MEASURE_TL mum
        where mum.uom_code = a.uom_code
          and mum.language = 'PTB')                                        as S_UTRIB_PTB                , -- 10278/2014
      a.quantity_invoiced                                                  as N_QTRIB                    ,
      a.unit_price                                                         as N_VUNTRIB                  ,
      1                                                                    as N_INDTOT                   ,
      nvl(c.ICMS_vlr, 0)   +
          nvl(c.IPI_vlr, 0)    +
          nvl(c.pis_vlr, 0)    +
          nvl(c.cofins_vlr, 0)                                             as N_VTOTTRIB                 ,
      nvl2(c.ICMS_cst, a.type_item_origin, null)                           as N_ICMS_ORIG                ,
      c.ICMS_cst                                                           as N_ICMS_CST                 ,
      3                                                                    as N_ICMS_MODBC               ,
      decode(c.ICMS_cst,40, null,
                        41, null,
                        50, null, c.ICMS_base)                             as N_ICMS_VBC                 ,
      nvl2(c.ICMS_cst, c.ICMS_aliq, null)                                  as N_ICMS_PICMS               ,
      decode(c.ICMS_cst,40, null,
                        41, null,
                        50, null, c.ICMS_vlr)                              as N_ICMS_VICMS               ,
      decode(c.ICMS_ST_cst, 10, null,
                            30, null,
                            60, null, c.ICMS_ST_base)                      as N_ICMS_VBCST               ,
      decode(c.ICMS_ST_cst, 10, null,
                            30, null,
                            60, null, c.ICMS_ST_aliq)                      as N_ICMS_PICMSST             ,
      decode(c.ICMS_ST_cst, 10, null,
                            30, null,
                            60, null, c.ICMS_ST_vlr)                       as N_ICMS_VICMSST             ,
      c.ICMS_ST_cst                                                        as N_ICMSST_CST               ,
      nvl((select ia.legal_justification_text3 -- ipi legal framing code
           from apps.cll_f255_ar_total_inv_taxes_v ia
           where ia.event_class_code = 'INVOICE' -- it can be invoice, credit_memo or debit_memo
           and ia.customer_trx_id = a.customer_trx_id
           and ia.link_to_cust_trx_line_id = a.customer_trx_line_id
           and ia.tax_regime_code = 'BRAZIL-VAT'
           and (ia.tax like 'IPI%C' or ia.tax like 'IPI')
           and ia.legal_justification_text3 is not null), '999')           as S_IPI_CENQ                 , -- Bug 22179527 : IPI LEGAL FRAMING CODE - NT 2015-002
      decode(c.IPI_cst, '00', c.IPI_cst,
                       '49', c.IPI_cst,
                       '50', c.IPI_cst,
                       '99', c.IPI_cst, null)                              as S_IPITRIB_CST              ,
      decode(c.IPI_cst, '00', c.IPI_base,
                       '49', c.IPI_base,
                       '50', c.IPI_base,
                       '99', c.IPI_base, null)                             as N_IPITRIB_VBC              ,
      decode(c.IPI_cst, '00', c.IPI_aliq,
                       '49', c.IPI_aliq,
                       '50', c.IPI_aliq,
                       '99', c.IPI_aliq, null)                             as N_IPITRIB_PIPI             ,
      decode(c.IPI_cst, '00', nvl(c.IPI_base, a.quantity_invoiced),
                       '49', nvl(c.IPI_base, a.quantity_invoiced),
                       '50', nvl(c.IPI_base, a.quantity_invoiced),
                       '99', nvl(c.IPI_base, a.quantity_invoiced), null)   as N_IPITRIB_QUNID            ,
      decode(c.IPI_cst, '00', nvl(c.IPI_base, a.unit_price),
                       '49', nvl(c.IPI_base, a.unit_price),
                       '50', nvl(c.IPI_base, a.unit_price),
                       '99', nvl(c.IPI_base, a.unit_price), null)          as N_IPITRIB_VUNID            ,
      decode(c.IPI_cst, '00', c.IPI_vlr,
                       '49', c.IPI_vlr,
                       '50', c.IPI_vlr,
                       '99', c.IPI_vlr, null)                              as N_IPITRIB_VIPI             ,
                       --01, 02, 03, 04, 51, 52, 53, 54 e 55
      decode(c.IPI_cst, '01', c.IPI_cst, '02', c.IPI_cst, '55', c.IPI_cst,
                       '03', c.IPI_cst, '04', c.IPI_cst,
                       '51', c.IPI_cst, '52', c.IPI_cst,
                       '53', c.IPI_cst, '54', c.IPI_cst, null)             as S_IPINT_CST                ,
      c.II_base                                                            as N_II_VBC                   ,
      0                                                                    as N_II_VDESPADU              ,
      c.II_vlr                                                             as N_II_VII                   ,
      0                                                                    as N_II_VIOF                  ,
      c.pis_cst                                                            as N_PISALIQ_CST              ,
      decode(c.pis_cst, 1, c.pis_base, 2, c.pis_base, null)                as N_PISALIQ_VBC              ,
      decode(c.pis_cst, 1, c.pis_aliq, 2, c.pis_aliq, null)                as N_PISALIQ_PPIS             ,
      decode(c.pis_cst, 1, c.pis_vlr, 2, c.pis_vlr, null)                  as N_PISALIQ_VPIS             ,
      c.pis_cst                                                            as N_PISQTDE_CST              ,
      decode(c.pis_cst, 3, c.pis_base, null)                               as N_PISQTDE_QBCPROD          ,
      decode(c.pis_cst, 3, c.pis_aliq, null)                               as N_PISQTDE_VALIQPROD        ,
      decode(c.pis_cst, 3, c.pis_vlr, null)                                as N_PISQTDE_VPIS             ,
      c.pis_cst                                                            as N_PISNT_CST                ,
      c.pis_cst                                                            as N_PISOUTR_CST              ,
      decode(c.pis_cst, 99, c.pis_base, null)                              as N_PISOUTR_VBC              ,
      decode(c.pis_cst, 99, c.pis_aliq, null)                              as N_PISOUTR_PPIS             ,
      decode(c.pis_cst, 99, a.vl_item, null)                               as N_PISOUTR_QBCPROD          ,
      decode(c.pis_cst, 99, a.vl_item * c.pis_aliq, null)                  as N_PISOUTR_VALIQPROD        ,
      decode(c.pis_cst, 99, c.pis_vlr, null)                               as N_PISOUTR_VPIS             ,
      --COFINS
      c.cofins_cst                                                         as N_COFINSALIQ_CST           ,
             decode(c.cofins_cst, 1, c.cofins_base,
                                  2, c.cofins_base, null)                  as N_COFINSALIQ_VBC           ,
             decode(c.cofins_cst, 1, c.cofins_aliq,
                                  2, c.cofins_aliq, null)                  as N_COFINSALIQ_PCOFINS       ,
             decode(c.cofins_cst, 1, c.cofins_vlr,
                                  2, c.cofins_vlr, null)                   as N_COFINSALIQ_VCOFINS       ,
      c.cofins_cst                                                         as N_COFINSQTDE_CST           ,
      decode(c.cofins_cst, 3, c.cofins_base, null)                         as N_COFINSQTDE_QBCPROD       ,
      decode(c.cofins_cst, 3, c.cofins_aliq, null)                         as N_COFINSQTDE_VALIQPROD     ,
      decode(c.cofins_cst, 3, c.cofins_vlr, null)                          as N_COFINSQTDE_VCOFINS       ,
      c.cofins_cst                                                         as N_COFINSNT_CST             ,
      c.cofins_cst                                                         as N_COFINSOUTR_CST           ,
      decode(c.cofins_cst, 99, c.cofins_base, null)                        as N_COFINSOUTR_VBC           ,
      decode(c.cofins_cst, 99, c.cofins_aliq, null)                        as N_COFINSOUTR_PCOFINS       ,
      decode(c.cofins_cst, 99, a.vl_item, null)                            as N_COFINSOUTR_QBCPROD       ,
      decode(c.cofins_cst, 99, a.vl_item * c.cofins_aliq, null)            as N_COFINSOUTR_VALIQPROD     ,
      decode(c.cofins_cst, 99, c.cofins_vlr, null)                         as N_COFINSOUTR_VCOFINS       ,
      --ADI
      a.attribute12                                                        as N_NADICAO                  ,
      a.attribute13                                                        as N_NSEQADIC                 ,
      a.attribute14                                                        as S_CFABRICANTE              ,
      null                                                                 as N_VDESCDI                  ,
      --NT003_2015
      a.cest_code                                                          as N_CEST                     ,
      a.icms_dest_taxable_basis                                            as N_ICMS_VBCUFDEST           ,
      a.icms_poverty_rate                                                  as N_ICMS_PFCPUFDEST          ,
      a.icms_internal_rate                                                 as N_ICMS_PICMSUFDEST         ,
      a.icms_interstate_rate                                               as N_ICMCS_PICMSINTER         ,
      a.icms_share_percentage                                              as N_ICMCS_PICMSINTERPART     ,
      a.icms_poverty_tax                                                   as N_ICMCS_VFCPUFDEST         ,
      a.icms_tax_destnation                                                as N_ICMCS_VICMSUFDEST        ,
      a.icms_tax_origin                                                    as N_ICMCS_VICMSUFREMET
 from apps.CLL_F255_AR_INVOICE_ITEMS_V  a,
      apps.MTL_SYSTEM_ITEMS_B           b,
      XXISV.XXISV_MEFSY_NF_ITEM_IMPOSTOS          c
where a.organization_id           = b.organization_id
  and a.INVENTORY_ITEM_ID         = b.INVENTORY_ITEM_ID
  and a.org_id                    = c.org_id
  and a.customer_trx_id           = c.customer_trx_id
  and a.customer_trx_line_id      = c.customer_trx_line_id
;
