create or replace package XXISV_MECPC_DFE is
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_MEFPC_DFE
--NOME FISICO.........: XXISV_MEFPC_DFE.SQL
--TIPO_OBJETO.........: PACKAGE
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--CUSTOMIZACOES.......:
------------------------------------------------------------------------------------------------------------------------

    procedure generate_nf(p_transaction_id  in XXISV_MEFsy_nf_notification.transaction_id%type,
                          p_customer_trx_id in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                          p_org_id          in XXISV_MEFsy_nf_notification.org_id%type,
                          p_organization_id in XXISV_MEFsy_nf_notification.organization_id%type,
                          p_event_type_id   in XXISV_MEFsy_nf_notification.event_type_id%type);

    procedure generate_nfe(p_transaction_id  in XXISV_MEFsy_nf_notification.transaction_id%type,
                           p_customer_trx_id in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                           p_org_id          in XXISV_MEFsy_nf_notification.org_id%type,
                           p_organization_id in XXISV_MEFsy_nf_notification.organization_id%type,
                           p_event_type_id   in XXISV_MEFsy_nf_notification.event_type_id%type);

    procedure generate_nfe_cancelamento(p_transaction_id                  in XXISV_MEFsy_nf_notification.transaction_id%type,
                                        p_customer_trx_id_da_nota         in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                                        p_customer_trx_id_to_cancel       in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                                        p_org_id                          in XXISV_MEFsy_nf_notification.org_id%type,
                                        p_organization_id                 in XXISV_MEFsy_nf_notification.organization_id%type,
                                        p_event_type_id                   in XXISV_MEFsy_nf_notification.event_type_id%type);


    procedure generate_nfe_inutilizacao(p_transaction_id                  in XXISV_MEFsy_nf_notification.transaction_id%type,
                                        p_customer_trx_id_da_nota         in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                                        p_customer_trx_id_to_inuti        in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                                        p_org_id                          in XXISV_MEFsy_nf_notification.org_id%type,
                                        p_organization_id                 in XXISV_MEFsy_nf_notification.organization_id%type,
                                        p_event_type_id                   in XXISV_MEFsy_nf_notification.event_type_id%type);

    procedure generate_nfs(p_transaction_id  in XXISV_MEFsy_nf_notification.transaction_id%type,
                           p_customer_trx_id in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                           p_org_id          in XXISV_MEFsy_nf_notification.org_id%type,
                           p_organization_id in XXISV_MEFsy_nf_notification.organization_id%type,
                           p_event_type_id   in XXISV_MEFsy_nf_notification.event_type_id%type);

    procedure generate_nfs_cancelamento(p_transaction_id                  in XXISV_MEFsy_nf_notification.transaction_id%type,
                                        p_customer_trx_id_da_nota         in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                                        p_customer_trx_id_to_cancel       in XXISV_MEFsy_nf_notification.customer_trx_id%type,
                                        p_org_id                          in XXISV_MEFsy_nf_notification.org_id%type,
                                        p_organization_id                 in XXISV_MEFsy_nf_notification.organization_id%type,
                                        p_event_type_id                   in XXISV_MEFsy_nf_notification.event_type_id%type);

end XXISV_MECPC_DFE;
/
create or replace package body XXISV_MECPC_DFE  is
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_MEFPC_DFE
--NOME FISICO.........: XXISV_MEFPC_DFE.SQL
--TIPO_OBJETO.........: PACKAGE BODY
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--CUSTOMIZACOES.......:
--                    : JVP001 - 22/06/2020 - ALTERA��O PARA TRATAR NATUREZA DE OPERA��O MUNICIPIO DE BARUERI
--                    : JVP002 - 30/06/2020 - TRATAMENTO LEI DA TRANSPARENCIA
--                    : JVP003 - 05/08/2020 - TRATAMENTO VLR_SERVICO QUE ESTVAM RETORNANDO "0"
------------------------------------------------------------------------------------------------------------------------

    function clean_delimiters(p_entrada in varchar2 ) return varchar2 is
      v_retorno  varchar2(4000);
    begin
      v_retorno := replace(replace(replace(p_entrada,'.',''),'-',''),'/','');
      return v_retorno;
    end;

    function get_ibge_codes(p_location_id in number, p_entity in varchar2) return number is
      v_identifier_value        varchar2(4000);
      v_IBGE_CODE_SUBTYPE       varchar2(4000);
    begin

      select S_IBGE_CODE_SUBTYPE into v_IBGE_CODE_SUBTYPE
      from XXISV_MEFSY_CONFIG;

      SELECT identifier_value
      INTO v_identifier_value
      FROM
            apps.hz_geography_identifiers geo_ident,
            apps.hz_geo_name_references geo_ref,
            apps.hr_locations loc
      WHERE
            loc.location_id = p_location_id
          and loc.location_id = geo_ref.location_id
          and geo_ref.geography_type = p_entity
          and geo_ident.identifier_subtype = v_IBGE_CODE_SUBTYPE
          and geo_ident.geography_id = geo_ref.geography_id
          and geo_ident.geography_type = p_entity; -- 'COUNTRY', 'STATE', 'CITY',

      return v_identifier_value;
    exception
      when no_data_found then
        begin
          SELECT identifier_value
          INTO v_identifier_value
          FROM
                apps.hz_geography_identifiers geo_ident,
                apps.hz_geo_name_references geo_ref,
                apps.hz_locations loc
          WHERE
                loc.location_id = p_location_id
              and loc.location_id = geo_ref.location_id
              and geo_ref.geography_type = p_entity
              and geo_ident.identifier_subtype = v_IBGE_CODE_SUBTYPE
              and geo_ident.geography_id = geo_ref.geography_id
              and geo_ident.geography_type = p_entity; -- 'COUNTRY', 'STATE', 'CITY',

           return v_identifier_value;
         exception
           when no_data_found then
             return null;
         end;
         return v_identifier_value;
    end;
    --

    -- claudio santos 02-10-2019

    -- Nova fun��o criada para retornar o codigo ibge do tomador
    function get_ibge_codes_tomador(p_location_id in number, p_entity in varchar2) return number is
      v_identifier_value        varchar2(4000);
      v_IBGE_CODE_SUBTYPE       varchar2(4000);
    begin

      select S_IBGE_CODE_SUBTYPE into v_IBGE_CODE_SUBTYPE
      from XXISV_MEFSY_CONFIG;

      SELECT identifier_value
      INTO v_identifier_value
      FROM
            apps.hz_geography_identifiers geo_ident,
            apps.hz_geo_name_references geo_ref
           -- apps.hr_locations loc
      WHERE
            geo_ref.location_id = p_location_id
         -- and loc.location_id = geo_ref.location_id
          and geo_ref.geography_type = p_entity
          and geo_ident.identifier_subtype = v_IBGE_CODE_SUBTYPE
          and geo_ident.geography_id = geo_ref.geography_id
          and geo_ident.geography_type = p_entity; -- 'COUNTRY', 'STATE', 'CITY',

      return v_identifier_value;
    exception
      when no_data_found then
        begin
         v_identifier_value :=null;
         return v_identifier_value;
    end;

    end;
    --

    -- Nova funcao customizada para retornar codigo do municipio do prestador
    function get_ibge_codes_muni(p_establishment_id in varchar2) return number is
      v_identifier_value        varchar2(4000);
      v_IBGE_CODE_SUBTYPE       varchar2(4000);
    begin

     select   a.etb_information1 into v_identifier_value
        from  apps.xle_etb_profiles a
        where a.establishment_id= p_establishment_id and rownum <2;
      return v_identifier_value;
    exception
      when no_data_found then
        v_identifier_value:='';

         return v_identifier_value;
    end;
    --
    function get_standard_codes(p_location_id in number, p_entity in varchar2) return varchar2 is
      v_identifier_value        varchar2(4000);
    begin
      begin
        SELECT identifier_value
        INTO v_identifier_value
        FROM
              apps.hz_geography_identifiers geo_ident,
              apps.hz_geo_name_references geo_ref,
              apps.hr_locations loc
        WHERE
              loc.location_id = p_location_id
            and loc.location_id = geo_ref.location_id
            and geo_ref.geography_type = p_entity
            and geo_ident.identifier_subtype = 'STANDARD_NAME'
            and geo_ident.geography_id = geo_ref.geography_id
            and geo_ident.geography_type = p_entity; -- 'COUNTRY', 'STATE', 'CITY',
      exception
        when no_data_found then
          begin
            SELECT identifier_value
            INTO v_identifier_value
            FROM
                  apps.hz_geography_identifiers geo_ident,
                  apps.hz_geo_name_references geo_ref,
                  apps.hz_locations loc
            WHERE
                  loc.location_id = p_location_id
                and loc.location_id = geo_ref.location_id
                and geo_ref.geography_type = p_entity
                and geo_ident.identifier_subtype = 'STANDARD_NAME'
                and geo_ident.geography_id = geo_ref.geography_id
                and geo_ident.geography_type = p_entity; -- 'COUNTRY', 'STATE', 'CITY',

           exception
             when no_data_found then
               return null;
           end;
       end;

       if v_identifier_value = 'Brazil' then --precisa analisar o campo language na hora de fazer a consulta
         v_identifier_value := 'Brasil';     --nesse ambiente nao tem valores para outras linguas alem de US
       end if;

       return v_identifier_value;
    end;

    procedure clean_old_data(P_CUSTOMER_TRX_ID in xxisv_mefsy_nf_notification.customer_trx_id%type) AS
    BEGIN

      delete from xxisv_mefsy_nfs_header a where a.customer_trx_id = p_customer_trx_id;
      delete from xxisv_mefsy_nfs_item a where a.customer_trx_id = p_customer_trx_id;
      delete from xxisv_mefsy_nfs_cancelamento a where a.customer_trx_id = p_customer_trx_id;

      delete from xxisv_mefsy_nfe_header a where a.customer_trx_id = p_customer_trx_id;
      delete from xxisv_mefsy_nfe_cancelamento a where a.customer_trx_id = p_customer_trx_id;
      delete from xxisv_mefsy_nfe_inutilizacao a where a.customer_trx_id = p_customer_trx_id;
      commit;

    end;

    procedure generate_nfe(p_transaction_id  in xxisv_mefsy_nf_notification.transaction_id%type,
                           p_customer_trx_id in xxisv_mefsy_nf_notification.customer_trx_id%type,
                           p_org_id          in xxisv_mefsy_nf_notification.org_id%type,
                           p_organization_id in xxisv_mefsy_nf_notification.organization_id%type,
                           p_event_type_id   in xxisv_mefsy_nf_notification.event_type_id%type) as

      r_cll_f255_ar_invoices_v     apps.cll_f255_ar_invoices_v%rowtype;
      r_cll_f255_establishment_v   apps.cll_f255_establishment_v%rowtype;
      r_cll_f255_ar_customers_v    apps.cll_f255_ar_customers_v%rowtype;
      header                       xxisv_mefsy_nfe_header%rowtype;
      dup                          xxisv_mefsy_nfe_dup%rowtype;
      reb                          xxisv_mefsy_nfe_reb%rowtype;
      vol                          xxisv_mefsy_nfe_vol%rowtype;
      vol_lacres                   xxisv_mefsy_nfe_vol_lacres%rowtype;
      item                         xxisv_mefsy_nfe_item%rowtype;
      di                           xxisv_mefsy_nfe_item_di%rowtype;
      adi                          xxisv_mefsy_nfe_item_adi%rowtype;
      config                       xxisv_mefsy_config%rowtype;

      v_warehouse_cnpj             apps.cll_f255_ar_invoice_items_v.warehouse_cnpj%type;
      v_warehouse_ie               apps.cll_f255_ar_invoice_items_v.warehouse_ie%type;

    begin

      select *
        into r_cll_f255_ar_invoices_v
        from apps.cll_f255_ar_invoices_v a
       where a.customer_trx_id = p_customer_trx_id
         and a.org_id          = p_org_id;

      header.customer_trx_id := p_customer_trx_id;
      header.transaction_id  := p_transaction_id;
--     header.n_versao        := 2; --config
--     header.n_tpamb         := 2; --config 2 - homol, 1 - prod
      header.s_id            := r_cll_f255_ar_invoices_v.electronic_inv_access_key;
      header.s_natop         := substr(trim(replace(r_cll_f255_ar_invoices_v.description,'|',' ')), 1, 60);
      header.s_mod           := '55';
      header.n_nnf           := r_cll_f255_ar_invoices_v.trx_number;
      header.n_serie         := r_cll_f255_ar_invoices_v.series;
      header.d_demi          := r_cll_f255_ar_invoices_v.trx_date;

      select *
        into config
       from xxisv_mefsy_config;

     header.n_versao        := config.N_VERSAO;
     header.n_tpamb         := config.N_TPAMB;
     header.n_tpimp         := config.n_tpimp;
     header.n_tpemis        := config.n_tpemis;
     header.n_finnfe        := r_cll_f255_ar_invoices_v.TYPE_GLOBAL_ATTRIBUTE5; --     header.n_finnfe        := config.n_finnfe; CH26143/2014
     header.n_procemi       := config.n_procemi;
     header.s_verproc       := config.s_verproc;

      begin
        select decode(max(due_days), 0, 0, 1)
          into header.n_indpag
          from apps.ra_terms_lines
         where term_id = r_cll_f255_ar_invoices_v.term_id;
      exception
        when no_data_found then
          null;
      end;

      select decode(r_cll_f255_ar_invoices_v.movement_in_out, 'ENTRY', 0, 1)
        into header.n_tpnf
       from dual;

--      header.n_tpimp   := 1; --config retrato paisagem
--      header.n_tpemis  := 1;
--      header.n_finnfe  := 1;
--      header.n_procemi := 3; --config
--      header.s_verproc := '3.0'; --config

      select xxisv_mefsq_nfe_cnf.nextval + 10000000
        into header.n_cnf
       from dual;

      -- emitente
      begin
        select warehouse_cnpj, warehouse_ie                   -- 10169/2014
          into v_warehouse_cnpj, v_warehouse_ie
          from apps.cll_f255_ar_invoice_items_v
         where customer_trx_id = p_customer_trx_id
           and org_id          = p_org_id
           and line_type       = 'LINE'
           and rownum          = 1;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao foi possivel encontrar o CNPJ da linha customer_trx_id='||p_customer_trx_id||' e org_id='||p_org_id);
      end;

      begin
        select a.*
          into r_cll_f255_establishment_v
          from apps.cll_f255_establishment_v a
         where a.registration_number = v_warehouse_cnpj       -- 10169/2014
           and rownum                = 1;
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o estabelecimento atraves do CNPJ '||v_warehouse_cnpj);
      end;

      header.n_cuf     := get_ibge_codes(r_cll_f255_establishment_v.location_id, 'STATE');
      header.n_cmunfg  := get_ibge_codes(r_cll_f255_establishment_v.location_id, 'CITY');

      header.s_emit_cnpj    := substr(r_cll_f255_establishment_v.registration_number,-14);
      header.s_emit_cpf     := '00000000000';
      --header.s_emit_xnome   := r_cll_f255_establishment_v.establishment_name;
      header.s_emit_xnome   := substr(r_cll_f255_establishment_v.establishment_name, 0, 60);--alterado - claudio santos 25/09/2019
      header.s_emit_xfant   := r_cll_f255_establishment_v.entity_name;
      header.s_emit_lgr     := r_cll_f255_establishment_v.address_line_1;
      header.s_emit_nro     := r_cll_f255_establishment_v.address_line_2;
      header.s_emit_xcpl    := r_cll_f255_establishment_v.address_line_3;
      header.s_emit_xbairro := r_cll_f255_establishment_v.region_1;
      header.n_emit_cmun    := header.n_cmunfg;
      header.s_emit_xmun    := r_cll_f255_establishment_v.town_or_city;
      header.s_emit_uf      := r_cll_f255_establishment_v.region_2;
      header.n_emit_cep     := regexp_replace(r_cll_f255_establishment_v.postal_code, '[^0-9]', '');
      header.n_emit_cpais   := get_ibge_codes(r_cll_f255_establishment_v.location_id, 'COUNTRY');
      header.s_emit_xpais   := get_standard_codes(r_cll_f255_establishment_v.location_id, 'COUNTRY');--r_cll_f255_establishment_v.country;
      header.n_emit_fone    := substr(regexp_replace(r_cll_f255_establishment_v.telephone_number_1,'[^0-9]',''), 1, 14);
      header.s_emit_fone    := substr(regexp_replace(r_cll_f255_establishment_v.telephone_number_1,'[^0-9]',''), 1, 14);
      header.s_emit_ie      := clean_delimiters(v_warehouse_ie);
      header.s_infcpl       := null; --25131/2014
      if substr(v_warehouse_ie, 1, 6) = 'ISENTO' then
         header.s_emit_ie   := 'ISENTO';
      end if;

      header.s_emit_iest    := null;
      header.s_emit_im      := null;
      header.s_emit_cnae    := null;
      header.s_emit_crt     := 3;

      -- destinatario
     begin
      select *
        into r_cll_f255_ar_customers_v
        from apps.cll_f255_ar_customers_v c
       where r_cll_f255_ar_invoices_v.ship_to_site_use_id  = c.site_use_id
       and rownum = 1; --CH26770/2014
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o destinatario atraves do ship_to_site_use_id '||r_cll_f255_ar_invoices_v.ship_to_site_use_id);
      end;

      header.s_dest_xnome   := trim(substr(r_cll_f255_ar_customers_v.customer_name, 1, 60));
      header.s_dest_xlgr    := r_cll_f255_ar_customers_v.address1;
      header.s_dest_nro     := r_cll_f255_ar_customers_v.address2;
      header.s_dest_xcpl    := r_cll_f255_ar_customers_v.address3;
      header.s_dest_xbairro := r_cll_f255_ar_customers_v.address4;
      header.s_dest_cpais   := get_ibge_codes(r_cll_f255_ar_customers_v.location_id, 'COUNTRY');
      header.s_dest_xpais   := get_standard_codes(r_cll_f255_ar_customers_v.location_id, 'COUNTRY');--r_cll_f255_ar_customers_v.country;
      header.s_dest_isuf    := null;
      header.n_dest_indiedest := r_cll_f255_ar_customers_v.global_attribute13; --CH6656/2015

    begin
      header.s_dest_uf := r_cll_f255_ar_customers_v.state;
    exception
    when others then
      header.s_dest_uf := null;
    end; -- 12799/2016

      if header.n_emit_cpais = header.s_dest_cpais then
        header.s_dest_cmun    := get_ibge_codes(r_cll_f255_ar_customers_v.location_id, 'CITY');
        header.s_dest_xmun    := r_cll_f255_ar_customers_v.city;
        header.s_dest_cep     := regexp_replace(r_cll_f255_ar_customers_v.postal_code, '[^0-9]', '');
        select decode(r_cll_f255_ar_customers_v.document_type, 'CNPJ', substr(regexp_replace(r_cll_f255_ar_customers_v.document_number,'[^0-9]', ''), -14), '00000000000000'),
               decode(r_cll_f255_ar_customers_v.document_type, 'CPF', substr(regexp_replace(r_cll_f255_ar_customers_v.document_number,'[^0-9]', ''), -11), '00000000000'),
               decode(r_cll_f255_ar_customers_v.document_type, 'CPF', 'ISENTO', r_cll_f255_ar_customers_v.ie)
          into header.s_dest_cnpj,
               header.s_dest_cpf,
               header.s_dest_ie
          from dual;
        header.s_dest_ie := clean_delimiters(header.s_dest_ie);
      else
        header.s_dest_uf   := 'EX';
        header.s_dest_xmun := 'EXTERIOR';
        header.s_dest_cep  := '99999999';
        header.s_dest_cmun := 9999999;
        header.s_dest_ie   := 'ISENTO';
        header.s_dest_cnpj := '00000000000000';
        header.s_dest_cpf  := '00000000000';
      end if;
      begin
        select substr(regexp_replace(area_code||phone_number,'[^0-9]',''), 1, 14) --25094/2015
          into header.s_dest_fone
          from apps.ar_phones_v
         where owner_table_id     = r_cll_f255_ar_customers_v.party_site_id
           and contact_point_type = 'PHONE'
           and trim(phone_number) is not null
           and rownum = 1
           and status = 'A';
      exception
         when no_data_found then
           null;
      end;

      begin
        select substr(regexp_replace(area_code||phone_number,'[^0-9]',''), 1, 14) --CH_16520_2016 Prefixo N em N_DEST_FONE mas o campo eh VARCHAR2
          into header.n_dest_fone
          from apps.ar_phones_v
         where owner_table_id     = r_cll_f255_ar_customers_v.party_site_id
           and contact_point_type = 'PHONE'
           and trim(phone_number) is not null
           and rownum = 1
           and status = 'A';
      exception
         when no_data_found then
           null;
      end;

      begin
        /*select email_address
          into header.s_dest_email
          from apps.ar_phones_v
         where owner_table_id     = r_cll_f255_ar_customers_v.party_site_id
           and contact_point_type = 'EMAIL'
           --and owner_table_name   = 'HZ PARTIES'
           and trim(email_address) is not null
             and rownum = 1;*/
             --alteracao por solicitacao da stone 04/12/2019
              select email_address
                into header.s_dest_email
                from apps.ar_phones_v
               where 1=1
                 and owner_table_id      = r_cll_f255_ar_customers_v.party_site_id
                 and contact_point_type = 'EMAIL'
                 and owner_table_name   = 'HZ_PARTY_SITES'
                 and trim(email_address) is not null
                 and status = 'A'
                 and rownum = 1;
      exception
         when no_data_found then
           null;
      end;

      -- transportadora
      begin
        select substr(lpad(decode(ssa.global_attribute9,2,(substr(ssa.global_attribute10,2)||ssa.global_attribute11||ssa.global_attribute12),'0'),14,'0'),0,14),
               substr(lpad(decode(ssa.global_attribute9,1,(ssa.global_attribute10||ssa.global_attribute12),'0'),11,'0'),0,11),
               substr(trim(vendor_name),0,60),
               substr(regexp_replace(ssa.global_attribute13,'[^0-9]',''),0,14),  -- header.s_transp_ie,
               substr(trim(address_line1),0,60),
               substr(trim(city),0,60),
               substr(trim(state),0,2)
          --
          into header.s_transp_cnpj,
               header.s_transp_cpf,
               header.s_transp_xnome,
               header.s_transp_ie,
               header.s_transp_xender,
               header.s_transp_xmun,
               header.s_transp_uf
          from apps.ap_suppliers s,
               apps.ap_supplier_sites_all ssa
         where s.vendor_id = r_cll_f255_ar_invoices_v.carrier_id
           and ssa.vendor_site_id = r_cll_f255_ar_invoices_v.carrier_site_id
           and ssa.vendor_id = s.vendor_id;
      exception
        when no_data_found then
          null;
      end;

      begin
        select DECODE(r_cll_f255_ar_invoices_v.fob_point, 'CIF', 1, 'FOB', 0, 9)
          into header.n_transp_modfrete
        from dual;
      exception
        when others then
          header.n_transp_modfrete := null;
      end;

      header.s_transp_placa       := r_cll_f255_ar_invoices_v.license_plate;
      header.s_transp_placa_uf    := r_cll_f255_ar_invoices_v.vehicle_plate_state_code;

      -- totais
      header.n_tot_icms_vbc       := 0;
      header.n_tot_icms_vicms     := 0;
      header.n_tot_icms_vfcpufdest   := null;
      header.n_tot_icms_vicmsufdest   := null;
      header.n_tot_icms_vicmsufremet := null;
      header.n_tot_icms_vbcst     := 0;
      header.n_tot_icms_vst       := 0;
      header.n_tot_icms_vprod     := 0;
      header.n_tot_icms_vfrete    := nvl(to_number(r_cll_f255_ar_invoices_v.vl_freight,'FM999999999999D99', 'NLS_NUMERIC_CHARACTERS = ''.,'''), 0);
      header.n_tot_icms_vseg      := nvl(to_number(r_cll_f255_ar_invoices_v.insurance_value,'FM999999999999D99', 'NLS_NUMERIC_CHARACTERS = ''.,'''), 0);
      header.n_tot_icms_vdesc     := 0;
      header.n_tot_icms_vii       := 0;
      header.n_tot_icms_vipi      := 0;
      header.n_tot_icms_vpis      := 0;
      header.n_tot_icms_vcofins   := 0;
      header.n_tot_icms_voutro    := nvl(to_number(r_cll_f255_ar_invoices_v.vl_others,'FM999999999999D99', 'NLS_NUMERIC_CHARACTERS = ''.,'''), 0);
      header.n_tot_icms_vnf       := 0;
      header.n_tot_icms_vicmsdeson := 0; --CH19635/2014
      header.n_tot_tottrib        := 0;

      header.n_tot_issqn_vserv    := null;
      header.n_tot_issqn_vbc      := null;
      header.n_tot_issqn_viss     := null;
      header.n_tot_issqn_vpis     := null;
      header.n_tot_issqn_vcofins  := null;
      header.d_tot_issqn_dcompet  := null; -- 3.10
      header.n_tot_issqn_vdeducao := null; -- 3.10
      header.n_tot_issqn_voutro   := null; -- 3.10
      header.n_tot_issqn_vdescincond := null; -- 3.10
      header.n_tot_issqn_vdesccond   := null; -- 3.10
      header.n_tot_issqn_vissret     := null; -- 3.10
      header.n_tot_issqn_cregtrib    := null; -- 3.10
      header.n_tot_ret_vretpis    := null;
      header.n_tot_ret_vretcofins := null;
      header.n_tot_ret_vretcsll   := null;
      header.n_tot_ret_vbcirrf    := null;
      header.n_tot_ret_virrf      := null;
      header.n_tot_ret_vbcretprev := null;
      header.n_tot_ret_vretprev   := null;

      -- cobranca fatura
      begin
        select e1.trx_number,
               to_number(e1.amount_due_original,'FM999999999999D99', 'NLS_NUMERIC_CHARACTERS = ''.,'''),
               to_number(e1.amount_due_original,'FM999999999999D99', 'NLS_NUMERIC_CHARACTERS = ''.,''')
          into header.s_cobr_fat_nfat,
               header.n_cobr_fat_vliq,
               header.n_cobr_fat_vorig
          from apps.ar_payment_schedules_all e1
         where e1.customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
           and e1.org_id          = r_cll_f255_ar_invoices_v.org_id
           and (customer_trx_id,org_id) IN (SELECT customer_trx_id, org_id
                                              FROM apps.ra_customer_trx_all
                                             WHERE  complete_flag = 'Y')
           and rownum <= 1;
      exception
        when no_data_found then
          null;
      end;

      -- mapeamento novos campos layout 3.10
      if header.s_dest_uf = 'EX' then
        header.n_iddest          := 3; -- Opera��������o com exterior
      elsif header.s_dest_uf != header.s_emit_uf then
        header.n_iddest          := 2; -- Opera��������o interestadual
      else
        header.n_iddest          := 1; -- Opera��������o interna
      end if;

      header.n_indfinal          := 0; -- 0- N����o; 1- Consumidor final;
      header.n_indpres           := 9; -- Nao presencial

      -- ambiente de homologacao
      if header.n_tpamb = 2 then
        header.s_dest_xnome := 'NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL';
      end if;

      -- identifica��������o do usu������rio no printer
      header.s_printer_ds_impressora    := r_cll_f255_ar_invoices_v.attribute8;
      header.s_printer_ordem_embarque   := r_cll_f255_ar_invoices_v.attribute9;
      header.s_printer_usuario_emitente := r_cll_f255_ar_invoices_v.attribute10;

      -- inserindo informacoes do header da nota fiscal
      insert into xxisv_mefsy_nfe_header values header;

      -- duplicata
      for r_dados_duplicata in (select a.customer_trx_id                  as customer_trx_id   ,
                                       a.trx_number                       as s_nfat            ,
                                       nvl(a.terms_sequence_number,
                                           a.payment_schedule_id )        as s_ndup            ,
                                       a.due_date                         as d_dvenc           ,
                                       a.amount_line_items_remaining      as n_vdup
                                  from apps.ar_payment_schedules_all a
                                 where a.customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
                                   and a.org_id          = r_cll_f255_ar_invoices_v.org_id)
      loop

        dup.customer_trx_id := r_cll_f255_ar_invoices_v.customer_trx_id;
        dup.s_nfat          := r_dados_duplicata.S_NFAT;
        dup.s_ndup          := r_dados_duplicata.S_NDUP;
        dup.d_dvenc         := r_dados_duplicata.D_DVENC;
        dup.n_vdup          := r_dados_duplicata.N_VDUP;

        insert into xxisv_mefsy_nfe_dup values dup;

      end loop;

      -- reboque
      if r_cll_f255_ar_invoices_v.TOWING_VEH_PLATE_NUMBER is not null then

         reb.customer_trx_id := r_cll_f255_ar_invoices_v.customer_trx_id;
         reb.S_PLACA         := r_cll_f255_ar_invoices_v.TOWING_VEH_PLATE_NUMBER;
         reb.S_UF            := r_cll_f255_ar_invoices_v.TOWING_VEH_PLATE_STATE_CODE;
         reb.S_RNTC          := r_cll_f255_ar_invoices_v.TOWING_VEH_ANTT_INSCRIPTION;

         insert into xxisv_mefsy_nfe_reb values reb;

      end if;

      --if r_cll_f255_ar_invoices_v.bulk_number is not null and r_cll_f255_ar_invoices_v.bulk_number <> 0 then

        vol.customer_trx_id    := r_cll_f255_ar_invoices_v.customer_trx_id;
        vol.n_numvol           := 1;
        vol.n_qvol             := r_cll_f255_ar_invoices_v.bulk;
        vol.s_esp              := r_cll_f255_ar_invoices_v.species_turnover;
        vol.s_marca            := r_cll_f255_ar_invoices_v.species_turnover;
        vol.s_nvol             := r_cll_f255_ar_invoices_v.bulk_number;
        vol.n_pesol            := r_cll_f255_ar_invoices_v.net_weight;
        vol.n_pesob            := r_cll_f255_ar_invoices_v.weight;

        insert into xxisv_mefsy_nfe_vol values vol;

        if r_cll_f255_ar_invoices_v.seal_number is not null then

          vol_lacres.customer_trx_id    := r_cll_f255_ar_invoices_v.customer_trx_id;
          vol_lacres.n_numvol           := 1;
          vol_lacres.s_nlacre           := r_cll_f255_ar_invoices_v.seal_number;

          insert into xxisv_mefsy_nfe_vol_lacres values vol_lacres;

        end if;

      --end if;

      --
      -- ITEM
      --
      for r_dados_item in (select *
                             from xxisv_mefsy_nf_item --12688/2016
                            where customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
                              and org_id          = r_cll_f255_ar_invoices_v.org_id)

      loop
          item.customer_trx_id           := r_dados_item.customer_trx_id;
          item.n_nitem                   := r_dados_item.n_nitem;
          item.s_cprod                   := r_dados_item.s_cprod;
          item.s_xprod                   := trim(substr(r_dados_item.s_xprod,0,120));
          item.s_ncm                     := r_dados_item.s_ncm;
          item.n_cest                    := r_dados_item.n_cest; --NT2015_003
          item.n_cfop                    := to_number(replace(replace(to_char(r_dados_item.n_cfop),'.',''),',',''));
          item.s_ucom                    := substr(NVL(r_dados_item.s_ucom_ptb, r_dados_item.s_ucom),0,6); -- 10278/2014 --16240/2017
          item.n_qcom                    := r_dados_item.n_qcom;
          item.n_vuncom                  := r_dados_item.n_vuncom;
          item.n_vprod                   := r_dados_item.n_vprod;
          item.s_utrib                   := substr(NVL(r_dados_item.s_utrib_ptb, r_dados_item.s_utrib),0,6); -- 10278/2014 --16240/2017
          item.n_qtrib                   := r_dados_item.n_qtrib;
          item.n_vuntrib                 := r_dados_item.n_vuntrib;
          item.n_indtot                  := r_dados_item.n_indtot;
          item.n_vtottrib                := r_dados_item.n_vtottrib;
          item.n_icms_orig               := r_dados_item.n_icms_orig;
          item.n_icms_cst                := r_dados_item.n_icms_cst;
          item.n_icms_modbc              := r_dados_item.n_icms_modbc;
          item.n_icms_vbc                := r_dados_item.n_icms_vbc;
          item.n_icms_picms              := r_dados_item.n_icms_picms;
          item.n_icms_vicms              := r_dados_item.n_icms_vicms;
          item.n_icms_modbcst            := null;
          item.n_icms_vbcst              := nvl(r_dados_item.n_icms_vbcst, 0);   --25234/2014
          item.n_icms_picmsst            := nvl(r_dados_item.n_icms_picmsst, 0); --25234/2014
          item.n_icms_vicmsst            := r_dados_item.n_icms_vicmsst;
          item.n_icmsst_cst              := r_dados_item.n_icmsst_cst;
          item.n_icms_vbcstret           := 0;
          item.n_icms_vicmsstret         := 0;
          item.n_icmsst_vbcstdest        := 0;
          item.n_icmsst_vbcstret         := 0;
          item.n_icmsst_pst              := null;  --NT2018.005v1.20
          item.n_icmsst_vicmssubstituto  := null;  --NT2018.005v1.20
          item.n_icmsst_vicmsstret       := 0;
          item.n_icmsst_vbcfcpstret      := null;  --NT2018.005v1.20
          item.n_icmsst_pfcpstret        := null;  --NT2018.005v1.20
          item.n_icmsst_vfcpstret        := null;  --NT2018.005v1.20
          item.n_icmsst_vicmsstdest      := 0;
          item.n_icmsst_predbcefet       := null;  --NT2018.005v1.20
          item.n_icmsst_vbcefet          := null;  --NT2018.005v1.20
          item.n_icmsst_picmsefet        := null;  --NT2018.005v1.20
          item.n_icmsst_vicmsefet        := null;  --NT2018.005v1.20
          item.n_icms_vbcufdest          := r_dados_item.n_icms_vbcufdest;             --NT2015_003
          item.n_icms_pfcpufdest         := r_dados_item.n_icms_pfcpufdest;            --NT2015_003
          item.n_icms_picmsufdest        := r_dados_item.n_icms_picmsufdest;           --NT2015_003
          item.n_icmcs_picmsinter        := r_dados_item.n_icmcs_picmsinter;           --NT2015_003
          item.n_icmcs_picmsinterpart    := r_dados_item.n_icmcs_picmsinterpart;       --NT2015_003
          item.n_icmcs_vfcpufdest        := r_dados_item.n_icmcs_vfcpufdest;           --NT2015_003
          item.n_icmcs_vicmsufdest       := r_dados_item.n_icmcs_vicmsufdest;          --NT2015_003
          item.n_icmcs_vicmsufremet      := r_dados_item.n_icmcs_vicmsufremet;         --NT2015_003
          item.n_icms_predbcefet         := null; --NT2016.002v1.60
          item.n_icms_vbcefet            := null; --NT2016.002v1.60
          item.n_icms_picmsefet          := null; --NT2016.002v1.60
          item.n_icms_vicmsefet          := null; --NT2016.002v1.60
          item.n_icms_vicmssubstituto    := null; --NT2018.005v1.20
          item.s_ipi_cenq                := substr(r_dados_item.s_ipi_cenq, 1, 3);     -- Bug 22179527 : IPI LEGAL FRAMING CODE - NT 2015-002
          item.s_ipitrib_cst             := r_dados_item.s_ipitrib_cst;
          item.n_ipitrib_vbc             := r_dados_item.n_ipitrib_vbc;
          item.n_ipitrib_pipi            := r_dados_item.n_ipitrib_pipi;
          item.n_ipitrib_qunid           := r_dados_item.n_ipitrib_qunid;
          item.n_ipitrib_vunid           := r_dados_item.n_ipitrib_vunid;
          item.n_ipitrib_vipi            := r_dados_item.n_ipitrib_vipi;
          item.s_ipint_cst               := r_dados_item.s_ipint_cst;
          item.n_ii_vbc                  := r_dados_item.n_ii_vbc;
          item.n_ii_vdespadu             := r_dados_item.n_ii_vdespadu;
          item.n_ii_vii                  := r_dados_item.n_ii_vii;
          item.n_ii_viof                 := r_dados_item.n_ii_viof;
          item.n_pisaliq_cst             := r_dados_item.n_pisaliq_cst;
          item.n_pisaliq_vbc             := r_dados_item.n_pisaliq_vbc;
          item.n_pisaliq_ppis            := r_dados_item.n_pisaliq_ppis;
          item.n_pisaliq_vpis            := r_dados_item.n_pisaliq_vpis;
          item.n_pisqtde_cst             := r_dados_item.n_pisqtde_cst;
          item.n_pisqtde_qbcprod         := r_dados_item.n_pisqtde_qbcprod;
          item.n_pisqtde_valiqprod       := r_dados_item.n_pisqtde_valiqprod;
          item.n_pisqtde_vpis            := r_dados_item.n_pisqtde_vpis;
          item.n_pisnt_cst               := r_dados_item.n_pisnt_cst;
          item.n_pisoutr_cst             := r_dados_item.n_pisoutr_cst;
          item.n_pisoutr_vbc             := r_dados_item.n_pisoutr_vbc;
          item.n_pisoutr_ppis            := r_dados_item.n_pisoutr_ppis;
          item.n_pisoutr_qbcprod         := r_dados_item.n_pisoutr_qbcprod;
          item.n_pisoutr_valiqprod       := r_dados_item.n_pisoutr_valiqprod;
          item.n_pisoutr_vpis            := r_dados_item.n_pisoutr_vpis;
          item.n_cofinsaliq_cst          := r_dados_item.n_cofinsaliq_cst;
          item.n_cofinsaliq_vbc          := r_dados_item.n_cofinsaliq_vbc;
          item.n_cofinsaliq_pcofins      := r_dados_item.n_cofinsaliq_pcofins;
          item.n_cofinsaliq_vcofins      := r_dados_item.n_cofinsaliq_vcofins;
          item.n_cofinsqtde_cst          := r_dados_item.n_cofinsqtde_cst;
          item.n_cofinsqtde_qbcprod      := r_dados_item.n_cofinsqtde_qbcprod;
          item.n_cofinsqtde_valiqprod    := r_dados_item.n_cofinsqtde_valiqprod;
          item.n_cofinsqtde_vcofins      := r_dados_item.n_cofinsqtde_vcofins;
          item.n_cofinsnt_cst            := r_dados_item.n_cofinsnt_cst;
          item.n_cofinsoutr_cst          := r_dados_item.n_cofinsoutr_cst;
          item.n_cofinsoutr_vbc          := r_dados_item.n_cofinsoutr_vbc;
          item.n_cofinsoutr_pcofins      := r_dados_item.n_cofinsoutr_pcofins;
          item.n_cofinsoutr_qbcprod      := r_dados_item.n_cofinsoutr_qbcprod;
          item.n_cofinsoutr_valiqprod    := r_dados_item.n_cofinsoutr_valiqprod;
          item.n_cofinsoutr_vcofins      := r_dados_item.n_cofinsoutr_vcofins;
          item.S_INFADPROD               := null;                    --CH25131/2014
          item.N_VDESC                   := 0;                       --CH25241/2014
          item.n_voutro                  := null;

          begin
            select nvl(io.ICMS_PREDBC, 0)
                 into item.N_ICMS_PREDBC
              from xxisv_mefsy_nf_item_impostos io  --12688/2016
             where customer_trx_id      = r_dados_item.customer_trx_id
               and org_id               = r_dados_item.org_id -- 25403/2015
               and CUSTOMER_TRX_LINE_ID = r_dados_item.CUSTOMER_TRX_LINE_ID; -- 3082/2016
          exception
            when no_data_found then
              item.N_ICMS_PREDBC := null;
          end;

          -- inserindo valores items
          insert into xxisv_mefsy_nfe_item values item;

          -- Informacoes DI e ADI
          if r_cll_f255_ar_invoices_v.attribute10 is not null and r_dados_item.N_NADICAO is not null then

              di.customer_trx_id           := item.customer_trx_id;
              di.n_nitem                   := item.n_nitem;
              di.s_ndi                     := r_cll_f255_ar_invoices_v.attribute10;
              di.d_ddi                     := to_date(r_cll_f255_ar_invoices_v.attribute11, 'yyyy/mm/dd hh24:mi:ss');
              di.s_xlocdesemb              := r_cll_f255_ar_invoices_v.attribute12;
              di.s_ufdesemb                := r_cll_f255_ar_invoices_v.attribute13;
              di.d_ddesemb                 := to_date(r_cll_f255_ar_invoices_v.attribute14, 'yyyy/mm/dd hh24:mi:ss');
              di.s_cexportador             := r_cll_f255_ar_invoices_v.attribute15;

              insert into xxisv_mefsy_nfe_item_di values di;

              adi.customer_trx_id          := r_dados_item.customer_trx_id;
              adi.n_nitem                  := r_dados_item.n_nitem;
              adi.s_ndi                    := di.s_ndi;
              adi.n_nadicao                := r_dados_item.n_nadicao;
              adi.n_nseqadic               := r_dados_item.n_nseqadic;
              adi.s_cfabricante            := r_dados_item.s_cfabricante;
              adi.n_vdescdi                := null;

              insert into xxisv_mefsy_nfe_item_adi values adi;

          end if;

          header.n_tot_icms_vbc       := header.n_tot_icms_vbc     + nvl(item.n_icms_vbc, 0);
          header.n_tot_icms_vicms     := header.n_tot_icms_vicms   + nvl(item.n_icms_vicms, 0);
          header.n_tot_icms_vbcst     := header.n_tot_icms_vbcst   + nvl(item.n_icms_vbcst, 0);
      --NT2015/003 INI
          header.n_tot_icms_vfcpufdest   := header.n_tot_icms_vfcpufdest   + nvl(item.n_icmcs_vfcpufdest, 0);
          header.n_tot_icms_vicmsufdest  := header.n_tot_icms_vicmsufdest  + nvl(item.n_icmcs_vicmsufdest, 0);
          header.n_tot_icms_vicmsufremet := header.n_tot_icms_vicmsufremet + nvl(item.n_icmcs_vicmsufremet, 0);
      --NT2015/003 FIM
          header.n_tot_icms_vst       := header.n_tot_icms_vst     + nvl(item.n_icmsst_vbcstret, 0);
          header.n_tot_icms_vprod     := header.n_tot_icms_vprod   + nvl(item.n_vprod, 0);
          header.n_tot_icms_vdesc     := header.n_tot_icms_vdesc   + nvl(item.n_vdesc, 0);
          header.n_tot_icms_vii       := header.n_tot_icms_vii     + nvl(item.n_ii_vii, 0);
          header.n_tot_icms_vipi      := header.n_tot_icms_vipi    + nvl(item.n_ipitrib_vipi, 0);
          header.n_tot_icms_vpis      := header.n_tot_icms_vpis    + nvl(item.n_pisaliq_vpis, 0);
          header.n_tot_icms_vcofins   := header.n_tot_icms_vcofins + nvl(item.n_cofinsaliq_vcofins, 0);
          header.n_tot_icms_vnf       := header.n_tot_icms_vnf     + nvl(item.n_vprod, 0)
                                                                   - nvl(item.n_vdesc, 0);
                                                                   --+ nvl(item.n_icms_vicms, 0);
                                                                   /*+ nvl(header.n_tot_icms_vfrete, 0)
                                                                   + nvl(header.n_tot_icms_vseg, 0)
                                                                   + nvl(header.n_tot_icms_voutro, 0)
                                                                   + nvl(header.n_tot_icms_vii, 0)
                                                                   + nvl(header.n_tot_icms_vipi, 0)
                                                                   + nvl(header.n_tot_issqn_vserv, 0);*/

          header.n_tot_tottrib        := header.n_tot_tottrib      + nvl(item.n_vtottrib, 0);

      end loop;

      header.n_tot_icms_vnf       := header.n_tot_icms_vnf + nvl(header.n_tot_icms_vfrete, 0)
                                                         + nvl(header.n_tot_icms_vseg, 0)
                                                         + nvl(header.n_tot_icms_voutro, 0)
                                                         + nvl(header.n_tot_icms_vii, 0)
                                                         + nvl(header.n_tot_icms_vipi, 0)
                                                         + nvl(header.n_tot_issqn_vserv, 0);
      update xxisv_mefsy_nfe_header r
         set ROW = header
       where customer_trx_id = header.customer_trx_id;
    end;

    procedure generate_nfe_cancelamento(p_transaction_id                  in xxisv_mefsy_nf_notification.transaction_id%type,
                                        p_customer_trx_id_da_nota         in xxisv_mefsy_nf_notification.customer_trx_id%type,
                                        p_customer_trx_id_to_cancel       in xxisv_mefsy_nf_notification.customer_trx_id%type,
                                        p_org_id                          in xxisv_mefsy_nf_notification.org_id%type,
                                        p_organization_id                 in xxisv_mefsy_nf_notification.organization_id%type,
                                        p_event_type_id                   in xxisv_mefsy_nf_notification.event_type_id%type) as
       r_cancelamento               xxisv_mefsy_nfe_cancelamento%rowtype;
       config                       xxisv_mefsy_config%rowtype;
       r_cll_f255_ar_invoices_v     apps.cll_f255_ar_invoices_v%rowtype;
       r_cll_f255_establishment_v   apps.cll_f255_establishment_v%rowtype;
       v_warehouse_cnpj             apps.cll_f255_ar_invoice_items_v.warehouse_cnpj%type;
       v_warehouse_ie               varchar2(20);
    begin

      select *
        into r_cll_f255_ar_invoices_v
        from apps.cll_f255_ar_invoices_v a
       where a.customer_trx_id = p_customer_trx_id_da_nota
         and a.org_id          = p_org_id;

      r_cancelamento.customer_trx_id     := p_customer_trx_id_da_nota;
      r_cancelamento.customer_trx_id_ref := p_customer_trx_id_to_cancel;
      r_cancelamento.transaction_id      := p_transaction_id;
--      r_cancelamento.n_versao             := 2; --config
      r_cancelamento.s_id                := r_cll_f255_ar_invoices_v.electronic_inv_access_key;

      select *
        into config
        from xxisv_mefsy_config;

     r_cancelamento.n_versao        := config.N_VERSAO;

      -- emitente
      begin
        select warehouse_cnpj                                 -- 10169/2014
          into v_warehouse_cnpj
          from apps.cll_f255_ar_invoice_items_v
         where customer_trx_id = p_customer_trx_id_da_nota
           and org_id          = p_org_id
           and line_type       = 'LINE'
           and rownum          = 1;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao foi possivel encontrar o CNPJ da linha customer_trx_id='||p_customer_trx_id_da_nota||' e org_id='||p_org_id);
      end;

      begin
        select a.*
          into r_cll_f255_establishment_v
          from apps.cll_f255_establishment_v a
         where a.registration_number = v_warehouse_cnpj       -- 10169/2014
           and rownum                = 1;
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o estabelecimento atraves do CNPJ '||v_warehouse_cnpj);
      end;

      begin
        select apps.cll_f255_utils_pkg.get_jurisdiction(r_cll_f255_establishment_v.location_id,
                                                        r_cll_f255_establishment_v.legal_entity_id,
                                                        'INCOME_TAX') io_ie
          into v_warehouse_ie
          from dual;
      exception
        when no_data_found then
          null;
      end;

      r_cancelamento.s_cnpj              :=substr(r_cll_f255_establishment_v.registration_number,-14);
      if substr(v_warehouse_ie, 1, 6) = 'ISENTO' then
        r_cancelamento.s_ie                := 'ISENTO';
      else
        r_cancelamento.s_ie                := v_warehouse_ie;
      end if;

      begin
      r_cancelamento.s_xjust := XXISV_MEFSY_NFE_CANC_JUST(p_customer_trx_id_to_cancel);
      exception
        when no_data_found then
          null;
      end;

      insert into xxisv_mefsy_nfe_cancelamento values r_cancelamento;

    end;

    procedure generate_nfe_inutilizacao(p_transaction_id                  in xxisv_mefsy_nf_notification.transaction_id%type,
                                        p_customer_trx_id_da_nota         in xxisv_mefsy_nf_notification.customer_trx_id%type,
                                        p_customer_trx_id_to_inuti        in xxisv_mefsy_nf_notification.customer_trx_id%type,
                                        p_org_id                          in xxisv_mefsy_nf_notification.org_id%type,
                                        p_organization_id                 in xxisv_mefsy_nf_notification.organization_id%type,
                                        p_event_type_id                   in xxisv_mefsy_nf_notification.event_type_id%type) as


       r_inutilizacao              xxisv_mefsy_nfe_inutilizacao%rowtype;
       r_cll_f255_ar_invoices_v    apps.cll_f255_ar_invoices_v%rowtype;
       r_cll_f255_establishment_v  apps.cll_f255_establishment_v%rowtype;
       v_warehouse_cnpj            apps.cll_f255_ar_invoice_items_v.warehouse_cnpj%type;
       v_warehouse_ie              varchar2(20);
       config                       xxisv_mefsy_config%rowtype;
    begin

      select *
        into r_cll_f255_ar_invoices_v
        from apps.cll_f255_ar_invoices_v a
       where a.customer_trx_id = p_customer_trx_id_da_nota;

      r_inutilizacao.customer_trx_id     := p_customer_trx_id_da_nota;
      r_inutilizacao.CUSTOMER_TRX_ID_REF := p_customer_trx_id_to_inuti;
      r_inutilizacao.TRANSACTION_ID      := p_transaction_id;
--      r_inutilizacao.N_VERSAO             := 2; --config
--      r_inutilizacao.n_tpamb             := 2; --config
      r_inutilizacao.n_serie             := r_cll_f255_ar_invoices_v.series;
      r_inutilizacao.n_nfini             := r_cll_f255_ar_invoices_v.trx_number;
      r_inutilizacao.n_nffin             := r_cll_f255_ar_invoices_v.trx_number;
      r_inutilizacao.n_ano               := to_number(to_char(/*sysdate*/ current_date,'YY'));

     select *
        into config
       from xxisv_mefsy_config;

     r_inutilizacao.n_versao        := config.N_VERSAO;
     r_inutilizacao.n_tpamb         := config.N_TPAMB;

      -- emitente
      begin
        select warehouse_cnpj                                 -- 10169/2014
          into v_warehouse_cnpj
         from apps.cll_f255_ar_invoice_items_v
        where customer_trx_id = p_customer_trx_id_da_nota
          and org_id          = p_org_id
          and line_type       = 'LINE'
          and rownum          = 1;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao foi possivel encontrar o CNPJ da linha customer_trx_id='||p_customer_trx_id_da_nota||' e org_id='||p_org_id);
      end;

      begin
        select a.*
          into r_cll_f255_establishment_v
          from apps.cll_f255_establishment_v a
         where a.registration_number = v_warehouse_cnpj       -- 10169/2014
           and rownum                = 1;
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o estabelecimento atraves do CNPJ '||v_warehouse_cnpj);
      end;

      begin
        select apps.cll_f255_utils_pkg.get_jurisdiction(r_cll_f255_establishment_v.location_id,
                                                        r_cll_f255_establishment_v.legal_entity_id,
                                                        'INCOME_TAX') io_ie
          into v_warehouse_ie
          from dual;
      exception
        when no_data_found then
          null;
      end;

      r_inutilizacao.s_cnpj              := substr(r_cll_f255_establishment_v.registration_number,-14);
      if substr(v_warehouse_ie, 1, 6) = 'ISENTO' then
        r_inutilizacao.s_ie                := 'ISENTO';
      else
        r_inutilizacao.s_ie                := v_warehouse_ie;
      end if;

      begin
      select substr(a.comments,1,255)
        into r_inutilizacao.s_xjust
        from apps.cll_f255_ar_invoices_v a
       where a.customer_trx_id = p_customer_trx_id_to_inuti;
      exception
        when no_data_found then
          null;
      end;

      insert into xxisv_mefsy_nfe_inutilizacao values r_inutilizacao;

    end;

    procedure generate_nfs(p_transaction_id  in xxisv_mefsy_nf_notification.transaction_id%type,
                           p_customer_trx_id in xxisv_mefsy_nf_notification.customer_trx_id%type,
                           p_org_id          in xxisv_mefsy_nf_notification.org_id%type,
                           p_organization_id in xxisv_mefsy_nf_notification.organization_id%type,
                           p_event_type_id   in xxisv_mefsy_nf_notification.event_type_id%type) as

      nfs                          xxisv_mefsy_nfs_header%rowtype;
      nfs_deducao                  xxisv_mefsy_nfs_deducao%rowtype;
      nfs_item                     xxisv_mefsy_nfs_item%rowtype;
      r_cll_f255_ar_invoices_v     apps.cll_f255_ar_invoices_v%rowtype;
      r_cll_f255_establishment_v   apps.cll_f255_establishment_v%rowtype;
      r_cll_f255_ar_customers_v    apps.cll_f255_ar_customers_v%rowtype;
      --v_valor_total_nota           number;
      v_warehouse_cnpj             apps.cll_f255_ar_invoice_items_v.warehouse_cnpj%type;
      v_warehouse_ie               varchar2(20);
      config                       xxisv_mefsy_config%rowtype;
      vlr_transp                   number(15,2);
      v_cserv                      xxisv_mefsy_nfs_header.s_codtribmunic%type;

    begin

      nfs       := null;
      nfs_item  := null;
      v_cserv   := null;

      select *
        into r_cll_f255_ar_invoices_v
        from apps.cll_f255_ar_invoices_v a
       where a.customer_trx_id = p_customer_trx_id
         and a.org_id          = p_org_id;

--      nfs.n_tpamb                           := 2; --config
      nfs.customer_trx_id                   := r_cll_f255_ar_invoices_v.customer_trx_id;
      nfs.transaction_id                    := p_transaction_id;
--      nfs.n_versao                          := 2.1;
      nfs.n_numero_rps                      := r_cll_f255_ar_invoices_v.trx_number;
      nfs.s_serie_rps                       := r_cll_f255_ar_invoices_v.series;
      nfs.s_campoUsoInterno                 := null;
      nfs.d_dtemis_rps                      := to_char(r_cll_f255_ar_invoices_v.trx_date, 'YYYY-MM-DD')||'T'||to_char(r_cll_f255_ar_invoices_v.trx_date,'HH24:MM:SS');
      nfs.d_dtcomp                          := null;
      nfs.n_tp_rps                          := 1;
      nfs.s_sit_rps                         := 1;
      --nfs.s_natoper                         := 'T'; -- ? pegar de algum campo

       --
      BEGIN
      select substr(replace(c.SEGMENT1||' - '||c.description||' - '||a.comments,'|',' '),1,1999) into nfs.s_desc_rps
        from apps.CLL_F255_AR_INVOICES_V         a,
             apps.CLL_F255_AR_INVOICE_ITEMS_V    b,
             apps.MTL_SYSTEM_ITEMS_B             c
        where
              a.org_id            = b.org_id
          and a.customer_trx_id   = b.customer_trx_id
          and b.INVENTORY_ITEM_ID = c.INVENTORY_ITEM_ID
          and b.organization_id   = c.organization_id
          and a.customer_trx_id     = r_cll_f255_ar_invoices_v.customer_trx_id;
       EXCEPTION
         when no_data_found then
           null;
       END;
      --

     -- nfs.s_desc_rps                        := r_cll_f255_ar_invoices_v.description;
      nfs.s_codservint                      := null;
      nfs.s_tiprec                          := '2'; -- ?
      nfs.n_valserv                         := 0; -- update abaixo

     select *
        into config
       from xxisv_mefsy_config;

     nfs.n_versao        := config.N_VERSAO;
     nfs.n_tpamb         := config.N_TPAMB;

     begin
      select abs(sum(nvl(io.ISS_base,0))),
             abs(sum(nvl(io.iss_aliq,0))/100),
             abs(sum(nvl(io.ISS_vlr,0))),
             abs(sum(nvl(io.PIS_RT_VLR,0))),
             abs(sum(nvl(io.COFINS_RT_VLR,0))),
             abs(sum(nvl(io.inss_vlr,0))),
             abs(sum(nvl(io.ir_vlr,0))),
             abs(sum(nvl(io.csll_vlr,0))),
             abs(sum(nvl(io.PIS_VLR,0))) +
             abs(sum(nvl(io.COFINS_VLR,0)))
        into nfs.n_basecalc,
             nfs.n_aliqserv,
             nfs.n_valiss,
             nfs.n_valpis,
             nfs.n_valconfins,
             nfs.n_valinss,
             nfs.n_valir,
             nfs.n_valcsll,
             vlr_transp
        from xxisv_mefsy_nf_item_impostos io -- 12688/2016
       where customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
         and org_id          = r_cll_f255_ar_invoices_v.org_id;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao retornado os impostos customer_trx_id='||p_customer_trx_id||' e org_id='||p_org_id);
      end;

      -- JVP002
      nfs.s_desc_rps := nfs.s_desc_rps||' Conforme lei 12.741/2012, os impostos incidentes sobre esta NFS-e:  Valor dos tributos federais: '||TO_CHAR(nvl(vlr_transp,0) , '999999990D99')||' Valor dos tributos municipais: '||TO_CHAR(nvl(nfs.n_valiss,0), '999999990D99')||'.';
      -- JVP002

         --TRATAMENTO DE VALORES NEGATIVOS
/*            IF nfs.n_basecalc   < 0 THEN nfs.n_basecalc   := nfs.n_basecalc   *-1; END IF;
            IF nfs.n_aliqserv   < 0 THEN nfs.n_aliqserv   := nfs.n_aliqserv   *-1; END IF;
            IF nfs.n_valiss     < 0 THEN nfs.n_valiss     := nfs.n_valiss     *-1; END IF;
            IF nfs.n_valpis     < 0 THEN nfs.n_valpis     := nfs.n_valpis     *-1; END IF;
            IF nfs.n_valconfins < 0 THEN nfs.n_valconfins := nfs.n_valconfins *-1; END IF;
            IF nfs.n_valinss    < 0 THEN nfs.n_valinss    := nfs.n_valinss    *-1; END IF;
            IF nfs.n_valir      < 0 THEN nfs.n_valir      := nfs.n_valir      *-1; END IF;
            IF nfs.n_valcsll    < 0 THEN nfs.n_valcsll    := nfs.n_valcsll    *-1; END IF;*/
         --FIM TRATAMENTO DE VALORES NEGATIVOS
      -- emitente
      begin
        select warehouse_cnpj
          into v_warehouse_cnpj
          from apps.cll_f255_ar_invoice_items_v
         where customer_trx_id = p_customer_trx_id
           and org_id          = p_org_id
           and line_type       = 'LINE'
           and rownum          = 1;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao foi possivel encontrar o CNPJ da linha customer_trx_id='||p_customer_trx_id||' e org_id='||p_org_id);
      end;

      begin
        select *
          into r_cll_f255_establishment_v
          from apps.cll_f255_establishment_v a
         where a.registration_number = v_warehouse_cnpj
           and rownum                = 1;
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o estabelecimento atraves do CNPJ '||v_warehouse_cnpj);
      end;

      nfs.s_razsoc_prest         := r_cll_f255_establishment_v.establishment_name;
      nfs.s_end_prest            := r_cll_f255_establishment_v.address_line_1;
      nfs.s_numend_prest         := r_cll_f255_establishment_v.address_line_2;
      nfs.s_complend_prest       := substr(trim(replace(replace(r_cll_f255_establishment_v.address_line_3,'|',' '),'"',' ')),1,30);
      --nfs.s_bai_prest            := r_cll_f255_establishment_v.region_1;
      nfs.s_bai_prest            := substr(trim(replace(replace(r_cll_f255_establishment_v.address_line_3,'|',' '),'"',' ')),1,30);
      nfs.n_cep_prest            := r_cll_f255_establishment_v.postal_code;
      nfs.s_uf_prest             := r_cll_f255_establishment_v.region_2;
      --nfs.n_pais_prest           := get_ibge_codes(r_cll_f255_establishment_v.location_id, 'COUNTRY');
      --temporario
      nfs.n_pais_prest           := '1058';
      nfs.s_ddd_prest            := substr(regexp_replace(r_cll_f255_establishment_v.telephone_number_1,'[^0-9]',''), 2);
      nfs.s_tel_prest            := substr(regexp_replace(r_cll_f255_establishment_v.telephone_number_1,'[^0-9]',''), -10);
      nfs.s_email_prest          := null;
      nfs.n_regespectrib         := null;
      nfs.s_cnpj_prest           := substr(r_cll_f255_establishment_v.registration_number,-14);
      nfs.n_optsimpnac           := 2;
      nfs.n_incetivcult          := 2;
      nfs.N_CODCID               := get_ibge_codes_muni(r_cll_f255_establishment_v.establishment_id);
      --temporario, at� ajustar origem do codigo ibge do municipio
     /* if r_cll_f255_establishment_v.location_id =156 then
        nfs.N_CODCID :='3550308';
      else
        nfs.N_CODCID:=null;
      end if;*/
      --


      begin
        /*select apps.cll_f255_utils_pkg.get_jurisdiction(r_cll_f255_establishment_v.location_id,
                                                        r_cll_f255_establishment_v.legal_entity_id,
                                                        'INCOME_TAX') io_ie
          into v_warehouse_ie
          from dual;*/
        --alterado - claudio santos retornar inscricao municipal--10/10/2019
        /*SELECT

               reg.registration_number into v_warehouse_ie
          FROM
               xle_registrations    reg,
               xle_jurisdictions_vl jur
         WHERE
             reg.source_table = 'XLE_ENTITY_PROFILES'
           AND jur.jurisdiction_id = reg.jurisdiction_id
           AND reg.location_id = r_cll_f255_establishment_v.location_id
           AND jur.legislative_cat_code = 'COMPANY_LAW'--'COMPANY_LAW' - inscricao municipal ,'FEDERAL_TAX' - cnpj
           AND reg.source_id = r_cll_f255_establishment_v.legal_entity_id;
        */   -------
        --ALTERADO A ORIGEM DA DA INSCRICAO MUNICIPAL
        select DISTINCT
               xreg.registration_number
          into v_warehouse_ie
          from apps.ra_customer_trx_all       rct
              ,apps.ra_customer_trx_lines_all rctl
              ,apps.mtl_system_items          msi
              ,apps.hr_all_organization_units hou
              ,apps.hr_locations              hr
              ,apps.xle_registrations         xreg
              ,apps.xle_jurisdictions_b        xjur
          where rct.customer_trx_id    = rctl.customer_trx_id
          and   rctl.warehouse_id      = msi.organization_id
          and   rctl.inventory_item_id = msi.inventory_item_id
          and   msi.organization_id    = hou.organization_id
          and   hou.location_id        = hr.location_id
          and   hr.location_id         = xreg.location_id
          and   rctl.line_type         = 'LINE'
          and   xreg.jurisdiction_id   = xjur.jurisdiction_id
          and   xjur.legislative_cat_code = 'COMPANY_LAW'
          and   rct.customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id;
      exception
        when no_data_found then
           v_warehouse_ie   := '';
      end;

      if substr(v_warehouse_ie, 1, 6) = 'ISENTO' then
          nfs.s_insc_prest   := 'ISENTO';
      else
          nfs.s_insc_prest   := v_warehouse_ie;
      end if;

      -- destinatario
      BEGIN
      select *
        into r_cll_f255_ar_customers_v
        from apps.cll_f255_ar_customers_v c
       where r_cll_f255_ar_invoices_v.ship_to_site_use_id  = c.site_use_id
       and rownum = 1;
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o destinatario atraves do ID '||r_cll_f255_ar_invoices_v.ship_to_site_use_id);
      end;

      nfs.s_razsoc_tomador       := substr(r_cll_f255_ar_customers_v.customer_name, 1, length(r_cll_f255_ar_customers_v.customer_name));
      nfs.s_end_tomador          := r_cll_f255_ar_customers_v.address1;
      nfs.s_numend_tomador       := substr(r_cll_f255_ar_customers_v.address2,1,9);
      --nfs.s_complend_tomador     := r_cll_f255_ar_customers_v.address3;
      nfs.s_complend_tomador     := substr(trim(replace(replace(r_cll_f255_ar_customers_v.address3,'|',' '),'"',' ')),1,30);
      --nfs.s_bai_tomador          := r_cll_f255_ar_customers_v.address4;
      nfs.s_bai_tomador          :=substr(trim(replace(replace(r_cll_f255_ar_customers_v.address4,'|',' '),'"',' ')),1,30);
      nfs.s_uf_tomador           := r_cll_f255_ar_customers_v.state;

      if (nfs.s_uf_tomador != 'EX') then
        --nfs.n_pais_tomador         := get_ibge_codes(r_cll_f255_ar_customers_v.location_id, 'COUNTRY');
        --temporario
         nfs.n_pais_tomador  :='1058';
        nfs.n_cid_tomador     := get_ibge_codes_tomador(r_cll_f255_ar_customers_v.location_id, 'CITY');
        nfs.n_cep_tomador     := regexp_replace(r_cll_f255_ar_customers_v.postal_code, '[^0-9]', '');
        select r_cll_f255_ar_customers_v.document_number,
               r_cll_f255_ar_customers_v.ie
          into nfs.s_cpfcnpj_tomador,
               nfs.s_inscest_tomador
          from dual;
      else
        --nfs.s_cid_tomador     := 'EXTERIOR';
        nfs.n_cid_tomador     := 9999999;
        nfs.n_cep_tomador     := '99999999';
        nfs.s_inscest_tomador := 'ISENTO';
        nfs.s_cpfcnpj_tomador := '00000000000000';
        nfs.s_inscest_tomador := 4;
      end if;

      begin
      select decode(r_cll_f255_ar_customers_v.document_type,'CPF', 1, 'CNPJ', 2, 3)
        into nfs.n_indcpfcnpj
       from dual;
      exception
        when no_data_found then
         null;
      end;

      nfs.n_municprest                      := nfs.n_cid_tomador; --?
      nfs.n_municincid                      := null;   -- ??
      nfs.n_paisserv                        := nfs.n_pais_tomador;   -- ??

      -- JVP001
      IF UPPER(r_cll_f255_establishment_v.TOWN_OR_CITY) = 'BARUERI' THEN
         nfs.s_natoper                         := '1';
      ELSIF UPPER(r_cll_f255_establishment_v.TOWN_OR_CITY) = 'RIO DE JANEIRO' THEN
         nfs.s_natoper                         := '1';
      ELSE
         nfs.s_natoper                         := 'T';
      END IF;
      -- JVP001

      begin
        select substr(regexp_replace(area_code,'[^0-9]',''),1,3), substr(regexp_replace(phone_number,'[^0-9]',''),1,9) --5337/2015
          into nfs.s_ddd_tomador, nfs.s_tel_tomador
          from apps.ar_phones_v
         where owner_table_id     = r_cll_f255_ar_customers_v.party_site_id
           and contact_point_type = 'PHONE'
           and trim(phone_number) is not null
           and rownum = 1;
      exception
         when no_data_found then
           null;
      end;

      begin
       /* select email_address
          into nfs.s_email_tomador
          from apps.ar_phones_v
         where owner_table_id     = r_cll_f255_ar_customers_v.party_site_id
           and contact_point_type = 'EMAIL'
           and trim(email_address) is not null
             and rownum = 1;*/
        --aleracao por solicitacao da stone em 04/12/2019
         select email_address
          into nfs.s_email_tomador
          from apps.ar_phones_v
         where 1=1
           and owner_table_id      = r_cll_f255_ar_customers_v.party_site_id
           and contact_point_type = 'EMAIL'
           and owner_table_name   = 'HZ_PARTY_SITES'
           and trim(email_address) is not null
           and status = 'A'
           and rownum = 1;
      exception
         when no_data_found then
           null;
      end;

      begin
        SELECT a.s_cprod
           INTO v_cserv
        FROM  xxisv_mefsy_nf_item a
        where a.customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
          and a.org_id          = r_cll_f255_ar_invoices_v.org_id
          and rownum = 1;
      exception
       when OTHERS then
          v_cserv                         := null;
      end;

      if v_cserv is not null then
          nfs.s_codcnae        := v_cserv;
          nfs.s_itemlistserv   := v_cserv;
          nfs.s_codtribmunic   := v_cserv;
          nfs.s_codservint     := v_cserv;
      else
          nfs.s_codcnae        := 'TBD';
          nfs.s_itemlistserv   := 'TBD';
          nfs.s_codtribmunic   := 'TBD';
          nfs.s_codservint     := null;
      end if;

      --
      begin
        SELECT a.global_attribute7
           INTO nfs.s_inscmun_tomador
        FROM  apps.hz_cust_acct_sites_all a
        where a.party_site_id   =  r_cll_f255_ar_customers_v.party_site_id
          and a.org_id          =  r_cll_f255_ar_customers_v.org_id;
      exception
       when no_data_found then
          nfs.s_inscmun_tomador := null;
      end;
      
      -- JVP003
      begin
        SELECT SUM(a.N_VALTOTAL)
           INTO nfs.n_valserv
        FROM  xxisv_mefsy_nf_item a
        where a.customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
          and a.org_id          = r_cll_f255_ar_invoices_v.org_id;
      exception
       when OTHERS then
          nfs.n_valserv                         := 0;
      end;
      -- JVP003

      clean_old_data(r_cll_f255_ar_invoices_v.customer_trx_id);

      begin
      insert into xxisv_mefsy_nfs_header values nfs;
      commit;
      exception
        when others then
          null;
      end;

      --v_valor_total_nota := 0;

      for r_dados_item in (select *
                             from xxisv_mefsy_nf_item -- 12688/2016
                            where customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
                              and org_id          = r_cll_f255_ar_invoices_v.org_id)
      loop

        --nfs.s_codcnae                         := r_dados_item.s_cprod; -- ??
        --nfs.s_itemlistserv                    := r_dados_item.s_cprod; -- ??
        --nfs.s_codtribmunic                    := r_dados_item.s_cprod; -- ??
        --claudio
        --nfs.s_codservint                      := r_dados_item.s_cprod;
        nfs_item.CUSTOMER_TRX_ID              := r_dados_item.customer_trx_id;
        nfs_item.N_NUMITEM                    := r_dados_item.n_nitem;

         --
      BEGIN
        select substr(replace(c.description,'|',' '),1,1999)
         into nfs_item.S_DISCSERV
          from apps.CLL_F255_AR_INVOICES_V         a,
               apps.CLL_F255_AR_INVOICE_ITEMS_V    b,
               apps.MTL_SYSTEM_ITEMS_B             c
          where a.org_id            = b.org_id
            and a.customer_trx_id   = b.customer_trx_id
            and b.INVENTORY_ITEM_ID = c.INVENTORY_ITEM_ID
            and b.organization_id   = c.organization_id
            and a.customer_trx_id     = r_dados_item.customer_trx_id;
         EXCEPTION
           when no_data_found then
             nfs_item.S_DISCSERV:=null;
         END;
        --

        --nfs_item.S_DISCSERV         := r_dados_item.s_xprod;
        nfs_item.N_QTDE             := r_dados_item.n_qcom;
        nfs_item.N_VALUNIT          := r_dados_item.N_VUNCOM;
        nfs_item.N_VALTOTAL         := r_dados_item.N_VALTOTAL;
        nfs_item.S_UNIDMED          := r_dados_item.S_UCOM;
        nfs_item.N_VALDEDUZITEM     := null;

        --v_valor_total_nota := v_valor_total_nota + nfs_item.N_VALTOTAL;

        begin
        insert into xxisv_mefsy_nfs_item values nfs_item;
        commit;
        exception
          when others then
            null;
        end;

      end loop;
      
      -- JVP003
      /*nfs.n_valserv := v_valor_total_nota;

      update xxisv_mefsy_nfs_header
         set row = nfs
       where customer_trx_id = nfs.customer_trx_id;
       commit;*/
      -- JVP003
      
    end;

   procedure generate_nfs_cancelamento(p_transaction_id                  in xxisv_mefsy_nf_notification.transaction_id%type,
                                        p_customer_trx_id_da_nota         in xxisv_mefsy_nf_notification.customer_trx_id%type,
                                        p_customer_trx_id_to_cancel       in xxisv_mefsy_nf_notification.customer_trx_id%type,
                                        p_org_id                          in xxisv_mefsy_nf_notification.org_id%type,
                                        p_organization_id                 in xxisv_mefsy_nf_notification.organization_id%type,
                                        p_event_type_id                   in xxisv_mefsy_nf_notification.event_type_id%type) as

       nfs_cancel                  xxisv_mefsy_nfs_cancelamento%rowtype;
       r_cll_f255_ar_invoices_v    apps.cll_f255_ar_invoices_v%rowtype;
       r_cll_f255_establishment_v  apps.cll_f255_establishment_v%rowtype;
       v_warehouse_cnpj            apps.cll_f255_ar_invoice_items_v.warehouse_cnpj%type;
       v_warehouse_ie              varchar2(20);
       config                       xxisv_mefsy_config%rowtype;
    begin

      select *
        into r_cll_f255_ar_invoices_v
        from apps.cll_f255_ar_invoices_v a
       where a.customer_trx_id = p_customer_trx_id_da_nota
         and a.org_id          = p_org_id;

      nfs_cancel.customer_trx_id      := r_cll_f255_ar_invoices_v.customer_trx_id;
      nfs_cancel.customer_trx_id_ref  := p_customer_trx_id_to_cancel;
      nfs_cancel.transaction_id       := p_transaction_id;

     select *
        into config
       from xxisv_mefsy_config;

     nfs_cancel.n_versao        := config.N_VERSAO;
     nfs_cancel.n_tpamb         := config.N_TPAMB;

--      nfs_cancel.n_versao             := 2.1; --config
--      nfs_cancel.n_tpamb              := 2; --config

      -- emitente
      begin
        select warehouse_cnpj
          into v_warehouse_cnpj
          from apps.cll_f255_ar_invoice_items_v
         where customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id
           and org_id          = r_cll_f255_ar_invoices_v.org_id
           and line_type       = 'LINE'
           and rownum          = 1;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao foi possivel encontrar o CNPJ da linha customer_trx_id='||r_cll_f255_ar_invoices_v.customer_trx_id||' e org_id='||r_cll_f255_ar_invoices_v.org_id);
      end;

      begin
        select *
          into r_cll_f255_establishment_v
          from apps.cll_f255_establishment_v a
         where a.registration_number = v_warehouse_cnpj
           and rownum                = 1;
      exception
        when no_data_found then
          raise_application_error(-20102, 'Nao foi possivel encontrar o estabelecimento atraves do CNPJ '||v_warehouse_cnpj);
      end;

      nfs_cancel.n_codcid             := get_ibge_codes_muni(r_cll_f255_establishment_v.establishment_id);
      nfs_cancel.s_cnpj_prest         := substr(r_cll_f255_establishment_v.registration_number,-14);
      nfs_cancel.s_numnfse            := replace(r_cll_f255_ar_invoices_v.seal_number,'NUMERO NFS GERADO:','');
      nfs_cancel.s_codverif           := r_cll_f255_ar_invoices_v.electronic_inv_access_key;
      nfs_cancel.n_codcanc            := 1; --1 Erro na emiss����o, 2 Servi����o nao prestado, 3 Duplicidade da nota, 9 Outros
      begin
        /*select apps.cll_f255_utils_pkg.get_jurisdiction(r_cll_f255_establishment_v.location_id,
                                                        r_cll_f255_establishment_v.legal_entity_id,
                                                        'INCOME_TAX') io_ie
          into v_warehouse_ie
          from dual;*/
         --alterado - claudio santos retornar inscricao municipal
        select DISTINCT
               xreg.registration_number
          into v_warehouse_ie
          from apps.ra_customer_trx_all       rct
              ,apps.ra_customer_trx_lines_all rctl
              ,apps.mtl_system_items          msi
              ,apps.hr_all_organization_units hou
              ,apps.hr_locations              hr
              ,apps.xle_registrations         xreg
              ,apps.xle_jurisdictions_b        xjur
          where rct.customer_trx_id    = rctl.customer_trx_id
          and   rctl.warehouse_id      = msi.organization_id
          and   rctl.inventory_item_id = msi.inventory_item_id
          and   msi.organization_id    = hou.organization_id
          and   hou.location_id        = hr.location_id
          and   hr.location_id         = xreg.location_id
          and   rctl.line_type         = 'LINE'
          and   xreg.jurisdiction_id   = xjur.jurisdiction_id
          and   xjur.legislative_cat_code = 'COMPANY_LAW'
          and   rct.customer_trx_id = r_cll_f255_ar_invoices_v.customer_trx_id;
      exception
        when no_data_found then
         v_warehouse_ie   := '';
      end;

      if substr(v_warehouse_ie, 1, 6) = 'ISENTO' then
         nfs_cancel.s_insc_prest   := 'ISENTO';
      else
         nfs_cancel.s_insc_prest   := v_warehouse_ie;
      end if;

      begin
        select substr(a.comments,1,255)
          into nfs_cancel.S_MOTCANC
          from apps.cll_f255_ar_invoices_v a
         where a.customer_trx_id = p_customer_trx_id_to_cancel;
      exception
        when no_data_found then
          raise_application_error(-20101, 'Nao foi possivel encontrar o Motivo do Cancelamento da linha customer_trx_id='||p_customer_trx_id_to_cancel);
      end;

      insert into xxisv_mefsy_nfs_cancelamento values nfs_cancel;

    end;

    procedure generate_nf (p_transaction_id  in xxisv_mefsy_nf_notification.transaction_id%type,
                           p_customer_trx_id in xxisv_mefsy_nf_notification.customer_trx_id%type,
                           p_org_id          in xxisv_mefsy_nf_notification.org_id%type,
                           p_organization_id in xxisv_mefsy_nf_notification.organization_id%type,
                           p_event_type_id   in xxisv_mefsy_nf_notification.event_type_id%type) as

      r_cll_f255_ar_invoices_v     apps.cll_f255_ar_invoices_v%rowtype;
      r_cll_f255_ar_invoices_v_ref apps.cll_f255_ar_invoices_v%rowtype;
      v_customer_trx_id_to_use     apps.cll_f255_ar_invoices_v.customer_trx_id%type;
    begin

      begin
        select *
          into r_cll_f255_ar_invoices_v
          from apps.cll_f255_ar_invoices_v a
         where a.customer_trx_id = p_customer_trx_id
           and a.org_id          = p_org_id;
      exception
        when no_data_found then
          raise_application_error(-20100, 'Nao foi encontrada a nota customer_trx_id='||p_customer_trx_id||' and org_id='||p_org_id);
      end;

      if r_cll_f255_ar_invoices_v.previous_customer_trx_id is null then -- emissao nota

        if r_cll_f255_ar_invoices_v.code_document = '08' then -- emissao nota servico

           --deleting old data
           clean_old_data(p_customer_trx_id);

           generate_nfs(p_transaction_id,
                        p_customer_trx_id,
                        p_org_id,
                        p_organization_id,
                        p_event_type_id);

        else -- emissao nota mercantil

           --deleting old data
           clean_old_data(p_customer_trx_id);

           generate_nfe(p_transaction_id,
                        p_customer_trx_id,
                        p_org_id,
                        p_organization_id,
                        p_event_type_id);
        end if;

      else -- cancelamento ou inutilizacao

        begin
           select *
             into r_cll_f255_ar_invoices_v_ref
             from apps.cll_f255_ar_invoices_v a
            where a.customer_trx_id = r_cll_f255_ar_invoices_v.previous_customer_trx_id
              and a.org_id          = p_org_id;
        exception
          when no_data_found then
            raise_application_error(-20100, 'Nao foi encontrada a nota referenciada previous_customer_trx_id='||p_customer_trx_id||' and org_id='||p_org_id);
        end;

        if r_cll_f255_ar_invoices_v_ref.code_document = '08' then -- cancelamento nota servico

           --deleting old data
           clean_old_data(r_cll_f255_ar_invoices_v.previous_customer_trx_id);

           generate_nfs_cancelamento(p_transaction_id,
                                     r_cll_f255_ar_invoices_v.previous_customer_trx_id,
                                     r_cll_f255_ar_invoices_v.customer_trx_id,
                                     p_org_id,
                                     p_organization_id,
                                     p_event_type_id);

        else -- cancelamento ou inutilizacao nota fiscal mercantil

           --deleting old data
           clean_old_data(r_cll_f255_ar_invoices_v.previous_customer_trx_id);

           -- electronic_inv_status (1 = enviado, 2 = finalizado, 3 = erro, 4 = cancelado, 5 = rejeitado pela sefaz, 6 = inutilizado, 7 = emissao em contingencia)
           if r_cll_f255_ar_invoices_v_ref.electronic_inv_status in (2, 7) then

               generate_nfe_cancelamento(p_transaction_id,
                                         r_cll_f255_ar_invoices_v.previous_customer_trx_id,
                                         r_cll_f255_ar_invoices_v.customer_trx_id,
                                         p_org_id,
                                         p_organization_id,
                                         p_event_type_id);

           elsif r_cll_f255_ar_invoices_v_ref.electronic_inv_status in (1, 3, 5) then

               generate_nfe_inutilizacao(p_transaction_id,
                                         r_cll_f255_ar_invoices_v.previous_customer_trx_id,
                                         r_cll_f255_ar_invoices_v.customer_trx_id,
                                         p_org_id,
                                         p_organization_id,
                                         p_event_type_id);
           end if;

        end if;

      end if;

    end;

end XXISV_MECPC_DFE;
/
