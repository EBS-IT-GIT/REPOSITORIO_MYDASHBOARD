  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_AR_AP_CM05_PKG" IS

  PROCEDURE main ( errbuf               OUT VARCHAR2
                 , retcode              OUT NUMBER
                 , p_anio                IN gl_periods.period_year%TYPE
                 , P_ACCESS_SET_ID       IN NUMBER
                 , p_set_of_books_id     IN gl_ledgers.ledger_id%TYPE);

END XX_AR_AP_CM05_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_AR_AP_CM05_PKG" IS
  PROCEDURE main ( errbuf               OUT VARCHAR2
                 , retcode              OUT NUMBER
                 , p_anio                IN gl_periods.period_year%TYPE
                 , P_ACCESS_SET_ID       IN NUMBER
                 , p_set_of_books_id     IN gl_ledgers.ledger_id%TYPE) IS

    --EXCEPCIONES
    e_exception EXCEPTION;
    e_retcode   NUMBER :=0;
    e_message   VARCHAR2(1000);
    
    TYPE r_salida is record
      ( origen_asiento gl_je_headers.je_source%TYPE
      , centro_costo   gl_code_combinations_kfv.segment3%TYPE
      , cuenta         gl_code_combinations_kfv.segment2%TYPE
      , fecha          gl_je_lines.effective_date%TYPE
      , monto          gl_je_lines.entered_dr%TYPE
      , origen         jl_ar_ap_provinces.province_name%TYPE
      , destino        jl_ar_ap_provinces.province_name%TYPE
      , nro_doc        VARCHAR2(100)
      , entidad        VARCHAR2(1000)
      );

    l_salida r_salida;

    l_sep VARCHAR(1) :=';';

    CURSOR c_lineas_flete( c_anio            gl_periods.period_year%TYPE
                         , c_set_of_books_id gl_ledgers.ledger_id%TYPE ) IS
      SELECT gjh.je_source
           , gjs_tl.user_je_source_name je_source_name
           , gcc_kfv.segment3           cost_centre
           , gcc_kfv.segment2           account
           , gjl.effective_date         gl_date
           , nvl(gjl.entered_dr,0) - nvl(gjl.entered_cr,0) amount
           , gjl.reference_1
           , gjl.reference_2
           , gjl.reference_3
           , gjl.reference_4
           , gir.reference_7 ae_header_id
           , gir.reference_8 ae_line_num
       FROM gl_je_lines gjl
          , gl_je_headers gjh
          , gl_periods gp
          , gl_ledgers gsob      -- Upgrate R12 gl_sets_of_books
          , gl_code_combinations_kfv gcc_kfv
          , gl_je_sources_tl gjs_tl
          , gl_import_references gir
      WHERE gjl.je_line_num           = gir.je_line_num (+)
        AND gjh.je_header_id          = gir.je_header_id (+)
        AND gjs_tl.language           = userenv('LANG')
        AND gjh.je_source             = gjs_tl.je_source_name
        AND gjl.code_combination_id   = gcc_kfv.code_combination_id
        AND gjh.je_header_id          = gjl.je_header_id
        AND gjh.actual_flag           = 'A'
        AND gjh.status                = 'P'
        AND gp.period_name            = gjh.period_name
        AND gsob.ledger_id            = gjh.ledger_id   -- Upgrate R12 gsob.set_of_books_id      = gjh.set_of_books_id
        AND gsob.period_set_name      = gp.period_set_name
        AND gp.adjustment_period_flag = 'N'
        AND gp.period_year            = c_anio
        AND gsob.ledger_id            = c_set_of_books_id     -- Upgrate R12  gsob.set_of_books_id      = c_set_of_books_id
        AND gcc_kfv.segment2         IN ( SELECT lookup_code
                                            FROM fnd_lookup_values
                                           WHERE lookup_type           = 'XX_AR_AP_CM05_CUENTAS'
                                             AND language              = userenv('LANG')
                                             AND nvl(enabled_flag,'N') = 'Y'
                                             AND sysdate BETWEEN NVL(start_date_active,sysdate)
                                                             AND NVL(end_date_active,sysdate));
                                                             
    --CR2463
    CURSOR c_distribuciones_ap ( c_ae_header_id xla_distribution_links.ae_header_id%TYPE
                               , c_ae_line_num  xla_distribution_links.ae_line_num%TYPE) IS
      SELECT source_distribution_id_num_1 invoice_distribution_id
      FROM   xla_distribution_links xld
      WHERE  ae_header_id = c_ae_header_id
      AND    ae_line_num  = c_ae_line_num;                                   

  BEGIN

    fnd_file.put_line(fnd_file.log,'Inicio ejecucion: '||to_char(sysdate, 'HH24:MI:SS'));

    fnd_file.put_line(fnd_file.output,'Origen asiento'  ||l_sep||
                                      'Centro costo'    ||l_sep||
                                      'Cuenta'          ||l_sep||
                                      'Fecha'           ||l_sep||
                                      'Monto'           ||l_sep||
                                      'Origen'          ||l_sep||
                                      'Destino'         ||l_sep||
                                      'Numero documento'||l_sep||
                                      'Entidad'         ||l_sep);

    FOR c1 IN c_lineas_flete(p_anio, p_set_of_books_id)
    LOOP

      l_salida.origen_asiento := c1.je_source_name;
      l_salida.centro_costo   := c1.cost_centre;
      l_salida.cuenta         := c1.account;
      l_salida.fecha          := c1.gl_date;
      l_salida.monto          := c1.amount;

      IF c1.je_source = 'Payables' THEN
        --CR2463
        FOR c_dist IN c_distribuciones_ap(c1.ae_header_id, c1.ae_line_num) LOOP
          BEGIN
          -- ITC 04.04.2018
            SELECT a.ORIGEN
                  ,a.DESTINO
                  ,a.NRO_DOC
                  ,a.ENTIDAD
              INTO l_salida.origen
                 , l_salida.destino
                 , l_salida.nro_doc
                 , l_salida.entidad
            FROM (
            -- ITC 04.04.2018
            SELECT DISTINCT
                   (SELECT province_name
                      FROM jl_ar_ap_provinces jaap
                     WHERE jaap.province_code = nvl(aid.attribute7,ai.attribute3)) ORIGEN
                 , (SELECT province_name
                      FROM hr_locations hl
                         , jl_ar_ap_provinces jaap
                     WHERE hl.region_2    = jaap.province_code
                       AND hl.location_id = aid.global_attribute3)                 DESTINO
                 , 'FC: '||ai.invoice_num                                          NRO_DOC
                 , pv.vendor_name                                                  ENTIDAD
              /*INTO l_salida.origen
                 , l_salida.destino
                 , l_salida.nro_doc
                 , l_salida.entidad */
              FROM ap_invoice_distributions_all aid
                 , ap_invoices_all ai
                 , ap_suppliers pv     -- Upgrate R12 po_vendors
             WHERE ai.vendor_id                 = pv.vendor_id
               AND aid.invoice_id               = ai.invoice_id
               /*AND NVL(aid.old_dist_line_number,
                   aid.distribution_line_number)= c1.reference_3
               AND aid.invoice_id               = l_invoice_id*/
               AND  aid.invoice_distribution_id = c_dist.invoice_distribution_id
            -- ITC 04.04.2018
                  ) a
             /*CR2463
               WHERE 1=1
               AND a.ORIGEN IS NOT NULL
               AND a.DESTINO IS NOT NULL*/
               ;
            -- ITC 04.04.2018    
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              e_retcode:=1;
              fnd_file.put_line(fnd_file.log, 'No se encontraron datos de origen payables invoice_distribution_id: '||c_dist.invoice_distribution_id);

            WHEN OTHERS THEN
              e_retcode := 2;
              e_message := 'Error buscando datos de origen payables invoice_distribution_id: '||c_dist.invoice_distribution_id||' - '||sqlerrm;
              RAISE e_exception;
          END;
        END LOOP;
        
      ELSIF c1.je_source = 'Purchasing' THEN
        BEGIN
          SELECT DISTINCT
                 'OC: '||ph.segment1
               , pv.vendor_name
               , (SELECT province_name
                    FROM hr_locations hl
                       , jl_ar_ap_provinces jaap
                   WHERE hl.region_2    = jaap.province_code
                     AND hl.location_id = pd.deliver_to_location_id) DESTINO
            INTO l_salida.nro_doc
               , l_salida.entidad
               , l_salida.destino
            FROM po_distributions_all pd
               , po_headers_all       ph
               , ap_suppliers         pv   -- Upgrate R12 po_vendors
           WHERE ph.vendor_id          = pv.vendor_id
             AND pd.po_header_id       = ph.po_header_id
             AND pd.po_distribution_id = c1.reference_3;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            e_retcode :=1;
            fnd_file.put_line(fnd_file.log, 'No se encontraron datos de PO reference_3: '||c1.reference_3);

          WHEN OTHERS THEN
            e_retcode := 2;
            e_message := 'Error buscando datos de PO reference_3: '||c1.reference_3||' - '||sqlerrm;
            RAISE e_exception;
        END;

        BEGIN
          SELECT DISTINCT
                 (SELECT province_name
                    FROM jl_ar_ap_provinces jaap
                   WHERE jaap.province_code = nvl(aid.attribute7,ai.attribute3)) ORIGEN
               , (SELECT nvl(l_salida.destino, province_name)
                    FROM hr_locations hl
                       , jl_ar_ap_provinces jaap
                   WHERE hl.region_2    = jaap.province_code
                     AND hl.location_id = aid.global_attribute3) DESTINO
               , 'FC: '||ai.invoice_num
            INTO l_salida.origen
               , l_salida.destino
               , l_salida.nro_doc
            FROM ap_invoice_distributions_all aid
               , ap_invoices_all              ai
           WHERE aid.invoice_id         = ai.invoice_id
             AND aid.reversal_flag     IS NULL
             AND aid.po_distribution_id = c1.reference_3;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            e_retcode :=1;
            fnd_file.put_line(fnd_file.log, 'No se encontraron datos de origen purchasing reference_3: '||c1.reference_3);

          WHEN TOO_MANY_ROWS THEN
            e_retcode :=1;
            fnd_file.put_line(fnd_file.log,'Distribuci�n de PO aplicada a m�ltiples facturas reference_3: '||c1.reference_3);

          WHEN OTHERS THEN
            e_retcode := 2;
            e_message := 'Error buscando datos de origen purchasing reference_3: '||c1.reference_3||' - '||sqlerrm;
            RAISE e_exception;
         END;

      ELSIF c1.je_source = 'Acopio Fletes' THEN
        BEGIN
          SELECT DISTINCT
                 'CP: '||numero_carta_porte
            INTO l_salida.nro_doc
            FROM xx_aco_cartas_porte_b
           WHERE carta_porte_id = c1.reference_1
          UNION
          --CR2463
          SELECT DISTINCT
                 'CP: '||numero_carta_porte
            FROM xx_tcg_cartas_porte
           WHERE carta_porte_id = c1.reference_1;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            e_retcode :=1;
            fnd_file.put_line(fnd_file.log, 'No se CP reference_1: '||c1.reference_1||', reference_3: '||c1.reference_3);

          WHEN OTHERS THEN
            e_retcode := 2;
            e_message := 'Error buscando CP reference_1: '||c1.reference_1||', reference_3: '||c1.reference_3||' - '||sqlerrm;
            RAISE e_exception;
        END;

        BEGIN
           SELECT DISTINCT
                  (SELECT province_name
                     FROM jl_ar_ap_provinces jaap
                    WHERE jaap.province_code = nvl(aid.attribute7,ai.attribute3)) ORIGEN
                , (SELECT province_name
                     FROM hr_locations hl
                        , jl_ar_ap_provinces jaap
                    WHERE hl.region_2    = jaap.province_code
                      AND hl.location_id = aid.global_attribute3) DESTINO
                , 'FC: '||ai.invoice_num NRO_DOC
                , pv.vendor_name ENTIDAD
             INTO l_salida.origen
                , l_salida.destino
                , l_salida.nro_doc
                , l_salida.entidad
             FROM ap_invoice_distributions_all aid
                , ap_invoices_all ai
                , ap_suppliers pv  -- Upgrate R12  po_vendors
            WHERE ai.vendor_id                 = pv.vendor_id
              AND aid.invoice_id               = ai.invoice_id
              AND aid.line_type_lookup_code    = 'FREIGHT'
              AND aid.reversal_flag         IS NULL
              AND aid.attribute10              = c1.reference_1
              AND pv.vendor_name               = c1.reference_3;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            e_retcode :=1;
            fnd_file.put_line(fnd_file.log,'No se encontraron datos de origen acopio reference_1: '||c1.reference_1||', reference_3: '||c1.reference_3);

          WHEN TOO_MANY_ROWS THEN
            e_retcode :=1;
            fnd_file.put_line(fnd_file.log,'Carta de porte asociada a multiples distribuciones reference_1: '||c1.reference_1||', reference_3: '||c1.reference_3);

          WHEN OTHERS THEN
            e_retcode := 2;
            e_message := 'Error buscando datos de origen acopio reference_1: '||c1.reference_1||', reference_3: '||c1.reference_3||' - '||sqlerrm;
            RAISE e_exception;
        END;
      END IF;

      fnd_file.put_line(fnd_file.output,l_salida.origen_asiento||l_sep||
                                        l_salida.centro_costo  ||l_sep||
                                        l_salida.cuenta        ||l_sep||
                                        l_salida.fecha         ||l_sep||
                                        l_salida.monto         ||l_sep||
                                        l_salida.origen        ||l_sep||
                                        l_salida.destino       ||l_sep||
                                        l_salida.nro_doc       ||l_sep||
                                        l_salida.entidad       ||l_sep);

      l_salida := null;
    END LOOP;

    retcode := e_retcode;

    fnd_file.put_line(fnd_file.log,'Final ejecucion: '||to_char(sysdate, 'HH24:MI:SS'));

  EXCEPTION
    WHEN E_EXCEPTION THEN
      fnd_file.put_line(fnd_file.log, e_message);
      errbuf := e_message;
      retcode := e_retcode;

    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Error no atrapado: '||sqlerrm);
      errbuf  := 'Error no atrapado: '||sqlerrm;
      retcode := 2;

  END main;

END XX_AR_AP_CM05_PKG;
/

exit
