UPDATE ap_invoices_all ai
SET    global_attribute12 = 'A'
     , global_attribute13 = '01'
     , last_update_date = sysdate
     , last_updated_by = -1
     , last_update_login = -1
WHERE  (invoice_num, (SELECT vendor_name
                      FROM   ap_suppliers asup
                      WHERE  asup.vendor_id  = ai.vendor_id)) IN
(('0003-00000007','GIGLI PABLO'),
('0003-00000026','SUÑER DAMARIS ARIANA'),
('0003-00000006','GIGLI PABLO'));
--3 Registro