UPDATE ap_invoices_all
SET    global_attribute9 = '19001IC04198741C'
WHERE  invoice_num = '0004-00178741';
--1 Registro