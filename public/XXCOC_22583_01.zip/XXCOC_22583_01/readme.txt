﻿----------------------------------------------------------------------------
-- +====================================================================+ --
-- |                              TRI-CS                                | --
-- |                   Todos os direitos reservados                     | --
-- +====================================================================+ --
-- |                                                                    | --
-- |  # Codigo:    XXCOC_22583_01                                         | --
-- |                                                                    | --
-- |  # Descrição: 22583 -  Restrição Item SDC - Tela OAF               | --
-- |                                                                    | --
-- |  # Versão:    1.0                                                  | --
-- |  # Data:      11/05/2020                                           | --
-- |  # Autor:     Mariana Andrade Resende                              | --
-- |                                                                    | --
-- +====================================================================+ --

----------------------------------------------------------------------------
###### 1. Pré-Instalação:                                             ######
----------------------------------------------------------------------------

  1.1) Para mais detalhes:

    - XXCOC_22583_01/doc/TRI_COCAL_Restrição_Item_SDC_Tela_OAF_MD070_v1.0.docx

  1.2) Verificar se o Owner customizado (XXCOC) existe para a instalação deste patch.
       Caso não exista é necessario que o owner customizado (XXCOC) seja criado corretamente tanto no banco de dados quanto na aplicação.

  1.3) Substituir $APPS_PWD pela senha do usuario APPS no Banco de Dados.
        
----------------------------------------------------------------------------
###### 2. Instalação:                                                 ######
----------------------------------------------------------------------------
  2.1) Execute os comandos abaixo no UNIX:

     2.1.1) Copie o arquivo XXCOC_22583_01.zip para $APPL_TOP/patches.

     2.1.2) Execute os comandos abaixo para descompactar o patch

        cd $APPL_TOP/patches
        unzip XXCOC_22583_01.zip
        cd XXCOC_22583_01
        

     2.1.3) Verifique se os diretorios abaixo existem, se não, criar os diretórios:

        $JAVA_TOP/xxcoc/oracle/apps/po/autocreate/webui/
 

     2.1.4) Execute os comandos abaixo para copiar os arquivos:
          # ----------------------------------------------------------------------  
          
         cp -f xxcoc/misc/XxcocReqSearchCO.class           $JAVA_TOP/xxcoc/oracle/apps/po/autocreate/webui/XxcocReqSearchCO.class
 
 
     2.1.5) Seguir os passos descritos para criar as Personalizações:
          # ----------------------------------------------------------------------
            
          # Seguir os passos descritos no 'Instruções de Instalação' do documento MD070 
            "XXCOC_22583_01/doc/TRI_COCAL_Restrição_Item_SDC_Tela_OAF_MD070_v1.0.docx" 
            para efetuar a criação das Personalizações 'OAF'.
        
    
---------------------------------------------------------------------------
###### 3. Pós-Instalação                                             ######
---------------------------------------------------------------------------
 
  3.1) Executar o bounce OAF

       cd $INST_TOP/admin/scripts
      
       - PARAR
         ./adoacorectl.sh stop
      
       - INICIAR
         ./adoacorectl.sh start
      
 
# *** Fim da Aplicação ***
# *** Verifique TODOS os logs para garantir que o patch foi aplicado corretamente ***
