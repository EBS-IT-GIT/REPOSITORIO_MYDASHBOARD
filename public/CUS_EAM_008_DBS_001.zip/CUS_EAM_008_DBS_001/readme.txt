==============================================================================
CUSEAM008_001 : Sistema de Ferramentaria 
==============================================================================

Atualiza��o - CUSEAM008_001
Produto     - XX Customizaciones
Data        - 15/09/2020 14:07:16
HotPatch    - N�o
Fornecedor  - HQS Plus

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSEAM008_001

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

    * Realizar as personaliza��es descritas no documento do diretorio 
      CUS_EAM_008_HQS_001\docs\CUS_EAM_008_BR100_Sistema de Ferramentaria.docx
    * Realizar um bounce no OACORE.


Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

N/A

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: SAE_EAM_INFO_FERRAMENTA.tab
                               SAE_EAM_INFO_FERRAMENTA.grt
                               SAE_EAM_INFO_FERRAMENTA.syn
                               SAE_EAM_INFO_FERRAMENTA_S.seq
                               SAE_EAM_INFO_FERRAMENTA_S.grt
                               SAE_EAM_INFO_FERRAMENTA_S.syn
                               SAE_EAM_FERRAMENTARIA_PKS.pls
                               SAE_EAM_FERRAMENTARIA_PKB.pls
                               SAE_EAM_FERRAMENTARIA_PK.grt
                               SAE_EAM_FERRAMENTARIA_PK.syn
                               SAE_EAM_INFO_FERRAMENTA_V.vw
                               SAE_EAM_INFO_FERRAMENTA_V.syn
                               SAE_MTL_MATERIAL_TRANS_TRG.trg
                               SAE_MTL_SERIAL_NUMBERS_TRG.trg
                               SAE_EAM_CARGA_FERRAMENTA.sql
                               SAE_EAM_INFO_FERRAMENTA_FNC.ldt
                               jSAECUSEAM008.zip
                               SaeEamFerOSLovRN.xml
                               SaeEamItensFerramentasLovRN.xml
                               SaeEamObsDevLovRN.xml
                               SaeEamSubinvFerramentariaLovRN.xml
                               SaeEamBancadaFerramentariaPG.xml
                               SaeEamFerramentaPG.xml
