WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE 

-- $Header: SAE_SENIOR_DBL.sql 121.1 08/10/2020 14:07:16 appldev ship $
-- +==================================================================+
-- |                      SANTO ANTONIO ENERGIA                       |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   SAE_SENIOR_DBL.sql                                             |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUS008                                                         |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   Synonym para SAE_SENIOR_DBL                                    |
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan de Castro Gomes      08/10/2020                          |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--

CREATE DATABASE LINK sae_senior
CONNECT TO vetorh IDENTIFIED BY odi2mh0m43
USING '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.142.19.5)(PORT = 1521)) (CONNECT_DATA =(SERVICE_NAME = HSEN)))'

/

WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
