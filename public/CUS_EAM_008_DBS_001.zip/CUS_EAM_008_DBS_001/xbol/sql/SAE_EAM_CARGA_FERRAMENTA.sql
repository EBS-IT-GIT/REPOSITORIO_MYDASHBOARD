WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

DECLARE
-- $Header: SAE_EAM_CARGA_FERRAMENTA.sql 121.3 21/09/2020 14:07:16 appldev ship $
-- +==================================================================+
-- |                      SANTO ANTONIO ENERGIA                       |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   SAE_EAM_CARGA_FERRAMENTA.sql                                   |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUS008                                                         |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   SQL SCRIPT                                                     |
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan de Castro Gomes      04/09/2020                          |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--
BEGIN
  -- Carga inicial de dados de Ferrramentas
  FOR ferr_serie IN (SELECT msn.inventory_item_id
                          , msn.serial_number 
                       FROM mtl_serial_numbers msn
                          , mtl_system_items_b msi
                      WHERE msn.inventory_item_id = msi.inventory_item_id
                        AND msi.organization_id   = (SELECT organization_id FROM mtl_parameters WHERE organization_code = 'MST') 
                        AND segment1              LIKE 'FER%'
                        ) LOOP
    --                        
    BEGIN 
      UPDATE mtl_serial_numbers
         SET c_attribute30 = 'X'
       WHERE inventory_item_id = ferr_serie.inventory_item_id
         AND serial_number     = ferr_serie.serial_number;
      EXCEPTION 
        WHEN OTHERS THEN 
          NULL;
    END;        
    COMMIT;
    
    BEGIN 
      UPDATE mtl_serial_numbers
         SET c_attribute30 = NULL
       WHERE inventory_item_id = ferr_serie.inventory_item_id
         AND serial_number     = ferr_serie.serial_number;
      EXCEPTION 
        WHEN OTHERS THEN 
          NULL;
    END;        
    COMMIT; 
       
  END LOOP;  
  
  
  -- Itens sem controle de Serie
  FOR ferr_trans IN (SELECT mmt.transaction_id
                       FROM mtl_material_transactions mmt
                          , mtl_system_items_b msi
                       WHERE mmt.inventory_item_id = msi.inventory_item_id
                         AND mmt.organization_id   = msi.organization_id
                         AND ((mmt.subinventory_code LIKE 'FER%' AND LENGTH(mmt.subinventory_code) = 6)
                           OR (mmt.transfer_subinventory LIKE 'FER%' AND LENGTH(mmt.transfer_subinventory) = 6)) 
                         AND msi.segment1          LIKE 'FER%'
                         AND msi.serial_number_control_code = 1) LOOP
                         
    BEGIN 
      UPDATE mtl_material_transactions
         SET attribute15 = 'X'
       WHERE transaction_id = ferr_trans.transaction_id; 
      EXCEPTION 
        WHEN OTHERS THEN 
          NULL;
    END;        
    COMMIT;
    
    BEGIN 
      UPDATE mtl_material_transactions
         SET attribute15 = NULL
       WHERE transaction_id = ferr_trans.transaction_id; 
      EXCEPTION 
        WHEN OTHERS THEN 
          NULL;
    END;        
    COMMIT;
  END LOOP;                     
END;
-- Indicativo de final de arquivo. Nao deve ser removido.

/

WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
