UPDATE apps.ar_payment_schedules_all aps
SET    trx_number =DECODE(trx_number
             ,'E-0001-00002200', 'A-0001-00002170'
             ,'E-0001-00002188', 'A-0001-00002170'
             ,'E-0001-00002143', 'A-0001-00002109'
             ,'E-0001-00002136', 'A-0001-00002040'
             ,'E-0001-00000337', 'A-0001-00000617'
             ,trx_number)
WHERE  trx_number IN ('E-0001-00000337', 'E-0001-00002136', 'E-0001-00002143', 'E-0001-00002188','E-0001-00002200')
AND    org_Id = 192
AND    trx_date >= '01-01-2020';
--4 Registros