UPDATE apps.ap_invoices_all ai
SET    invoice_date = decode(invoice_date, '08/05/2020', '07/07/2020', '08/06/2020', '04/08/2020', invoice_date)
      ,last_update_date = sysdate
      ,last_updated_by = 2070
WHERE  invoice_num IN ('0001-20200508','0001-20200608')
AND    vendor_id = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'TELEFONICA DE ARGENTINA S.A.');   
--2 Registros