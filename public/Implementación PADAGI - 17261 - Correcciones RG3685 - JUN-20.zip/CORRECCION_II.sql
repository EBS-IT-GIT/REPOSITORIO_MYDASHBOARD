UPDATE apps.ap_invoice_distributions_all aid
SET    attribute2 = 'FC INTERNA', attribute3 = 'Y'
     , last_update_date = sysdate, last_updated_by = 2070
WHERE (attribute4, (SELECT vendor_name 
                    FROM apps.ap_suppliers WHERE vendor_id = aid.attribute5)) IN (
('0001-00000124','PIRACUA SAS'),
('0002-00000307','ROSSO MARCELO DOMINGO'),
('0002-00000311','ROSSO MARCELO DOMINGO'));
--18 Registros