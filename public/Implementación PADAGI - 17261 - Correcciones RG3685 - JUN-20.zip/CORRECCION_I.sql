UPDATE apps.ap_invoices_all ai
SET    invoice_date = decode(invoice_date, '01/07/2020', '01/06/2020', '03/07/2020', '03/06/2020', invoice_date)
      ,last_update_date = sysdate
      ,last_updated_by = 2070
WHERE  invoice_num IN ('0004-00000235','0004-00000242','0004-00000243','0004-00000246','0004-00000247','0004-00000248')
AND    vendor_id = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'HUMBER SA');
--6 Registros