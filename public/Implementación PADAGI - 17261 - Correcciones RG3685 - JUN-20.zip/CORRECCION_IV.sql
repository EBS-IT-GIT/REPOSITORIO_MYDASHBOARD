UPDATE apps.ap_invoice_distributions_all aid
SET    attribute2 = 'FC GASOIL'
      ,last_update_date = sysdate
      ,last_updated_by = 2070
WHERE  attribute4 = '0004-00003707';
--12 Registros