UPDATE apps.ap_invoices_all
SET    global_attribute12 = 'A'
      ,global_attribute13 = '01'
WHERE  invoice_num = '0002-00000673'
AND    vendor_id = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'DENUNCIO EDUARDO DAMINO');
--1 Registro