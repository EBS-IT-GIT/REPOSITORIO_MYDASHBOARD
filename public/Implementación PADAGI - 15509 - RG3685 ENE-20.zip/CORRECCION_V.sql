UPDATE apps.ap_invoice_distributions_all aid
SET    attribute6 = '2019/12/16 00:00:00'
WHERE  attribute4 = '0006-00073799'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'ROMERO SOCIEDAD DE RESPONSABILIDAD LIMITADA');
--6 Registros