UPDATE apps.ap_invoices_all
SET    invoice_num ='0002-00000002'
WHERE  invoice_num = '0002--00000002';
--1 Registro