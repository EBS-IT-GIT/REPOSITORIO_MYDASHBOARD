UPDATE apps.ap_invoices_all
SET    invoice_num = '0055-00022278'
WHERE  invoice_num = '0055--00022278';
--1 Registro