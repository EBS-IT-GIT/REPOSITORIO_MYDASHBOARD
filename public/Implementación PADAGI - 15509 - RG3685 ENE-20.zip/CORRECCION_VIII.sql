UPDATE apps.ap_invoices_all ai
SET    global_attribute11 = 'FC INTERNA', global_attribute12 = 'Y', global_attribute13 = '99'
WHERE  invoice_num IN ('0001-00014723','0001-00014724')
AND    vendor_id = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name='HOTEL SOLAR S.A.');
--2 Registros