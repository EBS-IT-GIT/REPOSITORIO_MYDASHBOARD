UPDATE apps.ap_invoice_distributions_all aid
SET    attribute6 = '2019/12/26 00:00:00'
WHERE  attribute4 = '0005-00270561'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'CRACCO ADOLFO INOSENCIO');
--6 Registros