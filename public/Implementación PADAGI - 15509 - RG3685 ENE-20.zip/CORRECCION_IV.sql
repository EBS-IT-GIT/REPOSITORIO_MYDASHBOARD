UPDATE apps.ap_invoice_distributions_all aid
SET    attribute3 = 'Y'
WHERE  attribute4 = '0002-00000987'
AND    attribute5 = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'FF GANADERIA EL ORDEN');
--3 Registros