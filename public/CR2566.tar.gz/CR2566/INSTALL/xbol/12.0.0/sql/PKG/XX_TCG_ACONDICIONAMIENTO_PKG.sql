  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_TCG_ACONDICIONAMIENTO_PKG" AUTHID CURRENT_USER AS




/***************************************************************************
 *                                                                          *
 * Name    : Get_acond_id                                                   *
 * Purpose : Rutina que devuelve la línea de costo de Acondicionamiento     *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_acond_id ( p_contrato_id            IN NUMBER
                         , p_estab_destino_id      IN NUMBER
                         , p_empresa_destino_id    IN NUMBER
                         , p_zona_destino_code     IN VARCHAR2
                         , p_tipo_productor        IN VARCHAR2
                         , p_item_oncca_code       IN VARCHAR2
                         , p_fecha_recepcion       IN DATE
                         , p_acondicionamiento_id OUT NUMBER
                         , p_result               OUT BOOLEAN
                         , p_error_msg            OUT VARCHAR2);




/***************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Secada                                              *
 * Purpose : Rutina que devuelve la tarifa de Secada según las condiciones  *
 *           de acondicionamiento                                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Secada( p_carta_porte_id   IN NUMBER
                             , p_linea_costo      IN NUMBER
                             , x_tarifa_secada   OUT NUMBER
                             , x_moneda          OUT VARCHAR2
                             , x_result          OUT BOOLEAN
                             , x_error_msg       OUT VARCHAR2);




/***************************************************************************
 *                                                                          *
 * Name    : Get_Secada                                                     *
 * Purpose : Rutina que devuelve la merma, la tarifa y el importe de Secada *
 *           según las condiciones de acondicionamiento                     *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Secada ( p_carta_porte_id  IN NUMBER
                       , p_linea_costo     IN NUMBER
                       , p_merma_secada   OUT NUMBER
                       , p_tarifa_secada  OUT NUMBER
                       , p_importe_secada OUT NUMBER
                       , p_moneda         OUT VARCHAR2
                       , p_result         OUT BOOLEAN
                       , p_error_msg      OUT VARCHAR2);





/*****************************************************************************
 *                                                                           *
 * Name    : Get_Zaranda                                                     *
 * Purpose : Rutina que devuelve la merma, la tarifa y el importe de Zaranda *
 *           según las condiciones de acondicionamiento                      *
 *                                                                           *
 ****************************************************************************/
  PROCEDURE Get_Zaranda ( p_carta_porte_id    IN NUMBER
                        , p_linea_costo       IN NUMBER
                        , p_merma_zaranda    OUT NUMBER
                        , p_tarifa_zaranda   OUT NUMBER
                        , p_importe_zaranda  OUT NUMBER
                        , p_moneda           OUT VARCHAR2
                        , p_result           OUT BOOLEAN
                        , p_error_msg        OUT VARCHAR2);




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Paritaria                                                   *
 * Purpose : Rutina que devuelve la tarifa y el importe de Paritaria         *
 *           según las condiciones de acondicionamiento                      *
 *                                                                           *
 ****************************************************************************/
  PROCEDURE Get_Paritaria ( p_carta_porte_id      IN NUMBER
                          , p_linea_costo         IN NUMBER
                          , p_tarifa_paritaria   OUT NUMBER
                          , p_importe_paritaria  OUT NUMBER
                          , p_moneda             OUT VARCHAR2
                          , p_result             OUT BOOLEAN
                          , p_error_msg          OUT VARCHAR2);




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Fumigacion                                                  *
 * Purpose : Rutina que devuelve la tarifa y el importe de Fumigada          *
 *           según las condiciones de acondicionamiento                      *
 *                                                                           *
 ****************************************************************************/
  PROCEDURE Get_Fumigacion ( p_carta_porte_id       IN NUMBER
                           , p_linea_costo          IN NUMBER
                           , p_tarifa_fumigacion   OUT NUMBER
                           , p_importe_fumigacion  OUT NUMBER
                           , p_moneda              OUT VARCHAR2
                           , p_result              OUT BOOLEAN
                           , p_error_msg           OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Set_Lineas_Liq1116                                             *
 * Purpose : Rutina que crea las líneas de los Certificados (1116A) con las *
 *          memo_lines de cálculo automático                                *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Set_Lineas_Liq1116A ( p_liquidacion_id  IN NUMBER
                                , p_contrato_id     IN NUMBER
                                , p_boletin_hdr_id  IN NUMBER
                                , p_operating_unit  IN NUMBER
                                , p_tabla_aux       IN BOOLEAN
                                , p_result         OUT BOOLEAN
                                , p_error_msg      OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Cantidad_Memolines_1116A                                       *
 * Purpose : Devuelve la cantidad de servicios automáticos configurados     *
 *                                                                          *
 ****************************************************************************/
 PROCEDURE Cantidad_Memolines_1116A ( p_operating_unit  IN NUMBER
                                    , p_cant_memolines OUT NUMBER
                                    , p_result         OUT BOOLEAN
                                    , p_error_msg      OUT VARCHAR2);




/***************************************************************************
 *                                                                          *
 * Name    : Obtener_Servicios_Automaticos                                  *
 * Purpose : Procedimiento que obtiene los valores de importe, tarifa y     *
 *          mermas de los servicios automáticos, para una carta de porte    *
 *          dada                                                            *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Obtener_Servicios_Automaticos ( p_carta_porte_id         IN NUMBER
                                          , p_operating_unit         IN NUMBER
                                          , p_contrato_id            IN NUMBER DEFAULT NULL
                                          , p_solo_importes          IN BOOLEAN
                                          , p_acond_id              OUT NUMBER
                                          , p_merma_secada          OUT NUMBER
                                          , p_tarifa_secada         OUT NUMBER
                                          , p_importe_secada        OUT NUMBER
                                          , p_merma_zaranda         OUT NUMBER
                                          , p_tarifa_zaranda        OUT NUMBER
                                          , p_importe_zaranda       OUT NUMBER
                                          , p_tarifa_paritaria      OUT NUMBER
                                          , p_importe_paritaria     OUT NUMBER
                                          , p_tarifa_fumigacion     OUT NUMBER
                                          , p_importe_fumigacion    OUT NUMBER
                                          , p_tarifa_otros_gastos   OUT NUMBER
                                          , p_importe_otros_gastos  OUT NUMBER
                                          , p_tarifa_almacenaje     OUT NUMBER
                                          , p_importe_almacenaje    OUT NUMBER
                                          , p_tarifa_refactu_flete  OUT NUMBER
                                          , p_importe_refactu_flete OUT NUMBER
                                          , p_moneda_acond          OUT VARCHAR2
                                          , p_moneda_contrato       OUT VARCHAR2
                                          , p_result                OUT BOOLEAN
                                          , p_error_msg             OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Svcs_Automaticos_Asignados                                     *
 * Purpose : Devuelve TRUE si todos los servicios automáticos ya fueron     *
 *          asignados al Certificado                                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Svcs_Automaticos_Asignados ( p_liquidacion_id    IN NUMBER
                                       , p_operating_unit    IN NUMBER
                                       , p_result           OUT BOOLEAN
                                       , p_error_msg        OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Actualizar_Gastos_Acdmto_CP                                    *
 * Purpose : Procedimiento para insertar/actualizar los valores de svcs     *
 *           por Carta de Porte en la tabla XX_TCG_GASTO_ACONDICIONAMIENTO  *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Actualizar_Gastos_Acdmto_CP ( p_certificado_id        IN NUMBER DEFAULT NULL
                                        , p_carta_porte_id        IN NUMBER
                                        , p_acondicionamiento_id  IN NUMBER
                                        , p_eliminar_registro     IN BOOLEAN
                                        , p_tarifa_secada         IN NUMBER DEFAULT NULL
                                        , p_importe_secada        IN NUMBER DEFAULT NULL
                                        , p_tarifa_zaranda        IN NUMBER DEFAULT NULL
                                        , p_importe_zaranda       IN NUMBER DEFAULT NULL
                                        , p_tarifa_paritaria      IN NUMBER DEFAULT NULL
                                        , p_importe_paritaria     IN NUMBER DEFAULT NULL
                                        , p_tarifa_fumigacion     IN NUMBER DEFAULT NULL
                                        , p_importe_fumigacion    IN NUMBER DEFAULT NULL
                                        , p_result               OUT BOOLEAN
                                        , p_error_msg            OUT VARCHAR2);




/****************************************************************************
 *                                                                          *
 * Name    : Get_Parametros_Secada                                          *
 * Purpose : Procedimiento para obtener los valores de Secada para informar *
 *           a la AFIP                                                      *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Parametros_Secada ( p_acond_id              IN NUMBER
                                  , p_merma_header_id       IN NUMBER
                                  , p_porc_rango_inferior  OUT NUMBER
                                  , p_porc_rango_superior  OUT NUMBER
                                  , p_tarifa               OUT NUMBER
                                  , p_tarifa_exceso        OUT NUMBER
                                  , p_result               OUT BOOLEAN
                                  , p_error_msg            OUT VARCHAR2);


END XX_TCG_ACONDICIONAMIENTO_PKG;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_TCG_ACONDICIONAMIENTO_PKG" AS


-------------------------------------------------------------------------------
--                             Rutinas privadas                              --
-------------------------------------------------------------------------------




/***************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Secada_Rango                                        *
 * Purpose : Rutina que devuelve la tarifa cada 100 kg por Secada, obtenida *
 *           mediante el método de tipo Rango                               *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Secada_Rango( p_acond_id         IN NUMBER
                                   , p_pct_humedad      IN NUMBER
                                   , x_tarifa_secada   OUT NUMBER
                                   , x_result          OUT BOOLEAN
                                   , x_error_msg       OUT VARCHAR2) IS


   l_tabla          VARCHAR2(255);
   l_ref_s_ton      NUMBER;
   l_valor          NUMBER;
   l_tipo_calculo   VARCHAR2(10);


   CURSOR c_acond IS
     SELECT tabla
          , NVL(ref_s_ton, 0) ref_s_ton
       FROM XX_TCG_ACONDICIONAMIENTO
      WHERE acond_id = p_acond_id;


   CURSOR c_secada (p_costo_secada_id NUMBER) IS
     SELECT NVL(xtd.cantidad, 0) cantidad
          , xth.calcula_por
       FROM XX_TCG_COSTOS_SECADA_HDR xth
          , XX_TCG_COSTOS_SECADA_DTL xtd
      WHERE xth.costo_secada_id = xtd.costo_secada_id
        AND xth.costo_secada_id = p_costo_secada_id
        AND p_pct_humedad BETWEEN humedad_desde AND humedad_hasta
        AND active_flag = 1;

  BEGIN

    x_result := TRUE;

    -- Datos del acondicionamiento
    OPEN c_acond;
    FETCH c_acond INTO l_tabla
                     , l_ref_s_ton;
    CLOSE c_acond;


    -- Datos de la secada
    OPEN c_secada (l_tabla);
    FETCH c_secada INTO l_valor
                      , l_tipo_calculo;
    CLOSE c_secada;


    IF (l_tipo_calculo = 'IMPORTE') THEN

      --CR1273 x_tarifa_secada  := ROUND((100 * l_valor /1000), 2);                       -- Tarifa cada 100 kg recibidos
      x_tarifa_secada  := 100 * l_valor /1000;

    ELSIF (l_tipo_calculo = 'KILOS') THEN

      --CR1273 x_tarifa_secada  := ROUND(((l_valor/100) * l_ref_s_ton * 100 / 1000), 2);    -- Tarifa cada 100 kg recibidos
                                 -- l_valor se divide por 100 porque es un porcentaje
      x_tarifa_secada  := (l_valor/100) * l_ref_s_ton * 100 / 1000;

    END IF;


  EXCEPTION
    WHEN OTHERS THEN
      x_tarifa_secada := 0;
      x_result        := FALSE;
      x_error_msg     := 'Error en Get_Tarifa_Secada_Rango. '||SQLERRM;

  END Get_Tarifa_Secada_Rango;





/***************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Secada_Punto                                        *
 * Purpose : Rutina que devuelve la tarifa cada 100 kg por Secada, obtenida *
 *           mediante el método de tipo Punto                               *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Secada_Punto ( p_acond_id            IN NUMBER
                                    , p_pct_humedad         IN NUMBER
                                    , p_merma_hdr_id        IN NUMBER
                                    , x_tarifa_secada      OUT NUMBER
                                    , x_result             OUT BOOLEAN
                                    , x_error_msg          OUT VARCHAR2) IS

    l_medicion           NUMBER;
    l_cant_ptos_libres   NUMBER;
    l_cant_ptos_exceso   NUMBER;
    l_tar_pto_normal_ton NUMBER;
    l_tar_pto_exc_ton    NUMBER;
    l_pct_humedad_base   NUMBER;
    l_rango              NUMBER;
    l_ptos_a_pagar       NUMBER;
    l_ptos_en_exceso     NUMBER;
    l_ptos_normal        NUMBER;



    CURSOR c_merma IS
      SELECT MIN(medicion) medicion
        FROM XX_ACO_MERMA_LINES
       WHERE merma_header_id = p_merma_hdr_id;


   CURSOR c_acond IS
     SELECT NVL(s_pto_libre, 0)  cant_ptos_libres
          , NVL(s_pto_exc, 0)    cant_ptos_exceso
          , NVL(s_pto_ton, 0)    tarifa_pto_normal_ton
          , NVL(s_pto_adic, 0)   tarifa_pto_exc_ton
       FROM XX_TCG_ACONDICIONAMIENTO
      WHERE acond_id = p_acond_id;



 BEGIN

   x_result := TRUE;

   OPEN c_merma;
   FETCH c_merma INTO l_medicion;
   CLOSE c_merma;


   OPEN c_acond;
   FETCH c_acond INTO l_cant_ptos_libres
                    , l_cant_ptos_exceso
                    , l_tar_pto_normal_ton
                    , l_tar_pto_exc_ton;
   CLOSE c_acond;

   --Según la tabla merma humedad que figura en la CP, el primer porcentaje de humedad configurado,
   --se toma como humedad base
   l_pct_humedad_base := l_medicion;

   IF (p_pct_humedad < l_pct_humedad_base) THEN
     x_tarifa_secada := 0;
     RETURN;
   END IF;

   --Rango de tabla para evaluar => Truncar(Humedad CP - Humedad Base + 1)
   l_rango             := TRUNC(p_pct_humedad - l_pct_humedad_base + 1);

    --Ptos a pagar => A rango de tabla restarle los puntos libres de secada
   l_ptos_a_pagar      := l_rango - l_cant_ptos_libres;

   --Ptos a aplicar tarifa en exceso => Si ptos exceso es mayor a cero, se calcula Rango de tabla - exceso
   --Si el rango es menor a los puntos en exceso, significa que no se cobraran puntos en exceso, con lo cual
   --ptos en exceso quedan en cero.( l_rango > l_cant_ptos_exceso ) - AB C# 2242
   --IF l_cant_ptos_exceso > 0
   IF l_rango > l_cant_ptos_exceso THEN
     l_ptos_en_exceso  := l_rango - l_cant_ptos_exceso;
   ELSE
     l_ptos_en_exceso  := 0;
   END IF;

   -- Ptos a aplicar tarifa normal => Ptos a pagar - ptos a aplicar exceso
   l_ptos_normal        := l_ptos_a_pagar - l_ptos_en_exceso;


   IF (l_ptos_en_exceso = 0) THEN
     --CR1273  x_tarifa_secada  := ROUND((l_ptos_normal * l_tar_pto_normal_ton * 100 / 1000), 2);        -- Tarifa cada 100 kg recibidos
     x_tarifa_secada  := l_ptos_normal * l_tar_pto_normal_ton * 100 / 1000;

   ELSE
     --CR1273 x_tarifa_secada  := ROUND((l_ptos_normal * l_tar_pto_normal_ton * l_ptos_en_exceso * l_tar_pto_exc_ton * 100 / 1000), 2);
     --CR1951 -- ABARACCA --x_tarifa_secada  := l_ptos_normal * l_tar_pto_normal_ton * l_ptos_en_exceso * l_tar_pto_exc_ton * 100 / 1000;
     x_tarifa_secada  := ( l_ptos_normal * l_tar_pto_normal_ton * 100 / 1000 ) + ( l_ptos_en_exceso * l_tar_pto_exc_ton * 100 / 1000 );

   END IF;

   x_tarifa_secada := NVL(x_tarifa_secada, 0);

 EXCEPTION
   WHEN OTHERS THEN
     x_result    := FALSE;
     x_error_msg := 'Error en Get_Tarifa_Secada_Punto. '||SQLERRM;

  END Get_Tarifa_Secada_Punto;





/***************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Secada                                              *
 * Purpose : Rutina que devuelve la tarifa cada 100 kg de Secada según las  *
 *           condiciones de acondicionamiento                               *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Secada( p_carta_porte_id   IN NUMBER
                             , p_linea_costo      IN NUMBER
                             , x_tarifa_secada   OUT NUMBER
                             , x_moneda          OUT VARCHAR2
                             , x_result          OUT BOOLEAN
                             , x_error_msg       OUT VARCHAR2) IS

    l_tipo_secada    VARCHAR2(255);
    l_pct_humedad    NUMBER;
    l_merma_id       NUMBER;


    CURSOR c_acond IS
      SELECT tipo
           , moneda
        FROM XX_TCG_ACONDICIONAMIENTO
       WHERE acond_id = p_linea_costo;


    CURSOR c_carta_porte IS
      SELECT pctaje_humedad_recep
           , merma_header_id
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


  BEGIN

    x_result := TRUE;

    OPEN c_acond;
    FETCH c_acond INTO l_tipo_secada
                     , x_moneda;
    CLOSE c_acond;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_pct_humedad
                           , l_merma_id;
    CLOSE c_carta_porte;


    IF (l_tipo_secada = 'RANGO') THEN

      Get_Tarifa_Secada_Rango( p_acond_id           => p_linea_costo
                             , p_pct_humedad        => l_pct_humedad
                             , x_tarifa_secada      => x_tarifa_secada
                             , x_result             => x_result
                             , x_error_msg          => x_error_msg);


    ELSIF (l_tipo_secada = 'PUNTO') THEN

      Get_Tarifa_Secada_Punto ( p_acond_id           => p_linea_costo
                              , p_pct_humedad        => l_pct_humedad
                              , p_merma_hdr_id       => l_merma_id
                              , x_tarifa_secada      => x_tarifa_secada
                              , x_result             => x_result
                              , x_error_msg          => x_error_msg);

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Tarifa_Secada. '||SQLERRM;

  END Get_Tarifa_Secada;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Importe_Secada                                             *
 * Purpose : Rutina que devuelve el importe de Secada según las condiciones *
 *           de acondicionamiento en la recepción                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Importe_Secada( p_carta_porte_id   IN NUMBER
                              , p_linea_costo      IN NUMBER
                              , x_importe_secada   OUT NUMBER
                              , x_moneda           OUT VARCHAR2
                              , x_result           OUT BOOLEAN
                              , x_error_msg        OUT VARCHAR2) IS

     l_tarifa_secada  NUMBER;
     l_peso_neto      NUMBER;


     CURSOR c_carta_porte IS
       SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
         FROM XX_TCG_CARTAS_PORTE_ALL
        WHERE carta_porte_id = p_carta_porte_id;


  BEGIN

    x_result := TRUE;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto;
    CLOSE c_carta_porte;

    Get_Tarifa_Secada( p_carta_porte_id  => p_carta_porte_id
                     , p_linea_costo     => p_linea_costo
                     , x_tarifa_secada   => l_tarifa_secada
                     , x_moneda          => x_moneda
                     , x_result          => x_result
                     , x_error_msg       => x_error_msg);

    IF (NOT x_result) THEN
      RETURN;
    END IF;

    x_importe_secada := ROUND((l_peso_neto * l_tarifa_secada / 100), 2);

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Importe_Secada. '||SQLERRM;

  END Get_Importe_Secada;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Zaranda                                             *
 * Purpose : Rutina que devuelve la tarifa de Zaranda cada 100 Kg de        *
 *           producto recibido según las condiciones de acondicionamiento   *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Zaranda( p_carta_porte_id    IN NUMBER
                              , p_linea_costo       IN NUMBER
                              , x_tarifa_zaranda   OUT NUMBER
                              , x_moneda           OUT VARCHAR2
                              , x_result           OUT BOOLEAN
                              , x_error_msg        OUT VARCHAR2) IS

    l_costo_zaranda  NUMBER;

    CURSOR c_acond IS
      SELECT NVL(zaranda, 0) zaranda   -- $/ton
           , moneda
        FROM XX_TCG_ACONDICIONAMIENTO
       WHERE acond_id = p_linea_costo;


  BEGIN

    x_result := TRUE;

    OPEN c_acond;
    FETCH c_acond INTO l_costo_zaranda
                     , x_moneda;
    CLOSE c_acond;

    --CR1273 x_tarifa_zaranda := ROUND((NVL(l_costo_zaranda, 0) / 1000 * 100), 2);    -- Tarifa cada 100 kg
    x_tarifa_zaranda := NVL(l_costo_zaranda, 0) / 1000 * 100;


  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Tarifa_Zaranda. '||SQLERRM;

  END Get_Tarifa_Zaranda;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Importe_Zaranda                                            *
 * Purpose : Rutina que devuelve el importe por Zaranda del producto        *
 *           recibido según las condiciones de acondicionamiento            *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Importe_Zaranda( p_carta_porte_id    IN NUMBER
                               , p_linea_costo       IN NUMBER
                               , x_importe_zaranda  OUT NUMBER
                               , x_moneda           OUT VARCHAR2
                               , x_result           OUT BOOLEAN
                               , x_error_msg        OUT VARCHAR2) IS

    l_tarifa_zaranda    NUMBER;
    l_peso_neto         NUMBER;
    l_pctaje_zaranda    NUMBER; -- CR1273

    CURSOR c_carta_porte IS
      SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
           , NVL(pctaje_zaranda_recep, 0)            pctaje_zaranda   --CR1273
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


  BEGIN

    x_result := TRUE;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto
                           , l_pctaje_zaranda;
    CLOSE c_carta_porte;

    IF (l_pctaje_zaranda > 0) THEN

       Get_Tarifa_Zaranda( p_carta_porte_id   => p_carta_porte_id
                         , p_linea_costo      => p_linea_costo
                         , x_tarifa_zaranda   => l_tarifa_zaranda     -- tarifa expresada cada 100 kg
                         , x_moneda           => x_moneda
                         , x_result           => x_result
                         , x_error_msg        => x_error_msg);

      IF (NOT x_result) THEN
        RETURN;
      END IF;

      x_importe_zaranda :=  l_peso_neto * l_tarifa_zaranda / 100;

    ELSE

      x_importe_zaranda := 0;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error Get_Importe_zaranda. '||SQLERRM;

  END Get_Importe_Zaranda;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Paritaria                                           *
 * Purpose : Rutina que devuelve la tarifa de Paritaria para el producto    *
 *           recibido, según el importe configurado en la línea de          *
 *           Acondicionamiento                                              *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Paritaria ( p_carta_porte_id    IN NUMBER
                                 , p_linea_costo       IN NUMBER
                                 , x_tarifa_paritaria  OUT NUMBER
                                 , x_moneda            OUT VARCHAR2
                                 , x_result            OUT BOOLEAN
                                 , x_error_msg         OUT VARCHAR2)
  IS

    CURSOR c_acond IS
      SELECT NVL(paritaria, 0) paritaria
           , moneda
        FROM XX_TCG_ACONDICIONAMIENTO
       WHERE acond_id = p_linea_costo;

    l_costo_paritaria    NUMBER;

  BEGIN

    x_result := TRUE;

    OPEN c_acond;
    FETCH c_acond INTO l_costo_paritaria   -- $/ton
                     , x_moneda;
    CLOSE c_acond;

    --CR1273 x_tarifa_paritaria := ROUND((NVL(l_costo_paritaria, 0) / 1000 * 100), 2);    -- Tarifa cada 100 kg
    x_tarifa_paritaria := NVL(l_costo_paritaria, 0) / 1000 * 100;

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Tarifa_Paritaria: '||SQLERRM;

  END Get_Tarifa_Paritaria;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Importe_Paritaria                                          *
 * Purpose : Rutina que devuelve el importe de Paritaria para el producto   *
 *           recibido, según el importe configurado en la línea de          *
 *           Acondicionamiento                                              *
 ****************************************************************************/
  PROCEDURE Get_Importe_Paritaria ( p_carta_porte_id     IN NUMBER
                                  , p_linea_costo        IN NUMBER
                                  , x_importe_paritaria OUT NUMBER
                                  , x_moneda            OUT VARCHAR2
                                  , x_result            OUT BOOLEAN
                                  , x_error_msg         OUT VARCHAR2) IS

    CURSOR c_carta_porte IS
      SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


    l_peso_neto    NUMBER;
    l_paritaria    NUMBER;


  BEGIN

    x_result := TRUE;

    Get_Tarifa_Paritaria ( p_carta_porte_id    => p_carta_porte_id
                         , p_linea_costo       => p_linea_costo
                         , x_tarifa_paritaria  => l_paritaria
                         , x_moneda            => x_moneda
                         , x_result            => x_result
                         , x_error_msg         => x_error_msg);


    IF (NOT x_result) THEN
      RETURN;
    END IF;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto;
    CLOSE c_carta_porte;

    x_importe_paritaria := ROUND(( l_peso_neto * l_paritaria / 100),2);



  EXCEPTION
    WHEN OTHERS THEN
      x_result    := FALSE;
      x_error_msg := 'Error en Get_Importe_Paritaria.'||SQLERRM;

  END Get_Importe_Paritaria;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Tarifa_Fumigacion                                          *
 * Purpose : Rutina que devuelve la tarifa de Fumigacion para el producto   *
 *           recibido, según el importe configurado en la línea de          *
 *           Acondicionamiento                                              *
 ****************************************************************************/
  PROCEDURE Get_Tarifa_Fumigacion ( p_carta_porte_id      IN NUMBER
                                  , p_linea_costo         IN NUMBER
                                  , x_tarifa_fumigacion  OUT NUMBER
                                  , x_moneda             OUT VARCHAR2
                                  , x_result             OUT BOOLEAN
                                  , x_error_msg          OUT VARCHAR2)
  IS

    CURSOR c_acond IS
      SELECT NVL(fumigada, 0) fumigada
           , moneda
        FROM XX_TCG_ACONDICIONAMIENTO
       WHERE acond_id = p_linea_costo;

    l_costo_fumigada    NUMBER;

  BEGIN

    x_result := TRUE;

    OPEN c_acond;
    FETCH c_acond INTO l_costo_fumigada   -- $/ton
                     , x_moneda;
    CLOSE c_acond;

    --CR1273 x_tarifa_fumigacion := ROUND((NVL(l_costo_fumigada, 0) / 1000 * 100), 2);    -- Tarifa cada 100 kg
    x_tarifa_fumigacion := NVL(l_costo_fumigada, 0) / 1000 * 100;

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Tarifa_Fumigacion: '||SQLERRM;

  END Get_Tarifa_Fumigacion;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Importe_Fumigacion                                         *
 * Purpose : Rutina que devuelve el importe de Fumigacion para el producto  *
 *           recibido, según el importe configurado en la linea de          *
 *           Acondicionamiento                                              *
 ****************************************************************************/
  PROCEDURE Get_Importe_Fumigacion ( p_carta_porte_id      IN NUMBER
                                   , p_linea_costo         IN NUMBER
                                   , x_importe_fumigacion OUT NUMBER
                                   , x_moneda             OUT VARCHAR2
                                   , x_result             OUT BOOLEAN
                                   , x_error_msg          OUT VARCHAR2) IS

    CURSOR c_carta_porte IS
      SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


    l_peso_neto    NUMBER;
    l_fumigacion   NUMBER;


  BEGIN

    x_result := TRUE;

    Get_Tarifa_Fumigacion ( p_carta_porte_id     => p_carta_porte_id
                          , p_linea_costo        => p_linea_costo
                          , x_tarifa_fumigacion  => l_fumigacion
                          , x_moneda             => x_moneda
                          , x_result             => x_result
                          , x_error_msg          => x_error_msg);

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto;
    CLOSE c_carta_porte;



    x_importe_fumigacion := ROUND((l_peso_neto * l_fumigacion / 100), 2);



  EXCEPTION
    WHEN OTHERS THEN
      x_result    := FALSE;
      x_error_msg := 'Error en Get_Importe_Fumigacion.'||SQLERRM;

  END Get_Importe_Fumigacion;



/******************************************************************************
 *                                                                            *
 * Name    : Get_Importe_Otros_Gastos                                         *
 * Purpose : Rutina que devuelve el importe de Otros Gastos para el producto  *
 *           recibido, según el importe configurado en el Contrato de         *
 *           Compra                                                           *
 ****************************************************************************/
  PROCEDURE Get_Importe_Otros_Gastos( p_carta_porte_id      IN NUMBER
                                    , p_contrato_id         IN NUMBER
                                    , x_importe_otros_gs   OUT NUMBER
                                    , x_moneda             OUT VARCHAR2
                                    , x_result             OUT BOOLEAN
                                    , x_error_msg          OUT VARCHAR2) IS


    CURSOR c_carta_porte IS
      SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


    CURSOR c_contrato IS
      SELECT NVL(otros_gastos, 0) otros_gastos          --  $/100 kgs
           , servicios_currency_code
        FROM XX_TCG_CONTRATOS_COMPRA
       WHERE contrato_id = p_contrato_id;

    l_peso_neto     NUMBER;
    l_otros_gastos  NUMBER;


  BEGIN

    x_result := TRUE;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto;
    CLOSE c_carta_porte;

    OPEN c_contrato;
    FETCH c_contrato INTO l_otros_gastos
                        , x_moneda;
    CLOSE c_contrato;

    x_importe_otros_gs := ROUND((l_otros_gastos / 100 * l_peso_neto), 2);

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Importe_Otros_Gastos. '||SQLERRM;
  END Get_Importe_Otros_Gastos;




/******************************************************************************
 *                                                                            *
 * Name    : Get_Importe_Almacenaje                                           *
 * Purpose : Rutina que devuelve el importe de Almacenaje para el producto    *
 *           recibido, según el importe configurado en el Contrato de         *
 *           Compra                                                           *
 ****************************************************************************/
  PROCEDURE Get_Importe_Almacenaje ( p_carta_porte_id      IN NUMBER
                                   , p_contrato_id         IN NUMBER
                                   , x_importe_almacenaje OUT NUMBER
                                   , x_moneda             OUT VARCHAR2
                                   , x_result             OUT BOOLEAN
                                   , x_error_msg          OUT VARCHAR2) IS


    CURSOR c_carta_porte IS
      SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


    CURSOR c_contrato IS
      SELECT NVL(tarifa_almacenaje, 0) tarifa_almacenaje       --  $/100 kgs
           , servicios_currency_code
        FROM XX_TCG_CONTRATOS_COMPRA
       WHERE contrato_id = p_contrato_id;


    l_peso_neto    NUMBER;
    l_almacenaje   NUMBER;


  BEGIN

    x_result := TRUE;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto;
    CLOSE c_carta_porte;

    OPEN c_contrato;
    FETCH c_contrato INTO l_almacenaje
                        , x_moneda;
    CLOSE c_contrato;

    x_importe_almacenaje := ROUND((l_almacenaje / 100 * l_peso_neto), 2);

  EXCEPTION
    WHEN OTHERS THEN
      x_result := FALSE;
      x_error_msg := 'Error en Get_Importe_Almacenaje. '||SQLERRM;

  END Get_Importe_Almacenaje;



/******************************************************************************
 *                                                                            *
 * Name    : Get_Importe_Refact_Flete                                         *
 * Purpose : Rutina que devuelve el importe de Refacturación de Flete         *
 *           para el producto recibido, según el importe configurado en el    *
 *           Contrato de Compra                                               *
 *****************************************************************************/
  PROCEDURE Get_Importe_Refact_Flete ( p_carta_porte_id       IN NUMBER
                                     , p_contrato_id          IN NUMBER
                                     , x_importe_refact_flete OUT NUMBER
                                     , x_moneda               OUT VARCHAR2
                                     , x_result               OUT BOOLEAN
                                     , x_error_msg            OUT VARCHAR2) IS



    CURSOR c_carta_porte IS
      SELECT (peso_bruto_recepcion - tara_recepcion) peso_neto
           , NVL(costo_flete_xton, 0)                costo_flete                --Agregado CR1062
           , NVL(refacturar_flete_flag, 'N')         refacturar_flete_flag
        FROM XX_TCG_CARTAS_PORTE_ALL
       WHERE carta_porte_id = p_carta_porte_id;


    CURSOR c_contrato IS
      SELECT NVL(porcen_increm_refactu_flete, 0)   porcen_increm_refactu_flete
           , NVL(porcen_decrem_refactu_flete, 0)   porcen_decrem_refactu_flete
           --, NVL(costo_flete, 0)                   costo_flete                Comentado CR1062
           , servicios_currency_code
        FROM XX_TCG_CONTRATOS_COMPRA
       WHERE contrato_id = p_contrato_id;


    l_peso_neto             NUMBER;
    l_prct_increm           NUMBER;
    l_prct_decrem           NUMBER;
    l_importe_increm        NUMBER := 0;
    l_importe_decrem        NUMBER := 0;
    --l_costo_flete           NUMBER;     CR1062
    l_costo_flete_xton      NUMBER;
    l_ref_flete_flag        VARCHAR2(1);
    l_no_provisionada       NUMBER;


    l_num_monto_incremento  NUMBER:=0;
    l_num_por_decremento    NUMBER:=0;
    l_num_monto_decremento  NUMBER:=0;
    l_currency_code         VARCHAR2(15);
    l_num_existe            NUMBER:=0;


  BEGIN

    x_result := TRUE;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_peso_neto
                             --CR1062
                           , l_costo_flete_xton
                           , l_ref_flete_flag;
    CLOSE c_carta_porte;

    OPEN  c_contrato;
    FETCH c_contrato INTO l_prct_increm
                        , l_prct_decrem
                        --, l_costo_flete      CR1062
                        , x_moneda;
    CLOSE c_contrato;


    --Agregado CR1062
    IF (l_ref_flete_flag = 'Y') THEN
    --
      SELECT COUNT(*)
        INTO l_no_provisionada
        FROM XX_TCG_CARTAS_PORTE_ALL xtcp
       WHERE xtcp.carta_porte_id = p_carta_porte_id
         AND NVL(provisionar_flete_flag,'N') = 'Y'
         AND NVL(refacturar_flete_flag,'N')  = 'Y'
         AND NVL(provisionado_flag,'N')      = 'N'
         AND NVL(refacturado_flag,'N')       = 'N';


      IF (l_no_provisionada > 0) THEN
        x_error_msg := 'La Carta de Porte con id: '||p_carta_porte_id||' no ha sido provisionada.';
        x_result := FALSE;
      END IF;


      x_importe_refact_flete := ROUND((l_peso_neto * l_costo_flete_xton /1000), 2);


      IF (l_prct_increm > 0) THEN

        l_importe_increm       := ROUND((x_importe_refact_flete * l_prct_increm / 100), 2);
        x_importe_refact_flete := x_importe_refact_flete + l_importe_increm;

      END IF;

      IF (l_prct_decrem > 0) THEN

        l_importe_decrem := ROUND(x_importe_refact_flete * l_prct_decrem /100, 2);
        x_importe_refact_flete := x_importe_refact_flete - l_importe_decrem;

      END IF;

    ELSE

      x_importe_refact_flete := 0;

    END IF;

  EXCEPTION
    WHEN others THEN
      x_result    := FALSE;
      x_error_msg := 'Error en Get_Importe_Refact_Flete. '||SQLERRM;

  END Get_Importe_Refact_Flete;



/****************************************************************************
 *                                                                          *
 * Name    : Create_Liq1116A_Line                                           *
 * Purpose : Rutina que crea o actualiza una linea de liquidacion 1116A.    *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Create_Liq1116A_Line ( p_liquidacion_id  IN NUMBER
                                 , p_memo_line_id    IN NUMBER
                                 , p_importe         IN NUMBER
                                 , p_tabla_aux       IN BOOLEAN
                                 , x_result         OUT BOOLEAN
                                 , x_error_msg      OUT VARCHAR2) IS
  BEGIN

    x_result := TRUE;

    IF (p_tabla_aux) THEN

        UPDATE XX_TCG_LIQ1116A_LINES_AUX
           SET importe            = p_importe,
               calculo_automatico_flag = 'Y',
               last_updated_by    = FND_GLOBAL.user_id,
               last_update_date   = SYSDATE,
               last_update_login  = FND_GLOBAL.login_id
         WHERE liquidacion_id     = p_liquidacion_id
           AND memo_line_id       = p_memo_line_id;

        IF (SQL%ROWCOUNT = 0) THEN
            INSERT INTO XX_TCG_LIQ1116A_LINES_AUX
            (
              liquidacion_line_id,
              liquidacion_id,
              memo_line_id,
              importe,
              calculo_automatico_flag,
              created_by,
              creation_date,
              last_updated_by,
              last_update_date,
              last_update_login)
            VALUES
            (
              xx_aco_liq_1116A_lines_s.nextval,
              p_liquidacion_id,
              p_memo_line_id,
              p_importe,
              'Y',
              FND_GLOBAL.user_id,
              SYSDATE,
              FND_GLOBAL.user_id,
              SYSDATE,
              FND_GLOBAL.login_id
              );
        END IF;


    ELSE

        UPDATE XX_TCG_LIQUIDACION_1116A_LINES
           SET importe = p_importe,
               calculo_automatico_flag = 'Y',
               last_updated_by    = FND_GLOBAL.user_id,
               last_update_date   = SYSDATE,
               last_update_login  = FND_GLOBAL.login_id
         WHERE liquidacion_id     = p_liquidacion_id
           AND memo_line_id       = p_memo_line_id;

        IF (SQL%ROWCOUNT = 0) THEN
            INSERT INTO XX_TCG_LIQUIDACION_1116A_LINES
            (
              liquidacion_line_id,
              liquidacion_id,
              memo_line_id,
              importe,
              calculo_automatico_flag,
              created_by,
              creation_date,
              last_updated_by,
              last_update_date,
              last_update_login)
            VALUES
            (
              xx_aco_liq_1116A_lines_s.nextval,
              p_liquidacion_id,
              p_memo_line_id,
              p_importe,
              'Y',
              FND_GLOBAL.user_id,
              SYSDATE,
              FND_GLOBAL.user_id,
              SYSDATE,
              FND_GLOBAL.login_id
              );
        END IF;

    END IF;

  EXCEPTION
    WHEN others THEN
      x_result := FALSE;
      x_error_msg := 'Error inesperado insertanto linea de liquidacion. '||SQLERRM;

  END Create_Liq1116A_Line;







-------------------------------------------------------------------------------
--                             Rutinas públicas                              --
-------------------------------------------------------------------------------

/***************************************************************************
 *                                                                          *
 * Name    : Get_acond_id                                                   *
 * Purpose : Rutina que devuelve la línea de costo de Acondicionamiento     *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_acond_id ( p_contrato_id           IN NUMBER
                         , p_estab_destino_id      IN NUMBER
                         , p_empresa_destino_id    IN NUMBER
                         , p_zona_destino_code     IN VARCHAR2
                         , p_tipo_productor        IN VARCHAR2
                         , p_item_oncca_code       IN VARCHAR2
                         , p_fecha_recepcion       IN DATE
                         , p_acondicionamiento_id OUT NUMBER
                         , p_result               OUT BOOLEAN
                         , p_error_msg            OUT VARCHAR2) IS

    l_acond_id      NUMBER;
    l_dummy         NUMBER;

    CURSOR c_acond IS
      SELECT xta.acond_id, 1 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 2 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 3 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 4 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 5 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 6 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 7 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 8 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 9 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 10 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 11 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))

       UNION
      SELECT xta.acond_id, 12 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 13 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 14 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 15 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 16 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 17 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 18 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 19 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 20 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
       SELECT xta.acond_id, 21 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 22 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 23 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 24 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 25 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 26 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 27 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 28 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 29 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 30 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 31 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 32 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 33 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 34 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 35 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 36 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 37 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 38 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 39 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 40 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 41 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 42 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 43 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 44 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 45 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 46 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 47 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 48 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 49 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 50 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 51 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         = p_contrato_id
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 52 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 53 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 54 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 55 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    = p_estab_destino_id
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 56 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 57 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      = p_tipo_productor
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 58 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          = p_empresa_destino_id
         AND xta.cod_zona            IS NULL
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 59 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           = p_item_oncca_code
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       UNION
      SELECT xta.acond_id, 60 order_line
        FROM XX_TCG_ACONDICIONAMIENTO xta
       WHERE 1=1
         AND xta.contrato_id         IS NULL
         AND xta.destino_estab_id    IS NULL
         AND xta.destino_id          IS NULL
         AND xta.cod_zona            = p_zona_destino_code
         AND xta.tipo_productor      IS NULL
         AND xta.cod_oncca           IS NULL
         AND p_fecha_recepcion BETWEEN NVL(vigencia_desde, TRUNC(sysdate-1))
                                   AND NVL(vigencia_hasta, TRUNC(sysdate+1))
       ORDER BY order_line;



  BEGIN

    p_result := TRUE;


    OPEN c_acond;
    FETCH c_acond INTO l_acond_id
                     , l_dummy;
    CLOSE c_acond;

    IF (l_acond_id IS NULL) THEN
      p_result    := FALSE;
      p_error_msg := 'No se encuentra linea de Acondicionamiento para la CP dada.';
    ELSE
      p_acondicionamiento_id := l_acond_id;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      IF c_acond%ISOPEN THEN
        CLOSE  c_acond;
      END IF;

      p_result := FALSE;
      p_error_msg := 'Error al buscar la línea de Acondicionamiento. Detalle: '||SQLERRM;

  END Get_Acond_id;



/***************************************************************************
 *                                                                          *
 * Name    : Get_Secada                                                     *
 * Purpose : Rutina que devuelve la merma, la tarifa y el importe de Secada *
 *           según las condiciones de acondicionamiento                     *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Secada ( p_carta_porte_id  IN NUMBER
                       , p_linea_costo     IN NUMBER
                       , p_merma_secada   OUT NUMBER
                       , p_tarifa_secada  OUT NUMBER
                       , p_importe_secada OUT NUMBER
                       , p_moneda         OUT VARCHAR2
                       , p_result         OUT BOOLEAN
                       , p_error_msg      OUT VARCHAR2) IS

  BEGIN

    p_result := TRUE;

    p_merma_secada := NVL(XX_TCG_CALIDAD_PKG.Get_Merma_Humedad (p_carta_porte_id  => p_carta_porte_id), 0);


    Get_Tarifa_Secada( p_carta_porte_id  => p_carta_porte_id
                     , p_linea_costo     => p_linea_costo
                     , x_tarifa_secada   => p_tarifa_secada
                     , x_moneda          => p_moneda
                     , x_result          => p_result
                     , x_error_msg       => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;


    Get_Importe_Secada( p_carta_porte_id   => p_carta_porte_id
                      , p_linea_costo      => p_linea_costo
                      , x_importe_secada   => p_importe_secada
                      , x_moneda           => p_moneda
                      , x_result           => p_result
                      , x_error_msg        => p_error_msg);


  EXCEPTION
    WHEN OTHERS THEN
      p_result := FALSE;
      p_error_msg := 'Error en Get_Secada. '||SQLERRM;

  END Get_Secada;




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Zaranda                                                     *
 * Purpose : Rutina que devuelve la merma, la tarifa y el importe de Zaranda *
 *           según las condiciones de acondicionamiento                      *
 *                                                                           *
 ****************************************************************************/
  PROCEDURE Get_Zaranda ( p_carta_porte_id    IN NUMBER
                        , p_linea_costo       IN NUMBER
                        , p_merma_zaranda    OUT NUMBER
                        , p_tarifa_zaranda   OUT NUMBER
                        , p_importe_zaranda  OUT NUMBER
                        , p_moneda           OUT VARCHAR2
                        , p_result           OUT BOOLEAN
                        , p_error_msg        OUT VARCHAR2) IS


  BEGIN

    p_result := TRUE;

    p_merma_zaranda := XX_TCG_CALIDAD_PKG.Get_Merma_Zaranda( p_carta_porte_id  => p_carta_porte_id);


    Get_Tarifa_Zaranda( p_carta_porte_id   => p_carta_porte_id
                      , p_linea_costo      => p_linea_costo
                      , x_tarifa_zaranda   => p_tarifa_zaranda
                      , x_moneda           => p_moneda
                      , x_result           => p_result
                      , x_error_msg        => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;


    Get_Importe_Zaranda( p_carta_porte_id  => p_carta_porte_id
                       , p_linea_costo     => p_linea_costo
                       , x_importe_zaranda => p_importe_zaranda
                       , x_moneda          => p_moneda
                       , x_result          => p_result
                       , x_error_msg       => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Get_Zaranda. '||SQLERRM;

  END Get_Zaranda;



/***************************************************************************
 *                                                                          *
 * Name    : Get_Volatil                                                    *
 * Purpose : Rutina que devuelve la merma Volátil según las condiciones     *
 *           de acondicionamiento                                           *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Volatil ( p_carta_porte_id    IN NUMBER
                        , p_merma_volatil    OUT NUMBER
                        , p_result           OUT BOOLEAN
                        , p_error_msg        OUT VARCHAR2) IS

  BEGIN

    p_result := TRUE;

    p_merma_volatil := XX_TCG_CALIDAD_PKG.Get_Merma_Volatil ( p_carta_porte_id    => p_carta_porte_id);

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Get_Volatil. '||SQLERRM;

  END Get_Volatil;




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Paritaria                                                   *
 * Purpose : Rutina que devuelve la tarifa y el importe de Paritaria         *
 *           según las condiciones de acondicionamiento                      *
 *                                                                           *
 ****************************************************************************/
  PROCEDURE Get_Paritaria ( p_carta_porte_id      IN NUMBER
                          , p_linea_costo         IN NUMBER
                          , p_tarifa_paritaria   OUT NUMBER
                          , p_importe_paritaria  OUT NUMBER
                          , p_moneda             OUT VARCHAR2
                          , p_result             OUT BOOLEAN
                          , p_error_msg          OUT VARCHAR2)
  IS

  BEGIN

    Get_Tarifa_Paritaria( p_carta_porte_id    => p_carta_porte_id
                        , p_linea_costo       => p_linea_costo
                        , x_tarifa_paritaria  => p_tarifa_paritaria
                        , x_moneda            => p_moneda
                        , x_result            => p_result
                        , x_error_msg         => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;


    Get_Importe_Paritaria ( p_carta_porte_id    => p_carta_porte_id
                          , p_linea_costo       => p_linea_costo
                          , x_importe_paritaria => p_importe_paritaria
                          , x_moneda            => p_moneda
                          , x_result            => p_result
                          , x_error_msg         => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Get_Paritaria. '||SQLERRM;

  END Get_Paritaria;




/*****************************************************************************
 *                                                                           *
 * Name    : Get_Fumigacion                                                  *
 * Purpose : Rutina que devuelve la tarifa y el importe de Fumigada          *
 *           según las condiciones de acondicionamiento                      *
 *                                                                           *
 ****************************************************************************/
  PROCEDURE Get_Fumigacion ( p_carta_porte_id       IN NUMBER
                           , p_linea_costo          IN NUMBER
                           , p_tarifa_fumigacion   OUT NUMBER
                           , p_importe_fumigacion  OUT NUMBER
                           , p_moneda              OUT VARCHAR2
                           , p_result              OUT BOOLEAN
                           , p_error_msg           OUT VARCHAR2)
  IS

  BEGIN

    Get_Tarifa_Fumigacion ( p_carta_porte_id     => p_carta_porte_id
                          , p_linea_costo        => p_linea_costo
                          , x_tarifa_fumigacion  => p_tarifa_fumigacion
                          , x_moneda             => p_moneda
                          , x_result             => p_result
                          , x_error_msg          => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;


    Get_Importe_Fumigacion ( p_carta_porte_id     => p_carta_porte_id
                           , p_linea_costo        => p_linea_costo
                           , x_importe_fumigacion => p_importe_fumigacion
                           , x_moneda             => p_moneda
                           , x_result             => p_result
                           , x_error_msg          => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Get_Fumigacion. '||SQLERRM;

  END Get_Fumigacion;




/***************************************************************************
 *                                                                          *
 * Name    : Obtener_Servicios_Automaticos                                  *
 * Purpose : Procedimiento que obtiene los valores de importe, tarifa y     *
 *          mermas de los servicios automáticos, para una carta de porte    *
 *          dada                                                            *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Obtener_Servicios_Automaticos ( p_carta_porte_id         IN NUMBER
                                          , p_operating_unit         IN NUMBER
                                          , p_contrato_id            IN NUMBER DEFAULT NULL
                                          , p_solo_importes          IN BOOLEAN
                                          , p_acond_id              OUT NUMBER
                                          , p_merma_secada          OUT NUMBER
                                          , p_tarifa_secada         OUT NUMBER
                                          , p_importe_secada        OUT NUMBER
                                          , p_merma_zaranda         OUT NUMBER
                                          , p_tarifa_zaranda        OUT NUMBER
                                          , p_importe_zaranda       OUT NUMBER
                                          , p_tarifa_paritaria      OUT NUMBER
                                          , p_importe_paritaria     OUT NUMBER
                                          , p_tarifa_fumigacion     OUT NUMBER
                                          , p_importe_fumigacion    OUT NUMBER
                                          , p_tarifa_otros_gastos   OUT NUMBER
                                          , p_importe_otros_gastos  OUT NUMBER
                                          , p_tarifa_almacenaje     OUT NUMBER
                                          , p_importe_almacenaje    OUT NUMBER
                                          , p_tarifa_refactu_flete  OUT NUMBER
                                          , p_importe_refactu_flete OUT NUMBER
                                          , p_moneda_acond          OUT VARCHAR2
                                          , p_moneda_contrato       OUT VARCHAR2
                                          , p_result                OUT BOOLEAN
                                          , p_error_msg             OUT VARCHAR2)
  IS


    CURSOR c_carta_porte IS
      SELECT xtcp.destino_estab_id
           , xtcp.destino_id
           , DECODE(XX_TCG_FUNCTIONS_PKG.es_empresa_grupo_c(xtcp.titular_cp_cuit)
                   , 'Y', 'GRUPO'
                   , 'TERCERO')     tipo_productor
           , xtl.zona_destino
           , xmsi.cod_oncca
           , xtcp.fecha_recepcion
           , NVL(xtcp.refacturar_flete_flag, 'N')  refacturar_flete_flag            -- CR1062
        FROM XX_TCG_CARTAS_PORTE_ALL xtcp
           , (SELECT xl.zona_destino
                   , xl.pr_dpto_codigo
                   , xl.loc_codigo
                FROM XX_TCG_LOCALIDADES         xl
                   , XX_TCG_PARAMETROS_COMPANIA xtpc
               WHERE xtpc.operating_unit = p_operating_unit
                 AND xl.pais_codigo      = xtpc.operating_unit_country) xtl
           , (SELECT inventory_item_id
                   , organization_id
                   , msid.xx_aco_codigo_oncca cod_oncca
                FROM MTL_SYSTEM_ITEMS_B     msi
                   , MTL_SYSTEM_ITEMS_B_DFV msid
               WHERE msi.rowid = msid.row_id) xmsi
       WHERE xtcp.carta_porte_id    = p_carta_porte_id
         AND xtcp.destino_provincia = xtl.pr_dpto_codigo (+)
         AND xtcp.destino_localidad = xtl.loc_codigo (+)
         AND xtcp.item_id           = inventory_item_id (+)
         AND xtcp.org_id            = organization_id   (+);



    CURSOR c_memo_lines IS
      SELECT secada_memo_line_id        secada_id
           , zaranda_memo_line_id       zaranda_id
           , paritarias_memo_line_id    paritaria_id
           , fumigacion_memo_line_id    fumigacion_id
           , otros_gastos_memo_line_id  otros_gastos_id
           , almacenaje_memo_line_id    almacenaje_id
           , refactu_flete_memo_line_id ref_flete_id
           , operating_unit_country     oper_unit_ctry
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_operating_unit;


    l_cp_rec             c_carta_porte%ROWTYPE;
    l_ml_rec             c_memo_lines%ROWTYPE;
    l_acond_id           NUMBER;


  BEGIN

    p_result    := TRUE;
    p_error_msg := NULL;

    OPEN c_memo_lines;
    FETCH c_memo_lines INTO l_ml_rec;
    CLOSE c_memo_lines;

    OPEN c_carta_porte;
    FETCH c_carta_porte INTO l_cp_rec;
    CLOSE c_carta_porte;


    Get_Acond_Id ( p_contrato_id           => p_contrato_id
                 , p_estab_destino_id      => l_cp_rec.destino_estab_id
                 , p_empresa_destino_id    => l_cp_rec.destino_id
                 , p_zona_destino_code     => l_cp_rec.zona_destino
                 , p_tipo_productor        => l_cp_rec.tipo_productor
                 , p_item_oncca_code       => l_cp_rec.cod_oncca
                 , p_fecha_recepcion       => l_cp_rec.fecha_recepcion
                 , p_acondicionamiento_id  => l_acond_id
                 , p_result                => p_result
                 , p_error_msg             => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    ELSE
      p_acond_id := l_acond_id;
    END IF;


    IF (p_solo_importes) THEN

      IF (l_ml_rec.secada_id IS NOT NULL) THEN

        Get_Importe_Secada ( p_carta_porte_id    => p_carta_porte_id
                           , p_linea_costo       => l_acond_id
                           , x_importe_secada    => p_importe_secada
                           , x_moneda            => p_moneda_acond
                           , x_result            => p_result
                           , x_error_msg         => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;

      IF (l_ml_rec.zaranda_id IS NOT NULL) THEN

        Get_Importe_Zaranda ( p_carta_porte_id    => p_carta_porte_id
                            , p_linea_costo       => l_acond_id
                            , x_importe_zaranda   => p_importe_zaranda
                            , x_moneda            => p_moneda_acond
                            , x_result            => p_result
                            , x_error_msg         => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;

      IF (l_ml_rec.paritaria_id IS NOT NULL) THEN

        Get_Importe_Paritaria ( p_carta_porte_id    => p_carta_porte_id
                              , p_linea_costo       => l_acond_id
                              , x_importe_paritaria => p_importe_paritaria
                              , x_moneda            => p_moneda_acond
                              , x_result            => p_result
                              , x_error_msg         => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;

      IF (l_ml_rec.fumigacion_id IS NOT NULL) THEN

        Get_Importe_Fumigacion ( p_carta_porte_id     => p_carta_porte_id
                               , p_linea_costo        => l_acond_id
                               , x_importe_fumigacion => p_importe_fumigacion
                               , x_moneda             => p_moneda_acond
                               , x_result             => p_result
                               , x_error_msg          => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;


    ELSE  -- Importes, mermas, tarifas


      IF (l_ml_rec.secada_id IS NOT NULL) THEN

        Get_Secada ( p_carta_porte_id   => p_carta_porte_id
                   , p_linea_costo      => l_acond_id
                   , p_merma_secada     => p_merma_secada
                   , p_tarifa_secada    => p_tarifa_secada
                   , p_importe_secada   => p_importe_secada
                   , p_moneda           => p_moneda_acond
                   , p_result           => p_result
                   , p_error_msg        => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;


      IF (l_ml_rec.zaranda_id IS NOT NULL) THEN

        Get_Zaranda ( p_carta_porte_id   => p_carta_porte_id
                    , p_linea_costo      => l_acond_id
                    , p_merma_zaranda    => p_merma_zaranda
                    , p_tarifa_zaranda   => p_tarifa_zaranda
                    , p_importe_zaranda  => p_importe_zaranda
                    , p_moneda           => p_moneda_acond
                    , p_result           => p_result
                    , p_error_msg        => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;

      IF (l_ml_rec.paritaria_id IS NOT NULL) THEN

        Get_Paritaria ( p_carta_porte_id    => p_carta_porte_id
                      , p_linea_costo       => l_acond_id
                      , p_tarifa_paritaria  => p_tarifa_paritaria
                      , p_importe_paritaria => p_importe_paritaria
                      , p_moneda            => p_moneda_acond
                      , p_result            => p_result
                      , p_error_msg         => p_error_msg);

        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;

      IF (l_ml_rec.fumigacion_id IS NOT NULL) THEN

        Get_Fumigacion ( p_carta_porte_id     => p_carta_porte_id
                       , p_linea_costo        => l_acond_id
                       , p_tarifa_fumigacion  => p_tarifa_fumigacion
                       , p_importe_fumigacion => p_importe_fumigacion
                       , p_moneda             => p_moneda_acond
                       , p_result             => p_result
                       , p_error_msg          => p_error_msg);


        IF (NOT p_result) THEN
          RETURN;
        END IF;

      END IF;


    END IF;



    IF (l_ml_rec.otros_gastos_id IS NOT NULL AND
      p_contrato_id IS NOT NULL) THEN

      Get_Importe_Otros_Gastos ( p_carta_porte_id     => p_carta_porte_id
                               , p_contrato_id        => p_contrato_id
                               , x_importe_otros_gs   => p_importe_otros_gastos
                               , x_moneda             => p_moneda_contrato
                               , x_result             => p_result
                               , x_error_msg          => p_error_msg);


      IF (NOT p_result) THEN
        RETURN;
      END IF;

    END IF;

    IF (l_ml_rec.almacenaje_id IS NOT NULL AND
      p_contrato_id IS NOT NULL) THEN

      Get_Importe_Almacenaje ( p_carta_porte_id     => p_carta_porte_id
                             , p_contrato_id        => p_contrato_id
                             , x_importe_almacenaje => p_importe_almacenaje
                             , x_moneda             => p_moneda_contrato
                             , x_result             => p_result
                             , x_error_msg          => p_error_msg);


      IF (NOT p_result) THEN
        RETURN;
      END IF;

    END IF;

    IF (l_ml_rec.ref_flete_id IS NOT NULL AND
      p_contrato_id IS NOT NULL) THEN

      Get_Importe_Refact_Flete ( p_carta_porte_id       => p_carta_porte_id
                               , p_contrato_id          => p_contrato_id
                               , x_importe_refact_flete => p_importe_refactu_flete
                               , x_moneda               => p_moneda_contrato
                               , x_result               => p_result
                               , x_error_msg            => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;

    --Agregado CR1062
    ELSIF (l_ml_rec.ref_flete_id IS NULL AND
      l_cp_rec.refacturar_flete_flag = 'Y' ) THEN

      p_error_msg := 'No se encuentra configurada la memo line de Refacturacion de Flete '||
                     'para la Unidad Operativa '||p_operating_unit;
      p_result    := FALSE;
      RETURN;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result := FALSE;
      p_error_msg := 'Error en Obtener_Servicios_Automaticos. '||SQLERRM;

  END Obtener_Servicios_Automaticos;


/***************************************************************************
 *                                                                          *
 * Name    : Set_Lineas_Liq1116                                             *
 * Purpose : Rutina que crea las líneas de los Certificados (1116A) con las *
 *          memo_lines de cálculo automático                                *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Set_Lineas_Liq1116A ( p_liquidacion_id  IN NUMBER
                                , p_contrato_id     IN NUMBER
                                , p_boletin_hdr_id  IN NUMBER
                                , p_operating_unit  IN NUMBER
                                , p_tabla_aux       IN BOOLEAN
                                , p_result         OUT BOOLEAN
                                , p_error_msg      OUT VARCHAR2) IS


    CURSOR c_liquidacion IS
      SELECT xtl.currency_code        liq_currency
           , xtl.conversion_rate
           , xog.currency_code        funct_currency
        FROM XX_TCG_LIQUIDACIONES_1116A xtl
           , (SELECT gl.currency_code
                   , ood.organization_id
                FROM ORG_ORGANIZATION_DEFINITIONS ood
                   , GL_LEDGERS                   gl
               WHERE ood.set_of_books_id = gl.ledger_id ) xog
       WHERE xtl.liquidacion_id = p_liquidacion_id
         AND xtl.organization_id = xog.organization_id (+);


    CURSOR c_cartas_porte IS
      SELECT xtb.carta_porte_id
        FROM XX_TCG_BOLETIN_LINES    xtb
           , XX_TCG_CARTAS_PORTE_ALL xtcp
       WHERE xtb.carta_porte_id     = xtcp.carta_porte_id
         AND xtb.boletin_header_id  = p_boletin_hdr_id;


    CURSOR c_memo_lines IS
      SELECT secada_memo_line_id        secada_id
           , zaranda_memo_line_id       zaranda_id
           , paritarias_memo_line_id    paritaria_id
           , fumigacion_memo_line_id    fumigacion_id
           , otros_gastos_memo_line_id  otros_gastos_id
           , almacenaje_memo_line_id    almacenaje_id
           , refactu_flete_memo_line_id ref_flete_id
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_operating_unit;


    l_liq_rec              c_liquidacion%ROWTYPE;
    l_serv_acond_currency  VARCHAR2(10);
    l_serv_cto_currency    VARCHAR2(10);
    l_ml_rec               c_memo_lines%ROWTYPE;
    l_dummy                NUMBER;
    l_secada               NUMBER := 0;
    l_secada_cp            NUMBER := 0;
    l_zaranda              NUMBER := 0;
    l_zaranda_cp           NUMBER := 0;
    l_paritaria            NUMBER := 0;
    l_paritaria_cp         NUMBER := 0;
    l_fumigacion           NUMBER := 0;
    l_fumigacion_cp        NUMBER := 0;
    l_otros_gastos         NUMBER := 0;
    l_otros_gastos_cp      NUMBER := 0;
    l_almacenaje           NUMBER := 0;
    l_almacenaje_cp        NUMBER := 0;
    l_ref_flete            NUMBER := 0;
    l_ref_flete_cp         NUMBER := 0;
    l_acond_id             NUMBER;


  BEGIN

    OPEN c_liquidacion;
    FETCH c_liquidacion INTO l_liq_rec;
    CLOSE c_liquidacion;


    FOR rcp IN c_cartas_porte LOOP

      Obtener_Servicios_Automaticos ( p_carta_porte_id        => rcp.carta_porte_id
                                    , p_operating_unit        => p_operating_unit
                                    , p_contrato_id           => p_contrato_id
                                    , p_solo_importes         => TRUE
                                    , p_acond_id              => l_acond_id
                                    , p_merma_secada          => l_dummy
                                    , p_tarifa_secada         => l_dummy
                                    , p_importe_secada        => l_secada_cp
                                    , p_merma_zaranda         => l_dummy
                                    , p_tarifa_zaranda        => l_dummy
                                    , p_importe_zaranda       => l_zaranda_cp
                                    , p_tarifa_paritaria      => l_dummy
                                    , p_importe_paritaria     => l_paritaria_cp
                                    , p_tarifa_fumigacion     => l_dummy
                                    , p_importe_fumigacion    => l_fumigacion_cp
                                    , p_tarifa_otros_gastos   => l_dummy
                                    , p_importe_otros_gastos  => l_otros_gastos_cp
                                    , p_tarifa_almacenaje     => l_dummy
                                    , p_importe_almacenaje    => l_almacenaje_cp
                                    , p_tarifa_refactu_flete  => l_dummy
                                    , p_importe_refactu_flete => l_ref_flete_cp
                                    , p_moneda_acond          => l_serv_acond_currency
                                    , p_moneda_contrato       => l_serv_cto_currency
                                    , p_result                => p_result
                                    , p_error_msg             => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;

      IF (l_secada_cp IS NOT NULL) THEN

        IF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Secada se ha encontrado en '||l_serv_acond_currency||
                         ' para la línea de Acondicionamiento '||l_acond_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency = l_liq_rec.liq_currency) THEN

          l_secada_cp := l_secada_cp * l_liq_rec.conversion_rate;

        END IF;

        l_secada    := l_secada + ROUND(l_secada_cp,2);
        l_secada_cp := 0;

      END IF;

      IF (l_zaranda_cp IS NOT NULL) THEN

        IF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Zaranda se ha encontrado en '||l_serv_acond_currency||
                         ' para la línea de Acondicionamiento '||l_acond_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency = l_liq_rec.liq_currency) THEN

          l_zaranda_cp := l_zaranda_cp * l_liq_rec.conversion_rate;

        END IF;

        l_zaranda    := l_zaranda + ROUND(l_zaranda_cp,2);
        l_zaranda_cp := 0;

      END IF;

      IF (l_paritaria_cp IS NOT NULL) THEN

        IF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Paritaria se ha encontrado en '||l_serv_acond_currency||
                         ' para la línea de Acondicionamiento '||l_acond_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency = l_liq_rec.liq_currency) THEN

          l_paritaria_cp := l_paritaria_cp * l_liq_rec.conversion_rate;

        END IF;

        l_paritaria    := l_paritaria + ROUND(l_paritaria_cp,2);
        l_paritaria_cp := 0;

      END IF;

      IF (l_fumigacion_cp IS NOT NULL) THEN

        IF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Fumigación se ha encontrado en '||l_serv_acond_currency||
                         ' para la línea de Acondicionamiento '||l_acond_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_acond_currency != l_liq_rec.funct_currency) AND
          (l_serv_acond_currency = l_liq_rec.liq_currency) THEN

          l_fumigacion_cp := l_fumigacion_cp * l_liq_rec.conversion_rate;

        END IF;

        l_fumigacion    := l_fumigacion + ROUND(l_fumigacion_cp,2);
        l_fumigacion_cp := 0;

      END IF;

      IF (l_otros_gastos_cp IS NOT NULL) THEN

        IF (l_serv_cto_currency != l_liq_rec.funct_currency) AND
          (l_serv_cto_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Otros Gastos se ha encontrado en '||l_serv_cto_currency||
                         ' para el contrato '||p_contrato_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_cto_currency != l_liq_rec.funct_currency) AND
          (l_serv_cto_currency = l_liq_rec.liq_currency) THEN

          l_otros_gastos_cp := l_otros_gastos_cp * l_liq_rec.conversion_rate;

        END IF;

        l_otros_gastos    := l_otros_gastos + ROUND(l_otros_gastos_cp,2);
        l_otros_gastos_cp := 0;

      END IF;

      IF (l_almacenaje_cp IS NOT NULL) THEN

        IF (l_serv_cto_currency != l_liq_rec.funct_currency) AND
          (l_serv_cto_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Almacenaje se ha encontrado en '||l_serv_cto_currency||
                         ' para el contrato '||p_contrato_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_cto_currency != l_liq_rec.funct_currency) AND
          (l_serv_cto_currency = l_liq_rec.liq_currency) THEN

          l_almacenaje_cp := l_almacenaje_cp * l_liq_rec.conversion_rate;

        END IF;

        l_almacenaje    := l_almacenaje + ROUND(l_almacenaje_cp,2);
        l_almacenaje_cp := 0;

      END IF;

      IF (l_ref_flete_cp IS NOT NULL) THEN

        IF (l_serv_cto_currency != l_liq_rec.funct_currency) AND
          (l_serv_cto_currency != l_liq_rec.liq_currency) THEN

          p_result    := FALSE;
          p_error_msg := 'El importe de Refacturación de Flete se ha encontrado en '
                         ||l_serv_cto_currency||' para el contrato '||p_contrato_id||
                         ', y no se cuenta con dato de conversión a moneda funcional.' ;
          RETURN;

        ELSIF (l_serv_cto_currency != l_liq_rec.funct_currency) AND
          (l_serv_cto_currency = l_liq_rec.liq_currency) THEN

          l_ref_flete_cp := l_ref_flete_cp * l_liq_rec.conversion_rate;

        END IF;

        l_ref_flete    := l_ref_flete + ROUND(l_ref_flete_cp,2);
        l_ref_flete_cp := 0;

      END IF;

    END LOOP;


    OPEN c_memo_lines;
    FETCH c_memo_lines INTO l_ml_rec;
    CLOSE c_memo_lines;


    IF (l_ml_rec.zaranda_id IS NOT NULL) AND
      (l_zaranda >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.zaranda_id
                           , p_importe        => l_zaranda
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN

        RETURN;
      END IF;
    END IF;


    IF (l_ml_rec.secada_id IS NOT NULL) AND
      (l_secada >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.secada_id
                           , p_importe        => l_secada
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;
    END IF;


    IF (l_ml_rec.paritaria_id IS NOT NULL) AND
      (l_paritaria >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.paritaria_id
                           , p_importe        => l_paritaria
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;
    END IF;


    IF (l_ml_rec.fumigacion_id IS NOT NULL) AND
      (l_fumigacion >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.fumigacion_id
                           , p_importe        => l_fumigacion
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;
    END IF;


    IF (l_ml_rec.otros_gastos_id IS NOT NULL) AND
      (l_otros_gastos >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.otros_gastos_id
                           , p_importe        => l_otros_gastos
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;
    END IF;


    IF (l_ml_rec.almacenaje_id IS NOT NULL) AND
      (l_almacenaje >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.almacenaje_id
                           , p_importe        => l_almacenaje
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;
    END IF;


    IF (l_ml_rec.ref_flete_id IS NOT NULL) AND
      (l_ref_flete >= 0) THEN

      Create_Liq1116A_Line ( p_liquidacion_id => p_liquidacion_id
                           , p_memo_line_id   => l_ml_rec.ref_flete_id
                           , p_importe        => l_ref_flete
                           , p_tabla_aux      => p_tabla_aux
                           , x_result         => p_result
                           , x_error_msg      => p_error_msg);

      IF (NOT p_result) THEN
        RETURN;
      END IF;
    END IF;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Set_Lineas_Liq1116A. '||SQLERRM;

  END Set_Lineas_Liq1116A;




/****************************************************************************
 *                                                                          *
 * Name    : Cantidad_Memolines_1116A                                       *
 * Purpose : Devuelve la cantidad de servicios automáticos configurados     *
 *                                                                          *
 ****************************************************************************/
 PROCEDURE Cantidad_Memolines_1116A ( p_operating_unit  IN NUMBER
                                    , p_cant_memolines OUT NUMBER
                                    , p_result         OUT BOOLEAN
                                    , p_error_msg      OUT VARCHAR2)

  IS

    CURSOR c_memo_lines (p_oper_unit IN VARCHAR2) IS
      SELECT zaranda_memo_line_id
           , secada_memo_line_id
           , paritarias_memo_line_id
           , fumigacion_memo_line_id
           , otros_gastos_memo_line_id
           , almacenaje_memo_line_id
           , refactu_flete_memo_line_id
        FROM XX_TCG_PARAMETROS_COMPANIA
       WHERE operating_unit = p_oper_unit;

    TYPE MemoLines IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;

    tMemos             MemoLines;
    l_index            NUMBER  := 1;
    l_insert           BOOLEAN := TRUE;


  BEGIN

    p_result := TRUE;

    FOR rmemo IN c_memo_lines (p_operating_unit) LOOP

      IF (rmemo.zaranda_memo_line_id IS NOT NULL) THEN

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.zaranda_memo_line_id;
          l_index := l_index + 1;
        END IF;

      END IF;

      IF (rmemo.secada_memo_line_id IS NOT NULL) THEN

        IF (tMemos.COUNT > 0) THEN

          FOR i IN tMemos.first..tMemos.last LOOP
            IF (tMemos(i) = rmemo.secada_memo_line_id) THEN
              l_insert := FALSE;
              EXIT;
            END IF;
          END LOOP;

        END IF;

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.secada_memo_line_id;
          l_index := l_index + 1;
        ELSE
          l_insert := TRUE;
        END IF;

      END IF;

      IF (rmemo.paritarias_memo_line_id IS NOT NULL) THEN

        IF (tMemos.COUNT > 0) THEN

          FOR i IN tMemos.first..tMemos.last LOOP
            IF (tMemos(i) = rmemo.paritarias_memo_line_id) THEN
              l_insert := FALSE;
              EXIT;
            END IF;
          END LOOP;

        END IF;

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.paritarias_memo_line_id;
          l_index := l_index + 1;
        ELSE
          l_insert := TRUE;
        END IF;

      END IF;

      IF (rmemo.fumigacion_memo_line_id IS NOT NULL) THEN

        IF (tMemos.COUNT > 0) THEN

          FOR i IN tMemos.first..tMemos.last LOOP
            IF (tMemos(i) = rmemo.fumigacion_memo_line_id) THEN
              l_insert := FALSE;
              EXIT;
            END IF;
          END LOOP;

        END IF;

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.fumigacion_memo_line_id;
          l_index := l_index + 1;
        ELSE
          l_insert := TRUE;
        END IF;

      END IF;

      IF (rmemo.otros_gastos_memo_line_id IS NOT NULL) THEN

        IF (tMemos.COUNT > 0) THEN

          FOR i IN tMemos.first..tMemos.last LOOP
            IF (tMemos(i) = rmemo.otros_gastos_memo_line_id) THEN
              l_insert := FALSE;
              EXIT;
            END IF;
          END LOOP;

        END IF;

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.otros_gastos_memo_line_id;
          l_index := l_index + 1;
        ELSE
          l_insert := TRUE;
          EXIT;
        END IF;

      END IF;

      IF (rmemo.almacenaje_memo_line_id IS NOT NULL) THEN

        IF (tMemos.COUNT > 0) THEN

          FOR i IN tMemos.first..tMemos.last LOOP
            IF (tMemos(i) = rmemo.almacenaje_memo_line_id) THEN
              l_insert := FALSE;
              EXIT;
            END IF;
          END LOOP;

        END IF;

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.almacenaje_memo_line_id;
          l_index := l_index + 1;
        ELSE
          l_insert := TRUE;
        END IF;

      END IF;

      IF (rmemo.refactu_flete_memo_line_id IS NOT NULL) THEN

        IF (tMemos.COUNT > 0) THEN
          FOR i IN tMemos.first..tMemos.last LOOP
            IF (tMemos(i) = rmemo.refactu_flete_memo_line_id) THEN
              l_insert := FALSE;
              EXIT;
            END IF;
          END LOOP;
        END IF;

        IF (l_insert) THEN
          tMemos(l_index) := rmemo.refactu_flete_memo_line_id;
        ELSE
          l_insert := TRUE;
        END IF;

      END IF;

    END LOOP;

    p_cant_memolines := tMemos.COUNT;


  EXCEPTION
    WHEN OTHERS THEN
      p_cant_memolines := NULL;
      p_result         := FALSE;
      p_error_msg      := 'Error en Cantidad_Memolines_1116A. '||SQLERRM;

  END Cantidad_Memolines_1116A;



/****************************************************************************
 *                                                                          *
 * Name    : Svcs_Automaticos_Asignados                                     *
 * Purpose : Devuelve TRUE si todos los servicios automáticos ya fueron     *
 *          asignados al Certificado                                        *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Svcs_Automaticos_Asignados ( p_liquidacion_id    IN NUMBER
                                       , p_operating_unit    IN NUMBER
                                       , p_result           OUT BOOLEAN
                                       , p_error_msg        OUT VARCHAR2)
  IS

    CURSOR c_lines IS
      SELECT memo_line_id
           , importe
        FROM XX_TCG_LIQUIDACION_1116A_LINES
       WHERE liquidacion_id = p_liquidacion_id
         AND NVL(calculo_automatico_flag, 'N') = 'Y';


    l_cant_asignadas    NUMBER:=0;
    l_cant_memolines    NUMBER:=0;


  BEGIN


    Cantidad_Memolines_1116A ( p_operating_unit => p_operating_unit
                             , p_cant_memolines => l_cant_memolines
                             , p_result         => p_result
                             , p_error_msg      => p_error_msg);

    IF (NOT p_result) THEN
      RETURN;
    END IF;

    FOR rlines IN c_lines LOOP

      l_cant_asignadas := l_cant_asignadas + 1;

    END LOOP;

    IF (l_cant_asignadas = l_cant_memolines) THEN
      p_result := TRUE;
    ELSE
      p_result := FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Svcs_Automaticos_Asignados. '||SQLERRM;

  END Svcs_Automaticos_Asignados;




/****************************************************************************
 *                                                                          *
 * Name    : Actualizar_Gastos_Acdmto_CP                                    *
 * Purpose : Procedimiento para insertar/actualizar los valores de svcs     *
 *           por Carta de Porte en la tabla XX_TCG_GASTO_ACONDICIONAMIENTO  *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Actualizar_Gastos_Acdmto_CP ( p_certificado_id        IN NUMBER DEFAULT NULL
                                        , p_carta_porte_id        IN NUMBER
                                        , p_acondicionamiento_id  IN NUMBER
                                        , p_eliminar_registro     IN BOOLEAN
                                        , p_tarifa_secada         IN NUMBER DEFAULT NULL
                                        , p_importe_secada        IN NUMBER DEFAULT NULL
                                        , p_tarifa_zaranda        IN NUMBER DEFAULT NULL
                                        , p_importe_zaranda       IN NUMBER DEFAULT NULL
                                        , p_tarifa_paritaria      IN NUMBER DEFAULT NULL
                                        , p_importe_paritaria     IN NUMBER DEFAULT NULL
                                        , p_tarifa_fumigacion     IN NUMBER DEFAULT NULL
                                        , p_importe_fumigacion    IN NUMBER DEFAULT NULL
                                        , p_result               OUT BOOLEAN
                                        , p_error_msg            OUT VARCHAR2)
  IS

    l_existe  NUMBER;

    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    p_result := TRUE;

    BEGIN

      SELECT carta_porte_id
        INTO l_existe
        FROM XX_TCG_GASTO_ACONDICIONAMIENTO
       WHERE certificado_id = p_certificado_id
         AND carta_porte_id = p_carta_porte_id;


      IF (NOT p_eliminar_registro) THEN

        BEGIN

          UPDATE XX_TCG_GASTO_ACONDICIONAMIENTO
             SET acond_id          = p_acondicionamiento_id
               , paritaria_tarifa  = p_tarifa_paritaria
               , paritaria_importe = p_importe_paritaria
               , secada_tarifa     = p_tarifa_secada
               , secada_importe    = p_importe_secada
               , fumigada_tarifa   = p_tarifa_fumigacion
               , fumigada_importe  = p_importe_fumigacion
               , zaranda_tarifa    = p_tarifa_zaranda
               , zaranda_importe   = p_importe_zaranda
               , last_updated_by   = FND_GLOBAL.user_id
               , last_update_login = FND_GLOBAL.login_id
               , last_update_date  = SYSDATE
           WHERE certificado_id    = p_certificado_id
             AND carta_porte_id    = p_carta_porte_id;

        EXCEPTION
          WHEN OTHERS THEN
            p_result    := FALSE;
            p_error_msg := 'Error en Actualizar_Gastos_Acdmto_CP. Error al intentar actualizar la tabla '||
                           'XX_TCG_GASTO_ACONDICIONAMIENTO para la carta de porte '||p_carta_porte_id||'. '||
                           SQLERRM;
            RETURN;

        END;

      ELSE

        BEGIN

          DELETE FROM XX_TCG_GASTO_ACONDICIONAMIENTO
           WHERE certificado_id = p_certificado_id
             AND carta_porte_id = p_carta_porte_id
             AND acond_id       = p_acondicionamiento_id;

        EXCEPTION
          WHEN OTHERS THEN
            p_result    := FALSE;
            p_error_msg := 'Error en Actualizar_Gastos_Acdmto_CP. Error al intentar borrar de la tabla '||
                           'XX_TCG_GASTO_ACONDICIONAMIENTO, la carta de porte '||p_carta_porte_id||'. '||
                           SQLERRM;
            RETURN;

        END;

      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN

        BEGIN

          INSERT INTO XX_TCG_GASTO_ACONDICIONAMIENTO
            ( CERTIFICADO_ID
            , CARTA_PORTE_ID
            , ACOND_ID
            , PARITARIA_TARIFA
            , PARITARIA_IMPORTE
            , SECADA_TARIFA
            , SECADA_IMPORTE
            , FUMIGADA_TARIFA
            , FUMIGADA_IMPORTE
            , ZARANDA_TARIFA
            , ZARANDA_IMPORTE
            , CREATED_BY
            , CREATION_DATE
            , LAST_UPDATED_BY
            , LAST_UPDATE_LOGIN
            , LAST_UPDATE_DATE)
          VALUES
            ( p_certificado_id
            , p_carta_porte_id
            , p_acondicionamiento_id
            , p_tarifa_paritaria
            , p_importe_paritaria
            , p_tarifa_secada
            , p_importe_secada
            , p_tarifa_fumigacion
            , p_importe_fumigacion
            , p_tarifa_zaranda
            , p_importe_zaranda
            , FND_GLOBAL.user_id
            , SYSDATE
            , FND_GLOBAL.user_id
            , FND_GLOBAL.login_id
            , SYSDATE
            );

        EXCEPTION
          WHEN OTHERS THEN
            p_result := FALSE;
            p_error_msg := 'Error en Actualizar_Gastos_Acdmto_CP. Error inesperado al intentar '||
                           'insertar la linea: '||SQLERRM;
            RETURN;
        END;

      WHEN OTHERS THEN
        p_result := FALSE;
        p_error_msg := 'Error en Actualizar_Gastos_Acdmto_CP. Error inesperado al validar '||
                       'si ya existía una linea para la CP '||p_carta_porte_id||': '||SQLERRM;
        RETURN;
    END;


    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Actualizar_Gastos_Acdmto_CP. Error inesperado '||SQLERRM;

  END Actualizar_Gastos_Acdmto_CP;




/****************************************************************************
 *                                                                          *
 * Name    : Get_Parametros_Secada                                          *
 * Purpose : Procedimiento para obtener los valores de Secada para informar *
 *           a la AFIP                                                      *
 *                                                                          *
 ****************************************************************************/
  PROCEDURE Get_Parametros_Secada ( p_acond_id              IN NUMBER
                                  , p_merma_header_id       IN NUMBER
                                  , p_porc_rango_inferior  OUT NUMBER
                                  , p_porc_rango_superior  OUT NUMBER
                                  , p_tarifa               OUT NUMBER
                                  , p_tarifa_exceso        OUT NUMBER
                                  , p_result               OUT BOOLEAN
                                  , p_error_msg            OUT VARCHAR2)

  IS

    l_tipo              VARCHAR2(100);
    l_tabla             NUMBER;
    l_cant_ptos_libres  NUMBER;
    l_cant_ptos_exceso  NUMBER;
    l_tarifa_pto_normal NUMBER;
    l_tarifa_pto_exc    NUMBER;
    l_index             NUMBER;


    TYPE mermas_rec IS RECORD
      ( medicion      NUMBER
      , humedad_desde NUMBER
      , humedad_hasta NUMBER
      );


    TYPE mermas_tab IS TABLE OF mermas_rec INDEX BY BINARY_INTEGER;
    l_mermas  MERMAS_TAB;


    CURSOR c_acond IS
      SELECT tipo
           , tabla
           , NVL(s_pto_libre, 0)  cant_ptos_libres
           , NVL(s_pto_exc, 0)    cant_ptos_exceso
           , NVL(s_pto_ton, 0)    tarifa_pto_normal_ton
           , NVL(s_pto_adic, 0)   tarifa_pto_exc_ton
        FROM XX_TCG_ACONDICIONAMIENTO
       WHERE acond_id = p_acond_id;


    CURSOR c_mermas_pto IS
      SELECT medicion
        FROM XX_ACO_MERMA_LINES
       WHERE merma_header_id = p_merma_header_id
       ORDER BY medicion;

    CURSOR c_mermas_rgo (p_tabla NUMBER) IS
      SELECT humedad_desde
           , humedad_hasta
        FROM XX_TCG_COSTOS_SECADA_DTL
       WHERE costo_secada_id = p_tabla
       ORDER BY humedad_desde;


  BEGIN

    p_result := TRUE;

    OPEN c_acond;
    FETCH c_acond INTO l_tipo
                     , l_tabla
                     , l_cant_ptos_libres
                     , l_cant_ptos_exceso
                     , l_tarifa_pto_normal
                     , l_tarifa_pto_exc;
    CLOSE c_acond;

    p_tarifa        := l_tarifa_pto_normal;
    p_tarifa_exceso := l_tarifa_pto_exc;
    l_index         := 0;

    IF (l_tipo = 'PUNTO') THEN

      FOR rmp IN c_mermas_pto LOOP
        l_index := l_index + 1;
        l_mermas(l_index).medicion := rmp.medicion;
      END LOOP;

      IF (l_cant_ptos_libres > 0) THEN

        p_porc_rango_inferior := l_mermas(l_cant_ptos_libres+1).medicion;
        p_porc_rango_superior := l_mermas(l_index).medicion;

      ELSE

        p_porc_rango_inferior := l_mermas(1).medicion;
        p_porc_rango_superior := l_mermas(l_index).medicion;

      END IF;

    ELSIF (l_tipo = 'RANGO') THEN

      FOR rmg IN c_mermas_rgo (l_tabla) LOOP
        l_index := l_index + 1;
        l_mermas(l_index).humedad_desde := rmg.humedad_desde;
        l_mermas(l_index).humedad_hasta := rmg.humedad_hasta;
      END LOOP;

      IF (l_cant_ptos_libres > 0) THEN

        p_porc_rango_inferior  := l_mermas(l_cant_ptos_libres+1).humedad_desde;
        p_porc_rango_superior  := l_mermas(l_index).humedad_hasta;

      ELSE

        p_porc_rango_inferior  := l_mermas(1).humedad_desde;
        p_porc_rango_superior  := l_mermas(l_index).humedad_hasta;

      END IF;

    END IF;


  EXCEPTION
    WHEN OTHERS THEN
      p_result    := FALSE;
      p_error_msg := 'Error en Get_Parametros_Secada. Error inesperado '||SQLERRM;

  END Get_Parametros_Secada;

END XX_TCG_ACONDICIONAMIENTO_PKG;
/

exit
