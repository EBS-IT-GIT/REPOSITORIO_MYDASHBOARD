INSERT INTO bolinf.xx_hyp_periodos xhp (
SELECT period_name, period_year, period_num, 'CERRADO'
FROM   apps.gl_periods
WHERE  period_set_name = 'ADECO_CALENDARI'
AND    period_year = '2020');
--14 Registros