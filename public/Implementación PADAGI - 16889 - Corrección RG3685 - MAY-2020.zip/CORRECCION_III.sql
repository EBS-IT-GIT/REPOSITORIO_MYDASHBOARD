UPDATE apps.ap_invoices_all ai
SET    global_attribute12 = 'A'
      ,global_attribute13 = DECODE(global_attribute11, 'NC SERVICI', '03', 'FC SERVICI','01', global_attribute13)
      ,last_update_date = sysdate
      ,last_updated_by = 2070
WHERE  invoice_num IN ('0004-00000017','0004-00000003','0004-00000019')
AND    vendor_id = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name = 'PALMA JUAN CRUZ');
--3 Registro