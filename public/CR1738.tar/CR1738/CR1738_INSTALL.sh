#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR1738_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR1738
# |
# | HISTORY
# |   11-JUN-20  SOUZA, ARNALDO JULIO DE MELO - Bra
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR1738_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR1738_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR1738
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/ALR
mkdir -p xbol/12.0.0/FNDLOAD/CONC
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/PERSO
mkdir -p xbol/12.0.0/FNDLOAD/REQGRP
mkdir -p xbol/12.0.0/FNDLOAD/VALSET
mkdir -p xbol/12.0.0/sql/PKG
mkdir -p xbol/12.0.0/sql/SEQ
mkdir -p xbol/12.0.0/sql/TRG
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /desa12/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR1738" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR1738_9334.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR1738"
AddAllLogs $CROUT "FND" "CR1738_9334.ldt"
mv CR1738_9334.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ SEQCUSTOMER_TRX_ID_DB " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','SEQCUSTOMER_TRX_ID_DB','APPS','$PATCHDIR','CR1738');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv SEQCUSTOMER_TRX_ID_DB* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-SEQ SEQCUST_TRX_LINE_ID_DB " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('SEQ','SEQCUST_TRX_LINE_ID_DB','APPS','$PATCHDIR','CR1738');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv SEQCUST_TRX_LINE_ID_DB* $DOWNDBDIR/xbol/12.0.0/sql/SEQ

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-TRG XX_AR_BR_TRANSACAO_DEBITO_TRG " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('TRG','XX_AR_BR_TRANSACAO_DEBITO_TRG','APPS','$PATCHDIR','CR1738');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_AR_BR_TRANSACAO_DEBITO_TRG* $DOWNDBDIR/xbol/12.0.0/sql/TRG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-PKG XX_BR_AR_DM_AUTO_TRANSACTIONS " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'

export NLS_LANG='American_America.UTF8'
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('PKG','XX_BR_AR_DM_AUTO_TRANSACTIONS','APPS','$PATCHDIR','CR1738');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv XX_BR_AR_DM_AUTO_TRANSACTIONS* $DOWNDBDIR/xbol/12.0.0/sql/PKG

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-REQGRP JLBR+ARReports " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpreqg.lct JLBR+ARReports.ldt REQUEST_GROUP REQUEST_GROUP_NAME="JLBR + AR Reports" APPLICATION_SHORT_NAME="JL"
AddAllLogs $CROUT "FND" "JLBR+ARReports.ldt"
mv JLBR+ARReports.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/REQGRP

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_BR_AR_ORIGEM_DEBITO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_BR_AR_ORIGEM_DEBITO.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_BR_AR_ORIGEM_DEBITO"
AddAllLogs $CROUT "FND" "XX_BR_AR_ORIGEM_DEBITO.ldt"
mv XX_BR_AR_ORIGEM_DEBITO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_BR_TRANSACAO_DB_AR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_BR_TRANSACAO_DB_AR.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_BR_TRANSACAO_DB_AR"
AddAllLogs $CROUT "FND" "XX_BR_TRANSACAO_DB_AR.ldt"
mv XX_BR_TRANSACAO_DB_AR.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_TAXA_CAMBIO_BR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_TAXA_CAMBIO_BR.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_TAXA_CAMBIO_BR"
AddAllLogs $CROUT "FND" "XX_TAXA_CAMBIO_BR.ldt"
mv XX_TAXA_CAMBIO_BR.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_14NUMBER-PRECISAO9 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_14NUMBER-PRECISAO9.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_14 NUMBER - PRECISAO 9"
AddAllLogs $CROUT "FND" "XX_14NUMBER-PRECISAO9.ldt"
mv XX_14NUMBER-PRECISAO9.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_TRANSACAO_NFF_MOEDAS_ESTRANS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_TRANSACAO_NFF_MOEDAS_ESTRANS"
AddAllLogs $CROUT "FND" "XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt"
mv XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-CONC XX_BR_AR_DM_AUTO_TRANSACTIONS " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afcpprog.lct XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt PROGRAM APPLICATION_SHORT_NAME="XBOL" CONCURRENT_PROGRAM_NAME="XX_BR_AR_DM_AUTO_TRANSACTIONS"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt"
mv XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CONC

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_INTERFACE_HEADER" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_BR_AR_TRANS_DEBITO" END_USER_COLUMN_NAME="CUSTOMER_TRX_ID_REF"
AddAllLogs $CROUT "FND" "RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt"
mv RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_INTERFACE_HEADER" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_BR_AR_TRANS_DEBITO" END_USER_COLUMN_NAME="SEQ.CUSTOMER_TRX_ID_DB"
AddAllLogs $CROUT "FND" "RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt"
mv RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_INTERFACE_LINES" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_BR_AR_TRANS_DEBITO" END_USER_COLUMN_NAME="CUSTOMER_TRX_ID_REF"
AddAllLogs $CROUT "FND" "RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt"
mv RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_INTERFACE_LINES" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_BR_AR_TRANS_DEBITO" END_USER_COLUMN_NAME="CUSTOMER_TRX_LINE_ID_REF"
AddAllLogs $CROUT "FND" "RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt"
mv RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_INTERFACE_LINES" DESCRIPTIVE_FLEX_CONTEXT_CODE="XX_BR_AR_TRANS_DEBITO" END_USER_COLUMN_NAME="SEQ.CUST_TRX_LINE_ID_DB"
AddAllLogs $CROUT "FND" "RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt"
mv RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_CUST_TRX_TYPES" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_TRANSACAO_AR_DB"
AddAllLogs $CROUT "FND" "RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt"
mv RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_BATCH_SOURCES" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_REF_ORIGEM_DEBITO_AUTO"
AddAllLogs $CROUT "FND" "RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt"
mv RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF OE_HEADER_ATTRIBUTES_BR_XXTAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt DESC_FLEX APPLICATION_SHORT_NAME="ONT" DESCRIPTIVE_FLEXFIELD_NAME="OE_HEADER_ATTRIBUTES" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_TAXA"
AddAllLogs $CROUT "FND" "OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt"
mv OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt DESC_FLEX APPLICATION_SHORT_NAME="ONT" DESCRIPTIVE_FLEXFIELD_NAME="OE_HEADER_ATTRIBUTES" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_TAXA_CAMBIO"
AddAllLogs $CROUT "FND" "OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt"
mv OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF OE_HEADER_ATTRIBUTES_BR_XXDATATAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt DESC_FLEX APPLICATION_SHORT_NAME="ONT" DESCRIPTIVE_FLEXFIELD_NAME="OE_HEADER_ATTRIBUTES" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_DATA_TAXA"
AddAllLogs $CROUT "FND" "OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt"
mv OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_CUSTOMER_TRX_BR_XXTAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_CUSTOMER_TRX_BR_XXTAXA.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_CUSTOMER_TRX" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_TAXA"
AddAllLogs $CROUT "FND" "RA_CUSTOMER_TRX_BR_XXTAXA.ldt"
mv RA_CUSTOMER_TRX_BR_XXTAXA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_CUSTOMER_TRX_BR_XXDATATAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_CUSTOMER_TRX" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_DATA_TAXA"
AddAllLogs $CROUT "FND" "RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt"
mv RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF RA_CUSTOMER_TRX_BR_XXTAXACAMBIO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt DESC_FLEX APPLICATION_SHORT_NAME="AR" DESCRIPTIVE_FLEXFIELD_NAME="RA_CUSTOMER_TRX" DESCRIPTIVE_FLEX_CONTEXT_CODE="BR" END_USER_COLUMN_NAME="XX_TAXA_CAMBIO"
AddAllLogs $CROUT "FND" "RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt"
mv RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PERSO AR_ARXTWMAI_HEADER_81 " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct AR_ARXTWMAI_HEADER_81.ldt FND_FORM_CUSTOM_RULES FUNCTION_NAME="AR_ARXTWMAI_HEADER" SEQUENCE="81"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "AR_ARXTWMAI_HEADER_81.ldt"
mv AR_ARXTWMAI_HEADER_81.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PERSO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-PERSO ONT_OEXOETEL_72 " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct ONT_OEXOETEL_72.ldt FND_FORM_CUSTOM_RULES FUNCTION_NAME="ONT_OEXOETEL" SEQUENCE="72"
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "ONT_OEXOETEL_72.ldt"
mv ONT_OEXOETEL_72.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/PERSO

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-ALR XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $ALR_TOP/patch/115/import/xxalr.lct XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt ALR_ALERTS APPLICATION_SHORT_NAME="AR" ALERT_NAME="XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO"
AddAllLogs $CROUT "FND" "XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt"
mv XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/ALR


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-SEQ SEQCUSTOMER_TRX_ID_DB " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/SEQ/SEQCUSTOMER_TRX_ID_DB >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/SEQCUSTOMER_TRX_ID_DB.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/SEQ/SEQCUSTOMER_TRX_ID_DB.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/SEQCUSTOMER_TRX_ID_DB.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/SEQ/SEQCUSTOMER_TRX_ID_DB.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/SEQCUSTOMER_TRX_ID_DB.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-SEQ SEQCUST_TRX_LINE_ID_DB " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/SEQ/SEQCUST_TRX_LINE_ID_DB >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/SEQCUST_TRX_LINE_ID_DB.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/SEQ/SEQCUST_TRX_LINE_ID_DB.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/SEQCUST_TRX_LINE_ID_DB.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/SEQ/SEQCUST_TRX_LINE_ID_DB.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/SEQ/SEQCUST_TRX_LINE_ID_DB.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-TRG XX_AR_BR_TRANSACAO_DEBITO_TRG " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/TRG/XX_AR_BR_TRANSACAO_DEBITO_TRG >> $CROUT

if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG/XX_AR_BR_TRANSACAO_DEBITO_TRG.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/TRG/XX_AR_BR_TRANSACAO_DEBITO_TRG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG/XX_AR_BR_TRANSACAO_DEBITO_TRG.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/TRG/XX_AR_BR_TRANSACAO_DEBITO_TRG.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/TRG/XX_AR_BR_TRANSACAO_DEBITO_TRG.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-PKG XX_BR_AR_DM_AUTO_TRANSACTIONS " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/PKG/XX_BR_AR_DM_AUTO_TRANSACTIONS >> $CROUT

export NLS_LANG='American_America.UTF8'
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_BR_AR_DM_AUTO_TRANSACTIONS.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_BR_AR_DM_AUTO_TRANSACTIONS.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_BR_AR_DM_AUTO_TRANSACTIONS.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/PKG/XX_BR_AR_DM_AUTO_TRANSACTIONS.sql /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG >> $CROUT 2>> $CRERR
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/sql/PKG/XX_BR_AR_DM_AUTO_TRANSACTIONS.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-REQGRP JLBR+ARReports " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpreqg.lct $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/REQGRP/JLBR+ARReports.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_BR_AR_ORIGEM_DEBITO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_AR_ORIGEM_DEBITO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_BR_TRANSACAO_DB_AR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_BR_TRANSACAO_DB_AR.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_TAXA_CAMBIO_BR " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_TAXA_CAMBIO_BR.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_14NUMBER-PRECISAO9 " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_14NUMBER-PRECISAO9.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_TRANSACAO_NFF_MOEDAS_ESTRANS " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_TRANSACAO_NFF_MOEDAS_ESTRANS.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-CONC XX_BR_AR_DM_AUTO_TRANSACTIONS " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt CUSTOM_MODE=FORCE

export NLS_LANG='American_America.UTF8'

echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XX_BR_AR_DM_AUTO_TRANSACTIONS' 
              ,program_application => 'XBOL' 
              ,request_group       => 'JLBR + AR Reports' 
              ,group_application   => 'JL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XX_BR_AR_DM_AUTO_TRANSACTIONS' 
              ,program_application => 'XBOL' 
              ,request_group       => 'JLBR + AR Reports' 
              ,group_application   => 'JL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT


echo "DECLARE BEGIN 
IF NOT fnd_program.program_in_group 
              (program_short_name  => 'XX_BR_AR_DM_AUTO_TRANSACTIONS' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX AR BR All Reports' 
              ,group_application   => 'XBOL') THEN 
   fnd_program.add_to_group 
              (program_short_name  => 'XX_BR_AR_DM_AUTO_TRANSACTIONS' 
              ,program_application => 'XBOL' 
              ,request_group       => 'XX AR BR All Reports' 
              ,group_application   => 'XBOL'); 
END IF; 
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT; echo "" >> $CROUT

AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/CONC/XX_BR_AR_DM_AUTO_TRANSACTIONS.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_HEADER_XXBRARTRANSDEBI_SEQ.CUSTOMERTRX.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXIDRE.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_CUSTOMERTRXLINE.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_INTERFACE_LINES_XXBRARTRANSDEBI_SEQ.CUSTTRXLINE.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUST_TRX_TYPES_BR_XXTRANSACAOARDB.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_BATCH_SOURCES_BR_XXREFORIGEMDEBI.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF OE_HEADER_ATTRIBUTES_BR_XXTAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXTAXACAMBIO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF OE_HEADER_ATTRIBUTES_BR_XXDATATAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/OE_HEADER_ATTRIBUTES_BR_XXDATATAXA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_CUSTOMER_TRX_BR_XXTAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_CUSTOMER_TRX_BR_XXDATATAXA " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXDATATAXA.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF RA_CUSTOMER_TRX_BR_XXTAXACAMBIO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/RA_CUSTOMER_TRX_BR_XXTAXACAMBIO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PERSO AR_ARXTWMAI_HEADER_81 " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt CUSTOM_MODE=FORCE
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/AR_ARXTWMAI_HEADER_81.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-PERSO ONT_OEXOETEL_72 " >> $CROUT; echo "" >> $CROUT
export NLS_LANG='BRAZILIAN PORTUGUESE_AMERICA.UTF8'
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxaffrmcus.lct $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt CUSTOM_MODE=FORCE
export NLS_LANG='American_America.UTF8'
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/PERSO/ONT_OEXOETEL_72.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-ALR XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $ALR_TOP/patch/115/import/xxalr.lct $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt"
if ! ls /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
  svn add /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /desa12/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/ALR/XX_BR_VERIFICACAO_TRANS_DEB_PEND_CANCELAMENTO.ldt -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch




. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR1738" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR1738_9334.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR1738_9334.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
