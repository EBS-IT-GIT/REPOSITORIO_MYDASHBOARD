  set define off;

  CREATE OR REPLACE TRIGGER "APPS"."XX_AR_BR_TRANSACAO_DEBITO_TRG" 
BEFORE INSERT OR UPDATE
ON "JL"."JL_BR_CUSTOMER_TRX_EXTS#" REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
  WHEN ( NEW.ELECTRONIC_INV_STATUS = 2) DECLARE

  l_new_customer_trx_id     NUMBER;
  l_request_id              NUMBER;
  l_errmsg          VARCHAR2(2000);
  PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

               BEGIN
                  select rcta.customer_trx_id
                    into l_new_customer_trx_id
                  FROM apps.ra_customer_trx_all        rcta
                      ,apps.ra_cust_trx_types_all      rctta
                      ,apps.ra_batch_sources_all       rbsa
                 where rcta.cust_trx_type_id = rctta.cust_trx_type_id
                   AND rcta.batch_source_id = rbsa.batch_source_id
                   AND rctta.type in ('INV')
                   AND rcta.global_attribute_category = 'JL.BR.ARXTWMAI.Additional Info'
                   AND exists (SELECT 1
                                 FROM apps.cll_f255_ar_customers_v cfacv
                                WHERE cfacv.customer_id = rcta.bill_to_customer_id
                                  AND cfacv.site_use_id = rcta.bill_to_site_use_id
                                  AND cfacv.org_id = rcta.org_id
                                  AND cfacv.country <> 'BR'
                                  AND ROWNUM = 1)
                   AND rctta.attribute_category = 'BR'
                   AND rctta.attribute15 is not null
                   AND rcta.creation_date >= sysdate-120
                   AND rcta.customer_trx_id = :NEW.customer_trx_id;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      l_new_customer_trx_id := 1;
                      RETURN;
                END;

--
  fnd_global.apps_initialize (user_id => fnd_global.user_id
                             ,resp_id => fnd_global.resp_id
                             ,resp_appl_id => 222 );

--
      l_request_id := fnd_request.submit_request ( 'XBOL',
                                                   'XX_BR_AR_DM_AUTO_TRANSACTIONS',
                                                   '',
                                                   NULL,
                                                   FALSE,
                                                   FND_PROFILE.VALUE('ORG_ID'), ---param1
                                                   l_new_customer_trx_id,       ---param2
                                                   chr(0));
      COMMIT;

END;

/
ALTER TRIGGER "APPS"."XX_AR_BR_TRANSACAO_DEBITO_TRG" ENABLE;

exit
