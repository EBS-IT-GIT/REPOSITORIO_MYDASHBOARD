  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_BR_AR_DM_AUTO_TRANSACTIONS" AS

PROCEDURE log_p( p_name   IN VARCHAR2
                ,p_msg    IN VARCHAR2 ) ;


PROCEDURE output_p ( p_type             IN VARCHAR2
                    ,p_customer_trx_id  IN NUMBER   DEFAULT NULL
                    ,p_status           IN VARCHAR2 DEFAULT NULL
                    ,p_trx_number       IN VARCHAR2 DEFAULT NULL
                    ,p_customer_trx_id_new IN NUMBER   DEFAULT NULL
                    ,p_total            IN NUMBER   DEFAULT NULL
                    ,p_success          IN NUMBER   DEFAULT NULL
                    ,p_error            IN NUMBER   DEFAULT NULL ) ;


   PROCEDURE main_p ( errbuf            OUT VARCHAR2
                     ,retcode           OUT NUMBER
                     ,p_org_id          IN NUMBER
                     ,p_customer_trx_id IN NUMBER);


End XX_BR_AR_DM_AUTO_TRANSACTIONS;

/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_BR_AR_DM_AUTO_TRANSACTIONS" IS
--
-- +===================================================================+
-- |         Copyright (c) 2017 Adecoagro, Sao Paulo , Brasil          |
-- |                         All rights reserved.                      |
-- +===================================================================+
-- |                                                                   |
-- | Name       : XX_BR_AR_DM_AUTO_TRANSACTIONS                        |
-- |                                                                   |
-- |  Oracle Applications Rel 12.2.6                                   |
-- |   Produto.: Oracle                                                |
-- |  ### SD 91205 ###                                                 |
-- |  Objetivo: Processo de Criacao de Transacao de Debito em Moedas   |
-- |            Estrangeiras, com base na transacao do AR em moeda BRL |
-- | History:                                                          |
-- | ==========                                                        |
-- | Version  Date          Author           Description               |
-- | =======  ============  ==============   ========================= |
-- | 1.0      21/02/2018    Douglas Sousa    Initial Version           |
-- +===================================================================+
--


   PROCEDURE log_p( p_name   IN VARCHAR2
                   ,p_msg    IN VARCHAR2) IS
      --
      l_log_msg fnd_log_messages.message_text%TYPE;

      --
   BEGIN
      --
      l_log_msg := ' -> XX_BR_AR_DM_AUTO_TRANSACTIONS.' || p_name || ' = ' || p_msg;
      --
         --
         dbms_output.put_line(l_log_msg);
         fnd_file.put_line(fnd_file.LOG, l_log_msg); -- Rafae S. Nunes (Ninecon) -- SD 91205 -- Mai/2020
         --
   END;
   --
   PROCEDURE output_p ( p_type             IN VARCHAR2
                       ,p_customer_trx_id  IN NUMBER   DEFAULT NULL
                       ,p_status           IN VARCHAR2 DEFAULT NULL
                       ,p_trx_number       IN VARCHAR2 DEFAULT NULL
                       ,p_customer_trx_id_new IN NUMBER   DEFAULT NULL
                       ,p_total            IN NUMBER   DEFAULT NULL
                       ,p_success          IN NUMBER   DEFAULT NULL
                       ,p_error            IN NUMBER   DEFAULT NULL) IS
      --
      l_trx_number  NUMBER;
      --
   BEGIN
      --
      IF p_type = 'HEADER' THEN
         --
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '|                          Criacao de transacao de NOTA DEBITO no Modulo AR Oracle EBS                           |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Sem Parametros na Concurrent                                                                                  |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Processado(s)                                                                                                 |');
         fnd_file.put_line(fnd_file.OUTPUT, '| ------------------                                                                                             |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         --
      ELSIF p_type = 'ROW_HEADER' THEN
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|  Nro do Customer_trx_id_Referente : ' || RPAD(p_customer_trx_id,74, ' ')                                  || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Nota Fiscal ' || RPAD(p_status,97, ' ')                                                                  || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Nr. NF: ' || RPAD(p_trx_number,101, ' ')                                                                 || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|  Nro do Customer_trx_id nota Debito : ' || RPAD(NVL(TO_CHAR(p_customer_trx_id_new), ' '),72, ' ')         || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         --
      ELSIF p_type = 'SUM' THEN
         --
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '+----------------------------------------------------------------------------------------------------------------+');
         fnd_file.put_line(fnd_file.OUTPUT, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '|           Total Registros: ' || RPAD(p_total,83, ' ')                                                     || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '| Total Registros (Sucesso): ' || RPAD(p_success,83, ' ')                                                   || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|    Total Registros (Erro): ' || RPAD(p_error,83, ' ')                                                     || ' |');
         fnd_file.put_line(fnd_file.OUTPUT, '|                                                                                                                |');
         fnd_file.put_line(fnd_file.OUTPUT, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
         --
      END IF;
      --
   END;

   --

   PROCEDURE main_p ( errbuf            OUT VARCHAR2
                     ,retcode           OUT NUMBER
                     ,p_org_id          IN NUMBER
                     ,p_customer_trx_id IN NUMBER) IS
      --
      l_count_header            NUMBER;
      l_count_success           NUMBER;
      l_count_error             NUMBER;
      l_user_id                 NUMBER;
      l_ref_approved_sefaz      NUMBER;
      l_entry_cust_trx_type_id  NUMBER;
      l_count_lines             NUMBER;
      l_rma_trx_id              NUMBER;
      l_msg_count               NUMBER  := 0;
      l_customer_trx_id         NUMBER;
      l_resp_id                 NUMBER;
      l_resp_appl_id            NUMBER;
      l_total_gr_weight         NUMBER;
      l_total_nt_weight         NUMBER;
      --l_org_id                  NUMBER; -- Rafael -- 18/05/2020 -- variavel comentada, nao estava sendo usada.
      --
      l_name                    VARCHAR2(100);
      l_new_trx_number          VARCHAR2(100);
      l_return_status           VARCHAR2(1);
      l_msg_data                VARCHAR2(2000);
      l_msg_data_out            VARCHAR2(2000);
      l_volume_type             VARCHAR2(100);
      l_country_code            VARCHAR2(30);

      --
      l_ref_exchange_date       DATE;
      --
      l_error                   BOOLEAN := FALSE;
      --
      l_batch_source_rec        ar_invoice_api_pub.batch_source_rec_type;
      l_trx_header_tbl          ar_invoice_api_pub.trx_header_tbl_type;
      l_trx_lines_tbl           ar_invoice_api_pub.trx_line_tbl_type;
      l_trx_dist_tbl            ar_invoice_api_pub.trx_dist_tbl_type;
      l_trx_salescredits_tbl    ar_invoice_api_pub.trx_salescredits_tbl_type;
      ln_msg_index_out          NUMBER;
      lv_sqlerrm                VARCHAR2(4000) := NULL;
      --


      CURSOR c_header IS

            SELECT rcta.customer_trx_id
                   ,(apps.xx_om_int_adeco_prest_pkg.canonical_to_number_f(rctta.attribute15)) cust_trx_type_id
                   ,rcta.trx_number
                   ,rcta.trx_date
                   ,rcta.attribute13 invoice_currency_code
                   ,rcta.bill_to_customer_id
                   ,rcta.bill_to_site_use_id bill_cust_acct_site_id
                   ,rcta.ship_to_customer_id
                   ,rcta.ship_to_site_use_id ship_cust_acct_site_id
                   ,'User' exchange_rate_type
                   ,to_date(to_date(rcta.attribute12,'YYYY/MM/DD HH24:MI:SS'), 'DD/MM/YYYY') exchange_date
                   ,(apps.xx_om_int_adeco_prest_pkg.canonical_to_number_f(rcta.attribute11)) exchange_rate
                   ,rcta.ship_via
                   ,rcta.org_id
                   ,nvl(rcta.fob_point,0) fob_point
                   ,rcta.primary_salesrep_id
                   ,'S' default_tax_exempt_flag
                   ,rcta.global_attribute_category
                   ,rcta.term_id
                   ,rbsa.name batch_source_name
                   ,(apps.xx_om_int_adeco_prest_pkg.canonical_to_number_f(rbsa.attribute15)) batch_source_id
                   ,rcta.remit_to_address_id
                   ,rcta.global_attribute14
                   ,rcta.global_attribute16
                   ,rcta.global_attribute17
                   ,rcta.customer_trx_id interface_header_attribute1
              FROM apps.ra_customer_trx_all        rcta
                  ,apps.ra_cust_trx_types_all      rctta
                  ,apps.ra_batch_sources_all       rbsa
             where rcta.cust_trx_type_id = rctta.cust_trx_type_id
               AND rcta.batch_source_id = rbsa.batch_source_id
               AND rctta.type in ('INV')
               AND rcta.global_attribute_category = 'JL.BR.ARXTWMAI.Additional Info'
               AND exists (SELECT 1
                             FROM apps.cll_f255_ar_customers_v cfacv
                            WHERE cfacv.customer_id = rcta.bill_to_customer_id
                              AND cfacv.site_use_id = rcta.bill_to_site_use_id
                              AND cfacv.org_id = rcta.org_id
                              AND cfacv.country <> 'BR'
                              AND ROWNUM = 1)
               AND rcta.customer_trx_id = p_customer_trx_id;
      --


      CURSOR c_lines ( pc_customer_trx_id NUMBER) IS

                 SELECT rctla.customer_trx_id
                       ,rctla.customer_trx_line_id
                       ,rctla.line_number
                       ,rctla.customer_trx_id interface_line_attribute1
                       ,rctla.customer_trx_line_id interface_line_attribute2
                       ,rctla.quantity_invoiced
                       ,rctla.quantity_ordered
                       ,rctla.unit_selling_price / (apps.xx_om_int_adeco_prest_pkg.canonical_to_number_f(rcta.attribute11)) unit_selling_price
                       ,''unit_standard_price
                       ,rctla.inventory_item_id
                       ,rctla.uom_code
                       ,rctla.global_attribute4
                       ,rctla.global_attribute5
                       ,rctla.global_attribute6
                       ,rctla.global_attribute7
                       ,rctla.warehouse_id
                       ,rctla.global_attribute_category
                   FROM apps.ra_customer_trx_all rcta,
                        apps.ra_customer_trx_lines_all rctla
                  WHERE rcta.customer_trx_id = rctla.customer_trx_id
                    AND rctla.line_type = 'LINE'
                    AND rctla.customer_trx_id = pc_customer_trx_id;

      --
   BEGIN
      --
      dbms_output.enable(1000000);
      l_name := 'MAIN_P';
      --
      log_p(l_name,'Inicializando as variaveis');
      --
      log_p(l_name,'********************************');
      --
      l_count_success := 0;
      l_count_error   := 0;
      l_count_header  := 0;
      --
      log_p(l_name,'Abrindo o cursor c_header');      
      -- ----------------------------------------------------------------------------------- --
      -- Rafae S. Nunes (Ninecon) -- SD 91205 -- Mai/2020                                    --
      -- Teste Debug -- Utilizar apenas se for debugar fora da aplicacao!!!                  --
      -- ----------------------------------------------------------------------------------- --      
      /*fnd_global.apps_initialize ( user_id      => fnd_global.user_id
                                  ,resp_id      => fnd_global.resp_id
                                  ,resp_appl_id => 222);
      --                                                                    
      fnd_global.apps_initialize ( user_id      => 42397
                                  ,resp_id      => 51113
                                  ,resp_appl_id => 222);
      mo_global.set_policy_context('S', p_org_id); */
      --
      FOR r_header IN c_header LOOP -- LOOP r_header

         --
         l_count_header   := l_count_header + 1;
         l_volume_type := NULL;
         --
      /*fnd_global.apps_initialize ( user_id      => fnd_global.user_id
                                  ,resp_id      => fnd_global.resp_id
                                  ,resp_appl_id => 222);
      --mo_global.set_policy_context('S', l_org_id);
      mo_global.set_policy_context('S', p_org_id);*/
      --

               BEGIN
                  --
                  --
                  l_batch_source_rec.batch_source_id                  := r_header.batch_source_id;
                  --
                  log_p(l_name,'Populando as informacoes do cabecalho da Nota Fiscal');
                  --
                  l_trx_header_tbl(1).trx_header_id                     := r_header.customer_trx_id;
                  l_trx_header_tbl(1).trx_number                        := r_header.trx_number;
                  l_trx_header_tbl(1).trx_currency                      := r_header.invoice_currency_code;
                  l_trx_header_tbl(1).cust_trx_type_id                  := r_header.cust_trx_type_id;
                  l_trx_header_tbl(1).trx_date                          := r_header.trx_date;
                  l_trx_header_tbl(1).term_id                           := r_header.term_id;
                  l_trx_header_tbl(1).bill_to_customer_id               := r_header.bill_to_customer_id;
                  l_trx_header_tbl(1).ship_to_customer_id               := r_header.ship_to_customer_id;
                  l_trx_header_tbl(1).ship_to_address_id                := r_header.ship_cust_acct_site_id;
                  l_trx_header_tbl(1).sold_to_customer_id               := r_header.bill_to_customer_id;
                  l_trx_header_tbl(1).remit_to_address_id               := r_header.remit_to_address_id;
                  l_trx_header_tbl(1).exchange_rate_type                := r_header.exchange_rate_type;
                  l_trx_header_tbl(1).exchange_date                     := r_header.exchange_date;
                  l_trx_header_tbl(1).exchange_rate                     := r_header.exchange_rate;
                  l_trx_header_tbl(1).ship_date_actual                  := SYSDATE;
                  l_trx_header_tbl(1).ship_via                          := r_header.ship_via;
                  l_trx_header_tbl(1).fob_point                         := r_header.fob_point;
                  l_trx_header_tbl(1).primary_salesrep_id               := r_header.primary_salesrep_id;
                  l_trx_header_tbl(1).default_tax_exempt_flag           := r_header.default_tax_exempt_flag;
                  l_trx_header_tbl(1).org_id                            := r_header.org_id;
                  l_trx_header_tbl(1).global_attribute_category         := r_header.global_attribute_category;
                  l_trx_header_tbl(1).interface_header_context          := 'XX_BR_AR_TRANS_DEBITO';
                  l_trx_header_tbl(1).interface_header_attribute1       := r_header.customer_trx_id;
                  l_trx_header_tbl(1).interface_header_attribute2       := seqcustomer_trx_id_db.NEXTVAL;
                  l_trx_header_tbl(1).global_attribute14                := r_header.global_attribute14;
                  l_trx_header_tbl(1).global_attribute16                := r_header.global_attribute16;
                  l_trx_header_tbl(1).global_attribute17                := r_header.global_attribute17;

                  --
               END;
               --
               log_p(l_name,'Abrindo o cursor c_lines');
               --
               l_count_lines := 0;
               --

               -- COMENTADO LINES INICIO...
               FOR r_lines IN c_lines ( pc_customer_trx_id => r_header.customer_trx_id) LOOP -- r_lines

                  --
                     --
                     l_count_lines := l_count_lines + 1;
                     --
                     --
                     log_p(l_name,'Populando as informacoes da linha da Nota Fiscal');
                     --
                     l_trx_lines_tbl(l_count_lines).trx_header_id                    := r_header.customer_trx_id;
                     l_trx_lines_tbl(l_count_lines).trx_line_id                      := r_lines.customer_trx_line_id;
                     l_trx_lines_tbl(l_count_lines).line_number                      := r_lines.line_number;
                     l_trx_lines_tbl(l_count_lines).interface_line_context           := 'XX_BR_AR_TRANS_DEBITO';
                     l_trx_lines_tbl(l_count_lines).interface_line_attribute1        := r_header.customer_trx_id;
                     l_trx_lines_tbl(l_count_lines).interface_line_attribute2        := r_lines.customer_trx_line_id;
                     l_trx_lines_tbl(l_count_lines).interface_line_attribute3        := seqcust_trx_line_id_db.NEXTVAL;
                     l_trx_lines_tbl(l_count_lines).line_type                        := 'LINE';
                     l_trx_lines_tbl(l_count_lines).quantity_invoiced                := r_lines.quantity_invoiced;
                     l_trx_lines_tbl(l_count_lines).quantity_ordered                 := r_lines.quantity_ordered;
                     l_trx_lines_tbl(l_count_lines).unit_selling_price               := r_lines.unit_selling_price;
                     l_trx_lines_tbl(l_count_lines).unit_standard_price              := r_lines.unit_standard_price;
                     l_trx_lines_tbl(l_count_lines).inventory_item_id                := r_lines.inventory_item_id;
                     l_trx_lines_tbl(l_count_lines).uom_code                         := r_lines.uom_code;
                     l_trx_lines_tbl(l_count_lines).global_attribute_category        := r_lines.global_attribute_category;
                     l_trx_lines_tbl(l_count_lines).global_attribute4                := r_lines.global_attribute4;
                     l_trx_lines_tbl(l_count_lines).global_attribute5                := r_lines.Global_Attribute5;
                     l_trx_lines_tbl(l_count_lines).global_attribute6                := r_lines.global_attribute6;
                     l_trx_lines_tbl(l_count_lines).global_attribute7                := r_lines.global_attribute7;
                     l_trx_lines_tbl(l_count_lines).warehouse_id                     := r_lines.warehouse_id;

                     --

                     log_p(l_name,'Batch Source Debito = '   ||r_header.batch_source_id);
                     log_p(l_name,'cust_trx_type_id Debito ='||r_header.cust_trx_type_id);
                     log_p(l_name,'ship_cust_acct_site_id = '||r_header.ship_cust_acct_site_id);
                     log_p(l_name,'trx_number Saida = '      ||r_header.trx_number);
                     log_p(l_name,'Batch Source Saida = '    ||r_header.batch_source_name);

                     --
                  --
               END LOOP; -- LOOP r_lines
               --
               --
                  --
                  BEGIN
                     --
                     log_p(l_name,'Chamando a API para criar a Nota Fiscal no AR');
                     --
                     BEGIN
                        --
                        --
                        ar_invoice_api_pub.create_single_invoice( p_api_version          => 1.0                      -- IN
                                                                 ,p_init_msg_list        => FND_API.G_TRUE           -- IN
                                                                 ,p_commit               => FND_API.G_FALSE          -- IN
                                                                 ,p_batch_source_rec     => l_batch_source_rec       -- IN
                                                                 ,p_trx_header_tbl       => l_trx_header_tbl         -- IN
                                                                 ,p_trx_lines_tbl        => l_trx_lines_tbl          -- IN
                                                                 ,p_trx_dist_tbl         => l_trx_dist_tbl           -- IN
                                                                 ,p_trx_salescredits_tbl => l_trx_salescredits_tbl   -- IN
                                                                 ,x_customer_trx_id      => l_customer_trx_id        -- OUT
                                                                 ,x_return_status        => l_return_status          -- OUT
                                                                 ,x_msg_count            => l_msg_count              -- OUT
                                                                 ,x_msg_data             => l_msg_data               -- OUT
                                                                );

-- log--Inicio
                      dbms_output.put_line('l_return_status: '||l_return_status);
                      FND_FILE.PUT_LINE(FND_FILE.LOG, 'l_return_status: '||l_return_status);
                      --
                      IF l_return_status = fnd_api.g_ret_sts_error OR l_return_status = fnd_api.g_ret_sts_unexp_error THEN
                        dbms_output.put_line('FND_MSG_PUB.Count_Msg ');
                        dbms_output.put_line(l_return_status||': '||SQLERRM);
                        FND_FILE.PUT_LINE(FND_FILE.LOG, 'FND_MSG_PUB.Count_Msg ');
                        FND_FILE.PUT_LINE(FND_FILE.LOG, l_return_status||': '||SQLERRM);
                        --
                        FOR l_msg_count IN 1..FND_MSG_PUB.Count_Msg LOOP
                          FND_MSG_PUB.Get (p_msg_index     => l_msg_count
                                          ,p_encoded       => 'F'
                                          ,p_data          => l_msg_data
                                          ,p_msg_index_OUT => ln_msg_index_out);
                          --
                          lv_sqlerrm := SUBSTR(lv_sqlerrm||REPLACE(l_msg_data,CHR(10),''),1,3998);
                          dbms_output.put_line(l_return_status||': '||lv_sqlerrm);
                          FND_FILE.PUT_LINE(FND_FILE.LOG, l_return_status||': '||lv_sqlerrm);
                        END LOOP;
                        --
                        FND_MSG_PUB.Delete_Msg;
                      ELSE
                        dbms_output.put_line('FND_MSG_PUB.Count_Msg else: '||FND_MSG_PUB.Count_Msg);
                        FND_FILE.PUT_LINE(FND_FILE.LOG, 'FND_MSG_PUB.Count_Msg else: '||FND_MSG_PUB.Count_Msg);
                      END IF;

--log --Fim

                     EXCEPTION
                        WHEN OTHERS THEN
                           --
                           log_p (l_name, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           log_p (l_name, 'ERRO: Chamando a API para criar a Nota Fiscal no AR - ' || SQLERRM);
                           log_p (l_name, '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                           l_new_trx_number := 'ERRO Chamando a API para criar a Nota Fiscal no AR - '|| SUBSTR(SQLERRM, 1,30);
                           --
                           --
                     END;
                     --
                     IF l_return_status != FND_API.G_RET_STS_SUCCESS THEN
                        l_count_error:= l_count_error + 1;
                     ELSE
                         l_count_success := l_count_success + 1;
                     END IF;
                     --
                     FOR i IN (SELECT error_message
                                 FROM ar_trx_errors_gt) LOOP -- FOR i IN (SELECT error_message FROM ar_trx_errors_gt)
                       --
                       log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++');
                       log_p (l_name,'ERRO: API ' || i.error_message);
                       log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++');
                       --
                       --
                     END LOOP; -- FOR i IN (SELECT error_message FROM ar_trx_errors_gt)
                     --

                        BEGIN
                           --
                           SELECT rcta.trx_number
                             INTO l_new_trx_number
                             FROM apps.ra_customer_trx_all rcta
                            WHERE rcta.customer_trx_id = l_customer_trx_id;
                           --
                        EXCEPTION
                           WHEN OTHERS THEN
                              l_new_trx_number := 'ERRO: Ao processar a Transacao no Oracle';
                              --
                              log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                              log_p (l_name,'ERRO: Ao processar a Transacao no Oracle');
                              log_p (l_name,'+++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                              --
                              --
                        END;
                        --
                        log_p(l_name,'Nota Fiscal criada com successo');
                        log_p(l_name,'Nro da NF: '       || l_new_trx_number);
                        log_p(l_name,'Customer Trx Id: ' || l_customer_trx_id);
                        log_p(l_name,'Nro de Linhas: '   || l_count_lines);
                        --
                  END;
                  --
                 --
                  COMMIT;
                  --
                  --
                  output_p( p_type            => 'ROW_HEADER'
                           ,p_customer_trx_id => r_header.customer_trx_id
                           ,p_trx_number      => r_header.trx_number
                           ,p_customer_trx_id_new => l_customer_trx_id
                           ,p_status          => ' Integrada com Sucesso');
                  --
         --
      END LOOP; -- LOOP r_header
      --
      log_p(l_name,'-----------------------------------');
      log_p(l_name,'          Total Registros: ' || l_count_header);
      log_p(l_name,'Total Registros (Sucesso): ' || l_count_success);
      log_p(l_name,'   Total Registros (Erro): ' || l_count_error);
      log_p(l_name,'-----------------------------------');
      --
      output_p( p_type    => 'SUM'
               ,p_total   => l_count_header
               ,p_success => l_count_success
               ,p_error   => l_count_error);
      --
      IF l_count_header = l_count_success THEN -- IF l_count_total = l_count_success
         --
         retcode := 0;
         errbuf  := 'Integracao realizada com sucesso';
         --
      ELSIF l_count_header = l_count_error THEN -- IF l_count_total = l_count_success
         --
         retcode := 1; -- Termina concurrent com ADVERTENCIA, mas NAO para o processo.
       ---  retcode := 2;
         errbuf  := 'Integracao realizada com ERRO';
         --
      ELSE -- IF l_count_total = l_count_success
         --
         retcode := 1;
         errbuf  := 'Integracao realizada com ALERTAS, verificar';
         --
      END IF; -- IF l_count_total = l_count_success
      --
   END;

  END XX_BR_AR_DM_AUTO_TRANSACTIONS;
/

exit
