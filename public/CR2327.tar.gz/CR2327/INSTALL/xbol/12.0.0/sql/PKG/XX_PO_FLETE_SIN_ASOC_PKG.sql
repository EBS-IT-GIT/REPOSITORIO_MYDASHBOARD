  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_PO_FLETE_SIN_ASOC_PKG" is
P_ORG_ID            NUMBER;
P_VENDOR_ID     NUMBER;
P_TIPO      VARCHAR2(10);
P_DIAS    VARCHAR2(10);


procedure carga_tabla (p_operating_unit in number, p_transportista_id in number, p_tipo in varchar2, p_dias in number default null, p_incluye_oc in varchar2 default 'Y');

Function beforeReport  return boolean;

FUNCTION GET_LOCALIDAD_INV (p_secondary_inventory_name in varchar2, p_organization_id in number, p_location_id in number default null) return varchar2 ;

end xx_po_flete_sin_asoc_pkg;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_PO_FLETE_SIN_ASOC_PKG" is

g_dias_atras number ;
g_master_org number := 135;
g_casos_inv number;
g_casos_om number;
g_casos_rtv number;

FUNCTION GET_LOCALIDAD_INV (p_secondary_inventory_name in varchar2, p_organization_id in number, p_location_id in number default null) return varchar2 is
l_loc_nombre varchar2(360) := null;
l_loc_nombre_sv varchar2(360) := null;
l_location_id number := null;
begin
if p_location_id is null then
        if p_secondary_inventory_name is not null then
            begin
                       select  msi.location_id
                         into l_location_id
                        from mtl_secondary_inventories  msi
                        where msi.secondary_inventory_name = p_secondary_inventory_name
                                and msi.organization_id = p_organization_id;
                        exception when others then l_location_id := null;
                    end;
        end if;
        if l_location_id is null then
               begin
                            select      haou.location_id
                              into l_location_id
                        From  HR_ALL_ORGANIZATION_UNITS    haou
                        where haou.organization_id = p_organization_id;
                exception when others then l_location_id := null;
                end;
         end if;
else
      l_location_id := p_location_id;
end if;

if l_location_id is not null then
    begin
        select  (select xtl.loc_nombre from XX_TCG_LOCALIDADES           xtl
                    where xtl.pais_codigo = 'AR'
                     AND lpad(loc.loc_information16,5,'0') = xtl.loc_codigo
                    AND loc.region_2                 = xtl.pr_dpto_codigo),
                (select max(xtl.loc_nombre) from XX_TCG_LOCALIDADES           xtl
                    where xtl.pais_codigo = 'AR'
                     AND lpad(loc.loc_information16,5,'0') = xtl.loc_codigo)
                      into l_loc_nombre, l_loc_nombre_sv
                  from  hr_locations loc
                where loc.location_id = l_location_id ;

       exception when no_data_found then
                l_loc_nombre := null;
                l_loc_nombre_sv := null;
       end;
end if;

         return nvl(l_loc_nombre,l_loc_nombre_sv);


end get_localidad_inv     ;

procedure carga_tabla (p_operating_unit in number, p_transportista_id in number, p_tipo in varchar2, p_dias in number default null, p_incluye_oc in varchar2 default 'Y') is
 v_organization_id  number;
 x_errmsg  varchar2(1000);
 l_info_items VARCHAR2(4000);
 l_origen_pcia_org          varchar2(50);
l_origen_pcia_inv   varchar2(50);
 rRem                XX_PO_FLEPASIG_GT%ROWTYPE;
 l_casos        number;

begin
execute immediate 'truncate  table bolinf.XX_PO_FLEPASIG_GT';
g_dias_atras  :=  TO_NUMBER(NVL(p_dias, FND_PROFILE.value('XX_PO_DIAS_ANTELACION_PROFORMA')));

-----------------------------------------------------------------------------------------
--    TCG                                                                                               ---
-----------------------------------------------------------------------------------------
if p_tipo in ('ALL', 'TCG') THEN
        insert into bolinf.XX_PO_FLEPASIG_GT ( TIPO_DOCUMENTO
                                                , OPERATING_UNIT
                                                , TRANSPOR_VENDOR_ID
                                                , TRANSPORTISTA_DESC
                                                ,dominio
                                                ,PROVISIONADO_POR_DESC
                                                ,provisionado_por
                                                ,CLAVE_ID
                                                ,CLAVE_NRO
                                                ,inventory_item_id
                                                ,PRODUCTO_NRO
                                                ,PRODUCTO_DESC
                                                ,TITULAR_CUIT
                                                ,TITULAR_DESC
                                                ,origen_pcia
                                                ,origen_org_code
                                                ,DESTINATARIO_CUIT
                                                ,DESTINATARIO_DESC
                                                ,DESTINO_CUIT
                                                ,DESTINO_DESC
                                                , DESTINO_ESTAB_ID
                                                , titular_cp_estab_id
                                                , subinventory_code
                                                ,DESTINO_ESTAB_SUC
                                                ,DESTINO_PCIA
                                                ,FECHA_ENVIO
                                               , CANTIDAD
                                               , UDM
                                               , COSTO_UNITARIO
                                               , COSTO_TOTAL
                                                  ,CREATION_DATE
                                                ,INFO_ITEMS
                                                ,cant_items
                                                , localidad_origen
                                                , localidad_destino
                                                , inf_adicional_oc
                                                )

        SELECT 'TCG', xtpc.operating_unit  , atran.VENDOR_ID
                            , atran.vendor_name transportista_desc
                            , xtcp.PATENTE_CAMION || DECODE(NVL(xtcp.PATENTE_ACOPLADO,'ZZZZ'), 'ZZZZ',NULL,' - ' || xtcp.PATENTE_ACOPLADO)  dominio
                            , aps2.vendor_name provisionado_por_desc
                            , xtcp.provisionado_por
                            , xtcp.carta_porte_id clave_id
                            , xtcp.numero_carta_porte clave_NRO
                            , xtcp.item_id inventory_item_id
                            , msi.segment1 producto_nro
                            , msi.description producto_desc
                            , titular_cp_cuit  titular_cuit
                            ,  TITULAR_CP titular_desc
                            , (select xtpa.GEOGRAPHY_NAME from XX_TCG_PROVINCIAS_ARG  xtpa where xtpa.GEOGRAPHY_CODE =  TITULAR_CP_PROVINCIA) origen_pcia
                            ,  (SELECT  est.campo establecimiento   FROM  xx_opm_establecimientos est WHERE EST.ESTABLECIMIENTO_ID =  xtcp.titular_cp_estab_id) origen_org_code
                            , DESTINATARIO_CUIT destinatario_cuit
                            , destinatario  destinatario_desc
                            , DESTINO_CUIT
                            ,  destino  destino_desc
                            , DESTINO_ESTAB_ID
                            , titular_cp_estab_id
                            ,   case   when  intermediario_retiro = 'Y' or rtte_comercial_retiro = 'Y'  THEN  'Y'
                                else                 'N'
                                end es_retiro
                         , case
                             when  XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (xtcp.destino_cuit)  = 'Y' and xtcp.destino_estab_id is not null then
                                                           ('Estab :' ||   (select campo  from xx_opm_establecimientos where establecimiento_id = xtcp.DESTINO_ESTAB_ID))
                             when  XX_TCG_FUNCTIONS_PKG.Es_Empresa_Grupo_c (xtcp.destino_cuit)  = 'N'
                                       and xtcp.destino_id is not null and xtcp.destino_estab_id is not null then
                                               ( 'Suc : ' ||  ( select hl.address1
                                                        from hz_party_sites hps, hz_locations hl
                                                        where hps.party_id = xtcp.destino_id
                                                        and hps.party_site_id = xtcp.DESTINO_ESTAB_ID
                                                         and hl.location_id = hps.location_id))
                               when      xtcp.destino_localidad is not null and           xtcp.destino_provincia is not null then
                                                        ('Loc Oncca : ' || (select max( loc_oncca_desc || l.address_line_1 ||' ' ||  l.address_line_2)  destino_establ
                                                           from  (SELECT lv_loc.meaning     loc_oncca_code
                                                                   , lv_loc.description loc_oncca_desc
                                                                   , lv_loc.attribute1
                                                                   , prov.province_code prov_code
                                                                   , prov.province_name prov_desc
                                                              FROM fnd_lookup_values_vl lv_loc
                                                                 , fnd_lookup_values_vl lv_par
                                                                 , jl_ar_ap_provinces   prov
                                                              WHERE 1=1
                                                              AND lv_par.meaning     = lv_loc.attribute1
                                                              AND prov.province_code = lv_par.attribute1
                                                              AND lv_loc.lookup_type = 'XX_ACO_LOCALIDADES_ONCCA'
                                                              AND lv_loc.attribute_category = 'XX_ACO_LOCALIDADES_ONCCA'
                                                              AND lv_par.lookup_type = 'XX_ACO_PARTIDOS_ONCCA'
                                                             ) loc_oncca
                                                        , hr_locations            l
                                                        where  loc_oncca.loc_oncca_code   = xtcp.destino_localidad
                                                                    AND UPPER(loc_oncca.prov_code) = UPPER(xtcp.destino_provincia)
                                                                    AND l.loc_information15(+)  = loc_oncca.attribute1
                                                                    AND l.loc_information16(+)  = loc_oncca.loc_oncca_code
                                                                      AND l.attribute_category(+) = 'AR'))
                            else
                                                           ('Dir : ' || xtcp.destino_direccion)
                        end   Destino_estab_suc
                        , (select xtpa.GEOGRAPHY_NAME from XX_TCG_PROVINCIAS_ARG  xtpa where xtpa.GEOGRAPHY_CODE =  DESTINO_PROVINCIA) DESTINO_PCIA
                        ,  FECHA_ENVIO
                        , decode(substr(xtcp.numero_carta_porte,1,4),'9000',1, 
                                    ROUND(DECODE(nvl(peso_bruto_recepcion,0) - nvl(TARA_RECEPCION,0) ,0,  nvl(peso_bruto_ENVIO,0) - nvl(TARA_ENVIO,0) ,nvl(peso_bruto_recepcion,0) - nvl(TARA_RECEPCION,0))/ 1000,3)) CANTIDAD
                        , decode(substr(xtcp.numero_carta_porte,1,4),'9000','UN','TON') UDM
                        , decode(substr(xtcp.numero_carta_porte,1,4),'9000', round(costo_flete,2), round(costo_flete_xton,2)) costo_unitario
                        ,round(costo_flete,2) Costo_Total
                        , xtcp.creation_date
                        ,  msi.description || '|TON|'  || translate( to_char( (PESO_BRUTO_RECEPCION - TARA_RECEPCION)/1000, '999,999,999.00'),'.,',',.')
                        , 1
                            ,   (SELECT   xtl.loc_nombre
                                                        FROM xx_tcg_localidades xtl
                                                        WHERE  xtl.pais_codigo    = 'AR'
                                                        AND xtl.pr_dpto_codigo = titular_cp_provincia
                                                        AND xtl.loc_codigo     = titular_cp_localidad)   localidad_origen
                            ,   (SELECT   xtl.loc_nombre
                                                        FROM xx_tcg_localidades xtl
                                                        WHERE  xtl.pais_codigo    = 'AR'
                                                        AND xtl.pr_dpto_codigo = destino_provincia
                                                        AND xtl.loc_codigo     = destino_localidad)   localidad_destino
                        ,     decode(nvl(xtcp.INTERMEDIARIO_FLETE_CUIT,'X'),'X','TRANS - ','INTER - ') -- 0 si es sin intermediario, 1 si es intermediario                                     
                             ||  msi.description || ' - ' || nvl( xtcp.distancia_estimada ,(select xatd.distancia from xx_aco_tarifa_distancia xatd where xatd.distancia_id = xtcp.distancia_id)) || ' Kms - ' inf_adicional_oc
            FROM xx_tcg_cartas_porte      xtcp
                    , mtl_system_items         msi
                    , ap_suppliers             atran
                    , ap_suppliers aps2
                    , xx_tcg_parametros_compania xtpc
            WHERE 1=1
            AND DECODE( nvl(atran.attribute_category,'AR') , 'AR', atran.num_1099||atran.global_attribute12 , 'UY', atran.vat_registration_num)               = NVL(xtcp.intermediario_flete_cuit, xtcp.transportista_cuit)
            and nvl(atran.attribute_category,'AR') = xtpc.operating_unit_country
            and atran.enabled_flag = 'Y'
            and nvl(atran.end_date_active,sysdate+1) > sysdate
            AND atran.vendor_id           = NVL(p_transportista_id, atran.vendor_id)
            AND msi.inventory_item_id = xtcp.item_id
            AND msi.organization_id   = g_master_org
            AND xtcp.provisionado_flag  = 'Y'
            AND xtcp.provisionado_por   = aps2.party_id
            AND aps2.vendor_id          = xtpc.vendor_id
            AND xtpc.operating_unit     = p_operating_unit
            AND xtcp.creation_date >= SYSDATE-g_dias_atras
            AND  not EXISTS
                                        (SELECT 1
                                         FROM XX_AP_ASOCIA_CARTAS_PORTE xaacp
                                         WHERE 1=1
                                         AND xaacp.carta_porte_id = xtcp.carta_porte_id
                                          AND xaacp.tipo_erogacion IN (  'CP_NO_PROVISIONADAS', 'FLETE', 'RECHAZO_CP')
                                        )
            ;
           for c_cartasp in (select rowid row_id , clave_id, destino_cuit,  TITULAR_CUIT, inventory_item_id, DESTINO_ESTAB_ID, titular_cp_estab_id,
                                            XX_TCG_FUNCTIONS_PKG.Obtener_Cuit (provisionado_por) provisionado_por, subinventory_code,
                                            localidad_destino, localidad_origen
                                            from  XX_PO_FLEPASIG_GT
                                  where TIPO_DOCUMENTO = 'TCG') loop


                if not XX_TCG_PROVISION_FLETE_PK.ORG_DESTINO ( p_cuit_destino => c_cartasp.destino_cuit
                                                                                            , p_cuit_provisionado_por => c_cartasp.provisionado_por
                                                                                            , p_cuit_titular => c_cartasp.TITULAR_CUIT
                                                                                           , p_es_retiro => c_cartasp.subinventory_code -- contiene es retiro
                                                                                           , p_item_id => c_cartasp.inventory_item_id
                                                                                          , p_estab_id => c_cartasp.DESTINO_ESTAB_ID
                                                                                            , p_estab_id_tit => c_cartasp.titular_cp_estab_id
                                                                                            ,x_org_id =>  v_organization_id
                                                                                            , x_errmsg  => x_errmsg
                                                                                            ) then
                            v_organization_id := p_operating_unit; 
                END IF;
                
                SELECT COUNT(1) INTO l_casos from org_organization_definitions  WHERE ORGANIZATION_ID  = v_organization_id and operating_unit = p_operating_unit;    
                
                if l_casos = 0 then ---> la organizacion no pertenece a la unidad operativa, se busca desde el establecimiento
                   begin                         
                        SELECT msi.organization_id
                          INTO v_organization_id
                          FROM mtl_secondary_inventories msi,
                                   XX_OPM_ESTABLECIMIENTOS xoe,
                                   org_organization_definitions ood
                         WHERE     xoe.establecimiento_id = msi.attribute3
                               AND xoe.establecimiento_id = c_cartasp.titular_cp_estab_id
                               AND ood.organization_id = msi.organization_id
                               AND ood.operating_unit = p_operating_unit; 
                    exception when others then
                            begin
                                    SELECT organization_id
                                       INTO v_organization_id
                                     FROM org_organization_definitions 
                                     WHERE UPPER(organization_name) like '%PUERTO%TERCE%' 
                                     AND disable_date IS NULL 
                                     AND  operating_unit = p_operating_unit;
                              exception when others then
                                        v_organization_id := 0;
                             end;  
                    end ;
                 end if;

                update XX_PO_FLEPASIG_GT xpf set organization_id = v_organization_id,
                                            inf_adicional_oc = inf_adicional_oc || xpf.origen_org_code || ' - ' || c_cartasp.localidad_origen || ' - ' || c_cartasp.localidad_destino || ' - ' || xpf.dominio
                where rowid = c_cartasp.row_id;
            end loop;

END IF;
-----------------------------------------------------------------------------------------
--    controla que tenga registros en la impresión de recibos                       ---
-----------------------------------------------------------------------------------------

         SELECT sum(decode(source_table, 'MTL_MATERIAL_TRANSACTIONS',1,0)) casos_inv,
                     sum(decode(source_table,'WSH_NEW_DELIVERIES',1,0)) casos_om,
                     sum(decode(source_table,'RCV_TRANSACTIONS',1,0)) casos_rcv
           INTO g_casos_inv, g_casos_om , g_casos_rtv
             FROM xx_inv_remitos_impresos xiri,
                  wsh_carrier_services wser,
                  ORG_ORGANIZATION_DEFINITIONS ood
            WHERE   xiri.carrier_service_id = wser.carrier_service_id
                  AND xiri.creation_date > SYSDATE - g_dias_atras
                  AND wser.attribute1 = NVL (p_transportista_id, wser.attribute1)
                  AND xiri.organization_id = ood.organization_id
                  AND ood.operating_unit = p_operating_unit ;

-----------------------------------------------------------------------------------------
--    de remitos_impresos :  MTL_material_transactions                            ---
-----------------------------------------------------------------------------------------

if p_tipo in ('ALL', 'INV') and g_casos_inv > 0 THEN

        INSERT INTO bolinf.XX_PO_FLEPASIG_GT (OPERATING_UNIT,
                                        TRANSPOR_VENDOR_ID,
                                        TIPO_DOCUMENTO,
                                         carrier_service_id,
                                        TRANSPORTISTA_DESC,
                                        dominio,
                                        CLAVE_ID,
                                        CLAVE_NRO,
                                        REMITO,
                                        TITULAR_CUIT,
                                        TITULAR_DESC,
                                        organization_id,
                                        creation_date)
           SELECT ood.operating_unit
                  ,wser.ATTRIBUTE1 TRANSPOR_VENDOR_ID
                  , 'INV' TIPO_DOCUMENTO
                  , xiri.carrier_service_id
                 , (SELECT VENDOR_NAME     FROM AP_SUPPLIERS ASU       WHERE ASU.VENDOR_ID = wser.ATTRIBUTE1)                 transportista_desc
                  ,wser.attribute5
                  ,xiri.GROUP_ID
                  ,xiri.waybill_airbill CLAVE_NRO
                  ,xiri.waybill_airbill remito
                  ,hlv.global_attribute11 || hlv.global_attribute12 titular_cuit
                  ,hlv.GLOBAL_ATTRIBUTE8 titular_desc
                  ,xiri.organization_id
                  ,  xiri.creation_date
             FROM xx_inv_remitos_impresos xiri,
                  wsh_carrier_services wser,
                  ORG_ORGANIZATION_DEFINITIONS ood,
                  HR_ALL_ORGANIZATION_UNITS haou,
                  HR_LOCATIONS_V hlv
            WHERE     xiri.source_table = 'MTL_MATERIAL_TRANSACTIONS'
                  AND xiri.carrier_service_id = wser.carrier_service_id
                  AND xiri.creation_date > SYSDATE - g_dias_atras
                  AND wser.attribute1 = NVL (p_transportista_id, wser.attribute1)
                  AND xiri.organization_id = ood.organization_id
                  AND haou.organization_id = ood.operating_unit
                  AND haou.location_id = hlv.location_id
                  AND ood.operating_unit = p_operating_unit ;


                    FOR C_INV IN (SELECT  ROWID ROW_ID
                                            FROM   XX_PO_FLEPASIG_GT XPF WHERE TIPO_DOCUMENTO = 'INV' ) LOOP

                            select * into rRem from XX_PO_FLEPASIG_GT where rowid = c_inv.row_id;
                            begin
                                    select GEOGRAPHY_NAME
                                              into l_origen_pcia_inv
                                                       from mtl_secondary_inventories  msi_ori
                                                             , hr_locations loc_ori
                                                             , xx_tcg_provincias_arg pcia_ori
                                                      where msi_ori.secondary_inventory_name = rRem.subinventory_code
                                                                and msi_ori.organization_id = rRem.organization_id
                                                                and loc_ori.location_id(+) = msi_ori.location_id
                                                                and pcia_ori.geography_code(+) = loc_ori.region_2;
                             exception when others then l_origen_pcia_inv := null;
                             end;
                             begin
                                   select GEOGRAPHY_NAME
                                     into l_origen_pcia_org
                                               From  HR_ALL_ORGANIZATION_UNITS    haou
                                                       , HR_LOCATIONS_V               hlv
                                                       , xx_tcg_provincias_arg xtpa
                                            where haou.organization_id = rRem.organization_id
                                                  and  haou.location_id             = hlv.location_id
                                                  and xtpa.geography_code =  hlv.region_2 ;
                             exception when others then l_origen_pcia_org := null;
                             end;


                            for c_item in ( SELECT  substr( LISTAGG( ( SELECT DESCRIPTION FROM MTL_SYSTEM_ITEMS_B MSI WHERE MSI.ORGANIZATION_ID= g_master_org AND MSI.INVENTORY_ITEM_ID = MMT.INVENTORY_ITEM_ID) || '|' ||
                                                              MMT.TRANSACTION_UOM || '|'
                                                              ||   translate( to_char(DECODE(SIGN(PRIMARY_QUANTITY),-1,0-PRIMARY_QUANTITY,PRIMARY_QUANTITY) , '999,999,999.00'),'.,',',.')                  || '|' , ' ')
                                                                    WITHIN GROUP         (ORDER BY MMT.INVENTORY_ITEM_ID)    OVER (PARTITION BY MMT.TRANSACTION_SET_ID, mmt.waybill_airbill ),1,3900) todos
                                                   FROM mtl_material_transactions mmt
                                                WHERE mmt.TRANSACTION_SET_ID = rRem.CLAVE_ID
                                                   AND  mmt.waybill_airbill = rRem.REMITO
                                                  AND (mmt.transfer_organization_id IS NULL OR mmt.transaction_quantity < 0)) loop
                                         rRem.INFO_ITEMS  := c_item.todos;
                                         exit;
                        end loop;

                       SELECT MAX (mmt.inventory_item_id),
                                   COUNT (DISTINCT mmt.inventory_item_id),
                                    MAX (mmt.subinventory_code),
                                    MAX (mmt.transfer_organization_id),
                                     MAX (transfer_subinventory),
                                     MAX (mmt.TRANSACTION_DATE),
                                     MAX (mmt.ship_to_location_id) --customer_id, --> maxima ship_to_location_id
                            into rRem.inventory_item_id
                                , rRem.cant_items
                                , rRem.subinventory_code
                                , rRem.transfer_organization_id
                                , rRem.transfer_subinventory
                                 , rRem.fecha_envio
                                 , rRem.customer_id --> maxima ship_to_location_id
                             FROM mtl_material_transactions mmt
                            WHERE mmt.waybill_airbill = rRem.remito
                                  AND mmt.TRANSACTION_SET_ID = rRem.clave_id
                                  AND (mmt.transfer_organization_id IS NULL OR mmt.transaction_quantity < 0) -- para transferencia toma solo el movimiento de salida
                                 ;

                            select ood.organization_code
                            into rRem.origen_org_code
                            from   ORG_ORGANIZATION_DEFINITIONS ood
                            where ood.organization_id = rRem.organization_id;


                           rRem.origen_pcia :=    nvl(l_origen_pcia_inv,l_origen_pcia_org);
                           rRem.localidad_origen :=      GET_LOCALIDAD_INV (rRem.subinventory_code,  rRem.organization_id);

                           if  rRem.transfer_organization_id is null  then     --------> Ajustes
                                        -- recupera las localidades de destino
                                                 rRem.localidad_destino := null;
                                                 for c1_loc in (select  distinct GET_LOCALIDAD_INV(null,null,ship_to_location_id) localidad
                                                                        FROM mtl_material_transactions mmt
                                                                     WHERE mmt.waybill_airbill = rRem.remito
                                                                          AND mmt.TRANSACTION_SET_ID =  rRem.clave_id
                                                                          AND (mmt.transfer_organization_id IS NULL OR mmt.transaction_quantity < 0))  loop
                                                                if rRem.localidad_destino is not null then
                                                                   rRem.localidad_destino := rRem.localidad_destino || ' - ' ;
                                                                end if;
                                                                 rRem.localidad_destino := rRem.localidad_destino ||  c1_loc.localidad;
                                                    end loop;

                                             rRem.destino_cuit := rRem.titular_cuit;
                                             rRem.destino_desc    := rRem.titular_desc;

                                            begin
                                                    SELECT subzona, xoe.campo
                                                       into rRem.destino_pcia, rRem.destino_estab_suc
                                                     FROM mtl_secondary_inventories msi ,XX_OPM_ESTABLECIMIENTOS xoe
                                                   WHERE msi.location_id = rRem.customer_id
                                                       AND xoe.establecimiento_id = msi.attribute3;
                                            exception when others then

                                                    rRem.destino_pcia := null;
                                                    rRem.destino_estab_suc := null;
                                            end;
                        else -----------> transferencias
                                            begin

                                                    select  hlv.global_attribute11 || hlv.global_attribute12 cuit_DESTINO,
                                                              hlv.GLOBAL_ATTRIBUTE8  DESTINO_DESC
                                                        into rRem.destino_cuit, rRem.destino_desc
                                                         from ORG_ORGANIZATION_DEFINITIONS OOD
                                                                         , HR_ALL_ORGANIZATION_UNITS    haou
                                                                       , HR_LOCATIONS_V               hlv
                                                            where  OOD.organization_id = rRem.transfer_organization_id
                                                            and haou.organization_id            =  ood.operating_unit
                                                            and  haou.location_id             = hlv.location_id;
                                            exception when others then

                                                    rRem.destino_cuit := null;
                                                    rRem.destino_desc := null;
                                            end;

                                            begin
                                                        select decode(nvl(pcia_des.GEOGRAPHY_NAME ,'XXX'),'XXX',(select xtpa.GEOGRAPHY_NAME
                                                                                                                                                     from  HR_ALL_ORGANIZATION_UNITS    haou
                                                                                                                                                               , HR_LOCATIONS_V               hlv
                                                                                                                                                               , xx_tcg_provincias_arg xtpa
                                                                                                                                                    where haou.organization_id = rRem.transfer_organization_id
                                                                                                                                                          and  haou.location_id             = hlv.location_id
                                                                                                                                                          and xtpa.geography_code =  hlv.region_2) , pcia_des.GEOGRAPHY_NAME) destino_pcia,
                                                                    decode(nvl(msi_dfv.xx_tcg_establecimientos,'XXX'),'XXX',null,(select xoe.subzona || ' - ' || xoe.campo
                                                                                                                                                  from  xx_opm_establecimientos xoe
                                                                                                                                                  where  xoe.establecimiento_id  = msi_dfv.xx_tcg_establecimientos)) DESTINO_ESTAB_SUC
                                                        into rRem.destino_pcia, rRem.DESTINO_ESTAB_SUC
                                                      from mtl_secondary_inventories  msi_des
                                                                    , mtl_secondary_inventories_dfv  msi_dfv
                                                                    , hr_locations loc_des
                                                                    , xx_tcg_provincias_arg pcia_des
                                                            where msi_des.secondary_inventory_name = rRem.transfer_subinventory
                                                            and msi_des.organization_id = rRem.transfer_organization_id
                                                            and loc_des.location_id(+) = msi_des.location_id
                                                            and pcia_des.geography_code(+) = loc_des.region_2
                                                            and  msi_dfv.row_id = msi_des.rowid;
                                            exception when others then

                                                    rRem.destino_pcia := null;
                                                    rRem.DESTINO_ESTAB_SUC := null;
                                            end;

                                        -- Recupera todos las localidades de destino
                                        rRem.localidad_destino := null;
                                         for c1_loc in (select  distinct nvl(GET_LOCALIDAD_INV(null,null,msi.location_id),mmt.organization_id||'_'||mmt.subinventory_code || '_Sin loc' ) localidad
                                                                FROM mtl_material_transactions mmt
                                                                   ,mtl_secondary_inventories msi
                                                            WHERE msi.organization_id = mmt.organization_id
                                                                 and msi.secondary_inventory_name = mmt.subinventory_code
                                                                  AND mmt.waybill_airbill = rRem.remito
                                                                  AND mmt.TRANSACTION_SET_ID =  rRem.clave_id
                                                                  AND (mmt.transfer_organization_id IS NULL OR mmt.transaction_quantity < 0))  loop
                                                        if rRem.localidad_destino is not null then
                                                           rRem.localidad_destino := rRem.localidad_destino || ' - ' ;
                                                        end if;
                                                         rRem.localidad_destino := rRem.localidad_destino ||  c1_loc.localidad;
                                            end loop;

                                        -- Recupera todos las localidades de origen
                                        rRem.localidad_origen := null;
                                         for c2_loc in (select  distinct nvl(GET_LOCALIDAD_INV(null,null,msi.location_id) ,mmt.transfer_organization_id||'_'||mmt.transfer_subinventory || '_Sin loc' )  localidad
                                                                FROM mtl_material_transactions mmt
                                                                   ,mtl_secondary_inventories msi
                                                             WHERE msi.organization_id =  mmt.transfer_organization_id
                                                                  and msi.secondary_inventory_name = mmt.transfer_subinventory
                                                                  AND mmt.waybill_airbill = rRem.remito
                                                                  AND mmt.TRANSACTION_SET_ID =  rRem.clave_id
                                                                  AND (mmt.transfer_organization_id IS NULL OR mmt.transaction_quantity < 0))  loop
                                                        if rRem.localidad_origen is not null then
                                                           rRem.localidad_origen := rRem.localidad_origen || ' - ' ;
                                                        end if;
                                                         rRem.localidad_origen := rRem.localidad_origen ||  c2_loc.localidad;
                                            end loop;

                       end if;

                       if rRem.cant_items <> 1 then
                          rRem.producto_nro := null;
                          rRem.producto_desc := 'MULTIPLE';
                       ELSE
                                begin
                                                select   msi.segment1,msi.description
                                                  into rRem.producto_nro, rRem.producto_desc
                                             FROM         mtl_system_items         msi
                                               where   MSI.ORGANIZATION_ID = g_master_org
                                               AND msi.inventory_item_id = rRem.inventory_item_id;
                                exception when others then

                                                    rRem.producto_nro := null;
                                                    rRem.producto_desc := null;
                                end;
                       END IF;
                       rRem.inf_adicional_oc := rRem.Localidad_origen || ' - '  || rRem.remito || ' - ' || rRem.localidad_destino     ;

                  UPDATE bolinf.XX_PO_FLEPASIG_GT xacr
                            set (INFO_ITEMS
                                    ,inventory_item_id
                                , cant_items
                                , subinventory_code
                                , transfer_organization_id
                                , transfer_subinventory
                                , fecha_envio
                                , customer_id
                                , origen_org_code
                                , origen_pcia
                                , localidad_origen
                                , localidad_destino
                                , destino_cuit
                                , destino_desc
                                , destino_pcia
                                , destino_estab_suc
                                , producto_nro
                                , producto_desc
                                , inf_adicional_oc) = (select
                                 rRem.INFO_ITEMS
                                ,rRem.inventory_item_id
                                , rRem.cant_items
                                , rRem.subinventory_code
                                , rRem.transfer_organization_id
                                , rRem.transfer_subinventory
                                , rRem.fecha_envio
                                , rRem.customer_id
                                , rRem.origen_org_code
                                , rRem.origen_pcia
                                , rRem.localidad_origen
                                , rRem.localidad_destino
                                , rRem.destino_cuit
                                , rRem.destino_desc
                                , rRem.destino_pcia
                                , rRem.destino_estab_suc
                                , rRem.producto_nro
                                , rRem.producto_desc
                                , rRem.inf_adicional_oc from dual)
                            where rowid = c_inv.row_id;
                  END LOOP;

END IF;

-----------------------------------------------------------------------------------------
--    de remitos_impresos :  WSH_NEW_DELIVERIES                                ---
-----------------------------------------------------------------------------------------

if p_tipo in ('ALL', 'OM') and g_casos_om > 0 THEN
    insert into  bolinf.XX_PO_FLEPASIG_GT (  operating_unit, TIPO_DOCUMENTO,  remito, CLAVE_NRO, CLAVE_ID, organization_id,  creation_date,
                         carrier_service_id,   TRANSPOR_VENDOR_ID,
                          transportista_desc,
                           dominio,
                          trip_id,  ORIGEN_ORG_CODE,
                          origen_pcia, FECHA_ENVIO
                          ,localidad_origen)
           select   ood.operating_unit,   'OM', waybill_airbill, waybill_airbill,  group_id, xiri.organization_id,  xiri.creation_date,
                      xiri.carrier_service_id,   wser.attribute1 TRANSPOR_VENDOR_ID,
                      (select vendor_name from ap_suppliers where vendor_id = wser.attribute1) transportista_desc,
                        wser.attribute5,
                      (select max(wdt.trip_id)
                                     FROM wsh_new_deliveries wnd
                                             , wsh_delivery_assignments wda
                                             , wsh_deliverable_trips_v wdt
                                       where 1= 1
                                       AND wnd.organization_id = xiri.organization_id
                                       AND wnd.delivery_id = xiri.GROUP_ID
                                       AND wnd.delivery_id = wda.delivery_id
                                       AND wdt.delivery_detail_id = wda.delivery_detail_id) trip_id
                      ,ood.organization_code
                     ,  ( select GEOGRAPHY_NAME
                         from  HR_ALL_ORGANIZATION_UNITS    haou
                                , HR_LOCATIONS_V               hlv
                                , xx_tcg_provincias_arg xtpa
                        where haou.organization_id = xiri.organization_id
                              and  haou.location_id             = hlv.location_id
                              and xtpa.geography_code =  hlv.region_2) origen_pcia
                         , wnd.confirm_DATE
                     , GET_LOCALIDAD_INV (null, xiri. organization_id)  localidad_origen
             from      xx_inv_remitos_impresos xiri
                       , wsh_carrier_services wser
                      , ORG_ORGANIZATION_DEFINITIONS ood
                      , wsh_new_deliveries wnd
            where xiri.carrier_service_id = wser.carrier_service_id
            and xiri.source_table =  'WSH_NEW_DELIVERIES'
            and xiri.creation_date > sysdate-g_dias_atras
            and wser.attribute1 is not null
            --and wser.ship_method_meaning <> 'P
            and  wser.attribute1= nvl(p_transportista_id,wser.attribute1)
            and xiri.organization_id = ood.organization_id
            and ood.operating_unit = p_operating_unit
            and wnd.delivery_id = xiri.group_id
            and wnd.organization_id = xiri.organization_id;

                  FOR c_om IN (SELECT ROWID ROW_ID , CLAVE_ID, OPERATING_UNIT, ORIGEN_PCIA , trip_id
                                            FROM   XX_PO_FLEPASIG_GT XPF
                                            WHERE TIPO_DOCUMENTO = 'OM' ) LOOP


                            for c_item in ( SELECT  substr( LISTAGG( ( SELECT DESCRIPTION FROM MTL_SYSTEM_ITEMS_B MSI
                                                                                           WHERE MSI.ORGANIZATION_ID= g_master_org
                                                                                               AND MSI.INVENTORY_ITEM_ID = wdd.INVENTORY_ITEM_ID) || '|' || REQUESTED_QUANTITY_UOM || '|'
                                                                                                                                                    ||  translate( to_char(SHIPPED_QUANTITY , '999,999,999.00'),'.,',',.')  || '|' , ' ')
                                                                                            WITHIN GROUP         (ORDER BY WDD.INVENTORY_ITEM_ID)    OVER (PARTITION BY wda.delivery_iD ),1,3900) todos
                                                    FROM wsh_delivery_assignments wda
                                                               , wsh_delivery_details WDD
                                                    where   wda.delivery_id = C_om.CLAVE_ID
                                                                AND wda.delivery_detail_id = WDD.delivery_detail_id)loop
                                         L_INFO_ITEMS := c_item.todos;
                                         exit;
                           end loop;


                        UPDATE  XX_PO_FLEPASIG_GT XPF
                                SET INFO_ITEMS = L_INFO_ITEMS
                                , (INVENTORY_ITEM_ID, producto_nro, producto_desc, cant_items ) = (SELECT MAX(wdd.inventory_item_id),
                                                                                                                                       decode(COUNT(distinct wdd.inventory_item_id),1,max(MSI.segment1), null),
                                                                                                                                       decode(COUNT(DISTINCT wdd.inventory_item_id),1, max(msi.description),'MULTIPLE'),
                                                                                                                                      COUNT(DISTINCT wdd.inventory_item_id)
                                                                                                                                      FROM wsh_delivery_assignments wda
                                                                                                                                                , wsh_delivery_details WDD
                                                                                                                                               , mtl_system_items_b msi
                                                                                                                                     where   wda.delivery_id = C_om.CLAVE_id
                                                                                                                                      AND wda.delivery_detail_id = WDD.delivery_detail_id
                                                                                                                                       and msi.organization_id = g_master_org
                                                                                                                                       and  msi.inventory_item_id = wdd.inventory_item_id)
                                        ,    (titular_desc, titular_cuit) = (select hlv.GLOBAL_ATTRIBUTE8  titular_desc,     hlv.global_attribute11 || hlv.global_attribute12 titular_cuit
                                                                                 from HR_ALL_ORGANIZATION_UNITS    haou
                                                                                           , HR_LOCATIONS_V               hlv
                                                                                where  haou.organization_id            =  C_om.operating_unit
                                                                                and  haou.location_id             = hlv.location_id)
                                            , (  DESTINO_ESTAB_SUC , secuencia_remito,  destino_pcia, localidad_destino  ) =
                                                                                                                (select     loc_des.ui_location_code DESTINO_ESTAB_SUC,
                                                                                                                               stop_des.stop_sequence_number,
                                                                                                                            (select xtpa.GEOGRAPHY_NAME from XX_TCG_PROVINCIAS_ARG  xtpa
                                                                                                                              where xtpa.GEOGRAPHY_CODE =  nvl(loc_des.province,loc_des.address2))  destino_pcia,
                                                                                                                          nvl(loc_des.address2, (SELECT LOC_NOMBRE FROM XX_TCG_LOCALIDADES WHERE LOC_CODIGO =  loc_des.city))  localidad_destino
                                                                                                    from     wsh_delivery_legs wdl
                                                                                                            , wsh_trip_stops stop_des
                                                                                                            , wsh_locations loc_des
                                                                                                    where  wdl.delivery_id = C_om.CLAVE_id
                                                                                                    and     stop_des.stop_id            = wdl.drop_off_stop_id
                                                                                                    and loc_des.wsh_location_id   =  stop_des.stop_location_id)
                                            ,  origen_pcia = nvl((select   nvl(nvl(loc_ori.province,loc_ori.address2),C_om.origen_pcia)
                                                        from     wsh_delivery_legs wdl
                                                                , wsh_trip_stops stop_ori
                                                                , wsh_locations loc_ori
                                                        where  wdl.delivery_id = C_om.CLAVE_id
                                                        and     stop_ori.stop_id            = wdl.pick_up_stop_id
                                                        and loc_ori.wsh_location_id   =  stop_ori.stop_location_id),C_om.origen_pcia)
                                            , (destino_desc, destino_cuit) = (select hpa.party_name customer_name, hpa.jgzz_fiscal_code  ||SUBSTR(hca.global_attribute12,1,1)
                                                                            from  HZ_CUST_ACCOUNTS HCA,
                                                                                     hz_parties HPA
                                                                            where  HPA.PARTY_ID = HCA.PARTY_ID
                                                                            and hca.CUST_ACCOUNT_ID =  (select   max( wdd.customer_id)
                                                                                                                            FROM wsh_delivery_assignments wda
                                                                                                                                    , wsh_delivery_details WDD
                                                                                                                           where   wda.delivery_id = C_om.CLAVE_id
                                                                                                                           AND wda.delivery_detail_id = WDD.delivery_detail_id))
                                WHERE ROWID = C_om.ROW_ID;
                     END LOOP;

END IF;
-----------------------------------------------------------------------------------------
--    de remitos_impresos :  return to vendor                                           ---
-----------------------------------------------------------------------------------------

if p_tipo in ('ALL', 'RTV') and g_casos_rtv > 0 THEN
        insert into  bolinf.XX_PO_FLEPASIG_GT (  operating_unit, TIPO_DOCUMENTO,  CLAVE_NRO, remito, CLAVE_ID, organization_id,  creation_date,
                                             carrier_service_id,   TRANSPOR_VENDOR_ID, transportista_desc, dominio,
                                       FECHA_ENVIO,
                                      destino_cuit, destino_desc, destino_pcia,  localidad_destino, DESTINO_ESTAB_SUC,
                                      ORIGEN_ORG_CODE,ORIGEN_PCIA, localidad_origen)
            select distinct ood.operating_unit, 'RTV', xiri.waybill_airbill, xiri.waybill_airbill, xiri.group_id, xiri.organization_id, xiri.creation_date,
                                         xiri.carrier_service_id,  wser.attribute1, (select vendor_name from ap_suppliers where vendor_id = wser.attribute1) transportista_desc  ,  wser.attribute5,
                                                     rt.transaction_date
                                                      ,(asu.num_1099||asu.global_attribute12)  destino_cuit ,    asu.vendor_name   destino_desc
                                                     , ( select GEOGRAPHY_NAME    from   xx_tcg_provincias_arg xtpa where  xtpa.geography_code =  aps.province)  destino_pcia
                                                     , nvl(aps.address_line2, aps.state)  localidad_destino
                                                     ,aps.address_line1 || ' - ' || aps.address_line2  DESTINO_ESTAB_SUC
                                                     ,  (select ood.organization_code        from   ORG_ORGANIZATION_DEFINITIONS ood1        where ood1.organization_id = xiri.organization_id )    ORIGEN_ORG_CODE
                                                      , ( select GEOGRAPHY_NAME    from   xx_tcg_provincias_arg xtpa where  xtpa.geography_code =  hl.region_2)  ORIGEN_PCIA
                                                     , GET_LOCALIDAD_INV (null,  null,  hl.location_id)                   localidad_origen
          FROM rcv_transactions rt
             , xx_inv_remitos_impresos xiri
              , wsh_carrier_services wser
             , ORG_ORGANIZATION_DEFINITIONS ood
             , ap_supplier_sites_all aps
             , ap_suppliers asu
             , hr_locations hl
         WHERE 1 = 1
           AND rt.transaction_type = 'RETURN TO VENDOR'
           AND rt.rma_reference = xiri.waybill_airbill
           AND rt.GROUP_ID = xiri.GROUP_ID
           AND xiri.source_table = 'RCV_TRANSACTIONS'
           and xiri.carrier_service_id is not null
           and wser.carrier_service_id = xiri.carrier_service_id
           and  wser.attribute1= nvl(p_transportista_id,wser.attribute1)
           and ood.organization_id = xiri.organization_id
           and xiri.creation_date > sysdate-g_dias_atras
           and ood.operating_unit = p_operating_unit
           and aps.vendor_site_id = rt.vendor_site_id
            and asu.vendor_id = aps.vendor_id
            and  rt.deliver_to_location_id = hl.location_id
            ;
            FOR C_RTV IN (SELECT ROWID ROW_ID , CLAVE_ID, REMITO  , ORGANIZATION_ID FROM   XX_PO_FLEPASIG_GT XPF WHERE TIPO_DOCUMENTO = 'RTV' ) LOOP

                            for c_item in ( SELECT  substr( LISTAGG( ( SELECT DESCRIPTION FROM MTL_SYSTEM_ITEMS_B MSI WHERE MSI.ORGANIZATION_ID= g_master_org AND MSI.INVENTORY_ITEM_ID = rsl.item_id) || '|' ||
                                                              RSL.UNIT_OF_MEASURE || '|' ||   translate( to_char( RSL.QUANTITY_SHIPPED , '999,999,999.00'),'.,',',.') || '|' , ' ')
                                                                    WITHIN GROUP         (ORDER BY rsl.item_id)    OVER (PARTITION BY rt.rma_reference,rt.GROUP_ID ),1,3900) todos
                                                     FROM rcv_transactions rt,
                                                               rcv_shipment_lines RSL
                                                  WHERE  rt.transaction_type = 'RETURN TO VENDOR'
                                                     AND rt.rma_reference = C_RTV.REMITO
                                                      AND rt.GROUP_ID = C_RTV.clave_ID
                                                       AND RT.SHIPMENT_LINE_ID = RSL.SHIPMENT_LINE_ID)loop
                                         L_INFO_ITEMS := c_item.todos;
                                         exit;
                           end loop;


                        UPDATE  XX_PO_FLEPASIG_GT XPF
                                SET INFO_ITEMS = L_INFO_ITEMS
                                , (TITULAR_cuit, TITULAR_desc) = ( select  hlv.global_attribute11 || hlv.global_attribute12 TITULAR_cuit,
                                                                             hlv.GLOBAL_ATTRIBUTE8  TITULAR_desc
                                                                     from ORG_ORGANIZATION_DEFINITIONS OOD
                                                                            , HR_ALL_ORGANIZATION_UNITS    haou
                                                                            , HR_LOCATIONS_V               hlv
                                                                    where  OOD.organization_id = C_RTV.organization_id
                                                                       and haou.organization_id            =  ood.operating_unit
                                                                        and  haou.location_id             = hlv.location_id)
                                  ,(INVENTORY_ITEM_ID, producto_nro, producto_desc, cant_items ) = (SELECT MAX(rsl.ITEM_ID),
                                                                                                                       decode(COUNT(distinct rsl.ITEM_ID),1,max(msi.segment1), null),
                                                                                                                        decode(COUNT(DISTINCT ITEM_ID),1, max(rsl.item_description),'MULTIPLE'),
                                                                                                                        COUNT(DISTINCT ITEM_ID)
                                                                                                              FROM rcv_transactions rt,
                                                                                                                      rcv_shipment_lines RSL,
                                                                                                                      mtl_system_items_b msi
                                                                                                             WHERE  rt.transaction_type = 'RETURN TO VENDOR'
                                                                                                               AND rt.rma_reference = C_RTV.REMITO
                                                                                                               AND rt.GROUP_ID = C_RTV.clave_ID
                                                                                                               AND RT.SHIPMENT_LINE_ID = RSL.SHIPMENT_LINE_ID
                                                                                                               and msi.organization_id = g_master_org
                                                                                                               and  msi.inventory_item_id = rsl.item_id)
                                          , inf_adicional_oc = localidad_origen || ' - ' || remito || ' - ' || localidad_destino
                    WHERE ROWID =  C_RTV.ROW_ID;
        END LOOP;
end if;
-----------------------------------------------------------------------------------------
--    remitos de entrada                                                 ---
-----------------------------------------------------------------------------------------

if p_tipo in ('ALL', 'RCV') THEN
            --------------------------------------------
            --  Ingreso de proveedores
            -----------------------------------
            insert into  bolinf.XX_PO_FLEPASIG_GT (  operating_unit, TIPO_DOCUMENTO,  clave_nro, remito, CLAVE_ID, organization_id,  creation_date,
                                     carrier_service_id,   TRANSPOR_VENDOR_ID, transportista_desc, dominio,
                                    ORIGEN_ORG_CODE, localidad_origen , ORIGEN_PCIA,   FECHA_ENVIO ,
                                    titular_cuit, titular_desc)
            select  ood.operating_unit,  'PO',  replace(packing_slip,'R',''),    replace(packing_slip,'R','') , shipment_header_id,   rsh.ship_to_org_id    , rsh.creation_date  ,
                      rsh_dfv.carrier_service_id, wser.attribute1 TRANSPOR_VENDOR_ID,
                       (select vendor_name from ap_suppliers where vendor_id = wser.attribute1) transportista_desc  ,  wser.attribute5
                      ,aps.address_line1 || ' - ' || aps.address_line2  ORIGEN_ORG_CODE
                      , aps.address_line2 localidad_origen
                      ,  ( select GEOGRAPHY_NAME    from   xx_tcg_provincias_arg xtpa where  xtpa.geography_code =  aps.province)  ORIGEN_PCIA
                      , rsh.creation_date
                      ,(asu.num_1099||asu.global_attribute12)  titular_cuit ,    asu.vendor_name   titular_desc
             from      rcv_shipment_headers rsh
                       , rcv_shipment_headers_dfv rsh_dfv
                       , wsh_carrier_services wser
                      , ORG_ORGANIZATION_DEFINITIONS ood
                      , ap_supplier_sites_all aps
                      , ap_suppliers asu
            where rsh.rowid = rsh_dfv.row_id
            and rsh_dfv.carrier_service_id is not null
             AND rsh_dfv.carrier_service_id = wser.carrier_service_id
            and rsh.creation_date > sysdate-g_dias_atras
            and wser.attribute1 is not null
            and  wser.attribute1= nvl(p_transportista_id,wser.attribute1)
            and rsh.ship_to_org_id = ood.organization_id
            and ood.operating_unit = p_operating_unit
            and rsh.vendor_site_id = aps.vendor_site_id
            and asu.vendor_id = rsh.vendor_id
                ;

   FOR C_RCV IN (SELECT ROWID ROW_ID , CLAVE_ID, REMITO  , ORGANIZATION_ID , operating_unit ,
                        (Select max(ship_to_location_id)
                                        from rcv_transactions RT
                                        , PO_LINE_LOCATIONS_ALL PLL
                                    where destination_type_code = 'RECEIVING'
                                        AND  TRANSACTION_TYPE = 'RECEIVE'
                                        AND shipment_header_id = CLAVE_id
                                        AND PLL.LINE_LOCATION_ID = RT.PO_LINE_LOCATION_ID)        location_deliver
                            FROM   XX_PO_FLEPASIG_GT XPF
                            WHERE TIPO_DOCUMENTO = 'PO' ) LOOP

                            for c_item in ( SELECT  substr( LISTAGG( ( SELECT DESCRIPTION FROM MTL_SYSTEM_ITEMS_B MSI WHERE MSI.ORGANIZATION_ID= g_master_org AND MSI.INVENTORY_ITEM_ID =  PL.ITEM_ID) || '|' ||
                                                              RT.UOM_CODE || '|' ||translate( to_char(RT.PRIMARY_QUANTITY  , '999,999,999.00'),'.,',',.') || '|' , ' ')
                                                                    WITHIN GROUP         (ORDER BY PL.ITEM_ID)    OVER (PARTITION BY rt.shipment_header_id ),1,3900) todos
                                                   FROM rcv_transactions RT,
                                                             PO_LINES_ALL PL
                                                 WHERE  destination_type_code = 'RECEIVING'
                                                    AND  TRANSACTION_TYPE = 'RECEIVE'
                                                    AND shipment_header_id = C_RCV.CLAVE_id
                                                   AND PL.PO_LINE_ID = RT.PO_LINE_ID)loop
                                         L_INFO_ITEMS := c_item.todos;
                                         exit;
                           end loop;

                        UPDATE  XX_PO_FLEPASIG_GT XPF
                                SET INFO_ITEMS = L_INFO_ITEMS
                                    ,   (INVENTORY_ITEM_ID, producto_nro, producto_desc, cant_items ) = (SELECT MAX(PL.ITEM_ID),
                                                                                                                                   decode(COUNT(distinct PL.ITEM_ID),1,max(MSI.segment1), null),
                                                                                                                                   decode(COUNT(DISTINCT ITEM_ID),1, max(PL.item_description),'MULTIPLE'),
                                                                                                                                   COUNT(DISTINCT PL.ITEM_ID)
                                                                                                                      FROM rcv_transactions RT,
                                                                                                                                                PO_LINES_ALL PL,
                                                                                                                                              mtl_system_items_b msi
                                                                                                                     WHERE  destination_type_code = 'RECEIVING'
                                                                                                                        AND  TRANSACTION_TYPE = 'RECEIVE'
                                                                                                                        AND shipment_header_id = C_RCV.CLAVE_id
                                                                                                                       AND PL.PO_LINE_ID = RT.PO_LINE_ID
                                                                                                                       and msi.organization_id = g_master_org
                                                                                                                       and  msi.inventory_item_id = PL.item_id)
                                     ,(destino_desC, destino_cuit) = (select hlv.GLOBAL_ATTRIBUTE8  destino_desC,     hlv.global_attribute11 || hlv.global_attribute12 destino_cuit
                                                                         from HR_ALL_ORGANIZATION_UNITS    haou
                                                                                   , HR_LOCATIONS_V               hlv
                                                                        where  haou.organization_id            =  C_RCV.operating_unit
                                                                        and  haou.location_id             = hlv.location_id)
                           ,   (  DESTINO_ESTAB_SUC ,  destino_pcia  ) = (select     hl.ADDREsS_LINE_1,
                                                                                                  ( select GEOGRAPHY_NAME from   xx_tcg_provincias_arg xtpa where  xtpa.geography_code =  hl.REGION_2)  destino_pcia
                                                                                        from     HR_LOCATIONS hl
                                                                                        where  hl.location_id =    C_RCV.location_deliver )
                            , inf_adicional_oc = localidad_origen || ' - ' || remito  || ' - ' || GET_LOCALIDAD_INV ( null,null, C_RCV.location_deliver )
                     where rowid = C_RCV.row_id;
         end loop;
         ------------------------------------------------------------
         --- devoluciones de clientes (RMA)
         ---------------------------------------------------------------
         insert into  bolinf.XX_PO_FLEPASIG_GT (  operating_unit, TIPO_DOCUMENTO,  clave_nro, remito, CLAVE_ID, organization_id,  creation_date,
                                     carrier_service_id,   TRANSPOR_VENDOR_ID, transportista_desc, dominio,
                                FECHA_ENVIO ,
                                  customer_id,  titular_cuit, titular_desc)
            select  ood.operating_unit,  'RMA',  replace(packing_slip,'R',''),    replace(packing_slip,'R','') , shipment_header_id,   rsh.ship_to_org_id    , rsh.creation_date  ,
                      rsh_dfv.carrier_service_id, wser.attribute1 TRANSPOR_VENDOR_ID,
                       (select vendor_name from ap_suppliers where vendor_id = wser.attribute1) transportista_desc  ,  wser.attribute5
                      , rsh.creation_date
                      , rsh.customer_id
                      ,hpa.jgzz_fiscal_code  ||SUBSTR(hca.global_attribute12,1,1) titular_cuit
                      , hpa.party_name  titular_desc
             from      rcv_shipment_headers rsh
                       , rcv_shipment_headers_dfv rsh_dfv
                       , wsh_carrier_services wser
                      , ORG_ORGANIZATION_DEFINITIONS ood
                      , HZ_CUST_ACCOUNTS HCA
                      , hz_parties HPA
            where  RSH.receipt_source_code = 'CUSTOMER'
             AND rsh.rowid = rsh_dfv.row_id
            and rsh_dfv.carrier_service_id is not null
             AND rsh_dfv.carrier_service_id = wser.carrier_service_id
            and rsh.creation_date > sysdate-g_dias_atras
            and wser.attribute1 is not null
            and  wser.attribute1= nvl(p_transportista_id,wser.attribute1)
            and rsh.ship_to_org_id = ood.organization_id
            and ood.operating_unit = p_operating_unit
            AND HCA.CUST_ACCOUNT_ID= rsh.customer_id
              and HPA.party_id = hCa.party_id
                ;

   FOR C_RMA IN (SELECT ROWID ROW_ID , CLAVE_ID, REMITO  , ORGANIZATION_ID , operating_unit,
                        (SELECT hps.location_iD    FROM hz_cust_site_uses_all rsu,
                                                                        hz_cust_acct_sites_all hcas,
                                                                        hz_party_sites hps
                               WHERE rsu.site_use_id                 =  (select max(customer_site_id) from  rcv_transactions rt where rt.shipment_header_id = CLAVE_id)
                                 AND hcas.cust_acct_site_id       = rsu.cust_acct_site_id
                                 AND hcas.party_site_id             = hps.party_site_id) LOCATION_ORIGEN,
                          (Select  MAX(DELIVER_TO_LOCATION_ID)
                                                                                                            from rcv_transactions RT
                                                                                                        where destination_type_code = 'RECEIVING'
                                                                                                            AND  TRANSACTION_TYPE = 'RECEIVE'
                                                                                                            AND shipment_header_id = CLAVE_id) location_destino
                          FROM   XX_PO_FLEPASIG_GT XPF WHERE TIPO_DOCUMENTO = 'RMA' ) LOOP

                            for c_item in ( SELECT  substr( LISTAGG( ( SELECT DESCRIPTION FROM MTL_SYSTEM_ITEMS_B MSI WHERE MSI.ORGANIZATION_ID= g_master_org AND MSI.INVENTORY_ITEM_ID =  ool.inventory_item_id) || '|' ||
                                                              RT.UOM_CODE || '|' ||translate( to_char(RT.PRIMARY_QUANTITY  , '999,999,999.00'),'.,',',.') || '|' , ' ')
                                                                    WITHIN GROUP         (ORDER BY ool.inventory_item_id)    OVER (PARTITION BY rt.shipment_header_id ),1,3900) todos
                                                   FROM rcv_transactions RT
                                                            ,oe_order_lines_all ool
                                                    where rt.shipment_header_id =  C_rma.CLAVE_id
                                                        and ool.line_id =    rt.oe_order_line_id
                                                        and transaction_type = 'RECEIVE'
                                                        AND SOURCE_DOCUMENT_CODE = 'RMA'
                                                           AND DESTINATION_TYPE_CODE = 'RECEIVING' )  loop
                                         L_INFO_ITEMS := c_item.todos;
                                         exit;
                           end loop;

                        UPDATE  XX_PO_FLEPASIG_GT XPF
                                SET INFO_ITEMS = L_INFO_ITEMS
                                    ,   (INVENTORY_ITEM_ID, producto_nro, producto_desc, cant_items ) = (SELECT MAX(ool.inventory_item_id),
                                                                                                                                   decode(COUNT(distinct ool.inventory_item_id),1,max(MSI.segment1), null),
                                                                                                                                   decode(COUNT(DISTINCT ool.inventory_item_id),1, max(msi.description),'MULTIPLE'),
                                                                                                                                   COUNT(DISTINCT ool.inventory_item_id)
                                                                                                                      FROM rcv_transactions RT
                                                                                                                              ,oe_order_lines_all ool
                                                                                                                            ,    mtl_system_items_b msi
                                                                                                                     WHERE rt.shipment_header_id =  C_rma.CLAVE_id
                                                                                                                          and ool.line_id =    rt.oe_order_line_id
                                                                                                                          and transaction_type = 'RECEIVE'
                                                                                                                         AND SOURCE_DOCUMENT_CODE = 'RMA'
                                                                                                                          AND DESTINATION_TYPE_CODE = 'RECEIVING'
                                                                                                                       and msi.organization_id = g_master_org
                                                                                                                       and  msi.inventory_item_id = ool.inventory_item_id)

                                , (ORIGEN_ORG_CODE, ORIGEN_PCIA) = (SELECT  hl.address1 || ' - ' || hl.address2, UPPER(GEOGRAPHY_NAME)
                                                                                                FROM     hz_locations hl,
                                                                                                         xx_tcg_provincias_arg xtpa
                                                                                                WHERE hl.location_id                    = c_rma.LOCATION_ORIGEN
                                                                                                    AND  xtpa.geography_code            = hl.province        )

                                , inf_adicional_oc = (SELECT   hl.address2   FROM     hz_locations hl WHERE hl.location_id                    = c_rma.location_origen)
                                                                 || ' - ' || remito  || ' - ' ||
                                                                 XX_PO_FLETE_SIN_ASOC_PKG.GET_LOCALIDAD_INV(null,null, c_rma.location_destino)
                               ,(destino_desC, destino_cuit) = (select hlv.GLOBAL_ATTRIBUTE8  destino_desC,     hlv.global_attribute11 || hlv.global_attribute12 destino_cuit
                                                                                     from HR_ALL_ORGANIZATION_UNITS    haou
                                                                                         , HR_LOCATIONS_V               hlv
                                                                                    where  haou.organization_id            =  C_RMA.operating_unit
                                                                                      and  haou.location_id             = hlv.location_id)   ,
                         (  DESTINO_ESTAB_SUC ,  destino_pcia  ) = (select     hl.ADDREsS_LINE_1,
                                                                                                  ( select GEOGRAPHY_NAME from   xx_tcg_provincias_arg xtpa where  xtpa.geography_code =  hl.REGION_2)  destino_pcia
                                                                                        from     HR_LOCATIONS hl
                                                                                        where  hl.location_id =  c_rma.location_destino)

                     where rowid = C_RMA.row_id;
         end loop;
end if;
-- calcula columnas provincia final  y nros orden de compra
update xx_po_flepasig_gt xpf set destino_pcia = nvl(destino_pcia, origen_pcia),
                                            (oc_flete_id , oc_estadia_id, oc_aforo_id) = (select max(decode(xpar.tipo_erogacion,'FLETE',xpar.po_header_id,null)),
                                                                                                                        max(decode(xpar.tipo_erogacion,'ESTADIA',xpar.po_header_id,null)),
                                                                                                                        max(decode(xpar.tipo_erogacion,'AFORO',xpar.po_header_id,null))
                                                                                                               FROM XX_PO_ASOCIA_REMITOS xpar,
                                                                                                                            po_headers_all poh 
                                                                                                               WHERE xpar.clave_id = decode(xpf.tipo_documento,'OM',xpf.trip_id,xpf.clave_id)
                                                                                                                 and xpar.tipo_documento = xpf.tipo_documento
                                                                                                                 and    poh.po_header_id = xpar.po_header_id
                                                                                                                 and nvl(poh.cancel_flag,'N') = 'N' -- si esta cancelada  el remito no queda tomado 
                                                                                                                 and  nvl(poh.authorization_status,'INCOMPLETE')  not  IN ('CANCELED','CANCELLED','REJECTED')  -- si esta cancelada  el remito no queda tomado
                                                                                                                )                                          
                                                                    --AND  po_headers_sv3.get_po_status(po_header_id) NOT LIKE '%Cancelled%'
                                                                    -- AND  Po_headers_sv3.get_po_status(po_header_id) NOT LIKE '%Rejected%')
;

update xx_po_flepasig_gt a set destino_pcia_final = destino_pcia , clave_busqueda = clave_nro where trip_id is  null;


for c_viajes in (select  rowid row_id,
                   LAST_VALUE(destino_pcia) IGNORE NULLS
                         OVER (PARTITION BY trip_id ORDER BY clave_id ROWS BETWEEN
                           UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)  as destino_pcia_final ,
                   trip_id || ' : ' ||    LISTAGG(remito , '; ')          WITHIN GROUP            (ORDER BY secuencia_remito , remito)    OVER (PARTITION BY trip_id)  clave_busqueda,
                   localidad_origen || ' : ' ||    LISTAGG(remito || '-' || localidad_destino  , ' - ')          WITHIN GROUP            (ORDER BY secuencia_remito, remito)    OVER (PARTITION BY trip_id)  inf_adicional_oc
                             from xx_po_flepasig_gt tb
        where trip_id is not null) loop
        
            update xx_po_flepasig_gt set destino_pcia_final = c_viajes.destino_pcia_final
                                                        , clave_busqueda = c_viajes.clave_busqueda
                                                        , inf_adicional_oc = substr(c_viajes.inf_adicional_oc,1,2000)
            where rowid = c_viajes.row_id;
end loop;

-- Agrega el TRANS o INTER para Tcg
    update xx_po_flepasig_gt set clave_busqueda = substr(inf_adicional_oc,1,6) || clave_busqueda
    WHERE TIPO_DOCUMENTO = 'TCG';
--commit;
end;

Function beforeReport  return boolean is
begin

carga_tabla (p_operating_unit => P_ORG_ID
                , p_transportista_id => P_VENDOR_ID
                , p_tipo => NVL(P_TIPO, 'ALL')
                , p_dias => p_dias);
return true;

end beforeReport;

end xx_po_flete_sin_asoc_pkg;
/

exit
