UPDATE apps.ra_customer_trx_all rct
SET    batch_source_id = (SELECT batch_source_id FROM   apps.ra_batch_sources_all WHERE  org_id = 102 AND    name ='ND FICT PERCP')
      ,cust_trx_type_id = (SELECT cust_trx_type_id FROM   apps.ra_cust_trx_types_all WHERE  name = 'ND INT SOLO-PERC' AND    org_id = 102)
WHERE  customer_trx_id IN (14267306,14267315,14153200,14171196,14185375,14192232);
--6 Registros