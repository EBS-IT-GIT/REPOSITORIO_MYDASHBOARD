UPDATE apps.xx_inv_remitos_impresos 
SET    waybill_airbill = '0044-00054328', last_update_date = sysdate, last_updated_by = 2070
WHERE  waybill_airbill = '0044-00054628';
--1 Registro