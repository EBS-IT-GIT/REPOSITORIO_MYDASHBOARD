  set define off;

  CREATE OR REPLACE PACKAGE "APPS"."XX_OPM_RATEIO_PKG" IS
--
-- $Header: %f% %v% %d% %u% ship $
-- $Id: XX_OPM_RATEIO_PKG.txt 120.1 2019-06-11 12:00:00 rsnunes $
-- +=====================================================================+
-- |         Copyright (c) 2019 Ninecon, Sao Paulo , Brasil              |
-- |                         All rights reserved.                        |
-- +=====================================================================+
-- | FILENAME                                                            |
-- |   XX_OPM_RATEIOS_PKG.txt                                            |
-- |                                                                     |
-- | PURPOSE                                                             |
-- |   Oracle Applications Rel 12.2.6                                    |
-- |   Produto.: Oracle                                                  |
-- |   #53400# R11 - #727# R12 - Projeto Rateio de Custos indiretos      |
-- |   Objetivo: Projeto de automatizacao do processo de alocacao de     |
-- |             despesas indiretas nos centros de custos de apoios.     |
-- |                                                                     |
-- | DESCRIPTION                                                         |
-- |    Para esse desenvolvimento estaremos utilizando os dados do balan-|
-- |    cete (movimento do mes, debito menos credito) as contas do grupo |
-- |    de despesas (5XXXXX), criaremos  um portal  para  as areas (AGR, |
-- |    AGR-EQ, IND e RH),  informar  os  dados  referente  aos  indices |
-- |    utilizados para o rateio. A customizacao preve integracao  com a |
-- |    contabilidade  gerando os  lancamentos de  reclassificacoes  das |
-- |    despesas por fases (areas),  visando zerar os valores existentes |
-- |    nos centro de custos de apoio.  Contempla rotina de  verificacao |
-- |    se existem lancamentos em  contas contabeis ou  centro  de custo |
-- |    nao  cadastrados  nas  tabelas  customizadas. Todas as fases das |
-- |    rotinas devem ser passiveis de conferencia  antes da  integracao |
-- |    com a contabilidade,  isso deve ocorrer atraves de  relatorio de |
-- |    apoio a ser desenhado nesse projeto.  O resultado do processo de |
-- |    realocacao no  seu final deve apresentar saldo zerado nos centro |
-- |    de custo de apoio, isso demonstrara o sucesso do processo.       |
-- |                                                                     |
-- | CREATED BY                                                          |
-- |   Rafael S. Nunes (Ninecon)    11/06/2019 ~ 23/10/2019              |
-- |                                                                     |
-- | UPDATED BY                                                          |
-- |   Rafael S. Nunes (Ninecon) -- SD 110926 -- 05/12/2019              |
-- |     Correcoes diversas na procedure ETP_ANT_IND_21603_P.            |
-- |     Alterado os  percentuais 100% e 50% para o padrao dos arquivos  |
-- |     de indices ficando entao representados por 1 e 0.5,  respecti-  |
-- |     vamente.                                                        |
-- |                                                                     |
-- |   Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020                | 
-- |     Inclusao do parametro P_ENVIAR_GL na procedure                  |
-- |     ENVIAR_RATEIO_GL_P, para que o usuario tenha a opcao de apenas  |
-- |     imprimir o relatorio para conferencia antes de enviar definiti- |
-- |     vamente os dados para a interface do GL.                        |
-- |                                                                     |
-- |     O nome do concurrent que dispara este procedimento foi alterado |
-- |     de  "XX OPM Enviar Rateio de Custos para Interface do GL"  para |
-- |     "XX OPM Lancamentos do Rateio de Custos para o GL"  para  ficar |
-- |     mais abrangente com sua nova finalidade.                        |
-- |                                                                     |
-- +=====================================================================+
--
  -- Variaveis Globais
  g_nCalc_Rateio_Id     NUMBER;
  g_nCalc_Rateio_Id_Pai NUMBER;
  g_nCalc_Ct            NUMBER; -- Contador dos registros inseridos na tabela BOLINF.XX_OPM_CALC_RATEIO
  g_nCt_Insert          NUMBER;
  g_nIteracao           NUMBER;
  g_nCt                 NUMBER;
  g_nUser_id            NUMBER;
  g_nLogin_id           NUMBER;
  -- ----------------------------------------------------------- --
  -- O cursor abaixo  representa os  valores originais vindos do --
  -- Balancete, essas informacoes sao as mesmas que sao exibidas --
  -- na tela XX Valores a Serem Distribuidos por Area.           --
  -- ----------------------------------------------------------- --
  CURSOR c_val_orig ( pc_ledger_id   bolinf.xx_gl_resum_val_area_v.ledger_id%TYPE
                     ,pc_periodo     bolinf.xx_gl_resum_val_area_v.periodo%TYPE
                     ,pc_etapa       VARCHAR2
                     ,pc_u_produtiva bolinf.xx_gl_resum_val_area_v.u_produtiva%TYPE
                     ,pc_mov_mes     VARCHAR2 ) IS
    SELECT val_area.ledger_id
          ,val_area.livro
          ,val_area.periodo
          ,val_area.area
          ,val_area.etapa
          ,val_area.u_produtiva_original
          ,val_area.u_produtiva
          ,val_area.produto
          ,val_area.projeto
          ,val_area.c_custo
          ,val_area.conta
          ,val_area.grupo
          ,val_area.grupo_conta
          ,val_area.moeda
          ,val_area.mov_mes
          ,val_area.indice_cadastrado
      FROM bolinf.xx_gl_resum_val_area_v val_area
     WHERE val_area.ledger_id   = pc_ledger_id
       AND val_area.periodo     = pc_periodo
       AND val_area.etapa       = pc_etapa
       AND (pc_u_produtiva IS NULL OR val_area.u_produtiva = pc_u_produtiva)
       AND (pc_mov_mes = 'TODOS' OR ((pc_mov_mes = 'COM VALOR' AND NVL(val_area.mov_mes,0) <> 0) OR
                                     (pc_mov_mes = 'SEM VALOR' AND NVL(val_area.mov_mes,0) = 0 )))
     ORDER BY val_area.livro
             ,val_area.periodo
             ,val_area.area
             ,val_area.u_produtiva
             ,val_area.c_custo
             ,val_area.conta
             ,val_area.grupo
             ,val_area.mov_mes;
  -- ----------------------------------------------------------------------------- --
  -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020                            --
  -- O cursor abaixo foi originalmente criado para a Procedure ENVIAR_RATEIO_GL_P, --
  -- porem o mesmo sera  usado tambem na nova  procedure REL_PREVIA_RATEIO_GL_P,   --
  -- sendo convertido em um cursor global para reaproveitamento de codigo.         --
  -- ----------------------------------------------------------------------------- --   
  /*CURSOR c_global_gl ( pc_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                      ,pc_periodo   bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                      ,pc_area      bolinf.xx_opm_calc_rateio.area_calculo%TYPE ) IS
    SELECT calc.ledger_id                     --> LEDGER_ID
          ,calc.livro
          ,'BRL' currency_code                --> CURRENCY_CODE
          ,gl_bsv.segment_value companhia     --> SEGMENT1
          ,crc.conta                          --> SEGMENT2 Enviar ESSA Conta para o GL!
          ,cgr.u_negocios                     --> SEGMENT3
          ,calc.produto_calculo               --> SEGMENT4
          ,calc.u_produtiva_calculo           --> SEGMENT5
          ,calc.cc_calculo                    --> SEGMENT6
          ,calc.projeto_calculo               --> SEGMENT7
          ,CASE
             WHEN SUM(calc.rateio) < 0 THEN
               ABS(SUM(calc.rateio))
           END entered_cr                     --> ENTERED_CR
          ,CASE
            WHEN SUM(calc.rateio) > 0 THEN
              ABS(SUM(calc.rateio))
           END entered_dr                     --> ENTERED_DR
          --
          -- O EBS arredonda das colunas "ACCOUNTED_" ao contabilizar, para evitar
          -- qualquer problema de arredondamento, deixaremos esses campos ja
          -- arredondados com duas casas decimais "ROUND(valor,2)" no envio para a GL_INTERFACE.
          ,CASE
             WHEN SUM(calc.rateio) < 0 THEN
               ROUND(ABS(SUM(calc.rateio)),2)
           END accounted_cr                   --> ACCOUNTED_CR
          ,CASE
            WHEN SUM(calc.rateio) > 0 THEN
              ROUND(ABS(SUM(calc.rateio)),2)
           END accounted_dr                   --> ACCOUNTED_DR
          ,calc.periodo                       --> PERIOD_NAME
          ,gps.end_date accounting_date
          ,cgc.grupo_conta
          ,cgr.grupo
          ,calc.tipo
          ,crc.origem
          -- RATEIO DE CUSTO: (RH)-21201-1203-000-000000 PARA 21603-3121-000-000000 - VALOR: R$ 5.000,00 - INDICE: 5,67% - (MAI-19)
          -- RETIRAR ORIGINAL E RECEBENDO, MANTER APENAS O "ENVIANDO"
          -- RETIRAR VALOR E INDICE DA MSG abaixo para nao impactar o agrupamento
          ,'RATEIO DE CUSTO: ('|| calc.etapa             ||')-'||
                              calc.u_produtiva_enviando  ||'-'||
                              calc.cc_enviando           ||'-'||
                              calc.produto_enviando      ||'-'||
                              calc.projeto_enviando      ||' '||
                              '('||calc.periodo||')' desc_linha -- DESCRIPTION
          ,calc.etapa
      FROM bolinf.xx_opm_calc_rateio        calc -- Tabela de Calculos
          ,bolinf.xx_opm_cta_x_grp_cta      cgc  -- Conta vs Grupo Conta
          ,bolinf.xx_opm_cc_grupo_rateio    cgr  -- Centro de Custos vs Grupo
          ,bolinf.xx_opm_cta_redutora_custo crc  -- Conta vs Grupo
          ,apps.gl_ledger_le_bsv_specific_v gl_bsv
          ,apps.gl_period_statuses          gps
     WHERE calc.conta_calculo = cgc.conta
       AND calc.cc_calculo    = cgr.centro_custo
       AND cgc.grupo_conta    = crc.grupo_conta
       AND cgr.grupo          = crc.grupo
       AND calc.tipo          = crc.origem -- ENVIADO/RECEBIDO
       AND calc.ledger_id     = gl_bsv.ledger_id
       --
       -- JOIN com livro para recuperar a data final do periodo e enviar para GL_INTERFACE,
       -- o ACCOUNTING_DATE deve ser uma data dentro do periodo que esta sendo processado.
       AND calc.ledger_id     = gps.ledger_id
       AND calc.periodo       = gps.period_name
       AND gps.application_id = 101 \* Fixo General Ledger *\
       AND gps.closing_status = 'O' \* Fixo somente periodos Open *\
       --
       AND calc.tipo          IN ('ENVIADO','RECEBIDO')
       AND calc.ledger_id     = pc_ledger_id
       AND calc.periodo       = pc_periodo
       -- ---------------------------------------------------------------- --
       -- Nao confundir o parametro PC_AREA com o campo AREA_CALCULO, pois --
       -- este campo eh derivado dos calculos e nao representa as ETAPAS.  --
       -- Apesar do nome, o parametro PC_AREA devera filtrar as etapas!    --
       -- Ex.: se o parametro P_AREA do concurrent for 'RH', entao devera  --
       --      filtrar os registros das etapas RH-21603 e RH, se for 'IND' --
       --      devera selecionar os registros de IND-21603 e IND.          --
       -- ---------------------------------------------------------------- --
       AND (pc_area IS NULL OR ((pc_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                (pc_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                (calc.etapa = pc_area)))
       AND NVL(calc.enviado_gl_interface,'N') = 'N'
     GROUP BY calc.ledger_id
             ,calc.livro
             ,gl_bsv.segment_value
             ,crc.conta
             ,cgr.u_negocios
             ,calc.produto_calculo
             ,calc.u_produtiva_calculo
             ,calc.cc_calculo
             ,calc.projeto_calculo
             ,calc.periodo
             ,gps.end_date
             ,cgc.grupo_conta
             ,cgr.grupo
             ,calc.tipo
             ,crc.origem
             ,calc.u_produtiva_enviando
             ,calc.cc_enviando
             ,calc.produto_enviando
             ,calc.projeto_enviando
             ,calc.etapa;*/
  --
  PROCEDURE main_p
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_etapa       bolinf.xx_opm_calc_rateio.etapa%TYPE
     ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE
     ,p_mov_mes     VARCHAR2);
  --
  PROCEDURE rh_ind_21603_orig_p
    ( p_errbuf    OUT VARCHAR2
     ,p_retcode   OUT NUMBER
     ,p_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo   bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_etapa     bolinf.xx_opm_calc_rateio.etapa%TYPE);
  --
  PROCEDURE transit_rh_ind_p
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   IN bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     IN bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_area        IN bolinf.xx_opm_calc_rateio.area_calculo%TYPE
     ,p_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE
     ,p_u_produtiva IN bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE);
  --
  PROCEDURE transit_p
    ( p_errbuf  OUT VARCHAR2
     ,p_retcode OUT NUMBER
     ,p_ledger_id   IN  bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     IN  bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_area        IN  bolinf.xx_opm_calc_rateio.area_calculo%TYPE
     --,p_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE
     );
  --
  PROCEDURE etp_ant_ind_21603_p
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE
     ,p_etapa       bolinf.xx_opm_calc_rateio.etapa%TYPE
     ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE );
  --
  PROCEDURE log_p ( p_msg IN VARCHAR2 );
  --
  PROCEDURE print_p ( p_msg IN VARCHAR2 );
  --
  PROCEDURE rel_rateio_sintet_p
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE
     ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_original%TYPE
     ,p_c_custo     bolinf.xx_opm_calc_rateio.cc_original%TYPE );
  --
  PROCEDURE rel_rateio_analit_p
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE
     ,p_tipo        bolinf.xx_opm_calc_rateio.tipo%TYPE
     ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_original%TYPE
     ,p_c_custo     bolinf.xx_opm_calc_rateio.cc_original%TYPE );
  --
  PROCEDURE enviar_rateio_gl_p
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE 
     ,p_enviar_gl   VARCHAR2 DEFAULT 'N' ); -- S/N
  --
  FUNCTION etapa_processada_f
    ( p_errbuf      OUT VARCHAR2
     ,p_retcode     OUT NUMBER
     ,p_ledger_id   IN bolinf.xx_opm_calc_rateio.ledger_id%TYPE
     ,p_periodo     IN bolinf.xx_opm_calc_rateio.periodo%TYPE
     ,p_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE ) RETURN VARCHAR2; -- S/N (Sim/Nao)
  --
  FUNCTION desc_livro_f
    ( p_errbuf    OUT VARCHAR2
     ,p_retcode   OUT NUMBER
     ,p_ledger_id apps.gl_ledgers.ledger_id%TYPE ) RETURN VARCHAR2;
  -- -------------------------------------------------- --
  -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020 --
  -- -------------------------------------------------- --
  /*PROCEDURE rel_previa_rateio_gl_p ( p_errbuf    OUT VARCHAR2
                                    ,p_retcode   OUT NUMBER
                                    ,p_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                    ,p_periodo   bolinf.xx_opm_calc_rateio.periodo%TYPE
                                    ,p_area      bolinf.xx_opm_calc_rateio.area_calculo%TYPE );*/     
END xx_opm_rateio_pkg;
/


  CREATE OR REPLACE PACKAGE BODY "APPS"."XX_OPM_RATEIO_PKG" IS
--
-- $Header: %f% %v% %d% %u% ship $
-- $Id: XX_OPM_RATEIO_PKG.txt 120.1 2019-06-11 12:00:00 rsnunes $
-- +=====================================================================+
-- |         Copyright (c) 2019 Ninecon, Sao Paulo , Brasil              |
-- |                         All rights reserved.                        |
-- +=====================================================================+
-- | FILENAME                                                            |
-- |   XX_OPM_RATEIOB_PKG.txt                                            |
-- |                                                                     |
-- | PURPOSE                                                             |
-- |   Oracle Applications Rel 12.2.6                                    |
-- |   Produto.: Oracle                                                  |
-- |   #53400# R11 - #727# R12 - Projeto Rateio de Custos indiretos      |
-- |   Objetivo: Projeto de automatizacao do processo de alocacao de     |
-- |             despesas indiretas nos centros de custos de apoios.     |
-- |                                                                     |
-- | DESCRIPTION                                                         |
-- |    Para esse desenvolvimento estaremos utilizando os dados do balan-|
-- |    cete (movimento do mes, debito menos credito) as contas do grupo |
-- |    de despesas (5XXXXX), criaremos  um portal  para  as areas (AGR, |
-- |    AGR-EQ, IND e RH),  informar  os  dados  referente  aos  indices |
-- |    utilizados para o rateio. A customizacao preve integracao  com a |
-- |    contabilidade  gerando os  lancamentos de  reclassificacoes  das |
-- |    despesas por fases (areas),  visando zerar os valores existentes |
-- |    nos centro de custos de apoio.  Contempla rotina de  verificacao |
-- |    se existem lancamentos em  contas contabeis ou  centro  de custo |
-- |    nao  cadastrados  nas  tabelas  customizadas. Todas as fases das |
-- |    rotinas devem ser passiveis de conferencia  antes da  integracao |
-- |    com a contabilidade,  isso deve ocorrer atraves de  relatorio de |
-- |    apoio a ser desenhado nesse projeto.  O resultado do processo de |
-- |    realocacao no  seu final deve apresentar saldo zerado nos centro |
-- |    de custo de apoio, isso demonstrara o sucesso do processo.       |
-- |                                                                     |
-- | CREATED BY                                                          |
-- |   Rafael S. Nunes (Ninecon)    11/06/2019 ~ 23/10/2019              |
-- |                                                                     |
-- | UPDATED BY                                                          |
-- |   Rafael S. Nunes (Ninecon) -- SD 110926 -- 05/12/2019              |
-- |     Correcoes diversas na procedure ETP_ANT_IND_21603_P.            |
-- |     Alterado os  percentuais 100% e 50% para o padrao dos arquivos  |
-- |     de indices ficando entao representados por 1 e 0.5,  respecti-  |
-- |     vamente.                                                        |
-- |                                                                     |
-- |   Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020                | 
-- |     Inclusao do parametro P_ENVIAR_GL na procedure                  |
-- |     ENVIAR_RATEIO_GL_P, para que o usuario tenha a opcao de apenas  |
-- |     imprimir o relatorio para conferencia antes de enviar definiti- |
-- |     vamente os dados para a interface do GL.                        |
-- |                                                                     |
-- |     O nome do concurrent que dispara este procedimento foi alterado |
-- |     de  "XX OPM Enviar Rateio de Custos para Interface do GL"  para |
-- |     "XX OPM Lancamentos do Rateio de Custos para o GL"  para  ficar |
-- |     mais abrangente com sua nova finalidade.                        |
-- |                                                                     |
-- +=====================================================================+
--
  PROCEDURE main_p ( p_errbuf      OUT VARCHAR2
                    ,p_retcode     OUT NUMBER
                    ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                    ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
                    ,p_etapa       bolinf.xx_opm_calc_rateio.etapa%TYPE
                    ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE
                    ,p_mov_mes     VARCHAR2 ) IS -- TODOS, COM VALOR, SEM VALOR
    CURSOR c_1 ( pc_ledger_id bolinf.xx_gl_resum_val_area_v.ledger_id%TYPE
                ,pc_periodo   bolinf.xx_gl_resum_val_area_v.periodo%TYPE ) IS
      -- ------------------------------------------------------------ --
      -- Cursor para imprimir em log os registros que nao tenham      --
      -- indices cadastrados na tabela BOLINF.XX_OPM_PERC_RAT_DEPART. --
      -- ------------------------------------------------------------ --
      SELECT val_area.ledger_id
            ,val_area.livro
            ,val_area.periodo
            ,val_area.area
            ,val_area.etapa
            ,val_area.u_produtiva_original
            ,val_area.u_produtiva
            ,val_area.produto
            ,val_area.projeto
            ,val_area.c_custo
            ,val_area.conta
            ,val_area.grupo
            ,val_area.grupo_conta
            ,val_area.moeda
            ,val_area.mov_mes
            ,val_area.indice_cadastrado
        FROM bolinf.xx_gl_resum_val_area_v val_area
       WHERE val_area.ledger_id = pc_ledger_id
         AND val_area.periodo   = pc_periodo
         AND val_area.etapa     IN ('RH','RH-21603','AGR-EQ','AGR','IND-21603','IND')
         AND NVL(val_area.mov_mes,0) <> 0
         AND val_area.indice_cadastrado = 'NAO'
       ORDER BY val_area.livro
               ,val_area.periodo
               ,val_area.area
               ,val_area.u_produtiva
               ,val_area.c_custo
               ,val_area.conta
               ,val_area.grupo
               ,val_area.mov_mes;
    --
    l_vU_produtiva    bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE;
    l_nSem_Indice     NUMBER;
    l_nCt_Del         NUMBER;
    l_nCt             NUMBER;
  BEGIN
    -- ------------------------------------------------------------- --
    -- ATENCAO:                                                      --
    -- Devera ser configurada  a Incompatibilidade para o concurrent --
    -- 'XX OPM Rateio de Custos' com ele proprio para que nao ocorra --
    -- execucoes paralelas.                                          --
    -- ------------------------------------------------------------- --
    dbms_output.enable(1000000);
    g_nUser_id  := APPS.FND_GLOBAL.USER_ID;
    g_nLogin_id := APPS.FND_GLOBAL.LOGIN_ID;
    l_vU_produtiva := p_u_produtiva; -- Variavel sera trabalhada abaixo no codigo para as etapas RH-21603 e IND-21603
    l_nSem_Indice  := 0;
    l_nCt_Del      := 0;
    l_nCt          := 0;
    -- --------------------------------------------------------- --
    -- Verifica se a execucao esta sendo  feita pelo conjunto de --
    -- solicitacoes 'XX OPM Rateio de Custos (Todas as Etapas)'. --
    -- --------------------------------------------------------- --
    BEGIN
      SELECT COUNT(1)
        INTO l_nCt
        FROM apps.fnd_concurrent_requests req
            ,apps.fnd_request_sets_vl     rset
       WHERE req.argument1         = TO_CHAR(rset.application_id)
         AND req.argument2         = TO_CHAR(rset.request_set_id)
         AND req.responsibility_id = FND_GLOBAL.RESP_ID -- por responsabilidade
         AND req.phase_code        IN ('P','R') -- Pendente ou em execucao
         AND req.is_sub_request    = 'N'        -- Solicitacao filho = Nao
         AND rset.request_set_name = 'XX_OPM_RATEIO_TOTAL';
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'ERRO: Ao verificar execucao do conjunto de solicitacoes XX OPM Rateio de Custos (Todas as Etapas) - XX_OPM_RATEIO_TOTAL - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20010, p_errbuf);
    END;
    -- ------------------------------------------------------------------------------------------------- --
    -- 10012 - BR ANGELICA HISTORICO                                                                     --
    -- Se a execucao for pelo conjunto de solicitacoes 'XX OPM Rateio de Custos (Todas as Etapas)',      --
    -- entao devera ignorar e sair do concurrent sem forcar nenhum erro, para que seja possivel disparar --
    -- a proxima etapa pelo conjunto.                                                                    --
    -- ----------------------------------------------------------------------------------------------------
    IF l_nCt > 0 AND p_ledger_id <> 10012 AND p_etapa IN ('RH-21603','IND-21603') THEN
      log_p (' ');
      log_p ('*****************************************************************************');
      log_p ('AVISO: O livro ' || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id ) || ' nao processa a etapa ' || p_etapa);
      log_p ('       e sera ignorada neste conjunto de solicitacoes.') ;
      log_p ('*****************************************************************************');
      log_p (' ');
      RETURN;
    -- ------------------------------------------------------------------------------------------------- --
    -- Se a execucao for individual, entao termina o concurrent com erro (vermelho) e aborta o processo. --
    -- ------------------------------------------------------------------------------------------------- --
    ELSIF p_ledger_id <> 10012 AND p_etapa IN ('RH-21603','IND-21603') THEN
      p_retcode := -2;
      p_errbuf  := 'ERRO: Etapa ' || p_etapa || ' invalida para o Livro: ' || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id );
      RAISE_APPLICATION_ERROR(-20010, p_errbuf);
    END IF;
    --
    log_p ( 'Parametros:'      ||CHR(13)||
            'P_LEDGER_ID...: ' || p_ledger_id   ||CHR(13)||
            'LIVRO.........: ' || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id ) ||CHR(13)||
            'P_PERIODO.....: ' || p_periodo     ||CHR(13)||
            'P_ETAPA.......: ' || p_etapa       ||CHR(13)||
            'P_U_PRODUTIVA.: ' || p_u_produtiva ||CHR(13)||
            'P_MOV_MES.....: ' || p_mov_mes     ||CHR(13)||
            '--');
    -- ------------------------------------------------------------------------------------- --
    -- Se a etapa ja tiver sido processada antes, ela sera excluida e recalculada, as etapas --
    -- seguintes tambem serao excluidas e deverao serem reprocessadas pela area responsavel. --
    -- Etapa:      | Etapas seguintes:                                                       --
    -- ------------------------------------------------------------------------------------- --
    -- 1.RH-21603  | 2.RH, 3.AGR-EQ, 4.AGR, 5.IND-21063 e 6.IND                              --
    -- 2.RH        | 3.AGR-EQ, 4.AGR, 5.IND-21063 e 6.IND                                    --
    -- 3.AGR-EQ    | 4.AGR, 5.IND-21063 e 6.IND                                              --
    -- 4.AGR       | 5.IND-21063                                                             --
    -- 5.IND-21063 | 6.IND                                                                   --
    -- 6.IND       | Nao se aplica                                                           --
    -- ------------------------------------------------------------------------------------- --
    IF etapa_processada_f ( p_errbuf      => p_errbuf
                           ,p_retcode     => p_retcode
                           ,p_ledger_id   => p_ledger_id
                           ,p_periodo     => p_periodo
                           ,p_etapa       => p_etapa ) = 'S' THEN -- Sim/Nao
      BEGIN
        -- Nao usar U_PRODUTIVA na chave, pois este campo vai mudando durante o calculo das etapas.
        DELETE
          FROM bolinf.xx_opm_calc_rateio calc
         WHERE calc.ledger_id = p_ledger_id
           AND calc.periodo   = p_periodo
           AND (
                (p_etapa = 'RH-21603'  AND calc.etapa IN ('RH-21603','RH','AGR-EQ','AGR','IND-21603','IND')) OR
                (p_etapa = 'RH'        AND calc.etapa IN ('RH','AGR-EQ','AGR','IND-21603','IND')) OR
                (p_etapa = 'AGR-EQ'    AND calc.etapa IN ('AGR-EQ','AGR','IND-21603','IND')) OR
                (p_etapa = 'AGR'       AND calc.etapa IN ('AGR','IND-21603','IND')) OR
                (p_etapa = 'IND-21603' AND calc.etapa IN ('IND-21603','IND')) OR
                (p_etapa = 'IND'       AND calc.etapa = p_etapa)
               );
        --
        l_nCt_Del := SQL%ROWCOUNT;
        IF l_nCt_Del > 0 THEN
          log_p ('Foram excluidos ' || l_nCt_Del || ' registros da tabela de calculos.');
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO: Ao excluir etapa ' || p_etapa  || ' para efetuar novo calculo! - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20020, p_errbuf);
      END;
    END IF;
    -- --------------------------------------------------------------------- --
    -- Cursor para verificar  e imprimir  no log lancamentos  que nao tenham --
    -- indice de Rateio cadastrado. O processo devera ser abortado se houver --
    -- qualquer lancamento sem indice cadastrado, em qualquer etapa!         --
    -- --------------------------------------------------------------------- --
    FOR r_1 IN c_1 ( pc_ledger_id => p_ledger_id
                    ,pc_periodo   => p_periodo ) LOOP
      IF l_nSem_Indice = 0 THEN
        log_p (' ');
        log_p ('Indices nao encontrados para os lancamentos abaixo:');
        log_p ('---------------------------------------------------');
        log_p ('Livro                           Periodo  Area  U. Produtiva  Produto  C. Custo  Projeto   Conta  Grupo  Grupo Conta                               Mov. Mes  Ind. Cadastrado?');
      END IF;
      log_p ( RPAD(r_1.livro,30,' ')       || '  ' ||
              RPAD(r_1.periodo,7,' ')      || '  ' ||
              RPAD(r_1.area,4,' ')         || '  ' ||
              LPAD(r_1.u_produtiva,12,' ') || '  ' ||
              LPAD(r_1.produto,7,' ')      || '  ' ||
              LPAD(r_1.c_custo,8,' ')      || '  ' ||
              LPAD(NVL(r_1.projeto,' '),7,' ') || '  ' ||
              r_1.conta                        || '  ' ||
              LPAD(r_1.grupo,5,' ')            || '  ' ||
              RPAD(r_1.grupo_conta,38,' ') || '  ' ||
              LPAD(r_1.mov_mes,10,' ')     || '  ' ||
              r_1.indice_cadastrado);
      l_nSem_Indice := l_nSem_Indice + 1;
    END LOOP;
    --
    IF l_nSem_Indice > 0 THEN
      p_retcode := -2;
      p_errbuf  := 'ERRO: Indices nao encontrados!';
      RAISE_APPLICATION_ERROR(-20030, p_errbuf);
    END IF;
    --
    IF p_etapa IN ('RH-21603','IND-21603') AND p_ledger_id = 10012 THEN
      IF NVL(p_u_produtiva,'21603') <> '21603' THEN
        p_retcode := -2;
        p_errbuf  := 'ERRO: A Unidade Produtiva da etapa ' || p_etapa  || ' deve ser 21603!';
        RAISE_APPLICATION_ERROR(-20040, p_errbuf);
      ELSE
        IF p_u_produtiva IS NULL THEN
          l_vU_produtiva := '21603'; -- Valor padrao para as etapas RH-21603 e IND-21603, caso venha nulo do concurrent.
        END IF;
        -- -------------------------------------------------------------------------- --
        -- Processar valores originais das etapas RH-21603 e IND-21603 (mesma regra). --
        -- Obs.: Estas estapas sao aplicaveis apenas ao livro BR ANGELICA HISTORICO.  --
        -- -------------------------------------------------------------------------- --
        rh_ind_21603_orig_p ( p_errbuf    => p_errbuf
                             ,p_retcode   => p_retcode
                             ,p_ledger_id => p_ledger_id
                             ,p_periodo   => p_periodo
                             ,p_etapa     => p_etapa );
        -- ------------------------------------------------------------------ --
        -- Regra exclusiva para a etapa IND-21603:                            --
        -- Diferentemente da etapa RH-21603, apos calcular seu valor original --
        -- para a etapa IND-21603, devera ser calculado o rateio dos valores  --
        -- recebidos anteriormente na Area Calculo IND.                       --
        -- ------------------------------------------------------------------ --
        IF p_etapa = 'IND-21603' THEN
          etp_ant_ind_21603_p ( p_errbuf      => p_errbuf
                               ,p_retcode     => p_retcode
                               ,p_ledger_id   => p_ledger_id
                               ,p_periodo     => p_periodo
                               ,p_u_produtiva => l_vU_produtiva -- p_u_produtiva
                               ,p_etapa       => p_etapa  -- Etapa atual IND-21603
                               ,p_area        => 'IND' ); -- Area: IND
        END IF;
      END IF;
    ELSIF p_etapa IN ('RH','AGR','AGR-EQ','IND') THEN
      -- ------------------------------------------------------------------------------------- --
      -- Insere os valores ORIGINAIS das demais etapas na tabela de Calculos e na Transitoria. --
      -- ------------------------------------------------------------------------------------- --
      g_nCalc_Ct := 0;
      BEGIN
        INSERT
          INTO bolinf.xx_opm_calc_rateio ( calc_rateio_id             -- 1
                                          ,etapa                      -- 2
                                          ,periodo                    -- 3
                                          ,ledger_id                  -- 4
                                          ,livro                      -- 5
                                          --
                                          ,u_produtiva_enviando       -- 6
                                          ,produto_enviando           -- 7
                                          ,cc_enviando                -- 8
                                          ,projeto_enviando           -- 9
                                          --
                                          ,u_produtiva_recebendo      -- 10
                                          ,produto_recebendo          -- 11
                                          ,cc_recebendo               -- 12
                                          ,projeto_recebendo          -- 13
                                          --
                                          ,u_produtiva_original       -- 14
                                          ,produto_original           -- 15
                                          ,cc_original                -- 16
                                          ,projeto_original           -- 17
                                          --
                                          ,u_produtiva_calculo        -- 18
                                          ,produto_calculo            -- 19
                                          ,cc_calculo                 -- 20
                                          ,projeto_calculo            -- 21
                                          --
                                          ,area_calculo               -- 22
                                          ,conta_calculo              -- 23
                                          ,valor                      -- 24
                                          ,indice                     -- 25
                                          ,rateio                     -- 26
                                          ,tipo                       -- 27
                                          ,creation_date              -- 28
                                          ,created_by                 -- 29
                                          ,last_update_login )        -- 30
                                    --
                                    -- O Oracle nao permite usar sequence em select com Group By, entao foi necessario criar um subselect.
                                    --
                                    SELECT bolinf.xx_opm_calc_rateio_s.NEXTVAL -- 1
                                          ,s.area                      -- 2
                                          ,s.periodo                   -- 3
                                          ,s.ledger_id                 -- 4
                                          ,s.livro                     -- 5
                                          --
                                          ,s.u_produtiva               -- 6
                                          ,s.produto 	                 -- 7
                                          ,s.c_custo                   -- 8
                                          ,s.projeto                   -- 9
                                          --
                                          ,s.u_produtiva               -- 10
                                          ,s.produto                   -- 11
                                          ,s.c_custo                   -- 12
                                          ,s.projeto                   -- 13
                                          --
                                          ,s.u_produtiva               -- 14
                                          ,s.produto                   -- 15
                                          ,s.c_custo                   -- 16
                                          ,s.projeto                   -- 17
                                          --
                                          ,s.u_produtiva               -- 18
                                          ,s.produto	                 -- 19
                                          ,s.c_custo                   -- 20
                                          ,s.projeto                   -- 21
                                          --
                                          ,s.area                      -- 22
                                          ,s.conta                     -- 23
                                          ,s.mov_mes                   -- 24
                                          ,s.indice                    -- 25
                                          ,s.mov_mes                   -- 26
                                          ,s.tipo                      -- 27
                                          ,s.creation_date             -- 28
                                          ,s.created_by                -- 29
                                          ,s.last_update_login         -- 30
                                     FROM ( SELECT val_area.area
                                                  ,val_area.periodo
                                                  ,val_area.ledger_id
                                                  ,val_area.livro
                                                  ,val_area.u_produtiva
                                                  ,val_area.produto
                                                  ,val_area.c_custo
                                                  ,val_area.projeto
                                                  ,val_area.conta
                                                  ,val_area.mov_mes
                                                  --,100                AS indice
                                                  ,1                  AS indice -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                                                  ,'GASTOS ORIGINAIS' AS tipo
                                                  ,SYSDATE            AS creation_date
                                                  ,g_nUser_id         AS created_by
                                                  ,g_nLogin_id        AS last_update_login
                                              FROM bolinf.xx_gl_resum_val_area_v       val_area
                                             WHERE val_area.ledger_id   = p_ledger_id
                                               AND val_area.periodo     = p_periodo
                                               AND val_area.etapa       = p_etapa
                                               AND val_area.indice_cadastrado = 'SIM'
                                               AND (p_u_produtiva IS NULL OR val_area.u_produtiva = p_u_produtiva)
                                               AND (p_mov_mes = 'TODOS' OR ((p_mov_mes = 'COM VALOR' AND NVL(val_area.mov_mes,0) <> 0) OR
                                                                            (p_mov_mes = 'SEM VALOR' AND NVL(val_area.mov_mes,0) = 0 )))
                                             ORDER BY val_area.livro
                                                     ,val_area.periodo
                                                     ,val_area.area
                                                     ,val_area.u_produtiva
                                                     ,val_area.c_custo
                                                     ,val_area.conta
                                                     ,val_area.grupo
                                                     ,val_area.mov_mes ) s;
        g_nCalc_Ct := g_nCalc_Ct + SQL%ROWCOUNT;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir rateio do registro de Gastos Originais na tabela BOLINF.XX_OPM_CALC_RATEIO, procedimento BOLINF.XX_OPM_RATEIO_PKG.MAIN_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20100, p_errbuf);
      END;
      --
      g_nIteracao := 0;
      DELETE FROM bolinf.xx_opm_rateio_transitoria; -- Limpa a tabela transitoria antes das insercoes
      BEGIN
        INSERT
          INTO bolinf.xx_opm_rateio_transitoria ( ledger_id            -- 1
                                                 ,livro                -- 2
                                                 ,periodo              -- 3
                                                 ,u_produtiva_original -- 4
                                                 ,cc_original	         -- 5
                                                 ,projeto_original     -- 6
                                                 ,produto_original     -- 7
                                                 --
                                                 ,area_calculo	       -- 8
                                                 ,u_produtiva_calculo	 -- 9
                                                 ,produto_calculo      -- 10
                                                 ,cc_calculo	         -- 11
                                                 ,projeto_calculo      -- 12
                                                 ,conta_calculo	       -- 13
                                                 --
                                                 ,valor                -- 14
                                                 ,indice               -- 15
                                                 ,rateio               -- 16
                                                 ,iteracao )           -- 17
                                           SELECT calc.ledger_id             -- 1
                                                 ,calc.livro                 -- 2
                                                 ,calc.periodo               -- 3
                                                 ,calc.u_produtiva_original  -- 4
                                                 ,calc.cc_original           -- 5
                                                 ,calc.projeto_original      -- 6
                                                 ,calc.produto_original      -- 7
                                                 --
                                                 ,calc.area_calculo          -- 8
                                                 ,calc.u_produtiva_calculo   -- 9
                                                 ,calc.produto_calculo       -- 10
                                                 ,calc.cc_calculo            -- 11
                                                 ,calc.projeto_calculo       -- 12
                                                 ,calc.conta_calculo         -- 13
                                                 ,SUM(calc.valor)  AS valor  -- 14
                                                 ,calc.indice                -- 15
                                                 ,SUM(calc.rateio) AS rateio -- 16
                                                 ,g_nIteracao                -- 17
                                             FROM bolinf.xx_opm_calc_rateio calc
                                            WHERE calc.ledger_id    = p_ledger_id
                                              AND calc.periodo      = p_periodo
                                              --AND calc.etapa       = p_etapa
                                              --AND val_area.etapa       IN ('RH','AGR-EQ','AGR','IND')

                                              AND calc.AREA_CALCULO = p_etapa

                                              AND (p_u_produtiva IS NULL OR calc.u_produtiva_original = p_u_produtiva)
                                              --AND (p_mov_mes = 'TODOS' OR ((p_mov_mes = 'COM VALOR' AND NVL(calc.valor,0) <> 0) OR
                                              --                             (p_mov_mes = 'SEM VALOR' AND NVL(calc.valor,0) = 0 )))
                                              AND NVL(calc.enviado_gl_interface,'N') = 'N' -- Rafael -- 09/09/2019
                                           HAVING SUM(calc.valor) <> 0

                                            GROUP BY calc.ledger_id
                                                    ,calc.livro
                                                    ,calc.periodo
                                                    ,calc.u_produtiva_original
                                                    ,calc.cc_original
                                                    ,calc.projeto_original
                                                    ,calc.produto_original
                                                    --
                                                    ,calc.area_calculo
                                                    ,calc.u_produtiva_calculo
                                                    ,calc.produto_calculo
                                                    ,calc.cc_calculo
                                                    ,calc.projeto_calculo
                                                    ,calc.conta_calculo
                                                    ,calc.valor
                                                    ,calc.indice
                                                    ,calc.rateio;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir registro de Gastos Originais na tabela BOLINF.XX_OPM_RATEIO_TRANSITORIA, procedimento BOLINF.XX_OPM_RATEIO_PKG.MAIN_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20110, p_errbuf);
      END;
    END IF;
    --
    IF p_etapa IN ('RH','IND') THEN
      transit_rh_ind_p ( p_errbuf    => p_errbuf
                        ,p_retcode   => p_retcode
                        ,p_ledger_id => p_ledger_id
                        ,p_periodo   => p_periodo
                        ,p_area      => p_etapa
                        ,p_etapa     => p_etapa
                        ,p_u_produtiva => p_u_produtiva );
    --
    ELSIF p_etapa IN ('AGR-EQ','AGR') THEN
      transit_p ( p_errbuf    => p_errbuf
                 ,p_retcode   => p_retcode
                 ,p_ledger_id => p_ledger_id
                 ,p_periodo   => p_periodo
                 ,p_area      => p_etapa );
    END IF;
    log_p ( 'Registros inseridos na tabela de calculo: ' || g_nCalc_Ct );
  END main_p;
  -- --------------------------------- --
  -- Fases 1.RH-21603 e 5.IND-2603     --
  --    1.RH e Unid. Produtiva 21603   --
  --    5.IND e Unid. Produtiva 21603  --
  -- --------------------------------- --
  PROCEDURE rh_ind_21603_orig_p ( p_errbuf    OUT VARCHAR2
                                 ,p_retcode   OUT NUMBER
                                 ,p_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                 ,p_periodo   bolinf.xx_opm_calc_rateio.periodo%TYPE
                                 ,p_etapa     bolinf.xx_opm_calc_rateio.etapa%TYPE ) IS
    --
    CURSOR c_1 ( pc_ledger_id   IN bolinf.xx_gl_resum_val_area_v.ledger_id%TYPE
                ,pc_periodo     IN bolinf.xx_gl_resum_val_area_v.periodo%TYPE
                ,pc_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE ) IS
      SELECT slc.etapa
            ,slc.periodo
            ,slc.ledger_id
            ,slc.livro
            --
            ,slc.u_produtiva_enviando
            ,slc.produto_enviando
            ,slc.cc_enviando
            ,slc.projeto_enviando
            --
            ,slc.u_produtiva_recebendo
            ,slc.produto_recebendo
            ,slc.cc_recebendo
            ,slc.projeto_recebendo
            --
            ,slc.u_produtiva_original
            ,slc.produto_original
            ,slc.cc_original
            ,slc.projeto_original
            --
            ,slc.area_calculo
            ,slc.u_produtiva_calculo
            ,slc.produto_calculo
            ,slc.cc_calculo
            ,slc.projeto_calculo
            ,slc.conta_calculo
            --
            ,slc.valor
            ,slc.indice
            ,slc.rateio
            ,slc.tipo
            ,slc.seq
            ,slc.segment1
            ,slc.segment3
            ,slc.segment4
            ,slc.segment8
        FROM (
              SELECT aloc_d.etapa                AS etapa -- Ex: RH-21603
                    ,aloc_d.u_produtiva          AS u_produtiva_enviando
                    ,aloc_d.produto              AS produto_enviando
                    ,aloc_d.c_custo              AS cc_enviando
                    ,aloc_d.projeto              AS projeto_enviando
                    --
                    ,aloc_d.u_produtiva          AS u_produtiva_recebendo
                    ,aloc_d.produto              AS produto_recebendo
                    ,aloc_d.c_custo              AS cc_recebendo
                    ,aloc_d.projeto              AS projeto_recebendo
                    --
                    ,aloc_d.u_produtiva          AS u_produtiva_original
                    ,aloc_d.produto              AS produto_original
                    ,aloc_d.c_custo              AS cc_original
                    ,aloc_d.projeto              AS projeto_original
                    --
                    ,aloc_d.area                 AS area_calculo
                    ,aloc_d.u_produtiva          AS u_produtiva_calculo
                    ,aloc_d.produto              AS produto_calculo
                    ,aloc_d.c_custo              AS cc_calculo
                    ,aloc_d.projeto              AS projeto_calculo
                    ,aloc_d.conta                AS conta_calculo
                    --
                    ,aloc_d.net_month            AS valor
                    --,100                         AS indice
                    ,1                           AS indice -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                    ,aloc_d.net_month            AS rateio  -- ***
                    ,'GASTOS ORIGINAIS'          AS tipo
                    ,1                           AS seq
                    --
                    ,aloc_d.period_name          AS periodo
                    ,aloc_d.ledger_id            AS ledger_id
                    ,aloc_d.name                 AS livro
                    ,aloc_d.area                 AS area
                    ,aloc_d.u_produtiva          AS und_produtiva
                    ,aloc_d.c_custo              AS c_custo
                    ,aloc_d.conta                AS conta
                    ,aloc_d.segment1             AS segment1
                    ,aloc_d.segment3             AS segment3
                    ,aloc_d.segment4             AS segment4
                    ,aloc_d.segment8             AS segment8
                FROM bolinf.xx_gl_balances_aloc_desp_v aloc_d -- View ja contem o vinculo entre GL_BALANCES e XX_OPM_CC_GRUPO_RATEIO
               WHERE 1=1
               UNION
              SELECT aloc_d.etapa                AS etapa -- Ex: RH-21603
                    ,aloc_d.u_produtiva          AS u_produtiva_enviando
                    ,aloc_d.produto              AS produto_enviando
                    ,aloc_d.c_custo              AS cc_enviando
                    ,aloc_d.projeto              AS projeto_enviando
                    --
                    ,'21201'                     AS u_produtiva_recebendo
                    ,aloc_d.produto              AS produto_recebendo
                    ,aloc_d.c_custo              AS cc_recebendo
                    ,aloc_d.projeto              AS projeto_recebendo
                    --
                    ,aloc_d.u_produtiva          AS u_produtiva_original
                    ,aloc_d.produto              AS produto_original
                    ,aloc_d.c_custo              AS cc_original
                    ,aloc_d.projeto              AS projeto_original
                    --
                    ,aloc_d.area                 AS area_calculo
                    ,aloc_d.u_produtiva          AS u_produtiva_calculo
                    ,aloc_d.produto              AS produto_calculo
                    ,aloc_d.c_custo              AS cc_calculo
                    ,aloc_d.projeto              AS projeto_calculo
                    ,aloc_d.conta                AS conta_calculo
                    --
                    ,aloc_d.net_month            AS valor
                    --,50*-1                       AS indice
                    ,0.5*-1                      AS indice -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                    ,aloc_d.net_month*(50/100)*-1 AS rateio  -- ***
                    ,'ENVIADO'                   AS tipo
                    ,2                           AS seq
                    --
                    ,aloc_d.period_name          AS periodo
                    ,aloc_d.ledger_id            AS ledger_id
                    ,aloc_d.name                 AS livro
                    ,aloc_d.area                 AS area
                    ,aloc_d.u_produtiva          AS und_produtiva
                    ,aloc_d.c_custo              AS c_custo
                    ,aloc_d.conta                AS conta
                    ,aloc_d.segment1             AS segment1
                    ,aloc_d.segment3             AS segment3
                    ,aloc_d.segment4             AS segment4
                    ,aloc_d.segment8             AS segment8
                FROM bolinf.xx_gl_balances_aloc_desp_v aloc_d -- View ja contem o vinculo entre GL_BALANCES e XX_OPM_CC_GRUPO_RATEIO
               UNION
              SELECT aloc_d.etapa                AS etapa -- Ex: RH-21603
                    ,aloc_d.u_produtiva          AS u_produtiva_enviando
                    ,aloc_d.produto              AS produto_enviando
                    ,aloc_d.c_custo              AS cc_enviando
                    ,aloc_d.projeto              AS projeto_enviando
                    --
                    ,'21202'                     AS u_produtiva_recebendo
                    ,aloc_d.produto              AS produto_recebendo
                    ,aloc_d.c_custo              AS cc_recebendo
                    ,aloc_d.projeto              AS projeto_recebendo
                    --
                    ,aloc_d.u_produtiva          AS u_produtiva_original
                    ,aloc_d.produto              AS produto_original
                    ,aloc_d.c_custo              AS cc_original
                    ,aloc_d.projeto              AS projeto_original
                    --
                    ,aloc_d.area                 AS area_calculo
                    ,aloc_d.u_produtiva          AS u_produtiva_calculo
                    ,aloc_d.produto              AS produto_calculo
                    ,aloc_d.c_custo              AS cc_calculo
                    ,aloc_d.projeto              AS projeto_calculo
                    ,aloc_d.conta                AS conta_calculo
                    --
                    ,aloc_d.net_month            AS valor
                    --,50*-1                       AS indice
                    ,0.5*-1                      AS indice -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                    ,aloc_d.net_month*(50/100)*-1 AS rateio  -- ***
                    ,'ENVIADO'                   AS tipo
                    ,3                           AS seq
                    --
                    ,aloc_d.period_name          AS periodo
                    ,aloc_d.ledger_id            AS ledger_id
                    ,aloc_d.name                 AS livro
                    ,aloc_d.area                 AS area
                    ,aloc_d.u_produtiva          AS und_produtiva
                    ,aloc_d.c_custo              AS c_custo
                    ,aloc_d.conta                AS conta
                    ,aloc_d.segment1             AS segment1
                    ,aloc_d.segment3             AS segment3
                    ,aloc_d.segment4             AS segment4
                    ,aloc_d.segment8             AS segment8
                FROM bolinf.xx_gl_balances_aloc_desp_v aloc_d -- View ja contem o vinculo entre GL_BALANCES e XX_OPM_CC_GRUPO_RATEIO
               UNION
              SELECT aloc_d.etapa                AS etapa -- Ex: RH-21603
                    ,aloc_d.u_produtiva          AS u_produtiva_enviando
                    ,aloc_d.produto              AS produto_enviando
                    ,aloc_d.c_custo              AS cc_enviando
                    ,aloc_d.projeto              AS projeto_enviando
                    --
                    ,'21201'                     AS u_produtiva_recebendo -- ***
                    ,aloc_d.produto              AS produto_recebendo
                    ,aloc_d.c_custo              AS cc_recebendo
                    ,aloc_d.projeto              AS projeto_recebendo
                    --
                    ,aloc_d.u_produtiva          AS u_produtiva_original
                    ,aloc_d.produto              AS produto_original
                    ,aloc_d.c_custo              AS cc_original
                    ,aloc_d.projeto              AS projeto_original
                    --
                    ,aloc_d.area                 AS area_calculo
                    ,'21201'                     AS u_produtiva_calculo -- ***
                    ,aloc_d.produto              AS produto_calculo
                    ,aloc_d.c_custo              AS cc_calculo
                    ,aloc_d.projeto              AS projeto_calculo
                    ,aloc_d.conta                AS conta_calculo
                    --
                    -- Nesta etapa os indices sao fixos
                    ,aloc_d.net_month            AS valor
                    --,50                          AS indice  -- ***
                    ,0.5                         AS indice  -- *** -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                    ,aloc_d.net_month*(50/100)   AS rateio  -- ***
                    ,'RECEBIDO'                  AS tipo    -- ***
                    ,4                           AS seq
                    --
                    ,aloc_d.period_name          AS periodo
                    ,aloc_d.ledger_id            AS ledger_id
                    ,aloc_d.name                 AS livro
                    ,aloc_d.area                 AS area
                    ,aloc_d.u_produtiva          AS und_produtiva
                    ,aloc_d.c_custo              AS c_custo
                    ,aloc_d.conta                AS conta
                    ,aloc_d.segment1             AS segment1
                    ,aloc_d.segment3             AS segment3
                    ,aloc_d.segment4             AS segment4
                    ,aloc_d.segment8             AS segment8
                FROM bolinf.xx_gl_balances_aloc_desp_v aloc_d -- View ja contem o vinculo entre GL_BALANCES e XX_OPM_CC_GRUPO_RATEIO
               UNION
              SELECT aloc_d.etapa                AS etapa -- Ex: RH-21603
                    ,aloc_d.u_produtiva          AS u_produtiva_enviando
                    ,aloc_d.produto              AS produto_enviando
                    ,aloc_d.c_custo              AS cc_enviando
                    ,aloc_d.projeto              AS projeto_enviando
                    --
                    ,'21202'                     AS u_produtiva_recebendo -- ***
                    ,aloc_d.produto              AS produto_recebendo
                    ,aloc_d.c_custo              AS cc_recebendo
                    ,aloc_d.projeto              AS projeto_recebendo
                    --
                    ,aloc_d.u_produtiva          AS u_produtiva_original
                    ,aloc_d.produto              AS produto_original
                    ,aloc_d.c_custo              AS cc_original
                    ,aloc_d.projeto              AS projeto_original
                    --
                    ,aloc_d.area                 AS area_calculo
                    ,'21202'                     AS u_produtiva_calculo -- ***
                    ,aloc_d.produto              AS produto_calculo
                    ,aloc_d.c_custo              AS cc_calculo
                    ,aloc_d.projeto              AS projeto_calculo
                    ,aloc_d.conta                AS conta_calculo
                    --
                    -- Nesta etapa os indices sao fixos
                    ,aloc_d.net_month            AS valor
                    --,50                          AS indice  -- ***
                    ,0.5                         AS indice  -- *** -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                    ,aloc_d.net_month*(50/100)   AS rateio  -- ***
                    ,'RECEBIDO'                  AS tipo    -- ***
                    ,5                           AS seq
                    --
                    ,aloc_d.period_name          AS periodo
                    ,aloc_d.ledger_id            AS ledger_id
                    ,aloc_d.name                 AS livro
                    ,aloc_d.area                 AS area
                    ,aloc_d.u_produtiva          AS und_produtiva
                    ,aloc_d.c_custo              AS c_custo
                    ,aloc_d.conta                AS conta
                    ,aloc_d.segment1             AS segment1
                    ,aloc_d.segment3             AS segment3
                    ,aloc_d.segment4             AS segment4
                    ,aloc_d.segment8             AS segment8
                FROM bolinf.xx_gl_balances_aloc_desp_v aloc_d -- View ja contem o vinculo entre GL_BALANCES e XX_OPM_CC_GRUPO_RATEIO
            ) slc
       WHERE 1=1
         AND slc.etapa         = pc_etapa
         AND slc.und_produtiva = '21603' -- Fixo
         AND slc.valor         <> 0      -- Fixo
         AND slc.ledger_id     = pc_ledger_id
         AND slc.periodo       = pc_periodo
       ORDER BY slc.area
               ,slc.periodo
               ,slc.livro
               ,slc.c_custo
               ,slc.conta_calculo
               ,slc.seq;
  BEGIN
    g_nCalc_Ct := 0;
    -- -------------------- --
    -- RH-21603 e IND-21603 --
    -- -------------------- --
    FOR r_1 IN c_1 ( pc_ledger_id => p_ledger_id
                    ,pc_periodo   => p_periodo
                    ,pc_etapa     => p_etapa ) LOOP
      -- --------------------------------------------------------- --
      -- Armazanar o valor da Sequence da primeira linha pois esta --
      -- sera usada como chave estrangeira nas linhas filhas.      --
      -- --------------------------------------------------------- --
      BEGIN
        SELECT bolinf.xx_opm_calc_rateio_s.NEXTVAL
          INTO g_nCalc_Rateio_Id
          FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao gerar valor para a sequence BOLINF.XX_OPM_CALC_RATEIO_S em BOLINF.XX_OPM_RATEIO_PKG.rh_ind_21603_orig_p - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20060, p_errbuf);
      END;
      --
      IF r_1.seq = 1 THEN -- Armazena o ID da linha pai para ser utilizado nas linhas filhas
        g_nCalc_Rateio_Id_Pai := g_nCalc_Rateio_Id;
      END IF;
      --
      BEGIN
        INSERT
          INTO bolinf.xx_opm_calc_rateio ( calc_rateio_id             -- 1
                                          ,calc_rateio_id_pai         -- 2
                                          ,etapa                      -- 3
                                          ,periodo                    -- 4
                                          ,ledger_id                  -- 5
                                          ,livro                      -- 6
                                          --
                                          ,u_produtiva_enviando       -- 7
                                          ,produto_enviando           -- 8
                                          ,cc_enviando                -- 9
                                          ,projeto_enviando           -- 10
                                          --
                                          ,u_produtiva_recebendo      -- 11
                                          ,produto_recebendo          -- 12
                                          ,cc_recebendo               -- 13
                                          ,projeto_recebendo          -- 14
                                          --
                                          ,u_produtiva_original       -- 15
                                          ,produto_original           -- 16
                                          ,cc_original                -- 17
                                          ,projeto_original 	        -- 18
                                          --
                                          ,u_produtiva_calculo        -- 19
                                          ,produto_calculo            -- 20
                                          ,cc_calculo                 -- 21
                                          ,projeto_calculo            -- 22
                                          --
                                          ,area_calculo               -- 23
                                          ,conta_calculo              -- 24
                                          ,valor                      -- 25
                                          ,indice                     -- 26
                                          ,rateio                     -- 27
                                          ,tipo                       -- 28
                                          ,seq                        -- 29
                                          ,creation_date              -- 30
                                          ,created_by                 -- 31
                                          ,last_update_login )        -- 32
                                  VALUES ( g_nCalc_Rateio_Id          -- 1
                                          ,DECODE(r_1.seq, 1, NULL, g_nCalc_Rateio_Id_Pai) -- 2 -- Aqui sera inserido a chave do registro pai (primero insert)
                                          ,r_1.etapa                  -- 3
                                          ,r_1.periodo                -- 4
                                          ,r_1.ledger_id              -- 5
                                          ,r_1.livro                  -- 6
                                          --
                                          ,r_1.u_produtiva_enviando   -- 7
                                          ,r_1.produto_enviando       -- 8
                                          ,r_1.cc_enviando            -- 9
                                          ,r_1.projeto_enviando       -- 10
                                          --
                                          ,r_1.u_produtiva_recebendo  -- 11
                                          ,r_1.produto_recebendo      -- 12
                                          ,r_1.cc_recebendo           -- 13
                                          ,r_1.projeto_recebendo      -- 14
                                          --
                                          ,r_1.u_produtiva_original   -- 15
                                          ,r_1.produto_original       -- 16
                                          ,r_1.cc_original            -- 17
                                          ,r_1.projeto_original       -- 18
                                          --
                                          ,r_1.u_produtiva_calculo    -- 19
                                          ,r_1.produto_calculo        -- 20
                                          ,r_1.cc_calculo             -- 21
                                          ,r_1.projeto_calculo        -- 22
                                          --
                                          ,r_1.area_calculo           -- 23
                                          ,r_1.conta_calculo          -- 24
                                          ,r_1.valor                  -- 25
                                          ,r_1.indice                 -- 26
                                          ,r_1.rateio                 -- 27
                                          ,r_1.tipo                   -- 28
                                          ,r_1.seq                    -- 29
                                          ,SYSDATE                    -- 30
                                          ,g_nUser_id                 -- 31
                                          ,g_nLogin_id );             -- 32
        --
        g_nCalc_Ct := g_nCalc_Ct + SQL%ROWCOUNT;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir rateio do registro na tabela BOLINF.XX_OPM_CALC_RATEIO no procedimento BOLINF.XX_OPM_RATEIO_PKG.rh_ind_21603_orig_p,  - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20070, p_errbuf);
      END;
    END LOOP;
    --
    --log_p ( 'Registros inseridos tabela de calculo: ' || g_nCalc_Ct );
  END rh_ind_21603_orig_p;
  -- ----------------------------------------------------------- --
  -- Processar Registros enviados para a tabela TRANSITORIA.     --
  -- Neste ponto os registros enviados para a tabela Transitoria --
  -- serao realaciodos com a tabela de indices para os calculos. --
  -- e serao feitos os calculos do rateio ate que os rateios fi- --
  -- quem zerados.                                               --
  -- ----------------------------------------------------------- --
  PROCEDURE transit_rh_ind_p ( p_errbuf      OUT VARCHAR2
                              ,p_retcode     OUT NUMBER
                              ,p_ledger_id   IN  bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                              ,p_periodo     IN  bolinf.xx_opm_calc_rateio.periodo%TYPE
                              ,p_area        IN  bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                              ,p_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE
                              ,p_u_produtiva IN bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE ) IS
  BEGIN
    -- ------------------------------------------------------------------- --
    -- O count abaixo ira  controlar  as iteracoes  deste Loop,  que sera  --
    -- dinamico. Conforme o processo for sendo executado,  cada etapa di-  --
    -- minuira a quantidade de registros  retornados pelo select, ate que  --
    -- nao hajam mais valores a serem rateados e o processo saira do loop. --
    -- ------------------------------------------------------------------- --
    LOOP
	    BEGIN
	  	  SELECT COUNT(1) qtd_registros
				  INTO g_nCt
				  FROM ( SELECT transit.rateio * (ind_rat.indice * -1) AS rateio
				           FROM bolinf.xx_opm_rateio_transitoria transit
				               ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
				               ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
				          WHERE transit.ledger_id           = ind_rat.ledger_id
				            AND transit.periodo	            = ind_rat.periodo
				            AND transit.cc_calculo          = ind_rat.c_c_envio
				            AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio
				            AND transit.cc_calculo          = cc_grupo.centro_custo(+)
				            AND transit.area_calculo        = p_area
				          UNION ALL
				         SELECT transit.rateio*ind_rat.indice AS rateio
				           FROM bolinf.xx_opm_rateio_transitoria transit
				               ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
				               ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
				          WHERE transit.ledger_id           = ind_rat.ledger_id
				            AND transit.periodo	            = ind_rat.periodo
				            AND transit.cc_calculo          = ind_rat.c_c_envio
				            AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio
				            AND ind_rat.c_c_recebido        = cc_grupo.centro_custo(+)
				            AND transit.area_calculo        = p_area ) slc
				 WHERE slc.rateio < -0.0001 OR slc.rateio > 0.0001;
	    EXCEPTION
	    	WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao consultar a quantidade de registros a serem processados, procedimento BOLINF.XX_OPM_RATEIO_PKG.TRANSIT_RH_IND_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20130, p_errbuf);
	  	END;
      --
	    EXIT WHEN g_nCt = 0; -- Saira do loop quando nao houverem mais valores a serem rateados
	  	g_nIteracao := g_nIteracao + 1;
      --
      FOR r_2 IN (SELECT slc.*
									  FROM ( SELECT transit.ledger_id              AS ledger_id
									               ,transit.periodo                AS periodo
									               ,transit.livro                  AS livro
									               ,transit.area_calculo           AS etapa -- RH
										             ,transit.u_produtiva_calculo    AS u_produtiva_enviando
										             ,transit.produto_calculo        AS produto_enviando
										             ,transit.cc_calculo             AS cc_enviando
										             ,transit.projeto_calculo        AS projeto_enviando
										             --
										             ,ind_rat.und_produtiva_recebido AS u_produtiva_recebendo
											           ,LPAD(ind_rat.produto_recebido,3,'0') AS produto_recebendo -- O arquivo de indices quando aberto no Excel, pode suprimir dois zeros do campo PRODUTO = '000'
											           ,ind_rat.c_c_recebido           AS cc_recebendo
											           ,ind_rat.projeto_recebido       AS projeto_recebendo
										             --
										             ,transit.u_produtiva_original   AS u_produtiva_original
										             ,transit.produto_original       AS produto_original
										             ,transit.cc_original            AS cc_original
										             ,transit.projeto_original       AS projeto_original
										             --
										             ,cc_grupo.area                  AS area_calculo
										             ,transit.u_produtiva_calculo    AS u_produtiva_calculo
										             ,transit.produto_calculo        AS produto_calculo
										             ,transit.cc_calculo             AS cc_calculo
										             ,transit.projeto_calculo        AS projeto_calculo
										             ,transit.conta_calculo          AS conta_calculo
										             --
										             ,transit.valor                  AS valor
										             ,ind_rat.indice * -1            AS indice
										             ,transit.rateio * (ind_rat.indice * -1) AS rateio
										             ,'ENVIADO'                      AS tipo
										         FROM bolinf.xx_opm_rateio_transitoria transit
										             ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
										             ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
										        WHERE transit.ledger_id           = ind_rat.ledger_id
				                      AND transit.periodo	            = ind_rat.periodo
										          AND transit.cc_calculo          = ind_rat.c_c_envio
										          AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio
										          AND transit.cc_calculo          = cc_grupo.centro_custo(+)
										          AND transit.area_calculo        = p_area
										        UNION ALL
										       SELECT transit.ledger_id              AS ledger_id
									               ,transit.periodo                AS periodo
									               ,transit.livro                  AS livro
										             ,transit.area_calculo           AS etapa
										             ,transit.u_produtiva_calculo    AS u_produtiva_enviando
										             ,transit.produto_calculo        AS produto_enviando
										             ,transit.cc_calculo             AS cc_enviando
										             ,transit.projeto_calculo        AS projeto_enviando
										             --
										             ,ind_rat.und_produtiva_recebido AS u_produtiva_recebendo
										             ,LPAD(ind_rat.produto_recebido,3,'0') AS produto_recebendo -- O arquivo de indices quando aberto no Excel, pode suprimir dois zeros do campo PRODUTO = '000'
										             ,ind_rat.c_c_recebido           AS cc_recebendo
										             ,ind_rat.projeto_recebido       AS projeto_recebendo
										             --
										             ,transit.u_produtiva_original   AS u_produtiva_original
										             ,transit.produto_original       AS produto_original
										             ,transit.cc_original            AS cc_original
										             ,transit.projeto_original       AS projeto_original
										             --
										             ,cc_grupo.area                  AS area_calculo
                                 ,ind_rat.und_produtiva_recebido       AS u_produtiva_calculo
										             ,LPAD(ind_rat.produto_recebido,3,'0') AS produto_calculo
										             ,ind_rat.c_c_recebido           AS cc_calculo
										             ,ind_rat.projeto_recebido       AS projeto_calculo
										             ,transit.conta_calculo          AS conta_calculo
										             --
										             ,transit.valor                  AS valor
										             ,ind_rat.indice                 AS indice
										             ,transit.rateio*ind_rat.indice  AS rateio
				   				               ,'RECEBIDO'                     AS tipo
									           FROM bolinf.xx_opm_rateio_transitoria transit
										             ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
										             ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
										        WHERE transit.ledger_id           = ind_rat.ledger_id
				                      AND transit.periodo	            = ind_rat.periodo
										          AND transit.cc_calculo          = ind_rat.c_c_envio
										          AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio
										          AND ind_rat.c_c_recebido        = cc_grupo.centro_custo(+)
										          AND transit.area_calculo        = p_area ) slc
									 WHERE slc.rateio < -0.0001 OR slc.rateio > 0.0001
								   ORDER BY slc.etapa
									         ,slc.u_produtiva_calculo
									         ,slc.valor
									         ,slc.tipo
									         ,slc.cc_calculo ) LOOP
        BEGIN
		      INSERT
					  INTO bolinf.xx_opm_calc_rateio ( calc_rateio_id             -- 1
															              ,etapa                      -- 2
															              ,periodo                    -- 3
															              ,ledger_id	                -- 4
															              ,livro                      -- 5
															              --
															              ,u_produtiva_enviando       -- 6
															              ,produto_enviando           -- 7
															              ,cc_enviando                -- 8
															              ,projeto_enviando           -- 9
															              --
															              ,u_produtiva_recebendo      -- 10
															              ,produto_recebendo          -- 11
															              ,cc_recebendo               -- 12
															              ,projeto_recebendo          -- 13
															              --
															              ,u_produtiva_original       -- 14
															              ,produto_original           -- 15
															              ,cc_original                -- 16
															              ,projeto_original           -- 17
															              --
															              ,area_calculo               -- 18
															              ,u_produtiva_calculo        -- 19
															              ,produto_calculo            -- 20
															              ,cc_calculo                 -- 21
															              ,projeto_calculo            -- 22
															              ,conta_calculo              -- 23
															              --
															              ,valor                      -- 24
															              ,indice                     -- 25
															              ,rateio                     -- 26
															              ,tipo                       -- 27
															              ,creation_date              -- 28
															              ,created_by                 -- 29
															              ,last_update_login          -- 30
															              ,iteracao )									-- 31
															      VALUES ( bolinf.xx_opm_calc_rateio_s.NEXTVAL -- 1
	                                          ,r_2.etapa	                -- 2
	                                          ,r_2.periodo                -- 3
	                                          ,r_2.ledger_id              -- 4
	                                          ,r_2.livro                  -- 5
	                                          --
	                                          ,r_2.u_produtiva_enviando   -- 6
	                                          ,r_2.produto_enviando       -- 7
	                                          ,r_2.cc_enviando            -- 8
	                                          ,r_2.projeto_enviando       -- 9
	                                          --
	                                          ,r_2.u_produtiva_recebendo  -- 10
	                                          ,r_2.produto_recebendo      -- 11
	                                          ,r_2.cc_recebendo           -- 12
	                                          ,r_2.projeto_recebendo      -- 13
	                                          --
	                                          ,r_2.u_produtiva_original   -- 14
	                                          ,r_2.produto_original       -- 15
	                                          ,r_2.cc_original            -- 16
	                                          ,r_2.projeto_original       -- 17
	                                          --
	                                          ,r_2.area_calculo           -- 18
	                                          ,r_2.u_produtiva_calculo    -- 19
	                                          ,r_2.produto_calculo        -- 20
	                                          ,r_2.cc_calculo             -- 21
	                                          ,r_2.projeto_calculo        -- 22
	                                          ,r_2.conta_calculo          -- 23
	                                          --
	                                          ,r_2.valor                  -- 24
	                                          ,r_2.indice                 -- 25
	                                          ,r_2.rateio                 -- 26
	                                          ,r_2.tipo                   -- 27
	                                          ,SYSDATE                    -- 28
	                                          ,g_nUser_id                 -- 29
	                                          ,g_nLogin_id                -- 30
	                                          ,g_nIteracao );      			  -- 31
          --
	  	    g_nCalc_Ct := g_nCalc_Ct + SQL%ROWCOUNT;
	  	  EXCEPTION
		      WHEN OTHERS THEN
            p_retcode := -2;
            p_errbuf  := 'Erro ao inserir rateio do registro filho na tabela BOLINF.XX_OPM_CALC_RATEIO, procedimento BOLINF.XX_OPM_RATEIO_PKG.TRANSTI_RH_P  - ' || SQLERRM;
            RAISE_APPLICATION_ERROR(-20140, p_errbuf);
	  	  END;
      END LOOP; -- fim do 'FOR r_2 IN...'
      -- --------------------------------------------------------------------------- --
      -- Insere na tabela TRANSITORIA os registros do ultimo calculo enviado para a  --
      -- tabela de Calculos, agrupados. O insert com o Select abaixo pegara TODOS os --
      -- registros da tabela de Calculos, inclusive os GASTOS ORIGINAIS.             --
      -- *A chave sera o CALC_ID_RATEIO gerado na primeira linha e que tambem e vin- --
      -- culado as linhas filhas.                                                    --
      -- --------------------------------------------------------------------------- --
      DELETE FROM bolinf.xx_opm_rateio_transitoria; -- Limpa a tabela transitoria antes de novas insercoes
      BEGIN
      	INSERT
				  INTO bolinf.xx_opm_rateio_transitoria ( ledger_id            -- 1
				                                         ,livro                -- 2
				                                         ,periodo              -- 3
				                                         ,u_produtiva_original -- 4
				                                         ,produto_original     -- 5
				                                         ,cc_original          -- 6
				                                         ,projeto_original     -- 7
				                                         ,area_calculo         -- 8
				                                         ,u_produtiva_calculo  -- 9
				                                         ,produto_calculo			 -- 10
				                                         ,cc_calculo           -- 11
				                                         ,projeto_calculo      -- 12
				                                         ,conta_calculo        -- 13
				                                         ,valor                -- 14
				                                         ,rateio               -- 15
				                                         ,iteracao )           -- 16
				                                   SELECT calc.ledger_id            -- 1
				                                         ,calc.livro                -- 2
				                                         ,calc.periodo              -- 3
				                                         ,calc.u_produtiva_original -- 4
		                                             ,calc.produto_original     -- 5
		                                             ,calc.cc_original          -- 6
		                                             ,calc.projeto_original			-- 7
		                                             ,calc.area_calculo         -- 8
		                                             ,calc.u_produtiva_calculo  -- 9
		                                             ,calc.produto_calculo			-- 10
		                                             ,calc.cc_calculo	          -- 11
		                                             ,calc.projeto_calculo      -- 12
		                                             ,calc.conta_calculo        -- 13
		                                             ,calc.valor                -- 14
		                                             ,SUM(calc.rateio) rateio   -- 15
		                                             ,g_nIteracao               -- 16 -- Utilizar apenas na package -- cada iteracao soma o sequencial
		                                         FROM bolinf.xx_opm_calc_rateio calc
		                                        WHERE 1=1
		                                          --AND (calc.calc_rateio_id = g_nCalc_Rateio_Id_Pai OR calc.calc_rateio_id_pai = g_nCalc_Rateio_Id_Pai) -- 04/06/2019

                                              AND calc.ledger_id = p_ledger_id
                                              AND calc.periodo   = p_periodo

                                              --AND calc.etapa     = p_etapa
                                              AND calc.AREA_CALCULO = p_etapa

                                              AND (p_u_produtiva IS NULL OR calc.u_produtiva_original = p_u_produtiva)
                                              AND NVL(calc.enviado_gl_interface,'N') = 'N' -- Rafael -- 09/09/2019
		                                       HAVING (SUM(calc.rateio) < -0.0001 OR SUM(calc.rateio) > 0.0001)
                                            GROUP BY calc.ledger_id
						                                        ,calc.livro
						                                        ,calc.periodo
						                                        ,calc.u_produtiva_original
				                                            ,calc.produto_original
			                                              ,calc.cc_original
			                                              ,calc.projeto_original
			                                              ,calc.area_calculo
			                                              ,calc.u_produtiva_calculo
			                                              ,calc.produto_calculo
			                                              ,calc.cc_calculo
			                                              ,calc.projeto_calculo
			                                              ,calc.conta_calculo
			                                              ,calc.valor;
      EXCEPTION
      	WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir rateio do registro, iteracao ' || g_nIteracao || ', na tabela BOLINF.XX_OPM_RATEIO_TRANSITORIA, procedimento BOLINF.XX_OPM_RATEIO_PKG.TRANSTI_RH_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20150, p_errbuf);
      END;
    END LOOP;
  END transit_rh_ind_p;
  -- --------------------------------------------------------------- --
  --  ATENCAO   ATENCAO   ATENCAO    ATENCAO   ATENCAO   ATENCAO !!! --
  -- A procedure abaixo eh semelhante a procedure TRANSIT_RH_IND_P,  --
  -- com excessao do JOIN:                                           --
  -- "AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio" --
  --                                                                 --
  -- Processar Registros enviados para a tabela TRANSITORIA.         --
  -- Neste ponto os registros enviados para a tabela Transitoria se- --
  -- rao relaciodos com a tabela de indices para os calculos.        --
  -- e serao feitos os  calculos do rateio ate que os rateios fiquem --
  -- zerados.                                                        --
  -- --------------------------------------------------------------- --
  PROCEDURE transit_p ( p_errbuf  OUT VARCHAR2
                       ,p_retcode OUT NUMBER
                       ,p_ledger_id   IN  bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                       ,p_periodo     IN  bolinf.xx_opm_calc_rateio.periodo%TYPE
                       ,p_area        IN  bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                       --,p_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE
                       ) IS
  BEGIN
    -- ------------------------------------------------------------------- --
    -- O count abaixo ira  controlar  as iteracoes  deste Loop,  que sera  --
    -- dinamico. Conforme o processo for sendo executado,  cada etapa di-  --
    -- minuira a quantidade de registros  retornados pelo select, ate que  --
    -- nao hajam mais valores a serem rateados e o processo saira do loop. --
    -- ------------------------------------------------------------------- --
    LOOP
	    BEGIN
	  	  SELECT COUNT(1) qtd_registros
				  INTO g_nCt
				  FROM ( SELECT transit.rateio * (ind_rat.indice * -1) AS rateio
				           FROM bolinf.xx_opm_rateio_transitoria transit
				               ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
				               ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
				          WHERE transit.ledger_id           = ind_rat.ledger_id
				            AND transit.periodo	            = ind_rat.periodo
				            AND transit.cc_calculo          = ind_rat.c_c_envio

				            --AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio -- Este JOIN nao deve ser usado nesta etapa

				            AND transit.cc_calculo          = cc_grupo.centro_custo(+)
				            AND transit.area_calculo        = p_area -- 'RH'
				          UNION ALL
				         SELECT transit.rateio*ind_rat.indice AS rateio
				           FROM bolinf.xx_opm_rateio_transitoria transit
				               ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
				               ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
				          WHERE transit.ledger_id           = ind_rat.ledger_id
				            AND transit.periodo	            = ind_rat.periodo
				            AND transit.cc_calculo          = ind_rat.c_c_envio

				            --AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio -- Este JOIN nao deve ser usado nesta etapa

				            AND ind_rat.c_c_recebido        = cc_grupo.centro_custo(+)
				            AND transit.area_calculo        = p_area ) slc -- 'RH'
				 WHERE slc.rateio < -0.0001 OR slc.rateio > 0.0001;
	    EXCEPTION
	    	WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao consultar a quantidade de registros a serem processados, procedimento BOLINF.XX_OPM_RATEIO_PKG.TRANSIT_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20160, p_errbuf);
	  	END;
      --
	    EXIT WHEN g_nCt = 0; -- Saira do loop quando nao houverem mais valores a serem rateados
	  	g_nIteracao := g_nIteracao + 1;
      --
      FOR r_2 IN (SELECT slc.*
									  FROM ( SELECT transit.ledger_id              AS ledger_id
									               ,transit.periodo                AS periodo
									               ,transit.livro                  AS livro
									               ,transit.area_calculo           AS etapa
										             ,transit.u_produtiva_calculo    AS u_produtiva_enviando
										             ,transit.produto_calculo        AS produto_enviando
										             ,transit.cc_calculo             AS cc_enviando
										             ,transit.projeto_calculo        AS projeto_enviando
										             --
										             ,ind_rat.und_produtiva_recebido AS u_produtiva_recebendo
											           ,LPAD(ind_rat.produto_recebido,3,'0') AS produto_recebendo -- O arquivo de indices quando aberto no Excel, pode suprimir dois zeros do campo PRODUTO = '000'
											           ,ind_rat.c_c_recebido           AS cc_recebendo
											           ,ind_rat.projeto_recebido       AS projeto_recebendo
										             --
										             ,transit.u_produtiva_original   AS u_produtiva_original
										             ,transit.produto_original       AS produto_original
										             ,transit.cc_original            AS cc_original
										             ,transit.projeto_original       AS projeto_original
										             --
										             ,cc_grupo.area                  AS area_calculo
										             ,transit.u_produtiva_calculo    AS u_produtiva_calculo
										             ,transit.produto_calculo        AS produto_calculo
										             ,transit.cc_calculo             AS cc_calculo
										             ,transit.projeto_calculo        AS projeto_calculo
										             ,transit.conta_calculo          AS conta_calculo
										             --
										             ,transit.valor                  AS valor
										             ,ind_rat.indice * -1            AS indice
										             ,transit.rateio * (ind_rat.indice * -1) AS rateio
										             ,'ENVIADO'                      AS tipo
										         FROM bolinf.xx_opm_rateio_transitoria transit
										             ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
										             ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
										        WHERE transit.ledger_id           = ind_rat.ledger_id
				                      AND transit.periodo	            = ind_rat.periodo
										          AND transit.cc_calculo          = ind_rat.c_c_envio

                              --AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio -- Este JOIN nao deve ser usado nesta etapa

										          AND transit.cc_calculo          = cc_grupo.centro_custo(+)
										          AND transit.area_calculo        = p_area
										        UNION ALL
										       SELECT transit.ledger_id              AS ledger_id
									               ,transit.periodo                AS periodo
									               ,transit.livro                  AS livro
										             ,transit.area_calculo           AS etapa -- RH
										             ,transit.u_produtiva_calculo    AS u_produtiva_enviando
										             ,transit.produto_calculo        AS produto_enviando
										             ,transit.cc_calculo             AS cc_enviando
										             ,transit.projeto_calculo        AS projeto_enviando
										             --
										             ,ind_rat.und_produtiva_recebido AS u_produtiva_recebendo
										             ,LPAD(ind_rat.produto_recebido,3,'0') AS produto_recebendo -- O arquivo de indices quando aberto no Excel, pode suprimir dois zeros do campo PRODUTO = '000'
										             ,ind_rat.c_c_recebido           AS cc_recebendo
										             ,ind_rat.projeto_recebido       AS projeto_recebendo
										             --
										             ,transit.u_produtiva_original   AS u_produtiva_original
										             ,transit.produto_original       AS produto_original
										             ,transit.cc_original            AS cc_original
										             ,transit.projeto_original       AS projeto_original
										             --
										             ,cc_grupo.area                  AS area_calculo
                                 ,ind_rat.und_produtiva_recebido       AS u_produtiva_calculo
										             ,LPAD(ind_rat.produto_recebido,3,'0') AS produto_calculo
										             ,ind_rat.c_c_recebido           AS cc_calculo
										             ,ind_rat.projeto_recebido       AS projeto_calculo
										             ,transit.conta_calculo          AS conta_calculo
										             --
										             ,transit.valor                  AS valor
										             ,ind_rat.indice                 AS indice
										             ,transit.rateio*ind_rat.indice  AS rateio
				   				               ,'RECEBIDO'                     AS tipo
									           FROM bolinf.xx_opm_rateio_transitoria transit
										             ,bolinf.xx_opm_perc_rat_depart    ind_rat  -- Indices do Rateio
										             ,bolinf.xx_opm_cc_grupo_rateio    cc_grupo -- Centro de Custos vs Grupo
										        WHERE transit.ledger_id           = ind_rat.ledger_id
				                      AND transit.periodo	            = ind_rat.periodo
										          AND transit.cc_calculo          = ind_rat.c_c_envio

                              --AND transit.u_produtiva_calculo = ind_rat.und_produtiva_envio -- Este JOIN nao deve ser usado nesta etapa

                              AND ind_rat.c_c_recebido        = cc_grupo.centro_custo(+)
										          AND transit.area_calculo        = p_area ) slc
									 WHERE slc.rateio < -0.0001 OR slc.rateio > 0.0001
								   ORDER BY slc.etapa
									         ,slc.u_produtiva_calculo
									         ,slc.valor
									         ,slc.tipo
									         ,slc.cc_calculo ) LOOP
        BEGIN
		      INSERT
					  INTO bolinf.xx_opm_calc_rateio ( calc_rateio_id             -- 1
															              ,etapa                      -- 2
															              ,periodo                    -- 3
															              ,ledger_id	                -- 4
															              ,livro                      -- 5
															              --
															              ,u_produtiva_enviando       -- 6
															              ,produto_enviando           -- 7
															              ,cc_enviando                -- 8
															              ,projeto_enviando           -- 9
															              --
															              ,u_produtiva_recebendo      -- 10
															              ,produto_recebendo          -- 11
															              ,cc_recebendo               -- 12
															              ,projeto_recebendo          -- 13
															              --
															              ,u_produtiva_original       -- 14
															              ,produto_original           -- 15
															              ,cc_original                -- 16
															              ,projeto_original           -- 17
															              --
															              ,area_calculo               -- 18
															              ,u_produtiva_calculo        -- 19
															              ,produto_calculo            -- 20
															              ,cc_calculo                 -- 21
															              ,projeto_calculo            -- 22
															              ,conta_calculo              -- 23
															              --
															              ,valor                      -- 24
															              ,indice                     -- 25
															              ,rateio                     -- 26
															              ,tipo                       -- 27
															              ,creation_date              -- 28
															              ,created_by                 -- 29
															              ,last_update_login          -- 30
															              ,iteracao )									-- 31
															      VALUES ( bolinf.xx_opm_calc_rateio_s.NEXTVAL -- 1
                                            ,r_2.etapa	                -- 2
	                                          ,r_2.periodo                -- 3
	                                          ,r_2.ledger_id              -- 4
	                                          ,r_2.livro                  -- 5
	                                          --
	                                          ,r_2.u_produtiva_enviando   -- 6
	                                          ,r_2.produto_enviando       -- 7
	                                          ,r_2.cc_enviando            -- 8
	                                          ,r_2.projeto_enviando       -- 9
	                                          --
	                                          ,r_2.u_produtiva_recebendo  -- 10
	                                          ,r_2.produto_recebendo      -- 11
	                                          ,r_2.cc_recebendo           -- 12
	                                          ,r_2.projeto_recebendo      -- 13
	                                          --
	                                          ,r_2.u_produtiva_original   -- 14
	                                          ,r_2.produto_original       -- 15
	                                          ,r_2.cc_original            -- 16
	                                          ,r_2.projeto_original       -- 17
	                                          --
	                                          ,r_2.area_calculo           -- 18
	                                          ,r_2.u_produtiva_calculo    -- 19
	                                          ,r_2.produto_calculo        -- 20
	                                          ,r_2.cc_calculo             -- 21
	                                          ,r_2.projeto_calculo        -- 22
	                                          ,r_2.conta_calculo          -- 23
	                                          --
	                                          ,r_2.valor                  -- 24
	                                          ,r_2.indice                 -- 25
	                                          ,r_2.rateio                 -- 26
	                                          ,r_2.tipo                   -- 27
                                            ,SYSDATE                    -- 28
	                                          ,g_nUser_id                 -- 29
	                                          ,g_nLogin_id                -- 30
	                                          ,g_nIteracao );      			  -- 31
          --
	  	    g_nCalc_Ct := g_nCalc_Ct + SQL%ROWCOUNT;
	  	  EXCEPTION
		      WHEN OTHERS THEN
            p_retcode := -2;
            p_errbuf  := 'Erro ao inserir rateio do registro filho na tabela BOLINF.XX_OPM_CALC_RATEIO, procedimento BOLINF.XX_OPM_RATEIO_PKG.TRANSTI_P  - ' || SQLERRM;
            RAISE_APPLICATION_ERROR(-20170, p_errbuf);
	  	  END;
      END LOOP; -- Fim do 'FOR r_2 IN...'
      -- --------------------------------------------------------------------------- --
      -- Insere na tabela TRANSITORIA os registros do ultimo calculo enviado para a  --
      -- tabela de Calculos, agrupados. O insert com o Select abaixo pegara TODOS os --
      -- registros da tabela de Calculos, inclusive os GASTOS ORIGINAIS.             --
      -- *A chave sera o CALC_ID_RATEIO gerado na primeira linha e que tambem e vin- --
      -- culado as linhas filhas.                                                    --
      -- --------------------------------------------------------------------------- --
      DELETE FROM bolinf.xx_opm_rateio_transitoria; -- Limpa a tabela transitoria antes de novas insercoes
      BEGIN
      	INSERT
				  INTO bolinf.xx_opm_rateio_transitoria ( ledger_id            -- 1
				                                         ,livro                -- 2
				                                         ,periodo              -- 3
				                                         ,u_produtiva_original -- 4
				                                         ,produto_original     -- 5
				                                         ,cc_original          -- 6
				                                         ,projeto_original     -- 7
				                                         ,area_calculo         -- 8
				                                         ,u_produtiva_calculo  -- 9
				                                         ,produto_calculo			 -- 10
				                                         ,cc_calculo           -- 11
				                                         ,projeto_calculo      -- 12
				                                         ,conta_calculo        -- 13
				                                         ,valor                -- 14
				                                         ,rateio               -- 15
				                                         ,iteracao )           -- 16
				                                   SELECT calc.ledger_id            -- 1
				                                         ,calc.livro                -- 2
				                                         ,calc.periodo              -- 3
				                                         ,calc.u_produtiva_original	-- 4
		                                             ,calc.produto_original     -- 5
		                                             ,calc.cc_original          -- 6
		                                             ,calc.projeto_original			-- 7
		                                             ,calc.area_calculo         -- 8
		                                             ,calc.u_produtiva_calculo  -- 9
		                                             ,calc.produto_calculo			-- 10
		                                             ,calc.cc_calculo	          -- 11
		                                             ,calc.projeto_calculo      -- 12
		                                             ,calc.conta_calculo        -- 13
		                                             ,calc.valor                -- 14
		                                             ,SUM(calc.rateio) rateio   -- 15
		                                             ,g_nIteracao               -- 16 -- Utilizar apenas na package -- cada iteracao soma o sequencial
		                                         FROM bolinf.xx_opm_calc_rateio calc
		                                        WHERE 1=1
		                                          --AND (calc.calc_rateio_id = g_nCalc_Rateio_Id_Pai OR calc.calc_rateio_id_pai = g_nCalc_Rateio_Id_Pai) -- 04/06/2019

                                              AND calc.ledger_id = p_ledger_id
                                              AND calc.periodo   = p_periodo
                                              --AND calc.etapa     = p_etapa

                                              AND calc.AREA_CALCULO = p_area

                                              --AND (p_u_produtiva IS NULL OR calc.u_produtiva_original = p_u_produtiva)
                                              AND NVL(calc.enviado_gl_interface,'N') = 'N' -- Rafael -- 09/09/2019
		                                       HAVING (SUM(calc.rateio) < -0.0001 OR SUM(calc.rateio) > 0.0001) -- TESTE -- RAFAEL
		                                        GROUP BY calc.ledger_id
						                                        ,calc.livro
						                                        ,calc.periodo
						                                        ,calc.u_produtiva_original
				                                            ,calc.produto_original
			                                              ,calc.cc_original
			                                              ,calc.projeto_original
			                                              ,calc.area_calculo
			                                              ,calc.u_produtiva_calculo
			                                              ,calc.produto_calculo
			                                              ,calc.cc_calculo
			                                              ,calc.projeto_calculo
			                                              ,calc.conta_calculo
			                                              ,calc.valor;
      EXCEPTION
      	WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir rateio do registro, iteracao ' || g_nIteracao || ', na tabela BOLINF.XX_OPM_RATEIO_TRANSITORIA, procedimento BOLINF.XX_OPM_RATEIO_PKG.TRANSTI_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20180, p_errbuf);
      END;
    END LOOP;
  END transit_p;
  -- -------------------------------------------------------------------------- --
  -- Regra exclusiva para o processamento da etapa IND-21603:                   --
  -- Recuperar o rateio  recebido  das etapas anteriores que  forem da  area de --
  -- IND (industria) e tiver como unidade produtiva o 21603, pegando os valores --
  -- e  dividindo  em 50% para 21201 e 50% para 21202.  Regra definida pelo key --
  -- user Arlei Campos em 14/06/2019 via Skype.                                 --
  -- -------------------------------------------------------------------------- --
  -- ATENCAO:                                                                   --
  --  O cursor C_1 eh semelhante ao cursor da procedure RH_IND_21603_ORIG_P,    --
  --  a diferenca eh a chave utilizada 'AREA', ao inves da ETAPA e aqui deve-se --
  --  recuperar os dados que ja foram rateados na propria tabela                --
  --  BOLINF.XX_OPM_CALC_RATEIO.                                                --
  -- -------------------------------------------------------------------------- --
  PROCEDURE etp_ant_ind_21603_p ( p_errbuf      OUT VARCHAR2
                                 ,p_retcode     OUT NUMBER
                                 ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                 ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
                                 ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_calculo%TYPE
                                 ,p_etapa       bolinf.xx_opm_calc_rateio.etapa%TYPE
                                 ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE ) IS -- Area (IND) que sera processada
  BEGIN
    BEGIN
      INSERT
        INTO bolinf.xx_opm_calc_rateio ( calc_rateio_id          -- 1
                                        ,etapa                   -- 2
                                        ,periodo                 -- 3
                                        ,ledger_id               -- 4
                                        ,livro                   -- 5
                                        --
                                        ,u_produtiva_enviando    -- 6
                                        ,produto_enviando        -- 7
                                        ,cc_enviando             -- 8
                                        ,projeto_enviando        -- 9
                                        --
                                        ,u_produtiva_recebendo   -- 10
                                        ,produto_recebendo       -- 11
                                        ,cc_recebendo            -- 12
                                        ,projeto_recebendo       -- 13
                                        --
                                        ,u_produtiva_original    -- 14
                                        ,produto_original        -- 15
                                        ,cc_original             -- 16
                                        ,projeto_original        -- 17
                                        --
                                        ,u_produtiva_calculo     -- 18
                                        ,produto_calculo         -- 19
                                        ,cc_calculo              -- 20
                                        ,projeto_calculo         -- 21
                                        --
                                        ,area_calculo            -- 22
                                        ,conta_calculo           -- 23
                                        ,valor                   -- 24
                                        ,indice                  -- 25
                                        ,rateio                  -- 26
                                        ,tipo                    -- 27
                                        ,seq                     -- 28
                                        ,creation_date           -- 29
                                        ,created_by              -- 30
                                        ,last_update_login )     -- 31
                                  --
                                  -- O Oracle nao permite usar sequence em select com Group By, entao foi necessario criar um subselect.
                                  --
                                  SELECT bolinf.xx_opm_calc_rateio_s.NEXTVAL -- 1
                                        ,s.etapa                 -- 2
                                        ,s.periodo               -- 3
                                        ,s.ledger_id             -- 4
                                        ,s.livro                 -- 5
                                        --
                                        ,s.u_produtiva_enviando  -- 6
                                        ,s.produto_enviando      -- 7
                                        ,s.cc_enviando           -- 8
                                        ,s.projeto_enviando      -- 9
                                        --
                                        ,s.u_produtiva_recebendo -- 10
                                        ,s.produto_recebendo     -- 11
                                        ,s.cc_recebendo          -- 12
                                        ,s.projeto_recebendo     -- 13
                                        --
                                        ,s.u_produtiva_original  -- 14
                                        ,s.produto_original      -- 15
                                        ,s.cc_original           -- 16
                                        ,s.projeto_original      -- 17
                                        --
                                        ,s.u_produtiva_calculo   -- 18
                                        ,s.produto_calculo       -- 19
                                        ,s.cc_calculo            -- 20
                                        ,s.projeto_calculo       -- 21
                                         --
                                        ,s.area_calculo          -- 22
                                        ,s.conta_calculo         -- 23
                                        ,s.valor                 -- 24
                                        ,s.indice                -- 25
                                        ,s.rateio                -- 26
                                        ,s.tipo                  -- 27
                                        ,s.seq                   -- 28
                                        ,SYSDATE                 -- 29
                                        ,g_nUser_id              -- 30
                                        ,g_nLogin_id             -- 31
                                    FROM (SELECT slc.etapa                  -- 2
                                                ,slc.periodo                -- 3
                                                ,slc.ledger_id              -- 4
                                                ,slc.livro                  -- 5
                                                --
                                                ,slc.u_produtiva_enviando   -- 6
                                                ,slc.produto_enviando       -- 7
                                                ,slc.cc_enviando            -- 8
                                                ,slc.projeto_enviando       -- 9
                                                --
                                                ,slc.u_produtiva_recebendo  -- 10
                                                ,slc.produto_recebendo      -- 11
                                                ,slc.cc_recebendo           -- 12
                                                ,slc.projeto_recebendo      -- 13
                                                --
                                                ,slc.u_produtiva_original   -- 14
                                                ,slc.produto_original       -- 15
                                                ,slc.cc_original            -- 16
                                                ,slc.projeto_original       -- 17
                                                --
                                                ,slc.u_produtiva_calculo    -- 18
                                                ,slc.produto_calculo        -- 19
                                                ,slc.cc_calculo             -- 20
                                                ,slc.projeto_calculo        -- 21
                                                 --
                                                ,slc.area_calculo           -- 22
                                                ,slc.conta_calculo          -- 23
                                                ,SUM(slc.valor)  AS valor   -- 24
                                                ,slc.indice                 -- 25
                                                ,SUM(slc.rateio) AS rateio  -- 26
                                                ,slc.tipo                   -- 27
                                                ,slc.seq                    -- 28
                                            FROM (-- --------------- --
                                                  -- 21603 (ENVIADO) --
                                                  -- --------------- --
                                                  SELECT calc.calc_rateio_id_pai   AS calc_rateio_id_pai
                                                        --,calc.etapa                AS etapa
                                                        ,p_etapa                   AS etapa -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019
                                                        ,calc.u_produtiva_calculo  AS u_produtiva_enviando -- Regra definida pelo key user Arlei via Skype - 19/06/2019
                                                        --,calc.produto_enviando     AS produto_enviando
                                                        --,calc.cc_enviando          AS cc_enviando
                                                        --,calc.projeto_enviando     AS projeto_enviando

                                                        ,calc.produto_calculo      AS produto_enviando -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_enviando      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_enviando -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,'21201'                   AS u_produtiva_recebendo
                                                        --,calc.produto_recebendo    AS produto_recebendo
                                                        --,calc.cc_recebendo         AS cc_recebendo
                                                        --,calc.projeto_recebendo    AS projeto_recebendo

                                                        ,calc.produto_calculo      AS produto_recebendo -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_recebendo      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_recebendo -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,calc.u_produtiva_original AS u_produtiva_original
                                                        ,calc.produto_original     AS produto_original
                                                        ,calc.cc_original          AS cc_original
                                                        ,calc.projeto_original     AS projeto_original
                                                        --
                                                        ,calc.area_calculo         AS area_calculo
                                                        ,calc.u_produtiva_calculo  AS u_produtiva_calculo -- Regra definida pelo key user Arlei via Skype - 19/06/2019
                                                        ,calc.produto_calculo      AS produto_calculo
                                                        ,calc.cc_calculo           AS cc_calculo
                                                        ,calc.projeto_calculo      AS projeto_calculo
                                                        ,calc.conta_calculo        AS conta_calculo
                                                        --
                                                        ,calc.rateio               AS valor
                                                        --,50*-1                     AS indice
                                                        ,0.5*-1                    AS indice -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                                                        ,calc.rateio*(50/100)*-1   AS rateio  -- ***
                                                        ,'ENVIADO'                 AS tipo
                                                        ,1                         AS seq
                                                        --
                                                        ,calc.periodo              AS periodo
                                                        ,calc.ledger_id            AS ledger_id
                                                        ,calc.livro                AS livro
                                                        ,calc.area_calculo         AS area
                                                        ,calc.u_produtiva_calculo  AS und_produtiva
                                                        ,calc.cc_calculo           AS c_custo
                                                        ,calc.conta_calculo        AS conta
                                                    FROM bolinf.xx_opm_calc_rateio calc
                                                   WHERE calc.tipo = 'RECEBIDO' -- Seleciona o tipo 'RECEBIDO', mas a saida do Select sera convertido para 'ENVIADO'
                                                     AND calc.u_produtiva_calculo = p_u_produtiva -- Usar aqui (21603) pois na saida U_PRODUTIVA_CALCULO sera convertido para 21201 e 21202
                                                   UNION
                                                  -- --------------- --
                                                  -- 21603 (ENVIADO) --
                                                  -- --------------- --
                                                  SELECT calc.calc_rateio_id_pai   AS calc_rateio_id_pai
                                                        --,calc.etapa                AS etapa
                                                        ,p_etapa                   AS etapa -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019
                                                        --,calc.u_produtiva_enviando AS u_produtiva_enviando
                                                        ,calc.u_produtiva_calculo  AS u_produtiva_enviando -- Regra definida pelo key user Arlei via Skype - 19/06/2019
                                                        --,calc.produto_enviando     AS produto_enviando
                                                        --,calc.cc_enviando          AS cc_enviando
                                                        --,calc.projeto_enviando     AS projeto_enviando

                                                        ,calc.produto_calculo      AS produto_enviando -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_enviando      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_enviando -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,'21202'                   AS u_produtiva_recebendo
                                                        --,calc.produto_recebendo    AS produto_recebendo
                                                        --,calc.cc_recebendo         AS cc_recebendo
                                                        --,calc.projeto_recebendo    AS projeto_recebendo

                                                        ,calc.produto_calculo      AS produto_recebendo -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_recebendo      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_recebendo -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,calc.u_produtiva_original AS u_produtiva_original
                                                        ,calc.produto_original     AS produto_original
                                                        ,calc.cc_original          AS cc_original
                                                        ,calc.projeto_original     AS projeto_original
                                                        --
                                                        ,calc.area_calculo         AS area_calculo
                                                        ,calc.u_produtiva_calculo  AS u_produtiva_calculo -- Regra definida pelo key user Arlei via Skype - 19/06/2019
                                                        ,calc.produto_calculo      AS produto_calculo
                                                        ,calc.cc_calculo           AS cc_calculo
                                                        ,calc.projeto_calculo      AS projeto_calculo
                                                        ,calc.conta_calculo        AS conta_calculo
                                                        --
                                                        ,calc.rateio               AS valor
                                                        --,50*-1                     AS indice
                                                        ,0.5*-1                    AS indice -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                                                        ,calc.rateio*(50/100)*-1   AS rateio  -- ***
                                                        ,'ENVIADO'                 AS tipo
                                                        ,2                         AS seq
                                                        --
                                                        ,calc.periodo              AS periodo
                                                        ,calc.ledger_id            AS ledger_id
                                                        ,calc.livro                AS livro
                                                        ,calc.area_calculo         AS area
                                                        ,calc.u_produtiva_calculo  AS und_produtiva
                                                        ,calc.cc_calculo           AS c_custo
                                                        ,calc.conta_calculo        AS conta
                                                    FROM bolinf.xx_opm_calc_rateio calc
                                                   WHERE calc.tipo = 'RECEBIDO' -- Seleciona o tipo 'RECEBIDO', mas a saida do Select sera convertido para 'ENVIADO'
                                                     AND calc.u_produtiva_calculo = p_u_produtiva -- Usar aqui (21603) pois na saida U_PRODUTIVA_CALCULO sera convertido para 21201 e 21202
                                                   UNION
                                                  -- ---------------- --
                                                  -- 21201 (RECEBIDO) --
                                                  -- ---------------- --
                                                  SELECT calc.calc_rateio_id_pai   AS calc_rateio_id_pai
                                                        --,calc.etapa                AS etapa
                                                        --,calc.u_produtiva_enviando AS u_produtiva_enviando
                                                        --,calc.produto_enviando     AS produto_enviando
                                                        --,calc.cc_enviando          AS cc_enviando
                                                        --,calc.projeto_enviando     AS projeto_enviando

                                                        ,p_etapa                   AS etapa                  -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019
                                                        ,calc.u_produtiva_calculo  AS u_produtiva_enviando   -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: pode ser u_produtiva_calculo assumindo que estamos usando apenas 21603
                                                        ,calc.produto_calculo      AS produto_enviando       -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_enviando            -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_enviando       -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,'21201'                   AS u_produtiva_recebendo
                                                        --,calc.produto_recebendo    AS produto_recebendo
                                                        --,calc.cc_recebendo         AS cc_recebendo
                                                        --,calc.projeto_recebendo    AS projeto_recebendo

                                                        ,calc.produto_calculo      AS produto_recebendo      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: pode ser u_produtiva_calculo assumindo que estamos usando apenas 21603
                                                        ,calc.cc_calculo           AS cc_recebendo           -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: pode ser u_produtiva_calculo assumindo que estamos usando apenas 21603
                                                        ,calc.projeto_calculo      AS projeto_recebendo      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: pode ser u_produtiva_calculo assumindo que estamos usando apenas 21603
                                                        --
                                                        ,calc.u_produtiva_original AS u_produtiva_original
                                                        ,calc.produto_original     AS produto_original
                                                        ,calc.cc_original          AS cc_original
                                                        ,calc.projeto_original     AS projeto_original
                                                        --
                                                        ,calc.area_calculo         AS area_calculo
                                                        ,'21201'                   AS u_produtiva_calculo -- Regra definida pelo key user Arlei via Skype - 19/06/2019
                                                        ,calc.produto_calculo      AS produto_calculo
                                                        ,calc.cc_calculo           AS cc_calculo
                                                        ,calc.projeto_calculo      AS projeto_calculo
                                                        ,calc.conta_calculo        AS conta_calculo
                                                        --
                                                        ,calc.rateio               AS valor
                                                        --,50                        AS indice
                                                        ,0.5                       AS indice  -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                                                        ,calc.rateio*(50/100)      AS rateio
                                                        ,calc.tipo                 AS tipo
                                                        ,3                         AS seq
                                                        --
                                                        ,calc.periodo              AS periodo
                                                        ,calc.ledger_id            AS ledger_id
                                                        ,calc.livro                AS livro
                                                        ,calc.area_calculo         AS area
                                                        ,calc.u_produtiva_calculo  AS und_produtiva
                                                        ,calc.cc_calculo           AS c_custo
                                                        ,calc.conta_calculo        AS conta
                                                    FROM bolinf.xx_opm_calc_rateio calc
                                                   WHERE calc.tipo = 'RECEBIDO'
                                                     AND calc.u_produtiva_calculo = p_u_produtiva -- Usar aqui (21603) pois na saida U_PRODUTIVA_CALCULO sera convertido para 21201 e 21202
                                                   UNION
                                                  -- ---------------- --
                                                  -- 21202 (RECEBIDO) --
                                                  -- ---------------- --
                                                  SELECT calc.calc_rateio_id_pai   AS calc_rateio_id_pai
                                                        --,calc.etapa                AS etapa
                                                        --,calc.u_produtiva_enviando AS u_produtiva_enviando
                                                        --,calc.produto_enviando     AS produto_enviando
                                                        --,calc.cc_enviando          AS cc_enviando
                                                        --,calc.projeto_enviando     AS projeto_enviando

                                                        ,p_etapa                   AS etapa                 -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019
                                                        ,calc.u_produtiva_calculo  AS u_produtiva_enviando  -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: pode ser u_produtiva_calculo assumindo que estamos usando apenas 21603
                                                        ,calc.produto_calculo      AS produto_enviando      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_enviando           -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_enviando      -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,'21202'                   AS u_produtiva_recebendo
                                                        --,calc.produto_recebendo    AS produto_recebendo
                                                        --,calc.cc_recebendo         AS cc_recebendo
                                                        --,calc.projeto_recebendo    AS projeto_recebendo

                                                        ,calc.produto_calculo      AS produto_recebendo     -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.cc_calculo           AS cc_recebendo          -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        ,calc.projeto_calculo      AS projeto_recebendo     -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: a etapa deve apenas trocar u_produtiva, por tanto mantem os outros flex no enviando e recebendo - ACAMPOS
                                                        --
                                                        ,calc.u_produtiva_original AS u_produtiva_original
                                                        ,calc.produto_original     AS produto_original
                                                        ,calc.cc_original          AS cc_original
                                                        ,calc.projeto_original     AS projeto_original
                                                        --
                                                        ,calc.area_calculo         AS area_calculo
                                                        ,'21202'                   AS u_produtiva_calculo -- Regra definida pelo key user Arlei via Skype - 19/06/2019
                                                        ,calc.produto_calculo      AS produto_calculo
                                                        ,calc.cc_calculo           AS cc_calculo
                                                        ,calc.projeto_calculo      AS projeto_calculo
                                                        ,calc.conta_calculo        AS conta_calculo
                                                        --
                                                        ,calc.rateio               AS valor
                                                        --,50                        AS indice
                                                        ,0.5                       AS indice   -- Rafael S. Nunes (Ninecon) -- SD 110926 -- Dez/2019 -- comentarios do key user: usar mesmo padrão do upload do arquivo de índices - ACAMPOS
                                                        ,calc.rateio*(50/100)      AS rateio
                                                        ,calc.tipo                 AS tipo
                                                        ,4                         AS seq
                                                        --
                                                        ,calc.periodo              AS periodo
                                                        ,calc.ledger_id            AS ledger_id
                                                        ,calc.livro                AS livro
                                                        ,calc.area_calculo         AS area
                                                        ,calc.u_produtiva_calculo  AS und_produtiva
                                                        ,calc.cc_calculo           AS c_custo
                                                        ,calc.conta_calculo        AS conta
                                                    FROM bolinf.xx_opm_calc_rateio calc
                                                   WHERE calc.tipo = 'RECEBIDO'
                                                     AND calc.u_produtiva_calculo = p_u_produtiva -- Usar aqui (21603) pois na saida U_PRODUTIVA_CALCULO sera convertido para 21201 e 21202
                                                ) slc
                                           WHERE slc.ledger_id    = p_ledger_id
                                             AND slc.periodo      = p_periodo
                                             AND slc.area_calculo = p_area -- Passar a etapa anterior e ser recuperada para aplicar novo rateio na etapa atual.
                                             --AND slc.u_produtiva_calculo = &pc_u_produtiva -- '21603'
                                             --AND slc.valor         <> 0      -- Fixo             --> Devera usado com 'HAVING' no Group By
                                             --AND (slc.rateio < -0.0001 OR slc.rateio > 0.0001)   --> Devera usado com 'HAVING' no Group By

                                           GROUP BY slc.etapa
                                                   ,slc.periodo
                                                   ,slc.ledger_id
                                                   ,slc.livro
                                                   --
                                                   ,slc.u_produtiva_enviando
                                                   ,slc.produto_enviando
                                                   ,slc.cc_enviando
                                                   ,slc.projeto_enviando
                                                   --
                                                   ,slc.u_produtiva_recebendo
                                                   ,slc.produto_recebendo
                                                   ,slc.cc_recebendo
                                                   ,slc.projeto_recebendo
                                                   --
                                                   ,slc.u_produtiva_original
                                                   ,slc.produto_original
                                                   ,slc.cc_original
                                                   ,slc.projeto_original
                                                   --
                                                   ,slc.area_calculo
                                                   ,slc.u_produtiva_calculo
                                                   ,slc.produto_calculo
                                                   ,slc.cc_calculo
                                                   ,slc.projeto_calculo
                                                   ,slc.conta_calculo
                                                   --
                                                   ,slc.indice
                                                   ,slc.tipo
                                                   ,slc.seq
                                                   ,slc.calc_rateio_id_pai
                                          HAVING (SUM(slc.rateio) < -0.0001 OR SUM(slc.rateio) > 0.0001) AND SUM(slc.valor) <> 0
                                           ORDER BY slc.area_calculo
                                                   ,slc.periodo
                                                   ,slc.livro
                                                   ,slc.cc_calculo
                                                   ,slc.conta_calculo
                                                   ,slc.seq) s;
      --
      g_nCalc_Ct := g_nCalc_Ct + SQL%ROWCOUNT;
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'Erro ao inserir rateio do registro da etapa ' || p_etapa || ', na tabela BOLINF.XX_OPM_CALC_RATEIO, procedimento BOLINF.XX_OPM_RATEIO_PKG.ETP_ANT_IND_21603_P - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20200, p_errbuf);
    END;
  END etp_ant_ind_21603_p;
  -- ---------------------------------------------------------------------- --
  -- Procedure para unificar os comandos de mensagens no codigo ao imprimir --
  -- as mensagens no Log do concurrent e no output do PL/SQL.               --
  -- ---------------------------------------------------------------------- --
  PROCEDURE log_p ( p_msg IN VARCHAR2 ) IS
  BEGIN
    --DBMS_OUTPUT.PUT_LINE(p_msg); -- USAR APENAS EM TESTES, NAO ENVIAR PARA PRODUCAO POR O LOG ESTOURA COM QTD GRANDE DE REGISTROS!!!
    APPS.FND_FILE.PUT_LINE(APPS.FND_FILE.LOG, p_msg);
  END log_p;
  -- ---------------------------------------------------------------------- --
  -- Procedure para unificar os comandos de mensagens no codigo ao imprimir --
  -- as mensagens na saida do concurrent e no output do PL/SQL.             --
  -- ---------------------------------------------------------------------- --
  PROCEDURE print_p ( p_msg IN VARCHAR2 ) IS
  BEGIN
    --DBMS_OUTPUT.PUT_LINE(p_msg); -- USAR APENAS EM TESTES, NAO ENVIAR PARA PRODUCAO POR O LOG ESTOURA COM QTD GRANDE DE REGISTROS!!!
    APPS.FND_FILE.PUT_LINE ( APPS.FND_FILE.OUTPUT, p_msg);
  END print_p;
  -- -------------------------------------------------- --
  -- Relatorio dos calculos (agrupados).                --
  -- Executavel e Concurrent:                           --
  -- XX_OPM_REL_CALC_RATEIO                             --
  -- XX OPM Relatorio de Calculos do Rateio (Sintetico) --
  -- -------------------------------------------------- --
  PROCEDURE rel_rateio_sintet_p ( p_errbuf      OUT VARCHAR2
                                 ,p_retcode     OUT NUMBER
                                 ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                 ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
                                 ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                                 ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_original%TYPE
                                 ,p_c_custo     bolinf.xx_opm_calc_rateio.cc_original%TYPE ) IS
    CURSOR c_1 ( pc_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                ,pc_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
                ,pc_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                ,pc_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_original%TYPE
                ,pc_c_custo     bolinf.xx_opm_calc_rateio.cc_original%TYPE ) IS
      SELECT calc.etapa
            ,calc.periodo
            ,calc.ledger_id
            ,calc.livro
            ,calc.u_produtiva_enviando
            ,calc.produto_enviando
            ,calc.cc_enviando
            ,calc.projeto_enviando
            ,calc.u_produtiva_recebendo
            ,calc.produto_recebendo
            ,calc.cc_recebendo
            ,calc.projeto_recebendo
            ,calc.u_produtiva_original
            ,calc.produto_original
            ,calc.cc_original
            ,calc.projeto_original
            ,calc.u_produtiva_calculo
            ,calc.produto_calculo
            ,calc.cc_calculo
            ,calc.projeto_calculo
            ,calc.area_calculo
            ,calc.conta_calculo
            ,calc.valor
            ,calc.indice
            ,SUM(calc.rateio) rateio
            ,calc.tipo
        FROM bolinf.xx_opm_calc_rateio calc
       WHERE calc.ledger_id  = pc_ledger_id
         AND calc.periodo    = pc_periodo
         AND calc.tipo       IN ('ENVIADO','RECEBIDO')
         -- ---------------------------------------------------------------- --
         -- Nao confundir o parametro PC_AREA com o campo AREA_CALCULO, pois --
         -- este campo eh derivado dos calculos e nao representa as ETAPAS.  --
         -- Apesar do nome, o parametro PC_AREA devera filtrar as etapas!    --
         -- Ex.: se o parametro P_AREA do concurrent for 'RH', entao devera  --
         --      filtrar os registros das etapas RH-21603 e RH, se for 'IND' --
         --      devera selecionar os registros de IND-21603 e IND.          --
         -- ---------------------------------------------------------------- --
         AND (pc_area IS NULL OR ((pc_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                  (pc_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                  (calc.etapa = pc_area)))
         AND (pc_u_produtiva IS NULL OR calc.u_produtiva_original = pc_u_produtiva) -- Solicitado pelo key user em 12/07/2019
         AND (pc_c_custo     IS NULL OR calc.cc_original = pc_c_custo)              -- Solicitado pelo key user em 12/07/2019
      --HAVING SUM(calc.rateio) NOT BETWEEN -0.0001 AND 0.0001
       GROUP BY calc.etapa
               ,calc.periodo
               ,calc.ledger_id
               ,calc.livro
               ,calc.u_produtiva_enviando
               ,calc.produto_enviando
               ,calc.cc_enviando
               ,calc.projeto_enviando
               ,calc.u_produtiva_recebendo
               ,calc.produto_recebendo
               ,calc.cc_recebendo
               ,calc.projeto_recebendo
               ,calc.u_produtiva_original
               ,calc.produto_original
               ,calc.cc_original
               ,calc.projeto_original
               ,calc.u_produtiva_calculo
               ,calc.produto_calculo
               ,calc.cc_calculo
               ,calc.projeto_calculo
               ,calc.area_calculo
               ,calc.conta_calculo
               ,calc.valor
               ,calc.indice
               ,calc.tipo;
  BEGIN
    print_p ( 'XX OPM Relatorio de Calculos do Rateio (Sintetico)' || CHR(13) ||
              'Livro: '   || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id )|| CHR(13) ||
              'Periodo: ' || p_periodo || CHR(13) ||
              'Area: '    || NVL(p_area,'Todas')  || CHR(13) ||
              'Unid. Produtiva (original): ' || NVL(p_u_produtiva,'Todas') || CHR(13) ||
              'Centro Custo (original): '    || NVL(p_c_custo,'Todos') || CHR(13) ||
              'Tipo: ENVIADO e RECEBIDO' || CHR(13) || CHR(13));
    --
    print_p ( 'ETAPA;'                 ||
              'PERIODO;'               ||
              'U_PRODUTIVA_ENVIANDO;'  ||
              'PRODUTO_ENVIANDO;'      ||
              'CC_ENVIANDO;'           ||
              'PROJETO_ENVIANDO;'      ||
              'U_PRODUTIVA_RECEBENDO;' ||
              'PRODUTO_RECEBENDO;'     ||
              'CC_RECEBENDO;'          ||
              'PROJETO_RECEBENDO;'     ||
              'U_PRODUTIVA_ORIGINAL;'  ||
              'PRODUTO_ORIGINAL;'      ||
              'CC_ORIGINAL;'           ||
              'PROJETO_ORIGINAL;'      ||
              'U_PRODUTIVA_CALCULO;'   ||
              'PRODUTO_CALCULO;'       ||
              'CC_CALCULO;'            ||
              'PROJETO_CALCULO;'       ||
              'AREA_CALCULO;'          ||
              'CONTA_CALCULO;'         ||
              'VALOR;'                 ||
              'INDICE;'                ||
              'RATEIO;'                ||
              'TIPO;' );
    --
    FOR r_1 IN c_1 ( pc_ledger_id   => p_ledger_id
                    ,pc_periodo     => p_periodo
                    ,pc_area        => p_area
                    ,pc_u_produtiva => p_u_produtiva
                    ,pc_c_custo     => p_c_custo ) LOOP
      print_p ( r_1.etapa                 ||';'||
                r_1.periodo               ||';'||
                r_1.u_produtiva_enviando  ||';'||
                r_1.produto_enviando      ||';'||
                r_1.cc_enviando           ||';'||
                r_1.projeto_enviando      ||';'||
                r_1.u_produtiva_recebendo ||';'||
                r_1.produto_recebendo     ||';'||
                r_1.cc_recebendo          ||';'||
                r_1.projeto_recebendo     ||';'||
                r_1.u_produtiva_original  ||';'||
                r_1.produto_original      ||';'||
                r_1.cc_original           ||';'||
                r_1.projeto_original      ||';'||
                r_1.u_produtiva_calculo   ||';'||
                r_1.produto_calculo       ||';'||
                r_1.cc_calculo            ||';'||
                r_1.projeto_calculo       ||';'||
                r_1.area_calculo          ||';'||
                r_1.conta_calculo         ||';'||
                r_1.valor                 ||';'||
                r_1.indice                ||';'||
                r_1.rateio                ||';'||
                r_1.tipo );
    END LOOP;
  END rel_rateio_sintet_p;
  --
  PROCEDURE rel_rateio_analit_p ( p_errbuf      OUT VARCHAR2
                                 ,p_retcode     OUT NUMBER
                                 ,p_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                 ,p_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
                                 ,p_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                                 ,p_tipo        bolinf.xx_opm_calc_rateio.tipo%TYPE
                                 ,p_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_original%TYPE
                                 ,p_c_custo     bolinf.xx_opm_calc_rateio.cc_original%TYPE ) IS
    CURSOR c_1 ( pc_ledger_id   bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                ,pc_periodo     bolinf.xx_opm_calc_rateio.periodo%TYPE
                ,pc_area        bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                ,pc_tipo        bolinf.xx_opm_calc_rateio.tipo%TYPE
                ,pc_u_produtiva bolinf.xx_opm_calc_rateio.u_produtiva_original%TYPE
                ,pc_c_custo     bolinf.xx_opm_calc_rateio.cc_original%TYPE ) IS
      SELECT calc.calc_rateio_id
            ,calc.calc_rateio_id_pai
            ,calc.etapa
            ,calc.periodo
            ,calc.ledger_id
            ,calc.livro
            ,calc.u_produtiva_enviando
            ,calc.produto_enviando
            ,calc.cc_enviando
            ,calc.projeto_enviando
            ,calc.u_produtiva_recebendo
            ,calc.produto_recebendo
            ,calc.cc_recebendo
            ,calc.projeto_recebendo
            ,calc.u_produtiva_original
            ,calc.produto_original
            ,calc.cc_original
            ,calc.projeto_original
            ,calc.u_produtiva_calculo
            ,calc.produto_calculo
            ,calc.cc_calculo
            ,calc.projeto_calculo
            ,calc.area_calculo
            ,calc.conta_calculo
            ,calc.valor
            ,calc.indice
            ,calc.rateio
            ,calc.tipo
            ,calc.seq
            ,calc.iteracao
            ,calc.enviado_gl_interface
            ,calc.data_envio_gl
            ,calc.creation_date
            ,calc.created_by
            ,fu.user_name criado_por
       FROM bolinf.xx_opm_calc_rateio calc
           ,apps.fnd_user             fu
      WHERE calc.created_by = fu.user_id
        AND calc.ledger_id  = pc_ledger_id
        AND calc.periodo    = pc_periodo
        -- ---------------------------------------------------------------- --
        -- Nao confundir o parametro PC_AREA com o campo AREA_CALCULO, pois --
        -- este campo eh derivado dos calculos e nao representa as ETAPAS.  --
        -- Apesar do nome, o parametro PC_AREA devera filtrar as etapas!    --
        -- Ex.: se o parametro P_AREA do concurrent for 'RH', entao devera  --
        --      filtrar os registros das etapas RH-21603 e RH, se for 'IND' --
        --      devera selecionar os registros de IND-21603 e IND.          --
        -- ---------------------------------------------------------------- --
        AND (pc_area IS NULL OR ((pc_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                 (pc_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                 (calc.etapa = pc_area)))
        AND (pc_tipo        IS NULL OR calc.tipo = pc_tipo)
        AND (pc_u_produtiva IS NULL OR calc.u_produtiva_original = pc_u_produtiva) -- Solicitado pelo key user em 12/07/2019
        AND (pc_c_custo     IS NULL OR calc.cc_original = pc_c_custo)              -- Solicitado pelo key user em 12/07/2019
      ORDER BY calc.calc_rateio_id;
  BEGIN
    print_p ( 'XX OPM Relatorio de Calculos do Rateio (Analitico)' || CHR(13) ||
              'Livro: '   || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id ) || CHR(13) ||
              'Periodo: ' || p_periodo || CHR(13) ||
              'Area: '    || NVL(p_area,'Todas')  || CHR(13) ||
              'Tipo: '    || NVL(p_tipo,'Todos')  || CHR(13) ||
              'Unid. Produtiva (original): ' || NVL(p_u_produtiva,'Todas') || CHR(13) ||
              'Centro Custo (original): '    || NVL(p_c_custo,'Todos')     || CHR(13) || CHR(13));
    --
    print_p ( 'CALC_RATEIO_ID;'        ||
              'CALC_RATEIO_ID_PAI;'    ||
              'ETAPA;'                 ||
              'PERIODO;'               ||
              'LEDGER_ID;'             ||
              'LIVRO;'                 ||
              'U_PRODUTIVA_ENVIANDO;'  ||
              'PRODUTO_ENVIANDO;'      ||
              'CC_ENVIANDO;'           ||
              'PROJETO_ENVIANDO;'      ||
              'U_PRODUTIVA_RECEBENDO;' ||
              'PRODUTO_RECEBENDO;'     ||
              'CC_RECEBENDO;'          ||
              'PROJETO_RECEBENDO;'     ||
              'U_PRODUTIVA_ORIGINAL;'  ||
              'PRODUTO_ORIGINAL;'      ||
              'CC_ORIGINAL;'           ||
              'PROJETO_ORIGINAL;'      ||
              'U_PRODUTIVA_CALCULO;'   ||
              'PRODUTO_CALCULO;'       ||
              'CC_CALCULO;'            ||
              'PROJETO_CALCULO;'       ||
              'AREA_CALCULO;'          ||
              'CONTA_CALCULO;'         ||
              'VALOR;'                 ||
              'INDICE;'                ||
              'RATEIO;'                ||
              'TIPO;'                  ||
              'SEQ;'                   ||
              'ITERACAO;'              ||
              'ENVIADO_GL_INTERFACE;'  ||
              'DATA_ENVIO_GL;'         ||
              'DATA_CRICAO;'           ||
              'CRIADO_POR;' );
    --
    FOR r_1 IN c_1 ( pc_ledger_id   => p_ledger_id
                    ,pc_periodo     => p_periodo
                    ,pc_area        => p_area
                    ,pc_tipo        => p_tipo
                    ,pc_u_produtiva => p_u_produtiva
                    ,pc_c_custo     => p_c_custo ) LOOP
      print_p ( r_1.calc_rateio_id        ||';'||
                r_1.calc_rateio_id_pai    ||';'||
                r_1.etapa                 ||';'||
                r_1.periodo               ||';'||
                r_1.ledger_id             ||';'||
                r_1.livro                 ||';'||
                r_1.u_produtiva_enviando  ||';'||
                r_1.produto_enviando      ||';'||
                r_1.cc_enviando           ||';'||
                r_1.projeto_enviando      ||';'||
                r_1.u_produtiva_recebendo ||';'||
                r_1.produto_recebendo     ||';'||
                r_1.cc_recebendo          ||';'||
                r_1.projeto_recebendo     ||';'||
                r_1.u_produtiva_original  ||';'||
                r_1.produto_original      ||';'||
                r_1.cc_original           ||';'||
                r_1.projeto_original      ||';'||
                r_1.u_produtiva_calculo   ||';'||
                r_1.produto_calculo       ||';'||
                r_1.cc_calculo            ||';'||
                r_1.projeto_calculo       ||';'||
                r_1.area_calculo          ||';'||
                r_1.conta_calculo         ||';'||
                r_1.valor                 ||';'||
                r_1.indice                ||';'||
                r_1.rateio                ||';'||
                r_1.tipo                  ||';'||
                r_1.seq                   ||';'||
                r_1.iteracao              ||';'||
                r_1.enviado_gl_interface  ||';'||
                r_1.data_envio_gl         ||';'||
                r_1.creation_date         ||';'||
                r_1.criado_por );
    END LOOP;
  END rel_rateio_analit_p;
  --
  PROCEDURE enviar_rateio_gl_p ( p_errbuf    OUT VARCHAR2
                                ,p_retcode   OUT NUMBER
                                ,p_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                ,p_periodo   bolinf.xx_opm_calc_rateio.periodo%TYPE
                                ,p_area      bolinf.xx_opm_calc_rateio.area_calculo%TYPE 
                                ,p_enviar_gl VARCHAR2 DEFAULT 'N') IS -- Y/N   
    CURSOR c_1 ( pc_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                ,pc_periodo   bolinf.xx_opm_calc_rateio.area_calculo%TYPE
                ,pc_area      bolinf.xx_opm_calc_rateio.area_calculo%TYPE ) IS
      SELECT calc.ledger_id                     --> LEDGER_ID
            ,calc.livro
            ,'BRL' currency_code                --> CURRENCY_CODE
            ,gl_bsv.segment_value companhia     --> SEGMENT1
            ,crc.conta                          --> SEGMENT2 Enviar ESSA Conta para o GL!
            ,cgr.u_negocios                     --> SEGMENT3
            ,calc.produto_calculo               --> SEGMENT4
            ,calc.u_produtiva_calculo           --> SEGMENT5
            ,calc.cc_calculo                    --> SEGMENT6
            ,calc.projeto_calculo               --> SEGMENT7
            ,CASE
               WHEN SUM(calc.rateio) < 0 THEN
                 ABS(SUM(calc.rateio))
             END entered_cr                     --> ENTERED_CR
            ,CASE
              WHEN SUM(calc.rateio) > 0 THEN
                ABS(SUM(calc.rateio))
             END entered_dr                     --> ENTERED_DR
            --
            -- O EBS arredonda das colunas "ACCOUNTED_" ao contabilizar, para evitar
            -- qualquer problema de arredondamento, deixaremos esses campos ja
            -- arredondados com duas casas decimais "ROUND(valor,2)" no envio para a GL_INTERFACE.
            ,CASE
               WHEN SUM(calc.rateio) < 0 THEN
                 ROUND(ABS(SUM(calc.rateio)),2)
             END accounted_cr                   --> ACCOUNTED_CR
            ,CASE
              WHEN SUM(calc.rateio) > 0 THEN
                ROUND(ABS(SUM(calc.rateio)),2)
             END accounted_dr                   --> ACCOUNTED_DR
            ,calc.periodo                       --> PERIOD_NAME
            ,gps.end_date accounting_date
            ,cgc.grupo_conta
            ,cgr.grupo
            ,calc.tipo
            ,crc.origem
            -- RATEIO DE CUSTO: (RH)-21201-1203-000-000000 PARA 21603-3121-000-000000 - VALOR: R$ 5.000,00 - INDICE: 5,67% - (MAI-19)
            -- RETIRAR ORIGINAL E RECEBENDO, MANTER APENAS O "ENVIANDO"
            -- RETIRAR VALOR E INDICE DA MSG abaixo para nao impactar o agrupamento
            ,'RATEIO DE CUSTO: ('|| calc.etapa             ||')-'||
                                calc.u_produtiva_enviando  ||'-'||
                                calc.cc_enviando           ||'-'||
                                calc.produto_enviando      ||'-'||
                                calc.projeto_enviando      ||' '||
                                '('||calc.periodo||')' desc_linha -- DESCRIPTION
            ,calc.etapa
        FROM bolinf.xx_opm_calc_rateio        calc -- Tabela de Calculos
            ,bolinf.xx_opm_cta_x_grp_cta      cgc  -- Conta vs Grupo Conta
            ,bolinf.xx_opm_cc_grupo_rateio    cgr  -- Centro de Custos vs Grupo
            ,bolinf.xx_opm_cta_redutora_custo crc  -- Conta vs Grupo
            ,apps.gl_ledger_le_bsv_specific_v gl_bsv
            ,apps.gl_period_statuses          gps
       WHERE calc.conta_calculo = cgc.conta
         AND calc.cc_calculo    = cgr.centro_custo
         AND cgc.grupo_conta    = crc.grupo_conta
         AND cgr.grupo          = crc.grupo
         AND calc.tipo          = crc.origem -- ENVIADO/RECEBIDO
         AND calc.ledger_id     = gl_bsv.ledger_id
         --
         -- JOIN com livro para recuperar a data final do periodo e enviar para GL_INTERFACE,
         -- o ACCOUNTING_DATE deve ser uma data dentro do periodo que esta sendo processado.
         AND calc.ledger_id     = gps.ledger_id
         AND calc.periodo       = gps.period_name
         AND gps.application_id = 101 /* Fixo General Ledger */
         AND gps.closing_status = 'O' /* Fixo somente periodos Open */
         --
         AND calc.tipo          IN ('ENVIADO','RECEBIDO')
         AND calc.ledger_id     = pc_ledger_id
         AND calc.periodo       = pc_periodo
         -- ---------------------------------------------------------------- --
         -- Nao confundir o parametro PC_AREA com o campo AREA_CALCULO, pois --
         -- este campo eh derivado dos calculos e nao representa as ETAPAS.  --
         -- Apesar do nome, o parametro PC_AREA devera filtrar as etapas!    --
         -- Ex.: se o parametro P_AREA do concurrent for 'RH', entao devera  --
         --      filtrar os registros das etapas RH-21603 e RH, se for 'IND' --
         --      devera selecionar os registros de IND-21603 e IND.          --
         -- ---------------------------------------------------------------- --
         AND (pc_area IS NULL OR ((pc_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                  (pc_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                  (calc.etapa = pc_area)))
         AND NVL(calc.enviado_gl_interface,'N') = 'N'
       GROUP BY calc.ledger_id
               ,calc.livro
               ,gl_bsv.segment_value
               ,crc.conta
               ,cgr.u_negocios
               ,calc.produto_calculo
               ,calc.u_produtiva_calculo
               ,calc.cc_calculo
               ,calc.projeto_calculo
               ,calc.periodo
               ,gps.end_date
               ,cgc.grupo_conta
               ,cgr.grupo
               ,calc.tipo
               ,crc.origem
               ,calc.u_produtiva_enviando
               ,calc.cc_enviando
               ,calc.produto_enviando
               ,calc.projeto_enviando
               ,calc.etapa;
    l_nCt_Inst      NUMBER;
    l_nCt_Updt      NUMBER;
    l_nCt_Inst_Aju  NUMBER;
    l_nRequest_id   NUMBER;
    l_nJe_Batch_Id  NUMBER;
    l_vCompanhia    apps.gl_ledger_le_bsv_specific_v.segment_value%TYPE;
    l_vSegment2     apps.gl_interface.segment2%TYPE;
    l_vSegment3     apps.gl_interface.segment3%TYPE;
    l_vSegment4     apps.gl_interface.segment4%TYPE;
    l_vSegment5     apps.gl_interface.segment5%TYPE;
    l_vSegment6     apps.gl_interface.segment6%TYPE;
    l_vSegment7     apps.gl_interface.segment7%TYPE;
    l_vSegment8     apps.gl_interface.segment8%TYPE;
    l_vReference10  apps.gl_interface.reference10%TYPE;
    l_nEntered_cr   apps.gl_interface.entered_cr%TYPE;
    l_nEntered_dr   apps.gl_interface.entered_dr%TYPE;
    l_nAccounted_cr apps.gl_interface.accounted_cr%TYPE;
    l_nAccounted_dr apps.gl_interface.accounted_dr%TYPE;
    l_dAccounting_Date apps.gl_interface.accounting_date%TYPE;
  BEGIN
    l_nCt_Inst  := 0;
    l_nCt_Updt  := 0;
    l_nRequest_id  := APPS.FND_GLOBAL.CONC_REQUEST_ID;
    l_nCt_Inst_Aju := 0;
    --
    -- Gera o Id do lote de registros para GL_INTERFACE.
    IF p_enviar_gl = 'Y' THEN -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020
      BEGIN
        SELECT bolinf.xx_rateio_je_batch_id_s.NEXTVAL
          INTO l_nJe_Batch_Id
          FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'ERRO: Ao gerar valor da sequence BOLINF.XX_RATEIO_JE_BATCH_ID_S - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20210, p_errbuf);
      END;
    END IF;
    --
    print_p ( 'XX OPM Enviar Rateio de Custos para Interface do GL' );
    print_p ( 'LIVRO: '     || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id ) ||CHR(13)||
              'PERIODO: '   || p_periodo            ||CHR(13)||
              'AREA: '      || NVL(p_area,'Todas')  ||CHR(13)||CHR(13));
    print_p ( 'STATUS;'     ||
              'LIVRO;'      ||
              'MOEDA;'      ||
              'COMPANHIA;'  ||
              'CONTA;'      ||
              'U_NEGOCIOS;' ||
              'PRODUTO_CALCULO;'     ||
              'U_PRODUTIVA_CALCULO;' ||
              'CC_CALCULO;'          ||
              'PROJETO_CALCULO;'     ||
              'INTERCOMPANY;'        ||
              --
              'ENTRADA DR;'          ||
              'ENTRADA CR;'          ||
              'CONTABILIZADO DR;'    ||
              'CONTABILIZADO CR;'    ||
              --
              'PERIODO;'             ||
              'DATA CONTABILIDADE;'  ||
              'ACTUAL_FLAG;'         ||
              'CATEGORIA;'           ||
              'ORIGEM;'              ||
              'DATA CRIACAO;'        ||
              'DESCRICAO' );
    --
    FOR r_1 IN c_1 ( pc_ledger_id => p_ledger_id
                    ,pc_periodo   => p_periodo
                    ,pc_area      => p_area ) LOOP
      BEGIN
        IF p_enviar_gl = 'Y' THEN -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020
          INSERT
            INTO apps.gl_interface ( status                  -- 0
                                    ,ledger_id               -- 1
                                    ,currency_code           -- 2
                                    ,segment1                -- 3
                                    ,segment2                -- 4
                                    ,segment3                -- 5
                                    ,segment4                -- 6
                                    ,segment5                -- 7
                                    ,segment6                -- 8
                                    ,segment7                -- 9
                                    ,segment8                -- 10
                                    --
                                    ,entered_dr              -- 11
                                    ,entered_cr              -- 12
                                    ,accounted_dr            -- 14
                                    ,accounted_cr            -- 13
                                    --
                                    ,period_name             -- 15
                                    ,date_created            -- 16
                                    ,created_by              -- 17
                                    ,actual_flag             -- 18
                                    ,user_je_category_name   -- 19
                                    ,user_je_source_name     -- 20
                                    ,accounting_date         -- 21
                                    ,reference10             -- 22
                                    ,request_id              -- 23
                                    ,je_batch_id )           -- 24
                            VALUES ( 'NEW'                   -- 0
                                    ,r_1.ledger_id           -- 1
                                    ,r_1.currency_code       -- 2
                                    ,r_1.companhia           -- 3  -- SEGMENT1
                                    ,r_1.conta               -- 4  -- SEGMENT2
                                    ,r_1.u_negocios          -- 5  -- SEGMENT3
                                    ,r_1.produto_calculo     -- 6  -- SEGMENT4
                                    ,r_1.u_produtiva_calculo -- 7  -- SEGMENT5
                                    ,r_1.cc_calculo          -- 8  -- SEGMENT6
                                    ,r_1.projeto_calculo     -- 9  -- SEGMENT7
                                    ,0                       -- 10 -- SEGMENT8
                                    --
                                    ,r_1.entered_dr          -- 11
                                    ,r_1.entered_cr          -- 12
                                    ,r_1.accounted_dr        -- 13
                                    ,r_1.accounted_cr        -- 14
                                    --
                                    ,r_1.periodo             -- 15
                                    ,SYSDATE                 -- 16
                                    ,APPS.FND_GLOBAL.USER_ID -- 17
                                    ,'A'                     -- 18 -- ACTUAL_FLAG
                                   ,'XX_Rateio_'||r_1.etapa -- 19 -- USER_JE_CATEGORY_NAME -- Rafael S. Nunes (Ninecon) -- 22/10/2019
                                    ,'XX_Rateio_Custos'      -- 20 -- USER_JE_SOURCE_NAME 
                                    ,r_1.accounting_date     -- 21 -- ACCOUNTING_DATE
                                    ,r_1.desc_linha          -- 22 -- REFERENCE10
                                    ,l_nRequest_id           -- 23 -- REQUEST_ID
                                    ,l_nJe_Batch_Id );       -- 24
          l_nCt_Inst := l_nCt_Inst + SQL%ROWCOUNT;
        END IF;
        --
        -- Imprime os registros na saida do concurrent.
        --
        print_p ( 'NEW'                     ||';'||
                  r_1.livro                 ||';'||
                  r_1.currency_code         ||';'||
                  r_1.companhia             ||';'||
                  r_1.conta                 ||';'||
                  r_1.u_negocios            ||';'||
                  r_1.produto_calculo       ||';'||
                  r_1.u_produtiva_calculo   ||';'||
                  r_1.cc_calculo            ||';'||
                  r_1.projeto_calculo       ||';'||
                  '0'                       ||';'||
                  --
                  r_1.entered_dr            ||';'||
                  r_1.entered_cr            ||';'||
                  r_1.accounted_dr          ||';'||
                  r_1.accounted_cr          ||';'||
                  --
                  r_1.periodo               ||';'||
                  r_1.accounting_date       ||';'||
                  'A'                       ||';'||
                  --'XX_Rateio_Custos'        ||';'||
                  'XX_Rateio_'||r_1.etapa   ||';'||
                  'XX_Rateio_Custos'        ||';'||
                  SYSDATE                   ||';'||
                  r_1.desc_linha );
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir lancamento na GL_INTERFACE, area ' || p_area || ', procedimento BOLINF.XX_OPM_RATEIO_PKG.ENVIAR_RATEIO_GL_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20230, p_errbuf);
      END;
    END LOOP;
    --
    BEGIN
      SELECT gl_bsv.segment_value companhia
        INTO l_vCompanhia
        FROM apps.gl_ledger_le_bsv_specific_v gl_bsv
       WHERE gl_bsv.ledger_id = p_ledger_id;
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'Erro ao consultar codigo da Companhia, LEDGER_ID = ' || p_ledger_id || ', no procedimento BOLINF.XX_OPM_RATEIO_PKG.ENVIAR_RATEIO_GL_P - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20250, p_errbuf);
    END;
    --
    -- Consulta data final do Periodo para popular o campo ACCOUNTING_DATE,
    -- esta data precisa estar dentro do periodo que esta sendo processado.
    BEGIN
      SELECT gps.end_date
        INTO l_dAccounting_Date
        FROM apps.gl_period_statuses gps
       WHERE gps.application_id = 101 /* Fixo General Ledger */
         AND gps.closing_status = 'O' /* Fixo somente periodos Open */
         AND gps.ledger_id      = p_ledger_id
         AND gps.period_name    = p_periodo;
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'Erro ao consultar Data Final do periodo ' || p_periodo || ' e LEDGER_ID = ' || p_ledger_id || ', no procedimento BOLINF.XX_OPM_RATEIO_PKG.ENVIAR_RATEIO_GL_P - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20255, p_errbuf);
    END;
    -- --------------------------------------------------------------------------- --
    -- Verifica se existe diferenca entre Contabilizado Debito/Credito, se houver, --
    -- devera criar um novo lancamento (por categoria) na GL_INTERFACE para zerar  --
    -- essa diferenca.                                                             --
    -- --------------------------------------------------------------------------- --
    /*FOR r_1 IN ( SELECT ROUND(SUM(gl.accounted_dr) - SUM(gl.accounted_cr),2) dif
                       ,gl.user_je_category_name
                       ,gl.user_je_source_name
                   FROM gl_interface gl
                  WHERE gl.user_je_source_name = 'XX_Rateio_Custos'
                    AND gl.je_batch_id         = l_nJe_Batch_Id
                  GROUP BY gl.user_je_category_name
                          ,gl.user_je_source_name
                 HAVING ROUND(SUM(gl.accounted_dr) - SUM(gl.accounted_cr),2) <> 0 ) LOOP*/
    -- --------------------------------------------------------------------------- --
    -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020                          --
    -- Em virtude da solicitaco do SD 119351, a verificacao passa a ser feita nas  --
    -- tabelas de origem e nao mais  na GL_INTERFACE.  Quando o usuario solicitar  --
    -- que seja impresso apenas o relatorio, a GL_INTERFACE nao sera populada como --
    -- era anteriormente.                                                          --
    -- --------------------------------------------------------------------------- --
    -- Verifica se existe diferenca entre Contabilizado Debito/Credito, se houver, --
    -- devera criar um novo lancamento (por categoria) na GL_INTERFACE para zerar  --
    -- essa diferenca.                                                             --
    -- --------------------------------------------------------------------------- --
    FOR r_1 IN ( --SELECT NVL(slc.accounted_dr,0) - NVL(slc.accounted_cr,0) AS dif
                 SELECT SUM(NVL(slc.accounted_dr,0)) - SUM(NVL(slc.accounted_cr,0)) AS dif
                       ,slc.user_je_category_name   
                       ,slc.user_je_source_name
                   FROM (-- O EBS arredonda das colunas "ACCOUNTED_" ao contabilizar, para evitar
                         -- qualquer problema de arredondamento, deixaremos esses campos ja
                         -- arredondados com duas casas decimais "ROUND(valor,2)" no envio para a GL_INTERFACE.
                         SELECT CASE
                                  WHEN SUM(calc.rateio) < 0 THEN
                                    ROUND(ABS(SUM(calc.rateio)),2)
                                END accounted_cr
                               ,CASE
                                  WHEN SUM(calc.rateio) > 0 THEN
                                    ROUND(ABS(SUM(calc.rateio)),2)
                                END accounted_dr
                               ,'XX_Rateio_'||calc.etapa AS user_je_category_name
                               ,'XX_Rateio_Custos'       AS user_je_source_name
                           FROM bolinf.xx_opm_calc_rateio        calc -- Tabela de Calculos
                               ,bolinf.xx_opm_cta_x_grp_cta      cgc  -- Conta vs Grupo Conta
                               ,bolinf.xx_opm_cc_grupo_rateio    cgr  -- Centro de Custos vs Grupo
                               ,bolinf.xx_opm_cta_redutora_custo crc  -- Conta vs Grupo
                               ,apps.gl_ledger_le_bsv_specific_v gl_bsv
                               ,apps.gl_period_statuses          gps
                          WHERE calc.conta_calculo = cgc.conta
                            AND calc.cc_calculo    = cgr.centro_custo
                            AND cgc.grupo_conta    = crc.grupo_conta
                            AND cgr.grupo          = crc.grupo
                            AND calc.tipo          = crc.origem -- ENVIADO/RECEBIDO
                            AND calc.ledger_id     = gl_bsv.ledger_id
                            --
                            -- JOIN com livro para recuperar a data final do periodo e enviar para GL_INTERFACE,
                            -- o ACCOUNTING_DATE deve ser uma data dentro do periodo que esta sendo processado.
                            AND calc.ledger_id     = gps.ledger_id
                            AND calc.periodo       = gps.period_name
                            AND gps.application_id = 101 /* Fixo General Ledger */
                            AND gps.closing_status = 'O' /* Fixo somente periodos Open */
                            --
                            AND calc.tipo          IN ('ENVIADO','RECEBIDO')
                            AND calc.ledger_id     = p_ledger_id
                            AND calc.periodo       = p_periodo
                            -- ---------------------------------------------------------------- --
                            -- Nao confundir o parametro PC_AREA com o campo AREA_CALCULO, pois --
                            -- este campo eh derivado dos calculos e nao representa as ETAPAS.  --
                            -- Apesar do nome, o parametro PC_AREA devera filtrar as etapas!    --
                            -- Ex.: se o parametro P_AREA do concurrent for 'RH', entao devera  --
                            --      filtrar os registros das etapas RH-21603 e RH, se for 'IND' --
                            --      devera selecionar os registros de IND-21603 e IND.          --
                            -- ---------------------------------------------------------------- --
                            AND (p_area IS NULL OR ((p_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                                    (p_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                                    (calc.etapa = p_area)))
                            AND NVL(calc.enviado_gl_interface,'N') = 'N'
                          --
                          -- Manter agrupamento como no cursor original, mesmo nao exibindo 
                          -- todos os campos, como os valores sao pequenos, podem zerar o SUM!
                          GROUP BY calc.ledger_id
                                  ,calc.livro
                                  ,gl_bsv.segment_value
                                  ,crc.conta
                                  ,cgr.u_negocios
                                  ,calc.produto_calculo
                                  ,calc.u_produtiva_calculo
                                  ,calc.cc_calculo
                                  ,calc.projeto_calculo
                                  ,calc.periodo
                                  ,gps.end_date
                                  ,cgc.grupo_conta
                                  ,cgr.grupo
                                  ,calc.tipo
                                  ,crc.origem
                                  ,calc.u_produtiva_enviando
                                  ,calc.cc_enviando
                                  ,calc.produto_enviando
                                  ,calc.projeto_enviando
                                  ,calc.etapa ) slc
                  --WHERE (NVL(slc.accounted_dr,0) - NVL(slc.accounted_cr,0)) <> 0 
                  HAVING (SUM(NVL(slc.accounted_dr,0)) - SUM(NVL(slc.accounted_cr,0))) <> 0
                  GROUP BY slc.user_je_category_name   
                          ,slc.user_je_source_name ) LOOP
      --
      -- Rafael S. Nunes (Ninecon) -- SD 119351 -- fim
      --
      --IF r_1.dif <> 0 THEN
        l_vSegment2     := '571998';
        l_vSegment3     := '35';
        l_vSegment4     := '000';
        l_vSegment5     := '21604';
        l_vSegment6     := '1253';
        l_vSegment7     := '000000';
        l_vSegment8     := '0';
        l_vReference10  := 'AJUSTE ARREDONDAMENTO RATEIO DE CUSTOS INDIRETOS ' || p_periodo;
        l_nEntered_cr   := NULL;
        l_nEntered_dr   := NULL;
        l_nAccounted_cr := NULL;
        l_nAccounted_dr := NULL;
        -- --------------------------------------------------------- --
        -- Os valores serao determinados se serao gravados no debito --
        -- ou credito se a diferenca for positiva ou negativa.       --
        -- --------------------------------------------------------- --
        /*IF r_1.dif < 0 THEN
          l_nEntered_cr   := r_1.dif;
          l_nAccounted_cr := r_1.dif;
        ELSIF l_nDif > 0 THEN
          l_nEntered_dr   := r_1.dif;
          l_nAccounted_dr := r_1.dif;
        END IF;*/

        IF r_1.dif < 0 THEN
          l_nEntered_dr   := r_1.dif*-1; -- Debito (converter os valores negativos em positivos)
          l_nAccounted_dr := r_1.dif*-1; -- Debito (converter os valores negativos em positivos)
        ELSIF r_1.dif > 0 THEN
          l_nEntered_cr   := r_1.dif;    -- Credito
          l_nAccounted_cr := r_1.dif;    -- Credito
        END IF;
        -- -------------------------------------------------------------------- --
        -- Regra definida pelo key user Arlei Campos em 08/07/2019 via Skype.   --
        -- Combinacao contabil padrao para zerar a diferenca na contabilizacao: --
        -- ANGELICA: 203-571998-35-000-21604-1253-000000-0                      --
        -- UMA:      202-571998-35-000-21604-1253-000000-0                      --
        -- -------------------------------------------------------------------- --
        IF p_enviar_gl = 'Y' THEN -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020
          BEGIN        
            INSERT
              INTO apps.gl_interface ( status                  -- 0
                                      ,ledger_id               -- 1
                                      ,currency_code           -- 2
                                      ,segment1                -- 3
                                      ,segment2                -- 4
                                      ,segment3                -- 5
                                      ,segment4                -- 6
                                      ,segment5                -- 7
                                      ,segment6                -- 8
                                      ,segment7                -- 9
                                      ,segment8                -- 10
                                      --
                                      ,entered_dr              -- 11
                                      ,entered_cr              -- 12
                                      ,accounted_dr            -- 14
                                      ,accounted_cr            -- 13
                                      --
                                      ,period_name             -- 15
                                      ,date_created            -- 16
                                      ,created_by              -- 17
                                      ,actual_flag             -- 18
                                      ,user_je_category_name   -- 19
                                      ,user_je_source_name     -- 20
                                      ,accounting_date         -- 21
                                      ,reference10             -- 22
                                      ,request_id              -- 23
                                      ,je_batch_id )           -- 24
                              VALUES ( 'NEW'                   -- 0
                                      ,p_ledger_id             -- 1
                                      ,'BRL'                   -- 2
                                      ,l_vCompanhia            -- 3  -- SEGMENT1
                                      ,l_vSegment2             -- 4  -- SEGMENT2 (fixo)
                                      ,l_vSegment3             -- 5  -- SEGMENT3 (fixo)
                                      ,l_vSegment4             -- 6  -- SEGMENT4 (fixo)
                                      ,l_vSegment5             -- 7  -- SEGMENT5 (fixo)
                                      ,l_vSegment6             -- 8  -- SEGMENT6 (fixo)
                                      ,l_vSegment7             -- 9  -- SEGMENT7 (fixo)
                                      ,l_vSegment8             -- 10 -- SEGMENT8 (fixo)
                                      --
                                      ,l_nEntered_dr           -- 11 -- ENTERED_DR
                                      ,l_nEntered_cr           -- 12 -- ENTERED_CR
                                      ,l_nAccounted_dr         -- 13 -- ACCOUNTED_DR
                                      ,l_nAccounted_cr         -- 14 -- ACCOUNTED_CR
                                      --
                                      ,p_periodo               -- 15
                                      ,SYSDATE                 -- 16
                                      ,APPS.FND_GLOBAL.USER_ID -- 17
                                      ,'A'                     -- 18 -- ACTUAL_FLAG
                                      ,r_1.user_je_category_name -- 19 -- USER_JE_CATEGORY_NAME
                                      ,r_1.user_je_source_name   -- 20 -- USER_JE_SOURCE_NAME -- XX_Rateio_Custos
                                      ,l_dAccounting_Date        -- 21 -- ACCOUNTING_DATE
                                      ,l_vReference10            -- 22 -- REFERENCE10 (Desc. Linha)
                                      ,l_nRequest_id             -- 23 -- REQUEST_ID
                                      ,l_nJe_Batch_Id );         -- 24
            --
            l_nCt_Inst_Aju := l_nCt_Inst_Aju + SQL%ROWCOUNT;
          EXCEPTION
            WHEN OTHERS THEN
              p_retcode := -2;
              p_errbuf  := 'Erro ao inserir lancamento da diferenca Contabilizado Credito - Contabilizado Debito (ACCOUNTED_DR - ACCOUNTED_CR), na GL_INTERFACE, area ' || p_area || ', procedimento BOLINF.XX_OPM_RATEIO_PKG.ENVIAR_RATEIO_GL_P - ' || SQLERRM;
              RAISE_APPLICATION_ERROR(-20260, p_errbuf);
          END;
        END IF;
        --
        -- Imprime os registro do ajuste que acabou de ser inserido.
        --
        print_p ( 'NEW'              ||';'||
                  desc_livro_f ( p_errbuf, p_retcode, p_ledger_id ) ||';'||
                  'BRL'              ||';'||
                  l_vCompanhia       ||';'|| -- companhia
                  l_vSegment2        ||';'|| -- conta
                  l_vSegment3        ||';'|| -- u_negocios
                  l_vSegment4        ||';'|| -- produto_calculo
                  l_vSegment5        ||';'|| -- u_produtiva_calculo
                  l_vSegment6        ||';'|| -- cc_calculo
                  l_vSegment7        ||';'|| -- projeto_calculo
                  l_vSegment8        ||';'|| -- 0
                  --
                  l_nEntered_dr      ||';'||
                  l_nEntered_cr      ||';'||
                  l_nAccounted_dr    ||';'||
                  l_nAccounted_cr    ||';'||
                  --
                  p_periodo          ||';'||
                  l_dAccounting_Date ||';'||
                  'A'                ||';'||
                  --'XX_Rateio_Custos' ||';'||
                  --'XX_Rateio_Custos' ||';'||
                  r_1.user_je_category_name ||';'||
                  r_1.user_je_source_name   ||';'||
                  SYSDATE            ||';'||
                  l_vReference10 );
      --END IF;
    END LOOP;
    --
    IF p_enviar_gl = 'Y' THEN -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020
      IF l_nCt_Inst > 0 THEN
        log_p ('Obs.: Foi/foram criado(s) ' || l_nCt_Inst_Aju || ' lancamento(s) de ajuste de arredondamento do Rateio na GL_INTERFACE.');
        log_p ('--');
        BEGIN
          UPDATE bolinf.xx_opm_calc_rateio calc
             SET calc.enviado_gl_interface = 'S'
                ,calc.data_envio_gl     = SYSDATE
                ,calc.last_updated_by   = APPS.FND_GLOBAL.USER_ID
                ,calc.last_update_login = APPS.FND_GLOBAL.LOGIN_ID
                ,calc.last_update_date  = SYSDATE
           WHERE calc.ledger_id = p_ledger_id
             AND calc.periodo   = p_periodo
             AND (p_area IS NULL OR ((p_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                     (p_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                     (calc.etapa = p_area)));
          --
          l_nCt_Updt := SQL%ROWCOUNT;
          IF l_nCt_Updt > 0 THEN
            log_p ('Clique em ''Verificar Saida'' na tela de solicitacoes para exibir os dados enviados.');
            log_p ('--');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            p_retcode := -2;
            p_errbuf  := 'Erro ao atualizar registros na tabela BOLINF.XX_OPM_CALC_RATEIO, no procedimento BOLINF.XX_OPM_RATEIO_PKG.ENVIAR_RATEIO_GL_P - ' || SQLERRM;
            RAISE_APPLICATION_ERROR(-20270, p_errbuf);
        END;
      END IF;    
      --
      log_p ('Registros inseridos na interface (GL_INTERFACE).: ' || l_nCt_Inst);
      log_p ('Registros atualizados na tabela de calculos.....: ' || l_nCt_Updt);
    END IF;
  END enviar_rateio_gl_p;
  --
  FUNCTION etapa_processada_f ( p_errbuf      OUT VARCHAR2
                               ,p_retcode     OUT NUMBER
                               ,p_ledger_id   IN bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                               ,p_periodo     IN bolinf.xx_opm_calc_rateio.periodo%TYPE
                               ,p_etapa       IN bolinf.xx_opm_calc_rateio.etapa%TYPE ) RETURN VARCHAR2 IS -- S/N (Sim/Nao)
    l_nCt     NUMBER;
    l_vReturn VARCHAR2(1);
  BEGIN
    l_vReturn := 'X';
    -- ---------------------------------------------------------------------------- --
    -- Verifica se a etapa ja foi processada anteriormente e se ja foi enviada para --
    -- a GL_INTERFACE para o mesmo livro, periodo, etc.                             --
    -- *** Nao usar U_PRODUTIVA na chave, pois este campo vai mudando nas etapas.   --
    -- ---------------------------------------------------------------------------- --
    BEGIN
      SELECT COUNT(1)
        INTO l_nCt
        FROM bolinf.xx_opm_calc_rateio calc
       WHERE calc.ledger_id = p_ledger_id
         AND calc.periodo   = p_periodo
         AND calc.etapa     = p_etapa
         AND NVL(calc.enviado_gl_interface,'N') = 'S'; -- Sim
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'Erro ao consultar calculos feitos anteriormente e enviados para o GL, da etapa ' || p_etapa || ' na function ETAPA_PROCESSADA_F! - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20280, p_errbuf);
    END;
    --
    IF l_nCt > 0 THEN
      log_p ('***************************************************************************************************' ||CHR(13)||
             'ATENCAO: A etapa ' || p_etapa || ' ja foi calculada e enviada para a interface do GL anteriormente.' ||CHR(13)||
             '         A etapa atual e as SEGUINTES, se houver, serao excluidas e deverao ser recalculadas pela  ' ||CHR(13)||
             '         area responsavel!'                                                                          ||CHR(13)||
             '***************************************************************************************************' ||CHR(13)||CHR(13));
      RETURN 'S';  -- Sim
    END IF;
    -- ----------------------------------------------------------------------- --
    -- Verifica se a etapa ja foi processada anteriormente mas ainda nao tenha --
    -- sido enviada para o GL.                                                 --
    -- Nao usar U_PRODUTIVA na chave, pois este campo vai mudando nas etapas.  --
    -- ----------------------------------------------------------------------- --
    BEGIN
      SELECT COUNT(1)
        INTO l_nCt
        FROM bolinf.xx_opm_calc_rateio calc
       WHERE calc.ledger_id = p_ledger_id
         AND calc.periodo   = p_periodo
         AND calc.etapa     = p_etapa
         AND NVL(calc.enviado_gl_interface,'N') = 'N'; -- Nao
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'Erro ao consultar calculos feitos anteriormente, da etapa ' || p_etapa || ' na function ETAPA_PROCESSADA_F! - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20290, p_errbuf);
    END;
    --
    IF l_nCt > 0 THEN
      log_p ('***************************************************************************************' ||CHR(13)||
             'ATENCAO: A etapa ' || p_etapa || ' ja foi calculada anteriormente e sera recalculada.  ' ||CHR(13)||
             '         A etapa atual e as etapas SEGUINTES, se houver, serao excluidas e deverao ser ' ||CHR(13)||
             '         recalculadas pela area responsavel! '                                           ||CHR(13)||
             '***************************************************************************************' ||CHR(13)||CHR(13));
      RETURN 'S';  -- Sim
    END IF;
    --
    RETURN l_vReturn;
  END etapa_processada_f;
  --
  FUNCTION desc_livro_f ( p_errbuf    OUT VARCHAR2
                         ,p_retcode   OUT NUMBER
                         ,p_ledger_id apps.gl_ledgers.ledger_id%TYPE ) RETURN VARCHAR2 IS
    l_vLivro apps.gl_ledgers.name%TYPE;
  BEGIN
    l_vLivro := NULL;
    -- Consulta nome do livro para exibir no log.
    BEGIN
      SELECT gl.name
        INTO l_vLivro
        FROM apps.gl_ledgers gl
       WHERE gl.currency_code = 'BRL'
         AND gl.attribute1    = 'OPERATIVO'
         AND gl.ledger_id     = p_ledger_id;
    EXCEPTION
      WHEN OTHERS THEN
        p_retcode := -2;
        p_errbuf  := 'ERRO: Ao consultar nome do Livro, P_LEDGER_ID = ' || p_ledger_id || ', na function XX_OPM_RATEIO_PKG.DESC_LIVRO_F - ' || SQLERRM;
        RAISE_APPLICATION_ERROR(-20300, p_errbuf);
    END;
    --
    RETURN l_vLivro;
  END desc_livro_f;
  -- -------------------------------------------------- --
  -- Rafael S. Nunes (Ninecon) -- SD 119351 -- Ago/2020 --
  -- -------------------------------------------------- --
  /*PROCEDURE rel_previa_rateio_gl_p ( p_errbuf    OUT VARCHAR2
                                    ,p_retcode   OUT NUMBER
                                    ,p_ledger_id bolinf.xx_opm_calc_rateio.ledger_id%TYPE
                                    ,p_periodo   bolinf.xx_opm_calc_rateio.periodo%TYPE
                                    ,p_area      bolinf.xx_opm_calc_rateio.area_calculo%TYPE ) IS
    l_vSegment2     apps.gl_interface.segment2%TYPE;
    l_vSegment3     apps.gl_interface.segment3%TYPE;
    l_vSegment4     apps.gl_interface.segment4%TYPE;
    l_vSegment5     apps.gl_interface.segment5%TYPE;
    l_vSegment6     apps.gl_interface.segment6%TYPE;
    l_vSegment7     apps.gl_interface.segment7%TYPE;
    l_vSegment8     apps.gl_interface.segment8%TYPE;
    l_vReference10  apps.gl_interface.reference10%TYPE;
    l_nEntered_cr   apps.gl_interface.entered_cr%TYPE;
    l_nEntered_dr   apps.gl_interface.entered_dr%TYPE;
    l_nAccounted_cr apps.gl_interface.accounted_cr%TYPE;
    l_nAccounted_dr apps.gl_interface.accounted_dr%TYPE;
  BEGIN
    print_p ( 'XX OPM Enviar Rateio de Custos para Interface do GL' );
    print_p ( 'LIVRO: '     || desc_livro_f ( p_errbuf, p_retcode, p_ledger_id ) ||CHR(13)||
              'PERIODO: '   || p_periodo            ||CHR(13)||
              'AREA: '      || NVL(p_area,'Todas')  ||CHR(13)||CHR(13));
    print_p ( 'STATUS;'     ||
              'LIVRO;'      ||
              'MOEDA;'      ||
              'COMPANHIA;'  ||
              'CONTA;'      ||
              'U_NEGOCIOS;' ||
              'PRODUTO_CALCULO;'     ||
              'U_PRODUTIVA_CALCULO;' ||
              'CC_CALCULO;'          ||
              'PROJETO_CALCULO;'     ||
              'INTERCOMPANY;'        ||
              --
              'ENTRADA DR;'          ||
              'ENTRADA CR;'          ||
              'CONTABILIZADO DR;'    ||
              'CONTABILIZADO CR;'    ||
              --
              'PERIODO;'             ||
              'DATA CONTABILIDADE;'  ||
              'ACTUAL_FLAG;'         ||
              'CATEGORIA;'           ||
              'ORIGEM;'              ||
              'DATA CRIACAO;'        ||
              'DESCRICAO' );
    --
    FOR r_1 IN c_global_gl ( pc_ledger_id => p_ledger_id
                            ,pc_periodo   => p_periodo
                            ,pc_area      => p_area ) LOOP
      BEGIN        
        --
        -- Imprime os registros na saida do concurrent.
        --
        print_p ( 'NEW'                     ||';'||
                  r_1.livro                 ||';'||
                  r_1.currency_code         ||';'||
                  r_1.companhia             ||';'||
                  r_1.conta                 ||';'||
                  r_1.u_negocios            ||';'||
                  r_1.produto_calculo       ||';'||
                  r_1.u_produtiva_calculo   ||';'||
                  r_1.cc_calculo            ||';'||
                  r_1.projeto_calculo       ||';'||
                  '0'                       ||';'||
                  --
                  r_1.entered_dr            ||';'||
                  r_1.entered_cr            ||';'||
                  r_1.accounted_dr          ||';'||
                  r_1.accounted_cr          ||';'||
                  --
                  r_1.periodo               ||';'||
                  r_1.accounting_date       ||';'||
                  'A'                       ||';'||
                  --'XX_Rateio_Custos'        ||';'||
                  'XX_Rateio_'||r_1.etapa   ||';'||
                  'XX_Rateio_Custos'        ||';'||
                  SYSDATE                   ||';'||
                  r_1.desc_linha );
      EXCEPTION
        WHEN OTHERS THEN
          p_retcode := -2;
          p_errbuf  := 'Erro ao inserir lancamento na GL_INTERFACE, area ' || p_area || ', procedimento BOLINF.XX_OPM_RATEIO_PKG.ENVIAR_RATEIO_GL_P - ' || SQLERRM;
          RAISE_APPLICATION_ERROR(-20230, p_errbuf);
      END;
    END LOOP;    
    -- --------------------------------------------------------------------------- --
    -- Verifica se existe diferenca entre Contabilizado Debito/Credito, se houver, --
    -- devera criar um novo lancamento (por categoria) na GL_INTERFACE para zerar  --
    -- essa diferenca.                                                             --
    -- --------------------------------------------------------------------------- --
    -- Obs.: Esta verificacao tambem eh feita na procedure ENVIAR_RATEIO_GL_P,     --
    --       porem la os registros sao primeiramente inseridos na GL_INTERFACE     --
    --       possibilitando que a validacao seja feita na propria GL_INTERFACE.    --
    -- --------------------------------------------------------------------------- --
    FOR r_dif IN (SELECT NVL(slc.accounted_cr,0) AS accounted_cr
                        ,NVL(slc.accounted_dr,0) AS accounted_dr
                        ,slc.user_je_category_name   
                        ,slc.user_je_source_name
                    FROM (-- O EBS arredonda das colunas "ACCOUNTED_" ao contabilizar, para evitar
                          -- qualquer problema de arredondamento, deixaremos esses campos ja
                          -- arredondados com duas casas decimais "ROUND(valor,2)" no envio para a GL_INTERFACE.
                          SELECT CASE
                                   WHEN SUM(calc.rateio) < 0 THEN
                                     ROUND(ABS(SUM(calc.rateio)),2)
                                 END accounted_cr
                                ,CASE
                                   WHEN SUM(calc.rateio) > 0 THEN
                                     ROUND(ABS(SUM(calc.rateio)),2)
                                 END accounted_dr
                                ,'XX_Rateio_'||calc.etapa AS user_je_category_name
                                ,'XX_Rateio_Custos'       AS user_je_source_name
                            FROM bolinf.xx_opm_calc_rateio        calc -- Tabela de Calculos
                                ,bolinf.xx_opm_cta_x_grp_cta      cgc  -- Conta vs Grupo Conta
                                ,bolinf.xx_opm_cc_grupo_rateio    cgr  -- Centro de Custos vs Grupo
                                ,bolinf.xx_opm_cta_redutora_custo crc  -- Conta vs Grupo
                                ,apps.gl_ledger_le_bsv_specific_v gl_bsv
                                ,apps.gl_period_statuses          gps
                           WHERE calc.conta_calculo = cgc.conta
                             AND calc.cc_calculo    = cgr.centro_custo
                             AND cgc.grupo_conta    = crc.grupo_conta
                             AND cgr.grupo          = crc.grupo
                             AND calc.tipo          = crc.origem -- ENVIADO/RECEBIDO
                             AND calc.ledger_id     = gl_bsv.ledger_id
                             --
                             -- JOIN com livro para recuperar a data final do periodo e enviar para GL_INTERFACE,
                             -- o ACCOUNTING_DATE deve ser uma data dentro do periodo que esta sendo processado.
                             AND calc.ledger_id     = gps.ledger_id
                             AND calc.periodo       = gps.period_name
                             AND gps.application_id = 101 \* Fixo General Ledger *\
                             AND gps.closing_status = 'O' \* Fixo somente periodos Open *\
                             --
                             AND calc.tipo          IN ('ENVIADO','RECEBIDO')
                             AND calc.ledger_id     = p_ledger_id
                             AND calc.periodo       = p_periodo
                             -- ---------------------------------------------------------------- --
                             -- Nao confundir o parametro PC_AREA com o campo AREA_CALCULO, pois --
                             -- este campo eh derivado dos calculos e nao representa as ETAPAS.  --
                             -- Apesar do nome, o parametro PC_AREA devera filtrar as etapas!    --
                             -- Ex.: se o parametro P_AREA do concurrent for 'RH', entao devera  --
                             --      filtrar os registros das etapas RH-21603 e RH, se for 'IND' --
                             --      devera selecionar os registros de IND-21603 e IND.          --
                             -- ---------------------------------------------------------------- --
                             AND (p_area IS NULL OR ((p_area = 'RH' AND calc.etapa IN ('RH','RH-21603')) OR
                                                     (p_area = 'IND' AND calc.etapa IN ('IND','IND-21603')) OR
                                                     (calc.etapa = p_area)))
                             AND NVL(calc.enviado_gl_interface,'N') = 'N'
                           GROUP BY calc.etapa) slc
                   WHERE (slc.accounted_dr - slc.accounted_cr) <> 0) LOOP
      --
      l_vSegment2     := '571998';
      l_vSegment3     := '35';
      l_vSegment4     := '000';
      l_vSegment5     := '21604';
      l_vSegment6     := '1253';
      l_vSegment7     := '000000';
      l_vSegment8     := '0';
      l_vReference10  := 'AJUSTE ARREDONDAMENTO RATEIO DE CUSTOS INDIRETOS ' || p_periodo;
      l_nEntered_cr   := NULL;
      l_nEntered_dr   := NULL;
      l_nAccounted_cr := NULL;
      l_nAccounted_dr := NULL;
      -- --------------------------------------------------------- --
      -- Os valores serao determinados se serao gravados no debito --
      -- ou credito se a diferenca for positiva ou negativa.       --
      -- --------------------------------------------------------- --
      IF r_1.dif < 0 THEN
        l_nEntered_dr   := r_1.dif*-1; -- Debito (converter os valores negativos em positivos)
        l_nAccounted_dr := r_1.dif*-1; -- Debito (converter os valores negativos em positivos)
      ELSIF r_1.dif > 0 THEN
        l_nEntered_cr   := r_1.dif;    -- Credito
        l_nAccounted_cr := r_1.dif;    -- Credito
      END IF;
    END LOOP;                                 
  END rel_previa_rateio_gl_p;*/                                
END xx_opm_rateio_pkg;
/

exit
