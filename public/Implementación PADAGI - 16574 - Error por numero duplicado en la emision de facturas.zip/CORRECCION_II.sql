UPDATE apps.ra_customer_trx_all rct
SET    attribute9 = 'AE', attribute13 = null, attribute14 = null, attribute15 = null
WHERE  customer_trx_id = 14039207;
--1 Registro