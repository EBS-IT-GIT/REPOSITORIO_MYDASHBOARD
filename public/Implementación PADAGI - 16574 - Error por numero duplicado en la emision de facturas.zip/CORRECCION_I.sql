UPDATE apps.ra_customer_trx_all rct
SET    trx_number = 'A-0001-10002167', attribute14 = null
WHERE  customer_trx_id = 14039207;
--1 Registro