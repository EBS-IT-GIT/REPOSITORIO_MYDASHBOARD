UPDATE apps.ra_customer_trx_all
SET    trx_number = 'A-0001-00000645'
WHERE  customer_trx_id IN (14480220,14481232);
--2 Registros