UPDATE apps.ar_payment_schedules_all
SET    trx_number = 'A-0001-00000645'
WHERE  customer_trx_id IN (14481232);
--1 Registro