UPDATE apps.ra_customer_trx_all rct
SET    trx_date = to_date('01-06-2020', 'DD-MM-RRRR')
WHERE  org_id = 194
AND    attribute13 ='AE'
AND    attribute14 IS NULL;
--14 Registros