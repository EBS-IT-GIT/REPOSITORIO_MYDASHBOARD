UPDATE apps.xx_tcg_gasto_acondicionamiento xga
SET FUMIGADA_TARIFA = 0,
        FUMIGADA_IMPORTE = 0,
        LAST_UPDATE_DATE = sysdate
WHERE CARTA_PORTE_ID = 423346
--1