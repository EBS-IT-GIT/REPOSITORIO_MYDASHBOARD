REM $Header: glqblfix.sql 115.0.115103.2 2006/10/20 19:06:10 djogg noship $
REM +=======================================================================+
REM |                Copyright (c) 2000 Oracle Corporation                  |
REM |                    Redwood Shores, California, USA                    |
REM |                         All rights reserved.                          |
REM +=======================================================================+
REM   FILENAME
REM     glqblfix.sql
REM
REM   PURPOSE
REM     Creates the necessary temporary tables for GL_BAL_FIX
REM   NOTES
REM
REM   HISTORY
REM    06/02/06      D J Ogg
REM    03/05/08      MGOWDA            R12 changes
REM
REM dbdrv: none

SET VERIFY OFF
WHENEVER SQLERROR CONTINUE;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

connect &&GL_ACCOUNT/&&GL_PASSWD

REM Create tables and indices 

drop table gl_account_template_gt;
create global temporary table GL_ACCOUNT_TEMPLATE_GT(
bal_seg_value          varchar2(200)      not null,
pure_bsv               varchar2(25)       not null,
code_combination_id    NUMBER(15)         not null,
ni_row                 varchar2(1)        
)
on commit preserve rows;

create unique index gl_account_template_gt_u1 on gl_account_template_gt
(bal_seg_value);

create index gl_account_template_gt_n1 on gl_account_template_gt
(code_combination_id);

create global temporary table GL_BALANCE_FIX_GT(
ledger_id      number(15)		not null,
code_combination_id  number(15)         not null,
account_type         varchar2(1)        not null,
bal_seg_value        varchar2(200)      not null,
period_name	     varchar2(15)       not null,
effective_period_num number(15)         not null,
period_year          number(15)         not null,
quarter_num          number(15)         not null,
period_num           number(15)         not null,
currency_code	     varchar2(15)	not null,
actual_flag          varchar2(1)        not null,
account_combo        varchar2(2000)     null,
budget_version_id    number             null,
encumbrance_type_id  number             null,
problem_type_code    varchar2(30)       not null,
new_balance_dr       number             null,
new_balance_cr       number             null,
old_balance_dr       number             null,
old_balance_cr       number             null,
new_balance_dr_beq   number             null,
new_balance_cr_beq   number             null,
old_balance_dr_beq   number             null,
old_balance_cr_beq   number             null)
on commit preserve rows;

create global temporary table GL_BALANCE_FIX_RE_GT(
code_combination_id    varchar2(200)      not null,
period_name            varchar2(15)       not null,
currency_code          varchar2(15)       not null,
begin_balance_dr       NUMBER             not null,
begin_balance_cr       NUMBER             not null,
begin_balance_dr_beq   NUMBER             not null,
begin_balance_cr_beq   NUMBER             not null
)
on commit preserve rows;

create unique index gl_balance_fix_re_gt_u1 on gl_balance_fix_re_gt 
  (code_combination_id, period_name, currency_code);

create global temporary table GL_OPEN_INTERIM(
code_combination_id  number(15)         not null,
period_name	     varchar2(15)       not null,
ledger_id      number(15)		not null,
currency_code	     varchar2(15)	not null,
period_net_dr	     number             not null,
period_net_cr	     number     	not null,
quarter_to_date_dr   number     	not null,
quarter_to_date_cr   number     	not null,
project_to_date_dr   number     	not null,
project_to_date_cr   number     	not null,
begin_balance_dr     number     	not null,
begin_balance_cr     number     	not null,
period_year	     number(15),
period_num	     number(15),
period_type          varchar2(15),
account_type	     varchar2(1),
bal_seg_value        varchar2(51),
actual_flag          varchar2(1),
encumbrance_type_id  number(15),
budget_version_id    number(15),
template_id          number(15),
translated_flag      varchar2(1),
incremental_flag     varchar2(1),
period_net_dr_beq    number,
period_net_cr_beq    number,
quarter_to_date_dr_beq number,
quarter_to_date_cr_beq number,
project_to_date_dr_beq number,
project_to_date_cr_beq number,
begin_balance_dr_beq number,
begin_balance_cr_beq number,
segment1             varchar2(25),
segment2             varchar2(25),
segment3             varchar2(25),
segment4             varchar2(25),
segment5             varchar2(25),
segment6             varchar2(25),
segment7             varchar2(25),
segment8             varchar2(25),
segment9             varchar2(25),
segment10            varchar2(25), 
segment11            varchar2(25),
segment12            varchar2(25),
segment13            varchar2(25),
segment14            varchar2(25),
segment15            varchar2(25),
segment16            varchar2(25),
segment17            varchar2(25),
segment18            varchar2(25),
segment19            varchar2(25),
segment20            varchar2(25),
segment21            varchar2(25),
segment22            varchar2(25),
segment23            varchar2(25),
segment24            varchar2(25),
segment25            varchar2(25),
segment26            varchar2(25),
segment27            varchar2(25),
segment28            varchar2(25),
segment29            varchar2(25),
segment30            varchar2(25))
on commit preserve rows;

create global temporary table GL_DAILY_OPEN_INT(
ledger_id           NUMBER(15)       NOT NULL,
code_combination_id       NUMBER(15)       NOT NULL,
currency_code             VARCHAR2(15)     NOT NULL,
currency_type             VARCHAR2(1)      NOT NULL,
actual_flag               VARCHAR2(1)      NOT NULL,
period_name               VARCHAR2(15)     NOT NULL,
period_start_date         DATE             NOT NULL,
period_end_date           DATE             NOT NULL,
quarter_start_date        DATE             NOT NULL,
year_start_date           DATE             NOT NULL,
converted_from_currency   VARCHAR2(15),
bal_seg_value             VARCHAR2(25),
period_type               VARCHAR2(15),
period_year               NUMBER(15),
period_num                NUMBER(15),
template_id               NUMBER(15,0),
opening_period_aggregate  NUMBER,
opening_quarter_aggregate NUMBER,
opening_year_aggregate    NUMBER,
period_end_net_income     NUMBER,
period_aggregate1         NUMBER,
period_aggregate2         NUMBER,
period_aggregate3         NUMBER,
period_aggregate4         NUMBER,
period_aggregate5         NUMBER,
period_aggregate6         NUMBER,
period_aggregate7         NUMBER,
period_aggregate8         NUMBER,
period_aggregate9         NUMBER,
period_aggregate10        NUMBER, 
period_aggregate11        NUMBER,
period_aggregate12        NUMBER,
period_aggregate13        NUMBER,
period_aggregate14        NUMBER,
period_aggregate15        NUMBER,
period_aggregate16        NUMBER,
period_aggregate17        NUMBER,
period_aggregate18        NUMBER,
period_aggregate19        NUMBER,
period_aggregate20        NUMBER,
period_aggregate21        NUMBER,
period_aggregate22        NUMBER,
period_aggregate23        NUMBER,
period_aggregate24        NUMBER,
period_aggregate25        NUMBER,
period_aggregate26        NUMBER,
period_aggregate27        NUMBER,
period_aggregate28        NUMBER,
period_aggregate29        NUMBER,
period_aggregate30        NUMBER,
period_aggregate31        NUMBER,
period_aggregate32        NUMBER,
period_aggregate33        NUMBER,
period_aggregate34        NUMBER,
period_aggregate35        NUMBER)
on commit preserve rows;

create global temporary table GL_DAILY_BALANCE_FIX_GT(
ledger_id      number(15)		not null,
code_combination_id  number(15)         not null,
bal_seg_value        varchar2(200)      not null,
effective_date       date               not null,
period_name	     varchar2(15)       not null,
effective_period_num number(15)         not null,
period_year          number(15)         not null,
period_num           number(15)         not null,
period_start_date    date		not null,
period_end_date      date		not null,
quarter_start_date   date               not null,
year_start_date      date               not null, 
currency_code	     varchar2(15)	not null,
currency_type        varchar2(1)        not null,
ni_account_flag      varchar2(1)        not null,
converted_from_currency varchar2(15)    null,
account_combo        varchar2(2000)     null,
problem_type_code    varchar2(30)       not null,
new_balance          number             null,
old_balance          number             null)
on commit preserve rows;

create global temporary table GL_PERIOD_OVERLAP_GT(
from_period_name     varchar2(15)       not null,
to_period_name       varchar2(15)       not null);

create unique index gl_period_overlap_gt_u1 on gl_period_overlap_gt
(from_period_name, to_period_name);

create index gl_period_overlap_gt_n1 on gl_period_overlap_gt
(to_period_name);

create global temporary table GL_PERIOD_ORDER_GT(
current_period_name        varchar2(15)       not null,
previous_period_name       varchar2(15)       not null);

create unique index gl_period_order_gt_u1 on gl_period_order_gt
(current_period_name, previous_period_name);


REM Create grants
grant all on GL_account_template_gt to &&APPS_ACCOUNT;
grant all on GL_balance_fix_gt to &&APPS_ACCOUNT;
grant all on GL_balance_fix_re_gt to &&APPS_ACCOUNT;
grant all on GL_daily_balance_fix_gt to &&APPS_ACCOUNT;
grant all on GL_OPEN_INTERIM to &&APPS_ACCOUNT;
grant all on GL_DAILY_OPEN_INT to &&APPS_ACCOUNT;
grant all on GL_period_overlap_gt to &&APPS_ACCOUNT;
grant all on GL_period_order_gt to &&APPS_ACCOUNT;

REM Analyze tables
analyze table gl_account_template_gt compute statistics for table;
analyze table gl_account_template_gt compute statistics for all indexes;
analyze table gl_balance_fix_gt compute statistics for table;
analyze table gl_balance_fix_re_gt compute statistics for table;
analyze table gl_balance_fix_re_gt compute statistics for all indexes;
analyze table gl_daily_balance_fix_gt compute statistics for table;
analyze table gl_daily_balance_fix_gt compute statistics for all indexes;
analyze table gl_open_interim compute statistics for table;
analyze table gl_open_interim compute statistics for all indexes;
analyze table gl_daily_open_int compute statistics for table;
analyze table gl_daily_open_int compute statistics for all indexes;
analyze table gl_period_overlap_gt compute statistics for table;
analyze table gl_period_overlap_gt compute statistics for all indexes;
analyze table gl_period_order_gt compute statistics for table;
analyze table gl_period_order_gt compute statistics for all indexes;

REM Create necessary synonyms
connect &&APPS_ACCOUNT/&&APPS_PASSWORD
create synonym GL_account_template_gt for &&GL_ACCOUNT..gl_account_template_gt;
create synonym GL_balance_fix_gt for &&GL_ACCOUNT..gl_balance_fix_gt;
create synonym GL_balance_fix_re_gt for &&GL_ACCOUNT..gl_balance_fix_re_gt;
create synonym GL_daily_balance_fix_gt 
       for &&GL_ACCOUNT..gl_daily_balance_fix_gt;
create synonym GL_open_interim for &&GL_ACCOUNT..gl_open_interim;
create synonym GL_daily_open_int for &&GL_ACCOUNT..gl_daily_open_int;
create synonym GL_period_overlap_gt for &&GL_ACCOUNT..gl_period_overlap_gt;
create synonym GL_period_order_gt for &&GL_ACCOUNT..gl_period_order_gt;

commit;
exit;



