REM dbdrv: none
REM +=======================================================================+
REM |    Copyright (c) 1993 Oracle Corporation Belmont, California, USA     |
REM |                         All rights reserved.                          |
REM |    $Header: glbalfix.sql 115.0.115103.3 2006/10/25 20:41:07 djogg noship $       |
REM +=======================================================================+
REM   FILENAME
REM     glbalfix.pls
REM
REM   PURPOSE
REM     Balance Fix script.  Please read associated documentation before
REM     using
REM   NOTES
REM     Example:
REM             sqlplus apps/apps @glbalfix.sql
REM   HISTORY
REM     24-MAY-06        D J Ogg         Created
REM     05-MAR-06        MGOWDA          R12 changes
REM

SET VERIFY OFF
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

SET SERVEROUTPUT ON SIZE 10000;

set pagesize 58
set linesize 132
clear columns
clear breaks
ttitle off
set heading off
set newpage 0
set feedback on

CLEAR BUFFER;


PROMPT
PROMPT This is the GL Balances datafix corruption script.  Please review
PROMPT the documentation thoroughly before running this script.  Please
PROMPT also backup your gl_balances table before running this script
PROMPT unless you are going to run it in reporting mode only.
PROMPT

PAUSE Press RETURN to continue.

ACCEPT book_name PROMPT 'Ledger Name: '

ACCEPT start_period PROMPT 'Start period: '

ACCEPT low_account PROMPT 'Account range low: '
ACCEPT high_account PROMPT 'Account range high: '

ACCEPT user_nm PROMPT 'User: '

ACCEPT fix_data  PROMPT 'Report only (Y/N): '

PROMPT
PROMPT

DECLARE
  PROGRAM_FAILURE EXCEPTION;
  problem_cnt     NUMBER;
  fix_bal_data    BOOLEAN;
  user_id         NUMBER;
  resp_id         NUMBER;
  resp_appl_id    NUMBER;
BEGIN
  dbms_output.enable(10000);
  
  -- Determine if we are fixing data or just reporting
  IF (upper(substr('&fix_data',1,1)) = 'N') THEN
    fix_bal_data := TRUE;
  ELSE
    fix_bal_data := FALSE;
  END IF;

  -- Get the user_id
  BEGIN
    SELECT user_id
    INTO user_id
    FROM fnd_user
    WHERE user_name = '&user_nm';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      dbms_output.put_line('Error 17: The user name provided isn''t a user name that is defined on the system.');
      dbms_output.put_line('Balance corruption fix program aborted. ');
      RETURN;
  END;

  -- Get the responsibility id
  BEGIN
    SELECT responsibility_id, application_id
    INTO resp_id, resp_appl_id
    FROM fnd_responsibility
    WHERE responsibility_key = 'GENERAL_LEDGER_SUPER_USER';
  END;

  -- Set them for the balance fix call
  fnd_global.apps_initialize(user_id, resp_id, resp_appl_id);

  -- Run the balance fix script
  gl_balance_fix.check_balances('&book_name', '&start_period',
                                '&low_account', 
                                '&high_account', fix_bal_data);


  -- Check for failure
  IF (gl_balance_fix.errmsg IS NOT NULL) THEN
    dbms_output.put_line(gl_balance_fix.errmsg);
    dbms_output.put_line('Balance corruption fix program aborted. ');

    -- Make sure all data is rolled back so the report won't find anything
    Rollback;
  ELSE

    -- Check if anything was actually fixed
    problem_cnt := 1;
    IF (    (gl_balance_fix.insert_bal = 0)
        AND (gl_balance_fix.update_bal = 0)
        AND (gl_balance_fix.delete_bal = 0)
        AND (gl_balance_fix.insert_daily_bal = 0)
        AND (gl_balance_fix.update_daily_bal = 0)
        AND (gl_balance_fix.delete_daily_bal = 0)) THEN

      SELECT nvl(count(*),0)
      INTO problem_cnt
      FROM gl_balance_fix_gt;

      IF (problem_cnt = 0) THEN
        SELECT nvl(count(*),0)
        INTO problem_cnt
        FROM gl_daily_balance_fix_gt;
      END IF;
    END IF;

    -- No bad data
    IF (problem_cnt = 0) THEN
      dbms_output.put_line('No bad balances found.');

    -- Bad data, but we are only reporting
    ELSIF (NOT fix_bal_data) THEN
      dbms_output.put_line('Script was run in reporting mode only.  Balances were not fixed');

    -- Bad data that was fixed
    ELSE
      dbms_output.put_line(to_char(gl_balance_fix.insert_bal) 
                           || ' gl_balances rows inserted.');
      dbms_output.put_line(to_char(gl_balance_fix.update_bal) 
                           || ' gl_balances rows updated.');
      dbms_output.put_line(to_char(gl_balance_fix.delete_bal) 
                           || ' gl_balances rows deleted.');
      dbms_output.put_line(to_char(gl_balance_fix.insert_daily_bal) 
                           || ' gl_daily_balances rows inserted.');
      dbms_output.put_line(to_char(gl_balance_fix.update_daily_bal) 
                           || ' gl_daily_balances rows updated.');
      dbms_output.put_line(to_char(gl_balance_fix.delete_daily_bal) 
                           || ' gl_daily_balances rows deleted.');
    END IF;
  END IF;
END;
/
  
REM Get the date and time for the report
column datetime noprint new_value datetime

select        to_char(sysdate,'DD-MON-YY HH24:MI')    datetime
from dual;

set heading on
set newpage 0
set feedback off

ttitle  center  ' ' -
  skip  3  center  'Balance Corruption Fix Results' -
        right   'Date: ' datetime -
  skip  1  right 'Page:      ' sql.pno -
  skip  2 left 'Ledger: ' '&book_name' -
  skip  1 left 'Start Period: ' '&start_period' -
  skip  1 left 'Account Low: ' '&low_account' -
  skip  1 left 'Account High: ' '&high_account' -
	skip 2 center ' '

column account_combo format a65 heading "Account" wrap
column currency_code format a10 heading "Currency" wrap
column period_name   format a15 heading "Period" wrap
column problem       format a25 heading "Problem"
column new_dr        format a27 heading "New Dr"
column new_cr        format a27 heading "New Cr"
column old_dr        format a27 heading "Old Dr"
column old_cr        format a27 heading "Old Cr"
column new_dr_beq    format a27 heading "New Converted Dr"
column new_cr_beq    format a27 heading "New Converted Cr"
column old_dr_beq    format a27 heading "Old Converted Dr"
column old_cr_beq    format a27 heading "Old Converted Cr"

SELECT account_combo, fix.currency_code, period_name, 
       decode(problem_type_code,
         'BAD_PTD', 'Bad PTD Amount',
         'BAD_QTD', 'Bad QTD Amount',
         'BAD_YTD', 'Bad YTD Amount',
         'BAD_PJTD', 'Bad PJTD Amount',
         'EXTRA_ROW', 'Extra Row',
         'DUPLICATE_ROW', 'Duplicate Row'
       ) problem,
       decode(problem_type_code, 
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
          to_char(new_balance_dr, '99G999G999G999G999G990D99')) new_dr, 
       decode(problem_type_code,
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
         to_char(new_balance_cr, '99G999G999G999G999G990D99')) new_cr, 
       decode(problem_type_code,
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
         'BAD_QTD', NULL,
         'BAD_PJTD', NULL,
         decode(fix.currency_code,
           'STAT', '',
           bk.currency_code, decode(sysinfo.efb_upgrade_flag, 'Y',
                         to_char(new_balance_dr_beq,
'99G999G999G999G999G990D99'),''),
           to_char(new_balance_dr_beq, '99G999G999G999G999G990D99'))) new_dr_beq, 
       decode(problem_type_code,
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
         'BAD_QTD', NULL,
         'BAD_PJTD', NULL,
         decode(fix.currency_code,
           'STAT', '',
           bk.currency_code,  decode(sysinfo.efb_upgrade_flag, 'Y',
                         to_char(new_balance_cr_beq,
'99G999G999G999G999G990D99'),''),
           to_char(new_balance_cr_beq, '99G999G999G999G999G990D99'))) new_cr_beq, 
       decode(problem_type_code, 
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
          to_char(old_balance_dr, '99G999G999G999G999G990D99')) old_dr, 
       decode(problem_type_code,
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
         to_char(old_balance_cr, '99G999G999G999G999G990D99')) old_cr, 
       decode(problem_type_code,
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
         'BAD_QTD', NULL,
         'BAD_PJTD', NULL,
         decode(fix.currency_code,
           'STAT', '',
           bk.currency_code, decode(sysinfo.efb_upgrade_flag, 'Y',
                         to_char(old_balance_dr_beq, '99G999G999G999G999G990D99'),''),
           to_char(old_balance_dr_beq, '99G999G999G999G999G990D99'))) old_dr_beq, 
       decode(problem_type_code,
         'EXTRA_ROW', NULL,
         'DUPLICATE_ROW', NULL,
         'BAD_QTD', NULL,
         'BAD_PJTD', NULL,
         decode(fix.currency_code,
           'STAT', '',
           bk.currency_code,  decode(sysinfo.efb_upgrade_flag, 'Y',
                         to_char(old_balance_cr_beq,
'99G999G999G999G999G990D99'),''),
           to_char(old_balance_cr_beq, '99G999G999G999G999G990D99'))) old_cr_beq 
FROM gl_balance_fix_gt fix, gl_ledgers bk, gl_system_usages sysinfo
WHERE bk.ledger_id = fix.ledger_id
ORDER BY account_combo, currency_code, effective_period_num
/

set heading on
set feedback off

ttitle  center  ' ' -
  skip  3  center  'Daily Balance Corruption Fix Results' -
        right   'Date: ' datetime -
  skip  1  right 'Page:      ' sql.pno -
  skip  2 left 'Set of Books: ' '&book_name' -
  skip  1 left 'Start Period: ' '&start_period' -
  skip  1 left 'Account Low: ' '&low_account' -
  skip  1 left 'Account High: ' '&high_account' -
	skip 2 center ' '

column account_combo format a48 heading "Account" wrap
column currency_code format a10 heading "Currency" wrap
column currency_type format a13 heading "Currency Type" wrap
column period_name   format a15 heading "Period" wrap
column problem       format a25 heading "Problem"
column new_balance   format a27 heading "New Balance"
column old_balance   format a27 heading "Old Balance"
column effective_date format a15 heading "Effective Date"
SELECT account_combo, 
       effective_date,
       period_name, 
       decode(currency_type, 
         'C', fix.converted_from_currency, 
         fix.currency_code) currency_code, 
       decode(fix.currency_type, 
         'U', 'Cumulative',
         'E', 'Entered',
         'C', 'Converted') currency_type,
       decode(problem_type_code,
         'BAD_EOD', 'Bad EOD Amount',
         'BAD_PATD', 'Bad PATD Amount',
         'BAD_QATD', 'Bad QATD Amount',
         'BAD_YATD', 'Bad YATD Amount',
         'EXTRA_ROW', 'Extra Row',
         'DUPLICATE_ROW', 'Duplicate Row'
       ) problem,
       to_char(round(decode(problem_type_code, 
                       'EXTRA_ROW', NULL,
                       'DUPLICATE_ROW', NULL,
                       'BAD_QATD', decode(fix.effective_date 
                                          - fix.quarter_start_date, 
                                          0, new_balance,
                                          new_balance 
                                          / (fix.effective_date 
                                             - fix.quarter_start_date)),
                       'BAD_YATD', decode(fix.effective_date 
                                          - fix.year_start_date, 
                                          0, new_balance,
                                          new_balance 
                                          / (fix.effective_date 
                                             - fix.year_start_date)),
                       new_balance)
                     / decode(cur.minimum_accountable_unit,
                         NULL, power(10, -1 * cur.precision),
                         cur.minimum_accountable_unit))
              * decode(cur.minimum_accountable_unit,
                       NULL, power(10, -1 * cur.precision),
                       cur.minimum_accountable_unit),
              '99G999G999G999G999G990D99') new_balance,
       to_char(round(decode(problem_type_code, 
                       'EXTRA_ROW', NULL,
                       'DUPLICATE_ROW', NULL,
                       'BAD_QATD', decode(fix.effective_date 
                                          - fix.quarter_start_date, 
                                          0, old_balance,
                                          old_balance 
                                          / (fix.effective_date 
                                             - fix.quarter_start_date)),
                       'BAD_YATD', decode(fix.effective_date 
                                          - fix.year_start_date, 
                                          0, old_balance,
                                          old_balance 
                                          / (fix.effective_date 
                                             - fix.year_start_date)),
                       old_balance)
                     / decode(cur.minimum_accountable_unit,
                         NULL, power(10, -1 *cur.precision),
                         cur.minimum_accountable_unit))
              * decode(cur.minimum_accountable_unit,
                       NULL, power(10, -1 *cur.precision),
                       cur.minimum_accountable_unit),
              '99G999G999G999G999G990D99') old_balance
FROM gl_daily_balance_fix_gt fix, fnd_currencies cur
WHERE cur.currency_code = fix.currency_code
ORDER BY account_combo, effective_date, currency_code, 
         decode(currency_type, 'U', 1, 'E', 2, 'C', 3), problem_type_code
/

COMMIT;
EXIT;
