===================================================================================
                    ###  ESBR - Relatório de Fretes  ###                      
===================================================================================
-----------------------------------------------------------------------------------

Mover o arquivo ESBR_RI_REPORT_FRETE.zip para o servidor de aplicação do Oracle 
EBS e seguir os passos a seguir:
   
unzip ESBR_RI_REPORT_FRETE.zip
chmod 777 ESBR_RI_REPORT_FRETE
cd ESBR_RI_REPORT_FRETE
. install.sh
