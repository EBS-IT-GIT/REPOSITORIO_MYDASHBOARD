#!/bin/sh
# Description: ESBR - Relat�rio de Frete
# Versao:      2.0
# Data:        05-Jun-2019
#
# Senha para execu��o dos scripts
echo "Digite a senha do APPS:  "
read -s apps_pass 
#
# DataBase Scripts
echo "Scripts de Banco de Dados"
sqlplus -s apps/$apps_pass << _EOF 

spool ESBR_RI_RELATORIOS_PK.log
set define off;
@database/ESBR_RI_RELATORIOS_PK.pck
spool of
EXIT
_EOF
#
#
# Limpar a vari�vel com a senha do apps.
unset apps_pass
#
echo " "
echo "Verifique os logs de execu��o para confirmar a instala��o"
# Fim do script