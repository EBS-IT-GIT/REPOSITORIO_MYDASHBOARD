UPDATE apps.ra_customer_trx_all rct
SET    attribute9 = 'AE'
     , attribute13= 'AE'
     , attribute14= null
     , attribute15 = null
     , last_update_date = sysdate
     , last_updated_by = -1
     , last_update_login = -1
WHERE  customer_trx_id = 13249087;
--1 Registro