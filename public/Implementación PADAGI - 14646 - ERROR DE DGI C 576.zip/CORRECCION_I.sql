UPDATE apps.ra_customer_trx_all rct
SET    trx_number = 'A-0001-10000576'
     , attribute14 = null
     , last_update_date = sysdate
     , last_updated_by = -1
     , last_update_login = -1
WHERE  customer_trx_id =13249181;
--1 Registro