UPDATE apps.ar_payment_schedules_all rct
SET    trx_number = 'A-0001-10001962', last_update_date = sysdate, last_updated_by = 2070
WHERE  customer_trx_id = 13502176;
--1 Registro