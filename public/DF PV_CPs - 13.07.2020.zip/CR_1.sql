UPDATE apps.XX_TCG_ASOCIA_PEDIDO_VENTA
set asociacion_id = XX_ACO_APLICACION_CONTRATOS_S.nextval,
    last_update_date = sysdate,
    last_updated_by  = 2070
WHERE asociacion_id  =  309845
AND carta_porte_id   = 437319
--1