CREATE OR REPLACE VIEW XXISV_MECVW_NFS_NOTIFICATION AS
SELECT
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_mecvw_NF_NOTIFICATION
--NOME FISICO.........: XXISV_mecvw_NF_NOTIFICATION.SQL
--TIPO_OBJETO.........: VIEW
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--....................: 3.0.002 - OS-01414.004292 - 24/04/2017 - AJUSTE PARA UMA VIEW QUE PODE TRAZER APENAS MERCADORIA OU SERVICO.
--CUSTOMIZACOES.......:
------------------------------------------------------------------------------------------------------------------------
TRANSACTION_ID, CUSTOMER_TRX_ID, ORG_ID, ORGANIZATION_ID, STATUS, EVENT_TYPE_ID
  FROM (SELECT MAX(A.NOTIFICATION_ID) as TRANSACTION_ID,
               A.PARAMETER_VALUE1 as CUSTOMER_TRX_ID,
               A.PARAMETER_VALUE3 as ORG_ID,
               A.PARAMETER_VALUE7 as ORGANIZATION_ID,
               A.EXPORT_STATUS as STATUS,
               A.TRANSACTION_TYPE as EVENT_TYPE_ID,
               --
               (SELECT NVL(rcttP.global_attribute1,
                           NVL(rctt.global_attribute1, 'NFF'))
                  FROM APPS.RA_CUSTOMER_TRX_ALL B,
                       APPS.RA_CUSTOMER_TRX_ALL P,
                       RA_CUST_TRX_TYPES_ALL    RCTT,
                       RA_CUST_TRX_TYPES_ALL    RCTTP
                 WHERE 1 = 1
                   AND TO_NUMBER(A.PARAMETER_VALUE1) = B.CUSTOMER_TRX_ID
                   AND B.PREVIOUS_CUSTOMER_TRX_ID = P.CUSTOMER_TRX_ID(+)
                   AND B.ORG_ID = RCTT.ORG_ID
                   AND B.CUST_TRX_TYPE_ID = RCTT.CUST_TRX_TYPE_ID
                   AND RCTT.TYPE IN ('INV', 'CM', 'DM')
                      --
                   AND P.ORG_ID = RCTTP.ORG_ID (+)
                   AND P.CUST_TRX_TYPE_ID = RCTTP.CUST_TRX_TYPE_ID (+)) COD_DOCUMENTO
                      --
          from apps.CLL_F255_NOTIFICATIONS A
         where 1 = 1
           AND A.EXPORT_STATUS = 1
           and A.ISV_NAME = 'MASTERSAF'
           and A.TRANSACTION_TYPE in ('INSERT', 'UPDATE')
           and A.EVENT_NAME       = 'oracle.apps.cll.ra_customer_trx'
           --and A.PARAMETER_VALUE3 not in (84, 86) --retirando capta e mundpag das emissoes
           and rownum <= 1000
         group by A.PARAMETER_VALUE1,
                  A.PARAMETER_VALUE3,
                  A.PARAMETER_VALUE7,
                  A.EXPORT_STATUS,
                  A.TRANSACTION_TYPE)
 WHERE 1 = 1
   AND COD_DOCUMENTO = '08'
UNION ALL
SELECT
TRANSACTION_ID, CUSTOMER_TRX_ID, ORG_ID, ORGANIZATION_ID, STATUS, EVENT_TYPE_ID
  FROM (SELECT MAX(A.NOTIFICATION_ID) as TRANSACTION_ID,
               A.PARAMETER_VALUE2 as CUSTOMER_TRX_ID,
               A.PARAMETER_VALUE5 as ORG_ID,
               A.PARAMETER_VALUE7 as ORGANIZATION_ID,
               A.EXPORT_STATUS as STATUS,
               A.TRANSACTION_TYPE as EVENT_TYPE_ID,
               --
               (SELECT NVL(rcttP.global_attribute1,
                           NVL(rctt.global_attribute1, 'NFF'))
                  FROM APPS.RA_CUSTOMER_TRX_ALL B,
                       APPS.RA_CUSTOMER_TRX_ALL P,
                       RA_CUST_TRX_TYPES_ALL    RCTT,
                       RA_CUST_TRX_TYPES_ALL    RCTTP
                 WHERE 1 = 1
                   AND TO_NUMBER(A.PARAMETER_VALUE2) = B.CUSTOMER_TRX_ID
                   AND B.PREVIOUS_CUSTOMER_TRX_ID = P.CUSTOMER_TRX_ID(+)
                   AND B.ORG_ID = RCTT.ORG_ID
                   AND B.CUST_TRX_TYPE_ID = RCTT.CUST_TRX_TYPE_ID
                   AND RCTT.TYPE IN ('INV', 'CM', 'DM')
                      --
                   AND P.ORG_ID = RCTTP.ORG_ID (+)
                   AND P.CUST_TRX_TYPE_ID = RCTTP.CUST_TRX_TYPE_ID (+)) COD_DOCUMENTO
        --
          from apps.CLL_F255_NOTIFICATIONS A
         where 1 = 1
           AND A.EXPORT_STATUS = 1
           and A.ISV_NAME = 'MASTERSAF'
           and A.TRANSACTION_TYPE in ('INSERT', 'UPDATE')
           and A.EVENT_NAME       = 'oracle.apps.cll.eb.invoice.actionsNfe'
           --and A.PARAMETER_VALUE3 not in (84, 86) --retirando capta e mundpag das emissoes
           and rownum <= 1000
         group by A.PARAMETER_VALUE2,
                  A.PARAMETER_VALUE5,
                  A.PARAMETER_VALUE7,
                  A.EXPORT_STATUS,
                  A.TRANSACTION_TYPE)
 WHERE 1 = 1
   AND COD_DOCUMENTO = '08'
;
