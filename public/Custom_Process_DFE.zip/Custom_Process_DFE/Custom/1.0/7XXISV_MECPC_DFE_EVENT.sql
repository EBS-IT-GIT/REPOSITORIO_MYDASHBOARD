create or replace package XXISV_MECPC_DFE_EVENT is
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_MEFPC_DFE_EVENT
--NOME FISICO.........: XXISV_MEFPC_DFE_EVENT.SQL
--TIPO_OBJETO.........: PACKAGE
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--CUSTOMIZACOES.......:
------------------------------------------------------------------------------------------------------------------------

  PROCEDURE UPDATE_EVENT_EXTRACTED(P_TRANSACTION_ID IN NUMBER,
                                   P_STATUS         OUT VARCHAR2,
                                   P_MSG            IN VARCHAR2);

  PROCEDURE UPDATE_EVENT_ERROR(P_TRANSACTION_ID IN NUMBER,
                               P_STATUS         OUT VARCHAR2,
                               P_MSG            IN VARCHAR2);

  PROCEDURE DELETE_EVENT(P_TRANSACTION_ID IN NUMBER, P_STATUS OUT VARCHAR2);

  PROCEDURE UPDATE_ATTRIBUTES(P_API_VERSION           IN NUMBER,
                              P_COMMIT                IN VARCHAR2,
                              P_CUSTOMER_TRX_ID       IN NUMBER,
                              P_ELECT_INV_WEB_ADDRESS IN VARCHAR2,
                              P_ELECT_INV_STATUS      IN VARCHAR2,
                              P_ELECT_INV_ACCESS_KEY  IN VARCHAR2,
                              P_ELECT_INV_PROTOCOL    IN VARCHAR2,
                              P_MESSAGE_TEXT          IN VARCHAR2,
                              X_RETURN_STATUS         OUT VARCHAR2,
                              X_MSG_DATA              OUT VARCHAR2);

  PROCEDURE INSERT_LOG(P_API_VERSION      IN NUMBER,
                       P_COMMIT           IN VARCHAR2,
                       P_CUSTOMER_TRX_ID  IN NUMBER,
                       P_OCCURRENCE_DATE  IN DATE,
                       P_ELECT_INV_STATUS IN VARCHAR2,
                       P_MESSAGE_TEXT     IN VARCHAR2,
                       X_RETURN_STATUS    OUT VARCHAR2,
                       X_MSG_DATA         OUT VARCHAR2);

  PROCEDURE PROCESS_RETURN(P_API_VERSION           IN NUMBER,
                           P_COMMIT                IN VARCHAR2,
                           P_CUSTOMER_TRX_ID       IN NUMBER,
                           P_ELECT_INV_WEB_ADDRESS IN VARCHAR2,
                           P_ELECT_INV_STATUS      IN VARCHAR2,
                           P_ELECT_INV_ACCESS_KEY  IN VARCHAR2,
                           P_ELECT_INV_PROTOCOL    IN VARCHAR2,
                           P_MESSAGE_TEXT          IN VARCHAR2,
                           P_OCCURRENCE_DATE       IN DATE,
                           P_STATUS_SEFAZ          IN VARCHAR2,
                           P_DATAHORA_AUTOTIZACAO  IN VARCHAR2,
                           X_RETURN_STATUS         OUT VARCHAR2,
                           X_MSG_DATA              OUT VARCHAR2);

  PROCEDURE PROCESS_RETURN_NFS(P_API_VERSION           IN VARCHAR2,
                               P_COMMIT                IN VARCHAR2,
                               P_CUSTOMER_TRX_ID       IN VARCHAR2,
                               P_ELECT_INV_STATUS      IN VARCHAR2,
                               P_STATUS                IN VARCHAR2,
                               P_DESCRICAO_STATUS      IN VARCHAR2,
                               P_COD_CIDADE            IN VARCHAR2,
                               P_SIAFI_PRESTADOR       IN NUMERIC,
                               P_NUMERO_RPS            IN NUMERIC,
                               P_SERIE_RPS             IN VARCHAR2,
                               P_TIPO_RPS              IN VARCHAR2,
                               P_SITUACAO_RPS          IN VARCHAR2,
                               P_DATA_EMISSAO_RPS      IN VARCHAR2,
                               P_DATA_APROVACAO        IN VARCHAR2,
                               P_DATA_CANCELAMENTO     IN VARCHAR2,
                               P_NUMERO_NFE            IN VARCHAR2,
                               P_CNPJ_PRESTADOR        IN VARCHAR2,
                               P_INSCRICAO_PRESTADOR   IN VARCHAR2,
                               P_ALIQUOTA_SERVICOS     IN NUMERIC,
                               P_VALOR_SERVICOS        IN NUMERIC,
                               P_VALOR_DEDUZIR         IN NUMERIC,
                               P_CODIGO_VERIFICACAO    IN VARCHAR2,
                               P_CODIGO_CANCELAMENTO   IN VARCHAR2,
                               P_NUMERO_LOTE           IN NUMERIC,
                               P_NUMERO_PROTOCOLO      IN VARCHAR2,
                               P_TIPO_AMBIENTE_SISTEMA IN NUMERIC,
                               P_URL_CONSULTA          IN VARCHAR2,
                               P_PREF_BASE_CALCULO     IN NUMERIC,
                               P_PREF_VL_LIQ_NFSE      IN NUMERIC,
                               P_PREF_VL_ISS           IN NUMERIC,
                               X_RETURN_STATUS         OUT VARCHAR2,
                               X_MSG_DATA              OUT VARCHAR2);

end XXISV_MECPC_DFE_EVENT;
/
create or replace package body XXISV_MECPC_DFE_EVENT is
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_MEFPC_DFE_EVENT
--NOME FISICO.........: XXISV_MEFPC_DFE_EVENT.SQL
--TIPO_OBJETO.........: PACKAGE BODY
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--CUSTOMIZACOES.......:
------------------------------------------------------------------------------------------------------------------------

  procedure clean_old_data(P_CUSTOMER_TRX_ID in xxisv_mefsy_nf_notification.customer_trx_id%type) AS
  BEGIN

    delete from xxisv_meftb_nfe_header a where a.customer_trx_id = p_customer_trx_id;
    delete from xxisv_meftb_nfe_cancelamento a where a.customer_trx_id = p_customer_trx_id;
    delete from xxisv_meftb_nfe_inutilizacao a where a.customer_trx_id = p_customer_trx_id;

    delete from xxisv_meftb_nfs_header a where a.customer_trx_id = p_customer_trx_id;
    delete from xxisv_meftb_nfs_cancelamento a where a.customer_trx_id = p_customer_trx_id;
  end;

  PROCEDURE UPDATE_EVENT_EXTRACTED(P_TRANSACTION_ID IN NUMBER,
                                   P_STATUS         OUT VARCHAR2,
                                   P_MSG            IN VARCHAR2) IS
    r_notif  apps.CLL_F255_NOTIFICATIONS%rowtype;
  BEGIN

    select *
      into r_notif
      from apps.CLL_F255_NOTIFICATIONS
     where NOTIFICATION_ID = p_transaction_id;

    XXISV_MEFSY_NOTIFICATIONS_GRP.update_row(P_TRANSACTION_ID,
                                          2,
                                          P_STATUS,
                                          P_MSG);

    if r_notif.EVENT_NAME = 'oracle.apps.cll.ra_customer_trx' then
      -- removendo as linhas duplicadas
      delete from apps.CLL_F255_NOTIFICATIONS
      where PARAMETER_VALUE1 = r_notif.PARAMETER_VALUE1 AND
            PARAMETER_VALUE3 = r_notif.PARAMETER_VALUE3 AND
            PARAMETER_VALUE7 = r_notif.PARAMETER_VALUE7 AND
            EXPORT_STATUS    = r_notif.EXPORT_STATUS    AND
            TRANSACTION_TYPE = r_notif.TRANSACTION_TYPE AND
            EVENT_NAME       = 'oracle.apps.cll.ra_customer_trx' AND
            ISV_NAME         = 'MASTERSAF' AND
            NOTIFICATION_ID != p_transaction_id;

    elsif  r_notif.EVENT_NAME = 'oracle.apps.cll.eb.invoice.actionsNfe' then
      -- removendo as linhas duplicadas
      delete from apps.CLL_F255_NOTIFICATIONS
      where PARAMETER_VALUE2 = r_notif.PARAMETER_VALUE2 AND
            PARAMETER_VALUE5 = r_notif.PARAMETER_VALUE5 AND
            PARAMETER_VALUE7 = r_notif.PARAMETER_VALUE7 AND
            EXPORT_STATUS    = r_notif.EXPORT_STATUS    AND
            TRANSACTION_TYPE = r_notif.TRANSACTION_TYPE AND
            EVENT_NAME       = 'oracle.apps.cll.eb.invoice.actionsNfe' AND
            ISV_NAME         = 'MASTERSAF' AND
            NOTIFICATION_ID != p_transaction_id;
    end if;

  END UPDATE_EVENT_EXTRACTED;

  PROCEDURE UPDATE_EVENT_ERROR(P_TRANSACTION_ID IN NUMBER,
                               P_STATUS         OUT VARCHAR2,
                               P_MSG            IN VARCHAR2) IS
    r_notif  apps.CLL_F255_NOTIFICATIONS%rowtype;
  BEGIN

    select *
      into r_notif
      from apps.CLL_F255_NOTIFICATIONS
     where NOTIFICATION_ID = p_transaction_id;

    XXISV_MEFSY_NOTIFICATIONS_GRP.update_row(P_TRANSACTION_ID,
                                          4,
                                          P_STATUS,
                                          P_MSG);

    if r_notif.EVENT_NAME = 'oracle.apps.cll.ra_customer_trx' then
      -- removendo as linhas duplicadas
      delete from apps.CLL_F255_NOTIFICATIONS
      where PARAMETER_VALUE1 = r_notif.PARAMETER_VALUE1 AND
            PARAMETER_VALUE3 = r_notif.PARAMETER_VALUE3 AND
            PARAMETER_VALUE7 = r_notif.PARAMETER_VALUE7 AND
            EXPORT_STATUS    = r_notif.EXPORT_STATUS    AND
            TRANSACTION_TYPE = r_notif.TRANSACTION_TYPE AND
            EVENT_NAME       = 'oracle.apps.cll.ra_customer_trx' AND
            ISV_NAME         = 'MASTERSAF' AND
            NOTIFICATION_ID != p_transaction_id;

    elsif  r_notif.EVENT_NAME = 'oracle.apps.cll.eb.invoice.actionsNfe' then
      -- removendo as linhas duplicadas
      delete from apps.CLL_F255_NOTIFICATIONS
      where PARAMETER_VALUE2 = r_notif.PARAMETER_VALUE2 AND
            PARAMETER_VALUE5 = r_notif.PARAMETER_VALUE5 AND
            PARAMETER_VALUE7 = r_notif.PARAMETER_VALUE7 AND
            EXPORT_STATUS    = r_notif.EXPORT_STATUS    AND
            TRANSACTION_TYPE = r_notif.TRANSACTION_TYPE AND
            EVENT_NAME       = 'oracle.apps.cll.eb.invoice.actionsNfe' AND
            ISV_NAME         = 'MASTERSAF' AND
            NOTIFICATION_ID != p_transaction_id;
    end if;
  END;

  PROCEDURE DELETE_EVENT(P_TRANSACTION_ID IN NUMBER, P_STATUS OUT VARCHAR2) IS
  BEGIN

    XXISV_MEFSY_NOTIFICATIONS_GRP.delete_row(P_TRANSACTION_ID, P_STATUS);

  END;

  PROCEDURE UPDATE_ATTRIBUTES(P_API_VERSION           IN NUMBER,
                              P_COMMIT                IN VARCHAR2,
                              P_CUSTOMER_TRX_ID       IN NUMBER,
                              P_ELECT_INV_WEB_ADDRESS IN VARCHAR2,
                              P_ELECT_INV_STATUS      IN VARCHAR2,
                              P_ELECT_INV_ACCESS_KEY  IN VARCHAR2,
                              P_ELECT_INV_PROTOCOL    IN VARCHAR2,
                              P_MESSAGE_TEXT          IN VARCHAR2,
                              X_RETURN_STATUS         OUT VARCHAR2,
                              X_MSG_DATA              OUT VARCHAR2) AS
  BEGIN
    --insere e nao atualiza mais enquanto nao voltar o status
    XXISV_MEFSY_JL_BR_SPED_PUB.UPDATE_ATTRIBUTES (P_API_VERSION,
                                      P_COMMIT,
                                      P_CUSTOMER_TRX_ID,
                                      P_ELECT_INV_WEB_ADDRESS,
                                      P_ELECT_INV_STATUS,
                                      P_ELECT_INV_ACCESS_KEY,
                                      P_ELECT_INV_PROTOCOL,
                                      NULL,
                                      X_RETURN_STATUS,
                                      X_MSG_DATA);
  END;

  PROCEDURE INSERT_LOG(P_API_VERSION      IN NUMBER,
                       P_COMMIT           IN VARCHAR2,
                       P_CUSTOMER_TRX_ID  IN NUMBER,
                       P_OCCURRENCE_DATE  IN DATE,
                       P_ELECT_INV_STATUS IN VARCHAR2,
                       P_MESSAGE_TEXT     IN VARCHAR2,
                       X_RETURN_STATUS    OUT VARCHAR2,
                       X_MSG_DATA         OUT VARCHAR2) AS
  BEGIN

    execute immediate 'alter session set time_zone = ''-03:00'''; --para colocar a hora de brasilia
    --insere logs dos acontecimentos, tabela tem id sequencial e pela logica pode ser executado varias vezes
    XXISV_MEFSY_JL_BR_SPED_PUB.INSERT_LOG (P_API_VERSION,
                               P_COMMIT,
                               P_CUSTOMER_TRX_ID,
                               P_OCCURRENCE_DATE,
                               P_ELECT_INV_STATUS,
                               P_MESSAGE_TEXT,
                               X_RETURN_STATUS,
                               X_MSG_DATA);
  END;

  PROCEDURE PROCESS_RETURN(P_API_VERSION           IN NUMBER,
                           P_COMMIT                IN VARCHAR2,
                           P_CUSTOMER_TRX_ID       IN NUMBER,
                           P_ELECT_INV_WEB_ADDRESS IN VARCHAR2,
                           P_ELECT_INV_STATUS      IN VARCHAR2,
                           P_ELECT_INV_ACCESS_KEY  IN VARCHAR2,
                           P_ELECT_INV_PROTOCOL    IN VARCHAR2,
                           P_MESSAGE_TEXT          IN VARCHAR2,
                           P_OCCURRENCE_DATE       IN DATE,
                           P_STATUS_SEFAZ          IN VARCHAR2,
                           P_DATAHORA_AUTOTIZACAO  IN VARCHAR2,
                           X_RETURN_STATUS         OUT VARCHAR2,
                           X_MSG_DATA              OUT VARCHAR2) AS

    v_data                      date;
    v_cm_customer_trx_id        XXISV_MEFSY_F255_AR_INVO.CUSTOMER_TRX_ID%type;
    V_RETURN_STATUS             VARCHAR2(4000);
    V_MSG_DATA                  VARCHAR2(4000);
  BEGIN

    execute immediate 'alter session set time_zone = ''-03:00'''; --para colocar a hora de brasilia

    v_data := P_OCCURRENCE_DATE;
    v_cm_customer_trx_id := P_CUSTOMER_TRX_ID;

    --insere e nao atualiza mais enquanto nao voltar o status
    XXISV_MEFSY_JL_BR_SPED_PUB.UPDATE_ATTRIBUTES (P_API_VERSION,
                                      P_COMMIT,
                                      v_cm_customer_trx_id,
                                      P_ELECT_INV_WEB_ADDRESS,
                                      P_ELECT_INV_STATUS,
                                      P_ELECT_INV_ACCESS_KEY,
                                      P_ELECT_INV_PROTOCOL,
                                      NULL,
                                      V_RETURN_STATUS,
                                      V_MSG_DATA);

    --insere logs dos acontecimentos, tabela tem id sequencial e pela logica pode ser executado varias vezes
    XXISV_MEFSY_JL_BR_SPED_PUB.INSERT_LOG (P_API_VERSION,
                               P_COMMIT,
                               v_cm_customer_trx_id,
                               v_data, --V_OCCURRENCE_DATE,
                               P_ELECT_INV_STATUS,
                               substr(P_MESSAGE_TEXT, 1, 2000),
                               X_RETURN_STATUS,
                               X_MSG_DATA);


    if (V_RETURN_STATUS = 'E' or V_RETURN_STATUS = 'U') or
       (X_RETURN_STATUS = 'E' or X_RETURN_STATUS = 'U') then

       X_RETURN_STATUS := 'E';

    end if;
    
    -- F031 somente sendo processada para Mercantil

    XXISV_MEFSY_F031_ELECTRO_API.process_trx(
                          p_customer_trx_id => v_cm_customer_trx_id,
                          p_generate_date   => sysdate,
                          p_information1    => P_OCCURRENCE_DATE, -- Sent Date
                          p_information2    => P_ELECT_INV_ACCESS_KEY, -- Access Key
                          p_information3    => P_ELECT_INV_PROTOCOL, -- Protocol
                          p_location        => 'FEDERAL',
                          p_url             => P_ELECT_INV_WEB_ADDRESS,
                          p_return          => V_RETURN_STATUS);


    XXISV_MEFSY_F031_ELECTRO_API.process_return(
                          p_customer_trx_id => v_cm_customer_trx_id,
                          p_occurrence_date => sysdate,
                          p_status          => P_ELECT_INV_STATUS,
                          p_information1    => P_ELECT_INV_ACCESS_KEY, -- Access Key
                          p_information2    => P_ELECT_INV_PROTOCOL, -- Protocol
                          p_information3    => substr(P_MESSAGE_TEXT, 1, 150), -- Message, ajuste por que o p_information3 na API da oracle tem o tamanho de 150
                          p_location        => 'FEDERAL',
                          p_url             => P_ELECT_INV_WEB_ADDRESS,
                          p_return          => V_RETURN_STATUS);
                          
  
    X_MSG_DATA := 'UPDATE_ATTRIBUTES: '||V_MSG_DATA ||' INSERT_LOG:'||X_MSG_DATA;

    clean_old_data(v_cm_customer_trx_id);

  END;
  
  PROCEDURE PROCESS_RETURN_SERV(P_API_VERSION           IN NUMBER,
                                P_COMMIT                IN VARCHAR2,
                                P_CUSTOMER_TRX_ID       IN NUMBER,
                                P_ELECT_INV_WEB_ADDRESS IN VARCHAR2,
                                P_ELECT_INV_STATUS      IN VARCHAR2,
                                P_ELECT_INV_ACCESS_KEY  IN VARCHAR2,
                                P_ELECT_INV_PROTOCOL    IN VARCHAR2,
                                P_MESSAGE_TEXT          IN VARCHAR2,
                                P_NUMERO_NFS            IN VARCHAR2,
                                P_OCCURRENCE_DATE       IN DATE,
                                P_STATUS_SEFAZ          IN VARCHAR2,
                                P_DATAHORA_AUTOTIZACAO  IN VARCHAR2,
                                X_RETURN_STATUS         OUT VARCHAR2,
                                X_MSG_DATA              OUT VARCHAR2) AS

    v_data                      date;
    v_cm_customer_trx_id        XXISV_MEFSY_F255_AR_INVO.CUSTOMER_TRX_ID%type;
    V_RETURN_STATUS             VARCHAR2(4000);
    V_MSG_DATA                  VARCHAR2(4000);
  BEGIN

    execute immediate 'alter session set time_zone = ''-03:00'''; --para colocar a hora de brasilia

    v_data := P_OCCURRENCE_DATE;
    v_cm_customer_trx_id := P_CUSTOMER_TRX_ID;
    --
    BEGIN
      UPDATE APPS.RA_CUSTOMER_TRX_ALL
       SET ATTRIBUTE4         = P_NUMERO_NFS,
           ATTRIBUTE_CATEGORY = 'NFSE'
      WHERE CUSTOMER_TRX_ID = P_CUSTOMER_TRX_ID;
      commit;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    --
    
    --insere e nao atualiza mais enquanto nao voltar o status
    XXISV_MEFSY_JL_BR_SPED_PUB.UPDATE_ATTRIBUTES (P_API_VERSION,
                                      P_COMMIT,
                                      v_cm_customer_trx_id,
                                      P_ELECT_INV_WEB_ADDRESS,
                                      P_ELECT_INV_STATUS,
                                      P_ELECT_INV_ACCESS_KEY,
                                      P_ELECT_INV_PROTOCOL,
                                      'NUMERO NFS GERADO:' || P_NUMERO_NFS,
                                      V_RETURN_STATUS,
                                      V_MSG_DATA);
                                      
    --insere logs dos acontecimentos, tabela tem id sequencial e pela logica pode ser executado varias vezes
    XXISV_MEFSY_JL_BR_SPED_PUB.INSERT_LOG (P_API_VERSION,
                               P_COMMIT,
                               v_cm_customer_trx_id,
                               v_data, --V_OCCURRENCE_DATE,
                               P_ELECT_INV_STATUS,
                               substr(P_MESSAGE_TEXT, 1, 2000),
                               X_RETURN_STATUS,
                               X_MSG_DATA);

    if (V_RETURN_STATUS = 'E' or V_RETURN_STATUS = 'U') or
       (X_RETURN_STATUS = 'E' or X_RETURN_STATUS = 'U') then

       X_RETURN_STATUS := 'E';

    end if;
    
    -- F031 somente sendo processada para Mercantil

    XXISV_MEFSY_F031_ELECTRO_API.process_trx(
                          p_customer_trx_id => v_cm_customer_trx_id,
                          p_generate_date   => sysdate,
                          p_information1    => P_OCCURRENCE_DATE, -- Sent Date
                          p_information2    => P_ELECT_INV_ACCESS_KEY, -- Access Key
                          p_information3    => P_ELECT_INV_PROTOCOL, -- Protocol
                          p_location        => 'FEDERAL',
                          p_url             => P_ELECT_INV_WEB_ADDRESS,
                          p_return          => V_RETURN_STATUS);


    XXISV_MEFSY_F031_ELECTRO_API.process_return(
                          p_customer_trx_id => v_cm_customer_trx_id,
                          p_occurrence_date => sysdate,
                          p_status          => P_ELECT_INV_STATUS,
                          p_message         => P_MESSAGE_TEXT,
                          p_information1    => P_ELECT_INV_ACCESS_KEY, -- Access Key
                          p_information2    => P_ELECT_INV_PROTOCOL, -- Protocol
                          p_information3    => substr(P_MESSAGE_TEXT, 1, 150), -- Message, ajuste por que o p_information3 na API da oracle tem o tamanho de 150
                          p_location        => 'FEDERAL',
                          p_url             => P_ELECT_INV_WEB_ADDRESS,
                          p_return          => V_RETURN_STATUS);

 
    X_MSG_DATA := 'UPDATE_ATTRIBUTES: '||V_MSG_DATA ||' INSERT_LOG:'||X_MSG_DATA;

    clean_old_data(v_cm_customer_trx_id);

  END;

  PROCEDURE PROCESS_RETURN_NFS(P_API_VERSION           IN VARCHAR2,
                               P_COMMIT                IN VARCHAR2,
                               P_CUSTOMER_TRX_ID       IN VARCHAR2,
                               P_ELECT_INV_STATUS      IN VARCHAR2,
                               P_STATUS                IN VARCHAR2,
                               P_DESCRICAO_STATUS      IN VARCHAR2,
                               P_COD_CIDADE            IN VARCHAR2,
                               P_SIAFI_PRESTADOR       IN NUMERIC,
                               P_NUMERO_RPS            IN NUMERIC,
                               P_SERIE_RPS             IN VARCHAR2,
                               P_TIPO_RPS              IN VARCHAR2,
                               P_SITUACAO_RPS          IN VARCHAR2,
                               P_DATA_EMISSAO_RPS      IN VARCHAR2,
                               P_DATA_APROVACAO        IN VARCHAR2,
                               P_DATA_CANCELAMENTO     IN VARCHAR2,
                               P_NUMERO_NFE            IN VARCHAR2,
                               P_CNPJ_PRESTADOR        IN VARCHAR2,
                               P_INSCRICAO_PRESTADOR   IN VARCHAR2,
                               P_ALIQUOTA_SERVICOS     IN NUMERIC,
                               P_VALOR_SERVICOS        IN NUMERIC,
                               P_VALOR_DEDUZIR         IN NUMERIC,
                               P_CODIGO_VERIFICACAO    IN VARCHAR2,
                               P_CODIGO_CANCELAMENTO   IN VARCHAR2,
                               P_NUMERO_LOTE           IN NUMERIC,
                               P_NUMERO_PROTOCOLO      IN VARCHAR2,
                               P_TIPO_AMBIENTE_SISTEMA IN NUMERIC,
                               P_URL_CONSULTA          IN VARCHAR2,
                               P_PREF_BASE_CALCULO     IN NUMERIC,
                               P_PREF_VL_LIQ_NFSE      IN NUMERIC,
                               P_PREF_VL_ISS           IN NUMERIC,
                               X_RETURN_STATUS         OUT VARCHAR2,
                               X_MSG_DATA              OUT VARCHAR2) AS
  BEGIN

    PROCESS_RETURN_SERV(P_API_VERSION           => P_API_VERSION,       -- IN NUMBER
                        P_COMMIT                => P_COMMIT,            -- IN VARCHAR2
                        P_CUSTOMER_TRX_ID       => P_CUSTOMER_TRX_ID,   -- IN NUMBER
                        P_ELECT_INV_WEB_ADDRESS => P_URL_CONSULTA,      -- IN VARCHAR2,
                        P_ELECT_INV_STATUS      => P_ELECT_INV_STATUS,  -- IN VARCHAR2
                        P_ELECT_INV_ACCESS_KEY  => P_CODIGO_VERIFICACAO,-- IN VARCHAR2
                        P_ELECT_INV_PROTOCOL    => P_NUMERO_PROTOCOLO,  -- IN VARCHAR2
                        P_MESSAGE_TEXT          => P_DESCRICAO_STATUS,  -- IN VARCHAR2
                        P_NUMERO_NFS            => P_NUMERO_NFE,        -- IN VARCHAR2,
                        P_OCCURRENCE_DATE       => SYSDATE,             -- IN DATE
                        P_STATUS_SEFAZ          => P_STATUS,            -- IN VARCHAR2
                        P_DATAHORA_AUTOTIZACAO  => P_DATA_APROVACAO,    -- IN VARCHAR2
                        X_RETURN_STATUS         => X_RETURN_STATUS,     -- OUT VARCHAR2
                        X_MSG_DATA              => X_MSG_DATA);         -- OUT VARCHAR2

    clean_old_data(P_CUSTOMER_TRX_ID);

  END;

end XXISV_MECPC_DFE_EVENT;
/
