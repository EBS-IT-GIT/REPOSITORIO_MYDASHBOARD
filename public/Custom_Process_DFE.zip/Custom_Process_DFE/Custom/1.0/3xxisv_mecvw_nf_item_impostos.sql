create or replace view xxisv_mecvw_nf_item_impostos as
select
------------------------------------------------------------------------------------------------------------------------
--NOME OBJETO.........: XXISV_MEFVW_NF_ITEM_IMPOSTOS
--NOME FISICO.........: XXISV_MEFVW_NF_ITEM_IMPOSTOS.SQL
--TIPO_OBJETO.........: VIEW
--NUMERO..............: XXXXX
--REFERENCIA..........: EBS R12
--VIEW CLL  ..........:
--AUTOR...............: THOMSONREUTERS/MASTERSAF
--DATA................: 12/05/2014
--MODIFICACOES........: 3.0.001 - OS-00001.000000 - 12/05/2014 - IMPLEMENTACAO INICIAL
--CUSTOMIZACOES.......:
------------------------------------------------------------------------------------------------------------------------
        tax.customer_trx_id                                                                                                    as CUSTOMER_TRX_ID     ,
        tax.link_to_cust_trx_line_id                                                                                           as CUSTOMER_TRX_LINE_ID,
        tax.org_id                                                                                                             as ORG_ID              ,
        -- IPI
        max(decode(substr(tax_category,1,3), param.S_IPI, state_federal_tax_code, null))                                       as IPI_CST             ,
        sum(decode(substr(tax_category,1,3), param.S_IPI, value_base, null))                                                   as IPI_BASE            ,
        max(decode(substr(tax_category,1,3), param.S_IPI, tax_rate, null))                                                     as IPI_ALIQ            ,
        sum(decode(substr(tax_category,1,3), param.S_IPI, tax_amount, null))                                                   as IPI_VLR             ,
        -- ICMS
        max(decode(substr(tax_category,1,4), param.S_ICMS, decode(regexp_replace(tax_category, param.S_DADO_ICMSST, '')
                                           , param.S_ICMSST, null
                                           , state_state_tax_code), null))                                                     as ICMS_CST            ,
        sum(decode(substr(tax_category,1,4), param.S_ICMS, decode(regexp_replace(tax_category, param.S_DADO_ICMSST, '')
                                           , param.S_ICMSST, null
                                           , value_base), null))                                                               as ICMS_BASE           ,
        max(decode(substr(tax_category,1,4), param.S_ICMS, decode(regexp_replace(tax_category, param.S_DADO_ICMSST, '')
                                           , param.S_ICMSST, null
                                           , tax_rate), null))                                                                 as ICMS_ALIQ           ,
        sum(decode(substr(tax_category,1,4), param.S_ICMS, decode(regexp_replace(tax_category, param.S_DADO_ICMSST, '')
                                           , param.S_ICMSST, null
                                           , tax_amount), null))                                                               as ICMS_VLR            ,
        max(decode(regexp_replace(tax_category, param.S_DADO_ICMSST, ''), param.S_ICMSST, state_state_tax_code, null))         as ICMS_ST_CST         ,
        sum(decode(regexp_replace(tax_category, param.S_DADO_ICMSST, ''), param.S_ICMSST, value_base, null))                   as ICMS_ST_BASE        ,
        max(decode(regexp_replace(tax_category, param.S_DADO_ICMSST, ''), param.S_ICMSST, tax_rate, null))                     as ICMS_ST_ALIQ        ,
        sum(decode(regexp_replace(tax_category, param.S_DADO_ICMSST, ''), param.S_ICMSST, tax_amount, null))                   as ICMS_ST_VLR         ,

          -- PIS
        max(decode(substr(tax_category,1,5), param.S_PIS, state_federal_tax_code, null))                                       as PIS_CST             ,
        sum(decode(substr(tax_category,1,5), param.S_PIS, value_base, null))                                                   as PIS_BASE            ,
        max(decode(substr(tax_category,1,5), param.S_PIS, tax_rate, null))                                                     as PIS_ALIQ            ,
        sum(decode(substr(tax_category,1,5), param.S_PIS, tax_amount, null))                                                   as PIS_VLR             ,

        -- PIS_RT
        max(decode(substr(tax_category,1,5), param.S_AUX01, state_federal_tax_code, null))                                       as PIS_RT_CST             ,
        sum(decode(substr(tax_category,1,5), param.S_AUX01, value_base, null))                                                   as PIS_RT_BASE            ,
        max(decode(substr(tax_category,1,5), param.S_AUX01, tax_rate, null))                                                     as PIS_RT_ALIQ            ,
        sum(decode(substr(tax_category,1,5), param.S_AUX01, tax_amount, null))                                                   as PIS_RT_VLR             ,

        -- COFINS
        max(decode(substr(tax_category,1,8), param.S_COFINS, state_federal_tax_code, null))                                    as COFINS_CST          ,
        sum(decode(substr(tax_category,1,8), param.S_COFINS, value_base, null))                                                as COFINS_BASE         ,
        max(decode(substr(tax_category,1,8), param.S_COFINS, tax_rate, null))                                                  as COFINS_ALIQ         ,
        sum(decode(substr(tax_category,1,8), param.S_COFINS, tax_amount, null))                                                as COFINS_VLR          ,

         -- COFINS_RT
        max(decode(substr(tax_category,1,8), param.S_AUX02, state_federal_tax_code, null))                                    as COFINS_RT_CST          ,
        sum(decode(substr(tax_category,1,8), param.S_AUX02, value_base, null))                                                as COFINS_RT_BASE         ,
        max(decode(substr(tax_category,1,8), param.S_AUX02, tax_rate, null))                                                  as COFINS_RT_ALIQ         ,
        sum(decode(substr(tax_category,1,8), param.S_AUX02, tax_amount, null))                                                as COFINS_RT_VLR          ,

        -- II
        max(decode(substr(tax_category,1,2), param.S_II, state_federal_tax_code, null))                                        as II_CST              ,
        sum(decode(substr(tax_category,1,2), param.S_II, value_base, null))                                                    as II_BASE             ,
        max(decode(substr(tax_category,1,2), param.S_II, tax_rate, null))                                                      as II_ALIQ             ,
        sum(decode(substr(tax_category,1,2), param.S_II, tax_amount, null))                                                    as II_VLR              ,
        -- impostos servico
        max(decode(substr(tax_category,1,4), param.S_INSS, state_state_tax_code, null))                                        as INSS_CST            ,
        sum(decode(substr(tax_category,1,4), param.S_INSS, value_base, null))                                                  as INSS_BASE           ,
        max(decode(substr(tax_category,1,4), param.S_INSS, tax_rate, null))                                                    as INSS_ALIQ           ,
        sum(decode(substr(tax_category,1,4), param.S_INSS, tax_amount, null))                                                  as INSS_VLR            ,
        -- CSLL
        max(decode(substr(tax_category,1,4), param.S_CSLL, state_federal_tax_code, null))                                      as CSLL_CST            ,
        sum(decode(substr(tax_category,1,4), param.S_CSLL, value_base, null))                                                  as CSLL_BASE           ,
        max(decode(substr(tax_category,1,4), param.S_CSLL, tax_rate, null))                                                    as CSLL_ALIQ           ,
        sum(decode(substr(tax_category,1,4), param.S_CSLL, tax_amount, null))                                                  as CSLL_VLR            ,
        -- ISS
        max(decode(substr(tax_category,1,6), param.S_ISS, state_state_tax_code, null))                                         as ISS_CST             ,
        sum(decode(substr(tax_category,1,6), param.S_ISS, value_base, null))                                                   as ISS_BASE            ,
        max(decode(substr(tax_category,1,6), param.S_ISS, tax_rate, null))                                                     as ISS_ALIQ            ,
        sum(decode(substr(tax_category,1,6), param.S_ISS, tax_amount, null))                                                   as ISS_VLR             ,
        -- IR
        max(decode(substr(tax_category,1,4), param.S_IR, state_federal_tax_code, null))                                        as IR_CST              ,
        sum(decode(substr(tax_category,1,4), param.S_IR, value_base, null))                                                    as IR_BASE             ,
        max(decode(substr(tax_category,1,4), param.S_IR, tax_rate, null))                                                      as IR_ALIQ             ,
        sum(decode(substr(tax_category,1,4), param.S_IR, tax_amount, null))                                                    as IR_VLR              ,
    MAX(NVL(ABS(tax.tax_base_modifier_rate), NULL))                                                                            as ICMS_PREDBC --25403/2015
 from apps.CLL_F255_AR_TOTAL_INV_TAXES_V tax,
      apps.CLL_F255_AR_INVOICE_ITEMS_V   item,
      XXISV_MEFSY_PARAM_IMPOSTOS                           param
where tax.customer_trx_id=item.customer_trx_id
  and tax.link_to_cust_trx_line_id = item.customer_trx_line_id
  and item.line_type='LINE'
  and arvt_global_attribute2 = 'Y'
group by
      tax.customer_trx_id,
      tax.link_to_cust_trx_line_id,
      tax.org_id
;
