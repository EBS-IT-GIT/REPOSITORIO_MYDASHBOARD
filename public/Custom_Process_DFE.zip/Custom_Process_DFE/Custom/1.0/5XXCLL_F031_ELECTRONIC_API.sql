CREATE OR REPLACE PACKAGE XXCLL_F031_ELECTRONIC_API authid current_user as
/* $Header: CLLGEBAS.pls 120.6 2008/05/19 20:52:53 obolzam noship $ */
procedure process_trx(p_customer_trx_id      number
                     ,p_generate_date        date
                     ,p_cm_customer_trx_id   number   default null
                     ,p_url                  varchar2 default null
                     ,p_information1         varchar2 default null
                     ,p_information2         varchar2 default null
                     ,p_information3         varchar2 default null
                     ,p_information4         varchar2 default null
                     ,p_information5         varchar2 default null
                     ,p_information6         varchar2 default null
                     ,p_information7         varchar2 default null
                     ,p_information8         varchar2 default null
                     ,p_information9         varchar2 default null
                     ,p_information10        varchar2 default null
                     ,p_information11        varchar2 default null
                     ,p_information12        varchar2 default null
                     ,p_information13        varchar2 default null
                     ,p_information14        varchar2 default null
                     ,p_information15        varchar2 default null
                     ,p_information16        varchar2 default null
                     ,p_information17        varchar2 default null
                     ,p_information18        varchar2 default null
                     ,p_information19        varchar2 default null
                     ,p_information20        varchar2 default null
                     ,p_location             varchar2 default null
                     ,p_return    out nocopy varchar2
                     );

procedure process_return(p_customer_trx_id      number
                        ,p_occurrence_date      date
                        ,p_url                  varchar2 default null
                        ,p_status               varchar2 default null
                        ,p_message              clob     default null
                        ,p_information1         varchar2 default null
                        ,p_information2         varchar2 default null
                        ,p_information3         varchar2 default null
                        ,p_information4         varchar2 default null
                        ,p_information5         varchar2 default null
                        ,p_information6         varchar2 default null
                        ,p_information7         varchar2 default null
                        ,p_information8         varchar2 default null
                        ,p_information9         varchar2 default null
                        ,p_information10        varchar2 default null
                        ,p_information11        varchar2 default null
                        ,p_information12        varchar2 default null
                        ,p_information13        varchar2 default null
                        ,p_information14        varchar2 default null
                        ,p_information15        varchar2 default null
                        ,p_information16        varchar2 default null
                        ,p_information17        varchar2 default null
                        ,p_information18        varchar2 default null
                        ,p_information19        varchar2 default null
                        ,p_information20        varchar2 default null
                        ,p_location             varchar2 default null
                        ,p_return           out nocopy  varchar2
                        );

end XXCLL_F031_ELECTRONIC_API;
/
CREATE OR REPLACE PACKAGE BODY XXCLL_F031_ELECTRONIC_API as
/* $Header: CLLGEBAB.pls 120.9 2010/02/08 19:32:46 obolzam noship $ */

PROCEDURE trx_insert_row(p_customer_trx_id    NUMBER
                        ,p_status             VARCHAR2
                        ,p_last_generate_date DATE
                        ,p_cm_customer_trx_id NUMBER
                        ,p_url                VARCHAR2 DEFAULT NULL
                        ,p_attribute1         VARCHAR2 DEFAULT NULL
                        ,p_attribute2         VARCHAR2 DEFAULT NULL
                        ,p_attribute3         VARCHAR2 DEFAULT NULL
                        ,p_attribute4         VARCHAR2 DEFAULT NULL
                        ,p_attribute5         VARCHAR2 DEFAULT NULL
                        ,p_attribute6         VARCHAR2 DEFAULT NULL
                        ,p_attribute7         VARCHAR2 DEFAULT NULL
                        ,p_attribute8         VARCHAR2 DEFAULT NULL
                        ,p_attribute9         VARCHAR2 DEFAULT NULL
                        ,p_attribute10        VARCHAR2 DEFAULT NULL
                        ,p_attribute11        VARCHAR2 DEFAULT NULL
                        ,p_attribute12        VARCHAR2 DEFAULT NULL
                        ,p_attribute13        VARCHAR2 DEFAULT NULL
                        ,p_attribute14        VARCHAR2 DEFAULT NULL
                        ,p_attribute15        VARCHAR2 DEFAULT NULL
                        ,p_attribute16        VARCHAR2 DEFAULT NULL
                        ,p_attribute17        VARCHAR2 DEFAULT NULL
                        ,p_attribute18        VARCHAR2 DEFAULT NULL
                        ,p_attribute19        VARCHAR2 DEFAULT NULL
                        ,p_attribute20        VARCHAR2 DEFAULT NULL
                        ,p_attribute_category VARCHAR2 DEFAULT NULL
                        ,p_return         OUT NOCOPY VARCHAR2
                        ) IS

  v_electronic_trx_id number;
  v_org_id NUMBER;
BEGIN
  BEGIN
    SELECT rcta.org_id
      INTO v_org_id
      FROM apps.ra_customer_trx_all rcta
     WHERE rcta.customer_trx_id = p_customer_trx_id;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;

  select apps.cll_f031_electronic_trx_s.nextval
    into v_electronic_trx_id
    from dual;

  INSERT INTO apps.cll_f031_electronic_trx_all
             (electronic_trx_id
             ,customer_trx_id
             ,status
             ,last_generate_date
             ,cm_customer_trx_id
             ,org_id
             ,url
             ,attribute1
             ,attribute2
             ,attribute3
             ,attribute4
             ,attribute5
             ,attribute6
             ,attribute7
             ,attribute8
             ,attribute9
             ,attribute10
             ,attribute11
             ,attribute12
             ,attribute13
             ,attribute14
             ,attribute15
             ,attribute16
             ,attribute17
             ,attribute18
             ,attribute19
             ,attribute20
             ,attribute_category
             ,last_update_date
             ,last_updated_by
             ,creation_date
             ,created_by)
           VALUES
             (v_electronic_trx_id
             ,p_customer_trx_id
             ,p_status
             ,p_last_generate_date
             ,p_cm_customer_trx_id
             ,v_org_id
             ,p_url
             ,p_attribute1
             ,p_attribute2
             ,p_attribute3
             ,p_attribute4
             ,p_attribute5
             ,p_attribute6
             ,p_attribute7
             ,p_attribute8
             ,p_attribute9
             ,p_attribute10
             ,p_attribute11
             ,p_attribute12
             ,p_attribute13
             ,p_attribute14
             ,p_attribute15
             ,p_attribute16
             ,p_attribute17
             ,p_attribute18
             ,p_attribute19
             ,p_attribute20
             ,p_attribute_category
             ,SYSDATE
             ,-1
             ,SYSDATE
             ,-1
             );

  p_return := NULL;
EXCEPTION
  WHEN others THEN
    p_return := '1ERR:OTHER - '||SQLERRM; --BUG 6916625
END trx_insert_row;

PROCEDURE trx_update_row(p_customer_trx_id        NUMBER
                        ,p_status                 VARCHAR2 DEFAULT NULL
                        ,p_last_generate_date     DATE     DEFAULT NULL
                        ,p_cm_customer_trx_id     NUMBER   DEFAULT NULL
                        ,p_last_electronic_ret_id NUMBER   DEFAULT NULL
                        ,p_url                VARCHAR2 DEFAULT NULL
                        ,p_attribute1         VARCHAR2 DEFAULT NULL
                        ,p_attribute2         VARCHAR2 DEFAULT NULL
                        ,p_attribute3         VARCHAR2 DEFAULT NULL
                        ,p_attribute4         VARCHAR2 DEFAULT NULL
                        ,p_attribute5         VARCHAR2 DEFAULT NULL
                        ,p_attribute6         VARCHAR2 DEFAULT NULL
                        ,p_attribute7         VARCHAR2 DEFAULT NULL
                        ,p_attribute8         VARCHAR2 DEFAULT NULL
                        ,p_attribute9         VARCHAR2 DEFAULT NULL
                        ,p_attribute10        VARCHAR2 DEFAULT NULL
                        ,p_attribute11        VARCHAR2 DEFAULT NULL
                        ,p_attribute12        VARCHAR2 DEFAULT NULL
                        ,p_attribute13        VARCHAR2 DEFAULT NULL
                        ,p_attribute14        VARCHAR2 DEFAULT NULL
                        ,p_attribute15        VARCHAR2 DEFAULT NULL
                        ,p_attribute16        VARCHAR2 DEFAULT NULL
                        ,p_attribute17        VARCHAR2 DEFAULT NULL
                        ,p_attribute18        VARCHAR2 DEFAULT NULL
                        ,p_attribute19        VARCHAR2 DEFAULT NULL
                        ,p_attribute20        VARCHAR2 DEFAULT NULL
                        ,p_attribute_category VARCHAR2 DEFAULT NULL
                        ,p_return         OUT NOCOPY VARCHAR2
                        ) IS

BEGIN
  UPDATE apps.cll_f031_electronic_trx_all
     SET status                 = p_status
        ,last_generate_date     = p_last_generate_date
        ,cm_customer_trx_id     = p_cm_customer_trx_id
        ,last_electronic_ret_id = p_last_electronic_ret_id
        ,url         =  p_url
        ,attribute1  = p_attribute1
        ,attribute2  = p_attribute2
        ,attribute3  = p_attribute3
        ,attribute4  = p_attribute4
        ,attribute5  = p_attribute5
        ,attribute6  = p_attribute6
        ,attribute7  = p_attribute7
        ,attribute8  = p_attribute8
        ,attribute9  = p_attribute9
        ,attribute10 = p_attribute10
        ,attribute11 = p_attribute11
        ,attribute12 = p_attribute12
        ,attribute13 = p_attribute13
        ,attribute14 = p_attribute14
        ,attribute15 = p_attribute15
        ,attribute16 = p_attribute16
        ,attribute17 = p_attribute17
        ,attribute18 = p_attribute18
        ,attribute19 = p_attribute19
        ,attribute20 = p_attribute20
        ,attribute_category = p_attribute_category
        ,last_update_date   = SYSDATE
        ,last_updated_by    = -1
   WHERE customer_trx_id = p_customer_trx_id;
  --
  p_return := NULL;
EXCEPTION
  WHEN others THEN
    p_return := '2ERR:OTHER - '||SQLERRM; --BUG 6916625
END trx_update_row;

PROCEDURE ret_insert_row(p_customer_trx_id    NUMBER
                        ,p_occurrence_date    DATE
                        ,p_message            CLOB     DEFAULT NULL
                        ,p_attribute1         VARCHAR2 DEFAULT NULL
                        ,p_attribute2         VARCHAR2 DEFAULT NULL
                        ,p_attribute3         VARCHAR2 DEFAULT NULL
                        ,p_attribute4         VARCHAR2 DEFAULT NULL
                        ,p_attribute5         VARCHAR2 DEFAULT NULL
                        ,p_attribute6         VARCHAR2 DEFAULT NULL
                        ,p_attribute7         VARCHAR2 DEFAULT NULL
                        ,p_attribute8         VARCHAR2 DEFAULT NULL
                        ,p_attribute9         VARCHAR2 DEFAULT NULL
                        ,p_attribute10        VARCHAR2 DEFAULT NULL
                        ,p_attribute11        VARCHAR2 DEFAULT NULL
                        ,p_attribute12        VARCHAR2 DEFAULT NULL
                        ,p_attribute13        VARCHAR2 DEFAULT NULL
                        ,p_attribute14        VARCHAR2 DEFAULT NULL
                        ,p_attribute15        VARCHAR2 DEFAULT NULL
                        ,p_attribute16        VARCHAR2 DEFAULT NULL
                        ,p_attribute17        VARCHAR2 DEFAULT NULL
                        ,p_attribute18        VARCHAR2 DEFAULT NULL
                        ,p_attribute19        VARCHAR2 DEFAULT NULL
                        ,p_attribute20        VARCHAR2 DEFAULT NULL
                        ,p_attribute_category VARCHAR2 DEFAULT NULL
                        ,p_electronic_ret_id  OUT NOCOPY NUMBER
                        ,p_return         OUT NOCOPY VARCHAR2
                        ) IS
  v_electronic_trx_id number;
  v_org_id NUMBER;
BEGIN
  SELECT apps.cll_f031_electronic_ret_s.NEXTVAL
    INTO p_electronic_ret_id
    FROM dual;

  begin
     select electronic_trx_id
       into v_electronic_trx_id
       from apps.cll_f031_electronic_trx_all
      where customer_trx_id = p_customer_trx_id;
  exception when others then
    v_electronic_trx_id := null;
  end;

  BEGIN
    SELECT rcta.org_id
      INTO v_org_id
      FROM apps.ra_customer_trx_all rcta
     WHERE rcta.customer_trx_id = p_customer_trx_id;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;

  INSERT INTO apps.cll_f031_electronic_ret_all
             (electronic_trx_id
             ,electronic_ret_id
             ,customer_trx_id
             ,occurrence_date
             ,owner
             ,org_id
             ,message
             ,attribute1
             ,attribute2
             ,attribute3
             ,attribute4
             ,attribute5
             ,attribute6
             ,attribute7
             ,attribute8
             ,attribute9
             ,attribute10
             ,attribute11
             ,attribute12
             ,attribute13
             ,attribute14
             ,attribute15
             ,attribute16
             ,attribute17
             ,attribute18
             ,attribute19
             ,attribute20
             ,attribute_category
             ,last_update_date
             ,last_updated_by
             ,creation_date
             ,created_by)
           VALUES
             (v_electronic_trx_id
             ,p_electronic_ret_id
             ,p_customer_trx_id
             ,p_occurrence_date
             ,'SYS'
             ,v_org_id
             ,p_message
             ,p_attribute1
             ,p_attribute2
             ,p_attribute3
             ,p_attribute4
             ,p_attribute5
             ,p_attribute6
             ,p_attribute7
             ,p_attribute8
             ,p_attribute9
             ,p_attribute10
             ,p_attribute11
             ,p_attribute12
             ,p_attribute13
             ,p_attribute14
             ,p_attribute15
             ,p_attribute16
             ,p_attribute17
             ,p_attribute18
             ,p_attribute19
             ,p_attribute20
             ,p_attribute_category
             ,SYSDATE
             ,-1
             ,SYSDATE
             ,-1
             );

  p_return := NULL;
EXCEPTION WHEN others THEN
  p_return := '3ERR:OTHER - '||SQLERRM; --BUG 6916625
END ret_insert_row;

FUNCTION trx_validation
                     (p_customer_trx_id      IN NUMBER
                     ,p_generate_date        IN DATE
                     ,p_cm_customer_trx_id   IN NUMBER
                     ,p_information1         IN OUT NOCOPY VARCHAR2
                     ,p_information2         IN OUT NOCOPY VARCHAR2
                     ,p_information3         IN OUT NOCOPY VARCHAR2
                     ,p_information4         IN OUT NOCOPY VARCHAR2
                     ,p_information5         IN OUT NOCOPY VARCHAR2
                     ,p_information6         IN OUT NOCOPY VARCHAR2
                     ,p_information7         IN OUT NOCOPY VARCHAR2
                     ,p_information8         IN OUT NOCOPY VARCHAR2
                     ,p_information9         IN OUT NOCOPY VARCHAR2
                     ,p_information10        IN OUT NOCOPY VARCHAR2
                     ,p_information11        IN OUT NOCOPY VARCHAR2
                     ,p_information12        IN OUT NOCOPY VARCHAR2
                     ,p_information13        IN OUT NOCOPY VARCHAR2
                     ,p_information14        IN OUT NOCOPY VARCHAR2
                     ,p_information15        IN OUT NOCOPY VARCHAR2
                     ,p_information16        IN OUT NOCOPY VARCHAR2
                     ,p_information17        IN OUT NOCOPY VARCHAR2
                     ,p_information18        IN OUT NOCOPY VARCHAR2
                     ,p_information19        IN OUT NOCOPY VARCHAR2
                     ,p_information20        IN OUT NOCOPY VARCHAR2
                     ,p_location             IN VARCHAR2) RETURN VARCHAR2 IS

  v_number   NUMBER;
  v_date     DATE;
  v_check    NUMBER;
BEGIN
   DECLARE
     v_ok  NUMBER;
   BEGIN
     SELECT 1
       INTO v_ok
       FROM apps.ra_customer_trx_all rcta ,
            apps.ra_cust_trx_types_all rctta
      WHERE rcta.customer_trx_id = p_customer_trx_id
        AND rctta.cust_trx_type_id = rcta.cust_trx_type_id
        AND rctta.TYPE = 'INV'
        AND rctta.org_id = rcta.org_id;
   EXCEPTION
   WHEN others THEN
      RETURN 'ERR:INVALID_TRX';
   END;
   --
   IF p_cm_customer_trx_id IS NOT NULL THEN
      DECLARE
        v_ok  NUMBER;
      BEGIN
        SELECT 1
          INTO v_ok
          FROM apps.ra_customer_trx_all rcta ,
               apps.ra_cust_trx_types_all rctta
         WHERE rcta.customer_trx_id = p_cm_customer_trx_id
           AND rctta.cust_trx_type_id = rcta.cust_trx_type_id
           AND rctta.TYPE = 'CM'
           AND rctta.org_id = rcta.org_id;
      EXCEPTION
      WHEN others THEN
         RETURN 'ERR:INVALID_CM_TRX';
      END;
   END IF;
   --
   BEGIN
      SELECT 1
        INTO v_check
        FROM apps.fnd_descr_flex_contexts_vl
       WHERE descriptive_flexfield_name LIKE 'CLL_F031_ELECTRONIC_TRX_ALL'
         AND descriptive_flex_context_code = p_location;
   EXCEPTION
   WHEN OTHERS
   THEN
      RETURN 'ERR:INVALID_LOCATION';
   END;

   IF p_location <> 'FEDERAL' THEN
      BEGIN
         IF p_information1 IS NULL THEN
            RETURN 'ERR:INVALID_INFO1';
         END IF;
         --v_number := NVL(apps.fnd_number.canonical_to_number(nvl(replace(p_information1,',','.'),0)) ,0);
         --p_information1 := fnd_number.number_to_canonical(v_number);
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO1';
      END;
   END IF;
   --
   RETURN NULL;
END trx_validation;

FUNCTION return_validation
                     (p_customer_trx_id      IN NUMBER
                     ,p_occurrence_date      IN DATE
                     ,p_status               IN VARCHAR2
                     ,p_information1         IN OUT NOCOPY VARCHAR2
                     ,p_information2         IN OUT NOCOPY VARCHAR2
                     ,p_information3         IN OUT NOCOPY VARCHAR2
                     ,p_information4         IN OUT NOCOPY VARCHAR2
                     ,p_information5         IN OUT NOCOPY VARCHAR2
                     ,p_information6         IN OUT NOCOPY VARCHAR2
                     ,p_information7         IN OUT NOCOPY VARCHAR2
                     ,p_information8         IN OUT NOCOPY VARCHAR2
                     ,p_information9         IN OUT NOCOPY VARCHAR2
                     ,p_information10        IN OUT NOCOPY VARCHAR2
                     ,p_information11        IN OUT NOCOPY VARCHAR2
                     ,p_information12        IN OUT NOCOPY VARCHAR2
                     ,p_information13        IN OUT NOCOPY VARCHAR2
                     ,p_information14        IN OUT NOCOPY VARCHAR2
                     ,p_information15        IN OUT NOCOPY VARCHAR2
                     ,p_information16        IN OUT NOCOPY VARCHAR2
                     ,p_information17        IN OUT NOCOPY VARCHAR2
                     ,p_information18        IN OUT NOCOPY VARCHAR2
                     ,p_information19        IN OUT NOCOPY VARCHAR2
                     ,p_information20        IN OUT NOCOPY VARCHAR2
                     ,p_location             IN VARCHAR2) RETURN VARCHAR2 IS
  v_number   NUMBER;
  v_date     DATE;
  v_check    NUMBER;
BEGIN
   DECLARE
     v_ok  NUMBER;
   BEGIN
     SELECT 1
       INTO v_ok
       FROM apps.ra_customer_trx_all rcta ,
            apps.ra_cust_trx_types_all rctta
      WHERE rcta.customer_trx_id = p_customer_trx_id
        AND rctta.cust_trx_type_id = rcta.cust_trx_type_id
        AND rctta.TYPE = 'INV'
        AND rctta.org_id = rcta.org_id;
   EXCEPTION
   WHEN others THEN
      RETURN 'ERR:INVALID_TRX';
   END;
   --
   BEGIN
      SELECT 1
        INTO v_check
        FROM apps.fnd_descr_flex_contexts_vl
       WHERE descriptive_flexfield_name LIKE 'CLL_F031_ELECTRONIC_TRX_ALL'
         AND descriptive_flex_context_code = p_location;
   EXCEPTION
   WHEN OTHERS
   THEN
      RETURN 'ERR:INVALID_LOCATION';
   END;

   IF p_status IS NULL THEN
      RETURN 'ERR:INVALID_STATUS';
   ELSIF p_location <> 'FEDERAL' THEN
      IF p_information1 IS NULL THEN
         RETURN 'ERR:INVALID_INFO1';
      END IF;
      BEGIN
         IF p_information2 IS NULL THEN
            RETURN 'ERR:INVALID_INFO2';
         END IF;
         v_date := to_date (p_information2,'RRRRMMDD HH24MISS');
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO2';
      END;
      IF p_information3 IS NULL THEN
         RETURN 'ERR:INVALID_INFO3';
      END IF;
      BEGIN
         IF p_information4 IS NULL THEN
            RETURN 'ERR:INVALID_INFO4';
         END IF;
         v_date := to_date (p_information4,'RRRRMMDD');
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO4';
      END;
      BEGIN
         IF p_information6 IS NULL THEN
            RETURN 'ERR:INVALID_INFO6';
         END IF;
         --v_number := nvl(apps.fnd_number.canonical_to_number(nvl(replace(p_information6,',','.'),0)) ,0);
         --p_information6 := apps.fnd_number.number_to_canonical(v_number);
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO6';
      END;
      BEGIN
         IF p_information7 IS NULL THEN
            RETURN 'ERR:INVALID_INFO7';
         END IF;
         --v_number := nvl(apps.fnd_number.canonical_to_number(nvl(replace(p_information7,',','.'),0)) ,0);
         --p_information7 := apps.fnd_number.number_to_canonical(v_number);
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO7';
      END;
      BEGIN
         IF p_information8 IS NULL THEN
            RETURN 'ERR:INVALID_INFO8';
         END IF;
         --v_number := nvl(apps.fnd_number.canonical_to_number(nvl(replace(p_information8,',','.'),0)) ,0);
         --p_information8 := apps.fnd_number.number_to_canonical(v_number);
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO8';
      END;
      BEGIN
         IF p_information9 IS NULL THEN
            RETURN 'ERR:INVALID_INFO9';
         END IF;
         --v_number := nvl(apps.fnd_number.canonical_to_number(nvl(replace(p_information9,',','.'),0)) ,0);
         --p_information9 := apps.fnd_number.number_to_canonical(v_number);
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO9';
      END;
      BEGIN
         IF p_information10 IS NULL THEN
            RETURN 'ERR:INVALID_INFO10';
         END IF;
         --v_number := nvl(apps.fnd_number.canonical_to_number(nvl(replace(p_information10,',','.'),0)) ,0);
         --p_information10 := apps.fnd_number.number_to_canonical(v_number);
      EXCEPTION
         WHEN OTHERS THEN
            RETURN 'ERR:INVALID_INFO10';
      END;
   END IF;
   --
   RETURN NULL;
END return_validation;

PROCEDURE process_trx(p_customer_trx_id      NUMBER
                     ,p_generate_date        DATE
                     ,p_cm_customer_trx_id   NUMBER DEFAULT NULL
                     ,p_url                  VARCHAR2 DEFAULT NULL
                     ,p_information1         VARCHAR2 DEFAULT NULL
                     ,p_information2         VARCHAR2 DEFAULT NULL
                     ,p_information3         VARCHAR2 DEFAULT NULL
                     ,p_information4         VARCHAR2 DEFAULT NULL
                     ,p_information5         VARCHAR2 DEFAULT NULL
                     ,p_information6         VARCHAR2 DEFAULT NULL
                     ,p_information7         VARCHAR2 DEFAULT NULL
                     ,p_information8         VARCHAR2 DEFAULT NULL
                     ,p_information9         VARCHAR2 DEFAULT NULL
                     ,p_information10        VARCHAR2 DEFAULT NULL
                     ,p_information11        VARCHAR2 DEFAULT NULL
                     ,p_information12        VARCHAR2 DEFAULT NULL
                     ,p_information13        VARCHAR2 DEFAULT NULL
                     ,p_information14        VARCHAR2 DEFAULT NULL
                     ,p_information15        VARCHAR2 DEFAULT NULL
                     ,p_information16        VARCHAR2 DEFAULT NULL
                     ,p_information17        VARCHAR2 DEFAULT NULL
                     ,p_information18        VARCHAR2 DEFAULT NULL
                     ,p_information19        VARCHAR2 DEFAULT NULL
                     ,p_information20        VARCHAR2 DEFAULT NULL
                     ,p_location             VARCHAR2 DEFAULT NULL
                     ,p_return           OUT NOCOPY VARCHAR2
                     )IS

v_check_customer_trx_id NUMBER;
v_validation_status     VARCHAR2(30);
v_information1    VARCHAR2 (150);
v_information2    VARCHAR2 (150);
v_information3    VARCHAR2 (150);
v_information4    VARCHAR2 (150);
v_information5    VARCHAR2 (150);
v_information6    VARCHAR2 (150);
v_information7    VARCHAR2 (150);
v_information8    VARCHAR2 (150);
v_information9    VARCHAR2 (150);
v_information10   VARCHAR2 (150);
v_information11   VARCHAR2 (150);
v_information12   VARCHAR2 (150);
v_information13   VARCHAR2 (150);
v_information14   VARCHAR2 (150);
v_information15   VARCHAR2 (150);
v_information16   VARCHAR2 (150);
v_information17   VARCHAR2 (150);
v_information18   VARCHAR2 (150);
v_information19   VARCHAR2 (150);
v_information20   VARCHAR2 (150);
BEGIN
   v_information1    := p_information1;
   v_information2    := p_information2;
   v_information3    := p_information3;
   v_information4    := p_information4;
   v_information5    := p_information5;
   v_information6    := p_information6;
   v_information7    := p_information7;
   v_information8    := p_information8;
   v_information9    := p_information9;
   v_information10   := p_information10;
   v_information11   := p_information11;
   v_information12   := p_information12;
   v_information13   := p_information13;
   v_information14   := p_information14;
   v_information15   := p_information15;
   v_information16   := p_information16;
   v_information17   := p_information17;
   v_information18   := p_information18;
   v_information19   := p_information19;
   v_information20   := p_information20;

   v_validation_status := trx_validation
                         (p_customer_trx_id     => p_customer_trx_id
                         ,p_generate_date       => p_generate_date
                         ,p_cm_customer_trx_id  => p_cm_customer_trx_id
                         ,p_information1        => v_information1
                         ,p_information2        => v_information2
                         ,p_information3        => v_information3
                         ,p_information4        => v_information4
                         ,p_information5        => v_information5
                         ,p_information6        => v_information6
                         ,p_information7        => v_information7
                         ,p_information8        => v_information8
                         ,p_information9        => v_information9
                         ,p_information10       => v_information10
                         ,p_information11       => v_information11
                         ,p_information12       => v_information12
                         ,p_information13       => v_information13
                         ,p_information14       => v_information14
                         ,p_information15       => v_information15
                         ,p_information16       => v_information16
                         ,p_information17       => v_information17
                         ,p_information18       => v_information18
                         ,p_information19       => v_information19
                         ,p_information20       => v_information20
                         ,p_location            => p_location
                         );

  IF v_validation_status IS NOT NULL THEN
    p_return := v_validation_status;
    RETURN;
  END IF;

  BEGIN
    SELECT beeta.customer_trx_id
      INTO v_check_customer_trx_id
      FROM apps.cll_f031_electronic_trx_all beeta
     WHERE beeta.customer_trx_id = p_customer_trx_id;
  EXCEPTION WHEN others THEN
    v_check_customer_trx_id := NULL;
  END;

  IF (v_check_customer_trx_id IS NULL) THEN
    trx_insert_row(p_customer_trx_id    => p_customer_trx_id
                  ,p_status             => '1'
                  ,p_last_generate_date => p_generate_date
                  ,p_cm_customer_trx_id => p_cm_customer_trx_id
                  ,p_url                => p_url
                  ,p_attribute1         => v_information1
                  ,p_attribute2         => v_information2
                  ,p_attribute3         => v_information3
                  ,p_attribute4         => v_information4
                  ,p_attribute5         => v_information5
                  ,p_attribute6         => v_information6
                  ,p_attribute7         => v_information7
                  ,p_attribute8         => v_information8
                  ,p_attribute9         => v_information9
                  ,p_attribute10        => v_information10
                  ,p_attribute11        => v_information11
                  ,p_attribute12        => v_information12
                  ,p_attribute13        => v_information13
                  ,p_attribute14        => v_information14
                  ,p_attribute15        => v_information15
                  ,p_attribute16        => v_information16
                  ,p_attribute17        => v_information17
                  ,p_attribute18        => v_information18
                  ,p_attribute19        => v_information19
                  ,p_attribute20        => v_information20
                  ,p_attribute_category => p_location
                  ,p_return             => p_return
                  );
  ELSE
    trx_update_row(p_customer_trx_id    => p_customer_trx_id
                  ,p_status             => '1'
                  ,p_last_generate_date => p_generate_date
                  ,p_cm_customer_trx_id => p_cm_customer_trx_id
                  ,p_url                => p_url
                  ,p_attribute1         => v_information1
                  ,p_attribute2         => v_information2
                  ,p_attribute3         => v_information3
                  ,p_attribute4         => v_information4
                  ,p_attribute5         => v_information5
                  ,p_attribute6         => v_information6
                  ,p_attribute7         => v_information7
                  ,p_attribute8         => v_information8
                  ,p_attribute9         => v_information9
                  ,p_attribute10        => v_information10
                  ,p_attribute11        => v_information11
                  ,p_attribute12        => v_information12
                  ,p_attribute13        => v_information13
                  ,p_attribute14        => v_information14
                  ,p_attribute15        => v_information15
                  ,p_attribute16        => v_information16
                  ,p_attribute17        => v_information17
                  ,p_attribute18        => v_information18
                  ,p_attribute19        => v_information19
                  ,p_attribute20        => v_information20
                  ,p_attribute_category => p_location
                  ,p_return             => p_return
                  );
  END IF;
  p_return := NULL;
END process_trx;

PROCEDURE process_return(p_customer_trx_id      NUMBER
                        ,p_occurrence_date      DATE
                        ,p_url                  VARCHAR2 DEFAULT NULL
                        ,p_status               VARCHAR2 DEFAULT NULL
                        ,p_message              CLOB     DEFAULT NULL
                        ,p_information1         VARCHAR2 DEFAULT NULL
                        ,p_information2         VARCHAR2 DEFAULT NULL
                        ,p_information3         VARCHAR2 DEFAULT NULL
                        ,p_information4         VARCHAR2 DEFAULT NULL
                        ,p_information5         VARCHAR2 DEFAULT NULL
                        ,p_information6         VARCHAR2 DEFAULT NULL
                        ,p_information7         VARCHAR2 DEFAULT NULL
                        ,p_information8         VARCHAR2 DEFAULT NULL
                        ,p_information9         VARCHAR2 DEFAULT NULL
                        ,p_information10        VARCHAR2 DEFAULT NULL
                        ,p_information11        VARCHAR2 DEFAULT NULL
                        ,p_information12        VARCHAR2 DEFAULT NULL
                        ,p_information13        VARCHAR2 DEFAULT NULL
                        ,p_information14        VARCHAR2 DEFAULT NULL
                        ,p_information15        VARCHAR2 DEFAULT NULL
                        ,p_information16        VARCHAR2 DEFAULT NULL
                        ,p_information17        VARCHAR2 DEFAULT NULL
                        ,p_information18        VARCHAR2 DEFAULT NULL
                        ,p_information19        VARCHAR2 DEFAULT NULL
                        ,p_information20        VARCHAR2 DEFAULT NULL
                        ,p_location             VARCHAR2 DEFAULT NULL
                        ,p_return           OUT NOCOPY VARCHAR2
                        )IS

v_electronic_ret_id     NUMBER;
v_validation_status     VARCHAR2(30);

v_information1    VARCHAR2 (150);
v_information2    VARCHAR2 (150);
v_information3    VARCHAR2 (150);
v_information4    VARCHAR2 (150);
v_information5    VARCHAR2 (150);
v_information6    VARCHAR2 (150);
v_information7    VARCHAR2 (150);
v_information8    VARCHAR2 (150);
v_information9    VARCHAR2 (150);
v_information10   VARCHAR2 (150);
v_information11   VARCHAR2 (150);
v_information12   VARCHAR2 (150);
v_information13   VARCHAR2 (150);
v_information14   VARCHAR2 (150);
v_information15   VARCHAR2 (150);
v_information16   VARCHAR2 (150);
v_information17   VARCHAR2 (150);
v_information18   VARCHAR2 (150);
v_information19   VARCHAR2 (150);
v_information20   VARCHAR2 (150);

BEGIN
   v_information1    := p_information1;
   v_information2    := p_information2;
   v_information3    := p_information3;
   v_information4    := p_information4;
   v_information5    := p_information5;
   v_information6    := p_information6;
   v_information7    := p_information7;
   v_information8    := p_information8;
   v_information9    := p_information9;
   v_information10   := p_information10;
   v_information11   := p_information11;
   v_information12   := p_information12;
   v_information13   := p_information13;
   v_information14   := p_information14;
   v_information15   := p_information15;
   v_information16   := p_information16;
   v_information17   := p_information17;
   v_information18   := p_information18;
   v_information19   := p_information19;
   v_information20   := p_information20;

   v_validation_status := return_validation
                  (p_customer_trx_id    => p_customer_trx_id
                  ,p_occurrence_date    => p_occurrence_date
                  ,p_status             => p_status
                  ,p_information1       => v_information1
                  ,p_information2       => v_information2
                  ,p_information3       => v_information3
                  ,p_information4       => v_information4
                  ,p_information5       => v_information5
                  ,p_information6       => v_information6
                  ,p_information7       => v_information7
                  ,p_information8       => v_information8
                  ,p_information9       => v_information9
                  ,p_information10      => v_information10
                  ,p_information11      => v_information11
                  ,p_information12      => v_information12
                  ,p_information13      => v_information13
                  ,p_information14      => v_information14
                  ,p_information15      => v_information15
                  ,p_information16      => v_information16
                  ,p_information17      => v_information17
                  ,p_information18      => v_information18
                  ,p_information19      => v_information19
                  ,p_information20      => v_information20
                  ,p_location           => p_location
                  );

  IF v_validation_status IS NOT NULL THEN
    p_return := v_validation_status;
    RETURN;
  END IF;

  ret_insert_row(p_customer_trx_id     => p_customer_trx_id
                ,p_occurrence_date     => p_occurrence_date
                ,p_message             => p_message
                ,p_attribute1          => v_information1
                ,p_attribute2          => v_information2
                ,p_attribute3          => v_information3
                ,p_attribute4          => v_information4
                ,p_attribute5          => v_information5
                ,p_attribute6          => v_information6
                ,p_attribute7          => v_information7
                ,p_attribute8          => v_information8
                ,p_attribute9          => v_information9
                ,p_attribute10         => v_information10
                ,p_attribute11         => v_information11
                ,p_attribute12         => v_information12
                ,p_attribute13         => v_information13
                ,p_attribute14         => v_information14
                ,p_attribute15         => v_information15
                ,p_attribute16         => v_information16
                ,p_attribute17         => v_information17
                ,p_attribute18         => v_information18
                ,p_attribute19         => v_information19
                ,p_attribute20         => v_information20
                ,p_attribute_category  => p_location
                ,p_electronic_ret_id   => v_electronic_ret_id
                ,p_return              => p_return
                );
  --
  IF (p_return IS NULL) THEN
    UPDATE apps.cll_f031_electronic_trx_all
       SET status                 = p_status
          ,last_electronic_ret_id = v_electronic_ret_id
          ,url                    = p_url
          ,attribute2             = v_information1
          ,attribute3             = v_information2
     WHERE customer_trx_id = p_customer_trx_id;
  END IF;
  --p_return := null; --BUG 6916625
END process_return;

END xxcll_f031_electronic_api;
/
