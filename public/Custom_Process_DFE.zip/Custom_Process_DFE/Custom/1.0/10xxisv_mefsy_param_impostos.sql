delete from xxisv_mefsy_param_impostos;

insert into xxisv_mefsy_param_impostos (S_TABELA_Y, S_IPI, S_ICMS, S_ICMSST, S_DADO_ICMSST, S_PIS, S_COFINS, S_II, S_INSS, S_CSLL, S_ISS, S_IR, S_AUX01, S_AUX02, S_AUX03, S_AUX04, S_AUX05)
values ('Y', 'IPI_C', 'ICMS', 'ICMSST', '^[^ICMS]|C$|[^A-Z]', 'PIS_C', 'COFINS_C', 'II', 'INSS', 'CSLL', 'ISS_C', 'IR_R', 'PIS_R', 'COFINS_R', null, null, null);

commit;