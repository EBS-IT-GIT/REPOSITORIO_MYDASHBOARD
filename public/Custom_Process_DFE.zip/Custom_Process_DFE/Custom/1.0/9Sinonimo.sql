-- Create the synonym 
create or replace synonym XXISV_MEFSY_DFE
  for XXISV.XXISV_MECPC_DFE;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_DFE_EVENT
  for XXISV.XXISV_MECPC_DFE_EVENT;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_F031_ELECTRO_API
  for XXISV.XXCLL_F031_ELECTRONIC_API;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_JL_BR_SPED_PUB
  for XXISV.XXJL_BR_SPED_PUB;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_NFS_NOTIFICATION
  for XXISV.XXISV_MECVW_NFS_NOTIFICATION;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_NF_ITEM
  for XXISV.XXISV_MECVW_NF_ITEM;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_NF_ITEM_IMPOSTOS
  for XXISV.XXISV_MECVW_NF_ITEM_IMPOSTOS;

-- Create the synonym 
create or replace synonym XXISV_MEFSY_NF_NOTIFICATION
  for XXISV.XXISV_MECVW_NF_NOTIFICATION;
