UPDATE apps.ap_invoice_distributions_all
SET    global_attribute3 = (SELECT location_id
                            FROM   apps.hr_locations
                            WHERE  location_code = 'AR INTERNA')
     , last_update_date = sysdate
     , last_updated_by = 2070
WHERE  invoice_id = (SELECT invoice_id 
                     FROM   apps.ap_invoices_all ai
                           ,apps.ap_suppliers asup
                     WHERE  ai.vendor_id = asup.vendor_id
                     AND    invoice_num ='0000-00210518'
                     AND    vendor_name = 'EDICIONES GARI SRL')
AND    global_attribute3 = 142;
--3 Registros