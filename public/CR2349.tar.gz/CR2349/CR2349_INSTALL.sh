#!/bin/bash
# +=====================================================================================+
# | Copyright (c) 2012 Adecoagro, Martinez, Buenos Aires, Argentina
# |                           All Rights Reserved
# +=====================================================================================+
# |
# | FILENAME
# |   CR2349_INSTALL.sh
# |
# | DESCRIPTION
# |   Script para la implementacion del requerimiento CR2349
# |
# | HISTORY
# |   12-JUN-20  
# |
# +=====================================================================================+


clear
if ps -ef | grep _INSTALL.sh | grep -v CR2349_INSTALL.sh | grep -v grep &> /dev/null; then 
  echo "No es posible continuar ejecutando CR2349_INSTALL.sh, ya que hay una instalación en curso." 
  exit 0 
fi 


if [[ -z "$1" && -z "$2" && -z "$3" ]]; then 
  echo "Por favor, Ingrese la clave del usuario APPS"
  read -s APPS_PWD
  for i in `seq ${#APPS_PWD}`; do
  echo -n "*"
  done
  echo ""
  echo "Por favor, Ingrese la Base donde instalara la custom:"
  read DB
  DDBB=`echo "$DB" | tr '[a-z]' '[A-Z]'`
  echo ""
  echo "Por favor, Ingrese la clave del usuario BOLINF"
  read -s BOLINF_PWD
  for i in `seq ${#BOLINF_PWD}`; do
  echo -n "*"
  done
  echo ""
else
  APPS_PWD=$1
  DDBB=$2
  BOLINF_PWD=$3
fi

# Declaracion de variables
CRDATE=$(date +%Y%m%d)
CRNUM=CR2349
HOST=`hostname | sed s'/-ap-/-db-/g' | sed s'/-AP-/-DB-/g' | sed s'/-ap12/-db12/g' | sed s'/-AP12/-DB12/g' `
PORT=1521
CRDIR=`pwd`
. $NE_BASE/../EBSapps.env run
PATCHDIR=$NE_BASE/ADECO/patch

# Definicion y creacion de directorios
CROUT=$PATCHDIR"/"$CRNUM.out
CRERR=$PATCHDIR"/"$CRNUM.err
cd $CRDIR
find $CRDIR ! -path "*INSTALL*" ! -name "*.sh" -type f -delete
DOWNDBDIR=$CRDIR"/"BKPDDBB
mkdir -p $DOWNDBDIR
cd $DOWNDBDIR
mkdir -p xbol/12.0.0/FNDLOAD/CUSTOM
mkdir -p xbol/12.0.0/FNDLOAD/DFF
mkdir -p xbol/12.0.0/FNDLOAD/VALSET
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/DF
mkdir -p xbol/12.0.0/sql/DF
INSTDIR=$CRDIR"/"INSTALL
cd $PATCHDIR


AddAllLogs(){
 ALL_LOGS=`find $PATCHDIR -maxdepth 1 -name "*.log"`
 for FILES in $ALL_LOGS
 do
   FNAME=`basename $FILES`
   if [ "$2" = "FND" -o "$2" = "XML" ]; then
     `$XBOL_TOP/bin/ldtchk.sh $3 $1`
   fi
   if [ "$2" = "XML" ]; then
     echo ""
     echo "+---------------------------------------------------------------------------+" >> $1
     echo ""
   fi
   exec 0<"$FNAME"
   while read -r line
   do
     echo $line >> $1
   done
   rm -f $FNAME
   echo "" >> $1
 done
}

svn --username ADECO_DEV --password adecorepo info /crp3/svn/XXADECUSTOMS >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de resguardo" >> $CROUT; echo "" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando la solucion realizada en CR2349" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxadecustom.lct CR2349_9492.ldt XX_ADE_CUSTOM_HEADER CHANGE_REQUEST="CR2349"
AddAllLogs $CROUT "FND" "CR2349_9492.ldt"
mv CR2349_9492.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/CUSTOM

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF FACT_URUGUAY " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','FACT_URUGUAY','','$PATCHDIR','CR2349');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv FACT_URUGUAY* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF FACT_ARGENTINA1 " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','FACT_ARGENTINA1','','$PATCHDIR','CR2349');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv FACT_ARGENTINA1* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto SQL-DF FACT_ARGENTINA2 " >> $CROUT; echo "" >> $CROUT

echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Process_Sql('DF','FACT_ARGENTINA2','','$PATCHDIR','CR2349');
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

mv FACT_ARGENTINA2* $DOWNDBDIR/xbol/12.0.0/sql/DF

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET JLAR_AP_LEGAL_TRX_CATEGORY " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct JLAR_AP_LEGAL_TRX_CATEGORY.ldt VALUE_SET FLEX_VALUE_SET_NAME="JLAR_AP_LEGAL_TRX_CATEGORY"
AddAllLogs $CROUT "FND" "JLAR_AP_LEGAL_TRX_CATEGORY.ldt"
mv JLAR_AP_LEGAL_TRX_CATEGORY.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-VALSET XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/afffload.lct XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt VALUE_SET FLEX_VALUE_SET_NAME="XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY"
AddAllLogs $CROUT "FND" "XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt"
mv XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/VALSET

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Resguardando el objeto FNDLOAD-DFF FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y DOWNLOAD $FND_TOP/patch/115/import/xxafffload.lct FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt DESC_FLEX APPLICATION_SHORT_NAME="FND" DESCRIPTIVE_FLEXFIELD_NAME="FND_COMMON_LOOKUPS" DESCRIPTIVE_FLEX_CONTEXT_CODE="JLAR_LEGAL_TRX_CATEGORY" END_USER_COLUMN_NAME="XX_AP_COUNTRY"
AddAllLogs $CROUT "FND" "FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt"
mv FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt $DOWNDBDIR/xbol/12.0.0/FNDLOAD/DFF


more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de resguardo" >> $CROUT; echo "" >> $CROUT





echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Comenzando con el proceso de actualizacion " >> $CROUT; echo "" >> $CROUT; echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF FACT_URUGUAY " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/FACT_URUGUAY >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_URUGUAY.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/FACT_URUGUAY.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_URUGUAY.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/FACT_URUGUAY.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_URUGUAY.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF FACT_ARGENTINA1 " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/FACT_ARGENTINA1 >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_ARGENTINA1.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/FACT_ARGENTINA1.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_ARGENTINA1.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/FACT_ARGENTINA1.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_ARGENTINA1.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto SQL-DF FACT_ARGENTINA2 " >> $CROUT; echo "" >> $CROUT
sqlplus -s apps/$APPS_PWD @$INSTDIR/xbol/12.0.0/sql/DF/FACT_ARGENTINA2 >> $CROUT

if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_ARGENTINA2.sql &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/sql/DF/FACT_ARGENTINA2.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_ARGENTINA2.sql  >> $CROUT 2>> $CRERR
else
  cp $INSTDIR/xbol/12.0.0/sql/DF/FACT_ARGENTINA2.sql /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF >> $CROUT 2>> $CRERR
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/sql/DF/FACT_ARGENTINA2.sql -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET JLAR_AP_LEGAL_TRX_CATEGORY " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/JLAR_AP_LEGAL_TRX_CATEGORY.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-VALSET XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/VALSET/XX_AP_JLAR_AP_LEGAL_TRX_CATEGORY.ldt -m $CRNUM >> $CROUT 2>> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando el objeto FNDLOAD-DFF FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY " >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxafffload.lct $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt CUSTOM_MODE=FORCE
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt"
if ! ls /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt &> /dev/null; then 
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
  svn add /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt >> $CROUT 2>> $CRERR 
else
  cp $INSTDIR/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF >> $CROUT 2>> $CRERR 
fi
svn commit --force-log /crp3/svn/XXADECUSTOMS/xbol/12.0.0/FNDLOAD/DFF/FND_COMMON_LOOKUPS_JLARLEGALTRXCAT_XXAPCOUNTRY.ldt -m $CRNUM >> $CROUT 2>> $CRERR

. $NE_BASE/../EBSapps.env patch



. $NE_BASE/../EBSapps.env run

more "$CROUT" | grep -in error | grep -v compilation | grep -v "Compiling ON-ERROR trigger on form" >> $CRERR

echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Actualizando la solucion realizada en CR2349" >> $CROUT; echo "" >> $CROUT
FNDLOAD apps/$APPS_PWD 0 Y UPLOAD $FND_TOP/patch/115/import/xxadecustom.lct $INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2349_9492.ldt
AddAllLogs $CROUT "FND" "$INSTDIR/xbol/12.0.0/FNDLOAD/CUSTOM/CR2349_9492.ldt"

echo "Compilando objectos invalidos..." >> $CROUT
echo "DECLARE 
BEGIN 
  XX_ADE_CUSTOM_PKG.Compile_Objects;
END;
/
exit" | sqlplus -s APPS/$APPS_PWD >> $CROUT

echo "Fin de compilando objectos invalidos" >> $CROUT

echo "" >> $CROUT
echo "+---------------------------------------------------------------------------+" >> $CROUT
echo " Fin del proceso de actualizacion" >> $CROUT; echo "" >> $CROUT

mv $CRNUM*.sh $CRDIR
mv $CRNUM*.err $CRDIR
mv $CRNUM*.out $CRDIR
