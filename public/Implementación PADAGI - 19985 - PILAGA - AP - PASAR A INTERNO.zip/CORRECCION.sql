UPDATE  apps.ap_invoices_all aid
SET    global_attribute11 = 'FC INTERNA', global_attribute12 = 'Y', global_attribute13= '99', invoice_num = '00003-00006062 099',
       last_update_date = sysdate, last_updated_by = 2070
WHERE  invoice_num = '00003-00006062 001'
AND    vendor_id = (SELECT vendor_id FROM apps.ap_suppliers WHERE vendor_name like 'WAGNER NELSON A. Y ECKERDT LAURA%');
--1 Registro