-- Create table
create table EMI_CATEGORIA_EMB_GRUPO_RT
(
  ID_EMI_CATEGORIA_EMB_GRUPO_RT  NUMBER(28) not null,
  ID_EMI_CATEGORIA_EMB_GRUPO     NUMBER(28) not null,
  ID_ROTA                        NUMBER(28) not NULL
  
)
tablespace DADOS_BTI
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
  
  
  

-- Add comments to the table 
comment on table EMI_CATEGORIA_EMB_GRUPO_RT
  is 'GRUPO DE CATEGORIA DE EMBARQUE ROTAS';




alter table EMI_CATEGORIA_EMB_GRUPO_RT
  add constraint PK_ID_EMICATEGORIAEMBGRUPORT primary key (ID_EMI_CATEGORIA_EMB_GRUPO_RT)
  using index 
  tablespace INDICES_BTI
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
  

grant select, insert, update, delete on EMI_CATEGORIA_EMB_GRUPO_RT to TOOL;  


 
alter table EMI_CATEGORIA_EMB_GRUPO_RT
  add constraint FK_EMI_CATEGORIAEMBGRUPORT01 foreign key (ID_EMI_CATEGORIA_EMB_GRUPO)
  references EMI_CATEGORIA_EMB_GRUPO (ID_EMI_CATEGORIA_EMB_GRUPO);  
  

alter table EMI_CATEGORIA_EMB_GRUPO_RT
  add constraint FK_EMI_CATEGORIAEMBGRUPORT02 foreign key (ID_ROTA)
  references COL_ROTA (ID_ROTA);  
 


-- Create sequence 
create sequence SEQ_ID_EMI_CATEGORIAEMBGRUPORT
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
nocache;


CREATE OR REPLACE TRIGGER TRG_ID_EMI_CATEGORIAEMBGRUPORT
  BEFORE INSERT ON EMI_CATEGORIA_EMB_GRUPO_RT
  FOR EACH ROW

BEGIN
  SELECT SEQ_ID_EMI_CATEGORIAEMBGRUPORT.NEXTVAL
    INTO :NEW.ID_EMI_CATEGORIA_EMB_GRUPO_RT
    FROM DUAL;

END;
