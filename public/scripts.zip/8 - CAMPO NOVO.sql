-- Add/modify columns 
alter table EMI_CATEGORIA_EMB_GRUPO add operador_peso CHAR(1);
alter table EMI_CATEGORIA_EMB_GRUPO add peso NUMBER(7,2);

